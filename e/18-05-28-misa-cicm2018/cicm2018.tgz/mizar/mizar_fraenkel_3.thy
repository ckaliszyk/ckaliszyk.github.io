theory mizar_fraenkel_3
imports mizar_fraenkel "../mml/zfmisc_1" "../mml/subset_1"
begin  
    
  
definition ModeProd_prefix ("_ \<times> _" [101,102] 101)
  where "A \<times> B \<equiv> define_ty(object, \<lambda>_. True, \<lambda> x.  x is pair \<and> x`1 is A \<and> x`2 is B)"

lemma [simp]:"[x,y] is pair" using xtuple_0_def_1 by auto     
     
theorem ModeProd:
  "x is A\<times>B iff x is pair \<and> x`1 is A \<and> x`2 is B"
proof
  assume "x is A\<times>B"
  thus "x is pair \<and> x`1 is A \<and> x`2 is B" using  def_ty_property[OF ModeProd_prefix_def,THEN conjunct1] by auto 
next
  assume "x is pair \<and> x`1 is A \<and> x`2 is B"
  thus "x is A\<times>B" using def_ty_property[OF ModeProd_prefix_def,THEN conjunct2] by auto  
qed  

theorem ModeProd1:
  "[x,y] is A\<times>B iff x is A \<and> y is B"
proof
  assume A1: "[x,y] is A\<times>B"
  hence "[x,y]`1=x" "[x,y]`2=y" using xtuple_0_reduce by auto  
  thus " x is A \<and> y is B" using  ModeProd A1 by auto 
next
  have A2: "[x,y]`1=x" "[x,y]`2=y" using xtuple_0_reduce by auto  
  assume "x is A \<and> y is B"    
  thus "[x,y] is A\<times>B" using A2 ModeProd by auto  
qed    
  
theorem ModeProdI:
  assumes "inhabited(A)" "inhabited(B)" 
  shows "inhabited(A\<times>B)"
proof
  have "(the A) is A" "(the B) is B" using assms by auto
  thus "[the A,the B] is A\<times>B" using ModeProd1 by auto  
qed
    
lemma pair: "x is pair \<Longrightarrow> [x`1,x`2] = x"
proof-
  assume "x is pair"
  then obtain y z where
    A1: "x=[y,z]" using xtuple_0_def_1 by auto
  hence "x`1 = y" "x`2 = z" using xtuple_0_reduce by auto
  thus "[x`1,x`2] = x" using A1 by auto     
qed   
  
theorem ModeProdS:  
   assumes "inhabited(A)" "inhabited(B)" 
           "sethood_prop(A)" "sethood_prop(B)"
   shows "sethood_prop(A\<times>B)"
unfolding sethood_prop_def
proof-
  obtain X1 where
    SetH1[ty]: "X1 be set" and Prop1: "for x being object holds x be A \<longleftrightarrow> x in X1" using assms sethood by auto
  obtain X2 where
        SetH2[ty]: "X2 be set" and Prop2: "for x being object holds x be B \<longleftrightarrow> x in X2" using assms sethood by auto
  show "ex IT be set st  (\<forall>x : A\<times>B. x in IT)"
  proof(rule bexI[of _ _ "[:X1,X2:]"],auto)
    show "inhabited(A \<times> B)" using ModeProdI assms by auto
    fix x  
    assume "x is A\<times>B"
    hence [ty]: "x`1 is A" "x`2 is B" "x is pair" using ModeProd by auto
    hence "[x`1,x`2] in [:X1,X2:]" using Prop1 Prop2 zfmisc_1_th_87 by auto  
    thus "x in [:X1,X2:]" using pair by auto
  qed mauto
qed  

abbreviation 
  "COS(P) \<equiv> \<lambda> x. P(x`1,x`2)"
  
lemma Ifft: "B\<longleftrightarrow>C \<Longrightarrow> A\<longleftrightarrow>B \<Longrightarrow> A\<longleftrightarrow>C" by simp    
  
theorem ModeProdR: 
  assumes "inhabited(L1)" "inhabited(L2)" 
  shows "(\<exists> x :L1\<times>L2 . COS(P)(x))\<longleftrightarrow> (\<exists> x1:L1 . \<exists>x2:L2 . P(x1,x2))"
proof
  assume "\<exists> x :L1\<times>L2 . COS(P)(x)"
  then obtain x where
    A1: "x is L1\<times>L2" and A2: "COS(P)(x)" using ModeProdI assms by auto 
  thus "\<exists> x1:L1 . \<exists>x2:L2 . P(x1,x2)" using A2 assms ModeProd by auto    
next
  assume "\<exists> x1:L1 . \<exists>x2:L2 . P(x1,x2)"
  then obtain x1 x2 where
    A1:"x1 is L1" "x2 is L2" "P(x1,x2)" using assms by auto
  hence "[x1,x2] is L1\<times>L2" using ModeProd xtuple_0_reduce by auto
  thus   "\<exists> x :L1\<times>L2 . COS(P)(x)" using pair A1 ModeProdI[OF assms] xtuple_0_reduce by auto
qed  
  
theorem  Fraenkel1:
 assumes "inhabited(L1)" "sethood_prop(L1)"  
  shows "x in Fraenkel1(P, L1, Q) \<longleftrightarrow> (\<exists>y1 : L1. x = P(y1) \<and> Q(y1))"
using Fraenkel_A1[OF assms] by auto

theorem Fraenkel2:
    assumes "inhabited(L1)" "inhabited(L2)" 
           "sethood_prop(L1)" "sethood_prop(L2)"
    shows "x in Fraenkel1(COS(P), L1\<times>L2, COS(Q)) \<longleftrightarrow> (\<exists>y1 : L1.\<exists>y2 : L2. x = P(y1,y2) \<and> Q(y1,y2))"
by (rule Ifft[OF _  Fraenkel1],rule Ifft[OF _  ModeProdR],auto simp add: assms ModeProdS ModeProdI)           
    
abbreviation
  "FraenkelT(P,L1,L2,L3,Q) \<equiv> Fraenkel1(COS (COS(P)),L1\<times>L2\<times>L3,COS(COS(Q)))"   

syntax
  "_FraenkelT" :: "Set \<Rightarrow> vs \<Rightarrow> Ty \<Rightarrow> vs \<Rightarrow> Ty \<Rightarrow> vs \<Rightarrow> Ty \<Rightarrow> o \<Rightarrow> Set" ("{ _ where _ be _, _ be _ ,_ be _ : _ }")
translations
 "{ f where x be D, y be D2,z be D3 : P }" \<rightharpoonup> "CONST FraenkelT((%x y z. f), D, D2, D3, (%x y z. P))"

 
 
 theorem Fraenkel3:
  assumes "inhabited(L1)" "inhabited(L2)" "inhabited(L3)" 
           "sethood_prop(L1)" "sethood_prop(L2)" "sethood_prop(L3)" 
  shows "x in { P(x,y,z) where x be L1, y be L2,z be L3 : Q(x,y,z) } \<longleftrightarrow> 
         (\<exists>y1 : L1.\<exists>y2 : L2.\<exists>y3 : L3. x = P(y1,y2,y3) \<and> Q(y1,y2,y3))"
   by (rule Ifft[OF _  Fraenkel2],rule Ifft[OF _  ModeProdR],auto simp add: assms ModeProdS ModeProdI)           
     
theorem Fraenkel4:
  assumes "inhabited(L1)" "inhabited(L2)" "inhabited(L3)" "inhabited(L4)" 
           "sethood_prop(L1)" "sethood_prop(L2)" "sethood_prop(L3)" "sethood_prop(L4)" 
  shows "x in Fraenkel1(COS(COS(COS(P))), L1\<times>L2\<times>L3\<times>L4, COS(COS(COS(Q)))) \<longleftrightarrow> 
         (\<exists>y1 : L1.\<exists>y2 : L2.\<exists>y3 : L3. \<exists>y4:L4. x = P(y1,y2,y3,y4) \<and> Q(y1,y2,y3,y4))"
   by (rule Ifft[OF _  Fraenkel3],rule Ifft[OF _  ModeProdR],auto simp add: assms ModeProdS ModeProdI)           
    


lemma "COS(COS(P))(x) \<equiv>P(x`1`1,x`1`2,x`2)" by simp    

end

    
