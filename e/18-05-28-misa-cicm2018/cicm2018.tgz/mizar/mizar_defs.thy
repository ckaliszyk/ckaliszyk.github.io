theory mizar_defs
imports mizar_ty
begin

definition "pred_means(cond) \<longleftrightarrow> cond"
abbreviation (input) pred_means_p  ("pred _ means _" [0,0] 10)
  where "pred P means C \<equiv> P \<longleftrightarrow> pred_means(C)"

lemma pred_means_property:
  assumes df:"pred P means C"
    and "True"
  shows 
     "(C\<longrightarrow> P) \<and> (P\<longrightarrow>C)\<and>(P \<longleftrightarrow> C)" (* Add sth... *)
  using df unfolding pred_means_def by auto

definition "pred_means_if1(cond1,case1,condo) \<longleftrightarrow> ((case1\<longrightarrow> cond1)\<and>(\<not>case1\<longrightarrow>condo))"
abbreviation (input) pred_means_if1_p  ("pred _ means _ if _ otherwise _" [0,0,0,0] 10)
  where "pred P means cond1 if case1 otherwise condo \<equiv> P \<longleftrightarrow> pred_means_if1(cond1,case1,condo)"

lemma pred_means_if1_property:
  assumes df:"pred P means cond1 if case1 otherwise condo"
    and "True"
  shows 
     "(((case1\<and>cond1)\<or>(\<not>case1\<and>condo))\<longrightarrow> P) 
    \<and> (P\<longrightarrow>((case1\<longrightarrow> cond1)\<and>(\<not>case1\<longrightarrow>condo)))\<and>
     (P \<longleftrightarrow> ((case1\<longrightarrow> cond1)\<and>(\<not>case1\<longrightarrow>condo)))" (* Add sth... *)
  using df unfolding pred_means_if1_def by auto    

definition "pred_means_if2(cond1,case1,cond2,case2,condo) \<longleftrightarrow> 
      ((case1\<longrightarrow> cond1)\<and>(case2\<longrightarrow>cond2)\<and>(\<not>case1\<and>\<not>case2\<longrightarrow>condo))"
abbreviation (input) pred_means_if2_p  ("pred _ means _ if _ , _ if _ otherwise _" [0,0,0,0,0,0] 10)
  where "pred P means cond1 if case1, cond2 if case2 otherwise condo \<equiv> 
            P \<longleftrightarrow> pred_means_if2(cond1,case1,cond2,case2,condo)"

lemma pred_means_if2_property:
  assumes df:"pred P means cond1 if case1, cond2 if case2 otherwise condo"
    and cons: "case1\<and>case2\<longrightarrow> (cond1 \<longleftrightarrow>cond2)"
  shows 
     "(((case1\<and> cond1) \<or> (case2\<and>cond2) \<or> (\<not>case1\<and>\<not>case2\<and>condo))\<longrightarrow>P) 
    \<and> (P\<longrightarrow>((case1\<longrightarrow> cond1)\<and>(case2\<longrightarrow>cond2)\<and>(\<not>case1\<and>\<not>case2\<longrightarrow>condo)))\<and>
     (P \<longleftrightarrow> ((case1\<longrightarrow> cond1)\<and>(case2\<longrightarrow>cond2)\<and>(\<not>case1\<and>\<not>case2\<longrightarrow>condo)))"
proof-
  have "((case1\<longrightarrow> cond1) \<and> (case2\<longrightarrow>cond2) \<and> (\<not>case1\<and>\<not>case2\<longrightarrow>condo))\<longrightarrow>P"
      using df unfolding pred_means_if2_def by auto
  hence "(((case1\<and> cond1) \<or> (case2\<and>cond2) \<or> (\<not>case1\<and>\<not>case2\<and>condo))\<longrightarrow>P)" using cons by auto 
  thus ?thesis using df unfolding pred_means_if2_def cons by auto
qed 
  
definition "pred_means_if3(cond1,case1,cond2,case2,cond3,case3,condo) \<longleftrightarrow> 
      ((case1\<longrightarrow> cond1)\<and>(case2\<longrightarrow>cond2)\<and>(case3\<longrightarrow>cond3)\<and>(\<not>case1\<and>\<not>case2\<and>\<not>case3 \<longrightarrow> condo))"
abbreviation (input) pred_means_if3_p  ("pred _ means _ if _ , _ if _ , _ if _ otherwise _" [0,0,0,0,0,0,0,0] 10)
  where "pred P means cond1 if case1, cond2 if case2, cond3 if case3 otherwise condo \<equiv> 
            P \<longleftrightarrow> pred_means_if3(cond1,case1,cond2,case2,cond3,case3,condo)"

lemma pred_means_if3_property:
  assumes df:"pred P means cond1 if case1, cond2 if case2, cond3 if case3 otherwise condo"
    and cons: "(case1\<and>case2\<longrightarrow> (cond1 \<longleftrightarrow>cond2))\<and>
               (case1\<and>case3 \<longrightarrow> (cond1\<longleftrightarrow>cond3))\<and>
               (case2\<and>case3 \<longrightarrow>(cond2 \<longleftrightarrow>cond3))"
  shows 
     "(((case1\<and> cond1) \<or> (case2\<and>cond2) \<or> (case3\<and> cond3)\<or> (\<not>case1\<and>\<not>case2\<and>\<not>case3\<and>condo))\<longrightarrow>P) 
    \<and> (P\<longrightarrow>((case1\<longrightarrow> cond1)\<and>(case2\<longrightarrow>cond2)\<and>(case3\<longrightarrow> cond3)\<and>(\<not>case1\<and>\<not>case2\<and>\<not>case3\<longrightarrow>condo)))\<and>
     (P \<longleftrightarrow> ((case1\<longrightarrow> cond1)\<and>(case2\<longrightarrow>cond2)\<and>(case3\<longrightarrow>cond3)\<and>(\<not>case1\<and>\<not>case2\<and>\<not>case3\<longrightarrow>condo)))"
proof-
  have "((case1\<longrightarrow> cond1) \<and> (case2\<longrightarrow>cond2) \<and>(case3\<longrightarrow>cond3)\<and>(\<not>case1\<and>\<not>case2\<and>\<not>case3\<longrightarrow>condo))\<longrightarrow>P"
      using df unfolding pred_means_if3_def by auto
  hence "(((case1\<and> cond1) \<or> (case2\<and>cond2) \<or> (case3\<and> cond3)\<or> (\<not>case1\<and>\<not>case2\<and>\<not>case3\<and>condo))\<longrightarrow>P)" using cons by auto 
  thus ?thesis using df unfolding pred_means_if3_def cons by auto
qed   
  
  
  
    
definition "pred_antonym(cond) \<longleftrightarrow> \<not> cond"
abbreviation (input) pred_antonym_p  ("antonym pred _ for _" [0,0] 10)
  where "antonym pred P for C \<equiv> P \<longleftrightarrow> pred_antonym(C)"

lemma pred_antonym_property:
  assumes df:"antonym pred AP for P"
    and "True"
  shows "(AP \<longleftrightarrow> \<not> P)"
  using df unfolding pred_antonym_def by auto

definition "func_synonym(term) = term"
abbreviation (input) func_synonym_p  ("synonym func _ for _" [0,0] 10)
  where "synonym func T for term \<equiv> T = func_synonym(term)"

lemma func_synonym_property:
  assumes df:"synonym func T for term"
    and "True"
  shows "(T=term)"
  using df unfolding func_synonym_def by auto
    
    
(*func means*)

definition "func_means(ty, cond) = theProp(ty, cond)"
abbreviation func_means_p  ("func _ \<rightarrow> _ means _" [0,0] 10)
  where "func P \<rightarrow> R means D \<equiv> P = func_means(R, D)"

definition "func_assume_means(as, ty, cond) = the define_ty(ty, \<lambda>_. as, cond)"
abbreviation func_assume_means_p  ("assume _ func _ \<rightarrow> _ means _" [0,0,0,0] 10)
  where "assume as func def \<rightarrow> ty means cond \<equiv> def = func_assume_means(as, ty, cond)"

definition "func_means_if1(ty, cond1,case1,condo) = 
   theProp(ty, \<lambda>it. (case1 \<longrightarrow> cond1(it)) \<and> 
                    ( \<not>case1 \<longrightarrow> condo(it)))"
  
abbreviation func_means_if1_p  ("func _ \<rightarrow> _ means  _ if _ otherwise _ " [0,0,0,0] 10)
  where "func P \<rightarrow> R means cond1 if case1 otherwise condo \<equiv> P = func_means_if1(R, cond1, case1,condo)"

definition "func_assume_means_if1(as,ty, cond1,case1,condo) = 
   the define_ty(ty, \<lambda>_.as, \<lambda>it. (case1 \<longrightarrow> cond1(it)) \<and> 
                    ( \<not>case1 \<longrightarrow> condo(it)))"

abbreviation func_assume_means_if1_p  ("assume _ func _ \<rightarrow> _ means  _ if _ otherwise _ " [0,0,0,0,0] 10)
  where "assume as func P \<rightarrow> R means cond1 if case1 otherwise condo \<equiv> P = func_assume_means_if1(as,R, cond1, case1,condo)"

definition "func_means_if1o(ty, cond1,case1) = func_assume_means(case1, ty, cond1)"
abbreviation func_means_if1o_p  ("func _ \<rightarrow> _ means  _ if _ " [0,0,0] 10)
  where "func P \<rightarrow> R means cond1 if case1 \<equiv> P = func_means_if1o(R, cond1, case1)"
    
definition "func_means_if2(ty, cond1,case1,cond2,case2,condo) = 
   theProp(ty, \<lambda>it. (case1 \<longrightarrow> cond1(it)) \<and> 
                    (case2 \<longrightarrow> cond2(it)) \<and> 
                    ( \<not>case1 \<and> \<not>case2 \<longrightarrow> condo(it)))"
abbreviation func_means_if2_p  ("func _ \<rightarrow> _ means  _ if _ , _ if _ otherwise _ " [0,0,0,0,0,0] 10)
  where "func P \<rightarrow> R means cond1 if case1, cond2 if case2 otherwise condo \<equiv> P = func_means_if2(R, cond1, case1,cond2,case2,condo)"

definition "func_means_if2o(ty, cond1,case1,cond2,case2) = 
    func_assume_means(case1\<or>case2, ty, \<lambda>it. (case1\<longrightarrow>cond1(it))\<and>(case2\<longrightarrow>cond2(it)))"
abbreviation func_means_if2o_p  ("func _ \<rightarrow> _ means _ if _ , _ if _ " [0,0,0,0,0] 10)
  where "func P \<rightarrow> R means cond1 if case1, cond2 if case2 \<equiv> P = func_means_if2o(R, cond1, case1,cond2,case2)"

definition "func_means_if3(ty, cond1,case1,cond2,case2,cond3,case3,condo) = 
   theProp(ty, \<lambda>it. (case1 \<longrightarrow> cond1(it)) \<and> 
                    (case2 \<longrightarrow> cond2(it)) \<and> 
                    (case3 \<longrightarrow> cond3(it)) \<and> 
                    ( \<not>case1 \<and> \<not>case2 \<and>\<not>case3 \<longrightarrow> condo(it)))"
abbreviation func_means_if3_p  ("func _ \<rightarrow> _ means  _ if _ , _ if _ , _ if _ otherwise _ " [0,0,0,0,0,0,0,0] 10)
  where "func P \<rightarrow> R means cond1 if case1, cond2 if case2, cond3 if case3 otherwise condo \<equiv> 
         P = func_means_if3(R, cond1, case1,cond2,case2,cond3,case3,condo)"

definition "func_means_if4(ty, cond1,case1,cond2,case2,cond3,case3,cond4,case4,condo) = 
   theProp(ty, \<lambda>it. (case1 \<longrightarrow> cond1(it)) \<and> 
                    (case2 \<longrightarrow> cond2(it)) \<and> 
                    (case3 \<longrightarrow> cond3(it)) \<and>
                    (case4 \<longrightarrow> cond4(it)) \<and> 
                    ( \<not>case1 \<and> \<not>case2 \<and>\<not>case3\<and>\<not>case4 \<longrightarrow> condo(it)))"
abbreviation func_means_if4_p  ("func _ \<rightarrow> _ means  _ if _ , _ if _ , _ if _ , _ if _ otherwise _ " 
     [0,0,0,0,0,0,0,0,0,0] 10)
  where "func P \<rightarrow> R means cond1 if case1, cond2 if case2, cond3 if case3, cond4 if case4 otherwise condo \<equiv> 
         P = func_means_if4(R, cond1, case1,cond2,case2,cond3,case3,cond4,case4,condo)"
    
lemma func_means_property:
  assumes df: "func f \<rightarrow> ty means cond"
    and m: "inhabited(ty)"
    and ex: "\<exists>x:ty. cond(x)"
    and un: "\<And>x y. x be ty \<Longrightarrow> y be ty \<Longrightarrow>
                cond(x) \<Longrightarrow> cond(y) \<Longrightarrow> x = y"
  shows "f be ty \<and> (x be ty \<and> cond(x) \<longrightarrow> x = f) \<and> cond(f)"
  unfolding df func_means_def
proof (intro conjI)
  have e: "\<exists>\<^sub>Mx. x be define_ty(ty,\<lambda>_. True,cond)" using Bex_def[OF m] ex def_ty_property_true by auto
  hence f: "(theProp(ty,cond)) be define_ty(ty,\<lambda>_. True,cond)" using choice_ax inhabited_def by auto
  thus g: "(theProp(ty,cond)) be ty" using def_ty_property_true e object_root by auto
  show h: "cond(theProp(ty,cond))" using def_ty_property_true e f object_root by auto
  show "x be ty \<and> cond(x) \<longrightarrow> x = theProp(ty,cond)" using un g h by auto
qed
  
lemma func_assume_means_property:
assumes df: "assume as func f \<rightarrow> ty means cond"
   and assume_ex: "as \<Longrightarrow> \<exists>x:ty. cond(x)"
   and assume_un: "\<And>x y. as \<Longrightarrow> x be ty \<Longrightarrow> y be ty \<Longrightarrow>
       cond(x) \<Longrightarrow> cond(y) \<Longrightarrow> x = y"
   and mode_ex: "inhabited(ty)"
shows
   "f be ty \<and> (as \<and> x be ty \<and> cond(x) \<longrightarrow> x = f) \<and> (as \<longrightarrow> cond(f))"
proof (cases "as")
   assume r: "as"
   hence rdf: " f =  theProp(ty,cond)" using df func_assume_means_def by simp
   have un1: "\<And>x y. x be ty \<Longrightarrow> y be ty \<Longrightarrow>
     cond(x) \<Longrightarrow> cond(y) \<Longrightarrow> x = y" using assume_un r by simp
   show "f be ty \<and> (as \<and> x be ty \<and> cond(x) \<longrightarrow> x = f) \<and> (as \<longrightarrow> cond(f))"
     using func_means_property[unfolded func_means_def,OF rdf mode_ex assume_ex[OF r]] assume_un r by auto
next
  assume nR: "not as"
  have "(the ty) be ty" using choice_ax mode_ex by auto
  hence "inhabited(define_ty(ty,\<lambda>_. as,cond))" using def_ty_property[THEN conjunct2] using nR by simp
  hence "f be define_ty(ty,\<lambda>_. as,cond)" using choice_ax df[unfolded func_assume_means_def] inhabited_def by auto
  thus "f be ty \<and> (as \<and> x be ty \<and> cond(x) \<longrightarrow> x = f) \<and> (as \<longrightarrow> cond(f))"
    using def_ty_property[THEN conjunct1] nR by auto
qed
  
lemma func_means_if1_property:
  assumes df: "func f \<rightarrow> ty means cond1 if case1 otherwise condo"
    and m: "inhabited(ty)"
    and ex: "(case1 \<longrightarrow> (\<exists>x:ty. cond1(x)))\<and>
             (\<not>case1 \<longrightarrow> (\<exists>x:ty. condo(x)))"
    and un: "\<And>x y. x be ty \<Longrightarrow> y be ty \<Longrightarrow>
                (case1 \<and> cond1(x)\<and> cond1(y) \<longrightarrow> x = y)\<and>               
                (\<not>case1 \<and>  condo(x)\<and> condo(y) \<longrightarrow> x = y)"
    and co:"\<And>x. True" (*taka formuła jest w Mizarze, ja bym zostawił aby łatwo dopasowywac mis*)
  shows "f be ty 
         \<and> (x be ty \<longrightarrow> ((case1 \<and> cond1(x))\<or>(\<not>case1 \<and>  condo(x))) \<longrightarrow> x=f ) 
         \<and> ((case1 \<longrightarrow> cond1(f))\<and>(\<not>case1 \<longrightarrow> condo(f)))"
proof-
  let ?C = "\<lambda>it.(case1 \<longrightarrow> cond1(it))\<and> (\<not>case1 \<longrightarrow>  condo(it))"
  have dfF:" f= func_means(ty,?C)" using df unfolding func_means_def func_means_if1_def by auto
  have exF: "\<exists>x:ty. ?C(x)" using ex m co by blast     
  have unF: "\<And>x y. x be ty \<Longrightarrow> y be ty \<Longrightarrow>
                ?C(x) \<Longrightarrow> ?C(y) \<Longrightarrow> x = y" using un by blast
  show ?thesis using func_means_property[OF dfF m exF unF] by auto
qed 

lemma func_assume_means_if1_property:
assumes df: "assume as func f \<rightarrow> ty means cond1 if case1 otherwise condo"
   and assume_ex: "as \<Longrightarrow> (case1 \<longrightarrow> (\<exists>x:ty. cond1(x)))\<and>
             (\<not>case1 \<longrightarrow> (\<exists>x:ty. condo(x)))"
   and assume_un: "\<And>x y. as \<Longrightarrow> x be ty \<Longrightarrow> y be ty \<Longrightarrow>
                (case1 \<and> cond1(x)\<and> cond1(y) \<longrightarrow> x = y)\<and>               
                (\<not>case1 \<and>  condo(x)\<and> condo(y) \<longrightarrow> x = y)"
   and mode_ex: "inhabited(ty)"
 shows
   "f be ty 
         \<and> (as \<and> x be ty \<longrightarrow> ((case1 \<and> cond1(x))\<or>(\<not>case1 \<and>  condo(x))) \<longrightarrow> x=f ) 
         \<and> (as \<longrightarrow> (case1 \<longrightarrow> cond1(f))\<and>(\<not>case1 \<longrightarrow> condo(f)))"
proof-
   let ?C = "\<lambda>it.(case1 \<longrightarrow> cond1(it))\<and> (\<not>case1 \<longrightarrow>  condo(it))"

   have D: "assume as func f \<rightarrow> ty means ?C" using df func_assume_means_if1_def func_assume_means_def by auto
   have ex: "as \<Longrightarrow> \<exists>x:ty. ?C(x)" using assume_ex mode_ex by auto
   have un: "\<And>x y. as \<Longrightarrow> x be ty \<Longrightarrow> y be ty \<Longrightarrow>
       ?C(x) \<Longrightarrow> ?C(y) \<Longrightarrow> x = y" using assume_un by auto 
  thus ?thesis  using 
    func_assume_means_property[OF D ex un mode_ex] by auto  
qed  
  
  
  
  
lemma func_means_if2_property:
  assumes df: "func f \<rightarrow> ty means cond1 if case1, cond2 if case2 otherwise condo"
    and m: "inhabited(ty)"
    and ex: "(case1 \<longrightarrow> (\<exists>x:ty. cond1(x))) \<and> (case2 \<longrightarrow> (\<exists>x:ty. cond2(x)))\<and>
             (\<not>case1\<and>\<not>case2\<longrightarrow> (\<exists>x:ty. condo(x)))"
    and un: "\<And>x y. x be ty \<Longrightarrow> y be ty \<Longrightarrow>
                (case1 \<and> cond1(x)\<and> cond1(y) \<longrightarrow> x = y)\<and>
                (case2 \<and> cond2(x)\<and> cond2(y) \<longrightarrow> x = y)\<and> 
                (\<not>case1 \<and> \<not>case2\<and>  condo(x)\<and> condo(y) \<longrightarrow> x = y)"
    and co:"\<forall>x: ty. case1 \<and> case2 \<longrightarrow> (cond1(x) \<longleftrightarrow> cond2(x))"
  shows "f be ty 
         \<and> (x be ty \<longrightarrow> ((case1 \<and> cond1(x))\<or>(case2 \<and>cond2(x))\<or>(\<not>case1 \<and> \<not>case2 \<and>  condo(x))) \<longrightarrow> x=f )
         \<and> ((case1 \<longrightarrow> cond1(f))\<and>(case2 \<longrightarrow>cond2(f))\<and>(\<not>case1 \<and> \<not>case2 \<longrightarrow> condo(f)))"
proof-
  let ?C = "\<lambda>it.(case1 \<longrightarrow> cond1(it))\<and>(case2 \<longrightarrow>cond2(it))\<and> (\<not>case1 \<and> \<not>case2 \<longrightarrow>  condo(it))"
  have dfF:" f= func_means(ty,?C)" using df unfolding func_means_def func_means_if2_def by auto
  have exF: "\<exists>x:ty. ?C(x)" using ex m co by blast     
  have unF: "\<And>x y. x be ty \<Longrightarrow> y be ty \<Longrightarrow>
                ?C(x) \<Longrightarrow> ?C(y) \<Longrightarrow> x = y" using un by blast
  show ?thesis using func_means_property[OF dfF m exF unF,of x] co[THEN bspec] m by auto
qed 
  
  
lemma func_means_if3_property:
  assumes df: "func f \<rightarrow> ty means cond1 if case1, cond2 if case2, cond3 if case3 otherwise condo"
    and m: "inhabited(ty)"
    and ex: "(case1 \<longrightarrow> (\<exists>x:ty. cond1(x))) \<and> (case2 \<longrightarrow> (\<exists>x:ty. cond2(x)))\<and>
             (case3 \<longrightarrow> (\<exists>x:ty. cond3(x)))\<and>
             (\<not>case1\<and>\<not>case2\<and>\<not>case3 \<longrightarrow> (\<exists>x:ty. condo(x)))"
    and un: "\<And>x y. x be ty \<Longrightarrow> y be ty \<Longrightarrow>
                (case1 \<and> cond1(x)\<and> cond1(y) \<longrightarrow> x = y)\<and>
                (case2 \<and> cond2(x)\<and> cond2(y) \<longrightarrow> x = y)\<and> 
                (case3 \<and> cond3(x)\<and> cond3(y) \<longrightarrow> x = y)\<and> 
                (\<not>case1 \<and> \<not>case2\<and> \<not>case3\<and> condo(x)\<and> condo(y) \<longrightarrow> x = y)"
    and co:"\<forall>x: ty. (case1 \<and> case2 \<longrightarrow> (cond1(x) \<longleftrightarrow> cond2(x)))\<and>
                    (case1 \<and> case3 \<longrightarrow> (cond1(x) \<longleftrightarrow> cond3(x)))\<and>
                    (case2 \<and> case3 \<longrightarrow> (cond2(x) \<longleftrightarrow> cond3(x))) "
  shows "f be ty 
         \<and> (x be ty \<longrightarrow> ((case1 \<and> cond1(x))\<or> (case2 \<and>cond2(x))\<or>
                        (case3 \<and> cond3(x))\<or>(\<not>case1 \<and> \<not>case2 \<and> \<not>case3 \<and>  condo(x))) \<longrightarrow> x = f)
         \<and> ((case1 \<longrightarrow> cond1(f))\<and>(case2 \<longrightarrow>cond2(f))\<and>(case3 \<longrightarrow>cond3(f))
         \<and>  (\<not>case1 \<and> \<not>case2 \<and>\<not>case3 \<longrightarrow> condo(f)))"
proof-
  let ?C = "\<lambda>it.(case1 \<longrightarrow> cond1(it))\<and>(case2 \<longrightarrow>cond2(it))\<and>(case3 \<longrightarrow>cond3(it))\<and>
      (\<not>case1 \<and> \<not>case2 \<and> \<not>case3 \<longrightarrow>  condo(it))"
  have dfF:" f= func_means(ty,?C)" using df unfolding func_means_def func_means_if3_def by auto
  have exF: "\<exists>x:ty. ?C(x)" 
    proof (cases "case1\<or>case2")
    case True
      thus ?thesis using ex m co by blast
    next
     case False
      thus ?thesis using ex m co by auto
    qed
   have unF: "\<And>x y. x be ty \<Longrightarrow> y be ty \<Longrightarrow>
                ?C(x) \<Longrightarrow> ?C(y) \<Longrightarrow> x = y" 
   proof-
     fix x y assume A:"x be ty" "y be ty"
     assume C: "?C(x)" "?C(y)"
     have T1: "case1\<or>case2 \<longrightarrow> x = y" using un[OF A] C[THEN conjunct1] C[THEN conjunct2,THEN conjunct1] by auto  
     have T2: "case3 \<longrightarrow> x = y" using un[OF A] C[THEN conjunct2,THEN conjunct2] by auto  
     have "\<not>case1 \<and> \<not>case2 \<and> \<not>case3 \<longrightarrow> x = y" 
         using un[OF A] C[THEN conjunct2,THEN conjunct2,THEN conjunct2] by auto  
     thus "x=y" using T1 T2 by auto
   qed    
  show ?thesis using func_means_property[OF dfF m exF unF,of x] co[THEN bspec] m by auto
qed 

lemma func_means_if4_property:
  assumes df: "func f \<rightarrow> ty means cond1 if case1, cond2 if case2, cond3 if case3, cond4 if case4 otherwise condo"
    and m: "inhabited(ty)"
    and ex: "(case1 \<longrightarrow> (\<exists>x:ty. cond1(x))) \<and> (case2 \<longrightarrow> (\<exists>x:ty. cond2(x)))\<and>
             (case3 \<longrightarrow> (\<exists>x:ty. cond3(x))) \<and> (case4 \<longrightarrow> (\<exists>x:ty. cond4(x)))\<and>
             (\<not>case1\<and>\<not>case2\<and>\<not>case3\<and>\<not>case4 \<longrightarrow> (\<exists>x:ty. condo(x)))"
    and un: "\<And>x y. x be ty \<Longrightarrow> y be ty \<Longrightarrow>
                (case1 \<and> cond1(x)\<and> cond1(y) \<longrightarrow> x = y)\<and>
                (case2 \<and> cond2(x)\<and> cond2(y) \<longrightarrow> x = y)\<and> 
                (case3 \<and> cond3(x)\<and> cond3(y) \<longrightarrow> x = y)\<and> 
                (case4 \<and> cond4(x)\<and> cond4(y) \<longrightarrow> x = y)\<and>           
                (\<not>case1 \<and> \<not>case2\<and> \<not>case3\<and>\<not>case4 \<and>condo(x)\<and> condo(y) \<longrightarrow> x = y)"
    and co:"\<forall>x: ty. (case1 \<and> case2 \<longrightarrow> (cond1(x) \<longleftrightarrow> cond2(x)))\<and>
                    (case1 \<and> case3 \<longrightarrow> (cond1(x) \<longleftrightarrow> cond3(x)))\<and>
                    (case1 \<and> case4 \<longrightarrow> (cond1(x) \<longleftrightarrow> cond4(x)))\<and>
                    (case2 \<and> case3 \<longrightarrow> (cond2(x) \<longleftrightarrow> cond3(x)))\<and>
                    (case2 \<and> case4 \<longrightarrow> (cond2(x) \<longleftrightarrow> cond4(x)))\<and>
                    (case3 \<and> case4 \<longrightarrow> (cond3(x) \<longleftrightarrow> cond4(x)))"
  shows "f be ty 
         \<and> (x be ty \<longrightarrow> ((case1 \<and> cond1(x))\<or> (case2 \<and>cond2(x))\<or>
                         (case3 \<and> cond3(x))\<or> (case4 \<and> cond4(x))\<or>
                   (\<not>case1 \<and> \<not>case2 \<and> \<not>case3 \<and> \<not>case4 \<and> condo(x)))\<longrightarrow>x=f )
         \<and> ((case1 \<longrightarrow> cond1(f))\<and>(case2 \<longrightarrow>cond2(f))\<and>(case3 \<longrightarrow>cond3(f))\<and>(case4 \<longrightarrow>cond4(f))
         \<and>  (\<not>case1 \<and> \<not>case2 \<and>\<not>case3\<and> \<not>case4 \<longrightarrow> condo(f)))"
proof-
  let ?C = "\<lambda>it.(case1 \<longrightarrow> cond1(it))\<and>(case2 \<longrightarrow>cond2(it))\<and>(case3 \<longrightarrow>cond3(it))\<and>(case4 \<longrightarrow>cond4(it))\<and>
      (\<not>case1 \<and> \<not>case2 \<and> \<not>case3\<and> \<not>case4 \<longrightarrow>  condo(it))"
  have dfF:" f= func_means(ty,?C)" using df unfolding func_means_def func_means_if4_def by auto
  have exF: "\<exists>x:ty. ?C(x)" 
  proof (cases "case1\<or>case2")
    case True
      thus ?thesis using ex m co by blast
    next
     case False
      thus ?thesis using ex m co by auto
    qed
   have unF: "\<And>x y. x be ty \<Longrightarrow> y be ty \<Longrightarrow>
                ?C(x) \<Longrightarrow> ?C(y) \<Longrightarrow> x = y"
   proof-
     fix x y assume A:"x be ty" "y be ty"
     assume C: "?C(x)" "?C(y)"
     have T1: "case1\<or>case2 \<longrightarrow> x = y" using un[OF A] C[THEN conjunct1] C[THEN conjunct2,THEN conjunct1] by auto  
     have T2: "case3\<or>case4 \<longrightarrow> x = y" using un[OF A] C[THEN conjunct2,THEN conjunct2] by auto  
     have "\<not>case1 \<and> \<not>case2 \<and> \<not>case3\<and> \<not>case4 \<longrightarrow> x = y" 
         using un[OF A] C[THEN conjunct2,THEN conjunct2,THEN conjunct2] by auto  
     thus "x=y" using T1 T2 by auto
   qed 
  show ?thesis using func_means_property[OF dfF m exF unF,of x] co[THEN bspec] m by auto
qed 

  
  
  
lemma func_means_if1o_property:
  assumes df: "func f \<rightarrow> ty means cond1 if case1"
    and m: "inhabited(ty)"
    and ex: "case1 \<longrightarrow> (\<exists>x:ty. cond1(x))"
    and un: "\<And>x y. x be ty \<Longrightarrow> y be ty \<Longrightarrow>
                (case1 \<and> cond1(x)\<and> cond1(y) \<longrightarrow> x = y)"
    and co:"\<And>x. True" 
  shows "f be ty 
         \<and> (x be ty \<longrightarrow> (case1 \<and> cond1(x)\<longrightarrow> x=f ))
         \<and> ((case1 \<longrightarrow> cond1(f)))"
  using func_assume_means_property[of f case1 ty cond1,OF df[unfolded func_means_if1o_def]] 
     ex un m by auto

lemma func_means_if2o_property:
  assumes df: "func f \<rightarrow> ty means cond1 if case1, cond2 if case2"
    and m: "inhabited(ty)"
    and ex: "(case1 \<longrightarrow> (\<exists>x:ty. cond1(x))) \<and> (case2 \<longrightarrow> (\<exists>x:ty. cond2(x)))"
    and un: "\<And>x y. x be ty \<Longrightarrow> y be ty \<Longrightarrow>
                (case1 \<and> cond1(x)\<and> cond1(y) \<longrightarrow> x = y)\<and>
                (case2 \<and> cond2(x)\<and> cond2(y) \<longrightarrow> x = y)"
    and co:"\<forall>x: ty. case1 \<and> case2 \<longrightarrow> (cond1(x) \<longleftrightarrow> cond2(x))"
  shows "f be ty 
         \<and> (x be ty \<longrightarrow> ((case1 \<and> cond1(x))\<or> (case2 \<and>cond2(x)))\<longrightarrow>x=f)
         \<and> ((case1 \<longrightarrow> cond1(f))\<and>(case2 \<longrightarrow>cond2(f)))"
proof-
    let ?C = "\<lambda>it.(case1 \<longrightarrow> cond1(it))\<and>(case2 \<longrightarrow>cond2(it))"
    have dfF:" f= func_assume_means(case1\<or>case2,ty,?C)" using df 
      unfolding func_assume_means_def func_means_if2o_def by auto
    show ?thesis using func_assume_means_property[OF dfF,of x] co m un ex by auto    
qed

   
(*func equals*)  
  
definition "func_equals(ty, def) = func_means (ty, \<lambda>it. it = def)"
abbreviation func_equals_p  ("func _ \<rightarrow> _ equals _" [0,0] 10)
  where "func pat \<rightarrow> ty equals def \<equiv> pat = func_equals(ty, def)"

definition "func_assume_equals(as,ty, def) = func_assume_means (as,ty, \<lambda>it. it = def)"
abbreviation func_assume_equals_p  ("assume _ func _ \<rightarrow> _ equals _" [0,0,0] 10)
  where "assume as func pat \<rightarrow> ty equals def \<equiv> pat = func_assume_equals(as,ty, def)"    

definition "func_equals_if1(ty, term1,case1,termo) = func_means_if1 (ty, \<lambda>it. it = term1,case1,\<lambda>it. it = termo)"
abbreviation func_equals_if1_p  ("func _ \<rightarrow> _ equals _ if _ otherwise _" [0,0,0,0] 10)
  where "func pat \<rightarrow> ty equals term1 if case1 otherwise termo \<equiv> pat = func_equals_if1(ty, term1, case1,termo)"

definition "func_equals_if1o(ty, term1,case1) = func_means_if1o (ty, \<lambda>it. it = term1,case1)"
abbreviation func_equals_if1o_p  ("func _ \<rightarrow> _ equals _ if _ " [0,0,0] 10)
  where "func pat \<rightarrow> ty equals term1 if case1 \<equiv> pat = func_equals_if1o(ty, term1, case1)"

definition "func_equals_if2(ty, term1,case1,term2,case2,termo) = func_means_if2 
   (ty, \<lambda>it. it = term1,case1,\<lambda>it. it = term2,case2,\<lambda>it. it = termo)"
abbreviation func_equals_if2_p  ("func _ \<rightarrow> _ equals _ if _, _ if _ otherwise _" [0,0,0,0,0,0] 10)
  where "func pat \<rightarrow> ty equals term1 if case1, term2 if case2 otherwise termo \<equiv> pat = 
      func_equals_if2(ty, term1, case1,term2,case2,termo)"

definition "func_equals_if2o(ty, term1,case1,term2,case2) = 
    func_means_if2o (ty, \<lambda>it. it = term1,case1,\<lambda>it. it = term2,case2)"
abbreviation func_equals_if2o_p  ("func _ \<rightarrow> _ equals _ if _, _ if _ " [0,0,0,0,0] 10)
  where "func pat \<rightarrow> ty equals term1 if case1, term2 if case2 \<equiv> pat = func_equals_if2o(ty, term1, case1,term2,case2)"
        
lemma func_equals_property:
assumes df: "func f \<rightarrow> D equals term"
   and coherence: "term be D"
 shows "f be D \<and> f = term"
   using func_means_property[OF df[unfolded func_equals_def]] inhabited_def coherence by auto
  
lemma func_assume_equals_property:
assumes df: "assume R func f \<rightarrow> D equals term"
   and assume_coherence: "R \<Longrightarrow> term be D"
   and mode_ex: "inhabited(D)"
shows
   "f be D \<and> (R \<longrightarrow> f = term)"
proof-
  have assume_ex: "R \<Longrightarrow> ex x being D st x=term" using assume_coherence mode_ex by auto
  show "f be D \<and> (R \<longrightarrow> f = term)" using func_assume_means_property[OF df[unfolded func_assume_equals_def] 
     assume_ex,OF _ _ mode_ex] by auto
qed    

lemma func_equals_if1_property:
assumes df: "func f \<rightarrow> D equals term1 if case1 otherwise termo"
   and coherence: "(case1 \<longrightarrow> term1 be D)\<and>(\<not>case1 \<longrightarrow> termo be D)"
   and co: "\<And>x. True"
 shows "f be D \<and> ((case1 \<longrightarrow> f = term1)\<and>(\<not>case1 \<longrightarrow> f = termo))"
   using func_means_if1_property[OF df[unfolded func_equals_if1_def]] inhabited_def coherence by auto
  
lemma func_equals_if1o_property:
  assumes df: "func f \<rightarrow> D equals term1 if case1"
   and m:"inhabited(D)"
   and coherence: "(case1 \<longrightarrow> term1 be D)"
   and co: "\<And>x. True"
 shows "f be D \<and> (case1 \<longrightarrow> f = term1)"
using func_means_if1o_property[OF df[unfolded func_equals_if1o_def]] m coherence by auto
  
lemma func_equals_if2_property:
assumes df: "func f \<rightarrow> ty equals term1 if case1,term2 if case2 otherwise termo"
   and coherence: "(case1 \<longrightarrow> term1 be ty)\<and>(case2 \<longrightarrow> term2 be ty)\<and>(\<not>case1\<and>\<not>case2 \<longrightarrow> termo be ty)"
   and co: "\<forall>x: ty. case1 \<and> case2 \<longrightarrow> (x = term1 \<longleftrightarrow> x=term2)"
 shows "f be ty \<and> ((case1 \<longrightarrow> f = term1)\<and>(case2 \<longrightarrow> f = term2)\<and>(\<not>case1\<and>\<not>case2 \<longrightarrow> f = termo))"
using func_means_if2_property[OF df[unfolded func_equals_if2_def]] coherence inhabited_def co by auto 
  
lemma func_equals_if2o_property:
assumes df: "func f \<rightarrow> ty equals term1 if case1,term2 if case2"
   and coherence: "(case1 \<longrightarrow> term1 be ty)\<and>(case2 \<longrightarrow> term2 be ty)\<and>(\<not>case1\<and>\<not>case2 \<longrightarrow> termo be ty)"
   and co: "\<forall>x: ty. case1 \<and> case2 \<longrightarrow> (x = term1 \<longleftrightarrow> x=term2)"
 shows "f be ty \<and> ((case1 \<longrightarrow> f = term1)\<and>(case2 \<longrightarrow> f = term2))"
   using func_means_if2o_property[OF df[unfolded func_equals_if2o_def]] coherence co inhabited_def by auto

    
(*mode means*)    
    
definition "mode_means(p, cond) \<equiv> define_ty(p, \<lambda>_.True, cond)"
abbreviation mode_means_p  ("mode _ \<rightarrow> _ means _" [10,10,10] 10)
  where "mode M \<rightarrow> p means cond \<equiv> M =\<^sub>T mode_means(p, cond)"

definition "mode_assume_means(as,parent,cond) \<equiv> define_ty(parent,\<lambda>_.as,cond)"
abbreviation mode_assume_means_p ("assume _ mode _ \<rightarrow> _ means _" [0,0,0,0] 10)
where "assume as mode M \<rightarrow> p means cond \<equiv> M =\<^sub>T mode_assume_means(as,p, cond)"

definition "mode_means_if1(p, cond1,case1,condo) \<equiv> mode_means(p, \<lambda>it. (case1\<longrightarrow>cond1(it))\<and>(\<not>case1\<longrightarrow>condo(it)))"
abbreviation mode_means_if1_p  ("mode _ \<rightarrow> _ means '(_ if _ otherwise _ ')" [0,0,0,0,0] 10)
  where "mode M \<rightarrow> p means (cond1 if case1 otherwise condo) \<equiv> M =\<^sub>T mode_means_if1(p, cond1,case1,condo)"  
  
lemma mode_means_property:
  assumes df: "mode M \<rightarrow> p means cond"
      and m: "inhabited(p)"
      and ex: "\<exists>x:p. cond(x)"
    shows "inhabited(M) \<and> 
       (*ty_parent*) (x be M \<longrightarrow> x be p) \<and>
       (*intro*)    (x be p \<longrightarrow> cond(x)\<longrightarrow> x be M) \<and>
       (*elim*)     (x be M \<longrightarrow> cond(x))\<and>
                    (x be p \<longrightarrow> (x be M \<longleftrightarrow>  cond(x)))"
  text_raw {*}%EndSnippet*}
proof-
   obtain x where
    "x be p \<and> cond(x)" using ex m by auto
   hence "x be M" using ex def_ty_property_true df mode_means_def by auto
   thus ?thesis using ex def_ty_property_true df mode_means_def inhabited_def by auto
 qed  
   
lemma mode_assume_means_property:
  assumes df: "assume as mode M \<rightarrow> p means cond"
     and m: "inhabited(p)"
     and assume_ex: "as \<Longrightarrow> ex x being p st cond(x)"
   shows "inhabited(M) \<and>
      (*ty_parent*) (x be M \<longrightarrow> x be p) \<and>
       (*intro*)    (as \<longrightarrow> x be p \<longrightarrow> cond(x)\<longrightarrow> x be M) \<and>
       (*elim*)     (x be M \<longrightarrow>  (as \<longrightarrow> cond(x)))\<and>
                    (as \<longrightarrow> x be p \<longrightarrow> (x be M \<longleftrightarrow>  cond(x)))"
proof (cases "as")
   assume r: "as"
   hence rdf:"M  =\<^sub>T  mode_means(p, cond)" using df mode_assume_means_def mode_means_def by simp
   show ?thesis
     using mode_means_property[OF rdf m assume_ex[OF r],of x] r by blast
  next
    assume nr:"not as"
    hence rdf: "M \<equiv> define_ty(p, \<lambda>_. as, cond)" using df mode_assume_means_def mode_means_def by simp     
    have "(the p) be p" using choice_ax m by auto
    thus ?thesis using def_ty_property[OF rdf,of x]
          def_ty_property[OF rdf,of "the p",THEN conjunct2] nr by blast
qed

lemma mode_means_if1_property:
  assumes df: "mode M \<rightarrow> p means (cond1 if case1 otherwise condo)"
    and m: "inhabited(p)"
    and ex: "(case1 \<longrightarrow> (\<exists>x:p. cond1(x)))\<and>
             (\<not>case1 \<longrightarrow> (\<exists>x:p. condo(x)))"
    and co:"\<And>x. True"
  shows "inhabited(M) \<and> 
  (*ty_parent*)     (x be M \<longrightarrow> x be p) \<and>
       (*intro*)    (x be p \<longrightarrow> (case1 \<and> cond1(x))\<or>(\<not>case1 \<and> condo(x)) \<longrightarrow> x be M) \<and>
       (*elim*)     (x be M \<longrightarrow> (case1 \<longrightarrow> cond1(x))\<and>(\<not>case1 \<longrightarrow> condo(x)))\<and>                  
                    (x be p \<longrightarrow>(x be M \<longleftrightarrow> (case1 \<longrightarrow> cond1(x))\<and>(\<not>case1 \<longrightarrow> condo(x))))"
proof-
  let ?C = "\<lambda>it.(case1 \<longrightarrow> cond1(it))\<and> (\<not>case1 \<longrightarrow>  condo(it))"
  have dfF:" M=\<^sub>T mode_means(p,?C)" using df unfolding mode_means_if1_def by auto
  have exF: "\<exists>x:p. ?C(x)" using ex m co by blast     
  show ?thesis using mode_means_property[OF dfF m exF, of x] by blast
qed 
  (* (* (*  *) *) *)
(*attr means*)    
    
definition "attr_means(ty, cond) \<equiv> define_ty(object, \<lambda>it. it be ty, cond)"
abbreviation attr_means_p  ("attr _ for _ means _" [10,10,10] 10)
  where "attr def for ty means cond \<equiv> def =\<^sub>T attr_means(ty,cond)"

definition "attr_means_if1(ty, cond1,case1,condo) \<equiv> define_ty(object, \<lambda>it. it be ty,\<lambda>it. 
(case1(it)\<longrightarrow> cond1(it))\<and>(\<not>case1(it)\<longrightarrow>condo(it)))"
abbreviation attr_means_if1_p  ("attr _ for _ means  _ if _ otherwise _ " [0,0,0,0,0] 10)
  where "attr def for ty means cond1 if case1 otherwise condo \<equiv> def =\<^sub>T attr_means_if1(ty,cond1,case1,condo)" 

definition "attr_assume_means(as, ty, cond) \<equiv> define_ty(object, \<lambda>it. it be ty\<and> as(it), cond)"
abbreviation attr_assume_means_p  ("assume _ attr _ for _ means _" [0,0,0,0] 10)
  where "assume as attr def for ty means cond \<equiv> def =\<^sub>T attr_assume_means(as,ty,cond)"
     

    
lemma attr_means_property:
  assumes df:"attr def for ty means exp"
    and "True"
  shows "(X be ty \<longrightarrow> exp(X) \<longrightarrow> X is def) \<and> (X be ty \<longrightarrow> X is def \<longrightarrow> exp(X)) \<and>
         (X be ty \<longrightarrow> \<not> exp(X) \<longrightarrow> X is non def) \<and>        
           (X be ty \<longrightarrow> (X is def \<longleftrightarrow> exp(X)))"
          using def_ty_property_object df attr_means_def by auto
 
lemma attr_assume_means_property:
  assumes df:"assume as attr def for ty means exp"
    and "True"
  shows "(X be ty \<longrightarrow> as(X) \<longrightarrow> exp(X) \<longrightarrow> X is def) \<and> (X be ty \<longrightarrow> as(X)\<longrightarrow> X is def \<longrightarrow> exp(X)) \<and>
         (X be ty \<longrightarrow> as(X) \<longrightarrow> \<not> exp(X) \<longrightarrow> X is non def) \<and>        
           (X be ty \<longrightarrow> as(X) \<longrightarrow> (X is def \<longleftrightarrow> exp(X)))"
          using def_ty_property[of "def" object "\<lambda>it. it be ty\<and> as(it)" exp X] df[unfolded attr_assume_means_def] by auto            
            
lemma attr_means_if1_property:
  assumes df:"attr def for ty means cond1 if case1 otherwise condo"
    and co: "\<And>X. x is ty \<Longrightarrow> True"
  shows "(X be ty \<longrightarrow> (case1(X) \<and> cond1(X)) \<or>  (\<not>case1(X) \<and> condo(X))\<longrightarrow>X is def)\<and> 
         (X be ty \<longrightarrow> X is def \<longrightarrow> (case1(X) \<longrightarrow> cond1(X)) \<and> (\<not>case1(X) \<longrightarrow> condo(X)))\<and>
         (X be ty \<longrightarrow> (case1(X)\<longrightarrow>(X is def \<longleftrightarrow> cond1(X)))\<and>(\<not> case1(X)\<longrightarrow>(X is def \<longleftrightarrow> condo(X))))"
     using def_ty_property_object df attr_means_if1_def by auto


(*cluster*)
text_raw {*\DefineSnippet{ClusterCondAttrsAttrsTy}{*}               
definition "ClusterCondAttrsAttrsTy(attrs1, attrs2,ty) \<equiv> 
  (\<And>X. (X is  ty \<longrightarrow>  X is attrs1 \<longrightarrow> X is attrs2))"
abbreviation (input) ClusterCondAttrsAttrsTy_p  ("cluster _ \<rightarrow> _ for _" [0,0,0] 10)
  where "cluster attrs1 \<rightarrow> attrs2 for ty \<equiv> ClusterCondAttrsAttrsTy(attrs1, attrs2,ty)"
text_raw {*}%EndSnippet*}
   
lemma ClusterCondAttrsAttrsTyI[intro!]:
  assumes coherence: "\<forall> it: ty. (it is attrs1 \<longrightarrow> it is attrs2)" and
          i:"inhabited(ty)"
  shows "cluster attrs1 \<rightarrow> attrs2 for ty" 
using  ClusterCondAttrsAttrsTy_def using coherence i by auto  
        
lemma ClusterCondAttrsAttrsTy_property:
  assumes "cluster attrs1 \<rightarrow> attrs2 for ty" 
  shows "\<And>X. X be ty \<Longrightarrow>  X is attrs1 \<Longrightarrow> X is attrs2"
  using assms unfolding ClusterCondAttrsAttrsTy_def by simp

(*----*)    


definition "ClusterCondAttrsTy(attrs2,ty) \<equiv> (\<And> X.  (X be ty \<longrightarrow> X is attrs2))"
abbreviation (input) ClusterCondAttrsTy_p  ("cluster \<rightarrow> _ for _" [0,0] 10)
  where "cluster  \<rightarrow> attrs2 for ty \<equiv> ClusterCondAttrsTy(attrs2,ty)"

lemma ClusterCondAttrsTyI[intro!]:
  assumes coherence: "\<forall> it: ty. it is attrs2" and
          i:"inhabited(ty)"
  shows "cluster \<rightarrow> attrs2 for ty" 
using  ClusterCondAttrsTy_def using coherence i by auto  
        
lemma ClusterCondAttrsTy_property:
  assumes "cluster \<rightarrow> attrs2 for ty" 
  shows "\<And>X. X be ty \<Longrightarrow> X is attrs2"
  using assms unfolding ClusterCondAttrsTy_def by simp
    
(*----*)    
text_raw {*\DefineSnippet{ClusterExistence}{*}               
definition "ClusterExistence(attrs,ty) \<equiv> Trueprop (inhabited(attrs \<bar> ty))"
abbreviation (input) ClusterExistence_p  ("cluster  _ for _" [0,0] 10)
  where "cluster attrs for ty \<equiv> ClusterExistence(attrs,ty)"
text_raw {*}%EndSnippet*}
    
lemma ClusterExistenceI[intro!]:
   assumes "inhabited(attrs\<bar>ty)"
   shows "cluster attrs for ty" 
unfolding ClusterExistence_def using assms by auto
    
lemma ClusterExistence_property:
   assumes "cluster attrs for ty"  
   shows "inhabited(attrs\<bar>ty)"
using assms(1)[unfolded ClusterExistence_def] by auto

(*----*)

definition "ClusterFuncNoFor(fun,attrs) \<equiv> Trueprop (fun is attrs)"
abbreviation (input) ClusterFuncNoFor_p  ("cluster  _ \<rightarrow> _" [0,0] 10)
  where "cluster fun \<rightarrow> attrs \<equiv> ClusterFuncNoFor(fun,attrs)"

(* This was not a property! *)
lemma ClusterFuncNoForI[intro!]:
   assumes coherence: "fun is attrs"
   shows "cluster fun \<rightarrow> attrs" 
unfolding ClusterFuncNoFor_def using coherence by auto

lemma ClusterFuncNoFor_property:
  assumes "cluster fun \<rightarrow> attrs" 
  shows "fun is attrs"
  using assms unfolding ClusterFuncNoFor_def .
    
(*----*) 
    
definition "ClusterFuncFor(fun,attrs,ty) \<equiv> (fun is ty \<Longrightarrow> fun is attrs)"
abbreviation (input) ClusterFuncFor_p  ("cluster  _ \<rightarrow> _ fors _" [0,0,0] 10)
  where "cluster fun \<rightarrow> attrs fors ty \<equiv> ClusterFuncFor(fun,attrs,ty)"

lemma ClusterFuncForI[intro!]:
  assumes coherence: "\<forall> it: ty. it = fun \<longrightarrow> it is attrs" and
          i:"inhabited(ty)"
  shows "cluster fun \<rightarrow> attrs fors ty" 
using ClusterFuncFor_def using coherence[THEN bspec,of "fun"] i by auto  
        
lemma ClusterFuncFor_property:
  assumes "cluster fun \<rightarrow> attrs fors ty" 
  shows "fun is ty \<Longrightarrow> fun is attrs"
  using assms unfolding ClusterFuncFor_def .
    
(*----*) 

definition "Reduce(term,subterm) \<equiv>  Trueprop(term = subterm)"
abbreviation (input) Reduce_p  ("reduce _ to _" [0,0] 10)
  where "reduce term to subterm \<equiv> Reduce(term,subterm)"

lemma ReduceI[intro!]:
  assumes red: "term = subterm" 
  shows "reduce term to subterm" 
using Reduce_def using red by auto  
        
lemma Reduce_property:
  assumes "reduce term to subterm" 
  shows "term = subterm"
  using assms unfolding Reduce_def. 


(*Redefine func means*)    
    
    
definition "redefine_func_means(f,ty,cond) \<equiv>(\<And>x . (x be ty \<and> cond(x) \<longrightarrow> x = f) \<and> cond(f))"
abbreviation (input) redefine_func_means_p ("redefine func _ \<rightarrow> _ means _" [0,0,0] 10)
  where "redefine func f \<rightarrow> ty means cond \<equiv>redefine_func_means(f,ty,cond)"

definition "redefine_func_means_if1(f,ty, cond1,case1,condo) \<equiv>
  (\<And>x . (x be ty \<longrightarrow> (case1 \<and> cond1(x))\<or>(\<not>case1 \<and>  condo(x)) \<longrightarrow> x = f)
         \<and> ((case1 \<longrightarrow> cond1(f))\<and>(\<not>case1 \<longrightarrow> condo(f))))"    

abbreviation redefine_func_means_if1_p  ("redefine func _ \<rightarrow> _ means  _ if _ otherwise _ " [0,0,0,0] 10)
  where "redefine func f \<rightarrow> ty means cond1 if case1 otherwise condo \<equiv> redefine_func_means_if1(f,ty, cond1,case1,condo)"  

definition "redefine_func_assume_means(f,as, ty, cond) \<equiv> (\<And>x . (as \<and> x be ty \<and> cond(x) \<longrightarrow> x = f) \<and> (as \<longrightarrow>cond(f)))"
abbreviation (input) redefine_func_assume_means_p  ("assume _ redefine func _ \<rightarrow> _ means _" [0,0,0,0] 10)
  where "assume as redefine func f \<rightarrow> ty means cond \<equiv>  redefine_func_assume_means(f,as, ty, cond)"    
   
definition "redefine_func_means_if1o(f,ty, cond1,case1) \<equiv> redefine_func_assume_means(f,case1, ty, cond1)"
abbreviation redefine_func_means_if1o_p  ("redefine func _ \<rightarrow> _ means  _ if _ " [0,0,0,0] 10)
  where "redefine func f \<rightarrow> ty means cond1 if case1 \<equiv> redefine_func_means_if1o(f,ty, cond1,case1)"
    
lemma redefine_func_meansI[intro!]:
 assumes compatibility: "\<And>x . x be ty \<Longrightarrow> (x = f \<longleftrightarrow> newCondition(x))"
    and p: "f is ty"
 shows "redefine func f \<rightarrow> ty means newCondition"
unfolding redefine_func_means_def using compatibility p by auto

lemma redefine_func_means_property:
  assumes as: "redefine func f \<rightarrow> ty means newCondition"
  shows "(x be ty \<and> newCondition(x) \<longrightarrow> x=f) \<and>
           newCondition(f)"
using as[unfolded redefine_func_means_def] by auto
    
lemma redefine_func_means_if1I[intro!]:
  assumes compatibility: "\<And>x . x be ty \<Longrightarrow> 
      (case1 \<longrightarrow>(x = f \<longleftrightarrow> cond1(x)))\<and>(\<not> case1 \<longrightarrow>(x = f \<longleftrightarrow> condo(x)))"
    and p: "f is ty"
 shows "redefine func f \<rightarrow> ty means cond1 if case1 otherwise condo"
  unfolding redefine_func_means_if1_def 
      redefine_func_means_property  using compatibility p by auto
   
lemma redefine_func_means_if1_property:
  assumes "redefine func f \<rightarrow> ty means cond1 if case1 otherwise condo"
   shows "(x be ty \<longrightarrow> (case1 \<and> cond1(x))\<or>(\<not>case1 \<and>  condo(x)) \<longrightarrow> x = f)
         \<and> ((case1 \<longrightarrow> cond1(f))\<and>(\<not>case1 \<longrightarrow> condo(f)))"
  using assms[unfolded redefine_func_means_if1_def] by auto    

lemma redefine_func_assume_meansI[intro!]:
 assumes compatibility: "\<And>x . as \<and> x be ty \<Longrightarrow> (x = f \<longleftrightarrow> newCondition(x))"
    and p: "f is ty"
 shows "assume as redefine func f \<rightarrow> ty means newCondition"
unfolding redefine_func_assume_means_def using compatibility p by auto
   
lemma redefine_func_assume_means_property:
  assumes "assume as redefine func f \<rightarrow> ty means newCondition"
  shows "(as\<and>x be ty \<and> newCondition(x) \<longrightarrow> x=f) \<and>
           (as \<longrightarrow>newCondition(f))"
using assms[unfolded redefine_func_assume_means_def] by auto      

  
  
lemma redefine_func_means_if1oI[intro!]:
 assumes compatibility: "\<And>x . cond \<and> x be ty \<Longrightarrow> (x = f \<longleftrightarrow> newCondition(x))"
    and p: "f is ty"
 shows "redefine func f \<rightarrow> ty means newCondition if cond"
  unfolding redefine_func_means_if1o_def 
      redefine_func_assume_means_property  using compatibility p by auto
   
lemma redefine_func_means_if1o_property:
  assumes "redefine func f \<rightarrow> ty means newCondition if cond"
  shows "(cond \<and> x be ty \<and> newCondition(x) \<longrightarrow> x=f) \<and>
           (cond \<longrightarrow>newCondition(f))"
  using 
   redefine_func_assume_means_property[of f cond ty newCondition x,OF assms [unfolded redefine_func_means_if1o_def[of f ty newCondition cond]] ]
  by simp
    
(*Redefine func equals*) 
    
definition "redefine_func_equals(f,ty::Ty,def) \<equiv> Trueprop (f = def)"
abbreviation (input) redefine_func_equals_p ("redefine func _ \<rightarrow> _ equals _" [0,0,0] 10)
  where "redefine func f \<rightarrow> ty equals def \<equiv>redefine_func_equals(f,ty,def)"

definition "redefine_func_assume_equals(as, f, ty :: Ty, term) \<equiv> Trueprop (as \<longrightarrow>  f = term)"
abbreviation (input) redefine_func_assume_equals_p  ("assume _ redefine func _ \<rightarrow> _ equals _" [0,0,0,0] 10)
  where "assume as redefine func f \<rightarrow> ty equals term \<equiv>  redefine_func_assume_equals(as,f,ty, term)"

definition "redefine_func_equals_if1(f,ty::Ty, term1,case1,termo) \<equiv> Trueprop ((case1 \<longrightarrow>  f = term1) \<and>( \<not> case1 \<longrightarrow>f=termo))" 
abbreviation redefine_func_equals_if1_p  ("redefine func _ \<rightarrow> _ equals _ if _ otherwise _" [0,0,0,0,0] 10)
  where "redefine func pat \<rightarrow> ty equals term1 if case1 otherwise termo \<equiv> 
      redefine_func_equals_if1(pat,ty, term1, case1,termo)"

lemma redefine_func_equals_if1I[intro!]:
  assumes compatibility: "\<And>x . x be ty \<Longrightarrow> 
      (case1 \<longrightarrow>(x = f \<longleftrightarrow> x=term1))\<and>(\<not> case1 \<longrightarrow>(x = f \<longleftrightarrow> x=termo))"
    and p: "f is ty"
 shows "redefine func f \<rightarrow> ty equals term1 if case1 otherwise termo"
  unfolding redefine_func_equals_if1_def 
      redefine_func_means_property  using compatibility[OF p] by auto
   
lemma redefine_func_equals_if1_property:
  assumes "redefine func f \<rightarrow> ty equals term1 if case1 otherwise termo"
   shows "(case1 \<longrightarrow>  f = term1) \<and>( \<not> case1 \<longrightarrow>f=termo)"
  using assms[unfolded redefine_func_equals_if1_def] by auto    
    
    
lemma redefine_func_equalsI[intro!]:
 assumes compatybility: "\<And>x . x be ty \<Longrightarrow> (x = f \<longleftrightarrow> x = term)"
    and p: "f is ty"
 shows "redefine func f \<rightarrow> ty equals term"
unfolding redefine_func_equals_def using compatybility p by auto
   
lemma redefine_func_equals_property:
  assumes "redefine func f \<rightarrow> ty equals term"
  shows "f = term"
using assms[unfolded redefine_func_equals_def] by auto    
    
lemma redefine_func_assume_equalsI[intro!]:
 assumes compatybility: "\<And>x . as \<and> x be ty \<Longrightarrow> (x = f \<longleftrightarrow> x = term)"
    and p: "f is ty"
 shows "assume as redefine func f \<rightarrow> ty equals term"
unfolding redefine_func_assume_equals_def using compatybility p by auto
   
lemma redefine_func_assume_equals_property:
  assumes "assume as redefine func f \<rightarrow> ty equals term"
  shows "(as \<longrightarrow> f = term)"
using assms[unfolded redefine_func_assume_equals_def] by auto          


  
(*redefine func type*)        
        
definition "redefine_func_type(f,ty) \<equiv>Trueprop (f be ty)"
abbreviation (input) redefine_func_type_p ("redefine func _ \<rightarrow> _ " [0,0] 10)
  where "redefine func f \<rightarrow> ty \<equiv>redefine_func_type(f,ty)"

lemma redefine_func_typeI[intro!]:
 assumes coherence: "f be ty"
 shows "redefine func f \<rightarrow> ty"
using redefine_func_type_def coherence by mauto

lemma redefine_func_type_property:
  assumes "redefine func f \<rightarrow> ty"
  shows "f be ty"
using assms[unfolded redefine_func_type_def] by auto

  
  
  
(*redefine mode*)  
definition "redefine_mode_means(M,ty,cond) \<equiv>(\<And>x . (x be ty \<longrightarrow> (x be M \<longleftrightarrow> cond(x))))"
abbreviation (input) redefine_mode_means_p ("redefine mode _ \<rightarrow> _ means _" [0,0,0] 10)
  where "redefine mode M \<rightarrow> ty means cond \<equiv>redefine_mode_means(M,ty,cond)"

lemma redefine_mode_meansI[intro!]:
 assumes compatibility: "\<And>x . x be ty \<Longrightarrow> (x is M \<longleftrightarrow> cond(x))"
 shows "redefine mode M \<rightarrow> ty means cond"
unfolding redefine_mode_means_def using compatibility by auto

lemma redefine_mode_means_property:
  assumes as: "redefine mode M \<rightarrow> ty means cond"
  shows "(X be ty \<longrightarrow> cond(X) \<longrightarrow> X is M) \<and>
         (X be ty \<longrightarrow> X is M \<longrightarrow> cond(X)) \<and> (X be ty \<longrightarrow> (X is M \<longleftrightarrow> cond(X)))"
using as[unfolded redefine_mode_means_def] by auto  
  
  
  
(*redefine attr*) 
 
  
definition "redefine_attr_means(ty,Attr,cond) \<equiv>(\<And>x . x is ty \<longrightarrow>(x is Attr \<longleftrightarrow> cond(x)))"
abbreviation (input) redefine_attr_means_p ("redefine attr _ for _ means _" [0,0,0] 10)
  where "redefine attr Attr for ty means cond \<equiv>redefine_attr_means(ty,Attr,cond)"

lemma redefine_attr_meansI[intro!]:
  assumes compatibility: "\<forall>x:ty. x is Attr \<longleftrightarrow> cond(x)" and
     I:"inhabited(ty)"
 shows "redefine attr Attr for ty means cond"
unfolding redefine_attr_means_def using compatibility I by auto

lemma redefine_attr_means_property:
  assumes as: "redefine attr Attr for ty means cond"
  shows "(x is ty \<and> cond(x) \<longrightarrow> x is Attr) \<and>
         (x is ty \<and> x is Attr \<longrightarrow> cond(x)) \<and> (x is ty\<longrightarrow>(x is Attr \<longleftrightarrow> cond(x)))"
using as[unfolded redefine_attr_means_def] by auto  
 
(*redefine pred*) 
 
definition "redefine_pred_means(Pred,cond) \<equiv>Trueprop (Pred  \<longleftrightarrow> cond)"
abbreviation (input) redefine_pred_means_p ("redefine pred _ means _" [0,0] 10)
  where "redefine pred P means cond \<equiv>redefine_pred_means(P,cond)"

lemma redefine_pred_meansI[intro!]:
 assumes compatibility: "P \<longleftrightarrow> cond"
 shows "redefine pred P means cond"
unfolding redefine_pred_means_def using compatibility by auto

lemma redefine_pred_means_property:
  assumes as: "redefine pred P means cond"
  shows "(cond\<longrightarrow> P) \<and> (P \<longrightarrow> cond)\<and>(P \<longleftrightarrow> cond)"
using as[unfolded redefine_pred_means_def] by auto  

  
  
definition "redefine_pred_means_if1(Pred,cond1,case1,condo) \<equiv> ((case1\<longrightarrow> (Pred  \<longleftrightarrow> cond1))\<and>(\<not>case1\<longrightarrow>(Pred  \<longleftrightarrow> condo)))"
abbreviation (input) redefine_pred_means_if1_p  ("redefine pred _ means _ if _ otherwise _" [0,0,0,0] 10)
  where "redefine pred P means cond1 if case1 otherwise condo \<equiv> redefine_pred_means_if1(P,cond1,case1,condo)"

lemma redefine_pred_means_if1_property:
  assumes df:"redefine pred P means cond1 if case1 otherwise condo"
    and "True"
  shows 
     "(((case1\<longrightarrow> cond1)\<and>(\<not>case1\<longrightarrow>condo))\<longrightarrow> P) 
    \<and> (P\<longrightarrow>((case1\<longrightarrow> cond1)\<and>(\<not>case1\<longrightarrow>condo)))\<and>
     (P \<longleftrightarrow> ((case1\<longrightarrow> cond1)\<and>(\<not>case1\<longrightarrow>condo)))" (* Add sth... *)
  using df unfolding redefine_pred_means_if1_def by auto      

  

  
(*-----------*)  
  
abbreviation (input) prefix_asymmetry ("asymmetry _ _")
where "asymmetry dom R \<equiv> for x1,x2 being dom holds \<not> (R(x1,x2) \<and> R(x2,x1))"

abbreviation (input) prefix_irreflexive ("irreflexive _ _")
where "irreflexive dom R \<equiv> \<forall>x:dom. \<not>R(x,x)"

abbreviation (input) prefix_reflexive ("reflexive _ _")
where "reflexive dom R \<equiv> \<forall>x:dom. R(x,x)"

abbreviation (input) prefix_symmetry ("symmetry _ _")
where "symmetry dom R \<equiv> for x1,x2 being dom st R(x1,x2) holds R(x2,x1)"

abbreviation (input) prefix_connectedness ("connectedness _ _")
where "connectedness dom R \<equiv> for x1,x2 being dom holds R(x1,x2) \<or> R(x2,x1)"

abbreviation (input) prefix_involutiveness ("involutiveness _ _")
where "involutiveness dom U \<equiv> for x being dom holds U(U(x)) = x"

abbreviation (input) prefix_projectivity ("projectivity _ _")
where "projectivity dom U \<equiv> for x being dom holds U(U(x)) = U(x)"

abbreviation (input) prefix_idempotence ("idempotence _ _")
where "idempotence dom B \<equiv> for x being dom holds B(x,x) = x"

abbreviation (input) prefix_commutativity ("commutativity _ _")
where "commutativity dom B \<equiv> \<forall>x1:dom. \<forall>x2:dom. B(x1,x2) = B(x2,x1)"


section "PROPERTY"



(*"assume as func def \<rightarrow> ty means cond*)

(*
text_raw {*\DefineSnippet{assume_means_property}{*}
lemma assume_means_property:
assumes df: "assume as func f \<rightarrow> ty means cond"
   and assume_ex: "as \<Longrightarrow> \<exists>x:ty. cond(x)"
   and assume_un: "\<And>x y. as \<Longrightarrow> x be ty \<Longrightarrow> y be ty \<Longrightarrow>
       cond(x) \<Longrightarrow> cond(y) \<Longrightarrow> x = y"
   and mode_ex: "inhabited(ty)"
shows
   "f be ty \<and> (as \<longrightarrow> cond(f)) \<and> (as \<and> x be ty \<and> cond(x) \<longrightarrow> x = f)"
text_raw {*}%EndSnippet*}
proof (cases "as")
   assume r: "as"
   hence rdf: " f =  theProp(ty,cond)" using df by simp
   have un1: "\<And>x y. x be ty \<Longrightarrow> y be ty \<Longrightarrow>
     cond(x) \<Longrightarrow> cond(y) \<Longrightarrow> x = y" using assume_un r by simp
   show "f be ty \<and> (as \<longrightarrow> cond(f)) \<and> (as \<and> x be ty \<and> cond(x) \<longrightarrow> x = f)"
     using means_property[OF rdf mode_ex assume_ex[OF r]] assume_un r by auto
next
  assume nR: "not as"
  have "(the ty) be ty" using choice_ax mode_ex by auto
  hence "inhabited(define_ty(ty,\<lambda>_. as,cond))" using def_ty_property[THEN conjunct2] using nR by simp
  hence "f be define_ty(ty,\<lambda>_. as,cond)" using choice_ax df inhabited_def by auto
  thus "f be ty \<and> (as \<longrightarrow> cond(f)) \<and> (as \<and> x be ty \<and> cond(x) \<longrightarrow> x = f)"
    using def_ty_property[THEN conjunct1] nR by auto
qed

lemma assume_equals_property:
assumes df: "assume R func f \<rightarrow> D equals term"
   and assume_coherence: "R \<Longrightarrow> term be D"
   and mode_ex: "inhabited(D)"
shows
   "f be D \<and> (R \<longrightarrow> f = term)"
proof-
  have assume_ex: "R \<Longrightarrow> ex x being D st x=term" using assume_coherence mode_ex by auto
      show "f be D \<and> (R \<longrightarrow> f = term)" using assume_means_property[OF df assume_ex,OF _ _ mode_ex] by auto
    qed





text_raw {*\DefineSnippet{assume_mode_property}{*}
lemma assume_mode_property:
  assumes df: "assume R mode M \<rightarrow> D means P"
     and m: "inhabited(D)"
     and assume_ex: "R \<Longrightarrow> ex x being D st P(x)"
  shows
     "(x be M \<longrightarrow> (x be D \<and> (R \<longrightarrow> P(x))))
       \<and> (x be D \<and> R \<and> P(x) \<longrightarrow> x be M)
       \<and> inhabited(M)"
text_raw {*}%EndSnippet*}
proof (cases "R")
   assume r: "R"
   hence rdf:"M \<equiv>  define_ty(D,\<lambda>_.True, P)" using df by simp
   show "(x be M \<longrightarrow> (x be D \<and> (R \<longrightarrow> P(x))))
       \<and> (x be D \<and> R \<and> P(x) \<longrightarrow> x be M) \<and> inhabited(M)"
     using mode_property[OF rdf m assume_ex[OF r]] by auto
  next
    assume nr:"not R"
    have "(the D) be D" using choice_ax m by auto
    thus "(x be M \<longrightarrow> (x be D \<and> (R \<longrightarrow> P(x))))
     \<and> (x be D \<and> R \<and> P(x) \<longrightarrow> x be M)  \<and> inhabited(M)"
     using def_ty_property[OF df,of x]
          def_ty_property[OF df,of "the D",THEN conjunct2] nr by blast
 qed
*)
 

lemmas [simp] = choice_ax


end
