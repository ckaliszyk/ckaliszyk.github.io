theory newton
  imports "mizar/mizar_import"
begin   
local_setup {* dof "tarski" *}   
local_setup {* dof "xboole_0" *}
local_setup {* dof "boole" *}
local_setup {* dof "xboole_1" *}
local_setup {* dof "enumset1" *}
local_setup {* dof "xtuple_0" *}
local_setup {* dof "xfamily" *}
local_setup {* dof "xregular" *}
local_setup {* dof "zfmisc_1" *}
  
local_setup {* dof "subset_1" *}
local_setup {* dof "subset" *}
local_setup {* dof "setfam_1" *}
local_setup {* dof "relat_1" *}
local_setup {* dof "funct_1" *}     

local_setup {* dof "grfunc_1" *}
local_setup {* dof "relat_2" *}
local_setup {* dof "ordinal1" *}
local_setup {* dof "wellord1" *}
local_setup {* dof "relset_1" *}
local_setup {* dof "partfun1" *}
local_setup {* dof "mcart_1" *}
local_setup {* dof "wellord2" *}
local_setup {* dof "funct_2" *}
local_setup {* dof "binop_1" *}
local_setup {* dof "domain_1" *}
local_setup {* dof "funct_3" *}
local_setup {* dof "funcop_1" *}
local_setup {* dof "realset1" *}
local_setup {* dof "funct_4" *}
local_setup {* dof "numerals" *}
local_setup {* dof "ordinal2" *}
local_setup {* dof "ordinal3" *}
local_setup {* dof "wellset1" *}
local_setup {* dof "schems_1" *}
local_setup {* dof "finset_1" *}
local_setup {* dof "card_1" *}
local_setup {* dof "classes1" *}
local_setup {* dof "pboole" *}
local_setup {* dof "finsub_1" *}
local_setup {* dof "orders_1" *}
local_setup {* dof "setwiseo" *}
local_setup {* dof "funct_5" *}
local_setup {* dof "card_3" *}
local_setup {* dof "funct_6" *}
local_setup {* dof "arytm_3" *}
local_setup {* dof "arytm_2" *}
local_setup {* dof "arytm_1" *}
local_setup {* dof "numbers" *}
local_setup {* dof "arytm_0" *}
local_setup {* dof "xcmplx_0" *}
local_setup {* dof "arithm" *}
local_setup {* dof "xxreal_0" *}
local_setup {* dof "xreal_0" *}
local_setup {* dof "real" *}
local_setup {* dof "xcmplx_1" *}
local_setup {* dof "xreal_1" *}
local_setup {* dof "axioms" *}
local_setup {* dof "real_1" *}
local_setup {* dof "square_1" *}
local_setup {* dof "nat_1" *}
local_setup {* dof "int_1" *}
local_setup {* dof "rat_1" *}
local_setup {* dof "membered" *}
local_setup {* dof "valued_0" *}
local_setup {* dof "complex1" *}
local_setup {* dof "absvalue" *}
local_setup {* dof "binop_2" *}
local_setup {* dof "xxreal_1" *}
local_setup {* dof "xxreal_2" *}
local_setup {* dof "xxreal_3" *}
local_setup {* dof "finseq_1" *}
local_setup {* dof "eqrel_1" *}
local_setup {* dof "finseq_2" *}
local_setup {* dof "finseqop" *}
local_setup {* dof "finseq_3" *}
local_setup {* dof "valued_1" *}
  
local_setup {* dof "finseq_4" *}
local_setup {* dof "finsop_1" *}
local_setup {* dof "setwop_2" *}
local_setup {* dof "rvsum_1" *}

 
text "begin" 

abbreviation(input) XCMPLX_0K2_s (infixl "+\<^bsub>\<complex>\<^esub>" 80) where
  "x +\<^bsub>\<complex>\<^esub> y \<equiv> XCMPLX_0K2(x,y)"    
   
abbreviation(input) XCMPLX_0K3_s (infixl "*\<^bsub>\<complex>\<^esub>" 81) where
  "x *\<^bsub>\<complex>\<^esub> y \<equiv> XCMPLX_0K3(x,y)"    
  
abbreviation(input) NAT_1K3_s (infixl "+\<^bsub>\<nat>\<^esub>" 80) where
  "x +\<^bsub>\<nat>\<^esub> y \<equiv> x +\<^bsub>NAT_1K1\<^esub>y"    

abbreviation(input) XBOOLE_0R4_s (infixl "=\<^bsub>set\<^esub>" 10) where
  "x =\<^bsub>set\<^esub> y \<equiv> x =\<^bsub>XBOOLE_0R4\<^esub>y"    
  
abbreviation(input) ORDINAL1M1_s ("Number") where
  "Number \<equiv> Number\<^bsub>ORDINAL1M1\<^esub>"    

 abbreviation(input) ORDINAL1M2_s ("number") where
  "number \<equiv> number\<^bsub>ORDINAL1M2\<^esub>"    

abbreviation(input) XREAL_0M1_s ("Real") where
  "Real \<equiv> Real\<^bsub>XREAL_0M1\<^esub>"    

abbreviation(input) XCMPLX_0M1_s ("Complex") where
  "Complex \<equiv> Complex\<^bsub>XCMPLX_0M1\<^esub>"    

abbreviation(input) NAT_1M1_s ("Nat") where
  "Nat \<equiv> Nat\<^bsub>NAT_1M1\<^esub>"    

abbreviation(input) RVSUM_1K24_s ("\<Pi> _") where
  "\<Pi> F \<equiv> Product\<^bsub>RVSUM_1K24\<^esub> F"    

abbreviation(input) one_s ("1") where
  "1 \<equiv> succ 0"    

abbreviation(input) arrow_s (infixl "\<mapsto>" 100) where
  "x \<mapsto> y \<equiv> x |-> y"    
  
lemma [ex]:"inhabited(Complex)" unfolding XCMPLX_0M1_def by mauto 
lemma [ex]:"inhabited(Real)" unfolding XREAL_0M1_def using ORDINAL1M1_def by auto
lemma [ex]:"inhabited(Nat)" unfolding NAT_1M1_def using ORDINAL1M2_def by auto
lemma [ex]:"inhabited(FinSequence\<^bsub>FINSEQ_1M3\<^esub> REAL)" unfolding FINSEQ_1M3_def by auto
lemmas [simp] = ORDINAL1M2_def NUMBERSK6_def ORDINAL1M1_def ORDINAL1M3_def RVSUM_1K25_def RVSUM_1K24_def
    XBOOLE_0R4_def
lemma [ty]: "0 is Ordinal\<^bsub>ORDINAL1M3\<^esub>" unfolding ORDINAL1M3_def by mauto
lemma [ty_func_cluster]:
  "x is Nat\<Longrightarrow>x is natural" unfolding NAT_1M1_def by mauto
lemma [ty_func_cluster]:
  "x is natural\<Longrightarrow>x is Nat" unfolding NAT_1M1_def using tarski_th_1 by mauto
lemma [ty_func_cluster]:
  "x is Number\<Longrightarrow>x is number" unfolding ORDINAL1M1_def ORDINAL1M2_def using tarski_th_1 by auto

lemma [ty_func_cluster]:
  "x is natural\<Longrightarrow>x is Complex" unfolding XCMPLX_0M1_def using ty_func_cluster(187) by mauto
lemma [ty_func_cluster]:
  "x is number\<Longrightarrow>x is Number" unfolding ORDINAL1M1_def ORDINAL1M2_def using tarski_th_1 by auto





lemma [ty_func_cluster]:"x is Complex\<Longrightarrow>x is Element COMPLEX" 
   unfolding XCMPLX_0M1_def using xcmplx_0_def_2E[of x,simplified] 
           subset_1_def_1I[of COMPLEX x] TARSKIR2_def tarski_th_1 by mauto             
reserve i,j,k,n,m,l,s,t for "natural\<bar>Number" 
reserve a,b for "Real" 
reserve F,G,H for "FinSequence\<^bsub>FINSEQ_1M3\<^esub> REAL" 


mlemma [ty_func_cluster]:"(s +\<^bsub>\<complex>\<^esub> t) is natural\<bar>Number"  by mauto
mlemma [ty_func_cluster]:"(s *\<^bsub>\<complex>\<^esub> t) is natural\<bar>Number"  by mauto

    
mtheorem 
  mlet "x is Complex", "n is natural\<bar>Number"
  "cluster n \<mapsto> x \<rightarrow> complex-valued\<^bsub>VALUED_0V5\<^esub>" by auto
  
text_raw {*\DefineSnippet{newtondef1}{*}
mdef newton_def_1  ("_ \<^bsup> _ \<^esup>" [90,0]91) where
  mlet "x is Complex", "n is natural\<bar>Number"
  "func x\<^bsup>n\<^esup> \<rightarrow> number equals 
     \<Pi> (n \<mapsto> x)"
text_raw {*}%EndSnippet*}
 using tarski_th_1 ORDINAL1M2_def by simp
      
mtheorem 
  mlet "x is Real", "n is natural\<bar>Number"
  "cluster x\<^bsup>n\<^esup> \<rightarrow> real"
proof
  have [ty]:"x is real\<bar> Number" using XREAL_0M1_def by mauto  
  have [ty]:"x is Complex" unfolding XCMPLX_0M1_def by mauto
  have  "\<Pi> (n \<mapsto> x) is real" unfolding RVSUM_1K24_def by mauto
  thus "x\<^bsup>n\<^esup> is real" using newton_def_1 by mauto    
qed  
                         
mtheorem 
  mlet "z is Complex", "n is natural \<bar> Number"
  "cluster z\<^bsup>n\<^esup> \<rightarrow> complex"
proof
   have "(\<Pi> (n \<mapsto> z)) is Complex" unfolding RVSUM_1K24_def by mauto
   thus "z\<^bsup>n\<^esup> is complex" unfolding XCMPLX_0M1_def using newton_def_1 by auto   
qed

reserve x,y,z for "Complex" 
    
text_raw {*\DefineSnippet{newtonth4}{*}
mtheorem newton_th_4:
  " z\<^bsup>0\<^esup> = 1"
text_raw {*}%EndSnippet*}  
proof-
  have  "z\<^bsup>0\<^esup>= \<Pi> (0 \<mapsto> z)" using newton_def_1 by mauto
  also have "... = \<Pi> (<*> REAL)" 
    using finseq_2_th_58 FINSEQ_1R1_def finseq_1_def_6 by mty auto
  also have "... = 1" using rvsum_1_th_94 by mty auto
  finally show ?thesis by auto
qed    
 
text_raw {*\DefineSnippet{newtonth5}{*}
mtheorem newton_th_5:
  "z\<^bsup>1\<^esup> = z"
text_raw {*}%EndSnippet*}
proof-
  have "z\<^bsup>1\<^esup>  = \<Pi> (1 \<mapsto> z) " using newton_def_1 by mty auto
  also have "... = \<Pi> (<*\<^bsub>FINSEQ_1K10\<^esub> z *>)" 
     using finseq_2_th_59 FINSEQ_1R1_def by auto
  also have "... = z" using rvsum_1_th_95  by auto  
  finally show "z\<^bsup>1\<^esup> = z" by mauto  
qed
    
text_raw {*\DefineSnippet{newtonth6}{*}
mtheorem newton_th_6:
  "z\<^bsup>s +\<^bsub>\<nat>\<^esub> 1\<^esup> = z\<^bsup>s\<^esup> *\<^bsub>\<complex>\<^esub> z" 
text_raw {*}%EndSnippet*}  
proof-
    have "z \<^bsup>s +\<^bsub>\<nat>\<^esub> 1\<^esup> = \<Pi> ((s +\<^bsub>\<nat>\<^esub> 1) \<mapsto> z)"
        unfolding NAT_1K1_def using newton_def_1 by mauto
    also have "... =  \<Pi>((s \<mapsto> z)^ <*\<^bsub>FINSEQ_1K10\<^esub> z *>)"
        using finseq_2_th_60 FINSEQ_1R1_def by mty auto     
    also have "... =  (\<Pi> (s \<mapsto> z)) *\<^bsub>\<complex>\<^esub> z" using rvsum_1_th_96 by mauto
    also have "... =  z\<^bsup>s\<^esup> *\<^bsub>\<complex>\<^esub> z" using newton_def_1 by mauto
    finally show ?thesis by mauto
  qed   


text_raw {*\DefineSnippet{newton_cl}{*}        
mtheorem 
  mlet "x is natural\<bar>Number", "n is natural\<bar>Number"
  "cluster x\<^bsup>n\<^esup> \<rightarrow> natural"
proof
  have A0:"n is Nat" using tarski_th_1 by simp    
  let ?P = 
    "\<lambda>it. x\<^bsup>it\<^esup> is natural"
  have A1: "for a be Nat st ?P(a) 
    holds ?P(a +\<^bsub>\<nat>\<^esub> 1)"
  proof(rule ballI,rule impI)
    fix a assume [ty]:"a be Nat" and "?P(a)"
    hence [ty]:"x\<^bsup>a\<^esup> is natural\<bar>Number" by mauto
    have "x\<^bsup>a +\<^bsub>\<nat>\<^esub> 1\<^esup> = x\<^bsup>a\<^esup> *\<^bsub>\<complex>\<^esub> x" 
      using newton_th_6[of a] by mauto
    thus "x\<^bsup>a +\<^bsub>\<nat>\<^esub> 1\<^esup> is natural" by mauto
  qed mauto 
  have A2:"?P(0)" using newton_th_4 by mauto
  have "for a be Nat holds ?P(a)" 
    using nat_1_sch_2[of ?P] A2 A1 by simp
  thus "x\<^bsup>n\<^esup> is natural" using A0 by simp     
qed 
  
text_raw {*}%EndSnippet*}
(* last empty line needed for snippet*)   

mtheorem 
  mlet "a is Complex"
  "reduce a\<^bsup>1\<^esup> to a" using newton_th_5 by auto    
            
text_raw {*\DefineSnippet{newtonth7}{*}    
mtheorem newton_th_7:
  "(x *\<^bsub>\<complex>\<^esub> y)\<^bsup>s\<^esup> = x\<^bsup>s\<^esup> *\<^bsub>\<complex>\<^esub> y\<^bsup>s\<^esup>" 
  text_raw {*}%EndSnippet*}
proof-
  have [ty]:"(x *\<^bsub>\<complex>\<^esub> y) is Complex" unfolding XCMPLX_0M1_def by mauto 
  have "(x *\<^bsub>\<complex>\<^esub> y)\<^bsup>s\<^esup> = \<Pi> (s \<mapsto> (x *\<^bsub>\<complex>\<^esub> y))" using newton_def_1 by mauto
  also have "... = (\<Pi> (s |->\<^bsub>FINSEQ_2K5\<^esub> COMPLEX,x)) *\<^bsub>\<complex>\<^esub> 
                   (\<Pi> (s |->\<^bsub>FINSEQ_2K5\<^esub> COMPLEX,y))" using rvsum_1_th_113 by mauto
  also have "... = (x\<^bsup>s\<^esup>) *\<^bsub>\<complex>\<^esub> (y\<^bsup>s\<^esup>)" unfolding FINSEQ_2K5_def using newton_def_1 by mauto
  finally show ?thesis by mauto 
qed  

text_raw {*\DefineSnippet{newtonth8}{*}
mtheorem newton_th_8:
  "x\<^bsup>s +\<^bsub>\<complex>\<^esub> t\<^esup> = x\<^bsup>s\<^esup> *\<^bsub>\<complex>\<^esub> x\<^bsup>t\<^esup>" 
text_raw {*}%EndSnippet*}    
proof-
  have "x\<^bsup>s +\<^bsub>\<complex>\<^esub> t\<^esup> = \<Pi> ((s +\<^bsub>\<complex>\<^esub> t) |->\<^bsub>FINSEQ_2K5\<^esub> COMPLEX, x)" 
      unfolding FINSEQ_2K5_def using newton_def_1 by mauto
  also have "... = (\<Pi> (s |->\<^bsub>FINSEQ_2K5\<^esub> COMPLEX,x)) *\<^bsub>\<complex>\<^esub> 
                   (\<Pi> (t |->\<^bsub>FINSEQ_2K5\<^esub> COMPLEX,x))" using rvsum_1_th_111 by mauto
  also have "... = x\<^bsup>s\<^esup> *\<^bsub>\<complex>\<^esub> x\<^bsup>t\<^esup>" unfolding FINSEQ_2K5_def using newton_def_1 by mauto
  finally show ?thesis  by mauto
qed

text_raw {*\DefineSnippet{newtonth9}{*}
mtheorem newton_th_9:
  "(x\<^bsup>s\<^esup>)\<^bsup>t\<^esup> = x\<^bsup>(s *\<^bsub>\<complex>\<^esub> t)\<^esup>" 
text_raw {*}%EndSnippet*}  
proof-
  have [ty]:"x\<^bsup>s\<^esup> is Complex" unfolding XCMPLX_0M1_def by mty auto
  have "(x\<^bsup>s\<^esup>)\<^bsup>t\<^esup> = \<Pi> ( t |->\<^bsub>FINSEQ_2K5\<^esub> COMPLEX, \<Pi> (s |->\<^bsub>FINSEQ_2K5\<^esub>COMPLEX,x))" 
      unfolding FINSEQ_2K5_def using newton_def_1 by mauto
  also have "... = \<Pi> ((s *\<^bsub>\<complex>\<^esub> t) |->\<^bsub>FINSEQ_2K5\<^esub> COMPLEX,x)" 
      using rvsum_1_th_112 by mauto
  also have "... = x\<^bsup>(s *\<^bsub>\<complex>\<^esub> t)\<^esup>" 
      unfolding FINSEQ_2K5_def using rvsum_1_th_112 newton_def_1 by mauto
  finally show ?thesis by mauto
qed

notation XBOOLE_0K2 (infixl "\<union>" 65)
  

notation FUNCT_1K4 ("_ \<inverse>" 65)
  
thm funct_1_cl_10
  
text_raw {*\DefineSnippet{funct_1_cl_10}{*}
text {* @{thm [display]   funct_1_cl_10[no_vars]} *}
text_raw {*}%EndSnippet*}

text_raw {*\DefineSnippet{xboole_0_def_1}{*}
text {* @{thm [display] xboole_0_def_1[no_vars]} *}
text_raw {*}%EndSnippet*}

text_raw {*\DefineSnippet{xboole_0_def_1E}{*}
text {* @{thm [display] xboole_0_def_1E[no_vars]} *}
text_raw {*}%EndSnippet*}
  
text_raw {*\DefineSnippet{xboole_0_def_1I}{*}
text {* @{thm [display] xboole_0_def_1E[no_vars]} *}
text_raw {*}%EndSnippet*}
  
text_raw {*\DefineSnippet{xboole_0_def_10}{*}
text {* @{thm [display]  xboole_0_def_10[no_vars]} *}
text_raw {*}%EndSnippet*}
  
  
text_raw {*\DefineSnippet{subset_1_def_1}{*}
text {* @{thm [display]  subset_1_def_1[no_vars]} *}
text_raw {*}%EndSnippet*}
text_raw {*\DefineSnippet{XBOOLE_0_def_3}{*}
text {* @{thm [display]   xboole_0_def_3[no_vars]} *}
text_raw {*}%EndSnippet*}
  
  
text_raw {*\DefineSnippet{XBOOLE_0K2_commutativity}{*}
text {* @{thm [display]   XBOOLE_0K2_commutativity[no_vars]} *}
text_raw {*}%EndSnippet*}

text_raw {*\DefineSnippet{XBOOLE_0K2_idempotence}{*}
text {* @{thm [display]   XBOOLE_0K2_idempotence[no_vars]} *}
text_raw {*}%EndSnippet*}

text_raw {*\DefineSnippet{ordinal2_def_10}{*}
text {* @{thm [display]   ordinal2_def_10[no_vars]} *}
text_raw {*}%EndSnippet*}

 thm ordinal2_def_10_uniq
text_raw {*\DefineSnippet{ordinal2_def_10_ty}{*}
text {* @{thm [display]   ordinal2_def_10_ty[no_vars]} *}
text_raw {*}%EndSnippet*}
  
text_raw {*\DefineSnippet{finseq_1_th_17}{*}
text {* @{thm [display]   finseq_1_th_17[no_vars]} *}
text_raw {*}%EndSnippet*}

text_raw {*\DefineSnippet{FUNCT_1_def_1}{*}
text {* @{thm [display]   funct_1_def_1[no_vars]} *}
text_raw {*}%EndSnippet*}
  
text_raw {*\DefineSnippet{FUNCT_1_def_3}{*}
text {* @{thm [display]   funct_1_def_3[no_vars]} *}
text_raw {*}%EndSnippet*}

text_raw {*\DefineSnippet{finseq_1_add_3}{*}
text {* @{thm [display]  finseq_1_add_3[no_vars]} *}
text_raw {*}%EndSnippet*}
  
text_raw {*\DefineSnippet{SUBSET_1R1_def}{*}
text {* @{thm [display] SUBSET_1R1_def[no_vars]} *}
text_raw {*}%EndSnippet*}  
  
text_raw {*\DefineSnippet{SUBSET_1R1_irreflexivity}{*}
text {* @{thm [display] SUBSET_1R1_irreflexivity[no_vars]} *}
text_raw {*}%EndSnippet*}

text_raw {*\DefineSnippet{xboole_0_def_1A}{*}  
mdef xboole_0_def_1A : XBOOLE_0V1A ("emptyA") where
  "attr emptyA for set means 
     (\<lambda>X. \<not> (\<exists>x : object. x in X))"..  
text_raw {*}%EndSnippet*}

text_raw {*\DefineSnippet{XBOOLE_0R4_def}{*}
text {* @{thm [display]  XBOOLE_0R4_def[no_vars]} *}
text_raw {*}%EndSnippet*}
  
  
text_raw {*\DefineSnippet{subset_1_def_1A}{*}    
mdef subset_1_def_1A : SUBSET_1M1A ("ElementA _") where
  mlet "X is set"
  "mode ElementA X \<rightarrow> set means 
     (\<lambda>it. it in\<^bsub>TARSKIR2\<^esub> X if X is non empty otherwise \<lambda>it. it is empty)"  
text_raw {*}%EndSnippet*}
proof-
  show "(X is non empty \<longrightarrow> (\<exists>x : set. x in\<^bsub>TARSKIR2\<^esub> X)) \<and> (\<not> X is non empty \<longrightarrow> (\<exists>x : set. x is empty))"
  proof(intro impI conjI)
    assume [ty]: "X is non empty" 
    then obtain x where
      "x be object" and A1: "x in X" using xboole_0_def_1I by mauto
    thus "ex x be set st x in\<^bsub>TARSKIR2\<^esub> X " unfolding TARSKIR2_def using tarski_0_1 by auto
   next
      assume A2: "\<not> X is non empty"
      thus "ex x be set st x is empty " using tarski_0_1 by auto
    qed  
qed mauto
  
text_raw {*\DefineSnippet{RELAT_1K1_def}{*}
text {* @{thm [display] RELAT_1K1_def[no_vars]} *}
text_raw {*}%EndSnippet*}
  
text_raw {*\DefineSnippet{CARD_3V6_def}{*}
text {* @{thm [display] CARD_3V6_def[no_vars]} *}
text_raw {*}%EndSnippet*}

end
