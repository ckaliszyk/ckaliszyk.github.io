<?xml version="1.0"?>
<Registrations>
<Signature>
<ArticleID name="HIDDEN"/>
<ArticleID name="TARSKI"/>
<ArticleID name="XBOOLE_0"/>
<ArticleID name="ZFMISC_1"/>
<ArticleID name="SUBSET_1"/>
<ArticleID name="RELAT_1"/>
<ArticleID name="XTUPLE_0"/>
<ArticleID name="FUNCT_1"/>
<ArticleID name="ORDINAL1"/>
<ArticleID name="NUMBERS"/>
<ArticleID name="XCMPLX_0"/>
<ArticleID name="XREAL_0"/>
<ArticleID name="INT_1"/>
<ArticleID name="FINSET_1"/>
<ArticleID name="CARD_1"/>
<ArticleID name="FINSEQ_1"/>
<ArticleID name="PARTFUN1"/>
<ArticleID name="MCART_1"/>
<ArticleID name="FUNCT_2"/>
<ArticleID name="ORDINAL2"/>
<ArticleID name="SETFAM_1"/>
<ArticleID name="CLASSES2"/>
<ArticleID name="ORDINAL4"/>
<ArticleID name="AFINSQ_1"/>
<ArticleID name="XXREAL_0"/>
<ArticleID name="BINOP_1"/>
<ArticleID name="NAT_1"/>
<ArticleID name="VALUED_0"/>
<ArticleID name="RAT_1"/>
<ArticleID name="SURREAL0"/>
<ArticleID name="SURREALI"/>
<ArticleID name="SURREALO"/>
<ArticleID name="SURREALN"/>
<ArticleID name="SURREALC"/>
</Signature>
<RCluster aid="SURREALC" nr="1">
<ArgTypes/>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
<Cluster>
<Adjective nr="4"/>
<Adjective nr="12"/>
<Adjective nr="21"/>
<Adjective nr="85"/>
</Cluster>
</RCluster>
<RCluster aid="SURREALC" nr="2">
<ArgTypes/>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
<Cluster>
<Adjective nr="4"/>
<Adjective nr="12"/>
<Adjective nr="21"/>
<Adjective nr="86"/>
</Cluster>
</RCluster>
<RCluster aid="SURREALC" nr="3">
<ArgTypes/>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
<Cluster>
<Adjective nr="4"/>
<Adjective nr="12"/>
<Adjective nr="21"/>
<Adjective nr="85"/>
<Adjective nr="86"/>
<Adjective nr="87"/>
</Cluster>
</RCluster>
<RCluster aid="SURREALC" nr="4">
<ArgTypes/>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
<Cluster>
<Adjective nr="4"/>
<Adjective nr="8">
<Func kind="K" nr="57"/>
</Adjective>
<Adjective nr="12"/>
<Adjective nr="21"/>
<Adjective nr="25"/>
<Adjective nr="61"/>
<Adjective nr="62"/>
<Adjective nr="63"/>
</Cluster>
</RCluster>
<RCluster aid="SURREALC" nr="5">
<ArgTypes/>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
<Cluster>
<Adjective nr="4"/>
<Adjective nr="12"/>
<Adjective nr="21"/>
<Adjective nr="85"/>
<Adjective nr="86"/>
<Adjective nr="90"/>
<Adjective nr="91"/>
</Cluster>
</RCluster>
<FCluster aid="SURREALC" nr="1">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="75"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="262">
<LocusVar nr="1"/>
</Func>
<Cluster>
<Adjective nr="75"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALC" nr="2">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="75"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="262">
<LocusVar nr="1"/>
</Func>
<Cluster>
<Adjective nr="78"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALC" nr="3">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="75"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="182">
<LocusVar nr="1"/>
</Func>
<Cluster>
<Adjective nr="85"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALC" nr="4">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="4"/>
<Adjective nr="12"/>
<Adjective nr="85"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="43">
<LocusVar nr="1"/>
</Func>
<Cluster>
<Adjective nr="76"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALC" nr="5">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="4"/>
<Adjective nr="12"/>
<Adjective nr="85"/>
</Cluster>
</Typ>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
</ArgTypes>
<Func kind="K" nr="28">
<LocusVar nr="1"/>
<LocusVar nr="2"/>
</Func>
<Cluster>
<Adjective nr="4"/>
<Adjective nr="85"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALC" nr="6">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="4"/>
<Adjective nr="12"/>
<Adjective nr="21"/>
<Adjective nr="85"/>
</Cluster>
</Typ>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="4"/>
<Adjective nr="12"/>
<Adjective nr="21"/>
<Adjective nr="85"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="172">
<LocusVar nr="1"/>
<LocusVar nr="2"/>
</Func>
<Cluster>
<Adjective nr="4"/>
<Adjective nr="12"/>
<Adjective nr="21"/>
<Adjective nr="85"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALC" nr="7">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="75"/>
<Adjective nr="80"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="182">
<LocusVar nr="1"/>
</Func>
<Cluster>
<Adjective nr="86"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALC" nr="8">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="4"/>
<Adjective nr="12"/>
<Adjective nr="86"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="43">
<LocusVar nr="1"/>
</Func>
<Cluster>
<Adjective nr="81"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALC" nr="9">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="4"/>
<Adjective nr="12"/>
<Adjective nr="86"/>
</Cluster>
</Typ>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
</ArgTypes>
<Func kind="K" nr="28">
<LocusVar nr="1"/>
<LocusVar nr="2"/>
</Func>
<Cluster>
<Adjective nr="4"/>
<Adjective nr="86"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALC" nr="10">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="4"/>
<Adjective nr="12"/>
<Adjective nr="21"/>
<Adjective nr="86"/>
</Cluster>
</Typ>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="4"/>
<Adjective nr="12"/>
<Adjective nr="21"/>
<Adjective nr="86"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="172">
<LocusVar nr="1"/>
<LocusVar nr="2"/>
</Func>
<Cluster>
<Adjective nr="4"/>
<Adjective nr="12"/>
<Adjective nr="21"/>
<Adjective nr="86"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALC" nr="11">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="75"/>
<Adjective nr="80"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="182">
<LocusVar nr="1"/>
</Func>
<Cluster>
<Adjective nr="87"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALC" nr="12">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="4"/>
<Adjective nr="12"/>
<Adjective nr="21"/>
<Adjective nr="25"/>
</Cluster>
</Typ>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="4"/>
<Adjective nr="12"/>
<Adjective nr="21"/>
<Adjective nr="25"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="172">
<LocusVar nr="1"/>
<LocusVar nr="2"/>
</Func>
<Cluster>
<Adjective nr="4"/>
<Adjective nr="12"/>
<Adjective nr="21"/>
<Adjective nr="25"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALC" nr="13">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="75"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="182">
<LocusVar nr="1"/>
</Func>
<Cluster>
<Adjective nr="91"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALC" nr="14">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="75"/>
<Adjective nr="78"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="182">
<LocusVar nr="1"/>
</Func>
<Cluster>
<Adjective nr="90"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALC" nr="15">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="4"/>
<Adjective nr="12"/>
<Adjective nr="21"/>
<Adjective nr="85"/>
<Adjective nr="90"/>
</Cluster>
</Typ>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="19"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="28">
<LocusVar nr="1"/>
<LocusVar nr="2"/>
</Func>
<Cluster>
<Adjective nr="4"/>
<Adjective nr="90"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALC" nr="16">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="4"/>
<Adjective nr="12"/>
<Adjective nr="21"/>
<Adjective nr="85"/>
<Adjective nr="91"/>
</Cluster>
</Typ>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="19"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="28">
<LocusVar nr="1"/>
<LocusVar nr="2"/>
</Func>
<Cluster>
<Adjective nr="4"/>
<Adjective nr="91"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALC" nr="17">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="4"/>
<Adjective nr="12"/>
<Adjective nr="21"/>
<Adjective nr="85"/>
<Adjective nr="87"/>
</Cluster>
</Typ>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="19"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="28">
<LocusVar nr="1"/>
<LocusVar nr="2"/>
</Func>
<Cluster>
<Adjective nr="4"/>
<Adjective nr="87"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALC" nr="18">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="4"/>
<Adjective nr="25"/>
</Cluster>
</Typ>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
</ArgTypes>
<Func kind="K" nr="28">
<LocusVar nr="1"/>
<LocusVar nr="2"/>
</Func>
<Cluster>
<Adjective nr="4"/>
<Adjective nr="25"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALC" nr="19">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="4"/>
<Adjective nr="12"/>
<Adjective nr="21"/>
<Adjective nr="85"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="268">
<LocusVar nr="1"/>
</Func>
<Cluster>
<Adjective nr="4"/>
<Adjective nr="12"/>
<Adjective nr="21"/>
<Adjective nr="85"/>
<Adjective nr="90"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALC" nr="20">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="4"/>
<Adjective nr="12"/>
<Adjective nr="21"/>
<Adjective nr="85"/>
<Adjective nr="87"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="268">
<LocusVar nr="1"/>
</Func>
<Cluster>
<Adjective nr="4"/>
<Adjective nr="12"/>
<Adjective nr="21"/>
<Adjective nr="85"/>
<Adjective nr="91"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALC" nr="21">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="4"/>
<Adjective nr="8">
<Func kind="K" nr="57"/>
</Adjective>
<Adjective nr="12"/>
<Adjective nr="21"/>
<Adjective nr="25"/>
</Cluster>
</Typ>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="4"/>
<Adjective nr="12"/>
<Adjective nr="21"/>
<Adjective nr="85"/>
<Adjective nr="90"/>
<Adjective nr="91"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="266">
<LocusVar nr="1"/>
<LocusVar nr="2"/>
</Func>
<Cluster>
<Adjective nr="4"/>
<Adjective nr="12"/>
<Adjective nr="13"/>
<Adjective nr="21"/>
<Adjective nr="86"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALC" nr="22">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="4"/>
<Adjective nr="8">
<Func kind="K" nr="57"/>
</Adjective>
<Adjective nr="12"/>
<Adjective nr="21"/>
<Adjective nr="25"/>
</Cluster>
</Typ>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="4"/>
<Adjective nr="12"/>
<Adjective nr="21"/>
<Adjective nr="85"/>
<Adjective nr="90"/>
<Adjective nr="91"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="269">
<Func kind="K" nr="266">
<LocusVar nr="1"/>
<LocusVar nr="2"/>
</Func>
</Func>
<Cluster>
<Adjective nr="4"/>
<Adjective nr="12"/>
<Adjective nr="21"/>
<Adjective nr="47"/>
<Adjective nr="48"/>
</Cluster>
</FCluster>
<CCluster aid="SURREALC" nr="1">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="76"/>
</Cluster>
</Typ>
</ArgTypes>
<Cluster/>
<Typ kind="M" nr="3">
<Cluster/>
<Func kind="K" nr="10">
<LocusVar nr="1"/>
</Func>
</Typ>
<Cluster>
<Adjective nr="76"/>
</Cluster>
</CCluster>
<CCluster aid="SURREALC" nr="2">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="81"/>
</Cluster>
</Typ>
</ArgTypes>
<Cluster/>
<Typ kind="M" nr="3">
<Cluster/>
<Func kind="K" nr="10">
<LocusVar nr="1"/>
</Func>
</Typ>
<Cluster>
<Adjective nr="81"/>
</Cluster>
</CCluster>
<CCluster aid="SURREALC" nr="3">
<ArgTypes/>
<Cluster>
<Adjective nr="81"/>
</Cluster>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
<Cluster>
<Adjective nr="76"/>
</Cluster>
</CCluster>
<CCluster aid="SURREALC" nr="4">
<ArgTypes/>
<Cluster>
<Adjective nr="4"/>
<Adjective nr="12"/>
<Adjective nr="86"/>
</Cluster>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
<Cluster>
<Adjective nr="4"/>
<Adjective nr="12"/>
<Adjective nr="85"/>
</Cluster>
</CCluster>
</Registrations>
