B1
intersection(F,D)