set_difference(F,C)
domain(F,D,I)