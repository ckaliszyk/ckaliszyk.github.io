fof(myForms, conjecture, ! [D] : ! [F] : disjoint(intersection(D,F),symmetric_difference(D,F))).
fof(myForms, conjecture, ! [F] : disjoint(intersection(D,F),symmetric_difference(D,F))).
fof(myForms, conjecture, disjoint(intersection(D,F),symmetric_difference(D,F))).