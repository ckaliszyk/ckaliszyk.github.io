powerset(set_difference(C,D))
O