member_type(I)
union(C)