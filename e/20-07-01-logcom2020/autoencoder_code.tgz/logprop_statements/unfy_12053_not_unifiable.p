restrict4(I,D,F,J)
power_set(J)