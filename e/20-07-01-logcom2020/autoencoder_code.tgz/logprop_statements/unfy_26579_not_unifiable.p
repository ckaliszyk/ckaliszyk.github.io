compose5(D,F,I,J,B)
cartesian_product2(set_intersection2(C,D),F)