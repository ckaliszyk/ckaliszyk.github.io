fof(myForms, conjecture, ! [J] : equal_set(difference(J,J),empty_set)).
fof(myForms, conjecture, ! [C] : ! [D] : ~ (((~ singleton(D)=C & ~ empty_set=C) & ! [F] : ~ ((in(F,C) & ~ F=D))))).