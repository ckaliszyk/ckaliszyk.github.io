fof(myForms, conjecture, ! [J] : equal_set(difference(J,J),empty_set)).
fof(myForms, conjecture, ! [C] : ! [D] : ! [F] : ((in(C,D) & in(F,D)) => set_union2(unordered_pair(C,F),D)=D)).