domain_of(I)
union(intersection(D,F),intersection(D,I))