N
powerset(singleton(C))