difference(union(D,F),I)
set_intersection2(C,singleton(D))