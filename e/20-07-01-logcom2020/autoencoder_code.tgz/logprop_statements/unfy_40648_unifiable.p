E1
compose_function(X,compose_function(E,B,C,D,F),C,F,I)