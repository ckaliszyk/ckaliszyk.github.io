power_set(D)
set_difference(C,singleton(D))