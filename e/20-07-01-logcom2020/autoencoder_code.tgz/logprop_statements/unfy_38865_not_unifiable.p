union(image2(B,L),image2(B,P))
intersection(union(D,F),union(D,I))