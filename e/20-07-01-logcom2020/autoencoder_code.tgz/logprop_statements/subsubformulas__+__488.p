fof(myForms, conjecture, ! [G1] : (ilf_type(G1,set_type) => (subset(I,cross_product(B,G1)) => ilf_type(I,relation_type(B,G1))))).
fof(myForms, conjecture, (ilf_type(G1,set_type) => (subset(I,cross_product(B,G1)) => ilf_type(I,relation_type(B,G1))))).
fof(myForms, conjecture, ilf_type(G1,set_type)).
fof(myForms, conjecture, (subset(I,cross_product(B,G1)) => ilf_type(I,relation_type(B,G1)))).
fof(myForms, conjecture, subset(I,cross_product(B,G1))).
fof(myForms, conjecture, ilf_type(I,relation_type(B,G1))).