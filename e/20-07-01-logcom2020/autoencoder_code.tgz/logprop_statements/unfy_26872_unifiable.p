inverse_image3(B,intersection(L,P),C)
C1