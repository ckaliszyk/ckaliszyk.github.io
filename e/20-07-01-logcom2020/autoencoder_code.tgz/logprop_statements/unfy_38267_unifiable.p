powerset(C)
V