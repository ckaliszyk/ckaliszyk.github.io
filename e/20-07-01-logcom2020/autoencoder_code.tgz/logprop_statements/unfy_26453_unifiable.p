difference(D,union(D,F))
S