union(D)
set_union2(D,F)