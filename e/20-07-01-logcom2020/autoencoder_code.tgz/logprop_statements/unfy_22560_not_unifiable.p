union(D,F)
cartesian_product2(D,D)