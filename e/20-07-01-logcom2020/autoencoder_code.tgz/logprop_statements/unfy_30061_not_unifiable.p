subset_type(D)
intersection(D,union(F,I))