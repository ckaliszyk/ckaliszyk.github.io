union(union(D,F),I)
symmetric_difference(D,empty_set)