compose5(D,F,I,J,B)
symmetric_difference(F,D)