symmetric_difference(F,I)
H