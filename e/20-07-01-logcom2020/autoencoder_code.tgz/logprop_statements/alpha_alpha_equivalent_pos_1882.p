fof(myForms, conjecture, ! [C] : ! [D] : (subset(set_union2(singleton(C),D),D) => in(C,D))).
fof(myForms, conjecture, ! [R3] : ! [S3] : (subset(set_union2(singleton(R3),S3),S3) => in(R3,S3))).