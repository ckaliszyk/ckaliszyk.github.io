fof(myForms, conjecture, ! [C] : ((empty(C) => (empty(relation_dom(C)) & relation(relation_dom(C)))) => empty(C))).
fof(myForms, conjecture, ! [C] : empty(C)).