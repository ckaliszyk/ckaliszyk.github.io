compose_function(B,X,D,C,D)
compose_function(X,B,C,D,F)