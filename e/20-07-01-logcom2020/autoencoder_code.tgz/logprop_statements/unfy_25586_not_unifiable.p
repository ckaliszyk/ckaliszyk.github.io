intersection(F,difference(J,F))
inverse_function(B,C,D)