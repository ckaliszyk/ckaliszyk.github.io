cartesian_product2(set_intersection2(D,I),set_intersection2(F,J))
set_union2(set_difference(C,D),set_difference(C,F))