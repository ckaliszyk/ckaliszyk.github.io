fof(myForms, conjecture, ! [I] : (ilf_type(I,set_type) => ! [B] : (ilf_type(B,set_type) => ! [G1] : (ilf_type(G1,set_type) => ! [J1] : (ilf_type(J1,set_type) => ! [D] : (ilf_type(D,relation_type(I,G1)) => ((subset(I,B) & subset(G1,J1)) => ilf_type(D,relation_type(B,J1))))))))).
fof(myForms, conjecture, (ilf_type(I,set_type) => ! [B] : (ilf_type(B,set_type) => ! [G1] : (ilf_type(G1,set_type) => ! [J1] : (ilf_type(J1,set_type) => ! [D] : (ilf_type(D,relation_type(I,G1)) => ((subset(I,B) & subset(G1,J1)) => ilf_type(D,relation_type(B,J1))))))))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [B] : (ilf_type(B,set_type) => ! [G1] : (ilf_type(G1,set_type) => ! [J1] : (ilf_type(J1,set_type) => ! [D] : (ilf_type(D,relation_type(I,G1)) => ((subset(I,B) & subset(G1,J1)) => ilf_type(D,relation_type(B,J1)))))))).
fof(myForms, conjecture, (ilf_type(B,set_type) => ! [G1] : (ilf_type(G1,set_type) => ! [J1] : (ilf_type(J1,set_type) => ! [D] : (ilf_type(D,relation_type(I,G1)) => ((subset(I,B) & subset(G1,J1)) => ilf_type(D,relation_type(B,J1)))))))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ! [G1] : (ilf_type(G1,set_type) => ! [J1] : (ilf_type(J1,set_type) => ! [D] : (ilf_type(D,relation_type(I,G1)) => ((subset(I,B) & subset(G1,J1)) => ilf_type(D,relation_type(B,J1))))))).
fof(myForms, conjecture, (ilf_type(G1,set_type) => ! [J1] : (ilf_type(J1,set_type) => ! [D] : (ilf_type(D,relation_type(I,G1)) => ((subset(I,B) & subset(G1,J1)) => ilf_type(D,relation_type(B,J1))))))).
fof(myForms, conjecture, ilf_type(G1,set_type)).
fof(myForms, conjecture, ! [J1] : (ilf_type(J1,set_type) => ! [D] : (ilf_type(D,relation_type(I,G1)) => ((subset(I,B) & subset(G1,J1)) => ilf_type(D,relation_type(B,J1)))))).
fof(myForms, conjecture, (ilf_type(J1,set_type) => ! [D] : (ilf_type(D,relation_type(I,G1)) => ((subset(I,B) & subset(G1,J1)) => ilf_type(D,relation_type(B,J1)))))).
fof(myForms, conjecture, ilf_type(J1,set_type)).
fof(myForms, conjecture, ! [D] : (ilf_type(D,relation_type(I,G1)) => ((subset(I,B) & subset(G1,J1)) => ilf_type(D,relation_type(B,J1))))).
fof(myForms, conjecture, (ilf_type(D,relation_type(I,G1)) => ((subset(I,B) & subset(G1,J1)) => ilf_type(D,relation_type(B,J1))))).
fof(myForms, conjecture, ilf_type(D,relation_type(I,G1))).
fof(myForms, conjecture, ((subset(I,B) & subset(G1,J1)) => ilf_type(D,relation_type(B,J1)))).
fof(myForms, conjecture, (subset(I,B) & subset(G1,J1))).
fof(myForms, conjecture, subset(I,B)).
fof(myForms, conjecture, subset(G1,J1)).
fof(myForms, conjecture, ilf_type(D,relation_type(B,J1))).