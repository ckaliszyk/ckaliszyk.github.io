range(D,F,J)
range(F,D,inverse3(D,F,I))