set_difference(unordered_pair(C,D),singleton(D))
singleton(ordered_pair(C,D))