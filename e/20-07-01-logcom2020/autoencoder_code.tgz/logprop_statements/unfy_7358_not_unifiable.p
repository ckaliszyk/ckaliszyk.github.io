unordered_pair(C,C)
inverse_image3(B,image3(B,L,D),C)