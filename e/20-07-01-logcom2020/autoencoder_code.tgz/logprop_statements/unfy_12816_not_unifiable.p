cartesian_product2(set_union2(C,D),F)
identity_relation_of(F)