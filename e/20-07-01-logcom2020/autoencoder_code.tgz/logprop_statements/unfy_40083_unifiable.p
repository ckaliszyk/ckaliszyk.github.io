inverse_function(compose_function(E,B,C,D,F),C,F)
G1