fof(myForms, conjecture, ((~ empty(I) & ilf_type(I,set_type)) => ! [B] : ((~ empty(B) & ilf_type(B,set_type)) => ! [G1] : (ilf_type(G1,relation_type(I,B)) => ! [J1] : (ilf_type(J1,member_type(I)) => (member(J1,domain(I,B,G1)) <=> ? [D] : (ilf_type(D,member_type(B)) & member(ordered_pair(J1,D),G1)))))))).
fof(myForms, conjecture, (~ empty(I) & ilf_type(I,set_type))).
fof(myForms, conjecture, ~ empty(I)).
fof(myForms, conjecture, empty(I)).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [B] : ((~ empty(B) & ilf_type(B,set_type)) => ! [G1] : (ilf_type(G1,relation_type(I,B)) => ! [J1] : (ilf_type(J1,member_type(I)) => (member(J1,domain(I,B,G1)) <=> ? [D] : (ilf_type(D,member_type(B)) & member(ordered_pair(J1,D),G1))))))).
fof(myForms, conjecture, ((~ empty(B) & ilf_type(B,set_type)) => ! [G1] : (ilf_type(G1,relation_type(I,B)) => ! [J1] : (ilf_type(J1,member_type(I)) => (member(J1,domain(I,B,G1)) <=> ? [D] : (ilf_type(D,member_type(B)) & member(ordered_pair(J1,D),G1))))))).
fof(myForms, conjecture, (~ empty(B) & ilf_type(B,set_type))).
fof(myForms, conjecture, ~ empty(B)).
fof(myForms, conjecture, empty(B)).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ! [G1] : (ilf_type(G1,relation_type(I,B)) => ! [J1] : (ilf_type(J1,member_type(I)) => (member(J1,domain(I,B,G1)) <=> ? [D] : (ilf_type(D,member_type(B)) & member(ordered_pair(J1,D),G1)))))).
fof(myForms, conjecture, (ilf_type(G1,relation_type(I,B)) => ! [J1] : (ilf_type(J1,member_type(I)) => (member(J1,domain(I,B,G1)) <=> ? [D] : (ilf_type(D,member_type(B)) & member(ordered_pair(J1,D),G1)))))).
fof(myForms, conjecture, ilf_type(G1,relation_type(I,B))).
fof(myForms, conjecture, ! [J1] : (ilf_type(J1,member_type(I)) => (member(J1,domain(I,B,G1)) <=> ? [D] : (ilf_type(D,member_type(B)) & member(ordered_pair(J1,D),G1))))).
fof(myForms, conjecture, (ilf_type(J1,member_type(I)) => (member(J1,domain(I,B,G1)) <=> ? [D] : (ilf_type(D,member_type(B)) & member(ordered_pair(J1,D),G1))))).
fof(myForms, conjecture, ilf_type(J1,member_type(I))).
fof(myForms, conjecture, (member(J1,domain(I,B,G1)) <=> ? [D] : (ilf_type(D,member_type(B)) & member(ordered_pair(J1,D),G1)))).
fof(myForms, conjecture, member(J1,domain(I,B,G1))).
fof(myForms, conjecture, ? [D] : (ilf_type(D,member_type(B)) & member(ordered_pair(J1,D),G1))).
fof(myForms, conjecture, (ilf_type(D,member_type(B)) & member(ordered_pair(J1,D),G1))).
fof(myForms, conjecture, ilf_type(D,member_type(B))).
fof(myForms, conjecture, member(ordered_pair(J1,D),G1)).