powerset(symmetric_difference(C,D))
V