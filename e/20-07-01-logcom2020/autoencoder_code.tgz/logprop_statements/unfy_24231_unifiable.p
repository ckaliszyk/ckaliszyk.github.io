cartesian_product2(C,F)
cartesian_product2(set_intersection2(C,D),set_intersection2(F,I))