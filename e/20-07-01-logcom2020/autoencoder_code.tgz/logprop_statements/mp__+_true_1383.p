fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) & (ilf_type(D,set_type) => subset(D,D)))).
fof(myForms, conjecture, ! [D] : subset(D,D)).