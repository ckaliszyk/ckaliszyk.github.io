cartesian_product2(J,B)
cartesian_product2(C,D)