ordered_pair(B,J)
P