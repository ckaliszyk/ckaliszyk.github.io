ordered_pair(I,B)
domain(D,F,I)