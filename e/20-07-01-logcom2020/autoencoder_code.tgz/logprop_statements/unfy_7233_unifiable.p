V
set_difference(F,C)