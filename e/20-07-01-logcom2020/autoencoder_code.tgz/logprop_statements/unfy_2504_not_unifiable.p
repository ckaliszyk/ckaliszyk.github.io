unordered_pair(C,F)
difference(D,D)