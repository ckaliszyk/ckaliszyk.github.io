D
relation_type(F,I)