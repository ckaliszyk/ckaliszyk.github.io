fof(myForms, conjecture, ! [J] : equal_set(difference(J,J),empty_set)).
fof(myForms, conjecture, ! [D] : (ilf_type(D,binary_relation_type) => ilf_type(field_of(D),set_type))).