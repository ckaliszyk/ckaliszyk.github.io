restrict4(F,D,J,I)
cartesian_product2(unordered_pair(C,D),singleton(F))