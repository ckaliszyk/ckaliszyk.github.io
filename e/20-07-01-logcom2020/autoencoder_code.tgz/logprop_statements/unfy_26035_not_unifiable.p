union(C,intersection(D,F))
range(D,D,F)