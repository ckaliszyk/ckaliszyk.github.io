restrict4(D,I,J,F)
range_of(J)