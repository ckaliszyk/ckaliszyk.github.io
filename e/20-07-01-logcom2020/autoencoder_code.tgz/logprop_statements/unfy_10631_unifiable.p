intersection(I,cross_product(D,F))
intersection(C,C)