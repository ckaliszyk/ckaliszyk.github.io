fof(myForms, conjecture, ! [T4] : ! [U4] : subset(T4,T4)).
fof(myForms, conjecture, ! [G9] : ! [H9] : subset(G9,G9)).