powerset(C)
U