set_difference(singleton(C),D)
L