difference(D,empty_set)
I1