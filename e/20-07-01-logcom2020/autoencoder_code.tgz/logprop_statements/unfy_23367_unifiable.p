T
intersection(F,difference(J,F))