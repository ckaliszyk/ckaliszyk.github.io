union(I,J)
J