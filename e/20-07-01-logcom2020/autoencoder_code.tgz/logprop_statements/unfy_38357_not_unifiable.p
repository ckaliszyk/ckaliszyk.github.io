intersection4(D,F,I,J)
union(C,union(D,F))