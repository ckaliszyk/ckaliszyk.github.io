C1
compose_function(B,compose_function(X,E,D,F,C),D,C,D)