fof(myForms, conjecture, ! [B] : (ilf_type(B,set_type) => ! [G1] : (ilf_type(G1,relation_type(B,I)) => (! [J1] : (ilf_type(J1,set_type) => (member(J1,B) => ? [D] : (ilf_type(D,set_type) & member(ordered_pair(J1,D),G1)))) <=> domain(B,I,G1)=B)))).
fof(myForms, conjecture, (ilf_type(B,set_type) => ! [G1] : (ilf_type(G1,relation_type(B,I)) => (! [J1] : (ilf_type(J1,set_type) => (member(J1,B) => ? [D] : (ilf_type(D,set_type) & member(ordered_pair(J1,D),G1)))) <=> domain(B,I,G1)=B)))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ! [G1] : (ilf_type(G1,relation_type(B,I)) => (! [J1] : (ilf_type(J1,set_type) => (member(J1,B) => ? [D] : (ilf_type(D,set_type) & member(ordered_pair(J1,D),G1)))) <=> domain(B,I,G1)=B))).
fof(myForms, conjecture, (ilf_type(G1,relation_type(B,I)) => (! [J1] : (ilf_type(J1,set_type) => (member(J1,B) => ? [D] : (ilf_type(D,set_type) & member(ordered_pair(J1,D),G1)))) <=> domain(B,I,G1)=B))).
fof(myForms, conjecture, ilf_type(G1,relation_type(B,I))).
fof(myForms, conjecture, (! [J1] : (ilf_type(J1,set_type) => (member(J1,B) => ? [D] : (ilf_type(D,set_type) & member(ordered_pair(J1,D),G1)))) <=> domain(B,I,G1)=B)).
fof(myForms, conjecture, ! [J1] : (ilf_type(J1,set_type) => (member(J1,B) => ? [D] : (ilf_type(D,set_type) & member(ordered_pair(J1,D),G1))))).
fof(myForms, conjecture, (ilf_type(J1,set_type) => (member(J1,B) => ? [D] : (ilf_type(D,set_type) & member(ordered_pair(J1,D),G1))))).
fof(myForms, conjecture, ilf_type(J1,set_type)).
fof(myForms, conjecture, (member(J1,B) => ? [D] : (ilf_type(D,set_type) & member(ordered_pair(J1,D),G1)))).
fof(myForms, conjecture, member(J1,B)).
fof(myForms, conjecture, ? [D] : (ilf_type(D,set_type) & member(ordered_pair(J1,D),G1))).
fof(myForms, conjecture, (ilf_type(D,set_type) & member(ordered_pair(J1,D),G1))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, member(ordered_pair(J1,D),G1)).
fof(myForms, conjecture, domain(B,I,G1)=B).