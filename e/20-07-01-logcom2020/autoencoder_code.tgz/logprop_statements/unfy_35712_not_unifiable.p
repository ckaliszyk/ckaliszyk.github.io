member_type(I)
intersection(D,union(F,I))