fof(myForms, conjecture, ! [I] : ! [B] : ! [G1] : union(difference(I,union(B,G1)),intersection(intersection(I,B),G1))=difference(I,symmetric_difference(B,G1))).
fof(myForms, conjecture, ! [B] : ! [G1] : union(difference(I,union(B,G1)),intersection(intersection(I,B),G1))=difference(I,symmetric_difference(B,G1))).
fof(myForms, conjecture, ! [G1] : union(difference(I,union(B,G1)),intersection(intersection(I,B),G1))=difference(I,symmetric_difference(B,G1))).
fof(myForms, conjecture, union(difference(I,union(B,G1)),intersection(intersection(I,B),G1))=difference(I,symmetric_difference(B,G1))).