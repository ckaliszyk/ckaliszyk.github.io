cartesian_product2(D,I)
cartesian_product2(unordered_pair(C,D),F)