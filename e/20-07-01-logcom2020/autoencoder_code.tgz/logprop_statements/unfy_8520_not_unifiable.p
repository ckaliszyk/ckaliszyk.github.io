ordered_pair(E,X)
cartesian_product2(set_difference(C,D),F)