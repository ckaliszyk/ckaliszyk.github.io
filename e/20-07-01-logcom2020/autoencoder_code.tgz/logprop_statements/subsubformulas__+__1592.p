fof(myForms, conjecture, ! [D] : ! [J] : ! [L] : ! [F] : ! [I] : ! [B] : (((((maps(D,F,I) & maps(J,I,B)) & maps(L,I,B)) & surjective(D,F,I)) & equal_maps(compose_function(J,D,F,I,B),compose_function(L,D,F,I,B),F,B)) => equal_maps(J,L,I,B))).
fof(myForms, conjecture, ! [J] : ! [L] : ! [F] : ! [I] : ! [B] : (((((maps(D,F,I) & maps(J,I,B)) & maps(L,I,B)) & surjective(D,F,I)) & equal_maps(compose_function(J,D,F,I,B),compose_function(L,D,F,I,B),F,B)) => equal_maps(J,L,I,B))).
fof(myForms, conjecture, ! [L] : ! [F] : ! [I] : ! [B] : (((((maps(D,F,I) & maps(J,I,B)) & maps(L,I,B)) & surjective(D,F,I)) & equal_maps(compose_function(J,D,F,I,B),compose_function(L,D,F,I,B),F,B)) => equal_maps(J,L,I,B))).
fof(myForms, conjecture, ! [F] : ! [I] : ! [B] : (((((maps(D,F,I) & maps(J,I,B)) & maps(L,I,B)) & surjective(D,F,I)) & equal_maps(compose_function(J,D,F,I,B),compose_function(L,D,F,I,B),F,B)) => equal_maps(J,L,I,B))).
fof(myForms, conjecture, ! [I] : ! [B] : (((((maps(D,F,I) & maps(J,I,B)) & maps(L,I,B)) & surjective(D,F,I)) & equal_maps(compose_function(J,D,F,I,B),compose_function(L,D,F,I,B),F,B)) => equal_maps(J,L,I,B))).
fof(myForms, conjecture, ! [B] : (((((maps(D,F,I) & maps(J,I,B)) & maps(L,I,B)) & surjective(D,F,I)) & equal_maps(compose_function(J,D,F,I,B),compose_function(L,D,F,I,B),F,B)) => equal_maps(J,L,I,B))).
fof(myForms, conjecture, (((((maps(D,F,I) & maps(J,I,B)) & maps(L,I,B)) & surjective(D,F,I)) & equal_maps(compose_function(J,D,F,I,B),compose_function(L,D,F,I,B),F,B)) => equal_maps(J,L,I,B))).
fof(myForms, conjecture, ((((maps(D,F,I) & maps(J,I,B)) & maps(L,I,B)) & surjective(D,F,I)) & equal_maps(compose_function(J,D,F,I,B),compose_function(L,D,F,I,B),F,B))).
fof(myForms, conjecture, (((maps(D,F,I) & maps(J,I,B)) & maps(L,I,B)) & surjective(D,F,I))).
fof(myForms, conjecture, ((maps(D,F,I) & maps(J,I,B)) & maps(L,I,B))).
fof(myForms, conjecture, (maps(D,F,I) & maps(J,I,B))).
fof(myForms, conjecture, maps(D,F,I)).
fof(myForms, conjecture, maps(J,I,B)).
fof(myForms, conjecture, maps(L,I,B)).
fof(myForms, conjecture, surjective(D,F,I)).
fof(myForms, conjecture, equal_maps(compose_function(J,D,F,I,B),compose_function(L,D,F,I,B),F,B)).
fof(myForms, conjecture, equal_maps(J,L,I,B)).