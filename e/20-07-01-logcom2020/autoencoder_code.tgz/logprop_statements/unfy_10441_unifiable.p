ordered_pair(G1,X)
I1