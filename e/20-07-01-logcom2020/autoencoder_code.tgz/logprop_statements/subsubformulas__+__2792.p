fof(myForms, conjecture, ! [I] : ! [B] : (cartesian_product2(F,I)=B <=> ! [G1] : (in(G1,B) <=> ? [J1] : ? [D] : ((in(J1,F) & in(D,I)) & ordered_pair(J1,D)=G1)))).
fof(myForms, conjecture, ! [B] : (cartesian_product2(F,I)=B <=> ! [G1] : (in(G1,B) <=> ? [J1] : ? [D] : ((in(J1,F) & in(D,I)) & ordered_pair(J1,D)=G1)))).
fof(myForms, conjecture, (cartesian_product2(F,I)=B <=> ! [G1] : (in(G1,B) <=> ? [J1] : ? [D] : ((in(J1,F) & in(D,I)) & ordered_pair(J1,D)=G1)))).
fof(myForms, conjecture, cartesian_product2(F,I)=B).
fof(myForms, conjecture, ! [G1] : (in(G1,B) <=> ? [J1] : ? [D] : ((in(J1,F) & in(D,I)) & ordered_pair(J1,D)=G1))).
fof(myForms, conjecture, (in(G1,B) <=> ? [J1] : ? [D] : ((in(J1,F) & in(D,I)) & ordered_pair(J1,D)=G1))).
fof(myForms, conjecture, in(G1,B)).
fof(myForms, conjecture, ? [J1] : ? [D] : ((in(J1,F) & in(D,I)) & ordered_pair(J1,D)=G1)).
fof(myForms, conjecture, ? [D] : ((in(J1,F) & in(D,I)) & ordered_pair(J1,D)=G1)).
fof(myForms, conjecture, ((in(J1,F) & in(D,I)) & ordered_pair(J1,D)=G1)).
fof(myForms, conjecture, (in(J1,F) & in(D,I))).
fof(myForms, conjecture, in(J1,F)).
fof(myForms, conjecture, in(D,I)).
fof(myForms, conjecture, ordered_pair(J1,D)=G1).