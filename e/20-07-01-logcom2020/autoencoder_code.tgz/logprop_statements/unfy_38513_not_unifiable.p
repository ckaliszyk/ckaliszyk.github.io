union(image2(B,L),image2(B,P))
restrict(D,J)