difference(intersection(D,F),I)
intersection(F,D)