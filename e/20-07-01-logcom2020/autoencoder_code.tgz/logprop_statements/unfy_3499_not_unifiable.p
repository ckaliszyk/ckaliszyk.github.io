domain(D,D,F)
image4(I,D,J,F)