set_union2(singleton(C),unordered_pair(C,D))
set_difference(F,C)