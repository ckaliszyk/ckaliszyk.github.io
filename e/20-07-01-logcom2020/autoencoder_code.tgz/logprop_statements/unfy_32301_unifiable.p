unordered_pair(D,C)
unordered_pair(C,D)