fof(myForms, conjecture, ! [C] : ! [D] : ((~ empty(C) => ~ empty(set_union2(D,C))) => ~ empty(C))).
fof(myForms, conjecture, ! [C] : ! [D] : ~ empty(C)).