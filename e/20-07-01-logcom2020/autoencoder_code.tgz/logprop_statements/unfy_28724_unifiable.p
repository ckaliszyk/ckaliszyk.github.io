intersection(C,D)
D