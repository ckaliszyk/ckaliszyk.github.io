intersection(I,J)
compose_function(E,B,C,D,C)