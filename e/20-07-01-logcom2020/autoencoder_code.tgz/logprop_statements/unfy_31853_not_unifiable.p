intersection(intersection(C,D),F)
union(D)