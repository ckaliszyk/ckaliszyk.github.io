restrict4(F,D,J,I)
compose_function(B,B,C,C,C)