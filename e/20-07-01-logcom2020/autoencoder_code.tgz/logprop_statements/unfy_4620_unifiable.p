H
domain_of(J)