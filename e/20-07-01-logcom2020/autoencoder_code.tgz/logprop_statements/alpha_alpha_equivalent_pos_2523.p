fof(myForms, conjecture, ! [L] : ! [P] : member(ordered_pair(L,P),universal_class)).
fof(myForms, conjecture, ! [W5] : ! [X5] : member(ordered_pair(W5,X5),universal_class)).