ordered_pair(B,E)
W