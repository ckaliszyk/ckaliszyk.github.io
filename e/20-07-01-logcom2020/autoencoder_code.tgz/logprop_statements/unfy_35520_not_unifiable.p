compose(I,J)
set_union2(C,C)