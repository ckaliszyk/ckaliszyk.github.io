domain_of(D)
inverse2(D,range_of(D))