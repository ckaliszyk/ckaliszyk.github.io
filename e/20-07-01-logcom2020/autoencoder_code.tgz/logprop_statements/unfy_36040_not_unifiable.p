domain_of(J)
intersection(I,J)