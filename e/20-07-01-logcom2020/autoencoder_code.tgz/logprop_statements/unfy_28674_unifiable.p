intersection(C,D)
intersection(I,cross_product(D,F))