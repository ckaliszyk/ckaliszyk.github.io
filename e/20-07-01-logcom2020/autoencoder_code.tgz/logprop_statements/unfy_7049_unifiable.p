difference(D,union(F,I))
C