set_difference(F,D)
G1