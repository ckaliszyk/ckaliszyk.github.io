union(intersection(D,F),intersection(D,I))
ordered_pair(D,C)