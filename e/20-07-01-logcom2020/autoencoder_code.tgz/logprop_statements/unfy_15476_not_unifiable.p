member_of(L)
singleton(F)