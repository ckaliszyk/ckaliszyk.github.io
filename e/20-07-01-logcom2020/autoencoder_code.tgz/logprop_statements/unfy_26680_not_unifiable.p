intersection(D,intersection(F,I))
empty_set