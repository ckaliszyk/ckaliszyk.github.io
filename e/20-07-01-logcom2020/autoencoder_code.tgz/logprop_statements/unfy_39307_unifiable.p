inverse4(D,I,J,F)
B