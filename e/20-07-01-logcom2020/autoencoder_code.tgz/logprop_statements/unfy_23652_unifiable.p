T
cartesian_product2(F,set_difference(C,D))