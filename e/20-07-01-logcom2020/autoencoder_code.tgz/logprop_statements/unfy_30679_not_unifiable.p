cartesian_product2(F,set_union2(C,D))
union(union(intersection(D,F),intersection(F,I)),intersection(I,D))