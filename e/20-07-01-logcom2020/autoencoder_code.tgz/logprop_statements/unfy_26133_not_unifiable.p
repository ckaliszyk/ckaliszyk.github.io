union(C,intersection(D,F))
set_union2(C,F)