set_difference(unordered_pair(C,D),singleton(D))
subset_type(D)