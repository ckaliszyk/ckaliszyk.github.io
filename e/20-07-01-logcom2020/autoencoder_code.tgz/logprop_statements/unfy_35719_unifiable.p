compose_function(E,compose_function(B,X,F,C,D),F,D,F)
F