set_union2(C,C)
N