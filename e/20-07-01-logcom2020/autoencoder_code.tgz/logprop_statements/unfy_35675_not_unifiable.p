member_type(I)
intersection(D,C)