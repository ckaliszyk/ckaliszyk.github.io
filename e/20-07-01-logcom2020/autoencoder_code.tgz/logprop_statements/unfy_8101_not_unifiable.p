power_set(D)
union(I,J)