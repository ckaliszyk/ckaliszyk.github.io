set_union2(powerset(C),powerset(D))
set_difference(F,C)