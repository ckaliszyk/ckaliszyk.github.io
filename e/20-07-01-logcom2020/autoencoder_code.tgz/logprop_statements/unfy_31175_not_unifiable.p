equal_set_predicate
range(D,F,I)