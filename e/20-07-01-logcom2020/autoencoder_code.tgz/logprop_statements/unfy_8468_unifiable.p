domain(F,D,I)
A1