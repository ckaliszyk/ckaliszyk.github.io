set_union2(cartesian_product2(F,singleton(C)),cartesian_product2(F,singleton(D)))
set_union2(C,C)