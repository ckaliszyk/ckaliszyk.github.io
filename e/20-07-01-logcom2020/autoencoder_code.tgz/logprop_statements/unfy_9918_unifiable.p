difference(J,D)
difference(F,I)