G
range_of(J)