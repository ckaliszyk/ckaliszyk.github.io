B
intersection(D,C)