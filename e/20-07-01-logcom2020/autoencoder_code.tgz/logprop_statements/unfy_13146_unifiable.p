cartesian_product2(singleton(C),F)
cartesian_product2(I,singleton(D))