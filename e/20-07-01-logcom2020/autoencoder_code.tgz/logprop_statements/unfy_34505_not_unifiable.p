inverse4(F,D,I,image4(F,D,I,F))
compose_function(B,X,C,D,F)