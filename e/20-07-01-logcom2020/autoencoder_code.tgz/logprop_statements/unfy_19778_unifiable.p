B1
compose_function(B,inverse_function(B,C,D),D,C,D)