ordered_pair(I,B)
union(C,union(D,F))