difference(J,C)
set_difference(C,D)