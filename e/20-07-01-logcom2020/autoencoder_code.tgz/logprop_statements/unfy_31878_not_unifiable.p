intersection(intersection(C,D),F)
union(sum(C),sum(D))