set_difference(unordered_pair(C,D),singleton(D))
set_intersection2(cartesian_product2(F,C),cartesian_product2(F,D))