X
cartesian_product2(D,C)