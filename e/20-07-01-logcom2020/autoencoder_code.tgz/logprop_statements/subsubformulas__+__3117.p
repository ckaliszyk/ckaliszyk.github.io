fof(myForms, conjecture, (ilf_type(G1,set_type) => ! [J1] : (ilf_type(J1,set_type) => ((subset(I,B) & subset(G1,J1)) => subset(cross_product(I,G1),cross_product(B,J1)))))).
fof(myForms, conjecture, ilf_type(G1,set_type)).
fof(myForms, conjecture, ! [J1] : (ilf_type(J1,set_type) => ((subset(I,B) & subset(G1,J1)) => subset(cross_product(I,G1),cross_product(B,J1))))).
fof(myForms, conjecture, (ilf_type(J1,set_type) => ((subset(I,B) & subset(G1,J1)) => subset(cross_product(I,G1),cross_product(B,J1))))).
fof(myForms, conjecture, ilf_type(J1,set_type)).
fof(myForms, conjecture, ((subset(I,B) & subset(G1,J1)) => subset(cross_product(I,G1),cross_product(B,J1)))).
fof(myForms, conjecture, (subset(I,B) & subset(G1,J1))).
fof(myForms, conjecture, subset(I,B)).
fof(myForms, conjecture, subset(G1,J1)).
fof(myForms, conjecture, subset(cross_product(I,G1),cross_product(B,J1))).