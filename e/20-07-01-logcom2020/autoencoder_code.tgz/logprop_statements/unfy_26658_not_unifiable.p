compose5(D,F,I,J,B)
ordered_pair(J,B)