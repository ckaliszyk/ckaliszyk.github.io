unordered_pair(C,C)
set_intersection2(unordered_pair(C,F),D)