power_set(F)
I