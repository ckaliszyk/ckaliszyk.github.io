subset_type(D)
set_intersection2(unordered_pair(C,F),D)