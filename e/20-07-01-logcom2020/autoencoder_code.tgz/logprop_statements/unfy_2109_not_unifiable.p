set_difference(F,C)
difference(J,difference(J,C))