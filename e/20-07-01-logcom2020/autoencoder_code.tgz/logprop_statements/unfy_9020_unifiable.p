inverse(I)
W