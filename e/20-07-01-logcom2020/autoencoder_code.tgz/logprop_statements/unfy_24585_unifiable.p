compose_function(inverse_function(B,C,D),B,C,D,C)
compose_function(X,compose_function(E,B,C,D,F),C,F,C)