difference(F,I)
I1