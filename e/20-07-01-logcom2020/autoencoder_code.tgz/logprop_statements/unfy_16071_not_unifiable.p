set_difference(unordered_pair(C,D),F)
union(difference(J,C),C)