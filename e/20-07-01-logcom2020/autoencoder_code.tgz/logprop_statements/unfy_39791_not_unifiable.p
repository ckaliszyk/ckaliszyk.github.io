singleton(L)
symmetric_difference(symmetric_difference(D,F),I)