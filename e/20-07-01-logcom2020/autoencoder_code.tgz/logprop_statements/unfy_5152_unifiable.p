ordered_pair(I,J)
ordered_pair(D,F)