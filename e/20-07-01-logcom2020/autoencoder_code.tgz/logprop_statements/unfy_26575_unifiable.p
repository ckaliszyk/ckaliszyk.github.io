intersection(difference(J,C),difference(J,D))
P