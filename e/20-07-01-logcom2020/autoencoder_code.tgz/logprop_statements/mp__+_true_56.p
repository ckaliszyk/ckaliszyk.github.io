fof(myForms, conjecture, ! [D] : ((ilf_type(D,set_type) => ~ member(D,empty_set)) & ilf_type(D,set_type))).
fof(myForms, conjecture, ! [D] : ~ member(D,empty_set)).