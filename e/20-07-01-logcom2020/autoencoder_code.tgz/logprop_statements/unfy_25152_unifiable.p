Q
intersection(F,J)