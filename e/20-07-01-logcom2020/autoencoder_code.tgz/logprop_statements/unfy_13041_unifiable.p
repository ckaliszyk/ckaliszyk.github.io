ordered_pair(D,F)
ordered_pair(E,B)