inverse4(D,F,I,F)
N