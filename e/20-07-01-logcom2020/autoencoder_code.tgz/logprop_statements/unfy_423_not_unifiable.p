union(intersection(D,F),intersection(D,I))
cartesian_product2(F,unordered_pair(C,D))