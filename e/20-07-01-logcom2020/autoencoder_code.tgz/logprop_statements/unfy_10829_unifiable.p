cartesian_product2(F,set_intersection2(C,D))
cartesian_product2(set_union2(C,D),F)