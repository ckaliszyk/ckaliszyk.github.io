cartesian_product2(F,set_difference(C,D))
cartesian_product2(I,J)