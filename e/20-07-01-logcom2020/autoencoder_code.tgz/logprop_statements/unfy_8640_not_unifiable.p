ordered_pair(E,X)
difference(J,J)