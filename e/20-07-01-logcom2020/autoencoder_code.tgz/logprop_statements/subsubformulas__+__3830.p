fof(myForms, conjecture, ? [R] : singleton(R)=K1).
fof(myForms, conjecture, singleton(R)=K1).