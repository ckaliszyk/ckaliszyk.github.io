E
set_difference(unordered_pair(C,D),F)