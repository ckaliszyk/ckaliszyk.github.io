set_union2(D,C)
E