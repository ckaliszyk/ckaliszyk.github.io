union(union(D,F),I)
compose_function(inverse_function(B,C,D),B,C,D,C)