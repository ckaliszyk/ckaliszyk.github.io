intersection4(D,F,I,J)
relation_type(F,D)