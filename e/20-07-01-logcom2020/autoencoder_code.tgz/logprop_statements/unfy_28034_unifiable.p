relation_dom(C)
O