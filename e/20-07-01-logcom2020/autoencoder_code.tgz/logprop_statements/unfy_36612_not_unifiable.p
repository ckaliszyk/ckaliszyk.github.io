restrict(J,D)
powerset(set_intersection2(C,D))