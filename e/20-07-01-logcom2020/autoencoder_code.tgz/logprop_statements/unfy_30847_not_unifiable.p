cartesian_product2(F,set_union2(C,D))
difference(empty_set,D)