restrict4(D,F,I,J)
product(L)