unordered_pair(D,F)
A1