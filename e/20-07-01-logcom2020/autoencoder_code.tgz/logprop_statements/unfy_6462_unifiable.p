F
compose_function(B,B,C,C,C)