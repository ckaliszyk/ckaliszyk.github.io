ordered_pair(C,D)
relation_type(F,D)