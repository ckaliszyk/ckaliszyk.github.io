identity_relation_of_type(D)
set_difference(singleton(C),unordered_pair(C,D))