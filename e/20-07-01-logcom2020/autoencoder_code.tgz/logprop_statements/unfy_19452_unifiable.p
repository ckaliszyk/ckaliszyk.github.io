B1
cartesian_product2(set_union2(C,D),F)