compose(D,F)
union(C,D)