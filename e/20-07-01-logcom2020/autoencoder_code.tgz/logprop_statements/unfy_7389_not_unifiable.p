unordered_pair(C,C)
symmetric_difference(symmetric_difference(D,F),I)