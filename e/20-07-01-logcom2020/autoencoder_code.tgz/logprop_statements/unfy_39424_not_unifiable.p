singleton(L)
restrict(J,D)