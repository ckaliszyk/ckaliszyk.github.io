fof(myForms, conjecture, ! [C] : (empty(C) & (empty(C) => empty_set=C))).
fof(myForms, conjecture, ! [C] : empty_set=C).