range_of(I)
difference(intersection(D,F),I)