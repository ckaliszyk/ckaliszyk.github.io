intersection(D,D)
intersection(C,intersection(D,F))