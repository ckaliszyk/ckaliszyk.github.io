I1
set_intersection2(F,J)