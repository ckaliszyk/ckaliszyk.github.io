cartesian_product2(singleton(C),singleton(D))
G