equal_set_predicate
sum(union(C,D))