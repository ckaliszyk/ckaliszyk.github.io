V
cartesian_product2(F,set_intersection2(C,D))