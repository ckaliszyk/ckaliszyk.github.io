difference(D,J)
M