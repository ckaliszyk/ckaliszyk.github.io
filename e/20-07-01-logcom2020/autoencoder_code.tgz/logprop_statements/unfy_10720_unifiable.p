intersection(complement(L),L)
K