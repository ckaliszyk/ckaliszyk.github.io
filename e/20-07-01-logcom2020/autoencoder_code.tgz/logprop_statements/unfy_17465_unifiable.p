union(L,P)
T