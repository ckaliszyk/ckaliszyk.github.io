union(power_set(C),power_set(D))
P