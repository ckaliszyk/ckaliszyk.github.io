cartesian_product2(set_intersection2(D,I),set_intersection2(F,J))
intersection(union(D,F),union(D,I))