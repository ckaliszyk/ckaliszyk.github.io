member_of(L)
set_union2(union(C),union(D))