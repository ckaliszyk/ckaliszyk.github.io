intersection(F,difference(J,F))
compose(identity_relation_of(D),F)