set_difference(F,C)
cartesian_product2(C,D)