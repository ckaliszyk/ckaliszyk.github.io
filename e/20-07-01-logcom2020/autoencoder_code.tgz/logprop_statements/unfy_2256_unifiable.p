L
union(difference(D,F),difference(D,I))