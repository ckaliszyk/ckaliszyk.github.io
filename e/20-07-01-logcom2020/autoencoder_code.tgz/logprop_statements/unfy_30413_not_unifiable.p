cartesian_product2(F,set_union2(C,D))
restrict4(I,D,F,J)