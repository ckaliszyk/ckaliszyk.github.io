power_set(D)
inverse2(I,J)