union(I,J)
union(difference(D,F),difference(F,D))