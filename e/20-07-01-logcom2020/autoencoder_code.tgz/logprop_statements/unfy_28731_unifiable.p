ordered_pair(I,F)
I