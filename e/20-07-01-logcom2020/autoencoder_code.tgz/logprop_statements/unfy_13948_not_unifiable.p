set_intersection2(cartesian_product2(C,F),cartesian_product2(D,I))
difference(intersection(D,F),I)