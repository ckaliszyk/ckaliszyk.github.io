union(sum(C),sum(D))
difference(J,C)