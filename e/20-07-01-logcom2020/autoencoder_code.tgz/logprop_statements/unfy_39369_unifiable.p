union(difference(D,union(F,I)),intersection(intersection(D,F),I))
union(I,J)