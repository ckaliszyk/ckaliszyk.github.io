subset_type(D)
unordered_pair(D,C)