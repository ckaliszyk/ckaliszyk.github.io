union(intersection(D,F),intersection(D,I))
cross_product(domain_of(D),range_of(D))