set_difference(singleton(C),singleton(D))
set_difference(singleton(C),D)