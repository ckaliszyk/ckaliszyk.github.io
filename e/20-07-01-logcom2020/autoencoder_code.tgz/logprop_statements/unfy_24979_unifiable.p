union(set_intersection2(C,D))
Y