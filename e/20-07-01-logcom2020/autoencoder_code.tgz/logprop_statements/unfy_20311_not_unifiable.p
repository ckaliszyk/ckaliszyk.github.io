union(D)
ordered_pair(D,B)