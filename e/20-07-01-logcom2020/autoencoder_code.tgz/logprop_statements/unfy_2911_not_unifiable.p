intersection(C,union(D,F))
cross_product(domain_of(D),range_of(D))