cartesian_product2(singleton(C),unordered_pair(D,F))
unordered_pair(D,F)