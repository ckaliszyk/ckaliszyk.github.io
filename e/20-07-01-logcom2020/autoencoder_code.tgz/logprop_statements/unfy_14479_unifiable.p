relation_dom(F)
V