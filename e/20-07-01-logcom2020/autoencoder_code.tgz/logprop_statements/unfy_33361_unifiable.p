G1
intersection(D,F)