union(union(D,F),I)
unordered_pair(singleton(L),unordered_pair(L,null_class))