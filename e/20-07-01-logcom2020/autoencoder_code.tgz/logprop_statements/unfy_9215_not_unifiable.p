set_difference(F,D)
field_of(I)