difference(D,J)
difference(J,J)