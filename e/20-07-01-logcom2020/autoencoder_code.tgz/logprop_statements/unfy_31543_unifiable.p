S
relation_type(D,I)