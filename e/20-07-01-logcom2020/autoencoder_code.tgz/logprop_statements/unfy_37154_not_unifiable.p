set_union2(set_difference(C,D),set_difference(C,F))
compose_function(X,B,C,D,F)