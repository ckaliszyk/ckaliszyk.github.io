sum(empty_set)
X