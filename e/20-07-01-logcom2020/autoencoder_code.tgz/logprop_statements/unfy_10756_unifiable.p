intersection(complement(L),L)
G1