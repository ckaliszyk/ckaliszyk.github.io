binary_relation_type
difference(J,D)