difference(union(D,F),I)
identity_relation_of(D)