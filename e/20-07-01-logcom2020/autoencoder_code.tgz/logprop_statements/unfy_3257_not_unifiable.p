domain(D,D,F)
domain_of(I)