set_difference(cartesian_product2(C,D),cartesian_product2(F,I))
relation_type(empty_set,F)