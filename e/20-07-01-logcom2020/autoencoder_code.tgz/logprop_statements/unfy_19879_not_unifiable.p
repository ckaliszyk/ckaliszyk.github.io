intersection(C,empty_set)
product(C)