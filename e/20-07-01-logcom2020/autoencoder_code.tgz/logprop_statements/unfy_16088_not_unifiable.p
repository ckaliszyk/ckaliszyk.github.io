set_difference(unordered_pair(C,D),F)
cartesian_product2(D,C)