L
restrict(J,D)