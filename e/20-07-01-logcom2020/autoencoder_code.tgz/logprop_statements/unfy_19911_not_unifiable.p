intersection(C,empty_set)
difference(J,J)