difference(J,intersection(C,D))
powerset(set_intersection2(C,D))