intersection4(D,F,I,J)
cartesian_product2(D,I)