difference(D,union(D,F))
I1