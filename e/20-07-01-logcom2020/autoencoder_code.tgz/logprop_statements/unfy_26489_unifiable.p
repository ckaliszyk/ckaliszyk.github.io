apply(D,I)
T