intersection(D,F)
G1