C
intersection(image3(B,L,D),image3(B,P,D))