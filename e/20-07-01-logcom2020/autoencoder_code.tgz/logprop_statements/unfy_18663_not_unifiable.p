restrict4(D,I,J,F)
relation_dom(I)