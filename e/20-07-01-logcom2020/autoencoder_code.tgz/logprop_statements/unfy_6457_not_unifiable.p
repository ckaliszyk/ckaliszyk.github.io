intersection(F,J)
union(intersection(C,D),F)