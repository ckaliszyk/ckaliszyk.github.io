ordered_pair(I,B)
set_difference(cartesian_product2(C,F),cartesian_product2(D,F))