cartesian_product2(singleton(D),I)
cartesian_product2(I,J)