intersection(union(D,I),F)
B1