unordered_pair(C,C)
unordered_pair(L,singleton(P))