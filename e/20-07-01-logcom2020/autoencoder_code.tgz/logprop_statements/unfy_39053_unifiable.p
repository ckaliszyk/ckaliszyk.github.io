union(C,D)
Y