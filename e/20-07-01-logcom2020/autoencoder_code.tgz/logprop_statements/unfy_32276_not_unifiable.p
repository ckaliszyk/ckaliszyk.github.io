difference(D,union(F,I))
unordered_pair(C,F)