fof(myForms, conjecture, (order(N1,J1) & least(Q,N1,J1))).
fof(myForms, conjecture, order(N1,J1)).
fof(myForms, conjecture, least(Q,N1,J1)).