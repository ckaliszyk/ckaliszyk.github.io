union(D,F)
D