field_of(D)
cartesian_product2(D,I)