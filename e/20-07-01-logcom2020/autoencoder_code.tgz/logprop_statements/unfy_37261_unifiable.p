J
unordered_pair(ordered_pair(C,D),ordered_pair(C,F))