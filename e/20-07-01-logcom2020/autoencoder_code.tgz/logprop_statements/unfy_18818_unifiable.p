intersection(difference(D,F),F)
E