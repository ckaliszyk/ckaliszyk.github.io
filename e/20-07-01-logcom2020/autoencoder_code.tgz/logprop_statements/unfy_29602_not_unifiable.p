ordered_pair(B,E)
compose_function(B,compose_function(X,E,D,F,C),D,C,D)