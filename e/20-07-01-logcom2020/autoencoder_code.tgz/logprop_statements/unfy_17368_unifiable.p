difference(D,D)
difference(union(D,F),I)