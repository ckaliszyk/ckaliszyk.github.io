B1
set_union2(cartesian_product2(set_difference(C,F),D),cartesian_product2(C,set_difference(D,I)))