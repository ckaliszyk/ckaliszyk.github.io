J
set_intersection2(singleton(C),singleton(D))