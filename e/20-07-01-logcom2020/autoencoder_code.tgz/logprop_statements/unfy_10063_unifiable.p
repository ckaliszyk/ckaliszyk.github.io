cross_product(F,J)
V