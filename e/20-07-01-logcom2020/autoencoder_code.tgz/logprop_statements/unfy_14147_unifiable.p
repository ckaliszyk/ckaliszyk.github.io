set_union2(singleton(C),D)
P