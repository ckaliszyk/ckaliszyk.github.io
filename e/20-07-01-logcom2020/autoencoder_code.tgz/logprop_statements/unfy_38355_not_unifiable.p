intersection4(D,F,I,J)
compose_function(inverse_function(B,C,D),inverse_function(E,D,F),F,D,C)