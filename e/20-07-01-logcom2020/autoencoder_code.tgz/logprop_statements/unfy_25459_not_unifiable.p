intersection(F,difference(J,F))
difference(J,union(C,D))