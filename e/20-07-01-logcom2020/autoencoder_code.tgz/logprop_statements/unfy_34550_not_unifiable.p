inverse4(F,D,I,image4(F,D,I,F))
set_union2(C,F)