F
union(intersection(C,D),intersection(C,F))