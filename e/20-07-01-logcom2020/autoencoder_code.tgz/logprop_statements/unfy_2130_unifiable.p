L
intersection(difference(D,F),difference(D,I))