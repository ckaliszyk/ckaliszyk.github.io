empty_set
compose_function(inverse_function(B,C,D),inverse_function(E,D,F),F,D,C)