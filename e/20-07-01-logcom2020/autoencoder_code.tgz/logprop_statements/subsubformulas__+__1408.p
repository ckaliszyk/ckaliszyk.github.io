fof(myForms, conjecture, (subset(difference(I,B),G1) & subset(difference(B,I),G1))).
fof(myForms, conjecture, subset(difference(I,B),G1)).
fof(myForms, conjecture, subset(difference(B,I),G1)).