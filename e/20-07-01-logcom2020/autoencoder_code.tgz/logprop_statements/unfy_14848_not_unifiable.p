symmetric_difference(D,D)
compose_function(E,A1,C,D,C)