intersection(F,J)
unordered_pair(C,F)