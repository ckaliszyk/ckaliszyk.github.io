difference(F,D)
compose_function(B,X,D,C,D)