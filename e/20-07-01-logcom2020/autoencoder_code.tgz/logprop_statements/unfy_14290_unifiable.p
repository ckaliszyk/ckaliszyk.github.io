set_union2(unordered_pair(C,F),D)
W