fof(myForms, conjecture, (~ member(K1,universal_class) & ~ member(R,universal_class))).
fof(myForms, conjecture, ~ member(K1,universal_class)).
fof(myForms, conjecture, member(K1,universal_class)).
fof(myForms, conjecture, ~ member(R,universal_class)).
fof(myForms, conjecture, member(R,universal_class)).