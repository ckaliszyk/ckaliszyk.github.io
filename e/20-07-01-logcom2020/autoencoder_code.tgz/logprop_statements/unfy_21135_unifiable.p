compose_function(E,B,C,D,C)
compose_function(B,E,C,D,F)