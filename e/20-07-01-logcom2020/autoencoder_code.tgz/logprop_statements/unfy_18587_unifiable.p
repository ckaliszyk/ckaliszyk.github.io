union(D,difference(F,D))
union(H1,I1)