B
intersection(intersection(union(D,F),union(F,I)),union(I,D))