P
cross_product(D,D)