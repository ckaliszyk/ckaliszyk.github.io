fof(myForms, conjecture, ! [B] : ! [N1] : ! [P] : ! [K] : ((((maps(D,F,I) & maps(J,I,B)) & decreasing(D,F,N1,I,P)) & decreasing(J,I,P,B,K)) => increasing(compose_function(J,D,F,I,B),F,N1,B,K))).
fof(myForms, conjecture, ! [N1] : ! [P] : ! [K] : ((((maps(D,F,I) & maps(J,I,B)) & decreasing(D,F,N1,I,P)) & decreasing(J,I,P,B,K)) => increasing(compose_function(J,D,F,I,B),F,N1,B,K))).
fof(myForms, conjecture, ! [P] : ! [K] : ((((maps(D,F,I) & maps(J,I,B)) & decreasing(D,F,N1,I,P)) & decreasing(J,I,P,B,K)) => increasing(compose_function(J,D,F,I,B),F,N1,B,K))).
fof(myForms, conjecture, ! [K] : ((((maps(D,F,I) & maps(J,I,B)) & decreasing(D,F,N1,I,P)) & decreasing(J,I,P,B,K)) => increasing(compose_function(J,D,F,I,B),F,N1,B,K))).
fof(myForms, conjecture, ((((maps(D,F,I) & maps(J,I,B)) & decreasing(D,F,N1,I,P)) & decreasing(J,I,P,B,K)) => increasing(compose_function(J,D,F,I,B),F,N1,B,K))).
fof(myForms, conjecture, (((maps(D,F,I) & maps(J,I,B)) & decreasing(D,F,N1,I,P)) & decreasing(J,I,P,B,K))).
fof(myForms, conjecture, ((maps(D,F,I) & maps(J,I,B)) & decreasing(D,F,N1,I,P))).
fof(myForms, conjecture, (maps(D,F,I) & maps(J,I,B))).
fof(myForms, conjecture, maps(D,F,I)).
fof(myForms, conjecture, maps(J,I,B)).
fof(myForms, conjecture, decreasing(D,F,N1,I,P)).
fof(myForms, conjecture, decreasing(J,I,P,B,K)).
fof(myForms, conjecture, increasing(compose_function(J,D,F,I,B),F,N1,B,K)).