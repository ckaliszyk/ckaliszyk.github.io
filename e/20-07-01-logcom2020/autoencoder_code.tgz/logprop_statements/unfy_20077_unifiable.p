D1
restrict4(F,D,J,I)