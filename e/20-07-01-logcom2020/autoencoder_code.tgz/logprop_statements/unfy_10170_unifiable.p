intersection(union(D,I),F)
C1