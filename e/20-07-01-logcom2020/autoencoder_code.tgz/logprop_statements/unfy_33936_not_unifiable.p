field_of(D)
singleton(apply(D,C))