G1
singleton(ordered_pair(I,J))