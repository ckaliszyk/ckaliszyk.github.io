field_of(D)
set_union2(C,F)