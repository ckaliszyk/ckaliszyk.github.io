restrict4(I,D,F,J)
ordered_pair(E,X)