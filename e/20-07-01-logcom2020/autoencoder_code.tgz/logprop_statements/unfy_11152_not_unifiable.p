difference(F,D)
power_set(D)