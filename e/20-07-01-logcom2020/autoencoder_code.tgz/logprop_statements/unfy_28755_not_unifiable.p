apply(C,F)
union(set_union2(C,D))