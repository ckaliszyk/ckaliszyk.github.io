fof(myForms, conjecture, ! [D] : ! [F] : (subset(D,F) <=> ! [I] : ((member(I,D) => member(I,F)) => member(I,D)))).
fof(myForms, conjecture, ! [D] : ! [F] : (subset(D,F) <=> ! [I] : member(I,F))).