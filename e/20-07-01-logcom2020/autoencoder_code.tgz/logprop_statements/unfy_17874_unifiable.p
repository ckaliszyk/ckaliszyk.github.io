O
union(C,empty_set)