set_intersection2(F,J)
union(C,intersection(D,F))