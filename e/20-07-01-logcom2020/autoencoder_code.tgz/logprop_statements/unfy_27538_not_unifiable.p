cartesian_product2(set_intersection2(D,I),set_intersection2(F,J))
compose_function(E,B,D,C,D)