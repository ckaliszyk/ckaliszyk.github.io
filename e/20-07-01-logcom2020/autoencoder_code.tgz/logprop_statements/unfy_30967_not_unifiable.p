equal_set_predicate
difference(J,D)