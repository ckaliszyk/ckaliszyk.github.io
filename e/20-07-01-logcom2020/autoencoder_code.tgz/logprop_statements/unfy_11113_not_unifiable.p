ordered_pair(C,D)
union(difference(D,union(F,I)),intersection(intersection(D,F),I))