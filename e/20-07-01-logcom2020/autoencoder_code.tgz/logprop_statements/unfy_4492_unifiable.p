union(D,F)
union(C,D)