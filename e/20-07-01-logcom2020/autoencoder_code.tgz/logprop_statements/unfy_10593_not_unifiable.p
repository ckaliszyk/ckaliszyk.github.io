difference(intersection(D,F),I)
relation_composition(D,C)