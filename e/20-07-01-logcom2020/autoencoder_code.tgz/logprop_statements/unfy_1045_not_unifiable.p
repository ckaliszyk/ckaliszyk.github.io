ordered_pair(B,J)
intersection(union(C,D),union(C,F))