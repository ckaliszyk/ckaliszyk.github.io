fof(myForms, conjecture, (subset(I,B) => intersection(I,B)=I)).
fof(myForms, conjecture, subset(I,B)).
fof(myForms, conjecture, intersection(I,B)=I).