H
relation_dom(C)