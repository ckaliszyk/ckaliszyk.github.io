domain_of(F)
ordered_pair(Q,L)