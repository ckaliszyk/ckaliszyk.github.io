difference(J,C)
cartesian_product2(singleton(C),unordered_pair(D,F))