B
restrict4(F,D,J,I)