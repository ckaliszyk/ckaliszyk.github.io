ordered_pair(B,E)
domain_of(D)