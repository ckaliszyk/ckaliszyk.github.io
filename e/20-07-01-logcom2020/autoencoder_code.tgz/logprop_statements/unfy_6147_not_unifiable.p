intersection(F,J)
cartesian_product2(I,F)