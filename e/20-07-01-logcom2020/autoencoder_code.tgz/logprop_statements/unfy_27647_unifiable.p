M
compose_function(E,B,C,D,C)