apply(C,F)
intersection(D,I)