union(singleton(C))
union(C,D)