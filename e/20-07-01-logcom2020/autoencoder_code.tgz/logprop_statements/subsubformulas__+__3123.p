fof(myForms, conjecture, (((subset(F,I) & subset(I,B)) & subset(B,F)) => equal_set(F,B))).
fof(myForms, conjecture, ((subset(F,I) & subset(I,B)) & subset(B,F))).
fof(myForms, conjecture, (subset(F,I) & subset(I,B))).
fof(myForms, conjecture, subset(F,I)).
fof(myForms, conjecture, subset(I,B)).
fof(myForms, conjecture, subset(B,F)).
fof(myForms, conjecture, equal_set(F,B)).