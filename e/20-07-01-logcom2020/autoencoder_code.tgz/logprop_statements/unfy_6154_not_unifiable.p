intersection(F,J)
union(difference(J,C),difference(J,D))