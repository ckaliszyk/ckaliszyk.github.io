difference(D,D)
difference(J,union(C,D))