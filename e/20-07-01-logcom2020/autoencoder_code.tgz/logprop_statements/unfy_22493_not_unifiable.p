union(D,F)
difference(J,C)