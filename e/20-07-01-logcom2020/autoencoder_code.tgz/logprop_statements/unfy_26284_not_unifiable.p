compose5(D,F,I,J,B)
powerset(set_intersection2(C,D))