union(set_intersection2(C,D))
T