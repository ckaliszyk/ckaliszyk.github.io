unordered_pair(singleton(M),unordered_pair(M,N))
compose_function(E,B1,C,D,C)