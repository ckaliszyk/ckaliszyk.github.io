D1
intersection(union(D,I),F)