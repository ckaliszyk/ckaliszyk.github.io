equal_set_predicate
union(inverse_image2(B,L),inverse_image2(B,P))