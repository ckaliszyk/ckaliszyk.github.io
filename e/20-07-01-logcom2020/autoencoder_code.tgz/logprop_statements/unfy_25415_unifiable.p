Q
cartesian_product2(I,singleton(D))