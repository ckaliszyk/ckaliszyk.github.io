C1
intersection(C,difference(J,D))