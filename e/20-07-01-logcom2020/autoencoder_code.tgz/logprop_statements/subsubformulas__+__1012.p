fof(myForms, conjecture, (relation_like(I) <=> ! [B] : (ilf_type(B,set_type) => (member(B,I) => ? [G1] : (ilf_type(G1,set_type) & ? [J1] : (ilf_type(J1,set_type) & ordered_pair(G1,J1)=B)))))).
fof(myForms, conjecture, relation_like(I)).
fof(myForms, conjecture, ! [B] : (ilf_type(B,set_type) => (member(B,I) => ? [G1] : (ilf_type(G1,set_type) & ? [J1] : (ilf_type(J1,set_type) & ordered_pair(G1,J1)=B))))).
fof(myForms, conjecture, (ilf_type(B,set_type) => (member(B,I) => ? [G1] : (ilf_type(G1,set_type) & ? [J1] : (ilf_type(J1,set_type) & ordered_pair(G1,J1)=B))))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, (member(B,I) => ? [G1] : (ilf_type(G1,set_type) & ? [J1] : (ilf_type(J1,set_type) & ordered_pair(G1,J1)=B)))).
fof(myForms, conjecture, member(B,I)).
fof(myForms, conjecture, ? [G1] : (ilf_type(G1,set_type) & ? [J1] : (ilf_type(J1,set_type) & ordered_pair(G1,J1)=B))).
fof(myForms, conjecture, (ilf_type(G1,set_type) & ? [J1] : (ilf_type(J1,set_type) & ordered_pair(G1,J1)=B))).
fof(myForms, conjecture, ilf_type(G1,set_type)).
fof(myForms, conjecture, ? [J1] : (ilf_type(J1,set_type) & ordered_pair(G1,J1)=B)).
fof(myForms, conjecture, (ilf_type(J1,set_type) & ordered_pair(G1,J1)=B)).
fof(myForms, conjecture, ilf_type(J1,set_type)).
fof(myForms, conjecture, ordered_pair(G1,J1)=B).