cartesian_product2(C,singleton(D))
O