unordered_pair(singleton(M),unordered_pair(M,N))
inverse_function(compose_function(E,B,C,D,F),C,F)