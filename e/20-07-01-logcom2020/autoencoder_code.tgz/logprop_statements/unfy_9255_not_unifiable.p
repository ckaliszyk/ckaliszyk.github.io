set_difference(F,D)
inverse4(D,I,J,F)