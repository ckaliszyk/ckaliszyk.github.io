empty_set
intersection(inverse_image3(B,L,C),inverse_image3(B,P,C))