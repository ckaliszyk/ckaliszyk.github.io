apply(C,F)
ordered_pair(I,F)