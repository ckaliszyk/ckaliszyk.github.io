fof(myForms, conjecture, ! [D] : ! [F] : ((intersect(D,F) => intersect(F,D)) => intersect(D,F))).
fof(myForms, conjecture, ! [D] : ! [F] : intersect(F,D)).