difference(J,intersection(C,D))
subset_type(D)