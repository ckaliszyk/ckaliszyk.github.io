intersection(C,difference(J,D))
C1