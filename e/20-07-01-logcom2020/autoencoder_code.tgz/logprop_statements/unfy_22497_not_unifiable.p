union(D,F)
restrict4(F,D,J,I)