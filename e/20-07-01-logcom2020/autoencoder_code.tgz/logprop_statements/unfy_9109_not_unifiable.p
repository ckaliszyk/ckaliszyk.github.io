set_difference(F,D)
union(union(intersection(D,F),intersection(F,I)),intersection(I,D))