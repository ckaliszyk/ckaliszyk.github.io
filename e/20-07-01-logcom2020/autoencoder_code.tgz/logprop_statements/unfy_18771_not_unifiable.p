difference(union(D,F),I)
set_union2(set_difference(C,D),set_difference(C,F))