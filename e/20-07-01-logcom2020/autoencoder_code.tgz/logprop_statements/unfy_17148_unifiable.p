N
inverse(D)