unordered_pair(L,K)
O