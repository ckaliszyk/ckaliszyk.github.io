S
set_difference(singleton(C),D)