V
union(singleton(C))