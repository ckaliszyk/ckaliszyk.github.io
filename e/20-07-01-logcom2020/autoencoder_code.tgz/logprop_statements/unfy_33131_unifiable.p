set_difference(D,singleton(F))
set_difference(F,D)