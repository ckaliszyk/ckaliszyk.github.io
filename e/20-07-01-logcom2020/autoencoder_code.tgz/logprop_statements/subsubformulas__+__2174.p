fof(myForms, conjecture, ! [B] : (ilf_type(B,binary_relation_type) => (subset(range_of(B),I) => ilf_type(B,relation_type(domain_of(B),I))))).
fof(myForms, conjecture, (ilf_type(B,binary_relation_type) => (subset(range_of(B),I) => ilf_type(B,relation_type(domain_of(B),I))))).
fof(myForms, conjecture, ilf_type(B,binary_relation_type)).
fof(myForms, conjecture, (subset(range_of(B),I) => ilf_type(B,relation_type(domain_of(B),I)))).
fof(myForms, conjecture, subset(range_of(B),I)).
fof(myForms, conjecture, ilf_type(B,relation_type(domain_of(B),I))).