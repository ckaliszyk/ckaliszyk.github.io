O
range(D,F,J)