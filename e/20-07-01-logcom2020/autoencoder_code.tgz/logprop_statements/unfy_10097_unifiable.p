cross_product(F,J)
E1