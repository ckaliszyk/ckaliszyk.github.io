cartesian_product2(set_union2(C,D),set_union2(F,I))
restrict(D,F)