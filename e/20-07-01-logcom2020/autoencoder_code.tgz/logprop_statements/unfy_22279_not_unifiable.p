domain_of(I)
identity_relation_of(F)