X
range(F,D,inverse3(D,F,I))