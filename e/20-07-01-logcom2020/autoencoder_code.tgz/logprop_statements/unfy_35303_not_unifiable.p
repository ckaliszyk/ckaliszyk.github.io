compose(I,J)
relation_type(empty_set,F)