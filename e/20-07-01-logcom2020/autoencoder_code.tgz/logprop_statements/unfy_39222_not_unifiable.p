union(difference(D,F),difference(C,D))
inverse2(D,range_of(D))