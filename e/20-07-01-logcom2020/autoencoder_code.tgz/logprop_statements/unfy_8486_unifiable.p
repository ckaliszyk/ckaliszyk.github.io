domain(F,D,I)
G