set_intersection2(D,F)
identity_relation_of_type(D)