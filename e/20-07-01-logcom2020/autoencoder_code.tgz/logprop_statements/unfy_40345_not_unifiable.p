singleton(M)
set_intersection2(cartesian_product2(D,F),cartesian_product2(I,J))