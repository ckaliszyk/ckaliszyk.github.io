set_union2(set_difference(C,D),set_difference(C,F))
union(I,J)