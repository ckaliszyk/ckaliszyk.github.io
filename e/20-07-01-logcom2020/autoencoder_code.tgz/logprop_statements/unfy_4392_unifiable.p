domain_of(I)
Z