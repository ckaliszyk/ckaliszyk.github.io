unordered_pair(C,C)
relation_dom(D)