domain_of(D)
cross_product(domain_of(D),range_of(D))