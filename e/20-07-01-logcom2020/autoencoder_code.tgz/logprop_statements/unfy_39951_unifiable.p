ordered_pair(J,B)
ordered_pair(L,P)