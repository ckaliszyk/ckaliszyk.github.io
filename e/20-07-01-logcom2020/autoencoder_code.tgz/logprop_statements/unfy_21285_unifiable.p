G
image2(B,P)