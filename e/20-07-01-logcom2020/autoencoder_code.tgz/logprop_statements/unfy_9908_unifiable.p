difference(J,D)
I1