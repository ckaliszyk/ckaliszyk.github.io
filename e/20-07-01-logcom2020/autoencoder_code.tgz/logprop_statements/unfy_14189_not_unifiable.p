set_intersection2(cartesian_product2(C,F),cartesian_product2(D,I))
set_union2(union(C),union(D))