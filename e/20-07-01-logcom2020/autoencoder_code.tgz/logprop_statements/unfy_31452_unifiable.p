S
domain(F,D,inverse3(D,F,I))