domain_of(D)
set_union2(cartesian_product2(F,C),cartesian_product2(F,D))