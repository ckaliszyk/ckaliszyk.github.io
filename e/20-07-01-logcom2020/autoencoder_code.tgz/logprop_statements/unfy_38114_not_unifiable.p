intersection4(D,F,I,J)
power_set(union(C,D))