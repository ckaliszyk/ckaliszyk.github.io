singleton(L)
difference(D,empty_set)