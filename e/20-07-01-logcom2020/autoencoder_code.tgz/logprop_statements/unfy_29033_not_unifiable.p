ordered_pair(I,D)
difference(union(D,F),I)