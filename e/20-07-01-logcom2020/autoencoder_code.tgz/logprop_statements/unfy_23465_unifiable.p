T
intersection(union(C,D),union(C,F))