domain_of(J)
difference(D,D)