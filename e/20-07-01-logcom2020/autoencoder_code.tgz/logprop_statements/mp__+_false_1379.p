fof(myForms, conjecture, ! [D] : ((ilf_type(D,set_type) => (~ empty(power_set(D)) & ilf_type(power_set(D),set_type))) => ilf_type(D,set_type))).
fof(myForms, conjecture, ! [D] : ilf_type(D,set_type)).