powerset(F)
E