E
set_intersection2(F,J)