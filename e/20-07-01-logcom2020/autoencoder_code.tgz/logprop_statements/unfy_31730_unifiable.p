I1
ordered_pair(B,J)