difference(J,C)
relation_dom(C)