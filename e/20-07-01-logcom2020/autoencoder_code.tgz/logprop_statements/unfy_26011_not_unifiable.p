union(C,intersection(D,F))
image4(I,D,J,F)