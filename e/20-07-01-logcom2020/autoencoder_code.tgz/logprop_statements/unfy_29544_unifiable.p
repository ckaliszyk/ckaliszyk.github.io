union(D,C)
I