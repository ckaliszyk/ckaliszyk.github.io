fof(myForms, conjecture, ! [C] : ! [D] : ~ (((empty(C) & ~ D=C) & empty(D)))).
fof(myForms, conjecture, ! [D] : (ilf_type(D,binary_relation_type) => ilf_type(range_of(D),set_type))).