field_of(D)
set_union2(powerset(set_difference(C,D)),powerset(set_difference(D,C)))