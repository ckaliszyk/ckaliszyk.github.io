binary_relation_type
singleton(apply(D,C))