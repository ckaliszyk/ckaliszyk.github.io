union(D)
apply(C,D)