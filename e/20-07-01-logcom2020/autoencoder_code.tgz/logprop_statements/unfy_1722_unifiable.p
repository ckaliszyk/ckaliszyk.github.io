intersection(F,J)
V