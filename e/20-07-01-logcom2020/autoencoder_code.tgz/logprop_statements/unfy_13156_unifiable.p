cartesian_product2(singleton(C),F)
E