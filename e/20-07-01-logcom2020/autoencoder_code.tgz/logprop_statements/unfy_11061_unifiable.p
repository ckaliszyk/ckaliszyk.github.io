set_union2(C,set_union2(D,F))
E1