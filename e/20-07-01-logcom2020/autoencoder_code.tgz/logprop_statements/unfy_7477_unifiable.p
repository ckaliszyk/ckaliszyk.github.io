V
product(L)