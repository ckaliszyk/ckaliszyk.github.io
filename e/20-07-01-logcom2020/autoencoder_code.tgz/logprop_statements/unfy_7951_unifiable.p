restrict(J,D)
V