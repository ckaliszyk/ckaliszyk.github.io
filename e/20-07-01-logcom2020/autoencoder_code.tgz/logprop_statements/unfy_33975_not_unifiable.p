field_of(D)
range(D,F,I)