fof(myForms, conjecture, ! [C] : (member(C,on) & (member(C,on) => equal_set(C,intersection(C,power_set(C)))))).
fof(myForms, conjecture, ! [C] : equal_set(C,intersection(C,power_set(C)))).