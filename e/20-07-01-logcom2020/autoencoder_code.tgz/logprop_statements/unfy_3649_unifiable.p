X
unordered_pair(ordered_pair(C,F),ordered_pair(D,F))