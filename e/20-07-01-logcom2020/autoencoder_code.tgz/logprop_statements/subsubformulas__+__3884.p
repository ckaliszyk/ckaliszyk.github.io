fof(myForms, conjecture, (((maps(H1,F,I) & maps(O1,F,I)) & maps(J,I,F)) & identity(compose_function(J,H1,F,I,F),F))).
fof(myForms, conjecture, ((maps(H1,F,I) & maps(O1,F,I)) & maps(J,I,F))).
fof(myForms, conjecture, (maps(H1,F,I) & maps(O1,F,I))).
fof(myForms, conjecture, maps(H1,F,I)).
fof(myForms, conjecture, maps(O1,F,I)).
fof(myForms, conjecture, maps(J,I,F)).
fof(myForms, conjecture, identity(compose_function(J,H1,F,I,F),F)).