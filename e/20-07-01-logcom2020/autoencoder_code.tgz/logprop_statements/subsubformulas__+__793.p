fof(myForms, conjecture, (in(G1,B) <=> ? [J1] : ? [D] : ((in(J1,F) & in(D,I)) & ordered_pair(J1,D)=G1))).
fof(myForms, conjecture, in(G1,B)).
fof(myForms, conjecture, ? [J1] : ? [D] : ((in(J1,F) & in(D,I)) & ordered_pair(J1,D)=G1)).
fof(myForms, conjecture, ? [D] : ((in(J1,F) & in(D,I)) & ordered_pair(J1,D)=G1)).
fof(myForms, conjecture, ((in(J1,F) & in(D,I)) & ordered_pair(J1,D)=G1)).
fof(myForms, conjecture, (in(J1,F) & in(D,I))).
fof(myForms, conjecture, in(J1,F)).
fof(myForms, conjecture, in(D,I)).
fof(myForms, conjecture, ordered_pair(J1,D)=G1).