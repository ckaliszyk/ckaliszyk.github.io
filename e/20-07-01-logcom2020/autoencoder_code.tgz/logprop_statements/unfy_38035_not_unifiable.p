intersection4(D,F,I,J)
apply(F,I)