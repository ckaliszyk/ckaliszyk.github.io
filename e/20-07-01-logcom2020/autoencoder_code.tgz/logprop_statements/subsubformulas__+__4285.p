fof(myForms, conjecture, (singleton(F)=set_difference(singleton(F),singleton(I)) <=> ~ I=F)).
fof(myForms, conjecture, singleton(F)=set_difference(singleton(F),singleton(I))).
fof(myForms, conjecture, ~ I=F).
fof(myForms, conjecture, I=F).