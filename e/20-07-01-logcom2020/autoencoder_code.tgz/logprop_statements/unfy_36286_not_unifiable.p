domain_of(J)
compose_function(E,B,C,D,C)