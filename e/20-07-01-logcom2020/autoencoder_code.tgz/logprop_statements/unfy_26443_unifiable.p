difference(D,union(D,F))
Q