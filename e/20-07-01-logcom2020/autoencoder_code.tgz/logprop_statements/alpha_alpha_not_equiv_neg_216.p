fof(myForms, conjecture, ! [J] : equal_set(difference(J,J),empty_set)).
fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => (empty(D) <=> ! [F] : (ilf_type(F,set_type) => ~ member(F,D))))).