set_intersection2(D,F)
intersection(C,intersection(D,F))