fof(myForms, conjecture, ! [D] : ! [F] : (subset(D,F) <=> ! [I] : (member(I,D) & (member(I,D) => member(I,F))))).
fof(myForms, conjecture, ! [D] : ! [F] : (subset(D,F) <=> ! [I] : member(I,F))).