intersection4(D,F,I,J)
universal_class