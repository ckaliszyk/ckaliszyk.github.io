A1
image4(F,D,I,inverse4(F,D,I,D))