R
unordered_pair(C,F)