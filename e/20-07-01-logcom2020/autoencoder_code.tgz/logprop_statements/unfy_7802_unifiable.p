relation_type(D,D)
N