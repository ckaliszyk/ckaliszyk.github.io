ordered_pair(B,E)
unordered_pair(empty_set,singleton(C))