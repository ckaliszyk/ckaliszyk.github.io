set_intersection2(singleton(C),unordered_pair(C,D))
K