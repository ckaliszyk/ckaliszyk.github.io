T
set_intersection2(D,I)