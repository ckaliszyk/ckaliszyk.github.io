union(difference(D,union(F,I)),difference(F,union(D,I)))
union(D,C)