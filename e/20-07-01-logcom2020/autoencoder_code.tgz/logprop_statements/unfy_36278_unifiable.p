relation_type(D,I)
S