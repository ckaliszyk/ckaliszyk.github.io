D
cartesian_product2(unordered_pair(C,D),F)