restrict4(D,I,J,F)
set_difference(singleton(C),unordered_pair(C,D))