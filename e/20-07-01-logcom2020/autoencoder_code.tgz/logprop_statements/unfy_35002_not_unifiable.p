relation_type(D,D)
cross_product(I,F)