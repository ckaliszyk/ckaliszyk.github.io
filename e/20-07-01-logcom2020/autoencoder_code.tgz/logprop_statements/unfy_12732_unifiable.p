intersection(D,union(F,I))
J