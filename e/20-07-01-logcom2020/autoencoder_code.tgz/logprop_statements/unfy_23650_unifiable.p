T
powerset(D)