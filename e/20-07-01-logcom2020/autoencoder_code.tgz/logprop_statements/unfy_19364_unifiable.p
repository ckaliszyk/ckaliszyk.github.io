Y
union(C,union(D,F))