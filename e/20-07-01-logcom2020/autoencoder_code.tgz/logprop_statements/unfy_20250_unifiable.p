D1
union(D,intersection(F,I))