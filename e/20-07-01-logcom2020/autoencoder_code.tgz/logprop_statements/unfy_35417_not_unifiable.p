compose(I,J)
union(H1,I1)