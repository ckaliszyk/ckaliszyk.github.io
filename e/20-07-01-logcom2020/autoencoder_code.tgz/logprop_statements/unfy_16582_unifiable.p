image(D,F)
T