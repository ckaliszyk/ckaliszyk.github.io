fof(myForms, conjecture, ! [B] : ! [G1] : (intersection(B,G1)=I <=> ((subset(I,B) & subset(I,G1)) & ! [J1] : ((subset(J1,B) & subset(J1,G1)) => subset(J1,I))))).
fof(myForms, conjecture, ! [G1] : (intersection(B,G1)=I <=> ((subset(I,B) & subset(I,G1)) & ! [J1] : ((subset(J1,B) & subset(J1,G1)) => subset(J1,I))))).
fof(myForms, conjecture, (intersection(B,G1)=I <=> ((subset(I,B) & subset(I,G1)) & ! [J1] : ((subset(J1,B) & subset(J1,G1)) => subset(J1,I))))).
fof(myForms, conjecture, intersection(B,G1)=I).
fof(myForms, conjecture, ((subset(I,B) & subset(I,G1)) & ! [J1] : ((subset(J1,B) & subset(J1,G1)) => subset(J1,I)))).
fof(myForms, conjecture, (subset(I,B) & subset(I,G1))).
fof(myForms, conjecture, subset(I,B)).
fof(myForms, conjecture, subset(I,G1)).
fof(myForms, conjecture, ! [J1] : ((subset(J1,B) & subset(J1,G1)) => subset(J1,I))).
fof(myForms, conjecture, ((subset(J1,B) & subset(J1,G1)) => subset(J1,I))).
fof(myForms, conjecture, (subset(J1,B) & subset(J1,G1))).
fof(myForms, conjecture, subset(J1,B)).
fof(myForms, conjecture, subset(J1,G1)).
fof(myForms, conjecture, subset(J1,I)).