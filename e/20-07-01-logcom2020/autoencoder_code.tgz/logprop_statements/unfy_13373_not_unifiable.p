difference(J,C)
set_union2(D,F)