intersection(D,empty_set)
W