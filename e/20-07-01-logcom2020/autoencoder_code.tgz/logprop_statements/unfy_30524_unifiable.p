set_difference(set_union2(C,D),D)
X