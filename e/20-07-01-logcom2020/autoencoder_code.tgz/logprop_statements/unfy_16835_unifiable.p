N
union(sum(C),sum(D))