singleton(L)
relation_dom(D)