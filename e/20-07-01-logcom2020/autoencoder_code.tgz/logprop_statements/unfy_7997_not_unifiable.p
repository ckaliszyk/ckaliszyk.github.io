power_set(D)
intersection(D,C)