set_intersection2(cartesian_product2(C,I),cartesian_product2(D,F))
J