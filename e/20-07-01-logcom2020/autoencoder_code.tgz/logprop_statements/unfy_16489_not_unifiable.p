set_difference(cartesian_product2(C,D),cartesian_product2(F,I))
restrict(I,J)