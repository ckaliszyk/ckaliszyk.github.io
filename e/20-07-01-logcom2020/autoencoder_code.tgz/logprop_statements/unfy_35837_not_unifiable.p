member_type(I)
difference(I,F)