set_difference(D,singleton(F))
E1