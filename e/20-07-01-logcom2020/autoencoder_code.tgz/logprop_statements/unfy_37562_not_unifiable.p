intersection(intersection(D,F),I)
ordered_pair(D,C)