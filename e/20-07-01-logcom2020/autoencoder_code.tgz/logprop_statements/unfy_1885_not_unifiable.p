set_difference(F,C)
ordered_pair(B,E)