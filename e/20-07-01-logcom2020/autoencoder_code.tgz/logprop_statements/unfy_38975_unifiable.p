union(intersection(C,D),F)
P