identity_relation_of_type(D)
image4(D,F,I,J)