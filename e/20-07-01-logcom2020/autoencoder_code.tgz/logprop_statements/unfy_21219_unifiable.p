G
difference(J,C)