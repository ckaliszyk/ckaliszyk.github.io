empty_set
intersection(C,difference(J,D))