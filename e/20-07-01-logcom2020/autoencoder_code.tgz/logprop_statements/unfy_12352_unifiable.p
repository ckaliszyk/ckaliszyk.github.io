P
initial_segment(L,member_predicate,C)