H1
restrict4(D,I,J,F)