set_difference(unordered_pair(C,D),singleton(D))
ordered_pair(J,B)