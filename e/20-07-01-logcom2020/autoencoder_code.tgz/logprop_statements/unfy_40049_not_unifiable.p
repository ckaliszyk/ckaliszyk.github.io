identity_relation_of_type(D)
ordered_pair(E,G1)