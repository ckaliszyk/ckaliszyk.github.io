W
intersection(union(D,I),F)