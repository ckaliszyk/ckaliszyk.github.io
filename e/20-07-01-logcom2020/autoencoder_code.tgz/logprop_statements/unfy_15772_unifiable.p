difference(union(D,F),intersection(D,F))
D1