intersection(power_set(C),power_set(D))
B