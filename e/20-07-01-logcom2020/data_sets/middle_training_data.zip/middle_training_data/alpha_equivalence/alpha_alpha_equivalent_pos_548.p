fof(myForms, conjecture, ! [J1] : (ilf_type(J1,set_type) => subset(J1,J1))).
fof(myForms, conjecture, ! [T7] : (ilf_type(T7,set_type) => subset(T7,T7))).