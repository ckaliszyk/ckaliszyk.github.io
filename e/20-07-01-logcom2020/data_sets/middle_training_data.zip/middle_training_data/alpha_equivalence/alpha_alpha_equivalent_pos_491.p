fof(myForms, conjecture, ! [N5] : (subset(N5,cartesian_product2(N5,N5)) => empty_set=N5)).
fof(myForms, conjecture, ! [M9] : (subset(M9,cartesian_product2(M9,M9)) => empty_set=M9)).