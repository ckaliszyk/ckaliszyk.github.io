fof(myForms, conjecture, ! [C] : ! [D] : subset(C,C)).
fof(myForms, conjecture, ! [M1] : ! [N1] : subset(M1,M1)).