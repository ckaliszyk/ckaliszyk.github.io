fof(myForms, conjecture, ! [D] : ! [F] : union(intersection(D,F),difference(D,F))=D).
fof(myForms, conjecture, ! [E3] : ! [F3] : union(intersection(E3,F3),difference(E3,F3))=E3).