fof(myForms, conjecture, ? [L] : ! [K] : ~ member(K,L)).
fof(myForms, conjecture, ? [A6] : ! [B6] : ~ member(B6,A6)).