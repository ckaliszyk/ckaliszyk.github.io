fof(myForms, conjecture, ! [D] : ((empty(D) & ilf_type(D,set_type)) => relation_like(D))).
fof(myForms, conjecture, ! [L6] : ((empty(L6) & ilf_type(L6,set_type)) => relation_like(L6))).