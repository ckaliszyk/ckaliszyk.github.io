fof(myForms, conjecture, ? [Q4] : empty(Q4)).
fof(myForms, conjecture, ? [C4] : empty(C4)).