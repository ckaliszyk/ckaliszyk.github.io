fof(myForms, conjecture, ! [D] : ilf_type(D,set_type)).
fof(myForms, conjecture, ! [I5] : ilf_type(I5,set_type)).