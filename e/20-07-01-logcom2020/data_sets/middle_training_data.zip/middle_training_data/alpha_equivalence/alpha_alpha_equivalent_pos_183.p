fof(myForms, conjecture, ? [D] : ilf_type(D,binary_relation_type)).
fof(myForms, conjecture, ? [S2] : ilf_type(S2,binary_relation_type)).