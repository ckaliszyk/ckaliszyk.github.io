fof(myForms, conjecture, ! [C] : ! [D] : set_intersection2(C,C)=C).
fof(myForms, conjecture, ! [W8] : ! [X8] : set_intersection2(W8,W8)=W8).