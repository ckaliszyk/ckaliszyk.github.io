fof(myForms, conjecture, ! [D] : subset(D,D)).
fof(myForms, conjecture, ! [Z1] : subset(Z1,Z1)).