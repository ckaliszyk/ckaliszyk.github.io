fof(myForms, conjecture, ! [D] : ((empty(D) & ilf_type(D,set_type)) => relation_like(D))).
fof(myForms, conjecture, ! [P5] : ((empty(P5) & ilf_type(P5,set_type)) => relation_like(P5))).