fof(myForms, conjecture, ! [K6] : ! [L6] : (subset(set_union2(singleton(K6),L6),L6) => in(K6,L6))).
fof(myForms, conjecture, ! [W3] : ! [X3] : (subset(set_union2(singleton(W3),X3),X3) => in(W3,X3))).