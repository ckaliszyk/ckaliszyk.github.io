fof(myForms, conjecture, ! [M9] : ! [N9] : (subset(singleton(M9),singleton(N9)) => N9=M9)).
fof(myForms, conjecture, ! [M3] : ! [N3] : (subset(singleton(M3),singleton(N3)) => N3=M3)).