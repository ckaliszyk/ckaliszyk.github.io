fof(myForms, conjecture, ! [R] : ! [S] : unordered_pair(S,R)=unordered_pair(R,S)).
fof(myForms, conjecture, ! [M] : ! [N] : unordered_pair(N,M)=unordered_pair(M,N)).