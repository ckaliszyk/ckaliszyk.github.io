fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ~ member(D,empty_set))).
fof(myForms, conjecture, ! [I7] : (ilf_type(I7,set_type) => ~ member(I7,empty_set))).