fof(myForms, conjecture, ! [D] : union(D,empty_set)=D).
fof(myForms, conjecture, ! [Q5] : union(Q5,empty_set)=Q5).