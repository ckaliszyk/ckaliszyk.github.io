fof(myForms, conjecture, ! [D] : ((~ empty(D) & ilf_type(D,set_type)) => ? [F] : ilf_type(F,member_type(D)))).
fof(myForms, conjecture, ! [D] : ! [F] : (not_equal(D,F) <=> ~ F=D)).