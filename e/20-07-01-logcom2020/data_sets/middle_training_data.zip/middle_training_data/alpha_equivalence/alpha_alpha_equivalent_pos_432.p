fof(myForms, conjecture, ! [C] : ! [D] : set_intersection2(D,C)=set_intersection2(C,D)).
fof(myForms, conjecture, ! [D8] : ! [E8] : set_intersection2(E8,D8)=set_intersection2(D8,E8)).