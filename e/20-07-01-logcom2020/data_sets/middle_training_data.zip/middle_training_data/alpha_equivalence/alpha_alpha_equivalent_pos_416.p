fof(myForms, conjecture, ! [S7] : ilf_type(S7,set_type)).
fof(myForms, conjecture, ! [I5] : ilf_type(I5,set_type)).