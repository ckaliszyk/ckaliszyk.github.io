fof(myForms, conjecture, ! [E3] : ! [F3] : union(intersection(E3,F3),difference(E3,F3))=E3).
fof(myForms, conjecture, ! [G9] : ! [H9] : union(intersection(G9,H9),difference(G9,H9))=G9).