fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ilf_type(singleton(D),set_type))).
fof(myForms, conjecture, ! [Q5] : (ilf_type(Q5,set_type) => ilf_type(singleton(Q5),set_type))).