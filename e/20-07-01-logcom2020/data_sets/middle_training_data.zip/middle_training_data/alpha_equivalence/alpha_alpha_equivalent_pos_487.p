fof(myForms, conjecture, ! [D] : (ilf_type(D,binary_relation_type) => D=D)).
fof(myForms, conjecture, ! [D9] : (ilf_type(D9,binary_relation_type) => D9=D9)).