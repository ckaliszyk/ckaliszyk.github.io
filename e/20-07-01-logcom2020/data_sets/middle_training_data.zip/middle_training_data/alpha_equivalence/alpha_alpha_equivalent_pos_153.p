fof(myForms, conjecture, ! [D] : ! [F] : ! [I] : union(union(D,F),I)=union(D,union(F,I))).
fof(myForms, conjecture, ! [G4] : ! [H4] : ! [I4] : union(union(G4,H4),I4)=union(G4,union(H4,I4))).