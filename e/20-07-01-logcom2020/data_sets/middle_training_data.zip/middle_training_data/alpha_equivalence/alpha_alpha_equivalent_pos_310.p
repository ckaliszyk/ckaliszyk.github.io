fof(myForms, conjecture, ! [D] : ! [F] : union(F,D)=union(D,F)).
fof(myForms, conjecture, ! [E2] : ! [F2] : union(F2,E2)=union(E2,F2)).