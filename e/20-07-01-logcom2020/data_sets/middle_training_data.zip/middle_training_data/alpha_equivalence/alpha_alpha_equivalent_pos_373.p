fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ? [F] : ilf_type(F,subset_type(D)))).
fof(myForms, conjecture, ! [F6] : (ilf_type(F6,set_type) => ? [G6] : ilf_type(G6,subset_type(F6)))).