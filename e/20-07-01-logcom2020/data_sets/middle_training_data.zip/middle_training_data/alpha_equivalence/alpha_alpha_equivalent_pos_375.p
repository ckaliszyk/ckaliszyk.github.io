fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ? [F] : ilf_type(F,subset_type(D)))).
fof(myForms, conjecture, ! [Z7] : (ilf_type(Z7,set_type) => ? [A8] : ilf_type(A8,subset_type(Z7)))).