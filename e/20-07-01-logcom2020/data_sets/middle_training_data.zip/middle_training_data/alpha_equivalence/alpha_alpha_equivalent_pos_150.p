fof(myForms, conjecture, ! [D] : ((empty(D) & ilf_type(D,set_type)) => relation_like(D))).
fof(myForms, conjecture, ! [J2] : ((empty(J2) & ilf_type(J2,set_type)) => relation_like(J2))).