fof(myForms, conjecture, ! [O3] : ! [P3] : (member(P3,singleton(O3)) => P3=O3)).
fof(myForms, conjecture, ! [D8] : ! [E8] : (member(E8,singleton(D8)) => E8=D8)).