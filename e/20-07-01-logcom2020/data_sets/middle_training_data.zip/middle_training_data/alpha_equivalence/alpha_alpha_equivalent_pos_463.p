fof(myForms, conjecture, ! [C] : ! [D] : (~ empty(C) => ~ empty(set_union2(C,D)))).
fof(myForms, conjecture, ! [K3] : ! [L3] : (~ empty(K3) => ~ empty(set_union2(K3,L3)))).