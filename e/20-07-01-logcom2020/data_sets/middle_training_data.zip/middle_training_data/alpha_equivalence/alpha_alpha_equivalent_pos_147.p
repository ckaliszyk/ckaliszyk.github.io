fof(myForms, conjecture, ! [D] : ilf_type(D,set_type)).
fof(myForms, conjecture, ! [U3] : ilf_type(U3,set_type)).