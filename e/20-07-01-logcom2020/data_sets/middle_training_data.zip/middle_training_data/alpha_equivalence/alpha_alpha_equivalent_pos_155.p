fof(myForms, conjecture, ! [G4] : ! [H4] : ! [I4] : union(union(G4,H4),I4)=union(G4,union(H4,I4))).
fof(myForms, conjecture, ! [O6] : ! [P6] : ! [Q6] : union(union(O6,P6),Q6)=union(O6,union(P6,Q6))).