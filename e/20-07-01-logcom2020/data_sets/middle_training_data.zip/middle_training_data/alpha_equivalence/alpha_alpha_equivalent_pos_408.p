fof(myForms, conjecture, ! [D] : ilf_type(D,set_type)).
fof(myForms, conjecture, ! [F9] : ilf_type(F9,set_type)).