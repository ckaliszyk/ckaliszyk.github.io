fof(myForms, conjecture, ! [C] : ! [D] : ~ empty(ordered_pair(C,D))).
fof(myForms, conjecture, ! [X6] : ! [Y6] : ~ empty(ordered_pair(X6,Y6))).