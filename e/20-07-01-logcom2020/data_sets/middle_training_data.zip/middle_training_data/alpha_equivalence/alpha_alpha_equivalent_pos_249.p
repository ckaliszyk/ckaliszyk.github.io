fof(myForms, conjecture, ! [C] : ! [D] : (subset(singleton(C),singleton(D)) => D=C)).
fof(myForms, conjecture, ! [M9] : ! [N9] : (subset(singleton(M9),singleton(N9)) => N9=M9)).