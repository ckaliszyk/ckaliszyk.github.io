fof(myForms, conjecture, ! [D] : ! [F] : (intersect(D,F) => intersect(F,D))).
fof(myForms, conjecture, ! [S8] : ! [T8] : (intersect(S8,T8) => intersect(T8,S8))).