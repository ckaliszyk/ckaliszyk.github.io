fof(myForms, conjecture, ! [F9] : ilf_type(F9,set_type)).
fof(myForms, conjecture, ! [A7] : ilf_type(A7,set_type)).