fof(myForms, conjecture, ! [C] : ! [D] : (in(C,D) => subset(C,union(D)))).
fof(myForms, conjecture, ! [X2] : ! [Y2] : (in(X2,Y2) => subset(X2,union(Y2)))).