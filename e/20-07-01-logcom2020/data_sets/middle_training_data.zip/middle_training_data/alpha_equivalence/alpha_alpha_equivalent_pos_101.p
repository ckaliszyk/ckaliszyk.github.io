fof(myForms, conjecture, ? [L1] : ~ empty(L1)).
fof(myForms, conjecture, ? [Q9] : ~ empty(Q9)).