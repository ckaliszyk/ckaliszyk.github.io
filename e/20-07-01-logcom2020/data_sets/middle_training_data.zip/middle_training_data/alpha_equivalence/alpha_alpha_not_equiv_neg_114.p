fof(myForms, conjecture, ! [C] : ! [D] : union(unordered_pair(C,D))=set_union2(C,D)).
fof(myForms, conjecture, ! [D] : ! [F] : (F=D <=> ! [I] : (member(I,D) <=> member(I,F)))).