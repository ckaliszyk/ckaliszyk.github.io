fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ? [F] : ilf_type(F,subset_type(D)))).
fof(myForms, conjecture, ! [B3] : (ilf_type(B3,set_type) => ? [C3] : ilf_type(C3,subset_type(B3)))).