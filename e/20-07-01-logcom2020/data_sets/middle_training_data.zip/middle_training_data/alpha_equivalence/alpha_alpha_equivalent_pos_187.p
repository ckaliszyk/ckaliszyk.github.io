fof(myForms, conjecture, ! [D] : (ilf_type(D,binary_relation_type) => subset(D,D))).
fof(myForms, conjecture, ! [A8] : (ilf_type(A8,binary_relation_type) => subset(A8,A8))).