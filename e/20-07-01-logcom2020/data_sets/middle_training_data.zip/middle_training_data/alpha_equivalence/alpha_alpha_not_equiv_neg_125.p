fof(myForms, conjecture, ! [C] : ! [D] : union(unordered_pair(C,D))=set_union2(C,D)).
fof(myForms, conjecture, ! [D] : (ilf_type(D,binary_relation_type) => D=D)).