fof(myForms, conjecture, ! [D] : ! [F] : union(D,intersection(D,F))=D).
fof(myForms, conjecture, ! [E4] : ! [F4] : union(E4,intersection(E4,F4))=E4).