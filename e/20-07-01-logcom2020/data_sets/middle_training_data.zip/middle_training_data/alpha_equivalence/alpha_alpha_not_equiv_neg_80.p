fof(myForms, conjecture, ! [C] : ! [D] : union(unordered_pair(C,D))=set_union2(C,D)).
fof(myForms, conjecture, ! [D] : ! [F] : ! [I] : union(difference(D,I),difference(F,I))=difference(union(D,F),I)).