fof(myForms, conjecture, ! [Z1] : ! [A2] : set_union2(A2,Z1)=set_union2(Z1,A2)).
fof(myForms, conjecture, ! [O1] : ! [P1] : set_union2(P1,O1)=set_union2(O1,P1)).