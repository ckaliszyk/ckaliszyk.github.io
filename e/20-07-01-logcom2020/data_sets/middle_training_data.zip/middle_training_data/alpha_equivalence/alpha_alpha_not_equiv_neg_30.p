fof(myForms, conjecture, ! [C] : ! [D] : union(unordered_pair(C,D))=set_union2(C,D)).
fof(myForms, conjecture, ! [L] : ! [P] : ! [K] : ((subclass(L,P) & subclass(P,K)) => subclass(L,K))).