fof(myForms, conjecture, ! [D] : ! [F] : ! [I] : union(union(D,F),I)=union(D,union(F,I))).
fof(myForms, conjecture, ! [W1] : ! [X1] : ! [Y1] : union(union(W1,X1),Y1)=union(W1,union(X1,Y1))).