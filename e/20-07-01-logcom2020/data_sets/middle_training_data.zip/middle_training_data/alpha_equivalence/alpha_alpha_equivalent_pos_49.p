fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ? [F] : ilf_type(F,subset_type(D)))).
fof(myForms, conjecture, ! [W2] : (ilf_type(W2,set_type) => ? [X2] : ilf_type(X2,subset_type(W2)))).