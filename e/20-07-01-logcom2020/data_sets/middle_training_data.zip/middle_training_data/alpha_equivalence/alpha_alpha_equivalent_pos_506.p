fof(myForms, conjecture, ! [Z7] : ! [A8] : ~ ((disjoint(singleton(Z7),A8) & in(Z7,A8)))).
fof(myForms, conjecture, ! [I2] : ! [J2] : ~ ((disjoint(singleton(I2),J2) & in(I2,J2)))).