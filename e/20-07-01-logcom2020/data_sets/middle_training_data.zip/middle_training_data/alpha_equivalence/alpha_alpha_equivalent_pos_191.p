fof(myForms, conjecture, ! [F2] : ! [G2] : difference(F2,intersection(F2,G2))=difference(F2,G2)).
fof(myForms, conjecture, ! [B5] : ! [C5] : difference(B5,intersection(B5,C5))=difference(B5,C5)).