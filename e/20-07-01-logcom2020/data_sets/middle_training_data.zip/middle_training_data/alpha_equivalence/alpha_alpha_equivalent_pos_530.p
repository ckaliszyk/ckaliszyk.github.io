fof(myForms, conjecture, ! [Z1] : ((empty(Z1) & ilf_type(Z1,set_type)) => relation_like(Z1))).
fof(myForms, conjecture, ! [P5] : ((empty(P5) & ilf_type(P5,set_type)) => relation_like(P5))).