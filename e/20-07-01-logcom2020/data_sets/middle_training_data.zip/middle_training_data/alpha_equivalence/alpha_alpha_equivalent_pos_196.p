fof(myForms, conjecture, ! [D] : subset(empty_set,D)).
fof(myForms, conjecture, ! [I7] : subset(empty_set,I7)).