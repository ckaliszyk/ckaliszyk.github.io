fof(myForms, conjecture, ! [E9] : ! [F9] : intersection(F9,E9)=intersection(E9,F9)).
fof(myForms, conjecture, ! [Q1] : ! [R1] : intersection(R1,Q1)=intersection(Q1,R1)).