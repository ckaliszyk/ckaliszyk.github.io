fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ! [F] : ilf_type(F,set_type))).
fof(myForms, conjecture, ! [L3] : (ilf_type(L3,set_type) => ! [M3] : ilf_type(M3,set_type))).