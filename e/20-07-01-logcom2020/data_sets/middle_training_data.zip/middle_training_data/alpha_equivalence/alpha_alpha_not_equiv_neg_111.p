fof(myForms, conjecture, ! [C] : ! [D] : union(unordered_pair(C,D))=set_union2(C,D)).
fof(myForms, conjecture, ! [C] : ! [D] : (powerset(C)=D <=> ! [F] : (in(F,D) <=> subset(F,C)))).