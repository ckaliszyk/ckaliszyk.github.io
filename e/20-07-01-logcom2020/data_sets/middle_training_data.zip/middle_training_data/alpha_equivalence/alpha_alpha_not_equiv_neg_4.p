fof(myForms, conjecture, ! [C] : ! [D] : union(unordered_pair(C,D))=set_union2(C,D)).
fof(myForms, conjecture, ! [C] : ! [D] : (singleton(C)=D <=> ! [F] : (in(F,D) <=> F=C))).