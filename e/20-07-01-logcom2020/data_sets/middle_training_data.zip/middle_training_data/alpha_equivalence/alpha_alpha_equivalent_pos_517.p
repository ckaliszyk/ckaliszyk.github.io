fof(myForms, conjecture, ! [C] : ! [D] : (subset(singleton(C),singleton(D)) => D=C)).
fof(myForms, conjecture, ! [A7] : ! [B7] : (subset(singleton(A7),singleton(B7)) => B7=A7)).