fof(myForms, conjecture, ! [D] : (ilf_type(D,binary_relation_type) => D=D)).
fof(myForms, conjecture, ! [F] : (ilf_type(F,binary_relation_type) => F=F)).