fof(myForms, conjecture, ! [C] : ! [D] : union(unordered_pair(C,D))=set_union2(C,D)).
fof(myForms, conjecture, ! [C] : ! [D] : (set_difference(singleton(C),singleton(D))=empty_set => D=C)).