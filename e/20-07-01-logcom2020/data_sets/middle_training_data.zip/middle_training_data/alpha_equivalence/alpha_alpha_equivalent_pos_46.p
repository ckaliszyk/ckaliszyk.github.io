fof(myForms, conjecture, ! [L] : (subclass(L,null_class) => null_class=L)).
fof(myForms, conjecture, ! [R9] : (subclass(R9,null_class) => null_class=R9)).