fof(myForms, conjecture, ? [A6] : ! [B6] : ~ member(B6,A6)).
fof(myForms, conjecture, ? [H5] : ! [I5] : ~ member(I5,H5)).