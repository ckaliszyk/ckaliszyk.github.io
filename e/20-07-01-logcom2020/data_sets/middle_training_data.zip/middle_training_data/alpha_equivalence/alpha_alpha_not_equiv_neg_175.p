fof(myForms, conjecture, ! [C] : ! [D] : union(unordered_pair(C,D))=set_union2(C,D)).
fof(myForms, conjecture, ! [D] : ! [F] : ! [I] : (subset(D,F) => subset(difference(I,F),difference(I,D)))).