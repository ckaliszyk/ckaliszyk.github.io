fof(myForms, conjecture, ! [C] : ! [D] : union(unordered_pair(C,D))=set_union2(C,D)).
fof(myForms, conjecture, ! [C] : ! [D] : (subset(C,D) <=> ! [F] : (in(F,C) => in(F,D)))).