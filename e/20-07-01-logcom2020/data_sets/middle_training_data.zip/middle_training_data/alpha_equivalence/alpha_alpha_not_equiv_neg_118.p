fof(myForms, conjecture, ! [C] : ! [D] : union(unordered_pair(C,D))=set_union2(C,D)).
fof(myForms, conjecture, ! [D] : difference(empty_set,D)=empty_set).