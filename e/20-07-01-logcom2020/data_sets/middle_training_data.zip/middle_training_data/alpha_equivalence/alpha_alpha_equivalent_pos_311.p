fof(myForms, conjecture, ! [H] : ! [I] : union(I,H)=union(H,I)).
fof(myForms, conjecture, ! [E2] : ! [F2] : union(F2,E2)=union(E2,F2)).