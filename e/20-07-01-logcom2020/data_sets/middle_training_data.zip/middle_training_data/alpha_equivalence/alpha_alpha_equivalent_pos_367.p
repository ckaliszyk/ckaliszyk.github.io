fof(myForms, conjecture, ! [D] : ~ member(D,empty_set)).
fof(myForms, conjecture, ! [U4] : ~ member(U4,empty_set)).