fof(myForms, conjecture, ! [D] : ilf_type(D,set_type)).
fof(myForms, conjecture, ! [S7] : ilf_type(S7,set_type)).