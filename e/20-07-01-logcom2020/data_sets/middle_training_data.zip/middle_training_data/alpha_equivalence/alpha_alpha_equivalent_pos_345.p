fof(myForms, conjecture, ! [C] : ! [D] : set_union2(C,C)=C).
fof(myForms, conjecture, ! [B1] : ! [C1] : set_union2(B1,B1)=B1).