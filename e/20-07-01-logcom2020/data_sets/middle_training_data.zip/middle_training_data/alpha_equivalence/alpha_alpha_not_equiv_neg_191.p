fof(myForms, conjecture, ! [C] : ! [D] : union(unordered_pair(C,D))=set_union2(C,D)).
fof(myForms, conjecture, ! [C] : ! [D] : union(unordered_pair(singleton(C),singleton(D)))=unordered_pair(C,D)).