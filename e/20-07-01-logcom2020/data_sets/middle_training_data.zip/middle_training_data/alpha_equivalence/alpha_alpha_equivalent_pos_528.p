fof(myForms, conjecture, ! [D] : ((empty(D) & ilf_type(D,set_type)) => relation_like(D))).
fof(myForms, conjecture, ! [Z1] : ((empty(Z1) & ilf_type(Z1,set_type)) => relation_like(Z1))).