fof(myForms, conjecture, ! [C] : ! [D] : union(unordered_pair(C,D))=set_union2(C,D)).
fof(myForms, conjecture, ! [C] : ! [L] : ! [P] : ((subset(L,C) & subset(P,C)) <=> subset(union(L,P),C))).