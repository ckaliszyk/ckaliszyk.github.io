fof(myForms, conjecture, ! [C] : ! [D] : (disjoint(C,D) => disjoint(D,C))).
fof(myForms, conjecture, ! [A8] : ! [B8] : (disjoint(A8,B8) => disjoint(B8,A8))).