fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ~ member(D,empty_set))).
fof(myForms, conjecture, ! [Q4] : (ilf_type(Q4,set_type) => ~ member(Q4,empty_set))).