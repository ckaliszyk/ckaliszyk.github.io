fof(myForms, conjecture, ! [D] : subset(D,D)).
fof(myForms, conjecture, ! [P] : subset(P,P)).