fof(myForms, conjecture, ! [D8] : ((empty(D8) & ilf_type(D8,set_type)) => relation_like(D8))).
fof(myForms, conjecture, ! [L6] : ((empty(L6) & ilf_type(L6,set_type)) => relation_like(L6))).