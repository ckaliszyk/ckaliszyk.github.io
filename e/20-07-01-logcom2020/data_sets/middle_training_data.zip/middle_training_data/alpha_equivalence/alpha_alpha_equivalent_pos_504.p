fof(myForms, conjecture, ! [C] : ! [D] : ~ ((disjoint(singleton(C),D) & in(C,D)))).
fof(myForms, conjecture, ! [Z7] : ! [A8] : ~ ((disjoint(singleton(Z7),A8) & in(Z7,A8)))).