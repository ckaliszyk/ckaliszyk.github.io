fof(myForms, conjecture, ! [C] : ! [D] : (subset(singleton(C),singleton(D)) => D=C)).
fof(myForms, conjecture, ! [F7] : ! [G7] : (subset(singleton(F7),singleton(G7)) => G7=F7)).