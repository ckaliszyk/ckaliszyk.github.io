fof(myForms, conjecture, ! [D] : ((~ empty(D) & ilf_type(D,set_type)) => ? [F] : ilf_type(F,member_type(D)))).
fof(myForms, conjecture, ! [C] : ! [D] : (D=C <=> (subset(C,D) & subset(D,C)))).