fof(myForms, conjecture, ? [C2] : ilf_type(C2,binary_relation_type)).
fof(myForms, conjecture, ? [G] : ilf_type(G,binary_relation_type)).