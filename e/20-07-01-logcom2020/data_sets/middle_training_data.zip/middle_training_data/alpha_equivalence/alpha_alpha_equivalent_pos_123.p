fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ? [F] : ilf_type(F,subset_type(D)))).
fof(myForms, conjecture, ! [J3] : (ilf_type(J3,set_type) => ? [K3] : ilf_type(K3,subset_type(J3)))).