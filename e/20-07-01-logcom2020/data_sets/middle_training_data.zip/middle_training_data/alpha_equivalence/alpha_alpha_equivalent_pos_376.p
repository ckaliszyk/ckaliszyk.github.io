fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ? [F] : ilf_type(F,subset_type(D)))).
fof(myForms, conjecture, ! [A3] : (ilf_type(A3,set_type) => ? [B3] : ilf_type(B3,subset_type(A3)))).