fof(myForms, conjecture, ! [F8] : unordered_pair(empty_set,singleton(F8))=powerset(singleton(F8))).
fof(myForms, conjecture, ! [E9] : unordered_pair(empty_set,singleton(E9))=powerset(singleton(E9))).