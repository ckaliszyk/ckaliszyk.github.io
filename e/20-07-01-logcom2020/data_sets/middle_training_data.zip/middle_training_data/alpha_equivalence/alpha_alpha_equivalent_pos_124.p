fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ? [F] : ilf_type(F,subset_type(D)))).
fof(myForms, conjecture, ! [W9] : (ilf_type(W9,set_type) => ? [X9] : ilf_type(X9,subset_type(W9)))).