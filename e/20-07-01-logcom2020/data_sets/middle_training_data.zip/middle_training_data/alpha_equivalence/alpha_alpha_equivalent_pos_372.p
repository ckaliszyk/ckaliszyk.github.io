fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ? [F] : ilf_type(F,subset_type(D)))).
fof(myForms, conjecture, ! [Z1] : (ilf_type(Z1,set_type) => ? [A2] : ilf_type(A2,subset_type(Z1)))).