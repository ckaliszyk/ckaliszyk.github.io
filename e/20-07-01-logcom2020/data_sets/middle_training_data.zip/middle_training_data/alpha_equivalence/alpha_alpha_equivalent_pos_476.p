fof(myForms, conjecture, ! [P] : ilf_type(P,set_type)).
fof(myForms, conjecture, ! [A7] : ilf_type(A7,set_type)).