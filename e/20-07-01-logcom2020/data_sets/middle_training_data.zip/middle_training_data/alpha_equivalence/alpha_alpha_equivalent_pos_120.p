fof(myForms, conjecture, ! [D] : ! [F] : intersection(F,D)=intersection(D,F)).
fof(myForms, conjecture, ! [E9] : ! [F9] : intersection(F9,E9)=intersection(E9,F9)).