fof(myForms, conjecture, ! [C] : ! [D] : union(unordered_pair(C,D))=set_union2(C,D)).
fof(myForms, conjecture, ! [D] : ! [F] : (intersect(D,F) <=> ? [I] : (member(I,D) & member(I,F)))).