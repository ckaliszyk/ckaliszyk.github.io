fof(myForms, conjecture, ! [D] : ! [F] : difference(D,intersection(D,F))=difference(D,F)).
fof(myForms, conjecture, ! [F2] : ! [G2] : difference(F2,intersection(F2,G2))=difference(F2,G2)).