fof(myForms, conjecture, ! [N] : ! [O] : ~ ((disjoint(singleton(N),O) & in(N,O)))).
fof(myForms, conjecture, ! [M7] : ! [N7] : ~ ((disjoint(singleton(M7),N7) & in(M7,N7)))).