fof(myForms, conjecture, ! [C] : ! [D] : union(unordered_pair(C,D))=set_union2(C,D)).
fof(myForms, conjecture, ! [O] : ! [J] : ! [W] : ((total_order(O,J) & max(W,O,J)) => greatest(W,O,J))).