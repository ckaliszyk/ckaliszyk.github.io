fof(myForms, conjecture, ! [C] : ! [D] : subset(C,C)).
fof(myForms, conjecture, ! [J3] : ! [K3] : subset(J3,J3)).