fof(myForms, conjecture, ! [D] : ilf_type(D,set_type)).
fof(myForms, conjecture, ! [B4] : ilf_type(B4,set_type)).