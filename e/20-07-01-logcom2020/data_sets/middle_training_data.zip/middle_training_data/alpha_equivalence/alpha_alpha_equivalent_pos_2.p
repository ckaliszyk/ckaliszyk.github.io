fof(myForms, conjecture, ! [B7] : ! [C7] : union(unordered_pair(B7,C7))=set_union2(B7,C7)).
fof(myForms, conjecture, ! [S] : ! [T] : union(unordered_pair(S,T))=set_union2(S,T)).