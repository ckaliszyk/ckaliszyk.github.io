fof(myForms, conjecture, ! [C] : ! [D] : union(unordered_pair(C,D))=set_union2(C,D)).
fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => (subset(D,empty_set) => empty_set=D))).