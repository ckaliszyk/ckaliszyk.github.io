fof(myForms, conjecture, ! [D] : difference(empty_set,D)=empty_set).
fof(myForms, conjecture, ! [O7] : difference(empty_set,O7)=empty_set).