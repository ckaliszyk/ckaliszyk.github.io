fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => (subset(D,empty_set) => empty_set=D))).
fof(myForms, conjecture, ! [H2] : (ilf_type(H2,set_type) => (subset(H2,empty_set) => empty_set=H2))).