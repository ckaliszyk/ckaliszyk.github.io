fof(myForms, conjecture, ? [D] : ilf_type(D,binary_relation_type)).
fof(myForms, conjecture, ? [Z5] : ilf_type(Z5,binary_relation_type)).