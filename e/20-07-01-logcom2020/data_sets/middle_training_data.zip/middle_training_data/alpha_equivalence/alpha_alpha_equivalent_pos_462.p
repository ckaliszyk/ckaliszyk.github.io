fof(myForms, conjecture, ! [C] : ! [D] : (~ empty(C) => ~ empty(set_union2(C,D)))).
fof(myForms, conjecture, ! [R7] : ! [S7] : (~ empty(R7) => ~ empty(set_union2(R7,S7)))).