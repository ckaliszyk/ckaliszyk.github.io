fof(myForms, conjecture, ! [D] : ((empty(D) & ilf_type(D,set_type)) => relation_like(D))).
fof(myForms, conjecture, ! [V6] : ((empty(V6) & ilf_type(V6,set_type)) => relation_like(V6))).