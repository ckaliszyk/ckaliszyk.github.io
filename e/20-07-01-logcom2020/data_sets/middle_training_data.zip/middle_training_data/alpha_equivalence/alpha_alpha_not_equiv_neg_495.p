fof(myForms, conjecture, ! [D] : ((~ empty(D) & ilf_type(D,set_type)) => ? [F] : ilf_type(F,member_type(D)))).
fof(myForms, conjecture, ! [C] : ! [D] : (subset(C,D) <=> ! [F] : (in(F,C) => in(F,D)))).