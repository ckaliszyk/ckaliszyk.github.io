fof(myForms, conjecture, ! [C] : ! [D] : union(unordered_pair(C,D))=set_union2(C,D)).
fof(myForms, conjecture, ! [C] : ! [D] : (set_difference(C,D)=empty_set <=> subset(C,D))).