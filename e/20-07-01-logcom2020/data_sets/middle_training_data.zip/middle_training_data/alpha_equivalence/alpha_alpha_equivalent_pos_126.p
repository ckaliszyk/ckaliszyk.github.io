fof(myForms, conjecture, empty(empty_set)).
fof(myForms, conjecture, empty(empty_set)).