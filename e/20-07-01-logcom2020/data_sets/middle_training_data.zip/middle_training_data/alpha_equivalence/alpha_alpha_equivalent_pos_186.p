fof(myForms, conjecture, ! [D] : (ilf_type(D,binary_relation_type) => subset(D,D))).
fof(myForms, conjecture, ! [P8] : (ilf_type(P8,binary_relation_type) => subset(P8,P8))).