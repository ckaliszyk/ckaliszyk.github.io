fof(myForms, conjecture, ! [M1] : ! [N1] : subset(M1,M1)).
fof(myForms, conjecture, ! [J3] : ! [K3] : subset(J3,J3)).