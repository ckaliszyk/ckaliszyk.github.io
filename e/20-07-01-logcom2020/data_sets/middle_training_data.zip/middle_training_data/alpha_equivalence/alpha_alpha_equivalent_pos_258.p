fof(myForms, conjecture, ! [D] : (ilf_type(D,binary_relation_type) => D=D)).
fof(myForms, conjecture, ! [A2] : (ilf_type(A2,binary_relation_type) => A2=A2)).