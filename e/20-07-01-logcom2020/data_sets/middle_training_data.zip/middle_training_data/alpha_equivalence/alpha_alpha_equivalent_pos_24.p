fof(myForms, conjecture, ! [C] : ! [D] : (subset(set_union2(singleton(C),D),D) => in(C,D))).
fof(myForms, conjecture, ! [K6] : ! [L6] : (subset(set_union2(singleton(K6),L6),L6) => in(K6,L6))).