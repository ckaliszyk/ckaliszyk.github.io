fof(myForms, conjecture, union(empty_set)=empty_set).
fof(myForms, conjecture, union(empty_set)=empty_set).