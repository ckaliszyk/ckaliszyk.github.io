fof(myForms, conjecture, ? [D] : ilf_type(D,binary_relation_type)).
fof(myForms, conjecture, ? [R9] : ilf_type(R9,binary_relation_type)).