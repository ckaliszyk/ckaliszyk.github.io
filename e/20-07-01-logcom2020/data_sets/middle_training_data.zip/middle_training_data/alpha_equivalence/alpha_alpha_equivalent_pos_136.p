fof(myForms, conjecture, ! [D] : ((empty(D) & ilf_type(D,set_type)) => relation_like(D))).
fof(myForms, conjecture, ! [A1] : ((empty(A1) & ilf_type(A1,set_type)) => relation_like(A1))).