fof(myForms, conjecture, type(empty_set,set_type)).
fof(myForms, conjecture, type(empty_set,set_type)).