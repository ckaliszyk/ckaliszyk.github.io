fof(myForms, conjecture, ! [T1] : union(T1,empty_set)=T1).
fof(myForms, conjecture, ! [Q5] : union(Q5,empty_set)=Q5).