fof(myForms, conjecture, ! [C] : ! [D] : (subset(set_union2(singleton(C),D),D) => in(C,D))).
fof(myForms, conjecture, ! [I4] : ! [J4] : (subset(set_union2(singleton(I4),J4),J4) => in(I4,J4))).