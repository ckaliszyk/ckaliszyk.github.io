fof(myForms, conjecture, ! [D] : (ilf_type(D,binary_relation_type) => D=D)).
fof(myForms, conjecture, ! [V7] : (ilf_type(V7,binary_relation_type) => V7=V7)).