fof(myForms, conjecture, ! [B4] : ilf_type(B4,set_type)).
fof(myForms, conjecture, ! [D3] : ilf_type(D3,set_type)).