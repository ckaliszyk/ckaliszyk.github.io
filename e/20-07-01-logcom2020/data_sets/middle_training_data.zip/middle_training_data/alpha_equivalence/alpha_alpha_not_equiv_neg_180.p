fof(myForms, conjecture, ! [C] : ! [D] : union(unordered_pair(C,D))=set_union2(C,D)).
fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ? [F] : ilf_type(F,subset_type(D)))).