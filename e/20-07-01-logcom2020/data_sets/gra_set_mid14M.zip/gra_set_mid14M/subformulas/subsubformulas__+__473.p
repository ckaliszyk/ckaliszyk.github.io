fof(myForms, conjecture, ! [B] : ! [Y] : (member(Y,intersection(I,B)) <=> (member(Y,I) & member(Y,B)))).
fof(myForms, conjecture, ! [Y] : (member(Y,intersection(I,B)) <=> (member(Y,I) & member(Y,B)))).
fof(myForms, conjecture, (member(Y,intersection(I,B)) <=> (member(Y,I) & member(Y,B)))).
fof(myForms, conjecture, member(Y,intersection(I,B))).
fof(myForms, conjecture, (member(Y,I) & member(Y,B))).
fof(myForms, conjecture, member(Y,I)).
fof(myForms, conjecture, member(Y,B)).