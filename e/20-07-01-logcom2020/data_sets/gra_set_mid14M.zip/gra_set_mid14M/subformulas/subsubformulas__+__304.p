fof(myForms, conjecture, ! [Y] : (ilf_type(Y,relation_type(I,B)) => domain(I,B,Y)=domain_of(Y))).
fof(myForms, conjecture, (ilf_type(Y,relation_type(I,B)) => domain(I,B,Y)=domain_of(Y))).
fof(myForms, conjecture, ilf_type(Y,relation_type(I,B))).
fof(myForms, conjecture, domain(I,B,Y)=domain_of(Y)).