fof(myForms, conjecture, ~ ((member(F,I) & member(I,F)))).
fof(myForms, conjecture, (member(F,I) & member(I,F))).
fof(myForms, conjecture, member(F,I)).
fof(myForms, conjecture, member(I,F)).