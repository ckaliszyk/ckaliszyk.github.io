fof(myForms, conjecture, ! [F] : ! [I] : (union(F)=I <=> ! [B] : (in(B,I) <=> ? [Y] : (in(B,Y) & in(Y,F))))).
fof(myForms, conjecture, ! [I] : (union(F)=I <=> ! [B] : (in(B,I) <=> ? [Y] : (in(B,Y) & in(Y,F))))).
fof(myForms, conjecture, (union(F)=I <=> ! [B] : (in(B,I) <=> ? [Y] : (in(B,Y) & in(Y,F))))).
fof(myForms, conjecture, union(F)=I).
fof(myForms, conjecture, ! [B] : (in(B,I) <=> ? [Y] : (in(B,Y) & in(Y,F)))).
fof(myForms, conjecture, (in(B,I) <=> ? [Y] : (in(B,Y) & in(Y,F)))).
fof(myForms, conjecture, in(B,I)).
fof(myForms, conjecture, ? [Y] : (in(B,Y) & in(Y,F))).
fof(myForms, conjecture, (in(B,Y) & in(Y,F))).
fof(myForms, conjecture, in(B,Y)).
fof(myForms, conjecture, in(Y,F)).