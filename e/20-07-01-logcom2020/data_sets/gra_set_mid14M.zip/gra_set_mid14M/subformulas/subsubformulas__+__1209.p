fof(myForms, conjecture, (ilf_type(I,set_type) => ! [B] : (ilf_type(B,set_type) => ! [Y] : (ilf_type(Y,relation_type(I,B)) => ! [Z] : (ilf_type(Z,set_type) => inverse4(I,B,Y,Z)=inverse2(Y,Z)))))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [B] : (ilf_type(B,set_type) => ! [Y] : (ilf_type(Y,relation_type(I,B)) => ! [Z] : (ilf_type(Z,set_type) => inverse4(I,B,Y,Z)=inverse2(Y,Z))))).
fof(myForms, conjecture, (ilf_type(B,set_type) => ! [Y] : (ilf_type(Y,relation_type(I,B)) => ! [Z] : (ilf_type(Z,set_type) => inverse4(I,B,Y,Z)=inverse2(Y,Z))))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ! [Y] : (ilf_type(Y,relation_type(I,B)) => ! [Z] : (ilf_type(Z,set_type) => inverse4(I,B,Y,Z)=inverse2(Y,Z)))).
fof(myForms, conjecture, (ilf_type(Y,relation_type(I,B)) => ! [Z] : (ilf_type(Z,set_type) => inverse4(I,B,Y,Z)=inverse2(Y,Z)))).
fof(myForms, conjecture, ilf_type(Y,relation_type(I,B))).
fof(myForms, conjecture, ! [Z] : (ilf_type(Z,set_type) => inverse4(I,B,Y,Z)=inverse2(Y,Z))).
fof(myForms, conjecture, (ilf_type(Z,set_type) => inverse4(I,B,Y,Z)=inverse2(Y,Z))).
fof(myForms, conjecture, ilf_type(Z,set_type)).
fof(myForms, conjecture, inverse4(I,B,Y,Z)=inverse2(Y,Z)).