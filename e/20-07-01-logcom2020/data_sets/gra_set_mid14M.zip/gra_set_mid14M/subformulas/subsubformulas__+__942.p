fof(myForms, conjecture, (ilf_type(I,set_type) => ! [B] : (ilf_type(B,set_type) => ! [Y] : (ilf_type(Y,relation_type(I,B)) => range(I,B,Y)=range_of(Y))))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [B] : (ilf_type(B,set_type) => ! [Y] : (ilf_type(Y,relation_type(I,B)) => range(I,B,Y)=range_of(Y)))).
fof(myForms, conjecture, (ilf_type(B,set_type) => ! [Y] : (ilf_type(Y,relation_type(I,B)) => range(I,B,Y)=range_of(Y)))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ! [Y] : (ilf_type(Y,relation_type(I,B)) => range(I,B,Y)=range_of(Y))).
fof(myForms, conjecture, (ilf_type(Y,relation_type(I,B)) => range(I,B,Y)=range_of(Y))).
fof(myForms, conjecture, ilf_type(Y,relation_type(I,B))).
fof(myForms, conjecture, range(I,B,Y)=range_of(Y)).