fof(myForms, conjecture, ! [I] : (ilf_type(I,set_type) => ? [B] : ilf_type(B,subset_type(I)))).
fof(myForms, conjecture, (ilf_type(I,set_type) => ? [B] : ilf_type(B,subset_type(I)))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ? [B] : ilf_type(B,subset_type(I))).
fof(myForms, conjecture, ilf_type(B,subset_type(I))).