fof(myForms, conjecture, ! [L] : (null_class=L | (? [P] : singleton(P)=L | ? [N] : (member(N,L) & ? [Q] : member(Q,intersection(complement(singleton(N)),L)))))).
fof(myForms, conjecture, (null_class=L | (? [P] : singleton(P)=L | ? [N] : (member(N,L) & ? [Q] : member(Q,intersection(complement(singleton(N)),L)))))).
fof(myForms, conjecture, null_class=L).
fof(myForms, conjecture, (? [P] : singleton(P)=L | ? [N] : (member(N,L) & ? [Q] : member(Q,intersection(complement(singleton(N)),L))))).
fof(myForms, conjecture, ? [P] : singleton(P)=L).
fof(myForms, conjecture, singleton(P)=L).
fof(myForms, conjecture, ? [N] : (member(N,L) & ? [Q] : member(Q,intersection(complement(singleton(N)),L)))).
fof(myForms, conjecture, (member(N,L) & ? [Q] : member(Q,intersection(complement(singleton(N)),L)))).
fof(myForms, conjecture, member(N,L)).
fof(myForms, conjecture, ? [Q] : member(Q,intersection(complement(singleton(N)),L))).
fof(myForms, conjecture, member(Q,intersection(complement(singleton(N)),L))).