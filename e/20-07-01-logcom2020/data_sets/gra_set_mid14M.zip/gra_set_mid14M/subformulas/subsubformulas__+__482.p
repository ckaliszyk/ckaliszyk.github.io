fof(myForms, conjecture, (ilf_type(I,set_type) => ! [B] : (ilf_type(B,set_type) => ilf_type(unordered_pair(I,B),set_type)))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [B] : (ilf_type(B,set_type) => ilf_type(unordered_pair(I,B),set_type))).
fof(myForms, conjecture, (ilf_type(B,set_type) => ilf_type(unordered_pair(I,B),set_type))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ilf_type(unordered_pair(I,B),set_type)).