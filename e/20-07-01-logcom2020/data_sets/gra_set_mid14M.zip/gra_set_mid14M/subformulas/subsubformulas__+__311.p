fof(myForms, conjecture, (ilf_type(I,set_type) => ilf_type(singleton(I),set_type))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ilf_type(singleton(I),set_type)).