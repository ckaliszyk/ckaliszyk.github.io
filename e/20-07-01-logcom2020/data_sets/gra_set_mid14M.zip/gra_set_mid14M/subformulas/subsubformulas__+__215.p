fof(myForms, conjecture, ! [B] : (subset(unordered_pair(F,I),singleton(B)) => F=B)).
fof(myForms, conjecture, (subset(unordered_pair(F,I),singleton(B)) => F=B)).
fof(myForms, conjecture, subset(unordered_pair(F,I),singleton(B))).
fof(myForms, conjecture, F=B).