fof(myForms, conjecture, (subset(I,empty_set) => empty_set=I)).
fof(myForms, conjecture, subset(I,empty_set)).
fof(myForms, conjecture, empty_set=I).