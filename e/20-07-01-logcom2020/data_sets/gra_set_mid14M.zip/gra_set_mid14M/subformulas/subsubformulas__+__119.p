fof(myForms, conjecture, (ilf_type(Z,relation_type(B,Y)) => (subset(I,Z) => subset(I,cross_product(B,Y))))).
fof(myForms, conjecture, ilf_type(Z,relation_type(B,Y))).
fof(myForms, conjecture, (subset(I,Z) => subset(I,cross_product(B,Y)))).
fof(myForms, conjecture, subset(I,Z)).
fof(myForms, conjecture, subset(I,cross_product(B,Y))).