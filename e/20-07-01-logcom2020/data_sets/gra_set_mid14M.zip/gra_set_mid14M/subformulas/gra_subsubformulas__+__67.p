fof(myForms, conjecture, (vertex(N) & vertex(O))).
fof(myForms, conjecture, vertex(N)).
fof(myForms, conjecture, vertex(O)).