fof(myForms, conjecture, (complete => ! [P] : ! [N] : ! [O] : (shortest_path(N,O,P) => ! [K] : ! [L] : (((on_path(K,P) & on_path(L,P)) & sequential(K,L)) => ? [M] : triangle(K,L,M))))).
fof(myForms, conjecture, complete).
fof(myForms, conjecture, ! [P] : ! [N] : ! [O] : (shortest_path(N,O,P) => ! [K] : ! [L] : (((on_path(K,P) & on_path(L,P)) & sequential(K,L)) => ? [M] : triangle(K,L,M)))).
fof(myForms, conjecture, ! [N] : ! [O] : (shortest_path(N,O,P) => ! [K] : ! [L] : (((on_path(K,P) & on_path(L,P)) & sequential(K,L)) => ? [M] : triangle(K,L,M)))).
fof(myForms, conjecture, ! [O] : (shortest_path(N,O,P) => ! [K] : ! [L] : (((on_path(K,P) & on_path(L,P)) & sequential(K,L)) => ? [M] : triangle(K,L,M)))).
fof(myForms, conjecture, (shortest_path(N,O,P) => ! [K] : ! [L] : (((on_path(K,P) & on_path(L,P)) & sequential(K,L)) => ? [M] : triangle(K,L,M)))).
fof(myForms, conjecture, shortest_path(N,O,P)).
fof(myForms, conjecture, ! [K] : ! [L] : (((on_path(K,P) & on_path(L,P)) & sequential(K,L)) => ? [M] : triangle(K,L,M))).
fof(myForms, conjecture, ! [L] : (((on_path(K,P) & on_path(L,P)) & sequential(K,L)) => ? [M] : triangle(K,L,M))).
fof(myForms, conjecture, (((on_path(K,P) & on_path(L,P)) & sequential(K,L)) => ? [M] : triangle(K,L,M))).
fof(myForms, conjecture, ((on_path(K,P) & on_path(L,P)) & sequential(K,L))).
fof(myForms, conjecture, (on_path(K,P) & on_path(L,P))).
fof(myForms, conjecture, on_path(K,P)).
fof(myForms, conjecture, on_path(L,P)).
fof(myForms, conjecture, sequential(K,L)).
fof(myForms, conjecture, ? [M] : triangle(K,L,M)).
fof(myForms, conjecture, triangle(K,L,M)).