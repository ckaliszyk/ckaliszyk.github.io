fof(myForms, conjecture, (member(Y,I) & member(ordered_pair(B,Y),Z))).
fof(myForms, conjecture, member(Y,I)).
fof(myForms, conjecture, member(ordered_pair(B,Y),Z)).