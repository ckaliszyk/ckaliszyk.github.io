fof(myForms, conjecture, ! [B1] : (element(B1,A1) <=> element(B1,R))).
fof(myForms, conjecture, (element(B1,A1) <=> element(B1,R))).
fof(myForms, conjecture, element(B1,A1)).
fof(myForms, conjecture, element(B1,R)).