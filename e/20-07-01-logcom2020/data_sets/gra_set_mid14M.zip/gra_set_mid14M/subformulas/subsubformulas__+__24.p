fof(myForms, conjecture, ! [I] : unordered_pair(F,I)=set_union2(singleton(F),singleton(I))).
fof(myForms, conjecture, unordered_pair(F,I)=set_union2(singleton(F),singleton(I))).