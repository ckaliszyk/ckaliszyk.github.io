fof(myForms, conjecture, ! [D] : ! [F] : ! [I] : union(difference(D,I),difference(F,I))=difference(union(D,F),I)).
fof(myForms, conjecture, ! [F] : ! [I] : union(difference(D,I),difference(F,I))=difference(union(D,F),I)).
fof(myForms, conjecture, ! [I] : union(difference(D,I),difference(F,I))=difference(union(D,F),I)).
fof(myForms, conjecture, union(difference(D,I),difference(F,I))=difference(union(D,F),I)).