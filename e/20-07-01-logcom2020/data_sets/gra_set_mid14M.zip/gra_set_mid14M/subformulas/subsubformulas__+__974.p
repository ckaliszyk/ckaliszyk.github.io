fof(myForms, conjecture, (ilf_type(B,set_type) => ! [Y] : (ilf_type(Y,set_type) => ! [Z] : (ilf_type(Z,set_type) => ! [D] : (ilf_type(D,relation_type(I,B)) => (member(ordered_pair(Y,Z),D) => (member(Y,I) & member(Z,B)))))))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ! [Y] : (ilf_type(Y,set_type) => ! [Z] : (ilf_type(Z,set_type) => ! [D] : (ilf_type(D,relation_type(I,B)) => (member(ordered_pair(Y,Z),D) => (member(Y,I) & member(Z,B))))))).
fof(myForms, conjecture, (ilf_type(Y,set_type) => ! [Z] : (ilf_type(Z,set_type) => ! [D] : (ilf_type(D,relation_type(I,B)) => (member(ordered_pair(Y,Z),D) => (member(Y,I) & member(Z,B))))))).
fof(myForms, conjecture, ilf_type(Y,set_type)).
fof(myForms, conjecture, ! [Z] : (ilf_type(Z,set_type) => ! [D] : (ilf_type(D,relation_type(I,B)) => (member(ordered_pair(Y,Z),D) => (member(Y,I) & member(Z,B)))))).
fof(myForms, conjecture, (ilf_type(Z,set_type) => ! [D] : (ilf_type(D,relation_type(I,B)) => (member(ordered_pair(Y,Z),D) => (member(Y,I) & member(Z,B)))))).
fof(myForms, conjecture, ilf_type(Z,set_type)).
fof(myForms, conjecture, ! [D] : (ilf_type(D,relation_type(I,B)) => (member(ordered_pair(Y,Z),D) => (member(Y,I) & member(Z,B))))).
fof(myForms, conjecture, (ilf_type(D,relation_type(I,B)) => (member(ordered_pair(Y,Z),D) => (member(Y,I) & member(Z,B))))).
fof(myForms, conjecture, ilf_type(D,relation_type(I,B))).
fof(myForms, conjecture, (member(ordered_pair(Y,Z),D) => (member(Y,I) & member(Z,B)))).
fof(myForms, conjecture, member(ordered_pair(Y,Z),D)).
fof(myForms, conjecture, (member(Y,I) & member(Z,B))).
fof(myForms, conjecture, member(Y,I)).
fof(myForms, conjecture, member(Z,B)).