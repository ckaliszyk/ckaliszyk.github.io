fof(myForms, conjecture, ! [K] : ! [L] : ! [M] : (triangle(K,L,M) <=> (((((edge(K) & edge(L)) & edge(M)) & sequential(K,L)) & sequential(L,M)) & sequential(M,K)))).
fof(myForms, conjecture, ! [L] : ! [M] : (triangle(K,L,M) <=> (((((edge(K) & edge(L)) & edge(M)) & sequential(K,L)) & sequential(L,M)) & sequential(M,K)))).
fof(myForms, conjecture, ! [M] : (triangle(K,L,M) <=> (((((edge(K) & edge(L)) & edge(M)) & sequential(K,L)) & sequential(L,M)) & sequential(M,K)))).
fof(myForms, conjecture, (triangle(K,L,M) <=> (((((edge(K) & edge(L)) & edge(M)) & sequential(K,L)) & sequential(L,M)) & sequential(M,K)))).
fof(myForms, conjecture, triangle(K,L,M)).
fof(myForms, conjecture, (((((edge(K) & edge(L)) & edge(M)) & sequential(K,L)) & sequential(L,M)) & sequential(M,K))).
fof(myForms, conjecture, ((((edge(K) & edge(L)) & edge(M)) & sequential(K,L)) & sequential(L,M))).
fof(myForms, conjecture, (((edge(K) & edge(L)) & edge(M)) & sequential(K,L))).
fof(myForms, conjecture, ((edge(K) & edge(L)) & edge(M))).
fof(myForms, conjecture, (edge(K) & edge(L))).
fof(myForms, conjecture, edge(K)).
fof(myForms, conjecture, edge(L)).
fof(myForms, conjecture, edge(M)).
fof(myForms, conjecture, sequential(K,L)).
fof(myForms, conjecture, sequential(L,M)).
fof(myForms, conjecture, sequential(M,K)).