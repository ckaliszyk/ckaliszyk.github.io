fof(myForms, conjecture, (equal_set(F,intersection(F,I)) <=> subset(F,I))).
fof(myForms, conjecture, equal_set(F,intersection(F,I))).
fof(myForms, conjecture, subset(F,I)).