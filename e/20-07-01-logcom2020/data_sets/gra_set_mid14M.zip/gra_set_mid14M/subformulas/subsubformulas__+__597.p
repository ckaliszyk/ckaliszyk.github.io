fof(myForms, conjecture, ! [Z] : ! [Q] : ((total_order(C1,Z) & max(Q,C1,Z)) => greatest(Q,C1,Z))).
fof(myForms, conjecture, ! [Q] : ((total_order(C1,Z) & max(Q,C1,Z)) => greatest(Q,C1,Z))).
fof(myForms, conjecture, ((total_order(C1,Z) & max(Q,C1,Z)) => greatest(Q,C1,Z))).
fof(myForms, conjecture, (total_order(C1,Z) & max(Q,C1,Z))).
fof(myForms, conjecture, total_order(C1,Z)).
fof(myForms, conjecture, max(Q,C1,Z)).
fof(myForms, conjecture, greatest(Q,C1,Z)).