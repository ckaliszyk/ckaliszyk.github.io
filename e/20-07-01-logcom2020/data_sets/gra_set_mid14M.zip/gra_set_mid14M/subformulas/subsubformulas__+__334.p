fof(myForms, conjecture, ! [R] : ((singleton(A1)=singleton(R) & member(R,universal_class)) => A1=R)).
fof(myForms, conjecture, ((singleton(A1)=singleton(R) & member(R,universal_class)) => A1=R)).
fof(myForms, conjecture, (singleton(A1)=singleton(R) & member(R,universal_class))).
fof(myForms, conjecture, singleton(A1)=singleton(R)).
fof(myForms, conjecture, member(R,universal_class)).
fof(myForms, conjecture, A1=R).