fof(myForms, conjecture, ! [I] : (ilf_type(I,set_type) => ! [B] : (ilf_type(B,set_type) => ! [Y] : (ilf_type(Y,set_type) => ! [Z] : (ilf_type(Z,relation_type(I,B)) => ilf_type(restrict4(I,B,Y,Z),relation_type(I,B))))))).
fof(myForms, conjecture, (ilf_type(I,set_type) => ! [B] : (ilf_type(B,set_type) => ! [Y] : (ilf_type(Y,set_type) => ! [Z] : (ilf_type(Z,relation_type(I,B)) => ilf_type(restrict4(I,B,Y,Z),relation_type(I,B))))))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [B] : (ilf_type(B,set_type) => ! [Y] : (ilf_type(Y,set_type) => ! [Z] : (ilf_type(Z,relation_type(I,B)) => ilf_type(restrict4(I,B,Y,Z),relation_type(I,B)))))).
fof(myForms, conjecture, (ilf_type(B,set_type) => ! [Y] : (ilf_type(Y,set_type) => ! [Z] : (ilf_type(Z,relation_type(I,B)) => ilf_type(restrict4(I,B,Y,Z),relation_type(I,B)))))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ! [Y] : (ilf_type(Y,set_type) => ! [Z] : (ilf_type(Z,relation_type(I,B)) => ilf_type(restrict4(I,B,Y,Z),relation_type(I,B))))).
fof(myForms, conjecture, (ilf_type(Y,set_type) => ! [Z] : (ilf_type(Z,relation_type(I,B)) => ilf_type(restrict4(I,B,Y,Z),relation_type(I,B))))).
fof(myForms, conjecture, ilf_type(Y,set_type)).
fof(myForms, conjecture, ! [Z] : (ilf_type(Z,relation_type(I,B)) => ilf_type(restrict4(I,B,Y,Z),relation_type(I,B)))).
fof(myForms, conjecture, (ilf_type(Z,relation_type(I,B)) => ilf_type(restrict4(I,B,Y,Z),relation_type(I,B)))).
fof(myForms, conjecture, ilf_type(Z,relation_type(I,B))).
fof(myForms, conjecture, ilf_type(restrict4(I,B,Y,Z),relation_type(I,B))).