fof(myForms, conjecture, (Y=B | disjoint(B,Y))).
fof(myForms, conjecture, Y=B).
fof(myForms, conjecture, disjoint(B,Y)).