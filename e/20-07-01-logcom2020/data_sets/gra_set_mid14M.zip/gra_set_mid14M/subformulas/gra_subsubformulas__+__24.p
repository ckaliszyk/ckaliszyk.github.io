fof(myForms, conjecture, (? [M] : ((edge(M) & tail_of(M)=tail_of(K)) & head_of(M)=head_of(L)) <=> ? [M] : ((edge(M) & tail_of(M)=head_of(L)) & tail_of(K)=head_of(M)))).
fof(myForms, conjecture, ? [M] : ((edge(M) & tail_of(M)=tail_of(K)) & head_of(M)=head_of(L))).
fof(myForms, conjecture, ((edge(M) & tail_of(M)=tail_of(K)) & head_of(M)=head_of(L))).
fof(myForms, conjecture, (edge(M) & tail_of(M)=tail_of(K))).
fof(myForms, conjecture, edge(M)).
fof(myForms, conjecture, tail_of(M)=tail_of(K)).
fof(myForms, conjecture, head_of(M)=head_of(L)).
fof(myForms, conjecture, ? [M] : ((edge(M) & tail_of(M)=head_of(L)) & tail_of(K)=head_of(M))).
fof(myForms, conjecture, ((edge(M) & tail_of(M)=head_of(L)) & tail_of(K)=head_of(M))).
fof(myForms, conjecture, (edge(M) & tail_of(M)=head_of(L))).
fof(myForms, conjecture, edge(M)).
fof(myForms, conjecture, tail_of(M)=head_of(L)).
fof(myForms, conjecture, tail_of(K)=head_of(M)).