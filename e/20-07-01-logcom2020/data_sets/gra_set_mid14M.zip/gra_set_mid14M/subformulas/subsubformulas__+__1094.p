fof(myForms, conjecture, ! [B] : (ilf_type(B,set_type) => (subset(I,B) <=> ! [Y] : (ilf_type(Y,set_type) => (member(Y,I) => member(Y,B)))))).
fof(myForms, conjecture, (ilf_type(B,set_type) => (subset(I,B) <=> ! [Y] : (ilf_type(Y,set_type) => (member(Y,I) => member(Y,B)))))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, (subset(I,B) <=> ! [Y] : (ilf_type(Y,set_type) => (member(Y,I) => member(Y,B))))).
fof(myForms, conjecture, subset(I,B)).
fof(myForms, conjecture, ! [Y] : (ilf_type(Y,set_type) => (member(Y,I) => member(Y,B)))).
fof(myForms, conjecture, (ilf_type(Y,set_type) => (member(Y,I) => member(Y,B)))).
fof(myForms, conjecture, ilf_type(Y,set_type)).
fof(myForms, conjecture, (member(Y,I) => member(Y,B))).
fof(myForms, conjecture, member(Y,I)).
fof(myForms, conjecture, member(Y,B)).