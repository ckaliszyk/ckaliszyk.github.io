fof(myForms, conjecture, ! [F] : ! [I] : ! [B] : ~ ((in(F,cartesian_product2(I,B)) & ! [Y] : ! [Z] : ~ ordered_pair(Y,Z)=F))).
fof(myForms, conjecture, ! [I] : ! [B] : ~ ((in(F,cartesian_product2(I,B)) & ! [Y] : ! [Z] : ~ ordered_pair(Y,Z)=F))).
fof(myForms, conjecture, ! [B] : ~ ((in(F,cartesian_product2(I,B)) & ! [Y] : ! [Z] : ~ ordered_pair(Y,Z)=F))).
fof(myForms, conjecture, ~ ((in(F,cartesian_product2(I,B)) & ! [Y] : ! [Z] : ~ ordered_pair(Y,Z)=F))).
fof(myForms, conjecture, (in(F,cartesian_product2(I,B)) & ! [Y] : ! [Z] : ~ ordered_pair(Y,Z)=F)).
fof(myForms, conjecture, in(F,cartesian_product2(I,B))).
fof(myForms, conjecture, ! [Y] : ! [Z] : ~ ordered_pair(Y,Z)=F).
fof(myForms, conjecture, ! [Z] : ~ ordered_pair(Y,Z)=F).
fof(myForms, conjecture, ~ ordered_pair(Y,Z)=F).
fof(myForms, conjecture, ordered_pair(Y,Z)=F).