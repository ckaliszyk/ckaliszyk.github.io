fof(myForms, conjecture, (subset(I,cross_product(B,Y)) => ilf_type(I,relation_type(B,Y)))).
fof(myForms, conjecture, subset(I,cross_product(B,Y))).
fof(myForms, conjecture, ilf_type(I,relation_type(B,Y))).