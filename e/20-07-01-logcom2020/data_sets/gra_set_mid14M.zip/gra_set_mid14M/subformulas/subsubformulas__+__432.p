fof(myForms, conjecture, ! [B] : (unordered_pair(F,I)=B <=> ! [Y] : (in(Y,B) <=> (Y=F | Y=I)))).
fof(myForms, conjecture, (unordered_pair(F,I)=B <=> ! [Y] : (in(Y,B) <=> (Y=F | Y=I)))).
fof(myForms, conjecture, unordered_pair(F,I)=B).
fof(myForms, conjecture, ! [Y] : (in(Y,B) <=> (Y=F | Y=I))).
fof(myForms, conjecture, (in(Y,B) <=> (Y=F | Y=I))).
fof(myForms, conjecture, in(Y,B)).
fof(myForms, conjecture, (Y=F | Y=I)).
fof(myForms, conjecture, Y=F).
fof(myForms, conjecture, Y=I).