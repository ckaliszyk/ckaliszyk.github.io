fof(myForms, conjecture, ! [I] : (~ empty(F) => ~ empty(set_union2(F,I)))).
fof(myForms, conjecture, (~ empty(F) => ~ empty(set_union2(F,I)))).
fof(myForms, conjecture, ~ empty(F)).
fof(myForms, conjecture, empty(F)).
fof(myForms, conjecture, ~ empty(set_union2(F,I))).
fof(myForms, conjecture, empty(set_union2(F,I))).