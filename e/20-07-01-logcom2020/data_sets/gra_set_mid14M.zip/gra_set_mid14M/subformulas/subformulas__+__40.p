fof(myForms, conjecture, ! [D] : ! [F] : ! [I] : (intersect(D,intersection(F,I)) => intersect(D,F))).
fof(myForms, conjecture, ! [F] : ! [I] : (intersect(D,intersection(F,I)) => intersect(D,F))).
fof(myForms, conjecture, ! [I] : (intersect(D,intersection(F,I)) => intersect(D,F))).
fof(myForms, conjecture, (intersect(D,intersection(F,I)) => intersect(D,F))).
fof(myForms, conjecture, intersect(D,intersection(F,I))).
fof(myForms, conjecture, intersect(D,F)).