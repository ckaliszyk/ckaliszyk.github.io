fof(myForms, conjecture, ! [I] : (ilf_type(I,set_type) => ! [B] : (ilf_type(B,set_type) => ! [Y] : (ilf_type(Y,relation_type(B,I)) => (ilf_type(Y,relation_type(B,empty_set)) => empty_set=Y))))).
fof(myForms, conjecture, (ilf_type(I,set_type) => ! [B] : (ilf_type(B,set_type) => ! [Y] : (ilf_type(Y,relation_type(B,I)) => (ilf_type(Y,relation_type(B,empty_set)) => empty_set=Y))))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [B] : (ilf_type(B,set_type) => ! [Y] : (ilf_type(Y,relation_type(B,I)) => (ilf_type(Y,relation_type(B,empty_set)) => empty_set=Y)))).
fof(myForms, conjecture, (ilf_type(B,set_type) => ! [Y] : (ilf_type(Y,relation_type(B,I)) => (ilf_type(Y,relation_type(B,empty_set)) => empty_set=Y)))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ! [Y] : (ilf_type(Y,relation_type(B,I)) => (ilf_type(Y,relation_type(B,empty_set)) => empty_set=Y))).
fof(myForms, conjecture, (ilf_type(Y,relation_type(B,I)) => (ilf_type(Y,relation_type(B,empty_set)) => empty_set=Y))).
fof(myForms, conjecture, ilf_type(Y,relation_type(B,I))).
fof(myForms, conjecture, (ilf_type(Y,relation_type(B,empty_set)) => empty_set=Y)).
fof(myForms, conjecture, ilf_type(Y,relation_type(B,empty_set))).
fof(myForms, conjecture, empty_set=Y).