fof(myForms, conjecture, (complete => ! [G] : ! [E] : ! [F] : ((path(E,F,G) & ! [B] : ! [C] : (((on_path(B,G) & on_path(C,G)) & sequential(B,C)) => ? [D] : triangle(B,C,D))) => number_of_in(triangles,G)=number_of_in(sequential_pairs,G)))).
fof(myForms, conjecture, complete).
fof(myForms, conjecture, ! [G] : ! [E] : ! [F] : ((path(E,F,G) & ! [B] : ! [C] : (((on_path(B,G) & on_path(C,G)) & sequential(B,C)) => ? [D] : triangle(B,C,D))) => number_of_in(triangles,G)=number_of_in(sequential_pairs,G))).
fof(myForms, conjecture, ! [E] : ! [F] : ((path(E,F,G) & ! [B] : ! [C] : (((on_path(B,G) & on_path(C,G)) & sequential(B,C)) => ? [D] : triangle(B,C,D))) => number_of_in(triangles,G)=number_of_in(sequential_pairs,G))).
fof(myForms, conjecture, ! [F] : ((path(E,F,G) & ! [B] : ! [C] : (((on_path(B,G) & on_path(C,G)) & sequential(B,C)) => ? [D] : triangle(B,C,D))) => number_of_in(triangles,G)=number_of_in(sequential_pairs,G))).
fof(myForms, conjecture, ((path(E,F,G) & ! [B] : ! [C] : (((on_path(B,G) & on_path(C,G)) & sequential(B,C)) => ? [D] : triangle(B,C,D))) => number_of_in(triangles,G)=number_of_in(sequential_pairs,G))).
fof(myForms, conjecture, (path(E,F,G) & ! [B] : ! [C] : (((on_path(B,G) & on_path(C,G)) & sequential(B,C)) => ? [D] : triangle(B,C,D)))).
fof(myForms, conjecture, path(E,F,G)).
fof(myForms, conjecture, ! [B] : ! [C] : (((on_path(B,G) & on_path(C,G)) & sequential(B,C)) => ? [D] : triangle(B,C,D))).
fof(myForms, conjecture, ! [C] : (((on_path(B,G) & on_path(C,G)) & sequential(B,C)) => ? [D] : triangle(B,C,D))).
fof(myForms, conjecture, (((on_path(B,G) & on_path(C,G)) & sequential(B,C)) => ? [D] : triangle(B,C,D))).
fof(myForms, conjecture, ((on_path(B,G) & on_path(C,G)) & sequential(B,C))).
fof(myForms, conjecture, (on_path(B,G) & on_path(C,G))).
fof(myForms, conjecture, on_path(B,G)).
fof(myForms, conjecture, on_path(C,G)).
fof(myForms, conjecture, sequential(B,C)).
fof(myForms, conjecture, ? [D] : triangle(B,C,D)).
fof(myForms, conjecture, triangle(B,C,D)).
fof(myForms, conjecture, number_of_in(triangles,G)=number_of_in(sequential_pairs,G)).