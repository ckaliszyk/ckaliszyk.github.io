fof(myForms, conjecture, (((((((((((((green(Q,R) & green(Q,S)) & green(R,S)) & green(Q,T)) & green(R,T)) & green(S,T)) & green(Q,U)) & green(R,U)) & green(S,U)) & green(T,U)) & green(Q,V)) & green(R,V)) & green(S,V)) & green(T,V))).
fof(myForms, conjecture, ((((((((((((green(Q,R) & green(Q,S)) & green(R,S)) & green(Q,T)) & green(R,T)) & green(S,T)) & green(Q,U)) & green(R,U)) & green(S,U)) & green(T,U)) & green(Q,V)) & green(R,V)) & green(S,V))).
fof(myForms, conjecture, (((((((((((green(Q,R) & green(Q,S)) & green(R,S)) & green(Q,T)) & green(R,T)) & green(S,T)) & green(Q,U)) & green(R,U)) & green(S,U)) & green(T,U)) & green(Q,V)) & green(R,V))).
fof(myForms, conjecture, ((((((((((green(Q,R) & green(Q,S)) & green(R,S)) & green(Q,T)) & green(R,T)) & green(S,T)) & green(Q,U)) & green(R,U)) & green(S,U)) & green(T,U)) & green(Q,V))).
fof(myForms, conjecture, (((((((((green(Q,R) & green(Q,S)) & green(R,S)) & green(Q,T)) & green(R,T)) & green(S,T)) & green(Q,U)) & green(R,U)) & green(S,U)) & green(T,U))).
fof(myForms, conjecture, ((((((((green(Q,R) & green(Q,S)) & green(R,S)) & green(Q,T)) & green(R,T)) & green(S,T)) & green(Q,U)) & green(R,U)) & green(S,U))).
fof(myForms, conjecture, (((((((green(Q,R) & green(Q,S)) & green(R,S)) & green(Q,T)) & green(R,T)) & green(S,T)) & green(Q,U)) & green(R,U))).
fof(myForms, conjecture, ((((((green(Q,R) & green(Q,S)) & green(R,S)) & green(Q,T)) & green(R,T)) & green(S,T)) & green(Q,U))).
fof(myForms, conjecture, (((((green(Q,R) & green(Q,S)) & green(R,S)) & green(Q,T)) & green(R,T)) & green(S,T))).
fof(myForms, conjecture, ((((green(Q,R) & green(Q,S)) & green(R,S)) & green(Q,T)) & green(R,T))).
fof(myForms, conjecture, (((green(Q,R) & green(Q,S)) & green(R,S)) & green(Q,T))).
fof(myForms, conjecture, ((green(Q,R) & green(Q,S)) & green(R,S))).
fof(myForms, conjecture, (green(Q,R) & green(Q,S))).
fof(myForms, conjecture, green(Q,R)).
fof(myForms, conjecture, green(Q,S)).
fof(myForms, conjecture, green(R,S)).
fof(myForms, conjecture, green(Q,T)).
fof(myForms, conjecture, green(R,T)).
fof(myForms, conjecture, green(S,T)).
fof(myForms, conjecture, green(Q,U)).
fof(myForms, conjecture, green(R,U)).
fof(myForms, conjecture, green(S,U)).
fof(myForms, conjecture, green(T,U)).
fof(myForms, conjecture, green(Q,V)).
fof(myForms, conjecture, green(R,V)).
fof(myForms, conjecture, green(S,V)).
fof(myForms, conjecture, green(T,V)).