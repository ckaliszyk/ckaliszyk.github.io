fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => subset(D,D))).
fof(myForms, conjecture, (ilf_type(D,set_type) => subset(D,D))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, subset(D,D)).