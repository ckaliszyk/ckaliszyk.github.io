fof(myForms, conjecture, ! [Y] : (ilf_type(Y,relation_type(I,B)) => (subset(domain_of(Y),I) & subset(range_of(Y),B)))).
fof(myForms, conjecture, (ilf_type(Y,relation_type(I,B)) => (subset(domain_of(Y),I) & subset(range_of(Y),B)))).
fof(myForms, conjecture, ilf_type(Y,relation_type(I,B))).
fof(myForms, conjecture, (subset(domain_of(Y),I) & subset(range_of(Y),B))).
fof(myForms, conjecture, subset(domain_of(Y),I)).
fof(myForms, conjecture, subset(range_of(Y),B)).