fof(myForms, conjecture, ! [N] : ! [O] : ! [P] : (path(N,O,P) => number_of_in(edges,P)=length_of(P))).
fof(myForms, conjecture, ! [O] : ! [P] : (path(N,O,P) => number_of_in(edges,P)=length_of(P))).
fof(myForms, conjecture, ! [P] : (path(N,O,P) => number_of_in(edges,P)=length_of(P))).
fof(myForms, conjecture, (path(N,O,P) => number_of_in(edges,P)=length_of(P))).
fof(myForms, conjecture, path(N,O,P)).
fof(myForms, conjecture, number_of_in(edges,P)=length_of(P)).