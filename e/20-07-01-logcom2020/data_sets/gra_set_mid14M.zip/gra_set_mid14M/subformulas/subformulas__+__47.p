fof(myForms, conjecture, ? [C] : ~ empty(C)).
fof(myForms, conjecture, ~ empty(C)).
fof(myForms, conjecture, empty(C)).