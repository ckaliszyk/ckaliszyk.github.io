fof(myForms, conjecture, ! [O] : ! [K] : ! [L] : ! [P] : ((shortest_path(N,O,P) & precedes(K,L,P)) => ((((((vertex(N) & vertex(O)) & ~ O=N) & edge(K)) & edge(L)) & ~ L=K) & path(N,O,P)))).
fof(myForms, conjecture, ! [K] : ! [L] : ! [P] : ((shortest_path(N,O,P) & precedes(K,L,P)) => ((((((vertex(N) & vertex(O)) & ~ O=N) & edge(K)) & edge(L)) & ~ L=K) & path(N,O,P)))).
fof(myForms, conjecture, ! [L] : ! [P] : ((shortest_path(N,O,P) & precedes(K,L,P)) => ((((((vertex(N) & vertex(O)) & ~ O=N) & edge(K)) & edge(L)) & ~ L=K) & path(N,O,P)))).
fof(myForms, conjecture, ! [P] : ((shortest_path(N,O,P) & precedes(K,L,P)) => ((((((vertex(N) & vertex(O)) & ~ O=N) & edge(K)) & edge(L)) & ~ L=K) & path(N,O,P)))).
fof(myForms, conjecture, ((shortest_path(N,O,P) & precedes(K,L,P)) => ((((((vertex(N) & vertex(O)) & ~ O=N) & edge(K)) & edge(L)) & ~ L=K) & path(N,O,P)))).
fof(myForms, conjecture, (shortest_path(N,O,P) & precedes(K,L,P))).
fof(myForms, conjecture, shortest_path(N,O,P)).
fof(myForms, conjecture, precedes(K,L,P)).
fof(myForms, conjecture, ((((((vertex(N) & vertex(O)) & ~ O=N) & edge(K)) & edge(L)) & ~ L=K) & path(N,O,P))).
fof(myForms, conjecture, (((((vertex(N) & vertex(O)) & ~ O=N) & edge(K)) & edge(L)) & ~ L=K)).
fof(myForms, conjecture, ((((vertex(N) & vertex(O)) & ~ O=N) & edge(K)) & edge(L))).
fof(myForms, conjecture, (((vertex(N) & vertex(O)) & ~ O=N) & edge(K))).
fof(myForms, conjecture, ((vertex(N) & vertex(O)) & ~ O=N)).
fof(myForms, conjecture, (vertex(N) & vertex(O))).
fof(myForms, conjecture, vertex(N)).
fof(myForms, conjecture, vertex(O)).
fof(myForms, conjecture, ~ O=N).
fof(myForms, conjecture, O=N).
fof(myForms, conjecture, edge(K)).
fof(myForms, conjecture, edge(L)).
fof(myForms, conjecture, ~ L=K).
fof(myForms, conjecture, L=K).
fof(myForms, conjecture, path(N,O,P)).