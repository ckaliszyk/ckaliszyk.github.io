fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,subset_type(cross_product(D,F))) => relation_like(I))))).
fof(myForms, conjecture, (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,subset_type(cross_product(D,F))) => relation_like(I))))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,subset_type(cross_product(D,F))) => relation_like(I)))).
fof(myForms, conjecture, (ilf_type(F,set_type) => ! [I] : (ilf_type(I,subset_type(cross_product(D,F))) => relation_like(I)))).
fof(myForms, conjecture, ilf_type(F,set_type)).
fof(myForms, conjecture, ! [I] : (ilf_type(I,subset_type(cross_product(D,F))) => relation_like(I))).
fof(myForms, conjecture, (ilf_type(I,subset_type(cross_product(D,F))) => relation_like(I))).
fof(myForms, conjecture, ilf_type(I,subset_type(cross_product(D,F)))).
fof(myForms, conjecture, relation_like(I)).