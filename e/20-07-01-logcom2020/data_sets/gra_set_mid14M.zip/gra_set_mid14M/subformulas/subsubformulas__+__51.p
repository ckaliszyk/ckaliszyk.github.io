fof(myForms, conjecture, ! [B] : ! [Y] : ((subset(I,B) & subset(B,Y)) => subset(I,Y))).
fof(myForms, conjecture, ! [Y] : ((subset(I,B) & subset(B,Y)) => subset(I,Y))).
fof(myForms, conjecture, ((subset(I,B) & subset(B,Y)) => subset(I,Y))).
fof(myForms, conjecture, (subset(I,B) & subset(B,Y))).
fof(myForms, conjecture, subset(I,B)).
fof(myForms, conjecture, subset(B,Y)).
fof(myForms, conjecture, subset(I,Y)).