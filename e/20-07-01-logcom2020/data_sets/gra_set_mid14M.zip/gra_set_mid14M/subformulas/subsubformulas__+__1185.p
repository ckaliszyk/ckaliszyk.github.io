fof(myForms, conjecture, ! [I] : set_union2(F,F)=F).
fof(myForms, conjecture, set_union2(F,F)=F).