fof(myForms, conjecture, ! [C] : ! [D] : set_union2(D,C)=set_union2(C,D)).
fof(myForms, conjecture, ! [D] : set_union2(D,C)=set_union2(C,D)).
fof(myForms, conjecture, set_union2(D,C)=set_union2(C,D)).