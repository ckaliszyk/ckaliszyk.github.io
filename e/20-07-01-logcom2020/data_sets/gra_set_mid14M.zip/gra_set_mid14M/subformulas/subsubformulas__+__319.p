fof(myForms, conjecture, (ilf_type(Y,relation_type(I,B)) => ilf_type(range(I,B,Y),subset_type(B)))).
fof(myForms, conjecture, ilf_type(Y,relation_type(I,B))).
fof(myForms, conjecture, ilf_type(range(I,B,Y),subset_type(B))).