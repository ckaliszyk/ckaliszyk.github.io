fof(myForms, conjecture, ! [E] : ! [F] : ! [G] : (path(E,F,G) => number_of_in(edges,G)=length_of(G))).
fof(myForms, conjecture, ! [F] : ! [G] : (path(E,F,G) => number_of_in(edges,G)=length_of(G))).
fof(myForms, conjecture, ! [G] : (path(E,F,G) => number_of_in(edges,G)=length_of(G))).
fof(myForms, conjecture, (path(E,F,G) => number_of_in(edges,G)=length_of(G))).
fof(myForms, conjecture, path(E,F,G)).
fof(myForms, conjecture, number_of_in(edges,G)=length_of(G)).