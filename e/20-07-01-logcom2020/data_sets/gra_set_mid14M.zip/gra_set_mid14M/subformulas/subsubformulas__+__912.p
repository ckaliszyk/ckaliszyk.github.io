fof(myForms, conjecture, (empty(I) & ilf_type(I,set_type))).
fof(myForms, conjecture, empty(I)).
fof(myForms, conjecture, ilf_type(I,set_type)).