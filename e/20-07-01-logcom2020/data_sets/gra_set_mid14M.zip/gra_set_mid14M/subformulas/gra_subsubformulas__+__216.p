fof(myForms, conjecture, ! [S] : ! [T] : ! [U] : ((((((((((green(Q,R) & green(Q,S)) & green(R,S)) & green(Q,T)) & green(R,T)) & green(S,T)) & green(Q,U)) & green(R,U)) & green(S,U)) & green(T,U)) => goal)).
fof(myForms, conjecture, ! [T] : ! [U] : ((((((((((green(Q,R) & green(Q,S)) & green(R,S)) & green(Q,T)) & green(R,T)) & green(S,T)) & green(Q,U)) & green(R,U)) & green(S,U)) & green(T,U)) => goal)).
fof(myForms, conjecture, ! [U] : ((((((((((green(Q,R) & green(Q,S)) & green(R,S)) & green(Q,T)) & green(R,T)) & green(S,T)) & green(Q,U)) & green(R,U)) & green(S,U)) & green(T,U)) => goal)).
fof(myForms, conjecture, ((((((((((green(Q,R) & green(Q,S)) & green(R,S)) & green(Q,T)) & green(R,T)) & green(S,T)) & green(Q,U)) & green(R,U)) & green(S,U)) & green(T,U)) => goal)).
fof(myForms, conjecture, (((((((((green(Q,R) & green(Q,S)) & green(R,S)) & green(Q,T)) & green(R,T)) & green(S,T)) & green(Q,U)) & green(R,U)) & green(S,U)) & green(T,U))).
fof(myForms, conjecture, ((((((((green(Q,R) & green(Q,S)) & green(R,S)) & green(Q,T)) & green(R,T)) & green(S,T)) & green(Q,U)) & green(R,U)) & green(S,U))).
fof(myForms, conjecture, (((((((green(Q,R) & green(Q,S)) & green(R,S)) & green(Q,T)) & green(R,T)) & green(S,T)) & green(Q,U)) & green(R,U))).
fof(myForms, conjecture, ((((((green(Q,R) & green(Q,S)) & green(R,S)) & green(Q,T)) & green(R,T)) & green(S,T)) & green(Q,U))).
fof(myForms, conjecture, (((((green(Q,R) & green(Q,S)) & green(R,S)) & green(Q,T)) & green(R,T)) & green(S,T))).
fof(myForms, conjecture, ((((green(Q,R) & green(Q,S)) & green(R,S)) & green(Q,T)) & green(R,T))).
fof(myForms, conjecture, (((green(Q,R) & green(Q,S)) & green(R,S)) & green(Q,T))).
fof(myForms, conjecture, ((green(Q,R) & green(Q,S)) & green(R,S))).
fof(myForms, conjecture, (green(Q,R) & green(Q,S))).
fof(myForms, conjecture, green(Q,R)).
fof(myForms, conjecture, green(Q,S)).
fof(myForms, conjecture, green(R,S)).
fof(myForms, conjecture, green(Q,T)).
fof(myForms, conjecture, green(R,T)).
fof(myForms, conjecture, green(S,T)).
fof(myForms, conjecture, green(Q,U)).
fof(myForms, conjecture, green(R,U)).
fof(myForms, conjecture, green(S,U)).
fof(myForms, conjecture, green(T,U)).
fof(myForms, conjecture, goal).