fof(myForms, conjecture, (ilf_type(B,set_type) => ! [Y] : (ilf_type(Y,relation_type(I,B)) => ! [Z] : (ilf_type(Z,set_type) => ilf_type(inverse4(I,B,Y,Z),subset_type(I)))))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ! [Y] : (ilf_type(Y,relation_type(I,B)) => ! [Z] : (ilf_type(Z,set_type) => ilf_type(inverse4(I,B,Y,Z),subset_type(I))))).
fof(myForms, conjecture, (ilf_type(Y,relation_type(I,B)) => ! [Z] : (ilf_type(Z,set_type) => ilf_type(inverse4(I,B,Y,Z),subset_type(I))))).
fof(myForms, conjecture, ilf_type(Y,relation_type(I,B))).
fof(myForms, conjecture, ! [Z] : (ilf_type(Z,set_type) => ilf_type(inverse4(I,B,Y,Z),subset_type(I)))).
fof(myForms, conjecture, (ilf_type(Z,set_type) => ilf_type(inverse4(I,B,Y,Z),subset_type(I)))).
fof(myForms, conjecture, ilf_type(Z,set_type)).
fof(myForms, conjecture, ilf_type(inverse4(I,B,Y,Z),subset_type(I))).