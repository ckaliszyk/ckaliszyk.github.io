fof(myForms, conjecture, ((((subset(F,I) & ~ equal_set(F,I)) & subset(I,B)) & ~ equal_set(I,B)) => ~ equal_set(F,B))).
fof(myForms, conjecture, (((subset(F,I) & ~ equal_set(F,I)) & subset(I,B)) & ~ equal_set(I,B))).
fof(myForms, conjecture, ((subset(F,I) & ~ equal_set(F,I)) & subset(I,B))).
fof(myForms, conjecture, (subset(F,I) & ~ equal_set(F,I))).
fof(myForms, conjecture, subset(F,I)).
fof(myForms, conjecture, ~ equal_set(F,I)).
fof(myForms, conjecture, equal_set(F,I)).
fof(myForms, conjecture, subset(I,B)).
fof(myForms, conjecture, ~ equal_set(I,B)).
fof(myForms, conjecture, equal_set(I,B)).
fof(myForms, conjecture, ~ equal_set(F,B)).
fof(myForms, conjecture, equal_set(F,B)).