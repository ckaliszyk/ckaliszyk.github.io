fof(myForms, conjecture, ! [I] : (subset(F,I) => subset(union(F),union(I)))).
fof(myForms, conjecture, (subset(F,I) => subset(union(F),union(I)))).
fof(myForms, conjecture, subset(F,I)).
fof(myForms, conjecture, subset(union(F),union(I))).