fof(myForms, conjecture, ! [Z] : (ilf_type(Z,relation_type(I,B)) => ilf_type(Z,subset_type(cross_product(I,B))))).
fof(myForms, conjecture, (ilf_type(Z,relation_type(I,B)) => ilf_type(Z,subset_type(cross_product(I,B))))).
fof(myForms, conjecture, ilf_type(Z,relation_type(I,B))).
fof(myForms, conjecture, ilf_type(Z,subset_type(cross_product(I,B)))).