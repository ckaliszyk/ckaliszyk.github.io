fof(myForms, conjecture, ! [C] : ! [D] : (set_difference(singleton(C),D)=empty_set <=> in(C,D))).
fof(myForms, conjecture, ! [D] : (set_difference(singleton(C),D)=empty_set <=> in(C,D))).
fof(myForms, conjecture, (set_difference(singleton(C),D)=empty_set <=> in(C,D))).
fof(myForms, conjecture, set_difference(singleton(C),D)=empty_set).
fof(myForms, conjecture, in(C,D)).