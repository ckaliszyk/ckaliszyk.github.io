fof(myForms, conjecture, ((~ empty(I) & ilf_type(I,set_type)) => ! [B] : ((~ empty(B) & ilf_type(B,set_type)) => ! [Y] : ((~ empty(Y) & ilf_type(Y,set_type)) => ! [Z] : (ilf_type(Z,relation_type(I,Y)) => ! [D] : (ilf_type(D,member_type(I)) => (member(D,inverse4(I,Y,Z,B)) <=> ? [J] : ((ilf_type(J,member_type(Y)) & member(ordered_pair(D,J),Z)) & member(J,B))))))))).
fof(myForms, conjecture, (~ empty(I) & ilf_type(I,set_type))).
fof(myForms, conjecture, ~ empty(I)).
fof(myForms, conjecture, empty(I)).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [B] : ((~ empty(B) & ilf_type(B,set_type)) => ! [Y] : ((~ empty(Y) & ilf_type(Y,set_type)) => ! [Z] : (ilf_type(Z,relation_type(I,Y)) => ! [D] : (ilf_type(D,member_type(I)) => (member(D,inverse4(I,Y,Z,B)) <=> ? [J] : ((ilf_type(J,member_type(Y)) & member(ordered_pair(D,J),Z)) & member(J,B)))))))).
fof(myForms, conjecture, ((~ empty(B) & ilf_type(B,set_type)) => ! [Y] : ((~ empty(Y) & ilf_type(Y,set_type)) => ! [Z] : (ilf_type(Z,relation_type(I,Y)) => ! [D] : (ilf_type(D,member_type(I)) => (member(D,inverse4(I,Y,Z,B)) <=> ? [J] : ((ilf_type(J,member_type(Y)) & member(ordered_pair(D,J),Z)) & member(J,B)))))))).
fof(myForms, conjecture, (~ empty(B) & ilf_type(B,set_type))).
fof(myForms, conjecture, ~ empty(B)).
fof(myForms, conjecture, empty(B)).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ! [Y] : ((~ empty(Y) & ilf_type(Y,set_type)) => ! [Z] : (ilf_type(Z,relation_type(I,Y)) => ! [D] : (ilf_type(D,member_type(I)) => (member(D,inverse4(I,Y,Z,B)) <=> ? [J] : ((ilf_type(J,member_type(Y)) & member(ordered_pair(D,J),Z)) & member(J,B))))))).
fof(myForms, conjecture, ((~ empty(Y) & ilf_type(Y,set_type)) => ! [Z] : (ilf_type(Z,relation_type(I,Y)) => ! [D] : (ilf_type(D,member_type(I)) => (member(D,inverse4(I,Y,Z,B)) <=> ? [J] : ((ilf_type(J,member_type(Y)) & member(ordered_pair(D,J),Z)) & member(J,B))))))).
fof(myForms, conjecture, (~ empty(Y) & ilf_type(Y,set_type))).
fof(myForms, conjecture, ~ empty(Y)).
fof(myForms, conjecture, empty(Y)).
fof(myForms, conjecture, ilf_type(Y,set_type)).
fof(myForms, conjecture, ! [Z] : (ilf_type(Z,relation_type(I,Y)) => ! [D] : (ilf_type(D,member_type(I)) => (member(D,inverse4(I,Y,Z,B)) <=> ? [J] : ((ilf_type(J,member_type(Y)) & member(ordered_pair(D,J),Z)) & member(J,B)))))).
fof(myForms, conjecture, (ilf_type(Z,relation_type(I,Y)) => ! [D] : (ilf_type(D,member_type(I)) => (member(D,inverse4(I,Y,Z,B)) <=> ? [J] : ((ilf_type(J,member_type(Y)) & member(ordered_pair(D,J),Z)) & member(J,B)))))).
fof(myForms, conjecture, ilf_type(Z,relation_type(I,Y))).
fof(myForms, conjecture, ! [D] : (ilf_type(D,member_type(I)) => (member(D,inverse4(I,Y,Z,B)) <=> ? [J] : ((ilf_type(J,member_type(Y)) & member(ordered_pair(D,J),Z)) & member(J,B))))).
fof(myForms, conjecture, (ilf_type(D,member_type(I)) => (member(D,inverse4(I,Y,Z,B)) <=> ? [J] : ((ilf_type(J,member_type(Y)) & member(ordered_pair(D,J),Z)) & member(J,B))))).
fof(myForms, conjecture, ilf_type(D,member_type(I))).
fof(myForms, conjecture, (member(D,inverse4(I,Y,Z,B)) <=> ? [J] : ((ilf_type(J,member_type(Y)) & member(ordered_pair(D,J),Z)) & member(J,B)))).
fof(myForms, conjecture, member(D,inverse4(I,Y,Z,B))).
fof(myForms, conjecture, ? [J] : ((ilf_type(J,member_type(Y)) & member(ordered_pair(D,J),Z)) & member(J,B))).
fof(myForms, conjecture, ((ilf_type(J,member_type(Y)) & member(ordered_pair(D,J),Z)) & member(J,B))).
fof(myForms, conjecture, (ilf_type(J,member_type(Y)) & member(ordered_pair(D,J),Z))).
fof(myForms, conjecture, ilf_type(J,member_type(Y))).
fof(myForms, conjecture, member(ordered_pair(D,J),Z)).
fof(myForms, conjecture, member(J,B)).