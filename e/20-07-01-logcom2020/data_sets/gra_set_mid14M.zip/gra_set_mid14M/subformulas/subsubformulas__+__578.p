fof(myForms, conjecture, (ilf_type(I,set_type) => (subset(I,empty_set) => empty_set=I))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, (subset(I,empty_set) => empty_set=I)).
fof(myForms, conjecture, subset(I,empty_set)).
fof(myForms, conjecture, empty_set=I).