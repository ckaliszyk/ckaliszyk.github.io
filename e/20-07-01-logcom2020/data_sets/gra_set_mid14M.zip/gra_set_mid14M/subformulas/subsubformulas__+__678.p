fof(myForms, conjecture, ! [I] : set_intersection2(F,F)=F).
fof(myForms, conjecture, set_intersection2(F,F)=F).