fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => (ordered_pair(Y,Z)=D <=> unordered_pair(unordered_pair(Y,Z),singleton(Y))=D))).
fof(myForms, conjecture, (ilf_type(D,set_type) => (ordered_pair(Y,Z)=D <=> unordered_pair(unordered_pair(Y,Z),singleton(Y))=D))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, (ordered_pair(Y,Z)=D <=> unordered_pair(unordered_pair(Y,Z),singleton(Y))=D)).
fof(myForms, conjecture, ordered_pair(Y,Z)=D).
fof(myForms, conjecture, unordered_pair(unordered_pair(Y,Z),singleton(Y))=D).