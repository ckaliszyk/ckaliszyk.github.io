fof(myForms, conjecture, ! [I] : ! [B] : ((((maps(D,F,I) & maps(J,I,B)) & surjective(D,F,I)) & surjective(J,I,B)) => surjective(compose_function(J,D,F,I,B),F,B))).
fof(myForms, conjecture, ! [B] : ((((maps(D,F,I) & maps(J,I,B)) & surjective(D,F,I)) & surjective(J,I,B)) => surjective(compose_function(J,D,F,I,B),F,B))).
fof(myForms, conjecture, ((((maps(D,F,I) & maps(J,I,B)) & surjective(D,F,I)) & surjective(J,I,B)) => surjective(compose_function(J,D,F,I,B),F,B))).
fof(myForms, conjecture, (((maps(D,F,I) & maps(J,I,B)) & surjective(D,F,I)) & surjective(J,I,B))).
fof(myForms, conjecture, ((maps(D,F,I) & maps(J,I,B)) & surjective(D,F,I))).
fof(myForms, conjecture, (maps(D,F,I) & maps(J,I,B))).
fof(myForms, conjecture, maps(D,F,I)).
fof(myForms, conjecture, maps(J,I,B)).
fof(myForms, conjecture, surjective(D,F,I)).
fof(myForms, conjecture, surjective(J,I,B)).
fof(myForms, conjecture, surjective(compose_function(J,D,F,I,B),F,B)).