fof(myForms, conjecture, ! [F] : (empty_set=F <=> ! [I] : ~ in(I,F))).
fof(myForms, conjecture, (empty_set=F <=> ! [I] : ~ in(I,F))).
fof(myForms, conjecture, empty_set=F).
fof(myForms, conjecture, ! [I] : ~ in(I,F)).
fof(myForms, conjecture, ~ in(I,F)).
fof(myForms, conjecture, in(I,F)).