fof(myForms, conjecture, ! [D] : ! [F] : (F=D <=> (subset(D,F) & subset(F,D)))).
fof(myForms, conjecture, ! [F] : (F=D <=> (subset(D,F) & subset(F,D)))).
fof(myForms, conjecture, (F=D <=> (subset(D,F) & subset(F,D)))).
fof(myForms, conjecture, F=D).
fof(myForms, conjecture, (subset(D,F) & subset(F,D))).
fof(myForms, conjecture, subset(D,F)).
fof(myForms, conjecture, subset(F,D)).