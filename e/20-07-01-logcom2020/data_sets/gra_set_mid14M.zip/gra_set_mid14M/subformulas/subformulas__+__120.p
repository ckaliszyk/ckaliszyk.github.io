fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,set_type) => ! [B] : (ilf_type(B,relation_type(D,F)) => (member(ordered_pair(I,J),B) => (member(I,D) & member(J,F))))))))).
fof(myForms, conjecture, (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,set_type) => ! [B] : (ilf_type(B,relation_type(D,F)) => (member(ordered_pair(I,J),B) => (member(I,D) & member(J,F))))))))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,set_type) => ! [B] : (ilf_type(B,relation_type(D,F)) => (member(ordered_pair(I,J),B) => (member(I,D) & member(J,F)))))))).
fof(myForms, conjecture, (ilf_type(F,set_type) => ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,set_type) => ! [B] : (ilf_type(B,relation_type(D,F)) => (member(ordered_pair(I,J),B) => (member(I,D) & member(J,F)))))))).
fof(myForms, conjecture, ilf_type(F,set_type)).
fof(myForms, conjecture, ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,set_type) => ! [B] : (ilf_type(B,relation_type(D,F)) => (member(ordered_pair(I,J),B) => (member(I,D) & member(J,F))))))).
fof(myForms, conjecture, (ilf_type(I,set_type) => ! [J] : (ilf_type(J,set_type) => ! [B] : (ilf_type(B,relation_type(D,F)) => (member(ordered_pair(I,J),B) => (member(I,D) & member(J,F))))))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [J] : (ilf_type(J,set_type) => ! [B] : (ilf_type(B,relation_type(D,F)) => (member(ordered_pair(I,J),B) => (member(I,D) & member(J,F)))))).
fof(myForms, conjecture, (ilf_type(J,set_type) => ! [B] : (ilf_type(B,relation_type(D,F)) => (member(ordered_pair(I,J),B) => (member(I,D) & member(J,F)))))).
fof(myForms, conjecture, ilf_type(J,set_type)).
fof(myForms, conjecture, ! [B] : (ilf_type(B,relation_type(D,F)) => (member(ordered_pair(I,J),B) => (member(I,D) & member(J,F))))).
fof(myForms, conjecture, (ilf_type(B,relation_type(D,F)) => (member(ordered_pair(I,J),B) => (member(I,D) & member(J,F))))).
fof(myForms, conjecture, ilf_type(B,relation_type(D,F))).
fof(myForms, conjecture, (member(ordered_pair(I,J),B) => (member(I,D) & member(J,F)))).
fof(myForms, conjecture, member(ordered_pair(I,J),B)).
fof(myForms, conjecture, (member(I,D) & member(J,F))).
fof(myForms, conjecture, member(I,D)).
fof(myForms, conjecture, member(J,F)).