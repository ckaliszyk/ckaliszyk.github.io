fof(myForms, conjecture, ! [I] : subset(empty_set,I)).
fof(myForms, conjecture, subset(empty_set,I)).