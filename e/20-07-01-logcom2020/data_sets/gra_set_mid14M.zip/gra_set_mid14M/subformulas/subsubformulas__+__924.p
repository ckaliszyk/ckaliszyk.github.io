fof(myForms, conjecture, (element(A1,R) <=> ~ (? [B1] : (element(A1,B1) & element(B1,A1))))).
fof(myForms, conjecture, element(A1,R)).
fof(myForms, conjecture, ~ (? [B1] : (element(A1,B1) & element(B1,A1)))).
fof(myForms, conjecture, ? [B1] : (element(A1,B1) & element(B1,A1))).
fof(myForms, conjecture, (element(A1,B1) & element(B1,A1))).
fof(myForms, conjecture, element(A1,B1)).
fof(myForms, conjecture, element(B1,A1)).