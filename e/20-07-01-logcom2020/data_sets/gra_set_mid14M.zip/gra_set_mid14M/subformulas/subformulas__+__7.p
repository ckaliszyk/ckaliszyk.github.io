fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,binary_relation_type) => (member(ordered_pair(F,I),restrict(D,J)) <=> (member(I,D) & member(ordered_pair(F,I),J)))))))).
fof(myForms, conjecture, (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,binary_relation_type) => (member(ordered_pair(F,I),restrict(D,J)) <=> (member(I,D) & member(ordered_pair(F,I),J)))))))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,binary_relation_type) => (member(ordered_pair(F,I),restrict(D,J)) <=> (member(I,D) & member(ordered_pair(F,I),J))))))).
fof(myForms, conjecture, (ilf_type(F,set_type) => ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,binary_relation_type) => (member(ordered_pair(F,I),restrict(D,J)) <=> (member(I,D) & member(ordered_pair(F,I),J))))))).
fof(myForms, conjecture, ilf_type(F,set_type)).
fof(myForms, conjecture, ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,binary_relation_type) => (member(ordered_pair(F,I),restrict(D,J)) <=> (member(I,D) & member(ordered_pair(F,I),J)))))).
fof(myForms, conjecture, (ilf_type(I,set_type) => ! [J] : (ilf_type(J,binary_relation_type) => (member(ordered_pair(F,I),restrict(D,J)) <=> (member(I,D) & member(ordered_pair(F,I),J)))))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [J] : (ilf_type(J,binary_relation_type) => (member(ordered_pair(F,I),restrict(D,J)) <=> (member(I,D) & member(ordered_pair(F,I),J))))).
fof(myForms, conjecture, (ilf_type(J,binary_relation_type) => (member(ordered_pair(F,I),restrict(D,J)) <=> (member(I,D) & member(ordered_pair(F,I),J))))).
fof(myForms, conjecture, ilf_type(J,binary_relation_type)).
fof(myForms, conjecture, (member(ordered_pair(F,I),restrict(D,J)) <=> (member(I,D) & member(ordered_pair(F,I),J)))).
fof(myForms, conjecture, member(ordered_pair(F,I),restrict(D,J))).
fof(myForms, conjecture, (member(I,D) & member(ordered_pair(F,I),J))).
fof(myForms, conjecture, member(I,D)).
fof(myForms, conjecture, member(ordered_pair(F,I),J)).