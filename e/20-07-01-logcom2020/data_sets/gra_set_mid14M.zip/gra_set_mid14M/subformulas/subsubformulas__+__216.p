fof(myForms, conjecture, (subclass(A1,null_class) => null_class=A1)).
fof(myForms, conjecture, subclass(A1,null_class)).
fof(myForms, conjecture, null_class=A1).