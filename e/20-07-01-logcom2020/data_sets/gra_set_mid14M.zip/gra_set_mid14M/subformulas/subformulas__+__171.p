fof(myForms, conjecture, (! [L] : ! [P] : (equalish(L,P) <=> ! [K] : (a_member_of(K,L) <=> a_member_of(K,P))) => ! [L] : ! [P] : (equalish(L,P) <=> equalish(P,L)))).
fof(myForms, conjecture, ! [L] : ! [P] : (equalish(L,P) <=> ! [K] : (a_member_of(K,L) <=> a_member_of(K,P)))).
fof(myForms, conjecture, ! [P] : (equalish(L,P) <=> ! [K] : (a_member_of(K,L) <=> a_member_of(K,P)))).
fof(myForms, conjecture, (equalish(L,P) <=> ! [K] : (a_member_of(K,L) <=> a_member_of(K,P)))).
fof(myForms, conjecture, equalish(L,P)).
fof(myForms, conjecture, ! [K] : (a_member_of(K,L) <=> a_member_of(K,P))).
fof(myForms, conjecture, (a_member_of(K,L) <=> a_member_of(K,P))).
fof(myForms, conjecture, a_member_of(K,L)).
fof(myForms, conjecture, a_member_of(K,P)).
fof(myForms, conjecture, ! [L] : ! [P] : (equalish(L,P) <=> equalish(P,L))).
fof(myForms, conjecture, ! [P] : (equalish(L,P) <=> equalish(P,L))).
fof(myForms, conjecture, (equalish(L,P) <=> equalish(P,L))).
fof(myForms, conjecture, equalish(L,P)).
fof(myForms, conjecture, equalish(P,L)).