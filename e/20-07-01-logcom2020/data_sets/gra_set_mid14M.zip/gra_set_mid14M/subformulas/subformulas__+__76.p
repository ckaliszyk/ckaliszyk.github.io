fof(myForms, conjecture, ! [J] : ! [R] : ! [O] : ((pre_order(R,J) & ! [C] : ! [D] : ((member(C,J) & member(D,J)) => (apply(O,C,D) <=> (apply(R,C,D) & apply(R,D,C))))) => ! [S] : ! [T] : ! [U] : ! [V] : ((((member(S,J) & member(T,J)) & member(U,J)) & member(V,J)) => (((apply(O,S,U) & apply(O,T,V)) & apply(R,S,T)) => apply(R,U,V))))).
fof(myForms, conjecture, ! [R] : ! [O] : ((pre_order(R,J) & ! [C] : ! [D] : ((member(C,J) & member(D,J)) => (apply(O,C,D) <=> (apply(R,C,D) & apply(R,D,C))))) => ! [S] : ! [T] : ! [U] : ! [V] : ((((member(S,J) & member(T,J)) & member(U,J)) & member(V,J)) => (((apply(O,S,U) & apply(O,T,V)) & apply(R,S,T)) => apply(R,U,V))))).
fof(myForms, conjecture, ! [O] : ((pre_order(R,J) & ! [C] : ! [D] : ((member(C,J) & member(D,J)) => (apply(O,C,D) <=> (apply(R,C,D) & apply(R,D,C))))) => ! [S] : ! [T] : ! [U] : ! [V] : ((((member(S,J) & member(T,J)) & member(U,J)) & member(V,J)) => (((apply(O,S,U) & apply(O,T,V)) & apply(R,S,T)) => apply(R,U,V))))).
fof(myForms, conjecture, ((pre_order(R,J) & ! [C] : ! [D] : ((member(C,J) & member(D,J)) => (apply(O,C,D) <=> (apply(R,C,D) & apply(R,D,C))))) => ! [S] : ! [T] : ! [U] : ! [V] : ((((member(S,J) & member(T,J)) & member(U,J)) & member(V,J)) => (((apply(O,S,U) & apply(O,T,V)) & apply(R,S,T)) => apply(R,U,V))))).
fof(myForms, conjecture, (pre_order(R,J) & ! [C] : ! [D] : ((member(C,J) & member(D,J)) => (apply(O,C,D) <=> (apply(R,C,D) & apply(R,D,C)))))).
fof(myForms, conjecture, pre_order(R,J)).
fof(myForms, conjecture, ! [C] : ! [D] : ((member(C,J) & member(D,J)) => (apply(O,C,D) <=> (apply(R,C,D) & apply(R,D,C))))).
fof(myForms, conjecture, ! [D] : ((member(C,J) & member(D,J)) => (apply(O,C,D) <=> (apply(R,C,D) & apply(R,D,C))))).
fof(myForms, conjecture, ((member(C,J) & member(D,J)) => (apply(O,C,D) <=> (apply(R,C,D) & apply(R,D,C))))).
fof(myForms, conjecture, (member(C,J) & member(D,J))).
fof(myForms, conjecture, member(C,J)).
fof(myForms, conjecture, member(D,J)).
fof(myForms, conjecture, (apply(O,C,D) <=> (apply(R,C,D) & apply(R,D,C)))).
fof(myForms, conjecture, apply(O,C,D)).
fof(myForms, conjecture, (apply(R,C,D) & apply(R,D,C))).
fof(myForms, conjecture, apply(R,C,D)).
fof(myForms, conjecture, apply(R,D,C)).
fof(myForms, conjecture, ! [S] : ! [T] : ! [U] : ! [V] : ((((member(S,J) & member(T,J)) & member(U,J)) & member(V,J)) => (((apply(O,S,U) & apply(O,T,V)) & apply(R,S,T)) => apply(R,U,V)))).
fof(myForms, conjecture, ! [T] : ! [U] : ! [V] : ((((member(S,J) & member(T,J)) & member(U,J)) & member(V,J)) => (((apply(O,S,U) & apply(O,T,V)) & apply(R,S,T)) => apply(R,U,V)))).
fof(myForms, conjecture, ! [U] : ! [V] : ((((member(S,J) & member(T,J)) & member(U,J)) & member(V,J)) => (((apply(O,S,U) & apply(O,T,V)) & apply(R,S,T)) => apply(R,U,V)))).
fof(myForms, conjecture, ! [V] : ((((member(S,J) & member(T,J)) & member(U,J)) & member(V,J)) => (((apply(O,S,U) & apply(O,T,V)) & apply(R,S,T)) => apply(R,U,V)))).
fof(myForms, conjecture, ((((member(S,J) & member(T,J)) & member(U,J)) & member(V,J)) => (((apply(O,S,U) & apply(O,T,V)) & apply(R,S,T)) => apply(R,U,V)))).
fof(myForms, conjecture, (((member(S,J) & member(T,J)) & member(U,J)) & member(V,J))).
fof(myForms, conjecture, ((member(S,J) & member(T,J)) & member(U,J))).
fof(myForms, conjecture, (member(S,J) & member(T,J))).
fof(myForms, conjecture, member(S,J)).
fof(myForms, conjecture, member(T,J)).
fof(myForms, conjecture, member(U,J)).
fof(myForms, conjecture, member(V,J)).
fof(myForms, conjecture, (((apply(O,S,U) & apply(O,T,V)) & apply(R,S,T)) => apply(R,U,V))).
fof(myForms, conjecture, ((apply(O,S,U) & apply(O,T,V)) & apply(R,S,T))).
fof(myForms, conjecture, (apply(O,S,U) & apply(O,T,V))).
fof(myForms, conjecture, apply(O,S,U)).
fof(myForms, conjecture, apply(O,T,V)).
fof(myForms, conjecture, apply(R,S,T)).
fof(myForms, conjecture, apply(R,U,V)).