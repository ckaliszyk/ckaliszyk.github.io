fof(myForms, conjecture, ! [B] : (subset(unordered_pair(F,I),B) <=> (in(F,B) & in(I,B)))).
fof(myForms, conjecture, (subset(unordered_pair(F,I),B) <=> (in(F,B) & in(I,B)))).
fof(myForms, conjecture, subset(unordered_pair(F,I),B)).
fof(myForms, conjecture, (in(F,B) & in(I,B))).
fof(myForms, conjecture, in(F,B)).
fof(myForms, conjecture, in(I,B)).