fof(myForms, conjecture, (complete => ! [E] : ! [F] : ! [G] : ! [B] : ! [C] : ((((shortest_path(E,F,G) & on_path(B,G)) & on_path(C,G)) & sequential(B,C)) => ? [D] : triangle(B,C,D)))).
fof(myForms, conjecture, complete).
fof(myForms, conjecture, ! [E] : ! [F] : ! [G] : ! [B] : ! [C] : ((((shortest_path(E,F,G) & on_path(B,G)) & on_path(C,G)) & sequential(B,C)) => ? [D] : triangle(B,C,D))).
fof(myForms, conjecture, ! [F] : ! [G] : ! [B] : ! [C] : ((((shortest_path(E,F,G) & on_path(B,G)) & on_path(C,G)) & sequential(B,C)) => ? [D] : triangle(B,C,D))).
fof(myForms, conjecture, ! [G] : ! [B] : ! [C] : ((((shortest_path(E,F,G) & on_path(B,G)) & on_path(C,G)) & sequential(B,C)) => ? [D] : triangle(B,C,D))).
fof(myForms, conjecture, ! [B] : ! [C] : ((((shortest_path(E,F,G) & on_path(B,G)) & on_path(C,G)) & sequential(B,C)) => ? [D] : triangle(B,C,D))).
fof(myForms, conjecture, ! [C] : ((((shortest_path(E,F,G) & on_path(B,G)) & on_path(C,G)) & sequential(B,C)) => ? [D] : triangle(B,C,D))).
fof(myForms, conjecture, ((((shortest_path(E,F,G) & on_path(B,G)) & on_path(C,G)) & sequential(B,C)) => ? [D] : triangle(B,C,D))).
fof(myForms, conjecture, (((shortest_path(E,F,G) & on_path(B,G)) & on_path(C,G)) & sequential(B,C))).
fof(myForms, conjecture, ((shortest_path(E,F,G) & on_path(B,G)) & on_path(C,G))).
fof(myForms, conjecture, (shortest_path(E,F,G) & on_path(B,G))).
fof(myForms, conjecture, shortest_path(E,F,G)).
fof(myForms, conjecture, on_path(B,G)).
fof(myForms, conjecture, on_path(C,G)).
fof(myForms, conjecture, sequential(B,C)).
fof(myForms, conjecture, ? [D] : triangle(B,C,D)).
fof(myForms, conjecture, triangle(B,C,D)).