fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,relation_type(D,F)) => (subset(domain_of(I),D) & subset(range_of(I),F)))))).
fof(myForms, conjecture, (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,relation_type(D,F)) => (subset(domain_of(I),D) & subset(range_of(I),F)))))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,relation_type(D,F)) => (subset(domain_of(I),D) & subset(range_of(I),F))))).
fof(myForms, conjecture, (ilf_type(F,set_type) => ! [I] : (ilf_type(I,relation_type(D,F)) => (subset(domain_of(I),D) & subset(range_of(I),F))))).
fof(myForms, conjecture, ilf_type(F,set_type)).
fof(myForms, conjecture, ! [I] : (ilf_type(I,relation_type(D,F)) => (subset(domain_of(I),D) & subset(range_of(I),F)))).
fof(myForms, conjecture, (ilf_type(I,relation_type(D,F)) => (subset(domain_of(I),D) & subset(range_of(I),F)))).
fof(myForms, conjecture, ilf_type(I,relation_type(D,F))).
fof(myForms, conjecture, (subset(domain_of(I),D) & subset(range_of(I),F))).
fof(myForms, conjecture, subset(domain_of(I),D)).
fof(myForms, conjecture, subset(range_of(I),F)).