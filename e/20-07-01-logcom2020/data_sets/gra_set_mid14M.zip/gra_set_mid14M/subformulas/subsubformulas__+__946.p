fof(myForms, conjecture, ! [I] : ! [B] : symmetric_difference(I,B)=difference(union(I,B),intersection(I,B))).
fof(myForms, conjecture, ! [B] : symmetric_difference(I,B)=difference(union(I,B),intersection(I,B))).
fof(myForms, conjecture, symmetric_difference(I,B)=difference(union(I,B),intersection(I,B))).