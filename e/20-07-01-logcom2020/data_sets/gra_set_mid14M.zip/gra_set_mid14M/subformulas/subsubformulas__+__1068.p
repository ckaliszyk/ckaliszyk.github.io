fof(myForms, conjecture, ! [F] : ! [I] : union(unordered_pair(F,I))=set_union2(F,I)).
fof(myForms, conjecture, ! [I] : union(unordered_pair(F,I))=set_union2(F,I)).
fof(myForms, conjecture, union(unordered_pair(F,I))=set_union2(F,I)).