fof(myForms, conjecture, ! [Z] : (ilf_type(Z,relation_type(I,B)) => ilf_type(restrict4(I,B,Y,Z),relation_type(I,B)))).
fof(myForms, conjecture, (ilf_type(Z,relation_type(I,B)) => ilf_type(restrict4(I,B,Y,Z),relation_type(I,B)))).
fof(myForms, conjecture, ilf_type(Z,relation_type(I,B))).
fof(myForms, conjecture, ilf_type(restrict4(I,B,Y,Z),relation_type(I,B))).