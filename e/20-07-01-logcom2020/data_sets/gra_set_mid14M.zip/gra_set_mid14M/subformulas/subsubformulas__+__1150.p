fof(myForms, conjecture, (member(B,I) => ? [Y] : (ilf_type(Y,set_type) & ? [Z] : (ilf_type(Z,set_type) & ordered_pair(Y,Z)=B)))).
fof(myForms, conjecture, member(B,I)).
fof(myForms, conjecture, ? [Y] : (ilf_type(Y,set_type) & ? [Z] : (ilf_type(Z,set_type) & ordered_pair(Y,Z)=B))).
fof(myForms, conjecture, (ilf_type(Y,set_type) & ? [Z] : (ilf_type(Z,set_type) & ordered_pair(Y,Z)=B))).
fof(myForms, conjecture, ilf_type(Y,set_type)).
fof(myForms, conjecture, ? [Z] : (ilf_type(Z,set_type) & ordered_pair(Y,Z)=B)).
fof(myForms, conjecture, (ilf_type(Z,set_type) & ordered_pair(Y,Z)=B)).
fof(myForms, conjecture, ilf_type(Z,set_type)).
fof(myForms, conjecture, ordered_pair(Y,Z)=B).