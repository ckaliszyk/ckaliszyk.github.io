fof(myForms, conjecture, ((in(B,set_union2(F,I)) & in(Y,set_union2(F,I))) => (Y=B | disjoint(B,Y)))).
fof(myForms, conjecture, (in(B,set_union2(F,I)) & in(Y,set_union2(F,I)))).
fof(myForms, conjecture, in(B,set_union2(F,I))).
fof(myForms, conjecture, in(Y,set_union2(F,I))).
fof(myForms, conjecture, (Y=B | disjoint(B,Y))).
fof(myForms, conjecture, Y=B).
fof(myForms, conjecture, disjoint(B,Y)).