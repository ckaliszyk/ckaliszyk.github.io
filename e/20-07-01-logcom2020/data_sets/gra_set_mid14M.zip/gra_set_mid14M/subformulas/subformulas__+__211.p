fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => (ilf_type(F,subset_type(D)) <=> ilf_type(F,member_type(power_set(D))))))).
fof(myForms, conjecture, (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => (ilf_type(F,subset_type(D)) <=> ilf_type(F,member_type(power_set(D))))))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, ! [F] : (ilf_type(F,set_type) => (ilf_type(F,subset_type(D)) <=> ilf_type(F,member_type(power_set(D)))))).
fof(myForms, conjecture, (ilf_type(F,set_type) => (ilf_type(F,subset_type(D)) <=> ilf_type(F,member_type(power_set(D)))))).
fof(myForms, conjecture, ilf_type(F,set_type)).
fof(myForms, conjecture, (ilf_type(F,subset_type(D)) <=> ilf_type(F,member_type(power_set(D))))).
fof(myForms, conjecture, ilf_type(F,subset_type(D))).
fof(myForms, conjecture, ilf_type(F,member_type(power_set(D)))).