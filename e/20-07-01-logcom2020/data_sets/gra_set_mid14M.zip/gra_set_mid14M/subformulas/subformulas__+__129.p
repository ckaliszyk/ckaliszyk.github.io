fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => (ilf_type(D,binary_relation_type) <=> (relation_like(D) & ilf_type(D,set_type))))).
fof(myForms, conjecture, (ilf_type(D,set_type) => (ilf_type(D,binary_relation_type) <=> (relation_like(D) & ilf_type(D,set_type))))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, (ilf_type(D,binary_relation_type) <=> (relation_like(D) & ilf_type(D,set_type)))).
fof(myForms, conjecture, ilf_type(D,binary_relation_type)).
fof(myForms, conjecture, (relation_like(D) & ilf_type(D,set_type))).
fof(myForms, conjecture, relation_like(D)).
fof(myForms, conjecture, ilf_type(D,set_type)).