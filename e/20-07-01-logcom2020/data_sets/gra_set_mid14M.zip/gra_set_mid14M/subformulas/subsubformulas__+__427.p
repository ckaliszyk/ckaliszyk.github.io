fof(myForms, conjecture, ! [I] : (singleton(F)=I <=> ! [B] : (in(B,I) <=> F=B))).
fof(myForms, conjecture, (singleton(F)=I <=> ! [B] : (in(B,I) <=> F=B))).
fof(myForms, conjecture, singleton(F)=I).
fof(myForms, conjecture, ! [B] : (in(B,I) <=> F=B)).
fof(myForms, conjecture, (in(B,I) <=> F=B)).
fof(myForms, conjecture, in(B,I)).
fof(myForms, conjecture, F=B).