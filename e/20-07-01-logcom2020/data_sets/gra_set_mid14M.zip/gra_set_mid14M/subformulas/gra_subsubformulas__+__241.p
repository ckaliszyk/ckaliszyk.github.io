fof(myForms, conjecture, (less_than(Q,R) => (red(Q,R) | green(Q,R)))).
fof(myForms, conjecture, less_than(Q,R)).
fof(myForms, conjecture, (red(Q,R) | green(Q,R))).
fof(myForms, conjecture, red(Q,R)).
fof(myForms, conjecture, green(Q,R)).