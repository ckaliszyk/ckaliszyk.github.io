fof(myForms, conjecture, ! [I] : ~ (((set_difference(F,singleton(I))=empty_set & ~ empty_set=F) & ~ singleton(I)=F))).
fof(myForms, conjecture, ~ (((set_difference(F,singleton(I))=empty_set & ~ empty_set=F) & ~ singleton(I)=F))).
fof(myForms, conjecture, ((set_difference(F,singleton(I))=empty_set & ~ empty_set=F) & ~ singleton(I)=F)).
fof(myForms, conjecture, (set_difference(F,singleton(I))=empty_set & ~ empty_set=F)).
fof(myForms, conjecture, set_difference(F,singleton(I))=empty_set).
fof(myForms, conjecture, ~ empty_set=F).
fof(myForms, conjecture, empty_set=F).
fof(myForms, conjecture, ~ singleton(I)=F).
fof(myForms, conjecture, singleton(I)=F).