fof(myForms, conjecture, (in(Z,F) & in(D,I))).
fof(myForms, conjecture, in(Z,F)).
fof(myForms, conjecture, in(D,I)).