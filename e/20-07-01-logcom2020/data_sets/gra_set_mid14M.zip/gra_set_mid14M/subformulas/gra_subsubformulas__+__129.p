fof(myForms, conjecture, ((less_than(Q,R) & less_than(R,S)) => less_than(Q,S))).
fof(myForms, conjecture, (less_than(Q,R) & less_than(R,S))).
fof(myForms, conjecture, less_than(Q,R)).
fof(myForms, conjecture, less_than(R,S)).
fof(myForms, conjecture, less_than(Q,S)).