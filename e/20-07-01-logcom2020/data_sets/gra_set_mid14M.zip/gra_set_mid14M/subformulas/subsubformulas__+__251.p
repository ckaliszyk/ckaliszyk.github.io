fof(myForms, conjecture, (disjoint(singleton(F),I) & in(F,I))).
fof(myForms, conjecture, disjoint(singleton(F),I)).
fof(myForms, conjecture, in(F,I)).