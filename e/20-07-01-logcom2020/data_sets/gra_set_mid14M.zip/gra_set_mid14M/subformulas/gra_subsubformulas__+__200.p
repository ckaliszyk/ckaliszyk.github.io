fof(myForms, conjecture, (complete => ! [N] : ! [O] : ! [K] : ! [L] : ! [P] : (((shortest_path(N,O,P) & precedes(K,L,P)) & sequential(K,L)) => ? [M] : triangle(K,L,M)))).
fof(myForms, conjecture, complete).
fof(myForms, conjecture, ! [N] : ! [O] : ! [K] : ! [L] : ! [P] : (((shortest_path(N,O,P) & precedes(K,L,P)) & sequential(K,L)) => ? [M] : triangle(K,L,M))).
fof(myForms, conjecture, ! [O] : ! [K] : ! [L] : ! [P] : (((shortest_path(N,O,P) & precedes(K,L,P)) & sequential(K,L)) => ? [M] : triangle(K,L,M))).
fof(myForms, conjecture, ! [K] : ! [L] : ! [P] : (((shortest_path(N,O,P) & precedes(K,L,P)) & sequential(K,L)) => ? [M] : triangle(K,L,M))).
fof(myForms, conjecture, ! [L] : ! [P] : (((shortest_path(N,O,P) & precedes(K,L,P)) & sequential(K,L)) => ? [M] : triangle(K,L,M))).
fof(myForms, conjecture, ! [P] : (((shortest_path(N,O,P) & precedes(K,L,P)) & sequential(K,L)) => ? [M] : triangle(K,L,M))).
fof(myForms, conjecture, (((shortest_path(N,O,P) & precedes(K,L,P)) & sequential(K,L)) => ? [M] : triangle(K,L,M))).
fof(myForms, conjecture, ((shortest_path(N,O,P) & precedes(K,L,P)) & sequential(K,L))).
fof(myForms, conjecture, (shortest_path(N,O,P) & precedes(K,L,P))).
fof(myForms, conjecture, shortest_path(N,O,P)).
fof(myForms, conjecture, precedes(K,L,P)).
fof(myForms, conjecture, sequential(K,L)).
fof(myForms, conjecture, ? [M] : triangle(K,L,M)).
fof(myForms, conjecture, triangle(K,L,M)).