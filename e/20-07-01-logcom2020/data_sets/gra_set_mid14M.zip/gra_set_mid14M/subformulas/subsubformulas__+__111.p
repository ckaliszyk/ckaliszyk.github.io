fof(myForms, conjecture, (ilf_type(Z,member_type(I)) => (member(Z,domain(I,B,Y)) => ? [D] : (ilf_type(D,member_type(B)) & member(D,range(I,B,Y)))))).
fof(myForms, conjecture, ilf_type(Z,member_type(I))).
fof(myForms, conjecture, (member(Z,domain(I,B,Y)) => ? [D] : (ilf_type(D,member_type(B)) & member(D,range(I,B,Y))))).
fof(myForms, conjecture, member(Z,domain(I,B,Y))).
fof(myForms, conjecture, ? [D] : (ilf_type(D,member_type(B)) & member(D,range(I,B,Y)))).
fof(myForms, conjecture, (ilf_type(D,member_type(B)) & member(D,range(I,B,Y)))).
fof(myForms, conjecture, ilf_type(D,member_type(B))).
fof(myForms, conjecture, member(D,range(I,B,Y))).