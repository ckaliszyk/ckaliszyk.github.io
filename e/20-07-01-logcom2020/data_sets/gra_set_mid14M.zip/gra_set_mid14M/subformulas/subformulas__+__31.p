fof(myForms, conjecture, ! [L] : ! [P] : ! [K] : ((subclass(L,P) & subclass(P,K)) => subclass(L,K))).
fof(myForms, conjecture, ! [P] : ! [K] : ((subclass(L,P) & subclass(P,K)) => subclass(L,K))).
fof(myForms, conjecture, ! [K] : ((subclass(L,P) & subclass(P,K)) => subclass(L,K))).
fof(myForms, conjecture, ((subclass(L,P) & subclass(P,K)) => subclass(L,K))).
fof(myForms, conjecture, (subclass(L,P) & subclass(P,K))).
fof(myForms, conjecture, subclass(L,P)).
fof(myForms, conjecture, subclass(P,K)).
fof(myForms, conjecture, subclass(L,K)).