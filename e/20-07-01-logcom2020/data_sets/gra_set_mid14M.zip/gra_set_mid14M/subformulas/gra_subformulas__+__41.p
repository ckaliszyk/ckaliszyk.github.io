fof(myForms, conjecture, ! [E] : ! [F] : ! [B] : ! [C] : ! [G] : ((shortest_path(E,F,G) & precedes(B,C,G)) => ~ (? [D] : ((edge(D) & tail_of(D)=tail_of(B)) & head_of(D)=head_of(C))))).
fof(myForms, conjecture, ! [F] : ! [B] : ! [C] : ! [G] : ((shortest_path(E,F,G) & precedes(B,C,G)) => ~ (? [D] : ((edge(D) & tail_of(D)=tail_of(B)) & head_of(D)=head_of(C))))).
fof(myForms, conjecture, ! [B] : ! [C] : ! [G] : ((shortest_path(E,F,G) & precedes(B,C,G)) => ~ (? [D] : ((edge(D) & tail_of(D)=tail_of(B)) & head_of(D)=head_of(C))))).
fof(myForms, conjecture, ! [C] : ! [G] : ((shortest_path(E,F,G) & precedes(B,C,G)) => ~ (? [D] : ((edge(D) & tail_of(D)=tail_of(B)) & head_of(D)=head_of(C))))).
fof(myForms, conjecture, ! [G] : ((shortest_path(E,F,G) & precedes(B,C,G)) => ~ (? [D] : ((edge(D) & tail_of(D)=tail_of(B)) & head_of(D)=head_of(C))))).
fof(myForms, conjecture, ((shortest_path(E,F,G) & precedes(B,C,G)) => ~ (? [D] : ((edge(D) & tail_of(D)=tail_of(B)) & head_of(D)=head_of(C))))).
fof(myForms, conjecture, (shortest_path(E,F,G) & precedes(B,C,G))).
fof(myForms, conjecture, shortest_path(E,F,G)).
fof(myForms, conjecture, precedes(B,C,G)).
fof(myForms, conjecture, ~ (? [D] : ((edge(D) & tail_of(D)=tail_of(B)) & head_of(D)=head_of(C)))).
fof(myForms, conjecture, ? [D] : ((edge(D) & tail_of(D)=tail_of(B)) & head_of(D)=head_of(C))).
fof(myForms, conjecture, ((edge(D) & tail_of(D)=tail_of(B)) & head_of(D)=head_of(C))).
fof(myForms, conjecture, (edge(D) & tail_of(D)=tail_of(B))).
fof(myForms, conjecture, edge(D)).
fof(myForms, conjecture, tail_of(D)=tail_of(B)).
fof(myForms, conjecture, head_of(D)=head_of(C)).