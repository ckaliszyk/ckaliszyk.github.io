fof(myForms, conjecture, ((in(Z,F) & in(D,I)) & ordered_pair(Z,D)=Y)).
fof(myForms, conjecture, (in(Z,F) & in(D,I))).
fof(myForms, conjecture, in(Z,F)).
fof(myForms, conjecture, in(D,I)).
fof(myForms, conjecture, ordered_pair(Z,D)=Y).