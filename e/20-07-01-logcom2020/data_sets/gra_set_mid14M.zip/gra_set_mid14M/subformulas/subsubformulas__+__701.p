fof(myForms, conjecture, (~ empty(F) => ~ empty(set_union2(I,F)))).
fof(myForms, conjecture, ~ empty(F)).
fof(myForms, conjecture, empty(F)).
fof(myForms, conjecture, ~ empty(set_union2(I,F))).
fof(myForms, conjecture, empty(set_union2(I,F))).