fof(myForms, conjecture, ! [Q] : ! [R] : ! [S] : ! [T] : ((((((green(Q,R) & green(Q,S)) & green(R,S)) & green(Q,T)) & green(R,T)) & green(S,T)) => goal)).
fof(myForms, conjecture, ! [R] : ! [S] : ! [T] : ((((((green(Q,R) & green(Q,S)) & green(R,S)) & green(Q,T)) & green(R,T)) & green(S,T)) => goal)).
fof(myForms, conjecture, ! [S] : ! [T] : ((((((green(Q,R) & green(Q,S)) & green(R,S)) & green(Q,T)) & green(R,T)) & green(S,T)) => goal)).
fof(myForms, conjecture, ! [T] : ((((((green(Q,R) & green(Q,S)) & green(R,S)) & green(Q,T)) & green(R,T)) & green(S,T)) => goal)).
fof(myForms, conjecture, ((((((green(Q,R) & green(Q,S)) & green(R,S)) & green(Q,T)) & green(R,T)) & green(S,T)) => goal)).
fof(myForms, conjecture, (((((green(Q,R) & green(Q,S)) & green(R,S)) & green(Q,T)) & green(R,T)) & green(S,T))).
fof(myForms, conjecture, ((((green(Q,R) & green(Q,S)) & green(R,S)) & green(Q,T)) & green(R,T))).
fof(myForms, conjecture, (((green(Q,R) & green(Q,S)) & green(R,S)) & green(Q,T))).
fof(myForms, conjecture, ((green(Q,R) & green(Q,S)) & green(R,S))).
fof(myForms, conjecture, (green(Q,R) & green(Q,S))).
fof(myForms, conjecture, green(Q,R)).
fof(myForms, conjecture, green(Q,S)).
fof(myForms, conjecture, green(R,S)).
fof(myForms, conjecture, green(Q,T)).
fof(myForms, conjecture, green(R,T)).
fof(myForms, conjecture, green(S,T)).
fof(myForms, conjecture, goal).