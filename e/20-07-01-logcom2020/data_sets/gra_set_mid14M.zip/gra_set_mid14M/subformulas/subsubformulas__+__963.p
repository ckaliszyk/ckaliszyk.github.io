fof(myForms, conjecture, (ilf_type(B,set_type) => (member(I,power_set(B)) <=> ! [Y] : (ilf_type(Y,set_type) => (member(Y,I) => member(Y,B)))))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, (member(I,power_set(B)) <=> ! [Y] : (ilf_type(Y,set_type) => (member(Y,I) => member(Y,B))))).
fof(myForms, conjecture, member(I,power_set(B))).
fof(myForms, conjecture, ! [Y] : (ilf_type(Y,set_type) => (member(Y,I) => member(Y,B)))).
fof(myForms, conjecture, (ilf_type(Y,set_type) => (member(Y,I) => member(Y,B)))).
fof(myForms, conjecture, ilf_type(Y,set_type)).
fof(myForms, conjecture, (member(Y,I) => member(Y,B))).
fof(myForms, conjecture, member(Y,I)).
fof(myForms, conjecture, member(Y,B)).