fof(myForms, conjecture, ! [F] : ! [I] : (maps(D,F,I) => equal_set(image2(D,empty_set),empty_set))).
fof(myForms, conjecture, ! [I] : (maps(D,F,I) => equal_set(image2(D,empty_set),empty_set))).
fof(myForms, conjecture, (maps(D,F,I) => equal_set(image2(D,empty_set),empty_set))).
fof(myForms, conjecture, maps(D,F,I)).
fof(myForms, conjecture, equal_set(image2(D,empty_set),empty_set)).