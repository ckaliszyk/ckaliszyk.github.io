fof(myForms, conjecture, ! [Z] : (ilf_type(Z,set_type) => (member(ordered_pair(I,B),cross_product(Y,Z)) <=> (member(I,Y) & member(B,Z))))).
fof(myForms, conjecture, (ilf_type(Z,set_type) => (member(ordered_pair(I,B),cross_product(Y,Z)) <=> (member(I,Y) & member(B,Z))))).
fof(myForms, conjecture, ilf_type(Z,set_type)).
fof(myForms, conjecture, (member(ordered_pair(I,B),cross_product(Y,Z)) <=> (member(I,Y) & member(B,Z)))).
fof(myForms, conjecture, member(ordered_pair(I,B),cross_product(Y,Z))).
fof(myForms, conjecture, (member(I,Y) & member(B,Z))).
fof(myForms, conjecture, member(I,Y)).
fof(myForms, conjecture, member(B,Z)).