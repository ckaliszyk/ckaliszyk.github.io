fof(myForms, conjecture, (intersect(I,I) <=> not_equal(I,empty_set))).
fof(myForms, conjecture, intersect(I,I)).
fof(myForms, conjecture, not_equal(I,empty_set)).