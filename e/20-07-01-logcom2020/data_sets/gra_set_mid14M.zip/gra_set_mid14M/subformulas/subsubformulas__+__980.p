fof(myForms, conjecture, (ilf_type(Z,relation_type(I,B)) => restrict(Y,Z)=restrict4(I,B,Y,Z))).
fof(myForms, conjecture, ilf_type(Z,relation_type(I,B))).
fof(myForms, conjecture, restrict(Y,Z)=restrict4(I,B,Y,Z)).