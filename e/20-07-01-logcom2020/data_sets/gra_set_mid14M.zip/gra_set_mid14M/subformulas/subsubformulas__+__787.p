fof(myForms, conjecture, ((~ empty(B) & ilf_type(B,set_type)) => ! [Y] : (ilf_type(Y,relation_type(I,B)) => ! [Z] : (ilf_type(Z,member_type(I)) => (member(Z,domain(I,B,Y)) => ? [D] : (ilf_type(D,member_type(B)) & member(D,range(I,B,Y)))))))).
fof(myForms, conjecture, (~ empty(B) & ilf_type(B,set_type))).
fof(myForms, conjecture, ~ empty(B)).
fof(myForms, conjecture, empty(B)).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ! [Y] : (ilf_type(Y,relation_type(I,B)) => ! [Z] : (ilf_type(Z,member_type(I)) => (member(Z,domain(I,B,Y)) => ? [D] : (ilf_type(D,member_type(B)) & member(D,range(I,B,Y))))))).
fof(myForms, conjecture, (ilf_type(Y,relation_type(I,B)) => ! [Z] : (ilf_type(Z,member_type(I)) => (member(Z,domain(I,B,Y)) => ? [D] : (ilf_type(D,member_type(B)) & member(D,range(I,B,Y))))))).
fof(myForms, conjecture, ilf_type(Y,relation_type(I,B))).
fof(myForms, conjecture, ! [Z] : (ilf_type(Z,member_type(I)) => (member(Z,domain(I,B,Y)) => ? [D] : (ilf_type(D,member_type(B)) & member(D,range(I,B,Y)))))).
fof(myForms, conjecture, (ilf_type(Z,member_type(I)) => (member(Z,domain(I,B,Y)) => ? [D] : (ilf_type(D,member_type(B)) & member(D,range(I,B,Y)))))).
fof(myForms, conjecture, ilf_type(Z,member_type(I))).
fof(myForms, conjecture, (member(Z,domain(I,B,Y)) => ? [D] : (ilf_type(D,member_type(B)) & member(D,range(I,B,Y))))).
fof(myForms, conjecture, member(Z,domain(I,B,Y))).
fof(myForms, conjecture, ? [D] : (ilf_type(D,member_type(B)) & member(D,range(I,B,Y)))).
fof(myForms, conjecture, (ilf_type(D,member_type(B)) & member(D,range(I,B,Y)))).
fof(myForms, conjecture, ilf_type(D,member_type(B))).
fof(myForms, conjecture, member(D,range(I,B,Y))).