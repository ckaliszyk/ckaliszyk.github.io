fof(myForms, conjecture, ! [C] : ! [D] : (in(C,D) => ~ in(D,C))).
fof(myForms, conjecture, ! [D] : (in(C,D) => ~ in(D,C))).
fof(myForms, conjecture, (in(C,D) => ~ in(D,C))).
fof(myForms, conjecture, in(C,D)).
fof(myForms, conjecture, ~ in(D,C)).
fof(myForms, conjecture, in(D,C)).