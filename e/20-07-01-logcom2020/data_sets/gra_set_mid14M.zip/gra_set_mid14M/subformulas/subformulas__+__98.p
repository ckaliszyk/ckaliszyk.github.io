fof(myForms, conjecture, ! [C] : ! [D] : ! [F] : ! [I] : (in(ordered_pair(C,D),cartesian_product2(F,I)) <=> (in(C,F) & in(D,I)))).
fof(myForms, conjecture, ! [D] : ! [F] : ! [I] : (in(ordered_pair(C,D),cartesian_product2(F,I)) <=> (in(C,F) & in(D,I)))).
fof(myForms, conjecture, ! [F] : ! [I] : (in(ordered_pair(C,D),cartesian_product2(F,I)) <=> (in(C,F) & in(D,I)))).
fof(myForms, conjecture, ! [I] : (in(ordered_pair(C,D),cartesian_product2(F,I)) <=> (in(C,F) & in(D,I)))).
fof(myForms, conjecture, (in(ordered_pair(C,D),cartesian_product2(F,I)) <=> (in(C,F) & in(D,I)))).
fof(myForms, conjecture, in(ordered_pair(C,D),cartesian_product2(F,I))).
fof(myForms, conjecture, (in(C,F) & in(D,I))).
fof(myForms, conjecture, in(C,F)).
fof(myForms, conjecture, in(D,I)).