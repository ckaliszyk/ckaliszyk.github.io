fof(myForms, conjecture, ! [R] : ! [B1] : ((subclass(A1,R) & subclass(R,B1)) => subclass(A1,B1))).
fof(myForms, conjecture, ! [B1] : ((subclass(A1,R) & subclass(R,B1)) => subclass(A1,B1))).
fof(myForms, conjecture, ((subclass(A1,R) & subclass(R,B1)) => subclass(A1,B1))).
fof(myForms, conjecture, (subclass(A1,R) & subclass(R,B1))).
fof(myForms, conjecture, subclass(A1,R)).
fof(myForms, conjecture, subclass(R,B1)).
fof(myForms, conjecture, subclass(A1,B1)).