fof(myForms, conjecture, ? [Y] : ilf_type(Y,relation_type(B,I))).
fof(myForms, conjecture, ilf_type(Y,relation_type(B,I))).