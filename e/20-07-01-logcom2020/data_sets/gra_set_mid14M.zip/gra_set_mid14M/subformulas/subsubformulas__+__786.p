fof(myForms, conjecture, ! [F] : ! [I] : ! [B] : ! [Y] : (in(ordered_pair(F,I),cartesian_product2(singleton(B),singleton(Y))) <=> (F=B & Y=I))).
fof(myForms, conjecture, ! [I] : ! [B] : ! [Y] : (in(ordered_pair(F,I),cartesian_product2(singleton(B),singleton(Y))) <=> (F=B & Y=I))).
fof(myForms, conjecture, ! [B] : ! [Y] : (in(ordered_pair(F,I),cartesian_product2(singleton(B),singleton(Y))) <=> (F=B & Y=I))).
fof(myForms, conjecture, ! [Y] : (in(ordered_pair(F,I),cartesian_product2(singleton(B),singleton(Y))) <=> (F=B & Y=I))).
fof(myForms, conjecture, (in(ordered_pair(F,I),cartesian_product2(singleton(B),singleton(Y))) <=> (F=B & Y=I))).
fof(myForms, conjecture, in(ordered_pair(F,I),cartesian_product2(singleton(B),singleton(Y)))).
fof(myForms, conjecture, (F=B & Y=I)).
fof(myForms, conjecture, F=B).
fof(myForms, conjecture, Y=I).