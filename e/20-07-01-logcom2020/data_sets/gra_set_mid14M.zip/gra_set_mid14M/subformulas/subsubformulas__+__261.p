fof(myForms, conjecture, ! [D] : (ilf_type(D,relation_type(I,B)) => (member(ordered_pair(Y,Z),D) => (member(Y,I) & member(Z,B))))).
fof(myForms, conjecture, (ilf_type(D,relation_type(I,B)) => (member(ordered_pair(Y,Z),D) => (member(Y,I) & member(Z,B))))).
fof(myForms, conjecture, ilf_type(D,relation_type(I,B))).
fof(myForms, conjecture, (member(ordered_pair(Y,Z),D) => (member(Y,I) & member(Z,B)))).
fof(myForms, conjecture, member(ordered_pair(Y,Z),D)).
fof(myForms, conjecture, (member(Y,I) & member(Z,B))).
fof(myForms, conjecture, member(Y,I)).
fof(myForms, conjecture, member(Z,B)).