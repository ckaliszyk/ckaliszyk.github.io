fof(myForms, conjecture, (ilf_type(I,set_type) => (empty(I) <=> ! [B] : (ilf_type(B,set_type) => ~ member(B,I))))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, (empty(I) <=> ! [B] : (ilf_type(B,set_type) => ~ member(B,I)))).
fof(myForms, conjecture, empty(I)).
fof(myForms, conjecture, ! [B] : (ilf_type(B,set_type) => ~ member(B,I))).
fof(myForms, conjecture, (ilf_type(B,set_type) => ~ member(B,I))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ~ member(B,I)).
fof(myForms, conjecture, member(B,I)).