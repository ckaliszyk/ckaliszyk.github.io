fof(myForms, conjecture, ! [B] : ! [E] : ! [X] : ! [C] : ! [D] : ! [F] : ((((((maps(B,C,D) & maps(E,D,F)) & maps(X,F,C)) & injective(compose_function(X,compose_function(E,B,C,D,F),C,F,C),C,C)) & injective(compose_function(B,compose_function(X,E,D,F,C),D,C,D),D,D)) & surjective(compose_function(E,compose_function(B,X,F,C,D),F,D,F),F,F)) => one_to_one(X,F,C))).
fof(myForms, conjecture, ! [E] : ! [X] : ! [C] : ! [D] : ! [F] : ((((((maps(B,C,D) & maps(E,D,F)) & maps(X,F,C)) & injective(compose_function(X,compose_function(E,B,C,D,F),C,F,C),C,C)) & injective(compose_function(B,compose_function(X,E,D,F,C),D,C,D),D,D)) & surjective(compose_function(E,compose_function(B,X,F,C,D),F,D,F),F,F)) => one_to_one(X,F,C))).
fof(myForms, conjecture, ! [X] : ! [C] : ! [D] : ! [F] : ((((((maps(B,C,D) & maps(E,D,F)) & maps(X,F,C)) & injective(compose_function(X,compose_function(E,B,C,D,F),C,F,C),C,C)) & injective(compose_function(B,compose_function(X,E,D,F,C),D,C,D),D,D)) & surjective(compose_function(E,compose_function(B,X,F,C,D),F,D,F),F,F)) => one_to_one(X,F,C))).
fof(myForms, conjecture, ! [C] : ! [D] : ! [F] : ((((((maps(B,C,D) & maps(E,D,F)) & maps(X,F,C)) & injective(compose_function(X,compose_function(E,B,C,D,F),C,F,C),C,C)) & injective(compose_function(B,compose_function(X,E,D,F,C),D,C,D),D,D)) & surjective(compose_function(E,compose_function(B,X,F,C,D),F,D,F),F,F)) => one_to_one(X,F,C))).
fof(myForms, conjecture, ! [D] : ! [F] : ((((((maps(B,C,D) & maps(E,D,F)) & maps(X,F,C)) & injective(compose_function(X,compose_function(E,B,C,D,F),C,F,C),C,C)) & injective(compose_function(B,compose_function(X,E,D,F,C),D,C,D),D,D)) & surjective(compose_function(E,compose_function(B,X,F,C,D),F,D,F),F,F)) => one_to_one(X,F,C))).
fof(myForms, conjecture, ! [F] : ((((((maps(B,C,D) & maps(E,D,F)) & maps(X,F,C)) & injective(compose_function(X,compose_function(E,B,C,D,F),C,F,C),C,C)) & injective(compose_function(B,compose_function(X,E,D,F,C),D,C,D),D,D)) & surjective(compose_function(E,compose_function(B,X,F,C,D),F,D,F),F,F)) => one_to_one(X,F,C))).
fof(myForms, conjecture, ((((((maps(B,C,D) & maps(E,D,F)) & maps(X,F,C)) & injective(compose_function(X,compose_function(E,B,C,D,F),C,F,C),C,C)) & injective(compose_function(B,compose_function(X,E,D,F,C),D,C,D),D,D)) & surjective(compose_function(E,compose_function(B,X,F,C,D),F,D,F),F,F)) => one_to_one(X,F,C))).
fof(myForms, conjecture, (((((maps(B,C,D) & maps(E,D,F)) & maps(X,F,C)) & injective(compose_function(X,compose_function(E,B,C,D,F),C,F,C),C,C)) & injective(compose_function(B,compose_function(X,E,D,F,C),D,C,D),D,D)) & surjective(compose_function(E,compose_function(B,X,F,C,D),F,D,F),F,F))).
fof(myForms, conjecture, ((((maps(B,C,D) & maps(E,D,F)) & maps(X,F,C)) & injective(compose_function(X,compose_function(E,B,C,D,F),C,F,C),C,C)) & injective(compose_function(B,compose_function(X,E,D,F,C),D,C,D),D,D))).
fof(myForms, conjecture, (((maps(B,C,D) & maps(E,D,F)) & maps(X,F,C)) & injective(compose_function(X,compose_function(E,B,C,D,F),C,F,C),C,C))).
fof(myForms, conjecture, ((maps(B,C,D) & maps(E,D,F)) & maps(X,F,C))).
fof(myForms, conjecture, (maps(B,C,D) & maps(E,D,F))).
fof(myForms, conjecture, maps(B,C,D)).
fof(myForms, conjecture, maps(E,D,F)).
fof(myForms, conjecture, maps(X,F,C)).
fof(myForms, conjecture, injective(compose_function(X,compose_function(E,B,C,D,F),C,F,C),C,C)).
fof(myForms, conjecture, injective(compose_function(B,compose_function(X,E,D,F,C),D,C,D),D,D)).
fof(myForms, conjecture, surjective(compose_function(E,compose_function(B,X,F,C,D),F,D,F),F,F)).
fof(myForms, conjecture, one_to_one(X,F,C)).