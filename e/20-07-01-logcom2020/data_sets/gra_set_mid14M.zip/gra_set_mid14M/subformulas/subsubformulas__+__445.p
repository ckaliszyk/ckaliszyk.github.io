fof(myForms, conjecture, ~ I=B).
fof(myForms, conjecture, I=B).