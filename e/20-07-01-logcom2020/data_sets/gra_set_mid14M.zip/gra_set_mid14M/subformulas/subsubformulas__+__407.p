fof(myForms, conjecture, (ilf_type(Y,subset_type(cross_product(I,B))) => relation_like(Y))).
fof(myForms, conjecture, ilf_type(Y,subset_type(cross_product(I,B)))).
fof(myForms, conjecture, relation_like(Y)).