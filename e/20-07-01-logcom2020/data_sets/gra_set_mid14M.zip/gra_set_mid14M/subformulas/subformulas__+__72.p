fof(myForms, conjecture, ! [D] : ! [F] : (intersect(D,F) <=> ? [I] : (member(I,D) & member(I,F)))).
fof(myForms, conjecture, ! [F] : (intersect(D,F) <=> ? [I] : (member(I,D) & member(I,F)))).
fof(myForms, conjecture, (intersect(D,F) <=> ? [I] : (member(I,D) & member(I,F)))).
fof(myForms, conjecture, intersect(D,F)).
fof(myForms, conjecture, ? [I] : (member(I,D) & member(I,F))).
fof(myForms, conjecture, (member(I,D) & member(I,F))).
fof(myForms, conjecture, member(I,D)).
fof(myForms, conjecture, member(I,F)).