fof(myForms, conjecture, ! [D] : ((~ empty(D) & ilf_type(D,set_type)) => ? [F] : ilf_type(F,member_type(D)))).
fof(myForms, conjecture, ((~ empty(D) & ilf_type(D,set_type)) => ? [F] : ilf_type(F,member_type(D)))).
fof(myForms, conjecture, (~ empty(D) & ilf_type(D,set_type))).
fof(myForms, conjecture, ~ empty(D)).
fof(myForms, conjecture, empty(D)).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, ? [F] : ilf_type(F,member_type(D))).
fof(myForms, conjecture, ilf_type(F,member_type(D))).