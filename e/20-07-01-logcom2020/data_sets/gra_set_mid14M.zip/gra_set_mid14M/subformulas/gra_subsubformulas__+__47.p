fof(myForms, conjecture, ! [K] : ! [L] : (((on_path(K,P) & on_path(L,P)) & sequential(K,L)) => ? [M] : triangle(K,L,M))).
fof(myForms, conjecture, ! [L] : (((on_path(K,P) & on_path(L,P)) & sequential(K,L)) => ? [M] : triangle(K,L,M))).
fof(myForms, conjecture, (((on_path(K,P) & on_path(L,P)) & sequential(K,L)) => ? [M] : triangle(K,L,M))).
fof(myForms, conjecture, ((on_path(K,P) & on_path(L,P)) & sequential(K,L))).
fof(myForms, conjecture, (on_path(K,P) & on_path(L,P))).
fof(myForms, conjecture, on_path(K,P)).
fof(myForms, conjecture, on_path(L,P)).
fof(myForms, conjecture, sequential(K,L)).
fof(myForms, conjecture, ? [M] : triangle(K,L,M)).
fof(myForms, conjecture, triangle(K,L,M)).