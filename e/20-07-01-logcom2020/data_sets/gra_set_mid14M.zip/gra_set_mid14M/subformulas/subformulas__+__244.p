fof(myForms, conjecture, ! [C] : ! [D] : (subset(singleton(C),singleton(D)) => D=C)).
fof(myForms, conjecture, ! [D] : (subset(singleton(C),singleton(D)) => D=C)).
fof(myForms, conjecture, (subset(singleton(C),singleton(D)) => D=C)).
fof(myForms, conjecture, subset(singleton(C),singleton(D))).
fof(myForms, conjecture, D=C).