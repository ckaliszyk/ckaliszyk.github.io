fof(myForms, conjecture, (ilf_type(I,set_type) => ! [B] : (ilf_type(B,set_type) => ! [Y] : (ilf_type(Y,set_type) => ! [Z] : (ilf_type(Z,relation_type(Y,I)) => ilf_type(restrict4(Y,I,B,Z),relation_type(Y,B))))))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [B] : (ilf_type(B,set_type) => ! [Y] : (ilf_type(Y,set_type) => ! [Z] : (ilf_type(Z,relation_type(Y,I)) => ilf_type(restrict4(Y,I,B,Z),relation_type(Y,B)))))).
fof(myForms, conjecture, (ilf_type(B,set_type) => ! [Y] : (ilf_type(Y,set_type) => ! [Z] : (ilf_type(Z,relation_type(Y,I)) => ilf_type(restrict4(Y,I,B,Z),relation_type(Y,B)))))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ! [Y] : (ilf_type(Y,set_type) => ! [Z] : (ilf_type(Z,relation_type(Y,I)) => ilf_type(restrict4(Y,I,B,Z),relation_type(Y,B))))).
fof(myForms, conjecture, (ilf_type(Y,set_type) => ! [Z] : (ilf_type(Z,relation_type(Y,I)) => ilf_type(restrict4(Y,I,B,Z),relation_type(Y,B))))).
fof(myForms, conjecture, ilf_type(Y,set_type)).
fof(myForms, conjecture, ! [Z] : (ilf_type(Z,relation_type(Y,I)) => ilf_type(restrict4(Y,I,B,Z),relation_type(Y,B)))).
fof(myForms, conjecture, (ilf_type(Z,relation_type(Y,I)) => ilf_type(restrict4(Y,I,B,Z),relation_type(Y,B)))).
fof(myForms, conjecture, ilf_type(Z,relation_type(Y,I))).
fof(myForms, conjecture, ilf_type(restrict4(Y,I,B,Z),relation_type(Y,B))).