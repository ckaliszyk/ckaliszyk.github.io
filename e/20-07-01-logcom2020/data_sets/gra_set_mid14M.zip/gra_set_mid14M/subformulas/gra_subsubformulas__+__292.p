fof(myForms, conjecture, ((edge(K) & edge(L)) & edge(M))).
fof(myForms, conjecture, (edge(K) & edge(L))).
fof(myForms, conjecture, edge(K)).
fof(myForms, conjecture, edge(L)).
fof(myForms, conjecture, edge(M)).