fof(myForms, conjecture, ! [B] : (subset(I,B) <=> ! [Y] : (member(Y,I) => member(Y,B)))).
fof(myForms, conjecture, (subset(I,B) <=> ! [Y] : (member(Y,I) => member(Y,B)))).
fof(myForms, conjecture, subset(I,B)).
fof(myForms, conjecture, ! [Y] : (member(Y,I) => member(Y,B))).
fof(myForms, conjecture, (member(Y,I) => member(Y,B))).
fof(myForms, conjecture, member(Y,I)).
fof(myForms, conjecture, member(Y,B)).