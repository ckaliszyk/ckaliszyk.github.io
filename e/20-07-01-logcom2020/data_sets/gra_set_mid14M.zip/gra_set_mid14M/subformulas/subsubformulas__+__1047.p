fof(myForms, conjecture, (cartesian_product2(I,F)=cartesian_product2(F,I) => (empty_set=F | (empty_set=I | I=F)))).
fof(myForms, conjecture, cartesian_product2(I,F)=cartesian_product2(F,I)).
fof(myForms, conjecture, (empty_set=F | (empty_set=I | I=F))).
fof(myForms, conjecture, empty_set=F).
fof(myForms, conjecture, (empty_set=I | I=F)).
fof(myForms, conjecture, empty_set=I).
fof(myForms, conjecture, I=F).