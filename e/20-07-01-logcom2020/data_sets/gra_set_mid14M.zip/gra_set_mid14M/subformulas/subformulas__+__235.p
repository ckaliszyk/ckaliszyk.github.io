fof(myForms, conjecture, ! [C] : (subset(C,cartesian_product2(C,C)) => empty_set=C)).
fof(myForms, conjecture, (subset(C,cartesian_product2(C,C)) => empty_set=C)).
fof(myForms, conjecture, subset(C,cartesian_product2(C,C))).
fof(myForms, conjecture, empty_set=C).