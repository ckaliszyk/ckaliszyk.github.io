fof(myForms, conjecture, ((shortest_path(N,O,P) & precedes(K,L,P)) & sequential(K,L))).
fof(myForms, conjecture, (shortest_path(N,O,P) & precedes(K,L,P))).
fof(myForms, conjecture, shortest_path(N,O,P)).
fof(myForms, conjecture, precedes(K,L,P)).
fof(myForms, conjecture, sequential(K,L)).