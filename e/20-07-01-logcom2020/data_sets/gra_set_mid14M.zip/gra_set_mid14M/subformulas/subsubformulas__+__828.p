fof(myForms, conjecture, (subset(F,I) & subset(I,F))).
fof(myForms, conjecture, subset(F,I)).
fof(myForms, conjecture, subset(I,F)).