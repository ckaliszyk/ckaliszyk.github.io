fof(myForms, conjecture, ! [I] : ((~ empty(I) & ilf_type(I,set_type)) => ? [B] : ilf_type(B,member_type(I)))).
fof(myForms, conjecture, ((~ empty(I) & ilf_type(I,set_type)) => ? [B] : ilf_type(B,member_type(I)))).
fof(myForms, conjecture, (~ empty(I) & ilf_type(I,set_type))).
fof(myForms, conjecture, ~ empty(I)).
fof(myForms, conjecture, empty(I)).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ? [B] : ilf_type(B,member_type(I))).
fof(myForms, conjecture, ilf_type(B,member_type(I))).