fof(myForms, conjecture, ! [L] : ! [P] : ! [K] : (((member(P,universal_class) & member(K,universal_class)) & unordered_pair(L,P)=unordered_pair(L,K)) => P=K)).
fof(myForms, conjecture, ! [P] : ! [K] : (((member(P,universal_class) & member(K,universal_class)) & unordered_pair(L,P)=unordered_pair(L,K)) => P=K)).
fof(myForms, conjecture, ! [K] : (((member(P,universal_class) & member(K,universal_class)) & unordered_pair(L,P)=unordered_pair(L,K)) => P=K)).
fof(myForms, conjecture, (((member(P,universal_class) & member(K,universal_class)) & unordered_pair(L,P)=unordered_pair(L,K)) => P=K)).
fof(myForms, conjecture, ((member(P,universal_class) & member(K,universal_class)) & unordered_pair(L,P)=unordered_pair(L,K))).
fof(myForms, conjecture, (member(P,universal_class) & member(K,universal_class))).
fof(myForms, conjecture, member(P,universal_class)).
fof(myForms, conjecture, member(K,universal_class)).
fof(myForms, conjecture, unordered_pair(L,P)=unordered_pair(L,K)).
fof(myForms, conjecture, P=K).