fof(myForms, conjecture, ~ empty(ordered_pair(F,I))).
fof(myForms, conjecture, empty(ordered_pair(F,I))).