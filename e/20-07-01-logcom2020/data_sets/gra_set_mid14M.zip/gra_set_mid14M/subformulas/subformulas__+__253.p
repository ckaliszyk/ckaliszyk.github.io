fof(myForms, conjecture, ! [C] : ! [D] : ! [F] : ~ ((in(C,cartesian_product2(D,F)) & ! [I] : ! [J] : ~ ordered_pair(I,J)=C))).
fof(myForms, conjecture, ! [D] : ! [F] : ~ ((in(C,cartesian_product2(D,F)) & ! [I] : ! [J] : ~ ordered_pair(I,J)=C))).
fof(myForms, conjecture, ! [F] : ~ ((in(C,cartesian_product2(D,F)) & ! [I] : ! [J] : ~ ordered_pair(I,J)=C))).
fof(myForms, conjecture, ~ ((in(C,cartesian_product2(D,F)) & ! [I] : ! [J] : ~ ordered_pair(I,J)=C))).
fof(myForms, conjecture, (in(C,cartesian_product2(D,F)) & ! [I] : ! [J] : ~ ordered_pair(I,J)=C)).
fof(myForms, conjecture, in(C,cartesian_product2(D,F))).
fof(myForms, conjecture, ! [I] : ! [J] : ~ ordered_pair(I,J)=C).
fof(myForms, conjecture, ! [J] : ~ ordered_pair(I,J)=C).
fof(myForms, conjecture, ~ ordered_pair(I,J)=C).
fof(myForms, conjecture, ordered_pair(I,J)=C).