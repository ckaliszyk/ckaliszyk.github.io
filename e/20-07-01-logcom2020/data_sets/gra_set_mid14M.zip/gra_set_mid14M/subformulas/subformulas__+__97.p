fof(myForms, conjecture, ! [D] : union(D,empty_set)=D).
fof(myForms, conjecture, union(D,empty_set)=D).