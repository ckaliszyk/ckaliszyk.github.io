fof(myForms, conjecture, ~ disjoint(F,I)).
fof(myForms, conjecture, disjoint(F,I)).