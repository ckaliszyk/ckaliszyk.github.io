fof(myForms, conjecture, ! [D] : ! [J] : ! [L] : ! [F] : ! [I] : ! [B] : ((((((maps(D,F,I) & maps(J,I,B)) & maps(L,B,F)) & injective(compose_function(L,compose_function(J,D,F,I,B),F,B,F),F,F)) & injective(compose_function(D,compose_function(L,J,I,B,F),I,F,I),I,I)) & surjective(compose_function(J,compose_function(D,L,B,F,I),B,I,B),B,B)) => one_to_one(L,B,F))).
fof(myForms, conjecture, ! [J] : ! [L] : ! [F] : ! [I] : ! [B] : ((((((maps(D,F,I) & maps(J,I,B)) & maps(L,B,F)) & injective(compose_function(L,compose_function(J,D,F,I,B),F,B,F),F,F)) & injective(compose_function(D,compose_function(L,J,I,B,F),I,F,I),I,I)) & surjective(compose_function(J,compose_function(D,L,B,F,I),B,I,B),B,B)) => one_to_one(L,B,F))).
fof(myForms, conjecture, ! [L] : ! [F] : ! [I] : ! [B] : ((((((maps(D,F,I) & maps(J,I,B)) & maps(L,B,F)) & injective(compose_function(L,compose_function(J,D,F,I,B),F,B,F),F,F)) & injective(compose_function(D,compose_function(L,J,I,B,F),I,F,I),I,I)) & surjective(compose_function(J,compose_function(D,L,B,F,I),B,I,B),B,B)) => one_to_one(L,B,F))).
fof(myForms, conjecture, ! [F] : ! [I] : ! [B] : ((((((maps(D,F,I) & maps(J,I,B)) & maps(L,B,F)) & injective(compose_function(L,compose_function(J,D,F,I,B),F,B,F),F,F)) & injective(compose_function(D,compose_function(L,J,I,B,F),I,F,I),I,I)) & surjective(compose_function(J,compose_function(D,L,B,F,I),B,I,B),B,B)) => one_to_one(L,B,F))).
fof(myForms, conjecture, ! [I] : ! [B] : ((((((maps(D,F,I) & maps(J,I,B)) & maps(L,B,F)) & injective(compose_function(L,compose_function(J,D,F,I,B),F,B,F),F,F)) & injective(compose_function(D,compose_function(L,J,I,B,F),I,F,I),I,I)) & surjective(compose_function(J,compose_function(D,L,B,F,I),B,I,B),B,B)) => one_to_one(L,B,F))).
fof(myForms, conjecture, ! [B] : ((((((maps(D,F,I) & maps(J,I,B)) & maps(L,B,F)) & injective(compose_function(L,compose_function(J,D,F,I,B),F,B,F),F,F)) & injective(compose_function(D,compose_function(L,J,I,B,F),I,F,I),I,I)) & surjective(compose_function(J,compose_function(D,L,B,F,I),B,I,B),B,B)) => one_to_one(L,B,F))).
fof(myForms, conjecture, ((((((maps(D,F,I) & maps(J,I,B)) & maps(L,B,F)) & injective(compose_function(L,compose_function(J,D,F,I,B),F,B,F),F,F)) & injective(compose_function(D,compose_function(L,J,I,B,F),I,F,I),I,I)) & surjective(compose_function(J,compose_function(D,L,B,F,I),B,I,B),B,B)) => one_to_one(L,B,F))).
fof(myForms, conjecture, (((((maps(D,F,I) & maps(J,I,B)) & maps(L,B,F)) & injective(compose_function(L,compose_function(J,D,F,I,B),F,B,F),F,F)) & injective(compose_function(D,compose_function(L,J,I,B,F),I,F,I),I,I)) & surjective(compose_function(J,compose_function(D,L,B,F,I),B,I,B),B,B))).
fof(myForms, conjecture, ((((maps(D,F,I) & maps(J,I,B)) & maps(L,B,F)) & injective(compose_function(L,compose_function(J,D,F,I,B),F,B,F),F,F)) & injective(compose_function(D,compose_function(L,J,I,B,F),I,F,I),I,I))).
fof(myForms, conjecture, (((maps(D,F,I) & maps(J,I,B)) & maps(L,B,F)) & injective(compose_function(L,compose_function(J,D,F,I,B),F,B,F),F,F))).
fof(myForms, conjecture, ((maps(D,F,I) & maps(J,I,B)) & maps(L,B,F))).
fof(myForms, conjecture, (maps(D,F,I) & maps(J,I,B))).
fof(myForms, conjecture, maps(D,F,I)).
fof(myForms, conjecture, maps(J,I,B)).
fof(myForms, conjecture, maps(L,B,F)).
fof(myForms, conjecture, injective(compose_function(L,compose_function(J,D,F,I,B),F,B,F),F,F)).
fof(myForms, conjecture, injective(compose_function(D,compose_function(L,J,I,B,F),I,F,I),I,I)).
fof(myForms, conjecture, surjective(compose_function(J,compose_function(D,L,B,F,I),B,I,B),B,B)).
fof(myForms, conjecture, one_to_one(L,B,F)).