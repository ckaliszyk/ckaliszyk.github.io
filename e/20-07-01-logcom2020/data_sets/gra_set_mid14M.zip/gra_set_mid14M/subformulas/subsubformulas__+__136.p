fof(myForms, conjecture, (apply(C1,F1,M) & apply(C1,G1,N))).
fof(myForms, conjecture, apply(C1,F1,M)).
fof(myForms, conjecture, apply(C1,G1,N)).