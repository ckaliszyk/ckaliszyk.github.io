fof(myForms, conjecture, ! [J] : ! [K] : ! [L] : ! [M] : ! [N] : ! [O] : (((((((((((((((green(J,K) & green(J,L)) & green(K,L)) & green(J,M)) & green(K,M)) & green(L,M)) & green(J,N)) & green(K,N)) & green(L,N)) & green(M,N)) & green(J,O)) & green(K,O)) & green(L,O)) & green(M,O)) & green(N,O)) => goal)).
fof(myForms, conjecture, ! [K] : ! [L] : ! [M] : ! [N] : ! [O] : (((((((((((((((green(J,K) & green(J,L)) & green(K,L)) & green(J,M)) & green(K,M)) & green(L,M)) & green(J,N)) & green(K,N)) & green(L,N)) & green(M,N)) & green(J,O)) & green(K,O)) & green(L,O)) & green(M,O)) & green(N,O)) => goal)).
fof(myForms, conjecture, ! [L] : ! [M] : ! [N] : ! [O] : (((((((((((((((green(J,K) & green(J,L)) & green(K,L)) & green(J,M)) & green(K,M)) & green(L,M)) & green(J,N)) & green(K,N)) & green(L,N)) & green(M,N)) & green(J,O)) & green(K,O)) & green(L,O)) & green(M,O)) & green(N,O)) => goal)).
fof(myForms, conjecture, ! [M] : ! [N] : ! [O] : (((((((((((((((green(J,K) & green(J,L)) & green(K,L)) & green(J,M)) & green(K,M)) & green(L,M)) & green(J,N)) & green(K,N)) & green(L,N)) & green(M,N)) & green(J,O)) & green(K,O)) & green(L,O)) & green(M,O)) & green(N,O)) => goal)).
fof(myForms, conjecture, ! [N] : ! [O] : (((((((((((((((green(J,K) & green(J,L)) & green(K,L)) & green(J,M)) & green(K,M)) & green(L,M)) & green(J,N)) & green(K,N)) & green(L,N)) & green(M,N)) & green(J,O)) & green(K,O)) & green(L,O)) & green(M,O)) & green(N,O)) => goal)).
fof(myForms, conjecture, ! [O] : (((((((((((((((green(J,K) & green(J,L)) & green(K,L)) & green(J,M)) & green(K,M)) & green(L,M)) & green(J,N)) & green(K,N)) & green(L,N)) & green(M,N)) & green(J,O)) & green(K,O)) & green(L,O)) & green(M,O)) & green(N,O)) => goal)).
fof(myForms, conjecture, (((((((((((((((green(J,K) & green(J,L)) & green(K,L)) & green(J,M)) & green(K,M)) & green(L,M)) & green(J,N)) & green(K,N)) & green(L,N)) & green(M,N)) & green(J,O)) & green(K,O)) & green(L,O)) & green(M,O)) & green(N,O)) => goal)).
fof(myForms, conjecture, ((((((((((((((green(J,K) & green(J,L)) & green(K,L)) & green(J,M)) & green(K,M)) & green(L,M)) & green(J,N)) & green(K,N)) & green(L,N)) & green(M,N)) & green(J,O)) & green(K,O)) & green(L,O)) & green(M,O)) & green(N,O))).
fof(myForms, conjecture, (((((((((((((green(J,K) & green(J,L)) & green(K,L)) & green(J,M)) & green(K,M)) & green(L,M)) & green(J,N)) & green(K,N)) & green(L,N)) & green(M,N)) & green(J,O)) & green(K,O)) & green(L,O)) & green(M,O))).
fof(myForms, conjecture, ((((((((((((green(J,K) & green(J,L)) & green(K,L)) & green(J,M)) & green(K,M)) & green(L,M)) & green(J,N)) & green(K,N)) & green(L,N)) & green(M,N)) & green(J,O)) & green(K,O)) & green(L,O))).
fof(myForms, conjecture, (((((((((((green(J,K) & green(J,L)) & green(K,L)) & green(J,M)) & green(K,M)) & green(L,M)) & green(J,N)) & green(K,N)) & green(L,N)) & green(M,N)) & green(J,O)) & green(K,O))).
fof(myForms, conjecture, ((((((((((green(J,K) & green(J,L)) & green(K,L)) & green(J,M)) & green(K,M)) & green(L,M)) & green(J,N)) & green(K,N)) & green(L,N)) & green(M,N)) & green(J,O))).
fof(myForms, conjecture, (((((((((green(J,K) & green(J,L)) & green(K,L)) & green(J,M)) & green(K,M)) & green(L,M)) & green(J,N)) & green(K,N)) & green(L,N)) & green(M,N))).
fof(myForms, conjecture, ((((((((green(J,K) & green(J,L)) & green(K,L)) & green(J,M)) & green(K,M)) & green(L,M)) & green(J,N)) & green(K,N)) & green(L,N))).
fof(myForms, conjecture, (((((((green(J,K) & green(J,L)) & green(K,L)) & green(J,M)) & green(K,M)) & green(L,M)) & green(J,N)) & green(K,N))).
fof(myForms, conjecture, ((((((green(J,K) & green(J,L)) & green(K,L)) & green(J,M)) & green(K,M)) & green(L,M)) & green(J,N))).
fof(myForms, conjecture, (((((green(J,K) & green(J,L)) & green(K,L)) & green(J,M)) & green(K,M)) & green(L,M))).
fof(myForms, conjecture, ((((green(J,K) & green(J,L)) & green(K,L)) & green(J,M)) & green(K,M))).
fof(myForms, conjecture, (((green(J,K) & green(J,L)) & green(K,L)) & green(J,M))).
fof(myForms, conjecture, ((green(J,K) & green(J,L)) & green(K,L))).
fof(myForms, conjecture, (green(J,K) & green(J,L))).
fof(myForms, conjecture, green(J,K)).
fof(myForms, conjecture, green(J,L)).
fof(myForms, conjecture, green(K,L)).
fof(myForms, conjecture, green(J,M)).
fof(myForms, conjecture, green(K,M)).
fof(myForms, conjecture, green(L,M)).
fof(myForms, conjecture, green(J,N)).
fof(myForms, conjecture, green(K,N)).
fof(myForms, conjecture, green(L,N)).
fof(myForms, conjecture, green(M,N)).
fof(myForms, conjecture, green(J,O)).
fof(myForms, conjecture, green(K,O)).
fof(myForms, conjecture, green(L,O)).
fof(myForms, conjecture, green(M,O)).
fof(myForms, conjecture, green(N,O)).
fof(myForms, conjecture, goal).