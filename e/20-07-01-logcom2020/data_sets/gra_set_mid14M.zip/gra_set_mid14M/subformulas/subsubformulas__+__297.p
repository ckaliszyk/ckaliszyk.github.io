fof(myForms, conjecture, (ilf_type(I,set_type) => ! [B] : (ilf_type(B,set_type) => (! [Y] : (ilf_type(Y,subset_type(cross_product(I,B))) => ilf_type(Y,relation_type(I,B))) & ! [Z] : (ilf_type(Z,relation_type(I,B)) => ilf_type(Z,subset_type(cross_product(I,B)))))))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [B] : (ilf_type(B,set_type) => (! [Y] : (ilf_type(Y,subset_type(cross_product(I,B))) => ilf_type(Y,relation_type(I,B))) & ! [Z] : (ilf_type(Z,relation_type(I,B)) => ilf_type(Z,subset_type(cross_product(I,B))))))).
fof(myForms, conjecture, (ilf_type(B,set_type) => (! [Y] : (ilf_type(Y,subset_type(cross_product(I,B))) => ilf_type(Y,relation_type(I,B))) & ! [Z] : (ilf_type(Z,relation_type(I,B)) => ilf_type(Z,subset_type(cross_product(I,B))))))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, (! [Y] : (ilf_type(Y,subset_type(cross_product(I,B))) => ilf_type(Y,relation_type(I,B))) & ! [Z] : (ilf_type(Z,relation_type(I,B)) => ilf_type(Z,subset_type(cross_product(I,B)))))).
fof(myForms, conjecture, ! [Y] : (ilf_type(Y,subset_type(cross_product(I,B))) => ilf_type(Y,relation_type(I,B)))).
fof(myForms, conjecture, (ilf_type(Y,subset_type(cross_product(I,B))) => ilf_type(Y,relation_type(I,B)))).
fof(myForms, conjecture, ilf_type(Y,subset_type(cross_product(I,B)))).
fof(myForms, conjecture, ilf_type(Y,relation_type(I,B))).
fof(myForms, conjecture, ! [Z] : (ilf_type(Z,relation_type(I,B)) => ilf_type(Z,subset_type(cross_product(I,B))))).
fof(myForms, conjecture, (ilf_type(Z,relation_type(I,B)) => ilf_type(Z,subset_type(cross_product(I,B))))).
fof(myForms, conjecture, ilf_type(Z,relation_type(I,B))).
fof(myForms, conjecture, ilf_type(Z,subset_type(cross_product(I,B)))).