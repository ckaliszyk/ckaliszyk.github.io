fof(myForms, conjecture, ? [Y] : (ilf_type(Y,set_type) & member(Y,range_of(B)))).
fof(myForms, conjecture, (ilf_type(Y,set_type) & member(Y,range_of(B)))).
fof(myForms, conjecture, ilf_type(Y,set_type)).
fof(myForms, conjecture, member(Y,range_of(B))).