fof(myForms, conjecture, ! [J] : ! [K] : ! [L] : ! [M] : ((((((red(J,K) & red(J,L)) & red(K,L)) & red(J,M)) & red(K,M)) & red(L,M)) => goal)).
fof(myForms, conjecture, ! [K] : ! [L] : ! [M] : ((((((red(J,K) & red(J,L)) & red(K,L)) & red(J,M)) & red(K,M)) & red(L,M)) => goal)).
fof(myForms, conjecture, ! [L] : ! [M] : ((((((red(J,K) & red(J,L)) & red(K,L)) & red(J,M)) & red(K,M)) & red(L,M)) => goal)).
fof(myForms, conjecture, ! [M] : ((((((red(J,K) & red(J,L)) & red(K,L)) & red(J,M)) & red(K,M)) & red(L,M)) => goal)).
fof(myForms, conjecture, ((((((red(J,K) & red(J,L)) & red(K,L)) & red(J,M)) & red(K,M)) & red(L,M)) => goal)).
fof(myForms, conjecture, (((((red(J,K) & red(J,L)) & red(K,L)) & red(J,M)) & red(K,M)) & red(L,M))).
fof(myForms, conjecture, ((((red(J,K) & red(J,L)) & red(K,L)) & red(J,M)) & red(K,M))).
fof(myForms, conjecture, (((red(J,K) & red(J,L)) & red(K,L)) & red(J,M))).
fof(myForms, conjecture, ((red(J,K) & red(J,L)) & red(K,L))).
fof(myForms, conjecture, (red(J,K) & red(J,L))).
fof(myForms, conjecture, red(J,K)).
fof(myForms, conjecture, red(J,L)).
fof(myForms, conjecture, red(K,L)).
fof(myForms, conjecture, red(J,M)).
fof(myForms, conjecture, red(K,M)).
fof(myForms, conjecture, red(L,M)).
fof(myForms, conjecture, goal).