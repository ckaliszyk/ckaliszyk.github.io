fof(myForms, conjecture, ! [D] : ! [F] : symmetric_difference(F,D)=symmetric_difference(D,F)).
fof(myForms, conjecture, ! [F] : symmetric_difference(F,D)=symmetric_difference(D,F)).
fof(myForms, conjecture, symmetric_difference(F,D)=symmetric_difference(D,F)).