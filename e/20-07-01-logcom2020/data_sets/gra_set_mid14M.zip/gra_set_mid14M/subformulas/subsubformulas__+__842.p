fof(myForms, conjecture, ((~ empty(B) & ilf_type(B,set_type)) => (ilf_type(I,member_type(B)) <=> member(I,B)))).
fof(myForms, conjecture, (~ empty(B) & ilf_type(B,set_type))).
fof(myForms, conjecture, ~ empty(B)).
fof(myForms, conjecture, empty(B)).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, (ilf_type(I,member_type(B)) <=> member(I,B))).
fof(myForms, conjecture, ilf_type(I,member_type(B))).
fof(myForms, conjecture, member(I,B)).