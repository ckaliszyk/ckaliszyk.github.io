fof(myForms, conjecture, ! [U] : ! [V] : (((((((((((((((red(Q,R) & red(Q,S)) & red(R,S)) & red(Q,T)) & red(R,T)) & red(S,T)) & red(Q,U)) & red(R,U)) & red(S,U)) & red(T,U)) & red(Q,V)) & red(R,V)) & red(S,V)) & red(T,V)) & red(U,V)) => goal)).
fof(myForms, conjecture, ! [V] : (((((((((((((((red(Q,R) & red(Q,S)) & red(R,S)) & red(Q,T)) & red(R,T)) & red(S,T)) & red(Q,U)) & red(R,U)) & red(S,U)) & red(T,U)) & red(Q,V)) & red(R,V)) & red(S,V)) & red(T,V)) & red(U,V)) => goal)).
fof(myForms, conjecture, (((((((((((((((red(Q,R) & red(Q,S)) & red(R,S)) & red(Q,T)) & red(R,T)) & red(S,T)) & red(Q,U)) & red(R,U)) & red(S,U)) & red(T,U)) & red(Q,V)) & red(R,V)) & red(S,V)) & red(T,V)) & red(U,V)) => goal)).
fof(myForms, conjecture, ((((((((((((((red(Q,R) & red(Q,S)) & red(R,S)) & red(Q,T)) & red(R,T)) & red(S,T)) & red(Q,U)) & red(R,U)) & red(S,U)) & red(T,U)) & red(Q,V)) & red(R,V)) & red(S,V)) & red(T,V)) & red(U,V))).
fof(myForms, conjecture, (((((((((((((red(Q,R) & red(Q,S)) & red(R,S)) & red(Q,T)) & red(R,T)) & red(S,T)) & red(Q,U)) & red(R,U)) & red(S,U)) & red(T,U)) & red(Q,V)) & red(R,V)) & red(S,V)) & red(T,V))).
fof(myForms, conjecture, ((((((((((((red(Q,R) & red(Q,S)) & red(R,S)) & red(Q,T)) & red(R,T)) & red(S,T)) & red(Q,U)) & red(R,U)) & red(S,U)) & red(T,U)) & red(Q,V)) & red(R,V)) & red(S,V))).
fof(myForms, conjecture, (((((((((((red(Q,R) & red(Q,S)) & red(R,S)) & red(Q,T)) & red(R,T)) & red(S,T)) & red(Q,U)) & red(R,U)) & red(S,U)) & red(T,U)) & red(Q,V)) & red(R,V))).
fof(myForms, conjecture, ((((((((((red(Q,R) & red(Q,S)) & red(R,S)) & red(Q,T)) & red(R,T)) & red(S,T)) & red(Q,U)) & red(R,U)) & red(S,U)) & red(T,U)) & red(Q,V))).
fof(myForms, conjecture, (((((((((red(Q,R) & red(Q,S)) & red(R,S)) & red(Q,T)) & red(R,T)) & red(S,T)) & red(Q,U)) & red(R,U)) & red(S,U)) & red(T,U))).
fof(myForms, conjecture, ((((((((red(Q,R) & red(Q,S)) & red(R,S)) & red(Q,T)) & red(R,T)) & red(S,T)) & red(Q,U)) & red(R,U)) & red(S,U))).
fof(myForms, conjecture, (((((((red(Q,R) & red(Q,S)) & red(R,S)) & red(Q,T)) & red(R,T)) & red(S,T)) & red(Q,U)) & red(R,U))).
fof(myForms, conjecture, ((((((red(Q,R) & red(Q,S)) & red(R,S)) & red(Q,T)) & red(R,T)) & red(S,T)) & red(Q,U))).
fof(myForms, conjecture, (((((red(Q,R) & red(Q,S)) & red(R,S)) & red(Q,T)) & red(R,T)) & red(S,T))).
fof(myForms, conjecture, ((((red(Q,R) & red(Q,S)) & red(R,S)) & red(Q,T)) & red(R,T))).
fof(myForms, conjecture, (((red(Q,R) & red(Q,S)) & red(R,S)) & red(Q,T))).
fof(myForms, conjecture, ((red(Q,R) & red(Q,S)) & red(R,S))).
fof(myForms, conjecture, (red(Q,R) & red(Q,S))).
fof(myForms, conjecture, red(Q,R)).
fof(myForms, conjecture, red(Q,S)).
fof(myForms, conjecture, red(R,S)).
fof(myForms, conjecture, red(Q,T)).
fof(myForms, conjecture, red(R,T)).
fof(myForms, conjecture, red(S,T)).
fof(myForms, conjecture, red(Q,U)).
fof(myForms, conjecture, red(R,U)).
fof(myForms, conjecture, red(S,U)).
fof(myForms, conjecture, red(T,U)).
fof(myForms, conjecture, red(Q,V)).
fof(myForms, conjecture, red(R,V)).
fof(myForms, conjecture, red(S,V)).
fof(myForms, conjecture, red(T,V)).
fof(myForms, conjecture, red(U,V)).
fof(myForms, conjecture, goal).