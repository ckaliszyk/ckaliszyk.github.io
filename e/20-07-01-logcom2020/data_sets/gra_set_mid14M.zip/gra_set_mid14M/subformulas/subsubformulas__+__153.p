fof(myForms, conjecture, ! [Y] : (member(Y,union(I,B)) <=> (member(Y,I) | member(Y,B)))).
fof(myForms, conjecture, (member(Y,union(I,B)) <=> (member(Y,I) | member(Y,B)))).
fof(myForms, conjecture, member(Y,union(I,B))).
fof(myForms, conjecture, (member(Y,I) | member(Y,B))).
fof(myForms, conjecture, member(Y,I)).
fof(myForms, conjecture, member(Y,B)).