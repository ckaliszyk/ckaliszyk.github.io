fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,relation_type(I,D)) => ilf_type(restrict4(I,D,F,J),relation_type(I,F))))))).
fof(myForms, conjecture, (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,relation_type(I,D)) => ilf_type(restrict4(I,D,F,J),relation_type(I,F))))))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,relation_type(I,D)) => ilf_type(restrict4(I,D,F,J),relation_type(I,F)))))).
fof(myForms, conjecture, (ilf_type(F,set_type) => ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,relation_type(I,D)) => ilf_type(restrict4(I,D,F,J),relation_type(I,F)))))).
fof(myForms, conjecture, ilf_type(F,set_type)).
fof(myForms, conjecture, ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,relation_type(I,D)) => ilf_type(restrict4(I,D,F,J),relation_type(I,F))))).
fof(myForms, conjecture, (ilf_type(I,set_type) => ! [J] : (ilf_type(J,relation_type(I,D)) => ilf_type(restrict4(I,D,F,J),relation_type(I,F))))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [J] : (ilf_type(J,relation_type(I,D)) => ilf_type(restrict4(I,D,F,J),relation_type(I,F)))).
fof(myForms, conjecture, (ilf_type(J,relation_type(I,D)) => ilf_type(restrict4(I,D,F,J),relation_type(I,F)))).
fof(myForms, conjecture, ilf_type(J,relation_type(I,D))).
fof(myForms, conjecture, ilf_type(restrict4(I,D,F,J),relation_type(I,F))).