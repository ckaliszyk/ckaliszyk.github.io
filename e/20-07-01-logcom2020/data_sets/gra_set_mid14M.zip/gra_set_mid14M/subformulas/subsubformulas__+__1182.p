fof(myForms, conjecture, ! [B] : ! [Y] : (! [Z] : (member(Z,I) <=> (member(Z,B) & ~ member(Z,Y))) => difference(B,Y)=I)).
fof(myForms, conjecture, ! [Y] : (! [Z] : (member(Z,I) <=> (member(Z,B) & ~ member(Z,Y))) => difference(B,Y)=I)).
fof(myForms, conjecture, (! [Z] : (member(Z,I) <=> (member(Z,B) & ~ member(Z,Y))) => difference(B,Y)=I)).
fof(myForms, conjecture, ! [Z] : (member(Z,I) <=> (member(Z,B) & ~ member(Z,Y)))).
fof(myForms, conjecture, (member(Z,I) <=> (member(Z,B) & ~ member(Z,Y)))).
fof(myForms, conjecture, member(Z,I)).
fof(myForms, conjecture, (member(Z,B) & ~ member(Z,Y))).
fof(myForms, conjecture, member(Z,B)).
fof(myForms, conjecture, ~ member(Z,Y)).
fof(myForms, conjecture, member(Z,Y)).
fof(myForms, conjecture, difference(B,Y)=I).