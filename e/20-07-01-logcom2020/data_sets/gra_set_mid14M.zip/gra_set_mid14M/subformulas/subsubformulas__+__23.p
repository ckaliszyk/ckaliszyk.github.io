fof(myForms, conjecture, ! [F] : ! [I] : ordered_pair(F,I)=unordered_pair(unordered_pair(F,I),singleton(F))).
fof(myForms, conjecture, ! [I] : ordered_pair(F,I)=unordered_pair(unordered_pair(F,I),singleton(F))).
fof(myForms, conjecture, ordered_pair(F,I)=unordered_pair(unordered_pair(F,I),singleton(F))).