fof(myForms, conjecture, ! [C] : ! [D] : ! [F] : ! [I] : (in(ordered_pair(C,D),cartesian_product2(singleton(F),singleton(I))) <=> (F=C & I=D))).
fof(myForms, conjecture, ! [D] : ! [F] : ! [I] : (in(ordered_pair(C,D),cartesian_product2(singleton(F),singleton(I))) <=> (F=C & I=D))).
fof(myForms, conjecture, ! [F] : ! [I] : (in(ordered_pair(C,D),cartesian_product2(singleton(F),singleton(I))) <=> (F=C & I=D))).
fof(myForms, conjecture, ! [I] : (in(ordered_pair(C,D),cartesian_product2(singleton(F),singleton(I))) <=> (F=C & I=D))).
fof(myForms, conjecture, (in(ordered_pair(C,D),cartesian_product2(singleton(F),singleton(I))) <=> (F=C & I=D))).
fof(myForms, conjecture, in(ordered_pair(C,D),cartesian_product2(singleton(F),singleton(I)))).
fof(myForms, conjecture, (F=C & I=D)).
fof(myForms, conjecture, F=C).
fof(myForms, conjecture, I=D).