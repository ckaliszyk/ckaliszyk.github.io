fof(myForms, conjecture, (path(N,O,P) => number_of_in(sequential_pairs,P)=minus(length_of(P),n1))).
fof(myForms, conjecture, path(N,O,P)).
fof(myForms, conjecture, number_of_in(sequential_pairs,P)=minus(length_of(P),n1)).