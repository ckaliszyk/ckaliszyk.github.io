fof(myForms, conjecture, (less_than(n1,n2) & less_than(n2,n3))).
fof(myForms, conjecture, less_than(n1,n2)).
fof(myForms, conjecture, less_than(n2,n3)).