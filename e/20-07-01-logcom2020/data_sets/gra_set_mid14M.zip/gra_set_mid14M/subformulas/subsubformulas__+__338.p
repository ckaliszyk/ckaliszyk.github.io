fof(myForms, conjecture, ! [I] : (set_difference(F,I)=empty_set <=> subset(F,I))).
fof(myForms, conjecture, (set_difference(F,I)=empty_set <=> subset(F,I))).
fof(myForms, conjecture, set_difference(F,I)=empty_set).
fof(myForms, conjecture, subset(F,I)).