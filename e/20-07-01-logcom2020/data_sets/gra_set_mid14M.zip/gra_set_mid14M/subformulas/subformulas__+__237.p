fof(myForms, conjecture, ! [D] : (ilf_type(D,binary_relation_type) => ((empty_set=domain_of(D) | range_of(D)=empty_set) => empty_set=D))).
fof(myForms, conjecture, (ilf_type(D,binary_relation_type) => ((empty_set=domain_of(D) | range_of(D)=empty_set) => empty_set=D))).
fof(myForms, conjecture, ilf_type(D,binary_relation_type)).
fof(myForms, conjecture, ((empty_set=domain_of(D) | range_of(D)=empty_set) => empty_set=D)).
fof(myForms, conjecture, (empty_set=domain_of(D) | range_of(D)=empty_set)).
fof(myForms, conjecture, empty_set=domain_of(D)).
fof(myForms, conjecture, range_of(D)=empty_set).
fof(myForms, conjecture, empty_set=D).