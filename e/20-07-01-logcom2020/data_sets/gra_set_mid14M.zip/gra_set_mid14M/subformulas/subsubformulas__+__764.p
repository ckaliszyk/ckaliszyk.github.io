fof(myForms, conjecture, (((member(W,universal_class) & member(D1,universal_class)) & ordered_pair(W,D1)=A1) | ((~ (? [R] : ? [B1] : ((member(R,universal_class) & member(B1,universal_class)) & ordered_pair(R,B1)=A1)) & A1=W) & D1=A1))).
fof(myForms, conjecture, ((member(W,universal_class) & member(D1,universal_class)) & ordered_pair(W,D1)=A1)).
fof(myForms, conjecture, (member(W,universal_class) & member(D1,universal_class))).
fof(myForms, conjecture, member(W,universal_class)).
fof(myForms, conjecture, member(D1,universal_class)).
fof(myForms, conjecture, ordered_pair(W,D1)=A1).
fof(myForms, conjecture, ((~ (? [R] : ? [B1] : ((member(R,universal_class) & member(B1,universal_class)) & ordered_pair(R,B1)=A1)) & A1=W) & D1=A1)).
fof(myForms, conjecture, (~ (? [R] : ? [B1] : ((member(R,universal_class) & member(B1,universal_class)) & ordered_pair(R,B1)=A1)) & A1=W)).
fof(myForms, conjecture, ~ (? [R] : ? [B1] : ((member(R,universal_class) & member(B1,universal_class)) & ordered_pair(R,B1)=A1))).
fof(myForms, conjecture, ? [R] : ? [B1] : ((member(R,universal_class) & member(B1,universal_class)) & ordered_pair(R,B1)=A1)).
fof(myForms, conjecture, ? [B1] : ((member(R,universal_class) & member(B1,universal_class)) & ordered_pair(R,B1)=A1)).
fof(myForms, conjecture, ((member(R,universal_class) & member(B1,universal_class)) & ordered_pair(R,B1)=A1)).
fof(myForms, conjecture, (member(R,universal_class) & member(B1,universal_class))).
fof(myForms, conjecture, member(R,universal_class)).
fof(myForms, conjecture, member(B1,universal_class)).
fof(myForms, conjecture, ordered_pair(R,B1)=A1).
fof(myForms, conjecture, A1=W).
fof(myForms, conjecture, D1=A1).