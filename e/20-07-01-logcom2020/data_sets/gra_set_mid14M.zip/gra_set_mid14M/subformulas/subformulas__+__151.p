fof(myForms, conjecture, ! [C] : ! [D] : (D=C <=> (subset(C,D) & subset(D,C)))).
fof(myForms, conjecture, ! [D] : (D=C <=> (subset(C,D) & subset(D,C)))).
fof(myForms, conjecture, (D=C <=> (subset(C,D) & subset(D,C)))).
fof(myForms, conjecture, D=C).
fof(myForms, conjecture, (subset(C,D) & subset(D,C))).
fof(myForms, conjecture, subset(C,D)).
fof(myForms, conjecture, subset(D,C)).