fof(myForms, conjecture, ! [I] : (powerset(F)=I <=> ! [B] : (in(B,I) <=> subset(B,F)))).
fof(myForms, conjecture, (powerset(F)=I <=> ! [B] : (in(B,I) <=> subset(B,F)))).
fof(myForms, conjecture, powerset(F)=I).
fof(myForms, conjecture, ! [B] : (in(B,I) <=> subset(B,F))).
fof(myForms, conjecture, (in(B,I) <=> subset(B,F))).
fof(myForms, conjecture, in(B,I)).
fof(myForms, conjecture, subset(B,F)).