fof(myForms, conjecture, ! [L] : ! [P] : (member(P,singleton(L)) => P=L)).
fof(myForms, conjecture, ! [P] : (member(P,singleton(L)) => P=L)).
fof(myForms, conjecture, (member(P,singleton(L)) => P=L)).
fof(myForms, conjecture, member(P,singleton(L))).
fof(myForms, conjecture, P=L).