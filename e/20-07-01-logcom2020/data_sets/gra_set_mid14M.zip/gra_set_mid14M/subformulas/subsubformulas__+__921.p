fof(myForms, conjecture, (subset(set_union2(singleton(F),I),I) => in(F,I))).
fof(myForms, conjecture, subset(set_union2(singleton(F),I),I)).
fof(myForms, conjecture, in(F,I)).