fof(myForms, conjecture, ! [C] : ! [D] : ! [F] : ((((subset(C,D) & ~ equal_set(C,D)) & subset(D,F)) & ~ equal_set(D,F)) => ~ equal_set(C,F))).
fof(myForms, conjecture, ! [D] : ! [F] : ((((subset(C,D) & ~ equal_set(C,D)) & subset(D,F)) & ~ equal_set(D,F)) => ~ equal_set(C,F))).
fof(myForms, conjecture, ! [F] : ((((subset(C,D) & ~ equal_set(C,D)) & subset(D,F)) & ~ equal_set(D,F)) => ~ equal_set(C,F))).
fof(myForms, conjecture, ((((subset(C,D) & ~ equal_set(C,D)) & subset(D,F)) & ~ equal_set(D,F)) => ~ equal_set(C,F))).
fof(myForms, conjecture, (((subset(C,D) & ~ equal_set(C,D)) & subset(D,F)) & ~ equal_set(D,F))).
fof(myForms, conjecture, ((subset(C,D) & ~ equal_set(C,D)) & subset(D,F))).
fof(myForms, conjecture, (subset(C,D) & ~ equal_set(C,D))).
fof(myForms, conjecture, subset(C,D)).
fof(myForms, conjecture, ~ equal_set(C,D)).
fof(myForms, conjecture, equal_set(C,D)).
fof(myForms, conjecture, subset(D,F)).
fof(myForms, conjecture, ~ equal_set(D,F)).
fof(myForms, conjecture, equal_set(D,F)).
fof(myForms, conjecture, ~ equal_set(C,F)).
fof(myForms, conjecture, equal_set(C,F)).