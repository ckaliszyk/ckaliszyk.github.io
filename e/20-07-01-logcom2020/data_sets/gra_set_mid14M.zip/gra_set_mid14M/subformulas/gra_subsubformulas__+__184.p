fof(myForms, conjecture, (complete => ! [N] : ! [O] : ! [P] : ! [K] : ! [L] : ((((shortest_path(N,O,P) & on_path(K,P)) & on_path(L,P)) & sequential(K,L)) => ? [M] : triangle(K,L,M)))).
fof(myForms, conjecture, complete).
fof(myForms, conjecture, ! [N] : ! [O] : ! [P] : ! [K] : ! [L] : ((((shortest_path(N,O,P) & on_path(K,P)) & on_path(L,P)) & sequential(K,L)) => ? [M] : triangle(K,L,M))).
fof(myForms, conjecture, ! [O] : ! [P] : ! [K] : ! [L] : ((((shortest_path(N,O,P) & on_path(K,P)) & on_path(L,P)) & sequential(K,L)) => ? [M] : triangle(K,L,M))).
fof(myForms, conjecture, ! [P] : ! [K] : ! [L] : ((((shortest_path(N,O,P) & on_path(K,P)) & on_path(L,P)) & sequential(K,L)) => ? [M] : triangle(K,L,M))).
fof(myForms, conjecture, ! [K] : ! [L] : ((((shortest_path(N,O,P) & on_path(K,P)) & on_path(L,P)) & sequential(K,L)) => ? [M] : triangle(K,L,M))).
fof(myForms, conjecture, ! [L] : ((((shortest_path(N,O,P) & on_path(K,P)) & on_path(L,P)) & sequential(K,L)) => ? [M] : triangle(K,L,M))).
fof(myForms, conjecture, ((((shortest_path(N,O,P) & on_path(K,P)) & on_path(L,P)) & sequential(K,L)) => ? [M] : triangle(K,L,M))).
fof(myForms, conjecture, (((shortest_path(N,O,P) & on_path(K,P)) & on_path(L,P)) & sequential(K,L))).
fof(myForms, conjecture, ((shortest_path(N,O,P) & on_path(K,P)) & on_path(L,P))).
fof(myForms, conjecture, (shortest_path(N,O,P) & on_path(K,P))).
fof(myForms, conjecture, shortest_path(N,O,P)).
fof(myForms, conjecture, on_path(K,P)).
fof(myForms, conjecture, on_path(L,P)).
fof(myForms, conjecture, sequential(K,L)).
fof(myForms, conjecture, ? [M] : triangle(K,L,M)).
fof(myForms, conjecture, triangle(K,L,M)).