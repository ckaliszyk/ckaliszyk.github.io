fof(myForms, conjecture, (((green(Q,R) & green(R,S)) & green(Q,S)) => goal)).
fof(myForms, conjecture, ((green(Q,R) & green(R,S)) & green(Q,S))).
fof(myForms, conjecture, (green(Q,R) & green(R,S))).
fof(myForms, conjecture, green(Q,R)).
fof(myForms, conjecture, green(R,S)).
fof(myForms, conjecture, green(Q,S)).
fof(myForms, conjecture, goal).