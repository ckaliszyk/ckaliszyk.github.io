fof(myForms, conjecture, (ilf_type(Y,set_type) => ! [Z] : (ilf_type(Z,relation_type(B,Y)) => (subset(I,Z) => ilf_type(I,relation_type(B,Y)))))).
fof(myForms, conjecture, ilf_type(Y,set_type)).
fof(myForms, conjecture, ! [Z] : (ilf_type(Z,relation_type(B,Y)) => (subset(I,Z) => ilf_type(I,relation_type(B,Y))))).
fof(myForms, conjecture, (ilf_type(Z,relation_type(B,Y)) => (subset(I,Z) => ilf_type(I,relation_type(B,Y))))).
fof(myForms, conjecture, ilf_type(Z,relation_type(B,Y))).
fof(myForms, conjecture, (subset(I,Z) => ilf_type(I,relation_type(B,Y)))).
fof(myForms, conjecture, subset(I,Z)).
fof(myForms, conjecture, ilf_type(I,relation_type(B,Y))).