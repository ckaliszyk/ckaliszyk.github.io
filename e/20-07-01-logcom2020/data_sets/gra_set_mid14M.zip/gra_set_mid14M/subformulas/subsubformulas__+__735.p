fof(myForms, conjecture, ! [B] : symmetric_difference(I,B)=symmetric_difference(B,I)).
fof(myForms, conjecture, symmetric_difference(I,B)=symmetric_difference(B,I)).