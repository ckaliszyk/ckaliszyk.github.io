fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ! [F] : ((~ empty(F) & ilf_type(F,set_type)) => (ilf_type(D,member_type(F)) <=> member(D,F))))).
fof(myForms, conjecture, (ilf_type(D,set_type) => ! [F] : ((~ empty(F) & ilf_type(F,set_type)) => (ilf_type(D,member_type(F)) <=> member(D,F))))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, ! [F] : ((~ empty(F) & ilf_type(F,set_type)) => (ilf_type(D,member_type(F)) <=> member(D,F)))).
fof(myForms, conjecture, ((~ empty(F) & ilf_type(F,set_type)) => (ilf_type(D,member_type(F)) <=> member(D,F)))).
fof(myForms, conjecture, (~ empty(F) & ilf_type(F,set_type))).
fof(myForms, conjecture, ~ empty(F)).
fof(myForms, conjecture, empty(F)).
fof(myForms, conjecture, ilf_type(F,set_type)).
fof(myForms, conjecture, (ilf_type(D,member_type(F)) <=> member(D,F))).
fof(myForms, conjecture, ilf_type(D,member_type(F))).
fof(myForms, conjecture, member(D,F)).