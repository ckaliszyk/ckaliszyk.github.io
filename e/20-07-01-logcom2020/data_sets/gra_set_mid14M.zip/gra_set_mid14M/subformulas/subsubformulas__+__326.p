fof(myForms, conjecture, (relation_like(I) & ilf_type(I,set_type))).
fof(myForms, conjecture, relation_like(I)).
fof(myForms, conjecture, ilf_type(I,set_type)).