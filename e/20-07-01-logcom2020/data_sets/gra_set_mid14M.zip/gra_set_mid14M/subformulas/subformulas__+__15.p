fof(myForms, conjecture, ! [B] : ! [E] : ! [G] : ! [H] : ! [C] : ! [D] : ! [F] : ((((maps(B,C,D) & maps(E,D,F)) & compose_predicate(G,E,B,C,D,F)) & compose_predicate(H,E,B,C,D,F)) => equal_maps(G,H,C,F))).
fof(myForms, conjecture, ! [E] : ! [G] : ! [H] : ! [C] : ! [D] : ! [F] : ((((maps(B,C,D) & maps(E,D,F)) & compose_predicate(G,E,B,C,D,F)) & compose_predicate(H,E,B,C,D,F)) => equal_maps(G,H,C,F))).
fof(myForms, conjecture, ! [G] : ! [H] : ! [C] : ! [D] : ! [F] : ((((maps(B,C,D) & maps(E,D,F)) & compose_predicate(G,E,B,C,D,F)) & compose_predicate(H,E,B,C,D,F)) => equal_maps(G,H,C,F))).
fof(myForms, conjecture, ! [H] : ! [C] : ! [D] : ! [F] : ((((maps(B,C,D) & maps(E,D,F)) & compose_predicate(G,E,B,C,D,F)) & compose_predicate(H,E,B,C,D,F)) => equal_maps(G,H,C,F))).
fof(myForms, conjecture, ! [C] : ! [D] : ! [F] : ((((maps(B,C,D) & maps(E,D,F)) & compose_predicate(G,E,B,C,D,F)) & compose_predicate(H,E,B,C,D,F)) => equal_maps(G,H,C,F))).
fof(myForms, conjecture, ! [D] : ! [F] : ((((maps(B,C,D) & maps(E,D,F)) & compose_predicate(G,E,B,C,D,F)) & compose_predicate(H,E,B,C,D,F)) => equal_maps(G,H,C,F))).
fof(myForms, conjecture, ! [F] : ((((maps(B,C,D) & maps(E,D,F)) & compose_predicate(G,E,B,C,D,F)) & compose_predicate(H,E,B,C,D,F)) => equal_maps(G,H,C,F))).
fof(myForms, conjecture, ((((maps(B,C,D) & maps(E,D,F)) & compose_predicate(G,E,B,C,D,F)) & compose_predicate(H,E,B,C,D,F)) => equal_maps(G,H,C,F))).
fof(myForms, conjecture, (((maps(B,C,D) & maps(E,D,F)) & compose_predicate(G,E,B,C,D,F)) & compose_predicate(H,E,B,C,D,F))).
fof(myForms, conjecture, ((maps(B,C,D) & maps(E,D,F)) & compose_predicate(G,E,B,C,D,F))).
fof(myForms, conjecture, (maps(B,C,D) & maps(E,D,F))).
fof(myForms, conjecture, maps(B,C,D)).
fof(myForms, conjecture, maps(E,D,F)).
fof(myForms, conjecture, compose_predicate(G,E,B,C,D,F)).
fof(myForms, conjecture, compose_predicate(H,E,B,C,D,F)).
fof(myForms, conjecture, equal_maps(G,H,C,F)).