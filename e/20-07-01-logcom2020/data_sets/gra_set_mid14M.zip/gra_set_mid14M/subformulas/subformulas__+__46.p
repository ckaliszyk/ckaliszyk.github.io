fof(myForms, conjecture, ! [D] : ! [F] : (difference(D,F)=empty_set <=> subset(D,F))).
fof(myForms, conjecture, ! [F] : (difference(D,F)=empty_set <=> subset(D,F))).
fof(myForms, conjecture, (difference(D,F)=empty_set <=> subset(D,F))).
fof(myForms, conjecture, difference(D,F)=empty_set).
fof(myForms, conjecture, subset(D,F)).