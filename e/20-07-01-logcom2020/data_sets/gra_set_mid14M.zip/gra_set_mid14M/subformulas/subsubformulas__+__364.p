fof(myForms, conjecture, ! [B] : ! [Y] : (intersect(I,intersection(B,Y)) => intersect(I,B))).
fof(myForms, conjecture, ! [Y] : (intersect(I,intersection(B,Y)) => intersect(I,B))).
fof(myForms, conjecture, (intersect(I,intersection(B,Y)) => intersect(I,B))).
fof(myForms, conjecture, intersect(I,intersection(B,Y))).
fof(myForms, conjecture, intersect(I,B)).