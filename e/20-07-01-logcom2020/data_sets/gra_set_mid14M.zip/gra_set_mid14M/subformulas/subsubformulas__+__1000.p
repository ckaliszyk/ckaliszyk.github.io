fof(myForms, conjecture, (! [B] : (in(B,F) <=> in(B,I)) => I=F)).
fof(myForms, conjecture, ! [B] : (in(B,F) <=> in(B,I))).
fof(myForms, conjecture, (in(B,F) <=> in(B,I))).
fof(myForms, conjecture, in(B,F)).
fof(myForms, conjecture, in(B,I)).
fof(myForms, conjecture, I=F).