fof(myForms, conjecture, ! [B] : (ilf_type(B,set_type) => (ilf_type(B,subset_type(I)) <=> ilf_type(B,member_type(power_set(I)))))).
fof(myForms, conjecture, (ilf_type(B,set_type) => (ilf_type(B,subset_type(I)) <=> ilf_type(B,member_type(power_set(I)))))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, (ilf_type(B,subset_type(I)) <=> ilf_type(B,member_type(power_set(I))))).
fof(myForms, conjecture, ilf_type(B,subset_type(I))).
fof(myForms, conjecture, ilf_type(B,member_type(power_set(I)))).