fof(myForms, conjecture, ! [I] : ! [B] : equal_set(union(F,intersection(I,B)),intersection(union(F,I),union(F,B)))).
fof(myForms, conjecture, ! [B] : equal_set(union(F,intersection(I,B)),intersection(union(F,I),union(F,B)))).
fof(myForms, conjecture, equal_set(union(F,intersection(I,B)),intersection(union(F,I),union(F,B)))).