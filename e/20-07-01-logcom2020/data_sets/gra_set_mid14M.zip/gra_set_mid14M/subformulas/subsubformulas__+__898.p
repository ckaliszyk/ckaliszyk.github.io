fof(myForms, conjecture, ! [I] : (subset(F,I) <=> ! [B] : (in(B,F) => in(B,I)))).
fof(myForms, conjecture, (subset(F,I) <=> ! [B] : (in(B,F) => in(B,I)))).
fof(myForms, conjecture, subset(F,I)).
fof(myForms, conjecture, ! [B] : (in(B,F) => in(B,I))).
fof(myForms, conjecture, (in(B,F) => in(B,I))).
fof(myForms, conjecture, in(B,F)).
fof(myForms, conjecture, in(B,I)).