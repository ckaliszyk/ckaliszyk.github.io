fof(myForms, conjecture, (red(Q,R) & red(R,S))).
fof(myForms, conjecture, red(Q,R)).
fof(myForms, conjecture, red(R,S)).