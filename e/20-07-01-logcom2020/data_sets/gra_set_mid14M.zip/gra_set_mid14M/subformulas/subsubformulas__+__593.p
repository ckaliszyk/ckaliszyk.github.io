fof(myForms, conjecture, ! [Y] : (ilf_type(Y,set_type) => ! [Z] : (ilf_type(Z,set_type) => ! [D] : (ilf_type(D,set_type) => (ordered_pair(Y,Z)=D <=> unordered_pair(unordered_pair(Y,Z),singleton(Y))=D))))).
fof(myForms, conjecture, (ilf_type(Y,set_type) => ! [Z] : (ilf_type(Z,set_type) => ! [D] : (ilf_type(D,set_type) => (ordered_pair(Y,Z)=D <=> unordered_pair(unordered_pair(Y,Z),singleton(Y))=D))))).
fof(myForms, conjecture, ilf_type(Y,set_type)).
fof(myForms, conjecture, ! [Z] : (ilf_type(Z,set_type) => ! [D] : (ilf_type(D,set_type) => (ordered_pair(Y,Z)=D <=> unordered_pair(unordered_pair(Y,Z),singleton(Y))=D)))).
fof(myForms, conjecture, (ilf_type(Z,set_type) => ! [D] : (ilf_type(D,set_type) => (ordered_pair(Y,Z)=D <=> unordered_pair(unordered_pair(Y,Z),singleton(Y))=D)))).
fof(myForms, conjecture, ilf_type(Z,set_type)).
fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => (ordered_pair(Y,Z)=D <=> unordered_pair(unordered_pair(Y,Z),singleton(Y))=D))).
fof(myForms, conjecture, (ilf_type(D,set_type) => (ordered_pair(Y,Z)=D <=> unordered_pair(unordered_pair(Y,Z),singleton(Y))=D))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, (ordered_pair(Y,Z)=D <=> unordered_pair(unordered_pair(Y,Z),singleton(Y))=D)).
fof(myForms, conjecture, ordered_pair(Y,Z)=D).
fof(myForms, conjecture, unordered_pair(unordered_pair(Y,Z),singleton(Y))=D).