fof(myForms, conjecture, ! [D] : (ilf_type(D,binary_relation_type) => ! [F] : (ilf_type(F,binary_relation_type) => (F=D => F=D)))).
fof(myForms, conjecture, (ilf_type(D,binary_relation_type) => ! [F] : (ilf_type(F,binary_relation_type) => (F=D => F=D)))).
fof(myForms, conjecture, ilf_type(D,binary_relation_type)).
fof(myForms, conjecture, ! [F] : (ilf_type(F,binary_relation_type) => (F=D => F=D))).
fof(myForms, conjecture, (ilf_type(F,binary_relation_type) => (F=D => F=D))).
fof(myForms, conjecture, ilf_type(F,binary_relation_type)).
fof(myForms, conjecture, (F=D => F=D)).
fof(myForms, conjecture, F=D).
fof(myForms, conjecture, F=D).