fof(myForms, conjecture, (ilf_type(I,set_type) => ! [B] : (ilf_type(B,set_type) => ! [Y] : (ilf_type(Y,set_type) => ! [Z] : (ilf_type(Z,binary_relation_type) => (member(ordered_pair(B,Y),restrict(I,Z)) <=> (member(Y,I) & member(ordered_pair(B,Y),Z)))))))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [B] : (ilf_type(B,set_type) => ! [Y] : (ilf_type(Y,set_type) => ! [Z] : (ilf_type(Z,binary_relation_type) => (member(ordered_pair(B,Y),restrict(I,Z)) <=> (member(Y,I) & member(ordered_pair(B,Y),Z))))))).
fof(myForms, conjecture, (ilf_type(B,set_type) => ! [Y] : (ilf_type(Y,set_type) => ! [Z] : (ilf_type(Z,binary_relation_type) => (member(ordered_pair(B,Y),restrict(I,Z)) <=> (member(Y,I) & member(ordered_pair(B,Y),Z))))))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ! [Y] : (ilf_type(Y,set_type) => ! [Z] : (ilf_type(Z,binary_relation_type) => (member(ordered_pair(B,Y),restrict(I,Z)) <=> (member(Y,I) & member(ordered_pair(B,Y),Z)))))).
fof(myForms, conjecture, (ilf_type(Y,set_type) => ! [Z] : (ilf_type(Z,binary_relation_type) => (member(ordered_pair(B,Y),restrict(I,Z)) <=> (member(Y,I) & member(ordered_pair(B,Y),Z)))))).
fof(myForms, conjecture, ilf_type(Y,set_type)).
fof(myForms, conjecture, ! [Z] : (ilf_type(Z,binary_relation_type) => (member(ordered_pair(B,Y),restrict(I,Z)) <=> (member(Y,I) & member(ordered_pair(B,Y),Z))))).
fof(myForms, conjecture, (ilf_type(Z,binary_relation_type) => (member(ordered_pair(B,Y),restrict(I,Z)) <=> (member(Y,I) & member(ordered_pair(B,Y),Z))))).
fof(myForms, conjecture, ilf_type(Z,binary_relation_type)).
fof(myForms, conjecture, (member(ordered_pair(B,Y),restrict(I,Z)) <=> (member(Y,I) & member(ordered_pair(B,Y),Z)))).
fof(myForms, conjecture, member(ordered_pair(B,Y),restrict(I,Z))).
fof(myForms, conjecture, (member(Y,I) & member(ordered_pair(B,Y),Z))).
fof(myForms, conjecture, member(Y,I)).
fof(myForms, conjecture, member(ordered_pair(B,Y),Z)).