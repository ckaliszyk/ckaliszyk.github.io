fof(myForms, conjecture, ! [D] : ((empty(D) & ilf_type(D,set_type)) => relation_like(D))).
fof(myForms, conjecture, ((empty(D) & ilf_type(D,set_type)) => relation_like(D))).
fof(myForms, conjecture, (empty(D) & ilf_type(D,set_type))).
fof(myForms, conjecture, empty(D)).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, relation_like(D)).