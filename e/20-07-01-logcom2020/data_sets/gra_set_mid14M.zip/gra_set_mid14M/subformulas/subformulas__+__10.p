fof(myForms, conjecture, ! [C] : ! [D] : ((member(C,on) & member(D,on)) => ~ ((member(C,D) & member(D,C))))).
fof(myForms, conjecture, ! [D] : ((member(C,on) & member(D,on)) => ~ ((member(C,D) & member(D,C))))).
fof(myForms, conjecture, ((member(C,on) & member(D,on)) => ~ ((member(C,D) & member(D,C))))).
fof(myForms, conjecture, (member(C,on) & member(D,on))).
fof(myForms, conjecture, member(C,on)).
fof(myForms, conjecture, member(D,on)).
fof(myForms, conjecture, ~ ((member(C,D) & member(D,C)))).
fof(myForms, conjecture, (member(C,D) & member(D,C))).
fof(myForms, conjecture, member(C,D)).
fof(myForms, conjecture, member(D,C)).