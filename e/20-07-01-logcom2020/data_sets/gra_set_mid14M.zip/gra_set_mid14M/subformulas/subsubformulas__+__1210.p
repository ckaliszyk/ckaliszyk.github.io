fof(myForms, conjecture, (ilf_type(I,set_type) => ! [B] : (ilf_type(B,set_type) => ! [Y] : (ilf_type(Y,set_type) => ! [Z] : (ilf_type(Z,relation_type(B,Y)) => (subset(I,Z) => subset(I,cross_product(B,Y)))))))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [B] : (ilf_type(B,set_type) => ! [Y] : (ilf_type(Y,set_type) => ! [Z] : (ilf_type(Z,relation_type(B,Y)) => (subset(I,Z) => subset(I,cross_product(B,Y))))))).
fof(myForms, conjecture, (ilf_type(B,set_type) => ! [Y] : (ilf_type(Y,set_type) => ! [Z] : (ilf_type(Z,relation_type(B,Y)) => (subset(I,Z) => subset(I,cross_product(B,Y))))))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ! [Y] : (ilf_type(Y,set_type) => ! [Z] : (ilf_type(Z,relation_type(B,Y)) => (subset(I,Z) => subset(I,cross_product(B,Y)))))).
fof(myForms, conjecture, (ilf_type(Y,set_type) => ! [Z] : (ilf_type(Z,relation_type(B,Y)) => (subset(I,Z) => subset(I,cross_product(B,Y)))))).
fof(myForms, conjecture, ilf_type(Y,set_type)).
fof(myForms, conjecture, ! [Z] : (ilf_type(Z,relation_type(B,Y)) => (subset(I,Z) => subset(I,cross_product(B,Y))))).
fof(myForms, conjecture, (ilf_type(Z,relation_type(B,Y)) => (subset(I,Z) => subset(I,cross_product(B,Y))))).
fof(myForms, conjecture, ilf_type(Z,relation_type(B,Y))).
fof(myForms, conjecture, (subset(I,Z) => subset(I,cross_product(B,Y)))).
fof(myForms, conjecture, subset(I,Z)).
fof(myForms, conjecture, subset(I,cross_product(B,Y))).