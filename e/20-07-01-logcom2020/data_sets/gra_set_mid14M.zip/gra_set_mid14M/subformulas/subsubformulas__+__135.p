fof(myForms, conjecture, ! [I] : unordered_pair(I,F)=unordered_pair(F,I)).
fof(myForms, conjecture, unordered_pair(I,F)=unordered_pair(F,I)).