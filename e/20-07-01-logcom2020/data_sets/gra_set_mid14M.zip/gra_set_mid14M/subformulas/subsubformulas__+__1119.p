fof(myForms, conjecture, ! [B] : (ilf_type(B,set_type) => ilf_type(inverse2(I,B),set_type))).
fof(myForms, conjecture, (ilf_type(B,set_type) => ilf_type(inverse2(I,B),set_type))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ilf_type(inverse2(I,B),set_type)).