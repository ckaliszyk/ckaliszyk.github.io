fof(myForms, conjecture, ! [I] : (set_difference(singleton(F),singleton(I))=empty_set => I=F)).
fof(myForms, conjecture, (set_difference(singleton(F),singleton(I))=empty_set => I=F)).
fof(myForms, conjecture, set_difference(singleton(F),singleton(I))=empty_set).
fof(myForms, conjecture, I=F).