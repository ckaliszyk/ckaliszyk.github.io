fof(myForms, conjecture, ~ empty(power_set(I))).
fof(myForms, conjecture, empty(power_set(I))).