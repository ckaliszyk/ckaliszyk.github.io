fof(myForms, conjecture, (member(Y,difference(I,B)) <=> (member(Y,I) & ~ member(Y,B)))).
fof(myForms, conjecture, member(Y,difference(I,B))).
fof(myForms, conjecture, (member(Y,I) & ~ member(Y,B))).
fof(myForms, conjecture, member(Y,I)).
fof(myForms, conjecture, ~ member(Y,B)).
fof(myForms, conjecture, member(Y,B)).