fof(myForms, conjecture, ! [I] : (((maps(J,F,I) & maps(D,I,F)) & identity(compose_function(J,D,I,F,I),I)) => surjective(J,F,I))).
fof(myForms, conjecture, (((maps(J,F,I) & maps(D,I,F)) & identity(compose_function(J,D,I,F,I),I)) => surjective(J,F,I))).
fof(myForms, conjecture, ((maps(J,F,I) & maps(D,I,F)) & identity(compose_function(J,D,I,F,I),I))).
fof(myForms, conjecture, (maps(J,F,I) & maps(D,I,F))).
fof(myForms, conjecture, maps(J,F,I)).
fof(myForms, conjecture, maps(D,I,F)).
fof(myForms, conjecture, identity(compose_function(J,D,I,F,I),I)).
fof(myForms, conjecture, surjective(J,F,I)).