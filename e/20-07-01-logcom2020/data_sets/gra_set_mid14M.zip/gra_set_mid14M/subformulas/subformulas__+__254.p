fof(myForms, conjecture, ! [D] : ! [F] : ! [I] : (subset(D,F) => subset(difference(I,F),difference(I,D)))).
fof(myForms, conjecture, ! [F] : ! [I] : (subset(D,F) => subset(difference(I,F),difference(I,D)))).
fof(myForms, conjecture, ! [I] : (subset(D,F) => subset(difference(I,F),difference(I,D)))).
fof(myForms, conjecture, (subset(D,F) => subset(difference(I,F),difference(I,D)))).
fof(myForms, conjecture, subset(D,F)).
fof(myForms, conjecture, subset(difference(I,F),difference(I,D))).