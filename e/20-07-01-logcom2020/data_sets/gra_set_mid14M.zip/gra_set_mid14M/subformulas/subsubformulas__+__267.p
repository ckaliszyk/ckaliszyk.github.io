fof(myForms, conjecture, (ilf_type(D,member_type(B)) & member(D,range(I,B,Y)))).
fof(myForms, conjecture, ilf_type(D,member_type(B))).
fof(myForms, conjecture, member(D,range(I,B,Y))).