fof(myForms, conjecture, ! [I] : ! [B] : intersection(I,B)=intersection(B,I)).
fof(myForms, conjecture, ! [B] : intersection(I,B)=intersection(B,I)).
fof(myForms, conjecture, intersection(I,B)=intersection(B,I)).