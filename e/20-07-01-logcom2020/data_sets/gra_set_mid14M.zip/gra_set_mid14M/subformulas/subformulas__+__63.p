fof(myForms, conjecture, ! [D] : ! [F] : (intersect(D,F) => intersect(F,D))).
fof(myForms, conjecture, ! [F] : (intersect(D,F) => intersect(F,D))).
fof(myForms, conjecture, (intersect(D,F) => intersect(F,D))).
fof(myForms, conjecture, intersect(D,F)).
fof(myForms, conjecture, intersect(F,D)).