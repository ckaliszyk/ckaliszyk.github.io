fof(myForms, conjecture, (edge(M) & tail_of(M)=head_of(L))).
fof(myForms, conjecture, edge(M)).
fof(myForms, conjecture, tail_of(M)=head_of(L)).