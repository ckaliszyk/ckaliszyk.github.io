fof(myForms, conjecture, ! [B] : (difference(I,B)=empty_set <=> subset(I,B))).
fof(myForms, conjecture, (difference(I,B)=empty_set <=> subset(I,B))).
fof(myForms, conjecture, difference(I,B)=empty_set).
fof(myForms, conjecture, subset(I,B)).