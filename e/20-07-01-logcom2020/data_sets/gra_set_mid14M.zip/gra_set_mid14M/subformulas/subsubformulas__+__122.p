fof(myForms, conjecture, ~ ((in(Y,I) & in(Y,B)))).
fof(myForms, conjecture, (in(Y,I) & in(Y,B))).
fof(myForms, conjecture, in(Y,I)).
fof(myForms, conjecture, in(Y,B)).