fof(myForms, conjecture, (shortest_path(N,O,P) & on_path(K,P))).
fof(myForms, conjecture, shortest_path(N,O,P)).
fof(myForms, conjecture, on_path(K,P)).