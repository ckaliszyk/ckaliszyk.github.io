fof(myForms, conjecture, ! [Q] : ! [R] : ! [S] : (((red(Q,R) & red(R,S)) & red(Q,S)) => goal)).
fof(myForms, conjecture, ! [R] : ! [S] : (((red(Q,R) & red(R,S)) & red(Q,S)) => goal)).
fof(myForms, conjecture, ! [S] : (((red(Q,R) & red(R,S)) & red(Q,S)) => goal)).
fof(myForms, conjecture, (((red(Q,R) & red(R,S)) & red(Q,S)) => goal)).
fof(myForms, conjecture, ((red(Q,R) & red(R,S)) & red(Q,S))).
fof(myForms, conjecture, (red(Q,R) & red(R,S))).
fof(myForms, conjecture, red(Q,R)).
fof(myForms, conjecture, red(R,S)).
fof(myForms, conjecture, red(Q,S)).
fof(myForms, conjecture, goal).