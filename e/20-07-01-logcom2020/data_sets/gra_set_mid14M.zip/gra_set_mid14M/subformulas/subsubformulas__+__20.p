fof(myForms, conjecture, ! [I] : ! [B] : ! [Y] : (in(ordered_pair(F,I),cartesian_product2(B,Y)) => in(ordered_pair(I,F),cartesian_product2(Y,B)))).
fof(myForms, conjecture, ! [B] : ! [Y] : (in(ordered_pair(F,I),cartesian_product2(B,Y)) => in(ordered_pair(I,F),cartesian_product2(Y,B)))).
fof(myForms, conjecture, ! [Y] : (in(ordered_pair(F,I),cartesian_product2(B,Y)) => in(ordered_pair(I,F),cartesian_product2(Y,B)))).
fof(myForms, conjecture, (in(ordered_pair(F,I),cartesian_product2(B,Y)) => in(ordered_pair(I,F),cartesian_product2(Y,B)))).
fof(myForms, conjecture, in(ordered_pair(F,I),cartesian_product2(B,Y))).
fof(myForms, conjecture, in(ordered_pair(I,F),cartesian_product2(Y,B))).