fof(myForms, conjecture, ! [D] : ! [F] : ! [I] : ((maps(D,F,I) & one_to_one(D,F,I)) => maps(inverse_function(D,F,I),I,F))).
fof(myForms, conjecture, ! [F] : ! [I] : ((maps(D,F,I) & one_to_one(D,F,I)) => maps(inverse_function(D,F,I),I,F))).
fof(myForms, conjecture, ! [I] : ((maps(D,F,I) & one_to_one(D,F,I)) => maps(inverse_function(D,F,I),I,F))).
fof(myForms, conjecture, ((maps(D,F,I) & one_to_one(D,F,I)) => maps(inverse_function(D,F,I),I,F))).
fof(myForms, conjecture, (maps(D,F,I) & one_to_one(D,F,I))).
fof(myForms, conjecture, maps(D,F,I)).
fof(myForms, conjecture, one_to_one(D,F,I)).
fof(myForms, conjecture, maps(inverse_function(D,F,I),I,F)).