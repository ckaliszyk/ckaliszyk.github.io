fof(myForms, conjecture, (((member(R,universal_class) & member(B1,universal_class)) & unordered_pair(A1,B1)=unordered_pair(A1,R)) => B1=R)).
fof(myForms, conjecture, ((member(R,universal_class) & member(B1,universal_class)) & unordered_pair(A1,B1)=unordered_pair(A1,R))).
fof(myForms, conjecture, (member(R,universal_class) & member(B1,universal_class))).
fof(myForms, conjecture, member(R,universal_class)).
fof(myForms, conjecture, member(B1,universal_class)).
fof(myForms, conjecture, unordered_pair(A1,B1)=unordered_pair(A1,R)).
fof(myForms, conjecture, B1=R).