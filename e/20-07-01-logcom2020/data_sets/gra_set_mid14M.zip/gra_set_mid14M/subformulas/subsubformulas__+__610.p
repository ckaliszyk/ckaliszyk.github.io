fof(myForms, conjecture, (member(R,universal_class) | ordered_pair(A1,R)=second(ordered_pair(A1,R)))).
fof(myForms, conjecture, member(R,universal_class)).
fof(myForms, conjecture, ordered_pair(A1,R)=second(ordered_pair(A1,R))).