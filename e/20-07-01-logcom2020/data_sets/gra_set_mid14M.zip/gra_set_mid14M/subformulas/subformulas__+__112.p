fof(myForms, conjecture, ! [C] : ! [D] : (powerset(C)=D <=> ! [F] : (in(F,D) <=> subset(F,C)))).
fof(myForms, conjecture, ! [D] : (powerset(C)=D <=> ! [F] : (in(F,D) <=> subset(F,C)))).
fof(myForms, conjecture, (powerset(C)=D <=> ! [F] : (in(F,D) <=> subset(F,C)))).
fof(myForms, conjecture, powerset(C)=D).
fof(myForms, conjecture, ! [F] : (in(F,D) <=> subset(F,C))).
fof(myForms, conjecture, (in(F,D) <=> subset(F,C))).
fof(myForms, conjecture, in(F,D)).
fof(myForms, conjecture, subset(F,C)).