fof(myForms, conjecture, ! [B] : (ilf_type(B,binary_relation_type) => (member(I,domain_of(B)) => ? [Y] : (ilf_type(Y,set_type) & member(Y,range_of(B)))))).
fof(myForms, conjecture, (ilf_type(B,binary_relation_type) => (member(I,domain_of(B)) => ? [Y] : (ilf_type(Y,set_type) & member(Y,range_of(B)))))).
fof(myForms, conjecture, ilf_type(B,binary_relation_type)).
fof(myForms, conjecture, (member(I,domain_of(B)) => ? [Y] : (ilf_type(Y,set_type) & member(Y,range_of(B))))).
fof(myForms, conjecture, member(I,domain_of(B))).
fof(myForms, conjecture, ? [Y] : (ilf_type(Y,set_type) & member(Y,range_of(B)))).
fof(myForms, conjecture, (ilf_type(Y,set_type) & member(Y,range_of(B)))).
fof(myForms, conjecture, ilf_type(Y,set_type)).
fof(myForms, conjecture, member(Y,range_of(B))).