fof(myForms, conjecture, (((red(Q,R) & red(Q,S)) & red(R,S)) & red(Q,T))).
fof(myForms, conjecture, ((red(Q,R) & red(Q,S)) & red(R,S))).
fof(myForms, conjecture, (red(Q,R) & red(Q,S))).
fof(myForms, conjecture, red(Q,R)).
fof(myForms, conjecture, red(Q,S)).
fof(myForms, conjecture, red(R,S)).
fof(myForms, conjecture, red(Q,T)).