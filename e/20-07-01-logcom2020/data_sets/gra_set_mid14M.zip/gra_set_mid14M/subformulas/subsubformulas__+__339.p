fof(myForms, conjecture, ! [I] : ilf_type(I,set_type)).
fof(myForms, conjecture, ilf_type(I,set_type)).