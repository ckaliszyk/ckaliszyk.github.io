fof(myForms, conjecture, (complete => ! [N] : ! [O] : ! [K] : ! [L] : ! [P] : ((shortest_path(N,O,P) & precedes(K,L,P)) => ? [M] : ((edge(M) & tail_of(M)=head_of(L)) & tail_of(K)=head_of(M))))).
fof(myForms, conjecture, complete).
fof(myForms, conjecture, ! [N] : ! [O] : ! [K] : ! [L] : ! [P] : ((shortest_path(N,O,P) & precedes(K,L,P)) => ? [M] : ((edge(M) & tail_of(M)=head_of(L)) & tail_of(K)=head_of(M)))).
fof(myForms, conjecture, ! [O] : ! [K] : ! [L] : ! [P] : ((shortest_path(N,O,P) & precedes(K,L,P)) => ? [M] : ((edge(M) & tail_of(M)=head_of(L)) & tail_of(K)=head_of(M)))).
fof(myForms, conjecture, ! [K] : ! [L] : ! [P] : ((shortest_path(N,O,P) & precedes(K,L,P)) => ? [M] : ((edge(M) & tail_of(M)=head_of(L)) & tail_of(K)=head_of(M)))).
fof(myForms, conjecture, ! [L] : ! [P] : ((shortest_path(N,O,P) & precedes(K,L,P)) => ? [M] : ((edge(M) & tail_of(M)=head_of(L)) & tail_of(K)=head_of(M)))).
fof(myForms, conjecture, ! [P] : ((shortest_path(N,O,P) & precedes(K,L,P)) => ? [M] : ((edge(M) & tail_of(M)=head_of(L)) & tail_of(K)=head_of(M)))).
fof(myForms, conjecture, ((shortest_path(N,O,P) & precedes(K,L,P)) => ? [M] : ((edge(M) & tail_of(M)=head_of(L)) & tail_of(K)=head_of(M)))).
fof(myForms, conjecture, (shortest_path(N,O,P) & precedes(K,L,P))).
fof(myForms, conjecture, shortest_path(N,O,P)).
fof(myForms, conjecture, precedes(K,L,P)).
fof(myForms, conjecture, ? [M] : ((edge(M) & tail_of(M)=head_of(L)) & tail_of(K)=head_of(M))).
fof(myForms, conjecture, ((edge(M) & tail_of(M)=head_of(L)) & tail_of(K)=head_of(M))).
fof(myForms, conjecture, (edge(M) & tail_of(M)=head_of(L))).
fof(myForms, conjecture, edge(M)).
fof(myForms, conjecture, tail_of(M)=head_of(L)).
fof(myForms, conjecture, tail_of(K)=head_of(M)).