fof(myForms, conjecture, ! [I] : (in(F,I) => subset(F,union(I)))).
fof(myForms, conjecture, (in(F,I) => subset(F,union(I)))).
fof(myForms, conjecture, in(F,I)).
fof(myForms, conjecture, subset(F,union(I))).