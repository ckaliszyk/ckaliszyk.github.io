fof(myForms, conjecture, ! [N] : ! [O] : (shortest_path(N,O,P) => number_of_in(triangles,P)=minus(length_of(P),n1))).
fof(myForms, conjecture, ! [O] : (shortest_path(N,O,P) => number_of_in(triangles,P)=minus(length_of(P),n1))).
fof(myForms, conjecture, (shortest_path(N,O,P) => number_of_in(triangles,P)=minus(length_of(P),n1))).
fof(myForms, conjecture, shortest_path(N,O,P)).
fof(myForms, conjecture, number_of_in(triangles,P)=minus(length_of(P),n1)).