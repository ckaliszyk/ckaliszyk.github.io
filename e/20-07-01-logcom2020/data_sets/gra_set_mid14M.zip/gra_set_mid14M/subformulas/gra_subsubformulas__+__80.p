fof(myForms, conjecture, ((((((red(Q,R) & red(Q,S)) & red(R,S)) & red(Q,T)) & red(R,T)) & red(S,T)) => goal)).
fof(myForms, conjecture, (((((red(Q,R) & red(Q,S)) & red(R,S)) & red(Q,T)) & red(R,T)) & red(S,T))).
fof(myForms, conjecture, ((((red(Q,R) & red(Q,S)) & red(R,S)) & red(Q,T)) & red(R,T))).
fof(myForms, conjecture, (((red(Q,R) & red(Q,S)) & red(R,S)) & red(Q,T))).
fof(myForms, conjecture, ((red(Q,R) & red(Q,S)) & red(R,S))).
fof(myForms, conjecture, (red(Q,R) & red(Q,S))).
fof(myForms, conjecture, red(Q,R)).
fof(myForms, conjecture, red(Q,S)).
fof(myForms, conjecture, red(R,S)).
fof(myForms, conjecture, red(Q,T)).
fof(myForms, conjecture, red(R,T)).
fof(myForms, conjecture, red(S,T)).
fof(myForms, conjecture, goal).