fof(myForms, conjecture, ! [C] : ! [D] : (~ empty(C) => ~ empty(set_union2(C,D)))).
fof(myForms, conjecture, ! [D] : (~ empty(C) => ~ empty(set_union2(C,D)))).
fof(myForms, conjecture, (~ empty(C) => ~ empty(set_union2(C,D)))).
fof(myForms, conjecture, ~ empty(C)).
fof(myForms, conjecture, empty(C)).
fof(myForms, conjecture, ~ empty(set_union2(C,D))).
fof(myForms, conjecture, empty(set_union2(C,D))).