fof(myForms, conjecture, (member(Y,I) | member(Y,B))).
fof(myForms, conjecture, member(Y,I)).
fof(myForms, conjecture, member(Y,B)).