fof(myForms, conjecture, ! [F] : ! [I] : ! [W] : ! [D1] : (equal_set(unordered_pair(singleton(F),unordered_pair(F,I)),unordered_pair(singleton(W),unordered_pair(W,D1))) => W=F)).
fof(myForms, conjecture, ! [I] : ! [W] : ! [D1] : (equal_set(unordered_pair(singleton(F),unordered_pair(F,I)),unordered_pair(singleton(W),unordered_pair(W,D1))) => W=F)).
fof(myForms, conjecture, ! [W] : ! [D1] : (equal_set(unordered_pair(singleton(F),unordered_pair(F,I)),unordered_pair(singleton(W),unordered_pair(W,D1))) => W=F)).
fof(myForms, conjecture, ! [D1] : (equal_set(unordered_pair(singleton(F),unordered_pair(F,I)),unordered_pair(singleton(W),unordered_pair(W,D1))) => W=F)).
fof(myForms, conjecture, (equal_set(unordered_pair(singleton(F),unordered_pair(F,I)),unordered_pair(singleton(W),unordered_pair(W,D1))) => W=F)).
fof(myForms, conjecture, equal_set(unordered_pair(singleton(F),unordered_pair(F,I)),unordered_pair(singleton(W),unordered_pair(W,D1)))).
fof(myForms, conjecture, W=F).