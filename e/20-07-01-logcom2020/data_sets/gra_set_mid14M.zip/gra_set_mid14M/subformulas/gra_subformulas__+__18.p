fof(myForms, conjecture, (complete => ! [G] : ! [E] : ! [F] : (shortest_path(E,F,G) => number_of_in(triangles,G)=number_of_in(sequential_pairs,G)))).
fof(myForms, conjecture, complete).
fof(myForms, conjecture, ! [G] : ! [E] : ! [F] : (shortest_path(E,F,G) => number_of_in(triangles,G)=number_of_in(sequential_pairs,G))).
fof(myForms, conjecture, ! [E] : ! [F] : (shortest_path(E,F,G) => number_of_in(triangles,G)=number_of_in(sequential_pairs,G))).
fof(myForms, conjecture, ! [F] : (shortest_path(E,F,G) => number_of_in(triangles,G)=number_of_in(sequential_pairs,G))).
fof(myForms, conjecture, (shortest_path(E,F,G) => number_of_in(triangles,G)=number_of_in(sequential_pairs,G))).
fof(myForms, conjecture, shortest_path(E,F,G)).
fof(myForms, conjecture, number_of_in(triangles,G)=number_of_in(sequential_pairs,G)).