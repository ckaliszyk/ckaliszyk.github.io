fof(myForms, conjecture, (subset(A1,F) & subset(R,F))).
fof(myForms, conjecture, subset(A1,F)).
fof(myForms, conjecture, subset(R,F)).