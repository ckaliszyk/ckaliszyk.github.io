fof(myForms, conjecture, ! [I] : ! [B] : (set_difference(unordered_pair(F,I),B)=empty_set <=> (in(F,B) & in(I,B)))).
fof(myForms, conjecture, ! [B] : (set_difference(unordered_pair(F,I),B)=empty_set <=> (in(F,B) & in(I,B)))).
fof(myForms, conjecture, (set_difference(unordered_pair(F,I),B)=empty_set <=> (in(F,B) & in(I,B)))).
fof(myForms, conjecture, set_difference(unordered_pair(F,I),B)=empty_set).
fof(myForms, conjecture, (in(F,B) & in(I,B))).
fof(myForms, conjecture, in(F,B)).
fof(myForms, conjecture, in(I,B)).