fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => (F=D <=> ! [I] : (ilf_type(I,set_type) => (member(I,D) <=> member(I,F))))))).
fof(myForms, conjecture, (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => (F=D <=> ! [I] : (ilf_type(I,set_type) => (member(I,D) <=> member(I,F))))))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, ! [F] : (ilf_type(F,set_type) => (F=D <=> ! [I] : (ilf_type(I,set_type) => (member(I,D) <=> member(I,F)))))).
fof(myForms, conjecture, (ilf_type(F,set_type) => (F=D <=> ! [I] : (ilf_type(I,set_type) => (member(I,D) <=> member(I,F)))))).
fof(myForms, conjecture, ilf_type(F,set_type)).
fof(myForms, conjecture, (F=D <=> ! [I] : (ilf_type(I,set_type) => (member(I,D) <=> member(I,F))))).
fof(myForms, conjecture, F=D).
fof(myForms, conjecture, ! [I] : (ilf_type(I,set_type) => (member(I,D) <=> member(I,F)))).
fof(myForms, conjecture, (ilf_type(I,set_type) => (member(I,D) <=> member(I,F)))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, (member(I,D) <=> member(I,F))).
fof(myForms, conjecture, member(I,D)).
fof(myForms, conjecture, member(I,F)).