fof(myForms, conjecture, (~ empty(B) & ilf_type(B,set_type))).
fof(myForms, conjecture, ~ empty(B)).
fof(myForms, conjecture, empty(B)).
fof(myForms, conjecture, ilf_type(B,set_type)).