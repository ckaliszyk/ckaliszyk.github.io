fof(myForms, conjecture, ! [D] : ! [F] : ! [I] : ! [J] : ((subset(D,F) & subset(I,J)) => subset(difference(D,J),difference(F,I)))).
fof(myForms, conjecture, ! [F] : ! [I] : ! [J] : ((subset(D,F) & subset(I,J)) => subset(difference(D,J),difference(F,I)))).
fof(myForms, conjecture, ! [I] : ! [J] : ((subset(D,F) & subset(I,J)) => subset(difference(D,J),difference(F,I)))).
fof(myForms, conjecture, ! [J] : ((subset(D,F) & subset(I,J)) => subset(difference(D,J),difference(F,I)))).
fof(myForms, conjecture, ((subset(D,F) & subset(I,J)) => subset(difference(D,J),difference(F,I)))).
fof(myForms, conjecture, (subset(D,F) & subset(I,J))).
fof(myForms, conjecture, subset(D,F)).
fof(myForms, conjecture, subset(I,J)).
fof(myForms, conjecture, subset(difference(D,J),difference(F,I))).