fof(myForms, conjecture, (on_path(K,P) & on_path(L,P))).
fof(myForms, conjecture, on_path(K,P)).
fof(myForms, conjecture, on_path(L,P)).