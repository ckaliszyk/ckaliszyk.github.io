fof(myForms, conjecture, ! [C] : ! [D] : ~ ((disjoint(singleton(C),D) & in(C,D)))).
fof(myForms, conjecture, ! [D] : ~ ((disjoint(singleton(C),D) & in(C,D)))).
fof(myForms, conjecture, ~ ((disjoint(singleton(C),D) & in(C,D)))).
fof(myForms, conjecture, (disjoint(singleton(C),D) & in(C,D))).
fof(myForms, conjecture, disjoint(singleton(C),D)).
fof(myForms, conjecture, in(C,D)).