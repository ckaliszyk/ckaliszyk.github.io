fof(myForms, conjecture, (ilf_type(I,set_type) => ! [B] : (ilf_type(B,binary_relation_type) => ilf_type(restrict(I,B),binary_relation_type)))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [B] : (ilf_type(B,binary_relation_type) => ilf_type(restrict(I,B),binary_relation_type))).
fof(myForms, conjecture, (ilf_type(B,binary_relation_type) => ilf_type(restrict(I,B),binary_relation_type))).
fof(myForms, conjecture, ilf_type(B,binary_relation_type)).
fof(myForms, conjecture, ilf_type(restrict(I,B),binary_relation_type)).