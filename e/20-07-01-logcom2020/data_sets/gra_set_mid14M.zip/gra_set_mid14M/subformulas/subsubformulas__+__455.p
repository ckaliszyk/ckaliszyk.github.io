fof(myForms, conjecture, (ilf_type(Y,relation_type(I,B)) => range(I,B,Y)=range_of(Y))).
fof(myForms, conjecture, ilf_type(Y,relation_type(I,B))).
fof(myForms, conjecture, range(I,B,Y)=range_of(Y)).