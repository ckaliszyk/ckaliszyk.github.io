fof(myForms, conjecture, ! [D] : ! [F] : union(F,D)=union(D,F)).
fof(myForms, conjecture, ! [F] : union(F,D)=union(D,F)).
fof(myForms, conjecture, union(F,D)=union(D,F)).