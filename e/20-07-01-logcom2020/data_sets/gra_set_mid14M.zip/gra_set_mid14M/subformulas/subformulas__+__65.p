fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,set_type) => (member(ordered_pair(D,F),cross_product(I,J)) <=> (member(D,I) & member(F,J)))))))).
fof(myForms, conjecture, (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,set_type) => (member(ordered_pair(D,F),cross_product(I,J)) <=> (member(D,I) & member(F,J)))))))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,set_type) => (member(ordered_pair(D,F),cross_product(I,J)) <=> (member(D,I) & member(F,J))))))).
fof(myForms, conjecture, (ilf_type(F,set_type) => ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,set_type) => (member(ordered_pair(D,F),cross_product(I,J)) <=> (member(D,I) & member(F,J))))))).
fof(myForms, conjecture, ilf_type(F,set_type)).
fof(myForms, conjecture, ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,set_type) => (member(ordered_pair(D,F),cross_product(I,J)) <=> (member(D,I) & member(F,J)))))).
fof(myForms, conjecture, (ilf_type(I,set_type) => ! [J] : (ilf_type(J,set_type) => (member(ordered_pair(D,F),cross_product(I,J)) <=> (member(D,I) & member(F,J)))))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [J] : (ilf_type(J,set_type) => (member(ordered_pair(D,F),cross_product(I,J)) <=> (member(D,I) & member(F,J))))).
fof(myForms, conjecture, (ilf_type(J,set_type) => (member(ordered_pair(D,F),cross_product(I,J)) <=> (member(D,I) & member(F,J))))).
fof(myForms, conjecture, ilf_type(J,set_type)).
fof(myForms, conjecture, (member(ordered_pair(D,F),cross_product(I,J)) <=> (member(D,I) & member(F,J)))).
fof(myForms, conjecture, member(ordered_pair(D,F),cross_product(I,J))).
fof(myForms, conjecture, (member(D,I) & member(F,J))).
fof(myForms, conjecture, member(D,I)).
fof(myForms, conjecture, member(F,J)).