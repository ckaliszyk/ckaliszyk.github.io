fof(myForms, conjecture, ! [F] : ! [I] : (I=F <=> (subset(F,I) & subset(I,F)))).
fof(myForms, conjecture, ! [I] : (I=F <=> (subset(F,I) & subset(I,F)))).
fof(myForms, conjecture, (I=F <=> (subset(F,I) & subset(I,F)))).
fof(myForms, conjecture, I=F).
fof(myForms, conjecture, (subset(F,I) & subset(I,F))).
fof(myForms, conjecture, subset(F,I)).
fof(myForms, conjecture, subset(I,F)).