fof(myForms, conjecture, ((((less_than(n1,n2) & less_than(n2,n3)) & less_than(n3,n4)) & less_than(n4,n5)) & less_than(n5,n6))).
fof(myForms, conjecture, (((less_than(n1,n2) & less_than(n2,n3)) & less_than(n3,n4)) & less_than(n4,n5))).
fof(myForms, conjecture, ((less_than(n1,n2) & less_than(n2,n3)) & less_than(n3,n4))).
fof(myForms, conjecture, (less_than(n1,n2) & less_than(n2,n3))).
fof(myForms, conjecture, less_than(n1,n2)).
fof(myForms, conjecture, less_than(n2,n3)).
fof(myForms, conjecture, less_than(n3,n4)).
fof(myForms, conjecture, less_than(n4,n5)).
fof(myForms, conjecture, less_than(n5,n6)).