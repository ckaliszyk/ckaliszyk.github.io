fof(myForms, conjecture, (empty_set=I | I=F)).
fof(myForms, conjecture, empty_set=I).
fof(myForms, conjecture, I=F).