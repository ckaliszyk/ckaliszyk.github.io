fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => (empty(D) <=> ! [F] : (ilf_type(F,set_type) => ~ member(F,D))))).
fof(myForms, conjecture, (ilf_type(D,set_type) => (empty(D) <=> ! [F] : (ilf_type(F,set_type) => ~ member(F,D))))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, (empty(D) <=> ! [F] : (ilf_type(F,set_type) => ~ member(F,D)))).
fof(myForms, conjecture, empty(D)).
fof(myForms, conjecture, ! [F] : (ilf_type(F,set_type) => ~ member(F,D))).
fof(myForms, conjecture, (ilf_type(F,set_type) => ~ member(F,D))).
fof(myForms, conjecture, ilf_type(F,set_type)).
fof(myForms, conjecture, ~ member(F,D)).
fof(myForms, conjecture, member(F,D)).