fof(myForms, conjecture, (member(ordered_pair(Y,Z),D) => (member(Y,I) & member(Z,B)))).
fof(myForms, conjecture, member(ordered_pair(Y,Z),D)).
fof(myForms, conjecture, (member(Y,I) & member(Z,B))).
fof(myForms, conjecture, member(Y,I)).
fof(myForms, conjecture, member(Z,B)).