fof(myForms, conjecture, (~ disjoint(F,I) & ! [B] : ~ in(B,set_intersection2(F,I)))).
fof(myForms, conjecture, ~ disjoint(F,I)).
fof(myForms, conjecture, disjoint(F,I)).
fof(myForms, conjecture, ! [B] : ~ in(B,set_intersection2(F,I))).
fof(myForms, conjecture, ~ in(B,set_intersection2(F,I))).
fof(myForms, conjecture, in(B,set_intersection2(F,I))).