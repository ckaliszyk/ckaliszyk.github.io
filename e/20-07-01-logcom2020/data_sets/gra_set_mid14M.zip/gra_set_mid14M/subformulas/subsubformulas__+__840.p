fof(myForms, conjecture, (total_order(C1,Z) & max(Q,C1,Z))).
fof(myForms, conjecture, total_order(C1,Z)).
fof(myForms, conjecture, max(Q,C1,Z)).