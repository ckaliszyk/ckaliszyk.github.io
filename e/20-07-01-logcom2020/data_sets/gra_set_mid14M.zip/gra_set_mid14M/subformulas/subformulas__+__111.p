fof(myForms, conjecture, ! [C] : ! [D] : (cartesian_product2(D,D)=cartesian_product2(C,C) => D=C)).
fof(myForms, conjecture, ! [D] : (cartesian_product2(D,D)=cartesian_product2(C,C) => D=C)).
fof(myForms, conjecture, (cartesian_product2(D,D)=cartesian_product2(C,C) => D=C)).
fof(myForms, conjecture, cartesian_product2(D,D)=cartesian_product2(C,C)).
fof(myForms, conjecture, D=C).