fof(myForms, conjecture, ! [L] : (subclass(L,null_class) => null_class=L)).
fof(myForms, conjecture, (subclass(L,null_class) => null_class=L)).
fof(myForms, conjecture, subclass(L,null_class)).
fof(myForms, conjecture, null_class=L).