fof(myForms, conjecture, ! [F] : ! [A1] : ! [R] : ((subset(A1,F) & subset(R,F)) <=> subset(union(A1,R),F))).
fof(myForms, conjecture, ! [A1] : ! [R] : ((subset(A1,F) & subset(R,F)) <=> subset(union(A1,R),F))).
fof(myForms, conjecture, ! [R] : ((subset(A1,F) & subset(R,F)) <=> subset(union(A1,R),F))).
fof(myForms, conjecture, ((subset(A1,F) & subset(R,F)) <=> subset(union(A1,R),F))).
fof(myForms, conjecture, (subset(A1,F) & subset(R,F))).
fof(myForms, conjecture, subset(A1,F)).
fof(myForms, conjecture, subset(R,F)).
fof(myForms, conjecture, subset(union(A1,R),F)).