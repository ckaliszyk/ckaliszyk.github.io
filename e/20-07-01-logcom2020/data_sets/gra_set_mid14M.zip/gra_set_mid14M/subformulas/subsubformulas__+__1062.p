fof(myForms, conjecture, ! [F] : ! [I] : (set_difference(singleton(F),I)=empty_set <=> in(F,I))).
fof(myForms, conjecture, ! [I] : (set_difference(singleton(F),I)=empty_set <=> in(F,I))).
fof(myForms, conjecture, (set_difference(singleton(F),I)=empty_set <=> in(F,I))).
fof(myForms, conjecture, set_difference(singleton(F),I)=empty_set).
fof(myForms, conjecture, in(F,I)).