fof(myForms, conjecture, ! [R] : (member(R,singleton(A1)) => A1=R)).
fof(myForms, conjecture, (member(R,singleton(A1)) => A1=R)).
fof(myForms, conjecture, member(R,singleton(A1))).
fof(myForms, conjecture, A1=R).