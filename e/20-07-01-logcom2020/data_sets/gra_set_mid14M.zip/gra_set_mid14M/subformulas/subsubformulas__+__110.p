fof(myForms, conjecture, ! [B] : (intersect(I,B) <=> ? [Y] : (member(Y,I) & member(Y,B)))).
fof(myForms, conjecture, (intersect(I,B) <=> ? [Y] : (member(Y,I) & member(Y,B)))).
fof(myForms, conjecture, intersect(I,B)).
fof(myForms, conjecture, ? [Y] : (member(Y,I) & member(Y,B))).
fof(myForms, conjecture, (member(Y,I) & member(Y,B))).
fof(myForms, conjecture, member(Y,I)).
fof(myForms, conjecture, member(Y,B)).