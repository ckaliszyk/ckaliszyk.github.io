fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => (! [I] : (ilf_type(I,subset_type(cross_product(D,F))) => ilf_type(I,relation_type(D,F))) & ! [J] : (ilf_type(J,relation_type(D,F)) => ilf_type(J,subset_type(cross_product(D,F)))))))).
fof(myForms, conjecture, (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => (! [I] : (ilf_type(I,subset_type(cross_product(D,F))) => ilf_type(I,relation_type(D,F))) & ! [J] : (ilf_type(J,relation_type(D,F)) => ilf_type(J,subset_type(cross_product(D,F)))))))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, ! [F] : (ilf_type(F,set_type) => (! [I] : (ilf_type(I,subset_type(cross_product(D,F))) => ilf_type(I,relation_type(D,F))) & ! [J] : (ilf_type(J,relation_type(D,F)) => ilf_type(J,subset_type(cross_product(D,F))))))).
fof(myForms, conjecture, (ilf_type(F,set_type) => (! [I] : (ilf_type(I,subset_type(cross_product(D,F))) => ilf_type(I,relation_type(D,F))) & ! [J] : (ilf_type(J,relation_type(D,F)) => ilf_type(J,subset_type(cross_product(D,F))))))).
fof(myForms, conjecture, ilf_type(F,set_type)).
fof(myForms, conjecture, (! [I] : (ilf_type(I,subset_type(cross_product(D,F))) => ilf_type(I,relation_type(D,F))) & ! [J] : (ilf_type(J,relation_type(D,F)) => ilf_type(J,subset_type(cross_product(D,F)))))).
fof(myForms, conjecture, ! [I] : (ilf_type(I,subset_type(cross_product(D,F))) => ilf_type(I,relation_type(D,F)))).
fof(myForms, conjecture, (ilf_type(I,subset_type(cross_product(D,F))) => ilf_type(I,relation_type(D,F)))).
fof(myForms, conjecture, ilf_type(I,subset_type(cross_product(D,F)))).
fof(myForms, conjecture, ilf_type(I,relation_type(D,F))).
fof(myForms, conjecture, ! [J] : (ilf_type(J,relation_type(D,F)) => ilf_type(J,subset_type(cross_product(D,F))))).
fof(myForms, conjecture, (ilf_type(J,relation_type(D,F)) => ilf_type(J,subset_type(cross_product(D,F))))).
fof(myForms, conjecture, ilf_type(J,relation_type(D,F))).
fof(myForms, conjecture, ilf_type(J,subset_type(cross_product(D,F)))).