fof(myForms, conjecture, ! [B] : union(difference(I,B),difference(B,I))=symmetric_difference(I,B)).
fof(myForms, conjecture, union(difference(I,B),difference(B,I))=symmetric_difference(I,B)).