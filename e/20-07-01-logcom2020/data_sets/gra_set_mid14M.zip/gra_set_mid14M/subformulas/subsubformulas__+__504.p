fof(myForms, conjecture, (in(Y,B) <=> (in(Y,F) & in(Y,I)))).
fof(myForms, conjecture, in(Y,B)).
fof(myForms, conjecture, (in(Y,F) & in(Y,I))).
fof(myForms, conjecture, in(Y,F)).
fof(myForms, conjecture, in(Y,I)).