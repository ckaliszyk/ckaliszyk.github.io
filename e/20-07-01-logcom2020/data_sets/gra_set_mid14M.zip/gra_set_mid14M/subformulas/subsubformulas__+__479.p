fof(myForms, conjecture, ! [B] : ! [Y] : (subset(I,B) => subset(difference(Y,B),difference(Y,I)))).
fof(myForms, conjecture, ! [Y] : (subset(I,B) => subset(difference(Y,B),difference(Y,I)))).
fof(myForms, conjecture, (subset(I,B) => subset(difference(Y,B),difference(Y,I)))).
fof(myForms, conjecture, subset(I,B)).
fof(myForms, conjecture, subset(difference(Y,B),difference(Y,I))).