fof(myForms, conjecture, ! [C] : ! [D] : ~ ((in(C,D) & ! [F] : ~ ((in(F,D) & ! [I] : ~ ((in(I,D) & in(I,F)))))))).
fof(myForms, conjecture, ! [D] : ~ ((in(C,D) & ! [F] : ~ ((in(F,D) & ! [I] : ~ ((in(I,D) & in(I,F)))))))).
fof(myForms, conjecture, ~ ((in(C,D) & ! [F] : ~ ((in(F,D) & ! [I] : ~ ((in(I,D) & in(I,F)))))))).
fof(myForms, conjecture, (in(C,D) & ! [F] : ~ ((in(F,D) & ! [I] : ~ ((in(I,D) & in(I,F))))))).
fof(myForms, conjecture, in(C,D)).
fof(myForms, conjecture, ! [F] : ~ ((in(F,D) & ! [I] : ~ ((in(I,D) & in(I,F)))))).
fof(myForms, conjecture, ~ ((in(F,D) & ! [I] : ~ ((in(I,D) & in(I,F)))))).
fof(myForms, conjecture, (in(F,D) & ! [I] : ~ ((in(I,D) & in(I,F))))).
fof(myForms, conjecture, in(F,D)).
fof(myForms, conjecture, ! [I] : ~ ((in(I,D) & in(I,F)))).
fof(myForms, conjecture, ~ ((in(I,D) & in(I,F)))).
fof(myForms, conjecture, (in(I,D) & in(I,F))).
fof(myForms, conjecture, in(I,D)).
fof(myForms, conjecture, in(I,F)).