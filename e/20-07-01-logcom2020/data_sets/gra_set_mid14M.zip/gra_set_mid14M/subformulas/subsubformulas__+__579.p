fof(myForms, conjecture, ! [B] : (ilf_type(B,binary_relation_type) => (subset(I,B) <=> ! [Y] : (ilf_type(Y,set_type) => ! [Z] : (ilf_type(Z,set_type) => (member(ordered_pair(Y,Z),I) => member(ordered_pair(Y,Z),B))))))).
fof(myForms, conjecture, (ilf_type(B,binary_relation_type) => (subset(I,B) <=> ! [Y] : (ilf_type(Y,set_type) => ! [Z] : (ilf_type(Z,set_type) => (member(ordered_pair(Y,Z),I) => member(ordered_pair(Y,Z),B))))))).
fof(myForms, conjecture, ilf_type(B,binary_relation_type)).
fof(myForms, conjecture, (subset(I,B) <=> ! [Y] : (ilf_type(Y,set_type) => ! [Z] : (ilf_type(Z,set_type) => (member(ordered_pair(Y,Z),I) => member(ordered_pair(Y,Z),B)))))).
fof(myForms, conjecture, subset(I,B)).
fof(myForms, conjecture, ! [Y] : (ilf_type(Y,set_type) => ! [Z] : (ilf_type(Z,set_type) => (member(ordered_pair(Y,Z),I) => member(ordered_pair(Y,Z),B))))).
fof(myForms, conjecture, (ilf_type(Y,set_type) => ! [Z] : (ilf_type(Z,set_type) => (member(ordered_pair(Y,Z),I) => member(ordered_pair(Y,Z),B))))).
fof(myForms, conjecture, ilf_type(Y,set_type)).
fof(myForms, conjecture, ! [Z] : (ilf_type(Z,set_type) => (member(ordered_pair(Y,Z),I) => member(ordered_pair(Y,Z),B)))).
fof(myForms, conjecture, (ilf_type(Z,set_type) => (member(ordered_pair(Y,Z),I) => member(ordered_pair(Y,Z),B)))).
fof(myForms, conjecture, ilf_type(Z,set_type)).
fof(myForms, conjecture, (member(ordered_pair(Y,Z),I) => member(ordered_pair(Y,Z),B))).
fof(myForms, conjecture, member(ordered_pair(Y,Z),I)).
fof(myForms, conjecture, member(ordered_pair(Y,Z),B)).