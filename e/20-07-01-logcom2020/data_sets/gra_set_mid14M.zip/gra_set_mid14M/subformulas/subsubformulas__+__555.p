fof(myForms, conjecture, ! [Z] : (ilf_type(Z,set_type) => ilf_type(inverse4(I,B,Y,Z),subset_type(I)))).
fof(myForms, conjecture, (ilf_type(Z,set_type) => ilf_type(inverse4(I,B,Y,Z),subset_type(I)))).
fof(myForms, conjecture, ilf_type(Z,set_type)).
fof(myForms, conjecture, ilf_type(inverse4(I,B,Y,Z),subset_type(I))).