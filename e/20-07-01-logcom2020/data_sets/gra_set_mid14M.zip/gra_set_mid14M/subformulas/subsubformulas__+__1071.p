fof(myForms, conjecture, ! [F] : ! [I] : ~ ((in(F,I) & ! [B] : ~ ((in(B,I) & ! [Y] : ~ ((in(Y,I) & in(Y,B)))))))).
fof(myForms, conjecture, ! [I] : ~ ((in(F,I) & ! [B] : ~ ((in(B,I) & ! [Y] : ~ ((in(Y,I) & in(Y,B)))))))).
fof(myForms, conjecture, ~ ((in(F,I) & ! [B] : ~ ((in(B,I) & ! [Y] : ~ ((in(Y,I) & in(Y,B)))))))).
fof(myForms, conjecture, (in(F,I) & ! [B] : ~ ((in(B,I) & ! [Y] : ~ ((in(Y,I) & in(Y,B))))))).
fof(myForms, conjecture, in(F,I)).
fof(myForms, conjecture, ! [B] : ~ ((in(B,I) & ! [Y] : ~ ((in(Y,I) & in(Y,B)))))).
fof(myForms, conjecture, ~ ((in(B,I) & ! [Y] : ~ ((in(Y,I) & in(Y,B)))))).
fof(myForms, conjecture, (in(B,I) & ! [Y] : ~ ((in(Y,I) & in(Y,B))))).
fof(myForms, conjecture, in(B,I)).
fof(myForms, conjecture, ! [Y] : ~ ((in(Y,I) & in(Y,B)))).
fof(myForms, conjecture, ~ ((in(Y,I) & in(Y,B)))).
fof(myForms, conjecture, (in(Y,I) & in(Y,B))).
fof(myForms, conjecture, in(Y,I)).
fof(myForms, conjecture, in(Y,B)).