fof(myForms, conjecture, (member(D,inverse4(I,Y,Z,B)) <=> ? [J] : ((ilf_type(J,member_type(Y)) & member(ordered_pair(D,J),Z)) & member(J,B)))).
fof(myForms, conjecture, member(D,inverse4(I,Y,Z,B))).
fof(myForms, conjecture, ? [J] : ((ilf_type(J,member_type(Y)) & member(ordered_pair(D,J),Z)) & member(J,B))).
fof(myForms, conjecture, ((ilf_type(J,member_type(Y)) & member(ordered_pair(D,J),Z)) & member(J,B))).
fof(myForms, conjecture, (ilf_type(J,member_type(Y)) & member(ordered_pair(D,J),Z))).
fof(myForms, conjecture, ilf_type(J,member_type(Y))).
fof(myForms, conjecture, member(ordered_pair(D,J),Z)).
fof(myForms, conjecture, member(J,B)).