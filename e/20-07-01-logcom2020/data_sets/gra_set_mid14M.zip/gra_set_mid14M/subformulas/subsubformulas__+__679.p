fof(myForms, conjecture, ! [Z] : (ilf_type(Z,set_type) => inverse4(I,B,Y,Z)=inverse2(Y,Z))).
fof(myForms, conjecture, (ilf_type(Z,set_type) => inverse4(I,B,Y,Z)=inverse2(Y,Z))).
fof(myForms, conjecture, ilf_type(Z,set_type)).
fof(myForms, conjecture, inverse4(I,B,Y,Z)=inverse2(Y,Z)).