fof(myForms, conjecture, ! [J] : ! [K] : (less_than(J,K) => (red(J,K) | green(J,K)))).
fof(myForms, conjecture, ! [K] : (less_than(J,K) => (red(J,K) | green(J,K)))).
fof(myForms, conjecture, (less_than(J,K) => (red(J,K) | green(J,K)))).
fof(myForms, conjecture, less_than(J,K)).
fof(myForms, conjecture, (red(J,K) | green(J,K))).
fof(myForms, conjecture, red(J,K)).
fof(myForms, conjecture, green(J,K)).