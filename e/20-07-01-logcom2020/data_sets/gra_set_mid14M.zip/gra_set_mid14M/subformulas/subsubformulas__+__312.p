fof(myForms, conjecture, (set_union2(F,I)=B <=> ! [Y] : (in(Y,B) <=> (in(Y,F) | in(Y,I))))).
fof(myForms, conjecture, set_union2(F,I)=B).
fof(myForms, conjecture, ! [Y] : (in(Y,B) <=> (in(Y,F) | in(Y,I)))).
fof(myForms, conjecture, (in(Y,B) <=> (in(Y,F) | in(Y,I)))).
fof(myForms, conjecture, in(Y,B)).
fof(myForms, conjecture, (in(Y,F) | in(Y,I))).
fof(myForms, conjecture, in(Y,F)).
fof(myForms, conjecture, in(Y,I)).