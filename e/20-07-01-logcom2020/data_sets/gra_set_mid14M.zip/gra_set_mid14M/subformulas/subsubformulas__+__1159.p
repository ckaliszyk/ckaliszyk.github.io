fof(myForms, conjecture, (ilf_type(I,set_type) => ! [B] : ilf_type(B,set_type))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [B] : ilf_type(B,set_type)).
fof(myForms, conjecture, ilf_type(B,set_type)).