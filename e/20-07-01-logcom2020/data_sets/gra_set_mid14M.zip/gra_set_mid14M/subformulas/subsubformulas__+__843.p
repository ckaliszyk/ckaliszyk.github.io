fof(myForms, conjecture, (apply(C1,F,I) <=> (apply(O,F,I) & apply(O,I,F)))).
fof(myForms, conjecture, apply(C1,F,I)).
fof(myForms, conjecture, (apply(O,F,I) & apply(O,I,F))).
fof(myForms, conjecture, apply(O,F,I)).
fof(myForms, conjecture, apply(O,I,F)).