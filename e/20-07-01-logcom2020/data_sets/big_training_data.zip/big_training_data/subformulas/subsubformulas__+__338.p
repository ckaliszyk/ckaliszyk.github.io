fof(myForms, conjecture, ! [K1] : ! [F1] : ! [R] : ! [J1] : ((ordered_pair(K1,F1)=ordered_pair(R,J1) & member(F1,universal_class)) => J1=F1)).
fof(myForms, conjecture, ! [F1] : ! [R] : ! [J1] : ((ordered_pair(K1,F1)=ordered_pair(R,J1) & member(F1,universal_class)) => J1=F1)).
fof(myForms, conjecture, ! [R] : ! [J1] : ((ordered_pair(K1,F1)=ordered_pair(R,J1) & member(F1,universal_class)) => J1=F1)).
fof(myForms, conjecture, ! [J1] : ((ordered_pair(K1,F1)=ordered_pair(R,J1) & member(F1,universal_class)) => J1=F1)).
fof(myForms, conjecture, ((ordered_pair(K1,F1)=ordered_pair(R,J1) & member(F1,universal_class)) => J1=F1)).
fof(myForms, conjecture, (ordered_pair(K1,F1)=ordered_pair(R,J1) & member(F1,universal_class))).
fof(myForms, conjecture, ordered_pair(K1,F1)=ordered_pair(R,J1)).
fof(myForms, conjecture, member(F1,universal_class)).
fof(myForms, conjecture, J1=F1).