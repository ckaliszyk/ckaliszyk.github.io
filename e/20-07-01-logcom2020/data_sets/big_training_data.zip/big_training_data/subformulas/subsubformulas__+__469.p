fof(myForms, conjecture, (ilf_type(I1,set_type) => inverse4(I,B,E1,I1)=inverse2(E1,I1))).
fof(myForms, conjecture, ilf_type(I1,set_type)).
fof(myForms, conjecture, inverse4(I,B,E1,I1)=inverse2(E1,I1)).