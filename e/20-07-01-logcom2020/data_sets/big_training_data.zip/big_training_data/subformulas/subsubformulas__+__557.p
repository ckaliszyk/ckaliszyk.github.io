fof(myForms, conjecture, (in(F,cartesian_product2(I,B)) & ! [E1] : ! [I1] : ~ ordered_pair(E1,I1)=F)).
fof(myForms, conjecture, in(F,cartesian_product2(I,B))).
fof(myForms, conjecture, ! [E1] : ! [I1] : ~ ordered_pair(E1,I1)=F).
fof(myForms, conjecture, ! [I1] : ~ ordered_pair(E1,I1)=F).
fof(myForms, conjecture, ~ ordered_pair(E1,I1)=F).
fof(myForms, conjecture, ordered_pair(E1,I1)=F).