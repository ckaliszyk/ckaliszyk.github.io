fof(myForms, conjecture, ! [C] : ? [D] : (element(D,powerset(C)) & empty(D))).
fof(myForms, conjecture, ? [D] : (element(D,powerset(C)) & empty(D))).
fof(myForms, conjecture, (element(D,powerset(C)) & empty(D))).
fof(myForms, conjecture, element(D,powerset(C))).
fof(myForms, conjecture, empty(D)).