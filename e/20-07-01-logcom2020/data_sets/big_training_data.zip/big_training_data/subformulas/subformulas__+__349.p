fof(myForms, conjecture, ! [C] : ! [D] : ! [F] : ! [I] : ((disjoint(C,D) | disjoint(F,I)) => disjoint(cartesian_product2(C,F),cartesian_product2(D,I)))).
fof(myForms, conjecture, ! [D] : ! [F] : ! [I] : ((disjoint(C,D) | disjoint(F,I)) => disjoint(cartesian_product2(C,F),cartesian_product2(D,I)))).
fof(myForms, conjecture, ! [F] : ! [I] : ((disjoint(C,D) | disjoint(F,I)) => disjoint(cartesian_product2(C,F),cartesian_product2(D,I)))).
fof(myForms, conjecture, ! [I] : ((disjoint(C,D) | disjoint(F,I)) => disjoint(cartesian_product2(C,F),cartesian_product2(D,I)))).
fof(myForms, conjecture, ((disjoint(C,D) | disjoint(F,I)) => disjoint(cartesian_product2(C,F),cartesian_product2(D,I)))).
fof(myForms, conjecture, (disjoint(C,D) | disjoint(F,I))).
fof(myForms, conjecture, disjoint(C,D)).
fof(myForms, conjecture, disjoint(F,I)).
fof(myForms, conjecture, disjoint(cartesian_product2(C,F),cartesian_product2(D,I))).