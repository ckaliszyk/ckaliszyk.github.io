fof(myForms, conjecture, ! [I1] : ! [O] : ! [H1] : ((pre_order(O,I1) & ! [F] : ! [I] : ((member(F,I1) & member(I,I1)) => (apply(H1,F,I) <=> (apply(O,F,I) & apply(O,I,F))))) => ! [Y] : ! [Z] : ! [M] : ! [N] : ((((member(Y,I1) & member(Z,I1)) & member(M,I1)) & member(N,I1)) => (((apply(H1,Y,M) & apply(H1,Z,N)) & apply(O,Y,Z)) => apply(O,M,N))))).
fof(myForms, conjecture, ! [O] : ! [H1] : ((pre_order(O,I1) & ! [F] : ! [I] : ((member(F,I1) & member(I,I1)) => (apply(H1,F,I) <=> (apply(O,F,I) & apply(O,I,F))))) => ! [Y] : ! [Z] : ! [M] : ! [N] : ((((member(Y,I1) & member(Z,I1)) & member(M,I1)) & member(N,I1)) => (((apply(H1,Y,M) & apply(H1,Z,N)) & apply(O,Y,Z)) => apply(O,M,N))))).
fof(myForms, conjecture, ! [H1] : ((pre_order(O,I1) & ! [F] : ! [I] : ((member(F,I1) & member(I,I1)) => (apply(H1,F,I) <=> (apply(O,F,I) & apply(O,I,F))))) => ! [Y] : ! [Z] : ! [M] : ! [N] : ((((member(Y,I1) & member(Z,I1)) & member(M,I1)) & member(N,I1)) => (((apply(H1,Y,M) & apply(H1,Z,N)) & apply(O,Y,Z)) => apply(O,M,N))))).
fof(myForms, conjecture, ((pre_order(O,I1) & ! [F] : ! [I] : ((member(F,I1) & member(I,I1)) => (apply(H1,F,I) <=> (apply(O,F,I) & apply(O,I,F))))) => ! [Y] : ! [Z] : ! [M] : ! [N] : ((((member(Y,I1) & member(Z,I1)) & member(M,I1)) & member(N,I1)) => (((apply(H1,Y,M) & apply(H1,Z,N)) & apply(O,Y,Z)) => apply(O,M,N))))).
fof(myForms, conjecture, (pre_order(O,I1) & ! [F] : ! [I] : ((member(F,I1) & member(I,I1)) => (apply(H1,F,I) <=> (apply(O,F,I) & apply(O,I,F)))))).
fof(myForms, conjecture, pre_order(O,I1)).
fof(myForms, conjecture, ! [F] : ! [I] : ((member(F,I1) & member(I,I1)) => (apply(H1,F,I) <=> (apply(O,F,I) & apply(O,I,F))))).
fof(myForms, conjecture, ! [I] : ((member(F,I1) & member(I,I1)) => (apply(H1,F,I) <=> (apply(O,F,I) & apply(O,I,F))))).
fof(myForms, conjecture, ((member(F,I1) & member(I,I1)) => (apply(H1,F,I) <=> (apply(O,F,I) & apply(O,I,F))))).
fof(myForms, conjecture, (member(F,I1) & member(I,I1))).
fof(myForms, conjecture, member(F,I1)).
fof(myForms, conjecture, member(I,I1)).
fof(myForms, conjecture, (apply(H1,F,I) <=> (apply(O,F,I) & apply(O,I,F)))).
fof(myForms, conjecture, apply(H1,F,I)).
fof(myForms, conjecture, (apply(O,F,I) & apply(O,I,F))).
fof(myForms, conjecture, apply(O,F,I)).
fof(myForms, conjecture, apply(O,I,F)).
fof(myForms, conjecture, ! [Y] : ! [Z] : ! [M] : ! [N] : ((((member(Y,I1) & member(Z,I1)) & member(M,I1)) & member(N,I1)) => (((apply(H1,Y,M) & apply(H1,Z,N)) & apply(O,Y,Z)) => apply(O,M,N)))).
fof(myForms, conjecture, ! [Z] : ! [M] : ! [N] : ((((member(Y,I1) & member(Z,I1)) & member(M,I1)) & member(N,I1)) => (((apply(H1,Y,M) & apply(H1,Z,N)) & apply(O,Y,Z)) => apply(O,M,N)))).
fof(myForms, conjecture, ! [M] : ! [N] : ((((member(Y,I1) & member(Z,I1)) & member(M,I1)) & member(N,I1)) => (((apply(H1,Y,M) & apply(H1,Z,N)) & apply(O,Y,Z)) => apply(O,M,N)))).
fof(myForms, conjecture, ! [N] : ((((member(Y,I1) & member(Z,I1)) & member(M,I1)) & member(N,I1)) => (((apply(H1,Y,M) & apply(H1,Z,N)) & apply(O,Y,Z)) => apply(O,M,N)))).
fof(myForms, conjecture, ((((member(Y,I1) & member(Z,I1)) & member(M,I1)) & member(N,I1)) => (((apply(H1,Y,M) & apply(H1,Z,N)) & apply(O,Y,Z)) => apply(O,M,N)))).
fof(myForms, conjecture, (((member(Y,I1) & member(Z,I1)) & member(M,I1)) & member(N,I1))).
fof(myForms, conjecture, ((member(Y,I1) & member(Z,I1)) & member(M,I1))).
fof(myForms, conjecture, (member(Y,I1) & member(Z,I1))).
fof(myForms, conjecture, member(Y,I1)).
fof(myForms, conjecture, member(Z,I1)).
fof(myForms, conjecture, member(M,I1)).
fof(myForms, conjecture, member(N,I1)).
fof(myForms, conjecture, (((apply(H1,Y,M) & apply(H1,Z,N)) & apply(O,Y,Z)) => apply(O,M,N))).
fof(myForms, conjecture, ((apply(H1,Y,M) & apply(H1,Z,N)) & apply(O,Y,Z))).
fof(myForms, conjecture, (apply(H1,Y,M) & apply(H1,Z,N))).
fof(myForms, conjecture, apply(H1,Y,M)).
fof(myForms, conjecture, apply(H1,Z,N)).
fof(myForms, conjecture, apply(O,Y,Z)).
fof(myForms, conjecture, apply(O,M,N)).