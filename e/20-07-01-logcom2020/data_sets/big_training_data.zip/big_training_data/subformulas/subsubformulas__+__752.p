fof(myForms, conjecture, (in(F,I) & ~ F=B)).
fof(myForms, conjecture, in(F,I)).
fof(myForms, conjecture, ~ F=B).
fof(myForms, conjecture, F=B).