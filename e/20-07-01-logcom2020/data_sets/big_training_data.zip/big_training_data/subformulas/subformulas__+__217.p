fof(myForms, conjecture, ! [D] : ! [F] : ! [I] : union(difference(D,F),intersection(D,I))=difference(D,difference(F,I))).
fof(myForms, conjecture, ! [F] : ! [I] : union(difference(D,F),intersection(D,I))=difference(D,difference(F,I))).
fof(myForms, conjecture, ! [I] : union(difference(D,F),intersection(D,I))=difference(D,difference(F,I))).
fof(myForms, conjecture, union(difference(D,F),intersection(D,I))=difference(D,difference(F,I))).