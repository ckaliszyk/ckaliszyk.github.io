fof(myForms, conjecture, ! [D] : ! [F] : intersection(F,D)=intersection(D,F)).
fof(myForms, conjecture, ! [F] : intersection(F,D)=intersection(D,F)).
fof(myForms, conjecture, intersection(F,D)=intersection(D,F)).