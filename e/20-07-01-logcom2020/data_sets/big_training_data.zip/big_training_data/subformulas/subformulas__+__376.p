fof(myForms, conjecture, ! [B] : ! [E] : ! [C] : ! [D] : ! [F] : (((maps(B,C,D) & maps(E,D,F)) & injective(compose_function(E,B,C,D,F),C,F)) => injective(B,C,D))).
fof(myForms, conjecture, ! [E] : ! [C] : ! [D] : ! [F] : (((maps(B,C,D) & maps(E,D,F)) & injective(compose_function(E,B,C,D,F),C,F)) => injective(B,C,D))).
fof(myForms, conjecture, ! [C] : ! [D] : ! [F] : (((maps(B,C,D) & maps(E,D,F)) & injective(compose_function(E,B,C,D,F),C,F)) => injective(B,C,D))).
fof(myForms, conjecture, ! [D] : ! [F] : (((maps(B,C,D) & maps(E,D,F)) & injective(compose_function(E,B,C,D,F),C,F)) => injective(B,C,D))).
fof(myForms, conjecture, ! [F] : (((maps(B,C,D) & maps(E,D,F)) & injective(compose_function(E,B,C,D,F),C,F)) => injective(B,C,D))).
fof(myForms, conjecture, (((maps(B,C,D) & maps(E,D,F)) & injective(compose_function(E,B,C,D,F),C,F)) => injective(B,C,D))).
fof(myForms, conjecture, ((maps(B,C,D) & maps(E,D,F)) & injective(compose_function(E,B,C,D,F),C,F))).
fof(myForms, conjecture, (maps(B,C,D) & maps(E,D,F))).
fof(myForms, conjecture, maps(B,C,D)).
fof(myForms, conjecture, maps(E,D,F)).
fof(myForms, conjecture, injective(compose_function(E,B,C,D,F),C,F)).
fof(myForms, conjecture, injective(B,C,D)).