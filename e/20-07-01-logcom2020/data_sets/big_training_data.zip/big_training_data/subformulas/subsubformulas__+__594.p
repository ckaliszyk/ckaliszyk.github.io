fof(myForms, conjecture, ! [I] : ! [B] : (subset(F,I) => subset(set_difference(B,I),set_difference(B,F)))).
fof(myForms, conjecture, ! [B] : (subset(F,I) => subset(set_difference(B,I),set_difference(B,F)))).
fof(myForms, conjecture, (subset(F,I) => subset(set_difference(B,I),set_difference(B,F)))).
fof(myForms, conjecture, subset(F,I)).
fof(myForms, conjecture, subset(set_difference(B,I),set_difference(B,F))).