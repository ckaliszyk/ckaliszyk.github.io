fof(myForms, conjecture, ! [C] : ? [D] : ! [F] : (in(F,D) <=> (in(F,union(C)) & ? [I] : (I=F & ? [J] : (in(J,I) & in(J,C)))))).
fof(myForms, conjecture, ? [D] : ! [F] : (in(F,D) <=> (in(F,union(C)) & ? [I] : (I=F & ? [J] : (in(J,I) & in(J,C)))))).
fof(myForms, conjecture, ! [F] : (in(F,D) <=> (in(F,union(C)) & ? [I] : (I=F & ? [J] : (in(J,I) & in(J,C)))))).
fof(myForms, conjecture, (in(F,D) <=> (in(F,union(C)) & ? [I] : (I=F & ? [J] : (in(J,I) & in(J,C)))))).
fof(myForms, conjecture, in(F,D)).
fof(myForms, conjecture, (in(F,union(C)) & ? [I] : (I=F & ? [J] : (in(J,I) & in(J,C))))).
fof(myForms, conjecture, in(F,union(C))).
fof(myForms, conjecture, ? [I] : (I=F & ? [J] : (in(J,I) & in(J,C)))).
fof(myForms, conjecture, (I=F & ? [J] : (in(J,I) & in(J,C)))).
fof(myForms, conjecture, I=F).
fof(myForms, conjecture, ? [J] : (in(J,I) & in(J,C))).
fof(myForms, conjecture, (in(J,I) & in(J,C))).
fof(myForms, conjecture, in(J,I)).
fof(myForms, conjecture, in(J,C)).