fof(myForms, conjecture, ((in(F,I) & element(I,powerset(B))) & empty(B))).
fof(myForms, conjecture, (in(F,I) & element(I,powerset(B)))).
fof(myForms, conjecture, in(F,I)).
fof(myForms, conjecture, element(I,powerset(B))).
fof(myForms, conjecture, empty(B)).