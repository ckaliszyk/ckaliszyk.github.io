fof(myForms, conjecture, ! [F] : ! [F1] : ! [R] : ((subset(F1,F) & subset(R,F)) <=> subset(union(F1,R),F))).
fof(myForms, conjecture, ! [F1] : ! [R] : ((subset(F1,F) & subset(R,F)) <=> subset(union(F1,R),F))).
fof(myForms, conjecture, ! [R] : ((subset(F1,F) & subset(R,F)) <=> subset(union(F1,R),F))).
fof(myForms, conjecture, ((subset(F1,F) & subset(R,F)) <=> subset(union(F1,R),F))).
fof(myForms, conjecture, (subset(F1,F) & subset(R,F))).
fof(myForms, conjecture, subset(F1,F)).
fof(myForms, conjecture, subset(R,F)).
fof(myForms, conjecture, subset(union(F1,R),F)).