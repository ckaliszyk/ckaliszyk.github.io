fof(myForms, conjecture, ((~ (? [R] : ? [J1] : ((member(R,universal_class) & member(J1,universal_class)) & ordered_pair(R,J1)=F1)) & F1=W) & G1=F1)).
fof(myForms, conjecture, (~ (? [R] : ? [J1] : ((member(R,universal_class) & member(J1,universal_class)) & ordered_pair(R,J1)=F1)) & F1=W)).
fof(myForms, conjecture, ~ (? [R] : ? [J1] : ((member(R,universal_class) & member(J1,universal_class)) & ordered_pair(R,J1)=F1))).
fof(myForms, conjecture, ? [R] : ? [J1] : ((member(R,universal_class) & member(J1,universal_class)) & ordered_pair(R,J1)=F1)).
fof(myForms, conjecture, ? [J1] : ((member(R,universal_class) & member(J1,universal_class)) & ordered_pair(R,J1)=F1)).
fof(myForms, conjecture, ((member(R,universal_class) & member(J1,universal_class)) & ordered_pair(R,J1)=F1)).
fof(myForms, conjecture, (member(R,universal_class) & member(J1,universal_class))).
fof(myForms, conjecture, member(R,universal_class)).
fof(myForms, conjecture, member(J1,universal_class)).
fof(myForms, conjecture, ordered_pair(R,J1)=F1).
fof(myForms, conjecture, F1=W).
fof(myForms, conjecture, G1=F1).