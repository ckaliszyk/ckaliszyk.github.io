fof(myForms, conjecture, (set_equal(F1,R) <=> ! [J1] : (element(J1,F1) <=> element(J1,R)))).
fof(myForms, conjecture, set_equal(F1,R)).
fof(myForms, conjecture, ! [J1] : (element(J1,F1) <=> element(J1,R))).
fof(myForms, conjecture, (element(J1,F1) <=> element(J1,R))).
fof(myForms, conjecture, element(J1,F1)).
fof(myForms, conjecture, element(J1,R)).