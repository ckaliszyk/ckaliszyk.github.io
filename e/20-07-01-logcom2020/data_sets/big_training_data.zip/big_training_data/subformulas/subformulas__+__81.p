fof(myForms, conjecture, ! [C] : ~ empty(powerset(C))).
fof(myForms, conjecture, ~ empty(powerset(C))).
fof(myForms, conjecture, empty(powerset(C))).