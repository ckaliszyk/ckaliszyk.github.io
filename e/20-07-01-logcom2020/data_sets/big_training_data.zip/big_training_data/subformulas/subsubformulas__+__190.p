fof(myForms, conjecture, ! [I] : ! [B] : disjoint(intersection(I,B),difference(I,B))).
fof(myForms, conjecture, ! [B] : disjoint(intersection(I,B),difference(I,B))).
fof(myForms, conjecture, disjoint(intersection(I,B),difference(I,B))).