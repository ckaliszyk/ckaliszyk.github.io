fof(myForms, conjecture, ! [E1] : (union(intersection(I,B),intersection(I,E1))=I => subset(I,union(B,E1)))).
fof(myForms, conjecture, (union(intersection(I,B),intersection(I,E1))=I => subset(I,union(B,E1)))).
fof(myForms, conjecture, union(intersection(I,B),intersection(I,E1))=I).
fof(myForms, conjecture, subset(I,union(B,E1))).