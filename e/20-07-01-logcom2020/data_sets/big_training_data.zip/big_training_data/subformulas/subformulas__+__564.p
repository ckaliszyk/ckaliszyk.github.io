fof(myForms, conjecture, ! [D] : (ilf_type(D,binary_relation_type) => subset(D,cross_product(domain_of(D),range_of(D))))).
fof(myForms, conjecture, (ilf_type(D,binary_relation_type) => subset(D,cross_product(domain_of(D),range_of(D))))).
fof(myForms, conjecture, ilf_type(D,binary_relation_type)).
fof(myForms, conjecture, subset(D,cross_product(domain_of(D),range_of(D)))).