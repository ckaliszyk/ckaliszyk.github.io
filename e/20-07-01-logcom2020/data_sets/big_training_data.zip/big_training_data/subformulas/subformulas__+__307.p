fof(myForms, conjecture, ! [B] : ! [E] : ! [C] : ! [D] : ! [F] : ! [O] : ! [Y] : ! [Z] : ((((maps(B,C,D) & maps(E,D,F)) & increasing(B,C,O,D,Y)) & increasing(E,D,Y,F,Z)) => increasing(compose_function(E,B,C,D,F),C,O,F,Z))).
fof(myForms, conjecture, ! [E] : ! [C] : ! [D] : ! [F] : ! [O] : ! [Y] : ! [Z] : ((((maps(B,C,D) & maps(E,D,F)) & increasing(B,C,O,D,Y)) & increasing(E,D,Y,F,Z)) => increasing(compose_function(E,B,C,D,F),C,O,F,Z))).
fof(myForms, conjecture, ! [C] : ! [D] : ! [F] : ! [O] : ! [Y] : ! [Z] : ((((maps(B,C,D) & maps(E,D,F)) & increasing(B,C,O,D,Y)) & increasing(E,D,Y,F,Z)) => increasing(compose_function(E,B,C,D,F),C,O,F,Z))).
fof(myForms, conjecture, ! [D] : ! [F] : ! [O] : ! [Y] : ! [Z] : ((((maps(B,C,D) & maps(E,D,F)) & increasing(B,C,O,D,Y)) & increasing(E,D,Y,F,Z)) => increasing(compose_function(E,B,C,D,F),C,O,F,Z))).
fof(myForms, conjecture, ! [F] : ! [O] : ! [Y] : ! [Z] : ((((maps(B,C,D) & maps(E,D,F)) & increasing(B,C,O,D,Y)) & increasing(E,D,Y,F,Z)) => increasing(compose_function(E,B,C,D,F),C,O,F,Z))).
fof(myForms, conjecture, ! [O] : ! [Y] : ! [Z] : ((((maps(B,C,D) & maps(E,D,F)) & increasing(B,C,O,D,Y)) & increasing(E,D,Y,F,Z)) => increasing(compose_function(E,B,C,D,F),C,O,F,Z))).
fof(myForms, conjecture, ! [Y] : ! [Z] : ((((maps(B,C,D) & maps(E,D,F)) & increasing(B,C,O,D,Y)) & increasing(E,D,Y,F,Z)) => increasing(compose_function(E,B,C,D,F),C,O,F,Z))).
fof(myForms, conjecture, ! [Z] : ((((maps(B,C,D) & maps(E,D,F)) & increasing(B,C,O,D,Y)) & increasing(E,D,Y,F,Z)) => increasing(compose_function(E,B,C,D,F),C,O,F,Z))).
fof(myForms, conjecture, ((((maps(B,C,D) & maps(E,D,F)) & increasing(B,C,O,D,Y)) & increasing(E,D,Y,F,Z)) => increasing(compose_function(E,B,C,D,F),C,O,F,Z))).
fof(myForms, conjecture, (((maps(B,C,D) & maps(E,D,F)) & increasing(B,C,O,D,Y)) & increasing(E,D,Y,F,Z))).
fof(myForms, conjecture, ((maps(B,C,D) & maps(E,D,F)) & increasing(B,C,O,D,Y))).
fof(myForms, conjecture, (maps(B,C,D) & maps(E,D,F))).
fof(myForms, conjecture, maps(B,C,D)).
fof(myForms, conjecture, maps(E,D,F)).
fof(myForms, conjecture, increasing(B,C,O,D,Y)).
fof(myForms, conjecture, increasing(E,D,Y,F,Z)).
fof(myForms, conjecture, increasing(compose_function(E,B,C,D,F),C,O,F,Z)).