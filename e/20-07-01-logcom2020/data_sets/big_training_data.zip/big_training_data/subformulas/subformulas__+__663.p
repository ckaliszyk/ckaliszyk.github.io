fof(myForms, conjecture, ! [C] : ! [D] : (in(C,D) => set_union2(set_difference(D,singleton(C)),singleton(C))=D)).
fof(myForms, conjecture, ! [D] : (in(C,D) => set_union2(set_difference(D,singleton(C)),singleton(C))=D)).
fof(myForms, conjecture, (in(C,D) => set_union2(set_difference(D,singleton(C)),singleton(C))=D)).
fof(myForms, conjecture, in(C,D)).
fof(myForms, conjecture, set_union2(set_difference(D,singleton(C)),singleton(C))=D).