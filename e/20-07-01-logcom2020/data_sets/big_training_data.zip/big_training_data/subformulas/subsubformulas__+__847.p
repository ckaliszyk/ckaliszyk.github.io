fof(myForms, conjecture, ((((maps(D,F,I) & maps(J,I,F)) & maps(L,I,F)) & identity(compose_function(J,D,F,I,F),F)) & identity(compose_function(D,L,I,F,I),I))).
fof(myForms, conjecture, (((maps(D,F,I) & maps(J,I,F)) & maps(L,I,F)) & identity(compose_function(J,D,F,I,F),F))).
fof(myForms, conjecture, ((maps(D,F,I) & maps(J,I,F)) & maps(L,I,F))).
fof(myForms, conjecture, (maps(D,F,I) & maps(J,I,F))).
fof(myForms, conjecture, maps(D,F,I)).
fof(myForms, conjecture, maps(J,I,F)).
fof(myForms, conjecture, maps(L,I,F)).
fof(myForms, conjecture, identity(compose_function(J,D,F,I,F),F)).
fof(myForms, conjecture, identity(compose_function(D,L,I,F,I),I)).