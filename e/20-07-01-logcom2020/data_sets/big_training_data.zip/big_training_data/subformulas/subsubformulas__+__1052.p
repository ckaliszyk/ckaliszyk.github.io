fof(myForms, conjecture, ((disjoint(F,I) | disjoint(B,E1)) => disjoint(cartesian_product2(F,B),cartesian_product2(I,E1)))).
fof(myForms, conjecture, (disjoint(F,I) | disjoint(B,E1))).
fof(myForms, conjecture, disjoint(F,I)).
fof(myForms, conjecture, disjoint(B,E1)).
fof(myForms, conjecture, disjoint(cartesian_product2(F,B),cartesian_product2(I,E1))).