fof(myForms, conjecture, (cartesian_product2(F,I)=B <=> ! [E1] : (in(E1,B) <=> ? [I1] : ? [D] : ((in(I1,F) & in(D,I)) & ordered_pair(I1,D)=E1)))).
fof(myForms, conjecture, cartesian_product2(F,I)=B).
fof(myForms, conjecture, ! [E1] : (in(E1,B) <=> ? [I1] : ? [D] : ((in(I1,F) & in(D,I)) & ordered_pair(I1,D)=E1))).
fof(myForms, conjecture, (in(E1,B) <=> ? [I1] : ? [D] : ((in(I1,F) & in(D,I)) & ordered_pair(I1,D)=E1))).
fof(myForms, conjecture, in(E1,B)).
fof(myForms, conjecture, ? [I1] : ? [D] : ((in(I1,F) & in(D,I)) & ordered_pair(I1,D)=E1)).
fof(myForms, conjecture, ? [D] : ((in(I1,F) & in(D,I)) & ordered_pair(I1,D)=E1)).
fof(myForms, conjecture, ((in(I1,F) & in(D,I)) & ordered_pair(I1,D)=E1)).
fof(myForms, conjecture, (in(I1,F) & in(D,I))).
fof(myForms, conjecture, in(I1,F)).
fof(myForms, conjecture, in(D,I)).
fof(myForms, conjecture, ordered_pair(I1,D)=E1).