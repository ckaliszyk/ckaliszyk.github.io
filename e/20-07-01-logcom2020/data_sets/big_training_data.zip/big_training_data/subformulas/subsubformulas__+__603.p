fof(myForms, conjecture, (order(H1,I1) & least(Q,H1,I1))).
fof(myForms, conjecture, order(H1,I1)).
fof(myForms, conjecture, least(Q,H1,I1)).