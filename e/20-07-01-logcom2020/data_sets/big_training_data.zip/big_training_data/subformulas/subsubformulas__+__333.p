fof(myForms, conjecture, ! [R] : subclass(unordered_pair(F1,F1),unordered_pair(F1,R))).
fof(myForms, conjecture, subclass(unordered_pair(F1,F1),unordered_pair(F1,R))).