fof(myForms, conjecture, (ordered_pair(F1,R)=unordered_pair(null_class,singleton(null_class)) | (member(F1,universal_class) | member(R,universal_class)))).
fof(myForms, conjecture, ordered_pair(F1,R)=unordered_pair(null_class,singleton(null_class))).
fof(myForms, conjecture, (member(F1,universal_class) | member(R,universal_class))).
fof(myForms, conjecture, member(F1,universal_class)).
fof(myForms, conjecture, member(R,universal_class)).