fof(myForms, conjecture, ! [I] : ~ ((in(F,I) & empty(I)))).
fof(myForms, conjecture, ~ ((in(F,I) & empty(I)))).
fof(myForms, conjecture, (in(F,I) & empty(I))).
fof(myForms, conjecture, in(F,I)).
fof(myForms, conjecture, empty(I)).