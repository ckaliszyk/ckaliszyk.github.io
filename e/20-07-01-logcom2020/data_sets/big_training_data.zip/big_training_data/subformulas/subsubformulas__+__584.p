fof(myForms, conjecture, ! [H1] : ((pre_order(O,I1) & ! [F] : ! [I] : ((member(F,I1) & member(I,I1)) => (apply(H1,F,I) <=> (apply(O,F,I) & apply(O,I,F))))) => equivalence(H1,I1))).
fof(myForms, conjecture, ((pre_order(O,I1) & ! [F] : ! [I] : ((member(F,I1) & member(I,I1)) => (apply(H1,F,I) <=> (apply(O,F,I) & apply(O,I,F))))) => equivalence(H1,I1))).
fof(myForms, conjecture, (pre_order(O,I1) & ! [F] : ! [I] : ((member(F,I1) & member(I,I1)) => (apply(H1,F,I) <=> (apply(O,F,I) & apply(O,I,F)))))).
fof(myForms, conjecture, pre_order(O,I1)).
fof(myForms, conjecture, ! [F] : ! [I] : ((member(F,I1) & member(I,I1)) => (apply(H1,F,I) <=> (apply(O,F,I) & apply(O,I,F))))).
fof(myForms, conjecture, ! [I] : ((member(F,I1) & member(I,I1)) => (apply(H1,F,I) <=> (apply(O,F,I) & apply(O,I,F))))).
fof(myForms, conjecture, ((member(F,I1) & member(I,I1)) => (apply(H1,F,I) <=> (apply(O,F,I) & apply(O,I,F))))).
fof(myForms, conjecture, (member(F,I1) & member(I,I1))).
fof(myForms, conjecture, member(F,I1)).
fof(myForms, conjecture, member(I,I1)).
fof(myForms, conjecture, (apply(H1,F,I) <=> (apply(O,F,I) & apply(O,I,F)))).
fof(myForms, conjecture, apply(H1,F,I)).
fof(myForms, conjecture, (apply(O,F,I) & apply(O,I,F))).
fof(myForms, conjecture, apply(O,F,I)).
fof(myForms, conjecture, apply(O,I,F)).
fof(myForms, conjecture, equivalence(H1,I1)).