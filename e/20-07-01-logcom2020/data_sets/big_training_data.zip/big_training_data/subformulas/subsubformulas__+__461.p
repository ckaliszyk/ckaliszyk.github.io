fof(myForms, conjecture, ! [D] : (ilf_type(D,relation_type(B,E1)) => ilf_type(compose5(I,B,E1,I1,D),relation_type(I,E1)))).
fof(myForms, conjecture, (ilf_type(D,relation_type(B,E1)) => ilf_type(compose5(I,B,E1,I1,D),relation_type(I,E1)))).
fof(myForms, conjecture, ilf_type(D,relation_type(B,E1))).
fof(myForms, conjecture, ilf_type(compose5(I,B,E1,I1,D),relation_type(I,E1))).