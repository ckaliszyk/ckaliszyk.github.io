fof(myForms, conjecture, ! [C] : ! [D] : ! [F] : ((subset(C,D) & subset(D,F)) => subset(C,F))).
fof(myForms, conjecture, ! [D] : ! [F] : ((subset(C,D) & subset(D,F)) => subset(C,F))).
fof(myForms, conjecture, ! [F] : ((subset(C,D) & subset(D,F)) => subset(C,F))).
fof(myForms, conjecture, ((subset(C,D) & subset(D,F)) => subset(C,F))).
fof(myForms, conjecture, (subset(C,D) & subset(D,F))).
fof(myForms, conjecture, subset(C,D)).
fof(myForms, conjecture, subset(D,F)).
fof(myForms, conjecture, subset(C,F)).