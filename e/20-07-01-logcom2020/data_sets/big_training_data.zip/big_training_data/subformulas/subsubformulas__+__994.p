fof(myForms, conjecture, (apply(H1,Y,M) & apply(H1,Z,N))).
fof(myForms, conjecture, apply(H1,Y,M)).
fof(myForms, conjecture, apply(H1,Z,N)).