fof(myForms, conjecture, ! [C] : ! [D] : ((empty(C) & relation(D)) => (empty(relation_composition(C,D)) & relation(relation_composition(C,D))))).
fof(myForms, conjecture, ! [D] : ((empty(C) & relation(D)) => (empty(relation_composition(C,D)) & relation(relation_composition(C,D))))).
fof(myForms, conjecture, ((empty(C) & relation(D)) => (empty(relation_composition(C,D)) & relation(relation_composition(C,D))))).
fof(myForms, conjecture, (empty(C) & relation(D))).
fof(myForms, conjecture, empty(C)).
fof(myForms, conjecture, relation(D)).
fof(myForms, conjecture, (empty(relation_composition(C,D)) & relation(relation_composition(C,D)))).
fof(myForms, conjecture, empty(relation_composition(C,D))).
fof(myForms, conjecture, relation(relation_composition(C,D))).