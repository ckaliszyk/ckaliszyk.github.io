fof(myForms, conjecture, (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,relation_type(E1,I)) => (subset(I,B) => ilf_type(I1,relation_type(E1,B)))))).
fof(myForms, conjecture, ilf_type(E1,set_type)).
fof(myForms, conjecture, ! [I1] : (ilf_type(I1,relation_type(E1,I)) => (subset(I,B) => ilf_type(I1,relation_type(E1,B))))).
fof(myForms, conjecture, (ilf_type(I1,relation_type(E1,I)) => (subset(I,B) => ilf_type(I1,relation_type(E1,B))))).
fof(myForms, conjecture, ilf_type(I1,relation_type(E1,I))).
fof(myForms, conjecture, (subset(I,B) => ilf_type(I1,relation_type(E1,B)))).
fof(myForms, conjecture, subset(I,B)).
fof(myForms, conjecture, ilf_type(I1,relation_type(E1,B))).