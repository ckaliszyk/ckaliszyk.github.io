fof(myForms, conjecture, (relation(F) & function(F))).
fof(myForms, conjecture, relation(F)).
fof(myForms, conjecture, function(F)).