fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => (relation_like(D) <=> ! [F] : (ilf_type(F,set_type) => (member(F,D) => ? [I] : (ilf_type(I,set_type) & ? [J] : (ilf_type(J,set_type) & ordered_pair(I,J)=F))))))).
fof(myForms, conjecture, (ilf_type(D,set_type) => (relation_like(D) <=> ! [F] : (ilf_type(F,set_type) => (member(F,D) => ? [I] : (ilf_type(I,set_type) & ? [J] : (ilf_type(J,set_type) & ordered_pair(I,J)=F))))))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, (relation_like(D) <=> ! [F] : (ilf_type(F,set_type) => (member(F,D) => ? [I] : (ilf_type(I,set_type) & ? [J] : (ilf_type(J,set_type) & ordered_pair(I,J)=F)))))).
fof(myForms, conjecture, relation_like(D)).
fof(myForms, conjecture, ! [F] : (ilf_type(F,set_type) => (member(F,D) => ? [I] : (ilf_type(I,set_type) & ? [J] : (ilf_type(J,set_type) & ordered_pair(I,J)=F))))).
fof(myForms, conjecture, (ilf_type(F,set_type) => (member(F,D) => ? [I] : (ilf_type(I,set_type) & ? [J] : (ilf_type(J,set_type) & ordered_pair(I,J)=F))))).
fof(myForms, conjecture, ilf_type(F,set_type)).
fof(myForms, conjecture, (member(F,D) => ? [I] : (ilf_type(I,set_type) & ? [J] : (ilf_type(J,set_type) & ordered_pair(I,J)=F)))).
fof(myForms, conjecture, member(F,D)).
fof(myForms, conjecture, ? [I] : (ilf_type(I,set_type) & ? [J] : (ilf_type(J,set_type) & ordered_pair(I,J)=F))).
fof(myForms, conjecture, (ilf_type(I,set_type) & ? [J] : (ilf_type(J,set_type) & ordered_pair(I,J)=F))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ? [J] : (ilf_type(J,set_type) & ordered_pair(I,J)=F)).
fof(myForms, conjecture, (ilf_type(J,set_type) & ordered_pair(I,J)=F)).
fof(myForms, conjecture, ilf_type(J,set_type)).
fof(myForms, conjecture, ordered_pair(I,J)=F).