fof(myForms, conjecture, ! [C] : ! [D] : (set_difference(C,D)=empty_set <=> subset(C,D))).
fof(myForms, conjecture, ! [D] : (set_difference(C,D)=empty_set <=> subset(C,D))).
fof(myForms, conjecture, (set_difference(C,D)=empty_set <=> subset(C,D))).
fof(myForms, conjecture, set_difference(C,D)=empty_set).
fof(myForms, conjecture, subset(C,D)).