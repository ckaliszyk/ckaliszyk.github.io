fof(myForms, conjecture, (ilf_type(B,set_type) => ! [E1] : (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,relation_type(I,B)) => ! [D] : (ilf_type(D,relation_type(B,E1)) => ilf_type(compose5(I,B,E1,I1,D),relation_type(I,E1))))))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ! [E1] : (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,relation_type(I,B)) => ! [D] : (ilf_type(D,relation_type(B,E1)) => ilf_type(compose5(I,B,E1,I1,D),relation_type(I,E1)))))).
fof(myForms, conjecture, (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,relation_type(I,B)) => ! [D] : (ilf_type(D,relation_type(B,E1)) => ilf_type(compose5(I,B,E1,I1,D),relation_type(I,E1)))))).
fof(myForms, conjecture, ilf_type(E1,set_type)).
fof(myForms, conjecture, ! [I1] : (ilf_type(I1,relation_type(I,B)) => ! [D] : (ilf_type(D,relation_type(B,E1)) => ilf_type(compose5(I,B,E1,I1,D),relation_type(I,E1))))).
fof(myForms, conjecture, (ilf_type(I1,relation_type(I,B)) => ! [D] : (ilf_type(D,relation_type(B,E1)) => ilf_type(compose5(I,B,E1,I1,D),relation_type(I,E1))))).
fof(myForms, conjecture, ilf_type(I1,relation_type(I,B))).
fof(myForms, conjecture, ! [D] : (ilf_type(D,relation_type(B,E1)) => ilf_type(compose5(I,B,E1,I1,D),relation_type(I,E1)))).
fof(myForms, conjecture, (ilf_type(D,relation_type(B,E1)) => ilf_type(compose5(I,B,E1,I1,D),relation_type(I,E1)))).
fof(myForms, conjecture, ilf_type(D,relation_type(B,E1))).
fof(myForms, conjecture, ilf_type(compose5(I,B,E1,I1,D),relation_type(I,E1))).