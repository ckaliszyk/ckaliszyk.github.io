fof(myForms, conjecture, (member(ordered_pair(E1,I1),I) => member(ordered_pair(E1,I1),B))).
fof(myForms, conjecture, member(ordered_pair(E1,I1),I)).
fof(myForms, conjecture, member(ordered_pair(E1,I1),B)).