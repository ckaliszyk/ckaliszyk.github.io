fof(myForms, conjecture, (relation(F) & relation_empty_yielding(F))).
fof(myForms, conjecture, relation(F)).
fof(myForms, conjecture, relation_empty_yielding(F)).