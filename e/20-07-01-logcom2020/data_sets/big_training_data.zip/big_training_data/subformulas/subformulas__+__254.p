fof(myForms, conjecture, ! [J] : ! [L] : ! [O] : ((pre_order(O,J) & subset(L,J)) => pre_order(O,L))).
fof(myForms, conjecture, ! [L] : ! [O] : ((pre_order(O,J) & subset(L,J)) => pre_order(O,L))).
fof(myForms, conjecture, ! [O] : ((pre_order(O,J) & subset(L,J)) => pre_order(O,L))).
fof(myForms, conjecture, ((pre_order(O,J) & subset(L,J)) => pre_order(O,L))).
fof(myForms, conjecture, (pre_order(O,J) & subset(L,J))).
fof(myForms, conjecture, pre_order(O,J)).
fof(myForms, conjecture, subset(L,J)).
fof(myForms, conjecture, pre_order(O,L)).