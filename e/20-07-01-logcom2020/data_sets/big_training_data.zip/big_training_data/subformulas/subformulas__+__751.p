fof(myForms, conjecture, ! [D] : ! [F] : ! [I] : (intersection(F,I)=D <=> ((subset(D,F) & subset(D,I)) & ! [J] : ((subset(J,F) & subset(J,I)) => subset(J,D))))).
fof(myForms, conjecture, ! [F] : ! [I] : (intersection(F,I)=D <=> ((subset(D,F) & subset(D,I)) & ! [J] : ((subset(J,F) & subset(J,I)) => subset(J,D))))).
fof(myForms, conjecture, ! [I] : (intersection(F,I)=D <=> ((subset(D,F) & subset(D,I)) & ! [J] : ((subset(J,F) & subset(J,I)) => subset(J,D))))).
fof(myForms, conjecture, (intersection(F,I)=D <=> ((subset(D,F) & subset(D,I)) & ! [J] : ((subset(J,F) & subset(J,I)) => subset(J,D))))).
fof(myForms, conjecture, intersection(F,I)=D).
fof(myForms, conjecture, ((subset(D,F) & subset(D,I)) & ! [J] : ((subset(J,F) & subset(J,I)) => subset(J,D)))).
fof(myForms, conjecture, (subset(D,F) & subset(D,I))).
fof(myForms, conjecture, subset(D,F)).
fof(myForms, conjecture, subset(D,I)).
fof(myForms, conjecture, ! [J] : ((subset(J,F) & subset(J,I)) => subset(J,D))).
fof(myForms, conjecture, ((subset(J,F) & subset(J,I)) => subset(J,D))).
fof(myForms, conjecture, (subset(J,F) & subset(J,I))).
fof(myForms, conjecture, subset(J,F)).
fof(myForms, conjecture, subset(J,I)).
fof(myForms, conjecture, subset(J,D)).