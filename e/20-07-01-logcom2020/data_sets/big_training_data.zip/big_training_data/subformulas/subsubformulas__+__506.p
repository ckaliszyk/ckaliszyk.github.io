fof(myForms, conjecture, ! [B] : ! [E1] : ((subset(I,B) & subset(E1,B)) => subset(union(I,E1),B))).
fof(myForms, conjecture, ! [E1] : ((subset(I,B) & subset(E1,B)) => subset(union(I,E1),B))).
fof(myForms, conjecture, ((subset(I,B) & subset(E1,B)) => subset(union(I,E1),B))).
fof(myForms, conjecture, (subset(I,B) & subset(E1,B))).
fof(myForms, conjecture, subset(I,B)).
fof(myForms, conjecture, subset(E1,B)).
fof(myForms, conjecture, subset(union(I,E1),B)).