fof(myForms, conjecture, ? [F] : (~ empty(F) & relation(F))).
fof(myForms, conjecture, (~ empty(F) & relation(F))).
fof(myForms, conjecture, ~ empty(F)).
fof(myForms, conjecture, empty(F)).
fof(myForms, conjecture, relation(F)).