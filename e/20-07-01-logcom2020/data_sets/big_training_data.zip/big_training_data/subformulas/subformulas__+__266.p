fof(myForms, conjecture, ! [C] : ! [D] : ! [F] : (in(C,D) => ((in(F,D) & ~ F=C) | set_intersection2(unordered_pair(C,F),D)=singleton(C)))).
fof(myForms, conjecture, ! [D] : ! [F] : (in(C,D) => ((in(F,D) & ~ F=C) | set_intersection2(unordered_pair(C,F),D)=singleton(C)))).
fof(myForms, conjecture, ! [F] : (in(C,D) => ((in(F,D) & ~ F=C) | set_intersection2(unordered_pair(C,F),D)=singleton(C)))).
fof(myForms, conjecture, (in(C,D) => ((in(F,D) & ~ F=C) | set_intersection2(unordered_pair(C,F),D)=singleton(C)))).
fof(myForms, conjecture, in(C,D)).
fof(myForms, conjecture, ((in(F,D) & ~ F=C) | set_intersection2(unordered_pair(C,F),D)=singleton(C))).
fof(myForms, conjecture, (in(F,D) & ~ F=C)).
fof(myForms, conjecture, in(F,D)).
fof(myForms, conjecture, ~ F=C).
fof(myForms, conjecture, F=C).
fof(myForms, conjecture, set_intersection2(unordered_pair(C,F),D)=singleton(C)).