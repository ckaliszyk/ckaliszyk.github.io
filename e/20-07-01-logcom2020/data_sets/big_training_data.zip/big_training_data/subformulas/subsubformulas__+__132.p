fof(myForms, conjecture, ! [B] : (singleton(F)=set_difference(unordered_pair(F,I),B) <=> (~ in(F,B) & (in(I,B) | I=F)))).
fof(myForms, conjecture, (singleton(F)=set_difference(unordered_pair(F,I),B) <=> (~ in(F,B) & (in(I,B) | I=F)))).
fof(myForms, conjecture, singleton(F)=set_difference(unordered_pair(F,I),B)).
fof(myForms, conjecture, (~ in(F,B) & (in(I,B) | I=F))).
fof(myForms, conjecture, ~ in(F,B)).
fof(myForms, conjecture, in(F,B)).
fof(myForms, conjecture, (in(I,B) | I=F)).
fof(myForms, conjecture, in(I,B)).
fof(myForms, conjecture, I=F).