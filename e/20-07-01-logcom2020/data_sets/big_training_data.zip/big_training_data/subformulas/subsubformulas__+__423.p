fof(myForms, conjecture, (maps(D,F,I) & subset(B,F))).
fof(myForms, conjecture, maps(D,F,I)).
fof(myForms, conjecture, subset(B,F)).