fof(myForms, conjecture, ! [D] : intersection(D,D)=D).
fof(myForms, conjecture, intersection(D,D)=D).