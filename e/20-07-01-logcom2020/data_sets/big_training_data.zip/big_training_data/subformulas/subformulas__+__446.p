fof(myForms, conjecture, ! [C] : ! [D] : ~ ((disjoint(singleton(C),singleton(D)) & D=C))).
fof(myForms, conjecture, ! [D] : ~ ((disjoint(singleton(C),singleton(D)) & D=C))).
fof(myForms, conjecture, ~ ((disjoint(singleton(C),singleton(D)) & D=C))).
fof(myForms, conjecture, (disjoint(singleton(C),singleton(D)) & D=C)).
fof(myForms, conjecture, disjoint(singleton(C),singleton(D))).
fof(myForms, conjecture, D=C).