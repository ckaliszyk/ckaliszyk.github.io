fof(myForms, conjecture, ! [L] : (ordered_pair(first(L),second(L))=L => member(L,universal_class))).
fof(myForms, conjecture, (ordered_pair(first(L),second(L))=L => member(L,universal_class))).
fof(myForms, conjecture, ordered_pair(first(L),second(L))=L).
fof(myForms, conjecture, member(L,universal_class)).