fof(myForms, conjecture, ! [C] : ! [D] : (in(C,D) => set_intersection2(D,singleton(C))=singleton(C))).
fof(myForms, conjecture, ! [D] : (in(C,D) => set_intersection2(D,singleton(C))=singleton(C))).
fof(myForms, conjecture, (in(C,D) => set_intersection2(D,singleton(C))=singleton(C))).
fof(myForms, conjecture, in(C,D)).
fof(myForms, conjecture, set_intersection2(D,singleton(C))=singleton(C)).