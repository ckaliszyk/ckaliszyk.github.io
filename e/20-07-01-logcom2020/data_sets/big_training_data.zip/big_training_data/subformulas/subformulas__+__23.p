fof(myForms, conjecture, ! [L] : ! [P] : (member(L,universal_class) => ~ null_class=unordered_pair(L,P))).
fof(myForms, conjecture, ! [P] : (member(L,universal_class) => ~ null_class=unordered_pair(L,P))).
fof(myForms, conjecture, (member(L,universal_class) => ~ null_class=unordered_pair(L,P))).
fof(myForms, conjecture, member(L,universal_class)).
fof(myForms, conjecture, ~ null_class=unordered_pair(L,P)).
fof(myForms, conjecture, null_class=unordered_pair(L,P)).