fof(myForms, conjecture, ~ member(B,I)).
fof(myForms, conjecture, member(B,I)).