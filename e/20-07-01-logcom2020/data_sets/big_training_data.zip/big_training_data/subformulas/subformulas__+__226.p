fof(myForms, conjecture, ! [C] : ! [D] : ! [M] : ! [N] : (equal_set(unordered_pair(singleton(C),unordered_pair(C,D)),unordered_pair(singleton(M),unordered_pair(M,N))) => M=C)).
fof(myForms, conjecture, ! [D] : ! [M] : ! [N] : (equal_set(unordered_pair(singleton(C),unordered_pair(C,D)),unordered_pair(singleton(M),unordered_pair(M,N))) => M=C)).
fof(myForms, conjecture, ! [M] : ! [N] : (equal_set(unordered_pair(singleton(C),unordered_pair(C,D)),unordered_pair(singleton(M),unordered_pair(M,N))) => M=C)).
fof(myForms, conjecture, ! [N] : (equal_set(unordered_pair(singleton(C),unordered_pair(C,D)),unordered_pair(singleton(M),unordered_pair(M,N))) => M=C)).
fof(myForms, conjecture, (equal_set(unordered_pair(singleton(C),unordered_pair(C,D)),unordered_pair(singleton(M),unordered_pair(M,N))) => M=C)).
fof(myForms, conjecture, equal_set(unordered_pair(singleton(C),unordered_pair(C,D)),unordered_pair(singleton(M),unordered_pair(M,N)))).
fof(myForms, conjecture, M=C).