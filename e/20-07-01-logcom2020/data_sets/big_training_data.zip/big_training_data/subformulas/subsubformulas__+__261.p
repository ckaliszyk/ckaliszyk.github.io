fof(myForms, conjecture, ! [F] : ! [I] : (cartesian_product2(F,I)=empty_set <=> (empty_set=F | empty_set=I))).
fof(myForms, conjecture, ! [I] : (cartesian_product2(F,I)=empty_set <=> (empty_set=F | empty_set=I))).
fof(myForms, conjecture, (cartesian_product2(F,I)=empty_set <=> (empty_set=F | empty_set=I))).
fof(myForms, conjecture, cartesian_product2(F,I)=empty_set).
fof(myForms, conjecture, (empty_set=F | empty_set=I)).
fof(myForms, conjecture, empty_set=F).
fof(myForms, conjecture, empty_set=I).