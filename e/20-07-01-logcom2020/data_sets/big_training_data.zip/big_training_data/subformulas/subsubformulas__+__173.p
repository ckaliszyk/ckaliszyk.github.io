fof(myForms, conjecture, ! [I1] : (ilf_type(I1,relation_type(I,B)) => ilf_type(I1,subset_type(cross_product(I,B))))).
fof(myForms, conjecture, (ilf_type(I1,relation_type(I,B)) => ilf_type(I1,subset_type(cross_product(I,B))))).
fof(myForms, conjecture, ilf_type(I1,relation_type(I,B))).
fof(myForms, conjecture, ilf_type(I1,subset_type(cross_product(I,B)))).