fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => (ordered_pair(E1,I1)=D <=> unordered_pair(unordered_pair(E1,I1),singleton(E1))=D))).
fof(myForms, conjecture, (ilf_type(D,set_type) => (ordered_pair(E1,I1)=D <=> unordered_pair(unordered_pair(E1,I1),singleton(E1))=D))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, (ordered_pair(E1,I1)=D <=> unordered_pair(unordered_pair(E1,I1),singleton(E1))=D)).
fof(myForms, conjecture, ordered_pair(E1,I1)=D).
fof(myForms, conjecture, unordered_pair(unordered_pair(E1,I1),singleton(E1))=D).