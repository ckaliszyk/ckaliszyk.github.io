fof(myForms, conjecture, ! [D] : (ilf_type(D,binary_relation_type) => ilf_type(range_of(D),set_type))).
fof(myForms, conjecture, (ilf_type(D,binary_relation_type) => ilf_type(range_of(D),set_type))).
fof(myForms, conjecture, ilf_type(D,binary_relation_type)).
fof(myForms, conjecture, ilf_type(range_of(D),set_type)).