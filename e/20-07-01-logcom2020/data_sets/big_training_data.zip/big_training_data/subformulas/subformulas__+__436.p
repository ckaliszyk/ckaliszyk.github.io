fof(myForms, conjecture, ! [C] : ! [D] : ordered_pair(C,D)=unordered_pair(unordered_pair(C,D),singleton(C))).
fof(myForms, conjecture, ! [D] : ordered_pair(C,D)=unordered_pair(unordered_pair(C,D),singleton(C))).
fof(myForms, conjecture, ordered_pair(C,D)=unordered_pair(unordered_pair(C,D),singleton(C))).