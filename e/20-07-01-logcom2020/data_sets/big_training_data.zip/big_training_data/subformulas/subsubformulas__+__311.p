fof(myForms, conjecture, ! [Q] : (lower_bound(Q,H1,R) => lower_bound(Q,H1,F1))).
fof(myForms, conjecture, (lower_bound(Q,H1,R) => lower_bound(Q,H1,F1))).
fof(myForms, conjecture, lower_bound(Q,H1,R)).
fof(myForms, conjecture, lower_bound(Q,H1,F1)).