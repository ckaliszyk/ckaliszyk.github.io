fof(myForms, conjecture, (order(H1,I1) => ! [F1] : ! [R] : (((subset(F1,I1) & subset(R,I1)) & subset(F1,R)) => ! [Q] : (lower_bound(Q,H1,R) => lower_bound(Q,H1,F1))))).
fof(myForms, conjecture, order(H1,I1)).
fof(myForms, conjecture, ! [F1] : ! [R] : (((subset(F1,I1) & subset(R,I1)) & subset(F1,R)) => ! [Q] : (lower_bound(Q,H1,R) => lower_bound(Q,H1,F1)))).
fof(myForms, conjecture, ! [R] : (((subset(F1,I1) & subset(R,I1)) & subset(F1,R)) => ! [Q] : (lower_bound(Q,H1,R) => lower_bound(Q,H1,F1)))).
fof(myForms, conjecture, (((subset(F1,I1) & subset(R,I1)) & subset(F1,R)) => ! [Q] : (lower_bound(Q,H1,R) => lower_bound(Q,H1,F1)))).
fof(myForms, conjecture, ((subset(F1,I1) & subset(R,I1)) & subset(F1,R))).
fof(myForms, conjecture, (subset(F1,I1) & subset(R,I1))).
fof(myForms, conjecture, subset(F1,I1)).
fof(myForms, conjecture, subset(R,I1)).
fof(myForms, conjecture, subset(F1,R)).
fof(myForms, conjecture, ! [Q] : (lower_bound(Q,H1,R) => lower_bound(Q,H1,F1))).
fof(myForms, conjecture, (lower_bound(Q,H1,R) => lower_bound(Q,H1,F1))).
fof(myForms, conjecture, lower_bound(Q,H1,R)).
fof(myForms, conjecture, lower_bound(Q,H1,F1)).