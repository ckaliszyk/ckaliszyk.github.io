fof(myForms, conjecture, ! [E1] : (ilf_type(E1,relation_type(I,B)) => ilf_type(domain(I,B,E1),subset_type(I)))).
fof(myForms, conjecture, (ilf_type(E1,relation_type(I,B)) => ilf_type(domain(I,B,E1),subset_type(I)))).
fof(myForms, conjecture, ilf_type(E1,relation_type(I,B))).
fof(myForms, conjecture, ilf_type(domain(I,B,E1),subset_type(I))).