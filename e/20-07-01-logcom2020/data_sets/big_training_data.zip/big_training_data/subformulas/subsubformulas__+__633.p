fof(myForms, conjecture, (ilf_type(B,set_type) => ! [E1] : (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,set_type) => ! [D] : (ilf_type(D,set_type) => (ordered_pair(E1,I1)=D <=> unordered_pair(unordered_pair(E1,I1),singleton(E1))=D)))))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ! [E1] : (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,set_type) => ! [D] : (ilf_type(D,set_type) => (ordered_pair(E1,I1)=D <=> unordered_pair(unordered_pair(E1,I1),singleton(E1))=D))))).
fof(myForms, conjecture, (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,set_type) => ! [D] : (ilf_type(D,set_type) => (ordered_pair(E1,I1)=D <=> unordered_pair(unordered_pair(E1,I1),singleton(E1))=D))))).
fof(myForms, conjecture, ilf_type(E1,set_type)).
fof(myForms, conjecture, ! [I1] : (ilf_type(I1,set_type) => ! [D] : (ilf_type(D,set_type) => (ordered_pair(E1,I1)=D <=> unordered_pair(unordered_pair(E1,I1),singleton(E1))=D)))).
fof(myForms, conjecture, (ilf_type(I1,set_type) => ! [D] : (ilf_type(D,set_type) => (ordered_pair(E1,I1)=D <=> unordered_pair(unordered_pair(E1,I1),singleton(E1))=D)))).
fof(myForms, conjecture, ilf_type(I1,set_type)).
fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => (ordered_pair(E1,I1)=D <=> unordered_pair(unordered_pair(E1,I1),singleton(E1))=D))).
fof(myForms, conjecture, (ilf_type(D,set_type) => (ordered_pair(E1,I1)=D <=> unordered_pair(unordered_pair(E1,I1),singleton(E1))=D))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, (ordered_pair(E1,I1)=D <=> unordered_pair(unordered_pair(E1,I1),singleton(E1))=D)).
fof(myForms, conjecture, ordered_pair(E1,I1)=D).
fof(myForms, conjecture, unordered_pair(unordered_pair(E1,I1),singleton(E1))=D).