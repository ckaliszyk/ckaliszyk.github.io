fof(myForms, conjecture, ! [I] : ((relation(I) & function(I)) => ! [B] : ((relation(B) & function(B)) => ((! [E1] : (in(E1,relation_dom(B)) <=> (in(E1,relation_dom(F)) & in(apply(F,E1),relation_dom(I)))) & ! [E1] : (in(E1,relation_dom(B)) => apply(I,apply(F,E1))=apply(B,E1))) => relation_composition(F,I)=B)))).
fof(myForms, conjecture, ((relation(I) & function(I)) => ! [B] : ((relation(B) & function(B)) => ((! [E1] : (in(E1,relation_dom(B)) <=> (in(E1,relation_dom(F)) & in(apply(F,E1),relation_dom(I)))) & ! [E1] : (in(E1,relation_dom(B)) => apply(I,apply(F,E1))=apply(B,E1))) => relation_composition(F,I)=B)))).
fof(myForms, conjecture, (relation(I) & function(I))).
fof(myForms, conjecture, relation(I)).
fof(myForms, conjecture, function(I)).
fof(myForms, conjecture, ! [B] : ((relation(B) & function(B)) => ((! [E1] : (in(E1,relation_dom(B)) <=> (in(E1,relation_dom(F)) & in(apply(F,E1),relation_dom(I)))) & ! [E1] : (in(E1,relation_dom(B)) => apply(I,apply(F,E1))=apply(B,E1))) => relation_composition(F,I)=B))).
fof(myForms, conjecture, ((relation(B) & function(B)) => ((! [E1] : (in(E1,relation_dom(B)) <=> (in(E1,relation_dom(F)) & in(apply(F,E1),relation_dom(I)))) & ! [E1] : (in(E1,relation_dom(B)) => apply(I,apply(F,E1))=apply(B,E1))) => relation_composition(F,I)=B))).
fof(myForms, conjecture, (relation(B) & function(B))).
fof(myForms, conjecture, relation(B)).
fof(myForms, conjecture, function(B)).
fof(myForms, conjecture, ((! [E1] : (in(E1,relation_dom(B)) <=> (in(E1,relation_dom(F)) & in(apply(F,E1),relation_dom(I)))) & ! [E1] : (in(E1,relation_dom(B)) => apply(I,apply(F,E1))=apply(B,E1))) => relation_composition(F,I)=B)).
fof(myForms, conjecture, (! [E1] : (in(E1,relation_dom(B)) <=> (in(E1,relation_dom(F)) & in(apply(F,E1),relation_dom(I)))) & ! [E1] : (in(E1,relation_dom(B)) => apply(I,apply(F,E1))=apply(B,E1)))).
fof(myForms, conjecture, ! [E1] : (in(E1,relation_dom(B)) <=> (in(E1,relation_dom(F)) & in(apply(F,E1),relation_dom(I))))).
fof(myForms, conjecture, (in(E1,relation_dom(B)) <=> (in(E1,relation_dom(F)) & in(apply(F,E1),relation_dom(I))))).
fof(myForms, conjecture, in(E1,relation_dom(B))).
fof(myForms, conjecture, (in(E1,relation_dom(F)) & in(apply(F,E1),relation_dom(I)))).
fof(myForms, conjecture, in(E1,relation_dom(F))).
fof(myForms, conjecture, in(apply(F,E1),relation_dom(I))).
fof(myForms, conjecture, ! [E1] : (in(E1,relation_dom(B)) => apply(I,apply(F,E1))=apply(B,E1))).
fof(myForms, conjecture, (in(E1,relation_dom(B)) => apply(I,apply(F,E1))=apply(B,E1))).
fof(myForms, conjecture, in(E1,relation_dom(B))).
fof(myForms, conjecture, apply(I,apply(F,E1))=apply(B,E1)).
fof(myForms, conjecture, relation_composition(F,I)=B).