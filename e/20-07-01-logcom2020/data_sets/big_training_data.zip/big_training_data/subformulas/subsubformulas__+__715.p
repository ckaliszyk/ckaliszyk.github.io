fof(myForms, conjecture, (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,set_type) => (member(ordered_pair(E1,I1),I) => member(ordered_pair(E1,I1),B))))).
fof(myForms, conjecture, ilf_type(E1,set_type)).
fof(myForms, conjecture, ! [I1] : (ilf_type(I1,set_type) => (member(ordered_pair(E1,I1),I) => member(ordered_pair(E1,I1),B)))).
fof(myForms, conjecture, (ilf_type(I1,set_type) => (member(ordered_pair(E1,I1),I) => member(ordered_pair(E1,I1),B)))).
fof(myForms, conjecture, ilf_type(I1,set_type)).
fof(myForms, conjecture, (member(ordered_pair(E1,I1),I) => member(ordered_pair(E1,I1),B))).
fof(myForms, conjecture, member(ordered_pair(E1,I1),I)).
fof(myForms, conjecture, member(ordered_pair(E1,I1),B)).