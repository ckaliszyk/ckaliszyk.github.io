fof(myForms, conjecture, ! [B] : (set_intersection2(unordered_pair(F,I),B)=unordered_pair(F,I) => in(F,B))).
fof(myForms, conjecture, (set_intersection2(unordered_pair(F,I),B)=unordered_pair(F,I) => in(F,B))).
fof(myForms, conjecture, set_intersection2(unordered_pair(F,I),B)=unordered_pair(F,I)).
fof(myForms, conjecture, in(F,B)).