fof(myForms, conjecture, ! [C] : (((subset(C,on) & set(C)) & ? [L] : member(L,C)) => member(product(C),on))).
fof(myForms, conjecture, (((subset(C,on) & set(C)) & ? [L] : member(L,C)) => member(product(C),on))).
fof(myForms, conjecture, ((subset(C,on) & set(C)) & ? [L] : member(L,C))).
fof(myForms, conjecture, (subset(C,on) & set(C))).
fof(myForms, conjecture, subset(C,on)).
fof(myForms, conjecture, set(C)).
fof(myForms, conjecture, ? [L] : member(L,C)).
fof(myForms, conjecture, member(L,C)).
fof(myForms, conjecture, member(product(C),on)).