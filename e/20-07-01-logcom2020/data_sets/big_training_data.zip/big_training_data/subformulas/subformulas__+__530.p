fof(myForms, conjecture, ! [L] : ! [P] : (set_equal(L,P) <=> set_equal(P,L))).
fof(myForms, conjecture, ! [P] : (set_equal(L,P) <=> set_equal(P,L))).
fof(myForms, conjecture, (set_equal(L,P) <=> set_equal(P,L))).
fof(myForms, conjecture, set_equal(L,P)).
fof(myForms, conjecture, set_equal(P,L)).