fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => (ilf_type(F,identity_relation_of_type(D)) <=> ilf_type(F,relation_type(D,D)))))).
fof(myForms, conjecture, (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => (ilf_type(F,identity_relation_of_type(D)) <=> ilf_type(F,relation_type(D,D)))))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, ! [F] : (ilf_type(F,set_type) => (ilf_type(F,identity_relation_of_type(D)) <=> ilf_type(F,relation_type(D,D))))).
fof(myForms, conjecture, (ilf_type(F,set_type) => (ilf_type(F,identity_relation_of_type(D)) <=> ilf_type(F,relation_type(D,D))))).
fof(myForms, conjecture, ilf_type(F,set_type)).
fof(myForms, conjecture, (ilf_type(F,identity_relation_of_type(D)) <=> ilf_type(F,relation_type(D,D)))).
fof(myForms, conjecture, ilf_type(F,identity_relation_of_type(D))).
fof(myForms, conjecture, ilf_type(F,relation_type(D,D))).