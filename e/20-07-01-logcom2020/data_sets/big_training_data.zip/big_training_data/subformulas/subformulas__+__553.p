fof(myForms, conjecture, ! [B] : ! [E] : ! [C] : ! [D] : ! [F] : ((((maps(B,C,D) & maps(E,D,F)) & surjective(B,C,D)) & surjective(E,D,F)) => surjective(compose_function(E,B,C,D,F),C,F))).
fof(myForms, conjecture, ! [E] : ! [C] : ! [D] : ! [F] : ((((maps(B,C,D) & maps(E,D,F)) & surjective(B,C,D)) & surjective(E,D,F)) => surjective(compose_function(E,B,C,D,F),C,F))).
fof(myForms, conjecture, ! [C] : ! [D] : ! [F] : ((((maps(B,C,D) & maps(E,D,F)) & surjective(B,C,D)) & surjective(E,D,F)) => surjective(compose_function(E,B,C,D,F),C,F))).
fof(myForms, conjecture, ! [D] : ! [F] : ((((maps(B,C,D) & maps(E,D,F)) & surjective(B,C,D)) & surjective(E,D,F)) => surjective(compose_function(E,B,C,D,F),C,F))).
fof(myForms, conjecture, ! [F] : ((((maps(B,C,D) & maps(E,D,F)) & surjective(B,C,D)) & surjective(E,D,F)) => surjective(compose_function(E,B,C,D,F),C,F))).
fof(myForms, conjecture, ((((maps(B,C,D) & maps(E,D,F)) & surjective(B,C,D)) & surjective(E,D,F)) => surjective(compose_function(E,B,C,D,F),C,F))).
fof(myForms, conjecture, (((maps(B,C,D) & maps(E,D,F)) & surjective(B,C,D)) & surjective(E,D,F))).
fof(myForms, conjecture, ((maps(B,C,D) & maps(E,D,F)) & surjective(B,C,D))).
fof(myForms, conjecture, (maps(B,C,D) & maps(E,D,F))).
fof(myForms, conjecture, maps(B,C,D)).
fof(myForms, conjecture, maps(E,D,F)).
fof(myForms, conjecture, surjective(B,C,D)).
fof(myForms, conjecture, surjective(E,D,F)).
fof(myForms, conjecture, surjective(compose_function(E,B,C,D,F),C,F)).