fof(myForms, conjecture, (((subset(F1,I1) & subset(R,I1)) & subset(F1,R)) => ! [Q] : (upper_bound(Q,H1,R) => upper_bound(Q,H1,F1)))).
fof(myForms, conjecture, ((subset(F1,I1) & subset(R,I1)) & subset(F1,R))).
fof(myForms, conjecture, (subset(F1,I1) & subset(R,I1))).
fof(myForms, conjecture, subset(F1,I1)).
fof(myForms, conjecture, subset(R,I1)).
fof(myForms, conjecture, subset(F1,R)).
fof(myForms, conjecture, ! [Q] : (upper_bound(Q,H1,R) => upper_bound(Q,H1,F1))).
fof(myForms, conjecture, (upper_bound(Q,H1,R) => upper_bound(Q,H1,F1))).
fof(myForms, conjecture, upper_bound(Q,H1,R)).
fof(myForms, conjecture, upper_bound(Q,H1,F1)).