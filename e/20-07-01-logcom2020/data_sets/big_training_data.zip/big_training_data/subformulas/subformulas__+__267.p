fof(myForms, conjecture, ! [D] : (empty(D) <=> ! [F] : ~ member(F,D))).
fof(myForms, conjecture, (empty(D) <=> ! [F] : ~ member(F,D))).
fof(myForms, conjecture, empty(D)).
fof(myForms, conjecture, ! [F] : ~ member(F,D)).
fof(myForms, conjecture, ~ member(F,D)).
fof(myForms, conjecture, member(F,D)).