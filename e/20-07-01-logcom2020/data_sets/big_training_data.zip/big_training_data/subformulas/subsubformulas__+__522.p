fof(myForms, conjecture, (empty(F) => empty_set=F)).
fof(myForms, conjecture, empty(F)).
fof(myForms, conjecture, empty_set=F).