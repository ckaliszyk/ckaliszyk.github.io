fof(myForms, conjecture, ! [C] : ! [D] : ! [F] : (set_difference(unordered_pair(C,D),F)=unordered_pair(C,D) <=> (~ in(C,F) & ~ in(D,F)))).
fof(myForms, conjecture, ! [D] : ! [F] : (set_difference(unordered_pair(C,D),F)=unordered_pair(C,D) <=> (~ in(C,F) & ~ in(D,F)))).
fof(myForms, conjecture, ! [F] : (set_difference(unordered_pair(C,D),F)=unordered_pair(C,D) <=> (~ in(C,F) & ~ in(D,F)))).
fof(myForms, conjecture, (set_difference(unordered_pair(C,D),F)=unordered_pair(C,D) <=> (~ in(C,F) & ~ in(D,F)))).
fof(myForms, conjecture, set_difference(unordered_pair(C,D),F)=unordered_pair(C,D)).
fof(myForms, conjecture, (~ in(C,F) & ~ in(D,F))).
fof(myForms, conjecture, ~ in(C,F)).
fof(myForms, conjecture, in(C,F)).
fof(myForms, conjecture, ~ in(D,F)).
fof(myForms, conjecture, in(D,F)).