fof(myForms, conjecture, ! [I] : (union(F)=I <=> ! [B] : (in(B,I) <=> ? [E1] : (in(B,E1) & in(E1,F))))).
fof(myForms, conjecture, (union(F)=I <=> ! [B] : (in(B,I) <=> ? [E1] : (in(B,E1) & in(E1,F))))).
fof(myForms, conjecture, union(F)=I).
fof(myForms, conjecture, ! [B] : (in(B,I) <=> ? [E1] : (in(B,E1) & in(E1,F)))).
fof(myForms, conjecture, (in(B,I) <=> ? [E1] : (in(B,E1) & in(E1,F)))).
fof(myForms, conjecture, in(B,I)).
fof(myForms, conjecture, ? [E1] : (in(B,E1) & in(E1,F))).
fof(myForms, conjecture, (in(B,E1) & in(E1,F))).
fof(myForms, conjecture, in(B,E1)).
fof(myForms, conjecture, in(E1,F)).