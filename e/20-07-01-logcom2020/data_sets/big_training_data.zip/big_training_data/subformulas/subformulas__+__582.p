fof(myForms, conjecture, ! [C] : ! [D] : (subset(C,D) => subset(union(C),union(D)))).
fof(myForms, conjecture, ! [D] : (subset(C,D) => subset(union(C),union(D)))).
fof(myForms, conjecture, (subset(C,D) => subset(union(C),union(D)))).
fof(myForms, conjecture, subset(C,D)).
fof(myForms, conjecture, subset(union(C),union(D))).