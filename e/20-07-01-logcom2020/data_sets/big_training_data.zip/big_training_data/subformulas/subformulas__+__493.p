fof(myForms, conjecture, ~ empty(n1)).
fof(myForms, conjecture, empty(n1)).