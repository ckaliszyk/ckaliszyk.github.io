fof(myForms, conjecture, (subset(I,B) & subset(E1,I1))).
fof(myForms, conjecture, subset(I,B)).
fof(myForms, conjecture, subset(E1,I1)).