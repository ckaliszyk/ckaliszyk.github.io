fof(myForms, conjecture, ((subset(F,on) & set(F)) & ? [F1] : member(F1,F))).
fof(myForms, conjecture, (subset(F,on) & set(F))).
fof(myForms, conjecture, subset(F,on)).
fof(myForms, conjecture, set(F)).
fof(myForms, conjecture, ? [F1] : member(F1,F)).
fof(myForms, conjecture, member(F1,F)).