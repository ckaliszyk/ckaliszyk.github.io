fof(myForms, conjecture, ! [C] : ! [D] : ! [J] : ((subset(C,J) & subset(D,J)) => equal_set(difference(J,union(C,D)),intersection(difference(J,C),difference(J,D))))).
fof(myForms, conjecture, ! [D] : ! [J] : ((subset(C,J) & subset(D,J)) => equal_set(difference(J,union(C,D)),intersection(difference(J,C),difference(J,D))))).
fof(myForms, conjecture, ! [J] : ((subset(C,J) & subset(D,J)) => equal_set(difference(J,union(C,D)),intersection(difference(J,C),difference(J,D))))).
fof(myForms, conjecture, ((subset(C,J) & subset(D,J)) => equal_set(difference(J,union(C,D)),intersection(difference(J,C),difference(J,D))))).
fof(myForms, conjecture, (subset(C,J) & subset(D,J))).
fof(myForms, conjecture, subset(C,J)).
fof(myForms, conjecture, subset(D,J)).
fof(myForms, conjecture, equal_set(difference(J,union(C,D)),intersection(difference(J,C),difference(J,D)))).