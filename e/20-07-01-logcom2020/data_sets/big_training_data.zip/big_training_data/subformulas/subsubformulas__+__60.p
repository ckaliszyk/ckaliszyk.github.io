fof(myForms, conjecture, ? [B] : in(B,set_intersection2(F,I))).
fof(myForms, conjecture, in(B,set_intersection2(F,I))).