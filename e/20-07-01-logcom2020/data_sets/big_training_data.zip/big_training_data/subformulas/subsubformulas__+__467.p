fof(myForms, conjecture, ! [I] : ! [B] : ! [E1] : (intersect(I,intersection(B,E1)) => intersect(I,B))).
fof(myForms, conjecture, ! [B] : ! [E1] : (intersect(I,intersection(B,E1)) => intersect(I,B))).
fof(myForms, conjecture, ! [E1] : (intersect(I,intersection(B,E1)) => intersect(I,B))).
fof(myForms, conjecture, (intersect(I,intersection(B,E1)) => intersect(I,B))).
fof(myForms, conjecture, intersect(I,intersection(B,E1))).
fof(myForms, conjecture, intersect(I,B)).