fof(myForms, conjecture, (ilf_type(I,binary_relation_type) => ! [B] : (ilf_type(B,binary_relation_type) => (I=B <=> ! [E1] : (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,set_type) => (member(ordered_pair(E1,I1),I) <=> member(ordered_pair(E1,I1),B)))))))).
fof(myForms, conjecture, ilf_type(I,binary_relation_type)).
fof(myForms, conjecture, ! [B] : (ilf_type(B,binary_relation_type) => (I=B <=> ! [E1] : (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,set_type) => (member(ordered_pair(E1,I1),I) <=> member(ordered_pair(E1,I1),B))))))).
fof(myForms, conjecture, (ilf_type(B,binary_relation_type) => (I=B <=> ! [E1] : (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,set_type) => (member(ordered_pair(E1,I1),I) <=> member(ordered_pair(E1,I1),B))))))).
fof(myForms, conjecture, ilf_type(B,binary_relation_type)).
fof(myForms, conjecture, (I=B <=> ! [E1] : (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,set_type) => (member(ordered_pair(E1,I1),I) <=> member(ordered_pair(E1,I1),B)))))).
fof(myForms, conjecture, I=B).
fof(myForms, conjecture, ! [E1] : (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,set_type) => (member(ordered_pair(E1,I1),I) <=> member(ordered_pair(E1,I1),B))))).
fof(myForms, conjecture, (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,set_type) => (member(ordered_pair(E1,I1),I) <=> member(ordered_pair(E1,I1),B))))).
fof(myForms, conjecture, ilf_type(E1,set_type)).
fof(myForms, conjecture, ! [I1] : (ilf_type(I1,set_type) => (member(ordered_pair(E1,I1),I) <=> member(ordered_pair(E1,I1),B)))).
fof(myForms, conjecture, (ilf_type(I1,set_type) => (member(ordered_pair(E1,I1),I) <=> member(ordered_pair(E1,I1),B)))).
fof(myForms, conjecture, ilf_type(I1,set_type)).
fof(myForms, conjecture, (member(ordered_pair(E1,I1),I) <=> member(ordered_pair(E1,I1),B))).
fof(myForms, conjecture, member(ordered_pair(E1,I1),I)).
fof(myForms, conjecture, member(ordered_pair(E1,I1),B)).