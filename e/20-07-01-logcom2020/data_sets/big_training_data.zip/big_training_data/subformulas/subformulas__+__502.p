fof(myForms, conjecture, ! [C] : unordered_pair(empty_set,singleton(C))=powerset(singleton(C))).
fof(myForms, conjecture, unordered_pair(empty_set,singleton(C))=powerset(singleton(C))).