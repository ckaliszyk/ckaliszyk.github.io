fof(myForms, conjecture, (ilf_type(E1,binary_relation_type) => (member(ordered_pair(I,B),E1) => (member(I,domain_of(E1)) & member(B,range_of(E1)))))).
fof(myForms, conjecture, ilf_type(E1,binary_relation_type)).
fof(myForms, conjecture, (member(ordered_pair(I,B),E1) => (member(I,domain_of(E1)) & member(B,range_of(E1))))).
fof(myForms, conjecture, member(ordered_pair(I,B),E1)).
fof(myForms, conjecture, (member(I,domain_of(E1)) & member(B,range_of(E1)))).
fof(myForms, conjecture, member(I,domain_of(E1))).
fof(myForms, conjecture, member(B,range_of(E1))).