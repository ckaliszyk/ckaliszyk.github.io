fof(myForms, conjecture, ! [I1] : (ilf_type(I1,member_type(I)) => (member(I1,domain(I,B,E1)) => ? [D] : (ilf_type(D,member_type(B)) & member(D,range(I,B,E1)))))).
fof(myForms, conjecture, (ilf_type(I1,member_type(I)) => (member(I1,domain(I,B,E1)) => ? [D] : (ilf_type(D,member_type(B)) & member(D,range(I,B,E1)))))).
fof(myForms, conjecture, ilf_type(I1,member_type(I))).
fof(myForms, conjecture, (member(I1,domain(I,B,E1)) => ? [D] : (ilf_type(D,member_type(B)) & member(D,range(I,B,E1))))).
fof(myForms, conjecture, member(I1,domain(I,B,E1))).
fof(myForms, conjecture, ? [D] : (ilf_type(D,member_type(B)) & member(D,range(I,B,E1)))).
fof(myForms, conjecture, (ilf_type(D,member_type(B)) & member(D,range(I,B,E1)))).
fof(myForms, conjecture, ilf_type(D,member_type(B))).
fof(myForms, conjecture, member(D,range(I,B,E1))).