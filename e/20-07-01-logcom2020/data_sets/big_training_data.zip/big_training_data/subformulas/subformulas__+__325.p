fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,relation_type(D,F)) => ! [J] : (ilf_type(J,set_type) => ilf_type(restrict4(D,F,I,J),relation_type(D,F))))))).
fof(myForms, conjecture, (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,relation_type(D,F)) => ! [J] : (ilf_type(J,set_type) => ilf_type(restrict4(D,F,I,J),relation_type(D,F))))))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,relation_type(D,F)) => ! [J] : (ilf_type(J,set_type) => ilf_type(restrict4(D,F,I,J),relation_type(D,F)))))).
fof(myForms, conjecture, (ilf_type(F,set_type) => ! [I] : (ilf_type(I,relation_type(D,F)) => ! [J] : (ilf_type(J,set_type) => ilf_type(restrict4(D,F,I,J),relation_type(D,F)))))).
fof(myForms, conjecture, ilf_type(F,set_type)).
fof(myForms, conjecture, ! [I] : (ilf_type(I,relation_type(D,F)) => ! [J] : (ilf_type(J,set_type) => ilf_type(restrict4(D,F,I,J),relation_type(D,F))))).
fof(myForms, conjecture, (ilf_type(I,relation_type(D,F)) => ! [J] : (ilf_type(J,set_type) => ilf_type(restrict4(D,F,I,J),relation_type(D,F))))).
fof(myForms, conjecture, ilf_type(I,relation_type(D,F))).
fof(myForms, conjecture, ! [J] : (ilf_type(J,set_type) => ilf_type(restrict4(D,F,I,J),relation_type(D,F)))).
fof(myForms, conjecture, (ilf_type(J,set_type) => ilf_type(restrict4(D,F,I,J),relation_type(D,F)))).
fof(myForms, conjecture, ilf_type(J,set_type)).
fof(myForms, conjecture, ilf_type(restrict4(D,F,I,J),relation_type(D,F))).