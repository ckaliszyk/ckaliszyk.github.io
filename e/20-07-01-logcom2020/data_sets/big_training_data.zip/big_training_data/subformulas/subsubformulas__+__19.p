fof(myForms, conjecture, ~ in(I,relation_dom(F))).
fof(myForms, conjecture, in(I,relation_dom(F))).