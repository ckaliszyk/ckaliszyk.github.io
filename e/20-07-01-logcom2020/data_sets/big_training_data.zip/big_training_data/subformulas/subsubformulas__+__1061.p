fof(myForms, conjecture, ! [I] : subset(F,F)).
fof(myForms, conjecture, subset(F,F)).