fof(myForms, conjecture, ! [J] : ! [C1] : ! [D1] : ! [O] : (((equivalence(C1,J) & equivalence(D1,J)) & ! [C] : ! [D] : ((member(C,J) & member(D,J)) => (apply(O,C,D) <=> (apply(C1,C,D) & apply(D1,C,D))))) => equivalence(O,J))).
fof(myForms, conjecture, ! [C1] : ! [D1] : ! [O] : (((equivalence(C1,J) & equivalence(D1,J)) & ! [C] : ! [D] : ((member(C,J) & member(D,J)) => (apply(O,C,D) <=> (apply(C1,C,D) & apply(D1,C,D))))) => equivalence(O,J))).
fof(myForms, conjecture, ! [D1] : ! [O] : (((equivalence(C1,J) & equivalence(D1,J)) & ! [C] : ! [D] : ((member(C,J) & member(D,J)) => (apply(O,C,D) <=> (apply(C1,C,D) & apply(D1,C,D))))) => equivalence(O,J))).
fof(myForms, conjecture, ! [O] : (((equivalence(C1,J) & equivalence(D1,J)) & ! [C] : ! [D] : ((member(C,J) & member(D,J)) => (apply(O,C,D) <=> (apply(C1,C,D) & apply(D1,C,D))))) => equivalence(O,J))).
fof(myForms, conjecture, (((equivalence(C1,J) & equivalence(D1,J)) & ! [C] : ! [D] : ((member(C,J) & member(D,J)) => (apply(O,C,D) <=> (apply(C1,C,D) & apply(D1,C,D))))) => equivalence(O,J))).
fof(myForms, conjecture, ((equivalence(C1,J) & equivalence(D1,J)) & ! [C] : ! [D] : ((member(C,J) & member(D,J)) => (apply(O,C,D) <=> (apply(C1,C,D) & apply(D1,C,D)))))).
fof(myForms, conjecture, (equivalence(C1,J) & equivalence(D1,J))).
fof(myForms, conjecture, equivalence(C1,J)).
fof(myForms, conjecture, equivalence(D1,J)).
fof(myForms, conjecture, ! [C] : ! [D] : ((member(C,J) & member(D,J)) => (apply(O,C,D) <=> (apply(C1,C,D) & apply(D1,C,D))))).
fof(myForms, conjecture, ! [D] : ((member(C,J) & member(D,J)) => (apply(O,C,D) <=> (apply(C1,C,D) & apply(D1,C,D))))).
fof(myForms, conjecture, ((member(C,J) & member(D,J)) => (apply(O,C,D) <=> (apply(C1,C,D) & apply(D1,C,D))))).
fof(myForms, conjecture, (member(C,J) & member(D,J))).
fof(myForms, conjecture, member(C,J)).
fof(myForms, conjecture, member(D,J)).
fof(myForms, conjecture, (apply(O,C,D) <=> (apply(C1,C,D) & apply(D1,C,D)))).
fof(myForms, conjecture, apply(O,C,D)).
fof(myForms, conjecture, (apply(C1,C,D) & apply(D1,C,D))).
fof(myForms, conjecture, apply(C1,C,D)).
fof(myForms, conjecture, apply(D1,C,D)).
fof(myForms, conjecture, equivalence(O,J)).