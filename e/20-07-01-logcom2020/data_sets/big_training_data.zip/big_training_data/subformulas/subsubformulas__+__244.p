fof(myForms, conjecture, ! [I] : (ilf_type(I,set_type) => ! [B] : (ilf_type(B,binary_relation_type) => (subset(range_of(B),I) => compose(B,identity_relation_of(I))=B)))).
fof(myForms, conjecture, (ilf_type(I,set_type) => ! [B] : (ilf_type(B,binary_relation_type) => (subset(range_of(B),I) => compose(B,identity_relation_of(I))=B)))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [B] : (ilf_type(B,binary_relation_type) => (subset(range_of(B),I) => compose(B,identity_relation_of(I))=B))).
fof(myForms, conjecture, (ilf_type(B,binary_relation_type) => (subset(range_of(B),I) => compose(B,identity_relation_of(I))=B))).
fof(myForms, conjecture, ilf_type(B,binary_relation_type)).
fof(myForms, conjecture, (subset(range_of(B),I) => compose(B,identity_relation_of(I))=B)).
fof(myForms, conjecture, subset(range_of(B),I)).
fof(myForms, conjecture, compose(B,identity_relation_of(I))=B).