fof(myForms, conjecture, (null_class=F1 | ? [R] : singleton(R)=F1)).
fof(myForms, conjecture, null_class=F1).
fof(myForms, conjecture, ? [R] : singleton(R)=F1).
fof(myForms, conjecture, singleton(R)=F1).