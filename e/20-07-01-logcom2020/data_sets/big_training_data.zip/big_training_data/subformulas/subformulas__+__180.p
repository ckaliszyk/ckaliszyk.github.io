fof(myForms, conjecture, ! [C] : ! [D] : ! [F] : ! [I] : ~ (((subset(C,cartesian_product2(D,F)) & in(I,C)) & ! [J] : ! [B] : ~ (((in(J,D) & in(B,F)) & ordered_pair(J,B)=I))))).
fof(myForms, conjecture, ! [D] : ! [F] : ! [I] : ~ (((subset(C,cartesian_product2(D,F)) & in(I,C)) & ! [J] : ! [B] : ~ (((in(J,D) & in(B,F)) & ordered_pair(J,B)=I))))).
fof(myForms, conjecture, ! [F] : ! [I] : ~ (((subset(C,cartesian_product2(D,F)) & in(I,C)) & ! [J] : ! [B] : ~ (((in(J,D) & in(B,F)) & ordered_pair(J,B)=I))))).
fof(myForms, conjecture, ! [I] : ~ (((subset(C,cartesian_product2(D,F)) & in(I,C)) & ! [J] : ! [B] : ~ (((in(J,D) & in(B,F)) & ordered_pair(J,B)=I))))).
fof(myForms, conjecture, ~ (((subset(C,cartesian_product2(D,F)) & in(I,C)) & ! [J] : ! [B] : ~ (((in(J,D) & in(B,F)) & ordered_pair(J,B)=I))))).
fof(myForms, conjecture, ((subset(C,cartesian_product2(D,F)) & in(I,C)) & ! [J] : ! [B] : ~ (((in(J,D) & in(B,F)) & ordered_pair(J,B)=I)))).
fof(myForms, conjecture, (subset(C,cartesian_product2(D,F)) & in(I,C))).
fof(myForms, conjecture, subset(C,cartesian_product2(D,F))).
fof(myForms, conjecture, in(I,C)).
fof(myForms, conjecture, ! [J] : ! [B] : ~ (((in(J,D) & in(B,F)) & ordered_pair(J,B)=I))).
fof(myForms, conjecture, ! [B] : ~ (((in(J,D) & in(B,F)) & ordered_pair(J,B)=I))).
fof(myForms, conjecture, ~ (((in(J,D) & in(B,F)) & ordered_pair(J,B)=I))).
fof(myForms, conjecture, ((in(J,D) & in(B,F)) & ordered_pair(J,B)=I)).
fof(myForms, conjecture, (in(J,D) & in(B,F))).
fof(myForms, conjecture, in(J,D)).
fof(myForms, conjecture, in(B,F)).
fof(myForms, conjecture, ordered_pair(J,B)=I).