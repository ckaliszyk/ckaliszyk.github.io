fof(myForms, conjecture, ! [C] : ! [D] : (in(C,D) => subset(C,union(D)))).
fof(myForms, conjecture, ! [D] : (in(C,D) => subset(C,union(D)))).
fof(myForms, conjecture, (in(C,D) => subset(C,union(D)))).
fof(myForms, conjecture, in(C,D)).
fof(myForms, conjecture, subset(C,union(D))).