fof(myForms, conjecture, ! [D] : ! [F] : ! [I] : (member(I,intersection(D,F)) <=> (member(I,D) & member(I,F)))).
fof(myForms, conjecture, ! [F] : ! [I] : (member(I,intersection(D,F)) <=> (member(I,D) & member(I,F)))).
fof(myForms, conjecture, ! [I] : (member(I,intersection(D,F)) <=> (member(I,D) & member(I,F)))).
fof(myForms, conjecture, (member(I,intersection(D,F)) <=> (member(I,D) & member(I,F)))).
fof(myForms, conjecture, member(I,intersection(D,F))).
fof(myForms, conjecture, (member(I,D) & member(I,F))).
fof(myForms, conjecture, member(I,D)).
fof(myForms, conjecture, member(I,F)).