fof(myForms, conjecture, (member(I1,B) & ~ member(I1,E1))).
fof(myForms, conjecture, member(I1,B)).
fof(myForms, conjecture, ~ member(I1,E1)).
fof(myForms, conjecture, member(I1,E1)).