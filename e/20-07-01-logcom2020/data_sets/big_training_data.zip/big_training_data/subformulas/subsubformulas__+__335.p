fof(myForms, conjecture, ! [E1] : (ilf_type(E1,set_type) => (singleton(B)=E1 <=> ! [I1] : (ilf_type(I1,set_type) => (member(I1,E1) <=> I1=B))))).
fof(myForms, conjecture, (ilf_type(E1,set_type) => (singleton(B)=E1 <=> ! [I1] : (ilf_type(I1,set_type) => (member(I1,E1) <=> I1=B))))).
fof(myForms, conjecture, ilf_type(E1,set_type)).
fof(myForms, conjecture, (singleton(B)=E1 <=> ! [I1] : (ilf_type(I1,set_type) => (member(I1,E1) <=> I1=B)))).
fof(myForms, conjecture, singleton(B)=E1).
fof(myForms, conjecture, ! [I1] : (ilf_type(I1,set_type) => (member(I1,E1) <=> I1=B))).
fof(myForms, conjecture, (ilf_type(I1,set_type) => (member(I1,E1) <=> I1=B))).
fof(myForms, conjecture, ilf_type(I1,set_type)).
fof(myForms, conjecture, (member(I1,E1) <=> I1=B)).
fof(myForms, conjecture, member(I1,E1)).
fof(myForms, conjecture, I1=B).