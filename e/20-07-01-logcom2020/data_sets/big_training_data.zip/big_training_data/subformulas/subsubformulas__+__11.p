fof(myForms, conjecture, ! [G1] : ((member(W,F1) & member(G1,intersection(complement(singleton(W)),F1))) => G1=W)).
fof(myForms, conjecture, ((member(W,F1) & member(G1,intersection(complement(singleton(W)),F1))) => G1=W)).
fof(myForms, conjecture, (member(W,F1) & member(G1,intersection(complement(singleton(W)),F1)))).
fof(myForms, conjecture, member(W,F1)).
fof(myForms, conjecture, member(G1,intersection(complement(singleton(W)),F1))).
fof(myForms, conjecture, G1=W).