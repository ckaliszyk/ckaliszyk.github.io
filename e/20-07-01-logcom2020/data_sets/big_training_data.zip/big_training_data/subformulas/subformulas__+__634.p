fof(myForms, conjecture, ! [C] : ! [D] : subset(C,C)).
fof(myForms, conjecture, ! [D] : subset(C,C)).
fof(myForms, conjecture, subset(C,C)).