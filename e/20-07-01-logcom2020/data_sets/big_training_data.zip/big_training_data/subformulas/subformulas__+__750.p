fof(myForms, conjecture, ! [L] : ! [P] : (member(P,universal_class) | ordered_pair(L,P)=first(ordered_pair(L,P)))).
fof(myForms, conjecture, ! [P] : (member(P,universal_class) | ordered_pair(L,P)=first(ordered_pair(L,P)))).
fof(myForms, conjecture, (member(P,universal_class) | ordered_pair(L,P)=first(ordered_pair(L,P)))).
fof(myForms, conjecture, member(P,universal_class)).
fof(myForms, conjecture, ordered_pair(L,P)=first(ordered_pair(L,P))).