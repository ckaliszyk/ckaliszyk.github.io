fof(myForms, conjecture, ! [I] : ! [B] : ! [E1] : difference(difference(I,B),E1)=difference(I,union(B,E1))).
fof(myForms, conjecture, ! [B] : ! [E1] : difference(difference(I,B),E1)=difference(I,union(B,E1))).
fof(myForms, conjecture, ! [E1] : difference(difference(I,B),E1)=difference(I,union(B,E1))).
fof(myForms, conjecture, difference(difference(I,B),E1)=difference(I,union(B,E1))).