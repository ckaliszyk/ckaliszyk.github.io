fof(myForms, conjecture, ! [C] : ! [D] : (! [F] : (in(F,C) => subset(F,D)) => subset(union(C),D))).
fof(myForms, conjecture, ! [D] : (! [F] : (in(F,C) => subset(F,D)) => subset(union(C),D))).
fof(myForms, conjecture, (! [F] : (in(F,C) => subset(F,D)) => subset(union(C),D))).
fof(myForms, conjecture, ! [F] : (in(F,C) => subset(F,D))).
fof(myForms, conjecture, (in(F,C) => subset(F,D))).
fof(myForms, conjecture, in(F,C)).
fof(myForms, conjecture, subset(F,D)).
fof(myForms, conjecture, subset(union(C),D)).