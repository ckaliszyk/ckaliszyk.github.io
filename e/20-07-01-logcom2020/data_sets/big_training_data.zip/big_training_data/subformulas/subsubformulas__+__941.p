fof(myForms, conjecture, ((member(F1,universal_class) & member(R,universal_class)) & unordered_pair(F1,J1)=unordered_pair(R,J1))).
fof(myForms, conjecture, (member(F1,universal_class) & member(R,universal_class))).
fof(myForms, conjecture, member(F1,universal_class)).
fof(myForms, conjecture, member(R,universal_class)).
fof(myForms, conjecture, unordered_pair(F1,J1)=unordered_pair(R,J1)).