fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ilf_type(singleton(D),set_type))).
fof(myForms, conjecture, (ilf_type(D,set_type) => ilf_type(singleton(D),set_type))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, ilf_type(singleton(D),set_type)).