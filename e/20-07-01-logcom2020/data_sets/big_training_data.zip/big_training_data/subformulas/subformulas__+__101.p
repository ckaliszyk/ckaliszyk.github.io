fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => ilf_type(unordered_pair(D,F),set_type)))).
fof(myForms, conjecture, (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => ilf_type(unordered_pair(D,F),set_type)))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, ! [F] : (ilf_type(F,set_type) => ilf_type(unordered_pair(D,F),set_type))).
fof(myForms, conjecture, (ilf_type(F,set_type) => ilf_type(unordered_pair(D,F),set_type))).
fof(myForms, conjecture, ilf_type(F,set_type)).
fof(myForms, conjecture, ilf_type(unordered_pair(D,F),set_type)).