fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => (F=D <=> (subset(D,F) & subset(F,D)))))).
fof(myForms, conjecture, (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => (F=D <=> (subset(D,F) & subset(F,D)))))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, ! [F] : (ilf_type(F,set_type) => (F=D <=> (subset(D,F) & subset(F,D))))).
fof(myForms, conjecture, (ilf_type(F,set_type) => (F=D <=> (subset(D,F) & subset(F,D))))).
fof(myForms, conjecture, ilf_type(F,set_type)).
fof(myForms, conjecture, (F=D <=> (subset(D,F) & subset(F,D)))).
fof(myForms, conjecture, F=D).
fof(myForms, conjecture, (subset(D,F) & subset(F,D))).
fof(myForms, conjecture, subset(D,F)).
fof(myForms, conjecture, subset(F,D)).