fof(myForms, conjecture, ! [D] : ! [F] : ! [I] : ((member(D,F) & disjoint(F,I)) => ~ member(D,I))).
fof(myForms, conjecture, ! [F] : ! [I] : ((member(D,F) & disjoint(F,I)) => ~ member(D,I))).
fof(myForms, conjecture, ! [I] : ((member(D,F) & disjoint(F,I)) => ~ member(D,I))).
fof(myForms, conjecture, ((member(D,F) & disjoint(F,I)) => ~ member(D,I))).
fof(myForms, conjecture, (member(D,F) & disjoint(F,I))).
fof(myForms, conjecture, member(D,F)).
fof(myForms, conjecture, disjoint(F,I)).
fof(myForms, conjecture, ~ member(D,I)).
fof(myForms, conjecture, member(D,I)).