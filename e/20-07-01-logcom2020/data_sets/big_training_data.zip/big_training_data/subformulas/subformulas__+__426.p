fof(myForms, conjecture, ! [C] : ! [D] : ! [J] : ((subset(C,J) & subset(D,J)) => (subset(C,D) <=> subset(intersection(C,difference(J,D)),difference(J,C))))).
fof(myForms, conjecture, ! [D] : ! [J] : ((subset(C,J) & subset(D,J)) => (subset(C,D) <=> subset(intersection(C,difference(J,D)),difference(J,C))))).
fof(myForms, conjecture, ! [J] : ((subset(C,J) & subset(D,J)) => (subset(C,D) <=> subset(intersection(C,difference(J,D)),difference(J,C))))).
fof(myForms, conjecture, ((subset(C,J) & subset(D,J)) => (subset(C,D) <=> subset(intersection(C,difference(J,D)),difference(J,C))))).
fof(myForms, conjecture, (subset(C,J) & subset(D,J))).
fof(myForms, conjecture, subset(C,J)).
fof(myForms, conjecture, subset(D,J)).
fof(myForms, conjecture, (subset(C,D) <=> subset(intersection(C,difference(J,D)),difference(J,C)))).
fof(myForms, conjecture, subset(C,D)).
fof(myForms, conjecture, subset(intersection(C,difference(J,D)),difference(J,C))).