fof(myForms, conjecture, ! [I1] : (ilf_type(I1,relation_type(E1,I)) => ilf_type(restrict4(E1,I,B,I1),relation_type(E1,B)))).
fof(myForms, conjecture, (ilf_type(I1,relation_type(E1,I)) => ilf_type(restrict4(E1,I,B,I1),relation_type(E1,B)))).
fof(myForms, conjecture, ilf_type(I1,relation_type(E1,I))).
fof(myForms, conjecture, ilf_type(restrict4(E1,I,B,I1),relation_type(E1,B))).