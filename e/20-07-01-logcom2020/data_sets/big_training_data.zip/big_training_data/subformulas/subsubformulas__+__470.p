fof(myForms, conjecture, ((subset(F,I1) & subset(I,I1)) => (subset(F,I) <=> equal_set(union(difference(I1,F),I),I1)))).
fof(myForms, conjecture, (subset(F,I1) & subset(I,I1))).
fof(myForms, conjecture, subset(F,I1)).
fof(myForms, conjecture, subset(I,I1)).
fof(myForms, conjecture, (subset(F,I) <=> equal_set(union(difference(I1,F),I),I1))).
fof(myForms, conjecture, subset(F,I)).
fof(myForms, conjecture, equal_set(union(difference(I1,F),I),I1)).