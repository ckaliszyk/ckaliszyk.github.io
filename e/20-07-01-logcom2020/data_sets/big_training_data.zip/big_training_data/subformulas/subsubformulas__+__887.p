fof(myForms, conjecture, ! [L] : ! [F] : ! [I] : (((((maps(D,F,I) & maps(J,I,F)) & maps(L,I,F)) & identity(compose_function(J,D,F,I,F),F)) & identity(compose_function(D,L,I,F,I),I)) => one_to_one(D,F,I))).
fof(myForms, conjecture, ! [F] : ! [I] : (((((maps(D,F,I) & maps(J,I,F)) & maps(L,I,F)) & identity(compose_function(J,D,F,I,F),F)) & identity(compose_function(D,L,I,F,I),I)) => one_to_one(D,F,I))).
fof(myForms, conjecture, ! [I] : (((((maps(D,F,I) & maps(J,I,F)) & maps(L,I,F)) & identity(compose_function(J,D,F,I,F),F)) & identity(compose_function(D,L,I,F,I),I)) => one_to_one(D,F,I))).
fof(myForms, conjecture, (((((maps(D,F,I) & maps(J,I,F)) & maps(L,I,F)) & identity(compose_function(J,D,F,I,F),F)) & identity(compose_function(D,L,I,F,I),I)) => one_to_one(D,F,I))).
fof(myForms, conjecture, ((((maps(D,F,I) & maps(J,I,F)) & maps(L,I,F)) & identity(compose_function(J,D,F,I,F),F)) & identity(compose_function(D,L,I,F,I),I))).
fof(myForms, conjecture, (((maps(D,F,I) & maps(J,I,F)) & maps(L,I,F)) & identity(compose_function(J,D,F,I,F),F))).
fof(myForms, conjecture, ((maps(D,F,I) & maps(J,I,F)) & maps(L,I,F))).
fof(myForms, conjecture, (maps(D,F,I) & maps(J,I,F))).
fof(myForms, conjecture, maps(D,F,I)).
fof(myForms, conjecture, maps(J,I,F)).
fof(myForms, conjecture, maps(L,I,F)).
fof(myForms, conjecture, identity(compose_function(J,D,F,I,F),F)).
fof(myForms, conjecture, identity(compose_function(D,L,I,F,I),I)).
fof(myForms, conjecture, one_to_one(D,F,I)).