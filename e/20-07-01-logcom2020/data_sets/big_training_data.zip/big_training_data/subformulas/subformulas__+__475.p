fof(myForms, conjecture, ! [C] : member(C,power_set(C))).
fof(myForms, conjecture, member(C,power_set(C))).