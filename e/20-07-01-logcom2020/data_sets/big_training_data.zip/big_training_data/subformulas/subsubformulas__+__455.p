fof(myForms, conjecture, (member(B,I) & E1=B)).
fof(myForms, conjecture, member(B,I)).
fof(myForms, conjecture, E1=B).