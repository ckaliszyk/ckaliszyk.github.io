fof(myForms, conjecture, ! [D] : (ilf_type(D,binary_relation_type) => subset(D,D))).
fof(myForms, conjecture, (ilf_type(D,binary_relation_type) => subset(D,D))).
fof(myForms, conjecture, ilf_type(D,binary_relation_type)).
fof(myForms, conjecture, subset(D,D)).