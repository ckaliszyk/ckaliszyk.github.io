fof(myForms, conjecture, (intersect(I,difference(B,E1)) => intersect(I,B))).
fof(myForms, conjecture, intersect(I,difference(B,E1))).
fof(myForms, conjecture, intersect(I,B)).