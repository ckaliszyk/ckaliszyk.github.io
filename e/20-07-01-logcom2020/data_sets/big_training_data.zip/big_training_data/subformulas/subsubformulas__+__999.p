fof(myForms, conjecture, ? [J] : ((ilf_type(J,member_type(E1)) & member(ordered_pair(J,D),I1)) & member(J,B))).
fof(myForms, conjecture, ((ilf_type(J,member_type(E1)) & member(ordered_pair(J,D),I1)) & member(J,B))).
fof(myForms, conjecture, (ilf_type(J,member_type(E1)) & member(ordered_pair(J,D),I1))).
fof(myForms, conjecture, ilf_type(J,member_type(E1))).
fof(myForms, conjecture, member(ordered_pair(J,D),I1)).
fof(myForms, conjecture, member(J,B)).