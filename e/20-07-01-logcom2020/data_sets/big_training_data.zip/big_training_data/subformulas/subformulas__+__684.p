fof(myForms, conjecture, ! [D] : ! [F] : ! [I] : (intersect(D,difference(F,I)) => intersect(D,F))).
fof(myForms, conjecture, ! [F] : ! [I] : (intersect(D,difference(F,I)) => intersect(D,F))).
fof(myForms, conjecture, ! [I] : (intersect(D,difference(F,I)) => intersect(D,F))).
fof(myForms, conjecture, (intersect(D,difference(F,I)) => intersect(D,F))).
fof(myForms, conjecture, intersect(D,difference(F,I))).
fof(myForms, conjecture, intersect(D,F)).