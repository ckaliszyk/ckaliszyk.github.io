fof(myForms, conjecture, ! [L] : ! [P] : ((singleton(P)=singleton(L) & member(P,universal_class)) => P=L)).
fof(myForms, conjecture, ! [P] : ((singleton(P)=singleton(L) & member(P,universal_class)) => P=L)).
fof(myForms, conjecture, ((singleton(P)=singleton(L) & member(P,universal_class)) => P=L)).
fof(myForms, conjecture, (singleton(P)=singleton(L) & member(P,universal_class))).
fof(myForms, conjecture, singleton(P)=singleton(L)).
fof(myForms, conjecture, member(P,universal_class)).
fof(myForms, conjecture, P=L).