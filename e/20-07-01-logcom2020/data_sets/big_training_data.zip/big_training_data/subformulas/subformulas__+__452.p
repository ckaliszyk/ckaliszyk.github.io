fof(myForms, conjecture, ! [C] : ! [D] : ! [F] : ~ (((~ in(C,D) & ~ in(F,D)) & ~ disjoint(unordered_pair(C,F),D)))).
fof(myForms, conjecture, ! [D] : ! [F] : ~ (((~ in(C,D) & ~ in(F,D)) & ~ disjoint(unordered_pair(C,F),D)))).
fof(myForms, conjecture, ! [F] : ~ (((~ in(C,D) & ~ in(F,D)) & ~ disjoint(unordered_pair(C,F),D)))).
fof(myForms, conjecture, ~ (((~ in(C,D) & ~ in(F,D)) & ~ disjoint(unordered_pair(C,F),D)))).
fof(myForms, conjecture, ((~ in(C,D) & ~ in(F,D)) & ~ disjoint(unordered_pair(C,F),D))).
fof(myForms, conjecture, (~ in(C,D) & ~ in(F,D))).
fof(myForms, conjecture, ~ in(C,D)).
fof(myForms, conjecture, in(C,D)).
fof(myForms, conjecture, ~ in(F,D)).
fof(myForms, conjecture, in(F,D)).
fof(myForms, conjecture, ~ disjoint(unordered_pair(C,F),D)).
fof(myForms, conjecture, disjoint(unordered_pair(C,F),D)).