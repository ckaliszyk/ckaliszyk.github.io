fof(myForms, conjecture, ! [B] : (unordered_pair(F,I)=B <=> ! [E1] : (in(E1,B) <=> (E1=F | E1=I)))).
fof(myForms, conjecture, (unordered_pair(F,I)=B <=> ! [E1] : (in(E1,B) <=> (E1=F | E1=I)))).
fof(myForms, conjecture, unordered_pair(F,I)=B).
fof(myForms, conjecture, ! [E1] : (in(E1,B) <=> (E1=F | E1=I))).
fof(myForms, conjecture, (in(E1,B) <=> (E1=F | E1=I))).
fof(myForms, conjecture, in(E1,B)).
fof(myForms, conjecture, (E1=F | E1=I)).
fof(myForms, conjecture, E1=F).
fof(myForms, conjecture, E1=I).