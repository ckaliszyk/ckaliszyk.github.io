fof(myForms, conjecture, ((subset(domain_of(E1),I) & subset(range_of(E1),B)) => ilf_type(E1,relation_type(I,B)))).
fof(myForms, conjecture, (subset(domain_of(E1),I) & subset(range_of(E1),B))).
fof(myForms, conjecture, subset(domain_of(E1),I)).
fof(myForms, conjecture, subset(range_of(E1),B)).
fof(myForms, conjecture, ilf_type(E1,relation_type(I,B))).