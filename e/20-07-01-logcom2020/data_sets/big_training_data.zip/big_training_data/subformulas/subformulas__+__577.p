fof(myForms, conjecture, ! [K] : (null_class=K | ? [P] : member(P,K))).
fof(myForms, conjecture, (null_class=K | ? [P] : member(P,K))).
fof(myForms, conjecture, null_class=K).
fof(myForms, conjecture, ? [P] : member(P,K)).
fof(myForms, conjecture, member(P,K)).