fof(myForms, conjecture, (equal_set(equivalence_class(F,I1,H1),equivalence_class(I,I1,H1)) <=> ~ disjoint(equivalence_class(F,I1,H1),equivalence_class(I,I1,H1)))).
fof(myForms, conjecture, equal_set(equivalence_class(F,I1,H1),equivalence_class(I,I1,H1))).
fof(myForms, conjecture, ~ disjoint(equivalence_class(F,I1,H1),equivalence_class(I,I1,H1))).
fof(myForms, conjecture, disjoint(equivalence_class(F,I1,H1),equivalence_class(I,I1,H1))).