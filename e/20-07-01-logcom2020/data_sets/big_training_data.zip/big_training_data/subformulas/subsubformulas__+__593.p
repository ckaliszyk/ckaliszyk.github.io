fof(myForms, conjecture, (ilf_type(B,set_type) => ! [E1] : (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,set_type) => ((subset(I,B) & subset(E1,I1)) => subset(cross_product(I,E1),cross_product(B,I1))))))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ! [E1] : (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,set_type) => ((subset(I,B) & subset(E1,I1)) => subset(cross_product(I,E1),cross_product(B,I1)))))).
fof(myForms, conjecture, (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,set_type) => ((subset(I,B) & subset(E1,I1)) => subset(cross_product(I,E1),cross_product(B,I1)))))).
fof(myForms, conjecture, ilf_type(E1,set_type)).
fof(myForms, conjecture, ! [I1] : (ilf_type(I1,set_type) => ((subset(I,B) & subset(E1,I1)) => subset(cross_product(I,E1),cross_product(B,I1))))).
fof(myForms, conjecture, (ilf_type(I1,set_type) => ((subset(I,B) & subset(E1,I1)) => subset(cross_product(I,E1),cross_product(B,I1))))).
fof(myForms, conjecture, ilf_type(I1,set_type)).
fof(myForms, conjecture, ((subset(I,B) & subset(E1,I1)) => subset(cross_product(I,E1),cross_product(B,I1)))).
fof(myForms, conjecture, (subset(I,B) & subset(E1,I1))).
fof(myForms, conjecture, subset(I,B)).
fof(myForms, conjecture, subset(E1,I1)).
fof(myForms, conjecture, subset(cross_product(I,E1),cross_product(B,I1))).