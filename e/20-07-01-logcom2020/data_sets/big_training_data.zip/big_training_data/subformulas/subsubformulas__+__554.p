fof(myForms, conjecture, ! [E1] : (member(E1,I) => member(E1,B))).
fof(myForms, conjecture, (member(E1,I) => member(E1,B))).
fof(myForms, conjecture, member(E1,I)).
fof(myForms, conjecture, member(E1,B)).