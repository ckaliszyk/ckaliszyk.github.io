fof(myForms, conjecture, ? [C] : (relation(C) & relation_empty_yielding(C))).
fof(myForms, conjecture, (relation(C) & relation_empty_yielding(C))).
fof(myForms, conjecture, relation(C)).
fof(myForms, conjecture, relation_empty_yielding(C)).