fof(myForms, conjecture, ! [D] : ! [F] : (! [I] : (member(I,D) <=> member(I,F)) => F=D)).
fof(myForms, conjecture, ! [F] : (! [I] : (member(I,D) <=> member(I,F)) => F=D)).
fof(myForms, conjecture, (! [I] : (member(I,D) <=> member(I,F)) => F=D)).
fof(myForms, conjecture, ! [I] : (member(I,D) <=> member(I,F))).
fof(myForms, conjecture, (member(I,D) <=> member(I,F))).
fof(myForms, conjecture, member(I,D)).
fof(myForms, conjecture, member(I,F)).
fof(myForms, conjecture, F=D).