fof(myForms, conjecture, (ilf_type(E1,relation_type(I,B)) => range(I,B,E1)=range_of(E1))).
fof(myForms, conjecture, ilf_type(E1,relation_type(I,B))).
fof(myForms, conjecture, range(I,B,E1)=range_of(E1)).