fof(myForms, conjecture, ! [B] : subset(I,union(I,B))).
fof(myForms, conjecture, subset(I,union(I,B))).