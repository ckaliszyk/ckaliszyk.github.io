fof(myForms, conjecture, ! [D] : ! [F] : ! [I] : (subset(D,union(F,I)) => (subset(difference(D,F),I) & subset(difference(D,I),F)))).
fof(myForms, conjecture, ! [F] : ! [I] : (subset(D,union(F,I)) => (subset(difference(D,F),I) & subset(difference(D,I),F)))).
fof(myForms, conjecture, ! [I] : (subset(D,union(F,I)) => (subset(difference(D,F),I) & subset(difference(D,I),F)))).
fof(myForms, conjecture, (subset(D,union(F,I)) => (subset(difference(D,F),I) & subset(difference(D,I),F)))).
fof(myForms, conjecture, subset(D,union(F,I))).
fof(myForms, conjecture, (subset(difference(D,F),I) & subset(difference(D,I),F))).
fof(myForms, conjecture, subset(difference(D,F),I)).
fof(myForms, conjecture, subset(difference(D,I),F)).