fof(myForms, conjecture, ! [B] : ! [C] : ! [D] : ! [L] : ! [P] : ((((maps(B,C,D) & injective(B,C,D)) & subset(L,C)) & subset(P,C)) => equal_set(image3(B,intersection(L,P),D),intersection(image3(B,L,D),image3(B,P,D))))).
fof(myForms, conjecture, ! [C] : ! [D] : ! [L] : ! [P] : ((((maps(B,C,D) & injective(B,C,D)) & subset(L,C)) & subset(P,C)) => equal_set(image3(B,intersection(L,P),D),intersection(image3(B,L,D),image3(B,P,D))))).
fof(myForms, conjecture, ! [D] : ! [L] : ! [P] : ((((maps(B,C,D) & injective(B,C,D)) & subset(L,C)) & subset(P,C)) => equal_set(image3(B,intersection(L,P),D),intersection(image3(B,L,D),image3(B,P,D))))).
fof(myForms, conjecture, ! [L] : ! [P] : ((((maps(B,C,D) & injective(B,C,D)) & subset(L,C)) & subset(P,C)) => equal_set(image3(B,intersection(L,P),D),intersection(image3(B,L,D),image3(B,P,D))))).
fof(myForms, conjecture, ! [P] : ((((maps(B,C,D) & injective(B,C,D)) & subset(L,C)) & subset(P,C)) => equal_set(image3(B,intersection(L,P),D),intersection(image3(B,L,D),image3(B,P,D))))).
fof(myForms, conjecture, ((((maps(B,C,D) & injective(B,C,D)) & subset(L,C)) & subset(P,C)) => equal_set(image3(B,intersection(L,P),D),intersection(image3(B,L,D),image3(B,P,D))))).
fof(myForms, conjecture, (((maps(B,C,D) & injective(B,C,D)) & subset(L,C)) & subset(P,C))).
fof(myForms, conjecture, ((maps(B,C,D) & injective(B,C,D)) & subset(L,C))).
fof(myForms, conjecture, (maps(B,C,D) & injective(B,C,D))).
fof(myForms, conjecture, maps(B,C,D)).
fof(myForms, conjecture, injective(B,C,D)).
fof(myForms, conjecture, subset(L,C)).
fof(myForms, conjecture, subset(P,C)).
fof(myForms, conjecture, equal_set(image3(B,intersection(L,P),D),intersection(image3(B,L,D),image3(B,P,D)))).