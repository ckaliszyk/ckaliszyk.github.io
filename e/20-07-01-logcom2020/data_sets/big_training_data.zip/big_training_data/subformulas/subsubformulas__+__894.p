fof(myForms, conjecture, ((((order(H1,I1) & member(F,I1)) & member(I,I1)) & apply(H1,F,I)) => least_upper_bound(I,unordered_pair(F,I),H1,I1))).
fof(myForms, conjecture, (((order(H1,I1) & member(F,I1)) & member(I,I1)) & apply(H1,F,I))).
fof(myForms, conjecture, ((order(H1,I1) & member(F,I1)) & member(I,I1))).
fof(myForms, conjecture, (order(H1,I1) & member(F,I1))).
fof(myForms, conjecture, order(H1,I1)).
fof(myForms, conjecture, member(F,I1)).
fof(myForms, conjecture, member(I,I1)).
fof(myForms, conjecture, apply(H1,F,I)).
fof(myForms, conjecture, least_upper_bound(I,unordered_pair(F,I),H1,I1)).