fof(myForms, conjecture, ! [C] : ! [D] : (element(C,powerset(D)) <=> subset(C,D))).
fof(myForms, conjecture, ! [D] : (element(C,powerset(D)) <=> subset(C,D))).
fof(myForms, conjecture, (element(C,powerset(D)) <=> subset(C,D))).
fof(myForms, conjecture, element(C,powerset(D))).
fof(myForms, conjecture, subset(C,D)).