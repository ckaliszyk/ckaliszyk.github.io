fof(myForms, conjecture, ! [L] : ! [P] : (subclass(L,singleton(P)) => (null_class=L | singleton(P)=L))).
fof(myForms, conjecture, ! [P] : (subclass(L,singleton(P)) => (null_class=L | singleton(P)=L))).
fof(myForms, conjecture, (subclass(L,singleton(P)) => (null_class=L | singleton(P)=L))).
fof(myForms, conjecture, subclass(L,singleton(P))).
fof(myForms, conjecture, (null_class=L | singleton(P)=L)).
fof(myForms, conjecture, null_class=L).
fof(myForms, conjecture, singleton(P)=L).