fof(myForms, conjecture, ! [M] : ! [N] : ((((member(Y,I1) & member(Z,I1)) & member(M,I1)) & member(N,I1)) => (((apply(H1,Y,M) & apply(H1,Z,N)) & apply(O,Y,Z)) => apply(O,M,N)))).
fof(myForms, conjecture, ! [N] : ((((member(Y,I1) & member(Z,I1)) & member(M,I1)) & member(N,I1)) => (((apply(H1,Y,M) & apply(H1,Z,N)) & apply(O,Y,Z)) => apply(O,M,N)))).
fof(myForms, conjecture, ((((member(Y,I1) & member(Z,I1)) & member(M,I1)) & member(N,I1)) => (((apply(H1,Y,M) & apply(H1,Z,N)) & apply(O,Y,Z)) => apply(O,M,N)))).
fof(myForms, conjecture, (((member(Y,I1) & member(Z,I1)) & member(M,I1)) & member(N,I1))).
fof(myForms, conjecture, ((member(Y,I1) & member(Z,I1)) & member(M,I1))).
fof(myForms, conjecture, (member(Y,I1) & member(Z,I1))).
fof(myForms, conjecture, member(Y,I1)).
fof(myForms, conjecture, member(Z,I1)).
fof(myForms, conjecture, member(M,I1)).
fof(myForms, conjecture, member(N,I1)).
fof(myForms, conjecture, (((apply(H1,Y,M) & apply(H1,Z,N)) & apply(O,Y,Z)) => apply(O,M,N))).
fof(myForms, conjecture, ((apply(H1,Y,M) & apply(H1,Z,N)) & apply(O,Y,Z))).
fof(myForms, conjecture, (apply(H1,Y,M) & apply(H1,Z,N))).
fof(myForms, conjecture, apply(H1,Y,M)).
fof(myForms, conjecture, apply(H1,Z,N)).
fof(myForms, conjecture, apply(O,Y,Z)).
fof(myForms, conjecture, apply(O,M,N)).