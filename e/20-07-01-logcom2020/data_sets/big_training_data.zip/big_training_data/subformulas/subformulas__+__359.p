fof(myForms, conjecture, ! [C] : ! [D] : (! [F] : (in(F,C) <=> in(F,D)) => D=C)).
fof(myForms, conjecture, ! [D] : (! [F] : (in(F,C) <=> in(F,D)) => D=C)).
fof(myForms, conjecture, (! [F] : (in(F,C) <=> in(F,D)) => D=C)).
fof(myForms, conjecture, ! [F] : (in(F,C) <=> in(F,D))).
fof(myForms, conjecture, (in(F,C) <=> in(F,D))).
fof(myForms, conjecture, in(F,C)).
fof(myForms, conjecture, in(F,D)).
fof(myForms, conjecture, D=C).