fof(myForms, conjecture, ! [I] : (ilf_type(I,set_type) => ! [B] : (ilf_type(B,set_type) => ! [E1] : (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,set_type) => ! [D] : (ilf_type(D,relation_type(I,B)) => (member(ordered_pair(E1,I1),D) => (member(E1,I) & member(I1,B))))))))).
fof(myForms, conjecture, (ilf_type(I,set_type) => ! [B] : (ilf_type(B,set_type) => ! [E1] : (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,set_type) => ! [D] : (ilf_type(D,relation_type(I,B)) => (member(ordered_pair(E1,I1),D) => (member(E1,I) & member(I1,B))))))))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [B] : (ilf_type(B,set_type) => ! [E1] : (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,set_type) => ! [D] : (ilf_type(D,relation_type(I,B)) => (member(ordered_pair(E1,I1),D) => (member(E1,I) & member(I1,B)))))))).
fof(myForms, conjecture, (ilf_type(B,set_type) => ! [E1] : (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,set_type) => ! [D] : (ilf_type(D,relation_type(I,B)) => (member(ordered_pair(E1,I1),D) => (member(E1,I) & member(I1,B)))))))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ! [E1] : (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,set_type) => ! [D] : (ilf_type(D,relation_type(I,B)) => (member(ordered_pair(E1,I1),D) => (member(E1,I) & member(I1,B))))))).
fof(myForms, conjecture, (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,set_type) => ! [D] : (ilf_type(D,relation_type(I,B)) => (member(ordered_pair(E1,I1),D) => (member(E1,I) & member(I1,B))))))).
fof(myForms, conjecture, ilf_type(E1,set_type)).
fof(myForms, conjecture, ! [I1] : (ilf_type(I1,set_type) => ! [D] : (ilf_type(D,relation_type(I,B)) => (member(ordered_pair(E1,I1),D) => (member(E1,I) & member(I1,B)))))).
fof(myForms, conjecture, (ilf_type(I1,set_type) => ! [D] : (ilf_type(D,relation_type(I,B)) => (member(ordered_pair(E1,I1),D) => (member(E1,I) & member(I1,B)))))).
fof(myForms, conjecture, ilf_type(I1,set_type)).
fof(myForms, conjecture, ! [D] : (ilf_type(D,relation_type(I,B)) => (member(ordered_pair(E1,I1),D) => (member(E1,I) & member(I1,B))))).
fof(myForms, conjecture, (ilf_type(D,relation_type(I,B)) => (member(ordered_pair(E1,I1),D) => (member(E1,I) & member(I1,B))))).
fof(myForms, conjecture, ilf_type(D,relation_type(I,B))).
fof(myForms, conjecture, (member(ordered_pair(E1,I1),D) => (member(E1,I) & member(I1,B)))).
fof(myForms, conjecture, member(ordered_pair(E1,I1),D)).
fof(myForms, conjecture, (member(E1,I) & member(I1,B))).
fof(myForms, conjecture, member(E1,I)).
fof(myForms, conjecture, member(I1,B)).