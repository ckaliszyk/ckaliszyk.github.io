fof(myForms, conjecture, ! [C] : ! [D] : (subset(C,D) => set_intersection2(C,D)=C)).
fof(myForms, conjecture, ! [D] : (subset(C,D) => set_intersection2(C,D)=C)).
fof(myForms, conjecture, (subset(C,D) => set_intersection2(C,D)=C)).
fof(myForms, conjecture, subset(C,D)).
fof(myForms, conjecture, set_intersection2(C,D)=C).