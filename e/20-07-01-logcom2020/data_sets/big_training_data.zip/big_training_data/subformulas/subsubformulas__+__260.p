fof(myForms, conjecture, (in(ordered_pair(F,I),cartesian_product2(singleton(B),E1)) <=> (F=B & in(I,E1)))).
fof(myForms, conjecture, in(ordered_pair(F,I),cartesian_product2(singleton(B),E1))).
fof(myForms, conjecture, (F=B & in(I,E1))).
fof(myForms, conjecture, F=B).
fof(myForms, conjecture, in(I,E1)).