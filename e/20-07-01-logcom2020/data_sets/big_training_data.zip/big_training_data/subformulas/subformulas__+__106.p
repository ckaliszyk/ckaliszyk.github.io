fof(myForms, conjecture, ! [D] : (ilf_type(D,binary_relation_type) => ! [F] : (ilf_type(F,set_type) => (member(F,range_of(D)) <=> ? [I] : (ilf_type(I,set_type) & member(ordered_pair(I,F),D)))))).
fof(myForms, conjecture, (ilf_type(D,binary_relation_type) => ! [F] : (ilf_type(F,set_type) => (member(F,range_of(D)) <=> ? [I] : (ilf_type(I,set_type) & member(ordered_pair(I,F),D)))))).
fof(myForms, conjecture, ilf_type(D,binary_relation_type)).
fof(myForms, conjecture, ! [F] : (ilf_type(F,set_type) => (member(F,range_of(D)) <=> ? [I] : (ilf_type(I,set_type) & member(ordered_pair(I,F),D))))).
fof(myForms, conjecture, (ilf_type(F,set_type) => (member(F,range_of(D)) <=> ? [I] : (ilf_type(I,set_type) & member(ordered_pair(I,F),D))))).
fof(myForms, conjecture, ilf_type(F,set_type)).
fof(myForms, conjecture, (member(F,range_of(D)) <=> ? [I] : (ilf_type(I,set_type) & member(ordered_pair(I,F),D)))).
fof(myForms, conjecture, member(F,range_of(D))).
fof(myForms, conjecture, ? [I] : (ilf_type(I,set_type) & member(ordered_pair(I,F),D))).
fof(myForms, conjecture, (ilf_type(I,set_type) & member(ordered_pair(I,F),D))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, member(ordered_pair(I,F),D)).