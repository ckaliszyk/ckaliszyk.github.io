fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,set_type) => (member(ordered_pair(F,I),identity_relation_of(D)) <=> (member(F,D) & I=F)))))).
fof(myForms, conjecture, (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,set_type) => (member(ordered_pair(F,I),identity_relation_of(D)) <=> (member(F,D) & I=F)))))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,set_type) => (member(ordered_pair(F,I),identity_relation_of(D)) <=> (member(F,D) & I=F))))).
fof(myForms, conjecture, (ilf_type(F,set_type) => ! [I] : (ilf_type(I,set_type) => (member(ordered_pair(F,I),identity_relation_of(D)) <=> (member(F,D) & I=F))))).
fof(myForms, conjecture, ilf_type(F,set_type)).
fof(myForms, conjecture, ! [I] : (ilf_type(I,set_type) => (member(ordered_pair(F,I),identity_relation_of(D)) <=> (member(F,D) & I=F)))).
fof(myForms, conjecture, (ilf_type(I,set_type) => (member(ordered_pair(F,I),identity_relation_of(D)) <=> (member(F,D) & I=F)))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, (member(ordered_pair(F,I),identity_relation_of(D)) <=> (member(F,D) & I=F))).
fof(myForms, conjecture, member(ordered_pair(F,I),identity_relation_of(D))).
fof(myForms, conjecture, (member(F,D) & I=F)).
fof(myForms, conjecture, member(F,D)).
fof(myForms, conjecture, I=F).