fof(myForms, conjecture, ! [C] : ! [D] : ((((relation(C) & function(C)) & relation(D)) & function(D)) => (relation(relation_composition(C,D)) & function(relation_composition(C,D))))).
fof(myForms, conjecture, ! [D] : ((((relation(C) & function(C)) & relation(D)) & function(D)) => (relation(relation_composition(C,D)) & function(relation_composition(C,D))))).
fof(myForms, conjecture, ((((relation(C) & function(C)) & relation(D)) & function(D)) => (relation(relation_composition(C,D)) & function(relation_composition(C,D))))).
fof(myForms, conjecture, (((relation(C) & function(C)) & relation(D)) & function(D))).
fof(myForms, conjecture, ((relation(C) & function(C)) & relation(D))).
fof(myForms, conjecture, (relation(C) & function(C))).
fof(myForms, conjecture, relation(C)).
fof(myForms, conjecture, function(C)).
fof(myForms, conjecture, relation(D)).
fof(myForms, conjecture, function(D)).
fof(myForms, conjecture, (relation(relation_composition(C,D)) & function(relation_composition(C,D)))).
fof(myForms, conjecture, relation(relation_composition(C,D))).
fof(myForms, conjecture, function(relation_composition(C,D))).