fof(myForms, conjecture, ! [D] : (ilf_type(D,binary_relation_type) => ilf_type(D,relation_type(domain_of(D),range_of(D))))).
fof(myForms, conjecture, (ilf_type(D,binary_relation_type) => ilf_type(D,relation_type(domain_of(D),range_of(D))))).
fof(myForms, conjecture, ilf_type(D,binary_relation_type)).
fof(myForms, conjecture, ilf_type(D,relation_type(domain_of(D),range_of(D)))).