fof(myForms, conjecture, ! [D] : ! [F] : (difference(F,D)=difference(D,F) => F=D)).
fof(myForms, conjecture, ! [F] : (difference(F,D)=difference(D,F) => F=D)).
fof(myForms, conjecture, (difference(F,D)=difference(D,F) => F=D)).
fof(myForms, conjecture, difference(F,D)=difference(D,F)).
fof(myForms, conjecture, F=D).