fof(myForms, conjecture, ! [B] : ! [E] : ! [C] : ! [D] : ! [F] : ((((maps(B,C,D) & maps(E,D,F)) & one_to_one(B,C,D)) & one_to_one(E,D,F)) => equal_maps(inverse_function(compose_function(E,B,C,D,F),C,F),compose_function(inverse_function(B,C,D),inverse_function(E,D,F),F,D,C),F,C))).
fof(myForms, conjecture, ! [E] : ! [C] : ! [D] : ! [F] : ((((maps(B,C,D) & maps(E,D,F)) & one_to_one(B,C,D)) & one_to_one(E,D,F)) => equal_maps(inverse_function(compose_function(E,B,C,D,F),C,F),compose_function(inverse_function(B,C,D),inverse_function(E,D,F),F,D,C),F,C))).
fof(myForms, conjecture, ! [C] : ! [D] : ! [F] : ((((maps(B,C,D) & maps(E,D,F)) & one_to_one(B,C,D)) & one_to_one(E,D,F)) => equal_maps(inverse_function(compose_function(E,B,C,D,F),C,F),compose_function(inverse_function(B,C,D),inverse_function(E,D,F),F,D,C),F,C))).
fof(myForms, conjecture, ! [D] : ! [F] : ((((maps(B,C,D) & maps(E,D,F)) & one_to_one(B,C,D)) & one_to_one(E,D,F)) => equal_maps(inverse_function(compose_function(E,B,C,D,F),C,F),compose_function(inverse_function(B,C,D),inverse_function(E,D,F),F,D,C),F,C))).
fof(myForms, conjecture, ! [F] : ((((maps(B,C,D) & maps(E,D,F)) & one_to_one(B,C,D)) & one_to_one(E,D,F)) => equal_maps(inverse_function(compose_function(E,B,C,D,F),C,F),compose_function(inverse_function(B,C,D),inverse_function(E,D,F),F,D,C),F,C))).
fof(myForms, conjecture, ((((maps(B,C,D) & maps(E,D,F)) & one_to_one(B,C,D)) & one_to_one(E,D,F)) => equal_maps(inverse_function(compose_function(E,B,C,D,F),C,F),compose_function(inverse_function(B,C,D),inverse_function(E,D,F),F,D,C),F,C))).
fof(myForms, conjecture, (((maps(B,C,D) & maps(E,D,F)) & one_to_one(B,C,D)) & one_to_one(E,D,F))).
fof(myForms, conjecture, ((maps(B,C,D) & maps(E,D,F)) & one_to_one(B,C,D))).
fof(myForms, conjecture, (maps(B,C,D) & maps(E,D,F))).
fof(myForms, conjecture, maps(B,C,D)).
fof(myForms, conjecture, maps(E,D,F)).
fof(myForms, conjecture, one_to_one(B,C,D)).
fof(myForms, conjecture, one_to_one(E,D,F)).
fof(myForms, conjecture, equal_maps(inverse_function(compose_function(E,B,C,D,F),C,F),compose_function(inverse_function(B,C,D),inverse_function(E,D,F),F,D,C),F,C)).