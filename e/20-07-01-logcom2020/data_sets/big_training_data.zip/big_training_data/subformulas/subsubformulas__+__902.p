fof(myForms, conjecture, ! [F] : ! [I] : ! [B] : (set_difference(F,I)=B <=> ! [E1] : (in(E1,B) <=> (in(E1,F) & ~ in(E1,I))))).
fof(myForms, conjecture, ! [I] : ! [B] : (set_difference(F,I)=B <=> ! [E1] : (in(E1,B) <=> (in(E1,F) & ~ in(E1,I))))).
fof(myForms, conjecture, ! [B] : (set_difference(F,I)=B <=> ! [E1] : (in(E1,B) <=> (in(E1,F) & ~ in(E1,I))))).
fof(myForms, conjecture, (set_difference(F,I)=B <=> ! [E1] : (in(E1,B) <=> (in(E1,F) & ~ in(E1,I))))).
fof(myForms, conjecture, set_difference(F,I)=B).
fof(myForms, conjecture, ! [E1] : (in(E1,B) <=> (in(E1,F) & ~ in(E1,I)))).
fof(myForms, conjecture, (in(E1,B) <=> (in(E1,F) & ~ in(E1,I)))).
fof(myForms, conjecture, in(E1,B)).
fof(myForms, conjecture, (in(E1,F) & ~ in(E1,I))).
fof(myForms, conjecture, in(E1,F)).
fof(myForms, conjecture, ~ in(E1,I)).
fof(myForms, conjecture, in(E1,I)).