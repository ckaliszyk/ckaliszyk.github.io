fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,set_type) => ! [B] : (ilf_type(B,set_type) => (ordered_pair(I,J)=B <=> unordered_pair(unordered_pair(I,J),singleton(I))=B))))))).
fof(myForms, conjecture, (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,set_type) => ! [B] : (ilf_type(B,set_type) => (ordered_pair(I,J)=B <=> unordered_pair(unordered_pair(I,J),singleton(I))=B))))))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,set_type) => ! [B] : (ilf_type(B,set_type) => (ordered_pair(I,J)=B <=> unordered_pair(unordered_pair(I,J),singleton(I))=B)))))).
fof(myForms, conjecture, (ilf_type(F,set_type) => ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,set_type) => ! [B] : (ilf_type(B,set_type) => (ordered_pair(I,J)=B <=> unordered_pair(unordered_pair(I,J),singleton(I))=B)))))).
fof(myForms, conjecture, ilf_type(F,set_type)).
fof(myForms, conjecture, ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,set_type) => ! [B] : (ilf_type(B,set_type) => (ordered_pair(I,J)=B <=> unordered_pair(unordered_pair(I,J),singleton(I))=B))))).
fof(myForms, conjecture, (ilf_type(I,set_type) => ! [J] : (ilf_type(J,set_type) => ! [B] : (ilf_type(B,set_type) => (ordered_pair(I,J)=B <=> unordered_pair(unordered_pair(I,J),singleton(I))=B))))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [J] : (ilf_type(J,set_type) => ! [B] : (ilf_type(B,set_type) => (ordered_pair(I,J)=B <=> unordered_pair(unordered_pair(I,J),singleton(I))=B)))).
fof(myForms, conjecture, (ilf_type(J,set_type) => ! [B] : (ilf_type(B,set_type) => (ordered_pair(I,J)=B <=> unordered_pair(unordered_pair(I,J),singleton(I))=B)))).
fof(myForms, conjecture, ilf_type(J,set_type)).
fof(myForms, conjecture, ! [B] : (ilf_type(B,set_type) => (ordered_pair(I,J)=B <=> unordered_pair(unordered_pair(I,J),singleton(I))=B))).
fof(myForms, conjecture, (ilf_type(B,set_type) => (ordered_pair(I,J)=B <=> unordered_pair(unordered_pair(I,J),singleton(I))=B))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, (ordered_pair(I,J)=B <=> unordered_pair(unordered_pair(I,J),singleton(I))=B)).
fof(myForms, conjecture, ordered_pair(I,J)=B).
fof(myForms, conjecture, unordered_pair(unordered_pair(I,J),singleton(I))=B).