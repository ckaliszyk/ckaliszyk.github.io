fof(myForms, conjecture, ! [B] : ! [E1] : (((maps(D,F,I) & maps(J,I,B)) & maps(L,B,E1)) => equal_maps(compose_function(L,compose_function(J,D,F,I,B),F,B,E1),compose_function(compose_function(L,J,I,B,E1),D,F,I,E1),F,E1))).
fof(myForms, conjecture, ! [E1] : (((maps(D,F,I) & maps(J,I,B)) & maps(L,B,E1)) => equal_maps(compose_function(L,compose_function(J,D,F,I,B),F,B,E1),compose_function(compose_function(L,J,I,B,E1),D,F,I,E1),F,E1))).
fof(myForms, conjecture, (((maps(D,F,I) & maps(J,I,B)) & maps(L,B,E1)) => equal_maps(compose_function(L,compose_function(J,D,F,I,B),F,B,E1),compose_function(compose_function(L,J,I,B,E1),D,F,I,E1),F,E1))).
fof(myForms, conjecture, ((maps(D,F,I) & maps(J,I,B)) & maps(L,B,E1))).
fof(myForms, conjecture, (maps(D,F,I) & maps(J,I,B))).
fof(myForms, conjecture, maps(D,F,I)).
fof(myForms, conjecture, maps(J,I,B)).
fof(myForms, conjecture, maps(L,B,E1)).
fof(myForms, conjecture, equal_maps(compose_function(L,compose_function(J,D,F,I,B),F,B,E1),compose_function(compose_function(L,J,I,B,E1),D,F,I,E1),F,E1)).