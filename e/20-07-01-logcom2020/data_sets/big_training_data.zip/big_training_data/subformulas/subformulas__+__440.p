fof(myForms, conjecture, ! [C] : ! [D] : (singleton(C)=set_union2(singleton(C),singleton(D)) => D=C)).
fof(myForms, conjecture, ! [D] : (singleton(C)=set_union2(singleton(C),singleton(D)) => D=C)).
fof(myForms, conjecture, (singleton(C)=set_union2(singleton(C),singleton(D)) => D=C)).
fof(myForms, conjecture, singleton(C)=set_union2(singleton(C),singleton(D))).
fof(myForms, conjecture, D=C).