fof(myForms, conjecture, ! [C] : equal_set(sum(singleton(C)),C)).
fof(myForms, conjecture, equal_set(sum(singleton(C)),C)).