fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => (member(F,D) <=> member(ordered_pair(F,F),identity_relation_of(D)))))).
fof(myForms, conjecture, (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => (member(F,D) <=> member(ordered_pair(F,F),identity_relation_of(D)))))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, ! [F] : (ilf_type(F,set_type) => (member(F,D) <=> member(ordered_pair(F,F),identity_relation_of(D))))).
fof(myForms, conjecture, (ilf_type(F,set_type) => (member(F,D) <=> member(ordered_pair(F,F),identity_relation_of(D))))).
fof(myForms, conjecture, ilf_type(F,set_type)).
fof(myForms, conjecture, (member(F,D) <=> member(ordered_pair(F,F),identity_relation_of(D)))).
fof(myForms, conjecture, member(F,D)).
fof(myForms, conjecture, member(ordered_pair(F,F),identity_relation_of(D))).