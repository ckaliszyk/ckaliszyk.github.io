fof(myForms, conjecture, ! [D] : ! [J] : ! [F] : ! [I] : ! [B] : ((((maps(D,F,I) & maps(J,I,B)) & injective(D,F,I)) & injective(J,I,B)) => injective(compose_function(J,D,F,I,B),F,B))).
fof(myForms, conjecture, ! [J] : ! [F] : ! [I] : ! [B] : ((((maps(D,F,I) & maps(J,I,B)) & injective(D,F,I)) & injective(J,I,B)) => injective(compose_function(J,D,F,I,B),F,B))).
fof(myForms, conjecture, ! [F] : ! [I] : ! [B] : ((((maps(D,F,I) & maps(J,I,B)) & injective(D,F,I)) & injective(J,I,B)) => injective(compose_function(J,D,F,I,B),F,B))).
fof(myForms, conjecture, ! [I] : ! [B] : ((((maps(D,F,I) & maps(J,I,B)) & injective(D,F,I)) & injective(J,I,B)) => injective(compose_function(J,D,F,I,B),F,B))).
fof(myForms, conjecture, ! [B] : ((((maps(D,F,I) & maps(J,I,B)) & injective(D,F,I)) & injective(J,I,B)) => injective(compose_function(J,D,F,I,B),F,B))).
fof(myForms, conjecture, ((((maps(D,F,I) & maps(J,I,B)) & injective(D,F,I)) & injective(J,I,B)) => injective(compose_function(J,D,F,I,B),F,B))).
fof(myForms, conjecture, (((maps(D,F,I) & maps(J,I,B)) & injective(D,F,I)) & injective(J,I,B))).
fof(myForms, conjecture, ((maps(D,F,I) & maps(J,I,B)) & injective(D,F,I))).
fof(myForms, conjecture, (maps(D,F,I) & maps(J,I,B))).
fof(myForms, conjecture, maps(D,F,I)).
fof(myForms, conjecture, maps(J,I,B)).
fof(myForms, conjecture, injective(D,F,I)).
fof(myForms, conjecture, injective(J,I,B)).
fof(myForms, conjecture, injective(compose_function(J,D,F,I,B),F,B)).