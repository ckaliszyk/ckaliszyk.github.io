fof(myForms, conjecture, (member(ordered_pair(B,E1),identity_relation_of(I)) <=> (member(B,I) & E1=B))).
fof(myForms, conjecture, member(ordered_pair(B,E1),identity_relation_of(I))).
fof(myForms, conjecture, (member(B,I) & E1=B)).
fof(myForms, conjecture, member(B,I)).
fof(myForms, conjecture, E1=B).