fof(myForms, conjecture, ! [F] : ! [I] : ~ ((disjoint(singleton(F),singleton(I)) & I=F))).
fof(myForms, conjecture, ! [I] : ~ ((disjoint(singleton(F),singleton(I)) & I=F))).
fof(myForms, conjecture, ~ ((disjoint(singleton(F),singleton(I)) & I=F))).
fof(myForms, conjecture, (disjoint(singleton(F),singleton(I)) & I=F)).
fof(myForms, conjecture, disjoint(singleton(F),singleton(I))).
fof(myForms, conjecture, I=F).