fof(myForms, conjecture, ! [D] : ! [F] : ! [I] : (member(I,union(D,F)) <=> (member(I,D) | member(I,F)))).
fof(myForms, conjecture, ! [F] : ! [I] : (member(I,union(D,F)) <=> (member(I,D) | member(I,F)))).
fof(myForms, conjecture, ! [I] : (member(I,union(D,F)) <=> (member(I,D) | member(I,F)))).
fof(myForms, conjecture, (member(I,union(D,F)) <=> (member(I,D) | member(I,F)))).
fof(myForms, conjecture, member(I,union(D,F))).
fof(myForms, conjecture, (member(I,D) | member(I,F))).
fof(myForms, conjecture, member(I,D)).
fof(myForms, conjecture, member(I,F)).