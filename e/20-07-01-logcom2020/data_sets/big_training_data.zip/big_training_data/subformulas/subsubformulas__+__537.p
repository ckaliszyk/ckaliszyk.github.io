fof(myForms, conjecture, ! [E1] : ((~ empty(E1) & ilf_type(E1,set_type)) => ! [I1] : (ilf_type(I1,relation_type(E1,I)) => ! [D] : (ilf_type(D,member_type(I)) => (member(D,image4(E1,I,I1,B)) <=> ? [J] : ((ilf_type(J,member_type(E1)) & member(ordered_pair(J,D),I1)) & member(J,B))))))).
fof(myForms, conjecture, ((~ empty(E1) & ilf_type(E1,set_type)) => ! [I1] : (ilf_type(I1,relation_type(E1,I)) => ! [D] : (ilf_type(D,member_type(I)) => (member(D,image4(E1,I,I1,B)) <=> ? [J] : ((ilf_type(J,member_type(E1)) & member(ordered_pair(J,D),I1)) & member(J,B))))))).
fof(myForms, conjecture, (~ empty(E1) & ilf_type(E1,set_type))).
fof(myForms, conjecture, ~ empty(E1)).
fof(myForms, conjecture, empty(E1)).
fof(myForms, conjecture, ilf_type(E1,set_type)).
fof(myForms, conjecture, ! [I1] : (ilf_type(I1,relation_type(E1,I)) => ! [D] : (ilf_type(D,member_type(I)) => (member(D,image4(E1,I,I1,B)) <=> ? [J] : ((ilf_type(J,member_type(E1)) & member(ordered_pair(J,D),I1)) & member(J,B)))))).
fof(myForms, conjecture, (ilf_type(I1,relation_type(E1,I)) => ! [D] : (ilf_type(D,member_type(I)) => (member(D,image4(E1,I,I1,B)) <=> ? [J] : ((ilf_type(J,member_type(E1)) & member(ordered_pair(J,D),I1)) & member(J,B)))))).
fof(myForms, conjecture, ilf_type(I1,relation_type(E1,I))).
fof(myForms, conjecture, ! [D] : (ilf_type(D,member_type(I)) => (member(D,image4(E1,I,I1,B)) <=> ? [J] : ((ilf_type(J,member_type(E1)) & member(ordered_pair(J,D),I1)) & member(J,B))))).
fof(myForms, conjecture, (ilf_type(D,member_type(I)) => (member(D,image4(E1,I,I1,B)) <=> ? [J] : ((ilf_type(J,member_type(E1)) & member(ordered_pair(J,D),I1)) & member(J,B))))).
fof(myForms, conjecture, ilf_type(D,member_type(I))).
fof(myForms, conjecture, (member(D,image4(E1,I,I1,B)) <=> ? [J] : ((ilf_type(J,member_type(E1)) & member(ordered_pair(J,D),I1)) & member(J,B)))).
fof(myForms, conjecture, member(D,image4(E1,I,I1,B))).
fof(myForms, conjecture, ? [J] : ((ilf_type(J,member_type(E1)) & member(ordered_pair(J,D),I1)) & member(J,B))).
fof(myForms, conjecture, ((ilf_type(J,member_type(E1)) & member(ordered_pair(J,D),I1)) & member(J,B))).
fof(myForms, conjecture, (ilf_type(J,member_type(E1)) & member(ordered_pair(J,D),I1))).
fof(myForms, conjecture, ilf_type(J,member_type(E1))).
fof(myForms, conjecture, member(ordered_pair(J,D),I1)).
fof(myForms, conjecture, member(J,B)).