fof(myForms, conjecture, (ilf_type(B,set_type) => ! [E1] : (ilf_type(E1,relation_type(I,B)) => ilf_type(range(I,B,E1),subset_type(B))))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ! [E1] : (ilf_type(E1,relation_type(I,B)) => ilf_type(range(I,B,E1),subset_type(B)))).
fof(myForms, conjecture, (ilf_type(E1,relation_type(I,B)) => ilf_type(range(I,B,E1),subset_type(B)))).
fof(myForms, conjecture, ilf_type(E1,relation_type(I,B))).
fof(myForms, conjecture, ilf_type(range(I,B,E1),subset_type(B))).