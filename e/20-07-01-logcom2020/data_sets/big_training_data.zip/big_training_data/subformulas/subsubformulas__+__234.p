fof(myForms, conjecture, (ilf_type(I1,set_type) & member(ordered_pair(B,I1),E1))).
fof(myForms, conjecture, ilf_type(I1,set_type)).
fof(myForms, conjecture, member(ordered_pair(B,I1),E1)).