fof(myForms, conjecture, (~ in(F,B) & ~ in(I,B))).
fof(myForms, conjecture, ~ in(F,B)).
fof(myForms, conjecture, in(F,B)).
fof(myForms, conjecture, ~ in(I,B)).
fof(myForms, conjecture, in(I,B)).