fof(myForms, conjecture, ! [B] : ! [E] : ! [C] : ! [D] : ! [F] : ((((maps(B,C,D) & subset(F,D)) & image2(B,C)=F) & ! [L] : ! [P] : ((member(L,C) & member(P,F)) => (apply(E,L,P) <=> apply(B,L,P)))) => surjective(E,C,F))).
fof(myForms, conjecture, ! [E] : ! [C] : ! [D] : ! [F] : ((((maps(B,C,D) & subset(F,D)) & image2(B,C)=F) & ! [L] : ! [P] : ((member(L,C) & member(P,F)) => (apply(E,L,P) <=> apply(B,L,P)))) => surjective(E,C,F))).
fof(myForms, conjecture, ! [C] : ! [D] : ! [F] : ((((maps(B,C,D) & subset(F,D)) & image2(B,C)=F) & ! [L] : ! [P] : ((member(L,C) & member(P,F)) => (apply(E,L,P) <=> apply(B,L,P)))) => surjective(E,C,F))).
fof(myForms, conjecture, ! [D] : ! [F] : ((((maps(B,C,D) & subset(F,D)) & image2(B,C)=F) & ! [L] : ! [P] : ((member(L,C) & member(P,F)) => (apply(E,L,P) <=> apply(B,L,P)))) => surjective(E,C,F))).
fof(myForms, conjecture, ! [F] : ((((maps(B,C,D) & subset(F,D)) & image2(B,C)=F) & ! [L] : ! [P] : ((member(L,C) & member(P,F)) => (apply(E,L,P) <=> apply(B,L,P)))) => surjective(E,C,F))).
fof(myForms, conjecture, ((((maps(B,C,D) & subset(F,D)) & image2(B,C)=F) & ! [L] : ! [P] : ((member(L,C) & member(P,F)) => (apply(E,L,P) <=> apply(B,L,P)))) => surjective(E,C,F))).
fof(myForms, conjecture, (((maps(B,C,D) & subset(F,D)) & image2(B,C)=F) & ! [L] : ! [P] : ((member(L,C) & member(P,F)) => (apply(E,L,P) <=> apply(B,L,P))))).
fof(myForms, conjecture, ((maps(B,C,D) & subset(F,D)) & image2(B,C)=F)).
fof(myForms, conjecture, (maps(B,C,D) & subset(F,D))).
fof(myForms, conjecture, maps(B,C,D)).
fof(myForms, conjecture, subset(F,D)).
fof(myForms, conjecture, image2(B,C)=F).
fof(myForms, conjecture, ! [L] : ! [P] : ((member(L,C) & member(P,F)) => (apply(E,L,P) <=> apply(B,L,P)))).
fof(myForms, conjecture, ! [P] : ((member(L,C) & member(P,F)) => (apply(E,L,P) <=> apply(B,L,P)))).
fof(myForms, conjecture, ((member(L,C) & member(P,F)) => (apply(E,L,P) <=> apply(B,L,P)))).
fof(myForms, conjecture, (member(L,C) & member(P,F))).
fof(myForms, conjecture, member(L,C)).
fof(myForms, conjecture, member(P,F)).
fof(myForms, conjecture, (apply(E,L,P) <=> apply(B,L,P))).
fof(myForms, conjecture, apply(E,L,P)).
fof(myForms, conjecture, apply(B,L,P)).
fof(myForms, conjecture, surjective(E,C,F)).