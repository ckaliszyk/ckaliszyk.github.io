fof(myForms, conjecture, (((relation(F) & function(F)) & relation(I)) & function(I))).
fof(myForms, conjecture, ((relation(F) & function(F)) & relation(I))).
fof(myForms, conjecture, (relation(F) & function(F))).
fof(myForms, conjecture, relation(F)).
fof(myForms, conjecture, function(F)).
fof(myForms, conjecture, relation(I)).
fof(myForms, conjecture, function(I)).