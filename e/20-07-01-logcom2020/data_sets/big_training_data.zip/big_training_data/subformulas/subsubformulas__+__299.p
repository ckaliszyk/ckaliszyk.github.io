fof(myForms, conjecture, (ordered_pair(D,J)=F & in(D,set_intersection2(I,E1)))).
fof(myForms, conjecture, ordered_pair(D,J)=F).
fof(myForms, conjecture, in(D,set_intersection2(I,E1))).