fof(myForms, conjecture, ! [B] : ! [E] : ! [C] : ! [D] : (((maps(E,C,D) & maps(B,D,C)) & identity(compose_function(E,B,D,C,D),D)) => surjective(E,C,D))).
fof(myForms, conjecture, ! [E] : ! [C] : ! [D] : (((maps(E,C,D) & maps(B,D,C)) & identity(compose_function(E,B,D,C,D),D)) => surjective(E,C,D))).
fof(myForms, conjecture, ! [C] : ! [D] : (((maps(E,C,D) & maps(B,D,C)) & identity(compose_function(E,B,D,C,D),D)) => surjective(E,C,D))).
fof(myForms, conjecture, ! [D] : (((maps(E,C,D) & maps(B,D,C)) & identity(compose_function(E,B,D,C,D),D)) => surjective(E,C,D))).
fof(myForms, conjecture, (((maps(E,C,D) & maps(B,D,C)) & identity(compose_function(E,B,D,C,D),D)) => surjective(E,C,D))).
fof(myForms, conjecture, ((maps(E,C,D) & maps(B,D,C)) & identity(compose_function(E,B,D,C,D),D))).
fof(myForms, conjecture, (maps(E,C,D) & maps(B,D,C))).
fof(myForms, conjecture, maps(E,C,D)).
fof(myForms, conjecture, maps(B,D,C)).
fof(myForms, conjecture, identity(compose_function(E,B,D,C,D),D)).
fof(myForms, conjecture, surjective(E,C,D)).