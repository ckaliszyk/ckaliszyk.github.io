fof(myForms, conjecture, ! [F] : ! [I] : (set_intersection2(F,singleton(I))=singleton(I) => in(I,F))).
fof(myForms, conjecture, ! [I] : (set_intersection2(F,singleton(I))=singleton(I) => in(I,F))).
fof(myForms, conjecture, (set_intersection2(F,singleton(I))=singleton(I) => in(I,F))).
fof(myForms, conjecture, set_intersection2(F,singleton(I))=singleton(I)).
fof(myForms, conjecture, in(I,F)).