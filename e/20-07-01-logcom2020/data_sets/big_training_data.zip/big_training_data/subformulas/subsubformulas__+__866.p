fof(myForms, conjecture, ? [B] : ilf_type(B,member_type(I))).
fof(myForms, conjecture, ilf_type(B,member_type(I))).