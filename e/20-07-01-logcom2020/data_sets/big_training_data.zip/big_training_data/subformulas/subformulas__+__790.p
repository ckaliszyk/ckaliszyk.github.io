fof(myForms, conjecture, ! [C] : ! [D] : (! [F] : ! [I] : ((in(F,set_union2(C,D)) & in(I,set_union2(C,D))) => (I=F | disjoint(F,I))) => set_intersection2(union(C),union(D))=union(set_intersection2(C,D)))).
fof(myForms, conjecture, ! [D] : (! [F] : ! [I] : ((in(F,set_union2(C,D)) & in(I,set_union2(C,D))) => (I=F | disjoint(F,I))) => set_intersection2(union(C),union(D))=union(set_intersection2(C,D)))).
fof(myForms, conjecture, (! [F] : ! [I] : ((in(F,set_union2(C,D)) & in(I,set_union2(C,D))) => (I=F | disjoint(F,I))) => set_intersection2(union(C),union(D))=union(set_intersection2(C,D)))).
fof(myForms, conjecture, ! [F] : ! [I] : ((in(F,set_union2(C,D)) & in(I,set_union2(C,D))) => (I=F | disjoint(F,I)))).
fof(myForms, conjecture, ! [I] : ((in(F,set_union2(C,D)) & in(I,set_union2(C,D))) => (I=F | disjoint(F,I)))).
fof(myForms, conjecture, ((in(F,set_union2(C,D)) & in(I,set_union2(C,D))) => (I=F | disjoint(F,I)))).
fof(myForms, conjecture, (in(F,set_union2(C,D)) & in(I,set_union2(C,D)))).
fof(myForms, conjecture, in(F,set_union2(C,D))).
fof(myForms, conjecture, in(I,set_union2(C,D))).
fof(myForms, conjecture, (I=F | disjoint(F,I))).
fof(myForms, conjecture, I=F).
fof(myForms, conjecture, disjoint(F,I)).
fof(myForms, conjecture, set_intersection2(union(C),union(D))=union(set_intersection2(C,D))).