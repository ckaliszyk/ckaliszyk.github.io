fof(myForms, conjecture, ! [C] : ! [D] : ! [F] : ~ empty_set=set_union2(unordered_pair(C,D),F)).
fof(myForms, conjecture, ! [D] : ! [F] : ~ empty_set=set_union2(unordered_pair(C,D),F)).
fof(myForms, conjecture, ! [F] : ~ empty_set=set_union2(unordered_pair(C,D),F)).
fof(myForms, conjecture, ~ empty_set=set_union2(unordered_pair(C,D),F)).
fof(myForms, conjecture, empty_set=set_union2(unordered_pair(C,D),F)).