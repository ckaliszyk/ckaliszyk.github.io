fof(myForms, conjecture, ((maps(D,F,I) & maps(J,I,B)) & one_to_one(D,F,I))).
fof(myForms, conjecture, (maps(D,F,I) & maps(J,I,B))).
fof(myForms, conjecture, maps(D,F,I)).
fof(myForms, conjecture, maps(J,I,B)).
fof(myForms, conjecture, one_to_one(D,F,I)).