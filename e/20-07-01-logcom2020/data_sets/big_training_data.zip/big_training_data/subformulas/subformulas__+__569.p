fof(myForms, conjecture, ! [C] : ! [D] : ! [F] : ! [I] : (in(ordered_pair(C,D),cartesian_product2(F,I)) => in(ordered_pair(D,C),cartesian_product2(I,F)))).
fof(myForms, conjecture, ! [D] : ! [F] : ! [I] : (in(ordered_pair(C,D),cartesian_product2(F,I)) => in(ordered_pair(D,C),cartesian_product2(I,F)))).
fof(myForms, conjecture, ! [F] : ! [I] : (in(ordered_pair(C,D),cartesian_product2(F,I)) => in(ordered_pair(D,C),cartesian_product2(I,F)))).
fof(myForms, conjecture, ! [I] : (in(ordered_pair(C,D),cartesian_product2(F,I)) => in(ordered_pair(D,C),cartesian_product2(I,F)))).
fof(myForms, conjecture, (in(ordered_pair(C,D),cartesian_product2(F,I)) => in(ordered_pair(D,C),cartesian_product2(I,F)))).
fof(myForms, conjecture, in(ordered_pair(C,D),cartesian_product2(F,I))).
fof(myForms, conjecture, in(ordered_pair(D,C),cartesian_product2(I,F))).