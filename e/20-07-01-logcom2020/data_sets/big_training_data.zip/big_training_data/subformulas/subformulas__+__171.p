fof(myForms, conjecture, ! [C] : ! [J] : ! [O] : (partition(C,J) => (! [L] : ! [P] : ((member(L,J) & member(P,J)) => (apply(O,L,P) <=> ? [K] : ((member(K,C) & member(L,K)) & member(P,K)))) => equivalence(O,J)))).
fof(myForms, conjecture, ! [J] : ! [O] : (partition(C,J) => (! [L] : ! [P] : ((member(L,J) & member(P,J)) => (apply(O,L,P) <=> ? [K] : ((member(K,C) & member(L,K)) & member(P,K)))) => equivalence(O,J)))).
fof(myForms, conjecture, ! [O] : (partition(C,J) => (! [L] : ! [P] : ((member(L,J) & member(P,J)) => (apply(O,L,P) <=> ? [K] : ((member(K,C) & member(L,K)) & member(P,K)))) => equivalence(O,J)))).
fof(myForms, conjecture, (partition(C,J) => (! [L] : ! [P] : ((member(L,J) & member(P,J)) => (apply(O,L,P) <=> ? [K] : ((member(K,C) & member(L,K)) & member(P,K)))) => equivalence(O,J)))).
fof(myForms, conjecture, partition(C,J)).
fof(myForms, conjecture, (! [L] : ! [P] : ((member(L,J) & member(P,J)) => (apply(O,L,P) <=> ? [K] : ((member(K,C) & member(L,K)) & member(P,K)))) => equivalence(O,J))).
fof(myForms, conjecture, ! [L] : ! [P] : ((member(L,J) & member(P,J)) => (apply(O,L,P) <=> ? [K] : ((member(K,C) & member(L,K)) & member(P,K))))).
fof(myForms, conjecture, ! [P] : ((member(L,J) & member(P,J)) => (apply(O,L,P) <=> ? [K] : ((member(K,C) & member(L,K)) & member(P,K))))).
fof(myForms, conjecture, ((member(L,J) & member(P,J)) => (apply(O,L,P) <=> ? [K] : ((member(K,C) & member(L,K)) & member(P,K))))).
fof(myForms, conjecture, (member(L,J) & member(P,J))).
fof(myForms, conjecture, member(L,J)).
fof(myForms, conjecture, member(P,J)).
fof(myForms, conjecture, (apply(O,L,P) <=> ? [K] : ((member(K,C) & member(L,K)) & member(P,K)))).
fof(myForms, conjecture, apply(O,L,P)).
fof(myForms, conjecture, ? [K] : ((member(K,C) & member(L,K)) & member(P,K))).
fof(myForms, conjecture, ((member(K,C) & member(L,K)) & member(P,K))).
fof(myForms, conjecture, (member(K,C) & member(L,K))).
fof(myForms, conjecture, member(K,C)).
fof(myForms, conjecture, member(L,K)).
fof(myForms, conjecture, member(P,K)).
fof(myForms, conjecture, equivalence(O,J)).