fof(myForms, conjecture, ! [B] : ! [C] : ! [D] : ! [L] : (((maps(B,C,D) & subset(L,C)) & equal_set(image2(B,L),empty_set)) => equal_set(L,empty_set))).
fof(myForms, conjecture, ! [C] : ! [D] : ! [L] : (((maps(B,C,D) & subset(L,C)) & equal_set(image2(B,L),empty_set)) => equal_set(L,empty_set))).
fof(myForms, conjecture, ! [D] : ! [L] : (((maps(B,C,D) & subset(L,C)) & equal_set(image2(B,L),empty_set)) => equal_set(L,empty_set))).
fof(myForms, conjecture, ! [L] : (((maps(B,C,D) & subset(L,C)) & equal_set(image2(B,L),empty_set)) => equal_set(L,empty_set))).
fof(myForms, conjecture, (((maps(B,C,D) & subset(L,C)) & equal_set(image2(B,L),empty_set)) => equal_set(L,empty_set))).
fof(myForms, conjecture, ((maps(B,C,D) & subset(L,C)) & equal_set(image2(B,L),empty_set))).
fof(myForms, conjecture, (maps(B,C,D) & subset(L,C))).
fof(myForms, conjecture, maps(B,C,D)).
fof(myForms, conjecture, subset(L,C)).
fof(myForms, conjecture, equal_set(image2(B,L),empty_set)).
fof(myForms, conjecture, equal_set(L,empty_set)).