fof(myForms, conjecture, ! [C] : equal_set(intersection(C,empty_set),empty_set)).
fof(myForms, conjecture, equal_set(intersection(C,empty_set),empty_set)).