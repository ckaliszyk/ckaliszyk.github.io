fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,relation_type(D,I)) => ilf_type(restrict4(D,I,J,F),relation_type(F,I))))))).
fof(myForms, conjecture, (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,relation_type(D,I)) => ilf_type(restrict4(D,I,J,F),relation_type(F,I))))))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,relation_type(D,I)) => ilf_type(restrict4(D,I,J,F),relation_type(F,I)))))).
fof(myForms, conjecture, (ilf_type(F,set_type) => ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,relation_type(D,I)) => ilf_type(restrict4(D,I,J,F),relation_type(F,I)))))).
fof(myForms, conjecture, ilf_type(F,set_type)).
fof(myForms, conjecture, ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,relation_type(D,I)) => ilf_type(restrict4(D,I,J,F),relation_type(F,I))))).
fof(myForms, conjecture, (ilf_type(I,set_type) => ! [J] : (ilf_type(J,relation_type(D,I)) => ilf_type(restrict4(D,I,J,F),relation_type(F,I))))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [J] : (ilf_type(J,relation_type(D,I)) => ilf_type(restrict4(D,I,J,F),relation_type(F,I)))).
fof(myForms, conjecture, (ilf_type(J,relation_type(D,I)) => ilf_type(restrict4(D,I,J,F),relation_type(F,I)))).
fof(myForms, conjecture, ilf_type(J,relation_type(D,I))).
fof(myForms, conjecture, ilf_type(restrict4(D,I,J,F),relation_type(F,I))).