fof(myForms, conjecture, ! [I] : (ilf_type(I,set_type) => ! [B] : (ilf_type(B,set_type) => ilf_type(cross_product(I,B),relation_type(I,B))))).
fof(myForms, conjecture, (ilf_type(I,set_type) => ! [B] : (ilf_type(B,set_type) => ilf_type(cross_product(I,B),relation_type(I,B))))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [B] : (ilf_type(B,set_type) => ilf_type(cross_product(I,B),relation_type(I,B)))).
fof(myForms, conjecture, (ilf_type(B,set_type) => ilf_type(cross_product(I,B),relation_type(I,B)))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ilf_type(cross_product(I,B),relation_type(I,B))).