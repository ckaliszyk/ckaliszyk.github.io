fof(myForms, conjecture, ! [I] : ! [F1] : (((maps(D,F,I) & subset(F1,F)) & equal_set(image2(D,F1),empty_set)) => equal_set(F1,empty_set))).
fof(myForms, conjecture, ! [F1] : (((maps(D,F,I) & subset(F1,F)) & equal_set(image2(D,F1),empty_set)) => equal_set(F1,empty_set))).
fof(myForms, conjecture, (((maps(D,F,I) & subset(F1,F)) & equal_set(image2(D,F1),empty_set)) => equal_set(F1,empty_set))).
fof(myForms, conjecture, ((maps(D,F,I) & subset(F1,F)) & equal_set(image2(D,F1),empty_set))).
fof(myForms, conjecture, (maps(D,F,I) & subset(F1,F))).
fof(myForms, conjecture, maps(D,F,I)).
fof(myForms, conjecture, subset(F1,F)).
fof(myForms, conjecture, equal_set(image2(D,F1),empty_set)).
fof(myForms, conjecture, equal_set(F1,empty_set)).