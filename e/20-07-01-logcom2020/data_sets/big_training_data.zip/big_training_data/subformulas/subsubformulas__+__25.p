fof(myForms, conjecture, ! [F1] : ! [R] : ((((maps(D,F,I) & subset(F1,F)) & subset(R,F)) & subset(F1,R)) => subset(image2(D,F1),image2(D,R)))).
fof(myForms, conjecture, ! [R] : ((((maps(D,F,I) & subset(F1,F)) & subset(R,F)) & subset(F1,R)) => subset(image2(D,F1),image2(D,R)))).
fof(myForms, conjecture, ((((maps(D,F,I) & subset(F1,F)) & subset(R,F)) & subset(F1,R)) => subset(image2(D,F1),image2(D,R)))).
fof(myForms, conjecture, (((maps(D,F,I) & subset(F1,F)) & subset(R,F)) & subset(F1,R))).
fof(myForms, conjecture, ((maps(D,F,I) & subset(F1,F)) & subset(R,F))).
fof(myForms, conjecture, (maps(D,F,I) & subset(F1,F))).
fof(myForms, conjecture, maps(D,F,I)).
fof(myForms, conjecture, subset(F1,F)).
fof(myForms, conjecture, subset(R,F)).
fof(myForms, conjecture, subset(F1,R)).
fof(myForms, conjecture, subset(image2(D,F1),image2(D,R))).