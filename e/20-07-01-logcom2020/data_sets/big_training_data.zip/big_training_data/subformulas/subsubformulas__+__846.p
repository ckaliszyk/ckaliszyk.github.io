fof(myForms, conjecture, (ilf_type(I1,relation_type(I,B)) => (subset(identity_relation_of(E1),I1) => (subset(E1,domain(I,B,I1)) & subset(E1,range(I,B,I1)))))).
fof(myForms, conjecture, ilf_type(I1,relation_type(I,B))).
fof(myForms, conjecture, (subset(identity_relation_of(E1),I1) => (subset(E1,domain(I,B,I1)) & subset(E1,range(I,B,I1))))).
fof(myForms, conjecture, subset(identity_relation_of(E1),I1)).
fof(myForms, conjecture, (subset(E1,domain(I,B,I1)) & subset(E1,range(I,B,I1)))).
fof(myForms, conjecture, subset(E1,domain(I,B,I1))).
fof(myForms, conjecture, subset(E1,range(I,B,I1))).