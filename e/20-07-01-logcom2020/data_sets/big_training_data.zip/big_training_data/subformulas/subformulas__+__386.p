fof(myForms, conjecture, ! [C] : ! [D] : (subset(C,D) => subset(powerset(C),powerset(D)))).
fof(myForms, conjecture, ! [D] : (subset(C,D) => subset(powerset(C),powerset(D)))).
fof(myForms, conjecture, (subset(C,D) => subset(powerset(C),powerset(D)))).
fof(myForms, conjecture, subset(C,D)).
fof(myForms, conjecture, subset(powerset(C),powerset(D))).