fof(myForms, conjecture, ~ (? [J1] : (element(F1,J1) & element(J1,F1)))).
fof(myForms, conjecture, ? [J1] : (element(F1,J1) & element(J1,F1))).
fof(myForms, conjecture, (element(F1,J1) & element(J1,F1))).
fof(myForms, conjecture, element(F1,J1)).
fof(myForms, conjecture, element(J1,F1)).