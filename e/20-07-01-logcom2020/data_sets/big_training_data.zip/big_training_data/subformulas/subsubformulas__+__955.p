fof(myForms, conjecture, (in(ordered_pair(F,I),cartesian_product2(B,E1)) <=> (in(F,B) & in(I,E1)))).
fof(myForms, conjecture, in(ordered_pair(F,I),cartesian_product2(B,E1))).
fof(myForms, conjecture, (in(F,B) & in(I,E1))).
fof(myForms, conjecture, in(F,B)).
fof(myForms, conjecture, in(I,E1)).