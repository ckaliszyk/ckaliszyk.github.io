fof(myForms, conjecture, ! [E1] : (! [I1] : ! [D] : (in(ordered_pair(I1,D),cartesian_product2(F,I)) <=> in(ordered_pair(I1,D),cartesian_product2(B,E1))) => cartesian_product2(F,I)=cartesian_product2(B,E1))).
fof(myForms, conjecture, (! [I1] : ! [D] : (in(ordered_pair(I1,D),cartesian_product2(F,I)) <=> in(ordered_pair(I1,D),cartesian_product2(B,E1))) => cartesian_product2(F,I)=cartesian_product2(B,E1))).
fof(myForms, conjecture, ! [I1] : ! [D] : (in(ordered_pair(I1,D),cartesian_product2(F,I)) <=> in(ordered_pair(I1,D),cartesian_product2(B,E1)))).
fof(myForms, conjecture, ! [D] : (in(ordered_pair(I1,D),cartesian_product2(F,I)) <=> in(ordered_pair(I1,D),cartesian_product2(B,E1)))).
fof(myForms, conjecture, (in(ordered_pair(I1,D),cartesian_product2(F,I)) <=> in(ordered_pair(I1,D),cartesian_product2(B,E1)))).
fof(myForms, conjecture, in(ordered_pair(I1,D),cartesian_product2(F,I))).
fof(myForms, conjecture, in(ordered_pair(I1,D),cartesian_product2(B,E1))).
fof(myForms, conjecture, cartesian_product2(F,I)=cartesian_product2(B,E1)).