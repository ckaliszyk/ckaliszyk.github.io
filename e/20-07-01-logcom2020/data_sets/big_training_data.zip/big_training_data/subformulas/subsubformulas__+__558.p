fof(myForms, conjecture, ! [B] : ((in(F,I) & element(I,powerset(B))) => element(F,B))).
fof(myForms, conjecture, ((in(F,I) & element(I,powerset(B))) => element(F,B))).
fof(myForms, conjecture, (in(F,I) & element(I,powerset(B)))).
fof(myForms, conjecture, in(F,I)).
fof(myForms, conjecture, element(I,powerset(B))).
fof(myForms, conjecture, element(F,B)).