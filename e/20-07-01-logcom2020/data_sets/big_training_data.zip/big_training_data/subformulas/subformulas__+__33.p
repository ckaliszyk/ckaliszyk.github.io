fof(myForms, conjecture, ! [B] : ! [C] : ! [D] : ! [P] : (((maps(B,C,D) & surjective(B,C,D)) & subset(P,D)) => equal_set(image3(B,inverse_image3(B,P,C),D),P))).
fof(myForms, conjecture, ! [C] : ! [D] : ! [P] : (((maps(B,C,D) & surjective(B,C,D)) & subset(P,D)) => equal_set(image3(B,inverse_image3(B,P,C),D),P))).
fof(myForms, conjecture, ! [D] : ! [P] : (((maps(B,C,D) & surjective(B,C,D)) & subset(P,D)) => equal_set(image3(B,inverse_image3(B,P,C),D),P))).
fof(myForms, conjecture, ! [P] : (((maps(B,C,D) & surjective(B,C,D)) & subset(P,D)) => equal_set(image3(B,inverse_image3(B,P,C),D),P))).
fof(myForms, conjecture, (((maps(B,C,D) & surjective(B,C,D)) & subset(P,D)) => equal_set(image3(B,inverse_image3(B,P,C),D),P))).
fof(myForms, conjecture, ((maps(B,C,D) & surjective(B,C,D)) & subset(P,D))).
fof(myForms, conjecture, (maps(B,C,D) & surjective(B,C,D))).
fof(myForms, conjecture, maps(B,C,D)).
fof(myForms, conjecture, surjective(B,C,D)).
fof(myForms, conjecture, subset(P,D)).
fof(myForms, conjecture, equal_set(image3(B,inverse_image3(B,P,C),D),P)).