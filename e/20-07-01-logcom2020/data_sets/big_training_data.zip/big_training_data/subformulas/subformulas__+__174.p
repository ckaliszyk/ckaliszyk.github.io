fof(myForms, conjecture, ! [C] : ! [D] : ! [F] : ((in(C,D) & element(D,powerset(F))) => element(C,F))).
fof(myForms, conjecture, ! [D] : ! [F] : ((in(C,D) & element(D,powerset(F))) => element(C,F))).
fof(myForms, conjecture, ! [F] : ((in(C,D) & element(D,powerset(F))) => element(C,F))).
fof(myForms, conjecture, ((in(C,D) & element(D,powerset(F))) => element(C,F))).
fof(myForms, conjecture, (in(C,D) & element(D,powerset(F)))).
fof(myForms, conjecture, in(C,D)).
fof(myForms, conjecture, element(D,powerset(F))).
fof(myForms, conjecture, element(C,F)).