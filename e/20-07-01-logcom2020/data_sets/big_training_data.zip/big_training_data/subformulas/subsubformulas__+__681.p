fof(myForms, conjecture, ! [I1] : (ilf_type(I1,relation_type(I,E1)) => ilf_type(restrict4(I,E1,I1,B),relation_type(B,E1)))).
fof(myForms, conjecture, (ilf_type(I1,relation_type(I,E1)) => ilf_type(restrict4(I,E1,I1,B),relation_type(B,E1)))).
fof(myForms, conjecture, ilf_type(I1,relation_type(I,E1))).
fof(myForms, conjecture, ilf_type(restrict4(I,E1,I1,B),relation_type(B,E1))).