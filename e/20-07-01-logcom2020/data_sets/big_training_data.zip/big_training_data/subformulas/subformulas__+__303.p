fof(myForms, conjecture, ! [D] : ! [F] : (F=D <=> ! [I] : (member(I,D) <=> member(I,F)))).
fof(myForms, conjecture, ! [F] : (F=D <=> ! [I] : (member(I,D) <=> member(I,F)))).
fof(myForms, conjecture, (F=D <=> ! [I] : (member(I,D) <=> member(I,F)))).
fof(myForms, conjecture, F=D).
fof(myForms, conjecture, ! [I] : (member(I,D) <=> member(I,F))).
fof(myForms, conjecture, (member(I,D) <=> member(I,F))).
fof(myForms, conjecture, member(I,D)).
fof(myForms, conjecture, member(I,F)).