fof(myForms, conjecture, (ilf_type(I,set_type) => ! [B] : (ilf_type(B,set_type) => (member(I,power_set(B)) <=> ! [E1] : (ilf_type(E1,set_type) => (member(E1,I) => member(E1,B))))))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [B] : (ilf_type(B,set_type) => (member(I,power_set(B)) <=> ! [E1] : (ilf_type(E1,set_type) => (member(E1,I) => member(E1,B)))))).
fof(myForms, conjecture, (ilf_type(B,set_type) => (member(I,power_set(B)) <=> ! [E1] : (ilf_type(E1,set_type) => (member(E1,I) => member(E1,B)))))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, (member(I,power_set(B)) <=> ! [E1] : (ilf_type(E1,set_type) => (member(E1,I) => member(E1,B))))).
fof(myForms, conjecture, member(I,power_set(B))).
fof(myForms, conjecture, ! [E1] : (ilf_type(E1,set_type) => (member(E1,I) => member(E1,B)))).
fof(myForms, conjecture, (ilf_type(E1,set_type) => (member(E1,I) => member(E1,B)))).
fof(myForms, conjecture, ilf_type(E1,set_type)).
fof(myForms, conjecture, (member(E1,I) => member(E1,B))).
fof(myForms, conjecture, member(E1,I)).
fof(myForms, conjecture, member(E1,B)).