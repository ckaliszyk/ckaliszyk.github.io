fof(myForms, conjecture, ! [F1] : ((equivalence(H1,I1) & subset(F1,I1)) => equivalence(H1,F1))).
fof(myForms, conjecture, ((equivalence(H1,I1) & subset(F1,I1)) => equivalence(H1,F1))).
fof(myForms, conjecture, (equivalence(H1,I1) & subset(F1,I1))).
fof(myForms, conjecture, equivalence(H1,I1)).
fof(myForms, conjecture, subset(F1,I1)).
fof(myForms, conjecture, equivalence(H1,F1)).