fof(myForms, conjecture, ! [E1] : (ilf_type(E1,relation_type(B,I)) => (subset(identity_relation_of(B),E1) => (domain(B,I,E1)=B & subset(B,range(B,I,E1)))))).
fof(myForms, conjecture, (ilf_type(E1,relation_type(B,I)) => (subset(identity_relation_of(B),E1) => (domain(B,I,E1)=B & subset(B,range(B,I,E1)))))).
fof(myForms, conjecture, ilf_type(E1,relation_type(B,I))).
fof(myForms, conjecture, (subset(identity_relation_of(B),E1) => (domain(B,I,E1)=B & subset(B,range(B,I,E1))))).
fof(myForms, conjecture, subset(identity_relation_of(B),E1)).
fof(myForms, conjecture, (domain(B,I,E1)=B & subset(B,range(B,I,E1)))).
fof(myForms, conjecture, domain(B,I,E1)=B).
fof(myForms, conjecture, subset(B,range(B,I,E1))).