fof(myForms, conjecture, (order(H1,I1) => ! [F1] : (subset(F1,I1) => ! [Q] : (greatest(Q,H1,F1) <=> (member(Q,F1) & least_upper_bound(Q,F1,H1,I1)))))).
fof(myForms, conjecture, order(H1,I1)).
fof(myForms, conjecture, ! [F1] : (subset(F1,I1) => ! [Q] : (greatest(Q,H1,F1) <=> (member(Q,F1) & least_upper_bound(Q,F1,H1,I1))))).
fof(myForms, conjecture, (subset(F1,I1) => ! [Q] : (greatest(Q,H1,F1) <=> (member(Q,F1) & least_upper_bound(Q,F1,H1,I1))))).
fof(myForms, conjecture, subset(F1,I1)).
fof(myForms, conjecture, ! [Q] : (greatest(Q,H1,F1) <=> (member(Q,F1) & least_upper_bound(Q,F1,H1,I1)))).
fof(myForms, conjecture, (greatest(Q,H1,F1) <=> (member(Q,F1) & least_upper_bound(Q,F1,H1,I1)))).
fof(myForms, conjecture, greatest(Q,H1,F1)).
fof(myForms, conjecture, (member(Q,F1) & least_upper_bound(Q,F1,H1,I1))).
fof(myForms, conjecture, member(Q,F1)).
fof(myForms, conjecture, least_upper_bound(Q,F1,H1,I1)).