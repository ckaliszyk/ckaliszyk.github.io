fof(myForms, conjecture, ! [F1] : ! [R] : ! [J1] : (((member(F1,universal_class) & member(R,universal_class)) & unordered_pair(F1,J1)=unordered_pair(R,J1)) => F1=R)).
fof(myForms, conjecture, ! [R] : ! [J1] : (((member(F1,universal_class) & member(R,universal_class)) & unordered_pair(F1,J1)=unordered_pair(R,J1)) => F1=R)).
fof(myForms, conjecture, ! [J1] : (((member(F1,universal_class) & member(R,universal_class)) & unordered_pair(F1,J1)=unordered_pair(R,J1)) => F1=R)).
fof(myForms, conjecture, (((member(F1,universal_class) & member(R,universal_class)) & unordered_pair(F1,J1)=unordered_pair(R,J1)) => F1=R)).
fof(myForms, conjecture, ((member(F1,universal_class) & member(R,universal_class)) & unordered_pair(F1,J1)=unordered_pair(R,J1))).
fof(myForms, conjecture, (member(F1,universal_class) & member(R,universal_class))).
fof(myForms, conjecture, member(F1,universal_class)).
fof(myForms, conjecture, member(R,universal_class)).
fof(myForms, conjecture, unordered_pair(F1,J1)=unordered_pair(R,J1)).
fof(myForms, conjecture, F1=R).