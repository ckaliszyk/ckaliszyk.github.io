fof(myForms, conjecture, ! [D] : ! [F] : disjoint(intersection(D,F),difference(D,F))).
fof(myForms, conjecture, ! [F] : disjoint(intersection(D,F),difference(D,F))).
fof(myForms, conjecture, disjoint(intersection(D,F),difference(D,F))).