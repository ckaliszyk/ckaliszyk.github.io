fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ! [F] : (ilf_type(F,binary_relation_type) => (subset(domain_of(F),D) => ilf_type(F,relation_type(D,range_of(F))))))).
fof(myForms, conjecture, (ilf_type(D,set_type) => ! [F] : (ilf_type(F,binary_relation_type) => (subset(domain_of(F),D) => ilf_type(F,relation_type(D,range_of(F))))))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, ! [F] : (ilf_type(F,binary_relation_type) => (subset(domain_of(F),D) => ilf_type(F,relation_type(D,range_of(F)))))).
fof(myForms, conjecture, (ilf_type(F,binary_relation_type) => (subset(domain_of(F),D) => ilf_type(F,relation_type(D,range_of(F)))))).
fof(myForms, conjecture, ilf_type(F,binary_relation_type)).
fof(myForms, conjecture, (subset(domain_of(F),D) => ilf_type(F,relation_type(D,range_of(F))))).
fof(myForms, conjecture, subset(domain_of(F),D)).
fof(myForms, conjecture, ilf_type(F,relation_type(D,range_of(F)))).