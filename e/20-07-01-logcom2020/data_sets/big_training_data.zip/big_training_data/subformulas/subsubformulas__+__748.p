fof(myForms, conjecture, ! [E1] : (intersection(B,E1)=I <=> ((subset(I,B) & subset(I,E1)) & ! [I1] : ((subset(I1,B) & subset(I1,E1)) => subset(I1,I))))).
fof(myForms, conjecture, (intersection(B,E1)=I <=> ((subset(I,B) & subset(I,E1)) & ! [I1] : ((subset(I1,B) & subset(I1,E1)) => subset(I1,I))))).
fof(myForms, conjecture, intersection(B,E1)=I).
fof(myForms, conjecture, ((subset(I,B) & subset(I,E1)) & ! [I1] : ((subset(I1,B) & subset(I1,E1)) => subset(I1,I)))).
fof(myForms, conjecture, (subset(I,B) & subset(I,E1))).
fof(myForms, conjecture, subset(I,B)).
fof(myForms, conjecture, subset(I,E1)).
fof(myForms, conjecture, ! [I1] : ((subset(I1,B) & subset(I1,E1)) => subset(I1,I))).
fof(myForms, conjecture, ((subset(I1,B) & subset(I1,E1)) => subset(I1,I))).
fof(myForms, conjecture, (subset(I1,B) & subset(I1,E1))).
fof(myForms, conjecture, subset(I1,B)).
fof(myForms, conjecture, subset(I1,E1)).
fof(myForms, conjecture, subset(I1,I)).