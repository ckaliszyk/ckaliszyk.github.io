fof(myForms, conjecture, ! [B] : ! [C] : ! [D] : ((maps(B,C,D) & one_to_one(B,C,D)) => identity(compose_function(B,inverse_function(B,C,D),D,C,D),D))).
fof(myForms, conjecture, ! [C] : ! [D] : ((maps(B,C,D) & one_to_one(B,C,D)) => identity(compose_function(B,inverse_function(B,C,D),D,C,D),D))).
fof(myForms, conjecture, ! [D] : ((maps(B,C,D) & one_to_one(B,C,D)) => identity(compose_function(B,inverse_function(B,C,D),D,C,D),D))).
fof(myForms, conjecture, ((maps(B,C,D) & one_to_one(B,C,D)) => identity(compose_function(B,inverse_function(B,C,D),D,C,D),D))).
fof(myForms, conjecture, (maps(B,C,D) & one_to_one(B,C,D))).
fof(myForms, conjecture, maps(B,C,D)).
fof(myForms, conjecture, one_to_one(B,C,D)).
fof(myForms, conjecture, identity(compose_function(B,inverse_function(B,C,D),D,C,D),D)).