fof(myForms, conjecture, ((((((maps(L1,F,I) & maps(M1,F,I)) & maps(J,I,F)) & identity(compose_function(J,L1,F,I,F),F)) & identity(compose_function(J,M1,F,I,F),F)) & equal_set(image3(L1,F,I),image3(M1,F,I))) => equal_maps(L1,M1,F,I))).
fof(myForms, conjecture, (((((maps(L1,F,I) & maps(M1,F,I)) & maps(J,I,F)) & identity(compose_function(J,L1,F,I,F),F)) & identity(compose_function(J,M1,F,I,F),F)) & equal_set(image3(L1,F,I),image3(M1,F,I)))).
fof(myForms, conjecture, ((((maps(L1,F,I) & maps(M1,F,I)) & maps(J,I,F)) & identity(compose_function(J,L1,F,I,F),F)) & identity(compose_function(J,M1,F,I,F),F))).
fof(myForms, conjecture, (((maps(L1,F,I) & maps(M1,F,I)) & maps(J,I,F)) & identity(compose_function(J,L1,F,I,F),F))).
fof(myForms, conjecture, ((maps(L1,F,I) & maps(M1,F,I)) & maps(J,I,F))).
fof(myForms, conjecture, (maps(L1,F,I) & maps(M1,F,I))).
fof(myForms, conjecture, maps(L1,F,I)).
fof(myForms, conjecture, maps(M1,F,I)).
fof(myForms, conjecture, maps(J,I,F)).
fof(myForms, conjecture, identity(compose_function(J,L1,F,I,F),F)).
fof(myForms, conjecture, identity(compose_function(J,M1,F,I,F),F)).
fof(myForms, conjecture, equal_set(image3(L1,F,I),image3(M1,F,I))).
fof(myForms, conjecture, equal_maps(L1,M1,F,I)).