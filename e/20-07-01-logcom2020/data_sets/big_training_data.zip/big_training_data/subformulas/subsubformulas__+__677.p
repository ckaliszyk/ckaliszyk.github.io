fof(myForms, conjecture, ! [I] : ! [B] : ! [E1] : ~ (((subset(F,cartesian_product2(I,B)) & in(E1,F)) & ! [I1] : ! [D] : ~ (((in(I1,I) & in(D,B)) & ordered_pair(I1,D)=E1))))).
fof(myForms, conjecture, ! [B] : ! [E1] : ~ (((subset(F,cartesian_product2(I,B)) & in(E1,F)) & ! [I1] : ! [D] : ~ (((in(I1,I) & in(D,B)) & ordered_pair(I1,D)=E1))))).
fof(myForms, conjecture, ! [E1] : ~ (((subset(F,cartesian_product2(I,B)) & in(E1,F)) & ! [I1] : ! [D] : ~ (((in(I1,I) & in(D,B)) & ordered_pair(I1,D)=E1))))).
fof(myForms, conjecture, ~ (((subset(F,cartesian_product2(I,B)) & in(E1,F)) & ! [I1] : ! [D] : ~ (((in(I1,I) & in(D,B)) & ordered_pair(I1,D)=E1))))).
fof(myForms, conjecture, ((subset(F,cartesian_product2(I,B)) & in(E1,F)) & ! [I1] : ! [D] : ~ (((in(I1,I) & in(D,B)) & ordered_pair(I1,D)=E1)))).
fof(myForms, conjecture, (subset(F,cartesian_product2(I,B)) & in(E1,F))).
fof(myForms, conjecture, subset(F,cartesian_product2(I,B))).
fof(myForms, conjecture, in(E1,F)).
fof(myForms, conjecture, ! [I1] : ! [D] : ~ (((in(I1,I) & in(D,B)) & ordered_pair(I1,D)=E1))).
fof(myForms, conjecture, ! [D] : ~ (((in(I1,I) & in(D,B)) & ordered_pair(I1,D)=E1))).
fof(myForms, conjecture, ~ (((in(I1,I) & in(D,B)) & ordered_pair(I1,D)=E1))).
fof(myForms, conjecture, ((in(I1,I) & in(D,B)) & ordered_pair(I1,D)=E1)).
fof(myForms, conjecture, (in(I1,I) & in(D,B))).
fof(myForms, conjecture, in(I1,I)).
fof(myForms, conjecture, in(D,B)).
fof(myForms, conjecture, ordered_pair(I1,D)=E1).