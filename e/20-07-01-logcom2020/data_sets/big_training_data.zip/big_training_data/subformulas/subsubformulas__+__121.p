fof(myForms, conjecture, ((maps(D,F,I) & maps(J,I,B)) & maps(L,B,E1))).
fof(myForms, conjecture, (maps(D,F,I) & maps(J,I,B))).
fof(myForms, conjecture, maps(D,F,I)).
fof(myForms, conjecture, maps(J,I,B)).
fof(myForms, conjecture, maps(L,B,E1)).