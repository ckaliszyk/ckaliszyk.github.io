fof(myForms, conjecture, ! [C] : ! [D] : ((subset(C,cartesian_product2(C,D)) | subset(C,cartesian_product2(D,C))) => empty_set=C)).
fof(myForms, conjecture, ! [D] : ((subset(C,cartesian_product2(C,D)) | subset(C,cartesian_product2(D,C))) => empty_set=C)).
fof(myForms, conjecture, ((subset(C,cartesian_product2(C,D)) | subset(C,cartesian_product2(D,C))) => empty_set=C)).
fof(myForms, conjecture, (subset(C,cartesian_product2(C,D)) | subset(C,cartesian_product2(D,C)))).
fof(myForms, conjecture, subset(C,cartesian_product2(C,D))).
fof(myForms, conjecture, subset(C,cartesian_product2(D,C))).
fof(myForms, conjecture, empty_set=C).