fof(myForms, conjecture, ! [J] : ! [F] : ! [I] : ! [B] : ! [H1] : ! [P] : ! [K] : ((((maps(D,F,I) & maps(J,I,B)) & increasing(D,F,H1,I,P)) & increasing(J,I,P,B,K)) => increasing(compose_function(J,D,F,I,B),F,H1,B,K))).
fof(myForms, conjecture, ! [F] : ! [I] : ! [B] : ! [H1] : ! [P] : ! [K] : ((((maps(D,F,I) & maps(J,I,B)) & increasing(D,F,H1,I,P)) & increasing(J,I,P,B,K)) => increasing(compose_function(J,D,F,I,B),F,H1,B,K))).
fof(myForms, conjecture, ! [I] : ! [B] : ! [H1] : ! [P] : ! [K] : ((((maps(D,F,I) & maps(J,I,B)) & increasing(D,F,H1,I,P)) & increasing(J,I,P,B,K)) => increasing(compose_function(J,D,F,I,B),F,H1,B,K))).
fof(myForms, conjecture, ! [B] : ! [H1] : ! [P] : ! [K] : ((((maps(D,F,I) & maps(J,I,B)) & increasing(D,F,H1,I,P)) & increasing(J,I,P,B,K)) => increasing(compose_function(J,D,F,I,B),F,H1,B,K))).
fof(myForms, conjecture, ! [H1] : ! [P] : ! [K] : ((((maps(D,F,I) & maps(J,I,B)) & increasing(D,F,H1,I,P)) & increasing(J,I,P,B,K)) => increasing(compose_function(J,D,F,I,B),F,H1,B,K))).
fof(myForms, conjecture, ! [P] : ! [K] : ((((maps(D,F,I) & maps(J,I,B)) & increasing(D,F,H1,I,P)) & increasing(J,I,P,B,K)) => increasing(compose_function(J,D,F,I,B),F,H1,B,K))).
fof(myForms, conjecture, ! [K] : ((((maps(D,F,I) & maps(J,I,B)) & increasing(D,F,H1,I,P)) & increasing(J,I,P,B,K)) => increasing(compose_function(J,D,F,I,B),F,H1,B,K))).
fof(myForms, conjecture, ((((maps(D,F,I) & maps(J,I,B)) & increasing(D,F,H1,I,P)) & increasing(J,I,P,B,K)) => increasing(compose_function(J,D,F,I,B),F,H1,B,K))).
fof(myForms, conjecture, (((maps(D,F,I) & maps(J,I,B)) & increasing(D,F,H1,I,P)) & increasing(J,I,P,B,K))).
fof(myForms, conjecture, ((maps(D,F,I) & maps(J,I,B)) & increasing(D,F,H1,I,P))).
fof(myForms, conjecture, (maps(D,F,I) & maps(J,I,B))).
fof(myForms, conjecture, maps(D,F,I)).
fof(myForms, conjecture, maps(J,I,B)).
fof(myForms, conjecture, increasing(D,F,H1,I,P)).
fof(myForms, conjecture, increasing(J,I,P,B,K)).
fof(myForms, conjecture, increasing(compose_function(J,D,F,I,B),F,H1,B,K)).