fof(myForms, conjecture, ! [I] : union(I,empty_set)=I).
fof(myForms, conjecture, union(I,empty_set)=I).