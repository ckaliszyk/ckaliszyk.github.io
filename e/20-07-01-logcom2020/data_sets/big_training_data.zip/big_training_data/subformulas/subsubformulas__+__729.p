fof(myForms, conjecture, ! [E1] : (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,relation_type(B,I)) => (subset(B,E1) => restrict4(B,I,I1,E1)=I1)))).
fof(myForms, conjecture, (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,relation_type(B,I)) => (subset(B,E1) => restrict4(B,I,I1,E1)=I1)))).
fof(myForms, conjecture, ilf_type(E1,set_type)).
fof(myForms, conjecture, ! [I1] : (ilf_type(I1,relation_type(B,I)) => (subset(B,E1) => restrict4(B,I,I1,E1)=I1))).
fof(myForms, conjecture, (ilf_type(I1,relation_type(B,I)) => (subset(B,E1) => restrict4(B,I,I1,E1)=I1))).
fof(myForms, conjecture, ilf_type(I1,relation_type(B,I))).
fof(myForms, conjecture, (subset(B,E1) => restrict4(B,I,I1,E1)=I1)).
fof(myForms, conjecture, subset(B,E1)).
fof(myForms, conjecture, restrict4(B,I,I1,E1)=I1).