fof(myForms, conjecture, ! [I] : (ilf_type(I,set_type) => ! [B] : (ilf_type(B,set_type) => ! [E1] : (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,set_type) => (member(ordered_pair(I,B),cross_product(E1,I1)) <=> (member(I,E1) & member(B,I1)))))))).
fof(myForms, conjecture, (ilf_type(I,set_type) => ! [B] : (ilf_type(B,set_type) => ! [E1] : (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,set_type) => (member(ordered_pair(I,B),cross_product(E1,I1)) <=> (member(I,E1) & member(B,I1)))))))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [B] : (ilf_type(B,set_type) => ! [E1] : (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,set_type) => (member(ordered_pair(I,B),cross_product(E1,I1)) <=> (member(I,E1) & member(B,I1))))))).
fof(myForms, conjecture, (ilf_type(B,set_type) => ! [E1] : (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,set_type) => (member(ordered_pair(I,B),cross_product(E1,I1)) <=> (member(I,E1) & member(B,I1))))))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ! [E1] : (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,set_type) => (member(ordered_pair(I,B),cross_product(E1,I1)) <=> (member(I,E1) & member(B,I1)))))).
fof(myForms, conjecture, (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,set_type) => (member(ordered_pair(I,B),cross_product(E1,I1)) <=> (member(I,E1) & member(B,I1)))))).
fof(myForms, conjecture, ilf_type(E1,set_type)).
fof(myForms, conjecture, ! [I1] : (ilf_type(I1,set_type) => (member(ordered_pair(I,B),cross_product(E1,I1)) <=> (member(I,E1) & member(B,I1))))).
fof(myForms, conjecture, (ilf_type(I1,set_type) => (member(ordered_pair(I,B),cross_product(E1,I1)) <=> (member(I,E1) & member(B,I1))))).
fof(myForms, conjecture, ilf_type(I1,set_type)).
fof(myForms, conjecture, (member(ordered_pair(I,B),cross_product(E1,I1)) <=> (member(I,E1) & member(B,I1)))).
fof(myForms, conjecture, member(ordered_pair(I,B),cross_product(E1,I1))).
fof(myForms, conjecture, (member(I,E1) & member(B,I1))).
fof(myForms, conjecture, member(I,E1)).
fof(myForms, conjecture, member(B,I1)).