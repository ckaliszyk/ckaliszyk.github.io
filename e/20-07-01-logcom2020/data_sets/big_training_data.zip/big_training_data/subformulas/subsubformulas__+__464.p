fof(myForms, conjecture, ! [I] : ! [B] : ~ (((subset(singleton(F),unordered_pair(I,B)) & ~ I=F) & ~ F=B))).
fof(myForms, conjecture, ! [B] : ~ (((subset(singleton(F),unordered_pair(I,B)) & ~ I=F) & ~ F=B))).
fof(myForms, conjecture, ~ (((subset(singleton(F),unordered_pair(I,B)) & ~ I=F) & ~ F=B))).
fof(myForms, conjecture, ((subset(singleton(F),unordered_pair(I,B)) & ~ I=F) & ~ F=B)).
fof(myForms, conjecture, (subset(singleton(F),unordered_pair(I,B)) & ~ I=F)).
fof(myForms, conjecture, subset(singleton(F),unordered_pair(I,B))).
fof(myForms, conjecture, ~ I=F).
fof(myForms, conjecture, I=F).
fof(myForms, conjecture, ~ F=B).
fof(myForms, conjecture, F=B).