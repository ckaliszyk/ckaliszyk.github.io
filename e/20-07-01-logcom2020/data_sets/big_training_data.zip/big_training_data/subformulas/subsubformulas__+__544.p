fof(myForms, conjecture, ! [I] : union(unordered_pair(singleton(F),singleton(I)))=unordered_pair(F,I)).
fof(myForms, conjecture, union(unordered_pair(singleton(F),singleton(I)))=unordered_pair(F,I)).