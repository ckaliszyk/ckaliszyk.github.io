fof(myForms, conjecture, ((ordered_pair(K1,F1)=ordered_pair(R,J1) & member(K1,universal_class)) => K1=R)).
fof(myForms, conjecture, (ordered_pair(K1,F1)=ordered_pair(R,J1) & member(K1,universal_class))).
fof(myForms, conjecture, ordered_pair(K1,F1)=ordered_pair(R,J1)).
fof(myForms, conjecture, member(K1,universal_class)).
fof(myForms, conjecture, K1=R).