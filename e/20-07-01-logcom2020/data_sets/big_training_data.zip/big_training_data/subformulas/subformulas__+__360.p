fof(myForms, conjecture, ! [J] : ! [O] : ! [C] : ((equivalence(O,J) & member(C,J)) => member(C,equivalence_class(C,J,O)))).
fof(myForms, conjecture, ! [O] : ! [C] : ((equivalence(O,J) & member(C,J)) => member(C,equivalence_class(C,J,O)))).
fof(myForms, conjecture, ! [C] : ((equivalence(O,J) & member(C,J)) => member(C,equivalence_class(C,J,O)))).
fof(myForms, conjecture, ((equivalence(O,J) & member(C,J)) => member(C,equivalence_class(C,J,O)))).
fof(myForms, conjecture, (equivalence(O,J) & member(C,J))).
fof(myForms, conjecture, equivalence(O,J)).
fof(myForms, conjecture, member(C,J)).
fof(myForms, conjecture, member(C,equivalence_class(C,J,O))).