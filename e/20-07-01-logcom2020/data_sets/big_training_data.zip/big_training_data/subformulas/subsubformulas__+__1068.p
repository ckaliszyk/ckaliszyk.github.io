fof(myForms, conjecture, ! [I] : ! [B] : ((((maps(D,F,I) & subset(B,I)) & image2(D,F)=B) & ! [F1] : ! [R] : ((member(F1,F) & member(R,B)) => (apply(J,F1,R) <=> apply(D,F1,R)))) => surjective(J,F,B))).
fof(myForms, conjecture, ! [B] : ((((maps(D,F,I) & subset(B,I)) & image2(D,F)=B) & ! [F1] : ! [R] : ((member(F1,F) & member(R,B)) => (apply(J,F1,R) <=> apply(D,F1,R)))) => surjective(J,F,B))).
fof(myForms, conjecture, ((((maps(D,F,I) & subset(B,I)) & image2(D,F)=B) & ! [F1] : ! [R] : ((member(F1,F) & member(R,B)) => (apply(J,F1,R) <=> apply(D,F1,R)))) => surjective(J,F,B))).
fof(myForms, conjecture, (((maps(D,F,I) & subset(B,I)) & image2(D,F)=B) & ! [F1] : ! [R] : ((member(F1,F) & member(R,B)) => (apply(J,F1,R) <=> apply(D,F1,R))))).
fof(myForms, conjecture, ((maps(D,F,I) & subset(B,I)) & image2(D,F)=B)).
fof(myForms, conjecture, (maps(D,F,I) & subset(B,I))).
fof(myForms, conjecture, maps(D,F,I)).
fof(myForms, conjecture, subset(B,I)).
fof(myForms, conjecture, image2(D,F)=B).
fof(myForms, conjecture, ! [F1] : ! [R] : ((member(F1,F) & member(R,B)) => (apply(J,F1,R) <=> apply(D,F1,R)))).
fof(myForms, conjecture, ! [R] : ((member(F1,F) & member(R,B)) => (apply(J,F1,R) <=> apply(D,F1,R)))).
fof(myForms, conjecture, ((member(F1,F) & member(R,B)) => (apply(J,F1,R) <=> apply(D,F1,R)))).
fof(myForms, conjecture, (member(F1,F) & member(R,B))).
fof(myForms, conjecture, member(F1,F)).
fof(myForms, conjecture, member(R,B)).
fof(myForms, conjecture, (apply(J,F1,R) <=> apply(D,F1,R))).
fof(myForms, conjecture, apply(J,F1,R)).
fof(myForms, conjecture, apply(D,F1,R)).
fof(myForms, conjecture, surjective(J,F,B)).