fof(myForms, conjecture, (ilf_type(I,set_type) => ! [B] : (ilf_type(B,set_type) => (not_equal(I,B) <=> ~ I=B)))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [B] : (ilf_type(B,set_type) => (not_equal(I,B) <=> ~ I=B))).
fof(myForms, conjecture, (ilf_type(B,set_type) => (not_equal(I,B) <=> ~ I=B))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, (not_equal(I,B) <=> ~ I=B)).
fof(myForms, conjecture, not_equal(I,B)).
fof(myForms, conjecture, ~ I=B).
fof(myForms, conjecture, I=B).