fof(myForms, conjecture, ! [F] : ! [I] : (((equivalence(H1,I1) & member(F,I1)) & member(I,I1)) => (equal_set(equivalence_class(F,I1,H1),equivalence_class(I,I1,H1)) <=> apply(H1,F,I)))).
fof(myForms, conjecture, ! [I] : (((equivalence(H1,I1) & member(F,I1)) & member(I,I1)) => (equal_set(equivalence_class(F,I1,H1),equivalence_class(I,I1,H1)) <=> apply(H1,F,I)))).
fof(myForms, conjecture, (((equivalence(H1,I1) & member(F,I1)) & member(I,I1)) => (equal_set(equivalence_class(F,I1,H1),equivalence_class(I,I1,H1)) <=> apply(H1,F,I)))).
fof(myForms, conjecture, ((equivalence(H1,I1) & member(F,I1)) & member(I,I1))).
fof(myForms, conjecture, (equivalence(H1,I1) & member(F,I1))).
fof(myForms, conjecture, equivalence(H1,I1)).
fof(myForms, conjecture, member(F,I1)).
fof(myForms, conjecture, member(I,I1)).
fof(myForms, conjecture, (equal_set(equivalence_class(F,I1,H1),equivalence_class(I,I1,H1)) <=> apply(H1,F,I))).
fof(myForms, conjecture, equal_set(equivalence_class(F,I1,H1),equivalence_class(I,I1,H1))).
fof(myForms, conjecture, apply(H1,F,I)).