fof(myForms, conjecture, ! [I1] : (in(ordered_pair(E1,I1),B) <=> ? [D] : (in(ordered_pair(E1,D),F) & in(ordered_pair(D,I1),I)))).
fof(myForms, conjecture, (in(ordered_pair(E1,I1),B) <=> ? [D] : (in(ordered_pair(E1,D),F) & in(ordered_pair(D,I1),I)))).
fof(myForms, conjecture, in(ordered_pair(E1,I1),B)).
fof(myForms, conjecture, ? [D] : (in(ordered_pair(E1,D),F) & in(ordered_pair(D,I1),I))).
fof(myForms, conjecture, (in(ordered_pair(E1,D),F) & in(ordered_pair(D,I1),I))).
fof(myForms, conjecture, in(ordered_pair(E1,D),F)).
fof(myForms, conjecture, in(ordered_pair(D,I1),I)).