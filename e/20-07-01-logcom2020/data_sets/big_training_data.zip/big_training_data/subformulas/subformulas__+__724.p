fof(myForms, conjecture, ! [C] : equal_set(union(C,C),C)).
fof(myForms, conjecture, equal_set(union(C,C),C)).