fof(myForms, conjecture, ~ empty(relation_dom(F))).
fof(myForms, conjecture, empty(relation_dom(F))).