fof(myForms, conjecture, ! [D] : (in(ordered_pair(I1,D),cartesian_product2(F,I)) <=> in(ordered_pair(I1,D),cartesian_product2(B,E1)))).
fof(myForms, conjecture, (in(ordered_pair(I1,D),cartesian_product2(F,I)) <=> in(ordered_pair(I1,D),cartesian_product2(B,E1)))).
fof(myForms, conjecture, in(ordered_pair(I1,D),cartesian_product2(F,I))).
fof(myForms, conjecture, in(ordered_pair(I1,D),cartesian_product2(B,E1))).