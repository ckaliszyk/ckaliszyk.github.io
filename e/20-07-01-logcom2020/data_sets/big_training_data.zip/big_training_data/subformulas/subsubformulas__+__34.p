fof(myForms, conjecture, ! [I] : (ilf_type(I,set_type) => ! [B] : (ilf_type(B,set_type) => ! [E1] : (ilf_type(E1,relation_type(I,B)) => ! [I1] : (ilf_type(I1,set_type) => ilf_type(inverse4(I,B,E1,I1),subset_type(I))))))).
fof(myForms, conjecture, (ilf_type(I,set_type) => ! [B] : (ilf_type(B,set_type) => ! [E1] : (ilf_type(E1,relation_type(I,B)) => ! [I1] : (ilf_type(I1,set_type) => ilf_type(inverse4(I,B,E1,I1),subset_type(I))))))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [B] : (ilf_type(B,set_type) => ! [E1] : (ilf_type(E1,relation_type(I,B)) => ! [I1] : (ilf_type(I1,set_type) => ilf_type(inverse4(I,B,E1,I1),subset_type(I)))))).
fof(myForms, conjecture, (ilf_type(B,set_type) => ! [E1] : (ilf_type(E1,relation_type(I,B)) => ! [I1] : (ilf_type(I1,set_type) => ilf_type(inverse4(I,B,E1,I1),subset_type(I)))))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ! [E1] : (ilf_type(E1,relation_type(I,B)) => ! [I1] : (ilf_type(I1,set_type) => ilf_type(inverse4(I,B,E1,I1),subset_type(I))))).
fof(myForms, conjecture, (ilf_type(E1,relation_type(I,B)) => ! [I1] : (ilf_type(I1,set_type) => ilf_type(inverse4(I,B,E1,I1),subset_type(I))))).
fof(myForms, conjecture, ilf_type(E1,relation_type(I,B))).
fof(myForms, conjecture, ! [I1] : (ilf_type(I1,set_type) => ilf_type(inverse4(I,B,E1,I1),subset_type(I)))).
fof(myForms, conjecture, (ilf_type(I1,set_type) => ilf_type(inverse4(I,B,E1,I1),subset_type(I)))).
fof(myForms, conjecture, ilf_type(I1,set_type)).
fof(myForms, conjecture, ilf_type(inverse4(I,B,E1,I1),subset_type(I))).