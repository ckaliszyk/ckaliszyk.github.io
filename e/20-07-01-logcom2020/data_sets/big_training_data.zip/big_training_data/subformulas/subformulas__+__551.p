fof(myForms, conjecture, ! [D] : ((~ empty(D) & ilf_type(D,set_type)) => ! [F] : ((~ empty(F) & ilf_type(F,set_type)) => ! [I] : ((~ empty(I) & ilf_type(I,set_type)) => ! [J] : (ilf_type(J,relation_type(I,D)) => ! [B] : (ilf_type(B,member_type(D)) => (member(B,image4(I,D,J,F)) <=> ? [E] : ((ilf_type(E,member_type(I)) & member(ordered_pair(E,B),J)) & member(E,F))))))))).
fof(myForms, conjecture, ((~ empty(D) & ilf_type(D,set_type)) => ! [F] : ((~ empty(F) & ilf_type(F,set_type)) => ! [I] : ((~ empty(I) & ilf_type(I,set_type)) => ! [J] : (ilf_type(J,relation_type(I,D)) => ! [B] : (ilf_type(B,member_type(D)) => (member(B,image4(I,D,J,F)) <=> ? [E] : ((ilf_type(E,member_type(I)) & member(ordered_pair(E,B),J)) & member(E,F))))))))).
fof(myForms, conjecture, (~ empty(D) & ilf_type(D,set_type))).
fof(myForms, conjecture, ~ empty(D)).
fof(myForms, conjecture, empty(D)).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, ! [F] : ((~ empty(F) & ilf_type(F,set_type)) => ! [I] : ((~ empty(I) & ilf_type(I,set_type)) => ! [J] : (ilf_type(J,relation_type(I,D)) => ! [B] : (ilf_type(B,member_type(D)) => (member(B,image4(I,D,J,F)) <=> ? [E] : ((ilf_type(E,member_type(I)) & member(ordered_pair(E,B),J)) & member(E,F)))))))).
fof(myForms, conjecture, ((~ empty(F) & ilf_type(F,set_type)) => ! [I] : ((~ empty(I) & ilf_type(I,set_type)) => ! [J] : (ilf_type(J,relation_type(I,D)) => ! [B] : (ilf_type(B,member_type(D)) => (member(B,image4(I,D,J,F)) <=> ? [E] : ((ilf_type(E,member_type(I)) & member(ordered_pair(E,B),J)) & member(E,F)))))))).
fof(myForms, conjecture, (~ empty(F) & ilf_type(F,set_type))).
fof(myForms, conjecture, ~ empty(F)).
fof(myForms, conjecture, empty(F)).
fof(myForms, conjecture, ilf_type(F,set_type)).
fof(myForms, conjecture, ! [I] : ((~ empty(I) & ilf_type(I,set_type)) => ! [J] : (ilf_type(J,relation_type(I,D)) => ! [B] : (ilf_type(B,member_type(D)) => (member(B,image4(I,D,J,F)) <=> ? [E] : ((ilf_type(E,member_type(I)) & member(ordered_pair(E,B),J)) & member(E,F))))))).
fof(myForms, conjecture, ((~ empty(I) & ilf_type(I,set_type)) => ! [J] : (ilf_type(J,relation_type(I,D)) => ! [B] : (ilf_type(B,member_type(D)) => (member(B,image4(I,D,J,F)) <=> ? [E] : ((ilf_type(E,member_type(I)) & member(ordered_pair(E,B),J)) & member(E,F))))))).
fof(myForms, conjecture, (~ empty(I) & ilf_type(I,set_type))).
fof(myForms, conjecture, ~ empty(I)).
fof(myForms, conjecture, empty(I)).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [J] : (ilf_type(J,relation_type(I,D)) => ! [B] : (ilf_type(B,member_type(D)) => (member(B,image4(I,D,J,F)) <=> ? [E] : ((ilf_type(E,member_type(I)) & member(ordered_pair(E,B),J)) & member(E,F)))))).
fof(myForms, conjecture, (ilf_type(J,relation_type(I,D)) => ! [B] : (ilf_type(B,member_type(D)) => (member(B,image4(I,D,J,F)) <=> ? [E] : ((ilf_type(E,member_type(I)) & member(ordered_pair(E,B),J)) & member(E,F)))))).
fof(myForms, conjecture, ilf_type(J,relation_type(I,D))).
fof(myForms, conjecture, ! [B] : (ilf_type(B,member_type(D)) => (member(B,image4(I,D,J,F)) <=> ? [E] : ((ilf_type(E,member_type(I)) & member(ordered_pair(E,B),J)) & member(E,F))))).
fof(myForms, conjecture, (ilf_type(B,member_type(D)) => (member(B,image4(I,D,J,F)) <=> ? [E] : ((ilf_type(E,member_type(I)) & member(ordered_pair(E,B),J)) & member(E,F))))).
fof(myForms, conjecture, ilf_type(B,member_type(D))).
fof(myForms, conjecture, (member(B,image4(I,D,J,F)) <=> ? [E] : ((ilf_type(E,member_type(I)) & member(ordered_pair(E,B),J)) & member(E,F)))).
fof(myForms, conjecture, member(B,image4(I,D,J,F))).
fof(myForms, conjecture, ? [E] : ((ilf_type(E,member_type(I)) & member(ordered_pair(E,B),J)) & member(E,F))).
fof(myForms, conjecture, ((ilf_type(E,member_type(I)) & member(ordered_pair(E,B),J)) & member(E,F))).
fof(myForms, conjecture, (ilf_type(E,member_type(I)) & member(ordered_pair(E,B),J))).
fof(myForms, conjecture, ilf_type(E,member_type(I))).
fof(myForms, conjecture, member(ordered_pair(E,B),J)).
fof(myForms, conjecture, member(E,F)).