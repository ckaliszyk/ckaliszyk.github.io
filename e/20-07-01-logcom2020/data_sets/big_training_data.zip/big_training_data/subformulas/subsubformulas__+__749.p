fof(myForms, conjecture, ! [I] : ((relation(I) & function(I)) => ! [B] : ((relation(B) & function(B)) => ((relation_dom(I)=F & relation_dom(B)=F) => I=B)))).
fof(myForms, conjecture, ((relation(I) & function(I)) => ! [B] : ((relation(B) & function(B)) => ((relation_dom(I)=F & relation_dom(B)=F) => I=B)))).
fof(myForms, conjecture, (relation(I) & function(I))).
fof(myForms, conjecture, relation(I)).
fof(myForms, conjecture, function(I)).
fof(myForms, conjecture, ! [B] : ((relation(B) & function(B)) => ((relation_dom(I)=F & relation_dom(B)=F) => I=B))).
fof(myForms, conjecture, ((relation(B) & function(B)) => ((relation_dom(I)=F & relation_dom(B)=F) => I=B))).
fof(myForms, conjecture, (relation(B) & function(B))).
fof(myForms, conjecture, relation(B)).
fof(myForms, conjecture, function(B)).
fof(myForms, conjecture, ((relation_dom(I)=F & relation_dom(B)=F) => I=B)).
fof(myForms, conjecture, (relation_dom(I)=F & relation_dom(B)=F)).
fof(myForms, conjecture, relation_dom(I)=F).
fof(myForms, conjecture, relation_dom(B)=F).
fof(myForms, conjecture, I=B).