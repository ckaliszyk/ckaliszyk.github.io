fof(myForms, conjecture, ! [D] : ! [F] : ! [I] : (intersect(D,union(F,I)) <=> (intersect(D,F) | intersect(D,I)))).
fof(myForms, conjecture, ! [F] : ! [I] : (intersect(D,union(F,I)) <=> (intersect(D,F) | intersect(D,I)))).
fof(myForms, conjecture, ! [I] : (intersect(D,union(F,I)) <=> (intersect(D,F) | intersect(D,I)))).
fof(myForms, conjecture, (intersect(D,union(F,I)) <=> (intersect(D,F) | intersect(D,I)))).
fof(myForms, conjecture, intersect(D,union(F,I))).
fof(myForms, conjecture, (intersect(D,F) | intersect(D,I))).
fof(myForms, conjecture, intersect(D,F)).
fof(myForms, conjecture, intersect(D,I)).