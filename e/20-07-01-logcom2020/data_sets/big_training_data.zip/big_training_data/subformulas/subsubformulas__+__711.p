fof(myForms, conjecture, ! [F1] : (((member(W,universal_class) & member(G1,universal_class)) & ordered_pair(W,G1)=F1) => (first(F1)=W & second(F1)=G1))).
fof(myForms, conjecture, (((member(W,universal_class) & member(G1,universal_class)) & ordered_pair(W,G1)=F1) => (first(F1)=W & second(F1)=G1))).
fof(myForms, conjecture, ((member(W,universal_class) & member(G1,universal_class)) & ordered_pair(W,G1)=F1)).
fof(myForms, conjecture, (member(W,universal_class) & member(G1,universal_class))).
fof(myForms, conjecture, member(W,universal_class)).
fof(myForms, conjecture, member(G1,universal_class)).
fof(myForms, conjecture, ordered_pair(W,G1)=F1).
fof(myForms, conjecture, (first(F1)=W & second(F1)=G1)).
fof(myForms, conjecture, first(F1)=W).
fof(myForms, conjecture, second(F1)=G1).