fof(myForms, conjecture, (ilf_type(B,set_type) => ! [E1] : (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,relation_type(B,E1)) => (subset(I,I1) => subset(I,cross_product(B,E1))))))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ! [E1] : (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,relation_type(B,E1)) => (subset(I,I1) => subset(I,cross_product(B,E1)))))).
fof(myForms, conjecture, (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,relation_type(B,E1)) => (subset(I,I1) => subset(I,cross_product(B,E1)))))).
fof(myForms, conjecture, ilf_type(E1,set_type)).
fof(myForms, conjecture, ! [I1] : (ilf_type(I1,relation_type(B,E1)) => (subset(I,I1) => subset(I,cross_product(B,E1))))).
fof(myForms, conjecture, (ilf_type(I1,relation_type(B,E1)) => (subset(I,I1) => subset(I,cross_product(B,E1))))).
fof(myForms, conjecture, ilf_type(I1,relation_type(B,E1))).
fof(myForms, conjecture, (subset(I,I1) => subset(I,cross_product(B,E1)))).
fof(myForms, conjecture, subset(I,I1)).
fof(myForms, conjecture, subset(I,cross_product(B,E1))).