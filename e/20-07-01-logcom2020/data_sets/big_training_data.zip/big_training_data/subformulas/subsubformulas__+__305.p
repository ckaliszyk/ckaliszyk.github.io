fof(myForms, conjecture, ! [B] : (((maps(D,F,I) & maps(J,I,B)) & injective(compose_function(J,D,F,I,B),F,B)) => injective(D,F,I))).
fof(myForms, conjecture, (((maps(D,F,I) & maps(J,I,B)) & injective(compose_function(J,D,F,I,B),F,B)) => injective(D,F,I))).
fof(myForms, conjecture, ((maps(D,F,I) & maps(J,I,B)) & injective(compose_function(J,D,F,I,B),F,B))).
fof(myForms, conjecture, (maps(D,F,I) & maps(J,I,B))).
fof(myForms, conjecture, maps(D,F,I)).
fof(myForms, conjecture, maps(J,I,B)).
fof(myForms, conjecture, injective(compose_function(J,D,F,I,B),F,B)).
fof(myForms, conjecture, injective(D,F,I)).