fof(myForms, conjecture, ! [F] : ((equivalence(H1,I1) & member(F,I1)) => member(F,equivalence_class(F,I1,H1)))).
fof(myForms, conjecture, ((equivalence(H1,I1) & member(F,I1)) => member(F,equivalence_class(F,I1,H1)))).
fof(myForms, conjecture, (equivalence(H1,I1) & member(F,I1))).
fof(myForms, conjecture, equivalence(H1,I1)).
fof(myForms, conjecture, member(F,I1)).
fof(myForms, conjecture, member(F,equivalence_class(F,I1,H1))).