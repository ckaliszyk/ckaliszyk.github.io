fof(myForms, conjecture, (ilf_type(I,binary_relation_type) => ! [B] : (ilf_type(B,binary_relation_type) => (I=B => I=B)))).
fof(myForms, conjecture, ilf_type(I,binary_relation_type)).
fof(myForms, conjecture, ! [B] : (ilf_type(B,binary_relation_type) => (I=B => I=B))).
fof(myForms, conjecture, (ilf_type(B,binary_relation_type) => (I=B => I=B))).
fof(myForms, conjecture, ilf_type(B,binary_relation_type)).
fof(myForms, conjecture, (I=B => I=B)).
fof(myForms, conjecture, I=B).
fof(myForms, conjecture, I=B).