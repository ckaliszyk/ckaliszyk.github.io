fof(myForms, conjecture, ! [W] : ! [G1] : (equal_set(unordered_pair(singleton(F),unordered_pair(F,I)),unordered_pair(singleton(W),unordered_pair(W,G1))) => G1=I)).
fof(myForms, conjecture, ! [G1] : (equal_set(unordered_pair(singleton(F),unordered_pair(F,I)),unordered_pair(singleton(W),unordered_pair(W,G1))) => G1=I)).
fof(myForms, conjecture, (equal_set(unordered_pair(singleton(F),unordered_pair(F,I)),unordered_pair(singleton(W),unordered_pair(W,G1))) => G1=I)).
fof(myForms, conjecture, equal_set(unordered_pair(singleton(F),unordered_pair(F,I)),unordered_pair(singleton(W),unordered_pair(W,G1)))).
fof(myForms, conjecture, G1=I).