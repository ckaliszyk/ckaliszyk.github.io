fof(myForms, conjecture, ! [F] : ! [I] : subset(singleton(F),unordered_pair(F,I))).
fof(myForms, conjecture, ! [I] : subset(singleton(F),unordered_pair(F,I))).
fof(myForms, conjecture, subset(singleton(F),unordered_pair(F,I))).