fof(myForms, conjecture, ! [D] : ! [F] : ((subset(D,F) & intersection(F,D)=empty_set) => empty_set=D)).
fof(myForms, conjecture, ! [F] : ((subset(D,F) & intersection(F,D)=empty_set) => empty_set=D)).
fof(myForms, conjecture, ((subset(D,F) & intersection(F,D)=empty_set) => empty_set=D)).
fof(myForms, conjecture, (subset(D,F) & intersection(F,D)=empty_set)).
fof(myForms, conjecture, subset(D,F)).
fof(myForms, conjecture, intersection(F,D)=empty_set).
fof(myForms, conjecture, empty_set=D).