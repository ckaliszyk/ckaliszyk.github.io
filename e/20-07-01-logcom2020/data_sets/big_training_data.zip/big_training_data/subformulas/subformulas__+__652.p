fof(myForms, conjecture, ~ (? [P] : ! [L] : (element(L,P) <=> ~ (? [K] : (element(L,K) & element(K,L)))))).
fof(myForms, conjecture, ? [P] : ! [L] : (element(L,P) <=> ~ (? [K] : (element(L,K) & element(K,L))))).
fof(myForms, conjecture, ! [L] : (element(L,P) <=> ~ (? [K] : (element(L,K) & element(K,L))))).
fof(myForms, conjecture, (element(L,P) <=> ~ (? [K] : (element(L,K) & element(K,L))))).
fof(myForms, conjecture, element(L,P)).
fof(myForms, conjecture, ~ (? [K] : (element(L,K) & element(K,L)))).
fof(myForms, conjecture, ? [K] : (element(L,K) & element(K,L))).
fof(myForms, conjecture, (element(L,K) & element(K,L))).
fof(myForms, conjecture, element(L,K)).
fof(myForms, conjecture, element(K,L)).