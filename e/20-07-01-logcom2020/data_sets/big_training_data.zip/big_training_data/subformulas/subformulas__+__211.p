fof(myForms, conjecture, ! [C] : ! [D] : (subset(set_union2(singleton(C),D),D) => in(C,D))).
fof(myForms, conjecture, ! [D] : (subset(set_union2(singleton(C),D),D) => in(C,D))).
fof(myForms, conjecture, (subset(set_union2(singleton(C),D),D) => in(C,D))).
fof(myForms, conjecture, subset(set_union2(singleton(C),D),D)).
fof(myForms, conjecture, in(C,D)).