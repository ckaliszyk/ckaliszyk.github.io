fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,relation_type(D,F)) => (range(D,F,I)=image4(D,F,I,D) & domain(D,F,I)=inverse4(D,F,I,F)))))).
fof(myForms, conjecture, (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,relation_type(D,F)) => (range(D,F,I)=image4(D,F,I,D) & domain(D,F,I)=inverse4(D,F,I,F)))))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,relation_type(D,F)) => (range(D,F,I)=image4(D,F,I,D) & domain(D,F,I)=inverse4(D,F,I,F))))).
fof(myForms, conjecture, (ilf_type(F,set_type) => ! [I] : (ilf_type(I,relation_type(D,F)) => (range(D,F,I)=image4(D,F,I,D) & domain(D,F,I)=inverse4(D,F,I,F))))).
fof(myForms, conjecture, ilf_type(F,set_type)).
fof(myForms, conjecture, ! [I] : (ilf_type(I,relation_type(D,F)) => (range(D,F,I)=image4(D,F,I,D) & domain(D,F,I)=inverse4(D,F,I,F)))).
fof(myForms, conjecture, (ilf_type(I,relation_type(D,F)) => (range(D,F,I)=image4(D,F,I,D) & domain(D,F,I)=inverse4(D,F,I,F)))).
fof(myForms, conjecture, ilf_type(I,relation_type(D,F))).
fof(myForms, conjecture, (range(D,F,I)=image4(D,F,I,D) & domain(D,F,I)=inverse4(D,F,I,F))).
fof(myForms, conjecture, range(D,F,I)=image4(D,F,I,D)).
fof(myForms, conjecture, domain(D,F,I)=inverse4(D,F,I,F)).