fof(myForms, conjecture, ! [I1] : (ilf_type(I1,relation_type(I,B)) => ilf_type(restrict4(I,B,E1,I1),relation_type(I,B)))).
fof(myForms, conjecture, (ilf_type(I1,relation_type(I,B)) => ilf_type(restrict4(I,B,E1,I1),relation_type(I,B)))).
fof(myForms, conjecture, ilf_type(I1,relation_type(I,B))).
fof(myForms, conjecture, ilf_type(restrict4(I,B,E1,I1),relation_type(I,B))).