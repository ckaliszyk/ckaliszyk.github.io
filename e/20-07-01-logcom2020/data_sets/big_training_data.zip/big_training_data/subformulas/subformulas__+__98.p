fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,binary_relation_type) => (member(F,image(I,D)) <=> ? [J] : ((ilf_type(J,set_type) & member(ordered_pair(J,F),I)) & member(J,D))))))).
fof(myForms, conjecture, (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,binary_relation_type) => (member(F,image(I,D)) <=> ? [J] : ((ilf_type(J,set_type) & member(ordered_pair(J,F),I)) & member(J,D))))))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,binary_relation_type) => (member(F,image(I,D)) <=> ? [J] : ((ilf_type(J,set_type) & member(ordered_pair(J,F),I)) & member(J,D)))))).
fof(myForms, conjecture, (ilf_type(F,set_type) => ! [I] : (ilf_type(I,binary_relation_type) => (member(F,image(I,D)) <=> ? [J] : ((ilf_type(J,set_type) & member(ordered_pair(J,F),I)) & member(J,D)))))).
fof(myForms, conjecture, ilf_type(F,set_type)).
fof(myForms, conjecture, ! [I] : (ilf_type(I,binary_relation_type) => (member(F,image(I,D)) <=> ? [J] : ((ilf_type(J,set_type) & member(ordered_pair(J,F),I)) & member(J,D))))).
fof(myForms, conjecture, (ilf_type(I,binary_relation_type) => (member(F,image(I,D)) <=> ? [J] : ((ilf_type(J,set_type) & member(ordered_pair(J,F),I)) & member(J,D))))).
fof(myForms, conjecture, ilf_type(I,binary_relation_type)).
fof(myForms, conjecture, (member(F,image(I,D)) <=> ? [J] : ((ilf_type(J,set_type) & member(ordered_pair(J,F),I)) & member(J,D)))).
fof(myForms, conjecture, member(F,image(I,D))).
fof(myForms, conjecture, ? [J] : ((ilf_type(J,set_type) & member(ordered_pair(J,F),I)) & member(J,D))).
fof(myForms, conjecture, ((ilf_type(J,set_type) & member(ordered_pair(J,F),I)) & member(J,D))).
fof(myForms, conjecture, (ilf_type(J,set_type) & member(ordered_pair(J,F),I))).
fof(myForms, conjecture, ilf_type(J,set_type)).
fof(myForms, conjecture, member(ordered_pair(J,F),I)).
fof(myForms, conjecture, member(J,D)).