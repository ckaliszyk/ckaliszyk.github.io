fof(myForms, conjecture, ! [I] : ! [B] : ! [E1] : ((subset(F,cartesian_product2(I,B)) & ! [I1] : ! [D] : (in(ordered_pair(I1,D),F) => in(ordered_pair(I1,D),E1))) => subset(F,E1))).
fof(myForms, conjecture, ! [B] : ! [E1] : ((subset(F,cartesian_product2(I,B)) & ! [I1] : ! [D] : (in(ordered_pair(I1,D),F) => in(ordered_pair(I1,D),E1))) => subset(F,E1))).
fof(myForms, conjecture, ! [E1] : ((subset(F,cartesian_product2(I,B)) & ! [I1] : ! [D] : (in(ordered_pair(I1,D),F) => in(ordered_pair(I1,D),E1))) => subset(F,E1))).
fof(myForms, conjecture, ((subset(F,cartesian_product2(I,B)) & ! [I1] : ! [D] : (in(ordered_pair(I1,D),F) => in(ordered_pair(I1,D),E1))) => subset(F,E1))).
fof(myForms, conjecture, (subset(F,cartesian_product2(I,B)) & ! [I1] : ! [D] : (in(ordered_pair(I1,D),F) => in(ordered_pair(I1,D),E1)))).
fof(myForms, conjecture, subset(F,cartesian_product2(I,B))).
fof(myForms, conjecture, ! [I1] : ! [D] : (in(ordered_pair(I1,D),F) => in(ordered_pair(I1,D),E1))).
fof(myForms, conjecture, ! [D] : (in(ordered_pair(I1,D),F) => in(ordered_pair(I1,D),E1))).
fof(myForms, conjecture, (in(ordered_pair(I1,D),F) => in(ordered_pair(I1,D),E1))).
fof(myForms, conjecture, in(ordered_pair(I1,D),F)).
fof(myForms, conjecture, in(ordered_pair(I1,D),E1)).
fof(myForms, conjecture, subset(F,E1)).