fof(myForms, conjecture, (ilf_type(E1,set_type) => (member(E1,cross_product(I,B)) <=> ? [I1] : (ilf_type(I1,set_type) & ? [D] : (((ilf_type(D,set_type) & member(I1,I)) & member(D,B)) & ordered_pair(I1,D)=E1))))).
fof(myForms, conjecture, ilf_type(E1,set_type)).
fof(myForms, conjecture, (member(E1,cross_product(I,B)) <=> ? [I1] : (ilf_type(I1,set_type) & ? [D] : (((ilf_type(D,set_type) & member(I1,I)) & member(D,B)) & ordered_pair(I1,D)=E1)))).
fof(myForms, conjecture, member(E1,cross_product(I,B))).
fof(myForms, conjecture, ? [I1] : (ilf_type(I1,set_type) & ? [D] : (((ilf_type(D,set_type) & member(I1,I)) & member(D,B)) & ordered_pair(I1,D)=E1))).
fof(myForms, conjecture, (ilf_type(I1,set_type) & ? [D] : (((ilf_type(D,set_type) & member(I1,I)) & member(D,B)) & ordered_pair(I1,D)=E1))).
fof(myForms, conjecture, ilf_type(I1,set_type)).
fof(myForms, conjecture, ? [D] : (((ilf_type(D,set_type) & member(I1,I)) & member(D,B)) & ordered_pair(I1,D)=E1)).
fof(myForms, conjecture, (((ilf_type(D,set_type) & member(I1,I)) & member(D,B)) & ordered_pair(I1,D)=E1)).
fof(myForms, conjecture, ((ilf_type(D,set_type) & member(I1,I)) & member(D,B))).
fof(myForms, conjecture, (ilf_type(D,set_type) & member(I1,I))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, member(I1,I)).
fof(myForms, conjecture, member(D,B)).
fof(myForms, conjecture, ordered_pair(I1,D)=E1).