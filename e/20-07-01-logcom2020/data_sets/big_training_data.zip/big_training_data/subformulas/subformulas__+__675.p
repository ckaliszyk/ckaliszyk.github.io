fof(myForms, conjecture, ! [C] : ((relation(C) & function(C)) => ! [D] : ((relation(D) & function(D)) => ! [F] : ((relation(F) & function(F)) => ((! [I] : (in(I,relation_dom(F)) <=> (in(I,relation_dom(C)) & in(apply(C,I),relation_dom(D)))) & ! [I] : (in(I,relation_dom(F)) => apply(F,I)=apply(D,apply(C,I)))) => relation_composition(C,D)=F))))).
fof(myForms, conjecture, ((relation(C) & function(C)) => ! [D] : ((relation(D) & function(D)) => ! [F] : ((relation(F) & function(F)) => ((! [I] : (in(I,relation_dom(F)) <=> (in(I,relation_dom(C)) & in(apply(C,I),relation_dom(D)))) & ! [I] : (in(I,relation_dom(F)) => apply(F,I)=apply(D,apply(C,I)))) => relation_composition(C,D)=F))))).
fof(myForms, conjecture, (relation(C) & function(C))).
fof(myForms, conjecture, relation(C)).
fof(myForms, conjecture, function(C)).
fof(myForms, conjecture, ! [D] : ((relation(D) & function(D)) => ! [F] : ((relation(F) & function(F)) => ((! [I] : (in(I,relation_dom(F)) <=> (in(I,relation_dom(C)) & in(apply(C,I),relation_dom(D)))) & ! [I] : (in(I,relation_dom(F)) => apply(F,I)=apply(D,apply(C,I)))) => relation_composition(C,D)=F)))).
fof(myForms, conjecture, ((relation(D) & function(D)) => ! [F] : ((relation(F) & function(F)) => ((! [I] : (in(I,relation_dom(F)) <=> (in(I,relation_dom(C)) & in(apply(C,I),relation_dom(D)))) & ! [I] : (in(I,relation_dom(F)) => apply(F,I)=apply(D,apply(C,I)))) => relation_composition(C,D)=F)))).
fof(myForms, conjecture, (relation(D) & function(D))).
fof(myForms, conjecture, relation(D)).
fof(myForms, conjecture, function(D)).
fof(myForms, conjecture, ! [F] : ((relation(F) & function(F)) => ((! [I] : (in(I,relation_dom(F)) <=> (in(I,relation_dom(C)) & in(apply(C,I),relation_dom(D)))) & ! [I] : (in(I,relation_dom(F)) => apply(F,I)=apply(D,apply(C,I)))) => relation_composition(C,D)=F))).
fof(myForms, conjecture, ((relation(F) & function(F)) => ((! [I] : (in(I,relation_dom(F)) <=> (in(I,relation_dom(C)) & in(apply(C,I),relation_dom(D)))) & ! [I] : (in(I,relation_dom(F)) => apply(F,I)=apply(D,apply(C,I)))) => relation_composition(C,D)=F))).
fof(myForms, conjecture, (relation(F) & function(F))).
fof(myForms, conjecture, relation(F)).
fof(myForms, conjecture, function(F)).
fof(myForms, conjecture, ((! [I] : (in(I,relation_dom(F)) <=> (in(I,relation_dom(C)) & in(apply(C,I),relation_dom(D)))) & ! [I] : (in(I,relation_dom(F)) => apply(F,I)=apply(D,apply(C,I)))) => relation_composition(C,D)=F)).
fof(myForms, conjecture, (! [I] : (in(I,relation_dom(F)) <=> (in(I,relation_dom(C)) & in(apply(C,I),relation_dom(D)))) & ! [I] : (in(I,relation_dom(F)) => apply(F,I)=apply(D,apply(C,I))))).
fof(myForms, conjecture, ! [I] : (in(I,relation_dom(F)) <=> (in(I,relation_dom(C)) & in(apply(C,I),relation_dom(D))))).
fof(myForms, conjecture, (in(I,relation_dom(F)) <=> (in(I,relation_dom(C)) & in(apply(C,I),relation_dom(D))))).
fof(myForms, conjecture, in(I,relation_dom(F))).
fof(myForms, conjecture, (in(I,relation_dom(C)) & in(apply(C,I),relation_dom(D)))).
fof(myForms, conjecture, in(I,relation_dom(C))).
fof(myForms, conjecture, in(apply(C,I),relation_dom(D))).
fof(myForms, conjecture, ! [I] : (in(I,relation_dom(F)) => apply(F,I)=apply(D,apply(C,I)))).
fof(myForms, conjecture, (in(I,relation_dom(F)) => apply(F,I)=apply(D,apply(C,I)))).
fof(myForms, conjecture, in(I,relation_dom(F))).
fof(myForms, conjecture, apply(F,I)=apply(D,apply(C,I))).
fof(myForms, conjecture, relation_composition(C,D)=F).