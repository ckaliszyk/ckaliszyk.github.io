fof(myForms, conjecture, ! [I] : ! [B] : ! [E1] : ((subset(I,B) & subset(I,E1)) => subset(I,intersection(B,E1)))).
fof(myForms, conjecture, ! [B] : ! [E1] : ((subset(I,B) & subset(I,E1)) => subset(I,intersection(B,E1)))).
fof(myForms, conjecture, ! [E1] : ((subset(I,B) & subset(I,E1)) => subset(I,intersection(B,E1)))).
fof(myForms, conjecture, ((subset(I,B) & subset(I,E1)) => subset(I,intersection(B,E1)))).
fof(myForms, conjecture, (subset(I,B) & subset(I,E1))).
fof(myForms, conjecture, subset(I,B)).
fof(myForms, conjecture, subset(I,E1)).
fof(myForms, conjecture, subset(I,intersection(B,E1))).