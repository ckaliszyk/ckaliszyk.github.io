fof(myForms, conjecture, ! [D] : (ilf_type(D,member_type(I)) => (member(D,inverse4(I,E1,I1,B)) <=> ? [J] : ((ilf_type(J,member_type(E1)) & member(ordered_pair(D,J),I1)) & member(J,B))))).
fof(myForms, conjecture, (ilf_type(D,member_type(I)) => (member(D,inverse4(I,E1,I1,B)) <=> ? [J] : ((ilf_type(J,member_type(E1)) & member(ordered_pair(D,J),I1)) & member(J,B))))).
fof(myForms, conjecture, ilf_type(D,member_type(I))).
fof(myForms, conjecture, (member(D,inverse4(I,E1,I1,B)) <=> ? [J] : ((ilf_type(J,member_type(E1)) & member(ordered_pair(D,J),I1)) & member(J,B)))).
fof(myForms, conjecture, member(D,inverse4(I,E1,I1,B))).
fof(myForms, conjecture, ? [J] : ((ilf_type(J,member_type(E1)) & member(ordered_pair(D,J),I1)) & member(J,B))).
fof(myForms, conjecture, ((ilf_type(J,member_type(E1)) & member(ordered_pair(D,J),I1)) & member(J,B))).
fof(myForms, conjecture, (ilf_type(J,member_type(E1)) & member(ordered_pair(D,J),I1))).
fof(myForms, conjecture, ilf_type(J,member_type(E1))).
fof(myForms, conjecture, member(ordered_pair(D,J),I1)).
fof(myForms, conjecture, member(J,B)).