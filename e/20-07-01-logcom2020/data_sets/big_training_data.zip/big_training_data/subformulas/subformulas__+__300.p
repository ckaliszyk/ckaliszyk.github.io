fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => (not_equal(D,F) <=> ~ F=D)))).
fof(myForms, conjecture, (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => (not_equal(D,F) <=> ~ F=D)))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, ! [F] : (ilf_type(F,set_type) => (not_equal(D,F) <=> ~ F=D))).
fof(myForms, conjecture, (ilf_type(F,set_type) => (not_equal(D,F) <=> ~ F=D))).
fof(myForms, conjecture, ilf_type(F,set_type)).
fof(myForms, conjecture, (not_equal(D,F) <=> ~ F=D)).
fof(myForms, conjecture, not_equal(D,F)).
fof(myForms, conjecture, ~ F=D).
fof(myForms, conjecture, F=D).