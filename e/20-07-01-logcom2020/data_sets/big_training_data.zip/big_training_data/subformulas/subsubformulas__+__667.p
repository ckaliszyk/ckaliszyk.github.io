fof(myForms, conjecture, ! [I] : subset(set_intersection2(F,I),F)).
fof(myForms, conjecture, subset(set_intersection2(F,I),F)).