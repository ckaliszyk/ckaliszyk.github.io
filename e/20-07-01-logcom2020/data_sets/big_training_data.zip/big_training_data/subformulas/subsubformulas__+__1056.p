fof(myForms, conjecture, ! [F] : (relation(F) => ! [I] : (relation_dom(F)=I <=> ! [B] : (in(B,I) <=> ? [E1] : in(ordered_pair(B,E1),F))))).
fof(myForms, conjecture, (relation(F) => ! [I] : (relation_dom(F)=I <=> ! [B] : (in(B,I) <=> ? [E1] : in(ordered_pair(B,E1),F))))).
fof(myForms, conjecture, relation(F)).
fof(myForms, conjecture, ! [I] : (relation_dom(F)=I <=> ! [B] : (in(B,I) <=> ? [E1] : in(ordered_pair(B,E1),F)))).
fof(myForms, conjecture, (relation_dom(F)=I <=> ! [B] : (in(B,I) <=> ? [E1] : in(ordered_pair(B,E1),F)))).
fof(myForms, conjecture, relation_dom(F)=I).
fof(myForms, conjecture, ! [B] : (in(B,I) <=> ? [E1] : in(ordered_pair(B,E1),F))).
fof(myForms, conjecture, (in(B,I) <=> ? [E1] : in(ordered_pair(B,E1),F))).
fof(myForms, conjecture, in(B,I)).
fof(myForms, conjecture, ? [E1] : in(ordered_pair(B,E1),F)).
fof(myForms, conjecture, in(ordered_pair(B,E1),F)).