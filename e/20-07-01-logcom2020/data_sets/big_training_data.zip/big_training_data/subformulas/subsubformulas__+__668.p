fof(myForms, conjecture, ((~ empty(B) & ilf_type(B,set_type)) => ! [E1] : (ilf_type(E1,relation_type(I,B)) => ! [I1] : (ilf_type(I1,member_type(I)) => (member(I1,domain(I,B,E1)) => ? [D] : (ilf_type(D,member_type(B)) & member(D,range(I,B,E1)))))))).
fof(myForms, conjecture, (~ empty(B) & ilf_type(B,set_type))).
fof(myForms, conjecture, ~ empty(B)).
fof(myForms, conjecture, empty(B)).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ! [E1] : (ilf_type(E1,relation_type(I,B)) => ! [I1] : (ilf_type(I1,member_type(I)) => (member(I1,domain(I,B,E1)) => ? [D] : (ilf_type(D,member_type(B)) & member(D,range(I,B,E1))))))).
fof(myForms, conjecture, (ilf_type(E1,relation_type(I,B)) => ! [I1] : (ilf_type(I1,member_type(I)) => (member(I1,domain(I,B,E1)) => ? [D] : (ilf_type(D,member_type(B)) & member(D,range(I,B,E1))))))).
fof(myForms, conjecture, ilf_type(E1,relation_type(I,B))).
fof(myForms, conjecture, ! [I1] : (ilf_type(I1,member_type(I)) => (member(I1,domain(I,B,E1)) => ? [D] : (ilf_type(D,member_type(B)) & member(D,range(I,B,E1)))))).
fof(myForms, conjecture, (ilf_type(I1,member_type(I)) => (member(I1,domain(I,B,E1)) => ? [D] : (ilf_type(D,member_type(B)) & member(D,range(I,B,E1)))))).
fof(myForms, conjecture, ilf_type(I1,member_type(I))).
fof(myForms, conjecture, (member(I1,domain(I,B,E1)) => ? [D] : (ilf_type(D,member_type(B)) & member(D,range(I,B,E1))))).
fof(myForms, conjecture, member(I1,domain(I,B,E1))).
fof(myForms, conjecture, ? [D] : (ilf_type(D,member_type(B)) & member(D,range(I,B,E1)))).
fof(myForms, conjecture, (ilf_type(D,member_type(B)) & member(D,range(I,B,E1)))).
fof(myForms, conjecture, ilf_type(D,member_type(B))).
fof(myForms, conjecture, member(D,range(I,B,E1))).