fof(myForms, conjecture, ! [I] : (ilf_type(I,set_type) => ! [B] : (ilf_type(B,set_type) => ! [E1] : (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,binary_relation_type) => (member(ordered_pair(B,E1),restrict(I,I1)) <=> (member(E1,I) & member(ordered_pair(B,E1),I1)))))))).
fof(myForms, conjecture, (ilf_type(I,set_type) => ! [B] : (ilf_type(B,set_type) => ! [E1] : (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,binary_relation_type) => (member(ordered_pair(B,E1),restrict(I,I1)) <=> (member(E1,I) & member(ordered_pair(B,E1),I1)))))))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [B] : (ilf_type(B,set_type) => ! [E1] : (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,binary_relation_type) => (member(ordered_pair(B,E1),restrict(I,I1)) <=> (member(E1,I) & member(ordered_pair(B,E1),I1))))))).
fof(myForms, conjecture, (ilf_type(B,set_type) => ! [E1] : (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,binary_relation_type) => (member(ordered_pair(B,E1),restrict(I,I1)) <=> (member(E1,I) & member(ordered_pair(B,E1),I1))))))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ! [E1] : (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,binary_relation_type) => (member(ordered_pair(B,E1),restrict(I,I1)) <=> (member(E1,I) & member(ordered_pair(B,E1),I1)))))).
fof(myForms, conjecture, (ilf_type(E1,set_type) => ! [I1] : (ilf_type(I1,binary_relation_type) => (member(ordered_pair(B,E1),restrict(I,I1)) <=> (member(E1,I) & member(ordered_pair(B,E1),I1)))))).
fof(myForms, conjecture, ilf_type(E1,set_type)).
fof(myForms, conjecture, ! [I1] : (ilf_type(I1,binary_relation_type) => (member(ordered_pair(B,E1),restrict(I,I1)) <=> (member(E1,I) & member(ordered_pair(B,E1),I1))))).
fof(myForms, conjecture, (ilf_type(I1,binary_relation_type) => (member(ordered_pair(B,E1),restrict(I,I1)) <=> (member(E1,I) & member(ordered_pair(B,E1),I1))))).
fof(myForms, conjecture, ilf_type(I1,binary_relation_type)).
fof(myForms, conjecture, (member(ordered_pair(B,E1),restrict(I,I1)) <=> (member(E1,I) & member(ordered_pair(B,E1),I1)))).
fof(myForms, conjecture, member(ordered_pair(B,E1),restrict(I,I1))).
fof(myForms, conjecture, (member(E1,I) & member(ordered_pair(B,E1),I1))).
fof(myForms, conjecture, member(E1,I)).
fof(myForms, conjecture, member(ordered_pair(B,E1),I1)).