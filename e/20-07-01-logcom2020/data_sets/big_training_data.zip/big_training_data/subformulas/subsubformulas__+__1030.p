fof(myForms, conjecture, ((maps(D,F,I) & one_to_one(D,F,I)) => identity(compose_function(D,inverse_function(D,F,I),I,F,I),I))).
fof(myForms, conjecture, (maps(D,F,I) & one_to_one(D,F,I))).
fof(myForms, conjecture, maps(D,F,I)).
fof(myForms, conjecture, one_to_one(D,F,I)).
fof(myForms, conjecture, identity(compose_function(D,inverse_function(D,F,I),I,F,I),I)).