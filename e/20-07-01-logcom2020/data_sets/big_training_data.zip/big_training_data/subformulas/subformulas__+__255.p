fof(myForms, conjecture, ! [O] : ! [J] : (order(O,J) => ! [L] : ! [P] : (((subset(L,J) & subset(P,J)) & subset(L,P)) => ! [W] : (upper_bound(W,O,P) => upper_bound(W,O,L))))).
fof(myForms, conjecture, ! [J] : (order(O,J) => ! [L] : ! [P] : (((subset(L,J) & subset(P,J)) & subset(L,P)) => ! [W] : (upper_bound(W,O,P) => upper_bound(W,O,L))))).
fof(myForms, conjecture, (order(O,J) => ! [L] : ! [P] : (((subset(L,J) & subset(P,J)) & subset(L,P)) => ! [W] : (upper_bound(W,O,P) => upper_bound(W,O,L))))).
fof(myForms, conjecture, order(O,J)).
fof(myForms, conjecture, ! [L] : ! [P] : (((subset(L,J) & subset(P,J)) & subset(L,P)) => ! [W] : (upper_bound(W,O,P) => upper_bound(W,O,L)))).
fof(myForms, conjecture, ! [P] : (((subset(L,J) & subset(P,J)) & subset(L,P)) => ! [W] : (upper_bound(W,O,P) => upper_bound(W,O,L)))).
fof(myForms, conjecture, (((subset(L,J) & subset(P,J)) & subset(L,P)) => ! [W] : (upper_bound(W,O,P) => upper_bound(W,O,L)))).
fof(myForms, conjecture, ((subset(L,J) & subset(P,J)) & subset(L,P))).
fof(myForms, conjecture, (subset(L,J) & subset(P,J))).
fof(myForms, conjecture, subset(L,J)).
fof(myForms, conjecture, subset(P,J)).
fof(myForms, conjecture, subset(L,P)).
fof(myForms, conjecture, ! [W] : (upper_bound(W,O,P) => upper_bound(W,O,L))).
fof(myForms, conjecture, (upper_bound(W,O,P) => upper_bound(W,O,L))).
fof(myForms, conjecture, upper_bound(W,O,P)).
fof(myForms, conjecture, upper_bound(W,O,L)).