fof(myForms, conjecture, (subset(F,I1) & subset(I,I1))).
fof(myForms, conjecture, subset(F,I1)).
fof(myForms, conjecture, subset(I,I1)).