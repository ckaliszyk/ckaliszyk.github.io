fof(myForms, conjecture, (ilf_type(I,set_type) => ! [B] : (ilf_type(B,set_type) => ! [E1] : (ilf_type(E1,relation_type(I,B)) => range(I,B,E1)=range_of(E1))))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [B] : (ilf_type(B,set_type) => ! [E1] : (ilf_type(E1,relation_type(I,B)) => range(I,B,E1)=range_of(E1)))).
fof(myForms, conjecture, (ilf_type(B,set_type) => ! [E1] : (ilf_type(E1,relation_type(I,B)) => range(I,B,E1)=range_of(E1)))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ! [E1] : (ilf_type(E1,relation_type(I,B)) => range(I,B,E1)=range_of(E1))).
fof(myForms, conjecture, (ilf_type(E1,relation_type(I,B)) => range(I,B,E1)=range_of(E1))).
fof(myForms, conjecture, ilf_type(E1,relation_type(I,B))).
fof(myForms, conjecture, range(I,B,E1)=range_of(E1)).