fof(myForms, conjecture, ! [D] : ! [F] : union(D,intersection(D,F))=D).
fof(myForms, conjecture, ! [F] : union(D,intersection(D,F))=D).
fof(myForms, conjecture, union(D,intersection(D,F))=D).