fof(myForms, conjecture, ! [E1] : (ilf_type(E1,subset_type(cross_product(I,B))) => ilf_type(E1,relation_type(I,B)))).
fof(myForms, conjecture, (ilf_type(E1,subset_type(cross_product(I,B))) => ilf_type(E1,relation_type(I,B)))).
fof(myForms, conjecture, ilf_type(E1,subset_type(cross_product(I,B)))).
fof(myForms, conjecture, ilf_type(E1,relation_type(I,B))).