fof(myForms, conjecture, ! [C] : ! [D] : ! [F] : ! [I] : ((subset(C,D) & subset(F,I)) => set_intersection2(cartesian_product2(C,I),cartesian_product2(D,F))=cartesian_product2(C,F))).
fof(myForms, conjecture, ! [D] : ! [F] : ! [I] : ((subset(C,D) & subset(F,I)) => set_intersection2(cartesian_product2(C,I),cartesian_product2(D,F))=cartesian_product2(C,F))).
fof(myForms, conjecture, ! [F] : ! [I] : ((subset(C,D) & subset(F,I)) => set_intersection2(cartesian_product2(C,I),cartesian_product2(D,F))=cartesian_product2(C,F))).
fof(myForms, conjecture, ! [I] : ((subset(C,D) & subset(F,I)) => set_intersection2(cartesian_product2(C,I),cartesian_product2(D,F))=cartesian_product2(C,F))).
fof(myForms, conjecture, ((subset(C,D) & subset(F,I)) => set_intersection2(cartesian_product2(C,I),cartesian_product2(D,F))=cartesian_product2(C,F))).
fof(myForms, conjecture, (subset(C,D) & subset(F,I))).
fof(myForms, conjecture, subset(C,D)).
fof(myForms, conjecture, subset(F,I)).
fof(myForms, conjecture, set_intersection2(cartesian_product2(C,I),cartesian_product2(D,F))=cartesian_product2(C,F)).