fof(myForms, conjecture, ! [F] : ! [I] : ! [B] : ((maps(D,F,I) & subset(B,F)) => subset(B,inverse_image2(D,image2(D,B))))).
fof(myForms, conjecture, ! [I] : ! [B] : ((maps(D,F,I) & subset(B,F)) => subset(B,inverse_image2(D,image2(D,B))))).
fof(myForms, conjecture, ! [B] : ((maps(D,F,I) & subset(B,F)) => subset(B,inverse_image2(D,image2(D,B))))).
fof(myForms, conjecture, ((maps(D,F,I) & subset(B,F)) => subset(B,inverse_image2(D,image2(D,B))))).
fof(myForms, conjecture, (maps(D,F,I) & subset(B,F))).
fof(myForms, conjecture, maps(D,F,I)).
fof(myForms, conjecture, subset(B,F)).
fof(myForms, conjecture, subset(B,inverse_image2(D,image2(D,B)))).