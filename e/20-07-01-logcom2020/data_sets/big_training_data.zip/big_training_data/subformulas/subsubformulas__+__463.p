fof(myForms, conjecture, ! [B] : ~ ((((~ set_difference(unordered_pair(F,I),B)=empty_set & ~ singleton(F)=set_difference(unordered_pair(F,I),B)) & ~ singleton(I)=set_difference(unordered_pair(F,I),B)) & ~ set_difference(unordered_pair(F,I),B)=unordered_pair(F,I)))).
fof(myForms, conjecture, ~ ((((~ set_difference(unordered_pair(F,I),B)=empty_set & ~ singleton(F)=set_difference(unordered_pair(F,I),B)) & ~ singleton(I)=set_difference(unordered_pair(F,I),B)) & ~ set_difference(unordered_pair(F,I),B)=unordered_pair(F,I)))).
fof(myForms, conjecture, (((~ set_difference(unordered_pair(F,I),B)=empty_set & ~ singleton(F)=set_difference(unordered_pair(F,I),B)) & ~ singleton(I)=set_difference(unordered_pair(F,I),B)) & ~ set_difference(unordered_pair(F,I),B)=unordered_pair(F,I))).
fof(myForms, conjecture, ((~ set_difference(unordered_pair(F,I),B)=empty_set & ~ singleton(F)=set_difference(unordered_pair(F,I),B)) & ~ singleton(I)=set_difference(unordered_pair(F,I),B))).
fof(myForms, conjecture, (~ set_difference(unordered_pair(F,I),B)=empty_set & ~ singleton(F)=set_difference(unordered_pair(F,I),B))).
fof(myForms, conjecture, ~ set_difference(unordered_pair(F,I),B)=empty_set).
fof(myForms, conjecture, set_difference(unordered_pair(F,I),B)=empty_set).
fof(myForms, conjecture, ~ singleton(F)=set_difference(unordered_pair(F,I),B)).
fof(myForms, conjecture, singleton(F)=set_difference(unordered_pair(F,I),B)).
fof(myForms, conjecture, ~ singleton(I)=set_difference(unordered_pair(F,I),B)).
fof(myForms, conjecture, singleton(I)=set_difference(unordered_pair(F,I),B)).
fof(myForms, conjecture, ~ set_difference(unordered_pair(F,I),B)=unordered_pair(F,I)).
fof(myForms, conjecture, set_difference(unordered_pair(F,I),B)=unordered_pair(F,I)).