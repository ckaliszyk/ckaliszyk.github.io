fof(myForms, conjecture, ((maps(D,F,I) & injective(D,F,I)) & subset(F1,F))).
fof(myForms, conjecture, (maps(D,F,I) & injective(D,F,I))).
fof(myForms, conjecture, maps(D,F,I)).
fof(myForms, conjecture, injective(D,F,I)).
fof(myForms, conjecture, subset(F1,F)).