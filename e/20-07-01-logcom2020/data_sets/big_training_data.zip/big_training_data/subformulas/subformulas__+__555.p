fof(myForms, conjecture, ! [C] : ! [D] : set_intersection2(D,C)=set_intersection2(C,D)).
fof(myForms, conjecture, ! [D] : set_intersection2(D,C)=set_intersection2(C,D)).
fof(myForms, conjecture, set_intersection2(D,C)=set_intersection2(C,D)).