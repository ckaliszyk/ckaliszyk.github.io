fof(myForms, conjecture, (~ empty_set=F & ~ singleton(I)=F)).
fof(myForms, conjecture, ~ empty_set=F).
fof(myForms, conjecture, empty_set=F).
fof(myForms, conjecture, ~ singleton(I)=F).
fof(myForms, conjecture, singleton(I)=F).