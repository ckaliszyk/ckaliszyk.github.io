fof(myForms, conjecture, ! [D] : ! [F] : (subset(D,F) => intersection(D,F)=D)).
fof(myForms, conjecture, ! [F] : (subset(D,F) => intersection(D,F)=D)).
fof(myForms, conjecture, (subset(D,F) => intersection(D,F)=D)).
fof(myForms, conjecture, subset(D,F)).
fof(myForms, conjecture, intersection(D,F)=D).