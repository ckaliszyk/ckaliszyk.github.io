fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ! [F] : (ilf_type(F,binary_relation_type) => (member(D,domain_of(F)) <=> ? [I] : (ilf_type(I,set_type) & member(ordered_pair(D,I),F)))))).
fof(myForms, conjecture, (ilf_type(D,set_type) => ! [F] : (ilf_type(F,binary_relation_type) => (member(D,domain_of(F)) <=> ? [I] : (ilf_type(I,set_type) & member(ordered_pair(D,I),F)))))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, ! [F] : (ilf_type(F,binary_relation_type) => (member(D,domain_of(F)) <=> ? [I] : (ilf_type(I,set_type) & member(ordered_pair(D,I),F))))).
fof(myForms, conjecture, (ilf_type(F,binary_relation_type) => (member(D,domain_of(F)) <=> ? [I] : (ilf_type(I,set_type) & member(ordered_pair(D,I),F))))).
fof(myForms, conjecture, ilf_type(F,binary_relation_type)).
fof(myForms, conjecture, (member(D,domain_of(F)) <=> ? [I] : (ilf_type(I,set_type) & member(ordered_pair(D,I),F)))).
fof(myForms, conjecture, member(D,domain_of(F))).
fof(myForms, conjecture, ? [I] : (ilf_type(I,set_type) & member(ordered_pair(D,I),F))).
fof(myForms, conjecture, (ilf_type(I,set_type) & member(ordered_pair(D,I),F))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, member(ordered_pair(D,I),F)).