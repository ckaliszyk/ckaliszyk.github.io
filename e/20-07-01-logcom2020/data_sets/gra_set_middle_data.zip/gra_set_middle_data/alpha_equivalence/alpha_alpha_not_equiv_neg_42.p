fof(myForms, conjecture, goal).
fof(myForms, conjecture, ! [B] : ! [C] : ! [D] : (triangle(B,C,D) <=> (((((edge(B) & edge(C)) & edge(D)) & sequential(B,C)) & sequential(C,D)) & sequential(D,B)))).