fof(myForms, conjecture, ! [H] : ! [I] : less_or_equal(number_of_in(H,I),number_of_in(H,graph))).
fof(myForms, conjecture, ! [K5] : ! [L5] : less_or_equal(number_of_in(K5,L5),number_of_in(K5,graph))).