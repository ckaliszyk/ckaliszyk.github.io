fof(myForms, conjecture, goal).
fof(myForms, conjecture, ! [J] : ! [K] : ! [L] : (((green(J,K) & green(K,L)) & green(J,L)) => goal)).