fof(myForms, conjecture, goal).
fof(myForms, conjecture, ! [J] : ! [K] : ! [L] : ! [M] : ((((((green(J,K) & green(J,L)) & green(K,L)) & green(J,M)) & green(K,M)) & green(L,M)) => goal)).