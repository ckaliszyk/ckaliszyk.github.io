fof(myForms, conjecture, ! [H] : ! [I] : less_or_equal(number_of_in(H,I),number_of_in(H,graph))).
fof(myForms, conjecture, ! [K7] : ! [L7] : less_or_equal(number_of_in(K7,L7),number_of_in(K7,graph))).