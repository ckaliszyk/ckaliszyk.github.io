fof(myForms, conjecture, goal).
fof(myForms, conjecture, ! [H] : ! [I] : less_or_equal(number_of_in(H,I),number_of_in(H,graph))).