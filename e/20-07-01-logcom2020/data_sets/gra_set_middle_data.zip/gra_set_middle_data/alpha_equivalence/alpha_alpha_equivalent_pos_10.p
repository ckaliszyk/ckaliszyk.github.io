fof(myForms, conjecture, ! [J] : ! [K] : ! [L] : (((red(J,K) & red(K,L)) & red(J,L)) => goal)).
fof(myForms, conjecture, ! [G5] : ! [H5] : ! [I5] : (((red(G5,H5) & red(H5,I5)) & red(G5,I5)) => goal)).