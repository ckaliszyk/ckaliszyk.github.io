fof(myForms, conjecture, ! [J] : ! [K] : ! [L] : (((red(J,K) & red(K,L)) & red(J,L)) => goal)).
fof(myForms, conjecture, ! [U5] : ! [V5] : ! [W5] : (((red(U5,V5) & red(V5,W5)) & red(U5,W5)) => goal)).