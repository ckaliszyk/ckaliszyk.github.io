fof(myForms, conjecture, goal).
fof(myForms, conjecture, (complete => ! [G] : ! [E] : ! [F] : (shortest_path(E,F,G) => number_of_in(triangles,G)=minus(length_of(G),n1)))).