fof(myForms, conjecture, goal).
fof(myForms, conjecture, ! [E] : ! [F] : ! [G] : (path(E,F,G) => number_of_in(edges,G)=length_of(G))).