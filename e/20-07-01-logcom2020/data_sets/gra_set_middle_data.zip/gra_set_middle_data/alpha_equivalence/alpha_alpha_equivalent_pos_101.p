fof(myForms, conjecture, ! [U6] : ! [V6] : ((red(U6,V6) & green(U6,V6)) => goal)).
fof(myForms, conjecture, ! [F] : ! [G] : ((red(F,G) & green(F,G)) => goal)).