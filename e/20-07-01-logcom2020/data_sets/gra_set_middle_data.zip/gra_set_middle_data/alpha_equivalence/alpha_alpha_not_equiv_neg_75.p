fof(myForms, conjecture, goal).
fof(myForms, conjecture, ! [J] : ! [K] : ((red(J,K) & green(J,K)) => goal)).