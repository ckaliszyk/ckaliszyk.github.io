fof(myForms, conjecture, ((aElement0(xx) & sdtmndtasgtdt0(xb,xR,xx)) & sdtmndtasgtdt0(xd,xR,xx))).
fof(myForms, conjecture, ((aElement0(xx) & sdtmndtasgtdt0(xb,xR,xx)) & sdtmndtasgtdt0(xd,xR,xx))).