fof(myForms, conjecture, ! [V] : ! [W] : (equalish(V,W) => equalish(W,V))).
fof(myForms, conjecture, ! [A9] : ! [B9] : (equalish(A9,B9) => equalish(B9,A9))).