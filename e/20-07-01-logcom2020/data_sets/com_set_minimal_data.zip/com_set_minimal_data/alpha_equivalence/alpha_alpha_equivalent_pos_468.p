fof(myForms, conjecture, ((aElement0(xu) & aReductOfIn0(xu,xa,xR)) & sdtmndtasgtdt0(xu,xR,xb))).
fof(myForms, conjecture, ((aElement0(xu) & aReductOfIn0(xu,xa,xR)) & sdtmndtasgtdt0(xu,xR,xb))).