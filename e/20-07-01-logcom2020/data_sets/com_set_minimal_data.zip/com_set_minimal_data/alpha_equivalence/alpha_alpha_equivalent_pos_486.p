fof(myForms, conjecture, aRewritingSystem0(xR)).
fof(myForms, conjecture, aRewritingSystem0(xR)).