fof(myForms, conjecture, ! [V] : ! [W] : (rewrite(V,W) => reflexive_rewrite(V,W))).
fof(myForms, conjecture, ! [D3] : ! [E3] : (rewrite(D3,E3) => reflexive_rewrite(D3,E3))).