fof(myForms, conjecture, ~ (? [Z] : algorithm_program_decides(Z))).
fof(myForms, conjecture, ~ (? [Z9] : algorithm_program_decides(Z9))).