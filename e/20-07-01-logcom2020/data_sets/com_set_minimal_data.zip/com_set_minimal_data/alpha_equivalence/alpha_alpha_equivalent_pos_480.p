fof(myForms, conjecture, ! [K] : valphaEquivalent(K,K)).
fof(myForms, conjecture, ! [E1] : valphaEquivalent(E1,E1)).