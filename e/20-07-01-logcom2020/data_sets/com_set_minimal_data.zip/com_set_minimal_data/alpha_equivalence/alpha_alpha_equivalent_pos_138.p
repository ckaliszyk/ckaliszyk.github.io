fof(myForms, conjecture, ! [I1] : ! [J1] : ! [K1] : ! [L1] : ~ vvar(I1)=vabs(J1,K1,L1)).
fof(myForms, conjecture, ! [Z2] : ! [A3] : ! [B3] : ! [C3] : ~ vvar(Z2)=vabs(A3,B3,C3)).