fof(myForms, conjecture, ! [V] : ! [W] : (equalish(V,W) => equalish(W,V))).
fof(myForms, conjecture, ! [Q1] : ! [K] : (vgensym(K)=Q1 => ~ visFreeVar(Q1,K))).