fof(myForms, conjecture, ! [V] : ! [W] : (equalish(V,W) => equalish(W,V))).
fof(myForms, conjecture, ! [Z] : ! [A1] : ! [C1] : (halts2_outputs(Z,A1,C1) <=> (halts2(Z,A1) & outputs(Z,C1)))).