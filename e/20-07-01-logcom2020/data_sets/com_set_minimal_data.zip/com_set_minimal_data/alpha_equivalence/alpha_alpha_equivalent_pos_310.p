fof(myForms, conjecture, ((aElement0(xw) & sdtmndtasgtdt0(xu,xR,xw)) & sdtmndtasgtdt0(xv,xR,xw))).
fof(myForms, conjecture, ((aElement0(xw) & sdtmndtasgtdt0(xu,xR,xw)) & sdtmndtasgtdt0(xv,xR,xw))).