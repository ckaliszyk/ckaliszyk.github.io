fof(myForms, conjecture, ! [V] : ! [W] : (rewrite(V,W) => transitive_reflexive_rewrite(V,W))).
fof(myForms, conjecture, ! [O9] : ! [P9] : (rewrite(O9,P9) => transitive_reflexive_rewrite(O9,P9))).