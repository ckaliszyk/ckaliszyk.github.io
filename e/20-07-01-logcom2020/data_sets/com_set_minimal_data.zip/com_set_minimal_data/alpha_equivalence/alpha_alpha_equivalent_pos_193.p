fof(myForms, conjecture, ! [K1] : ~ vnoType=vsomeType(K1)).
fof(myForms, conjecture, ! [N3] : ~ vnoType=vsomeType(N3)).