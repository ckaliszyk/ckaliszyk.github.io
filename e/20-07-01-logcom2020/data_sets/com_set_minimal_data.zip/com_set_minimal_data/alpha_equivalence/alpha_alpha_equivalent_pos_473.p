fof(myForms, conjecture, ! [A] : ((reflexive_rewrite(b,A) & reflexive_rewrite(c,A)) => goal)).
fof(myForms, conjecture, ! [S4] : ((reflexive_rewrite(b,S4) & reflexive_rewrite(c,S4)) => goal)).