fof(myForms, conjecture, ! [V] : ! [W] : (equalish(V,W) => equalish(W,V))).
fof(myForms, conjecture, ((aElement0(xv) & aReductOfIn0(xv,xa,xR)) & sdtmndtasgtdt0(xv,xR,xc))).