fof(myForms, conjecture, ! [B] : (aElement0(B) => $true)).
fof(myForms, conjecture, ! [U5] : (aElement0(U5) => $true)).