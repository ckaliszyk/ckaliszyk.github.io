fof(myForms, conjecture, ? [B] : aNormalFormOfIn0(B,xw,xR)).
fof(myForms, conjecture, ? [V7] : aNormalFormOfIn0(V7,xw,xR)).