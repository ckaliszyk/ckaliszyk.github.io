fof(myForms, conjecture, ! [V] : ! [W] : (W=V => reflexive_rewrite(V,W))).
fof(myForms, conjecture, ! [Z3] : ! [A4] : (A4=Z3 => reflexive_rewrite(Z3,A4))).