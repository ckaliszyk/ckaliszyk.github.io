fof(myForms, conjecture, ! [K] : ! [T1] : (vsomeType(K)=T1 => visSomeType(T1))).
fof(myForms, conjecture, ! [Z9] : ! [A10] : (vsomeType(Z9)=A10 => visSomeType(A10))).