fof(myForms, conjecture, ! [Q] : ! [T] : ! [L1] : (vapp(Q,T)=L1 => ~ visValue(L1))).
fof(myForms, conjecture, ! [D1] : ! [E1] : ! [F1] : (vapp(D1,E1)=F1 => ~ visValue(F1))).