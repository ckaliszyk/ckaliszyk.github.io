fof(myForms, conjecture, (isLocallyConfluent0(xR) & isTerminating0(xR))).
fof(myForms, conjecture, (isLocallyConfluent0(xR) & isTerminating0(xR))).