fof(myForms, conjecture, ! [V] : ! [W] : (equalish(V,W) => equalish(W,V))).
fof(myForms, conjecture, ! [J] : ! [N] : ! [L] : ((vreduce(ve1)=vsomeExp(N) & vtcheck(J,ve1,L)) => vtcheck(J,N,L))).