fof(myForms, conjecture, ! [K8] : equalish(K8,K8)).
fof(myForms, conjecture, ! [V6] : equalish(V6,V6)).