fof(myForms, conjecture, ! [I] : ! [M] : ! [J] : ! [L] : ((~ visFreeVar(I,veabs) & vtcheck(vbind(I,M,J),veabs,L)) => vtcheck(J,veabs,L))).
fof(myForms, conjecture, ? [B] : aNormalFormOfIn0(B,xw,xR)).