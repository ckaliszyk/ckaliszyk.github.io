fof(myForms, conjecture, ! [V] : ! [W] : (equalish(V,W) => equalish(W,V))).
fof(myForms, conjecture, ! [K] : ! [I] : ! [Q] : ((~ visFreeVar(I,K) & valphaEquivalent(K,Q)) => ~ visFreeVar(I,Q))).