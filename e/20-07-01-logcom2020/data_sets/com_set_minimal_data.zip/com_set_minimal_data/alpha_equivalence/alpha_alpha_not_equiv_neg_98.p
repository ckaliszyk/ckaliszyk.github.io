fof(myForms, conjecture, ! [V] : ! [W] : (equalish(V,W) => equalish(W,V))).
fof(myForms, conjecture, ! [V] : ! [W] : ! [X] : ((equalish(V,W) & reflexive_rewrite(W,X)) => reflexive_rewrite(V,X))).