fof(myForms, conjecture, ! [V] : ! [W] : (equalish(V,W) => equalish(W,V))).
fof(myForms, conjecture, ! [Z] : (program_program_decides(Z) <=> (program(Z) & program_decides(Z)))).