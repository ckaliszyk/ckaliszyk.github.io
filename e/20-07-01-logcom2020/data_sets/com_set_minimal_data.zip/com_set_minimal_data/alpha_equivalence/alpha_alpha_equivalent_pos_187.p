fof(myForms, conjecture, ! [I1] : ! [K1] : ! [L1] : ! [N1] : ! [O1] : ~ vabs(I1,K1,L1)=vapp(N1,O1)).
fof(myForms, conjecture, ! [S] : ! [T] : ! [U] : ! [V] : ! [W] : ~ vabs(S,T,U)=vapp(V,W)).