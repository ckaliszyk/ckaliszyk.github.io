fof(myForms, conjecture, ! [A4] : ! [B4] : ! [C4] : ~ vempty=vbind(A4,B4,C4)).
fof(myForms, conjecture, ! [T6] : ! [U6] : ! [V6] : ~ vempty=vbind(T6,U6,V6)).