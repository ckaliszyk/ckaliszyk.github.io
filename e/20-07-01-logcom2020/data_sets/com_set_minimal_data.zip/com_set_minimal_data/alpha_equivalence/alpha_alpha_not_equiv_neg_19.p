fof(myForms, conjecture, ! [V] : ! [W] : (equalish(V,W) => equalish(W,V))).
fof(myForms, conjecture, ! [Z] : (program_decides(Z) <=> ! [A1] : (program(A1) => ! [B1] : decides(Z,A1,B1)))).