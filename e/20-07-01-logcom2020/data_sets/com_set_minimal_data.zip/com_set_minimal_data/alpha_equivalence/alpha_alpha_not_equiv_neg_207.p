fof(myForms, conjecture, ! [V] : ! [W] : (equalish(V,W) => equalish(W,V))).
fof(myForms, conjecture, ! [K] : ! [Q] : ! [I] : ! [S] : (vgensym(vapp(vapp(K,Q),vvar(I)))=S => ~ S=I)).