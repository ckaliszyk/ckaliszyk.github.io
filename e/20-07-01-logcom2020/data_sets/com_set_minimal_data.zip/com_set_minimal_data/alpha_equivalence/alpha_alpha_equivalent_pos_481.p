fof(myForms, conjecture, ! [K] : valphaEquivalent(K,K)).
fof(myForms, conjecture, ! [X1] : valphaEquivalent(X1,X1)).