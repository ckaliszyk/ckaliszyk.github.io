fof(myForms, conjecture, (sdtmndtplgtdt0(xa,xR,xb) & sdtmndtplgtdt0(xa,xR,xc))).
fof(myForms, conjecture, (sdtmndtplgtdt0(xa,xR,xb) & sdtmndtplgtdt0(xa,xR,xc))).