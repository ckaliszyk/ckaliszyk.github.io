fof(myForms, conjecture, ! [V] : ! [W] : (equalish(V,W) => equalish(W,V))).
fof(myForms, conjecture, ! [I] : ! [L1] : (vvar(I)=L1 => ~ visValue(L1))).