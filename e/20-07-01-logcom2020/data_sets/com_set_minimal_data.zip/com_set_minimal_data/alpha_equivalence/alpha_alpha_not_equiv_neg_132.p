fof(myForms, conjecture, ! [V] : ! [W] : (equalish(V,W) => equalish(W,V))).
fof(myForms, conjecture, ! [K] : ! [T1] : (vsomeType(K)=T1 => visSomeType(T1))).