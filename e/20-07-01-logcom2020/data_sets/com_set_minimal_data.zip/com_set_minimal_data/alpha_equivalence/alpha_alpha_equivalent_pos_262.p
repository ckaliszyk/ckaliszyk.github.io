fof(myForms, conjecture, ((aElement0(xv) & aReductOfIn0(xv,xa,xR)) & sdtmndtasgtdt0(xv,xR,xc))).
fof(myForms, conjecture, ((aElement0(xv) & aReductOfIn0(xv,xa,xR)) & sdtmndtasgtdt0(xv,xR,xc))).