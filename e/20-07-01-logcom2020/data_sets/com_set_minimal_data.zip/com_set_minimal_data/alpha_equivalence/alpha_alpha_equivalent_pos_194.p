fof(myForms, conjecture, ! [J5] : ~ vnoType=vsomeType(J5)).
fof(myForms, conjecture, ! [N3] : ~ vnoType=vsomeType(N3)).