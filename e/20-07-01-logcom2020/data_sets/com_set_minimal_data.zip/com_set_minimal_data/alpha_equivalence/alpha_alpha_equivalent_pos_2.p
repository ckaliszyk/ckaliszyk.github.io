fof(myForms, conjecture, ! [C9] : ! [D9] : (equalish(C9,D9) => equalish(D9,C9))).
fof(myForms, conjecture, ! [V] : ! [W] : (equalish(V,W) => equalish(W,V))).