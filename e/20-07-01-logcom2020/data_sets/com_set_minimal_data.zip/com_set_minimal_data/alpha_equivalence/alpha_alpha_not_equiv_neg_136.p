fof(myForms, conjecture, ! [V] : ! [W] : (equalish(V,W) => equalish(W,V))).
fof(myForms, conjecture, ! [V] : ((transitive_reflexive_rewrite(b,V) & transitive_reflexive_rewrite(c,V)) => goal)).