fof(myForms, conjecture, ! [V] : ! [W] : (equalish(V,W) => equalish(W,V))).
fof(myForms, conjecture, ! [I1] : ! [K1] : ! [R1] : ~ vempty=vbind(I1,K1,R1)).