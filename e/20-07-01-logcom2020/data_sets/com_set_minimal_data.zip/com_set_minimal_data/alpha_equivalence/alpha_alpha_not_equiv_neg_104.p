fof(myForms, conjecture, ! [V] : ! [W] : (equalish(V,W) => equalish(W,V))).
fof(myForms, conjecture, ? [B] : ((aElement0(B) & sdtmndtasgtdt0(xb,xR,B)) & sdtmndtasgtdt0(xd,xR,B))).