fof(myForms, conjecture, ! [V] : ! [W] : (rewrite(V,W) => transitive_reflexive_rewrite(V,W))).
fof(myForms, conjecture, ! [U3] : ! [V3] : (rewrite(U3,V3) => transitive_reflexive_rewrite(U3,V3))).