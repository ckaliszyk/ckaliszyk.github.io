fof(myForms, conjecture, goal).
fof(myForms, conjecture, goal).