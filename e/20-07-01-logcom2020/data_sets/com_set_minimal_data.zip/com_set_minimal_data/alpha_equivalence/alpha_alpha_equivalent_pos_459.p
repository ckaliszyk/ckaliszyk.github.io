fof(myForms, conjecture, (transitive_reflexive_rewrite(a,b) & transitive_reflexive_rewrite(a,c))).
fof(myForms, conjecture, (transitive_reflexive_rewrite(a,b) & transitive_reflexive_rewrite(a,c))).