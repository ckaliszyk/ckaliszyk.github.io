fof(myForms, conjecture, ~ (? [Z] : algorithm_program_decides(Z))).
fof(myForms, conjecture, ~ (? [E7] : algorithm_program_decides(E7))).