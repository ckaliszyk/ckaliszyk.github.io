fof(myForms, conjecture, ! [T] : ! [Q] : (valphaEquivalent(Q,T) => valphaEquivalent(T,Q))).
fof(myForms, conjecture, ! [G5] : ! [H5] : (valphaEquivalent(H5,G5) => valphaEquivalent(G5,H5))).