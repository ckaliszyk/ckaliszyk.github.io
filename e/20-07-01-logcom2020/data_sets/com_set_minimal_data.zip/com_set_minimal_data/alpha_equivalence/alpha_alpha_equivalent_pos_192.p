fof(myForms, conjecture, ! [K1] : ~ vnoType=vsomeType(K1)).
fof(myForms, conjecture, ! [J5] : ~ vnoType=vsomeType(J5)).