fof(myForms, conjecture, ! [V] : ! [W] : (equalish(V,W) => equalish(W,V))).
fof(myForms, conjecture, ! [V] : ! [W] : (reflexive_rewrite(V,W) => (W=V | rewrite(V,W)))).