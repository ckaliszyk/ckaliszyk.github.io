fof(myForms, conjecture, ! [V] : ((reflexive_rewrite(b,V) & reflexive_rewrite(c,V)) => goal)).
fof(myForms, conjecture, ! [A] : ((reflexive_rewrite(b,A) & reflexive_rewrite(c,A)) => goal)).