fof(myForms, conjecture, ! [I6] : ! [J6] : ! [K6] : ! [L6] : (vabs(I6,J6,K6)=L6 => visValue(L6))).
fof(myForms, conjecture, ! [H4] : ! [I4] : ! [J4] : ! [K4] : (vabs(H4,I4,J4)=K4 => visValue(K4))).