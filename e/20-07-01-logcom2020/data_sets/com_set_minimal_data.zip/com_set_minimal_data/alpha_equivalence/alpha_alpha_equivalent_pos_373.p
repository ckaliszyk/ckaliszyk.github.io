fof(myForms, conjecture, ! [V] : ! [W] : (W=V => transitive_reflexive_rewrite(V,W))).
fof(myForms, conjecture, ! [T] : ! [U] : (U=T => transitive_reflexive_rewrite(T,U))).