fof(myForms, conjecture, ! [V] : ! [W] : (equalish(V,W) => equalish(W,V))).
fof(myForms, conjecture, ! [B] : ! [C] : ((aElement0(B) & aElement0(C)) => (iLess0(B,C) => $true))).