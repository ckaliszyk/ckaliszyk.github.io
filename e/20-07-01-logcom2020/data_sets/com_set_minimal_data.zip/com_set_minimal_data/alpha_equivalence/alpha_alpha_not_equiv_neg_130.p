fof(myForms, conjecture, ! [V] : ! [W] : (equalish(V,W) => equalish(W,V))).
fof(myForms, conjecture, ? [B] : ((aElement0(B) & sdtmndtasgtdt0(xu,xR,B)) & sdtmndtasgtdt0(xv,xR,B))).