fof(myForms, conjecture, sdtmndtasgtdt0(xb,xR,xd)).
fof(myForms, conjecture, sdtmndtasgtdt0(xb,xR,xd)).