fof(myForms, conjecture, ! [Q1] : ! [K] : (vgensym(K)=Q1 => ~ visFreeVar(Q1,K))).
fof(myForms, conjecture, ! [G] : ! [H] : (vgensym(H)=G => ~ visFreeVar(G,H))).