fof(myForms, conjecture, ! [V] : ! [W] : (W=V => transitive_reflexive_rewrite(V,W))).
fof(myForms, conjecture, ! [E8] : ! [F8] : (F8=E8 => transitive_reflexive_rewrite(E8,F8))).