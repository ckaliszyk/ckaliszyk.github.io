fof(myForms, conjecture, ! [E1] : valphaEquivalent(E1,E1)).
fof(myForms, conjecture, ! [X1] : valphaEquivalent(X1,X1)).