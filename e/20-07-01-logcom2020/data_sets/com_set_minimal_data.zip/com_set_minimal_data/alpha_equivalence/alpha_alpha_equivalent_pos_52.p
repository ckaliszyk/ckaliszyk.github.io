fof(myForms, conjecture, ! [V] : ! [W] : (rewrite(V,W) => reflexive_rewrite(V,W))).
fof(myForms, conjecture, ! [Q] : ! [R] : (rewrite(Q,R) => reflexive_rewrite(Q,R))).