fof(myForms, conjecture, ! [I] : ! [M] : ! [K] : ! [L1] : (vabs(I,M,K)=L1 => visValue(L1))).
fof(myForms, conjecture, ! [I6] : ! [J6] : ! [K6] : ! [L6] : (vabs(I6,J6,K6)=L6 => visValue(L6))).