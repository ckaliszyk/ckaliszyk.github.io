fof(myForms, conjecture, ! [V] : ! [W] : (equalish(V,W) => reflexive_rewrite(V,W))).
fof(myForms, conjecture, ! [Q7] : ! [R7] : (equalish(Q7,R7) => reflexive_rewrite(Q7,R7))).