fof(myForms, conjecture, ! [V] : ! [W] : (equalish(V,W) => equalish(W,V))).
fof(myForms, conjecture, ! [V] : ! [W] : ! [X] : ((rewrite(V,W) & rewrite(V,X)) => ? [Y] : (rewrite(W,Y) & rewrite(X,Y)))).