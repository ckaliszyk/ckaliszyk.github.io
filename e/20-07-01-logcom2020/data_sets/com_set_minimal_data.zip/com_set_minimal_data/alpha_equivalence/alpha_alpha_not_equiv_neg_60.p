fof(myForms, conjecture, ! [V] : ! [W] : (equalish(V,W) => equalish(W,V))).
fof(myForms, conjecture, ! [L] : ((vtcheck(vempty,ve1,L) & ~ visValue(ve1)) => ? [N] : vreduce(ve1)=vsomeExp(N))).