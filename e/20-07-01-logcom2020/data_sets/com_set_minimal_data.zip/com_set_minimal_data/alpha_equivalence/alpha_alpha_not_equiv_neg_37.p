fof(myForms, conjecture, ! [V] : ! [W] : (equalish(V,W) => equalish(W,V))).
fof(myForms, conjecture, ! [V] : ! [W] : (equalish(V,W) => transitive_reflexive_rewrite(V,W))).