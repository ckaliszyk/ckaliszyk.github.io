fof(myForms, conjecture, ! [B] : (aRewritingSystem0(B) => $true)).
fof(myForms, conjecture, ! [I1] : (aRewritingSystem0(I1) => $true)).