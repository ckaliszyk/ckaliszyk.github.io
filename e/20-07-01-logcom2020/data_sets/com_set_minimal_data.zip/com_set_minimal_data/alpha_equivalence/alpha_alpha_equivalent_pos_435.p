fof(myForms, conjecture, ! [T1] : (vnoType=T1 => ~ visSomeType(T1))).
fof(myForms, conjecture, ! [Z7] : (vnoType=Z7 => ~ visSomeType(Z7))).