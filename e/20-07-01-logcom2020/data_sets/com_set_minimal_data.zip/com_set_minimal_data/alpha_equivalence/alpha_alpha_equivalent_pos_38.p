fof(myForms, conjecture, ? [V7] : aNormalFormOfIn0(V7,xw,xR)).
fof(myForms, conjecture, ? [Y2] : aNormalFormOfIn0(Y2,xw,xR)).