fof(myForms, conjecture, ! [V] : ! [W] : (W=V => reflexive_rewrite(V,W))).
fof(myForms, conjecture, ! [P7] : ! [Q7] : (Q7=P7 => reflexive_rewrite(P7,Q7))).