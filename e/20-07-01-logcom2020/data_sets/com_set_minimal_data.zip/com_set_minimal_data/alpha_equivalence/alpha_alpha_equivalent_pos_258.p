fof(myForms, conjecture, ((vnoType=vnoType => $true) & ($true => vnoType=vnoType))).
fof(myForms, conjecture, ((vnoType=vnoType => $true) & ($true => vnoType=vnoType))).