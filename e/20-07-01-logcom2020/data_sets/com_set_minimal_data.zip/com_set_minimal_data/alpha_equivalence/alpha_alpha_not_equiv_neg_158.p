fof(myForms, conjecture, ! [V] : ! [W] : (equalish(V,W) => equalish(W,V))).
fof(myForms, conjecture, ! [T1] : (vnoType=T1 => ~ visSomeType(T1))).