fof(myForms, conjecture, ! [V] : ! [W] : (equalish(V,W) => equalish(W,V))).
fof(myForms, conjecture, ! [J] : ! [I] : ! [L] : (vlookup(I,J)=vsomeType(L) => vtcheck(J,vvar(I),L))).