fof(myForms, conjecture, ! [V] : ! [W] : (equalish(V,W) => equalish(W,V))).
fof(myForms, conjecture, ! [I] : ! [M] : ! [K] : ! [L1] : (vabs(I,M,K)=L1 => visValue(L1))).