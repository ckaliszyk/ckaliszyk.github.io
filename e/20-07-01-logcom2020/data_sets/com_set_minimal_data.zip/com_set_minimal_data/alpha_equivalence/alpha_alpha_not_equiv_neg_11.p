fof(myForms, conjecture, ! [V] : ! [W] : (equalish(V,W) => equalish(W,V))).
fof(myForms, conjecture, ? [B] : aNormalFormOfIn0(B,xw,xR)).