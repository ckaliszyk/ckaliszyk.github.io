fof(myForms, conjecture, ! [I] : ! [M] : ! [K] : ! [L1] : (vabs(I,M,K)=L1 => visValue(L1))).
fof(myForms, conjecture, ! [H4] : ! [I4] : ! [J4] : ! [K4] : (vabs(H4,I4,J4)=K4 => visValue(K4))).