fof(myForms, conjecture, ! [Q] : ! [T] : ! [L1] : (vapp(Q,T)=L1 => ~ visValue(L1))).
fof(myForms, conjecture, ! [L3] : ! [M3] : ! [N3] : (vapp(L3,M3)=N3 => ~ visValue(N3))).