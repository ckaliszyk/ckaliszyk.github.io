fof(myForms, conjecture, ! [A9] : ! [B9] : (equalish(A9,B9) => equalish(B9,A9))).
fof(myForms, conjecture, ! [F2] : ! [G2] : (equalish(F2,G2) => equalish(G2,F2))).