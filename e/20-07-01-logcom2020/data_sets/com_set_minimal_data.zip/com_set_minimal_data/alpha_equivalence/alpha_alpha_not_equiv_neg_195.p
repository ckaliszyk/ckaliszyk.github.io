fof(myForms, conjecture, ! [V] : ! [W] : (equalish(V,W) => equalish(W,V))).
fof(myForms, conjecture, ! [T] : ! [Q] : (valphaEquivalent(Q,T) => valphaEquivalent(T,Q))).