fof(myForms, conjecture, isConfluent0(xR)).
fof(myForms, conjecture, isConfluent0(xR)).