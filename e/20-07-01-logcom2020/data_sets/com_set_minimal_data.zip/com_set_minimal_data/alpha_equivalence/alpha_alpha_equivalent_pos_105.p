fof(myForms, conjecture, (aRewritingSystem0(xR) & isTerminating0(xR))).
fof(myForms, conjecture, (aRewritingSystem0(xR) & isTerminating0(xR))).