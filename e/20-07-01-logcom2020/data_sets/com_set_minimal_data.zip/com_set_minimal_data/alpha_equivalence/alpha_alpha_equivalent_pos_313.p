fof(myForms, conjecture, ((aElement0(xa) & aElement0(xb)) & aElement0(xc))).
fof(myForms, conjecture, ((aElement0(xa) & aElement0(xb)) & aElement0(xc))).