fof(myForms, conjecture, ! [L] : ! [J] : ! [I] : ! [K] : ! [R] : ((vtcheck(J,K,L) & vtcheck(vbind(I,L,J),ve1,R)) => vtcheck(J,vsubst(I,K,ve1),R))).
fof(myForms, conjecture, sdtmndtasgtdt0(xb,xR,xd)).