fof(myForms, conjecture, ! [D3] : ! [E3] : (rewrite(D3,E3) => reflexive_rewrite(D3,E3))).
fof(myForms, conjecture, ! [Q] : ! [R] : (rewrite(Q,R) => reflexive_rewrite(Q,R))).