fof(myForms, conjecture, ! [U2] : (aElement0(U2) => $true)).
fof(myForms, conjecture, ! [U5] : (aElement0(U5) => $true)).