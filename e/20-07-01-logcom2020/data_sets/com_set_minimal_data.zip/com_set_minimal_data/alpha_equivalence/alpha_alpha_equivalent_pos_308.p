fof(myForms, conjecture, ~ (? [Z9] : algorithm_program_decides(Z9))).
fof(myForms, conjecture, ~ (? [E7] : algorithm_program_decides(E7))).