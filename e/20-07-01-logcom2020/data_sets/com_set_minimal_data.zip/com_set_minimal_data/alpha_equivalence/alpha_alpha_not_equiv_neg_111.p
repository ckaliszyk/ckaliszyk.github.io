fof(myForms, conjecture, ! [V] : ! [W] : (equalish(V,W) => equalish(W,V))).
fof(myForms, conjecture, ! [Z] : ! [A1] : (program_halts2(Z,A1) <=> (program(Z) & halts2(Z,A1)))).