fof(myForms, conjecture, ! [L3] : ! [M3] : ! [N3] : (vapp(L3,M3)=N3 => ~ visValue(N3))).
fof(myForms, conjecture, ! [D1] : ! [E1] : ! [F1] : (vapp(D1,E1)=F1 => ~ visValue(F1))).