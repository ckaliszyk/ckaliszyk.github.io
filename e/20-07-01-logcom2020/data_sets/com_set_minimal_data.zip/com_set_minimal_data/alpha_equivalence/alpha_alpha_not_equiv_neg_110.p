fof(myForms, conjecture, ! [V] : ! [W] : (equalish(V,W) => equalish(W,V))).
fof(myForms, conjecture, ~ (? [Z] : algorithm_program_decides(Z))).