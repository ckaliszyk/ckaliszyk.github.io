fof(myForms, conjecture, ! [Q7] : ! [R7] : (equalish(Q7,R7) => reflexive_rewrite(Q7,R7))).
fof(myForms, conjecture, ! [X7] : ! [Y7] : (equalish(X7,Y7) => reflexive_rewrite(X7,Y7))).