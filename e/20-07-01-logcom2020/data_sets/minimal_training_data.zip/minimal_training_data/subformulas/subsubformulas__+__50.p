fof(myForms, conjecture, ~ in(I,F)).
fof(myForms, conjecture, in(I,F)).