fof(myForms, conjecture, (ilf_type(R,set_type) => ! [S] : (ilf_type(S,relation_type(R,I)) => ilf_type(restrict4(R,I,B,S),relation_type(R,B))))).
fof(myForms, conjecture, ilf_type(R,set_type)).
fof(myForms, conjecture, ! [S] : (ilf_type(S,relation_type(R,I)) => ilf_type(restrict4(R,I,B,S),relation_type(R,B)))).
fof(myForms, conjecture, (ilf_type(S,relation_type(R,I)) => ilf_type(restrict4(R,I,B,S),relation_type(R,B)))).
fof(myForms, conjecture, ilf_type(S,relation_type(R,I))).
fof(myForms, conjecture, ilf_type(restrict4(R,I,B,S),relation_type(R,B))).