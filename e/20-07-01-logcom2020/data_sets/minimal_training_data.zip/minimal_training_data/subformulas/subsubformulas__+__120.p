fof(myForms, conjecture, (disjoint(I,B) <=> ~ intersect(I,B))).
fof(myForms, conjecture, disjoint(I,B)).
fof(myForms, conjecture, ~ intersect(I,B)).
fof(myForms, conjecture, intersect(I,B)).