fof(myForms, conjecture, ~ equal_set(F,B)).
fof(myForms, conjecture, equal_set(F,B)).