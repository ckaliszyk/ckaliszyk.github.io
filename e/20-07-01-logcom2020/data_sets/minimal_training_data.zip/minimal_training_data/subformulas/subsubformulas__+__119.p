fof(myForms, conjecture, ? [R] : (ilf_type(R,set_type) & ? [S] : (ilf_type(S,set_type) & ordered_pair(R,S)=B))).
fof(myForms, conjecture, (ilf_type(R,set_type) & ? [S] : (ilf_type(S,set_type) & ordered_pair(R,S)=B))).
fof(myForms, conjecture, ilf_type(R,set_type)).
fof(myForms, conjecture, ? [S] : (ilf_type(S,set_type) & ordered_pair(R,S)=B)).
fof(myForms, conjecture, (ilf_type(S,set_type) & ordered_pair(R,S)=B)).
fof(myForms, conjecture, ilf_type(S,set_type)).
fof(myForms, conjecture, ordered_pair(R,S)=B).