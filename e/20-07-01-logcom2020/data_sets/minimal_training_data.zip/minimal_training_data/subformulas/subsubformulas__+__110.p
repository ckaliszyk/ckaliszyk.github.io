fof(myForms, conjecture, ! [B] : difference(I,intersection(I,B))=difference(I,B)).
fof(myForms, conjecture, difference(I,intersection(I,B))=difference(I,B)).