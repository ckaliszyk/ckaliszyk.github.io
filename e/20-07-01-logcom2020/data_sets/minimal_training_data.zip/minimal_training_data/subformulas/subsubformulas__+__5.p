fof(myForms, conjecture, (member(I,R) & member(B,S))).
fof(myForms, conjecture, member(I,R)).
fof(myForms, conjecture, member(B,S)).