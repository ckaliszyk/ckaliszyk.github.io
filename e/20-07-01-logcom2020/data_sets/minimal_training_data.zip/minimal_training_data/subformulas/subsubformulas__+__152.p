fof(myForms, conjecture, (subset(F,I) & ~ equal_set(F,I))).
fof(myForms, conjecture, subset(F,I)).
fof(myForms, conjecture, ~ equal_set(F,I)).
fof(myForms, conjecture, equal_set(F,I)).