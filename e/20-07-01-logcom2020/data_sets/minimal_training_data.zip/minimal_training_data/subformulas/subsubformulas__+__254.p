fof(myForms, conjecture, (ilf_type(S,set_type) & ordered_pair(R,S)=B)).
fof(myForms, conjecture, ilf_type(S,set_type)).
fof(myForms, conjecture, ordered_pair(R,S)=B).