fof(myForms, conjecture, ? [R] : ilf_type(R,relation_type(B,I))).
fof(myForms, conjecture, ilf_type(R,relation_type(B,I))).