fof(myForms, conjecture, (ilf_type(B,set_type) => ! [R] : (ilf_type(R,relation_type(I,B)) => (subset(domain_of(R),I) & subset(range_of(R),B))))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ! [R] : (ilf_type(R,relation_type(I,B)) => (subset(domain_of(R),I) & subset(range_of(R),B)))).
fof(myForms, conjecture, (ilf_type(R,relation_type(I,B)) => (subset(domain_of(R),I) & subset(range_of(R),B)))).
fof(myForms, conjecture, ilf_type(R,relation_type(I,B))).
fof(myForms, conjecture, (subset(domain_of(R),I) & subset(range_of(R),B))).
fof(myForms, conjecture, subset(domain_of(R),I)).
fof(myForms, conjecture, subset(range_of(R),B)).