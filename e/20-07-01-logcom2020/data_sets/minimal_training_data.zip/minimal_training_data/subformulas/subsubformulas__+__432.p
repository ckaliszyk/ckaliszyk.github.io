fof(myForms, conjecture, ! [B] : (in(B,I) <=> F=B)).
fof(myForms, conjecture, (in(B,I) <=> F=B)).
fof(myForms, conjecture, in(B,I)).
fof(myForms, conjecture, F=B).