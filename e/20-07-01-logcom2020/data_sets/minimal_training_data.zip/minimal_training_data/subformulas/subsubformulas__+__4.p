fof(myForms, conjecture, ! [U] : (null_class=U | (? [W] : singleton(W)=U | ? [X] : (member(X,U) & ? [Y] : member(Y,intersection(complement(singleton(X)),U)))))).
fof(myForms, conjecture, (null_class=U | (? [W] : singleton(W)=U | ? [X] : (member(X,U) & ? [Y] : member(Y,intersection(complement(singleton(X)),U)))))).
fof(myForms, conjecture, null_class=U).
fof(myForms, conjecture, (? [W] : singleton(W)=U | ? [X] : (member(X,U) & ? [Y] : member(Y,intersection(complement(singleton(X)),U))))).
fof(myForms, conjecture, ? [W] : singleton(W)=U).
fof(myForms, conjecture, singleton(W)=U).
fof(myForms, conjecture, ? [X] : (member(X,U) & ? [Y] : member(Y,intersection(complement(singleton(X)),U)))).
fof(myForms, conjecture, (member(X,U) & ? [Y] : member(Y,intersection(complement(singleton(X)),U)))).
fof(myForms, conjecture, member(X,U)).
fof(myForms, conjecture, ? [Y] : member(Y,intersection(complement(singleton(X)),U))).
fof(myForms, conjecture, member(Y,intersection(complement(singleton(X)),U))).