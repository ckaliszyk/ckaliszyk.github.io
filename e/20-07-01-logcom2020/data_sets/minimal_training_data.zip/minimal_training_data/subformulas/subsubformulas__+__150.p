fof(myForms, conjecture, (ilf_type(B,set_type) => ! [R] : (ilf_type(R,relation_type(B,I)) => (ilf_type(R,relation_type(B,empty_set)) => empty_set=R)))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ! [R] : (ilf_type(R,relation_type(B,I)) => (ilf_type(R,relation_type(B,empty_set)) => empty_set=R))).
fof(myForms, conjecture, (ilf_type(R,relation_type(B,I)) => (ilf_type(R,relation_type(B,empty_set)) => empty_set=R))).
fof(myForms, conjecture, ilf_type(R,relation_type(B,I))).
fof(myForms, conjecture, (ilf_type(R,relation_type(B,empty_set)) => empty_set=R)).
fof(myForms, conjecture, ilf_type(R,relation_type(B,empty_set))).
fof(myForms, conjecture, empty_set=R).