fof(myForms, conjecture, (ilf_type(B,set_type) => relation_like(cross_product(I,B)))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, relation_like(cross_product(I,B))).