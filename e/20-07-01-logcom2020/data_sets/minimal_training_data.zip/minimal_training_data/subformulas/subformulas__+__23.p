fof(myForms, conjecture, ! [D] : ! [F] : ! [I] : (union(intersection(D,F),intersection(D,I))=D => subset(D,union(F,I)))).
fof(myForms, conjecture, ! [F] : ! [I] : (union(intersection(D,F),intersection(D,I))=D => subset(D,union(F,I)))).
fof(myForms, conjecture, ! [I] : (union(intersection(D,F),intersection(D,I))=D => subset(D,union(F,I)))).
fof(myForms, conjecture, (union(intersection(D,F),intersection(D,I))=D => subset(D,union(F,I)))).
fof(myForms, conjecture, union(intersection(D,F),intersection(D,I))=D).
fof(myForms, conjecture, subset(D,union(F,I))).