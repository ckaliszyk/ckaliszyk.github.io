fof(myForms, conjecture, (member(ordered_pair(R,S),D) => (member(R,I) & member(S,B)))).
fof(myForms, conjecture, member(ordered_pair(R,S),D)).
fof(myForms, conjecture, (member(R,I) & member(S,B))).
fof(myForms, conjecture, member(R,I)).
fof(myForms, conjecture, member(S,B)).