fof(myForms, conjecture, (ilf_type(B,set_type) => ! [R] : (ilf_type(R,relation_type(I,B)) => range(I,B,R)=range_of(R)))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ! [R] : (ilf_type(R,relation_type(I,B)) => range(I,B,R)=range_of(R))).
fof(myForms, conjecture, (ilf_type(R,relation_type(I,B)) => range(I,B,R)=range_of(R))).
fof(myForms, conjecture, ilf_type(R,relation_type(I,B))).
fof(myForms, conjecture, range(I,B,R)=range_of(R)).