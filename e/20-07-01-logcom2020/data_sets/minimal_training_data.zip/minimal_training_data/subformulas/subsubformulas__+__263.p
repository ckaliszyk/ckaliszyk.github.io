fof(myForms, conjecture, ? [Y] : member(Y,intersection(complement(singleton(X)),U))).
fof(myForms, conjecture, member(Y,intersection(complement(singleton(X)),U))).