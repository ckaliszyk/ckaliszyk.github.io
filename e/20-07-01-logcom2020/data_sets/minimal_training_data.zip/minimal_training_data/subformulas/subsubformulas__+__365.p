fof(myForms, conjecture, (ilf_type(B,set_type) => ~ member(B,I))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ~ member(B,I)).
fof(myForms, conjecture, member(B,I)).