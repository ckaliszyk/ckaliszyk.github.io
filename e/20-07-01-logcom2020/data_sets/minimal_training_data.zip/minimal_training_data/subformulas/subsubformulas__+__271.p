fof(myForms, conjecture, ! [F] : ! [I] : ~ empty(ordered_pair(F,I))).
fof(myForms, conjecture, ! [I] : ~ empty(ordered_pair(F,I))).
fof(myForms, conjecture, ~ empty(ordered_pair(F,I))).
fof(myForms, conjecture, empty(ordered_pair(F,I))).