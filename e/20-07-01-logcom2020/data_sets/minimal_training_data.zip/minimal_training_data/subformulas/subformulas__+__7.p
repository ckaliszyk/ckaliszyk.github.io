fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => (subset(D,empty_set) => empty_set=D))).
fof(myForms, conjecture, (ilf_type(D,set_type) => (subset(D,empty_set) => empty_set=D))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, (subset(D,empty_set) => empty_set=D)).
fof(myForms, conjecture, subset(D,empty_set)).
fof(myForms, conjecture, empty_set=D).