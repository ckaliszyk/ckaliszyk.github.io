fof(myForms, conjecture, (ilf_type(B,binary_relation_type) => (member(I,domain_of(B)) => ? [R] : (ilf_type(R,set_type) & member(R,range_of(B)))))).
fof(myForms, conjecture, ilf_type(B,binary_relation_type)).
fof(myForms, conjecture, (member(I,domain_of(B)) => ? [R] : (ilf_type(R,set_type) & member(R,range_of(B))))).
fof(myForms, conjecture, member(I,domain_of(B))).
fof(myForms, conjecture, ? [R] : (ilf_type(R,set_type) & member(R,range_of(B)))).
fof(myForms, conjecture, (ilf_type(R,set_type) & member(R,range_of(B)))).
fof(myForms, conjecture, ilf_type(R,set_type)).
fof(myForms, conjecture, member(R,range_of(B))).