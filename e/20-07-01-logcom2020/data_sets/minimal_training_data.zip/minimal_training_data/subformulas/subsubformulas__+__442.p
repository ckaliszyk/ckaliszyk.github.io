fof(myForms, conjecture, ! [R] : (ilf_type(R,subset_type(cross_product(I,B))) => ilf_type(R,relation_type(I,B)))).
fof(myForms, conjecture, (ilf_type(R,subset_type(cross_product(I,B))) => ilf_type(R,relation_type(I,B)))).
fof(myForms, conjecture, ilf_type(R,subset_type(cross_product(I,B)))).
fof(myForms, conjecture, ilf_type(R,relation_type(I,B))).