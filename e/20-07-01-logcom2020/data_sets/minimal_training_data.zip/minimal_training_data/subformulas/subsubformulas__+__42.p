fof(myForms, conjecture, (ilf_type(I,binary_relation_type) => ((empty_set=domain_of(I) | range_of(I)=empty_set) => empty_set=I))).
fof(myForms, conjecture, ilf_type(I,binary_relation_type)).
fof(myForms, conjecture, ((empty_set=domain_of(I) | range_of(I)=empty_set) => empty_set=I)).
fof(myForms, conjecture, (empty_set=domain_of(I) | range_of(I)=empty_set)).
fof(myForms, conjecture, empty_set=domain_of(I)).
fof(myForms, conjecture, range_of(I)=empty_set).
fof(myForms, conjecture, empty_set=I).