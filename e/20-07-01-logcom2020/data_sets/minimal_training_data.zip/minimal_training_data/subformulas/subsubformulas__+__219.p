fof(myForms, conjecture, ! [F] : ! [I] : set_intersection2(I,F)=set_intersection2(F,I)).
fof(myForms, conjecture, ! [I] : set_intersection2(I,F)=set_intersection2(F,I)).
fof(myForms, conjecture, set_intersection2(I,F)=set_intersection2(F,I)).