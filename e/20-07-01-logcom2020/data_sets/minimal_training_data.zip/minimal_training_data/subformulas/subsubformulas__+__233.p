fof(myForms, conjecture, ! [W] : (equalish(U,W) <=> equalish(W,U))).
fof(myForms, conjecture, (equalish(U,W) <=> equalish(W,U))).
fof(myForms, conjecture, equalish(U,W)).
fof(myForms, conjecture, equalish(W,U)).