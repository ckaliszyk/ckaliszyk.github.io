fof(myForms, conjecture, ! [R] : (in(R,B) <=> (in(R,F) & in(R,I)))).
fof(myForms, conjecture, (in(R,B) <=> (in(R,F) & in(R,I)))).
fof(myForms, conjecture, in(R,B)).
fof(myForms, conjecture, (in(R,F) & in(R,I))).
fof(myForms, conjecture, in(R,F)).
fof(myForms, conjecture, in(R,I)).