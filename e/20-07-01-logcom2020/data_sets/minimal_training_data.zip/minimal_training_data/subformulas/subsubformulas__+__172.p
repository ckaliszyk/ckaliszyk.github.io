fof(myForms, conjecture, ! [I] : (ilf_type(I,set_type) => ! [B] : (ilf_type(B,set_type) => ! [R] : (ilf_type(R,set_type) => ! [S] : (ilf_type(S,set_type) => ! [D] : (ilf_type(D,relation_type(I,B)) => (member(ordered_pair(R,S),D) => (member(R,I) & member(S,B))))))))).
fof(myForms, conjecture, (ilf_type(I,set_type) => ! [B] : (ilf_type(B,set_type) => ! [R] : (ilf_type(R,set_type) => ! [S] : (ilf_type(S,set_type) => ! [D] : (ilf_type(D,relation_type(I,B)) => (member(ordered_pair(R,S),D) => (member(R,I) & member(S,B))))))))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [B] : (ilf_type(B,set_type) => ! [R] : (ilf_type(R,set_type) => ! [S] : (ilf_type(S,set_type) => ! [D] : (ilf_type(D,relation_type(I,B)) => (member(ordered_pair(R,S),D) => (member(R,I) & member(S,B)))))))).
fof(myForms, conjecture, (ilf_type(B,set_type) => ! [R] : (ilf_type(R,set_type) => ! [S] : (ilf_type(S,set_type) => ! [D] : (ilf_type(D,relation_type(I,B)) => (member(ordered_pair(R,S),D) => (member(R,I) & member(S,B)))))))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ! [R] : (ilf_type(R,set_type) => ! [S] : (ilf_type(S,set_type) => ! [D] : (ilf_type(D,relation_type(I,B)) => (member(ordered_pair(R,S),D) => (member(R,I) & member(S,B))))))).
fof(myForms, conjecture, (ilf_type(R,set_type) => ! [S] : (ilf_type(S,set_type) => ! [D] : (ilf_type(D,relation_type(I,B)) => (member(ordered_pair(R,S),D) => (member(R,I) & member(S,B))))))).
fof(myForms, conjecture, ilf_type(R,set_type)).
fof(myForms, conjecture, ! [S] : (ilf_type(S,set_type) => ! [D] : (ilf_type(D,relation_type(I,B)) => (member(ordered_pair(R,S),D) => (member(R,I) & member(S,B)))))).
fof(myForms, conjecture, (ilf_type(S,set_type) => ! [D] : (ilf_type(D,relation_type(I,B)) => (member(ordered_pair(R,S),D) => (member(R,I) & member(S,B)))))).
fof(myForms, conjecture, ilf_type(S,set_type)).
fof(myForms, conjecture, ! [D] : (ilf_type(D,relation_type(I,B)) => (member(ordered_pair(R,S),D) => (member(R,I) & member(S,B))))).
fof(myForms, conjecture, (ilf_type(D,relation_type(I,B)) => (member(ordered_pair(R,S),D) => (member(R,I) & member(S,B))))).
fof(myForms, conjecture, ilf_type(D,relation_type(I,B))).
fof(myForms, conjecture, (member(ordered_pair(R,S),D) => (member(R,I) & member(S,B)))).
fof(myForms, conjecture, member(ordered_pair(R,S),D)).
fof(myForms, conjecture, (member(R,I) & member(S,B))).
fof(myForms, conjecture, member(R,I)).
fof(myForms, conjecture, member(S,B)).