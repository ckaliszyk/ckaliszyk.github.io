fof(myForms, conjecture, (ilf_type(R,relation_type(I,B)) => ilf_type(range(I,B,R),subset_type(B)))).
fof(myForms, conjecture, ilf_type(R,relation_type(I,B))).
fof(myForms, conjecture, ilf_type(range(I,B,R),subset_type(B))).