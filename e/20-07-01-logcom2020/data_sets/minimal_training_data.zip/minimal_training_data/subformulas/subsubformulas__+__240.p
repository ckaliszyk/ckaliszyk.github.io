fof(myForms, conjecture, (pre_order(A1,S) & subset(U,S))).
fof(myForms, conjecture, pre_order(A1,S)).
fof(myForms, conjecture, subset(U,S)).