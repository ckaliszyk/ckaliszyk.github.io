fof(myForms, conjecture, ! [I] : ! [B] : ! [R] : (member(R,union(I,B)) <=> (member(R,I) | member(R,B)))).
fof(myForms, conjecture, ! [B] : ! [R] : (member(R,union(I,B)) <=> (member(R,I) | member(R,B)))).
fof(myForms, conjecture, ! [R] : (member(R,union(I,B)) <=> (member(R,I) | member(R,B)))).
fof(myForms, conjecture, (member(R,union(I,B)) <=> (member(R,I) | member(R,B)))).
fof(myForms, conjecture, member(R,union(I,B))).
fof(myForms, conjecture, (member(R,I) | member(R,B))).
fof(myForms, conjecture, member(R,I)).
fof(myForms, conjecture, member(R,B)).