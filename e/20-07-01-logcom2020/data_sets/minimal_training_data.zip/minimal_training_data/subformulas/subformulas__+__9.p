fof(myForms, conjecture, ! [D] : (ilf_type(D,binary_relation_type) => ! [F] : (ilf_type(F,binary_relation_type) => (F=D <=> ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,set_type) => (member(ordered_pair(I,J),D) <=> member(ordered_pair(I,J),F)))))))).
fof(myForms, conjecture, (ilf_type(D,binary_relation_type) => ! [F] : (ilf_type(F,binary_relation_type) => (F=D <=> ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,set_type) => (member(ordered_pair(I,J),D) <=> member(ordered_pair(I,J),F)))))))).
fof(myForms, conjecture, ilf_type(D,binary_relation_type)).
fof(myForms, conjecture, ! [F] : (ilf_type(F,binary_relation_type) => (F=D <=> ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,set_type) => (member(ordered_pair(I,J),D) <=> member(ordered_pair(I,J),F))))))).
fof(myForms, conjecture, (ilf_type(F,binary_relation_type) => (F=D <=> ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,set_type) => (member(ordered_pair(I,J),D) <=> member(ordered_pair(I,J),F))))))).
fof(myForms, conjecture, ilf_type(F,binary_relation_type)).
fof(myForms, conjecture, (F=D <=> ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,set_type) => (member(ordered_pair(I,J),D) <=> member(ordered_pair(I,J),F)))))).
fof(myForms, conjecture, F=D).
fof(myForms, conjecture, ! [I] : (ilf_type(I,set_type) => ! [J] : (ilf_type(J,set_type) => (member(ordered_pair(I,J),D) <=> member(ordered_pair(I,J),F))))).
fof(myForms, conjecture, (ilf_type(I,set_type) => ! [J] : (ilf_type(J,set_type) => (member(ordered_pair(I,J),D) <=> member(ordered_pair(I,J),F))))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [J] : (ilf_type(J,set_type) => (member(ordered_pair(I,J),D) <=> member(ordered_pair(I,J),F)))).
fof(myForms, conjecture, (ilf_type(J,set_type) => (member(ordered_pair(I,J),D) <=> member(ordered_pair(I,J),F)))).
fof(myForms, conjecture, ilf_type(J,set_type)).
fof(myForms, conjecture, (member(ordered_pair(I,J),D) <=> member(ordered_pair(I,J),F))).
fof(myForms, conjecture, member(ordered_pair(I,J),D)).
fof(myForms, conjecture, member(ordered_pair(I,J),F)).