fof(myForms, conjecture, ((empty(I) & ilf_type(I,set_type)) => relation_like(I))).
fof(myForms, conjecture, (empty(I) & ilf_type(I,set_type))).
fof(myForms, conjecture, empty(I)).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, relation_like(I)).