fof(myForms, conjecture, ! [C] : ! [D] : (singleton(C)=D <=> ! [F] : (in(F,D) <=> F=C))).
fof(myForms, conjecture, ! [D] : (singleton(C)=D <=> ! [F] : (in(F,D) <=> F=C))).
fof(myForms, conjecture, (singleton(C)=D <=> ! [F] : (in(F,D) <=> F=C))).
fof(myForms, conjecture, singleton(C)=D).
fof(myForms, conjecture, ! [F] : (in(F,D) <=> F=C)).
fof(myForms, conjecture, (in(F,D) <=> F=C)).
fof(myForms, conjecture, in(F,D)).
fof(myForms, conjecture, F=C).