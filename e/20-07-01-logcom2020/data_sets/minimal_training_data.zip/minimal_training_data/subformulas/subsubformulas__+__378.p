fof(myForms, conjecture, (ilf_type(I,binary_relation_type) => ilf_type(range_of(I),set_type))).
fof(myForms, conjecture, ilf_type(I,binary_relation_type)).
fof(myForms, conjecture, ilf_type(range_of(I),set_type)).