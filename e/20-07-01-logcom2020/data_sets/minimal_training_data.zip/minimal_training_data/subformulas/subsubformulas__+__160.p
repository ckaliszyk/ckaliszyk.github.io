fof(myForms, conjecture, (in(ordered_pair(F,I),cartesian_product2(B,R)) <=> (in(F,B) & in(I,R)))).
fof(myForms, conjecture, in(ordered_pair(F,I),cartesian_product2(B,R))).
fof(myForms, conjecture, (in(F,B) & in(I,R))).
fof(myForms, conjecture, in(F,B)).
fof(myForms, conjecture, in(I,R)).