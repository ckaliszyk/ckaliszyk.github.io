fof(myForms, conjecture, ! [B] : ! [C] : ! [D] : (maps(B,C,D) => equal_set(image2(B,empty_set),empty_set))).
fof(myForms, conjecture, ! [C] : ! [D] : (maps(B,C,D) => equal_set(image2(B,empty_set),empty_set))).
fof(myForms, conjecture, ! [D] : (maps(B,C,D) => equal_set(image2(B,empty_set),empty_set))).
fof(myForms, conjecture, (maps(B,C,D) => equal_set(image2(B,empty_set),empty_set))).
fof(myForms, conjecture, maps(B,C,D)).
fof(myForms, conjecture, equal_set(image2(B,empty_set),empty_set)).