fof(myForms, conjecture, ! [I] : ! [B] : ! [R] : (member(R,intersection(I,B)) <=> (member(R,I) & member(R,B)))).
fof(myForms, conjecture, ! [B] : ! [R] : (member(R,intersection(I,B)) <=> (member(R,I) & member(R,B)))).
fof(myForms, conjecture, ! [R] : (member(R,intersection(I,B)) <=> (member(R,I) & member(R,B)))).
fof(myForms, conjecture, (member(R,intersection(I,B)) <=> (member(R,I) & member(R,B)))).
fof(myForms, conjecture, member(R,intersection(I,B))).
fof(myForms, conjecture, (member(R,I) & member(R,B))).
fof(myForms, conjecture, member(R,I)).
fof(myForms, conjecture, member(R,B)).