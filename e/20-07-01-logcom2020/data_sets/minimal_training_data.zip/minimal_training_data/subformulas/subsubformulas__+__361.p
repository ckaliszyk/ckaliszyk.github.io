fof(myForms, conjecture, (ilf_type(S,relation_type(R,I)) => ilf_type(restrict4(R,I,B,S),relation_type(R,B)))).
fof(myForms, conjecture, ilf_type(S,relation_type(R,I))).
fof(myForms, conjecture, ilf_type(restrict4(R,I,B,S),relation_type(R,B))).