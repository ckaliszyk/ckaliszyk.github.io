fof(myForms, conjecture, ! [B] : (I=B <=> (subset(I,B) & subset(B,I)))).
fof(myForms, conjecture, (I=B <=> (subset(I,B) & subset(B,I)))).
fof(myForms, conjecture, I=B).
fof(myForms, conjecture, (subset(I,B) & subset(B,I))).
fof(myForms, conjecture, subset(I,B)).
fof(myForms, conjecture, subset(B,I)).