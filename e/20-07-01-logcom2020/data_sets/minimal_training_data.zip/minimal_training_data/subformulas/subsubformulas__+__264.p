fof(myForms, conjecture, ! [I] : ~ member(I,empty_set)).
fof(myForms, conjecture, ~ member(I,empty_set)).
fof(myForms, conjecture, member(I,empty_set)).