fof(myForms, conjecture, ! [B] : ! [R] : (union(intersection(I,B),intersection(I,R))=I => subset(I,union(B,R)))).
fof(myForms, conjecture, ! [R] : (union(intersection(I,B),intersection(I,R))=I => subset(I,union(B,R)))).
fof(myForms, conjecture, (union(intersection(I,B),intersection(I,R))=I => subset(I,union(B,R)))).
fof(myForms, conjecture, union(intersection(I,B),intersection(I,R))=I).
fof(myForms, conjecture, subset(I,union(B,R))).