fof(myForms, conjecture, ! [B] : (ilf_type(B,set_type) => ilf_type(cross_product(I,B),set_type))).
fof(myForms, conjecture, (ilf_type(B,set_type) => ilf_type(cross_product(I,B),set_type))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ilf_type(cross_product(I,B),set_type)).