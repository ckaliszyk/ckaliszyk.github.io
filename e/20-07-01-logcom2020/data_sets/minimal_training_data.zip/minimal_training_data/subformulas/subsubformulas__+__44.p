fof(myForms, conjecture, (intersect(I,intersection(B,R)) => intersect(I,B))).
fof(myForms, conjecture, intersect(I,intersection(B,R))).
fof(myForms, conjecture, intersect(I,B)).