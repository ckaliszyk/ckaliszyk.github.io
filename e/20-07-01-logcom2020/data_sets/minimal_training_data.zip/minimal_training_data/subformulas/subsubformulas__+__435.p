fof(myForms, conjecture, (in(R,B) <=> (R=F | R=I))).
fof(myForms, conjecture, in(R,B)).
fof(myForms, conjecture, (R=F | R=I)).
fof(myForms, conjecture, R=F).
fof(myForms, conjecture, R=I).