fof(myForms, conjecture, ! [D] : ((~ empty(D) & ilf_type(D,set_type)) => ! [F] : ((~ empty(F) & ilf_type(F,set_type)) => ! [I] : (ilf_type(I,relation_type(D,F)) => ! [J] : (ilf_type(J,member_type(D)) => (member(J,domain(D,F,I)) => ? [B] : (ilf_type(B,member_type(F)) & member(B,range(D,F,I))))))))).
fof(myForms, conjecture, ((~ empty(D) & ilf_type(D,set_type)) => ! [F] : ((~ empty(F) & ilf_type(F,set_type)) => ! [I] : (ilf_type(I,relation_type(D,F)) => ! [J] : (ilf_type(J,member_type(D)) => (member(J,domain(D,F,I)) => ? [B] : (ilf_type(B,member_type(F)) & member(B,range(D,F,I))))))))).
fof(myForms, conjecture, (~ empty(D) & ilf_type(D,set_type))).
fof(myForms, conjecture, ~ empty(D)).
fof(myForms, conjecture, empty(D)).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, ! [F] : ((~ empty(F) & ilf_type(F,set_type)) => ! [I] : (ilf_type(I,relation_type(D,F)) => ! [J] : (ilf_type(J,member_type(D)) => (member(J,domain(D,F,I)) => ? [B] : (ilf_type(B,member_type(F)) & member(B,range(D,F,I)))))))).
fof(myForms, conjecture, ((~ empty(F) & ilf_type(F,set_type)) => ! [I] : (ilf_type(I,relation_type(D,F)) => ! [J] : (ilf_type(J,member_type(D)) => (member(J,domain(D,F,I)) => ? [B] : (ilf_type(B,member_type(F)) & member(B,range(D,F,I)))))))).
fof(myForms, conjecture, (~ empty(F) & ilf_type(F,set_type))).
fof(myForms, conjecture, ~ empty(F)).
fof(myForms, conjecture, empty(F)).
fof(myForms, conjecture, ilf_type(F,set_type)).
fof(myForms, conjecture, ! [I] : (ilf_type(I,relation_type(D,F)) => ! [J] : (ilf_type(J,member_type(D)) => (member(J,domain(D,F,I)) => ? [B] : (ilf_type(B,member_type(F)) & member(B,range(D,F,I))))))).
fof(myForms, conjecture, (ilf_type(I,relation_type(D,F)) => ! [J] : (ilf_type(J,member_type(D)) => (member(J,domain(D,F,I)) => ? [B] : (ilf_type(B,member_type(F)) & member(B,range(D,F,I))))))).
fof(myForms, conjecture, ilf_type(I,relation_type(D,F))).
fof(myForms, conjecture, ! [J] : (ilf_type(J,member_type(D)) => (member(J,domain(D,F,I)) => ? [B] : (ilf_type(B,member_type(F)) & member(B,range(D,F,I)))))).
fof(myForms, conjecture, (ilf_type(J,member_type(D)) => (member(J,domain(D,F,I)) => ? [B] : (ilf_type(B,member_type(F)) & member(B,range(D,F,I)))))).
fof(myForms, conjecture, ilf_type(J,member_type(D))).
fof(myForms, conjecture, (member(J,domain(D,F,I)) => ? [B] : (ilf_type(B,member_type(F)) & member(B,range(D,F,I))))).
fof(myForms, conjecture, member(J,domain(D,F,I))).
fof(myForms, conjecture, ? [B] : (ilf_type(B,member_type(F)) & member(B,range(D,F,I)))).
fof(myForms, conjecture, (ilf_type(B,member_type(F)) & member(B,range(D,F,I)))).
fof(myForms, conjecture, ilf_type(B,member_type(F))).
fof(myForms, conjecture, member(B,range(D,F,I))).