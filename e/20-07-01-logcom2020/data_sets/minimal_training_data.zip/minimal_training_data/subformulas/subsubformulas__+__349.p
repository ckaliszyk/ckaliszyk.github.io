fof(myForms, conjecture, ? [F] : empty(F)).
fof(myForms, conjecture, empty(F)).