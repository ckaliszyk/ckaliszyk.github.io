fof(myForms, conjecture, ((~ empty(I) & ilf_type(I,set_type)) => ! [B] : ((~ empty(B) & ilf_type(B,set_type)) => ! [R] : (ilf_type(R,relation_type(I,B)) => ! [S] : (ilf_type(S,member_type(I)) => (member(S,domain(I,B,R)) => ? [D] : (ilf_type(D,member_type(B)) & member(D,range(I,B,R))))))))).
fof(myForms, conjecture, (~ empty(I) & ilf_type(I,set_type))).
fof(myForms, conjecture, ~ empty(I)).
fof(myForms, conjecture, empty(I)).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [B] : ((~ empty(B) & ilf_type(B,set_type)) => ! [R] : (ilf_type(R,relation_type(I,B)) => ! [S] : (ilf_type(S,member_type(I)) => (member(S,domain(I,B,R)) => ? [D] : (ilf_type(D,member_type(B)) & member(D,range(I,B,R)))))))).
fof(myForms, conjecture, ((~ empty(B) & ilf_type(B,set_type)) => ! [R] : (ilf_type(R,relation_type(I,B)) => ! [S] : (ilf_type(S,member_type(I)) => (member(S,domain(I,B,R)) => ? [D] : (ilf_type(D,member_type(B)) & member(D,range(I,B,R)))))))).
fof(myForms, conjecture, (~ empty(B) & ilf_type(B,set_type))).
fof(myForms, conjecture, ~ empty(B)).
fof(myForms, conjecture, empty(B)).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ! [R] : (ilf_type(R,relation_type(I,B)) => ! [S] : (ilf_type(S,member_type(I)) => (member(S,domain(I,B,R)) => ? [D] : (ilf_type(D,member_type(B)) & member(D,range(I,B,R))))))).
fof(myForms, conjecture, (ilf_type(R,relation_type(I,B)) => ! [S] : (ilf_type(S,member_type(I)) => (member(S,domain(I,B,R)) => ? [D] : (ilf_type(D,member_type(B)) & member(D,range(I,B,R))))))).
fof(myForms, conjecture, ilf_type(R,relation_type(I,B))).
fof(myForms, conjecture, ! [S] : (ilf_type(S,member_type(I)) => (member(S,domain(I,B,R)) => ? [D] : (ilf_type(D,member_type(B)) & member(D,range(I,B,R)))))).
fof(myForms, conjecture, (ilf_type(S,member_type(I)) => (member(S,domain(I,B,R)) => ? [D] : (ilf_type(D,member_type(B)) & member(D,range(I,B,R)))))).
fof(myForms, conjecture, ilf_type(S,member_type(I))).
fof(myForms, conjecture, (member(S,domain(I,B,R)) => ? [D] : (ilf_type(D,member_type(B)) & member(D,range(I,B,R))))).
fof(myForms, conjecture, member(S,domain(I,B,R))).
fof(myForms, conjecture, ? [D] : (ilf_type(D,member_type(B)) & member(D,range(I,B,R)))).
fof(myForms, conjecture, (ilf_type(D,member_type(B)) & member(D,range(I,B,R)))).
fof(myForms, conjecture, ilf_type(D,member_type(B))).
fof(myForms, conjecture, member(D,range(I,B,R))).