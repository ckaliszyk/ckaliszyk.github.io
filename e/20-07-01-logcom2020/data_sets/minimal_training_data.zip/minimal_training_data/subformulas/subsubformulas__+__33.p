fof(myForms, conjecture, ! [I] : (union(F)=I <=> ! [B] : (in(B,I) <=> ? [R] : (in(B,R) & in(R,F))))).
fof(myForms, conjecture, (union(F)=I <=> ! [B] : (in(B,I) <=> ? [R] : (in(B,R) & in(R,F))))).
fof(myForms, conjecture, union(F)=I).
fof(myForms, conjecture, ! [B] : (in(B,I) <=> ? [R] : (in(B,R) & in(R,F)))).
fof(myForms, conjecture, (in(B,I) <=> ? [R] : (in(B,R) & in(R,F)))).
fof(myForms, conjecture, in(B,I)).
fof(myForms, conjecture, ? [R] : (in(B,R) & in(R,F))).
fof(myForms, conjecture, (in(B,R) & in(R,F))).
fof(myForms, conjecture, in(B,R)).
fof(myForms, conjecture, in(R,F)).