fof(myForms, conjecture, (in(F,B) & in(I,R))).
fof(myForms, conjecture, in(F,B)).
fof(myForms, conjecture, in(I,R)).