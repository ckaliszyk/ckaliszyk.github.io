fof(myForms, conjecture, (ilf_type(S,relation_type(I,B)) => ilf_type(S,subset_type(cross_product(I,B))))).
fof(myForms, conjecture, ilf_type(S,relation_type(I,B))).
fof(myForms, conjecture, ilf_type(S,subset_type(cross_product(I,B)))).