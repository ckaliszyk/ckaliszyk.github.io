fof(myForms, conjecture, ! [B] : (intersect(I,B) => intersect(B,I))).
fof(myForms, conjecture, (intersect(I,B) => intersect(B,I))).
fof(myForms, conjecture, intersect(I,B)).
fof(myForms, conjecture, intersect(B,I)).