fof(myForms, conjecture, ! [D] : ! [F] : union(difference(D,F),difference(F,D))=symmetric_difference(D,F)).
fof(myForms, conjecture, ! [F] : union(difference(D,F),difference(F,D))=symmetric_difference(D,F)).
fof(myForms, conjecture, union(difference(D,F),difference(F,D))=symmetric_difference(D,F)).