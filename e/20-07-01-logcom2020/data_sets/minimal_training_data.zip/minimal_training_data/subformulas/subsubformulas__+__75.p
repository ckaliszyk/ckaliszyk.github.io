fof(myForms, conjecture, ~ empty(F)).
fof(myForms, conjecture, empty(F)).