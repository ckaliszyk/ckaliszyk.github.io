fof(myForms, conjecture, (ilf_type(B,set_type) => ! [R] : (ilf_type(R,relation_type(I,B)) => domain(I,B,R)=domain_of(R)))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ! [R] : (ilf_type(R,relation_type(I,B)) => domain(I,B,R)=domain_of(R))).
fof(myForms, conjecture, (ilf_type(R,relation_type(I,B)) => domain(I,B,R)=domain_of(R))).
fof(myForms, conjecture, ilf_type(R,relation_type(I,B))).
fof(myForms, conjecture, domain(I,B,R)=domain_of(R)).