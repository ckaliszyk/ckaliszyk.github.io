fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ~ member(D,empty_set))).
fof(myForms, conjecture, (ilf_type(D,set_type) => ~ member(D,empty_set))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, ~ member(D,empty_set)).
fof(myForms, conjecture, member(D,empty_set)).