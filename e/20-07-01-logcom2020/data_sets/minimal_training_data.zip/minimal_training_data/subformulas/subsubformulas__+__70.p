fof(myForms, conjecture, (ilf_type(I,set_type) => subset(I,I))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, subset(I,I)).