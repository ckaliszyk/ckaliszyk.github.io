fof(myForms, conjecture, ! [R] : (member(R,difference(I,B)) <=> (member(R,I) & ~ member(R,B)))).
fof(myForms, conjecture, (member(R,difference(I,B)) <=> (member(R,I) & ~ member(R,B)))).
fof(myForms, conjecture, member(R,difference(I,B))).
fof(myForms, conjecture, (member(R,I) & ~ member(R,B))).
fof(myForms, conjecture, member(R,I)).
fof(myForms, conjecture, ~ member(R,B)).
fof(myForms, conjecture, member(R,B)).