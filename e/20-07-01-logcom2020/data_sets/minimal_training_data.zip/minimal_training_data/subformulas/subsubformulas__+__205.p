fof(myForms, conjecture, ? [B] : ilf_type(B,subset_type(I))).
fof(myForms, conjecture, ilf_type(B,subset_type(I))).