fof(myForms, conjecture, ! [B] : (ilf_type(B,set_type) => ! [R] : (ilf_type(R,set_type) => ! [S] : (ilf_type(S,binary_relation_type) => (member(ordered_pair(B,R),restrict(I,S)) <=> (member(R,I) & member(ordered_pair(B,R),S))))))).
fof(myForms, conjecture, (ilf_type(B,set_type) => ! [R] : (ilf_type(R,set_type) => ! [S] : (ilf_type(S,binary_relation_type) => (member(ordered_pair(B,R),restrict(I,S)) <=> (member(R,I) & member(ordered_pair(B,R),S))))))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ! [R] : (ilf_type(R,set_type) => ! [S] : (ilf_type(S,binary_relation_type) => (member(ordered_pair(B,R),restrict(I,S)) <=> (member(R,I) & member(ordered_pair(B,R),S)))))).
fof(myForms, conjecture, (ilf_type(R,set_type) => ! [S] : (ilf_type(S,binary_relation_type) => (member(ordered_pair(B,R),restrict(I,S)) <=> (member(R,I) & member(ordered_pair(B,R),S)))))).
fof(myForms, conjecture, ilf_type(R,set_type)).
fof(myForms, conjecture, ! [S] : (ilf_type(S,binary_relation_type) => (member(ordered_pair(B,R),restrict(I,S)) <=> (member(R,I) & member(ordered_pair(B,R),S))))).
fof(myForms, conjecture, (ilf_type(S,binary_relation_type) => (member(ordered_pair(B,R),restrict(I,S)) <=> (member(R,I) & member(ordered_pair(B,R),S))))).
fof(myForms, conjecture, ilf_type(S,binary_relation_type)).
fof(myForms, conjecture, (member(ordered_pair(B,R),restrict(I,S)) <=> (member(R,I) & member(ordered_pair(B,R),S)))).
fof(myForms, conjecture, member(ordered_pair(B,R),restrict(I,S))).
fof(myForms, conjecture, (member(R,I) & member(ordered_pair(B,R),S))).
fof(myForms, conjecture, member(R,I)).
fof(myForms, conjecture, member(ordered_pair(B,R),S)).