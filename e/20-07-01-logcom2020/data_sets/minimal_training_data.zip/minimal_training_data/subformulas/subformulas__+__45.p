fof(myForms, conjecture, ! [C] : (empty_set=C <=> ! [D] : ~ in(D,C))).
fof(myForms, conjecture, (empty_set=C <=> ! [D] : ~ in(D,C))).
fof(myForms, conjecture, empty_set=C).
fof(myForms, conjecture, ! [D] : ~ in(D,C)).
fof(myForms, conjecture, ~ in(D,C)).
fof(myForms, conjecture, in(D,C)).