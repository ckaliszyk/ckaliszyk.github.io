fof(myForms, conjecture, ! [U] : ! [W] : (equalish(U,W) <=> ! [T] : (a_member_of(T,U) <=> a_member_of(T,W)))).
fof(myForms, conjecture, ! [W] : (equalish(U,W) <=> ! [T] : (a_member_of(T,U) <=> a_member_of(T,W)))).
fof(myForms, conjecture, (equalish(U,W) <=> ! [T] : (a_member_of(T,U) <=> a_member_of(T,W)))).
fof(myForms, conjecture, equalish(U,W)).
fof(myForms, conjecture, ! [T] : (a_member_of(T,U) <=> a_member_of(T,W))).
fof(myForms, conjecture, (a_member_of(T,U) <=> a_member_of(T,W))).
fof(myForms, conjecture, a_member_of(T,U)).
fof(myForms, conjecture, a_member_of(T,W)).