fof(myForms, conjecture, (ilf_type(I,set_type) => (relation_like(I) <=> ! [B] : (ilf_type(B,set_type) => (member(B,I) => ? [R] : (ilf_type(R,set_type) & ? [S] : (ilf_type(S,set_type) & ordered_pair(R,S)=B))))))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, (relation_like(I) <=> ! [B] : (ilf_type(B,set_type) => (member(B,I) => ? [R] : (ilf_type(R,set_type) & ? [S] : (ilf_type(S,set_type) & ordered_pair(R,S)=B)))))).
fof(myForms, conjecture, relation_like(I)).
fof(myForms, conjecture, ! [B] : (ilf_type(B,set_type) => (member(B,I) => ? [R] : (ilf_type(R,set_type) & ? [S] : (ilf_type(S,set_type) & ordered_pair(R,S)=B))))).
fof(myForms, conjecture, (ilf_type(B,set_type) => (member(B,I) => ? [R] : (ilf_type(R,set_type) & ? [S] : (ilf_type(S,set_type) & ordered_pair(R,S)=B))))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, (member(B,I) => ? [R] : (ilf_type(R,set_type) & ? [S] : (ilf_type(S,set_type) & ordered_pair(R,S)=B)))).
fof(myForms, conjecture, member(B,I)).
fof(myForms, conjecture, ? [R] : (ilf_type(R,set_type) & ? [S] : (ilf_type(S,set_type) & ordered_pair(R,S)=B))).
fof(myForms, conjecture, (ilf_type(R,set_type) & ? [S] : (ilf_type(S,set_type) & ordered_pair(R,S)=B))).
fof(myForms, conjecture, ilf_type(R,set_type)).
fof(myForms, conjecture, ? [S] : (ilf_type(S,set_type) & ordered_pair(R,S)=B)).
fof(myForms, conjecture, (ilf_type(S,set_type) & ordered_pair(R,S)=B)).
fof(myForms, conjecture, ilf_type(S,set_type)).
fof(myForms, conjecture, ordered_pair(R,S)=B).