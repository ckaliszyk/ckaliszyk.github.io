fof(myForms, conjecture, ! [D] : ! [F] : (subset(D,F) <=> ! [I] : (member(I,D) => member(I,F)))).
fof(myForms, conjecture, ! [F] : (subset(D,F) <=> ! [I] : (member(I,D) => member(I,F)))).
fof(myForms, conjecture, (subset(D,F) <=> ! [I] : (member(I,D) => member(I,F)))).
fof(myForms, conjecture, subset(D,F)).
fof(myForms, conjecture, ! [I] : (member(I,D) => member(I,F))).
fof(myForms, conjecture, (member(I,D) => member(I,F))).
fof(myForms, conjecture, member(I,D)).
fof(myForms, conjecture, member(I,F)).