fof(myForms, conjecture, (ilf_type(B,set_type) => (member(I,power_set(B)) <=> ! [R] : (ilf_type(R,set_type) => (member(R,I) => member(R,B)))))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, (member(I,power_set(B)) <=> ! [R] : (ilf_type(R,set_type) => (member(R,I) => member(R,B))))).
fof(myForms, conjecture, member(I,power_set(B))).
fof(myForms, conjecture, ! [R] : (ilf_type(R,set_type) => (member(R,I) => member(R,B)))).
fof(myForms, conjecture, (ilf_type(R,set_type) => (member(R,I) => member(R,B)))).
fof(myForms, conjecture, ilf_type(R,set_type)).
fof(myForms, conjecture, (member(R,I) => member(R,B))).
fof(myForms, conjecture, member(R,I)).
fof(myForms, conjecture, member(R,B)).