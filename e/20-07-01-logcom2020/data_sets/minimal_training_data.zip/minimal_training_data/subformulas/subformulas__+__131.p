fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ! [F] : (ilf_type(F,binary_relation_type) => ilf_type(restrict(D,F),binary_relation_type)))).
fof(myForms, conjecture, (ilf_type(D,set_type) => ! [F] : (ilf_type(F,binary_relation_type) => ilf_type(restrict(D,F),binary_relation_type)))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, ! [F] : (ilf_type(F,binary_relation_type) => ilf_type(restrict(D,F),binary_relation_type))).
fof(myForms, conjecture, (ilf_type(F,binary_relation_type) => ilf_type(restrict(D,F),binary_relation_type))).
fof(myForms, conjecture, ilf_type(F,binary_relation_type)).
fof(myForms, conjecture, ilf_type(restrict(D,F),binary_relation_type)).