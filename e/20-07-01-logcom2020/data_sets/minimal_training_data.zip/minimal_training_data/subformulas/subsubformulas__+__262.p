fof(myForms, conjecture, ~ member(T,U)).
fof(myForms, conjecture, member(T,U)).