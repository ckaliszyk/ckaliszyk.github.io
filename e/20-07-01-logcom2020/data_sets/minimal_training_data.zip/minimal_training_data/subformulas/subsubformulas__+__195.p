fof(myForms, conjecture, (ilf_type(S,set_type) => (member(ordered_pair(I,B),cross_product(R,S)) <=> (member(I,R) & member(B,S))))).
fof(myForms, conjecture, ilf_type(S,set_type)).
fof(myForms, conjecture, (member(ordered_pair(I,B),cross_product(R,S)) <=> (member(I,R) & member(B,S)))).
fof(myForms, conjecture, member(ordered_pair(I,B),cross_product(R,S))).
fof(myForms, conjecture, (member(I,R) & member(B,S))).
fof(myForms, conjecture, member(I,R)).
fof(myForms, conjecture, member(B,S)).