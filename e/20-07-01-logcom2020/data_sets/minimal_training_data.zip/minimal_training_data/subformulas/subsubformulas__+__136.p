fof(myForms, conjecture, (member(R,I) & member(S,B))).
fof(myForms, conjecture, member(R,I)).
fof(myForms, conjecture, member(S,B)).