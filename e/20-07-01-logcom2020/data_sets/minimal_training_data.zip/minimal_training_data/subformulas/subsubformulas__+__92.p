fof(myForms, conjecture, ! [R] : (ilf_type(R,set_type) => ! [S] : (ilf_type(S,set_type) => (member(ordered_pair(R,S),I) <=> member(ordered_pair(R,S),B))))).
fof(myForms, conjecture, (ilf_type(R,set_type) => ! [S] : (ilf_type(S,set_type) => (member(ordered_pair(R,S),I) <=> member(ordered_pair(R,S),B))))).
fof(myForms, conjecture, ilf_type(R,set_type)).
fof(myForms, conjecture, ! [S] : (ilf_type(S,set_type) => (member(ordered_pair(R,S),I) <=> member(ordered_pair(R,S),B)))).
fof(myForms, conjecture, (ilf_type(S,set_type) => (member(ordered_pair(R,S),I) <=> member(ordered_pair(R,S),B)))).
fof(myForms, conjecture, ilf_type(S,set_type)).
fof(myForms, conjecture, (member(ordered_pair(R,S),I) <=> member(ordered_pair(R,S),B))).
fof(myForms, conjecture, member(ordered_pair(R,S),I)).
fof(myForms, conjecture, member(ordered_pair(R,S),B)).