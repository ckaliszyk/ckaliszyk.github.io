fof(myForms, conjecture, (ilf_type(R,set_type) => ! [S] : (ilf_type(S,relation_type(I,B)) => restrict(R,S)=restrict4(I,B,R,S)))).
fof(myForms, conjecture, ilf_type(R,set_type)).
fof(myForms, conjecture, ! [S] : (ilf_type(S,relation_type(I,B)) => restrict(R,S)=restrict4(I,B,R,S))).
fof(myForms, conjecture, (ilf_type(S,relation_type(I,B)) => restrict(R,S)=restrict4(I,B,R,S))).
fof(myForms, conjecture, ilf_type(S,relation_type(I,B))).
fof(myForms, conjecture, restrict(R,S)=restrict4(I,B,R,S)).