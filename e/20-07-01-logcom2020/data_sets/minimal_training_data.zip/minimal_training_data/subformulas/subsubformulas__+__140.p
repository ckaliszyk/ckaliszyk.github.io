fof(myForms, conjecture, (member(ordered_pair(I,B),cross_product(R,S)) <=> (member(I,R) & member(B,S)))).
fof(myForms, conjecture, member(ordered_pair(I,B),cross_product(R,S))).
fof(myForms, conjecture, (member(I,R) & member(B,S))).
fof(myForms, conjecture, member(I,R)).
fof(myForms, conjecture, member(B,S)).