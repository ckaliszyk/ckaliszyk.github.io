fof(myForms, conjecture, ! [I] : difference(empty_set,I)=empty_set).
fof(myForms, conjecture, difference(empty_set,I)=empty_set).