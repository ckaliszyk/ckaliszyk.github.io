fof(myForms, conjecture, ! [C] : ! [D] : ! [F] : (unordered_pair(C,D)=F <=> ! [I] : (in(I,F) <=> (I=C | I=D)))).
fof(myForms, conjecture, ! [D] : ! [F] : (unordered_pair(C,D)=F <=> ! [I] : (in(I,F) <=> (I=C | I=D)))).
fof(myForms, conjecture, ! [F] : (unordered_pair(C,D)=F <=> ! [I] : (in(I,F) <=> (I=C | I=D)))).
fof(myForms, conjecture, (unordered_pair(C,D)=F <=> ! [I] : (in(I,F) <=> (I=C | I=D)))).
fof(myForms, conjecture, unordered_pair(C,D)=F).
fof(myForms, conjecture, ! [I] : (in(I,F) <=> (I=C | I=D))).
fof(myForms, conjecture, (in(I,F) <=> (I=C | I=D))).
fof(myForms, conjecture, in(I,F)).
fof(myForms, conjecture, (I=C | I=D)).
fof(myForms, conjecture, I=C).
fof(myForms, conjecture, I=D).