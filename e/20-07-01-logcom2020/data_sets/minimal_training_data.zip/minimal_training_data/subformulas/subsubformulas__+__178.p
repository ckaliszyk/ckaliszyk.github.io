fof(myForms, conjecture, ~ (((set_intersection2(unordered_pair(F,I),B)=singleton(F) & in(I,B)) & ~ I=F))).
fof(myForms, conjecture, ((set_intersection2(unordered_pair(F,I),B)=singleton(F) & in(I,B)) & ~ I=F)).
fof(myForms, conjecture, (set_intersection2(unordered_pair(F,I),B)=singleton(F) & in(I,B))).
fof(myForms, conjecture, set_intersection2(unordered_pair(F,I),B)=singleton(F)).
fof(myForms, conjecture, in(I,B)).
fof(myForms, conjecture, ~ I=F).
fof(myForms, conjecture, I=F).