fof(myForms, conjecture, (ilf_type(B,set_type) => (! [R] : (ilf_type(R,subset_type(cross_product(I,B))) => ilf_type(R,relation_type(I,B))) & ! [S] : (ilf_type(S,relation_type(I,B)) => ilf_type(S,subset_type(cross_product(I,B))))))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, (! [R] : (ilf_type(R,subset_type(cross_product(I,B))) => ilf_type(R,relation_type(I,B))) & ! [S] : (ilf_type(S,relation_type(I,B)) => ilf_type(S,subset_type(cross_product(I,B)))))).
fof(myForms, conjecture, ! [R] : (ilf_type(R,subset_type(cross_product(I,B))) => ilf_type(R,relation_type(I,B)))).
fof(myForms, conjecture, (ilf_type(R,subset_type(cross_product(I,B))) => ilf_type(R,relation_type(I,B)))).
fof(myForms, conjecture, ilf_type(R,subset_type(cross_product(I,B)))).
fof(myForms, conjecture, ilf_type(R,relation_type(I,B))).
fof(myForms, conjecture, ! [S] : (ilf_type(S,relation_type(I,B)) => ilf_type(S,subset_type(cross_product(I,B))))).
fof(myForms, conjecture, (ilf_type(S,relation_type(I,B)) => ilf_type(S,subset_type(cross_product(I,B))))).
fof(myForms, conjecture, ilf_type(S,relation_type(I,B))).
fof(myForms, conjecture, ilf_type(S,subset_type(cross_product(I,B)))).