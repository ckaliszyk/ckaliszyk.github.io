fof(myForms, conjecture, ! [C] : ! [D] : (union(C)=D <=> ! [F] : (in(F,D) <=> ? [I] : (in(F,I) & in(I,C))))).
fof(myForms, conjecture, ! [D] : (union(C)=D <=> ! [F] : (in(F,D) <=> ? [I] : (in(F,I) & in(I,C))))).
fof(myForms, conjecture, (union(C)=D <=> ! [F] : (in(F,D) <=> ? [I] : (in(F,I) & in(I,C))))).
fof(myForms, conjecture, union(C)=D).
fof(myForms, conjecture, ! [F] : (in(F,D) <=> ? [I] : (in(F,I) & in(I,C)))).
fof(myForms, conjecture, (in(F,D) <=> ? [I] : (in(F,I) & in(I,C)))).
fof(myForms, conjecture, in(F,D)).
fof(myForms, conjecture, ? [I] : (in(F,I) & in(I,C))).
fof(myForms, conjecture, (in(F,I) & in(I,C))).
fof(myForms, conjecture, in(F,I)).
fof(myForms, conjecture, in(I,C)).