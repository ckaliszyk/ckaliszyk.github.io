fof(myForms, conjecture, ? [X] : (member(X,U) & ? [Y] : member(Y,intersection(complement(singleton(X)),U)))).
fof(myForms, conjecture, (member(X,U) & ? [Y] : member(Y,intersection(complement(singleton(X)),U)))).
fof(myForms, conjecture, member(X,U)).
fof(myForms, conjecture, ? [Y] : member(Y,intersection(complement(singleton(X)),U))).
fof(myForms, conjecture, member(Y,intersection(complement(singleton(X)),U))).