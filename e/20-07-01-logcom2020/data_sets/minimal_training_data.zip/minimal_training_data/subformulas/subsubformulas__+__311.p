fof(myForms, conjecture, (ilf_type(I,member_type(B)) <=> member(I,B))).
fof(myForms, conjecture, ilf_type(I,member_type(B))).
fof(myForms, conjecture, member(I,B)).