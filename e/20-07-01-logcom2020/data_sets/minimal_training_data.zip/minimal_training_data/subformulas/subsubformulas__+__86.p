fof(myForms, conjecture, ! [I] : ! [B] : (I=B <=> ! [R] : (member(R,I) <=> member(R,B)))).
fof(myForms, conjecture, ! [B] : (I=B <=> ! [R] : (member(R,I) <=> member(R,B)))).
fof(myForms, conjecture, (I=B <=> ! [R] : (member(R,I) <=> member(R,B)))).
fof(myForms, conjecture, I=B).
fof(myForms, conjecture, ! [R] : (member(R,I) <=> member(R,B))).
fof(myForms, conjecture, (member(R,I) <=> member(R,B))).
fof(myForms, conjecture, member(R,I)).
fof(myForms, conjecture, member(R,B)).