fof(myForms, conjecture, ! [C] : ! [D] : set_intersection2(C,C)=C).
fof(myForms, conjecture, ! [D] : set_intersection2(C,C)=C).
fof(myForms, conjecture, set_intersection2(C,C)=C).