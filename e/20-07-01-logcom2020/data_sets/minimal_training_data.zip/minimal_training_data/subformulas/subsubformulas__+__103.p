fof(myForms, conjecture, (ilf_type(I,set_type) => ! [B] : (ilf_type(B,set_type) => ! [R] : (ilf_type(R,set_type) => ! [S] : (ilf_type(S,set_type) => (member(ordered_pair(I,B),cross_product(R,S)) <=> (member(I,R) & member(B,S)))))))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [B] : (ilf_type(B,set_type) => ! [R] : (ilf_type(R,set_type) => ! [S] : (ilf_type(S,set_type) => (member(ordered_pair(I,B),cross_product(R,S)) <=> (member(I,R) & member(B,S))))))).
fof(myForms, conjecture, (ilf_type(B,set_type) => ! [R] : (ilf_type(R,set_type) => ! [S] : (ilf_type(S,set_type) => (member(ordered_pair(I,B),cross_product(R,S)) <=> (member(I,R) & member(B,S))))))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ! [R] : (ilf_type(R,set_type) => ! [S] : (ilf_type(S,set_type) => (member(ordered_pair(I,B),cross_product(R,S)) <=> (member(I,R) & member(B,S)))))).
fof(myForms, conjecture, (ilf_type(R,set_type) => ! [S] : (ilf_type(S,set_type) => (member(ordered_pair(I,B),cross_product(R,S)) <=> (member(I,R) & member(B,S)))))).
fof(myForms, conjecture, ilf_type(R,set_type)).
fof(myForms, conjecture, ! [S] : (ilf_type(S,set_type) => (member(ordered_pair(I,B),cross_product(R,S)) <=> (member(I,R) & member(B,S))))).
fof(myForms, conjecture, (ilf_type(S,set_type) => (member(ordered_pair(I,B),cross_product(R,S)) <=> (member(I,R) & member(B,S))))).
fof(myForms, conjecture, ilf_type(S,set_type)).
fof(myForms, conjecture, (member(ordered_pair(I,B),cross_product(R,S)) <=> (member(I,R) & member(B,S)))).
fof(myForms, conjecture, member(ordered_pair(I,B),cross_product(R,S))).
fof(myForms, conjecture, (member(I,R) & member(B,S))).
fof(myForms, conjecture, member(I,R)).
fof(myForms, conjecture, member(B,S)).