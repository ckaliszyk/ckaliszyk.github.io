fof(myForms, conjecture, ! [S] : (ilf_type(S,member_type(I)) => (member(S,domain(I,B,R)) => ? [D] : (ilf_type(D,member_type(B)) & member(D,range(I,B,R)))))).
fof(myForms, conjecture, (ilf_type(S,member_type(I)) => (member(S,domain(I,B,R)) => ? [D] : (ilf_type(D,member_type(B)) & member(D,range(I,B,R)))))).
fof(myForms, conjecture, ilf_type(S,member_type(I))).
fof(myForms, conjecture, (member(S,domain(I,B,R)) => ? [D] : (ilf_type(D,member_type(B)) & member(D,range(I,B,R))))).
fof(myForms, conjecture, member(S,domain(I,B,R))).
fof(myForms, conjecture, ? [D] : (ilf_type(D,member_type(B)) & member(D,range(I,B,R)))).
fof(myForms, conjecture, (ilf_type(D,member_type(B)) & member(D,range(I,B,R)))).
fof(myForms, conjecture, ilf_type(D,member_type(B))).
fof(myForms, conjecture, member(D,range(I,B,R))).