fof(myForms, conjecture, ! [B] : union(I,B)=union(B,I)).
fof(myForms, conjecture, union(I,B)=union(B,I)).