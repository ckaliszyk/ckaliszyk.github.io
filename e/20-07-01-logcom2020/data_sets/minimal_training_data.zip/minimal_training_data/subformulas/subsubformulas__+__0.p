fof(myForms, conjecture, (~ empty(power_set(I)) & ilf_type(power_set(I),set_type))).
fof(myForms, conjecture, ~ empty(power_set(I))).
fof(myForms, conjecture, empty(power_set(I))).
fof(myForms, conjecture, ilf_type(power_set(I),set_type)).