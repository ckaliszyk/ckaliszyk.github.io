fof(myForms, conjecture, ~ member(R,B)).
fof(myForms, conjecture, member(R,B)).