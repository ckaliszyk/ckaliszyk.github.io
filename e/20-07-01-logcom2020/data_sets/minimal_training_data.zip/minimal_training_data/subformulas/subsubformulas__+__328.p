fof(myForms, conjecture, (ilf_type(I,set_type) => ! [B] : (ilf_type(B,set_type) => (subset(I,B) <=> ! [R] : (ilf_type(R,set_type) => (member(R,I) => member(R,B))))))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [B] : (ilf_type(B,set_type) => (subset(I,B) <=> ! [R] : (ilf_type(R,set_type) => (member(R,I) => member(R,B)))))).
fof(myForms, conjecture, (ilf_type(B,set_type) => (subset(I,B) <=> ! [R] : (ilf_type(R,set_type) => (member(R,I) => member(R,B)))))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, (subset(I,B) <=> ! [R] : (ilf_type(R,set_type) => (member(R,I) => member(R,B))))).
fof(myForms, conjecture, subset(I,B)).
fof(myForms, conjecture, ! [R] : (ilf_type(R,set_type) => (member(R,I) => member(R,B)))).
fof(myForms, conjecture, (ilf_type(R,set_type) => (member(R,I) => member(R,B)))).
fof(myForms, conjecture, ilf_type(R,set_type)).
fof(myForms, conjecture, (member(R,I) => member(R,B))).
fof(myForms, conjecture, member(R,I)).
fof(myForms, conjecture, member(R,B)).