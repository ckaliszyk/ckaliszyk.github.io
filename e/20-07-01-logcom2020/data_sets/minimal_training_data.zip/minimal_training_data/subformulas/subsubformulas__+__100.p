fof(myForms, conjecture, ! [T] : (a_member_of(T,U) <=> a_member_of(T,W))).
fof(myForms, conjecture, (a_member_of(T,U) <=> a_member_of(T,W))).
fof(myForms, conjecture, a_member_of(T,U)).
fof(myForms, conjecture, a_member_of(T,W)).