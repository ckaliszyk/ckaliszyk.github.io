fof(myForms, conjecture, ! [I] : ! [B] : (set_intersection2(F,I)=B <=> ! [R] : (in(R,B) <=> (in(R,F) & in(R,I))))).
fof(myForms, conjecture, ! [B] : (set_intersection2(F,I)=B <=> ! [R] : (in(R,B) <=> (in(R,F) & in(R,I))))).
fof(myForms, conjecture, (set_intersection2(F,I)=B <=> ! [R] : (in(R,B) <=> (in(R,F) & in(R,I))))).
fof(myForms, conjecture, set_intersection2(F,I)=B).
fof(myForms, conjecture, ! [R] : (in(R,B) <=> (in(R,F) & in(R,I)))).
fof(myForms, conjecture, (in(R,B) <=> (in(R,F) & in(R,I)))).
fof(myForms, conjecture, in(R,B)).
fof(myForms, conjecture, (in(R,F) & in(R,I))).
fof(myForms, conjecture, in(R,F)).
fof(myForms, conjecture, in(R,I)).