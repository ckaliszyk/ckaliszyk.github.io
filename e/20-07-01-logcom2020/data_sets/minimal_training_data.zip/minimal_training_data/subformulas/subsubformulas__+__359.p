fof(myForms, conjecture, ! [I] : (empty(I) <=> ! [B] : ~ member(B,I))).
fof(myForms, conjecture, (empty(I) <=> ! [B] : ~ member(B,I))).
fof(myForms, conjecture, empty(I)).
fof(myForms, conjecture, ! [B] : ~ member(B,I)).
fof(myForms, conjecture, ~ member(B,I)).
fof(myForms, conjecture, member(B,I)).