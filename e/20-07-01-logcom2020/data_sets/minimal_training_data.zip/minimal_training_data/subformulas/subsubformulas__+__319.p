fof(myForms, conjecture, (ilf_type(R,set_type) => (member(R,I) => member(R,B)))).
fof(myForms, conjecture, ilf_type(R,set_type)).
fof(myForms, conjecture, (member(R,I) => member(R,B))).
fof(myForms, conjecture, member(R,I)).
fof(myForms, conjecture, member(R,B)).