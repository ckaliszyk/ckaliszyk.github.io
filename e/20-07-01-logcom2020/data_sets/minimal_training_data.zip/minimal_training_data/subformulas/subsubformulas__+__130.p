fof(myForms, conjecture, ! [V] : ! [F] : ! [I] : ! [B] : ((((maps(D,F,I) & maps(J,I,B)) & compose_predicate(E,J,D,F,I,B)) & compose_predicate(V,J,D,F,I,B)) => equal_maps(E,V,F,B))).
fof(myForms, conjecture, ! [F] : ! [I] : ! [B] : ((((maps(D,F,I) & maps(J,I,B)) & compose_predicate(E,J,D,F,I,B)) & compose_predicate(V,J,D,F,I,B)) => equal_maps(E,V,F,B))).
fof(myForms, conjecture, ! [I] : ! [B] : ((((maps(D,F,I) & maps(J,I,B)) & compose_predicate(E,J,D,F,I,B)) & compose_predicate(V,J,D,F,I,B)) => equal_maps(E,V,F,B))).
fof(myForms, conjecture, ! [B] : ((((maps(D,F,I) & maps(J,I,B)) & compose_predicate(E,J,D,F,I,B)) & compose_predicate(V,J,D,F,I,B)) => equal_maps(E,V,F,B))).
fof(myForms, conjecture, ((((maps(D,F,I) & maps(J,I,B)) & compose_predicate(E,J,D,F,I,B)) & compose_predicate(V,J,D,F,I,B)) => equal_maps(E,V,F,B))).
fof(myForms, conjecture, (((maps(D,F,I) & maps(J,I,B)) & compose_predicate(E,J,D,F,I,B)) & compose_predicate(V,J,D,F,I,B))).
fof(myForms, conjecture, ((maps(D,F,I) & maps(J,I,B)) & compose_predicate(E,J,D,F,I,B))).
fof(myForms, conjecture, (maps(D,F,I) & maps(J,I,B))).
fof(myForms, conjecture, maps(D,F,I)).
fof(myForms, conjecture, maps(J,I,B)).
fof(myForms, conjecture, compose_predicate(E,J,D,F,I,B)).
fof(myForms, conjecture, compose_predicate(V,J,D,F,I,B)).
fof(myForms, conjecture, equal_maps(E,V,F,B)).