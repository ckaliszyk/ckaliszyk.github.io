fof(myForms, conjecture, ! [B] : (ilf_type(B,binary_relation_type) => (subset(I,B) <=> ! [R] : (ilf_type(R,set_type) => ! [S] : (ilf_type(S,set_type) => (member(ordered_pair(R,S),I) => member(ordered_pair(R,S),B))))))).
fof(myForms, conjecture, (ilf_type(B,binary_relation_type) => (subset(I,B) <=> ! [R] : (ilf_type(R,set_type) => ! [S] : (ilf_type(S,set_type) => (member(ordered_pair(R,S),I) => member(ordered_pair(R,S),B))))))).
fof(myForms, conjecture, ilf_type(B,binary_relation_type)).
fof(myForms, conjecture, (subset(I,B) <=> ! [R] : (ilf_type(R,set_type) => ! [S] : (ilf_type(S,set_type) => (member(ordered_pair(R,S),I) => member(ordered_pair(R,S),B)))))).
fof(myForms, conjecture, subset(I,B)).
fof(myForms, conjecture, ! [R] : (ilf_type(R,set_type) => ! [S] : (ilf_type(S,set_type) => (member(ordered_pair(R,S),I) => member(ordered_pair(R,S),B))))).
fof(myForms, conjecture, (ilf_type(R,set_type) => ! [S] : (ilf_type(S,set_type) => (member(ordered_pair(R,S),I) => member(ordered_pair(R,S),B))))).
fof(myForms, conjecture, ilf_type(R,set_type)).
fof(myForms, conjecture, ! [S] : (ilf_type(S,set_type) => (member(ordered_pair(R,S),I) => member(ordered_pair(R,S),B)))).
fof(myForms, conjecture, (ilf_type(S,set_type) => (member(ordered_pair(R,S),I) => member(ordered_pair(R,S),B)))).
fof(myForms, conjecture, ilf_type(S,set_type)).
fof(myForms, conjecture, (member(ordered_pair(R,S),I) => member(ordered_pair(R,S),B))).
fof(myForms, conjecture, member(ordered_pair(R,S),I)).
fof(myForms, conjecture, member(ordered_pair(R,S),B)).