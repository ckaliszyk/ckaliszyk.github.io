fof(myForms, conjecture, ~ intersect(I,B)).
fof(myForms, conjecture, intersect(I,B)).