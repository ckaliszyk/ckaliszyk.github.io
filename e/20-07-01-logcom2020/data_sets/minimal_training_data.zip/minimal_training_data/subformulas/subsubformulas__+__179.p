fof(myForms, conjecture, (in(ordered_pair(F,I),cartesian_product2(B,R)) => in(ordered_pair(I,F),cartesian_product2(R,B)))).
fof(myForms, conjecture, in(ordered_pair(F,I),cartesian_product2(B,R))).
fof(myForms, conjecture, in(ordered_pair(I,F),cartesian_product2(R,B))).