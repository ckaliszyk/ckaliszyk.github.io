fof(myForms, conjecture, ! [X] : (equal_set(unordered_pair(singleton(F),unordered_pair(F,I)),unordered_pair(singleton(Z),unordered_pair(Z,X))) => Z=F)).
fof(myForms, conjecture, (equal_set(unordered_pair(singleton(F),unordered_pair(F,I)),unordered_pair(singleton(Z),unordered_pair(Z,X))) => Z=F)).
fof(myForms, conjecture, equal_set(unordered_pair(singleton(F),unordered_pair(F,I)),unordered_pair(singleton(Z),unordered_pair(Z,X)))).
fof(myForms, conjecture, Z=F).