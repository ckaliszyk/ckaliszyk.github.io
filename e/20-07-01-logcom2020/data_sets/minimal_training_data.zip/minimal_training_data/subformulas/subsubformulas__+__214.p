fof(myForms, conjecture, (ilf_type(I,set_type) => ! [B] : (ilf_type(B,set_type) => ! [R] : (ilf_type(R,subset_type(cross_product(I,B))) => relation_like(R))))).
fof(myForms, conjecture, ilf_type(I,set_type)).
fof(myForms, conjecture, ! [B] : (ilf_type(B,set_type) => ! [R] : (ilf_type(R,subset_type(cross_product(I,B))) => relation_like(R)))).
fof(myForms, conjecture, (ilf_type(B,set_type) => ! [R] : (ilf_type(R,subset_type(cross_product(I,B))) => relation_like(R)))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ! [R] : (ilf_type(R,subset_type(cross_product(I,B))) => relation_like(R))).
fof(myForms, conjecture, (ilf_type(R,subset_type(cross_product(I,B))) => relation_like(R))).
fof(myForms, conjecture, ilf_type(R,subset_type(cross_product(I,B)))).
fof(myForms, conjecture, relation_like(R)).