fof(myForms, conjecture, (member(I,B) & disjoint(B,R))).
fof(myForms, conjecture, member(I,B)).
fof(myForms, conjecture, disjoint(B,R)).