fof(myForms, conjecture, (ilf_type(R,set_type) & member(R,range_of(B)))).
fof(myForms, conjecture, ilf_type(R,set_type)).
fof(myForms, conjecture, member(R,range_of(B))).