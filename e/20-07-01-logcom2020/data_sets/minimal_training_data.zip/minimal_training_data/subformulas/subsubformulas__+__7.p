fof(myForms, conjecture, (member(ordered_pair(R,S),I) => member(ordered_pair(R,S),B))).
fof(myForms, conjecture, member(ordered_pair(R,S),I)).
fof(myForms, conjecture, member(ordered_pair(R,S),B)).