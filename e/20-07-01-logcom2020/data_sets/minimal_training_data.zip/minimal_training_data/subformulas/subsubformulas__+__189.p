fof(myForms, conjecture, ? [W] : singleton(W)=U).
fof(myForms, conjecture, singleton(W)=U).