fof(myForms, conjecture, (in(F,I) => ~ in(I,F))).
fof(myForms, conjecture, in(F,I)).
fof(myForms, conjecture, ~ in(I,F)).
fof(myForms, conjecture, in(I,F)).