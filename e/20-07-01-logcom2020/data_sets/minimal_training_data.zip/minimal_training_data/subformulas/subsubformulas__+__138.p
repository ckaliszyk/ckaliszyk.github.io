fof(myForms, conjecture, (subset(domain_of(R),I) & subset(range_of(R),B))).
fof(myForms, conjecture, subset(domain_of(R),I)).
fof(myForms, conjecture, subset(range_of(R),B)).