fof(myForms, conjecture, ! [B] : (intersect(I,B) <=> ? [R] : (member(R,I) & member(R,B)))).
fof(myForms, conjecture, (intersect(I,B) <=> ? [R] : (member(R,I) & member(R,B)))).
fof(myForms, conjecture, intersect(I,B)).
fof(myForms, conjecture, ? [R] : (member(R,I) & member(R,B))).
fof(myForms, conjecture, (member(R,I) & member(R,B))).
fof(myForms, conjecture, member(R,I)).
fof(myForms, conjecture, member(R,B)).