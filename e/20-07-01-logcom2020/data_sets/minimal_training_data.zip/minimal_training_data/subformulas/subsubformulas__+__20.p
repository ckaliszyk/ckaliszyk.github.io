fof(myForms, conjecture, ! [U] : ! [A1] : ((pre_order(A1,S) & subset(U,S)) => pre_order(A1,U))).
fof(myForms, conjecture, ! [A1] : ((pre_order(A1,S) & subset(U,S)) => pre_order(A1,U))).
fof(myForms, conjecture, ((pre_order(A1,S) & subset(U,S)) => pre_order(A1,U))).
fof(myForms, conjecture, (pre_order(A1,S) & subset(U,S))).
fof(myForms, conjecture, pre_order(A1,S)).
fof(myForms, conjecture, subset(U,S)).
fof(myForms, conjecture, pre_order(A1,U)).