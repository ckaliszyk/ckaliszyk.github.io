fof(myForms, conjecture, ! [I] : (ilf_type(I,binary_relation_type) => I=I)).
fof(myForms, conjecture, (ilf_type(I,binary_relation_type) => I=I)).
fof(myForms, conjecture, ilf_type(I,binary_relation_type)).
fof(myForms, conjecture, I=I).