fof(myForms, conjecture, ~ I=F).
fof(myForms, conjecture, I=F).