fof(myForms, conjecture, (member(R,I) | member(R,B))).
fof(myForms, conjecture, member(R,I)).
fof(myForms, conjecture, member(R,B)).