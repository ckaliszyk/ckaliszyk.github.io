fof(myForms, conjecture, ! [B] : (subset(I,B) <=> ! [R] : (member(R,I) => member(R,B)))).
fof(myForms, conjecture, (subset(I,B) <=> ! [R] : (member(R,I) => member(R,B)))).
fof(myForms, conjecture, subset(I,B)).
fof(myForms, conjecture, ! [R] : (member(R,I) => member(R,B))).
fof(myForms, conjecture, (member(R,I) => member(R,B))).
fof(myForms, conjecture, member(R,I)).
fof(myForms, conjecture, member(R,B)).