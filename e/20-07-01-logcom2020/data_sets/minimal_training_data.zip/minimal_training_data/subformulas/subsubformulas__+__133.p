fof(myForms, conjecture, ! [B] : (ilf_type(B,set_type) => ? [R] : ilf_type(R,relation_type(B,I)))).
fof(myForms, conjecture, (ilf_type(B,set_type) => ? [R] : ilf_type(R,relation_type(B,I)))).
fof(myForms, conjecture, ilf_type(B,set_type)).
fof(myForms, conjecture, ? [R] : ilf_type(R,relation_type(B,I))).
fof(myForms, conjecture, ilf_type(R,relation_type(B,I))).