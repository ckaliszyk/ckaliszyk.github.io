fof(myForms, conjecture, ! [D] : ! [F] : difference(D,intersection(D,F))=difference(D,F)).
fof(myForms, conjecture, ! [F] : difference(D,intersection(D,F))=difference(D,F)).
fof(myForms, conjecture, difference(D,intersection(D,F))=difference(D,F)).