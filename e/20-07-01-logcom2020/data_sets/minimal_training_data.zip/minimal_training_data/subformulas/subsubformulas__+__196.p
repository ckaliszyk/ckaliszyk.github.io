fof(myForms, conjecture, ~ member(I,R)).
fof(myForms, conjecture, member(I,R)).