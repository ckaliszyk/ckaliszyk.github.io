fof(myForms, conjecture, ! [F] : ! [I] : (cartesian_product2(I,I)=cartesian_product2(F,F) => I=F)).
fof(myForms, conjecture, ! [I] : (cartesian_product2(I,I)=cartesian_product2(F,F) => I=F)).
fof(myForms, conjecture, (cartesian_product2(I,I)=cartesian_product2(F,F) => I=F)).
fof(myForms, conjecture, cartesian_product2(I,I)=cartesian_product2(F,F)).
fof(myForms, conjecture, I=F).