fof(myForms, conjecture, ! [B] : ! [R] : union(difference(I,R),difference(B,R))=difference(union(I,B),R)).
fof(myForms, conjecture, ! [R] : union(difference(I,R),difference(B,R))=difference(union(I,B),R)).
fof(myForms, conjecture, union(difference(I,R),difference(B,R))=difference(union(I,B),R)).