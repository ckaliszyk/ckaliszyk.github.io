fof(myForms, conjecture, ! [C] : ! [D] : unordered_pair(D,C)=unordered_pair(C,D)).
fof(myForms, conjecture, ! [D] : unordered_pair(D,C)=unordered_pair(C,D)).
fof(myForms, conjecture, unordered_pair(D,C)=unordered_pair(C,D)).