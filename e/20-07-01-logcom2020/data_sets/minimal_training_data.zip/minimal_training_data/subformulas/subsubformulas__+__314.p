fof(myForms, conjecture, ~ equal_set(F,I)).
fof(myForms, conjecture, equal_set(F,I)).