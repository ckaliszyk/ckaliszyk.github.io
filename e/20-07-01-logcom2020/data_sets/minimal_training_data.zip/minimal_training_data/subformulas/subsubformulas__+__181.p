fof(myForms, conjecture, ! [I] : ! [B] : ! [R] : ((member(I,B) & disjoint(B,R)) => ~ member(I,R))).
fof(myForms, conjecture, ! [B] : ! [R] : ((member(I,B) & disjoint(B,R)) => ~ member(I,R))).
fof(myForms, conjecture, ! [R] : ((member(I,B) & disjoint(B,R)) => ~ member(I,R))).
fof(myForms, conjecture, ((member(I,B) & disjoint(B,R)) => ~ member(I,R))).
fof(myForms, conjecture, (member(I,B) & disjoint(B,R))).
fof(myForms, conjecture, member(I,B)).
fof(myForms, conjecture, disjoint(B,R)).
fof(myForms, conjecture, ~ member(I,R)).
fof(myForms, conjecture, member(I,R)).