fof(myForms, conjecture, ! [D] : (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,relation_type(F,D)) => (ilf_type(I,relation_type(F,empty_set)) => empty_set=I))))).
fof(myForms, conjecture, (ilf_type(D,set_type) => ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,relation_type(F,D)) => (ilf_type(I,relation_type(F,empty_set)) => empty_set=I))))).
fof(myForms, conjecture, ilf_type(D,set_type)).
fof(myForms, conjecture, ! [F] : (ilf_type(F,set_type) => ! [I] : (ilf_type(I,relation_type(F,D)) => (ilf_type(I,relation_type(F,empty_set)) => empty_set=I)))).
fof(myForms, conjecture, (ilf_type(F,set_type) => ! [I] : (ilf_type(I,relation_type(F,D)) => (ilf_type(I,relation_type(F,empty_set)) => empty_set=I)))).
fof(myForms, conjecture, ilf_type(F,set_type)).
fof(myForms, conjecture, ! [I] : (ilf_type(I,relation_type(F,D)) => (ilf_type(I,relation_type(F,empty_set)) => empty_set=I))).
fof(myForms, conjecture, (ilf_type(I,relation_type(F,D)) => (ilf_type(I,relation_type(F,empty_set)) => empty_set=I))).
fof(myForms, conjecture, ilf_type(I,relation_type(F,D))).
fof(myForms, conjecture, (ilf_type(I,relation_type(F,empty_set)) => empty_set=I)).
fof(myForms, conjecture, ilf_type(I,relation_type(F,empty_set))).
fof(myForms, conjecture, empty_set=I).