theory relat_1
  imports xtuple_0 subset_1
begin
(*begin*)
reserve A, X, X1, X2, Y, Y1, Y2 for "setHIDDENM2"
reserve a, b, c, d, x, y, z for "objectHIDDENM1"
mdef relat_1_def_1 ("Relation-likeRELAT-1V1" 70 ) where
"attr Relation-likeRELAT-1V1 for setHIDDENM2 means
  (\<lambda>IT.  for x be objectHIDDENM1 holds x inHIDDENR3 IT implies ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st x =HIDDENR1 [TARSKIK4 y,z ]))"..

mtheorem relat_1_cl_1:
"cluster emptyXBOOLE-0V1 also-is Relation-likeRELAT-1V1 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be emptyXBOOLE-0V1 implies it be Relation-likeRELAT-1V1"
     sorry
qed "sorry"

syntax RELAT_1M1 :: "Ty" ("RelationRELAT-1M1" 70)
translations "RelationRELAT-1M1" \<rightharpoonup> "Relation-likeRELAT-1V1\<bar>setHIDDENM2"

reserve P, P1, P2, Q, R, S for "RelationRELAT-1M1"
mtheorem relat_1_cl_2:
  mlet "R be RelationRELAT-1M1"
"cluster note-that Relation-likeRELAT-1V1 for SubsetSUBSET-1M2-of R"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of R holds it be Relation-likeRELAT-1V1"
    using relat_1_def_1 sorry
qed "sorry"

theorem relat_1_sch_1:
  fixes Af0 Bf0 Pp2 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "Bf0 be setHIDDENM2"
  shows " ex R be RelationRELAT-1M1 st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R iff (x inHIDDENR3 Af0 & y inHIDDENR3 Bf0) & Pp2(x,y)"
  proof-
    have " ex tVar1 be RelationRELAT-1M1 st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 tVar1 implies (x inHIDDENR3 Af0 & y inHIDDENR3 Bf0) & Pp2(x,y)) & ((x inHIDDENR3 Af0 & y inHIDDENR3 Bf0) & Pp2(x,y) implies [TARSKIK4 x,y ] inHIDDENR3 tVar1)"
    proof-
      have " ex R be RelationRELAT-1M1 st  for p be objectHIDDENM1 holds p inHIDDENR3 R iff p inHIDDENR3 [:ZFMISC-1K2 Af0,Bf0 :] & ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st p =HIDDENR1 [TARSKIK4 x,y ] & Pp2(x,y))"
      proof-
        have " not ( for R be RelationRELAT-1M1 holds  not ( for p be objectHIDDENM1 holds  not (p inHIDDENR3 R &  not (p inHIDDENR3 [:ZFMISC-1K2 Af0,Bf0 :] &  not ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not (p =HIDDENR1 [TARSKIK4 x,y ] & Pp2(x,y))))) &  not ((p inHIDDENR3 [:ZFMISC-1K2 Af0,Bf0 :] &  not ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not (p =HIDDENR1 [TARSKIK4 x,y ] & Pp2(x,y)))) &  not p inHIDDENR3 R)))"
        proof-
          let ?Q = "\<lambda>Lamb1.  ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st Lamb1 =HIDDENR1 [TARSKIK4 x,y ] & Pp2(x,y)"
          obtain B where
            [ty]:"B be setHIDDENM2" and 
            A1: " for p be objectHIDDENM1 holds p inHIDDENR3 B iff p inHIDDENR3 [:ZFMISC-1K2 Af0,Bf0 :] & ?Q(p)"
            using xboole_0_sch_1 sorry
          have " for p be objectHIDDENM1 holds p inHIDDENR3 B implies ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st p =HIDDENR1 [TARSKIK4 x,y ])"
          proof-
            have " for p be objectHIDDENM1 holds p inHIDDENR3 B implies  not ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not p =HIDDENR1 [TARSKIK4 x,y ])"
            proof(rule ballI,rule impI)
              fix p assume [ty]: "p be objectHIDDENM1"
              assume "p inHIDDENR3 B"
              then have " ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st p =HIDDENR1 [TARSKIK4 x,y ] & Pp2(x,y)"
                using A1 sorry
              thus " not ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not p =HIDDENR1 [TARSKIK4 x,y ])"
                 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          then have "B be RelationRELAT-1M1"
            using relat_1_def_1 sorry
          thus " not ( for R be RelationRELAT-1M1 holds  not ( for p be objectHIDDENM1 holds  not (p inHIDDENR3 R &  not (p inHIDDENR3 [:ZFMISC-1K2 Af0,Bf0 :] &  not ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not (p =HIDDENR1 [TARSKIK4 x,y ] & Pp2(x,y))))) &  not ((p inHIDDENR3 [:ZFMISC-1K2 Af0,Bf0 :] &  not ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not (p =HIDDENR1 [TARSKIK4 x,y ] & Pp2(x,y)))) &  not p inHIDDENR3 R)))"
            using A1 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      then obtain R where
        [ty]:"R be RelationRELAT-1M1" and 
        A2: " for p be objectHIDDENM1 holds p inHIDDENR3 R iff p inHIDDENR3 [:ZFMISC-1K2 Af0,Bf0 :] & ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st p =HIDDENR1 [TARSKIK4 x,y ] & Pp2(x,y))"
         sorry
      show " ex tVar1 be RelationRELAT-1M1 st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 tVar1 implies (x inHIDDENR3 Af0 & y inHIDDENR3 Bf0) & Pp2(x,y)) & ((x inHIDDENR3 Af0 & y inHIDDENR3 Bf0) & Pp2(x,y) implies [TARSKIK4 x,y ] inHIDDENR3 tVar1)"
      proof(rule bexI[of _ "R"],rule ballI,rule ballI,rule conjMI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        show "[TARSKIK4 x,y ] inHIDDENR3 R implies (x inHIDDENR3 Af0 & y inHIDDENR3 Bf0) & Pp2(x,y)"
        proof(rule impI)
          assume A3: "[TARSKIK4 x,y ] inHIDDENR3 R"
          then obtain xx yy where
            [ty]:"xx be objectHIDDENM1" "yy be objectHIDDENM1" and 
            A4: "[TARSKIK4 x,y ] =HIDDENR1 [TARSKIK4 xx,yy ]"and A5: "Pp2(xx,yy)"
            using A2 sorry
          have A6: "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Af0,Bf0 :]"
            using A2 A3 sorry
          have "x =HIDDENR1 xx"
            using A4 xtuple_0_th_1 sorry
          thus "(x inHIDDENR3 Af0 & y inHIDDENR3 Bf0) & Pp2(x,y)"
            using A4 A5 A6 xtuple_0_th_1 zfmisc_1_th_87 sorry
        qed
        show "(x inHIDDENR3 Af0 & y inHIDDENR3 Bf0) & Pp2(x,y) implies [TARSKIK4 x,y ] inHIDDENR3 R"
        proof(rule impMI ,rule impI)
          assume A7: "x inHIDDENR3 Af0 & y inHIDDENR3 Bf0"
            and A8: "Pp2(x,y)"
          have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Af0,Bf0 :]"
            using A7 zfmisc_1_th_87 sorry
          thus "[TARSKIK4 x,y ] inHIDDENR3 R"
            using A2 A8 sorry
        qed
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

abbreviation(input) RELAT_1R1(" _ =RELAT-1R1  _ " [50,50]50) where
  "P =RELAT-1R1 R \<equiv> P =HIDDENR1 R"

mtheorem relat_1_def_2:
  mlet "P be RelationRELAT-1M1", "R be RelationRELAT-1M1"
"redefine pred P =RELAT-1R1 R means
   for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 P iff [TARSKIK4 a,b ] inHIDDENR3 R"
proof
(*compatibility*)
  show "P =RELAT-1R1 R iff ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 P iff [TARSKIK4 a,b ] inHIDDENR3 R)"
  proof-
    have "(P =XBOOLE-0R4 R implies ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 P iff [TARSKIK4 a,b ] inHIDDENR3 R)) & (( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 P iff [TARSKIK4 a,b ] inHIDDENR3 R) implies P =HIDDENR1 R)"
    proof(rule conjMI,rule impI)
      show "P =XBOOLE-0R4 R implies ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 P iff [TARSKIK4 a,b ] inHIDDENR3 R)"
         sorry
      assume A1: " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 P iff [TARSKIK4 a,b ] inHIDDENR3 R"
      have "P c=TARSKIR1 R & R c=TARSKIR1 P"
      proof(rule conjMI)
        show "P c=TARSKIR1 R"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 P implies x inHIDDENR3 R"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A2: "x inHIDDENR3 P"
            then have " ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st x =HIDDENR1 [TARSKIK4 y,z ]"
              using relat_1_def_1 sorry
            thus "x inHIDDENR3 R"
              using A1 A2 sorry
          qed "sorry"
          thus "P c=TARSKIR1 R"
            using tarski_def_3 sorry
        qed
        have " for x be objectHIDDENM1 holds x inHIDDENR3 R implies x inHIDDENR3 P"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A3: "x inHIDDENR3 R"
          then have " ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st x =HIDDENR1 [TARSKIK4 y,z ]"
            using relat_1_def_1 sorry
          thus "x inHIDDENR3 P"
            using A1 A3 sorry
        qed "sorry"
        thus "R c=TARSKIR1 P"
          using tarski_def_3 sorry
      qed
      thus "P =HIDDENR1 R"
        using xboole_0_def_10 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem relat_1_cl_3:
  mlet "P be RelationRELAT-1M1", "X be setHIDDENM2"
"cluster P /\\XBOOLE-0K3 X as-term-is Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "P /\\XBOOLE-0K3 X be Relation-likeRELAT-1V1"
  proof-
    have "P /\\XBOOLE-0K3 X c=TARSKIR1 P"
      using xboole_1_th_17 sorry
    thus "P /\\XBOOLE-0K3 X be Relation-likeRELAT-1V1"
       sorry
  qed
qed "sorry"

mtheorem relat_1_cl_4:
  mlet "P be RelationRELAT-1M1", "X be setHIDDENM2"
"cluster P \\SUBSET-1K6 X as-term-is Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "P \\SUBSET-1K6 X be Relation-likeRELAT-1V1"
     sorry
qed "sorry"

mtheorem relat_1_cl_5:
  mlet "P be RelationRELAT-1M1", "R be RelationRELAT-1M1"
"cluster P \\/XBOOLE-0K2 R as-term-is Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "P \\/XBOOLE-0K2 R be Relation-likeRELAT-1V1"
  proof-
    have " for x be objectHIDDENM1 holds x inHIDDENR3 P \\/XBOOLE-0K2 R implies ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st x =HIDDENR1 [TARSKIK4 y,z ])"
    proof(rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have A1: "x inHIDDENR3 R implies ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st x =HIDDENR1 [TARSKIK4 y,z ])"
        using relat_1_def_1 sorry
      have "x inHIDDENR3 P implies ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st x =HIDDENR1 [TARSKIK4 y,z ])"
        using relat_1_def_1 sorry
      thus "x inHIDDENR3 P \\/XBOOLE-0K2 R implies ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st x =HIDDENR1 [TARSKIK4 y,z ])"
        using A1 xboole_0_def_3 sorry
    qed "sorry"
    thus "P \\/XBOOLE-0K2 R be Relation-likeRELAT-1V1"
      using relat_1_def_1 sorry
  qed
qed "sorry"

mtheorem relat_1_cl_6:
  mlet "R be RelationRELAT-1M1", "S be RelationRELAT-1M1"
"cluster R \\+\\XBOOLE-0K5 S as-term-is Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "R \\+\\XBOOLE-0K5 S be Relation-likeRELAT-1V1"
     sorry
qed "sorry"

mtheorem relat_1_cl_7:
  mlet "a be objectHIDDENM1", "b be objectHIDDENM1"
"cluster {TARSKIK1 [TARSKIK4 a,b ] } as-term-is Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "{TARSKIK1 [TARSKIK4 a,b ] } be Relation-likeRELAT-1V1"
  proof-
    have " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK1 [TARSKIK4 a,b ] } implies  not ( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  not x =HIDDENR1 [TARSKIK4 y,z ])"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 {TARSKIK1 [TARSKIK4 a,b ] }"
      then have "x =HIDDENR1 [TARSKIK4 a,b ]"
        using tarski_def_1 sorry
      thus " not ( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  not x =HIDDENR1 [TARSKIK4 y,z ])"
         sorry
    qed "sorry"
    thus "{TARSKIK1 [TARSKIK4 a,b ] } be Relation-likeRELAT-1V1"
      using relat_1_def_1 sorry
  qed
qed "sorry"

mtheorem relat_1_cl_8:
  mlet "a be setHIDDENM2", "b be setHIDDENM2"
"cluster [:ZFMISC-1K2 a,b :] as-term-is Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "[:ZFMISC-1K2 a,b :] be Relation-likeRELAT-1V1"
  proof-
    have " for z be objectHIDDENM1 holds z inHIDDENR3 [:ZFMISC-1K2 a,b :] implies  not ( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  not z =HIDDENR1 [TARSKIK4 y,z ])"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be objectHIDDENM1"
      assume "z inHIDDENR3 [:ZFMISC-1K2 a,b :]"
      then have " ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st (x inHIDDENR3 a & y inHIDDENR3 b) & [TARSKIK4 x,y ] =HIDDENR1 z"
        using zfmisc_1_def_2 sorry
      thus " not ( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  not z =HIDDENR1 [TARSKIK4 y,z ])"
         sorry
    qed "sorry"
    thus "[:ZFMISC-1K2 a,b :] be Relation-likeRELAT-1V1"
      using relat_1_def_1 sorry
  qed
qed "sorry"

mtheorem relat_1_cl_9:
  mlet "a be objectHIDDENM1", "b be objectHIDDENM1", "c be objectHIDDENM1", "d be objectHIDDENM1"
"cluster {TARSKIK2 [TARSKIK4 a,b ],[TARSKIK4 c,d ] } as-term-is Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "{TARSKIK2 [TARSKIK4 a,b ],[TARSKIK4 c,d ] } be Relation-likeRELAT-1V1"
  proof-
    have "{TARSKIK2 [TARSKIK4 a,b ],[TARSKIK4 c,d ] } =XBOOLE-0R4 {TARSKIK1 [TARSKIK4 a,b ] } \\/XBOOLE-0K2 {TARSKIK1 [TARSKIK4 c,d ] }"
      using enumset1_th_1 sorry
    thus "{TARSKIK2 [TARSKIK4 a,b ],[TARSKIK4 c,d ] } be Relation-likeRELAT-1V1"
       sorry
  qed
qed "sorry"

abbreviation(input) RELAT_1R2(" _ c=RELAT-1R2  _ " [50,50]50) where
  "P c=RELAT-1R2 A \<equiv> P c=TARSKIR1 A"

mtheorem relat_1_def_3:
  mlet "P be RelationRELAT-1M1", "A be setHIDDENM2"
"redefine pred P c=RELAT-1R2 A means
   for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 P implies [TARSKIK4 a,b ] inHIDDENR3 A"
proof
(*compatibility*)
  show "P c=RELAT-1R2 A iff ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 P implies [TARSKIK4 a,b ] inHIDDENR3 A)"
  proof-
    have "(P c=TARSKIR1 A implies ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 P implies [TARSKIK4 a,b ] inHIDDENR3 A)) & (( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 P implies [TARSKIK4 a,b ] inHIDDENR3 A) implies P c=TARSKIR1 A)"
    proof(rule conjMI,rule impI)
      show "P c=TARSKIR1 A implies ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 P implies [TARSKIK4 a,b ] inHIDDENR3 A)"
         sorry
      assume A1: " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 P implies [TARSKIK4 a,b ] inHIDDENR3 A"
      have " for x be objectHIDDENM1 holds x inHIDDENR3 P implies x inHIDDENR3 A"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A2: "x inHIDDENR3 P"
        then have " ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st x =HIDDENR1 [TARSKIK4 y,z ]"
          using relat_1_def_1 sorry
        thus "x inHIDDENR3 A"
          using A1 A2 sorry
      qed "sorry"
      thus "P c=TARSKIR1 A"
        using tarski_def_3 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

abbreviation(input) RELAT_1K1("domRELAT-1K1  _ " [228]228) where
  "domRELAT-1K1 R \<equiv> proj1XTUPLE-0K12 R"

abbreviation(input) RELAT_1K2("rngRELAT-1K2  _ " [228]228) where
  "rngRELAT-1K2 R \<equiv> proj2XTUPLE-0K13 R"

(*\$CT 6*)
mtheorem relat_1_th_7:
" for R be RelationRELAT-1M1 holds R c=RELAT-1R2 [:ZFMISC-1K2 domRELAT-1K1 R,rngRELAT-1K2 R :]"
proof-
  have " for R be RelationRELAT-1M1 holds R c=RELAT-1R2 [:ZFMISC-1K2 domRELAT-1K1 R,rngRELAT-1K2 R :]"
  proof(rule ballI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds [TARSKIK4 y,z ] inHIDDENR3 R implies [TARSKIK4 y,z ] inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 R,rngRELAT-1K2 R :]"
    proof(rule ballI,rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      fix z assume [ty]: "z be objectHIDDENM1"
      assume "[TARSKIK4 y,z ] inHIDDENR3 R"
      then have "y inHIDDENR3 domRELAT-1K1 R & z inHIDDENR3 rngRELAT-1K2 R"
        using xtuple_0_def_12 xtuple_0_def_13 sorry
      thus "[TARSKIK4 y,z ] inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 R,rngRELAT-1K2 R :]"
        using zfmisc_1_th_87 sorry
    qed "sorry"
    thus "R c=RELAT-1R2 [:ZFMISC-1K2 domRELAT-1K1 R,rngRELAT-1K2 R :]"
      using relat_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_8:
" for R be RelationRELAT-1M1 holds R /\\XBOOLE-0K3 ([:ZFMISC-1K2 domRELAT-1K1 R,rngRELAT-1K2 R :]) =RELAT-1R1 R"
  using relat_1_th_7 xboole_1_th_28 sorry

mtheorem relat_1_th_9:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds domRELAT-1K1 {TARSKIK1 [TARSKIK4 x,y ] } =XBOOLE-0R4 {TARSKIK1 x} & rngRELAT-1K2 {TARSKIK1 [TARSKIK4 x,y ] } =XBOOLE-0R4 {TARSKIK1 y}"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds domRELAT-1K1 {TARSKIK1 [TARSKIK4 x,y ] } =XBOOLE-0R4 {TARSKIK1 x} & rngRELAT-1K2 {TARSKIK1 [TARSKIK4 x,y ] } =XBOOLE-0R4 {TARSKIK1 y}"
  proof(rule ballI,rule ballI,rule conjMI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    let ?R = "{TARSKIK1 [TARSKIK4 x,y ] }"
    have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 ?R iff z inHIDDENR3 {TARSKIK1 x}"
    proof-
      have " for z be objectHIDDENM1 holds (z inHIDDENR3 domRELAT-1K1 {TARSKIK1 [TARSKIK4 x,y ] } implies z inHIDDENR3 {TARSKIK1 x}) & (z inHIDDENR3 {TARSKIK1 x} implies z inHIDDENR3 domRELAT-1K1 {TARSKIK1 [TARSKIK4 x,y ] })"
      proof(rule ballI,rule conjMI,rule impI)
        fix z assume [ty]: "z be objectHIDDENM1"
        show "z inHIDDENR3 domRELAT-1K1 {TARSKIK1 [TARSKIK4 x,y ] } implies z inHIDDENR3 {TARSKIK1 x}"
        proof(rule impI)
          assume "z inHIDDENR3 domRELAT-1K1 ?R"
          then obtain b where
            [ty]:"b be objectHIDDENM1" and 
            A2: "[TARSKIK4 z,b ] inHIDDENR3 ?R"
            using xtuple_0_def_12 sorry
          have "[TARSKIK4 z,b ] =HIDDENR1 [TARSKIK4 x,y ]"
            using A2 tarski_def_1 sorry
          then have "z =HIDDENR1 x"
            using xtuple_0_th_1 sorry
          thus "z inHIDDENR3 {TARSKIK1 x}"
            using tarski_def_1 sorry
        qed
        assume "z inHIDDENR3 {TARSKIK1 x}"
        then have "z =HIDDENR1 x"
          using tarski_def_1 sorry
        then have "[TARSKIK4 z,y ] inHIDDENR3 ?R"
          using tarski_def_1 sorry
        thus "z inHIDDENR3 domRELAT-1K1 {TARSKIK1 [TARSKIK4 x,y ] }"
          using xtuple_0_def_12 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "domRELAT-1K1 {TARSKIK1 [TARSKIK4 x,y ] } =XBOOLE-0R4 {TARSKIK1 x}"
      using tarski_th_2 sorry
    have " for z be objectHIDDENM1 holds z inHIDDENR3 rngRELAT-1K2 ?R iff z inHIDDENR3 {TARSKIK1 y}"
    proof-
      have " for z be objectHIDDENM1 holds (z inHIDDENR3 rngRELAT-1K2 {TARSKIK1 [TARSKIK4 x,y ] } implies z inHIDDENR3 {TARSKIK1 y}) & (z inHIDDENR3 {TARSKIK1 y} implies z inHIDDENR3 rngRELAT-1K2 {TARSKIK1 [TARSKIK4 x,y ] })"
      proof(rule ballI,rule conjMI,rule impI)
        fix z assume [ty]: "z be objectHIDDENM1"
        show "z inHIDDENR3 rngRELAT-1K2 {TARSKIK1 [TARSKIK4 x,y ] } implies z inHIDDENR3 {TARSKIK1 y}"
        proof(rule impI)
          assume "z inHIDDENR3 rngRELAT-1K2 ?R"
          then obtain a where
            [ty]:"a be objectHIDDENM1" and 
            A3: "[TARSKIK4 a,z ] inHIDDENR3 ?R"
            using xtuple_0_def_13 sorry
          have "[TARSKIK4 a,z ] =HIDDENR1 [TARSKIK4 x,y ]"
            using A3 tarski_def_1 sorry
          then have "z =HIDDENR1 y"
            using xtuple_0_th_1 sorry
          thus "z inHIDDENR3 {TARSKIK1 y}"
            using tarski_def_1 sorry
        qed
        assume "z inHIDDENR3 {TARSKIK1 y}"
        then have "z =HIDDENR1 y"
          using tarski_def_1 sorry
        then have "[TARSKIK4 x,z ] inHIDDENR3 ?R"
          using tarski_def_1 sorry
        thus "z inHIDDENR3 rngRELAT-1K2 {TARSKIK1 [TARSKIK4 x,y ] }"
          using xtuple_0_def_13 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "rngRELAT-1K2 {TARSKIK1 [TARSKIK4 x,y ] } =XBOOLE-0R4 {TARSKIK1 y}"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_10:
" for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds domRELAT-1K1 {TARSKIK2 [TARSKIK4 a,b ],[TARSKIK4 x,y ] } =XBOOLE-0R4 {TARSKIK2 a,x } & rngRELAT-1K2 {TARSKIK2 [TARSKIK4 a,b ],[TARSKIK4 x,y ] } =XBOOLE-0R4 {TARSKIK2 b,y }"
proof-
  have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds domRELAT-1K1 {TARSKIK2 [TARSKIK4 a,b ],[TARSKIK4 x,y ] } =XBOOLE-0R4 {TARSKIK2 a,x } & rngRELAT-1K2 {TARSKIK2 [TARSKIK4 a,b ],[TARSKIK4 x,y ] } =XBOOLE-0R4 {TARSKIK2 b,y }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI)
    fix a assume [ty]: "a be objectHIDDENM1"
    fix b assume [ty]: "b be objectHIDDENM1"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    let ?R = "{TARSKIK2 [TARSKIK4 a,b ],[TARSKIK4 x,y ] }"
    show "domRELAT-1K1 {TARSKIK2 [TARSKIK4 a,b ],[TARSKIK4 x,y ] } =XBOOLE-0R4 {TARSKIK2 a,x }"
    proof-
      have "domRELAT-1K1 {TARSKIK2 [TARSKIK4 a,b ],[TARSKIK4 x,y ] } c=TARSKIR1 {TARSKIK2 a,x } & {TARSKIK2 a,x } c=TARSKIR1 domRELAT-1K1 {TARSKIK2 [TARSKIK4 a,b ],[TARSKIK4 x,y ] }"
      proof(rule conjMI)
        show "domRELAT-1K1 {TARSKIK2 [TARSKIK4 a,b ],[TARSKIK4 x,y ] } c=TARSKIR1 {TARSKIK2 a,x }"
        proof-
          have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 {TARSKIK2 [TARSKIK4 a,b ],[TARSKIK4 x,y ] } implies z inHIDDENR3 {TARSKIK2 a,x }"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be objectHIDDENM1"
            assume "z inHIDDENR3 domRELAT-1K1 ?R"
            then obtain c where
              [ty]:"c be objectHIDDENM1" and 
              A2: "[TARSKIK4 z,c ] inHIDDENR3 ?R"
              using xtuple_0_def_12 sorry
            have "[TARSKIK4 z,c ] =HIDDENR1 [TARSKIK4 a,b ] or [TARSKIK4 z,c ] =HIDDENR1 [TARSKIK4 x,y ]"
              using A2 tarski_def_2 sorry
            then have "z =HIDDENR1 a or z =HIDDENR1 x"
              using xtuple_0_th_1 sorry
            thus "z inHIDDENR3 {TARSKIK2 a,x }"
              using tarski_def_2 sorry
          qed "sorry"
          thus "domRELAT-1K1 {TARSKIK2 [TARSKIK4 a,b ],[TARSKIK4 x,y ] } c=TARSKIR1 {TARSKIK2 a,x }"
            using tarski_def_3 sorry
        qed
        have " for z be objectHIDDENM1 holds z inHIDDENR3 {TARSKIK2 a,x } implies z inHIDDENR3 domRELAT-1K1 {TARSKIK2 [TARSKIK4 a,b ],[TARSKIK4 x,y ] }"
        proof(rule ballI,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          assume "z inHIDDENR3 {TARSKIK2 a,x }"
          then have "z =HIDDENR1 a or z =HIDDENR1 x"
            using tarski_def_2 sorry
          then have "[TARSKIK4 z,b ] inHIDDENR3 ?R or [TARSKIK4 z,y ] inHIDDENR3 ?R"
            using tarski_def_2 sorry
          thus "z inHIDDENR3 domRELAT-1K1 {TARSKIK2 [TARSKIK4 a,b ],[TARSKIK4 x,y ] }"
            using xtuple_0_def_12 sorry
        qed "sorry"
        thus "{TARSKIK2 a,x } c=TARSKIR1 domRELAT-1K1 {TARSKIK2 [TARSKIK4 a,b ],[TARSKIK4 x,y ] }"
          using tarski_def_3 sorry
      qed
      thus "domRELAT-1K1 {TARSKIK2 [TARSKIK4 a,b ],[TARSKIK4 x,y ] } =XBOOLE-0R4 {TARSKIK2 a,x }"
        using xboole_0_def_10 sorry
    qed
    have "rngRELAT-1K2 {TARSKIK2 [TARSKIK4 a,b ],[TARSKIK4 x,y ] } c=TARSKIR1 {TARSKIK2 b,y } & {TARSKIK2 b,y } c=TARSKIR1 rngRELAT-1K2 {TARSKIK2 [TARSKIK4 a,b ],[TARSKIK4 x,y ] }"
    proof(rule conjMI)
      show "rngRELAT-1K2 {TARSKIK2 [TARSKIK4 a,b ],[TARSKIK4 x,y ] } c=TARSKIR1 {TARSKIK2 b,y }"
      proof-
        have " for z be objectHIDDENM1 holds z inHIDDENR3 rngRELAT-1K2 {TARSKIK2 [TARSKIK4 a,b ],[TARSKIK4 x,y ] } implies z inHIDDENR3 {TARSKIK2 b,y }"
        proof(rule ballI,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          assume "z inHIDDENR3 rngRELAT-1K2 ?R"
          then obtain d where
            [ty]:"d be objectHIDDENM1" and 
            A3: "[TARSKIK4 d,z ] inHIDDENR3 ?R"
            using xtuple_0_def_13 sorry
          have "[TARSKIK4 d,z ] =HIDDENR1 [TARSKIK4 a,b ] or [TARSKIK4 d,z ] =HIDDENR1 [TARSKIK4 x,y ]"
            using A3 tarski_def_2 sorry
          then have "z =HIDDENR1 b or z =HIDDENR1 y"
            using xtuple_0_th_1 sorry
          thus "z inHIDDENR3 {TARSKIK2 b,y }"
            using tarski_def_2 sorry
        qed "sorry"
        thus "rngRELAT-1K2 {TARSKIK2 [TARSKIK4 a,b ],[TARSKIK4 x,y ] } c=TARSKIR1 {TARSKIK2 b,y }"
          using tarski_def_3 sorry
      qed
      have " for z be objectHIDDENM1 holds z inHIDDENR3 {TARSKIK2 b,y } implies z inHIDDENR3 rngRELAT-1K2 {TARSKIK2 [TARSKIK4 a,b ],[TARSKIK4 x,y ] }"
      proof(rule ballI,rule impI)
        fix z assume [ty]: "z be objectHIDDENM1"
        assume "z inHIDDENR3 {TARSKIK2 b,y }"
        then have "z =HIDDENR1 b or z =HIDDENR1 y"
          using tarski_def_2 sorry
        then have "[TARSKIK4 a,z ] inHIDDENR3 ?R or [TARSKIK4 x,z ] inHIDDENR3 ?R"
          using tarski_def_2 sorry
        thus "z inHIDDENR3 rngRELAT-1K2 {TARSKIK2 [TARSKIK4 a,b ],[TARSKIK4 x,y ] }"
          using xtuple_0_def_13 sorry
      qed "sorry"
      thus "{TARSKIK2 b,y } c=TARSKIR1 rngRELAT-1K2 {TARSKIK2 [TARSKIK4 a,b ],[TARSKIK4 x,y ] }"
        using tarski_def_3 sorry
    qed
    thus "rngRELAT-1K2 {TARSKIK2 [TARSKIK4 a,b ],[TARSKIK4 x,y ] } =XBOOLE-0R4 {TARSKIK2 b,y }"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_11:
" for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds P c=RELAT-1R2 R implies domRELAT-1K1 P c=TARSKIR1 domRELAT-1K1 R & rngRELAT-1K2 P c=TARSKIR1 rngRELAT-1K2 R"
  using xtuple_0_th_8 xtuple_0_th_9 sorry

mtheorem relat_1_th_12:
" for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds rngRELAT-1K2 (P \\/XBOOLE-0K2 R) =XBOOLE-0R4 rngRELAT-1K2 P \\/XBOOLE-0K2 rngRELAT-1K2 R"
  using xtuple_0_th_27 sorry

mtheorem relat_1_th_13:
" for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds rngRELAT-1K2 (P /\\XBOOLE-0K3 R) c=TARSKIR1 rngRELAT-1K2 P /\\XBOOLE-0K3 rngRELAT-1K2 R"
  using xtuple_0_th_28 sorry

mtheorem relat_1_th_14:
" for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds rngRELAT-1K2 P \\SUBSET-1K6 rngRELAT-1K2 R c=TARSKIR1 rngRELAT-1K2 (P \\SUBSET-1K6 R)"
  using xtuple_0_th_29 sorry

(*\$CD 2*)
mdef relat_1_def_6 ("fieldRELAT-1K3  _ " [228]228 ) where
  mlet "R be RelationRELAT-1M1"
"func fieldRELAT-1K3 R \<rightarrow> setHIDDENM2 equals
  domRELAT-1K1 R \\/XBOOLE-0K2 rngRELAT-1K2 R"
proof-
  (*coherence*)
    show "domRELAT-1K1 R \\/XBOOLE-0K2 rngRELAT-1K2 R be setHIDDENM2"
       sorry
qed "sorry"

mtheorem relat_1_th_15:
" for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds [TARSKIK4 a,b ] inHIDDENR3 R implies a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R"
proof-
  have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds [TARSKIK4 a,b ] inHIDDENR3 R implies a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix a assume [ty]: "a be objectHIDDENM1"
    fix b assume [ty]: "b be objectHIDDENM1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume A1: "[TARSKIK4 a,b ] inHIDDENR3 R"
    then have "a inHIDDENR3 domRELAT-1K1 R"
      using xtuple_0_def_12 sorry
    thus "a inHIDDENR3 fieldRELAT-1K3 R"
      using xboole_0_def_3 sorry
    have "b inHIDDENR3 rngRELAT-1K2 R"
      using A1 xtuple_0_def_13 sorry
    thus "b inHIDDENR3 fieldRELAT-1K3 R"
      using xboole_0_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_16:
" for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds P c=RELAT-1R2 R implies fieldRELAT-1K3 P c=TARSKIR1 fieldRELAT-1K3 R"
proof-
  have " for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds P c=RELAT-1R2 R implies fieldRELAT-1K3 P c=TARSKIR1 fieldRELAT-1K3 R"
  proof(rule ballI,rule ballI,rule impI)
    fix P assume [ty]: "P be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume "P c=RELAT-1R2 R"
    then have "domRELAT-1K1 P c=TARSKIR1 domRELAT-1K1 R & rngRELAT-1K2 P c=TARSKIR1 rngRELAT-1K2 R"
      using xtuple_0_th_8 xtuple_0_th_9 sorry
    thus "fieldRELAT-1K3 P c=TARSKIR1 fieldRELAT-1K3 R"
      using xboole_1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_17:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds fieldRELAT-1K3 {TARSKIK1 [TARSKIK4 x,y ] } =XBOOLE-0R4 {TARSKIK2 x,y }"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds fieldRELAT-1K3 {TARSKIK1 [TARSKIK4 x,y ] } =XBOOLE-0R4 {TARSKIK2 x,y }"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    have "domRELAT-1K1 {TARSKIK1 [TARSKIK4 x,y ] } =XBOOLE-0R4 {TARSKIK1 x} & rngRELAT-1K2 {TARSKIK1 [TARSKIK4 x,y ] } =XBOOLE-0R4 {TARSKIK1 y}"
      using relat_1_th_9 sorry
    thus "fieldRELAT-1K3 {TARSKIK1 [TARSKIK4 x,y ] } =XBOOLE-0R4 {TARSKIK2 x,y }"
      using enumset1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_18:
" for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds fieldRELAT-1K3 (P \\/XBOOLE-0K2 R) =XBOOLE-0R4 fieldRELAT-1K3 P \\/XBOOLE-0K2 fieldRELAT-1K3 R"
proof-
  have " for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds fieldRELAT-1K3 (P \\/XBOOLE-0K2 R) =HIDDENR1 fieldRELAT-1K3 P \\/XBOOLE-0K2 fieldRELAT-1K3 R"
  proof(rule ballI,rule ballI)
    fix P assume [ty]: "P be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have "fieldRELAT-1K3 (P \\/XBOOLE-0K2 R) =HIDDENR1 (domRELAT-1K1 P \\/XBOOLE-0K2 domRELAT-1K1 R)\\/XBOOLE-0K2 rngRELAT-1K2 (P \\/XBOOLE-0K2 R)"
      using xtuple_0_th_23 sorry
    also have "... = (domRELAT-1K1 P \\/XBOOLE-0K2 domRELAT-1K1 R)\\/XBOOLE-0K2 (rngRELAT-1K2 P \\/XBOOLE-0K2 rngRELAT-1K2 R)"
      using xtuple_0_th_27 sorry
    also have "... = ((domRELAT-1K1 P \\/XBOOLE-0K2 domRELAT-1K1 R)\\/XBOOLE-0K2 rngRELAT-1K2 P)\\/XBOOLE-0K2 rngRELAT-1K2 R"
      using xboole_1_th_4 sorry
    also have "... = (fieldRELAT-1K3 P \\/XBOOLE-0K2 domRELAT-1K1 R)\\/XBOOLE-0K2 rngRELAT-1K2 R"
      using xboole_1_th_4 sorry
    also have "... = fieldRELAT-1K3 P \\/XBOOLE-0K2 fieldRELAT-1K3 R"
      using xboole_1_th_4 sorry
    finally show "fieldRELAT-1K3 (P \\/XBOOLE-0K2 R) =HIDDENR1 fieldRELAT-1K3 P \\/XBOOLE-0K2 fieldRELAT-1K3 R"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_19:
" for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds fieldRELAT-1K3 (P /\\XBOOLE-0K3 R) c=TARSKIR1 fieldRELAT-1K3 P /\\XBOOLE-0K3 fieldRELAT-1K3 R"
proof-
  have " for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds fieldRELAT-1K3 (P /\\XBOOLE-0K3 R) c=TARSKIR1 fieldRELAT-1K3 P /\\XBOOLE-0K3 fieldRELAT-1K3 R"
  proof(rule ballI,rule ballI)
    fix P assume [ty]: "P be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 fieldRELAT-1K3 (P /\\XBOOLE-0K3 R) implies x inHIDDENR3 fieldRELAT-1K3 P /\\XBOOLE-0K3 fieldRELAT-1K3 R"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 fieldRELAT-1K3 (P /\\XBOOLE-0K3 R)"
      then have A1: "x inHIDDENR3 domRELAT-1K1 (P /\\XBOOLE-0K3 R) or x inHIDDENR3 rngRELAT-1K2 (P /\\XBOOLE-0K3 R)"
        using xboole_0_def_3 sorry
      have "x inHIDDENR3 domRELAT-1K1 P /\\XBOOLE-0K3 domRELAT-1K1 R or x inHIDDENR3 rngRELAT-1K2 P /\\XBOOLE-0K3 rngRELAT-1K2 R implies (x inHIDDENR3 domRELAT-1K1 P or x inHIDDENR3 rngRELAT-1K2 P) & (x inHIDDENR3 domRELAT-1K1 R or x inHIDDENR3 rngRELAT-1K2 R)"
        using xboole_0_def_4 sorry
      then have A2: "x inHIDDENR3 domRELAT-1K1 P /\\XBOOLE-0K3 domRELAT-1K1 R or x inHIDDENR3 rngRELAT-1K2 P /\\XBOOLE-0K3 rngRELAT-1K2 R implies x inHIDDENR3 domRELAT-1K1 P \\/XBOOLE-0K2 rngRELAT-1K2 P & x inHIDDENR3 domRELAT-1K1 R \\/XBOOLE-0K2 rngRELAT-1K2 R"
        using xboole_0_def_3 sorry
      have "domRELAT-1K1 (P /\\XBOOLE-0K3 R) c=TARSKIR1 domRELAT-1K1 P /\\XBOOLE-0K3 domRELAT-1K1 R & rngRELAT-1K2 (P /\\XBOOLE-0K3 R) c=TARSKIR1 rngRELAT-1K2 P /\\XBOOLE-0K3 rngRELAT-1K2 R"
        using xtuple_0_th_24 xtuple_0_th_28 sorry
      thus "x inHIDDENR3 fieldRELAT-1K3 P /\\XBOOLE-0K3 fieldRELAT-1K3 R"
        using A1 A2 xboole_0_def_4 sorry
    qed "sorry"
    thus "fieldRELAT-1K3 (P /\\XBOOLE-0K3 R) c=TARSKIR1 fieldRELAT-1K3 P /\\XBOOLE-0K3 fieldRELAT-1K3 R"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef relat_1_def_7 (" _ ~RELAT-1K4" [228]228 ) where
  mlet "R be RelationRELAT-1M1"
"func R ~RELAT-1K4 \<rightarrow> RelationRELAT-1M1 means
  \<lambda>it.  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 it iff [TARSKIK4 y,x ] inHIDDENR3 R"
proof-
  (*existence*)
    show " ex it be RelationRELAT-1M1 st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 it iff [TARSKIK4 y,x ] inHIDDENR3 R"
    proof-
      have " ex tVar2 be RelationRELAT-1M1 st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 tVar2 &  not [TARSKIK4 y,x ] inHIDDENR3 R) &  not ([TARSKIK4 y,x ] inHIDDENR3 R &  not [TARSKIK4 x,y ] inHIDDENR3 tVar2)"
      proof-
        let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2. [TARSKIK4 Lamb2,Lamb1 ] inHIDDENR3 R"
        obtain P where
          [ty]:"P be RelationRELAT-1M1" and 
          A1: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 P iff (x inHIDDENR3 rngRELAT-1K2 R & y inHIDDENR3 domRELAT-1K1 R) & ?Q(x,y)"
          using relat_1_sch_1 sorry
        show " ex tVar2 be RelationRELAT-1M1 st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 tVar2 &  not [TARSKIK4 y,x ] inHIDDENR3 R) &  not ([TARSKIK4 y,x ] inHIDDENR3 R &  not [TARSKIK4 x,y ] inHIDDENR3 tVar2)"
        proof(rule bexI[of _ "P"],rule ballI,rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          have "[TARSKIK4 y,x ] inHIDDENR3 R implies y inHIDDENR3 domRELAT-1K1 R & x inHIDDENR3 rngRELAT-1K2 R"
            using xtuple_0_def_12 xtuple_0_def_13 sorry
          thus " not ([TARSKIK4 x,y ] inHIDDENR3 P &  not [TARSKIK4 y,x ] inHIDDENR3 R) &  not ([TARSKIK4 y,x ] inHIDDENR3 R &  not [TARSKIK4 x,y ] inHIDDENR3 P)"
            using A1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be RelationRELAT-1M1 holds  for it2 be RelationRELAT-1M1 holds ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 it1 iff [TARSKIK4 y,x ] inHIDDENR3 R) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 it2 iff [TARSKIK4 y,x ] inHIDDENR3 R) implies it1 =HIDDENR1 it2"
    proof-
      have " for P1 be RelationRELAT-1M1 holds  for P2 be RelationRELAT-1M1 holds ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 P1 iff [TARSKIK4 y,x ] inHIDDENR3 R) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 P2 iff [TARSKIK4 y,x ] inHIDDENR3 R) implies P1 =HIDDENR1 P2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix P1 assume [ty]: "P1 be RelationRELAT-1M1"
        fix P2 assume [ty]: "P2 be RelationRELAT-1M1"
        assume A2: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 P1 iff [TARSKIK4 y,x ] inHIDDENR3 R"
          and A3: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 P2 iff [TARSKIK4 y,x ] inHIDDENR3 R"
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 P1 iff [TARSKIK4 x,y ] inHIDDENR3 P2"
        proof(rule ballI,rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          have "[TARSKIK4 x,y ] inHIDDENR3 P1 iff [TARSKIK4 y,x ] inHIDDENR3 R"
            using A2 sorry
          thus "[TARSKIK4 x,y ] inHIDDENR3 P1 iff [TARSKIK4 x,y ] inHIDDENR3 P2"
            using A3 sorry
        qed "sorry"
        thus "P1 =HIDDENR1 P2"
          using relat_1_def_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem RELAT_1K4_involutiveness:
" for R be RelationRELAT-1M1 holds (R ~RELAT-1K4)~RELAT-1K4 =HIDDENR1 R"
proof-
  have " for it be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds it =HIDDENR1 R ~RELAT-1K4 implies R =HIDDENR1 it ~RELAT-1K4"
  proof-
    have " for it be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 it iff [TARSKIK4 y,x ] inHIDDENR3 R) implies ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R iff [TARSKIK4 y,x ] inHIDDENR3 it)"
       sorry
    thus " ?thesis "
      using relat_1_def_7 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_20:
" for R be RelationRELAT-1M1 holds rngRELAT-1K2 R =XBOOLE-0R4 domRELAT-1K1 (R ~RELAT-1K4) & domRELAT-1K1 R =XBOOLE-0R4 rngRELAT-1K2 (R ~RELAT-1K4)"
proof-
  have " for R be RelationRELAT-1M1 holds rngRELAT-1K2 R =XBOOLE-0R4 domRELAT-1K1 (R ~RELAT-1K4) & domRELAT-1K1 R =XBOOLE-0R4 rngRELAT-1K2 (R ~RELAT-1K4)"
  proof(rule ballI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have "rngRELAT-1K2 R c=TARSKIR1 domRELAT-1K1 (R ~RELAT-1K4) & (domRELAT-1K1 (R ~RELAT-1K4) c=TARSKIR1 rngRELAT-1K2 R & domRELAT-1K1 R =XBOOLE-0R4 rngRELAT-1K2 (R ~RELAT-1K4))"
    proof(rule conjMI,rule conjMI)
      show "rngRELAT-1K2 R c=TARSKIR1 domRELAT-1K1 (R ~RELAT-1K4)"
      proof-
        have " for u be objectHIDDENM1 holds u inHIDDENR3 rngRELAT-1K2 R implies u inHIDDENR3 domRELAT-1K1 (R ~RELAT-1K4)"
        proof(rule ballI,rule impI)
          fix u assume [ty]: "u be objectHIDDENM1"
          assume "u inHIDDENR3 rngRELAT-1K2 R"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A1: "[TARSKIK4 x,u ] inHIDDENR3 R"
            using xtuple_0_def_13 sorry
          have "[TARSKIK4 u,x ] inHIDDENR3 R ~RELAT-1K4"
            using A1 relat_1_def_7 sorry
          thus "u inHIDDENR3 domRELAT-1K1 (R ~RELAT-1K4)"
            using xtuple_0_def_12 sorry
        qed "sorry"
        thus "rngRELAT-1K2 R c=TARSKIR1 domRELAT-1K1 (R ~RELAT-1K4)"
          using tarski_def_3 sorry
      qed
      show "domRELAT-1K1 (R ~RELAT-1K4) c=TARSKIR1 rngRELAT-1K2 R"
      proof-
        have " for u be objectHIDDENM1 holds u inHIDDENR3 domRELAT-1K1 (R ~RELAT-1K4) implies u inHIDDENR3 rngRELAT-1K2 R"
        proof(rule ballI,rule impI)
          fix u assume [ty]: "u be objectHIDDENM1"
          assume "u inHIDDENR3 domRELAT-1K1 (R ~RELAT-1K4)"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A2: "[TARSKIK4 u,x ] inHIDDENR3 R ~RELAT-1K4"
            using xtuple_0_def_12 sorry
          have "[TARSKIK4 x,u ] inHIDDENR3 R"
            using A2 relat_1_def_7 sorry
          thus "u inHIDDENR3 rngRELAT-1K2 R"
            using xtuple_0_def_13 sorry
        qed "sorry"
        thus "domRELAT-1K1 (R ~RELAT-1K4) c=TARSKIR1 rngRELAT-1K2 R"
          using tarski_def_3 sorry
      qed
      have "domRELAT-1K1 R c=TARSKIR1 rngRELAT-1K2 (R ~RELAT-1K4) & rngRELAT-1K2 (R ~RELAT-1K4) c=TARSKIR1 domRELAT-1K1 R"
      proof(rule conjMI)
        show "domRELAT-1K1 R c=TARSKIR1 rngRELAT-1K2 (R ~RELAT-1K4)"
        proof-
          have " for u be objectHIDDENM1 holds u inHIDDENR3 domRELAT-1K1 R implies u inHIDDENR3 rngRELAT-1K2 (R ~RELAT-1K4)"
          proof(rule ballI,rule impI)
            fix u assume [ty]: "u be objectHIDDENM1"
            assume "u inHIDDENR3 domRELAT-1K1 R"
            then obtain x where
              [ty]:"x be objectHIDDENM1" and 
              A3: "[TARSKIK4 u,x ] inHIDDENR3 R"
              using xtuple_0_def_12 sorry
            have "[TARSKIK4 x,u ] inHIDDENR3 R ~RELAT-1K4"
              using A3 relat_1_def_7 sorry
            thus "u inHIDDENR3 rngRELAT-1K2 (R ~RELAT-1K4)"
              using xtuple_0_def_13 sorry
          qed "sorry"
          thus "domRELAT-1K1 R c=TARSKIR1 rngRELAT-1K2 (R ~RELAT-1K4)"
            using tarski_def_3 sorry
        qed
        have " for u be objectHIDDENM1 holds u inHIDDENR3 rngRELAT-1K2 (R ~RELAT-1K4) implies u inHIDDENR3 domRELAT-1K1 R"
        proof(rule ballI,rule impI)
          fix u assume [ty]: "u be objectHIDDENM1"
          assume "u inHIDDENR3 rngRELAT-1K2 (R ~RELAT-1K4)"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A4: "[TARSKIK4 x,u ] inHIDDENR3 R ~RELAT-1K4"
            using xtuple_0_def_13 sorry
          have "[TARSKIK4 u,x ] inHIDDENR3 R"
            using A4 relat_1_def_7 sorry
          thus "u inHIDDENR3 domRELAT-1K1 R"
            using xtuple_0_def_12 sorry
        qed "sorry"
        thus "rngRELAT-1K2 (R ~RELAT-1K4) c=TARSKIR1 domRELAT-1K1 R"
          using tarski_def_3 sorry
      qed
      thus "domRELAT-1K1 R =XBOOLE-0R4 rngRELAT-1K2 (R ~RELAT-1K4)"
        using xboole_0_def_10 sorry
    qed
    thus "rngRELAT-1K2 R =XBOOLE-0R4 domRELAT-1K1 (R ~RELAT-1K4) & domRELAT-1K1 R =XBOOLE-0R4 rngRELAT-1K2 (R ~RELAT-1K4)"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_21:
" for R be RelationRELAT-1M1 holds fieldRELAT-1K3 R =XBOOLE-0R4 fieldRELAT-1K3 (R ~RELAT-1K4)"
proof-
  have " for R be RelationRELAT-1M1 holds fieldRELAT-1K3 R =HIDDENR1 fieldRELAT-1K3 (R ~RELAT-1K4)"
  proof(rule ballI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have "fieldRELAT-1K3 R =HIDDENR1 rngRELAT-1K2 (R ~RELAT-1K4) \\/XBOOLE-0K2 rngRELAT-1K2 R"
      using relat_1_th_20 sorry
    also have "... = fieldRELAT-1K3 (R ~RELAT-1K4)"
      using relat_1_th_20 sorry
    finally show "fieldRELAT-1K3 R =HIDDENR1 fieldRELAT-1K3 (R ~RELAT-1K4)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_22:
" for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds (P /\\XBOOLE-0K3 R)~RELAT-1K4 =RELAT-1R1 P ~RELAT-1K4 /\\XBOOLE-0K3 R ~RELAT-1K4"
proof-
  have " for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds (P /\\XBOOLE-0K3 R)~RELAT-1K4 =RELAT-1R1 P ~RELAT-1K4 /\\XBOOLE-0K3 R ~RELAT-1K4"
  proof(rule ballI,rule ballI)
    fix P assume [ty]: "P be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 (P /\\XBOOLE-0K3 R)~RELAT-1K4 &  not [TARSKIK4 x,y ] inHIDDENR3 P ~RELAT-1K4 /\\XBOOLE-0K3 R ~RELAT-1K4) &  not ([TARSKIK4 x,y ] inHIDDENR3 P ~RELAT-1K4 /\\XBOOLE-0K3 R ~RELAT-1K4 &  not [TARSKIK4 x,y ] inHIDDENR3 (P /\\XBOOLE-0K3 R)~RELAT-1K4)"
    proof(rule ballI,rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      have "[TARSKIK4 x,y ] inHIDDENR3 (P /\\XBOOLE-0K3 R)~RELAT-1K4 iff [TARSKIK4 y,x ] inHIDDENR3 P /\\XBOOLE-0K3 R"
        using relat_1_def_7 sorry
      then have "[TARSKIK4 x,y ] inHIDDENR3 (P /\\XBOOLE-0K3 R)~RELAT-1K4 iff [TARSKIK4 y,x ] inHIDDENR3 P & [TARSKIK4 y,x ] inHIDDENR3 R"
        using xboole_0_def_4 sorry
      then have "[TARSKIK4 x,y ] inHIDDENR3 (P /\\XBOOLE-0K3 R)~RELAT-1K4 iff [TARSKIK4 x,y ] inHIDDENR3 P ~RELAT-1K4 & [TARSKIK4 x,y ] inHIDDENR3 R ~RELAT-1K4"
        using relat_1_def_7 sorry
      thus " not ([TARSKIK4 x,y ] inHIDDENR3 (P /\\XBOOLE-0K3 R)~RELAT-1K4 &  not [TARSKIK4 x,y ] inHIDDENR3 P ~RELAT-1K4 /\\XBOOLE-0K3 R ~RELAT-1K4) &  not ([TARSKIK4 x,y ] inHIDDENR3 P ~RELAT-1K4 /\\XBOOLE-0K3 R ~RELAT-1K4 &  not [TARSKIK4 x,y ] inHIDDENR3 (P /\\XBOOLE-0K3 R)~RELAT-1K4)"
        using xboole_0_def_4 sorry
    qed "sorry"
    thus "(P /\\XBOOLE-0K3 R)~RELAT-1K4 =RELAT-1R1 P ~RELAT-1K4 /\\XBOOLE-0K3 R ~RELAT-1K4"
      using relat_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_23:
" for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds (P \\/XBOOLE-0K2 R)~RELAT-1K4 =RELAT-1R1 P ~RELAT-1K4 \\/XBOOLE-0K2 R ~RELAT-1K4"
proof-
  have " for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds (P \\/XBOOLE-0K2 R)~RELAT-1K4 =RELAT-1R1 P ~RELAT-1K4 \\/XBOOLE-0K2 R ~RELAT-1K4"
  proof(rule ballI,rule ballI)
    fix P assume [ty]: "P be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 (P \\/XBOOLE-0K2 R)~RELAT-1K4 &  not [TARSKIK4 x,y ] inHIDDENR3 P ~RELAT-1K4 \\/XBOOLE-0K2 R ~RELAT-1K4) &  not ([TARSKIK4 x,y ] inHIDDENR3 P ~RELAT-1K4 \\/XBOOLE-0K2 R ~RELAT-1K4 &  not [TARSKIK4 x,y ] inHIDDENR3 (P \\/XBOOLE-0K2 R)~RELAT-1K4)"
    proof(rule ballI,rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      have "[TARSKIK4 x,y ] inHIDDENR3 (P \\/XBOOLE-0K2 R)~RELAT-1K4 iff [TARSKIK4 y,x ] inHIDDENR3 P \\/XBOOLE-0K2 R"
        using relat_1_def_7 sorry
      then have "[TARSKIK4 x,y ] inHIDDENR3 (P \\/XBOOLE-0K2 R)~RELAT-1K4 iff [TARSKIK4 y,x ] inHIDDENR3 P or [TARSKIK4 y,x ] inHIDDENR3 R"
        using xboole_0_def_3 sorry
      then have "[TARSKIK4 x,y ] inHIDDENR3 (P \\/XBOOLE-0K2 R)~RELAT-1K4 iff [TARSKIK4 x,y ] inHIDDENR3 P ~RELAT-1K4 or [TARSKIK4 x,y ] inHIDDENR3 R ~RELAT-1K4"
        using relat_1_def_7 sorry
      thus " not ([TARSKIK4 x,y ] inHIDDENR3 (P \\/XBOOLE-0K2 R)~RELAT-1K4 &  not [TARSKIK4 x,y ] inHIDDENR3 P ~RELAT-1K4 \\/XBOOLE-0K2 R ~RELAT-1K4) &  not ([TARSKIK4 x,y ] inHIDDENR3 P ~RELAT-1K4 \\/XBOOLE-0K2 R ~RELAT-1K4 &  not [TARSKIK4 x,y ] inHIDDENR3 (P \\/XBOOLE-0K2 R)~RELAT-1K4)"
        using xboole_0_def_3 sorry
    qed "sorry"
    thus "(P \\/XBOOLE-0K2 R)~RELAT-1K4 =RELAT-1R1 P ~RELAT-1K4 \\/XBOOLE-0K2 R ~RELAT-1K4"
      using relat_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_24:
" for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds (P \\SUBSET-1K6 R)~RELAT-1K4 =RELAT-1R1 P ~RELAT-1K4 \\SUBSET-1K6 R ~RELAT-1K4"
proof-
  have " for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds (P \\SUBSET-1K6 R)~RELAT-1K4 =RELAT-1R1 P ~RELAT-1K4 \\SUBSET-1K6 R ~RELAT-1K4"
  proof(rule ballI,rule ballI)
    fix P assume [ty]: "P be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 (P \\SUBSET-1K6 R)~RELAT-1K4 &  not [TARSKIK4 x,y ] inHIDDENR3 P ~RELAT-1K4 \\SUBSET-1K6 R ~RELAT-1K4) &  not ([TARSKIK4 x,y ] inHIDDENR3 P ~RELAT-1K4 \\SUBSET-1K6 R ~RELAT-1K4 &  not [TARSKIK4 x,y ] inHIDDENR3 (P \\SUBSET-1K6 R)~RELAT-1K4)"
    proof(rule ballI,rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      have "[TARSKIK4 x,y ] inHIDDENR3 (P \\SUBSET-1K6 R)~RELAT-1K4 iff [TARSKIK4 y,x ] inHIDDENR3 P \\SUBSET-1K6 R"
        using relat_1_def_7 sorry
      then have "[TARSKIK4 x,y ] inHIDDENR3 (P \\SUBSET-1K6 R)~RELAT-1K4 iff [TARSKIK4 y,x ] inHIDDENR3 P &  not [TARSKIK4 y,x ] inHIDDENR3 R"
        using xboole_0_def_5 sorry
      then have "[TARSKIK4 x,y ] inHIDDENR3 (P \\SUBSET-1K6 R)~RELAT-1K4 iff [TARSKIK4 x,y ] inHIDDENR3 P ~RELAT-1K4 &  not [TARSKIK4 x,y ] inHIDDENR3 R ~RELAT-1K4"
        using relat_1_def_7 sorry
      thus " not ([TARSKIK4 x,y ] inHIDDENR3 (P \\SUBSET-1K6 R)~RELAT-1K4 &  not [TARSKIK4 x,y ] inHIDDENR3 P ~RELAT-1K4 \\SUBSET-1K6 R ~RELAT-1K4) &  not ([TARSKIK4 x,y ] inHIDDENR3 P ~RELAT-1K4 \\SUBSET-1K6 R ~RELAT-1K4 &  not [TARSKIK4 x,y ] inHIDDENR3 (P \\SUBSET-1K6 R)~RELAT-1K4)"
        using xboole_0_def_5 sorry
    qed "sorry"
    thus "(P \\SUBSET-1K6 R)~RELAT-1K4 =RELAT-1R1 P ~RELAT-1K4 \\SUBSET-1K6 R ~RELAT-1K4"
      using relat_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef relat_1_def_8 (" _ '(#')RELAT-1K5  _ " [164,164]164 ) where
  mlet "P be setHIDDENM2", "R be setHIDDENM2"
"func P (#)RELAT-1K5 R \<rightarrow> RelationRELAT-1M1 means
  \<lambda>it.  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 it iff ( ex z be objectHIDDENM1 st [TARSKIK4 x,z ] inHIDDENR3 P & [TARSKIK4 z,y ] inHIDDENR3 R)"
proof-
  (*existence*)
    show " ex it be RelationRELAT-1M1 st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 it iff ( ex z be objectHIDDENM1 st [TARSKIK4 x,z ] inHIDDENR3 P & [TARSKIK4 z,y ] inHIDDENR3 R)"
    proof-
      have " ex tVar3 be RelationRELAT-1M1 st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 tVar3 implies ( ex z be objectHIDDENM1 st [TARSKIK4 x,z ] inHIDDENR3 P & [TARSKIK4 z,y ] inHIDDENR3 R)) & (( ex z be objectHIDDENM1 st [TARSKIK4 x,z ] inHIDDENR3 P & [TARSKIK4 z,y ] inHIDDENR3 R) implies [TARSKIK4 x,y ] inHIDDENR3 tVar3)"
      proof-
        let ?Z = "\<lambda>Lamb1. \<lambda>Lamb2.  ex z be objectHIDDENM1 st [TARSKIK4 Lamb1,z ] inHIDDENR3 P & [TARSKIK4 z,Lamb2 ] inHIDDENR3 R"
        obtain Q where
          [ty]:"Q be RelationRELAT-1M1" and 
          A1: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 Q iff (x inHIDDENR3 proj1XTUPLE-0K12 P & y inHIDDENR3 proj2XTUPLE-0K13 R) & ?Z(x,y)"
          using relat_1_sch_1 sorry
        show " ex tVar3 be RelationRELAT-1M1 st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 tVar3 implies ( ex z be objectHIDDENM1 st [TARSKIK4 x,z ] inHIDDENR3 P & [TARSKIK4 z,y ] inHIDDENR3 R)) & (( ex z be objectHIDDENM1 st [TARSKIK4 x,z ] inHIDDENR3 P & [TARSKIK4 z,y ] inHIDDENR3 R) implies [TARSKIK4 x,y ] inHIDDENR3 tVar3)"
        proof(rule bexI[of _ "Q"],rule ballI,rule ballI,rule conjMI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          show "[TARSKIK4 x,y ] inHIDDENR3 Q implies ( ex z be objectHIDDENM1 st [TARSKIK4 x,z ] inHIDDENR3 P & [TARSKIK4 z,y ] inHIDDENR3 R)"
            using A1 sorry
          assume Given: " ex z be objectHIDDENM1 st [TARSKIK4 x,z ] inHIDDENR3 P & [TARSKIK4 z,y ] inHIDDENR3 R"
          then obtain z where
            [ty]:"z be objectHIDDENM1" and 
            A2: "[TARSKIK4 x,z ] inHIDDENR3 P & [TARSKIK4 z,y ] inHIDDENR3 R"
             sorry
          have "x inHIDDENR3 proj1XTUPLE-0K12 P & y inHIDDENR3 proj2XTUPLE-0K13 R"
            using A2 xtuple_0_def_12 xtuple_0_def_13 sorry
          thus "[TARSKIK4 x,y ] inHIDDENR3 Q"
            using A1 A2 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be RelationRELAT-1M1 holds  for it2 be RelationRELAT-1M1 holds ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 it1 iff ( ex z be objectHIDDENM1 st [TARSKIK4 x,z ] inHIDDENR3 P & [TARSKIK4 z,y ] inHIDDENR3 R)) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 it2 iff ( ex z be objectHIDDENM1 st [TARSKIK4 x,z ] inHIDDENR3 P & [TARSKIK4 z,y ] inHIDDENR3 R)) implies it1 =HIDDENR1 it2"
    proof-
      have " for P1 be RelationRELAT-1M1 holds  for P2 be RelationRELAT-1M1 holds ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 P1 iff ( ex z be objectHIDDENM1 st [TARSKIK4 x,z ] inHIDDENR3 P & [TARSKIK4 z,y ] inHIDDENR3 R)) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 P2 iff ( ex z be objectHIDDENM1 st [TARSKIK4 x,z ] inHIDDENR3 P & [TARSKIK4 z,y ] inHIDDENR3 R)) implies P1 =HIDDENR1 P2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix P1 assume [ty]: "P1 be RelationRELAT-1M1"
        fix P2 assume [ty]: "P2 be RelationRELAT-1M1"
        assume A3: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 P1 iff ( ex z be objectHIDDENM1 st [TARSKIK4 x,z ] inHIDDENR3 P & [TARSKIK4 z,y ] inHIDDENR3 R)"
          and A4: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 P2 iff ( ex z be objectHIDDENM1 st [TARSKIK4 x,z ] inHIDDENR3 P & [TARSKIK4 z,y ] inHIDDENR3 R)"
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 P1 iff [TARSKIK4 x,y ] inHIDDENR3 P2"
        proof(rule ballI,rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          have "[TARSKIK4 x,y ] inHIDDENR3 P1 iff ( ex z be objectHIDDENM1 st [TARSKIK4 x,z ] inHIDDENR3 P & [TARSKIK4 z,y ] inHIDDENR3 R)"
            using A3 sorry
          thus "[TARSKIK4 x,y ] inHIDDENR3 P1 iff [TARSKIK4 x,y ] inHIDDENR3 P2"
            using A4 sorry
        qed "sorry"
        thus "P1 =HIDDENR1 P2"
          using relat_1_def_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

abbreviation(input) RELAT_1K6(" _ *RELAT-1K6  _ " [164,164]164) where
  "P *RELAT-1K6 R \<equiv> P (#)RELAT-1K5 R"

mtheorem relat_1_th_25:
" for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds domRELAT-1K1 (P *RELAT-1K6 R) c=TARSKIR1 domRELAT-1K1 P"
proof-
  have " for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds domRELAT-1K1 (P *RELAT-1K6 R) c=TARSKIR1 domRELAT-1K1 P"
  proof(rule ballI,rule ballI)
    fix P assume [ty]: "P be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (P *RELAT-1K6 R) implies x inHIDDENR3 domRELAT-1K1 P"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 domRELAT-1K1 (P *RELAT-1K6 R)"
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A1: "[TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 R"
        using xtuple_0_def_12 sorry
      have " ex z be objectHIDDENM1 st [TARSKIK4 x,z ] inHIDDENR3 P & [TARSKIK4 z,y ] inHIDDENR3 R"
        using A1 relat_1_def_8 sorry
      thus "x inHIDDENR3 domRELAT-1K1 P"
        using xtuple_0_def_12 sorry
    qed "sorry"
    thus "domRELAT-1K1 (P *RELAT-1K6 R) c=TARSKIR1 domRELAT-1K1 P"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_26:
" for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds rngRELAT-1K2 (P *RELAT-1K6 R) c=TARSKIR1 rngRELAT-1K2 R"
proof-
  have " for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds rngRELAT-1K2 (P *RELAT-1K6 R) c=TARSKIR1 rngRELAT-1K2 R"
  proof(rule ballI,rule ballI)
    fix P assume [ty]: "P be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 rngRELAT-1K2 (P *RELAT-1K6 R) implies y inHIDDENR3 rngRELAT-1K2 R"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 rngRELAT-1K2 (P *RELAT-1K6 R)"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A1: "[TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 R"
        using xtuple_0_def_13 sorry
      have " ex z be objectHIDDENM1 st [TARSKIK4 x,z ] inHIDDENR3 P & [TARSKIK4 z,y ] inHIDDENR3 R"
        using A1 relat_1_def_8 sorry
      thus "y inHIDDENR3 rngRELAT-1K2 R"
        using xtuple_0_def_13 sorry
    qed "sorry"
    thus "rngRELAT-1K2 (P *RELAT-1K6 R) c=TARSKIR1 rngRELAT-1K2 R"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_27:
" for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds rngRELAT-1K2 R c=TARSKIR1 domRELAT-1K1 P implies domRELAT-1K1 (R *RELAT-1K6 P) =XBOOLE-0R4 domRELAT-1K1 R"
proof-
  have " for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds  not (rngRELAT-1K2 R c=TARSKIR1 domRELAT-1K1 P &  not domRELAT-1K1 (R *RELAT-1K6 P) =XBOOLE-0R4 domRELAT-1K1 R)"
  proof(rule ballI,rule ballI)
    fix P assume [ty]: "P be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have "( for y be objectHIDDENM1 holds y inHIDDENR3 rngRELAT-1K2 R implies y inHIDDENR3 domRELAT-1K1 P) implies domRELAT-1K1 (R *RELAT-1K6 P) =XBOOLE-0R4 domRELAT-1K1 R"
    proof(rule impI)
      assume A1: " for y be objectHIDDENM1 holds y inHIDDENR3 rngRELAT-1K2 R implies y inHIDDENR3 domRELAT-1K1 P"
      have "domRELAT-1K1 (R *RELAT-1K6 P) c=TARSKIR1 domRELAT-1K1 R & domRELAT-1K1 R c=TARSKIR1 domRELAT-1K1 (R *RELAT-1K6 P)"
      proof(rule conjMI)
        show "domRELAT-1K1 (R *RELAT-1K6 P) c=TARSKIR1 domRELAT-1K1 R"
          using relat_1_th_25 sorry
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 R implies x inHIDDENR3 domRELAT-1K1 (R *RELAT-1K6 P)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 domRELAT-1K1 R"
          then obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A2: "[TARSKIK4 x,y ] inHIDDENR3 R"
            using xtuple_0_def_12 sorry
          have "y inHIDDENR3 rngRELAT-1K2 R"
            using A2 xtuple_0_def_13 sorry
          then have "y inHIDDENR3 domRELAT-1K1 P"
            using A1 sorry
          then obtain z where
            [ty]:"z be objectHIDDENM1" and 
            A3: "[TARSKIK4 y,z ] inHIDDENR3 P"
            using xtuple_0_def_12 sorry
          have "[TARSKIK4 x,z ] inHIDDENR3 R *RELAT-1K6 P"
            using A2 A3 relat_1_def_8 sorry
          thus "x inHIDDENR3 domRELAT-1K1 (R *RELAT-1K6 P)"
            using xtuple_0_def_12 sorry
        qed "sorry"
        thus "domRELAT-1K1 R c=TARSKIR1 domRELAT-1K1 (R *RELAT-1K6 P)"
          using tarski_def_3 sorry
      qed
      thus "domRELAT-1K1 (R *RELAT-1K6 P) =XBOOLE-0R4 domRELAT-1K1 R"
        using xboole_0_def_10 sorry
    qed
    thus " not (rngRELAT-1K2 R c=TARSKIR1 domRELAT-1K1 P &  not domRELAT-1K1 (R *RELAT-1K6 P) =XBOOLE-0R4 domRELAT-1K1 R)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_28:
" for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds domRELAT-1K1 P c=TARSKIR1 rngRELAT-1K2 R implies rngRELAT-1K2 (R *RELAT-1K6 P) =XBOOLE-0R4 rngRELAT-1K2 P"
proof-
  have " for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds  not (domRELAT-1K1 P c=TARSKIR1 rngRELAT-1K2 R &  not rngRELAT-1K2 (R *RELAT-1K6 P) =XBOOLE-0R4 rngRELAT-1K2 P)"
  proof(rule ballI,rule ballI)
    fix P assume [ty]: "P be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have "( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 P implies y inHIDDENR3 rngRELAT-1K2 R) implies rngRELAT-1K2 (R *RELAT-1K6 P) =XBOOLE-0R4 rngRELAT-1K2 P"
    proof(rule impI)
      assume A1: " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 P implies y inHIDDENR3 rngRELAT-1K2 R"
      have "rngRELAT-1K2 (R *RELAT-1K6 P) c=TARSKIR1 rngRELAT-1K2 P & rngRELAT-1K2 P c=TARSKIR1 rngRELAT-1K2 (R *RELAT-1K6 P)"
      proof(rule conjMI)
        show "rngRELAT-1K2 (R *RELAT-1K6 P) c=TARSKIR1 rngRELAT-1K2 P"
          using relat_1_th_26 sorry
        have " for z be objectHIDDENM1 holds z inHIDDENR3 rngRELAT-1K2 P implies z inHIDDENR3 rngRELAT-1K2 (R *RELAT-1K6 P)"
        proof(rule ballI,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          assume "z inHIDDENR3 rngRELAT-1K2 P"
          then obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A2: "[TARSKIK4 y,z ] inHIDDENR3 P"
            using xtuple_0_def_13 sorry
          have "y inHIDDENR3 domRELAT-1K1 P"
            using A2 xtuple_0_def_12 sorry
          then have "y inHIDDENR3 rngRELAT-1K2 R"
            using A1 sorry
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A3: "[TARSKIK4 x,y ] inHIDDENR3 R"
            using xtuple_0_def_13 sorry
          have "[TARSKIK4 x,z ] inHIDDENR3 R *RELAT-1K6 P"
            using A2 A3 relat_1_def_8 sorry
          thus "z inHIDDENR3 rngRELAT-1K2 (R *RELAT-1K6 P)"
            using xtuple_0_def_13 sorry
        qed "sorry"
        thus "rngRELAT-1K2 P c=TARSKIR1 rngRELAT-1K2 (R *RELAT-1K6 P)"
          using tarski_def_3 sorry
      qed
      thus "rngRELAT-1K2 (R *RELAT-1K6 P) =XBOOLE-0R4 rngRELAT-1K2 P"
        using xboole_0_def_10 sorry
    qed
    thus " not (domRELAT-1K1 P c=TARSKIR1 rngRELAT-1K2 R &  not rngRELAT-1K2 (R *RELAT-1K6 P) =XBOOLE-0R4 rngRELAT-1K2 P)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_29:
" for P be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds P c=RELAT-1R2 R implies Q *RELAT-1K6 P c=RELAT-1R2 Q *RELAT-1K6 R"
proof-
  have " for P be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds P c=RELAT-1R2 R implies Q *RELAT-1K6 P c=RELAT-1R2 Q *RELAT-1K6 R"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix P assume [ty]: "P be RelationRELAT-1M1"
    fix Q assume [ty]: "Q be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume A1: "P c=RELAT-1R2 R"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 Q *RELAT-1K6 P implies [TARSKIK4 x,y ] inHIDDENR3 Q *RELAT-1K6 R"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "[TARSKIK4 x,y ] inHIDDENR3 Q *RELAT-1K6 P"
      then have " ex z be objectHIDDENM1 st [TARSKIK4 x,z ] inHIDDENR3 Q & [TARSKIK4 z,y ] inHIDDENR3 P"
        using relat_1_def_8 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 Q *RELAT-1K6 R"
        using A1 relat_1_def_8 sorry
    qed "sorry"
    thus "Q *RELAT-1K6 P c=RELAT-1R2 Q *RELAT-1K6 R"
      using relat_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_30:
" for P be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds P c=RELAT-1R2 Q implies P *RELAT-1K6 R c=RELAT-1R2 Q *RELAT-1K6 R"
proof-
  have " for P be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds P c=RELAT-1R2 Q implies P *RELAT-1K6 R c=RELAT-1R2 Q *RELAT-1K6 R"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix P assume [ty]: "P be RelationRELAT-1M1"
    fix Q assume [ty]: "Q be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume A1: "P c=RELAT-1R2 Q"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 R implies [TARSKIK4 x,y ] inHIDDENR3 Q *RELAT-1K6 R"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "[TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 R"
      then have " ex z be objectHIDDENM1 st [TARSKIK4 x,z ] inHIDDENR3 P & [TARSKIK4 z,y ] inHIDDENR3 R"
        using relat_1_def_8 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 Q *RELAT-1K6 R"
        using A1 relat_1_def_8 sorry
    qed "sorry"
    thus "P *RELAT-1K6 R c=RELAT-1R2 Q *RELAT-1K6 R"
      using relat_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_31:
" for P be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds  for S be RelationRELAT-1M1 holds P c=RELAT-1R2 R & Q c=RELAT-1R2 S implies P *RELAT-1K6 Q c=RELAT-1R2 R *RELAT-1K6 S"
proof-
  have " for P be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds  for S be RelationRELAT-1M1 holds P c=RELAT-1R2 R & Q c=RELAT-1R2 S implies P *RELAT-1K6 Q c=RELAT-1R2 R *RELAT-1K6 S"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix P assume [ty]: "P be RelationRELAT-1M1"
    fix Q assume [ty]: "Q be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix S assume [ty]: "S be RelationRELAT-1M1"
    assume A1: "P c=RELAT-1R2 R & Q c=RELAT-1R2 S"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 Q implies [TARSKIK4 x,y ] inHIDDENR3 R *RELAT-1K6 S"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "[TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 Q"
      then have " ex z be objectHIDDENM1 st [TARSKIK4 x,z ] inHIDDENR3 P & [TARSKIK4 z,y ] inHIDDENR3 Q"
        using relat_1_def_8 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 R *RELAT-1K6 S"
        using A1 relat_1_def_8 sorry
    qed "sorry"
    thus "P *RELAT-1K6 Q c=RELAT-1R2 R *RELAT-1K6 S"
      using relat_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_32:
" for P be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds P *RELAT-1K6 (R \\/XBOOLE-0K2 Q) =RELAT-1R1 P *RELAT-1K6 R \\/XBOOLE-0K2 P *RELAT-1K6 Q"
proof-
  have " for P be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds P *RELAT-1K6 (R \\/XBOOLE-0K2 Q) =RELAT-1R1 P *RELAT-1K6 R \\/XBOOLE-0K2 P *RELAT-1K6 Q"
  proof(rule ballI,rule ballI,rule ballI)
    fix P assume [ty]: "P be RelationRELAT-1M1"
    fix Q assume [ty]: "Q be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 (R \\/XBOOLE-0K2 Q) implies [TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 R \\/XBOOLE-0K2 P *RELAT-1K6 Q) & ([TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 R \\/XBOOLE-0K2 P *RELAT-1K6 Q implies [TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 (R \\/XBOOLE-0K2 Q))"
    proof(rule ballI,rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      show "[TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 (R \\/XBOOLE-0K2 Q) implies [TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 R \\/XBOOLE-0K2 P *RELAT-1K6 Q"
      proof(rule impI)
        assume "[TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 (R \\/XBOOLE-0K2 Q)"
        then obtain z where
          [ty]:"z be objectHIDDENM1" and 
          A1: "[TARSKIK4 x,z ] inHIDDENR3 P"and A2: "[TARSKIK4 z,y ] inHIDDENR3 R \\/XBOOLE-0K2 Q"
          using relat_1_def_8 sorry
        have "[TARSKIK4 z,y ] inHIDDENR3 R or [TARSKIK4 z,y ] inHIDDENR3 Q"
          using A2 xboole_0_def_3 sorry
        then have "[TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 R or [TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 Q"
          using A1 relat_1_def_8 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 R \\/XBOOLE-0K2 P *RELAT-1K6 Q"
          using xboole_0_def_3 sorry
      qed
      assume A3: "[TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 R \\/XBOOLE-0K2 P *RELAT-1K6 Q"
      show "[TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 (R \\/XBOOLE-0K2 Q)"
      proof-
        have cases: "[TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 Q or [TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 R"
          using A3 xboole_0_def_3 sorry
        have case1: "[TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 Q implies [TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 (R \\/XBOOLE-0K2 Q)"
        proof(rule impI)
          assume "[TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 Q"
          then obtain z where
            [ty]:"z be objectHIDDENM1" and 
            A4: "[TARSKIK4 x,z ] inHIDDENR3 P"and A5: "[TARSKIK4 z,y ] inHIDDENR3 Q"
            using relat_1_def_8 sorry
          have "[TARSKIK4 z,y ] inHIDDENR3 R \\/XBOOLE-0K2 Q"
            using A5 xboole_0_def_3 sorry
          thus "[TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 (R \\/XBOOLE-0K2 Q)"
            using A4 relat_1_def_8 sorry
        qed
        have case2: "[TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 R implies [TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 (R \\/XBOOLE-0K2 Q)"
        proof(rule impI)
          assume "[TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 R"
          then obtain z where
            [ty]:"z be objectHIDDENM1" and 
            A6: "[TARSKIK4 x,z ] inHIDDENR3 P"and A7: "[TARSKIK4 z,y ] inHIDDENR3 R"
            using relat_1_def_8 sorry
          have "[TARSKIK4 z,y ] inHIDDENR3 R \\/XBOOLE-0K2 Q"
            using A7 xboole_0_def_3 sorry
          thus "[TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 (R \\/XBOOLE-0K2 Q)"
            using A6 relat_1_def_8 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus "P *RELAT-1K6 (R \\/XBOOLE-0K2 Q) =RELAT-1R1 P *RELAT-1K6 R \\/XBOOLE-0K2 P *RELAT-1K6 Q"
      using relat_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_33:
" for P be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds P *RELAT-1K6 (R /\\XBOOLE-0K3 Q) c=RELAT-1R2 (P *RELAT-1K6 R)/\\XBOOLE-0K3 (P *RELAT-1K6 Q)"
proof-
  have " for P be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds P *RELAT-1K6 (R /\\XBOOLE-0K3 Q) c=RELAT-1R2 (P *RELAT-1K6 R)/\\XBOOLE-0K3 (P *RELAT-1K6 Q)"
  proof(rule ballI,rule ballI,rule ballI)
    fix P assume [ty]: "P be RelationRELAT-1M1"
    fix Q assume [ty]: "Q be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 (R /\\XBOOLE-0K3 Q) implies [TARSKIK4 x,y ] inHIDDENR3 (P *RELAT-1K6 R)/\\XBOOLE-0K3 (P *RELAT-1K6 Q)"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "[TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 (R /\\XBOOLE-0K3 Q)"
      then obtain z where
        [ty]:"z be objectHIDDENM1" and 
        A1: "[TARSKIK4 x,z ] inHIDDENR3 P"and A2: "[TARSKIK4 z,y ] inHIDDENR3 R /\\XBOOLE-0K3 Q"
        using relat_1_def_8 sorry
      have "[TARSKIK4 z,y ] inHIDDENR3 Q"
        using A2 xboole_0_def_4 sorry
      then have A3: "[TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 Q"
        using A1 relat_1_def_8 sorry
      have "[TARSKIK4 z,y ] inHIDDENR3 R"
        using A2 xboole_0_def_4 sorry
      then have "[TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 R"
        using A1 relat_1_def_8 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 (P *RELAT-1K6 R)/\\XBOOLE-0K3 (P *RELAT-1K6 Q)"
        using A3 xboole_0_def_4 sorry
    qed "sorry"
    thus "P *RELAT-1K6 (R /\\XBOOLE-0K3 Q) c=RELAT-1R2 (P *RELAT-1K6 R)/\\XBOOLE-0K3 (P *RELAT-1K6 Q)"
      using relat_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_34:
" for P be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds P *RELAT-1K6 R \\SUBSET-1K6 P *RELAT-1K6 Q c=RELAT-1R2 P *RELAT-1K6 (R \\SUBSET-1K6 Q)"
proof-
  have " for P be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds P *RELAT-1K6 R \\SUBSET-1K6 P *RELAT-1K6 Q c=RELAT-1R2 P *RELAT-1K6 (R \\SUBSET-1K6 Q)"
  proof(rule ballI,rule ballI,rule ballI)
    fix P assume [ty]: "P be RelationRELAT-1M1"
    fix Q assume [ty]: "Q be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 P *RELAT-1K6 R \\SUBSET-1K6 P *RELAT-1K6 Q implies [TARSKIK4 a,b ] inHIDDENR3 P *RELAT-1K6 (R \\SUBSET-1K6 Q)"
    proof(rule ballI,rule ballI,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      fix b assume [ty]: "b be objectHIDDENM1"
      assume A1: "[TARSKIK4 a,b ] inHIDDENR3 P *RELAT-1K6 R \\SUBSET-1K6 P *RELAT-1K6 Q"
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A2: "[TARSKIK4 a,y ] inHIDDENR3 P"and A3: "[TARSKIK4 y,b ] inHIDDENR3 R"
        using relat_1_def_8 sorry
      have " not [TARSKIK4 a,b ] inHIDDENR3 P *RELAT-1K6 Q"
        using A1 xboole_0_def_5 sorry
      then have " not [TARSKIK4 a,y ] inHIDDENR3 P or  not [TARSKIK4 y,b ] inHIDDENR3 Q"
        using relat_1_def_8 sorry
      then have "[TARSKIK4 y,b ] inHIDDENR3 R \\SUBSET-1K6 Q"
        using A2 A3 xboole_0_def_5 sorry
      thus "[TARSKIK4 a,b ] inHIDDENR3 P *RELAT-1K6 (R \\SUBSET-1K6 Q)"
        using A2 relat_1_def_8 sorry
    qed "sorry"
    thus "P *RELAT-1K6 R \\SUBSET-1K6 P *RELAT-1K6 Q c=RELAT-1R2 P *RELAT-1K6 (R \\SUBSET-1K6 Q)"
      using relat_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_35:
" for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds (P *RELAT-1K6 R)~RELAT-1K4 =RELAT-1R1 R ~RELAT-1K4 *RELAT-1K6 P ~RELAT-1K4"
proof-
  have " for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds (P *RELAT-1K6 R)~RELAT-1K4 =RELAT-1R1 R ~RELAT-1K4 *RELAT-1K6 P ~RELAT-1K4"
  proof(rule ballI,rule ballI)
    fix P assume [ty]: "P be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds ([TARSKIK4 a,b ] inHIDDENR3 (P *RELAT-1K6 R)~RELAT-1K4 implies [TARSKIK4 a,b ] inHIDDENR3 R ~RELAT-1K4 *RELAT-1K6 P ~RELAT-1K4) & ([TARSKIK4 a,b ] inHIDDENR3 R ~RELAT-1K4 *RELAT-1K6 P ~RELAT-1K4 implies [TARSKIK4 a,b ] inHIDDENR3 (P *RELAT-1K6 R)~RELAT-1K4)"
    proof(rule ballI,rule ballI,rule conjMI,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      fix b assume [ty]: "b be objectHIDDENM1"
      show "[TARSKIK4 a,b ] inHIDDENR3 (P *RELAT-1K6 R)~RELAT-1K4 implies [TARSKIK4 a,b ] inHIDDENR3 R ~RELAT-1K4 *RELAT-1K6 P ~RELAT-1K4"
      proof(rule impI)
        assume "[TARSKIK4 a,b ] inHIDDENR3 (P *RELAT-1K6 R)~RELAT-1K4"
        then have "[TARSKIK4 b,a ] inHIDDENR3 P *RELAT-1K6 R"
          using relat_1_def_7 sorry
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A1: "[TARSKIK4 b,y ] inHIDDENR3 P & [TARSKIK4 y,a ] inHIDDENR3 R"
          using relat_1_def_8 sorry
        have "[TARSKIK4 y,b ] inHIDDENR3 P ~RELAT-1K4 & [TARSKIK4 a,y ] inHIDDENR3 R ~RELAT-1K4"
          using A1 relat_1_def_7 sorry
        thus "[TARSKIK4 a,b ] inHIDDENR3 R ~RELAT-1K4 *RELAT-1K6 P ~RELAT-1K4"
          using relat_1_def_8 sorry
      qed
      assume "[TARSKIK4 a,b ] inHIDDENR3 R ~RELAT-1K4 *RELAT-1K6 P ~RELAT-1K4"
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A2: "[TARSKIK4 a,y ] inHIDDENR3 R ~RELAT-1K4 & [TARSKIK4 y,b ] inHIDDENR3 P ~RELAT-1K4"
        using relat_1_def_8 sorry
      have "[TARSKIK4 y,a ] inHIDDENR3 R & [TARSKIK4 b,y ] inHIDDENR3 P"
        using A2 relat_1_def_7 sorry
      then have "[TARSKIK4 b,a ] inHIDDENR3 P *RELAT-1K6 R"
        using relat_1_def_8 sorry
      thus "[TARSKIK4 a,b ] inHIDDENR3 (P *RELAT-1K6 R)~RELAT-1K4"
        using relat_1_def_7 sorry
    qed "sorry"
    thus "(P *RELAT-1K6 R)~RELAT-1K4 =RELAT-1R1 R ~RELAT-1K4 *RELAT-1K6 P ~RELAT-1K4"
      using relat_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_36:
" for P be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds (P *RELAT-1K6 R)*RELAT-1K6 Q =RELAT-1R1 P *RELAT-1K6 (R *RELAT-1K6 Q)"
proof-
  have " for P be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds (P *RELAT-1K6 R)*RELAT-1K6 Q =RELAT-1R1 P *RELAT-1K6 (R *RELAT-1K6 Q)"
  proof(rule ballI,rule ballI,rule ballI)
    fix P assume [ty]: "P be RelationRELAT-1M1"
    fix Q assume [ty]: "Q be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds ([TARSKIK4 a,b ] inHIDDENR3 (P *RELAT-1K6 R)*RELAT-1K6 Q implies [TARSKIK4 a,b ] inHIDDENR3 P *RELAT-1K6 (R *RELAT-1K6 Q)) & ([TARSKIK4 a,b ] inHIDDENR3 P *RELAT-1K6 (R *RELAT-1K6 Q) implies [TARSKIK4 a,b ] inHIDDENR3 (P *RELAT-1K6 R)*RELAT-1K6 Q)"
    proof(rule ballI,rule ballI,rule conjMI,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      fix b assume [ty]: "b be objectHIDDENM1"
      show "[TARSKIK4 a,b ] inHIDDENR3 (P *RELAT-1K6 R)*RELAT-1K6 Q implies [TARSKIK4 a,b ] inHIDDENR3 P *RELAT-1K6 (R *RELAT-1K6 Q)"
      proof(rule impI)
        assume "[TARSKIK4 a,b ] inHIDDENR3 (P *RELAT-1K6 R)*RELAT-1K6 Q"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A1: "[TARSKIK4 a,y ] inHIDDENR3 P *RELAT-1K6 R"and A2: "[TARSKIK4 y,b ] inHIDDENR3 Q"
          using relat_1_def_8 sorry
        obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A3: "[TARSKIK4 a,x ] inHIDDENR3 P"and A4: "[TARSKIK4 x,y ] inHIDDENR3 R"
          using A1 relat_1_def_8 sorry
        have "[TARSKIK4 x,b ] inHIDDENR3 R *RELAT-1K6 Q"
          using A2 A4 relat_1_def_8 sorry
        thus "[TARSKIK4 a,b ] inHIDDENR3 P *RELAT-1K6 (R *RELAT-1K6 Q)"
          using A3 relat_1_def_8 sorry
      qed
      assume "[TARSKIK4 a,b ] inHIDDENR3 P *RELAT-1K6 (R *RELAT-1K6 Q)"
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A5: "[TARSKIK4 a,y ] inHIDDENR3 P"and A6: "[TARSKIK4 y,b ] inHIDDENR3 R *RELAT-1K6 Q"
        using relat_1_def_8 sorry
      obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A7: "[TARSKIK4 y,x ] inHIDDENR3 R"and A8: "[TARSKIK4 x,b ] inHIDDENR3 Q"
        using A6 relat_1_def_8 sorry
      have "[TARSKIK4 a,x ] inHIDDENR3 P *RELAT-1K6 R"
        using A5 A7 relat_1_def_8 sorry
      thus "[TARSKIK4 a,b ] inHIDDENR3 (P *RELAT-1K6 R)*RELAT-1K6 Q"
        using A8 relat_1_def_8 sorry
    qed "sorry"
    thus "(P *RELAT-1K6 R)*RELAT-1K6 Q =RELAT-1R1 P *RELAT-1K6 (R *RELAT-1K6 Q)"
      using relat_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_cl_10:
"cluster  non emptyXBOOLE-0V1 for RelationRELAT-1M1"
proof
(*existence*)
  show " ex it be RelationRELAT-1M1 st it be  non emptyXBOOLE-0V1"
  proof-
    have " not ( for VarFor1 be RelationRELAT-1M1 holds VarFor1 be emptyXBOOLE-0V1)"
    proof-
      have "{TARSKIK1 [TARSKIK4 {}XBOOLE-0K1,{}XBOOLE-0K1 ] } be  non emptyXBOOLE-0V1"
         sorry
      thus " not ( for VarFor1 be RelationRELAT-1M1 holds VarFor1 be emptyXBOOLE-0V1)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem relat_1_cl_11:
  mlet "f be  non emptyXBOOLE-0V1\<bar>RelationRELAT-1M1"
"cluster domRELAT-1K1 f as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "domRELAT-1K1 f be  non emptyXBOOLE-0V1"
  proof-
    have " not domRELAT-1K1 f be emptyXBOOLE-0V1"
    proof-
      have " ex x1 be objectHIDDENM1 st  ex x2 be objectHIDDENM1 st the ElementSUBSET-1M1-of f =HIDDENR1 [TARSKIK4 x1,x2 ]"
        using relat_1_def_1 sorry
      thus " not domRELAT-1K1 f be emptyXBOOLE-0V1"
        using xtuple_0_def_12 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem relat_1_cl_12:
  mlet "f be  non emptyXBOOLE-0V1\<bar>RelationRELAT-1M1"
"cluster rngRELAT-1K2 f as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "rngRELAT-1K2 f be  non emptyXBOOLE-0V1"
  proof-
    have " not rngRELAT-1K2 f be emptyXBOOLE-0V1"
    proof-
      have " ex x1 be objectHIDDENM1 st  ex x2 be objectHIDDENM1 st the ElementSUBSET-1M1-of f =HIDDENR1 [TARSKIK4 x1,x2 ]"
        using relat_1_def_1 sorry
      thus " not rngRELAT-1K2 f be emptyXBOOLE-0V1"
        using xtuple_0_def_13 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem relat_1_th_37:
" for R be RelationRELAT-1M1 holds ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not [TARSKIK4 x,y ] inHIDDENR3 R) implies R =RELAT-1R1 {}XBOOLE-0K1"
   sorry

mtheorem relat_1_th_38:
"domRELAT-1K1 ({}XBOOLE-0K1) =RELAT-1R1 {}XBOOLE-0K1 & rngRELAT-1K2 ({}XBOOLE-0K1) =RELAT-1R1 {}XBOOLE-0K1"
   sorry

mtheorem relat_1_th_39:
" for R be RelationRELAT-1M1 holds {}XBOOLE-0K1 *RELAT-1K6 R =RELAT-1R1 {}XBOOLE-0K1 & R *RELAT-1K6 {}XBOOLE-0K1 =RELAT-1R1 {}XBOOLE-0K1"
proof-
  have " for R be RelationRELAT-1M1 holds {}XBOOLE-0K1 *RELAT-1K6 R =RELAT-1R1 {}XBOOLE-0K1 & R *RELAT-1K6 {}XBOOLE-0K1 =RELAT-1R1 {}XBOOLE-0K1"
  proof(rule ballI,rule conjMI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "{}XBOOLE-0K1 *RELAT-1K6 R =RELAT-1R1 {}XBOOLE-0K1"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 {}XBOOLE-0K1 *RELAT-1K6 R implies [TARSKIK4 x,y ] inHIDDENR3 {}XBOOLE-0K1) &  not ([TARSKIK4 x,y ] inHIDDENR3 {}XBOOLE-0K1 &  not [TARSKIK4 x,y ] inHIDDENR3 {}XBOOLE-0K1 *RELAT-1K6 R)"
      proof(rule ballI,rule ballI,rule conjMI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        show "[TARSKIK4 x,y ] inHIDDENR3 {}XBOOLE-0K1 *RELAT-1K6 R implies [TARSKIK4 x,y ] inHIDDENR3 {}XBOOLE-0K1"
        proof(rule impI)
          assume "[TARSKIK4 x,y ] inHIDDENR3 {}XBOOLE-0K1 *RELAT-1K6 R"
          then have " ex z be objectHIDDENM1 st [TARSKIK4 x,z ] inHIDDENR3 {}XBOOLE-0K1 & [TARSKIK4 z,y ] inHIDDENR3 R"
            using relat_1_def_8 sorry
          thus "[TARSKIK4 x,y ] inHIDDENR3 {}XBOOLE-0K1"
             sorry
        qed
        show " not ([TARSKIK4 x,y ] inHIDDENR3 {}XBOOLE-0K1 &  not [TARSKIK4 x,y ] inHIDDENR3 {}XBOOLE-0K1 *RELAT-1K6 R)"
           sorry
      qed "sorry"
      thus "{}XBOOLE-0K1 *RELAT-1K6 R =RELAT-1R1 {}XBOOLE-0K1"
        using relat_1_def_2 sorry
    qed
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 R *RELAT-1K6 {}XBOOLE-0K1 implies [TARSKIK4 x,y ] inHIDDENR3 {}XBOOLE-0K1) &  not ([TARSKIK4 x,y ] inHIDDENR3 {}XBOOLE-0K1 &  not [TARSKIK4 x,y ] inHIDDENR3 R *RELAT-1K6 {}XBOOLE-0K1)"
    proof(rule ballI,rule ballI,rule conjMI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      show "[TARSKIK4 x,y ] inHIDDENR3 R *RELAT-1K6 {}XBOOLE-0K1 implies [TARSKIK4 x,y ] inHIDDENR3 {}XBOOLE-0K1"
      proof(rule impI)
        assume "[TARSKIK4 x,y ] inHIDDENR3 R *RELAT-1K6 {}XBOOLE-0K1"
        then have " ex z be objectHIDDENM1 st [TARSKIK4 x,z ] inHIDDENR3 R & [TARSKIK4 z,y ] inHIDDENR3 {}XBOOLE-0K1"
          using relat_1_def_8 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 {}XBOOLE-0K1"
           sorry
      qed
      show " not ([TARSKIK4 x,y ] inHIDDENR3 {}XBOOLE-0K1 &  not [TARSKIK4 x,y ] inHIDDENR3 R *RELAT-1K6 {}XBOOLE-0K1)"
         sorry
    qed "sorry"
    thus "R *RELAT-1K6 {}XBOOLE-0K1 =RELAT-1R1 {}XBOOLE-0K1"
      using relat_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_cl_13:
  mlet "X be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster domRELAT-1K1 X as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "domRELAT-1K1 X be emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem relat_1_cl_14:
  mlet "X be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster rngRELAT-1K2 X as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "rngRELAT-1K2 X be emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem relat_1_cl_15:
  mlet "X be emptyXBOOLE-0V1\<bar>setHIDDENM2", "R be RelationRELAT-1M1"
"cluster X *RELAT-1K6 R as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "X *RELAT-1K6 R be emptyXBOOLE-0V1"
    using relat_1_th_39 sorry
qed "sorry"

mtheorem relat_1_cl_16:
  mlet "X be emptyXBOOLE-0V1\<bar>setHIDDENM2", "R be RelationRELAT-1M1"
"cluster R *RELAT-1K6 X as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "R *RELAT-1K6 X be emptyXBOOLE-0V1"
    using relat_1_th_39 sorry
qed "sorry"

mtheorem relat_1_th_40:
"fieldRELAT-1K3 ({}XBOOLE-0K1) =XBOOLE-0R4 {}XBOOLE-0K1"
   sorry

mtheorem relat_1_th_41:
" for R be RelationRELAT-1M1 holds domRELAT-1K1 R =XBOOLE-0R4 {}XBOOLE-0K1 or rngRELAT-1K2 R =XBOOLE-0R4 {}XBOOLE-0K1 implies R =RELAT-1R1 {}XBOOLE-0K1"
   sorry

mtheorem relat_1_th_42:
" for R be RelationRELAT-1M1 holds domRELAT-1K1 R =XBOOLE-0R4 {}XBOOLE-0K1 iff rngRELAT-1K2 R =XBOOLE-0R4 {}XBOOLE-0K1"
  using relat_1_th_38 relat_1_th_41 sorry

mtheorem relat_1_cl_17:
  mlet "X be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster X ~RELAT-1K4 as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "X ~RELAT-1K4 be emptyXBOOLE-0V1"
  proof-
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 ({}XBOOLE-0K1)~RELAT-1K4 implies  False "
      using relat_1_def_7 sorry
    thus "X ~RELAT-1K4 be emptyXBOOLE-0V1"
      using relat_1_th_37 sorry
  qed
qed "sorry"

mtheorem relat_1_th_43:
"({}XBOOLE-0K1)~RELAT-1K4 =RELAT-1R1 {}XBOOLE-0K1"
   sorry

mtheorem relat_1_th_44:
" for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds rngRELAT-1K2 R missesXBOOLE-0R1 domRELAT-1K1 P implies R *RELAT-1K6 P =RELAT-1R1 {}XBOOLE-0K1"
proof-
  have " for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds  not (rngRELAT-1K2 R missesXBOOLE-0R1 domRELAT-1K1 P &  not R *RELAT-1K6 P =RELAT-1R1 {}XBOOLE-0K1)"
  proof(rule ballI,rule ballI)
    fix P assume [ty]: "P be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have "rngRELAT-1K2 R /\\XBOOLE-0K3 domRELAT-1K1 P =XBOOLE-0R4 {}XBOOLE-0K1 implies (R *RELAT-1K6 P <>HIDDENR2 {}XBOOLE-0K1 implies  False )"
    proof(rule impI,rule impI)
      assume A1: "rngRELAT-1K2 R /\\XBOOLE-0K3 domRELAT-1K1 P =XBOOLE-0R4 {}XBOOLE-0K1"
      assume "R *RELAT-1K6 P <>HIDDENR2 {}XBOOLE-0K1"
      then obtain x z where
        [ty]:"x be objectHIDDENM1" "z be objectHIDDENM1" and 
        A2: "[TARSKIK4 x,z ] inHIDDENR3 R *RELAT-1K6 P"
         sorry
      obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A3: "[TARSKIK4 x,y ] inHIDDENR3 R & [TARSKIK4 y,z ] inHIDDENR3 P"
        using A2 relat_1_def_8 sorry
      have "y inHIDDENR3 rngRELAT-1K2 R & y inHIDDENR3 domRELAT-1K1 P"
        using A3 xtuple_0_def_12 xtuple_0_def_13 sorry
      thus " False "
        using A1 xboole_0_def_4 sorry
    qed
    thus " not (rngRELAT-1K2 R missesXBOOLE-0R1 domRELAT-1K1 P &  not R *RELAT-1K6 P =RELAT-1R1 {}XBOOLE-0K1)"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef relat_1_def_9 ("non-emptyRELAT-1V2" 70 ) where
"attr non-emptyRELAT-1V2 for RelationRELAT-1M1 means
  (\<lambda>R.  not {}XBOOLE-0K1 inTARSKIR2 rngRELAT-1K2 R)"..

mtheorem relat_1_cl_18:
"cluster non-emptyRELAT-1V2 for RelationRELAT-1M1"
proof
(*existence*)
  show " ex it be RelationRELAT-1M1 st it be non-emptyRELAT-1V2"
  proof-
    have " ex tVar4 be RelationRELAT-1M1 st tVar4 be non-emptyRELAT-1V2"
    proof-
      show " ex tVar4 be RelationRELAT-1M1 st tVar4 be non-emptyRELAT-1V2"
      proof(rule bexI[of _ "{}XBOOLE-0K1"])
        have " not {}XBOOLE-0K1 inTARSKIR2 rngRELAT-1K2 ({}XBOOLE-0K1)"
        proof-
          show " not {}XBOOLE-0K1 inTARSKIR2 rngRELAT-1K2 ({}XBOOLE-0K1)"
             sorry
        qed
        thus "{}XBOOLE-0K1 be non-emptyRELAT-1V2"
          using relat_1_def_9 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem relat_1_cl_19:
  mlet "R be RelationRELAT-1M1", "S be non-emptyRELAT-1V2\<bar>RelationRELAT-1M1"
"cluster R *RELAT-1K6 S as-term-is non-emptyRELAT-1V2"
proof
(*coherence*)
  show "R *RELAT-1K6 S be non-emptyRELAT-1V2"
  proof-
    have Cut863: "rngRELAT-1K2 (R *RELAT-1K6 S) c=TARSKIR1 rngRELAT-1K2 S"
      using relat_1_th_26 sorry
    have " not {}XBOOLE-0K1 inTARSKIR2 rngRELAT-1K2 (R *RELAT-1K6 S)"
    proof-
      show " not {}XBOOLE-0K1 inTARSKIR2 rngRELAT-1K2 (R *RELAT-1K6 S)"
        using relat_1_def_9 Cut863 sorry
    qed
    thus "R *RELAT-1K6 S be non-emptyRELAT-1V2"
      using relat_1_def_9 sorry
  qed
qed "sorry"

mdef relat_1_def_10 ("idRELAT-1K7  _ " [228]228 ) where
  mlet "X be setHIDDENM2"
"func idRELAT-1K7 X \<rightarrow> RelationRELAT-1M1 means
  \<lambda>it.  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 it iff x inHIDDENR3 X & x =HIDDENR1 y"
proof-
  (*existence*)
    show " ex it be RelationRELAT-1M1 st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 it iff x inHIDDENR3 X & x =HIDDENR1 y"
    proof-
      have " ex tVar5 be RelationRELAT-1M1 st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 tVar5 &  not (x inHIDDENR3 X & x =HIDDENR1 y)) &  not ((x inHIDDENR3 X & x =HIDDENR1 y) &  not [TARSKIK4 x,y ] inHIDDENR3 tVar5)"
      proof-
        let ?Z = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb1 =HIDDENR1 Lamb2"
        obtain R where
          [ty]:"R be RelationRELAT-1M1" and 
          A1: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R iff (x inHIDDENR3 X & y inHIDDENR3 X) & ?Z(x,y)"
          using relat_1_sch_1 sorry
        show " ex tVar5 be RelationRELAT-1M1 st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 tVar5 &  not (x inHIDDENR3 X & x =HIDDENR1 y)) &  not ((x inHIDDENR3 X & x =HIDDENR1 y) &  not [TARSKIK4 x,y ] inHIDDENR3 tVar5)"
        proof(rule bexI[of _ "R"],rule ballI,rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          show " not ([TARSKIK4 x,y ] inHIDDENR3 R &  not (x inHIDDENR3 X & x =HIDDENR1 y)) &  not ((x inHIDDENR3 X & x =HIDDENR1 y) &  not [TARSKIK4 x,y ] inHIDDENR3 R)"
            using A1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be RelationRELAT-1M1 holds  for it2 be RelationRELAT-1M1 holds ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 it1 iff x inHIDDENR3 X & x =HIDDENR1 y) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 it2 iff x inHIDDENR3 X & x =HIDDENR1 y) implies it1 =HIDDENR1 it2"
    proof-
      have " for P1 be RelationRELAT-1M1 holds  for P2 be RelationRELAT-1M1 holds ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 P1 iff x inHIDDENR3 X & x =HIDDENR1 y) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 P2 iff x inHIDDENR3 X & x =HIDDENR1 y) implies P1 =HIDDENR1 P2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix P1 assume [ty]: "P1 be RelationRELAT-1M1"
        fix P2 assume [ty]: "P2 be RelationRELAT-1M1"
        assume A2: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 P1 iff x inHIDDENR3 X & x =HIDDENR1 y"
          and A3: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 P2 iff x inHIDDENR3 X & x =HIDDENR1 y"
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 P1 iff [TARSKIK4 x,y ] inHIDDENR3 P2"
        proof(rule ballI,rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          have "[TARSKIK4 x,y ] inHIDDENR3 P1 iff x inHIDDENR3 X & x =HIDDENR1 y"
            using A2 sorry
          thus "[TARSKIK4 x,y ] inHIDDENR3 P1 iff [TARSKIK4 x,y ] inHIDDENR3 P2"
            using A3 sorry
        qed "sorry"
        thus "P1 =HIDDENR1 P2"
          using relat_1_def_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem relat_1_reduce_1:
  mlet "X be setHIDDENM2"
"reduce domRELAT-1K1 (idRELAT-1K7 X) to X"
proof
(*reducibility*)
  show "domRELAT-1K1 (idRELAT-1K7 X) =HIDDENR1 X"
  proof-
    have "domRELAT-1K1 (idRELAT-1K7 X) c=TARSKIR1 X & X c=TARSKIR1 domRELAT-1K1 (idRELAT-1K7 X)"
    proof(rule conjMI)
      show "domRELAT-1K1 (idRELAT-1K7 X) c=TARSKIR1 X"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (idRELAT-1K7 X) implies x inHIDDENR3 X"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 domRELAT-1K1 (idRELAT-1K7 X)"
          then have " ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X"
            using xtuple_0_def_12 sorry
          thus "x inHIDDENR3 X"
            using relat_1_def_10 sorry
        qed "sorry"
        thus "domRELAT-1K1 (idRELAT-1K7 X) c=TARSKIR1 X"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 domRELAT-1K1 (idRELAT-1K7 X)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 X"
        then have "[TARSKIK4 x,x ] inHIDDENR3 idRELAT-1K7 X"
          using relat_1_def_10 sorry
        thus "x inHIDDENR3 domRELAT-1K1 (idRELAT-1K7 X)"
          using xtuple_0_def_12 sorry
      qed "sorry"
      thus "X c=TARSKIR1 domRELAT-1K1 (idRELAT-1K7 X)"
        using tarski_def_3 sorry
    qed
    thus "domRELAT-1K1 (idRELAT-1K7 X) =HIDDENR1 X"
      using xboole_0_def_10 sorry
  qed
qed "sorry"

mtheorem relat_1_reduce_2:
  mlet "X be setHIDDENM2"
"reduce rngRELAT-1K2 (idRELAT-1K7 X) to X"
proof
(*reducibility*)
  show "rngRELAT-1K2 (idRELAT-1K7 X) =HIDDENR1 X"
  proof-
    have "rngRELAT-1K2 (idRELAT-1K7 X) c=TARSKIR1 X & X c=TARSKIR1 rngRELAT-1K2 (idRELAT-1K7 X)"
    proof(rule conjMI)
      show "rngRELAT-1K2 (idRELAT-1K7 X) c=TARSKIR1 X"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELAT-1K2 (idRELAT-1K7 X) implies x inHIDDENR3 X"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 rngRELAT-1K2 (idRELAT-1K7 X)"
          then obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A1: "[TARSKIK4 y,x ] inHIDDENR3 idRELAT-1K7 X"
            using xtuple_0_def_13 sorry
          have "x =HIDDENR1 y"
            using A1 relat_1_def_10 sorry
          thus "x inHIDDENR3 X"
            using A1 relat_1_def_10 sorry
        qed "sorry"
        thus "rngRELAT-1K2 (idRELAT-1K7 X) c=TARSKIR1 X"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds  not (x inHIDDENR3 X &  not x inHIDDENR3 rngRELAT-1K2 (idRELAT-1K7 X))"
      proof(rule ballI)
        fix x assume [ty]: "x be objectHIDDENM1"
        have "[TARSKIK4 x,x ] inHIDDENR3 idRELAT-1K7 X iff x inHIDDENR3 X"
          using relat_1_def_10 sorry
        thus " not (x inHIDDENR3 X &  not x inHIDDENR3 rngRELAT-1K2 (idRELAT-1K7 X))"
          using xtuple_0_def_13 sorry
      qed "sorry"
      thus "X c=TARSKIR1 rngRELAT-1K2 (idRELAT-1K7 X)"
        using tarski_def_3 sorry
    qed
    thus "rngRELAT-1K2 (idRELAT-1K7 X) =HIDDENR1 X"
      using xboole_0_def_10 sorry
  qed
qed "sorry"

mtheorem relat_1_th_45:
" for X be setHIDDENM2 holds domRELAT-1K1 (idRELAT-1K7 X) =XBOOLE-0R4 X & rngRELAT-1K2 (idRELAT-1K7 X) =XBOOLE-0R4 X"
   sorry

mtheorem relat_1_reduce_3:
  mlet "X be setHIDDENM2"
"reduce (idRELAT-1K7 X)~RELAT-1K4 to idRELAT-1K7 X"
proof
(*reducibility*)
  show "(idRELAT-1K7 X)~RELAT-1K4 =HIDDENR1 idRELAT-1K7 X"
  proof-
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 (idRELAT-1K7 X)~RELAT-1K4 implies [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X) & ([TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X implies [TARSKIK4 x,y ] inHIDDENR3 (idRELAT-1K7 X)~RELAT-1K4)"
    proof(rule ballI,rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      show "[TARSKIK4 x,y ] inHIDDENR3 (idRELAT-1K7 X)~RELAT-1K4 implies [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X"
      proof(rule impI)
        assume "[TARSKIK4 x,y ] inHIDDENR3 (idRELAT-1K7 X)~RELAT-1K4"
        then have "[TARSKIK4 y,x ] inHIDDENR3 idRELAT-1K7 X"
          using relat_1_def_7 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X"
          using relat_1_def_10 sorry
      qed
      assume A1: "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X"
      then have "x =HIDDENR1 y"
        using relat_1_def_10 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 (idRELAT-1K7 X)~RELAT-1K4"
        using A1 relat_1_def_7 sorry
    qed "sorry"
    thus "(idRELAT-1K7 X)~RELAT-1K4 =HIDDENR1 idRELAT-1K7 X"
      using relat_1_def_2 sorry
  qed
qed "sorry"

mtheorem relat_1_th_46:
" for X be setHIDDENM2 holds (idRELAT-1K7 X)~RELAT-1K4 =RELAT-1R1 idRELAT-1K7 X"
   sorry

mtheorem relat_1_th_47:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies [TARSKIK4 x,x ] inHIDDENR3 R) implies idRELAT-1K7 X c=RELAT-1R2 R"
proof-
  have " for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies [TARSKIK4 x,x ] inHIDDENR3 R) implies idRELAT-1K7 X c=RELAT-1R2 R"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies [TARSKIK4 x,x ] inHIDDENR3 R"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X implies [TARSKIK4 x,y ] inHIDDENR3 R"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X"
      then have "x inHIDDENR3 X & x =HIDDENR1 y"
        using relat_1_def_10 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 R"
        using A1 sorry
    qed "sorry"
    thus "idRELAT-1K7 X c=RELAT-1R2 R"
      using relat_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_48:
" for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X *RELAT-1K6 R iff x inHIDDENR3 X & [TARSKIK4 x,y ] inHIDDENR3 R"
proof-
  have " for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds ([TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X *RELAT-1K6 R implies x inHIDDENR3 X & [TARSKIK4 x,y ] inHIDDENR3 R) & (x inHIDDENR3 X implies  not ([TARSKIK4 x,y ] inHIDDENR3 R &  not [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X *RELAT-1K6 R))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X *RELAT-1K6 R implies x inHIDDENR3 X & [TARSKIK4 x,y ] inHIDDENR3 R"
    proof(rule impI)
      assume "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X *RELAT-1K6 R"
      then have " ex z be objectHIDDENM1 st [TARSKIK4 x,z ] inHIDDENR3 idRELAT-1K7 X & [TARSKIK4 z,y ] inHIDDENR3 R"
        using relat_1_def_8 sorry
      thus "x inHIDDENR3 X & [TARSKIK4 x,y ] inHIDDENR3 R"
        using relat_1_def_10 sorry
    qed
    assume "x inHIDDENR3 X"
    then have "[TARSKIK4 x,x ] inHIDDENR3 idRELAT-1K7 X"
      using relat_1_def_10 sorry
    thus " not ([TARSKIK4 x,y ] inHIDDENR3 R &  not [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X *RELAT-1K6 R)"
      using relat_1_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_49:
" for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds [TARSKIK4 x,y ] inHIDDENR3 R *RELAT-1K6 idRELAT-1K7 Y iff y inHIDDENR3 Y & [TARSKIK4 x,y ] inHIDDENR3 R"
proof-
  have " for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds ([TARSKIK4 x,y ] inHIDDENR3 R *RELAT-1K6 idRELAT-1K7 Y implies y inHIDDENR3 Y & [TARSKIK4 x,y ] inHIDDENR3 R) &  not ((y inHIDDENR3 Y & [TARSKIK4 x,y ] inHIDDENR3 R) &  not [TARSKIK4 x,y ] inHIDDENR3 R *RELAT-1K6 idRELAT-1K7 Y)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "[TARSKIK4 x,y ] inHIDDENR3 R *RELAT-1K6 idRELAT-1K7 Y implies y inHIDDENR3 Y & [TARSKIK4 x,y ] inHIDDENR3 R"
    proof(rule impI)
      assume "[TARSKIK4 x,y ] inHIDDENR3 R *RELAT-1K6 idRELAT-1K7 Y"
      then obtain z where
        [ty]:"z be objectHIDDENM1" and 
        A1: "[TARSKIK4 x,z ] inHIDDENR3 R"and A2: "[TARSKIK4 z,y ] inHIDDENR3 idRELAT-1K7 Y"
        using relat_1_def_8 sorry
      have "z =HIDDENR1 y"
        using A2 relat_1_def_10 sorry
      thus "y inHIDDENR3 Y & [TARSKIK4 x,y ] inHIDDENR3 R"
        using A1 A2 relat_1_def_10 sorry
    qed
    have "y inHIDDENR3 Y implies [TARSKIK4 y,y ] inHIDDENR3 idRELAT-1K7 Y"
      using relat_1_def_10 sorry
    thus " not ((y inHIDDENR3 Y & [TARSKIK4 x,y ] inHIDDENR3 R) &  not [TARSKIK4 x,y ] inHIDDENR3 R *RELAT-1K6 idRELAT-1K7 Y)"
      using relat_1_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_50:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R *RELAT-1K6 idRELAT-1K7 X c=RELAT-1R2 R & idRELAT-1K7 X *RELAT-1K6 R c=RELAT-1R2 R"
proof-
  have " for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R *RELAT-1K6 idRELAT-1K7 X c=RELAT-1R2 R & idRELAT-1K7 X *RELAT-1K6 R c=RELAT-1R2 R"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have "( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R *RELAT-1K6 idRELAT-1K7 X implies [TARSKIK4 x,y ] inHIDDENR3 R) & idRELAT-1K7 X *RELAT-1K6 R c=RELAT-1R2 R"
    proof(rule conjMI)
      show " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R *RELAT-1K6 idRELAT-1K7 X implies [TARSKIK4 x,y ] inHIDDENR3 R"
      proof-
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R *RELAT-1K6 idRELAT-1K7 X implies [TARSKIK4 x,y ] inHIDDENR3 R"
        proof(rule ballI,rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "[TARSKIK4 x,y ] inHIDDENR3 R *RELAT-1K6 idRELAT-1K7 X"
          then have " ex z be objectHIDDENM1 st [TARSKIK4 x,z ] inHIDDENR3 R & [TARSKIK4 z,y ] inHIDDENR3 idRELAT-1K7 X"
            using relat_1_def_8 sorry
          thus "[TARSKIK4 x,y ] inHIDDENR3 R"
            using relat_1_def_10 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X *RELAT-1K6 R implies [TARSKIK4 x,y ] inHIDDENR3 R"
      proof-
        show " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X *RELAT-1K6 R implies [TARSKIK4 x,y ] inHIDDENR3 R"
        proof-
          have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X *RELAT-1K6 R implies [TARSKIK4 x,y ] inHIDDENR3 R"
          proof(rule ballI,rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            fix y assume [ty]: "y be objectHIDDENM1"
            assume "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X *RELAT-1K6 R"
            then have " ex z be objectHIDDENM1 st [TARSKIK4 x,z ] inHIDDENR3 idRELAT-1K7 X & [TARSKIK4 z,y ] inHIDDENR3 R"
              using relat_1_def_8 sorry
            thus "[TARSKIK4 x,y ] inHIDDENR3 R"
              using relat_1_def_10 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
      qed
      thus "idRELAT-1K7 X *RELAT-1K6 R c=RELAT-1R2 R"
        using relat_1_def_3 sorry
    qed
    thus "R *RELAT-1K6 idRELAT-1K7 X c=RELAT-1R2 R & idRELAT-1K7 X *RELAT-1K6 R c=RELAT-1R2 R"
      using relat_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_51:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds domRELAT-1K1 R c=TARSKIR1 X implies idRELAT-1K7 X *RELAT-1K6 R =RELAT-1R1 R"
proof-
  have " for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds domRELAT-1K1 R c=TARSKIR1 X implies idRELAT-1K7 X *RELAT-1K6 R =RELAT-1R1 R"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume A1: "domRELAT-1K1 R c=TARSKIR1 X"
    have "R c=RELAT-1R2 idRELAT-1K7 X *RELAT-1K6 R"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R implies [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X *RELAT-1K6 R"
      proof(rule ballI,rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A2: "[TARSKIK4 x,y ] inHIDDENR3 R"
        then have "x inHIDDENR3 domRELAT-1K1 R"
          using xtuple_0_def_12 sorry
        then have "[TARSKIK4 x,x ] inHIDDENR3 idRELAT-1K7 X"
          using A1 relat_1_def_10 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X *RELAT-1K6 R"
          using A2 relat_1_def_8 sorry
      qed "sorry"
      thus "R c=RELAT-1R2 idRELAT-1K7 X *RELAT-1K6 R"
        using relat_1_def_3 sorry
    qed
    thus "idRELAT-1K7 X *RELAT-1K6 R =RELAT-1R1 R"
      using relat_1_th_50 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_52:
" for R be RelationRELAT-1M1 holds idRELAT-1K7 (domRELAT-1K1 R) *RELAT-1K6 R =RELAT-1R1 R"
  using relat_1_th_51 sorry

mtheorem relat_1_th_53:
" for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds rngRELAT-1K2 R c=TARSKIR1 Y implies R *RELAT-1K6 idRELAT-1K7 Y =RELAT-1R1 R"
proof-
  have " for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds rngRELAT-1K2 R c=TARSKIR1 Y implies R *RELAT-1K6 idRELAT-1K7 Y =RELAT-1R1 R"
  proof(rule ballI,rule ballI,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume A1: "rngRELAT-1K2 R c=TARSKIR1 Y"
    have "R c=RELAT-1R2 R *RELAT-1K6 idRELAT-1K7 Y"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R implies [TARSKIK4 x,y ] inHIDDENR3 R *RELAT-1K6 idRELAT-1K7 Y"
      proof(rule ballI,rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A2: "[TARSKIK4 x,y ] inHIDDENR3 R"
        then have "y inHIDDENR3 rngRELAT-1K2 R"
          using xtuple_0_def_13 sorry
        then have "[TARSKIK4 y,y ] inHIDDENR3 idRELAT-1K7 Y"
          using A1 relat_1_def_10 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 R *RELAT-1K6 idRELAT-1K7 Y"
          using A2 relat_1_def_8 sorry
      qed "sorry"
      thus "R c=RELAT-1R2 R *RELAT-1K6 idRELAT-1K7 Y"
        using relat_1_def_3 sorry
    qed
    thus "R *RELAT-1K6 idRELAT-1K7 Y =RELAT-1R1 R"
      using relat_1_th_50 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_54:
" for R be RelationRELAT-1M1 holds R *RELAT-1K6 idRELAT-1K7 (rngRELAT-1K2 R) =RELAT-1R1 R"
  using relat_1_th_53 sorry

mtheorem relat_1_th_55:
"idRELAT-1K7 ({}XBOOLE-0K1) =RELAT-1R1 {}XBOOLE-0K1"
proof-
  have "domRELAT-1K1 (idRELAT-1K7 ({}XBOOLE-0K1)) =XBOOLE-0R4 {}XBOOLE-0K1"
     sorry
  thus "idRELAT-1K7 ({}XBOOLE-0K1) =RELAT-1R1 {}XBOOLE-0K1"
     sorry
qed

mtheorem relat_1_th_56:
" for X be setHIDDENM2 holds  for P1 be RelationRELAT-1M1 holds  for P2 be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds (rngRELAT-1K2 P2 c=TARSKIR1 X & P2 *RELAT-1K6 R =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 P1)) & R *RELAT-1K6 P1 =RELAT-1R1 idRELAT-1K7 X implies P1 =RELAT-1R1 P2"
proof-
  have " for X be setHIDDENM2 holds  for P1 be RelationRELAT-1M1 holds  for P2 be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds  not (((rngRELAT-1K2 P2 c=TARSKIR1 X & P2 *RELAT-1K6 R =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 P1)) & R *RELAT-1K6 P1 =RELAT-1R1 idRELAT-1K7 X) &  not P1 =RELAT-1R1 P2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix P1 assume [ty]: "P1 be RelationRELAT-1M1"
    fix P2 assume [ty]: "P2 be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have "(P2 *RELAT-1K6 R)*RELAT-1K6 P1 =RELAT-1R1 P2 *RELAT-1K6 (R *RELAT-1K6 P1) & idRELAT-1K7 (domRELAT-1K1 P1) *RELAT-1K6 P1 =RELAT-1R1 P1"
      using relat_1_th_36 relat_1_th_51 sorry
    thus " not (((rngRELAT-1K2 P2 c=TARSKIR1 X & P2 *RELAT-1K6 R =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 P1)) & R *RELAT-1K6 P1 =RELAT-1R1 idRELAT-1K7 X) &  not P1 =RELAT-1R1 P2)"
      using relat_1_th_53 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef relat_1_def_11 (" _  |RELAT-1K8  _ " [200,200]200 ) where
  mlet "R be RelationRELAT-1M1", "X be setHIDDENM2"
"func R  |RELAT-1K8 X \<rightarrow> RelationRELAT-1M1 means
  \<lambda>it.  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 it iff x inHIDDENR3 X & [TARSKIK4 x,y ] inHIDDENR3 R"
proof-
  (*existence*)
    show " ex it be RelationRELAT-1M1 st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 it iff x inHIDDENR3 X & [TARSKIK4 x,y ] inHIDDENR3 R"
    proof-
      have " ex tVar6 be RelationRELAT-1M1 st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 tVar6 &  not (x inHIDDENR3 X & [TARSKIK4 x,y ] inHIDDENR3 R)) &  not ((x inHIDDENR3 X & [TARSKIK4 x,y ] inHIDDENR3 R) &  not [TARSKIK4 x,y ] inHIDDENR3 tVar6)"
      proof-
        let ?Z = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb1 inHIDDENR3 X & [TARSKIK4 Lamb1,Lamb2 ] inHIDDENR3 R"
        obtain P where
          [ty]:"P be RelationRELAT-1M1" and 
          A1: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 P iff (x inHIDDENR3 domRELAT-1K1 R & y inHIDDENR3 rngRELAT-1K2 R) & ?Z(x,y)"
          using relat_1_sch_1 sorry
        show " ex tVar6 be RelationRELAT-1M1 st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 tVar6 &  not (x inHIDDENR3 X & [TARSKIK4 x,y ] inHIDDENR3 R)) &  not ((x inHIDDENR3 X & [TARSKIK4 x,y ] inHIDDENR3 R) &  not [TARSKIK4 x,y ] inHIDDENR3 tVar6)"
        proof(rule bexI[of _ "P"],rule ballI,rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          have "x inHIDDENR3 X & [TARSKIK4 x,y ] inHIDDENR3 R implies x inHIDDENR3 domRELAT-1K1 R & y inHIDDENR3 rngRELAT-1K2 R"
            using xtuple_0_def_12 xtuple_0_def_13 sorry
          thus " not ([TARSKIK4 x,y ] inHIDDENR3 P &  not (x inHIDDENR3 X & [TARSKIK4 x,y ] inHIDDENR3 R)) &  not ((x inHIDDENR3 X & [TARSKIK4 x,y ] inHIDDENR3 R) &  not [TARSKIK4 x,y ] inHIDDENR3 P)"
            using A1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be RelationRELAT-1M1 holds  for it2 be RelationRELAT-1M1 holds ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 it1 iff x inHIDDENR3 X & [TARSKIK4 x,y ] inHIDDENR3 R) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 it2 iff x inHIDDENR3 X & [TARSKIK4 x,y ] inHIDDENR3 R) implies it1 =HIDDENR1 it2"
    proof-
      have " for P1 be RelationRELAT-1M1 holds  for P2 be RelationRELAT-1M1 holds ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 P1 iff x inHIDDENR3 X & [TARSKIK4 x,y ] inHIDDENR3 R) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 P2 iff x inHIDDENR3 X & [TARSKIK4 x,y ] inHIDDENR3 R) implies P1 =HIDDENR1 P2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix P1 assume [ty]: "P1 be RelationRELAT-1M1"
        fix P2 assume [ty]: "P2 be RelationRELAT-1M1"
        assume A2: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 P1 iff x inHIDDENR3 X & [TARSKIK4 x,y ] inHIDDENR3 R"
          and A3: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 P2 iff x inHIDDENR3 X & [TARSKIK4 x,y ] inHIDDENR3 R"
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 P1 iff [TARSKIK4 x,y ] inHIDDENR3 P2"
        proof(rule ballI,rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          have "[TARSKIK4 x,y ] inHIDDENR3 P1 iff x inHIDDENR3 X & [TARSKIK4 x,y ] inHIDDENR3 R"
            using A2 sorry
          thus "[TARSKIK4 x,y ] inHIDDENR3 P1 iff [TARSKIK4 x,y ] inHIDDENR3 P2"
            using A3 sorry
        qed "sorry"
        thus "P1 =HIDDENR1 P2"
          using relat_1_def_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem relat_1_cl_20:
  mlet "R be RelationRELAT-1M1", "X be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster R  |RELAT-1K8 X as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "R  |RELAT-1K8 X be emptyXBOOLE-0V1"
  proof-
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not [TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 {}XBOOLE-0K1"
      using relat_1_def_11 sorry
    thus "R  |RELAT-1K8 X be emptyXBOOLE-0V1"
      using relat_1_th_37 sorry
  qed
qed "sorry"

mtheorem relat_1_th_57:
" for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds x inHIDDENR3 domRELAT-1K1 (R  |RELAT-1K8 X) iff x inHIDDENR3 X & x inHIDDENR3 domRELAT-1K1 R"
proof-
  have " for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds (x inHIDDENR3 domRELAT-1K1 (R  |RELAT-1K8 X) implies x inHIDDENR3 X & x inHIDDENR3 domRELAT-1K1 R) & (x inHIDDENR3 X implies (x inHIDDENR3 domRELAT-1K1 R implies x inHIDDENR3 domRELAT-1K1 (R  |RELAT-1K8 X)))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "x inHIDDENR3 domRELAT-1K1 (R  |RELAT-1K8 X) implies x inHIDDENR3 X & x inHIDDENR3 domRELAT-1K1 R"
    proof(rule impI)
      assume "x inHIDDENR3 domRELAT-1K1 (R  |RELAT-1K8 X)"
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A1: "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X"
        using xtuple_0_def_12 sorry
      have "[TARSKIK4 x,y ] inHIDDENR3 R"
        using A1 relat_1_def_11 sorry
      thus "x inHIDDENR3 X & x inHIDDENR3 domRELAT-1K1 R"
        using A1 relat_1_def_11 xtuple_0_def_12 sorry
    qed
    assume A2: "x inHIDDENR3 X"
    assume "x inHIDDENR3 domRELAT-1K1 R"
    then obtain y where
      [ty]:"y be objectHIDDENM1" and 
      A3: "[TARSKIK4 x,y ] inHIDDENR3 R"
      using xtuple_0_def_12 sorry
    have "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X"
      using A2 A3 relat_1_def_11 sorry
    thus "x inHIDDENR3 domRELAT-1K1 (R  |RELAT-1K8 X)"
      using xtuple_0_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_58:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds domRELAT-1K1 (R  |RELAT-1K8 X) c=TARSKIR1 X"
  using relat_1_th_57 sorry

mtheorem relat_1_th_59:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R  |RELAT-1K8 X c=RELAT-1R2 R"
  using relat_1_def_11 sorry

mtheorem relat_1_th_60:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds domRELAT-1K1 (R  |RELAT-1K8 X) c=TARSKIR1 domRELAT-1K1 R"
  using relat_1_th_57 sorry

mtheorem relat_1_th_61:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds domRELAT-1K1 (R  |RELAT-1K8 X) =XBOOLE-0R4 domRELAT-1K1 R /\\XBOOLE-0K3 X"
proof-
  have " for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds domRELAT-1K1 (R  |RELAT-1K8 X) =XBOOLE-0R4 domRELAT-1K1 R /\\XBOOLE-0K3 X"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (R  |RELAT-1K8 X) iff x inHIDDENR3 domRELAT-1K1 R /\\XBOOLE-0K3 X"
    proof-
      have " for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 (R  |RELAT-1K8 X) &  not x inHIDDENR3 domRELAT-1K1 R /\\XBOOLE-0K3 X) &  not (x inHIDDENR3 domRELAT-1K1 R /\\XBOOLE-0K3 X &  not x inHIDDENR3 domRELAT-1K1 (R  |RELAT-1K8 X))"
      proof(rule ballI)
        fix x assume [ty]: "x be objectHIDDENM1"
        have "x inHIDDENR3 domRELAT-1K1 (R  |RELAT-1K8 X) iff x inHIDDENR3 domRELAT-1K1 R & x inHIDDENR3 X"
          using relat_1_th_57 sorry
        thus " not (x inHIDDENR3 domRELAT-1K1 (R  |RELAT-1K8 X) &  not x inHIDDENR3 domRELAT-1K1 R /\\XBOOLE-0K3 X) &  not (x inHIDDENR3 domRELAT-1K1 R /\\XBOOLE-0K3 X &  not x inHIDDENR3 domRELAT-1K1 (R  |RELAT-1K8 X))"
          using xboole_0_def_4 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "domRELAT-1K1 (R  |RELAT-1K8 X) =XBOOLE-0R4 domRELAT-1K1 R /\\XBOOLE-0K3 X"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_62:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds X c=TARSKIR1 domRELAT-1K1 R implies domRELAT-1K1 (R  |RELAT-1K8 X) =XBOOLE-0R4 X"
proof-
  have " for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds  not (X c=TARSKIR1 domRELAT-1K1 R &  not domRELAT-1K1 (R  |RELAT-1K8 X) =XBOOLE-0R4 X)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have "domRELAT-1K1 (R  |RELAT-1K8 X) =XBOOLE-0R4 domRELAT-1K1 R /\\XBOOLE-0K3 X"
      using relat_1_th_61 sorry
    thus " not (X c=TARSKIR1 domRELAT-1K1 R &  not domRELAT-1K1 (R  |RELAT-1K8 X) =XBOOLE-0R4 X)"
      using xboole_1_th_28 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_63:
" for X be setHIDDENM2 holds  for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds R  |RELAT-1K8 X *RELAT-1K6 P c=RELAT-1R2 R *RELAT-1K6 P"
  using relat_1_th_30 relat_1_th_59 sorry

mtheorem relat_1_th_64:
" for X be setHIDDENM2 holds  for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds P *RELAT-1K6 R  |RELAT-1K8 X c=RELAT-1R2 P *RELAT-1K6 R"
  using relat_1_th_29 relat_1_th_59 sorry

mtheorem relat_1_th_65:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R  |RELAT-1K8 X =RELAT-1R1 idRELAT-1K7 X *RELAT-1K6 R"
proof-
  have " for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R  |RELAT-1K8 X =RELAT-1R1 idRELAT-1K7 X *RELAT-1K6 R"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X &  not [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X *RELAT-1K6 R) &  not ([TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X *RELAT-1K6 R &  not [TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X)"
    proof(rule ballI,rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      have "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X iff [TARSKIK4 x,y ] inHIDDENR3 R & x inHIDDENR3 X"
        using relat_1_def_11 sorry
      thus " not ([TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X &  not [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X *RELAT-1K6 R) &  not ([TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X *RELAT-1K6 R &  not [TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X)"
        using relat_1_th_48 sorry
    qed "sorry"
    thus "R  |RELAT-1K8 X =RELAT-1R1 idRELAT-1K7 X *RELAT-1K6 R"
      using relat_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_66:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R  |RELAT-1K8 X =RELAT-1R1 {}XBOOLE-0K1 iff domRELAT-1K1 R missesXBOOLE-0R1 X"
proof-
  have " for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds (R  |RELAT-1K8 X =RELAT-1R1 {}XBOOLE-0K1 implies domRELAT-1K1 R missesXBOOLE-0R1 X) &  not (domRELAT-1K1 R missesXBOOLE-0R1 X &  not R  |RELAT-1K8 X =RELAT-1R1 {}XBOOLE-0K1)"
  proof(rule ballI,rule ballI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "R  |RELAT-1K8 X =RELAT-1R1 {}XBOOLE-0K1 implies domRELAT-1K1 R missesXBOOLE-0R1 X"
    proof(rule impI)
      assume A1: "R  |RELAT-1K8 X =RELAT-1R1 {}XBOOLE-0K1"
      have "domRELAT-1K1 R /\\XBOOLE-0K3 X =XBOOLE-0R4 {}XBOOLE-0K1"
      proof-
        show "domRELAT-1K1 R /\\XBOOLE-0K3 X =XBOOLE-0R4 {}XBOOLE-0K1"
        proof-
          have "domRELAT-1K1 R /\\XBOOLE-0K3 X c=TARSKIR1 {}XBOOLE-0K1 & {}XBOOLE-0K1 c=TARSKIR1 domRELAT-1K1 R /\\XBOOLE-0K3 X"
          proof(rule conjMI)
            show "domRELAT-1K1 R /\\XBOOLE-0K3 X c=TARSKIR1 {}XBOOLE-0K1"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 R /\\XBOOLE-0K3 X implies x inHIDDENR3 {}XBOOLE-0K1"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume A2: "x inHIDDENR3 domRELAT-1K1 R /\\XBOOLE-0K3 X"
                then have "x inHIDDENR3 domRELAT-1K1 R"
                  using xboole_0_def_4 sorry
                then have A3: " ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R"
                  using xtuple_0_def_12 sorry
                have "x inHIDDENR3 X"
                  using A2 xboole_0_def_4 sorry
                thus "x inHIDDENR3 {}XBOOLE-0K1"
                  using A1 A3 relat_1_def_11 sorry
              qed "sorry"
              thus "domRELAT-1K1 R /\\XBOOLE-0K3 X c=TARSKIR1 {}XBOOLE-0K1"
                using tarski_def_3 sorry
            qed
            show "{}XBOOLE-0K1 c=TARSKIR1 domRELAT-1K1 R /\\XBOOLE-0K3 X"
               sorry
          qed
          thus "domRELAT-1K1 R /\\XBOOLE-0K3 X =XBOOLE-0R4 {}XBOOLE-0K1"
            using xboole_0_def_10 sorry
        qed
      qed
      thus "domRELAT-1K1 R missesXBOOLE-0R1 X"
        using xboole_0_def_7 sorry
    qed
    have "domRELAT-1K1 R /\\XBOOLE-0K3 X =XBOOLE-0R4 {}XBOOLE-0K1 implies R  |RELAT-1K8 X =RELAT-1R1 {}XBOOLE-0K1"
    proof(rule impI)
      assume A4: "domRELAT-1K1 R /\\XBOOLE-0K3 X =XBOOLE-0R4 {}XBOOLE-0K1"
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X implies [TARSKIK4 x,y ] inHIDDENR3 {}XBOOLE-0K1) &  not ([TARSKIK4 x,y ] inHIDDENR3 {}XBOOLE-0K1 &  not [TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X)"
      proof(rule ballI,rule ballI,rule conjMI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        show "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X implies [TARSKIK4 x,y ] inHIDDENR3 {}XBOOLE-0K1"
        proof(rule impI)
          assume A5: "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X"
          then have "x inHIDDENR3 X"
            using relat_1_def_11 sorry
          then have A6: " not x inHIDDENR3 domRELAT-1K1 R"
            using A4 xboole_0_def_4 sorry
          have "[TARSKIK4 x,y ] inHIDDENR3 R"
            using A5 relat_1_def_11 sorry
          thus "[TARSKIK4 x,y ] inHIDDENR3 {}XBOOLE-0K1"
            using A6 xtuple_0_def_12 sorry
        qed
        show " not ([TARSKIK4 x,y ] inHIDDENR3 {}XBOOLE-0K1 &  not [TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X)"
           sorry
      qed "sorry"
      thus "R  |RELAT-1K8 X =RELAT-1R1 {}XBOOLE-0K1"
        using relat_1_def_2 sorry
    qed
    thus " not (domRELAT-1K1 R missesXBOOLE-0R1 X &  not R  |RELAT-1K8 X =RELAT-1R1 {}XBOOLE-0K1)"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_67:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R  |RELAT-1K8 X =RELAT-1R1 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,rngRELAT-1K2 R :])"
proof-
  have " for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R  |RELAT-1K8 X =RELAT-1R1 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,rngRELAT-1K2 R :])"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    let ?P = "R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,rngRELAT-1K2 R :])"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X implies [TARSKIK4 x,y ] inHIDDENR3 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,rngRELAT-1K2 R :])) & ([TARSKIK4 x,y ] inHIDDENR3 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,rngRELAT-1K2 R :]) implies [TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X)"
    proof(rule ballI,rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      show "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X implies [TARSKIK4 x,y ] inHIDDENR3 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,rngRELAT-1K2 R :])"
      proof(rule impI)
        assume A1: "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X"
        then have A2: "x inHIDDENR3 X"
          using relat_1_def_11 sorry
        have A3: "[TARSKIK4 x,y ] inHIDDENR3 R"
          using A1 relat_1_def_11 sorry
        then have "y inHIDDENR3 rngRELAT-1K2 R"
          using xtuple_0_def_13 sorry
        then have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,rngRELAT-1K2 R :]"
          using A2 zfmisc_1_def_2 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,rngRELAT-1K2 R :])"
          using A3 xboole_0_def_4 sorry
      qed
      assume A4: "[TARSKIK4 x,y ] inHIDDENR3 ?P"
      then have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,rngRELAT-1K2 R :]"
        using xboole_0_def_4 sorry
      then have A5: "x inHIDDENR3 X"
        using zfmisc_1_th_87 sorry
      have "[TARSKIK4 x,y ] inHIDDENR3 R"
        using A4 xboole_0_def_4 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X"
        using A5 relat_1_def_11 sorry
    qed "sorry"
    thus "R  |RELAT-1K8 X =RELAT-1R1 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,rngRELAT-1K2 R :])"
      using relat_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_68:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds domRELAT-1K1 R c=TARSKIR1 X implies R  |RELAT-1K8 X =RELAT-1R1 R"
proof-
  have " for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds domRELAT-1K1 R c=TARSKIR1 X implies R  |RELAT-1K8 X =RELAT-1R1 R"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume "domRELAT-1K1 R c=TARSKIR1 X"
    then have A1: "[:ZFMISC-1K2 domRELAT-1K1 R,rngRELAT-1K2 R :] c=RELAT-1R2 [:ZFMISC-1K2 X,rngRELAT-1K2 R :]"
      using zfmisc_1_th_95 sorry
    have "R c=RELAT-1R2 [:ZFMISC-1K2 domRELAT-1K1 R,rngRELAT-1K2 R :] & R  |RELAT-1K8 X =RELAT-1R1 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,rngRELAT-1K2 R :])"
      using relat_1_th_7 relat_1_th_67 sorry
    thus "R  |RELAT-1K8 X =RELAT-1R1 R"
      using A1 xboole_1_th_1 xboole_1_th_28 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_reduce_4:
  mlet "R be RelationRELAT-1M1"
"reduce R  |RELAT-1K8 domRELAT-1K1 R to R"
proof
(*reducibility*)
  show "R  |RELAT-1K8 domRELAT-1K1 R =HIDDENR1 R"
    using relat_1_th_68 sorry
qed "sorry"

mtheorem relat_1_th_69:
" for R be RelationRELAT-1M1 holds R  |RELAT-1K8 domRELAT-1K1 R =RELAT-1R1 R"
   sorry

mtheorem relat_1_th_70:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds rngRELAT-1K2 (R  |RELAT-1K8 X) c=TARSKIR1 rngRELAT-1K2 R"
  using relat_1_th_59 xtuple_0_th_9 sorry

mtheorem relat_1_th_71:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds (R  |RELAT-1K8 X) |RELAT-1K8 Y =RELAT-1R1 R  |RELAT-1K8 (X /\\XBOOLE-0K3 Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds (R  |RELAT-1K8 X) |RELAT-1K8 Y =RELAT-1R1 R  |RELAT-1K8 (X /\\XBOOLE-0K3 Y)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 (R  |RELAT-1K8 X) |RELAT-1K8 Y &  not [TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 (X /\\XBOOLE-0K3 Y)) &  not ([TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 (X /\\XBOOLE-0K3 Y) &  not [TARSKIK4 x,y ] inHIDDENR3 (R  |RELAT-1K8 X) |RELAT-1K8 Y)"
    proof(rule ballI,rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      have A1: "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X iff [TARSKIK4 x,y ] inHIDDENR3 R & x inHIDDENR3 X"
        using relat_1_def_11 sorry
      have A2: "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 (X /\\XBOOLE-0K3 Y) iff [TARSKIK4 x,y ] inHIDDENR3 R & x inHIDDENR3 X /\\XBOOLE-0K3 Y"
        using relat_1_def_11 sorry
      have "[TARSKIK4 x,y ] inHIDDENR3 (R  |RELAT-1K8 X) |RELAT-1K8 Y iff [TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X & x inHIDDENR3 Y"
        using relat_1_def_11 sorry
      thus " not ([TARSKIK4 x,y ] inHIDDENR3 (R  |RELAT-1K8 X) |RELAT-1K8 Y &  not [TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 (X /\\XBOOLE-0K3 Y)) &  not ([TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 (X /\\XBOOLE-0K3 Y) &  not [TARSKIK4 x,y ] inHIDDENR3 (R  |RELAT-1K8 X) |RELAT-1K8 Y)"
        using A1 A2 xboole_0_def_4 sorry
    qed "sorry"
    thus "(R  |RELAT-1K8 X) |RELAT-1K8 Y =RELAT-1R1 R  |RELAT-1K8 (X /\\XBOOLE-0K3 Y)"
      using relat_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_reduce_5:
  mlet "R be RelationRELAT-1M1", "X be setHIDDENM2"
"reduce (R  |RELAT-1K8 X) |RELAT-1K8 X to R  |RELAT-1K8 X"
proof
(*reducibility*)
  show "(R  |RELAT-1K8 X) |RELAT-1K8 X =HIDDENR1 R  |RELAT-1K8 X"
  proof-
    have "X /\\XBOOLE-0K3 X =XBOOLE-0R4 X"
       sorry
    thus "(R  |RELAT-1K8 X) |RELAT-1K8 X =HIDDENR1 R  |RELAT-1K8 X"
      using relat_1_th_71 sorry
  qed
qed "sorry"

mtheorem relat_1_th_72:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds (R  |RELAT-1K8 X) |RELAT-1K8 X =RELAT-1R1 R  |RELAT-1K8 X"
   sorry

mtheorem relat_1_th_73:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds X c=TARSKIR1 Y implies (R  |RELAT-1K8 X) |RELAT-1K8 Y =RELAT-1R1 R  |RELAT-1K8 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds  not (X c=TARSKIR1 Y &  not (R  |RELAT-1K8 X) |RELAT-1K8 Y =RELAT-1R1 R  |RELAT-1K8 X)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have "X c=TARSKIR1 Y implies X /\\XBOOLE-0K3 Y =XBOOLE-0R4 X"
      using xboole_1_th_28 sorry
    thus " not (X c=TARSKIR1 Y &  not (R  |RELAT-1K8 X) |RELAT-1K8 Y =RELAT-1R1 R  |RELAT-1K8 X)"
      using relat_1_th_71 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_74:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds Y c=TARSKIR1 X implies (R  |RELAT-1K8 X) |RELAT-1K8 Y =RELAT-1R1 R  |RELAT-1K8 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds  not (Y c=TARSKIR1 X &  not (R  |RELAT-1K8 X) |RELAT-1K8 Y =RELAT-1R1 R  |RELAT-1K8 Y)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have "Y c=TARSKIR1 X implies X /\\XBOOLE-0K3 Y =XBOOLE-0R4 Y"
      using xboole_1_th_28 sorry
    thus " not (Y c=TARSKIR1 X &  not (R  |RELAT-1K8 X) |RELAT-1K8 Y =RELAT-1R1 R  |RELAT-1K8 Y)"
      using relat_1_th_71 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_75:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds X c=TARSKIR1 Y implies R  |RELAT-1K8 X c=RELAT-1R2 R  |RELAT-1K8 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds X c=TARSKIR1 Y implies R  |RELAT-1K8 X c=RELAT-1R2 R  |RELAT-1K8 Y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume A1: "X c=TARSKIR1 Y"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X implies [TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 Y"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X"
      then have "x inHIDDENR3 X & [TARSKIK4 x,y ] inHIDDENR3 R"
        using relat_1_def_11 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 Y"
        using A1 relat_1_def_11 sorry
    qed "sorry"
    thus "R  |RELAT-1K8 X c=RELAT-1R2 R  |RELAT-1K8 Y"
      using relat_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_76:
" for X be setHIDDENM2 holds  for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds P c=RELAT-1R2 R implies P  |RELAT-1K8 X c=RELAT-1R2 R  |RELAT-1K8 X"
proof-
  have " for X be setHIDDENM2 holds  for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds P c=RELAT-1R2 R implies P  |RELAT-1K8 X c=RELAT-1R2 R  |RELAT-1K8 X"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix P assume [ty]: "P be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume A1: "P c=RELAT-1R2 R"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 P  |RELAT-1K8 X implies [TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "[TARSKIK4 x,y ] inHIDDENR3 P  |RELAT-1K8 X"
      then have "[TARSKIK4 x,y ] inHIDDENR3 P & x inHIDDENR3 X"
        using relat_1_def_11 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X"
        using A1 relat_1_def_11 sorry
    qed "sorry"
    thus "P  |RELAT-1K8 X c=RELAT-1R2 R  |RELAT-1K8 X"
      using relat_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_77:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds P c=RELAT-1R2 R & X c=TARSKIR1 Y implies P  |RELAT-1K8 X c=RELAT-1R2 R  |RELAT-1K8 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds P c=RELAT-1R2 R & X c=TARSKIR1 Y implies P  |RELAT-1K8 X c=RELAT-1R2 R  |RELAT-1K8 Y"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix P assume [ty]: "P be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume "P c=RELAT-1R2 R & X c=TARSKIR1 Y"
    then have "P  |RELAT-1K8 X c=RELAT-1R2 R  |RELAT-1K8 X & R  |RELAT-1K8 X c=RELAT-1R2 R  |RELAT-1K8 Y"
      using relat_1_th_75 relat_1_th_76 sorry
    thus "P  |RELAT-1K8 X c=RELAT-1R2 R  |RELAT-1K8 Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_78:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R  |RELAT-1K8 (X \\/XBOOLE-0K2 Y) =RELAT-1R1 R  |RELAT-1K8 X \\/XBOOLE-0K2 R  |RELAT-1K8 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R  |RELAT-1K8 (X \\/XBOOLE-0K2 Y) =RELAT-1R1 R  |RELAT-1K8 X \\/XBOOLE-0K2 R  |RELAT-1K8 Y"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 (X \\/XBOOLE-0K2 Y) implies [TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X \\/XBOOLE-0K2 R  |RELAT-1K8 Y) & ([TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X \\/XBOOLE-0K2 R  |RELAT-1K8 Y implies [TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 (X \\/XBOOLE-0K2 Y))"
    proof(rule ballI,rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      show "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 (X \\/XBOOLE-0K2 Y) implies [TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X \\/XBOOLE-0K2 R  |RELAT-1K8 Y"
      proof(rule impI)
        assume A1: "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 (X \\/XBOOLE-0K2 Y)"
        then have "x inHIDDENR3 X \\/XBOOLE-0K2 Y"
          using relat_1_def_11 sorry
        then have A2: "x inHIDDENR3 X or x inHIDDENR3 Y"
          using xboole_0_def_3 sorry
        have "[TARSKIK4 x,y ] inHIDDENR3 R"
          using A1 relat_1_def_11 sorry
        then have "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X or [TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 Y"
          using A2 relat_1_def_11 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X \\/XBOOLE-0K2 R  |RELAT-1K8 Y"
          using xboole_0_def_3 sorry
      qed
      assume A3: "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X \\/XBOOLE-0K2 R  |RELAT-1K8 Y"
      show "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 (X \\/XBOOLE-0K2 Y)"
      proof-
        have cases: "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 Y or [TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X"
          using A3 xboole_0_def_3 sorry
        have case1: "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 Y implies [TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 (X \\/XBOOLE-0K2 Y)"
        proof(rule impI)
          assume A4: "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 Y"
          then have "x inHIDDENR3 Y"
            using relat_1_def_11 sorry
          then have A5: "x inHIDDENR3 X \\/XBOOLE-0K2 Y"
            using xboole_0_def_3 sorry
          have "[TARSKIK4 x,y ] inHIDDENR3 R"
            using A4 relat_1_def_11 sorry
          thus "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 (X \\/XBOOLE-0K2 Y)"
            using A5 relat_1_def_11 sorry
        qed
        have case2: "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X implies [TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 (X \\/XBOOLE-0K2 Y)"
        proof(rule impI)
          assume A6: "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X"
          then have "x inHIDDENR3 X"
            using relat_1_def_11 sorry
          then have A7: "x inHIDDENR3 X \\/XBOOLE-0K2 Y"
            using xboole_0_def_3 sorry
          have "[TARSKIK4 x,y ] inHIDDENR3 R"
            using A6 relat_1_def_11 sorry
          thus "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 (X \\/XBOOLE-0K2 Y)"
            using A7 relat_1_def_11 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus "R  |RELAT-1K8 (X \\/XBOOLE-0K2 Y) =RELAT-1R1 R  |RELAT-1K8 X \\/XBOOLE-0K2 R  |RELAT-1K8 Y"
      using relat_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_79:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R  |RELAT-1K8 (X /\\XBOOLE-0K3 Y) =RELAT-1R1 R  |RELAT-1K8 X /\\XBOOLE-0K3 R  |RELAT-1K8 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R  |RELAT-1K8 (X /\\XBOOLE-0K3 Y) =RELAT-1R1 R  |RELAT-1K8 X /\\XBOOLE-0K3 R  |RELAT-1K8 Y"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 (X /\\XBOOLE-0K3 Y) implies [TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X /\\XBOOLE-0K3 R  |RELAT-1K8 Y) & ([TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X /\\XBOOLE-0K3 R  |RELAT-1K8 Y implies [TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 (X /\\XBOOLE-0K3 Y))"
    proof(rule ballI,rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      show "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 (X /\\XBOOLE-0K3 Y) implies [TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X /\\XBOOLE-0K3 R  |RELAT-1K8 Y"
      proof(rule impI)
        assume A1: "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 (X /\\XBOOLE-0K3 Y)"
        then have A2: "x inHIDDENR3 X /\\XBOOLE-0K3 Y"
          using relat_1_def_11 sorry
        have A3: "[TARSKIK4 x,y ] inHIDDENR3 R"
          using A1 relat_1_def_11 sorry
        have "x inHIDDENR3 Y"
          using A2 xboole_0_def_4 sorry
        then have A4: "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 Y"
          using A3 relat_1_def_11 sorry
        have "x inHIDDENR3 X"
          using A2 xboole_0_def_4 sorry
        then have "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X"
          using A3 relat_1_def_11 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X /\\XBOOLE-0K3 R  |RELAT-1K8 Y"
          using A4 xboole_0_def_4 sorry
      qed
      assume A5: "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X /\\XBOOLE-0K3 R  |RELAT-1K8 Y"
      then have "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 Y"
        using xboole_0_def_4 sorry
      then have A6: "x inHIDDENR3 Y"
        using relat_1_def_11 sorry
      have A7: "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X"
        using A5 xboole_0_def_4 sorry
      then have "x inHIDDENR3 X"
        using relat_1_def_11 sorry
      then have A8: "x inHIDDENR3 X /\\XBOOLE-0K3 Y"
        using A6 xboole_0_def_4 sorry
      have "[TARSKIK4 x,y ] inHIDDENR3 R"
        using A7 relat_1_def_11 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 (X /\\XBOOLE-0K3 Y)"
        using A8 relat_1_def_11 sorry
    qed "sorry"
    thus "R  |RELAT-1K8 (X /\\XBOOLE-0K3 Y) =RELAT-1R1 R  |RELAT-1K8 X /\\XBOOLE-0K3 R  |RELAT-1K8 Y"
      using relat_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_80:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R  |RELAT-1K8 (X \\SUBSET-1K6 Y) =RELAT-1R1 R  |RELAT-1K8 X \\SUBSET-1K6 R  |RELAT-1K8 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R  |RELAT-1K8 (X \\SUBSET-1K6 Y) =RELAT-1R1 R  |RELAT-1K8 X \\SUBSET-1K6 R  |RELAT-1K8 Y"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 (X \\SUBSET-1K6 Y) implies [TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X \\SUBSET-1K6 R  |RELAT-1K8 Y) & ([TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X \\SUBSET-1K6 R  |RELAT-1K8 Y implies [TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 (X \\SUBSET-1K6 Y))"
    proof(rule ballI,rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      show "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 (X \\SUBSET-1K6 Y) implies [TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X \\SUBSET-1K6 R  |RELAT-1K8 Y"
      proof(rule impI)
        assume A1: "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 (X \\SUBSET-1K6 Y)"
        then have A2: "x inHIDDENR3 X \\SUBSET-1K6 Y"
          using relat_1_def_11 sorry
        then have " not x inHIDDENR3 Y"
          using xboole_0_def_5 sorry
        then have A3: " not [TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 Y"
          using relat_1_def_11 sorry
        have "[TARSKIK4 x,y ] inHIDDENR3 R"
          using A1 relat_1_def_11 sorry
        then have "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X"
          using A2 relat_1_def_11 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X \\SUBSET-1K6 R  |RELAT-1K8 Y"
          using A3 xboole_0_def_5 sorry
      qed
      assume A4: "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X \\SUBSET-1K6 R  |RELAT-1K8 Y"
      then have A5: "[TARSKIK4 x,y ] inHIDDENR3 R"
        using relat_1_def_11 sorry
      have " not [TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 Y"
        using A4 xboole_0_def_5 sorry
      then have A6: " not x inHIDDENR3 Y or  not [TARSKIK4 x,y ] inHIDDENR3 R"
        using relat_1_def_11 sorry
      have "x inHIDDENR3 X"
        using A4 relat_1_def_11 sorry
      then have "x inHIDDENR3 X \\SUBSET-1K6 Y"
        using A4 A6 relat_1_def_11 xboole_0_def_5 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 (X \\SUBSET-1K6 Y)"
        using A5 relat_1_def_11 sorry
    qed "sorry"
    thus "R  |RELAT-1K8 (X \\SUBSET-1K6 Y) =RELAT-1R1 R  |RELAT-1K8 X \\SUBSET-1K6 R  |RELAT-1K8 Y"
      using relat_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_cl_21:
  mlet "R be emptyXBOOLE-0V1\<bar>RelationRELAT-1M1", "X be setHIDDENM2"
"cluster R  |RELAT-1K8 X as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "R  |RELAT-1K8 X be emptyXBOOLE-0V1"
  proof-
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 {}XBOOLE-0K1  |RELAT-1K8 X implies  False "
      using relat_1_def_11 sorry
    thus "R  |RELAT-1K8 X be emptyXBOOLE-0V1"
      using relat_1_th_37 sorry
  qed
qed "sorry"

mtheorem relat_1_th_81:
" for R be RelationRELAT-1M1 holds R  |RELAT-1K8 {}XBOOLE-0K1 =RELAT-1R1 {}XBOOLE-0K1"
   sorry

mtheorem relat_1_th_82:
" for X be setHIDDENM2 holds {}XBOOLE-0K1  |RELAT-1K8 X =RELAT-1R1 {}XBOOLE-0K1"
   sorry

mtheorem relat_1_th_83:
" for X be setHIDDENM2 holds  for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds (P *RELAT-1K6 R) |RELAT-1K8 X =RELAT-1R1 P  |RELAT-1K8 X *RELAT-1K6 R"
proof-
  have " for X be setHIDDENM2 holds  for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds (P *RELAT-1K6 R) |RELAT-1K8 X =RELAT-1R1 P  |RELAT-1K8 X *RELAT-1K6 R"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix P assume [ty]: "P be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 (P *RELAT-1K6 R) |RELAT-1K8 X implies [TARSKIK4 x,y ] inHIDDENR3 P  |RELAT-1K8 X *RELAT-1K6 R) & ([TARSKIK4 x,y ] inHIDDENR3 P  |RELAT-1K8 X *RELAT-1K6 R implies [TARSKIK4 x,y ] inHIDDENR3 (P *RELAT-1K6 R) |RELAT-1K8 X)"
    proof(rule ballI,rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      show "[TARSKIK4 x,y ] inHIDDENR3 (P *RELAT-1K6 R) |RELAT-1K8 X implies [TARSKIK4 x,y ] inHIDDENR3 P  |RELAT-1K8 X *RELAT-1K6 R"
      proof(rule impI)
        assume A1: "[TARSKIK4 x,y ] inHIDDENR3 (P *RELAT-1K6 R) |RELAT-1K8 X"
        then have "[TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 R"
          using relat_1_def_11 sorry
        then obtain a where
          [ty]:"a be objectHIDDENM1" and 
          A2: "[TARSKIK4 x,a ] inHIDDENR3 P"and A3: "[TARSKIK4 a,y ] inHIDDENR3 R"
          using relat_1_def_8 sorry
        have "x inHIDDENR3 X"
          using A1 relat_1_def_11 sorry
        then have "[TARSKIK4 x,a ] inHIDDENR3 P  |RELAT-1K8 X"
          using A2 relat_1_def_11 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 P  |RELAT-1K8 X *RELAT-1K6 R"
          using A3 relat_1_def_8 sorry
      qed
      assume "[TARSKIK4 x,y ] inHIDDENR3 P  |RELAT-1K8 X *RELAT-1K6 R"
      then obtain a where
        [ty]:"a be objectHIDDENM1" and 
        A4: "[TARSKIK4 x,a ] inHIDDENR3 P  |RELAT-1K8 X"and A5: "[TARSKIK4 a,y ] inHIDDENR3 R"
        using relat_1_def_8 sorry
      have "[TARSKIK4 x,a ] inHIDDENR3 P"
        using A4 relat_1_def_11 sorry
      then have A6: "[TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 R"
        using A5 relat_1_def_8 sorry
      have "x inHIDDENR3 X"
        using A4 relat_1_def_11 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 (P *RELAT-1K6 R) |RELAT-1K8 X"
        using A6 relat_1_def_11 sorry
    qed "sorry"
    thus "(P *RELAT-1K6 R) |RELAT-1K8 X =RELAT-1R1 P  |RELAT-1K8 X *RELAT-1K6 R"
      using relat_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef relat_1_def_12 (" _  |`RELAT-1K9  _ " [200,200]200 ) where
  mlet "Y be setHIDDENM2", "R be RelationRELAT-1M1"
"func Y  |`RELAT-1K9 R \<rightarrow> RelationRELAT-1M1 means
  \<lambda>it.  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 it iff y inHIDDENR3 Y & [TARSKIK4 x,y ] inHIDDENR3 R"
proof-
  (*existence*)
    show " ex it be RelationRELAT-1M1 st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 it iff y inHIDDENR3 Y & [TARSKIK4 x,y ] inHIDDENR3 R"
    proof-
      have " ex tVar7 be RelationRELAT-1M1 st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 tVar7 &  not (y inHIDDENR3 Y & [TARSKIK4 x,y ] inHIDDENR3 R)) &  not ((y inHIDDENR3 Y & [TARSKIK4 x,y ] inHIDDENR3 R) &  not [TARSKIK4 x,y ] inHIDDENR3 tVar7)"
      proof-
        let ?Z = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 inHIDDENR3 Y & [TARSKIK4 Lamb1,Lamb2 ] inHIDDENR3 R"
        obtain P where
          [ty]:"P be RelationRELAT-1M1" and 
          A1: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 P iff (x inHIDDENR3 domRELAT-1K1 R & y inHIDDENR3 rngRELAT-1K2 R) & ?Z(x,y)"
          using relat_1_sch_1 sorry
        show " ex tVar7 be RelationRELAT-1M1 st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 tVar7 &  not (y inHIDDENR3 Y & [TARSKIK4 x,y ] inHIDDENR3 R)) &  not ((y inHIDDENR3 Y & [TARSKIK4 x,y ] inHIDDENR3 R) &  not [TARSKIK4 x,y ] inHIDDENR3 tVar7)"
        proof(rule bexI[of _ "P"],rule ballI,rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          have "y inHIDDENR3 Y & [TARSKIK4 x,y ] inHIDDENR3 R implies x inHIDDENR3 domRELAT-1K1 R & y inHIDDENR3 rngRELAT-1K2 R"
            using xtuple_0_def_12 xtuple_0_def_13 sorry
          thus " not ([TARSKIK4 x,y ] inHIDDENR3 P &  not (y inHIDDENR3 Y & [TARSKIK4 x,y ] inHIDDENR3 R)) &  not ((y inHIDDENR3 Y & [TARSKIK4 x,y ] inHIDDENR3 R) &  not [TARSKIK4 x,y ] inHIDDENR3 P)"
            using A1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be RelationRELAT-1M1 holds  for it2 be RelationRELAT-1M1 holds ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 it1 iff y inHIDDENR3 Y & [TARSKIK4 x,y ] inHIDDENR3 R) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 it2 iff y inHIDDENR3 Y & [TARSKIK4 x,y ] inHIDDENR3 R) implies it1 =HIDDENR1 it2"
    proof-
      have " for P1 be RelationRELAT-1M1 holds  for P2 be RelationRELAT-1M1 holds ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 P1 iff y inHIDDENR3 Y & [TARSKIK4 x,y ] inHIDDENR3 R) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 P2 iff y inHIDDENR3 Y & [TARSKIK4 x,y ] inHIDDENR3 R) implies P1 =HIDDENR1 P2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix P1 assume [ty]: "P1 be RelationRELAT-1M1"
        fix P2 assume [ty]: "P2 be RelationRELAT-1M1"
        assume A2: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 P1 iff y inHIDDENR3 Y & [TARSKIK4 x,y ] inHIDDENR3 R"
          and A3: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 P2 iff y inHIDDENR3 Y & [TARSKIK4 x,y ] inHIDDENR3 R"
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 P1 iff [TARSKIK4 x,y ] inHIDDENR3 P2"
        proof(rule ballI,rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          have "[TARSKIK4 x,y ] inHIDDENR3 P1 iff y inHIDDENR3 Y & [TARSKIK4 x,y ] inHIDDENR3 R"
            using A2 sorry
          thus "[TARSKIK4 x,y ] inHIDDENR3 P1 iff [TARSKIK4 x,y ] inHIDDENR3 P2"
            using A3 sorry
        qed "sorry"
        thus "P1 =HIDDENR1 P2"
          using relat_1_def_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem relat_1_cl_22:
  mlet "R be RelationRELAT-1M1", "X be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster X  |`RELAT-1K9 R as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "X  |`RELAT-1K9 R be emptyXBOOLE-0V1"
  proof-
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not [TARSKIK4 x,y ] inHIDDENR3 X  |`RELAT-1K9 R"
      using relat_1_def_12 sorry
    thus "X  |`RELAT-1K9 R be emptyXBOOLE-0V1"
      using relat_1_th_37 sorry
  qed
qed "sorry"

mtheorem relat_1_th_84:
" for Y be setHIDDENM2 holds  for y be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds y inHIDDENR3 rngRELAT-1K2 (Y  |`RELAT-1K9 R) iff y inHIDDENR3 Y & y inHIDDENR3 rngRELAT-1K2 R"
proof-
  have " for Y be setHIDDENM2 holds  for y be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds (y inHIDDENR3 rngRELAT-1K2 (Y  |`RELAT-1K9 R) implies y inHIDDENR3 Y & y inHIDDENR3 rngRELAT-1K2 R) & (y inHIDDENR3 Y implies (y inHIDDENR3 rngRELAT-1K2 R implies y inHIDDENR3 rngRELAT-1K2 (Y  |`RELAT-1K9 R)))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "y inHIDDENR3 rngRELAT-1K2 (Y  |`RELAT-1K9 R) implies y inHIDDENR3 Y & y inHIDDENR3 rngRELAT-1K2 R"
    proof(rule impI)
      assume "y inHIDDENR3 rngRELAT-1K2 (Y  |`RELAT-1K9 R)"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A1: "[TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 R"
        using xtuple_0_def_13 sorry
      have "[TARSKIK4 x,y ] inHIDDENR3 R"
        using A1 relat_1_def_12 sorry
      thus "y inHIDDENR3 Y & y inHIDDENR3 rngRELAT-1K2 R"
        using A1 relat_1_def_12 xtuple_0_def_13 sorry
    qed
    assume A2: "y inHIDDENR3 Y"
    assume "y inHIDDENR3 rngRELAT-1K2 R"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A3: "[TARSKIK4 x,y ] inHIDDENR3 R"
      using xtuple_0_def_13 sorry
    have "[TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 R"
      using A2 A3 relat_1_def_12 sorry
    thus "y inHIDDENR3 rngRELAT-1K2 (Y  |`RELAT-1K9 R)"
      using xtuple_0_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_85:
" for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds rngRELAT-1K2 (Y  |`RELAT-1K9 R) c=TARSKIR1 Y"
  using relat_1_th_84 sorry

mtheorem relat_1_th_86:
" for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds Y  |`RELAT-1K9 R c=RELAT-1R2 R"
  using relat_1_def_12 sorry

mtheorem relat_1_th_87:
" for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds rngRELAT-1K2 (Y  |`RELAT-1K9 R) c=TARSKIR1 rngRELAT-1K2 R"
  using relat_1_th_86 xtuple_0_th_9 sorry

mtheorem relat_1_th_88:
" for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds rngRELAT-1K2 (Y  |`RELAT-1K9 R) =XBOOLE-0R4 rngRELAT-1K2 R /\\XBOOLE-0K3 Y"
proof-
  have " for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds rngRELAT-1K2 (Y  |`RELAT-1K9 R) =XBOOLE-0R4 rngRELAT-1K2 R /\\XBOOLE-0K3 Y"
  proof(rule ballI,rule ballI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have Cut1514: "rngRELAT-1K2 (Y  |`RELAT-1K9 R) c=TARSKIR1 Y & rngRELAT-1K2 (Y  |`RELAT-1K9 R) c=TARSKIR1 rngRELAT-1K2 R"
      using relat_1_th_84 sorry
    have "rngRELAT-1K2 (Y  |`RELAT-1K9 R) c=TARSKIR1 rngRELAT-1K2 R /\\XBOOLE-0K3 Y & rngRELAT-1K2 R /\\XBOOLE-0K3 Y c=TARSKIR1 rngRELAT-1K2 (Y  |`RELAT-1K9 R)"
    proof(rule conjMI)
      show "rngRELAT-1K2 (Y  |`RELAT-1K9 R) c=TARSKIR1 rngRELAT-1K2 R /\\XBOOLE-0K3 Y"
        using xboole_1_th_19 Cut1514 sorry
      have " for y be objectHIDDENM1 holds y inHIDDENR3 rngRELAT-1K2 R /\\XBOOLE-0K3 Y implies y inHIDDENR3 rngRELAT-1K2 (Y  |`RELAT-1K9 R)"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A1: "y inHIDDENR3 rngRELAT-1K2 R /\\XBOOLE-0K3 Y"
        then have "y inHIDDENR3 rngRELAT-1K2 R"
          using xboole_0_def_4 sorry
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A2: "[TARSKIK4 x,y ] inHIDDENR3 R"
          using xtuple_0_def_13 sorry
        have "y inHIDDENR3 Y"
          using A1 xboole_0_def_4 sorry
        then have "[TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 R"
          using A2 relat_1_def_12 sorry
        thus "y inHIDDENR3 rngRELAT-1K2 (Y  |`RELAT-1K9 R)"
          using xtuple_0_def_13 sorry
      qed "sorry"
      thus "rngRELAT-1K2 R /\\XBOOLE-0K3 Y c=TARSKIR1 rngRELAT-1K2 (Y  |`RELAT-1K9 R)"
        using tarski_def_3 sorry
    qed
    thus "rngRELAT-1K2 (Y  |`RELAT-1K9 R) =XBOOLE-0R4 rngRELAT-1K2 R /\\XBOOLE-0K3 Y"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_89:
" for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds Y c=TARSKIR1 rngRELAT-1K2 R implies rngRELAT-1K2 (Y  |`RELAT-1K9 R) =XBOOLE-0R4 Y"
proof-
  have " for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds Y c=TARSKIR1 rngRELAT-1K2 R implies rngRELAT-1K2 (Y  |`RELAT-1K9 R) =XBOOLE-0R4 Y"
  proof(rule ballI,rule ballI,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume "Y c=TARSKIR1 rngRELAT-1K2 R"
    then have "rngRELAT-1K2 R /\\XBOOLE-0K3 Y =XBOOLE-0R4 Y"
      using xboole_1_th_28 sorry
    thus "rngRELAT-1K2 (Y  |`RELAT-1K9 R) =XBOOLE-0R4 Y"
      using relat_1_th_88 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_90:
" for Y be setHIDDENM2 holds  for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds Y  |`RELAT-1K9 R *RELAT-1K6 P c=RELAT-1R2 R *RELAT-1K6 P"
  using relat_1_th_30 relat_1_th_86 sorry

mtheorem relat_1_th_91:
" for Y be setHIDDENM2 holds  for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds P *RELAT-1K6 Y  |`RELAT-1K9 R c=RELAT-1R2 P *RELAT-1K6 R"
  using relat_1_th_29 relat_1_th_86 sorry

mtheorem relat_1_th_92:
" for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds Y  |`RELAT-1K9 R =RELAT-1R1 R *RELAT-1K6 idRELAT-1K7 Y"
proof-
  have " for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds Y  |`RELAT-1K9 R =RELAT-1R1 R *RELAT-1K6 idRELAT-1K7 Y"
  proof(rule ballI,rule ballI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 R &  not [TARSKIK4 x,y ] inHIDDENR3 R *RELAT-1K6 idRELAT-1K7 Y) &  not ([TARSKIK4 x,y ] inHIDDENR3 R *RELAT-1K6 idRELAT-1K7 Y &  not [TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 R)"
    proof(rule ballI,rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      have "[TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 R iff y inHIDDENR3 Y & [TARSKIK4 x,y ] inHIDDENR3 R"
        using relat_1_def_12 sorry
      thus " not ([TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 R &  not [TARSKIK4 x,y ] inHIDDENR3 R *RELAT-1K6 idRELAT-1K7 Y) &  not ([TARSKIK4 x,y ] inHIDDENR3 R *RELAT-1K6 idRELAT-1K7 Y &  not [TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 R)"
        using relat_1_th_49 sorry
    qed "sorry"
    thus "Y  |`RELAT-1K9 R =RELAT-1R1 R *RELAT-1K6 idRELAT-1K7 Y"
      using relat_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_93:
" for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds Y  |`RELAT-1K9 R =RELAT-1R1 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 domRELAT-1K1 R,Y :])"
proof-
  have " for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds Y  |`RELAT-1K9 R =RELAT-1R1 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 domRELAT-1K1 R,Y :])"
  proof(rule ballI,rule ballI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    let ?P = "R /\\XBOOLE-0K3 ([:ZFMISC-1K2 domRELAT-1K1 R,Y :])"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 R implies [TARSKIK4 x,y ] inHIDDENR3 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 domRELAT-1K1 R,Y :])) & ([TARSKIK4 x,y ] inHIDDENR3 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 domRELAT-1K1 R,Y :]) implies [TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 R)"
    proof(rule ballI,rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      show "[TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 R implies [TARSKIK4 x,y ] inHIDDENR3 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 domRELAT-1K1 R,Y :])"
      proof(rule impI)
        assume A1: "[TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 R"
        then have A2: "y inHIDDENR3 Y"
          using relat_1_def_12 sorry
        have A3: "[TARSKIK4 x,y ] inHIDDENR3 R"
          using A1 relat_1_def_12 sorry
        then have "x inHIDDENR3 domRELAT-1K1 R"
          using xtuple_0_def_12 sorry
        then have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 R,Y :]"
          using A2 zfmisc_1_def_2 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 domRELAT-1K1 R,Y :])"
          using A3 xboole_0_def_4 sorry
      qed
      assume A4: "[TARSKIK4 x,y ] inHIDDENR3 ?P"
      then have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 R,Y :]"
        using xboole_0_def_4 sorry
      then have A5: "y inHIDDENR3 Y"
        using zfmisc_1_th_87 sorry
      have "[TARSKIK4 x,y ] inHIDDENR3 R"
        using A4 xboole_0_def_4 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 R"
        using A5 relat_1_def_12 sorry
    qed "sorry"
    thus "Y  |`RELAT-1K9 R =RELAT-1R1 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 domRELAT-1K1 R,Y :])"
      using relat_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_94:
" for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds rngRELAT-1K2 R c=TARSKIR1 Y implies Y  |`RELAT-1K9 R =RELAT-1R1 R"
proof-
  have " for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds rngRELAT-1K2 R c=TARSKIR1 Y implies Y  |`RELAT-1K9 R =RELAT-1R1 R"
  proof(rule ballI,rule ballI,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume "rngRELAT-1K2 R c=TARSKIR1 Y"
    then have A1: "[:ZFMISC-1K2 domRELAT-1K1 R,rngRELAT-1K2 R :] c=RELAT-1R2 [:ZFMISC-1K2 domRELAT-1K1 R,Y :]"
      using zfmisc_1_th_95 sorry
    have "R c=RELAT-1R2 [:ZFMISC-1K2 domRELAT-1K1 R,rngRELAT-1K2 R :] & Y  |`RELAT-1K9 R =RELAT-1R1 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 domRELAT-1K1 R,Y :])"
      using relat_1_th_7 relat_1_th_93 sorry
    thus "Y  |`RELAT-1K9 R =RELAT-1R1 R"
      using A1 xboole_1_th_1 xboole_1_th_28 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_reduce_6:
  mlet "R be RelationRELAT-1M1"
"reduce rngRELAT-1K2 R  |`RELAT-1K9 R to R"
proof
(*reducibility*)
  show "rngRELAT-1K2 R  |`RELAT-1K9 R =HIDDENR1 R"
    using relat_1_th_94 sorry
qed "sorry"

mtheorem relat_1_th_95:
" for R be RelationRELAT-1M1 holds rngRELAT-1K2 R  |`RELAT-1K9 R =RELAT-1R1 R"
   sorry

mtheorem relat_1_th_96:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds Y  |`RELAT-1K9 (X  |`RELAT-1K9 R) =RELAT-1R1 (Y /\\XBOOLE-0K3 X) |`RELAT-1K9 R"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds Y  |`RELAT-1K9 (X  |`RELAT-1K9 R) =RELAT-1R1 (Y /\\XBOOLE-0K3 X) |`RELAT-1K9 R"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 (X  |`RELAT-1K9 R) &  not [TARSKIK4 x,y ] inHIDDENR3 (Y /\\XBOOLE-0K3 X) |`RELAT-1K9 R) &  not ([TARSKIK4 x,y ] inHIDDENR3 (Y /\\XBOOLE-0K3 X) |`RELAT-1K9 R &  not [TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 (X  |`RELAT-1K9 R))"
    proof(rule ballI,rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      have A1: "[TARSKIK4 x,y ] inHIDDENR3 X  |`RELAT-1K9 R iff [TARSKIK4 x,y ] inHIDDENR3 R & y inHIDDENR3 X"
        using relat_1_def_12 sorry
      have A2: "[TARSKIK4 x,y ] inHIDDENR3 (Y /\\XBOOLE-0K3 X) |`RELAT-1K9 R iff [TARSKIK4 x,y ] inHIDDENR3 R & y inHIDDENR3 Y /\\XBOOLE-0K3 X"
        using relat_1_def_12 sorry
      have "[TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 (X  |`RELAT-1K9 R) iff [TARSKIK4 x,y ] inHIDDENR3 X  |`RELAT-1K9 R & y inHIDDENR3 Y"
        using relat_1_def_12 sorry
      thus " not ([TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 (X  |`RELAT-1K9 R) &  not [TARSKIK4 x,y ] inHIDDENR3 (Y /\\XBOOLE-0K3 X) |`RELAT-1K9 R) &  not ([TARSKIK4 x,y ] inHIDDENR3 (Y /\\XBOOLE-0K3 X) |`RELAT-1K9 R &  not [TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 (X  |`RELAT-1K9 R))"
        using A1 A2 xboole_0_def_4 sorry
    qed "sorry"
    thus "Y  |`RELAT-1K9 (X  |`RELAT-1K9 R) =RELAT-1R1 (Y /\\XBOOLE-0K3 X) |`RELAT-1K9 R"
      using relat_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_reduce_7:
  mlet "Y be setHIDDENM2", "R be RelationRELAT-1M1"
"reduce Y  |`RELAT-1K9 (Y  |`RELAT-1K9 R) to Y  |`RELAT-1K9 R"
proof
(*reducibility*)
  show "Y  |`RELAT-1K9 (Y  |`RELAT-1K9 R) =HIDDENR1 Y  |`RELAT-1K9 R"
  proof-
    have "Y /\\XBOOLE-0K3 Y =XBOOLE-0R4 Y"
       sorry
    thus "Y  |`RELAT-1K9 (Y  |`RELAT-1K9 R) =HIDDENR1 Y  |`RELAT-1K9 R"
      using relat_1_th_96 sorry
  qed
qed "sorry"

mtheorem relat_1_th_97:
" for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds Y  |`RELAT-1K9 (Y  |`RELAT-1K9 R) =RELAT-1R1 Y  |`RELAT-1K9 R"
   sorry

mtheorem relat_1_th_98:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds X c=TARSKIR1 Y implies Y  |`RELAT-1K9 (X  |`RELAT-1K9 R) =RELAT-1R1 X  |`RELAT-1K9 R"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds  not (X c=TARSKIR1 Y &  not Y  |`RELAT-1K9 (X  |`RELAT-1K9 R) =RELAT-1R1 X  |`RELAT-1K9 R)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have "X c=TARSKIR1 Y implies Y /\\XBOOLE-0K3 X =XBOOLE-0R4 X"
      using xboole_1_th_28 sorry
    thus " not (X c=TARSKIR1 Y &  not Y  |`RELAT-1K9 (X  |`RELAT-1K9 R) =RELAT-1R1 X  |`RELAT-1K9 R)"
      using relat_1_th_96 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_99:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds Y c=TARSKIR1 X implies Y  |`RELAT-1K9 (X  |`RELAT-1K9 R) =RELAT-1R1 Y  |`RELAT-1K9 R"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds  not (Y c=TARSKIR1 X &  not Y  |`RELAT-1K9 (X  |`RELAT-1K9 R) =RELAT-1R1 Y  |`RELAT-1K9 R)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have "Y c=TARSKIR1 X implies Y /\\XBOOLE-0K3 X =XBOOLE-0R4 Y"
      using xboole_1_th_28 sorry
    thus " not (Y c=TARSKIR1 X &  not Y  |`RELAT-1K9 (X  |`RELAT-1K9 R) =RELAT-1R1 Y  |`RELAT-1K9 R)"
      using relat_1_th_96 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_100:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds X c=TARSKIR1 Y implies X  |`RELAT-1K9 R c=RELAT-1R2 Y  |`RELAT-1K9 R"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds X c=TARSKIR1 Y implies X  |`RELAT-1K9 R c=RELAT-1R2 Y  |`RELAT-1K9 R"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume A1: "X c=TARSKIR1 Y"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 X  |`RELAT-1K9 R &  not [TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 R)"
    proof(rule ballI,rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      have "[TARSKIK4 x,y ] inHIDDENR3 X  |`RELAT-1K9 R iff [TARSKIK4 x,y ] inHIDDENR3 R & y inHIDDENR3 X"
        using relat_1_def_12 sorry
      thus " not ([TARSKIK4 x,y ] inHIDDENR3 X  |`RELAT-1K9 R &  not [TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 R)"
        using A1 relat_1_def_12 sorry
    qed "sorry"
    thus "X  |`RELAT-1K9 R c=RELAT-1R2 Y  |`RELAT-1K9 R"
      using relat_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_101:
" for Y be setHIDDENM2 holds  for P1 be RelationRELAT-1M1 holds  for P2 be RelationRELAT-1M1 holds P1 c=RELAT-1R2 P2 implies Y  |`RELAT-1K9 P1 c=RELAT-1R2 Y  |`RELAT-1K9 P2"
proof-
  have " for Y be setHIDDENM2 holds  for P1 be RelationRELAT-1M1 holds  for P2 be RelationRELAT-1M1 holds P1 c=RELAT-1R2 P2 implies Y  |`RELAT-1K9 P1 c=RELAT-1R2 Y  |`RELAT-1K9 P2"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix P1 assume [ty]: "P1 be RelationRELAT-1M1"
    fix P2 assume [ty]: "P2 be RelationRELAT-1M1"
    assume A1: "P1 c=RELAT-1R2 P2"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 P1 implies [TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 P2"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "[TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 P1"
      then have "[TARSKIK4 x,y ] inHIDDENR3 P1 & y inHIDDENR3 Y"
        using relat_1_def_12 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 P2"
        using A1 relat_1_def_12 sorry
    qed "sorry"
    thus "Y  |`RELAT-1K9 P1 c=RELAT-1R2 Y  |`RELAT-1K9 P2"
      using relat_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_102:
" for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for P1 be RelationRELAT-1M1 holds  for P2 be RelationRELAT-1M1 holds P1 c=RELAT-1R2 P2 & Y1 c=TARSKIR1 Y2 implies Y1  |`RELAT-1K9 P1 c=RELAT-1R2 Y2  |`RELAT-1K9 P2"
proof-
  have " for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for P1 be RelationRELAT-1M1 holds  for P2 be RelationRELAT-1M1 holds P1 c=RELAT-1R2 P2 & Y1 c=TARSKIR1 Y2 implies Y1  |`RELAT-1K9 P1 c=RELAT-1R2 Y2  |`RELAT-1K9 P2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix Y2 assume [ty]: "Y2 be setHIDDENM2"
    fix P1 assume [ty]: "P1 be RelationRELAT-1M1"
    fix P2 assume [ty]: "P2 be RelationRELAT-1M1"
    assume "P1 c=RELAT-1R2 P2 & Y1 c=TARSKIR1 Y2"
    then have "Y1  |`RELAT-1K9 P1 c=RELAT-1R2 Y1  |`RELAT-1K9 P2 & Y1  |`RELAT-1K9 P2 c=RELAT-1R2 Y2  |`RELAT-1K9 P2"
      using relat_1_th_100 relat_1_th_101 sorry
    thus "Y1  |`RELAT-1K9 P1 c=RELAT-1R2 Y2  |`RELAT-1K9 P2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_103:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds (X \\/XBOOLE-0K2 Y) |`RELAT-1K9 R =RELAT-1R1 X  |`RELAT-1K9 R \\/XBOOLE-0K2 Y  |`RELAT-1K9 R"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds (X \\/XBOOLE-0K2 Y) |`RELAT-1K9 R =RELAT-1R1 X  |`RELAT-1K9 R \\/XBOOLE-0K2 Y  |`RELAT-1K9 R"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 (X \\/XBOOLE-0K2 Y) |`RELAT-1K9 R &  not [TARSKIK4 x,y ] inHIDDENR3 X  |`RELAT-1K9 R \\/XBOOLE-0K2 Y  |`RELAT-1K9 R) &  not ([TARSKIK4 x,y ] inHIDDENR3 X  |`RELAT-1K9 R \\/XBOOLE-0K2 Y  |`RELAT-1K9 R &  not [TARSKIK4 x,y ] inHIDDENR3 (X \\/XBOOLE-0K2 Y) |`RELAT-1K9 R)"
    proof(rule ballI,rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      have A1: "y inHIDDENR3 X \\/XBOOLE-0K2 Y iff y inHIDDENR3 X or y inHIDDENR3 Y"
        using xboole_0_def_3 sorry
      have A2: "[TARSKIK4 x,y ] inHIDDENR3 X  |`RELAT-1K9 R \\/XBOOLE-0K2 Y  |`RELAT-1K9 R iff [TARSKIK4 x,y ] inHIDDENR3 X  |`RELAT-1K9 R or [TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 R"
        using xboole_0_def_3 sorry
      have "[TARSKIK4 x,y ] inHIDDENR3 (X \\/XBOOLE-0K2 Y) |`RELAT-1K9 R iff y inHIDDENR3 X \\/XBOOLE-0K2 Y & [TARSKIK4 x,y ] inHIDDENR3 R"
        using relat_1_def_12 sorry
      thus " not ([TARSKIK4 x,y ] inHIDDENR3 (X \\/XBOOLE-0K2 Y) |`RELAT-1K9 R &  not [TARSKIK4 x,y ] inHIDDENR3 X  |`RELAT-1K9 R \\/XBOOLE-0K2 Y  |`RELAT-1K9 R) &  not ([TARSKIK4 x,y ] inHIDDENR3 X  |`RELAT-1K9 R \\/XBOOLE-0K2 Y  |`RELAT-1K9 R &  not [TARSKIK4 x,y ] inHIDDENR3 (X \\/XBOOLE-0K2 Y) |`RELAT-1K9 R)"
        using A1 A2 relat_1_def_12 sorry
    qed "sorry"
    thus "(X \\/XBOOLE-0K2 Y) |`RELAT-1K9 R =RELAT-1R1 X  |`RELAT-1K9 R \\/XBOOLE-0K2 Y  |`RELAT-1K9 R"
      using relat_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_104:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds (X /\\XBOOLE-0K3 Y) |`RELAT-1K9 R =RELAT-1R1 X  |`RELAT-1K9 R /\\XBOOLE-0K3 Y  |`RELAT-1K9 R"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds (X /\\XBOOLE-0K3 Y) |`RELAT-1K9 R =RELAT-1R1 X  |`RELAT-1K9 R /\\XBOOLE-0K3 Y  |`RELAT-1K9 R"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 (X /\\XBOOLE-0K3 Y) |`RELAT-1K9 R &  not [TARSKIK4 x,y ] inHIDDENR3 X  |`RELAT-1K9 R /\\XBOOLE-0K3 Y  |`RELAT-1K9 R) &  not ([TARSKIK4 x,y ] inHIDDENR3 X  |`RELAT-1K9 R /\\XBOOLE-0K3 Y  |`RELAT-1K9 R &  not [TARSKIK4 x,y ] inHIDDENR3 (X /\\XBOOLE-0K3 Y) |`RELAT-1K9 R)"
    proof(rule ballI,rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      have A1: "y inHIDDENR3 X /\\XBOOLE-0K3 Y iff y inHIDDENR3 X & y inHIDDENR3 Y"
        using xboole_0_def_4 sorry
      have A2: "[TARSKIK4 x,y ] inHIDDENR3 X  |`RELAT-1K9 R /\\XBOOLE-0K3 Y  |`RELAT-1K9 R iff [TARSKIK4 x,y ] inHIDDENR3 X  |`RELAT-1K9 R & [TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 R"
        using xboole_0_def_4 sorry
      have "[TARSKIK4 x,y ] inHIDDENR3 (X /\\XBOOLE-0K3 Y) |`RELAT-1K9 R iff y inHIDDENR3 X /\\XBOOLE-0K3 Y & [TARSKIK4 x,y ] inHIDDENR3 R"
        using relat_1_def_12 sorry
      thus " not ([TARSKIK4 x,y ] inHIDDENR3 (X /\\XBOOLE-0K3 Y) |`RELAT-1K9 R &  not [TARSKIK4 x,y ] inHIDDENR3 X  |`RELAT-1K9 R /\\XBOOLE-0K3 Y  |`RELAT-1K9 R) &  not ([TARSKIK4 x,y ] inHIDDENR3 X  |`RELAT-1K9 R /\\XBOOLE-0K3 Y  |`RELAT-1K9 R &  not [TARSKIK4 x,y ] inHIDDENR3 (X /\\XBOOLE-0K3 Y) |`RELAT-1K9 R)"
        using A1 A2 relat_1_def_12 sorry
    qed "sorry"
    thus "(X /\\XBOOLE-0K3 Y) |`RELAT-1K9 R =RELAT-1R1 X  |`RELAT-1K9 R /\\XBOOLE-0K3 Y  |`RELAT-1K9 R"
      using relat_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_105:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds (X \\SUBSET-1K6 Y) |`RELAT-1K9 R =RELAT-1R1 X  |`RELAT-1K9 R \\SUBSET-1K6 Y  |`RELAT-1K9 R"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds (X \\SUBSET-1K6 Y) |`RELAT-1K9 R =RELAT-1R1 X  |`RELAT-1K9 R \\SUBSET-1K6 Y  |`RELAT-1K9 R"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 (X \\SUBSET-1K6 Y) |`RELAT-1K9 R &  not [TARSKIK4 x,y ] inHIDDENR3 X  |`RELAT-1K9 R \\SUBSET-1K6 Y  |`RELAT-1K9 R) &  not ([TARSKIK4 x,y ] inHIDDENR3 X  |`RELAT-1K9 R \\SUBSET-1K6 Y  |`RELAT-1K9 R &  not [TARSKIK4 x,y ] inHIDDENR3 (X \\SUBSET-1K6 Y) |`RELAT-1K9 R)"
    proof(rule ballI,rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      have A1: "y inHIDDENR3 X \\SUBSET-1K6 Y iff y inHIDDENR3 X &  not y inHIDDENR3 Y"
        using xboole_0_def_5 sorry
      have A2: "[TARSKIK4 x,y ] inHIDDENR3 X  |`RELAT-1K9 R \\SUBSET-1K6 Y  |`RELAT-1K9 R iff [TARSKIK4 x,y ] inHIDDENR3 X  |`RELAT-1K9 R &  not [TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 R"
        using xboole_0_def_5 sorry
      have "[TARSKIK4 x,y ] inHIDDENR3 X  |`RELAT-1K9 R iff y inHIDDENR3 X & [TARSKIK4 x,y ] inHIDDENR3 R"
        using relat_1_def_12 sorry
      thus " not ([TARSKIK4 x,y ] inHIDDENR3 (X \\SUBSET-1K6 Y) |`RELAT-1K9 R &  not [TARSKIK4 x,y ] inHIDDENR3 X  |`RELAT-1K9 R \\SUBSET-1K6 Y  |`RELAT-1K9 R) &  not ([TARSKIK4 x,y ] inHIDDENR3 X  |`RELAT-1K9 R \\SUBSET-1K6 Y  |`RELAT-1K9 R &  not [TARSKIK4 x,y ] inHIDDENR3 (X \\SUBSET-1K6 Y) |`RELAT-1K9 R)"
        using A1 A2 relat_1_def_12 sorry
    qed "sorry"
    thus "(X \\SUBSET-1K6 Y) |`RELAT-1K9 R =RELAT-1R1 X  |`RELAT-1K9 R \\SUBSET-1K6 Y  |`RELAT-1K9 R"
      using relat_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_106:
" for R be RelationRELAT-1M1 holds {}XBOOLE-0K1  |`RELAT-1K9 R =RELAT-1R1 {}XBOOLE-0K1"
   sorry

mtheorem relat_1_th_107:
" for Y be setHIDDENM2 holds Y  |`RELAT-1K9 {}XBOOLE-0K1 =RELAT-1R1 {}XBOOLE-0K1"
  using relat_1_def_12 sorry

mtheorem relat_1_th_108:
" for Y be setHIDDENM2 holds  for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds Y  |`RELAT-1K9 (P *RELAT-1K6 R) =RELAT-1R1 P *RELAT-1K6 Y  |`RELAT-1K9 R"
proof-
  have " for Y be setHIDDENM2 holds  for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds Y  |`RELAT-1K9 (P *RELAT-1K6 R) =RELAT-1R1 P *RELAT-1K6 Y  |`RELAT-1K9 R"
  proof(rule ballI,rule ballI,rule ballI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix P assume [ty]: "P be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 (P *RELAT-1K6 R) implies [TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 Y  |`RELAT-1K9 R) & ([TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 Y  |`RELAT-1K9 R implies [TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 (P *RELAT-1K6 R))"
    proof(rule ballI,rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      show "[TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 (P *RELAT-1K6 R) implies [TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 Y  |`RELAT-1K9 R"
      proof(rule impI)
        assume A1: "[TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 (P *RELAT-1K6 R)"
        then have "[TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 R"
          using relat_1_def_12 sorry
        then obtain a where
          [ty]:"a be objectHIDDENM1" and 
          A2: "[TARSKIK4 x,a ] inHIDDENR3 P"and A3: "[TARSKIK4 a,y ] inHIDDENR3 R"
          using relat_1_def_8 sorry
        have "y inHIDDENR3 Y"
          using A1 relat_1_def_12 sorry
        then have "[TARSKIK4 a,y ] inHIDDENR3 Y  |`RELAT-1K9 R"
          using A3 relat_1_def_12 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 Y  |`RELAT-1K9 R"
          using A2 relat_1_def_8 sorry
      qed
      assume "[TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 Y  |`RELAT-1K9 R"
      then obtain a where
        [ty]:"a be objectHIDDENM1" and 
        A4: "[TARSKIK4 x,a ] inHIDDENR3 P"and A5: "[TARSKIK4 a,y ] inHIDDENR3 Y  |`RELAT-1K9 R"
        using relat_1_def_8 sorry
      have "[TARSKIK4 a,y ] inHIDDENR3 R"
        using A5 relat_1_def_12 sorry
      then have A6: "[TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 R"
        using A4 relat_1_def_8 sorry
      have "y inHIDDENR3 Y"
        using A5 relat_1_def_12 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 (P *RELAT-1K6 R)"
        using A6 relat_1_def_12 sorry
    qed "sorry"
    thus "Y  |`RELAT-1K9 (P *RELAT-1K6 R) =RELAT-1R1 P *RELAT-1K6 Y  |`RELAT-1K9 R"
      using relat_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_109:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds (Y  |`RELAT-1K9 R) |RELAT-1K8 X =RELAT-1R1 Y  |`RELAT-1K9 (R  |RELAT-1K8 X)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds (Y  |`RELAT-1K9 R) |RELAT-1K8 X =RELAT-1R1 Y  |`RELAT-1K9 (R  |RELAT-1K8 X)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 (Y  |`RELAT-1K9 R) |RELAT-1K8 X &  not [TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 (R  |RELAT-1K8 X)) &  not ([TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 (R  |RELAT-1K8 X) &  not [TARSKIK4 x,y ] inHIDDENR3 (Y  |`RELAT-1K9 R) |RELAT-1K8 X)"
    proof(rule ballI,rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      have A1: "[TARSKIK4 x,y ] inHIDDENR3 R & x inHIDDENR3 X iff [TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X"
        using relat_1_def_11 sorry
      have "[TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 R iff [TARSKIK4 x,y ] inHIDDENR3 R & y inHIDDENR3 Y"
        using relat_1_def_12 sorry
      thus " not ([TARSKIK4 x,y ] inHIDDENR3 (Y  |`RELAT-1K9 R) |RELAT-1K8 X &  not [TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 (R  |RELAT-1K8 X)) &  not ([TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 (R  |RELAT-1K8 X) &  not [TARSKIK4 x,y ] inHIDDENR3 (Y  |`RELAT-1K9 R) |RELAT-1K8 X)"
        using A1 relat_1_def_11 relat_1_def_12 sorry
    qed "sorry"
    thus "(Y  |`RELAT-1K9 R) |RELAT-1K8 X =RELAT-1R1 Y  |`RELAT-1K9 (R  |RELAT-1K8 X)"
      using relat_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef relat_1_def_13 (" _ .:RELAT-1K10  _ " [200,200]200 ) where
  mlet "R be RelationRELAT-1M1", "X be setHIDDENM2"
"func R .:RELAT-1K10 X \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for y be objectHIDDENM1 holds y inHIDDENR3 it iff ( ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & x inHIDDENR3 X)"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for y be objectHIDDENM1 holds y inHIDDENR3 it iff ( ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & x inHIDDENR3 X)"
    proof-
      have " ex tVar8 be setHIDDENM2 st  for y be objectHIDDENM1 holds (y inHIDDENR3 tVar8 implies ( ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & x inHIDDENR3 X)) & (( ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & x inHIDDENR3 X) implies y inHIDDENR3 tVar8)"
      proof-
        let ?Z = "\<lambda>Lamb1.  ex x be objectHIDDENM1 st [TARSKIK4 x,Lamb1 ] inHIDDENR3 R & x inHIDDENR3 X"
        obtain Y where
          [ty]:"Y be setHIDDENM2" and 
          A1: " for y be objectHIDDENM1 holds y inHIDDENR3 Y iff y inHIDDENR3 rngRELAT-1K2 R & ?Z(y)"
          using xboole_0_sch_1 sorry
        show " ex tVar8 be setHIDDENM2 st  for y be objectHIDDENM1 holds (y inHIDDENR3 tVar8 implies ( ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & x inHIDDENR3 X)) & (( ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & x inHIDDENR3 X) implies y inHIDDENR3 tVar8)"
        proof(rule bexI[of _ "Y"],rule ballI,rule conjMI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          show "y inHIDDENR3 Y implies ( ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & x inHIDDENR3 X)"
            using A1 sorry
          assume Given: " ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & x inHIDDENR3 X"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A2: "[TARSKIK4 x,y ] inHIDDENR3 R"and A3: "x inHIDDENR3 X"
             sorry
          have "y inHIDDENR3 rngRELAT-1K2 R"
            using A2 xtuple_0_def_13 sorry
          thus "y inHIDDENR3 Y"
            using A1 A2 A3 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for y be objectHIDDENM1 holds y inHIDDENR3 it1 iff ( ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & x inHIDDENR3 X)) & ( for y be objectHIDDENM1 holds y inHIDDENR3 it2 iff ( ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & x inHIDDENR3 X)) implies it1 =HIDDENR1 it2"
    proof-
      have " for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds ( for y be objectHIDDENM1 holds y inHIDDENR3 Y1 iff ( ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & x inHIDDENR3 X)) & ( for y be objectHIDDENM1 holds y inHIDDENR3 Y2 iff ( ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & x inHIDDENR3 X)) implies Y1 =HIDDENR1 Y2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix Y1 assume [ty]: "Y1 be setHIDDENM2"
        fix Y2 assume [ty]: "Y2 be setHIDDENM2"
        assume A4: " for y be objectHIDDENM1 holds y inHIDDENR3 Y1 iff ( ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & x inHIDDENR3 X)"
          and A5: " for y be objectHIDDENM1 holds y inHIDDENR3 Y2 iff ( ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & x inHIDDENR3 X)"
        have " for y be objectHIDDENM1 holds y inHIDDENR3 Y1 iff y inHIDDENR3 Y2"
        proof(rule ballI)
          fix y assume [ty]: "y be objectHIDDENM1"
          have "y inHIDDENR3 Y1 iff ( ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & x inHIDDENR3 X)"
            using A4 sorry
          thus "y inHIDDENR3 Y1 iff y inHIDDENR3 Y2"
            using A5 sorry
        qed "sorry"
        thus "Y1 =HIDDENR1 Y2"
          using tarski_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem relat_1_th_110:
" for X be setHIDDENM2 holds  for y be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds y inHIDDENR3 R .:RELAT-1K10 X iff ( ex x be objectHIDDENM1 st (x inHIDDENR3 domRELAT-1K1 R & [TARSKIK4 x,y ] inHIDDENR3 R) & x inHIDDENR3 X)"
proof-
  have " for X be setHIDDENM2 holds  for y be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds (y inHIDDENR3 R .:RELAT-1K10 X implies ( ex x be objectHIDDENM1 st (x inHIDDENR3 domRELAT-1K1 R & [TARSKIK4 x,y ] inHIDDENR3 R) & x inHIDDENR3 X)) &  not ( not ( for x be objectHIDDENM1 holds  not ((x inHIDDENR3 domRELAT-1K1 R & [TARSKIK4 x,y ] inHIDDENR3 R) & x inHIDDENR3 X)) &  not y inHIDDENR3 R .:RELAT-1K10 X)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "y inHIDDENR3 R .:RELAT-1K10 X implies ( ex x be objectHIDDENM1 st (x inHIDDENR3 domRELAT-1K1 R & [TARSKIK4 x,y ] inHIDDENR3 R) & x inHIDDENR3 X)"
    proof-
      have "y inHIDDENR3 R .:RELAT-1K10 X implies ( ex tVar9 be objectHIDDENM1 st (tVar9 inHIDDENR3 domRELAT-1K1 R & [TARSKIK4 tVar9,y ] inHIDDENR3 R) & tVar9 inHIDDENR3 X)"
      proof(rule impI)
        assume "y inHIDDENR3 R .:RELAT-1K10 X"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A1: "[TARSKIK4 x,y ] inHIDDENR3 R & x inHIDDENR3 X"
          using relat_1_def_13 sorry
        show " ex tVar9 be objectHIDDENM1 st (tVar9 inHIDDENR3 domRELAT-1K1 R & [TARSKIK4 tVar9,y ] inHIDDENR3 R) & tVar9 inHIDDENR3 X"
        proof(rule bexI[of _ "x"])
          show "(x inHIDDENR3 domRELAT-1K1 R & [TARSKIK4 x,y ] inHIDDENR3 R) & x inHIDDENR3 X"
            using A1 xtuple_0_def_12 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    show " not ( not ( for x be objectHIDDENM1 holds  not ((x inHIDDENR3 domRELAT-1K1 R & [TARSKIK4 x,y ] inHIDDENR3 R) & x inHIDDENR3 X)) &  not y inHIDDENR3 R .:RELAT-1K10 X)"
      using relat_1_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_111:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R .:RELAT-1K10 X c=TARSKIR1 rngRELAT-1K2 R"
proof-
  have " for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R .:RELAT-1K10 X c=TARSKIR1 rngRELAT-1K2 R"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 R .:RELAT-1K10 X implies y inHIDDENR3 rngRELAT-1K2 R"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 R .:RELAT-1K10 X"
      then have " ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & x inHIDDENR3 X"
        using relat_1_def_13 sorry
      thus "y inHIDDENR3 rngRELAT-1K2 R"
        using xtuple_0_def_13 sorry
    qed "sorry"
    thus "R .:RELAT-1K10 X c=TARSKIR1 rngRELAT-1K2 R"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_112:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R .:RELAT-1K10 X =XBOOLE-0R4 R .:RELAT-1K10 (domRELAT-1K1 R /\\XBOOLE-0K3 X)"
proof-
  have " for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R .:RELAT-1K10 X =XBOOLE-0R4 R .:RELAT-1K10 (domRELAT-1K1 R /\\XBOOLE-0K3 X)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 R .:RELAT-1K10 X iff y inHIDDENR3 R .:RELAT-1K10 (domRELAT-1K1 R /\\XBOOLE-0K3 X)"
    proof-
      have " for y be objectHIDDENM1 holds (y inHIDDENR3 R .:RELAT-1K10 X implies y inHIDDENR3 R .:RELAT-1K10 (domRELAT-1K1 R /\\XBOOLE-0K3 X)) & (y inHIDDENR3 R .:RELAT-1K10 (domRELAT-1K1 R /\\XBOOLE-0K3 X) implies y inHIDDENR3 R .:RELAT-1K10 X)"
      proof(rule ballI,rule conjMI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        show "y inHIDDENR3 R .:RELAT-1K10 X implies y inHIDDENR3 R .:RELAT-1K10 (domRELAT-1K1 R /\\XBOOLE-0K3 X)"
        proof(rule impI)
          assume "y inHIDDENR3 R .:RELAT-1K10 X"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A1: "x inHIDDENR3 domRELAT-1K1 R"and A2: "[TARSKIK4 x,y ] inHIDDENR3 R"and A3: "x inHIDDENR3 X"
            using relat_1_th_110 sorry
          have "x inHIDDENR3 domRELAT-1K1 R /\\XBOOLE-0K3 X"
            using A1 A3 xboole_0_def_4 sorry
          thus "y inHIDDENR3 R .:RELAT-1K10 (domRELAT-1K1 R /\\XBOOLE-0K3 X)"
            using A2 relat_1_def_13 sorry
        qed
        assume "y inHIDDENR3 R .:RELAT-1K10 (domRELAT-1K1 R /\\XBOOLE-0K3 X)"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          "x inHIDDENR3 domRELAT-1K1 R"and A4: "[TARSKIK4 x,y ] inHIDDENR3 R"and A5: "x inHIDDENR3 domRELAT-1K1 R /\\XBOOLE-0K3 X"
          using relat_1_th_110 sorry
        have "x inHIDDENR3 X"
          using A5 xboole_0_def_4 sorry
        thus "y inHIDDENR3 R .:RELAT-1K10 X"
          using A4 relat_1_def_13 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "R .:RELAT-1K10 X =XBOOLE-0R4 R .:RELAT-1K10 (domRELAT-1K1 R /\\XBOOLE-0K3 X)"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_113:
" for R be RelationRELAT-1M1 holds R .:RELAT-1K10 domRELAT-1K1 R =XBOOLE-0R4 rngRELAT-1K2 R"
proof-
  have " for R be RelationRELAT-1M1 holds R .:RELAT-1K10 domRELAT-1K1 R =XBOOLE-0R4 rngRELAT-1K2 R"
  proof(rule ballI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have "R .:RELAT-1K10 domRELAT-1K1 R c=TARSKIR1 rngRELAT-1K2 R & rngRELAT-1K2 R c=TARSKIR1 R .:RELAT-1K10 domRELAT-1K1 R"
    proof(rule conjMI)
      show "R .:RELAT-1K10 domRELAT-1K1 R c=TARSKIR1 rngRELAT-1K2 R"
        using relat_1_th_111 sorry
      have " for y be objectHIDDENM1 holds y inHIDDENR3 rngRELAT-1K2 R implies y inHIDDENR3 R .:RELAT-1K10 domRELAT-1K1 R"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 rngRELAT-1K2 R"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A1: "[TARSKIK4 x,y ] inHIDDENR3 R"
          using xtuple_0_def_13 sorry
        have "x inHIDDENR3 domRELAT-1K1 R"
          using A1 xtuple_0_def_12 sorry
        thus "y inHIDDENR3 R .:RELAT-1K10 domRELAT-1K1 R"
          using A1 relat_1_def_13 sorry
      qed "sorry"
      thus "rngRELAT-1K2 R c=TARSKIR1 R .:RELAT-1K10 domRELAT-1K1 R"
        using tarski_def_3 sorry
    qed
    thus "R .:RELAT-1K10 domRELAT-1K1 R =XBOOLE-0R4 rngRELAT-1K2 R"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_114:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R .:RELAT-1K10 X c=TARSKIR1 R .:RELAT-1K10 domRELAT-1K1 R"
proof-
  have " for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R .:RELAT-1K10 X c=TARSKIR1 R .:RELAT-1K10 domRELAT-1K1 R"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have "R .:RELAT-1K10 X c=TARSKIR1 rngRELAT-1K2 R"
      using relat_1_th_111 sorry
    thus "R .:RELAT-1K10 X c=TARSKIR1 R .:RELAT-1K10 domRELAT-1K1 R"
      using relat_1_th_113 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_115:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds rngRELAT-1K2 (R  |RELAT-1K8 X) =XBOOLE-0R4 R .:RELAT-1K10 X"
proof-
  have " for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds rngRELAT-1K2 (R  |RELAT-1K8 X) =XBOOLE-0R4 R .:RELAT-1K10 X"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 rngRELAT-1K2 (R  |RELAT-1K8 X) iff y inHIDDENR3 R .:RELAT-1K10 X"
    proof-
      have " for y be objectHIDDENM1 holds (y inHIDDENR3 rngRELAT-1K2 (R  |RELAT-1K8 X) implies y inHIDDENR3 R .:RELAT-1K10 X) & (y inHIDDENR3 R .:RELAT-1K10 X implies y inHIDDENR3 rngRELAT-1K2 (R  |RELAT-1K8 X))"
      proof(rule ballI,rule conjMI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        show "y inHIDDENR3 rngRELAT-1K2 (R  |RELAT-1K8 X) implies y inHIDDENR3 R .:RELAT-1K10 X"
        proof(rule impI)
          assume "y inHIDDENR3 rngRELAT-1K2 (R  |RELAT-1K8 X)"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A1: "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X"
            using xtuple_0_def_13 sorry
          have "x inHIDDENR3 X & [TARSKIK4 x,y ] inHIDDENR3 R"
            using A1 relat_1_def_11 sorry
          thus "y inHIDDENR3 R .:RELAT-1K10 X"
            using relat_1_def_13 sorry
        qed
        assume "y inHIDDENR3 R .:RELAT-1K10 X"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A2: "[TARSKIK4 x,y ] inHIDDENR3 R & x inHIDDENR3 X"
          using relat_1_def_13 sorry
        have "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X"
          using A2 relat_1_def_11 sorry
        thus "y inHIDDENR3 rngRELAT-1K2 (R  |RELAT-1K8 X)"
          using xtuple_0_def_13 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "rngRELAT-1K2 (R  |RELAT-1K8 X) =XBOOLE-0R4 R .:RELAT-1K10 X"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_cl_23:
  mlet "R be RelationRELAT-1M1", "X be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster R .:RELAT-1K10 X as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "R .:RELAT-1K10 X be emptyXBOOLE-0V1"
  proof-
    let ?y = "the ElementSUBSET-1M1-of R .:RELAT-1K10 {}XBOOLE-0K1"
    have "?y inTARSKIR2 R .:RELAT-1K10 {}XBOOLE-0K1 implies ( ex x be objectHIDDENM1 st [TARSKIK4 x,?y ] inHIDDENR3 R & x inHIDDENR3 {}XBOOLE-0K1)"
      using relat_1_def_13 sorry
    thus "R .:RELAT-1K10 X be emptyXBOOLE-0V1"
       sorry
  qed
qed "sorry"

mtheorem relat_1_cl_24:
  mlet "R be emptyXBOOLE-0V1\<bar>RelationRELAT-1M1", "X be setHIDDENM2"
"cluster R .:RELAT-1K10 X as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "R .:RELAT-1K10 X be emptyXBOOLE-0V1"
  proof-
    have " not R .:RELAT-1K10 X be emptyXBOOLE-0V1 implies  False "
    proof(rule impI)
      assume " not R .:RELAT-1K10 X be emptyXBOOLE-0V1"
      then have " ex x be objectHIDDENM1 st [TARSKIK4 x,the ElementSUBSET-1M1-of {}XBOOLE-0K1 .:RELAT-1K10 X ] inHIDDENR3 {}XBOOLE-0K1 & x inHIDDENR3 X"
        using relat_1_def_13 sorry
      thus " False "
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

(*\$CT 2*)
mtheorem relat_1_th_118:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R .:RELAT-1K10 X =XBOOLE-0R4 {}XBOOLE-0K1 iff domRELAT-1K1 R missesXBOOLE-0R1 X"
proof-
  have " for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds (R .:RELAT-1K10 X =XBOOLE-0R4 {}XBOOLE-0K1 implies domRELAT-1K1 R missesXBOOLE-0R1 X) &  not (domRELAT-1K1 R missesXBOOLE-0R1 X &  not R .:RELAT-1K10 X =XBOOLE-0R4 {}XBOOLE-0K1)"
  proof(rule ballI,rule ballI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    let ?y = "the ElementSUBSET-1M1-of R .:RELAT-1K10 X"
    show "R .:RELAT-1K10 X =XBOOLE-0R4 {}XBOOLE-0K1 implies domRELAT-1K1 R missesXBOOLE-0R1 X"
    proof-
      have "R .:RELAT-1K10 X =XBOOLE-0R4 {}XBOOLE-0K1 implies ( not domRELAT-1K1 R missesXBOOLE-0R1 X implies  False )"
      proof(rule impI,rule impI)
        assume A1: "R .:RELAT-1K10 X =XBOOLE-0R4 {}XBOOLE-0K1"
        assume " not domRELAT-1K1 R missesXBOOLE-0R1 X"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A2: "x inHIDDENR3 domRELAT-1K1 R"and A3: "x inHIDDENR3 X"
          using xboole_0_th_3 sorry
        have " ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R"
          using A2 xtuple_0_def_12 sorry
        thus " False "
          using A1 A2 A3 relat_1_th_110 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "domRELAT-1K1 R /\\XBOOLE-0K3 X =XBOOLE-0R4 {}XBOOLE-0K1 implies ( not R .:RELAT-1K10 X =XBOOLE-0R4 {}XBOOLE-0K1 implies  False )"
    proof(rule impI,rule impI)
      assume A4: "domRELAT-1K1 R /\\XBOOLE-0K3 X =XBOOLE-0R4 {}XBOOLE-0K1"
      assume " not R .:RELAT-1K10 X =XBOOLE-0R4 {}XBOOLE-0K1"
      then have " ex x be objectHIDDENM1 st (x inHIDDENR3 domRELAT-1K1 R & [TARSKIK4 x,?y ] inHIDDENR3 R) & x inHIDDENR3 X"
        using relat_1_th_110 sorry
      thus " False "
        using A4 xboole_0_def_4 sorry
    qed
    thus " not (domRELAT-1K1 R missesXBOOLE-0R1 X &  not R .:RELAT-1K10 X =XBOOLE-0R4 {}XBOOLE-0K1)"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_119:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds X <>HIDDENR2 {}XBOOLE-0K1 & X c=TARSKIR1 domRELAT-1K1 R implies R .:RELAT-1K10 X <>HIDDENR2 {}XBOOLE-0K1"
proof-
  have " for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds X <>HIDDENR2 {}XBOOLE-0K1 & X c=TARSKIR1 domRELAT-1K1 R implies  not R .:RELAT-1K10 X <>HIDDENR2 {}XBOOLE-0K1"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume A1: "X <>HIDDENR2 {}XBOOLE-0K1"
      and A2: "X c=TARSKIR1 domRELAT-1K1 R"
    let ?x = "the ElementSUBSET-1M1-of X"
    have A3: "?x inTARSKIR2 domRELAT-1K1 R"
      using A1 A2 sorry
    then have " ex y be objectHIDDENM1 st [TARSKIK4 ?x,y ] inHIDDENR3 R"
      using xtuple_0_def_12 sorry
    thus " not R .:RELAT-1K10 X <>HIDDENR2 {}XBOOLE-0K1"
      using A1 A3 relat_1_th_110 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_120:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R .:RELAT-1K10 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 R .:RELAT-1K10 X \\/XBOOLE-0K2 R .:RELAT-1K10 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R .:RELAT-1K10 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 R .:RELAT-1K10 X \\/XBOOLE-0K2 R .:RELAT-1K10 Y"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have "R .:RELAT-1K10 (X \\/XBOOLE-0K2 Y) c=TARSKIR1 R .:RELAT-1K10 X \\/XBOOLE-0K2 R .:RELAT-1K10 Y & R .:RELAT-1K10 X \\/XBOOLE-0K2 R .:RELAT-1K10 Y c=TARSKIR1 R .:RELAT-1K10 (X \\/XBOOLE-0K2 Y)"
    proof(rule conjMI)
      show "R .:RELAT-1K10 (X \\/XBOOLE-0K2 Y) c=TARSKIR1 R .:RELAT-1K10 X \\/XBOOLE-0K2 R .:RELAT-1K10 Y"
      proof-
        have " for y be objectHIDDENM1 holds y inHIDDENR3 R .:RELAT-1K10 (X \\/XBOOLE-0K2 Y) implies y inHIDDENR3 R .:RELAT-1K10 X \\/XBOOLE-0K2 R .:RELAT-1K10 Y"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "y inHIDDENR3 R .:RELAT-1K10 (X \\/XBOOLE-0K2 Y)"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A1: "[TARSKIK4 x,y ] inHIDDENR3 R"and A2: "x inHIDDENR3 X \\/XBOOLE-0K2 Y"
            using relat_1_def_13 sorry
          have "x inHIDDENR3 X or x inHIDDENR3 Y"
            using A2 xboole_0_def_3 sorry
          then have "y inHIDDENR3 R .:RELAT-1K10 X or y inHIDDENR3 R .:RELAT-1K10 Y"
            using A1 relat_1_def_13 sorry
          thus "y inHIDDENR3 R .:RELAT-1K10 X \\/XBOOLE-0K2 R .:RELAT-1K10 Y"
            using xboole_0_def_3 sorry
        qed "sorry"
        thus "R .:RELAT-1K10 (X \\/XBOOLE-0K2 Y) c=TARSKIR1 R .:RELAT-1K10 X \\/XBOOLE-0K2 R .:RELAT-1K10 Y"
          using tarski_def_3 sorry
      qed
      have " for y be objectHIDDENM1 holds y inHIDDENR3 R .:RELAT-1K10 X \\/XBOOLE-0K2 R .:RELAT-1K10 Y implies y inHIDDENR3 R .:RELAT-1K10 (X \\/XBOOLE-0K2 Y)"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A3: "y inHIDDENR3 R .:RELAT-1K10 X \\/XBOOLE-0K2 R .:RELAT-1K10 Y"
        show "y inHIDDENR3 R .:RELAT-1K10 (X \\/XBOOLE-0K2 Y)"
        proof-
          have cases: "y inHIDDENR3 R .:RELAT-1K10 Y or y inHIDDENR3 R .:RELAT-1K10 X"
            using A3 xboole_0_def_3 sorry
          have case1: "y inHIDDENR3 R .:RELAT-1K10 Y implies y inHIDDENR3 R .:RELAT-1K10 (X \\/XBOOLE-0K2 Y)"
          proof(rule impI)
            assume "y inHIDDENR3 R .:RELAT-1K10 Y"
            then obtain x where
              [ty]:"x be objectHIDDENM1" and 
              A4: "[TARSKIK4 x,y ] inHIDDENR3 R"and A5: "x inHIDDENR3 Y"
              using relat_1_def_13 sorry
            have "x inHIDDENR3 X \\/XBOOLE-0K2 Y"
              using A5 xboole_0_def_3 sorry
            thus "y inHIDDENR3 R .:RELAT-1K10 (X \\/XBOOLE-0K2 Y)"
              using A4 relat_1_def_13 sorry
          qed
          have case2: "y inHIDDENR3 R .:RELAT-1K10 X implies y inHIDDENR3 R .:RELAT-1K10 (X \\/XBOOLE-0K2 Y)"
          proof(rule impI)
            assume "y inHIDDENR3 R .:RELAT-1K10 X"
            then obtain x where
              [ty]:"x be objectHIDDENM1" and 
              A6: "[TARSKIK4 x,y ] inHIDDENR3 R"and A7: "x inHIDDENR3 X"
              using relat_1_def_13 sorry
            have "x inHIDDENR3 X \\/XBOOLE-0K2 Y"
              using A7 xboole_0_def_3 sorry
            thus "y inHIDDENR3 R .:RELAT-1K10 (X \\/XBOOLE-0K2 Y)"
              using A6 relat_1_def_13 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus "R .:RELAT-1K10 X \\/XBOOLE-0K2 R .:RELAT-1K10 Y c=TARSKIR1 R .:RELAT-1K10 (X \\/XBOOLE-0K2 Y)"
        using tarski_def_3 sorry
    qed
    thus "R .:RELAT-1K10 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 R .:RELAT-1K10 X \\/XBOOLE-0K2 R .:RELAT-1K10 Y"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_121:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R .:RELAT-1K10 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 R .:RELAT-1K10 X /\\XBOOLE-0K3 R .:RELAT-1K10 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R .:RELAT-1K10 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 R .:RELAT-1K10 X /\\XBOOLE-0K3 R .:RELAT-1K10 Y"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 R .:RELAT-1K10 (X /\\XBOOLE-0K3 Y) implies y inHIDDENR3 R .:RELAT-1K10 X /\\XBOOLE-0K3 R .:RELAT-1K10 Y"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 R .:RELAT-1K10 (X /\\XBOOLE-0K3 Y)"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A1: "[TARSKIK4 x,y ] inHIDDENR3 R"and A2: "x inHIDDENR3 X /\\XBOOLE-0K3 Y"
        using relat_1_def_13 sorry
      have "x inHIDDENR3 Y"
        using A2 xboole_0_def_4 sorry
      then have A3: "y inHIDDENR3 R .:RELAT-1K10 Y"
        using A1 relat_1_def_13 sorry
      have "x inHIDDENR3 X"
        using A2 xboole_0_def_4 sorry
      then have "y inHIDDENR3 R .:RELAT-1K10 X"
        using A1 relat_1_def_13 sorry
      thus "y inHIDDENR3 R .:RELAT-1K10 X /\\XBOOLE-0K3 R .:RELAT-1K10 Y"
        using A3 xboole_0_def_4 sorry
    qed "sorry"
    thus "R .:RELAT-1K10 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 R .:RELAT-1K10 X /\\XBOOLE-0K3 R .:RELAT-1K10 Y"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_122:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R .:RELAT-1K10 X \\SUBSET-1K6 R .:RELAT-1K10 Y c=TARSKIR1 R .:RELAT-1K10 (X \\SUBSET-1K6 Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R .:RELAT-1K10 X \\SUBSET-1K6 R .:RELAT-1K10 Y c=TARSKIR1 R .:RELAT-1K10 (X \\SUBSET-1K6 Y)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 R .:RELAT-1K10 X \\SUBSET-1K6 R .:RELAT-1K10 Y implies y inHIDDENR3 R .:RELAT-1K10 (X \\SUBSET-1K6 Y)"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A1: "y inHIDDENR3 R .:RELAT-1K10 X \\SUBSET-1K6 R .:RELAT-1K10 Y"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A2: "[TARSKIK4 x,y ] inHIDDENR3 R"and A3: "x inHIDDENR3 X"
        using relat_1_def_13 sorry
      have " not y inHIDDENR3 R .:RELAT-1K10 Y"
        using A1 xboole_0_def_5 sorry
      then have " not x inHIDDENR3 Y or  not [TARSKIK4 x,y ] inHIDDENR3 R"
        using relat_1_def_13 sorry
      then have "x inHIDDENR3 X \\SUBSET-1K6 Y"
        using A2 A3 xboole_0_def_5 sorry
      thus "y inHIDDENR3 R .:RELAT-1K10 (X \\SUBSET-1K6 Y)"
        using A2 relat_1_def_13 sorry
    qed "sorry"
    thus "R .:RELAT-1K10 X \\SUBSET-1K6 R .:RELAT-1K10 Y c=TARSKIR1 R .:RELAT-1K10 (X \\SUBSET-1K6 Y)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_123:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds X c=TARSKIR1 Y implies R .:RELAT-1K10 X c=TARSKIR1 R .:RELAT-1K10 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds X c=TARSKIR1 Y implies R .:RELAT-1K10 X c=TARSKIR1 R .:RELAT-1K10 Y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume A1: "X c=TARSKIR1 Y"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 R .:RELAT-1K10 X implies y inHIDDENR3 R .:RELAT-1K10 Y"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 R .:RELAT-1K10 X"
      then have " ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & x inHIDDENR3 X"
        using relat_1_def_13 sorry
      thus "y inHIDDENR3 R .:RELAT-1K10 Y"
        using A1 relat_1_def_13 sorry
    qed "sorry"
    thus "R .:RELAT-1K10 X c=TARSKIR1 R .:RELAT-1K10 Y"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_124:
" for X be setHIDDENM2 holds  for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds P c=RELAT-1R2 R implies P .:RELAT-1K10 X c=TARSKIR1 R .:RELAT-1K10 X"
proof-
  have " for X be setHIDDENM2 holds  for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds P c=RELAT-1R2 R implies P .:RELAT-1K10 X c=TARSKIR1 R .:RELAT-1K10 X"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix P assume [ty]: "P be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume A1: "P c=RELAT-1R2 R"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 P .:RELAT-1K10 X implies y inHIDDENR3 R .:RELAT-1K10 X"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 P .:RELAT-1K10 X"
      then have " ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 P & x inHIDDENR3 X"
        using relat_1_def_13 sorry
      thus "y inHIDDENR3 R .:RELAT-1K10 X"
        using A1 relat_1_def_13 sorry
    qed "sorry"
    thus "P .:RELAT-1K10 X c=TARSKIR1 R .:RELAT-1K10 X"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_125:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds P c=RELAT-1R2 R & X c=TARSKIR1 Y implies P .:RELAT-1K10 X c=TARSKIR1 R .:RELAT-1K10 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds P c=RELAT-1R2 R & X c=TARSKIR1 Y implies P .:RELAT-1K10 X c=TARSKIR1 R .:RELAT-1K10 Y"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix P assume [ty]: "P be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume "P c=RELAT-1R2 R & X c=TARSKIR1 Y"
    then have "P .:RELAT-1K10 X c=TARSKIR1 R .:RELAT-1K10 X & R .:RELAT-1K10 X c=TARSKIR1 R .:RELAT-1K10 Y"
      using relat_1_th_123 relat_1_th_124 sorry
    thus "P .:RELAT-1K10 X c=TARSKIR1 R .:RELAT-1K10 Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_126:
" for X be setHIDDENM2 holds  for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds (P *RELAT-1K6 R).:RELAT-1K10 X =XBOOLE-0R4 R .:RELAT-1K10 (P .:RELAT-1K10 X)"
proof-
  have " for X be setHIDDENM2 holds  for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds (P *RELAT-1K6 R).:RELAT-1K10 X =XBOOLE-0R4 R .:RELAT-1K10 (P .:RELAT-1K10 X)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix P assume [ty]: "P be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 (P *RELAT-1K6 R).:RELAT-1K10 X iff y inHIDDENR3 R .:RELAT-1K10 (P .:RELAT-1K10 X)"
    proof-
      have " for y be objectHIDDENM1 holds (y inHIDDENR3 (P *RELAT-1K6 R).:RELAT-1K10 X implies y inHIDDENR3 R .:RELAT-1K10 (P .:RELAT-1K10 X)) & (y inHIDDENR3 R .:RELAT-1K10 (P .:RELAT-1K10 X) implies y inHIDDENR3 (P *RELAT-1K6 R).:RELAT-1K10 X)"
      proof(rule ballI,rule conjMI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        show "y inHIDDENR3 (P *RELAT-1K6 R).:RELAT-1K10 X implies y inHIDDENR3 R .:RELAT-1K10 (P .:RELAT-1K10 X)"
        proof(rule impI)
          assume "y inHIDDENR3 (P *RELAT-1K6 R).:RELAT-1K10 X"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A1: "[TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 R"and A2: "x inHIDDENR3 X"
            using relat_1_def_13 sorry
          obtain z where
            [ty]:"z be objectHIDDENM1" and 
            A3: "[TARSKIK4 x,z ] inHIDDENR3 P"and A4: "[TARSKIK4 z,y ] inHIDDENR3 R"
            using A1 relat_1_def_8 sorry
          have "z inHIDDENR3 P .:RELAT-1K10 X"
            using A2 A3 relat_1_def_13 sorry
          thus "y inHIDDENR3 R .:RELAT-1K10 (P .:RELAT-1K10 X)"
            using A4 relat_1_def_13 sorry
        qed
        assume "y inHIDDENR3 R .:RELAT-1K10 (P .:RELAT-1K10 X)"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A5: "[TARSKIK4 x,y ] inHIDDENR3 R"and A6: "x inHIDDENR3 P .:RELAT-1K10 X"
          using relat_1_def_13 sorry
        obtain z where
          [ty]:"z be objectHIDDENM1" and 
          A7: "[TARSKIK4 z,x ] inHIDDENR3 P"and A8: "z inHIDDENR3 X"
          using A6 relat_1_def_13 sorry
        have "[TARSKIK4 z,y ] inHIDDENR3 P *RELAT-1K6 R"
          using A5 A7 relat_1_def_8 sorry
        thus "y inHIDDENR3 (P *RELAT-1K6 R).:RELAT-1K10 X"
          using A8 relat_1_def_13 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "(P *RELAT-1K6 R).:RELAT-1K10 X =XBOOLE-0R4 R .:RELAT-1K10 (P .:RELAT-1K10 X)"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_127:
" for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds rngRELAT-1K2 (P *RELAT-1K6 R) =XBOOLE-0R4 R .:RELAT-1K10 rngRELAT-1K2 P"
proof-
  have " for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds rngRELAT-1K2 (P *RELAT-1K6 R) =XBOOLE-0R4 R .:RELAT-1K10 rngRELAT-1K2 P"
  proof(rule ballI,rule ballI)
    fix P assume [ty]: "P be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for z be objectHIDDENM1 holds z inHIDDENR3 rngRELAT-1K2 (P *RELAT-1K6 R) iff z inHIDDENR3 R .:RELAT-1K10 rngRELAT-1K2 P"
    proof-
      have " for z be objectHIDDENM1 holds (z inHIDDENR3 rngRELAT-1K2 (P *RELAT-1K6 R) implies z inHIDDENR3 R .:RELAT-1K10 rngRELAT-1K2 P) & (z inHIDDENR3 R .:RELAT-1K10 rngRELAT-1K2 P implies z inHIDDENR3 rngRELAT-1K2 (P *RELAT-1K6 R))"
      proof(rule ballI,rule conjMI,rule impI)
        fix z assume [ty]: "z be objectHIDDENM1"
        show "z inHIDDENR3 rngRELAT-1K2 (P *RELAT-1K6 R) implies z inHIDDENR3 R .:RELAT-1K10 rngRELAT-1K2 P"
        proof(rule impI)
          assume "z inHIDDENR3 rngRELAT-1K2 (P *RELAT-1K6 R)"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A1: "[TARSKIK4 x,z ] inHIDDENR3 P *RELAT-1K6 R"
            using xtuple_0_def_13 sorry
          obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A2: "[TARSKIK4 x,y ] inHIDDENR3 P"and A3: "[TARSKIK4 y,z ] inHIDDENR3 R"
            using A1 relat_1_def_8 sorry
          have "y inHIDDENR3 rngRELAT-1K2 P"
            using A2 xtuple_0_def_13 sorry
          thus "z inHIDDENR3 R .:RELAT-1K10 rngRELAT-1K2 P"
            using A3 relat_1_def_13 sorry
        qed
        assume "z inHIDDENR3 R .:RELAT-1K10 rngRELAT-1K2 P"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A4: "[TARSKIK4 y,z ] inHIDDENR3 R"and A5: "y inHIDDENR3 rngRELAT-1K2 P"
          using relat_1_def_13 sorry
        obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A6: "[TARSKIK4 x,y ] inHIDDENR3 P"
          using A5 xtuple_0_def_13 sorry
        have "[TARSKIK4 x,z ] inHIDDENR3 P *RELAT-1K6 R"
          using A4 A6 relat_1_def_8 sorry
        thus "z inHIDDENR3 rngRELAT-1K2 (P *RELAT-1K6 R)"
          using xtuple_0_def_13 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "rngRELAT-1K2 (P *RELAT-1K6 R) =XBOOLE-0R4 R .:RELAT-1K10 rngRELAT-1K2 P"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_128:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds (R  |RELAT-1K8 X).:RELAT-1K10 Y c=TARSKIR1 R .:RELAT-1K10 Y"
  using relat_1_th_59 relat_1_th_124 sorry

mtheorem relat_1_th_129:
" for R be RelationRELAT-1M1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies (R  |RELAT-1K8 Y).:RELAT-1K10 X =XBOOLE-0R4 R .:RELAT-1K10 X"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix R assume [ty]: "R be RelationRELAT-1M1"
  fix X assume [ty]: "X be setHIDDENM2"
  fix Y assume [ty]: "Y be setHIDDENM2"
  assume A1: "X c=TARSKIR1 Y"
  have "(R  |RELAT-1K8 Y).:RELAT-1K10 X c=TARSKIR1 R .:RELAT-1K10 X & R .:RELAT-1K10 X c=TARSKIR1 (R  |RELAT-1K8 Y).:RELAT-1K10 X"
  proof(rule conjMI)
    show "(R  |RELAT-1K8 Y).:RELAT-1K10 X c=TARSKIR1 R .:RELAT-1K10 X"
      using relat_1_th_59 relat_1_th_124 sorry
    have " for y be objectHIDDENM1 holds y inHIDDENR3 R .:RELAT-1K10 X implies y inHIDDENR3 (R  |RELAT-1K8 Y).:RELAT-1K10 X"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 R .:RELAT-1K10 X"
      then obtain x1 where
        [ty]:"x1 be objectHIDDENM1" and 
        A2: "[TARSKIK4 x1,y ] inHIDDENR3 R"and A3: "x1 inHIDDENR3 X"
        using relat_1_def_13 sorry
      have " ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 Y & x inHIDDENR3 X"
      proof-
        have " ex tVar10 be objectHIDDENM1 st [TARSKIK4 tVar10,y ] inHIDDENR3 R  |RELAT-1K8 Y & tVar10 inHIDDENR3 X"
        proof-
          show " ex tVar10 be objectHIDDENM1 st [TARSKIK4 tVar10,y ] inHIDDENR3 R  |RELAT-1K8 Y & tVar10 inHIDDENR3 X"
          proof(rule bexI[of _ "x1"],rule conjMI)
            show "[TARSKIK4 x1,y ] inHIDDENR3 R  |RELAT-1K8 Y"
              using A1 A2 A3 relat_1_def_11 sorry
            show "x1 inHIDDENR3 X"
              using A3 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
      thus "y inHIDDENR3 (R  |RELAT-1K8 Y).:RELAT-1K10 X"
        using relat_1_def_13 sorry
    qed "sorry"
    thus "R .:RELAT-1K10 X c=TARSKIR1 (R  |RELAT-1K8 Y).:RELAT-1K10 X"
      using tarski_def_3 sorry
  qed
  thus "(R  |RELAT-1K8 Y).:RELAT-1K10 X =XBOOLE-0R4 R .:RELAT-1K10 X"
    using xboole_0_def_10 sorry
qed "sorry"

mtheorem relat_1_th_130:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds domRELAT-1K1 R /\\XBOOLE-0K3 X c=TARSKIR1 R ~RELAT-1K4 .:RELAT-1K10 (R .:RELAT-1K10 X)"
proof-
  have " for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds domRELAT-1K1 R /\\XBOOLE-0K3 X c=TARSKIR1 R ~RELAT-1K4 .:RELAT-1K10 (R .:RELAT-1K10 X)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 R /\\XBOOLE-0K3 X implies x inHIDDENR3 R ~RELAT-1K4 .:RELAT-1K10 (R .:RELAT-1K10 X)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A1: "x inHIDDENR3 domRELAT-1K1 R /\\XBOOLE-0K3 X"
      then have "x inHIDDENR3 domRELAT-1K1 R"
        using xboole_0_def_4 sorry
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A2: "[TARSKIK4 x,y ] inHIDDENR3 R"
        using xtuple_0_def_12 sorry
      have A3: "[TARSKIK4 y,x ] inHIDDENR3 R ~RELAT-1K4"
        using A2 relat_1_def_7 sorry
      have "x inHIDDENR3 X"
        using A1 xboole_0_def_4 sorry
      then have "y inHIDDENR3 R .:RELAT-1K10 X"
        using A2 relat_1_def_13 sorry
      thus "x inHIDDENR3 R ~RELAT-1K4 .:RELAT-1K10 (R .:RELAT-1K10 X)"
        using A3 relat_1_def_13 sorry
    qed "sorry"
    thus "domRELAT-1K1 R /\\XBOOLE-0K3 X c=TARSKIR1 R ~RELAT-1K4 .:RELAT-1K10 (R .:RELAT-1K10 X)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef relat_1_def_14 (" _ \<inverse>RELAT-1K11  _ " [228,228]228 ) where
  mlet "R be RelationRELAT-1M1", "Y be setHIDDENM2"
"func R \<inverse>RELAT-1K11 Y \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & y inHIDDENR3 Y)"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & y inHIDDENR3 Y)"
    proof-
      have " ex tVar11 be setHIDDENM2 st  for x be objectHIDDENM1 holds (x inHIDDENR3 tVar11 implies ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & y inHIDDENR3 Y)) & (( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & y inHIDDENR3 Y) implies x inHIDDENR3 tVar11)"
      proof-
        let ?Z = "\<lambda>Lamb1.  ex y be objectHIDDENM1 st [TARSKIK4 Lamb1,y ] inHIDDENR3 R & y inHIDDENR3 Y"
        obtain X where
          [ty]:"X be setHIDDENM2" and 
          A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X iff x inHIDDENR3 domRELAT-1K1 R & ?Z(x)"
          using xboole_0_sch_1 sorry
        show " ex tVar11 be setHIDDENM2 st  for x be objectHIDDENM1 holds (x inHIDDENR3 tVar11 implies ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & y inHIDDENR3 Y)) & (( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & y inHIDDENR3 Y) implies x inHIDDENR3 tVar11)"
        proof(rule bexI[of _ "X"],rule ballI,rule conjMI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          show "x inHIDDENR3 X implies ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & y inHIDDENR3 Y)"
            using A1 sorry
          assume Given: " ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & y inHIDDENR3 Y"
          then obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A2: "[TARSKIK4 x,y ] inHIDDENR3 R"and A3: "y inHIDDENR3 Y"
             sorry
          have "x inHIDDENR3 domRELAT-1K1 R"
            using A2 xtuple_0_def_12 sorry
          thus "x inHIDDENR3 X"
            using A1 A2 A3 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & y inHIDDENR3 Y)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & y inHIDDENR3 Y)) implies it1 =HIDDENR1 it2"
    proof-
      have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 X1 iff ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & y inHIDDENR3 Y)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 X2 iff ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & y inHIDDENR3 Y)) implies X1 =HIDDENR1 X2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix X1 assume [ty]: "X1 be setHIDDENM2"
        fix X2 assume [ty]: "X2 be setHIDDENM2"
        assume A4: " for x be objectHIDDENM1 holds x inHIDDENR3 X1 iff ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & y inHIDDENR3 Y)"
          and A5: " for x be objectHIDDENM1 holds x inHIDDENR3 X2 iff ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & y inHIDDENR3 Y)"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 X1 iff x inHIDDENR3 X2"
        proof(rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          have "x inHIDDENR3 X1 iff ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & y inHIDDENR3 Y)"
            using A4 sorry
          thus "x inHIDDENR3 X1 iff x inHIDDENR3 X2"
            using A5 sorry
        qed "sorry"
        thus "X1 =HIDDENR1 X2"
          using tarski_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem relat_1_th_131:
" for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds x inHIDDENR3 R \<inverse>RELAT-1K11 Y iff ( ex y be objectHIDDENM1 st (y inHIDDENR3 rngRELAT-1K2 R & [TARSKIK4 x,y ] inHIDDENR3 R) & y inHIDDENR3 Y)"
proof-
  have " for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds (x inHIDDENR3 R \<inverse>RELAT-1K11 Y implies ( ex y be objectHIDDENM1 st (y inHIDDENR3 rngRELAT-1K2 R & [TARSKIK4 x,y ] inHIDDENR3 R) & y inHIDDENR3 Y)) &  not ( not ( for y be objectHIDDENM1 holds  not ((y inHIDDENR3 rngRELAT-1K2 R & [TARSKIK4 x,y ] inHIDDENR3 R) & y inHIDDENR3 Y)) &  not x inHIDDENR3 R \<inverse>RELAT-1K11 Y)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "x inHIDDENR3 R \<inverse>RELAT-1K11 Y implies ( ex y be objectHIDDENM1 st (y inHIDDENR3 rngRELAT-1K2 R & [TARSKIK4 x,y ] inHIDDENR3 R) & y inHIDDENR3 Y)"
    proof-
      have "x inHIDDENR3 R \<inverse>RELAT-1K11 Y implies ( ex tVar12 be objectHIDDENM1 st (tVar12 inHIDDENR3 rngRELAT-1K2 R & [TARSKIK4 x,tVar12 ] inHIDDENR3 R) & tVar12 inHIDDENR3 Y)"
      proof(rule impI)
        assume "x inHIDDENR3 R \<inverse>RELAT-1K11 Y"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A1: "[TARSKIK4 x,y ] inHIDDENR3 R & y inHIDDENR3 Y"
          using relat_1_def_14 sorry
        show " ex tVar12 be objectHIDDENM1 st (tVar12 inHIDDENR3 rngRELAT-1K2 R & [TARSKIK4 x,tVar12 ] inHIDDENR3 R) & tVar12 inHIDDENR3 Y"
        proof(rule bexI[of _ "y"])
          show "(y inHIDDENR3 rngRELAT-1K2 R & [TARSKIK4 x,y ] inHIDDENR3 R) & y inHIDDENR3 Y"
            using A1 xtuple_0_def_13 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    show " not ( not ( for y be objectHIDDENM1 holds  not ((y inHIDDENR3 rngRELAT-1K2 R & [TARSKIK4 x,y ] inHIDDENR3 R) & y inHIDDENR3 Y)) &  not x inHIDDENR3 R \<inverse>RELAT-1K11 Y)"
      using relat_1_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_132:
" for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R \<inverse>RELAT-1K11 Y c=TARSKIR1 domRELAT-1K1 R"
proof-
  have " for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R \<inverse>RELAT-1K11 Y c=TARSKIR1 domRELAT-1K1 R"
  proof(rule ballI,rule ballI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 R \<inverse>RELAT-1K11 Y implies x inHIDDENR3 domRELAT-1K1 R"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 R \<inverse>RELAT-1K11 Y"
      then have " ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & y inHIDDENR3 Y"
        using relat_1_def_14 sorry
      thus "x inHIDDENR3 domRELAT-1K1 R"
        using xtuple_0_def_12 sorry
    qed "sorry"
    thus "R \<inverse>RELAT-1K11 Y c=TARSKIR1 domRELAT-1K1 R"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_133:
" for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R \<inverse>RELAT-1K11 Y =XBOOLE-0R4 R \<inverse>RELAT-1K11 (rngRELAT-1K2 R /\\XBOOLE-0K3 Y)"
proof-
  have " for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R \<inverse>RELAT-1K11 Y =XBOOLE-0R4 R \<inverse>RELAT-1K11 (rngRELAT-1K2 R /\\XBOOLE-0K3 Y)"
  proof(rule ballI,rule ballI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 R \<inverse>RELAT-1K11 Y iff x inHIDDENR3 R \<inverse>RELAT-1K11 (rngRELAT-1K2 R /\\XBOOLE-0K3 Y)"
    proof-
      have " for x be objectHIDDENM1 holds (x inHIDDENR3 R \<inverse>RELAT-1K11 Y implies x inHIDDENR3 R \<inverse>RELAT-1K11 (rngRELAT-1K2 R /\\XBOOLE-0K3 Y)) & (x inHIDDENR3 R \<inverse>RELAT-1K11 (rngRELAT-1K2 R /\\XBOOLE-0K3 Y) implies x inHIDDENR3 R \<inverse>RELAT-1K11 Y)"
      proof(rule ballI,rule conjMI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        show "x inHIDDENR3 R \<inverse>RELAT-1K11 Y implies x inHIDDENR3 R \<inverse>RELAT-1K11 (rngRELAT-1K2 R /\\XBOOLE-0K3 Y)"
        proof(rule impI)
          assume "x inHIDDENR3 R \<inverse>RELAT-1K11 Y"
          then obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A1: "y inHIDDENR3 rngRELAT-1K2 R"and A2: "[TARSKIK4 x,y ] inHIDDENR3 R"and A3: "y inHIDDENR3 Y"
            using relat_1_th_131 sorry
          have "y inHIDDENR3 rngRELAT-1K2 R /\\XBOOLE-0K3 Y"
            using A1 A3 xboole_0_def_4 sorry
          thus "x inHIDDENR3 R \<inverse>RELAT-1K11 (rngRELAT-1K2 R /\\XBOOLE-0K3 Y)"
            using A2 relat_1_def_14 sorry
        qed
        assume "x inHIDDENR3 R \<inverse>RELAT-1K11 (rngRELAT-1K2 R /\\XBOOLE-0K3 Y)"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          "y inHIDDENR3 rngRELAT-1K2 R"and A4: "[TARSKIK4 x,y ] inHIDDENR3 R"and A5: "y inHIDDENR3 rngRELAT-1K2 R /\\XBOOLE-0K3 Y"
          using relat_1_th_131 sorry
        have "y inHIDDENR3 Y"
          using A5 xboole_0_def_4 sorry
        thus "x inHIDDENR3 R \<inverse>RELAT-1K11 Y"
          using A4 relat_1_def_14 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "R \<inverse>RELAT-1K11 Y =XBOOLE-0R4 R \<inverse>RELAT-1K11 (rngRELAT-1K2 R /\\XBOOLE-0K3 Y)"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_134:
" for R be RelationRELAT-1M1 holds R \<inverse>RELAT-1K11 (rngRELAT-1K2 R) =XBOOLE-0R4 domRELAT-1K1 R"
proof-
  have " for R be RelationRELAT-1M1 holds R \<inverse>RELAT-1K11 (rngRELAT-1K2 R) =XBOOLE-0R4 domRELAT-1K1 R"
  proof(rule ballI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have "R \<inverse>RELAT-1K11 (rngRELAT-1K2 R) c=TARSKIR1 domRELAT-1K1 R & domRELAT-1K1 R c=TARSKIR1 R \<inverse>RELAT-1K11 (rngRELAT-1K2 R)"
    proof(rule conjMI)
      show "R \<inverse>RELAT-1K11 (rngRELAT-1K2 R) c=TARSKIR1 domRELAT-1K1 R"
        using relat_1_th_132 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 R implies x inHIDDENR3 R \<inverse>RELAT-1K11 (rngRELAT-1K2 R)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 domRELAT-1K1 R"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A1: "[TARSKIK4 x,y ] inHIDDENR3 R"
          using xtuple_0_def_12 sorry
        have "y inHIDDENR3 rngRELAT-1K2 R"
          using A1 xtuple_0_def_13 sorry
        thus "x inHIDDENR3 R \<inverse>RELAT-1K11 (rngRELAT-1K2 R)"
          using A1 relat_1_def_14 sorry
      qed "sorry"
      thus "domRELAT-1K1 R c=TARSKIR1 R \<inverse>RELAT-1K11 (rngRELAT-1K2 R)"
        using tarski_def_3 sorry
    qed
    thus "R \<inverse>RELAT-1K11 (rngRELAT-1K2 R) =XBOOLE-0R4 domRELAT-1K1 R"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_135:
" for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R \<inverse>RELAT-1K11 Y c=TARSKIR1 R \<inverse>RELAT-1K11 (rngRELAT-1K2 R)"
proof-
  have " for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R \<inverse>RELAT-1K11 Y c=TARSKIR1 R \<inverse>RELAT-1K11 (rngRELAT-1K2 R)"
  proof(rule ballI,rule ballI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have "R \<inverse>RELAT-1K11 Y c=TARSKIR1 domRELAT-1K1 R"
      using relat_1_th_132 sorry
    thus "R \<inverse>RELAT-1K11 Y c=TARSKIR1 R \<inverse>RELAT-1K11 (rngRELAT-1K2 R)"
      using relat_1_th_134 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_cl_25:
  mlet "R be RelationRELAT-1M1", "Y be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster R \<inverse>RELAT-1K11 Y as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "R \<inverse>RELAT-1K11 Y be emptyXBOOLE-0V1"
  proof-
    let ?x = "the ElementSUBSET-1M1-of R \<inverse>RELAT-1K11 ({}XBOOLE-0K1)"
    have "?x inTARSKIR2 R \<inverse>RELAT-1K11 ({}XBOOLE-0K1) implies ( ex y be objectHIDDENM1 st [TARSKIK4 ?x,y ] inHIDDENR3 R & y inHIDDENR3 {}XBOOLE-0K1)"
      using relat_1_def_14 sorry
    thus "R \<inverse>RELAT-1K11 Y be emptyXBOOLE-0V1"
       sorry
  qed
qed "sorry"

mtheorem relat_1_cl_26:
  mlet "R be emptyXBOOLE-0V1\<bar>RelationRELAT-1M1", "Y be setHIDDENM2"
"cluster R \<inverse>RELAT-1K11 Y as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "R \<inverse>RELAT-1K11 Y be emptyXBOOLE-0V1"
  proof-
    have " not R \<inverse>RELAT-1K11 Y be emptyXBOOLE-0V1 implies  False "
    proof(rule impI)
      assume " not R \<inverse>RELAT-1K11 Y be emptyXBOOLE-0V1"
      then have " ex y be objectHIDDENM1 st [TARSKIK4 the ElementSUBSET-1M1-of ({}XBOOLE-0K1)\<inverse>RELAT-1K11 Y,y ] inHIDDENR3 {}XBOOLE-0K1 & y inHIDDENR3 Y"
        using relat_1_def_14 sorry
      thus " False "
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

(*\$CT 2*)
mtheorem relat_1_th_138:
" for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R \<inverse>RELAT-1K11 Y =XBOOLE-0R4 {}XBOOLE-0K1 iff rngRELAT-1K2 R missesXBOOLE-0R1 Y"
proof-
  have " for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds (R \<inverse>RELAT-1K11 Y =XBOOLE-0R4 {}XBOOLE-0K1 implies rngRELAT-1K2 R missesXBOOLE-0R1 Y) &  not (rngRELAT-1K2 R missesXBOOLE-0R1 Y &  not R \<inverse>RELAT-1K11 Y =XBOOLE-0R4 {}XBOOLE-0K1)"
  proof(rule ballI,rule ballI,rule conjMI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    let ?x = "the ElementSUBSET-1M1-of R \<inverse>RELAT-1K11 Y"
    show "R \<inverse>RELAT-1K11 Y =XBOOLE-0R4 {}XBOOLE-0K1 implies rngRELAT-1K2 R missesXBOOLE-0R1 Y"
    proof-
      have "R \<inverse>RELAT-1K11 Y =XBOOLE-0R4 {}XBOOLE-0K1 implies ( not rngRELAT-1K2 R missesXBOOLE-0R1 Y implies  False )"
      proof(rule impI,rule impI)
        assume A1: "R \<inverse>RELAT-1K11 Y =XBOOLE-0R4 {}XBOOLE-0K1"
        assume " not rngRELAT-1K2 R missesXBOOLE-0R1 Y"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A2: "y inHIDDENR3 rngRELAT-1K2 R"and A3: "y inHIDDENR3 Y"
          using xboole_0_th_3 sorry
        have " ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R"
          using A2 xtuple_0_def_13 sorry
        thus " False "
          using A1 A2 A3 relat_1_th_131 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "rngRELAT-1K2 R /\\XBOOLE-0K3 Y =XBOOLE-0R4 {}XBOOLE-0K1 implies ( not R \<inverse>RELAT-1K11 Y =XBOOLE-0R4 {}XBOOLE-0K1 implies  False )"
    proof(rule impI,rule impI)
      assume A4: "rngRELAT-1K2 R /\\XBOOLE-0K3 Y =XBOOLE-0R4 {}XBOOLE-0K1"
      assume " not R \<inverse>RELAT-1K11 Y =XBOOLE-0R4 {}XBOOLE-0K1"
      then have " ex y be objectHIDDENM1 st (y inHIDDENR3 rngRELAT-1K2 R & [TARSKIK4 ?x,y ] inHIDDENR3 R) & y inHIDDENR3 Y"
        using relat_1_th_131 sorry
      thus " False "
        using A4 xboole_0_def_4 sorry
    qed
    thus " not (rngRELAT-1K2 R missesXBOOLE-0R1 Y &  not R \<inverse>RELAT-1K11 Y =XBOOLE-0R4 {}XBOOLE-0K1)"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_139:
" for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds Y <>HIDDENR2 {}XBOOLE-0K1 & Y c=TARSKIR1 rngRELAT-1K2 R implies R \<inverse>RELAT-1K11 Y <>HIDDENR2 {}XBOOLE-0K1"
proof-
  have " for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds Y <>HIDDENR2 {}XBOOLE-0K1 & Y c=TARSKIR1 rngRELAT-1K2 R implies  not R \<inverse>RELAT-1K11 Y <>HIDDENR2 {}XBOOLE-0K1"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume A1: "Y <>HIDDENR2 {}XBOOLE-0K1"
      and A2: "Y c=TARSKIR1 rngRELAT-1K2 R"
    let ?y = "the ElementSUBSET-1M1-of Y"
    have A3: "?y inTARSKIR2 rngRELAT-1K2 R"
      using A1 A2 sorry
    then have " ex x be objectHIDDENM1 st [TARSKIK4 x,?y ] inHIDDENR3 R"
      using xtuple_0_def_13 sorry
    thus " not R \<inverse>RELAT-1K11 Y <>HIDDENR2 {}XBOOLE-0K1"
      using A1 A3 relat_1_th_131 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_140:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R \<inverse>RELAT-1K11 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 R \<inverse>RELAT-1K11 X \\/XBOOLE-0K2 R \<inverse>RELAT-1K11 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R \<inverse>RELAT-1K11 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 R \<inverse>RELAT-1K11 X \\/XBOOLE-0K2 R \<inverse>RELAT-1K11 Y"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have "R \<inverse>RELAT-1K11 (X \\/XBOOLE-0K2 Y) c=TARSKIR1 R \<inverse>RELAT-1K11 X \\/XBOOLE-0K2 R \<inverse>RELAT-1K11 Y & R \<inverse>RELAT-1K11 X \\/XBOOLE-0K2 R \<inverse>RELAT-1K11 Y c=TARSKIR1 R \<inverse>RELAT-1K11 (X \\/XBOOLE-0K2 Y)"
    proof(rule conjMI)
      show "R \<inverse>RELAT-1K11 (X \\/XBOOLE-0K2 Y) c=TARSKIR1 R \<inverse>RELAT-1K11 X \\/XBOOLE-0K2 R \<inverse>RELAT-1K11 Y"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 R \<inverse>RELAT-1K11 (X \\/XBOOLE-0K2 Y) implies x inHIDDENR3 R \<inverse>RELAT-1K11 X \\/XBOOLE-0K2 R \<inverse>RELAT-1K11 Y"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 R \<inverse>RELAT-1K11 (X \\/XBOOLE-0K2 Y)"
          then obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A1: "[TARSKIK4 x,y ] inHIDDENR3 R"and A2: "y inHIDDENR3 X \\/XBOOLE-0K2 Y"
            using relat_1_def_14 sorry
          have "y inHIDDENR3 X or y inHIDDENR3 Y"
            using A2 xboole_0_def_3 sorry
          then have "x inHIDDENR3 R \<inverse>RELAT-1K11 X or x inHIDDENR3 R \<inverse>RELAT-1K11 Y"
            using A1 relat_1_def_14 sorry
          thus "x inHIDDENR3 R \<inverse>RELAT-1K11 X \\/XBOOLE-0K2 R \<inverse>RELAT-1K11 Y"
            using xboole_0_def_3 sorry
        qed "sorry"
        thus "R \<inverse>RELAT-1K11 (X \\/XBOOLE-0K2 Y) c=TARSKIR1 R \<inverse>RELAT-1K11 X \\/XBOOLE-0K2 R \<inverse>RELAT-1K11 Y"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 R \<inverse>RELAT-1K11 X \\/XBOOLE-0K2 R \<inverse>RELAT-1K11 Y implies x inHIDDENR3 R \<inverse>RELAT-1K11 (X \\/XBOOLE-0K2 Y)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A3: "x inHIDDENR3 R \<inverse>RELAT-1K11 X \\/XBOOLE-0K2 R \<inverse>RELAT-1K11 Y"
        show "x inHIDDENR3 R \<inverse>RELAT-1K11 (X \\/XBOOLE-0K2 Y)"
        proof-
          have cases: "x inHIDDENR3 R \<inverse>RELAT-1K11 Y or x inHIDDENR3 R \<inverse>RELAT-1K11 X"
            using A3 xboole_0_def_3 sorry
          have case1: "x inHIDDENR3 R \<inverse>RELAT-1K11 Y implies x inHIDDENR3 R \<inverse>RELAT-1K11 (X \\/XBOOLE-0K2 Y)"
          proof(rule impI)
            assume "x inHIDDENR3 R \<inverse>RELAT-1K11 Y"
            then obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A4: "[TARSKIK4 x,y ] inHIDDENR3 R"and A5: "y inHIDDENR3 Y"
              using relat_1_def_14 sorry
            have "y inHIDDENR3 X \\/XBOOLE-0K2 Y"
              using A5 xboole_0_def_3 sorry
            thus "x inHIDDENR3 R \<inverse>RELAT-1K11 (X \\/XBOOLE-0K2 Y)"
              using A4 relat_1_def_14 sorry
          qed
          have case2: "x inHIDDENR3 R \<inverse>RELAT-1K11 X implies x inHIDDENR3 R \<inverse>RELAT-1K11 (X \\/XBOOLE-0K2 Y)"
          proof(rule impI)
            assume "x inHIDDENR3 R \<inverse>RELAT-1K11 X"
            then obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A6: "[TARSKIK4 x,y ] inHIDDENR3 R"and A7: "y inHIDDENR3 X"
              using relat_1_def_14 sorry
            have "y inHIDDENR3 X \\/XBOOLE-0K2 Y"
              using A7 xboole_0_def_3 sorry
            thus "x inHIDDENR3 R \<inverse>RELAT-1K11 (X \\/XBOOLE-0K2 Y)"
              using A6 relat_1_def_14 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus "R \<inverse>RELAT-1K11 X \\/XBOOLE-0K2 R \<inverse>RELAT-1K11 Y c=TARSKIR1 R \<inverse>RELAT-1K11 (X \\/XBOOLE-0K2 Y)"
        using tarski_def_3 sorry
    qed
    thus "R \<inverse>RELAT-1K11 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 R \<inverse>RELAT-1K11 X \\/XBOOLE-0K2 R \<inverse>RELAT-1K11 Y"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_141:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R \<inverse>RELAT-1K11 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 R \<inverse>RELAT-1K11 X /\\XBOOLE-0K3 R \<inverse>RELAT-1K11 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R \<inverse>RELAT-1K11 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 R \<inverse>RELAT-1K11 X /\\XBOOLE-0K3 R \<inverse>RELAT-1K11 Y"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 R \<inverse>RELAT-1K11 (X /\\XBOOLE-0K3 Y) implies x inHIDDENR3 R \<inverse>RELAT-1K11 X /\\XBOOLE-0K3 R \<inverse>RELAT-1K11 Y"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 R \<inverse>RELAT-1K11 (X /\\XBOOLE-0K3 Y)"
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A1: "[TARSKIK4 x,y ] inHIDDENR3 R"and A2: "y inHIDDENR3 X /\\XBOOLE-0K3 Y"
        using relat_1_def_14 sorry
      have "y inHIDDENR3 Y"
        using A2 xboole_0_def_4 sorry
      then have A3: "x inHIDDENR3 R \<inverse>RELAT-1K11 Y"
        using A1 relat_1_def_14 sorry
      have "y inHIDDENR3 X"
        using A2 xboole_0_def_4 sorry
      then have "x inHIDDENR3 R \<inverse>RELAT-1K11 X"
        using A1 relat_1_def_14 sorry
      thus "x inHIDDENR3 R \<inverse>RELAT-1K11 X /\\XBOOLE-0K3 R \<inverse>RELAT-1K11 Y"
        using A3 xboole_0_def_4 sorry
    qed "sorry"
    thus "R \<inverse>RELAT-1K11 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 R \<inverse>RELAT-1K11 X /\\XBOOLE-0K3 R \<inverse>RELAT-1K11 Y"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_142:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R \<inverse>RELAT-1K11 X \\SUBSET-1K6 R \<inverse>RELAT-1K11 Y c=TARSKIR1 R \<inverse>RELAT-1K11 (X \\SUBSET-1K6 Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R \<inverse>RELAT-1K11 X \\SUBSET-1K6 R \<inverse>RELAT-1K11 Y c=TARSKIR1 R \<inverse>RELAT-1K11 (X \\SUBSET-1K6 Y)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 R \<inverse>RELAT-1K11 X \\SUBSET-1K6 R \<inverse>RELAT-1K11 Y implies x inHIDDENR3 R \<inverse>RELAT-1K11 (X \\SUBSET-1K6 Y)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A1: "x inHIDDENR3 R \<inverse>RELAT-1K11 X \\SUBSET-1K6 R \<inverse>RELAT-1K11 Y"
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A2: "[TARSKIK4 x,y ] inHIDDENR3 R"and A3: "y inHIDDENR3 X"
        using relat_1_def_14 sorry
      have " not x inHIDDENR3 R \<inverse>RELAT-1K11 Y"
        using A1 xboole_0_def_5 sorry
      then have " not y inHIDDENR3 Y or  not [TARSKIK4 x,y ] inHIDDENR3 R"
        using relat_1_def_14 sorry
      then have "y inHIDDENR3 X \\SUBSET-1K6 Y"
        using A2 A3 xboole_0_def_5 sorry
      thus "x inHIDDENR3 R \<inverse>RELAT-1K11 (X \\SUBSET-1K6 Y)"
        using A2 relat_1_def_14 sorry
    qed "sorry"
    thus "R \<inverse>RELAT-1K11 X \\SUBSET-1K6 R \<inverse>RELAT-1K11 Y c=TARSKIR1 R \<inverse>RELAT-1K11 (X \\SUBSET-1K6 Y)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_143:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds X c=TARSKIR1 Y implies R \<inverse>RELAT-1K11 X c=TARSKIR1 R \<inverse>RELAT-1K11 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds X c=TARSKIR1 Y implies R \<inverse>RELAT-1K11 X c=TARSKIR1 R \<inverse>RELAT-1K11 Y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume A1: "X c=TARSKIR1 Y"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 R \<inverse>RELAT-1K11 X implies x inHIDDENR3 R \<inverse>RELAT-1K11 Y"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 R \<inverse>RELAT-1K11 X"
      then have " ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & y inHIDDENR3 X"
        using relat_1_def_14 sorry
      thus "x inHIDDENR3 R \<inverse>RELAT-1K11 Y"
        using A1 relat_1_def_14 sorry
    qed "sorry"
    thus "R \<inverse>RELAT-1K11 X c=TARSKIR1 R \<inverse>RELAT-1K11 Y"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_144:
" for Y be setHIDDENM2 holds  for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds P c=RELAT-1R2 R implies P \<inverse>RELAT-1K11 Y c=TARSKIR1 R \<inverse>RELAT-1K11 Y"
proof-
  have " for Y be setHIDDENM2 holds  for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds P c=RELAT-1R2 R implies P \<inverse>RELAT-1K11 Y c=TARSKIR1 R \<inverse>RELAT-1K11 Y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix P assume [ty]: "P be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume A1: "P c=RELAT-1R2 R"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 P \<inverse>RELAT-1K11 Y implies x inHIDDENR3 R \<inverse>RELAT-1K11 Y"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 P \<inverse>RELAT-1K11 Y"
      then have " ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 P & y inHIDDENR3 Y"
        using relat_1_def_14 sorry
      thus "x inHIDDENR3 R \<inverse>RELAT-1K11 Y"
        using A1 relat_1_def_14 sorry
    qed "sorry"
    thus "P \<inverse>RELAT-1K11 Y c=TARSKIR1 R \<inverse>RELAT-1K11 Y"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_145:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds P c=RELAT-1R2 R & X c=TARSKIR1 Y implies P \<inverse>RELAT-1K11 X c=TARSKIR1 R \<inverse>RELAT-1K11 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds P c=RELAT-1R2 R & X c=TARSKIR1 Y implies P \<inverse>RELAT-1K11 X c=TARSKIR1 R \<inverse>RELAT-1K11 Y"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix P assume [ty]: "P be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume "P c=RELAT-1R2 R & X c=TARSKIR1 Y"
    then have "P \<inverse>RELAT-1K11 X c=TARSKIR1 R \<inverse>RELAT-1K11 X & R \<inverse>RELAT-1K11 X c=TARSKIR1 R \<inverse>RELAT-1K11 Y"
      using relat_1_th_143 relat_1_th_144 sorry
    thus "P \<inverse>RELAT-1K11 X c=TARSKIR1 R \<inverse>RELAT-1K11 Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_146:
" for Y be setHIDDENM2 holds  for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds (P *RELAT-1K6 R)\<inverse>RELAT-1K11 Y =XBOOLE-0R4 P \<inverse>RELAT-1K11 (R \<inverse>RELAT-1K11 Y)"
proof-
  have " for Y be setHIDDENM2 holds  for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds (P *RELAT-1K6 R)\<inverse>RELAT-1K11 Y =XBOOLE-0R4 P \<inverse>RELAT-1K11 (R \<inverse>RELAT-1K11 Y)"
  proof(rule ballI,rule ballI,rule ballI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix P assume [ty]: "P be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 (P *RELAT-1K6 R)\<inverse>RELAT-1K11 Y iff x inHIDDENR3 P \<inverse>RELAT-1K11 (R \<inverse>RELAT-1K11 Y)"
    proof-
      have " for x be objectHIDDENM1 holds (x inHIDDENR3 (P *RELAT-1K6 R)\<inverse>RELAT-1K11 Y implies x inHIDDENR3 P \<inverse>RELAT-1K11 (R \<inverse>RELAT-1K11 Y)) & (x inHIDDENR3 P \<inverse>RELAT-1K11 (R \<inverse>RELAT-1K11 Y) implies x inHIDDENR3 (P *RELAT-1K6 R)\<inverse>RELAT-1K11 Y)"
      proof(rule ballI,rule conjMI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        show "x inHIDDENR3 (P *RELAT-1K6 R)\<inverse>RELAT-1K11 Y implies x inHIDDENR3 P \<inverse>RELAT-1K11 (R \<inverse>RELAT-1K11 Y)"
        proof(rule impI)
          assume "x inHIDDENR3 (P *RELAT-1K6 R)\<inverse>RELAT-1K11 Y"
          then obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A1: "[TARSKIK4 x,y ] inHIDDENR3 P *RELAT-1K6 R"and A2: "y inHIDDENR3 Y"
            using relat_1_def_14 sorry
          obtain z where
            [ty]:"z be objectHIDDENM1" and 
            A3: "[TARSKIK4 x,z ] inHIDDENR3 P"and A4: "[TARSKIK4 z,y ] inHIDDENR3 R"
            using A1 relat_1_def_8 sorry
          have "z inHIDDENR3 R \<inverse>RELAT-1K11 Y"
            using A2 A4 relat_1_def_14 sorry
          thus "x inHIDDENR3 P \<inverse>RELAT-1K11 (R \<inverse>RELAT-1K11 Y)"
            using A3 relat_1_def_14 sorry
        qed
        assume "x inHIDDENR3 P \<inverse>RELAT-1K11 (R \<inverse>RELAT-1K11 Y)"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A5: "[TARSKIK4 x,y ] inHIDDENR3 P"and A6: "y inHIDDENR3 R \<inverse>RELAT-1K11 Y"
          using relat_1_def_14 sorry
        obtain z where
          [ty]:"z be objectHIDDENM1" and 
          A7: "[TARSKIK4 y,z ] inHIDDENR3 R"and A8: "z inHIDDENR3 Y"
          using A6 relat_1_def_14 sorry
        have "[TARSKIK4 x,z ] inHIDDENR3 P *RELAT-1K6 R"
          using A5 A7 relat_1_def_8 sorry
        thus "x inHIDDENR3 (P *RELAT-1K6 R)\<inverse>RELAT-1K11 Y"
          using A8 relat_1_def_14 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "(P *RELAT-1K6 R)\<inverse>RELAT-1K11 Y =XBOOLE-0R4 P \<inverse>RELAT-1K11 (R \<inverse>RELAT-1K11 Y)"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_147:
" for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds domRELAT-1K1 (P *RELAT-1K6 R) =XBOOLE-0R4 P \<inverse>RELAT-1K11 (domRELAT-1K1 R)"
proof-
  have " for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds domRELAT-1K1 (P *RELAT-1K6 R) =XBOOLE-0R4 P \<inverse>RELAT-1K11 (domRELAT-1K1 R)"
  proof(rule ballI,rule ballI)
    fix P assume [ty]: "P be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 (P *RELAT-1K6 R) iff z inHIDDENR3 P \<inverse>RELAT-1K11 (domRELAT-1K1 R)"
    proof-
      have " for z be objectHIDDENM1 holds (z inHIDDENR3 domRELAT-1K1 (P *RELAT-1K6 R) implies z inHIDDENR3 P \<inverse>RELAT-1K11 (domRELAT-1K1 R)) & (z inHIDDENR3 P \<inverse>RELAT-1K11 (domRELAT-1K1 R) implies z inHIDDENR3 domRELAT-1K1 (P *RELAT-1K6 R))"
      proof(rule ballI,rule conjMI,rule impI)
        fix z assume [ty]: "z be objectHIDDENM1"
        show "z inHIDDENR3 domRELAT-1K1 (P *RELAT-1K6 R) implies z inHIDDENR3 P \<inverse>RELAT-1K11 (domRELAT-1K1 R)"
        proof(rule impI)
          assume "z inHIDDENR3 domRELAT-1K1 (P *RELAT-1K6 R)"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A1: "[TARSKIK4 z,x ] inHIDDENR3 P *RELAT-1K6 R"
            using xtuple_0_def_12 sorry
          obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A2: "[TARSKIK4 z,y ] inHIDDENR3 P"and A3: "[TARSKIK4 y,x ] inHIDDENR3 R"
            using A1 relat_1_def_8 sorry
          have "y inHIDDENR3 domRELAT-1K1 R"
            using A3 xtuple_0_def_12 sorry
          thus "z inHIDDENR3 P \<inverse>RELAT-1K11 (domRELAT-1K1 R)"
            using A2 relat_1_def_14 sorry
        qed
        assume "z inHIDDENR3 P \<inverse>RELAT-1K11 (domRELAT-1K1 R)"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A4: "[TARSKIK4 z,y ] inHIDDENR3 P"and A5: "y inHIDDENR3 domRELAT-1K1 R"
          using relat_1_def_14 sorry
        obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A6: "[TARSKIK4 y,x ] inHIDDENR3 R"
          using A5 xtuple_0_def_12 sorry
        have "[TARSKIK4 z,x ] inHIDDENR3 P *RELAT-1K6 R"
          using A4 A6 relat_1_def_8 sorry
        thus "z inHIDDENR3 domRELAT-1K1 (P *RELAT-1K6 R)"
          using xtuple_0_def_12 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "domRELAT-1K1 (P *RELAT-1K6 R) =XBOOLE-0R4 P \<inverse>RELAT-1K11 (domRELAT-1K1 R)"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_148:
" for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds rngRELAT-1K2 R /\\XBOOLE-0K3 Y c=TARSKIR1 (R ~RELAT-1K4)\<inverse>RELAT-1K11 (R \<inverse>RELAT-1K11 Y)"
proof-
  have " for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds rngRELAT-1K2 R /\\XBOOLE-0K3 Y c=TARSKIR1 (R ~RELAT-1K4)\<inverse>RELAT-1K11 (R \<inverse>RELAT-1K11 Y)"
  proof(rule ballI,rule ballI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 rngRELAT-1K2 R /\\XBOOLE-0K3 Y implies y inHIDDENR3 (R ~RELAT-1K4)\<inverse>RELAT-1K11 (R \<inverse>RELAT-1K11 Y)"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A1: "y inHIDDENR3 rngRELAT-1K2 R /\\XBOOLE-0K3 Y"
      then have "y inHIDDENR3 rngRELAT-1K2 R"
        using xboole_0_def_4 sorry
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A2: "[TARSKIK4 x,y ] inHIDDENR3 R"
        using xtuple_0_def_13 sorry
      have A3: "[TARSKIK4 y,x ] inHIDDENR3 R ~RELAT-1K4"
        using A2 relat_1_def_7 sorry
      have "y inHIDDENR3 Y"
        using A1 xboole_0_def_4 sorry
      then have "x inHIDDENR3 R \<inverse>RELAT-1K11 Y"
        using A2 relat_1_def_14 sorry
      thus "y inHIDDENR3 (R ~RELAT-1K4)\<inverse>RELAT-1K11 (R \<inverse>RELAT-1K11 Y)"
        using A3 relat_1_def_14 sorry
    qed "sorry"
    thus "rngRELAT-1K2 R /\\XBOOLE-0K3 Y c=TARSKIR1 (R ~RELAT-1K4)\<inverse>RELAT-1K11 (R \<inverse>RELAT-1K11 Y)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mdef relat_1_def_15 ("empty-yieldingRELAT-1V3" 70 ) where
"attr empty-yieldingRELAT-1V3 for RelationRELAT-1M1 means
  (\<lambda>R. rngRELAT-1K2 R c=TARSKIR1 {TARSKIK1 {}XBOOLE-0K1 })"..

mtheorem relat_1_th_149:
" for R be RelationRELAT-1M1 holds R be empty-yieldingRELAT-1V3 iff ( for X be setHIDDENM2 holds X inTARSKIR2 rngRELAT-1K2 R implies X =XBOOLE-0R4 {}XBOOLE-0K1)"
proof-
  have " for R be RelationRELAT-1M1 holds (R be empty-yieldingRELAT-1V3 implies ( for X be setHIDDENM2 holds X inTARSKIR2 rngRELAT-1K2 R implies X =XBOOLE-0R4 {}XBOOLE-0K1)) & (( for X be setHIDDENM2 holds X inTARSKIR2 rngRELAT-1K2 R implies X =XBOOLE-0R4 {}XBOOLE-0K1) implies R be empty-yieldingRELAT-1V3)"
  proof(rule ballI,rule conjMI,rule impI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "R be empty-yieldingRELAT-1V3 implies ( for X be setHIDDENM2 holds X inTARSKIR2 rngRELAT-1K2 R implies X =XBOOLE-0R4 {}XBOOLE-0K1)"
      using tarski_def_1 sorry
    assume A1: " for X be setHIDDENM2 holds X inTARSKIR2 rngRELAT-1K2 R implies X =XBOOLE-0R4 {}XBOOLE-0K1"
    have " for Y be objectHIDDENM1 holds Y inHIDDENR3 rngRELAT-1K2 R implies Y inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
    proof(rule ballI,rule impI)
      fix Y assume [ty]: "Y be objectHIDDENM1"
      assume "Y inHIDDENR3 rngRELAT-1K2 R"
      then have "Y =HIDDENR1 {}XBOOLE-0K1"
        using A1 sorry
      thus "Y inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
        using tarski_def_1 sorry
    qed "sorry"
    thus "R be empty-yieldingRELAT-1V3"
      using tarski_def_3 relat_1_def_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_150:
" for f be RelationRELAT-1M1 holds  for g be RelationRELAT-1M1 holds  for A be setHIDDENM2 holds  for B be setHIDDENM2 holds f  |RELAT-1K8 A =RELAT-1R1 g  |RELAT-1K8 A & f  |RELAT-1K8 B =RELAT-1R1 g  |RELAT-1K8 B implies f  |RELAT-1K8 (A \\/XBOOLE-0K2 B) =RELAT-1R1 g  |RELAT-1K8 (A \\/XBOOLE-0K2 B)"
proof-
  have " for f be RelationRELAT-1M1 holds  for g be RelationRELAT-1M1 holds  for A be setHIDDENM2 holds  for B be setHIDDENM2 holds f  |RELAT-1K8 A =RELAT-1R1 g  |RELAT-1K8 A & f  |RELAT-1K8 B =RELAT-1R1 g  |RELAT-1K8 B implies f  |RELAT-1K8 (A \\/XBOOLE-0K2 B) =HIDDENR1 g  |RELAT-1K8 (A \\/XBOOLE-0K2 B)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be RelationRELAT-1M1"
    fix g assume [ty]: "g be RelationRELAT-1M1"
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    assume "f  |RELAT-1K8 A =RELAT-1R1 g  |RELAT-1K8 A & f  |RELAT-1K8 B =RELAT-1R1 g  |RELAT-1K8 B"
    then have "f  |RELAT-1K8 (A \\/XBOOLE-0K2 B) =HIDDENR1 g  |RELAT-1K8 A \\/XBOOLE-0K2 g  |RELAT-1K8 B"
      using relat_1_th_78 sorry
    also have "... = g  |RELAT-1K8 (A \\/XBOOLE-0K2 B)"
      using relat_1_th_78 sorry
    finally show "f  |RELAT-1K8 (A \\/XBOOLE-0K2 B) =HIDDENR1 g  |RELAT-1K8 (A \\/XBOOLE-0K2 B)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_151:
" for X be setHIDDENM2 holds  for f be RelationRELAT-1M1 holds  for g be RelationRELAT-1M1 holds domRELAT-1K1 g c=TARSKIR1 X & g c=RELAT-1R2 f implies g c=RELAT-1R2 f  |RELAT-1K8 X"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix X assume [ty]: "X be setHIDDENM2"
  fix f assume [ty]: "f be RelationRELAT-1M1"
  fix g assume [ty]: "g be RelationRELAT-1M1"
  assume "domRELAT-1K1 g c=TARSKIR1 X & g c=RELAT-1R2 f"
  then have "g  |RELAT-1K8 domRELAT-1K1 g c=RELAT-1R2 f  |RELAT-1K8 X"
    using relat_1_th_77 sorry
  thus "g c=RELAT-1R2 f  |RELAT-1K8 X"
     sorry
qed "sorry"

mtheorem relat_1_th_152:
" for f be RelationRELAT-1M1 holds  for X be setHIDDENM2 holds X missesXBOOLE-0R1 domRELAT-1K1 f implies f  |RELAT-1K8 X =RELAT-1R1 {}XBOOLE-0K1"
proof-
  have " for f be RelationRELAT-1M1 holds  for X be setHIDDENM2 holds  not (X missesXBOOLE-0R1 domRELAT-1K1 f &  not f  |RELAT-1K8 X =RELAT-1R1 {}XBOOLE-0K1)"
  proof(rule ballI,rule ballI)
    fix f assume [ty]: "f be RelationRELAT-1M1"
    fix X assume [ty]: "X be setHIDDENM2"
    have "X /\\XBOOLE-0K3 domRELAT-1K1 f =XBOOLE-0R4 {}XBOOLE-0K1 implies f  |RELAT-1K8 X =HIDDENR1 {}XBOOLE-0K1"
    proof(rule impI)
      assume A1: "X /\\XBOOLE-0K3 domRELAT-1K1 f =XBOOLE-0R4 {}XBOOLE-0K1"
      have "f  |RELAT-1K8 X =HIDDENR1 (f  |RELAT-1K8 domRELAT-1K1 f) |RELAT-1K8 X"
         sorry
      also have "... = f  |RELAT-1K8 {}XBOOLE-0K1"
        using A1 relat_1_th_71 sorry
      also have "... = {}XBOOLE-0K1"
         sorry
      finally show "f  |RELAT-1K8 X =HIDDENR1 {}XBOOLE-0K1"
         sorry
    qed
    thus " not (X missesXBOOLE-0R1 domRELAT-1K1 f &  not f  |RELAT-1K8 X =RELAT-1R1 {}XBOOLE-0K1)"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_153:
" for f be RelationRELAT-1M1 holds  for g be RelationRELAT-1M1 holds  for A be setHIDDENM2 holds  for B be setHIDDENM2 holds A c=TARSKIR1 B & f  |RELAT-1K8 B =RELAT-1R1 g  |RELAT-1K8 B implies f  |RELAT-1K8 A =RELAT-1R1 g  |RELAT-1K8 A"
proof-
  have " for f be RelationRELAT-1M1 holds  for g be RelationRELAT-1M1 holds  for A be setHIDDENM2 holds  for B be setHIDDENM2 holds A c=TARSKIR1 B & f  |RELAT-1K8 B =RELAT-1R1 g  |RELAT-1K8 B implies f  |RELAT-1K8 A =HIDDENR1 g  |RELAT-1K8 A"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix f assume [ty]: "f be RelationRELAT-1M1"
    fix g assume [ty]: "g be RelationRELAT-1M1"
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    assume A1: "A c=TARSKIR1 B"
      and A2: "f  |RELAT-1K8 B =RELAT-1R1 g  |RELAT-1K8 B"
    have A3: "A =XBOOLE-0R4 B /\\XBOOLE-0K3 A"
      using A1 xboole_1_th_28 sorry
    then have "f  |RELAT-1K8 A =HIDDENR1 (f  |RELAT-1K8 B) |RELAT-1K8 A"
      using relat_1_th_71 sorry
    also have "... = g  |RELAT-1K8 A"
      using A2 A3 relat_1_th_71 sorry
    finally show "f  |RELAT-1K8 A =HIDDENR1 g  |RELAT-1K8 A"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_154:
" for R be RelationRELAT-1M1 holds  for S be RelationRELAT-1M1 holds R  |RELAT-1K8 domRELAT-1K1 S =RELAT-1R1 R  |RELAT-1K8 domRELAT-1K1 (S  |RELAT-1K8 domRELAT-1K1 R)"
proof-
  have " for R be RelationRELAT-1M1 holds  for S be RelationRELAT-1M1 holds R  |RELAT-1K8 domRELAT-1K1 S =HIDDENR1 R  |RELAT-1K8 domRELAT-1K1 (S  |RELAT-1K8 domRELAT-1K1 R)"
  proof(rule ballI,rule ballI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix S assume [ty]: "S be RelationRELAT-1M1"
    have "R  |RELAT-1K8 domRELAT-1K1 S =HIDDENR1 (R  |RELAT-1K8 domRELAT-1K1 R) |RELAT-1K8 domRELAT-1K1 S"
       sorry
    also have "... = R  |RELAT-1K8 (domRELAT-1K1 S /\\XBOOLE-0K3 domRELAT-1K1 R)"
      using relat_1_th_71 sorry
    also have "... = R  |RELAT-1K8 domRELAT-1K1 (S  |RELAT-1K8 domRELAT-1K1 R)"
      using relat_1_th_61 sorry
    finally show "R  |RELAT-1K8 domRELAT-1K1 S =HIDDENR1 R  |RELAT-1K8 domRELAT-1K1 (S  |RELAT-1K8 domRELAT-1K1 R)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_cl_27:
"cluster emptyXBOOLE-0V1 also-is empty-yieldingRELAT-1V3 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be emptyXBOOLE-0V1 implies it be empty-yieldingRELAT-1V3"
  proof-
    have " for R be RelationRELAT-1M1 holds R be emptyXBOOLE-0V1 implies R be empty-yieldingRELAT-1V3"
    proof(rule ballI,rule impI)
      fix R assume [ty]: "R be RelationRELAT-1M1"
      assume Cut2513: "R be emptyXBOOLE-0V1"
      have "rngRELAT-1K2 R c=TARSKIR1 {TARSKIK1 {}XBOOLE-0K1 }"
      proof-
        show "rngRELAT-1K2 R c=TARSKIR1 {TARSKIK1 {}XBOOLE-0K1 }"
          using Cut2513 sorry
      qed
      thus "R be empty-yieldingRELAT-1V3"
        using relat_1_def_15 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem relat_1_cl_28:
  mlet "R be empty-yieldingRELAT-1V3\<bar>RelationRELAT-1M1", "X be setHIDDENM2"
"cluster R  |RELAT-1K8 X as-term-is empty-yieldingRELAT-1V3"
proof
(*coherence*)
  show "R  |RELAT-1K8 X be empty-yieldingRELAT-1V3"
  proof-
    have Cut2524: "rngRELAT-1K2 R c=TARSKIR1 {TARSKIK1 {}XBOOLE-0K1 } & rngRELAT-1K2 (R  |RELAT-1K8 X) c=TARSKIR1 rngRELAT-1K2 R"
      using relat_1_def_15 relat_1_th_59 xtuple_0_th_9 sorry
    have "rngRELAT-1K2 (R  |RELAT-1K8 X) c=TARSKIR1 {TARSKIK1 {}XBOOLE-0K1 }"
    proof-
      show "rngRELAT-1K2 (R  |RELAT-1K8 X) c=TARSKIR1 {TARSKIK1 {}XBOOLE-0K1 }"
        using Cut2524 sorry
    qed
    thus "R  |RELAT-1K8 X be empty-yieldingRELAT-1V3"
      using relat_1_def_15 sorry
  qed
qed "sorry"

mtheorem relat_1_th_155:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R  |RELAT-1K8 X be  non empty-yieldingRELAT-1V3 implies R be  non empty-yieldingRELAT-1V3"
   sorry

mdef relat_1_def_16 ("ImRELAT-1K12'( _ , _ ')" [0,0]228 ) where
  mlet "R be RelationRELAT-1M1", "x be objectHIDDENM1"
"func ImRELAT-1K12(R,x) \<rightarrow> setHIDDENM2 equals
  R .:RELAT-1K10 {TARSKIK1 x}"
proof-
  (*coherence*)
    show "R .:RELAT-1K10 {TARSKIK1 x} be setHIDDENM2"
       sorry
qed "sorry"

theorem relat_1_sch_2:
  fixes Af0 Bf0 Pp2 
  assumes
[ty]: "Af0 be RelationRELAT-1M1" and
  [ty]: "Bf0 be RelationRELAT-1M1" and
   A1: " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 Af0 iff Pp2(a,b)" and
   A2: " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 Bf0 iff Pp2(a,b)"
  shows "Af0 =RELAT-1R1 Bf0"
  proof-
    have " for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds ([TARSKIK4 y,z ] inHIDDENR3 Af0 implies [TARSKIK4 y,z ] inHIDDENR3 Bf0) & ([TARSKIK4 y,z ] inHIDDENR3 Bf0 implies [TARSKIK4 y,z ] inHIDDENR3 Af0)"
    proof(rule ballI,rule ballI,rule conjMI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      fix z assume [ty]: "z be objectHIDDENM1"
      show "[TARSKIK4 y,z ] inHIDDENR3 Af0 implies [TARSKIK4 y,z ] inHIDDENR3 Bf0"
        using A1 A2 sorry
      assume "[TARSKIK4 y,z ] inHIDDENR3 Bf0"
      thus "[TARSKIK4 y,z ] inHIDDENR3 Af0"
        using A1 A2 sorry
    qed "sorry"
    thus "Af0 =RELAT-1R1 Bf0"
      using relat_1_def_2 sorry
  qed

mtheorem relat_1_th_156:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds domRELAT-1K1 (R  |RELAT-1K8 (domRELAT-1K1 R \\SUBSET-1K6 X)) =XBOOLE-0R4 domRELAT-1K1 R \\SUBSET-1K6 X"
proof-
  have " for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds domRELAT-1K1 (R  |RELAT-1K8 (domRELAT-1K1 R \\SUBSET-1K6 X)) =HIDDENR1 domRELAT-1K1 R \\SUBSET-1K6 X"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have "domRELAT-1K1 (R  |RELAT-1K8 (domRELAT-1K1 R \\SUBSET-1K6 X)) =HIDDENR1 domRELAT-1K1 R /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 R)\<^esub> (domRELAT-1K1 R \\SUBSET-1K6 X)"
      using relat_1_th_61 sorry
    also have "... = domRELAT-1K1 R /\\XBOOLE-0K3 domRELAT-1K1 R \\SUBSET-1K6 X"
      using xboole_1_th_49 sorry
    also have "... = domRELAT-1K1 R \\SUBSET-1K6 X"
       sorry
    finally show "domRELAT-1K1 (R  |RELAT-1K8 (domRELAT-1K1 R \\SUBSET-1K6 X)) =HIDDENR1 domRELAT-1K1 R \\SUBSET-1K6 X"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_157:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R  |RELAT-1K8 X =RELAT-1R1 R  |RELAT-1K8 (domRELAT-1K1 R /\\XBOOLE-0K3 X)"
proof-
  have " for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R  |RELAT-1K8 X =HIDDENR1 R  |RELAT-1K8 (domRELAT-1K1 R /\\XBOOLE-0K3 X)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have "R  |RELAT-1K8 X =HIDDENR1 (R  |RELAT-1K8 domRELAT-1K1 R) |RELAT-1K8 X"
       sorry
    also have "... = R  |RELAT-1K8 (domRELAT-1K1 R /\\XBOOLE-0K3 X)"
      using relat_1_th_71 sorry
    finally show "R  |RELAT-1K8 X =HIDDENR1 R  |RELAT-1K8 (domRELAT-1K1 R /\\XBOOLE-0K3 X)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_158:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds domRELAT-1K1 ([:ZFMISC-1K2 X,Y :]) c=TARSKIR1 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds domRELAT-1K1 ([:ZFMISC-1K2 X,Y :]) c=TARSKIR1 X"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 ([:ZFMISC-1K2 X,Y :]) implies x inHIDDENR3 X"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 domRELAT-1K1 ([:ZFMISC-1K2 X,Y :])"
      then have " ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
        using xtuple_0_def_12 sorry
      thus "x inHIDDENR3 X"
        using zfmisc_1_th_87 sorry
    qed "sorry"
    thus "domRELAT-1K1 ([:ZFMISC-1K2 X,Y :]) c=TARSKIR1 X"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_159:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds rngRELAT-1K2 ([:ZFMISC-1K2 X,Y :]) c=TARSKIR1 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds rngRELAT-1K2 ([:ZFMISC-1K2 X,Y :]) c=TARSKIR1 Y"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELAT-1K2 ([:ZFMISC-1K2 X,Y :]) implies x inHIDDENR3 Y"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 rngRELAT-1K2 ([:ZFMISC-1K2 X,Y :])"
      then have " ex y be objectHIDDENM1 st [TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
        using xtuple_0_def_13 sorry
      thus "x inHIDDENR3 Y"
        using zfmisc_1_th_87 sorry
    qed "sorry"
    thus "rngRELAT-1K2 ([:ZFMISC-1K2 X,Y :]) c=TARSKIR1 Y"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_160:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X <>HIDDENR2 {}XBOOLE-0K1 & Y <>HIDDENR2 {}XBOOLE-0K1 implies domRELAT-1K1 ([:ZFMISC-1K2 X,Y :]) =XBOOLE-0R4 X & rngRELAT-1K2 ([:ZFMISC-1K2 X,Y :]) =XBOOLE-0R4 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X <>HIDDENR2 {}XBOOLE-0K1 implies (Y <>HIDDENR2 {}XBOOLE-0K1 implies domRELAT-1K1 ([:ZFMISC-1K2 X,Y :]) =XBOOLE-0R4 X & rngRELAT-1K2 ([:ZFMISC-1K2 X,Y :]) =XBOOLE-0R4 Y)"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume "X <>HIDDENR2 {}XBOOLE-0K1"
    then obtain a where
      [ty]:"a be objectHIDDENM1" and 
      A1: "a inHIDDENR3 X"
      using xboole_0_def_1 sorry
    assume "Y <>HIDDENR2 {}XBOOLE-0K1"
    then obtain b where
      [ty]:"b be objectHIDDENM1" and 
      A2: "b inHIDDENR3 Y"
      using xboole_0_def_1 sorry
    have A3: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :])"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 X"
      then have "[TARSKIK4 x,b ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
        using A2 zfmisc_1_th_87 sorry
      thus " ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
         sorry
    qed "sorry"
    have " for x be objectHIDDENM1 holds ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]) implies x inHIDDENR3 X"
      using zfmisc_1_th_87 sorry
    thus "domRELAT-1K1 ([:ZFMISC-1K2 X,Y :]) =XBOOLE-0R4 X"
      using A3 xtuple_0_def_12 sorry
    have A4: " for y be objectHIDDENM1 holds y inHIDDENR3 Y implies ( ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :])"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 Y"
      then have "[TARSKIK4 a,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
        using A1 zfmisc_1_th_87 sorry
      thus " ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
         sorry
    qed "sorry"
    have " for y be objectHIDDENM1 holds ( ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]) implies y inHIDDENR3 Y"
      using zfmisc_1_th_87 sorry
    thus "rngRELAT-1K2 ([:ZFMISC-1K2 X,Y :]) =XBOOLE-0R4 Y"
      using A4 xtuple_0_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_161:
" for Q be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds domRELAT-1K1 R =XBOOLE-0R4 {}XBOOLE-0K1 & domRELAT-1K1 Q =XBOOLE-0R4 {}XBOOLE-0K1 implies R =RELAT-1R1 Q"
   sorry

mtheorem relat_1_th_162:
" for Q be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds rngRELAT-1K2 R =XBOOLE-0R4 {}XBOOLE-0K1 & rngRELAT-1K2 Q =XBOOLE-0R4 {}XBOOLE-0K1 implies R =RELAT-1R1 Q"
   sorry

mtheorem relat_1_th_163:
" for Q be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds  for S be RelationRELAT-1M1 holds domRELAT-1K1 R =XBOOLE-0R4 domRELAT-1K1 Q implies domRELAT-1K1 (S *RELAT-1K6 R) =XBOOLE-0R4 domRELAT-1K1 (S *RELAT-1K6 Q)"
proof-
  have " for Q be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds  for S be RelationRELAT-1M1 holds domRELAT-1K1 R =XBOOLE-0R4 domRELAT-1K1 Q implies domRELAT-1K1 (S *RELAT-1K6 R) =HIDDENR1 domRELAT-1K1 (S *RELAT-1K6 Q)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix Q assume [ty]: "Q be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix S assume [ty]: "S be RelationRELAT-1M1"
    assume A1: "domRELAT-1K1 R =XBOOLE-0R4 domRELAT-1K1 Q"
    have "domRELAT-1K1 (S *RELAT-1K6 R) =HIDDENR1 S \<inverse>RELAT-1K11 (domRELAT-1K1 R)"
      using relat_1_th_147 sorry
    also have "... = domRELAT-1K1 (S *RELAT-1K6 Q)"
      using A1 relat_1_th_147 sorry
    finally show "domRELAT-1K1 (S *RELAT-1K6 R) =HIDDENR1 domRELAT-1K1 (S *RELAT-1K6 Q)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_164:
" for Q be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds  for S be RelationRELAT-1M1 holds rngRELAT-1K2 R =XBOOLE-0R4 rngRELAT-1K2 Q implies rngRELAT-1K2 (R *RELAT-1K6 S) =XBOOLE-0R4 rngRELAT-1K2 (Q *RELAT-1K6 S)"
proof-
  have " for Q be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds  for S be RelationRELAT-1M1 holds rngRELAT-1K2 R =XBOOLE-0R4 rngRELAT-1K2 Q implies rngRELAT-1K2 (R *RELAT-1K6 S) =HIDDENR1 rngRELAT-1K2 (Q *RELAT-1K6 S)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix Q assume [ty]: "Q be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix S assume [ty]: "S be RelationRELAT-1M1"
    assume A1: "rngRELAT-1K2 R =XBOOLE-0R4 rngRELAT-1K2 Q"
    have "rngRELAT-1K2 (R *RELAT-1K6 S) =HIDDENR1 S .:RELAT-1K10 rngRELAT-1K2 R"
      using relat_1_th_127 sorry
    also have "... = rngRELAT-1K2 (Q *RELAT-1K6 S)"
      using A1 relat_1_th_127 sorry
    finally show "rngRELAT-1K2 (R *RELAT-1K6 S) =HIDDENR1 rngRELAT-1K2 (Q *RELAT-1K6 S)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef relat_1_def_17 ("CoimRELAT-1K13'( _ , _ ')" [0,0]164 ) where
  mlet "R be RelationRELAT-1M1", "x be objectHIDDENM1"
"func CoimRELAT-1K13(R,x) \<rightarrow> setHIDDENM2 equals
  R \<inverse>RELAT-1K11 {TARSKIK1 x}"
proof-
  (*coherence*)
    show "R \<inverse>RELAT-1K11 {TARSKIK1 x} be setHIDDENM2"
       sorry
qed "sorry"

mtheorem relat_1_cl_29:
  mlet "R be trivialSUBSET-1V2\<bar>RelationRELAT-1M1"
"cluster domRELAT-1K1 R as-term-is trivialSUBSET-1V2"
proof
(*coherence*)
  show "domRELAT-1K1 R be trivialSUBSET-1V2"
  proof-
    have "domRELAT-1K1 R be trivialZFMISC-1V1"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 R implies (y inHIDDENR3 domRELAT-1K1 R implies x =HIDDENR1 y)"
      proof(rule ballI,rule ballI,rule impI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "x inHIDDENR3 domRELAT-1K1 R"
        then obtain a where
          [ty]:"a be objectHIDDENM1" and 
          A1: "[TARSKIK4 x,a ] inHIDDENR3 R"
          using xtuple_0_def_12 sorry
        assume "y inHIDDENR3 domRELAT-1K1 R"
        then obtain b where
          [ty]:"b be objectHIDDENM1" and 
          A2: "[TARSKIK4 y,b ] inHIDDENR3 R"
          using xtuple_0_def_12 sorry
        have "[TARSKIK4 x,a ] =HIDDENR1 [TARSKIK4 y,b ]"
          using A1 A2 zfmisc_1_def_10 sorry
        thus "x =HIDDENR1 y"
          using xtuple_0_th_1 sorry
      qed "sorry"
      thus "domRELAT-1K1 R be trivialZFMISC-1V1"
        using zfmisc_1_def_10 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem relat_1_cl_30:
  mlet "R be trivialSUBSET-1V2\<bar>RelationRELAT-1M1"
"cluster rngRELAT-1K2 R as-term-is trivialSUBSET-1V2"
proof
(*coherence*)
  show "rngRELAT-1K2 R be trivialSUBSET-1V2"
  proof-
    have "rngRELAT-1K2 R be trivialZFMISC-1V1"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 rngRELAT-1K2 R implies (y inHIDDENR3 rngRELAT-1K2 R implies x =HIDDENR1 y)"
      proof(rule ballI,rule ballI,rule impI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "x inHIDDENR3 rngRELAT-1K2 R"
        then obtain a where
          [ty]:"a be objectHIDDENM1" and 
          A1: "[TARSKIK4 a,x ] inHIDDENR3 R"
          using xtuple_0_def_13 sorry
        assume "y inHIDDENR3 rngRELAT-1K2 R"
        then obtain b where
          [ty]:"b be objectHIDDENM1" and 
          A2: "[TARSKIK4 b,y ] inHIDDENR3 R"
          using xtuple_0_def_13 sorry
        have "[TARSKIK4 a,x ] =HIDDENR1 [TARSKIK4 b,y ]"
          using A1 A2 zfmisc_1_def_10 sorry
        thus "x =HIDDENR1 y"
          using xtuple_0_th_1 sorry
      qed "sorry"
      thus "rngRELAT-1K2 R be trivialZFMISC-1V1"
        using zfmisc_1_def_10 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem relat_1_th_165:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds  for S be RelationRELAT-1M1 holds rngRELAT-1K2 R c=TARSKIR1 domRELAT-1K1 (S  |RELAT-1K8 X) implies R *RELAT-1K6 S  |RELAT-1K8 X =RELAT-1R1 R *RELAT-1K6 S"
proof-
  have " for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds  for S be RelationRELAT-1M1 holds rngRELAT-1K2 R c=TARSKIR1 domRELAT-1K1 (S  |RELAT-1K8 X) implies R *RELAT-1K6 S  |RELAT-1K8 X =RELAT-1R1 R *RELAT-1K6 S"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix S assume [ty]: "S be RelationRELAT-1M1"
    assume A1: "rngRELAT-1K2 R c=TARSKIR1 domRELAT-1K1 (S  |RELAT-1K8 X)"
    have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds ([TARSKIK4 a,b ] inHIDDENR3 R *RELAT-1K6 S  |RELAT-1K8 X implies [TARSKIK4 a,b ] inHIDDENR3 R *RELAT-1K6 S) & ([TARSKIK4 a,b ] inHIDDENR3 R *RELAT-1K6 S implies [TARSKIK4 a,b ] inHIDDENR3 R *RELAT-1K6 S  |RELAT-1K8 X)"
    proof(rule ballI,rule ballI,rule conjMI,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      fix b assume [ty]: "b be objectHIDDENM1"
      have "R *RELAT-1K6 S  |RELAT-1K8 X c=RELAT-1R2 R *RELAT-1K6 S"
        using relat_1_th_29 relat_1_th_59 sorry
      thus "[TARSKIK4 a,b ] inHIDDENR3 R *RELAT-1K6 S  |RELAT-1K8 X implies [TARSKIK4 a,b ] inHIDDENR3 R *RELAT-1K6 S"
         sorry
      assume "[TARSKIK4 a,b ] inHIDDENR3 R *RELAT-1K6 S"
      then obtain c where
        [ty]:"c be objectHIDDENM1" and 
        A2: "[TARSKIK4 a,c ] inHIDDENR3 R"and A3: "[TARSKIK4 c,b ] inHIDDENR3 S"
        using relat_1_def_8 sorry
      have "c inHIDDENR3 rngRELAT-1K2 R"
        using A2 xtuple_0_def_13 sorry
      then have "c inHIDDENR3 X"
        using A1 relat_1_th_57 sorry
      then have "[TARSKIK4 c,b ] inHIDDENR3 S  |RELAT-1K8 X"
        using A3 relat_1_def_11 sorry
      thus "[TARSKIK4 a,b ] inHIDDENR3 R *RELAT-1K6 S  |RELAT-1K8 X"
        using A2 relat_1_def_8 sorry
    qed "sorry"
    thus "R *RELAT-1K6 S  |RELAT-1K8 X =RELAT-1R1 R *RELAT-1K6 S"
      using relat_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_166:
" for A be setHIDDENM2 holds  for Q be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds Q  |RELAT-1K8 A =RELAT-1R1 R  |RELAT-1K8 A implies Q .:RELAT-1K10 A =XBOOLE-0R4 R .:RELAT-1K10 A"
proof-
  have " for A be setHIDDENM2 holds  for Q be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds Q  |RELAT-1K8 A =RELAT-1R1 R  |RELAT-1K8 A implies Q .:RELAT-1K10 A =HIDDENR1 R .:RELAT-1K10 A"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix Q assume [ty]: "Q be RelationRELAT-1M1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume "Q  |RELAT-1K8 A =RELAT-1R1 R  |RELAT-1K8 A"
    then have "Q .:RELAT-1K10 A =HIDDENR1 (R  |RELAT-1K8 A).:RELAT-1K10 A"
      using relat_1_th_129 sorry
    also have "... = R .:RELAT-1K10 A"
      using relat_1_th_129 sorry
    finally show "Q .:RELAT-1K10 A =HIDDENR1 R .:RELAT-1K10 A"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef relat_1_def_18 (" _ -definedRELAT-1V4" [70]70 ) where
  mlet "X be setHIDDENM2"
"attr X -definedRELAT-1V4 for RelationRELAT-1M1 means
  (\<lambda>R. domRELAT-1K1 R c=TARSKIR1 X)"..

mdef relat_1_def_19 (" _ -valuedRELAT-1V5" [70]70 ) where
  mlet "X be setHIDDENM2"
"attr X -valuedRELAT-1V5 for RelationRELAT-1M1 means
  (\<lambda>R. rngRELAT-1K2 R c=TARSKIR1 X)"..

mlemma relat_1_lm_1:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds {}XBOOLE-0K1 be X -definedRELAT-1V4\<bar>Y -valuedRELAT-1V5"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds {}XBOOLE-0K1 be X -definedRELAT-1V4 & {}XBOOLE-0K1 be Y -valuedRELAT-1V5"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "domRELAT-1K1 ({}XBOOLE-0K1) c=RELAT-1R2 X & rngRELAT-1K2 ({}XBOOLE-0K1) c=RELAT-1R2 Y"
    proof-
      show "domRELAT-1K1 ({}XBOOLE-0K1) c=RELAT-1R2 X & rngRELAT-1K2 ({}XBOOLE-0K1) c=RELAT-1R2 Y"
         sorry
    qed
    thus "{}XBOOLE-0K1 be X -definedRELAT-1V4 & {}XBOOLE-0K1 be Y -valuedRELAT-1V5"
      using relat_1_def_18 relat_1_def_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_cl_31:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"cluster X -definedRELAT-1V4\<bar>Y -valuedRELAT-1V5 for RelationRELAT-1M1"
proof
(*existence*)
  show " ex it be RelationRELAT-1M1 st it be X -definedRELAT-1V4\<bar>Y -valuedRELAT-1V5"
  proof-
    have " ex tVar13 be RelationRELAT-1M1 st tVar13 be X -definedRELAT-1V4 & tVar13 be Y -valuedRELAT-1V5"
    proof-
      show " ex tVar13 be RelationRELAT-1M1 st tVar13 be X -definedRELAT-1V4 & tVar13 be Y -valuedRELAT-1V5"
      proof(rule bexI[of _ "{}XBOOLE-0K1"])
        show "{}XBOOLE-0K1 be X -definedRELAT-1V4 & {}XBOOLE-0K1 be Y -valuedRELAT-1V5"
          using relat_1_lm_1 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem relat_1_th_167:
" for D be setHIDDENM2 holds  for R be D -valuedRELAT-1V5\<bar>RelationRELAT-1M1 holds  for y be objectHIDDENM1 holds y inHIDDENR3 rngRELAT-1K2 R implies y inHIDDENR3 D"
proof-
  have " for D be setHIDDENM2 holds  for R be D -valuedRELAT-1V5\<bar>RelationRELAT-1M1 holds  for y be objectHIDDENM1 holds  not (y inHIDDENR3 rngRELAT-1K2 R &  not y inHIDDENR3 D)"
  proof(rule ballI,rule ballI)
    fix D assume [ty]: "D be setHIDDENM2"
    fix R assume [ty]: "R be D -valuedRELAT-1V5\<bar>RelationRELAT-1M1"
    have "rngRELAT-1K2 R c=TARSKIR1 D"
      using relat_1_def_19 sorry
    thus " for y be objectHIDDENM1 holds  not (y inHIDDENR3 rngRELAT-1K2 R &  not y inHIDDENR3 D)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_cl_32:
  mlet "X be setHIDDENM2", "A be setHIDDENM2", "R be A -valuedRELAT-1V5\<bar>RelationRELAT-1M1"
"cluster R  |RELAT-1K8 X as-term-is A -valuedRELAT-1V5"
proof
(*coherence*)
  show "R  |RELAT-1K8 X be A -valuedRELAT-1V5"
  proof-
    have Cut2768: "rngRELAT-1K2 (R  |RELAT-1K8 X) c=TARSKIR1 rngRELAT-1K2 R & rngRELAT-1K2 R c=TARSKIR1 A"
      using relat_1_def_19 relat_1_th_59 xtuple_0_th_9 sorry
    have "rngRELAT-1K2 (R  |RELAT-1K8 X) c=TARSKIR1 A"
    proof-
      show "rngRELAT-1K2 (R  |RELAT-1K8 X) c=TARSKIR1 A"
        using Cut2768 sorry
    qed
    thus "R  |RELAT-1K8 X be A -valuedRELAT-1V5"
      using relat_1_def_19 sorry
  qed
qed "sorry"

mtheorem relat_1_cl_33:
  mlet "X be setHIDDENM2", "A be setHIDDENM2", "R be A -definedRELAT-1V4\<bar>RelationRELAT-1M1"
"cluster R  |RELAT-1K8 X as-term-is A -definedRELAT-1V4\<bar>X -definedRELAT-1V4"
proof
(*coherence*)
  show "R  |RELAT-1K8 X be A -definedRELAT-1V4\<bar>X -definedRELAT-1V4"
  proof-
    have "R  |RELAT-1K8 X be A -definedRELAT-1V4 & R  |RELAT-1K8 X be X -definedRELAT-1V4"
    proof-
      have Cut2779: "domRELAT-1K1 (R  |RELAT-1K8 X) c=TARSKIR1 domRELAT-1K1 R & domRELAT-1K1 R c=TARSKIR1 A"
        using relat_1_def_18 relat_1_th_57 sorry
      have "domRELAT-1K1 (R  |RELAT-1K8 X) c=TARSKIR1 A & R  |RELAT-1K8 X be X -definedRELAT-1V4"
      proof(rule conjMI)
        show "domRELAT-1K1 (R  |RELAT-1K8 X) c=TARSKIR1 A"
          using Cut2779 sorry
        have "domRELAT-1K1 (R  |RELAT-1K8 X) c=TARSKIR1 X"
        proof-
          show "domRELAT-1K1 (R  |RELAT-1K8 X) c=TARSKIR1 X"
            using relat_1_th_57 sorry
        qed
        thus "R  |RELAT-1K8 X be X -definedRELAT-1V4"
          using relat_1_def_18 sorry
      qed
      thus "R  |RELAT-1K8 X be A -definedRELAT-1V4 & R  |RELAT-1K8 X be X -definedRELAT-1V4"
        using relat_1_def_18 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem relat_1_cl_34:
  mlet "X be setHIDDENM2"
"cluster idRELAT-1K7 X as-term-is X -definedRELAT-1V4\<bar>X -valuedRELAT-1V5"
proof
(*coherence*)
  show "idRELAT-1K7 X be X -definedRELAT-1V4\<bar>X -valuedRELAT-1V5"
     sorry
qed "sorry"

mtheorem relat_1_cl_35:
  mlet "A be setHIDDENM2", "R be A -valuedRELAT-1V5\<bar>RelationRELAT-1M1", "S be RelationRELAT-1M1"
"cluster S *RELAT-1K6 R as-term-is A -valuedRELAT-1V5"
proof
(*coherence*)
  show "S *RELAT-1K6 R be A -valuedRELAT-1V5"
  proof-
    have Cut2799: "rngRELAT-1K2 R c=TARSKIR1 A & rngRELAT-1K2 (S *RELAT-1K6 R) c=TARSKIR1 rngRELAT-1K2 R"
      using relat_1_def_19 relat_1_th_26 sorry
    have "rngRELAT-1K2 (S *RELAT-1K6 R) c=TARSKIR1 A"
    proof-
      show "rngRELAT-1K2 (S *RELAT-1K6 R) c=TARSKIR1 A"
        using Cut2799 sorry
    qed
    thus "S *RELAT-1K6 R be A -valuedRELAT-1V5"
      using relat_1_def_19 sorry
  qed
qed "sorry"

mtheorem relat_1_cl_36:
  mlet "A be setHIDDENM2", "R be A -definedRELAT-1V4\<bar>RelationRELAT-1M1", "S be RelationRELAT-1M1"
"cluster R *RELAT-1K6 S as-term-is A -definedRELAT-1V4"
proof
(*coherence*)
  show "R *RELAT-1K6 S be A -definedRELAT-1V4"
  proof-
    have Cut2810: "domRELAT-1K1 R c=TARSKIR1 A & domRELAT-1K1 (R *RELAT-1K6 S) c=TARSKIR1 domRELAT-1K1 R"
      using relat_1_def_18 relat_1_th_25 sorry
    have "domRELAT-1K1 (R *RELAT-1K6 S) c=TARSKIR1 A"
    proof-
      show "domRELAT-1K1 (R *RELAT-1K6 S) c=TARSKIR1 A"
        using Cut2810 sorry
    qed
    thus "R *RELAT-1K6 S be A -definedRELAT-1V4"
      using relat_1_def_18 sorry
  qed
qed "sorry"

mtheorem relat_1_th_168:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds x inHIDDENR3 X implies ImRELAT-1K12([:ZFMISC-1K2 X,Y :],x) =XBOOLE-0R4 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds x inHIDDENR3 X implies ImRELAT-1K12([:ZFMISC-1K2 X,Y :],x) =XBOOLE-0R4 Y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "x inHIDDENR3 X"
    have "ImRELAT-1K12([:ZFMISC-1K2 X,Y :],x) c=TARSKIR1 Y & Y c=TARSKIR1 ImRELAT-1K12([:ZFMISC-1K2 X,Y :],x)"
    proof(rule conjMI)
      show "ImRELAT-1K12([:ZFMISC-1K2 X,Y :],x) c=TARSKIR1 Y"
      proof-
        have " for y be objectHIDDENM1 holds y inHIDDENR3 ImRELAT-1K12([:ZFMISC-1K2 X,Y :],x) implies y inHIDDENR3 Y"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "y inHIDDENR3 ImRELAT-1K12([:ZFMISC-1K2 X,Y :],x)"
          then have " ex z be objectHIDDENM1 st [TARSKIK4 z,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :] & z inHIDDENR3 {TARSKIK1 x}"
            using relat_1_def_13 sorry
          thus "y inHIDDENR3 Y"
            using zfmisc_1_th_87 sorry
        qed "sorry"
        thus "ImRELAT-1K12([:ZFMISC-1K2 X,Y :],x) c=TARSKIR1 Y"
          using tarski_def_3 sorry
      qed
      have " for y be objectHIDDENM1 holds y inHIDDENR3 Y implies y inHIDDENR3 ImRELAT-1K12([:ZFMISC-1K2 X,Y :],x)"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 Y"
        then have A2: "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
          using A1 zfmisc_1_th_87 sorry
        have "x inHIDDENR3 {TARSKIK1 x}"
          using tarski_def_1 sorry
        thus "y inHIDDENR3 ImRELAT-1K12([:ZFMISC-1K2 X,Y :],x)"
          using A2 relat_1_def_13 sorry
      qed "sorry"
      thus "Y c=TARSKIR1 ImRELAT-1K12([:ZFMISC-1K2 X,Y :],x)"
        using tarski_def_3 sorry
    qed
    thus "ImRELAT-1K12([:ZFMISC-1K2 X,Y :],x) =XBOOLE-0R4 Y"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_169:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds [TARSKIK4 x,y ] inHIDDENR3 R iff y inHIDDENR3 ImRELAT-1K12(R,x)"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds ([TARSKIK4 x,y ] inHIDDENR3 R implies y inHIDDENR3 ImRELAT-1K12(R,x)) & (y inHIDDENR3 ImRELAT-1K12(R,x) implies [TARSKIK4 x,y ] inHIDDENR3 R)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "[TARSKIK4 x,y ] inHIDDENR3 R implies y inHIDDENR3 ImRELAT-1K12(R,x)"
    proof-
      have " not ([TARSKIK4 x,y ] inHIDDENR3 R &  not y inHIDDENR3 ImRELAT-1K12(R,x))"
      proof-
        have "x inHIDDENR3 {TARSKIK1 x}"
          using tarski_def_1 sorry
        thus " not ([TARSKIK4 x,y ] inHIDDENR3 R &  not y inHIDDENR3 ImRELAT-1K12(R,x))"
          using relat_1_def_13 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume "y inHIDDENR3 ImRELAT-1K12(R,x)"
    then have " ex z be objectHIDDENM1 st [TARSKIK4 z,y ] inHIDDENR3 R & z inHIDDENR3 {TARSKIK1 x}"
      using relat_1_def_13 sorry
    thus "[TARSKIK4 x,y ] inHIDDENR3 R"
      using tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_170:
" for x be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds x inHIDDENR3 domRELAT-1K1 R iff ImRELAT-1K12(R,x) <>HIDDENR2 {}XBOOLE-0K1"
proof-
  have " for x be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds (x inHIDDENR3 domRELAT-1K1 R implies ImRELAT-1K12(R,x) <>HIDDENR2 {}XBOOLE-0K1) & (ImRELAT-1K12(R,x) <>HIDDENR2 {}XBOOLE-0K1 implies x inHIDDENR3 domRELAT-1K1 R)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "x inHIDDENR3 domRELAT-1K1 R implies ImRELAT-1K12(R,x) <>HIDDENR2 {}XBOOLE-0K1"
    proof(rule impI)
      assume "x inHIDDENR3 domRELAT-1K1 R"
      then have " ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R"
        using xtuple_0_def_12 sorry
      thus "ImRELAT-1K12(R,x) <>HIDDENR2 {}XBOOLE-0K1"
        using relat_1_th_169 sorry
    qed
    assume "ImRELAT-1K12(R,x) <>HIDDENR2 {}XBOOLE-0K1"
    then obtain y where
      [ty]:"y be objectHIDDENM1" and 
      A1: "y inHIDDENR3 ImRELAT-1K12(R,x)"
      using xboole_0_def_1 sorry
    have "[TARSKIK4 x,y ] inHIDDENR3 R"
      using A1 relat_1_th_169 sorry
    thus "x inHIDDENR3 domRELAT-1K1 R"
      using xtuple_0_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_171:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds {}XBOOLE-0K1 be X -definedRELAT-1V4\<bar>Y -valuedRELAT-1V5"
  using relat_1_lm_1 sorry

mtheorem relat_1_cl_37:
"cluster emptyXBOOLE-0V1 also-is non-emptyRELAT-1V2 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be emptyXBOOLE-0V1 implies it be non-emptyRELAT-1V2"
     sorry
qed "sorry"

mtheorem relat_1_cl_38:
  mlet "X be setHIDDENM2", "R be X -definedRELAT-1V4\<bar>RelationRELAT-1M1"
"cluster note-that X -definedRELAT-1V4 for SubsetSUBSET-1M2-of R"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of R holds it be X -definedRELAT-1V4"
  proof-
    have " for S be SubsetSUBSET-1M2-of R holds S be X -definedRELAT-1V4"
    proof(rule ballI)
      fix S assume [ty]: "S be SubsetSUBSET-1M2-of R"
      have A1: "domRELAT-1K1 R c=TARSKIR1 X"
        using relat_1_def_18 sorry
      have Cut2877: "domRELAT-1K1 S c=TARSKIR1 domRELAT-1K1 R"
        using xtuple_0_th_8 sorry
      have "domRELAT-1K1 S c=TARSKIR1 X"
      proof-
        show "domRELAT-1K1 S c=TARSKIR1 X"
          using A1 Cut2877 sorry
      qed
      thus "S be X -definedRELAT-1V4"
        using relat_1_def_18 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem relat_1_cl_39:
  mlet "X be setHIDDENM2", "R be X -valuedRELAT-1V5\<bar>RelationRELAT-1M1"
"cluster note-that X -valuedRELAT-1V5 for SubsetSUBSET-1M2-of R"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of R holds it be X -valuedRELAT-1V5"
  proof-
    have " for S be SubsetSUBSET-1M2-of R holds S be X -valuedRELAT-1V5"
    proof(rule ballI)
      fix S assume [ty]: "S be SubsetSUBSET-1M2-of R"
      have A1: "rngRELAT-1K2 R c=TARSKIR1 X"
        using relat_1_def_19 sorry
      have Cut2887: "rngRELAT-1K2 S c=TARSKIR1 rngRELAT-1K2 R"
        using xtuple_0_th_9 sorry
      have "rngRELAT-1K2 S c=TARSKIR1 X"
      proof-
        show "rngRELAT-1K2 S c=TARSKIR1 X"
          using A1 Cut2887 sorry
      qed
      thus "S be X -valuedRELAT-1V5"
        using relat_1_def_19 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem relat_1_th_172:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds X missesXBOOLE-0R1 Y implies (R  |RELAT-1K8 X) |RELAT-1K8 Y =RELAT-1R1 {}XBOOLE-0K1"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds X missesXBOOLE-0R1 Y implies (R  |RELAT-1K8 X) |RELAT-1K8 Y =HIDDENR1 {}XBOOLE-0K1"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume "X missesXBOOLE-0R1 Y"
    then have "(R  |RELAT-1K8 X) |RELAT-1K8 Y =HIDDENR1 R  |RELAT-1K8 {}XBOOLE-0K1"
      using relat_1_th_71 sorry
    also have "... = {}XBOOLE-0K1"
       sorry
    finally show "(R  |RELAT-1K8 X) |RELAT-1K8 Y =HIDDENR1 {}XBOOLE-0K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_173:
" for x be objectHIDDENM1 holds fieldRELAT-1K3 {TARSKIK1 [TARSKIK4 x,x ] } =XBOOLE-0R4 {TARSKIK1 x}"
proof-
  have " for x be objectHIDDENM1 holds fieldRELAT-1K3 {TARSKIK1 [TARSKIK4 x,x ] } =HIDDENR1 {TARSKIK1 x}"
  proof(rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    have "fieldRELAT-1K3 {TARSKIK1 [TARSKIK4 x,x ] } =HIDDENR1 {TARSKIK2 x,x }"
      using relat_1_th_17 sorry
    also have "... = {TARSKIK1 x}"
      using enumset1_th_29 sorry
    finally show "fieldRELAT-1K3 {TARSKIK1 [TARSKIK4 x,x ] } =HIDDENR1 {TARSKIK1 x}"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_reduce_8:
  mlet "X be setHIDDENM2", "R be X -definedRELAT-1V4\<bar>RelationRELAT-1M1"
"reduce R  |RELAT-1K8 X to R"
proof
(*reducibility*)
  show "R  |RELAT-1K8 X =HIDDENR1 R"
  proof-
    have "R  |RELAT-1K8 X =RELAT-1R1 R"
    proof-
      have "domRELAT-1K1 R c=TARSKIR1 X"
        using relat_1_def_18 sorry
      thus "R  |RELAT-1K8 X =RELAT-1R1 R"
        using relat_1_th_68 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem relat_1_reduce_9:
  mlet "Y be setHIDDENM2", "R be Y -valuedRELAT-1V5\<bar>RelationRELAT-1M1"
"reduce Y  |`RELAT-1K9 R to R"
proof
(*reducibility*)
  show "Y  |`RELAT-1K9 R =HIDDENR1 R"
  proof-
    have "Y  |`RELAT-1K9 R =RELAT-1R1 R"
    proof-
      have "rngRELAT-1K2 R c=TARSKIR1 Y"
        using relat_1_def_19 sorry
      thus "Y  |`RELAT-1K9 R =RELAT-1R1 R"
        using relat_1_th_94 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem relat_1_th_174:
" for X be setHIDDENM2 holds  for R be X -definedRELAT-1V4\<bar>RelationRELAT-1M1 holds R =RELAT-1R1 R  |RELAT-1K8 X"
   sorry

mtheorem relat_1_th_175:
" for X be setHIDDENM2 holds  for S be RelationRELAT-1M1 holds  for R be X -definedRELAT-1V4\<bar>RelationRELAT-1M1 holds R c=RELAT-1R2 S implies R c=RELAT-1R2 S  |RELAT-1K8 X"
proof-
  have " for X be setHIDDENM2 holds  for S be RelationRELAT-1M1 holds  for R be X -definedRELAT-1V4\<bar>RelationRELAT-1M1 holds  not (R c=RELAT-1R2 S &  not R c=RELAT-1R2 S  |RELAT-1K8 X)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix S assume [ty]: "S be RelationRELAT-1M1"
    fix R assume [ty]: "R be X -definedRELAT-1V4\<bar>RelationRELAT-1M1"
    have "R =RELAT-1R1 R  |RELAT-1K8 X"
       sorry
    thus " not (R c=RELAT-1R2 S &  not R c=RELAT-1R2 S  |RELAT-1K8 X)"
      using relat_1_th_76 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_176:
" for A be setHIDDENM2 holds  for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds domRELAT-1K1 R c=TARSKIR1 X implies R \\SUBSET-1K6 R  |RELAT-1K8 A =RELAT-1R1 R  |RELAT-1K8 (X \\SUBSET-1K6 A)"
proof-
  have " for A be setHIDDENM2 holds  for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds domRELAT-1K1 R c=TARSKIR1 X implies R \\SUBSET-1K6 R  |RELAT-1K8 A =HIDDENR1 R  |RELAT-1K8 (X \\SUBSET-1K6 A)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume "domRELAT-1K1 R c=TARSKIR1 X"
    then have "R \\SUBSET-1K6 R  |RELAT-1K8 A =HIDDENR1 R  |RELAT-1K8 X \\SUBSET-1K6 R  |RELAT-1K8 A"
      using relat_1_th_68 sorry
    also have "... = R  |RELAT-1K8 (X \\SUBSET-1K6 A)"
      using relat_1_th_80 sorry
    finally show "R \\SUBSET-1K6 R  |RELAT-1K8 A =HIDDENR1 R  |RELAT-1K8 (X \\SUBSET-1K6 A)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_177:
" for A be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds domRELAT-1K1 (R \\SUBSET-1K6 R  |RELAT-1K8 A) =XBOOLE-0R4 domRELAT-1K1 R \\SUBSET-1K6 A"
proof-
  have " for A be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds domRELAT-1K1 (R \\SUBSET-1K6 R  |RELAT-1K8 A) =HIDDENR1 domRELAT-1K1 R \\SUBSET-1K6 A"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have "R \\SUBSET-1K6 R  |RELAT-1K8 A =RELAT-1R1 R  |RELAT-1K8 (domRELAT-1K1 R \\SUBSET-1K6 A)"
      using relat_1_th_176 sorry
    then have "domRELAT-1K1 (R \\SUBSET-1K6 R  |RELAT-1K8 A) =HIDDENR1 domRELAT-1K1 R /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 R)\<^esub> (domRELAT-1K1 R \\SUBSET-1K6 A)"
      using relat_1_th_61 sorry
    also have "... = domRELAT-1K1 R /\\XBOOLE-0K3 domRELAT-1K1 R \\SUBSET-1K6 A"
      using xboole_1_th_49 sorry
    also have "... = domRELAT-1K1 R \\SUBSET-1K6 A"
       sorry
    finally show "domRELAT-1K1 (R \\SUBSET-1K6 R  |RELAT-1K8 A) =HIDDENR1 domRELAT-1K1 R \\SUBSET-1K6 A"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_178:
" for A be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds domRELAT-1K1 R \\SUBSET-1K6 domRELAT-1K1 (R  |RELAT-1K8 A) =XBOOLE-0R4 domRELAT-1K1 (R \\SUBSET-1K6 R  |RELAT-1K8 A)"
proof-
  have " for A be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds domRELAT-1K1 R \\SUBSET-1K6 domRELAT-1K1 (R  |RELAT-1K8 A) =HIDDENR1 domRELAT-1K1 (R \\SUBSET-1K6 R  |RELAT-1K8 A)"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have "domRELAT-1K1 R \\SUBSET-1K6 domRELAT-1K1 (R  |RELAT-1K8 A) =HIDDENR1 domRELAT-1K1 R \\SUBSET-1K6 A /\\XBOOLE-0K3 domRELAT-1K1 R"
      using relat_1_th_61 sorry
    also have "... = domRELAT-1K1 R \\SUBSET-1K6 A"
      using xboole_1_th_47 sorry
    also have "... = domRELAT-1K1 (R \\SUBSET-1K6 R  |RELAT-1K8 A)"
      using relat_1_th_177 sorry
    finally show "domRELAT-1K1 R \\SUBSET-1K6 domRELAT-1K1 (R  |RELAT-1K8 A) =HIDDENR1 domRELAT-1K1 (R \\SUBSET-1K6 R  |RELAT-1K8 A)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_179:
" for R be RelationRELAT-1M1 holds  for S be RelationRELAT-1M1 holds domRELAT-1K1 R missesXBOOLE-0R1 domRELAT-1K1 S implies R missesXBOOLE-0R1 S"
proof-
  have " for R be RelationRELAT-1M1 holds  for S be RelationRELAT-1M1 holds domRELAT-1K1 R missesXBOOLE-0R1 domRELAT-1K1 S implies (R meetsXBOOLE-0R5 S implies  False )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix S assume [ty]: "S be RelationRELAT-1M1"
    assume A1: "domRELAT-1K1 R missesXBOOLE-0R1 domRELAT-1K1 S"
    assume "R meetsXBOOLE-0R5 S"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A2: "x inHIDDENR3 R"and A3: "x inHIDDENR3 S"
      using xboole_0_th_3 sorry
    obtain y z where
      [ty]:"y be objectHIDDENM1" "z be objectHIDDENM1" and 
      A4: "x =HIDDENR1 [TARSKIK4 y,z ]"
      using A2 relat_1_def_1 sorry
    have "y inHIDDENR3 domRELAT-1K1 R & y inHIDDENR3 domRELAT-1K1 S"
      using A2 A3 A4 xtuple_0_def_12 sorry
    thus " False "
      using A1 xboole_0_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_180:
" for R be RelationRELAT-1M1 holds  for S be RelationRELAT-1M1 holds rngRELAT-1K2 R missesXBOOLE-0R1 rngRELAT-1K2 S implies R missesXBOOLE-0R1 S"
proof-
  have " for R be RelationRELAT-1M1 holds  for S be RelationRELAT-1M1 holds rngRELAT-1K2 R missesXBOOLE-0R1 rngRELAT-1K2 S implies (R meetsXBOOLE-0R5 S implies  False )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix S assume [ty]: "S be RelationRELAT-1M1"
    assume A1: "rngRELAT-1K2 R missesXBOOLE-0R1 rngRELAT-1K2 S"
    assume "R meetsXBOOLE-0R5 S"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A2: "x inHIDDENR3 R"and A3: "x inHIDDENR3 S"
      using xboole_0_th_3 sorry
    obtain y z where
      [ty]:"y be objectHIDDENM1" "z be objectHIDDENM1" and 
      A4: "x =HIDDENR1 [TARSKIK4 y,z ]"
      using A2 relat_1_def_1 sorry
    have "z inHIDDENR3 rngRELAT-1K2 R & z inHIDDENR3 rngRELAT-1K2 S"
      using A2 A3 A4 xtuple_0_def_13 sorry
    thus " False "
      using A1 xboole_0_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_181:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds X c=TARSKIR1 Y implies (R \\SUBSET-1K6 R  |RELAT-1K8 Y) |RELAT-1K8 X =RELAT-1R1 {}XBOOLE-0K1"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds X c=TARSKIR1 Y implies (R \\SUBSET-1K6 R  |RELAT-1K8 Y) |RELAT-1K8 X =RELAT-1R1 {}XBOOLE-0K1"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume A1: "X c=TARSKIR1 Y"
    have "domRELAT-1K1 R /\\XBOOLE-0K3 X c=TARSKIR1 X"
      using xboole_1_th_17 sorry
    then have A2: "domRELAT-1K1 R /\\XBOOLE-0K3 X c=TARSKIR1 Y"
      using A1 sorry
    have "domRELAT-1K1 (R \\SUBSET-1K6 R  |RELAT-1K8 Y) =XBOOLE-0R4 domRELAT-1K1 R \\SUBSET-1K6 Y"
      using relat_1_th_177 sorry
    then have "domRELAT-1K1 ((R \\SUBSET-1K6 R  |RELAT-1K8 Y) |RELAT-1K8 X) =HIDDENR1 (domRELAT-1K1 R \\SUBSET-1K6 Y)/\\SUBSET-1K8\<^bsub>(domRELAT-1K1 R)\<^esub> X"
      using relat_1_th_61 sorry
    also have "... = domRELAT-1K1 R /\\XBOOLE-0K3 X \\SUBSET-1K6 Y"
      using xboole_1_th_49 sorry
    also have "... = {}XBOOLE-0K1"
      using A2 xboole_1_th_37 sorry
    finally have "domRELAT-1K1 ((R \\SUBSET-1K6 R  |RELAT-1K8 Y) |RELAT-1K8 X) =HIDDENR1 {}XBOOLE-0K1"
       sorry
    thus "(R \\SUBSET-1K6 R  |RELAT-1K8 Y) |RELAT-1K8 X =RELAT-1R1 {}XBOOLE-0K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_182:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies ( for R be X -definedRELAT-1V4\<bar>RelationRELAT-1M1 holds R be Y -definedRELAT-1V4)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies ( for R be X -definedRELAT-1V4\<bar>RelationRELAT-1M1 holds R be Y -definedRELAT-1V4)"
  proof(rule ballI,rule ballI,rule impI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "X c=TARSKIR1 Y"
    fix R assume [ty]: "R be X -definedRELAT-1V4\<bar>RelationRELAT-1M1"
    have Cut3016: "domRELAT-1K1 R c=TARSKIR1 X"
      using relat_1_def_18 sorry
    have "domRELAT-1K1 R c=TARSKIR1 Y"
    proof-
      show "domRELAT-1K1 R c=TARSKIR1 Y"
        using A1 Cut3016 sorry
    qed
    thus "R be Y -definedRELAT-1V4"
      using relat_1_def_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_183:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies ( for R be X -valuedRELAT-1V5\<bar>RelationRELAT-1M1 holds R be Y -valuedRELAT-1V5)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies ( for R be X -valuedRELAT-1V5\<bar>RelationRELAT-1M1 holds R be Y -valuedRELAT-1V5)"
  proof(rule ballI,rule ballI,rule impI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "X c=TARSKIR1 Y"
    fix R assume [ty]: "R be X -valuedRELAT-1V5\<bar>RelationRELAT-1M1"
    have Cut3026: "rngRELAT-1K2 R c=TARSKIR1 X"
      using relat_1_def_19 sorry
    have "rngRELAT-1K2 R c=TARSKIR1 Y"
    proof-
      show "rngRELAT-1K2 R c=TARSKIR1 Y"
        using A1 Cut3026 sorry
    qed
    thus "R be Y -valuedRELAT-1V5"
      using relat_1_def_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_184:
" for R be RelationRELAT-1M1 holds  for S be RelationRELAT-1M1 holds R c=RELAT-1R2 S iff R c=RELAT-1R2 S  |RELAT-1K8 domRELAT-1K1 R"
proof-
  have " for R be RelationRELAT-1M1 holds  for S be RelationRELAT-1M1 holds (R c=RELAT-1R2 S implies R c=RELAT-1R2 S  |RELAT-1K8 domRELAT-1K1 R) &  not (R c=RELAT-1R2 S  |RELAT-1K8 domRELAT-1K1 R &  not R c=RELAT-1R2 S)"
  proof(rule ballI,rule ballI,rule conjMI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix S assume [ty]: "S be RelationRELAT-1M1"
    show "R c=RELAT-1R2 S implies R c=RELAT-1R2 S  |RELAT-1K8 domRELAT-1K1 R"
    proof(rule impI)
      assume "R c=RELAT-1R2 S"
      then have "R  |RELAT-1K8 domRELAT-1K1 R c=RELAT-1R2 S  |RELAT-1K8 domRELAT-1K1 R"
        using relat_1_th_76 sorry
      thus "R c=RELAT-1R2 S  |RELAT-1K8 domRELAT-1K1 R"
         sorry
    qed
    show " not (R c=RELAT-1R2 S  |RELAT-1K8 domRELAT-1K1 R &  not R c=RELAT-1R2 S)"
      using relat_1_def_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_185:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be X -definedRELAT-1V4\<bar>Y -valuedRELAT-1V5\<bar>RelationRELAT-1M1 holds R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :]"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be X -definedRELAT-1V4\<bar>Y -valuedRELAT-1V5\<bar>RelationRELAT-1M1 holds R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :]"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be X -definedRELAT-1V4\<bar>Y -valuedRELAT-1V5\<bar>RelationRELAT-1M1"
    have A1: "R c=RELAT-1R2 [:ZFMISC-1K2 domRELAT-1K1 R,rngRELAT-1K2 R :]"
      using relat_1_th_7 sorry
    have "domRELAT-1K1 R c=TARSKIR1 X & rngRELAT-1K2 R c=TARSKIR1 Y"
      using relat_1_def_18 relat_1_def_19 sorry
    then have "[:ZFMISC-1K2 domRELAT-1K1 R,rngRELAT-1K2 R :] c=RELAT-1R2 [:ZFMISC-1K2 X,Y :]"
      using zfmisc_1_th_96 sorry
    thus "R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :]"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_1_th_186:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds domRELAT-1K1 (X  |`RELAT-1K9 R) c=TARSKIR1 domRELAT-1K1 R"
  using relat_1_th_86 xtuple_0_th_8 sorry

mtheorem relat_1_cl_40:
  mlet "A be setHIDDENM2", "X be setHIDDENM2", "R be A -definedRELAT-1V4\<bar>RelationRELAT-1M1"
"cluster X  |`RELAT-1K9 R as-term-is A -definedRELAT-1V4"
proof
(*coherence*)
  show "X  |`RELAT-1K9 R be A -definedRELAT-1V4"
  proof-
    have Cut3063: "domRELAT-1K1 (X  |`RELAT-1K9 R) c=TARSKIR1 domRELAT-1K1 R & domRELAT-1K1 R c=TARSKIR1 A"
      using relat_1_def_18 relat_1_th_86 xtuple_0_th_8 sorry
    have "domRELAT-1K1 (X  |`RELAT-1K9 R) c=TARSKIR1 A"
    proof-
      show "domRELAT-1K1 (X  |`RELAT-1K9 R) c=TARSKIR1 A"
        using Cut3063 sorry
    qed
    thus "X  |`RELAT-1K9 R be A -definedRELAT-1V4"
      using relat_1_def_18 sorry
  qed
qed "sorry"

mtheorem relat_1_cl_41:
  mlet "X be setHIDDENM2", "A be setHIDDENM2", "R be A -valuedRELAT-1V5\<bar>RelationRELAT-1M1"
"cluster X  |`RELAT-1K9 R as-term-is A -valuedRELAT-1V5\<bar>X -valuedRELAT-1V5"
proof
(*coherence*)
  show "X  |`RELAT-1K9 R be A -valuedRELAT-1V5\<bar>X -valuedRELAT-1V5"
  proof-
    have "X  |`RELAT-1K9 R be A -valuedRELAT-1V5 & X  |`RELAT-1K9 R be X -valuedRELAT-1V5"
    proof-
      have Cut3074: "rngRELAT-1K2 (X  |`RELAT-1K9 R) c=TARSKIR1 rngRELAT-1K2 R & rngRELAT-1K2 R c=TARSKIR1 A"
        using relat_1_def_19 relat_1_th_86 xtuple_0_th_9 sorry
      have "rngRELAT-1K2 (X  |`RELAT-1K9 R) c=TARSKIR1 A & X  |`RELAT-1K9 R be X -valuedRELAT-1V5"
      proof(rule conjMI)
        show "rngRELAT-1K2 (X  |`RELAT-1K9 R) c=TARSKIR1 A"
          using Cut3074 sorry
        have "rngRELAT-1K2 (X  |`RELAT-1K9 R) c=TARSKIR1 X"
        proof-
          show "rngRELAT-1K2 (X  |`RELAT-1K9 R) c=TARSKIR1 X"
            using relat_1_th_84 sorry
        qed
        thus "X  |`RELAT-1K9 R be X -valuedRELAT-1V5"
          using relat_1_def_19 sorry
      qed
      thus "X  |`RELAT-1K9 R be A -valuedRELAT-1V5 & X  |`RELAT-1K9 R be X -valuedRELAT-1V5"
        using relat_1_def_19 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem relat_1_cl_42:
  mlet "X be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster note-that emptyXBOOLE-0V1 for X -definedRELAT-1V4\<bar>RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be X -definedRELAT-1V4\<bar>RelationRELAT-1M1 holds it be emptyXBOOLE-0V1"
  proof-
    have " for R be X -definedRELAT-1V4\<bar>RelationRELAT-1M1 holds R be emptyXBOOLE-0V1"
    proof(rule ballI)
      fix R assume [ty]: "R be X -definedRELAT-1V4\<bar>RelationRELAT-1M1"
      have "domRELAT-1K1 R c=TARSKIR1 X"
        using relat_1_def_18 sorry
      thus "R be emptyXBOOLE-0V1"
        using xboole_1_th_3 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem relat_1_cl_43:
  mlet "X be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster note-that emptyXBOOLE-0V1 for X -valuedRELAT-1V5\<bar>RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be X -valuedRELAT-1V5\<bar>RelationRELAT-1M1 holds it be emptyXBOOLE-0V1"
  proof-
    have " for R be X -valuedRELAT-1V5\<bar>RelationRELAT-1M1 holds R be emptyXBOOLE-0V1"
    proof(rule ballI)
      fix R assume [ty]: "R be X -valuedRELAT-1V5\<bar>RelationRELAT-1M1"
      have "rngRELAT-1K2 R c=TARSKIR1 X"
        using relat_1_def_19 sorry
      thus "R be emptyXBOOLE-0V1"
        using xboole_1_th_3 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem relat_1_th_187:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for P be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds X missesXBOOLE-0R1 Y implies P  |RELAT-1K8 X missesXBOOLE-0R1 R  |RELAT-1K8 Y"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix X assume [ty]: "X be setHIDDENM2"
  fix Y assume [ty]: "Y be setHIDDENM2"
  fix P assume [ty]: "P be RelationRELAT-1M1"
  fix R assume [ty]: "R be RelationRELAT-1M1"
  assume A1: "X missesXBOOLE-0R1 Y"
  have A2: "domRELAT-1K1 (P  |RELAT-1K8 X) =XBOOLE-0R4 domRELAT-1K1 P /\\XBOOLE-0K3 X"
    using relat_1_th_61 sorry
  have "domRELAT-1K1 (R  |RELAT-1K8 Y) =XBOOLE-0R4 domRELAT-1K1 R /\\XBOOLE-0K3 Y"
    using relat_1_th_61 sorry
  then have "domRELAT-1K1 (P  |RELAT-1K8 X) /\\XBOOLE-0K3 domRELAT-1K1 (R  |RELAT-1K8 Y) =HIDDENR1 domRELAT-1K1 P /\\XBOOLE-0K3 (X /\\XBOOLE-0K3 (domRELAT-1K1 R /\\XBOOLE-0K3 Y))"
    using A2 xboole_1_th_16 sorry
  also have "... = domRELAT-1K1 P /\\XBOOLE-0K3 ((X /\\XBOOLE-0K3 Y)/\\XBOOLE-0K3 domRELAT-1K1 R)"
    using xboole_1_th_16 sorry
  also have "... = {}XBOOLE-0K1"
    using A1 sorry
  finally have "domRELAT-1K1 (P  |RELAT-1K8 X) /\\XBOOLE-0K3 domRELAT-1K1 (R  |RELAT-1K8 Y) =HIDDENR1 {}XBOOLE-0K1"
     sorry
  then have "domRELAT-1K1 (P  |RELAT-1K8 X) missesXBOOLE-0R1 domRELAT-1K1 (R  |RELAT-1K8 Y)"
     sorry
  thus "P  |RELAT-1K8 X missesXBOOLE-0R1 R  |RELAT-1K8 Y"
    using relat_1_th_179 sorry
qed "sorry"

mtheorem relat_1_th_188:
" for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds Y  |`RELAT-1K9 R c=RELAT-1R2 R  |RELAT-1K8 R \<inverse>RELAT-1K11 Y"
proof(rule ballI,rule ballI)
  fix Y assume [ty]: "Y be setHIDDENM2"
  fix R assume [ty]: "R be RelationRELAT-1M1"
  have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 Y  |`RELAT-1K9 R implies [TARSKIK4 a,b ] inHIDDENR3 R  |RELAT-1K8 R \<inverse>RELAT-1K11 Y"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be objectHIDDENM1"
    fix b assume [ty]: "b be objectHIDDENM1"
    assume A1: "[TARSKIK4 a,b ] inHIDDENR3 Y  |`RELAT-1K9 R"
    then have A2: "b inHIDDENR3 Y"
      using relat_1_def_12 sorry
    have A3: "[TARSKIK4 a,b ] inHIDDENR3 R"
      using A1 relat_1_def_12 sorry
    then have "a inHIDDENR3 R \<inverse>RELAT-1K11 Y"
      using A2 relat_1_def_14 sorry
    thus "[TARSKIK4 a,b ] inHIDDENR3 R  |RELAT-1K8 R \<inverse>RELAT-1K11 Y"
      using A3 relat_1_def_11 sorry
  qed "sorry"
  thus "Y  |`RELAT-1K9 R c=RELAT-1R2 R  |RELAT-1K8 R \<inverse>RELAT-1K11 Y"
    using relat_1_def_3 sorry
qed "sorry"

mtheorem relat_1_th_189:
" for f be RelationRELAT-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds domRELAT-1K1 f =XBOOLE-0R4 {TARSKIK1 x} & rngRELAT-1K2 f =XBOOLE-0R4 {TARSKIK1 y} implies f =RELAT-1R1 {TARSKIK1 [TARSKIK4 x,y ] }"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix f assume [ty]: "f be RelationRELAT-1M1"
  fix x assume [ty]: "x be objectHIDDENM1"
  fix y assume [ty]: "y be objectHIDDENM1"
  have A1: "f c=RELAT-1R2 [:ZFMISC-1K2 domRELAT-1K1 f,rngRELAT-1K2 f :]"
    using relat_1_th_7 sorry
  assume A2: "domRELAT-1K1 f =XBOOLE-0R4 {TARSKIK1 x} & rngRELAT-1K2 f =XBOOLE-0R4 {TARSKIK1 y}"
  have "x inHIDDENR3 domRELAT-1K1 f"
    using A2 tarski_def_1 sorry
  then obtain yy where
    [ty]:"yy be objectHIDDENM1" and 
    A3: "[TARSKIK4 x,yy ] inHIDDENR3 f"
    using xtuple_0_def_12 sorry
  have "yy inHIDDENR3 rngRELAT-1K2 f"
    using A3 xtuple_0_def_13 sorry
  then have "[TARSKIK4 x,y ] inHIDDENR3 f"
    using A3 A2 tarski_def_1 sorry
  thus "f =RELAT-1R1 {TARSKIK1 [TARSKIK4 x,y ] }"
    using A1 A2 zfmisc_1_th_29 zfmisc_1_th_31 sorry
qed "sorry"

mtheorem relat_1_sethood_1:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"cluster sethood of X -definedRELAT-1V4\<bar>Y -valuedRELAT-1V5\<bar>RelationRELAT-1M1"
proof
(*sethood*)
  show " ex cover be setHIDDENM2 st  for it be X -definedRELAT-1V4\<bar>Y -valuedRELAT-1V5\<bar>RelationRELAT-1M1 holds it inHIDDENR3 cover"
  proof-
    have " ex tVar14 be setHIDDENM2 st  for R be X -definedRELAT-1V4\<bar>Y -valuedRELAT-1V5\<bar>RelationRELAT-1M1 holds R inHIDDENR3 tVar14"
    proof-
      show " ex tVar14 be setHIDDENM2 st  for R be X -definedRELAT-1V4\<bar>Y -valuedRELAT-1V5\<bar>RelationRELAT-1M1 holds R inHIDDENR3 tVar14"
      proof(rule bexI[of _ "boolZFMISC-1K1 ([:ZFMISC-1K2 X,Y :])"],rule ballI)
        fix R assume [ty]: "R be X -definedRELAT-1V4\<bar>Y -valuedRELAT-1V5\<bar>RelationRELAT-1M1"
        have "R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :]"
          using relat_1_th_185 sorry
        thus "R inHIDDENR3 boolZFMISC-1K1 ([:ZFMISC-1K2 X,Y :])"
          using zfmisc_1_def_1 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

end
