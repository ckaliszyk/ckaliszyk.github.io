theory finseq_6
  imports xxreal_2 funct_7 seqm_3 card_2 xcmplx_1 binarith
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x, y, z for "setHIDDENM2"
mtheorem finseq_6_cl_1:
  mlet "x be setHIDDENM2", "y be setHIDDENM2", "z be setHIDDENM2"
"cluster <*FINSEQ-1K12 x,y,z *> as-term-is  non trivialZFMISC-1V1"
proof
(*coherence*)
  show "<*FINSEQ-1K12 x,y,z *> be  non trivialZFMISC-1V1"
  proof-
    have " not <*FINSEQ-1K12 x,y,z *> be trivialSUBSET-1V2"
    proof-
      have "lenFINSEQ-1K4 (<*FINSEQ-1K12 x,y,z *>) =XBOOLE-0R4 \<three>\<^sub>M"
        using finseq_1_th_45 sorry
      thus " not <*FINSEQ-1K12 x,y,z *> be trivialSUBSET-1V2"
        using nat_d_th_60 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finseq_6_cl_2:
  mlet "f be  non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M1"
"cluster RevFINSEQ-5K3 f as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "RevFINSEQ-5K3 f be  non emptyXBOOLE-0V1"
  proof-
    have " not RevFINSEQ-5K3 f be emptyXBOOLE-0V1"
    proof-
      have "domFINSEQ-1K5 f <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      thus " not RevFINSEQ-5K3 f be emptyXBOOLE-0V1"
        using finseq_5_th_57 relat_1_th_38 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mlemma finseq_6_lm_1:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds rngFUNCT-1K2 (<*FINSEQ-1K11 x,y *>) =XBOOLE-0R4 {TARSKIK2 x,y }"
proof-
  have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds rngFUNCT-1K2 (<*FINSEQ-1K11 x,y *>) =HIDDENR1 {TARSKIK2 x,y }"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    have "rngFUNCT-1K2 (<*FINSEQ-1K11 x,y *>) =HIDDENR1 rngFUNCT-1K2 (<*FINSEQ-1K10 x*>) \\/XBOOLE-0K2 rngFUNCT-1K2 (<*FINSEQ-1K10 y*>)"
      using finseq_1_th_31 sorry
    also have "... = {TARSKIK1 x} \\/XBOOLE-0K2 rngFUNCT-1K2 (<*FINSEQ-1K10 y*>)"
      using finseq_1_th_38 sorry
    also have "... = {TARSKIK1 x} \\/XBOOLE-0K2 {TARSKIK1 y}"
      using finseq_1_th_38 sorry
    also have "... = {TARSKIK2 x,y }"
      using enumset1_th_1 sorry
    finally show "rngFUNCT-1K2 (<*FINSEQ-1K11 x,y *>) =HIDDENR1 {TARSKIK2 x,y }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma finseq_6_lm_2:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds rngFUNCT-1K2 (<*FINSEQ-1K12 x,y,z *>) =XBOOLE-0R4 {ENUMSET1K1 x,y,z }"
proof-
  have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds rngFUNCT-1K2 (<*FINSEQ-1K12 x,y,z *>) =HIDDENR1 {ENUMSET1K1 x,y,z }"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    fix z assume [ty]: "z be setHIDDENM2"
    have "rngFUNCT-1K2 (<*FINSEQ-1K12 x,y,z *>) =HIDDENR1 rngFUNCT-1K2 (<*FINSEQ-1K11 x,y *>) \\/XBOOLE-0K2 rngFUNCT-1K2 (<*FINSEQ-1K10 z*>)"
      using finseq_1_th_31 sorry
    also have "... = {TARSKIK2 x,y } \\/XBOOLE-0K2 rngFUNCT-1K2 (<*FINSEQ-1K10 z*>)"
      using finseq_6_lm_1 sorry
    also have "... = {TARSKIK2 x,y } \\/XBOOLE-0K2 {TARSKIK1 z}"
      using finseq_1_th_38 sorry
    also have "... = {ENUMSET1K1 x,y,z }"
      using enumset1_th_3 sorry
    finally show "rngFUNCT-1K2 (<*FINSEQ-1K12 x,y,z *>) =HIDDENR1 {ENUMSET1K1 x,y,z }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
reserve f, f1, f2, f3 for "FinSequenceFINSEQ-1M1"
reserve p, p1, p2, p3 for "setHIDDENM2"
reserve i, k for "NatNAT-1M1"
mtheorem finseq_6_th_1:
" for X be setHIDDENM2 holds  for i be NatNAT-1M1 holds X c=TARSKIR1 SegFINSEQ-1K2 i & \<one>\<^sub>M inTARSKIR2 X implies SgmFINSEQ-1K15 X .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for X be setHIDDENM2 holds  for i be NatNAT-1M1 holds X c=TARSKIR1 SegFINSEQ-1K2 i & \<one>\<^sub>M inTARSKIR2 X implies (SgmFINSEQ-1K15 X .FUNCT-1K1 \<one>\<^sub>M <>HIDDENR2 \<one>\<^sub>M implies  False )"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix i assume [ty]: "i be NatNAT-1M1"
    assume A1: "X c=TARSKIR1 SegFINSEQ-1K2 i"
      and A2: "\<one>\<^sub>M inTARSKIR2 X"
    have "SgmFINSEQ-1K15 X <>HIDDENR2 {}XBOOLE-0K1"
      using A1 A2 finseq_1_th_51 sorry
    then have "lenFINSEQ-1K4 (SgmFINSEQ-1K15 X) >=XXREAL-0R2 \<one>\<^sub>M"
      using nat_1_th_14 sorry
    then have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (SgmFINSEQ-1K15 X)"
      using finseq_3_th_25 sorry
    then have A3: "SgmFINSEQ-1K15 X .FUNCT-1K1 \<one>\<^sub>M inTARSKIR2 rngFUNCT-1K2 (SgmFINSEQ-1K15 X)"
      using funct_1_def_3 sorry
    obtain k1 where 
      [ty]:"k1 be NatNAT-1M1" and k1Def:"k1 = SgmFINSEQ-1K15 X .FUNCT-1K1 \<one>\<^sub>M"
       sorry
    assume A4: "SgmFINSEQ-1K15 X .FUNCT-1K1 \<one>\<^sub>M <>HIDDENR2 \<one>\<^sub>M"
    have A5: "rngFUNCT-1K2 (SgmFINSEQ-1K15 X) =XBOOLE-0R4 X"
      using A1 finseq_1_def_13 sorry
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A6: "x inHIDDENR3 domFINSEQ-1K5 (SgmFINSEQ-1K15 X)"and A7: "SgmFINSEQ-1K15 X .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M"
      using A2 funct_1_def_3 sorry
    have A8: "k1 >=XXREAL-0R2 \<one>\<^sub>M"
      using A1 A5 A3 finseq_1_th_1 sorry
    obtain j where 
      [ty]:"j be NatNAT-1M1" and jDef:"j = x"
      using A6 sorry
    have "j >=XXREAL-0R2 \<one>\<^sub>M"
      using A6 finseq_3_th_25 sorry
    then have A9: "\<one>\<^sub>M <XXREAL-0R3 j"
      using A7 A4 xxreal_0_th_1 sorry
    have "j <=XXREAL-0R1 lenFINSEQ-1K4 (SgmFINSEQ-1K15 X)"
      using A6 finseq_3_th_25 sorry
    thus " False "
      using A1 A7 A8 A9 finseq_1_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_2:
" for k be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds k inTARSKIR2 domFINSEQ-1K5 f & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 k implies f .FUNCT-1K1 i <>HIDDENR2 f .FUNCT-1K1 k) implies (f .FUNCT-1K1 k)..FINSEQ-4K4 f =XBOOLE-0R4 k"
proof-
  have " for k be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds k inTARSKIR2 domFINSEQ-1K5 f & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 k implies f .FUNCT-1K1 i <>HIDDENR2 f .FUNCT-1K1 k) implies ((f .FUNCT-1K1 k)..FINSEQ-4K4 f <>HIDDENR2 k implies  False )"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
    assume A1: "k inTARSKIR2 domFINSEQ-1K5 f"
      and A2: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 k implies f .FUNCT-1K1 i <>HIDDENR2 f .FUNCT-1K1 k"
    assume A3: "(f .FUNCT-1K1 k)..FINSEQ-4K4 f <>HIDDENR2 k"
    have "(f .FUNCT-1K1 k)..FINSEQ-4K4 f <=XXREAL-0R1 k"
      using A1 finseq_4_th_24 sorry
    then have A4: "(f .FUNCT-1K1 k)..FINSEQ-4K4 f <XXREAL-0R3 k"
      using A3 xxreal_0_th_1 sorry
    have A5: "f .FUNCT-1K1 k inTARSKIR2 rngFUNCT-1K2 f"
      using A1 funct_1_def_3 sorry
    then have "f .FUNCT-1K1 ((f .FUNCT-1K1 k)..FINSEQ-4K4 f) =XBOOLE-0R4 f .FUNCT-1K1 k"
      using finseq_4_th_19 sorry
    thus " False "
      using A2 A5 A4 finseq_4_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_3:
" for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds (<*FINSEQ-1K11 p1,p2 *>) |RELAT-1K8 SegFINSEQ-1K2 \<one>\<^sub>M =FUNCT-1R1 <*FINSEQ-1K10 p1*>"
proof-
  have " for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds (<*FINSEQ-1K11 p1,p2 *>) |RELAT-1K8 SegFINSEQ-1K2 \<one>\<^sub>M =FUNCT-1R1 <*FINSEQ-1K10 p1*>"
  proof(rule ballI,rule ballI)
    fix p1 assume [ty]: "p1 be setHIDDENM2"
    fix p2 assume [ty]: "p2 be setHIDDENM2"
    let ?f = "(<*FINSEQ-1K11 p1,p2 *>) |RELAT-1K8 SegFINSEQ-1K2 \<one>\<^sub>M"
    have "lenFINSEQ-1K4 (<*FINSEQ-1K11 p1,p2 *>) =XBOOLE-0R4 \<two>\<^sub>M"
      using finseq_1_th_44 sorry
    then have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K11 p1,p2 *>)"
      using finseq_3_th_25 sorry
    then have A1: "SegFINSEQ-1K2 \<one>\<^sub>M c=TARSKIR1 domFINSEQ-1K5 (<*FINSEQ-1K11 p1,p2 *>)"
      using finseq_1_th_2 zfmisc_1_th_31 sorry
    have A2: "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ?f =HIDDENR1 domFINSEQ-1K5 (<*FINSEQ-1K11 p1,p2 *>) /\\SUBSET-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> SegFINSEQ-1K2 \<one>\<^sub>M"
      using relat_1_th_61 sorry
    also have "... = SegFINSEQ-1K2 \<one>\<^sub>M"
      using A1 xboole_1_th_28 sorry
    finally have "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ?f =HIDDENR1 SegFINSEQ-1K2 \<one>\<^sub>M"
       sorry
    then obtain f where 
      [ty]:"f be FinSequenceFINSEQ-1M1" and fDef:"f = ?f"
      using finseq_1_def_2 sorry
    have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
      using A2 sorry
    then have A3: "f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 (<*FINSEQ-1K11 p1,p2 *>).FUNCT-1K1 \<one>\<^sub>M"
      using funct_1_th_47 sorry
    also have "... = p1"
      using finseq_1_th_44 sorry
    finally have "f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 p1"
       sorry
    have "lenFINSEQ-1K4 f =XBOOLE-0R4 \<one>\<^sub>M"
      using A2 finseq_1_def_3 sorry
    thus "(<*FINSEQ-1K11 p1,p2 *>) |RELAT-1K8 SegFINSEQ-1K2 \<one>\<^sub>M =FUNCT-1R1 <*FINSEQ-1K10 p1*>"
      using A3 finseq_1_th_40 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_4:
" for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for p3 be setHIDDENM2 holds (<*FINSEQ-1K12 p1,p2,p3 *>) |RELAT-1K8 SegFINSEQ-1K2 \<one>\<^sub>M =FUNCT-1R1 <*FINSEQ-1K10 p1*>"
proof-
  have " for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for p3 be setHIDDENM2 holds (<*FINSEQ-1K12 p1,p2,p3 *>) |RELAT-1K8 SegFINSEQ-1K2 \<one>\<^sub>M =FUNCT-1R1 <*FINSEQ-1K10 p1*>"
  proof(rule ballI,rule ballI,rule ballI)
    fix p1 assume [ty]: "p1 be setHIDDENM2"
    fix p2 assume [ty]: "p2 be setHIDDENM2"
    fix p3 assume [ty]: "p3 be setHIDDENM2"
    let ?f = "(<*FINSEQ-1K12 p1,p2,p3 *>) |RELAT-1K8 SegFINSEQ-1K2 \<one>\<^sub>M"
    have "lenFINSEQ-1K4 (<*FINSEQ-1K12 p1,p2,p3 *>) =XBOOLE-0R4 \<three>\<^sub>M"
      using finseq_1_th_45 sorry
    then have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K12 p1,p2,p3 *>)"
      using finseq_3_th_25 sorry
    then have A1: "SegFINSEQ-1K2 \<one>\<^sub>M c=TARSKIR1 domFINSEQ-1K5 (<*FINSEQ-1K12 p1,p2,p3 *>)"
      using finseq_1_th_2 zfmisc_1_th_31 sorry
    have A2: "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ?f =HIDDENR1 domFINSEQ-1K5 (<*FINSEQ-1K12 p1,p2,p3 *>) /\\SUBSET-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> SegFINSEQ-1K2 \<one>\<^sub>M"
      using relat_1_th_61 sorry
    also have "... = SegFINSEQ-1K2 \<one>\<^sub>M"
      using A1 xboole_1_th_28 sorry
    finally have "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ?f =HIDDENR1 SegFINSEQ-1K2 \<one>\<^sub>M"
       sorry
    then obtain f where 
      [ty]:"f be FinSequenceFINSEQ-1M1" and fDef:"f = ?f"
      using finseq_1_def_2 sorry
    have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
      using A2 sorry
    then have A3: "f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 (<*FINSEQ-1K12 p1,p2,p3 *>).FUNCT-1K1 \<one>\<^sub>M"
      using funct_1_th_47 sorry
    also have "... = p1"
      using finseq_1_th_45 sorry
    finally have "f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 p1"
       sorry
    have "lenFINSEQ-1K4 f =XBOOLE-0R4 \<one>\<^sub>M"
      using A2 finseq_1_def_3 sorry
    thus "(<*FINSEQ-1K12 p1,p2,p3 *>) |RELAT-1K8 SegFINSEQ-1K2 \<one>\<^sub>M =FUNCT-1R1 <*FINSEQ-1K10 p1*>"
      using A3 finseq_1_th_40 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_5:
" for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for p3 be setHIDDENM2 holds (<*FINSEQ-1K12 p1,p2,p3 *>) |RELAT-1K8 SegFINSEQ-1K2 \<two>\<^sub>M =FUNCT-1R1 <*FINSEQ-1K11 p1,p2 *>"
proof-
  have " for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for p3 be setHIDDENM2 holds (<*FINSEQ-1K12 p1,p2,p3 *>) |RELAT-1K8 SegFINSEQ-1K2 \<two>\<^sub>M =FUNCT-1R1 <*FINSEQ-1K11 p1,p2 *>"
  proof(rule ballI,rule ballI,rule ballI)
    fix p1 assume [ty]: "p1 be setHIDDENM2"
    fix p2 assume [ty]: "p2 be setHIDDENM2"
    fix p3 assume [ty]: "p3 be setHIDDENM2"
    let ?f = "(<*FINSEQ-1K12 p1,p2,p3 *>) |RELAT-1K8 SegFINSEQ-1K2 \<two>\<^sub>M"
    have A1: "lenFINSEQ-1K4 (<*FINSEQ-1K12 p1,p2,p3 *>) =XBOOLE-0R4 \<three>\<^sub>M"
      using finseq_1_th_45 sorry
    then have A2: "\<two>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K12 p1,p2,p3 *>)"
      using finseq_3_th_25 sorry
    have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K12 p1,p2,p3 *>)"
      using A1 finseq_3_th_25 sorry
    then have A3: "SegFINSEQ-1K2 \<two>\<^sub>M c=TARSKIR1 domFINSEQ-1K5 (<*FINSEQ-1K12 p1,p2,p3 *>)"
      using A2 finseq_1_th_2 zfmisc_1_th_32 sorry
    have A4: "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ?f =HIDDENR1 domFINSEQ-1K5 (<*FINSEQ-1K12 p1,p2,p3 *>) /\\SUBSET-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> SegFINSEQ-1K2 \<two>\<^sub>M"
      using relat_1_th_61 sorry
    also have "... = SegFINSEQ-1K2 \<two>\<^sub>M"
      using A3 xboole_1_th_28 sorry
    finally have "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ?f =HIDDENR1 SegFINSEQ-1K2 \<two>\<^sub>M"
       sorry
    then obtain f where 
      [ty]:"f be FinSequenceFINSEQ-1M1" and fDef:"f = ?f"
      using finseq_1_def_2 sorry
    have A5: "lenFINSEQ-1K4 f =XBOOLE-0R4 \<two>\<^sub>M"
      using A4 finseq_1_def_3 sorry
    then have "\<two>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
      using finseq_3_th_25 sorry
    then have A6: "f .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 (<*FINSEQ-1K12 p1,p2,p3 *>).FUNCT-1K1 \<two>\<^sub>M"
      using funct_1_th_47 sorry
    also have "... = p2"
      using finseq_1_th_45 sorry
    finally have "f .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 p2"
       sorry
    have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
      using A5 finseq_3_th_25 sorry
    then have "f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 (<*FINSEQ-1K12 p1,p2,p3 *>).FUNCT-1K1 \<one>\<^sub>M"
      using funct_1_th_47 sorry
    also have "... = p1"
      using finseq_1_th_45 sorry
    finally have "f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 p1"
       sorry
    thus "(<*FINSEQ-1K12 p1,p2,p3 *>) |RELAT-1K8 SegFINSEQ-1K2 \<two>\<^sub>M =FUNCT-1R1 <*FINSEQ-1K11 p1,p2 *>"
      using A5 A6 finseq_1_th_44 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_6:
" for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  for p be setHIDDENM2 holds p inTARSKIR2 rngFUNCT-1K2 f1 implies p ..FINSEQ-4K4 (f1 ^FINSEQ-1K8 f2) =XBOOLE-0R4 p ..FINSEQ-4K4 f1"
proof-
  have " for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  for p be setHIDDENM2 holds p inTARSKIR2 rngFUNCT-1K2 f1 implies p ..FINSEQ-4K4 (f1 ^FINSEQ-1K8 f2) =XBOOLE-0R4 p ..FINSEQ-4K4 f1"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix f1 assume [ty]: "f1 be FinSequenceFINSEQ-1M1"
    fix f2 assume [ty]: "f2 be FinSequenceFINSEQ-1M1"
    fix p assume [ty]: "p be setHIDDENM2"
    have A1: "domFINSEQ-1K5 f1 c=TARSKIR1 domFINSEQ-1K5 (f1 ^FINSEQ-1K8 f2)"
      using finseq_1_th_26 sorry
    assume A2: "p inTARSKIR2 rngFUNCT-1K2 f1"
    then have A3: "p ..FINSEQ-4K4 f1 inTARSKIR2 domFINSEQ-1K5 f1"
      using finseq_4_th_20 sorry
    have A4: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 p ..FINSEQ-4K4 f1 implies (f1 ^FINSEQ-1K8 f2).FUNCT-1K1 i <>HIDDENR2 (f1 ^FINSEQ-1K8 f2).FUNCT-1K1 (p ..FINSEQ-4K4 f1)"
    proof(rule ballI,rule impMI ,rule impI)
      have A5: "(f1 ^FINSEQ-1K8 f2).FUNCT-1K1 (p ..FINSEQ-4K4 f1) =XBOOLE-0R4 f1 .FUNCT-1K1 (p ..FINSEQ-4K4 f1)"
        using A3 finseq_1_def_7 sorry
      fix i assume [ty]: "i be NatNAT-1M1"
      assume A6: "\<one>\<^sub>M <=XXREAL-0R1 i"
        and A7: "i <XXREAL-0R3 p ..FINSEQ-4K4 f1"
      have "p ..FINSEQ-4K4 f1 <=XXREAL-0R1 lenFINSEQ-1K4 f1"
        using A2 finseq_4_th_21 sorry
      then have "i <=XXREAL-0R1 lenFINSEQ-1K4 f1"
        using A7 xxreal_0_th_2 sorry
      then have A8: "i inTARSKIR2 domFINSEQ-1K5 f1"
        using A6 finseq_3_th_25 sorry
      then have "(f1 ^FINSEQ-1K8 f2).FUNCT-1K1 i =XBOOLE-0R4 f1 .FUNCT-1K1 i"
        using finseq_1_def_7 sorry
      thus "(f1 ^FINSEQ-1K8 f2).FUNCT-1K1 i <>HIDDENR2 (f1 ^FINSEQ-1K8 f2).FUNCT-1K1 (p ..FINSEQ-4K4 f1)"
        using A2 A7 A8 A5 finseq_4_th_19 finseq_4_th_24 sorry
    qed "sorry"
    have "f1 .FUNCT-1K1 (p ..FINSEQ-4K4 f1) =XBOOLE-0R4 p"
      using A2 finseq_4_th_19 sorry
    then have "(f1 ^FINSEQ-1K8 f2).FUNCT-1K1 (p ..FINSEQ-4K4 f1) =XBOOLE-0R4 p"
      using A3 finseq_1_def_7 sorry
    thus "p ..FINSEQ-4K4 (f1 ^FINSEQ-1K8 f2) =XBOOLE-0R4 p ..FINSEQ-4K4 f1"
      using A3 A1 A4 finseq_6_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_7:
" for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  for p be setHIDDENM2 holds p inTARSKIR2 rngFUNCT-1K2 f2 \\SUBSET-1K6 rngFUNCT-1K2 f1 implies p ..FINSEQ-4K4 (f1 ^FINSEQ-1K8 f2) =XBOOLE-0R4 lenFINSEQ-1K4 f1 +NAT-1K1 p ..FINSEQ-4K4 f2"
proof-
  have " for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  for p be setHIDDENM2 holds p inTARSKIR2 rngFUNCT-1K2 f2 \\SUBSET-1K6 rngFUNCT-1K2 f1 implies p ..FINSEQ-4K4 (f1 ^FINSEQ-1K8 f2) =XBOOLE-0R4 lenFINSEQ-1K4 f1 +NAT-1K1 p ..FINSEQ-4K4 f2"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix f1 assume [ty]: "f1 be FinSequenceFINSEQ-1M1"
    fix f2 assume [ty]: "f2 be FinSequenceFINSEQ-1M1"
    fix p assume [ty]: "p be setHIDDENM2"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f2 \\SUBSET-1K6 rngFUNCT-1K2 f1"
    then have A2: "p ..FINSEQ-4K4 f2 inTARSKIR2 domFINSEQ-1K5 f2"
      using finseq_4_th_20 sorry
    have "f2 .FUNCT-1K1 (p ..FINSEQ-4K4 f2) =XBOOLE-0R4 p"
      using A1 finseq_4_th_19 sorry
    then have A3: "(f1 ^FINSEQ-1K8 f2).FUNCT-1K1 (lenFINSEQ-1K4 f1 +NAT-1K1 p ..FINSEQ-4K4 f2) =XBOOLE-0R4 p"
      using A2 finseq_1_def_7 sorry
    have A4: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f1 +NAT-1K1 p ..FINSEQ-4K4 f2 implies ((f1 ^FINSEQ-1K8 f2).FUNCT-1K1 i =XBOOLE-0R4 (f1 ^FINSEQ-1K8 f2).FUNCT-1K1 (lenFINSEQ-1K4 f1 +NAT-1K1 p ..FINSEQ-4K4 f2) implies  False )"
    proof(rule ballI,rule impMI ,rule impI)
      fix i assume [ty]: "i be NatNAT-1M1"
      assume A5: "\<one>\<^sub>M <=XXREAL-0R1 i"
        and A6: "i <XXREAL-0R3 lenFINSEQ-1K4 f1 +NAT-1K1 p ..FINSEQ-4K4 f2"
      show "(f1 ^FINSEQ-1K8 f2).FUNCT-1K1 i =XBOOLE-0R4 (f1 ^FINSEQ-1K8 f2).FUNCT-1K1 (lenFINSEQ-1K4 f1 +NAT-1K1 p ..FINSEQ-4K4 f2) implies  False "
      proof-
        have cases: "i <=XXREAL-0R1 lenFINSEQ-1K4 f1 or i >XXREAL-0R4 lenFINSEQ-1K4 f1"
           sorry
        have case1: "i <=XXREAL-0R1 lenFINSEQ-1K4 f1 implies ((f1 ^FINSEQ-1K8 f2).FUNCT-1K1 i =XBOOLE-0R4 (f1 ^FINSEQ-1K8 f2).FUNCT-1K1 (lenFINSEQ-1K4 f1 +NAT-1K1 p ..FINSEQ-4K4 f2) implies  False )"
        proof(rule impI,rule impI)
          assume "i <=XXREAL-0R1 lenFINSEQ-1K4 f1"
          then have A7: "i inTARSKIR2 domFINSEQ-1K5 f1"
            using A5 finseq_3_th_25 sorry
          assume "(f1 ^FINSEQ-1K8 f2).FUNCT-1K1 i =XBOOLE-0R4 (f1 ^FINSEQ-1K8 f2).FUNCT-1K1 (lenFINSEQ-1K4 f1 +NAT-1K1 p ..FINSEQ-4K4 f2)"
          then have "f1 .FUNCT-1K1 i =XBOOLE-0R4 p"
            using A3 A7 finseq_1_def_7 sorry
          then have "p inTARSKIR2 rngFUNCT-1K2 f1"
            using A7 funct_1_def_3 sorry
          thus " False "
            using A1 xboole_0_def_5 sorry
        qed
        have case2: "i >XXREAL-0R4 lenFINSEQ-1K4 f1 implies (f1 ^FINSEQ-1K8 f2).FUNCT-1K1 i <>HIDDENR2 (f1 ^FINSEQ-1K8 f2).FUNCT-1K1 (lenFINSEQ-1K4 f1 +NAT-1K1 p ..FINSEQ-4K4 f2)"
        proof(rule impI)
          assume A8: "i >XXREAL-0R4 lenFINSEQ-1K4 f1"
          then obtain j where 
            [ty]:"j be ElementSUBSET-1M1-of NATNUMBERSK1" and jDef:"j = i -XCMPLX-0K6 lenFINSEQ-1K4 f1"
            using int_1_th_5 sorry
          have "j >XXREAL-0R4 0NUMBERSK6"
            using A8 xreal_1_th_50 sorry
          then have A9: "\<one>\<^sub>M <=XXREAL-0R1 j"
            using nat_1_th_14 sorry
          have A10: "i =XBOOLE-0R4 j +NAT-1K1 lenFINSEQ-1K4 f1"
             sorry
          then have A11: "j <XXREAL-0R3 p ..FINSEQ-4K4 f2"
            using A6 xreal_1_th_6 sorry
          have A12: "(f1 ^FINSEQ-1K8 f2).FUNCT-1K1 (lenFINSEQ-1K4 f1 +NAT-1K1 p ..FINSEQ-4K4 f2) =XBOOLE-0R4 f2 .FUNCT-1K1 (p ..FINSEQ-4K4 f2)"
            using A2 finseq_1_def_7 sorry
          have A13: "p ..FINSEQ-4K4 f2 <=XXREAL-0R1 lenFINSEQ-1K4 f2"
            using A1 finseq_4_th_21 sorry
          have "j <=XXREAL-0R1 p ..FINSEQ-4K4 f2"
            using A6 A10 xreal_1_th_6 sorry
          then have "j <=XXREAL-0R1 lenFINSEQ-1K4 f2"
            using A13 xxreal_0_th_2 sorry
          then have A14: "j inTARSKIR2 domFINSEQ-1K5 f2"
            using A9 finseq_3_th_25 sorry
          then have "(f1 ^FINSEQ-1K8 f2).FUNCT-1K1 i =XBOOLE-0R4 f2 .FUNCT-1K1 j"
            using A10 finseq_1_def_7 sorry
          thus "(f1 ^FINSEQ-1K8 f2).FUNCT-1K1 i <>HIDDENR2 (f1 ^FINSEQ-1K8 f2).FUNCT-1K1 (lenFINSEQ-1K4 f1 +NAT-1K1 p ..FINSEQ-4K4 f2)"
            using A1 A11 A14 A12 finseq_4_th_19 finseq_4_th_24 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    have "lenFINSEQ-1K4 f1 +NAT-1K1 p ..FINSEQ-4K4 f2 inTARSKIR2 domFINSEQ-1K5 (f1 ^FINSEQ-1K8 f2)"
      using A2 finseq_1_th_28 sorry
    thus "p ..FINSEQ-4K4 (f1 ^FINSEQ-1K8 f2) =XBOOLE-0R4 lenFINSEQ-1K4 f1 +NAT-1K1 p ..FINSEQ-4K4 f2"
      using A3 A4 finseq_6_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_8:
" for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  for p be setHIDDENM2 holds p inTARSKIR2 rngFUNCT-1K2 f1 implies f1 ^FINSEQ-1K8 f2  |--FINSEQ-4K6 p =FINSEQ-1R1 (f1  |--FINSEQ-4K6 p)^FINSEQ-1K8 f2"
proof-
  have " for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  for p be setHIDDENM2 holds p inTARSKIR2 rngFUNCT-1K2 f1 implies f1 ^FINSEQ-1K8 f2  |--FINSEQ-4K6 p =FINSEQ-1R1 (f1  |--FINSEQ-4K6 p)^FINSEQ-1K8 f2"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix f1 assume [ty]: "f1 be FinSequenceFINSEQ-1M1"
    fix f2 assume [ty]: "f2 be FinSequenceFINSEQ-1M1"
    fix p assume [ty]: "p be setHIDDENM2"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f1"
    then have A2: "p ..FINSEQ-4K4 f1 =XBOOLE-0R4 p ..FINSEQ-4K4 (f1 ^FINSEQ-1K8 f2)"
      using finseq_6_th_6 sorry
    have A3: "lenFINSEQ-1K4 (f1  |--FINSEQ-4K6 p) =XBOOLE-0R4 lenFINSEQ-1K4 f1 -XCMPLX-0K6 p ..FINSEQ-4K4 f1"
      using A1 finseq_4_def_6 sorry
    have A4: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 ((f1  |--FINSEQ-4K6 p)^FINSEQ-1K8 f2) implies ((f1  |--FINSEQ-4K6 p)^FINSEQ-1K8 f2).FUNCT-1K1 k =HIDDENR1 (f1 ^FINSEQ-1K8 f2).FUNCT-1K1 (k +NAT-1K1 p ..FINSEQ-4K4 (f1 ^FINSEQ-1K8 f2))"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume A5: "k inTARSKIR2 domFINSEQ-1K5 ((f1  |--FINSEQ-4K6 p)^FINSEQ-1K8 f2)"
      show "((f1  |--FINSEQ-4K6 p)^FINSEQ-1K8 f2).FUNCT-1K1 k =HIDDENR1 (f1 ^FINSEQ-1K8 f2).FUNCT-1K1 (k +NAT-1K1 p ..FINSEQ-4K4 (f1 ^FINSEQ-1K8 f2))"
      proof-
        have cases: "k inTARSKIR2 domFINSEQ-1K5 (f1  |--FINSEQ-4K6 p) or ( ex n be NatNAT-1M1 st n inTARSKIR2 domFINSEQ-1K5 f2 & k =XBOOLE-0R4 lenFINSEQ-1K4 (f1  |--FINSEQ-4K6 p) +XCMPLX-0K2 n)"
          using A5 finseq_1_th_25 sorry
        have case1: "k inTARSKIR2 domFINSEQ-1K5 (f1  |--FINSEQ-4K6 p) implies ((f1  |--FINSEQ-4K6 p)^FINSEQ-1K8 f2).FUNCT-1K1 k =HIDDENR1 (f1 ^FINSEQ-1K8 f2).FUNCT-1K1 (k +NAT-1K1 p ..FINSEQ-4K4 (f1 ^FINSEQ-1K8 f2))"
        proof(rule impI)
          assume A6: "k inTARSKIR2 domFINSEQ-1K5 (f1  |--FINSEQ-4K6 p)"
          have "lenFINSEQ-1K4 (f1  |--FINSEQ-4K6 p) =XBOOLE-0R4 lenFINSEQ-1K4 f1 -XCMPLX-0K6 p ..FINSEQ-4K4 f1"
            using A1 finseq_4_def_6 sorry
          then have A7: "lenFINSEQ-1K4 (f1  |--FINSEQ-4K6 p) +NAT-1K1 p ..FINSEQ-4K4 f1 =XBOOLE-0R4 lenFINSEQ-1K4 f1"
             sorry
          have "k <=XXREAL-0R1 lenFINSEQ-1K4 (f1  |--FINSEQ-4K6 p)"
            using A6 finseq_3_th_25 sorry
          then have A8: "k +NAT-1K1 p ..FINSEQ-4K4 f1 <=XXREAL-0R1 lenFINSEQ-1K4 f1"
            using A7 xreal_1_th_6 sorry
          have A9: "k <=XXREAL-0R1 k +NAT-1K1 p ..FINSEQ-4K4 f1"
            using nat_1_th_11 sorry
          have "\<one>\<^sub>M <=XXREAL-0R1 k"
            using A6 finseq_3_th_25 sorry
          then have "\<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 p ..FINSEQ-4K4 f1"
            using A9 xxreal_0_th_2 sorry
          then have A10: "k +NAT-1K1 p ..FINSEQ-4K4 f1 inTARSKIR2 domFINSEQ-1K5 f1"
            using A8 finseq_3_th_25 sorry
          have "((f1  |--FINSEQ-4K6 p)^FINSEQ-1K8 f2).FUNCT-1K1 k =HIDDENR1 (f1  |--FINSEQ-4K6 p).FUNCT-1K1 k"
            using A6 finseq_1_def_7 sorry
          also have "... = f1 .FUNCT-1K1 (k +NAT-1K1 p ..FINSEQ-4K4 f1)"
            using A1 A6 finseq_4_def_6 sorry
          also have "... = (f1 ^FINSEQ-1K8 f2).FUNCT-1K1 (k +NAT-1K1 p ..FINSEQ-4K4 (f1 ^FINSEQ-1K8 f2))"
            using A2 A10 finseq_1_def_7 sorry
          finally show "((f1  |--FINSEQ-4K6 p)^FINSEQ-1K8 f2).FUNCT-1K1 k =HIDDENR1 (f1 ^FINSEQ-1K8 f2).FUNCT-1K1 (k +NAT-1K1 p ..FINSEQ-4K4 (f1 ^FINSEQ-1K8 f2))"
             sorry
        qed
        have case2: "( ex n be NatNAT-1M1 st n inTARSKIR2 domFINSEQ-1K5 f2 & k =XBOOLE-0R4 lenFINSEQ-1K4 (f1  |--FINSEQ-4K6 p) +XCMPLX-0K2 n) implies ((f1  |--FINSEQ-4K6 p)^FINSEQ-1K8 f2).FUNCT-1K1 k =HIDDENR1 (f1 ^FINSEQ-1K8 f2).FUNCT-1K1 (k +NAT-1K1 p ..FINSEQ-4K4 (f1 ^FINSEQ-1K8 f2))"
        proof(rule impI)
          assume " ex n be NatNAT-1M1 st n inTARSKIR2 domFINSEQ-1K5 f2 & k =XBOOLE-0R4 lenFINSEQ-1K4 (f1  |--FINSEQ-4K6 p) +XCMPLX-0K2 n"
          then obtain n where
            [ty]:"n be NatNAT-1M1" and 
            A11: "n inTARSKIR2 domFINSEQ-1K5 f2"and A12: "k =XBOOLE-0R4 lenFINSEQ-1K4 (f1  |--FINSEQ-4K6 p) +XCMPLX-0K2 n"
             sorry
          have "((f1  |--FINSEQ-4K6 p)^FINSEQ-1K8 f2).FUNCT-1K1 k =HIDDENR1 f2 .FUNCT-1K1 n"
            using A11 A12 finseq_1_def_7 sorry
          also have "... = (f1 ^FINSEQ-1K8 f2).FUNCT-1K1 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 n)"
            using A11 finseq_1_def_7 sorry
          also have "... = (f1 ^FINSEQ-1K8 f2).FUNCT-1K1 (k +NAT-1K1 p ..FINSEQ-4K4 (f1 ^FINSEQ-1K8 f2))"
            using A2 A3 A12 sorry
          finally show "((f1  |--FINSEQ-4K6 p)^FINSEQ-1K8 f2).FUNCT-1K1 k =HIDDENR1 (f1 ^FINSEQ-1K8 f2).FUNCT-1K1 (k +NAT-1K1 p ..FINSEQ-4K4 (f1 ^FINSEQ-1K8 f2))"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    have "rngFUNCT-1K2 (f1 ^FINSEQ-1K8 f2) =XBOOLE-0R4 rngFUNCT-1K2 f1 \\/XBOOLE-0K2 rngFUNCT-1K2 f2"
      using finseq_1_th_31 sorry
    then have A13: "p inTARSKIR2 rngFUNCT-1K2 (f1 ^FINSEQ-1K8 f2)"
      using A1 xboole_0_def_3 sorry
    have "lenFINSEQ-1K4 ((f1  |--FINSEQ-4K6 p)^FINSEQ-1K8 f2) =HIDDENR1 (lenFINSEQ-1K4 f1 -XCMPLX-0K6 p ..FINSEQ-4K4 f1)+XCMPLX-0K2 lenFINSEQ-1K4 f2"
      using A3 finseq_1_th_22 sorry
    also have "... = (lenFINSEQ-1K4 f1 +NAT-1K1 lenFINSEQ-1K4 f2)-XCMPLX-0K6 p ..FINSEQ-4K4 f1"
       sorry
    also have "... = lenFINSEQ-1K4 (f1 ^FINSEQ-1K8 f2) -XCMPLX-0K6 p ..FINSEQ-4K4 (f1 ^FINSEQ-1K8 f2)"
      using A2 finseq_1_th_22 sorry
    finally have "lenFINSEQ-1K4 ((f1  |--FINSEQ-4K6 p)^FINSEQ-1K8 f2) =HIDDENR1 lenFINSEQ-1K4 (f1 ^FINSEQ-1K8 f2) -XCMPLX-0K6 p ..FINSEQ-4K4 (f1 ^FINSEQ-1K8 f2)"
       sorry
    thus "f1 ^FINSEQ-1K8 f2  |--FINSEQ-4K6 p =FINSEQ-1R1 (f1  |--FINSEQ-4K6 p)^FINSEQ-1K8 f2"
      using A13 A4 finseq_4_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_9:
" for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  for p be setHIDDENM2 holds p inTARSKIR2 rngFUNCT-1K2 f2 \\SUBSET-1K6 rngFUNCT-1K2 f1 implies f1 ^FINSEQ-1K8 f2  |--FINSEQ-4K6 p =FINSEQ-1R1 f2  |--FINSEQ-4K6 p"
proof-
  have " for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  for p be setHIDDENM2 holds p inTARSKIR2 rngFUNCT-1K2 f2 \\SUBSET-1K6 rngFUNCT-1K2 f1 implies f1 ^FINSEQ-1K8 f2  |--FINSEQ-4K6 p =FINSEQ-1R1 f2  |--FINSEQ-4K6 p"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix f1 assume [ty]: "f1 be FinSequenceFINSEQ-1M1"
    fix f2 assume [ty]: "f2 be FinSequenceFINSEQ-1M1"
    fix p assume [ty]: "p be setHIDDENM2"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f2 \\SUBSET-1K6 rngFUNCT-1K2 f1"
    then have A2: "lenFINSEQ-1K4 f1 +NAT-1K1 p ..FINSEQ-4K4 f2 =XBOOLE-0R4 p ..FINSEQ-4K4 (f1 ^FINSEQ-1K8 f2)"
      using finseq_6_th_7 sorry
    have A3: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 (f2  |--FINSEQ-4K6 p) implies (f2  |--FINSEQ-4K6 p).FUNCT-1K1 k =HIDDENR1 (f1 ^FINSEQ-1K8 f2).FUNCT-1K1 (k +NAT-1K1 p ..FINSEQ-4K4 (f1 ^FINSEQ-1K8 f2))"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      have A4: "k <=XXREAL-0R1 k +NAT-1K1 p ..FINSEQ-4K4 f2"
        using nat_1_th_11 sorry
      have "lenFINSEQ-1K4 (f2  |--FINSEQ-4K6 p) =XBOOLE-0R4 lenFINSEQ-1K4 f2 -XCMPLX-0K6 p ..FINSEQ-4K4 f2"
        using A1 finseq_4_def_6 sorry
      then have A5: "lenFINSEQ-1K4 (f2  |--FINSEQ-4K6 p) +NAT-1K1 p ..FINSEQ-4K4 f2 =XBOOLE-0R4 lenFINSEQ-1K4 f2"
         sorry
      assume A6: "k inTARSKIR2 domFINSEQ-1K5 (f2  |--FINSEQ-4K6 p)"
      then have "k <=XXREAL-0R1 lenFINSEQ-1K4 (f2  |--FINSEQ-4K6 p)"
        using finseq_3_th_25 sorry
      then have A7: "k +NAT-1K1 p ..FINSEQ-4K4 f2 <=XXREAL-0R1 lenFINSEQ-1K4 f2"
        using A5 xreal_1_th_6 sorry
      have "\<one>\<^sub>M <=XXREAL-0R1 k"
        using A6 finseq_3_th_25 sorry
      then have "\<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 p ..FINSEQ-4K4 f2"
        using A4 xxreal_0_th_2 sorry
      then have A8: "k +NAT-1K1 p ..FINSEQ-4K4 f2 inTARSKIR2 domFINSEQ-1K5 f2"
        using A7 finseq_3_th_25 sorry
      have "(f2  |--FINSEQ-4K6 p).FUNCT-1K1 k =HIDDENR1 f2 .FUNCT-1K1 (k +NAT-1K1 p ..FINSEQ-4K4 f2)"
        using A1 A6 finseq_4_def_6 sorry
      also have "... = (f1 ^FINSEQ-1K8 f2).FUNCT-1K1 (lenFINSEQ-1K4 f1 +NAT-1K1 (k +NAT-1K1 p ..FINSEQ-4K4 f2))"
        using A8 finseq_1_def_7 sorry
      also have "... = (f1 ^FINSEQ-1K8 f2).FUNCT-1K1 (k +NAT-1K1 p ..FINSEQ-4K4 (f1 ^FINSEQ-1K8 f2))"
        using A2 sorry
      finally show "(f2  |--FINSEQ-4K6 p).FUNCT-1K1 k =HIDDENR1 (f1 ^FINSEQ-1K8 f2).FUNCT-1K1 (k +NAT-1K1 p ..FINSEQ-4K4 (f1 ^FINSEQ-1K8 f2))"
         sorry
    qed "sorry"
    have "rngFUNCT-1K2 (f1 ^FINSEQ-1K8 f2) =XBOOLE-0R4 rngFUNCT-1K2 f1 \\/XBOOLE-0K2 rngFUNCT-1K2 f2"
      using finseq_1_th_31 sorry
    then have A9: "p inTARSKIR2 rngFUNCT-1K2 (f1 ^FINSEQ-1K8 f2)"
      using A1 xboole_0_def_3 sorry
    have "lenFINSEQ-1K4 (f2  |--FINSEQ-4K6 p) =HIDDENR1 lenFINSEQ-1K4 f2 -XCMPLX-0K6 p ..FINSEQ-4K4 f2"
      using A1 finseq_4_def_6 sorry
    also have "... = (lenFINSEQ-1K4 f1 +NAT-1K1 lenFINSEQ-1K4 f2)-XCMPLX-0K6 (lenFINSEQ-1K4 f1 +NAT-1K1 p ..FINSEQ-4K4 f2)"
       sorry
    also have "... = lenFINSEQ-1K4 (f1 ^FINSEQ-1K8 f2) -XCMPLX-0K6 p ..FINSEQ-4K4 (f1 ^FINSEQ-1K8 f2)"
      using A2 finseq_1_th_22 sorry
    finally have "lenFINSEQ-1K4 (f2  |--FINSEQ-4K6 p) =HIDDENR1 lenFINSEQ-1K4 (f1 ^FINSEQ-1K8 f2) -XCMPLX-0K6 p ..FINSEQ-4K4 (f1 ^FINSEQ-1K8 f2)"
       sorry
    thus "f1 ^FINSEQ-1K8 f2  |--FINSEQ-4K6 p =FINSEQ-1R1 f2  |--FINSEQ-4K6 p"
      using A9 A3 finseq_4_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_10:
" for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds f1 c=RELAT-1R2 f1 ^FINSEQ-1K8 f2"
proof-
  have " for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds f1 c=RELAT-1R2 f1 ^FINSEQ-1K8 f2"
  proof(rule ballI,rule ballI)
    fix f1 assume [ty]: "f1 be FinSequenceFINSEQ-1M1"
    fix f2 assume [ty]: "f2 be FinSequenceFINSEQ-1M1"
    have A1: " for x be objectHIDDENM1 holds x inHIDDENR3 domFINSEQ-1K5 f1 implies f1 .FUNCT-1K1 x =XBOOLE-0R4 (f1 ^FINSEQ-1K8 f2).FUNCT-1K1 x"
      using finseq_1_def_7 sorry
    have "domFINSEQ-1K5 f1 c=TARSKIR1 domFINSEQ-1K5 (f1 ^FINSEQ-1K8 f2)"
      using finseq_1_th_26 sorry
    thus "f1 c=RELAT-1R2 f1 ^FINSEQ-1K8 f2"
      using A1 grfunc_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_11:
" for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  for A be setHIDDENM2 holds A c=TARSKIR1 domFINSEQ-1K5 f1 implies (f1 ^FINSEQ-1K8 f2) |RELAT-1K8 A =FUNCT-1R1 f1  |RELAT-1K8 A"
  using finseq_6_th_10 grfunc_1_th_27 sorry

mtheorem finseq_6_th_12:
" for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  for p be setHIDDENM2 holds p inTARSKIR2 rngFUNCT-1K2 f1 implies f1 ^FINSEQ-1K8 f2 -|FINSEQ-4K5 p =FINSEQ-1R1 f1 -|FINSEQ-4K5 p"
proof-
  have " for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  for p be setHIDDENM2 holds p inTARSKIR2 rngFUNCT-1K2 f1 implies f1 ^FINSEQ-1K8 f2 -|FINSEQ-4K5 p =FINSEQ-1R1 f1 -|FINSEQ-4K5 p"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix f1 assume [ty]: "f1 be FinSequenceFINSEQ-1M1"
    fix f2 assume [ty]: "f2 be FinSequenceFINSEQ-1M1"
    fix p assume [ty]: "p be setHIDDENM2"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f1"
    then obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A2: "n =XBOOLE-0R4 p ..FINSEQ-4K4 f1 -XCMPLX-0K6 \<one>\<^sub>M"and A3: "f1  |RELAT-1K8 SegFINSEQ-1K2 n =FUNCT-1R1 f1 -|FINSEQ-4K5 p"
      using finseq_4_def_5 sorry
    have A4: "p ..FINSEQ-4K4 f1 <=XXREAL-0R1 lenFINSEQ-1K4 f1"
      using A1 finseq_4_th_21 sorry
    have "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 p ..FINSEQ-4K4 f1"
      using A2 sorry
    then have "n <=XXREAL-0R1 p ..FINSEQ-4K4 f1"
      using nat_1_th_11 sorry
    then have "n <=XXREAL-0R1 lenFINSEQ-1K4 f1"
      using A4 xxreal_0_th_2 sorry
    then have "SegFINSEQ-1K2 n c=TARSKIR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 f1)"
      using finseq_1_th_5 sorry
    then have "SegFINSEQ-1K2 n c=TARSKIR1 domFINSEQ-1K5 f1"
      using finseq_1_def_3 sorry
    then have A5: "(f1 ^FINSEQ-1K8 f2) |RELAT-1K8 SegFINSEQ-1K2 n =FUNCT-1R1 f1  |RELAT-1K8 SegFINSEQ-1K2 n"
      using finseq_6_th_10 grfunc_1_th_27 sorry
    have "rngFUNCT-1K2 (f1 ^FINSEQ-1K8 f2) =XBOOLE-0R4 rngFUNCT-1K2 f1 \\/XBOOLE-0K2 rngFUNCT-1K2 f2"
      using finseq_1_th_31 sorry
    then have A6: "p inTARSKIR2 rngFUNCT-1K2 (f1 ^FINSEQ-1K8 f2)"
      using A1 xboole_0_def_3 sorry
    have "n =XBOOLE-0R4 p ..FINSEQ-4K4 (f1 ^FINSEQ-1K8 f2) -XCMPLX-0K6 \<one>\<^sub>M"
      using A1 A2 finseq_6_th_6 sorry
    thus "f1 ^FINSEQ-1K8 f2 -|FINSEQ-4K5 p =FINSEQ-1R1 f1 -|FINSEQ-4K5 p"
      using A3 A6 A5 finseq_4_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_cl_3:
  mlet "f1 be FinSequenceFINSEQ-1M1", "i be NatNAT-1M1"
"cluster f1  |RELAT-1K8 SegFINSEQ-1K2 i as-term-is FinSequence-likeFINSEQ-1V1"
proof
(*coherence*)
  show "f1  |RELAT-1K8 SegFINSEQ-1K2 i be FinSequence-likeFINSEQ-1V1"
    using finseq_1_th_15 sorry
qed "sorry"

mtheorem finseq_6_th_13:
" for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  for f3 be FinSequenceFINSEQ-1M1 holds f1 c=RELAT-1R2 f2 implies f3 ^FINSEQ-1K8 f1 c=RELAT-1R2 f3 ^FINSEQ-1K8 f2"
proof-
  have " for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  for f3 be FinSequenceFINSEQ-1M1 holds f1 c=RELAT-1R2 f2 implies f3 ^FINSEQ-1K8 f1 c=RELAT-1R2 f3 ^FINSEQ-1K8 f2"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix f1 assume [ty]: "f1 be FinSequenceFINSEQ-1M1"
    fix f2 assume [ty]: "f2 be FinSequenceFINSEQ-1M1"
    fix f3 assume [ty]: "f3 be FinSequenceFINSEQ-1M1"
    assume A1: "f1 c=RELAT-1R2 f2"
    have A2: "domFINSEQ-1K5 (f3 ^FINSEQ-1K8 f1) c=TARSKIR1 domFINSEQ-1K5 (f3 ^FINSEQ-1K8 f2)"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domFINSEQ-1K5 (f3 ^FINSEQ-1K8 f1) implies x inHIDDENR3 domFINSEQ-1K5 (f3 ^FINSEQ-1K8 f2)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A3: "x inHIDDENR3 domFINSEQ-1K5 (f3 ^FINSEQ-1K8 f1)"
        then obtain i where 
          [ty]:"i be NatNAT-1M1" and iDef:"i = x"
           sorry
        show "x inHIDDENR3 domFINSEQ-1K5 (f3 ^FINSEQ-1K8 f2)"
        proof-
          have cases: "i inTARSKIR2 domFINSEQ-1K5 f3 or ( ex n be NatNAT-1M1 st n inTARSKIR2 domFINSEQ-1K5 f1 & i =XBOOLE-0R4 lenFINSEQ-1K4 f3 +XCMPLX-0K2 n)"
            using A3 finseq_1_th_25 sorry
          have case1: "i inTARSKIR2 domFINSEQ-1K5 f3 implies x inHIDDENR3 domFINSEQ-1K5 (f3 ^FINSEQ-1K8 f2)"
          proof(rule impI)
            assume A4: "i inTARSKIR2 domFINSEQ-1K5 f3"
            have "domFINSEQ-1K5 f3 c=TARSKIR1 domFINSEQ-1K5 (f3 ^FINSEQ-1K8 f2)"
              using finseq_1_th_26 sorry
            thus "x inHIDDENR3 domFINSEQ-1K5 (f3 ^FINSEQ-1K8 f2)"
              using A4 sorry
          qed
          have case2: "( ex n be NatNAT-1M1 st n inTARSKIR2 domFINSEQ-1K5 f1 & i =XBOOLE-0R4 lenFINSEQ-1K4 f3 +XCMPLX-0K2 n) implies x inHIDDENR3 domFINSEQ-1K5 (f3 ^FINSEQ-1K8 f2)"
          proof(rule impI)
            assume A5: " ex n be NatNAT-1M1 st n inTARSKIR2 domFINSEQ-1K5 f1 & i =XBOOLE-0R4 lenFINSEQ-1K4 f3 +XCMPLX-0K2 n"
            have "domFINSEQ-1K5 f1 c=TARSKIR1 domFINSEQ-1K5 f2"
              using A1 relat_1_th_11 sorry
            thus "x inHIDDENR3 domFINSEQ-1K5 (f3 ^FINSEQ-1K8 f2)"
              using A5 finseq_1_th_28 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus "domFINSEQ-1K5 (f3 ^FINSEQ-1K8 f1) c=TARSKIR1 domFINSEQ-1K5 (f3 ^FINSEQ-1K8 f2)"
        using tarski_def_3 sorry
    qed
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domFINSEQ-1K5 (f3 ^FINSEQ-1K8 f1) implies (f3 ^FINSEQ-1K8 f1).FUNCT-1K1 x =XBOOLE-0R4 (f3 ^FINSEQ-1K8 f2).FUNCT-1K1 x"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domFINSEQ-1K5 (f3 ^FINSEQ-1K8 f1) implies (f3 ^FINSEQ-1K8 f1).FUNCT-1K1 x =HIDDENR1 (f3 ^FINSEQ-1K8 f2).FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A6: "x inHIDDENR3 domFINSEQ-1K5 (f3 ^FINSEQ-1K8 f1)"
        then obtain i where 
          [ty]:"i be NatNAT-1M1" and iDef:"i = x"
           sorry
        show "(f3 ^FINSEQ-1K8 f1).FUNCT-1K1 x =HIDDENR1 (f3 ^FINSEQ-1K8 f2).FUNCT-1K1 x"
        proof-
          have cases: "i inTARSKIR2 domFINSEQ-1K5 f3 or ( ex n be NatNAT-1M1 st n inTARSKIR2 domFINSEQ-1K5 f1 & i =XBOOLE-0R4 lenFINSEQ-1K4 f3 +XCMPLX-0K2 n)"
            using A6 finseq_1_th_25 sorry
          have case1: "i inTARSKIR2 domFINSEQ-1K5 f3 implies (f3 ^FINSEQ-1K8 f1).FUNCT-1K1 x =HIDDENR1 (f3 ^FINSEQ-1K8 f2).FUNCT-1K1 x"
          proof(rule impI)
            assume A7: "i inTARSKIR2 domFINSEQ-1K5 f3"
            then have "(f3 ^FINSEQ-1K8 f1).FUNCT-1K1 x =HIDDENR1 f3 .FUNCT-1K1 i"
              using finseq_1_def_7 sorry
            also have "... = (f3 ^FINSEQ-1K8 f2).FUNCT-1K1 x"
              using A7 finseq_1_def_7 sorry
            finally show "(f3 ^FINSEQ-1K8 f1).FUNCT-1K1 x =HIDDENR1 (f3 ^FINSEQ-1K8 f2).FUNCT-1K1 x"
               sorry
          qed
          have case2: "( ex n be NatNAT-1M1 st n inTARSKIR2 domFINSEQ-1K5 f1 & i =XBOOLE-0R4 lenFINSEQ-1K4 f3 +XCMPLX-0K2 n) implies (f3 ^FINSEQ-1K8 f1).FUNCT-1K1 x =HIDDENR1 (f3 ^FINSEQ-1K8 f2).FUNCT-1K1 x"
          proof(rule impI)
            assume A8: " ex n be NatNAT-1M1 st n inTARSKIR2 domFINSEQ-1K5 f1 & i =XBOOLE-0R4 lenFINSEQ-1K4 f3 +XCMPLX-0K2 n"
            have A9: "domFINSEQ-1K5 f1 c=TARSKIR1 domFINSEQ-1K5 f2"
              using A1 relat_1_th_11 sorry
            obtain k where
              [ty]:"k be NatNAT-1M1" and 
              A10: "k inTARSKIR2 domFINSEQ-1K5 f1"and A11: "i =XBOOLE-0R4 lenFINSEQ-1K4 f3 +XCMPLX-0K2 k"
              using A8 sorry
            have "(f3 ^FINSEQ-1K8 f1).FUNCT-1K1 x =HIDDENR1 f1 .FUNCT-1K1 k"
              using A10 A11 finseq_1_def_7 sorry
            also have "... = f2 .FUNCT-1K1 k"
              using A1 A10 grfunc_1_th_2 sorry
            also have "... = (f3 ^FINSEQ-1K8 f2).FUNCT-1K1 x"
              using A10 A11 A9 finseq_1_def_7 sorry
            finally show "(f3 ^FINSEQ-1K8 f1).FUNCT-1K1 x =HIDDENR1 (f3 ^FINSEQ-1K8 f2).FUNCT-1K1 x"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "f3 ^FINSEQ-1K8 f1 c=RELAT-1R2 f3 ^FINSEQ-1K8 f2"
      using A2 grfunc_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_14:
" for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  for i be NatNAT-1M1 holds (f1 ^FINSEQ-1K8 f2) |RELAT-1K8 SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 i) =FINSEQ-1R1 f1 ^FINSEQ-1K8 f2  |RELAT-1K8 SegFINSEQ-1K2 i"
proof-
  have " for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  for i be NatNAT-1M1 holds (f1 ^FINSEQ-1K8 f2) |RELAT-1K8 SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 i) =FINSEQ-1R1 f1 ^FINSEQ-1K8 f2  |RELAT-1K8 SegFINSEQ-1K2 i"
  proof(rule ballI,rule ballI,rule ballI)
    fix f1 assume [ty]: "f1 be FinSequenceFINSEQ-1M1"
    fix f2 assume [ty]: "f2 be FinSequenceFINSEQ-1M1"
    fix i assume [ty]: "i be NatNAT-1M1"
    have A1: "domFINSEQ-1K5 (f1 ^FINSEQ-1K8 f2  |RELAT-1K8 SegFINSEQ-1K2 i) c=TARSKIR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 i)"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domFINSEQ-1K5 (f1 ^FINSEQ-1K8 f2  |RELAT-1K8 SegFINSEQ-1K2 i) implies x inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 i)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A2: "x inHIDDENR3 domFINSEQ-1K5 (f1 ^FINSEQ-1K8 f2  |RELAT-1K8 SegFINSEQ-1K2 i)"
        then obtain j where 
          [ty]:"j be NatNAT-1M1" and jDef:"j = x"
           sorry
        show "x inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 i)"
        proof-
          have cases: "j inTARSKIR2 domFINSEQ-1K5 f1 or ( ex n be NatNAT-1M1 st n inTARSKIR2 domFINSEQ-1K5 (f2  |RELAT-1K8 SegFINSEQ-1K2 i) & j =XBOOLE-0R4 lenFINSEQ-1K4 f1 +XCMPLX-0K2 n)"
            using A2 finseq_1_th_25 sorry
          have case1: "j inTARSKIR2 domFINSEQ-1K5 f1 implies x inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 i)"
          proof(rule impI)
            assume A3: "j inTARSKIR2 domFINSEQ-1K5 f1"
            have "lenFINSEQ-1K4 f1 <=XXREAL-0R1 lenFINSEQ-1K4 f1 +XCMPLX-0K2 i"
              using nat_1_th_11 sorry
            then have A4: "SegFINSEQ-1K2 (lenFINSEQ-1K4 f1) c=TARSKIR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 i)"
              using finseq_1_th_5 sorry
            have "j inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 f1)"
              using A3 finseq_1_def_3 sorry
            thus "x inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 i)"
              using A4 sorry
          qed
          have case2: "( ex n be NatNAT-1M1 st n inTARSKIR2 domFINSEQ-1K5 (f2  |RELAT-1K8 SegFINSEQ-1K2 i) & j =XBOOLE-0R4 lenFINSEQ-1K4 f1 +XCMPLX-0K2 n) implies x inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 i)"
          proof(rule impI)
            assume " ex n be NatNAT-1M1 st n inTARSKIR2 domFINSEQ-1K5 (f2  |RELAT-1K8 SegFINSEQ-1K2 i) & j =XBOOLE-0R4 lenFINSEQ-1K4 f1 +XCMPLX-0K2 n"
            then obtain k where
              [ty]:"k be NatNAT-1M1" and 
              A5: "k inTARSKIR2 domFINSEQ-1K5 (f2  |RELAT-1K8 SegFINSEQ-1K2 i)"and A6: "j =XBOOLE-0R4 lenFINSEQ-1K4 f1 +XCMPLX-0K2 k"
               sorry
            have A7: "k <=XXREAL-0R1 j"
              using A6 nat_1_th_11 sorry
            have "domFINSEQ-1K5 (f2  |RELAT-1K8 SegFINSEQ-1K2 i) =XBOOLE-0R4 domFINSEQ-1K5 f2 /\\SUBSET-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> SegFINSEQ-1K2 i"
              using relat_1_th_61 sorry
            then have "k inTARSKIR2 SegFINSEQ-1K2 i"
              using A5 xboole_0_def_4 sorry
            then have "k <=XXREAL-0R1 i"
              using finseq_1_th_1 sorry
            then have A8: "j <=XXREAL-0R1 lenFINSEQ-1K4 f1 +XCMPLX-0K2 i"
              using A6 xreal_1_th_6 sorry
            have "\<one>\<^sub>M <=XXREAL-0R1 k"
              using A5 finseq_3_th_25 sorry
            then have "\<one>\<^sub>M <=XXREAL-0R1 j"
              using A7 xxreal_0_th_2 sorry
            thus "x inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 i)"
              using A8 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus "domFINSEQ-1K5 (f1 ^FINSEQ-1K8 f2  |RELAT-1K8 SegFINSEQ-1K2 i) c=TARSKIR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 i)"
        using tarski_def_3 sorry
    qed
    have A9: "domFINSEQ-1K5 (f1 ^FINSEQ-1K8 f2) /\\SUBSET-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 i) c=TARSKIR1 domFINSEQ-1K5 (f1 ^FINSEQ-1K8 f2  |RELAT-1K8 SegFINSEQ-1K2 i)"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domFINSEQ-1K5 (f1 ^FINSEQ-1K8 f2) /\\SUBSET-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 i) implies x inHIDDENR3 domFINSEQ-1K5 (f1 ^FINSEQ-1K8 f2  |RELAT-1K8 SegFINSEQ-1K2 i)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A10: "x inHIDDENR3 domFINSEQ-1K5 (f1 ^FINSEQ-1K8 f2) /\\SUBSET-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 i)"
        then have A11: "x inHIDDENR3 domFINSEQ-1K5 (f1 ^FINSEQ-1K8 f2)"
          using xboole_0_def_4 sorry
        obtain j where 
          [ty]:"j be NatNAT-1M1" and jDef:"j = x"
          using A10 sorry
        show "x inHIDDENR3 domFINSEQ-1K5 (f1 ^FINSEQ-1K8 f2  |RELAT-1K8 SegFINSEQ-1K2 i)"
        proof-
          have cases: "j inTARSKIR2 domFINSEQ-1K5 f1 or ( ex n be NatNAT-1M1 st n inTARSKIR2 domFINSEQ-1K5 f2 & j =XBOOLE-0R4 lenFINSEQ-1K4 f1 +XCMPLX-0K2 n)"
            using A11 finseq_1_th_25 sorry
          have case1: "j inTARSKIR2 domFINSEQ-1K5 f1 implies x inHIDDENR3 domFINSEQ-1K5 (f1 ^FINSEQ-1K8 f2  |RELAT-1K8 SegFINSEQ-1K2 i)"
          proof(rule impI)
            assume A12: "j inTARSKIR2 domFINSEQ-1K5 f1"
            have "domFINSEQ-1K5 f1 c=TARSKIR1 domFINSEQ-1K5 (f1 ^FINSEQ-1K8 f2  |RELAT-1K8 SegFINSEQ-1K2 i)"
              using finseq_1_th_26 sorry
            thus "x inHIDDENR3 domFINSEQ-1K5 (f1 ^FINSEQ-1K8 f2  |RELAT-1K8 SegFINSEQ-1K2 i)"
              using A12 sorry
          qed
          have case2: "( ex n be NatNAT-1M1 st n inTARSKIR2 domFINSEQ-1K5 f2 & j =XBOOLE-0R4 lenFINSEQ-1K4 f1 +XCMPLX-0K2 n) implies x inHIDDENR3 domFINSEQ-1K5 (f1 ^FINSEQ-1K8 f2  |RELAT-1K8 SegFINSEQ-1K2 i)"
          proof(rule impI)
            assume " ex n be NatNAT-1M1 st n inTARSKIR2 domFINSEQ-1K5 f2 & j =XBOOLE-0R4 lenFINSEQ-1K4 f1 +XCMPLX-0K2 n"
            then obtain k where
              [ty]:"k be NatNAT-1M1" and 
              A13: "k inTARSKIR2 domFINSEQ-1K5 f2"and A14: "j =XBOOLE-0R4 lenFINSEQ-1K4 f1 +XCMPLX-0K2 k"
               sorry
            have A15: "\<one>\<^sub>M <=XXREAL-0R1 k"
              using A13 finseq_3_th_25 sorry
            have A16: "domFINSEQ-1K5 (f2  |RELAT-1K8 SegFINSEQ-1K2 i) =XBOOLE-0R4 domFINSEQ-1K5 f2 /\\SUBSET-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> SegFINSEQ-1K2 i"
              using relat_1_th_61 sorry
            have "j inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 i)"
              using A10 xboole_0_def_4 sorry
            then have "j <=XXREAL-0R1 lenFINSEQ-1K4 f1 +XCMPLX-0K2 i"
              using finseq_1_th_1 sorry
            then have "k <=XXREAL-0R1 i"
              using A14 xreal_1_th_6 sorry
            then have "k inTARSKIR2 SegFINSEQ-1K2 i"
              using A15 sorry
            then have "k inTARSKIR2 domFINSEQ-1K5 (f2  |RELAT-1K8 SegFINSEQ-1K2 i)"
              using A13 A16 xboole_0_def_4 sorry
            thus "x inHIDDENR3 domFINSEQ-1K5 (f1 ^FINSEQ-1K8 f2  |RELAT-1K8 SegFINSEQ-1K2 i)"
              using A14 finseq_1_th_28 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus "domFINSEQ-1K5 (f1 ^FINSEQ-1K8 f2) /\\SUBSET-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 i) c=TARSKIR1 domFINSEQ-1K5 (f1 ^FINSEQ-1K8 f2  |RELAT-1K8 SegFINSEQ-1K2 i)"
        using tarski_def_3 sorry
    qed
    have A17: "domFINSEQ-1K5 ((f1 ^FINSEQ-1K8 f2) |RELAT-1K8 SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 i)) =XBOOLE-0R4 domFINSEQ-1K5 (f1 ^FINSEQ-1K8 f2) /\\SUBSET-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 i)"
      using relat_1_th_61 sorry
    have A18: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 ((f1 ^FINSEQ-1K8 f2) |RELAT-1K8 SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 i)) implies ((f1 ^FINSEQ-1K8 f2) |RELAT-1K8 SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 i)).FUNCT-1K1 k =HIDDENR1 (f1 ^FINSEQ-1K8 f2  |RELAT-1K8 SegFINSEQ-1K2 i).FUNCT-1K1 k"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume A19: "k inTARSKIR2 domFINSEQ-1K5 ((f1 ^FINSEQ-1K8 f2) |RELAT-1K8 SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 i))"
      then have A20: "\<one>\<^sub>M <=XXREAL-0R1 k"
        using finseq_3_th_25 sorry
      show "((f1 ^FINSEQ-1K8 f2) |RELAT-1K8 SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 i)).FUNCT-1K1 k =HIDDENR1 (f1 ^FINSEQ-1K8 f2  |RELAT-1K8 SegFINSEQ-1K2 i).FUNCT-1K1 k"
      proof-
        have cases: "k <=XXREAL-0R1 lenFINSEQ-1K4 f1 or k >XXREAL-0R4 lenFINSEQ-1K4 f1"
           sorry
        have case1: "k <=XXREAL-0R1 lenFINSEQ-1K4 f1 implies ((f1 ^FINSEQ-1K8 f2) |RELAT-1K8 SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 i)).FUNCT-1K1 k =HIDDENR1 (f1 ^FINSEQ-1K8 f2  |RELAT-1K8 SegFINSEQ-1K2 i).FUNCT-1K1 k"
        proof(rule impI)
          assume "k <=XXREAL-0R1 lenFINSEQ-1K4 f1"
          then have A21: "k inTARSKIR2 domFINSEQ-1K5 f1"
            using A20 finseq_3_th_25 sorry
          have "((f1 ^FINSEQ-1K8 f2) |RELAT-1K8 SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 i)).FUNCT-1K1 k =HIDDENR1 (f1 ^FINSEQ-1K8 f2).FUNCT-1K1 k"
            using A19 funct_1_th_47 sorry
          also have "... = f1 .FUNCT-1K1 k"
            using A21 finseq_1_def_7 sorry
          also have "... = (f1 ^FINSEQ-1K8 f2  |RELAT-1K8 SegFINSEQ-1K2 i).FUNCT-1K1 k"
            using A21 finseq_1_def_7 sorry
          finally show "((f1 ^FINSEQ-1K8 f2) |RELAT-1K8 SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 i)).FUNCT-1K1 k =HIDDENR1 (f1 ^FINSEQ-1K8 f2  |RELAT-1K8 SegFINSEQ-1K2 i).FUNCT-1K1 k"
             sorry
        qed
        have case2: "k >XXREAL-0R4 lenFINSEQ-1K4 f1 implies ((f1 ^FINSEQ-1K8 f2) |RELAT-1K8 SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 i)).FUNCT-1K1 k =HIDDENR1 (f1 ^FINSEQ-1K8 f2  |RELAT-1K8 SegFINSEQ-1K2 i).FUNCT-1K1 k"
        proof(rule impI)
          assume A22: "k >XXREAL-0R4 lenFINSEQ-1K4 f1"
          then obtain j where 
            [ty]:"j be ElementSUBSET-1M1-of NATNUMBERSK1" and jDef:"j = k -XCMPLX-0K6 lenFINSEQ-1K4 f1"
            using int_1_th_5 sorry
          have "j >XXREAL-0R4 0NUMBERSK6"
            using A22 xreal_1_th_50 sorry
          then have A23: "\<one>\<^sub>M <=XXREAL-0R1 j"
            using nat_1_th_14 sorry
          have A24: "k =XBOOLE-0R4 lenFINSEQ-1K4 f1 +NAT-1K1 j"
             sorry
          have A25: " not k inTARSKIR2 domFINSEQ-1K5 f1"
            using A22 finseq_3_th_25 sorry
          have "k inTARSKIR2 domFINSEQ-1K5 (f1 ^FINSEQ-1K8 f2)"
            using A17 A19 xboole_0_def_4 sorry
          then have A26: " ex n be NatNAT-1M1 st n inTARSKIR2 domFINSEQ-1K5 f2 & k =XBOOLE-0R4 lenFINSEQ-1K4 f1 +XCMPLX-0K2 n"
            using A25 finseq_1_th_25 sorry
          have "k inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 i)"
            using A17 A19 xboole_0_def_4 sorry
          then have "k <=XXREAL-0R1 lenFINSEQ-1K4 f1 +XCMPLX-0K2 i"
            using finseq_1_th_1 sorry
          then have "j <=XXREAL-0R1 i"
            using A24 xreal_1_th_6 sorry
          then have A27: "j inTARSKIR2 SegFINSEQ-1K2 i"
            using A23 sorry
          have "domFINSEQ-1K5 (f2  |RELAT-1K8 SegFINSEQ-1K2 i) =XBOOLE-0R4 domFINSEQ-1K5 f2 /\\SUBSET-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> SegFINSEQ-1K2 i"
            using relat_1_th_61 sorry
          then have A28: "j inTARSKIR2 domFINSEQ-1K5 (f2  |RELAT-1K8 SegFINSEQ-1K2 i)"
            using A27 A26 xboole_0_def_4 sorry
          have "((f1 ^FINSEQ-1K8 f2) |RELAT-1K8 SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 i)).FUNCT-1K1 k =HIDDENR1 (f1 ^FINSEQ-1K8 f2).FUNCT-1K1 k"
            using A19 funct_1_th_47 sorry
          also have "... = f2 .FUNCT-1K1 j"
            using A26 finseq_1_def_7 sorry
          also have "... = (f2  |RELAT-1K8 SegFINSEQ-1K2 i).FUNCT-1K1 j"
            using A28 funct_1_th_47 sorry
          also have "... = (f1 ^FINSEQ-1K8 f2  |RELAT-1K8 SegFINSEQ-1K2 i).FUNCT-1K1 k"
            using A24 A28 finseq_1_def_7 sorry
          finally show "((f1 ^FINSEQ-1K8 f2) |RELAT-1K8 SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 i)).FUNCT-1K1 k =HIDDENR1 (f1 ^FINSEQ-1K8 f2  |RELAT-1K8 SegFINSEQ-1K2 i).FUNCT-1K1 k"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    have "f1 ^FINSEQ-1K8 f2  |RELAT-1K8 SegFINSEQ-1K2 i c=RELAT-1R2 f1 ^FINSEQ-1K8 f2"
      using finseq_6_th_13 relat_1_th_59 sorry
    then have "domFINSEQ-1K5 (f1 ^FINSEQ-1K8 f2  |RELAT-1K8 SegFINSEQ-1K2 i) c=TARSKIR1 domFINSEQ-1K5 (f1 ^FINSEQ-1K8 f2)"
      using relat_1_th_11 sorry
    then have "domFINSEQ-1K5 (f1 ^FINSEQ-1K8 f2  |RELAT-1K8 SegFINSEQ-1K2 i) c=TARSKIR1 domFINSEQ-1K5 (f1 ^FINSEQ-1K8 f2) /\\SUBSET-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 i)"
      using A1 xboole_1_th_19 sorry
    then have "domFINSEQ-1K5 ((f1 ^FINSEQ-1K8 f2) |RELAT-1K8 SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 i)) =XBOOLE-0R4 domFINSEQ-1K5 (f1 ^FINSEQ-1K8 f2  |RELAT-1K8 SegFINSEQ-1K2 i)"
      using A17 A9 sorry
    thus "(f1 ^FINSEQ-1K8 f2) |RELAT-1K8 SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 i) =FINSEQ-1R1 f1 ^FINSEQ-1K8 f2  |RELAT-1K8 SegFINSEQ-1K2 i"
      using A18 finseq_1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_15:
" for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  for p be setHIDDENM2 holds p inTARSKIR2 rngFUNCT-1K2 f2 \\SUBSET-1K6 rngFUNCT-1K2 f1 implies f1 ^FINSEQ-1K8 f2 -|FINSEQ-4K5 p =FINSEQ-1R1 f1 ^FINSEQ-1K8 (f2 -|FINSEQ-4K5 p)"
proof-
  have " for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  for p be setHIDDENM2 holds p inTARSKIR2 rngFUNCT-1K2 f2 \\SUBSET-1K6 rngFUNCT-1K2 f1 implies f1 ^FINSEQ-1K8 f2 -|FINSEQ-4K5 p =FINSEQ-1R1 f1 ^FINSEQ-1K8 (f2 -|FINSEQ-4K5 p)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix f1 assume [ty]: "f1 be FinSequenceFINSEQ-1M1"
    fix f2 assume [ty]: "f2 be FinSequenceFINSEQ-1M1"
    fix p assume [ty]: "p be setHIDDENM2"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f2 \\SUBSET-1K6 rngFUNCT-1K2 f1"
    then obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A2: "n =XBOOLE-0R4 p ..FINSEQ-4K4 f2 -XCMPLX-0K6 \<one>\<^sub>M"and A3: "f2  |RELAT-1K8 SegFINSEQ-1K2 n =FINSEQ-1R1 f2 -|FINSEQ-4K5 p"
      using finseq_4_def_5 sorry
    have "p ..FINSEQ-4K4 (f1 ^FINSEQ-1K8 f2) =XBOOLE-0R4 lenFINSEQ-1K4 f1 +NAT-1K1 p ..FINSEQ-4K4 f2"
      using A1 finseq_6_th_7 sorry
    then have A4: "lenFINSEQ-1K4 f1 +XCMPLX-0K2 n =XBOOLE-0R4 p ..FINSEQ-4K4 (f1 ^FINSEQ-1K8 f2) -XCMPLX-0K6 \<one>\<^sub>M"
      using A2 sorry
    have "rngFUNCT-1K2 (f1 ^FINSEQ-1K8 f2) =XBOOLE-0R4 rngFUNCT-1K2 f1 \\/XBOOLE-0K2 rngFUNCT-1K2 f2"
      using finseq_1_th_31 sorry
    then have A5: "p inTARSKIR2 rngFUNCT-1K2 (f1 ^FINSEQ-1K8 f2)"
      using A1 xboole_0_def_3 sorry
    have "(f1 ^FINSEQ-1K8 f2) |RELAT-1K8 SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 n) =FINSEQ-1R1 f1 ^FINSEQ-1K8 (f2 -|FINSEQ-4K5 p)"
      using A3 finseq_6_th_14 sorry
    thus "f1 ^FINSEQ-1K8 f2 -|FINSEQ-4K5 p =FINSEQ-1R1 f1 ^FINSEQ-1K8 (f2 -|FINSEQ-4K5 p)"
      using A5 A4 finseq_4_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_16:
" for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  for p be setHIDDENM2 holds f1 ^FINSEQ-1K8 f2 just-once-valuesFINSEQ-4R2 p implies p inTARSKIR2 rngFUNCT-1K2 f1 \\+\\XBOOLE-0K5 rngFUNCT-1K2 f2"
proof-
  have " for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  for p be setHIDDENM2 holds f1 ^FINSEQ-1K8 f2 just-once-valuesFINSEQ-4R2 p implies p inTARSKIR2 rngFUNCT-1K2 f1 \\+\\XBOOLE-0K5 rngFUNCT-1K2 f2"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix f1 assume [ty]: "f1 be FinSequenceFINSEQ-1M1"
    fix f2 assume [ty]: "f2 be FinSequenceFINSEQ-1M1"
    fix p assume [ty]: "p be setHIDDENM2"
    have A1: "rngFUNCT-1K2 (f1 ^FINSEQ-1K8 f2) =XBOOLE-0R4 rngFUNCT-1K2 f1 \\/XBOOLE-0K2 rngFUNCT-1K2 f2"
      using finseq_1_th_31 sorry
    assume A2: "f1 ^FINSEQ-1K8 f2 just-once-valuesFINSEQ-4R2 p"
    have A3: "p inTARSKIR2 rngFUNCT-1K2 f1 /\\XBOOLE-0K3 rngFUNCT-1K2 f2 implies  False "
    proof(rule impI)
      assume A4: "p inTARSKIR2 rngFUNCT-1K2 f1 /\\XBOOLE-0K3 rngFUNCT-1K2 f2"
      then have "p inTARSKIR2 rngFUNCT-1K2 f1"
        using xboole_0_def_4 sorry
      then have "f1 ^FINSEQ-1K8 f2  |--FINSEQ-4K6 p =FINSEQ-1R1 (f1  |--FINSEQ-4K6 p)^FINSEQ-1K8 f2"
        using finseq_6_th_8 sorry
      then have A5: " not p inTARSKIR2 rngFUNCT-1K2 ((f1  |--FINSEQ-4K6 p)^FINSEQ-1K8 f2)"
        using A2 finseq_4_th_45 sorry
      have "rngFUNCT-1K2 ((f1  |--FINSEQ-4K6 p)^FINSEQ-1K8 f2) =XBOOLE-0R4 rngFUNCT-1K2 (f1  |--FINSEQ-4K6 p) \\/XBOOLE-0K2 rngFUNCT-1K2 f2"
        using finseq_1_th_31 sorry
      then have " not p inTARSKIR2 rngFUNCT-1K2 f2"
        using A5 xboole_0_def_3 sorry
      thus " False "
        using A4 xboole_0_def_4 sorry
    qed
    have "p inTARSKIR2 rngFUNCT-1K2 (f1 ^FINSEQ-1K8 f2)"
      using A2 finseq_4_th_5 sorry
    then have "p inTARSKIR2 (rngFUNCT-1K2 f1 \\/XBOOLE-0K2 rngFUNCT-1K2 f2)\\SUBSET-1K6 rngFUNCT-1K2 f1 /\\XBOOLE-0K3 rngFUNCT-1K2 f2"
      using A1 A3 xboole_0_def_5 sorry
    thus "p inTARSKIR2 rngFUNCT-1K2 f1 \\+\\XBOOLE-0K5 rngFUNCT-1K2 f2"
      using xboole_1_th_101 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_17:
" for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  for p be setHIDDENM2 holds f1 ^FINSEQ-1K8 f2 just-once-valuesFINSEQ-4R2 p & p inTARSKIR2 rngFUNCT-1K2 f1 implies f1 just-once-valuesFINSEQ-4R2 p"
proof-
  have " for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  for p be setHIDDENM2 holds f1 ^FINSEQ-1K8 f2 just-once-valuesFINSEQ-4R2 p & p inTARSKIR2 rngFUNCT-1K2 f1 implies f1 just-once-valuesFINSEQ-4R2 p"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix f1 assume [ty]: "f1 be FinSequenceFINSEQ-1M1"
    fix f2 assume [ty]: "f2 be FinSequenceFINSEQ-1M1"
    fix p assume [ty]: "p be setHIDDENM2"
    assume A1: "f1 ^FINSEQ-1K8 f2 just-once-valuesFINSEQ-4R2 p"
      and A2: "p inTARSKIR2 rngFUNCT-1K2 f1"
    have "f1 ^FINSEQ-1K8 f2  |--FINSEQ-4K6 p =FINSEQ-1R1 (f1  |--FINSEQ-4K6 p)^FINSEQ-1K8 f2"
      using A2 finseq_6_th_8 sorry
    then have A3: "rngFUNCT-1K2 (f1 ^FINSEQ-1K8 f2  |--FINSEQ-4K6 p) =XBOOLE-0R4 rngFUNCT-1K2 (f1  |--FINSEQ-4K6 p) \\/XBOOLE-0K2 rngFUNCT-1K2 f2"
      using finseq_1_th_31 sorry
    have " not p inTARSKIR2 rngFUNCT-1K2 (f1 ^FINSEQ-1K8 f2  |--FINSEQ-4K6 p)"
      using A1 finseq_4_th_45 sorry
    then have " not p inTARSKIR2 rngFUNCT-1K2 (f1  |--FINSEQ-4K6 p)"
      using A3 xboole_0_def_3 sorry
    thus "f1 just-once-valuesFINSEQ-4R2 p"
      using A2 finseq_4_th_45 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_18:
" for p be setHIDDENM2 holds p ..FINSEQ-4K4 (<*FINSEQ-1K10 p*>) =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for p be setHIDDENM2 holds p ..FINSEQ-4K4 (<*FINSEQ-1K10 p*>) =XBOOLE-0R4 \<one>\<^sub>M"
  proof(rule ballI)
    fix p assume [ty]: "p be setHIDDENM2"
    have A1: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 \<one>\<^sub>M implies (<*FINSEQ-1K10 p*>).FUNCT-1K1 i <>HIDDENR2 (<*FINSEQ-1K10 p*>).FUNCT-1K1 \<one>\<^sub>M"
       sorry
    have "domFINSEQ-1K5 (<*FINSEQ-1K10 p*>) =XBOOLE-0R4 SegFINSEQ-1K2 \<one>\<^sub>M"
      using finseq_1_th_38 sorry
    then have A2: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 p*>)"
       sorry
    have "(<*FINSEQ-1K10 p*>).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 p"
      using finseq_1_th_40 sorry
    thus "p ..FINSEQ-4K4 (<*FINSEQ-1K10 p*>) =XBOOLE-0R4 \<one>\<^sub>M"
      using A2 A1 finseq_6_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_19:
" for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds p1 ..FINSEQ-4K4 (<*FINSEQ-1K11 p1,p2 *>) =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds p1 ..FINSEQ-4K4 (<*FINSEQ-1K11 p1,p2 *>) =XBOOLE-0R4 \<one>\<^sub>M"
  proof(rule ballI,rule ballI)
    fix p1 assume [ty]: "p1 be setHIDDENM2"
    fix p2 assume [ty]: "p2 be setHIDDENM2"
    have A1: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 \<one>\<^sub>M implies (<*FINSEQ-1K11 p1,p2 *>).FUNCT-1K1 i <>HIDDENR2 (<*FINSEQ-1K11 p1,p2 *>).FUNCT-1K1 \<one>\<^sub>M"
       sorry
    have "lenFINSEQ-1K4 (<*FINSEQ-1K11 p1,p2 *>) =XBOOLE-0R4 \<two>\<^sub>M"
      using finseq_1_th_44 sorry
    then have A2: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K11 p1,p2 *>)"
      using finseq_3_th_25 sorry
    have "(<*FINSEQ-1K11 p1,p2 *>).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 p1"
      using finseq_1_th_44 sorry
    thus "p1 ..FINSEQ-4K4 (<*FINSEQ-1K11 p1,p2 *>) =XBOOLE-0R4 \<one>\<^sub>M"
      using A2 A1 finseq_6_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_20:
" for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds p1 <>HIDDENR2 p2 implies p2 ..FINSEQ-4K4 (<*FINSEQ-1K11 p1,p2 *>) =XBOOLE-0R4 \<two>\<^sub>M"
proof-
  have " for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds p1 <>HIDDENR2 p2 implies p2 ..FINSEQ-4K4 (<*FINSEQ-1K11 p1,p2 *>) =XBOOLE-0R4 \<two>\<^sub>M"
  proof(rule ballI,rule ballI,rule impI)
    fix p1 assume [ty]: "p1 be setHIDDENM2"
    fix p2 assume [ty]: "p2 be setHIDDENM2"
    have A1: "(<*FINSEQ-1K11 p1,p2 *>).FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 p2"
      using finseq_1_th_44 sorry
    have A2: "(<*FINSEQ-1K11 p1,p2 *>).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 p1"
      using finseq_1_th_44 sorry
    assume A3: "p1 <>HIDDENR2 p2"
    have A4: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i implies (i <XXREAL-0R3 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M implies (<*FINSEQ-1K11 p1,p2 *>).FUNCT-1K1 i <>HIDDENR2 (<*FINSEQ-1K11 p1,p2 *>).FUNCT-1K1 \<two>\<^sub>M)"
    proof(rule ballI,rule impI,rule impI)
      fix i assume [ty]: "i be NatNAT-1M1"
      assume A5: "\<one>\<^sub>M <=XXREAL-0R1 i"
      assume "i <XXREAL-0R3 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
      then have "i <=XXREAL-0R1 \<one>\<^sub>M"
        using nat_1_th_13 sorry
      thus "(<*FINSEQ-1K11 p1,p2 *>).FUNCT-1K1 i <>HIDDENR2 (<*FINSEQ-1K11 p1,p2 *>).FUNCT-1K1 \<two>\<^sub>M"
        using A3 A1 A2 A5 xxreal_0_th_1 sorry
    qed "sorry"
    have "\<two>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 (<*FINSEQ-1K11 p1,p2 *>)"
      using finseq_1_th_44 sorry
    then have "\<two>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K11 p1,p2 *>)"
      using finseq_3_th_25 sorry
    thus "p2 ..FINSEQ-4K4 (<*FINSEQ-1K11 p1,p2 *>) =XBOOLE-0R4 \<two>\<^sub>M"
      using A1 A4 finseq_6_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_21:
" for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for p3 be setHIDDENM2 holds p1 ..FINSEQ-4K4 (<*FINSEQ-1K12 p1,p2,p3 *>) =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for p3 be setHIDDENM2 holds p1 ..FINSEQ-4K4 (<*FINSEQ-1K12 p1,p2,p3 *>) =XBOOLE-0R4 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI)
    fix p1 assume [ty]: "p1 be setHIDDENM2"
    fix p2 assume [ty]: "p2 be setHIDDENM2"
    fix p3 assume [ty]: "p3 be setHIDDENM2"
    have A1: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 \<one>\<^sub>M implies (<*FINSEQ-1K12 p1,p2,p3 *>).FUNCT-1K1 i <>HIDDENR2 (<*FINSEQ-1K12 p1,p2,p3 *>).FUNCT-1K1 \<one>\<^sub>M"
       sorry
    have "lenFINSEQ-1K4 (<*FINSEQ-1K12 p1,p2,p3 *>) =XBOOLE-0R4 \<three>\<^sub>M"
      using finseq_1_th_45 sorry
    then have A2: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K12 p1,p2,p3 *>)"
      using finseq_3_th_25 sorry
    have "(<*FINSEQ-1K12 p1,p2,p3 *>).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 p1"
      using finseq_1_th_45 sorry
    thus "p1 ..FINSEQ-4K4 (<*FINSEQ-1K12 p1,p2,p3 *>) =XBOOLE-0R4 \<one>\<^sub>M"
      using A2 A1 finseq_6_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_22:
" for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for p3 be setHIDDENM2 holds p1 <>HIDDENR2 p2 implies p2 ..FINSEQ-4K4 (<*FINSEQ-1K12 p1,p2,p3 *>) =XBOOLE-0R4 \<two>\<^sub>M"
proof-
  have " for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for p3 be setHIDDENM2 holds p1 <>HIDDENR2 p2 implies p2 ..FINSEQ-4K4 (<*FINSEQ-1K12 p1,p2,p3 *>) =XBOOLE-0R4 \<two>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix p1 assume [ty]: "p1 be setHIDDENM2"
    fix p2 assume [ty]: "p2 be setHIDDENM2"
    fix p3 assume [ty]: "p3 be setHIDDENM2"
    have A1: "(<*FINSEQ-1K12 p1,p2,p3 *>).FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 p2"
      using finseq_1_th_45 sorry
    have A2: "(<*FINSEQ-1K12 p1,p2,p3 *>).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 p1"
      using finseq_1_th_45 sorry
    assume A3: "p1 <>HIDDENR2 p2"
    have A4: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i implies (i <XXREAL-0R3 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M implies (<*FINSEQ-1K12 p1,p2,p3 *>).FUNCT-1K1 i <>HIDDENR2 (<*FINSEQ-1K12 p1,p2,p3 *>).FUNCT-1K1 \<two>\<^sub>M)"
    proof(rule ballI,rule impI,rule impI)
      fix i assume [ty]: "i be NatNAT-1M1"
      assume A5: "\<one>\<^sub>M <=XXREAL-0R1 i"
      assume "i <XXREAL-0R3 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
      then have "i <=XXREAL-0R1 \<one>\<^sub>M"
        using nat_1_th_13 sorry
      thus "(<*FINSEQ-1K12 p1,p2,p3 *>).FUNCT-1K1 i <>HIDDENR2 (<*FINSEQ-1K12 p1,p2,p3 *>).FUNCT-1K1 \<two>\<^sub>M"
        using A3 A1 A2 A5 xxreal_0_th_1 sorry
    qed "sorry"
    have "lenFINSEQ-1K4 (<*FINSEQ-1K12 p1,p2,p3 *>) =XBOOLE-0R4 \<three>\<^sub>M"
      using finseq_1_th_45 sorry
    then have "\<two>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K12 p1,p2,p3 *>)"
      using finseq_3_th_25 sorry
    thus "p2 ..FINSEQ-4K4 (<*FINSEQ-1K12 p1,p2,p3 *>) =XBOOLE-0R4 \<two>\<^sub>M"
      using A1 A4 finseq_6_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_23:
" for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for p3 be setHIDDENM2 holds p1 <>HIDDENR2 p3 & p2 <>HIDDENR2 p3 implies p3 ..FINSEQ-4K4 (<*FINSEQ-1K12 p1,p2,p3 *>) =XBOOLE-0R4 \<three>\<^sub>M"
proof-
  have " for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for p3 be setHIDDENM2 holds p1 <>HIDDENR2 p3 & p2 <>HIDDENR2 p3 implies p3 ..FINSEQ-4K4 (<*FINSEQ-1K12 p1,p2,p3 *>) =XBOOLE-0R4 \<three>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p1 assume [ty]: "p1 be setHIDDENM2"
    fix p2 assume [ty]: "p2 be setHIDDENM2"
    fix p3 assume [ty]: "p3 be setHIDDENM2"
    assume A1: "p1 <>HIDDENR2 p3"
      and A2: "p2 <>HIDDENR2 p3"
    have A3: "(<*FINSEQ-1K12 p1,p2,p3 *>).FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 p3"
      using finseq_1_th_45 sorry
    have A4: "(<*FINSEQ-1K12 p1,p2,p3 *>).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 p1"
      using finseq_1_th_45 sorry
    have A5: "(<*FINSEQ-1K12 p1,p2,p3 *>).FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 p2"
      using finseq_1_th_45 sorry
    have A6: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i implies (i <XXREAL-0R3 \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M implies (<*FINSEQ-1K12 p1,p2,p3 *>).FUNCT-1K1 i <>HIDDENR2 (<*FINSEQ-1K12 p1,p2,p3 *>).FUNCT-1K1 \<three>\<^sub>M)"
    proof(rule ballI,rule impI,rule impI)
      fix i assume [ty]: "i be NatNAT-1M1"
      assume "\<one>\<^sub>M <=XXREAL-0R1 i"
      then have A7: "i <>HIDDENR2 0NUMBERSK6"
         sorry
      assume "i <XXREAL-0R3 \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
      then have "i <=XXREAL-0R1 \<two>\<^sub>M"
        using nat_1_th_13 sorry
      then have " ex VarFor1 be setHIDDENM2 st (0NUMBERSK6 <=XXREAL-0R1 VarFor1 & VarFor1 <=XXREAL-0R1 \<two>\<^sub>M) & i =XBOOLE-0R4 VarFor1"
         sorry
      thus "(<*FINSEQ-1K12 p1,p2,p3 *>).FUNCT-1K1 i <>HIDDENR2 (<*FINSEQ-1K12 p1,p2,p3 *>).FUNCT-1K1 \<three>\<^sub>M"
        using A1 A2 A3 A5 A4 A7 sorry
    qed "sorry"
    have "\<three>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 (<*FINSEQ-1K12 p1,p2,p3 *>)"
      using finseq_1_th_45 sorry
    then have "\<three>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K12 p1,p2,p3 *>)"
      using finseq_3_th_25 sorry
    thus "p3 ..FINSEQ-4K4 (<*FINSEQ-1K12 p1,p2,p3 *>) =XBOOLE-0R4 \<three>\<^sub>M"
      using A3 A6 finseq_6_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_24:
" for p be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M1 holds RevFINSEQ-5K3 ((<*FINSEQ-1K10 p*>)^FINSEQ-1K8 f) =FINSEQ-1R1 RevFINSEQ-5K3 f ^FINSEQ-1K8 (<*FINSEQ-1K10 p*>)"
proof-
  have " for p be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M1 holds RevFINSEQ-5K3 ((<*FINSEQ-1K10 p*>)^FINSEQ-1K8 f) =HIDDENR1 RevFINSEQ-5K3 f ^FINSEQ-1K8 (<*FINSEQ-1K10 p*>)"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
    have "RevFINSEQ-5K3 ((<*FINSEQ-1K10 p*>)^FINSEQ-1K8 f) =HIDDENR1 RevFINSEQ-5K3 f ^FINSEQ-1K8 RevFINSEQ-5K3 (<*FINSEQ-1K10 p*>)"
      using finseq_5_th_64 sorry
    also have "... = RevFINSEQ-5K3 f ^FINSEQ-1K8 (<*FINSEQ-1K10 p*>)"
      using finseq_5_th_60 sorry
    finally show "RevFINSEQ-5K3 ((<*FINSEQ-1K10 p*>)^FINSEQ-1K8 f) =HIDDENR1 RevFINSEQ-5K3 f ^FINSEQ-1K8 (<*FINSEQ-1K10 p*>)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_25:
" for f be FinSequenceFINSEQ-1M1 holds RevFINSEQ-5K3 (RevFINSEQ-5K3 f) =FINSEQ-1R1 f"
   sorry

mtheorem finseq_6_th_26:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x <>HIDDENR2 y implies <*FINSEQ-1K11 x,y *> -|FINSEQ-4K5 y =FINSEQ-1R1 <*FINSEQ-1K10 x*>"
proof-
  have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x <>HIDDENR2 y implies <*FINSEQ-1K11 x,y *> -|FINSEQ-4K5 y =HIDDENR1 <*FINSEQ-1K10 x*>"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    assume "x <>HIDDENR2 y"
    then have "y ..FINSEQ-4K4 (<*FINSEQ-1K11 x,y *>) =XBOOLE-0R4 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
      using finseq_6_th_20 sorry
    then have A1: "\<one>\<^sub>M =XBOOLE-0R4 y ..FINSEQ-4K4 (<*FINSEQ-1K11 x,y *>) -XCMPLX-0K6 \<one>\<^sub>M"
       sorry
    have "rngFUNCT-1K2 (<*FINSEQ-1K11 x,y *>) =XBOOLE-0R4 {TARSKIK2 x,y }"
      using finseq_6_lm_1 sorry
    then have "y inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K11 x,y *>)"
      using tarski_def_2 sorry
    then have "<*FINSEQ-1K11 x,y *> -|FINSEQ-4K5 y =HIDDENR1 (<*FINSEQ-1K11 x,y *>) |RELAT-1K8 SegFINSEQ-1K2 \<one>\<^sub>M"
      using A1 finseq_4_th_33 sorry
    also have "... = <*FINSEQ-1K10 x*>"
      using finseq_6_th_3 sorry
    finally show "<*FINSEQ-1K11 x,y *> -|FINSEQ-4K5 y =HIDDENR1 <*FINSEQ-1K10 x*>"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_27:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds x <>HIDDENR2 y implies <*FINSEQ-1K12 x,y,z *> -|FINSEQ-4K5 y =FINSEQ-1R1 <*FINSEQ-1K10 x*>"
proof-
  have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds x <>HIDDENR2 y implies <*FINSEQ-1K12 x,y,z *> -|FINSEQ-4K5 y =HIDDENR1 <*FINSEQ-1K10 x*>"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    fix z assume [ty]: "z be setHIDDENM2"
    assume "x <>HIDDENR2 y"
    then have "y ..FINSEQ-4K4 (<*FINSEQ-1K12 x,y,z *>) =XBOOLE-0R4 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
      using finseq_6_th_22 sorry
    then have A1: "\<one>\<^sub>M =XBOOLE-0R4 y ..FINSEQ-4K4 (<*FINSEQ-1K12 x,y,z *>) -XCMPLX-0K6 \<one>\<^sub>M"
       sorry
    have "rngFUNCT-1K2 (<*FINSEQ-1K12 x,y,z *>) =XBOOLE-0R4 {ENUMSET1K1 x,y,z }"
      using finseq_6_lm_2 sorry
    then have "y inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K12 x,y,z *>)"
      using enumset1_def_1 sorry
    then have "<*FINSEQ-1K12 x,y,z *> -|FINSEQ-4K5 y =HIDDENR1 (<*FINSEQ-1K12 x,y,z *>) |RELAT-1K8 SegFINSEQ-1K2 \<one>\<^sub>M"
      using A1 finseq_4_th_33 sorry
    also have "... = <*FINSEQ-1K10 x*>"
      using finseq_6_th_4 sorry
    finally show "<*FINSEQ-1K12 x,y,z *> -|FINSEQ-4K5 y =HIDDENR1 <*FINSEQ-1K10 x*>"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_28:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds x <>HIDDENR2 z & y <>HIDDENR2 z implies <*FINSEQ-1K12 x,y,z *> -|FINSEQ-4K5 z =FINSEQ-1R1 <*FINSEQ-1K11 x,y *>"
proof-
  have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds x <>HIDDENR2 z & y <>HIDDENR2 z implies <*FINSEQ-1K12 x,y,z *> -|FINSEQ-4K5 z =HIDDENR1 <*FINSEQ-1K11 x,y *>"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    fix z assume [ty]: "z be setHIDDENM2"
    assume A1: "x <>HIDDENR2 z"
      and A2: "y <>HIDDENR2 z"
    have "rngFUNCT-1K2 (<*FINSEQ-1K12 x,y,z *>) =XBOOLE-0R4 {ENUMSET1K1 x,y,z }"
      using finseq_6_lm_2 sorry
    then have A3: "z inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K12 x,y,z *>)"
      using enumset1_def_1 sorry
    have "z ..FINSEQ-4K4 (<*FINSEQ-1K12 x,y,z *>) =XBOOLE-0R4 \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
      using A1 A2 finseq_6_th_23 sorry
    then have "\<two>\<^sub>M =XBOOLE-0R4 z ..FINSEQ-4K4 (<*FINSEQ-1K12 x,y,z *>) -XCMPLX-0K6 \<one>\<^sub>M"
       sorry
    then have "<*FINSEQ-1K12 x,y,z *> -|FINSEQ-4K5 z =HIDDENR1 (<*FINSEQ-1K12 x,y,z *>) |RELAT-1K8 SegFINSEQ-1K2 \<two>\<^sub>M"
      using A3 finseq_4_th_33 sorry
    also have "... = <*FINSEQ-1K11 x,y *>"
      using finseq_6_th_5 sorry
    finally show "<*FINSEQ-1K12 x,y,z *> -|FINSEQ-4K5 z =HIDDENR1 <*FINSEQ-1K11 x,y *>"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_29:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds <*FINSEQ-1K11 x,y *>  |--FINSEQ-4K6 x =FINSEQ-1R1 <*FINSEQ-1K10 y*>"
proof-
  have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds <*FINSEQ-1K11 x,y *>  |--FINSEQ-4K6 x =FINSEQ-1R1 <*FINSEQ-1K10 y*>"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    have A1: "x ..FINSEQ-4K4 (<*FINSEQ-1K11 x,y *>) =XBOOLE-0R4 \<one>\<^sub>M"
      using finseq_6_th_19 sorry
    then have "lenFINSEQ-1K4 (<*FINSEQ-1K10 y*>) +NAT-1K1 x ..FINSEQ-4K4 (<*FINSEQ-1K11 x,y *>) =HIDDENR1 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
      using finseq_1_th_40 sorry
    also have "... = lenFINSEQ-1K4 (<*FINSEQ-1K11 x,y *>)"
      using finseq_1_th_44 sorry
    finally have "lenFINSEQ-1K4 (<*FINSEQ-1K10 y*>) +NAT-1K1 x ..FINSEQ-4K4 (<*FINSEQ-1K11 x,y *>) =HIDDENR1 lenFINSEQ-1K4 (<*FINSEQ-1K11 x,y *>)"
       sorry
    then have A2: "lenFINSEQ-1K4 (<*FINSEQ-1K10 y*>) =XBOOLE-0R4 lenFINSEQ-1K4 (<*FINSEQ-1K11 x,y *>) -XCMPLX-0K6 x ..FINSEQ-4K4 (<*FINSEQ-1K11 x,y *>)"
       sorry
    have A3: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 y*>) implies (<*FINSEQ-1K10 y*>).FUNCT-1K1 k =HIDDENR1 (<*FINSEQ-1K11 x,y *>).FUNCT-1K1 (k +NAT-1K1 x ..FINSEQ-4K4 (<*FINSEQ-1K11 x,y *>))"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume "k inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 y*>)"
      then have "k inTARSKIR2 SegFINSEQ-1K2 \<one>\<^sub>M"
        using finseq_1_th_38 sorry
      then have A4: "k =XBOOLE-0R4 \<one>\<^sub>M"
        using finseq_1_th_2 tarski_def_1 sorry
      then have "(<*FINSEQ-1K10 y*>).FUNCT-1K1 k =HIDDENR1 y"
        using finseq_1_th_40 sorry
      also have "... = (<*FINSEQ-1K11 x,y *>).FUNCT-1K1 (k +NAT-1K1 x ..FINSEQ-4K4 (<*FINSEQ-1K11 x,y *>))"
        using A1 A4 finseq_1_th_44 sorry
      finally show "(<*FINSEQ-1K10 y*>).FUNCT-1K1 k =HIDDENR1 (<*FINSEQ-1K11 x,y *>).FUNCT-1K1 (k +NAT-1K1 x ..FINSEQ-4K4 (<*FINSEQ-1K11 x,y *>))"
         sorry
    qed "sorry"
    have "x inTARSKIR2 {TARSKIK2 x,y }"
      using tarski_def_2 sorry
    then have "x inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K11 x,y *>)"
      using finseq_6_lm_1 sorry
    thus "<*FINSEQ-1K11 x,y *>  |--FINSEQ-4K6 x =FINSEQ-1R1 <*FINSEQ-1K10 y*>"
      using A2 A3 finseq_4_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_30:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds x <>HIDDENR2 y implies <*FINSEQ-1K12 x,y,z *>  |--FINSEQ-4K6 y =FINSEQ-1R1 <*FINSEQ-1K10 z*>"
proof-
  have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds x <>HIDDENR2 y implies <*FINSEQ-1K12 x,y,z *>  |--FINSEQ-4K6 y =FINSEQ-1R1 <*FINSEQ-1K10 z*>"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    fix z assume [ty]: "z be setHIDDENM2"
    assume "x <>HIDDENR2 y"
    then have A1: "y ..FINSEQ-4K4 (<*FINSEQ-1K12 x,y,z *>) =XBOOLE-0R4 \<two>\<^sub>M"
      using finseq_6_th_22 sorry
    then have "lenFINSEQ-1K4 (<*FINSEQ-1K10 z*>) +NAT-1K1 y ..FINSEQ-4K4 (<*FINSEQ-1K12 x,y,z *>) =HIDDENR1 \<one>\<^sub>M +NAT-1K1 \<two>\<^sub>M"
      using finseq_1_th_40 sorry
    also have "... = lenFINSEQ-1K4 (<*FINSEQ-1K12 x,y,z *>)"
      using finseq_1_th_45 sorry
    finally have "lenFINSEQ-1K4 (<*FINSEQ-1K10 z*>) +NAT-1K1 y ..FINSEQ-4K4 (<*FINSEQ-1K12 x,y,z *>) =HIDDENR1 lenFINSEQ-1K4 (<*FINSEQ-1K12 x,y,z *>)"
       sorry
    then have A2: "lenFINSEQ-1K4 (<*FINSEQ-1K10 z*>) =XBOOLE-0R4 lenFINSEQ-1K4 (<*FINSEQ-1K12 x,y,z *>) -XCMPLX-0K6 y ..FINSEQ-4K4 (<*FINSEQ-1K12 x,y,z *>)"
       sorry
    have A3: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 z*>) implies (<*FINSEQ-1K10 z*>).FUNCT-1K1 k =HIDDENR1 (<*FINSEQ-1K12 x,y,z *>).FUNCT-1K1 (k +NAT-1K1 y ..FINSEQ-4K4 (<*FINSEQ-1K12 x,y,z *>))"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume "k inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 z*>)"
      then have "k inTARSKIR2 SegFINSEQ-1K2 \<one>\<^sub>M"
        using finseq_1_th_38 sorry
      then have A4: "k =XBOOLE-0R4 \<one>\<^sub>M"
        using finseq_1_th_2 tarski_def_1 sorry
      then have "(<*FINSEQ-1K10 z*>).FUNCT-1K1 k =HIDDENR1 z"
        using finseq_1_th_40 sorry
      also have "... = (<*FINSEQ-1K12 x,y,z *>).FUNCT-1K1 (k +NAT-1K1 y ..FINSEQ-4K4 (<*FINSEQ-1K12 x,y,z *>))"
        using A1 A4 finseq_1_th_45 sorry
      finally show "(<*FINSEQ-1K10 z*>).FUNCT-1K1 k =HIDDENR1 (<*FINSEQ-1K12 x,y,z *>).FUNCT-1K1 (k +NAT-1K1 y ..FINSEQ-4K4 (<*FINSEQ-1K12 x,y,z *>))"
         sorry
    qed "sorry"
    have "y inTARSKIR2 {ENUMSET1K1 x,y,z }"
      using enumset1_def_1 sorry
    then have "y inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K12 x,y,z *>)"
      using finseq_6_lm_2 sorry
    thus "<*FINSEQ-1K12 x,y,z *>  |--FINSEQ-4K6 y =FINSEQ-1R1 <*FINSEQ-1K10 z*>"
      using A2 A3 finseq_4_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_31:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds <*FINSEQ-1K12 x,y,z *>  |--FINSEQ-4K6 x =FINSEQ-1R1 <*FINSEQ-1K11 y,z *>"
proof-
  have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds <*FINSEQ-1K12 x,y,z *>  |--FINSEQ-4K6 x =FINSEQ-1R1 <*FINSEQ-1K11 y,z *>"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    fix z assume [ty]: "z be setHIDDENM2"
    have A1: "x ..FINSEQ-4K4 (<*FINSEQ-1K12 x,y,z *>) =XBOOLE-0R4 \<one>\<^sub>M"
      using finseq_6_th_21 sorry
    then have "lenFINSEQ-1K4 (<*FINSEQ-1K11 y,z *>) +NAT-1K1 x ..FINSEQ-4K4 (<*FINSEQ-1K12 x,y,z *>) =HIDDENR1 \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
      using finseq_1_th_44 sorry
    also have "... = lenFINSEQ-1K4 (<*FINSEQ-1K12 x,y,z *>)"
      using finseq_1_th_45 sorry
    finally have "lenFINSEQ-1K4 (<*FINSEQ-1K11 y,z *>) +NAT-1K1 x ..FINSEQ-4K4 (<*FINSEQ-1K12 x,y,z *>) =HIDDENR1 lenFINSEQ-1K4 (<*FINSEQ-1K12 x,y,z *>)"
       sorry
    then have A2: "lenFINSEQ-1K4 (<*FINSEQ-1K11 y,z *>) =XBOOLE-0R4 lenFINSEQ-1K4 (<*FINSEQ-1K12 x,y,z *>) -XCMPLX-0K6 x ..FINSEQ-4K4 (<*FINSEQ-1K12 x,y,z *>)"
       sorry
    have A3: "lenFINSEQ-1K4 (<*FINSEQ-1K11 y,z *>) =XBOOLE-0R4 \<two>\<^sub>M"
      using finseq_1_th_44 sorry
    have A4: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K11 y,z *>) implies (<*FINSEQ-1K11 y,z *>).FUNCT-1K1 k =HIDDENR1 (<*FINSEQ-1K12 x,y,z *>).FUNCT-1K1 (k +NAT-1K1 x ..FINSEQ-4K4 (<*FINSEQ-1K12 x,y,z *>))"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume "k inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K11 y,z *>)"
      then have A5: "k inTARSKIR2 SegFINSEQ-1K2 \<two>\<^sub>M"
        using A3 finseq_1_def_3 sorry
      show "(<*FINSEQ-1K11 y,z *>).FUNCT-1K1 k =HIDDENR1 (<*FINSEQ-1K12 x,y,z *>).FUNCT-1K1 (k +NAT-1K1 x ..FINSEQ-4K4 (<*FINSEQ-1K12 x,y,z *>))"
      proof-
        have cases: "k =XBOOLE-0R4 \<one>\<^sub>M or k =XBOOLE-0R4 \<two>\<^sub>M"
          using A5 finseq_1_th_2 tarski_def_2 sorry
        have case1: "k =XBOOLE-0R4 \<one>\<^sub>M implies (<*FINSEQ-1K11 y,z *>).FUNCT-1K1 k =HIDDENR1 (<*FINSEQ-1K12 x,y,z *>).FUNCT-1K1 (k +NAT-1K1 x ..FINSEQ-4K4 (<*FINSEQ-1K12 x,y,z *>))"
        proof(rule impI)
          assume A6: "k =XBOOLE-0R4 \<one>\<^sub>M"
          then have "(<*FINSEQ-1K11 y,z *>).FUNCT-1K1 k =HIDDENR1 y"
            using finseq_1_th_44 sorry
          also have "... = (<*FINSEQ-1K12 x,y,z *>).FUNCT-1K1 (k +NAT-1K1 x ..FINSEQ-4K4 (<*FINSEQ-1K12 x,y,z *>))"
            using A1 A6 finseq_1_th_45 sorry
          finally show "(<*FINSEQ-1K11 y,z *>).FUNCT-1K1 k =HIDDENR1 (<*FINSEQ-1K12 x,y,z *>).FUNCT-1K1 (k +NAT-1K1 x ..FINSEQ-4K4 (<*FINSEQ-1K12 x,y,z *>))"
             sorry
        qed
        have case2: "k =XBOOLE-0R4 \<two>\<^sub>M implies (<*FINSEQ-1K11 y,z *>).FUNCT-1K1 k =HIDDENR1 (<*FINSEQ-1K12 x,y,z *>).FUNCT-1K1 (k +NAT-1K1 x ..FINSEQ-4K4 (<*FINSEQ-1K12 x,y,z *>))"
        proof(rule impI)
          assume A7: "k =XBOOLE-0R4 \<two>\<^sub>M"
          then have "(<*FINSEQ-1K11 y,z *>).FUNCT-1K1 k =HIDDENR1 z"
            using finseq_1_th_44 sorry
          also have "... = (<*FINSEQ-1K12 x,y,z *>).FUNCT-1K1 (k +NAT-1K1 x ..FINSEQ-4K4 (<*FINSEQ-1K12 x,y,z *>))"
            using A1 A7 finseq_1_th_45 sorry
          finally show "(<*FINSEQ-1K11 y,z *>).FUNCT-1K1 k =HIDDENR1 (<*FINSEQ-1K12 x,y,z *>).FUNCT-1K1 (k +NAT-1K1 x ..FINSEQ-4K4 (<*FINSEQ-1K12 x,y,z *>))"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    have "x inTARSKIR2 {ENUMSET1K1 x,y,z }"
      using enumset1_def_1 sorry
    then have "x inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K12 x,y,z *>)"
      using finseq_6_lm_2 sorry
    thus "<*FINSEQ-1K12 x,y,z *>  |--FINSEQ-4K6 x =FINSEQ-1R1 <*FINSEQ-1K11 y,z *>"
      using A2 A4 finseq_4_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_32:
" for z be setHIDDENM2 holds <*FINSEQ-1K10 z*>  |--FINSEQ-4K6 z =FINSEQ-1R1 {}XBOOLE-0K1 & <*FINSEQ-1K10 z*> -|FINSEQ-4K5 z =FINSEQ-1R1 {}XBOOLE-0K1"
proof-
  have " for z be setHIDDENM2 holds <*FINSEQ-1K10 z*>  |--FINSEQ-4K6 z =FINSEQ-1R1 {}XBOOLE-0K1 & <*FINSEQ-1K10 z*> -|FINSEQ-4K5 z =FINSEQ-1R1 {}XBOOLE-0K1"
  proof(rule ballI,rule conjMI)
    fix z assume [ty]: "z be setHIDDENM2"
    have "z inTARSKIR2 {TARSKIK1 z}"
      using tarski_def_1 sorry
    then have A1: "z inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K10 z*>)"
      using finseq_1_th_39 sorry
    have A2: "z ..FINSEQ-4K4 (<*FINSEQ-1K10 z*>) =XBOOLE-0R4 \<one>\<^sub>M"
      using finseq_6_th_18 sorry
    have "lenFINSEQ-1K4 (<*FINSEQ-1K10 z*>) =XBOOLE-0R4 \<one>\<^sub>M"
      using finseq_1_th_39 sorry
    thus "<*FINSEQ-1K10 z*>  |--FINSEQ-4K6 z =FINSEQ-1R1 {}XBOOLE-0K1"
      using A1 A2 finseq_4_th_49 sorry
    show "<*FINSEQ-1K10 z*> -|FINSEQ-4K5 z =FINSEQ-1R1 {}XBOOLE-0K1"
      using A1 A2 finseq_4_th_40 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_33:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x <>HIDDENR2 y implies <*FINSEQ-1K11 x,y *>  |--FINSEQ-4K6 y =FINSEQ-1R1 {}XBOOLE-0K1"
proof-
  have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x <>HIDDENR2 y implies <*FINSEQ-1K11 x,y *>  |--FINSEQ-4K6 y =FINSEQ-1R1 {}XBOOLE-0K1"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    have "y inTARSKIR2 {TARSKIK2 x,y }"
      using tarski_def_2 sorry
    then have A1: "y inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K11 x,y *>)"
      using finseq_6_lm_1 sorry
    assume "x <>HIDDENR2 y"
    then have A2: "y ..FINSEQ-4K4 (<*FINSEQ-1K11 x,y *>) =XBOOLE-0R4 \<two>\<^sub>M"
      using finseq_6_th_20 sorry
    have "lenFINSEQ-1K4 (<*FINSEQ-1K11 x,y *>) =XBOOLE-0R4 \<two>\<^sub>M"
      using finseq_1_th_44 sorry
    thus "<*FINSEQ-1K11 x,y *>  |--FINSEQ-4K6 y =FINSEQ-1R1 {}XBOOLE-0K1"
      using A1 A2 finseq_4_th_49 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_34:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds x <>HIDDENR2 z & y <>HIDDENR2 z implies <*FINSEQ-1K12 x,y,z *>  |--FINSEQ-4K6 z =FINSEQ-1R1 {}XBOOLE-0K1"
proof-
  have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds x <>HIDDENR2 z & y <>HIDDENR2 z implies <*FINSEQ-1K12 x,y,z *>  |--FINSEQ-4K6 z =FINSEQ-1R1 {}XBOOLE-0K1"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    fix z assume [ty]: "z be setHIDDENM2"
    assume A1: "x <>HIDDENR2 z"
      and A2: "y <>HIDDENR2 z"
    have A3: "lenFINSEQ-1K4 (<*FINSEQ-1K12 x,y,z *>) =XBOOLE-0R4 \<three>\<^sub>M"
      using finseq_1_th_45 sorry
    have "z inTARSKIR2 {ENUMSET1K1 x,y,z }"
      using enumset1_def_1 sorry
    then have A4: "z inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K12 x,y,z *>)"
      using finseq_6_lm_2 sorry
    have "z ..FINSEQ-4K4 (<*FINSEQ-1K12 x,y,z *>) =XBOOLE-0R4 \<three>\<^sub>M"
      using A1 A2 finseq_6_th_23 sorry
    thus "<*FINSEQ-1K12 x,y,z *>  |--FINSEQ-4K6 z =FINSEQ-1R1 {}XBOOLE-0K1"
      using A4 A3 finseq_4_th_49 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_35:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M1 holds x inTARSKIR2 rngFUNCT-1K2 f & y inTARSKIR2 rngFUNCT-1K2 (f -|FINSEQ-4K5 x) implies (f -|FINSEQ-4K5 x)-|FINSEQ-4K5 y =FINSEQ-1R1 f -|FINSEQ-4K5 y"
proof-
  have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M1 holds x inTARSKIR2 rngFUNCT-1K2 f & y inTARSKIR2 rngFUNCT-1K2 (f -|FINSEQ-4K5 x) implies f -|FINSEQ-4K5 y =HIDDENR1 (f -|FINSEQ-4K5 x)-|FINSEQ-4K5 y"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
    assume A1: "x inTARSKIR2 rngFUNCT-1K2 f"
      and A2: "y inTARSKIR2 rngFUNCT-1K2 (f -|FINSEQ-4K5 x)"
    have "f -|FINSEQ-4K5 y =HIDDENR1 ((f -|FINSEQ-4K5 x)^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))^FINSEQ-1K8 (f  |--FINSEQ-4K6 x) -|FINSEQ-4K5 y"
      using A1 finseq_4_th_51 sorry
    also have "... = (f -|FINSEQ-4K5 x)^FINSEQ-1K8 ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 (f  |--FINSEQ-4K6 x)) -|FINSEQ-4K5 y"
      using finseq_1_th_32 sorry
    also have "... = (f -|FINSEQ-4K5 x)-|FINSEQ-4K5 y"
      using A2 finseq_6_th_12 sorry
    finally show "f -|FINSEQ-4K5 y =HIDDENR1 (f -|FINSEQ-4K5 x)-|FINSEQ-4K5 y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_36:
" for x be setHIDDENM2 holds  for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  not x inTARSKIR2 rngFUNCT-1K2 f1 implies x ..FINSEQ-4K4 ((f1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))^FINSEQ-1K8 f2) =XBOOLE-0R4 lenFINSEQ-1K4 f1 +NAT-1K1 \<one>\<^sub>M"
proof-
  have " for x be setHIDDENM2 holds  for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  not x inTARSKIR2 rngFUNCT-1K2 f1 implies x ..FINSEQ-4K4 ((f1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))^FINSEQ-1K8 f2) =HIDDENR1 lenFINSEQ-1K4 f1 +NAT-1K1 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix f1 assume [ty]: "f1 be FinSequenceFINSEQ-1M1"
    fix f2 assume [ty]: "f2 be FinSequenceFINSEQ-1M1"
    have "x inTARSKIR2 {TARSKIK1 x}"
      using tarski_def_1 sorry
    then have A1: "x inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K10 x*>)"
      using finseq_1_th_38 sorry
    assume " not x inTARSKIR2 rngFUNCT-1K2 f1"
    then have "x inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K10 x*>) \\SUBSET-1K6 rngFUNCT-1K2 f1"
      using A1 xboole_0_def_5 sorry
    then have A2: "f1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)  |--FINSEQ-4K6 x =HIDDENR1 <*FINSEQ-1K10 x*>  |--FINSEQ-4K6 x"
      using finseq_6_th_9 sorry
    also have "... = {}XBOOLE-0K1"
      using finseq_6_th_32 sorry
    finally have "f1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)  |--FINSEQ-4K6 x =HIDDENR1 {}XBOOLE-0K1"
       sorry
    have "rngFUNCT-1K2 (f1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) =XBOOLE-0R4 rngFUNCT-1K2 f1 \\/XBOOLE-0K2 rngFUNCT-1K2 (<*FINSEQ-1K10 x*>)"
      using finseq_1_th_31 sorry
    then have A3: "x inTARSKIR2 rngFUNCT-1K2 (f1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
      using A1 xboole_0_def_3 sorry
    then have "lenFINSEQ-1K4 (f1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) -XCMPLX-0K6 x ..FINSEQ-4K4 (f1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) =HIDDENR1 lenFINSEQ-1K4 (f1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)  |--FINSEQ-4K6 x)"
      using finseq_4_def_6 sorry
    also have "... = 0NUMBERSK6"
      using A2 sorry
    finally have "lenFINSEQ-1K4 (f1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) -XCMPLX-0K6 x ..FINSEQ-4K4 (f1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) =HIDDENR1 0NUMBERSK6"
       sorry
    then have "x ..FINSEQ-4K4 ((f1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))^FINSEQ-1K8 f2) =HIDDENR1 lenFINSEQ-1K4 (f1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
      using A3 finseq_6_th_6 sorry
    also have "... = lenFINSEQ-1K4 f1 +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>)"
      using finseq_1_th_22 sorry
    also have "... = lenFINSEQ-1K4 f1 +NAT-1K1 \<one>\<^sub>M"
      using finseq_1_th_39 sorry
    finally show "x ..FINSEQ-4K4 ((f1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))^FINSEQ-1K8 f2) =HIDDENR1 lenFINSEQ-1K4 f1 +NAT-1K1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_37:
" for x be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M1 holds f just-once-valuesFINSEQ-4R2 x implies x ..FINSEQ-4K4 f +NAT-1K1 x ..FINSEQ-4K4 RevFINSEQ-5K3 f =XBOOLE-0R4 lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M"
proof-
  have " for x be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M1 holds f just-once-valuesFINSEQ-4R2 x implies x ..FINSEQ-4K4 f +NAT-1K1 x ..FINSEQ-4K4 RevFINSEQ-5K3 f =HIDDENR1 lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
    assume A1: "f just-once-valuesFINSEQ-4R2 x"
    then have A2: "x inTARSKIR2 rngFUNCT-1K2 f"
      using finseq_4_th_5 sorry
    then have A3: "f =FINSEQ-1R1 ((f -|FINSEQ-4K5 x)^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))^FINSEQ-1K8 (f  |--FINSEQ-4K6 x)"
      using finseq_4_th_51 sorry
    then have A4: "lenFINSEQ-1K4 f =HIDDENR1 lenFINSEQ-1K4 ((f -|FINSEQ-4K5 x)^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) +NAT-1K1 lenFINSEQ-1K4 (f  |--FINSEQ-4K6 x)"
      using finseq_1_th_22 sorry
    also have "... = (lenFINSEQ-1K4 (f -|FINSEQ-4K5 x) +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>))+NAT-1K1 lenFINSEQ-1K4 (f  |--FINSEQ-4K6 x)"
      using finseq_1_th_22 sorry
    also have "... = (lenFINSEQ-1K4 (f -|FINSEQ-4K5 x) +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 lenFINSEQ-1K4 (f  |--FINSEQ-4K6 x)"
      using finseq_1_th_39 sorry
    finally have "lenFINSEQ-1K4 f =HIDDENR1 (lenFINSEQ-1K4 (f -|FINSEQ-4K5 x) +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 lenFINSEQ-1K4 (f  |--FINSEQ-4K6 x)"
       sorry
    have " not x inTARSKIR2 rngFUNCT-1K2 (f  |--FINSEQ-4K6 x)"
      using A1 finseq_4_th_45 sorry
    then have A5: " not x inTARSKIR2 rngFUNCT-1K2 (RevFINSEQ-5K3 (f  |--FINSEQ-4K6 x))"
      using finseq_5_th_57 sorry
    have "RevFINSEQ-5K3 f =HIDDENR1 RevFINSEQ-5K3 (f  |--FINSEQ-4K6 x) ^FINSEQ-1K8 RevFINSEQ-5K3 ((f -|FINSEQ-4K5 x)^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
      using A3 finseq_5_th_64 sorry
    also have "... = RevFINSEQ-5K3 (f  |--FINSEQ-4K6 x) ^FINSEQ-1K8 ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 RevFINSEQ-5K3 (f -|FINSEQ-4K5 x))"
      using finseq_5_th_63 sorry
    also have "... = (RevFINSEQ-5K3 (f  |--FINSEQ-4K6 x) ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))^FINSEQ-1K8 RevFINSEQ-5K3 (f -|FINSEQ-4K5 x)"
      using finseq_1_th_32 sorry
    finally have "RevFINSEQ-5K3 f =HIDDENR1 (RevFINSEQ-5K3 (f  |--FINSEQ-4K6 x) ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))^FINSEQ-1K8 RevFINSEQ-5K3 (f -|FINSEQ-4K5 x)"
       sorry
    then have A6: "x ..FINSEQ-4K4 RevFINSEQ-5K3 f =XBOOLE-0R4 lenFINSEQ-1K4 (RevFINSEQ-5K3 (f  |--FINSEQ-4K6 x)) +NAT-1K1 \<one>\<^sub>M"
      using A5 finseq_6_th_36 sorry
    have "lenFINSEQ-1K4 (f -|FINSEQ-4K5 x) +NAT-1K1 \<one>\<^sub>M =HIDDENR1 (x ..FINSEQ-4K4 f -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M"
      using A2 finseq_4_th_34 sorry
    also have "... = x ..FINSEQ-4K4 f"
       sorry
    finally have "lenFINSEQ-1K4 (f -|FINSEQ-4K5 x) +NAT-1K1 \<one>\<^sub>M =HIDDENR1 x ..FINSEQ-4K4 f"
       sorry
    then have "x ..FINSEQ-4K4 f +NAT-1K1 x ..FINSEQ-4K4 RevFINSEQ-5K3 f =HIDDENR1 ((lenFINSEQ-1K4 (f -|FINSEQ-4K5 x) +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 lenFINSEQ-1K4 (RevFINSEQ-5K3 (f  |--FINSEQ-4K6 x)))+NAT-1K1 \<one>\<^sub>M"
      using A6 sorry
    also have "... = lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M"
      using A4 finseq_5_def_3 sorry
    finally show "x ..FINSEQ-4K4 f +NAT-1K1 x ..FINSEQ-4K4 RevFINSEQ-5K3 f =HIDDENR1 lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_38:
" for x be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M1 holds f just-once-valuesFINSEQ-4R2 x implies RevFINSEQ-5K3 (f -|FINSEQ-4K5 x) =FINSEQ-1R1 RevFINSEQ-5K3 f  |--FINSEQ-4K6 x"
proof-
  have " for x be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M1 holds f just-once-valuesFINSEQ-4R2 x implies RevFINSEQ-5K3 (f -|FINSEQ-4K5 x) =FINSEQ-1R1 RevFINSEQ-5K3 f  |--FINSEQ-4K6 x"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
    have A1: "lenFINSEQ-1K4 (RevFINSEQ-5K3 (f -|FINSEQ-4K5 x)) =XBOOLE-0R4 lenFINSEQ-1K4 (f -|FINSEQ-4K5 x)"
      using finseq_5_def_3 sorry
    assume A2: "f just-once-valuesFINSEQ-4R2 x"
    then have A3: "x inTARSKIR2 rngFUNCT-1K2 f"
      using finseq_4_th_5 sorry
    then have A4: "x inTARSKIR2 rngFUNCT-1K2 (RevFINSEQ-5K3 f)"
      using finseq_5_th_57 sorry
    have A5: "x ..FINSEQ-4K4 f +NAT-1K1 x ..FINSEQ-4K4 RevFINSEQ-5K3 f =XBOOLE-0R4 lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M"
      using A2 finseq_6_th_37 sorry
    have A6: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 (RevFINSEQ-5K3 (f -|FINSEQ-4K5 x)) implies RevFINSEQ-5K3 (f -|FINSEQ-4K5 x) .FUNCT-1K1 k =HIDDENR1 RevFINSEQ-5K3 f .FUNCT-1K1 (k +NAT-1K1 x ..FINSEQ-4K4 RevFINSEQ-5K3 f)"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      obtain m where
        [ty]:"m be NatNAT-1M1" and 
        "m =XBOOLE-0R4 x ..FINSEQ-4K4 f -XCMPLX-0K6 \<one>\<^sub>M"and A7: "f -|FINSEQ-4K5 x =FINSEQ-1R1 f  |RELAT-1K8 SegFINSEQ-1K2 m"
        using A3 finseq_4_def_5 sorry
      assume A8: "k inTARSKIR2 domFINSEQ-1K5 (RevFINSEQ-5K3 (f -|FINSEQ-4K5 x))"
      then have A9: "\<one>\<^sub>M <=XXREAL-0R1 k"
        using finseq_3_th_25 sorry
      then have A10: "x ..FINSEQ-4K4 f -XCMPLX-0K6 k <=XXREAL-0R1 x ..FINSEQ-4K4 f -XCMPLX-0K6 \<one>\<^sub>M"
        using xreal_1_th_13 sorry
      have A11: "lenFINSEQ-1K4 (f -|FINSEQ-4K5 x) =XBOOLE-0R4 x ..FINSEQ-4K4 f -XCMPLX-0K6 \<one>\<^sub>M"
        using A3 finseq_4_th_34 sorry
      have "k inTARSKIR2 domFINSEQ-1K5 (f -|FINSEQ-4K5 x)"
        using A8 finseq_5_th_57 sorry
      then have "k <=XXREAL-0R1 x ..FINSEQ-4K4 f -XCMPLX-0K6 \<one>\<^sub>M"
        using A11 finseq_3_th_25 sorry
      then have A12: "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 x ..FINSEQ-4K4 f"
        using xreal_1_th_19 sorry
      then have "k <XXREAL-0R3 x ..FINSEQ-4K4 f"
        using nat_1_th_13 sorry
      then have "k +NAT-1K1 x ..FINSEQ-4K4 RevFINSEQ-5K3 f <XXREAL-0R3 lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M"
        using A5 xreal_1_th_6 sorry
      then have "k +NAT-1K1 x ..FINSEQ-4K4 RevFINSEQ-5K3 f <=XXREAL-0R1 lenFINSEQ-1K4 f"
        using nat_1_th_13 sorry
      then have A13: "k +NAT-1K1 x ..FINSEQ-4K4 RevFINSEQ-5K3 f <=XXREAL-0R1 lenFINSEQ-1K4 (RevFINSEQ-5K3 f)"
        using finseq_5_def_3 sorry
      have A14: "\<one>\<^sub>M <=XXREAL-0R1 x ..FINSEQ-4K4 f -XCMPLX-0K6 k"
        using A12 xreal_1_th_19 sorry
      then have "x ..FINSEQ-4K4 f -XCMPLX-0K6 k inTARSKIR2 NATNUMBERSK1"
        using int_1_th_5 xreal_1_th_49 sorry
      then have A15: "((x ..FINSEQ-4K4 f -XCMPLX-0K6 \<one>\<^sub>M)-XCMPLX-0K6 k)+XCMPLX-0K2 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (f  |RELAT-1K8 SegFINSEQ-1K2 m)"
        using A7 A11 A14 A10 finseq_3_th_25 sorry
      have "k <=XXREAL-0R1 k +NAT-1K1 x ..FINSEQ-4K4 RevFINSEQ-5K3 f"
        using nat_1_th_11 sorry
      then have "\<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 x ..FINSEQ-4K4 RevFINSEQ-5K3 f"
        using A9 xxreal_0_th_2 sorry
      then have A16: "k +NAT-1K1 x ..FINSEQ-4K4 RevFINSEQ-5K3 f inTARSKIR2 domFINSEQ-1K5 (RevFINSEQ-5K3 f)"
        using A13 finseq_3_th_25 sorry
      have "RevFINSEQ-5K3 (f -|FINSEQ-4K5 x) .FUNCT-1K1 k =HIDDENR1 (f -|FINSEQ-4K5 x).FUNCT-1K1 (((x ..FINSEQ-4K4 f -XCMPLX-0K6 \<one>\<^sub>M)-XCMPLX-0K6 k)+XCMPLX-0K2 \<one>\<^sub>M)"
        using A8 A11 finseq_5_def_3 sorry
      also have "... = f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 (k +NAT-1K1 x ..FINSEQ-4K4 RevFINSEQ-5K3 f))+XCMPLX-0K2 \<one>\<^sub>M)"
        using A5 A7 A15 funct_1_th_47 sorry
      also have "... = RevFINSEQ-5K3 f .FUNCT-1K1 (k +NAT-1K1 x ..FINSEQ-4K4 RevFINSEQ-5K3 f)"
        using A16 finseq_5_def_3 sorry
      finally show "RevFINSEQ-5K3 (f -|FINSEQ-4K5 x) .FUNCT-1K1 k =HIDDENR1 RevFINSEQ-5K3 f .FUNCT-1K1 (k +NAT-1K1 x ..FINSEQ-4K4 RevFINSEQ-5K3 f)"
         sorry
    qed "sorry"
    have "lenFINSEQ-1K4 (f -|FINSEQ-4K5 x) =HIDDENR1 x ..FINSEQ-4K4 f -XCMPLX-0K6 \<one>\<^sub>M"
      using A3 finseq_4_th_34 sorry
    also have "... = lenFINSEQ-1K4 f -XCMPLX-0K6 x ..FINSEQ-4K4 RevFINSEQ-5K3 f"
      using A5 sorry
    also have "... = lenFINSEQ-1K4 (RevFINSEQ-5K3 f) -XCMPLX-0K6 x ..FINSEQ-4K4 RevFINSEQ-5K3 f"
      using finseq_5_def_3 sorry
    finally have "lenFINSEQ-1K4 (f -|FINSEQ-4K5 x) =HIDDENR1 lenFINSEQ-1K4 (RevFINSEQ-5K3 f) -XCMPLX-0K6 x ..FINSEQ-4K4 RevFINSEQ-5K3 f"
       sorry
    thus "RevFINSEQ-5K3 (f -|FINSEQ-4K5 x) =FINSEQ-1R1 RevFINSEQ-5K3 f  |--FINSEQ-4K6 x"
      using A4 A1 A6 finseq_4_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_39:
" for x be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M1 holds f just-once-valuesFINSEQ-4R2 x implies RevFINSEQ-5K3 f just-once-valuesFINSEQ-4R2 x"
proof-
  have " for x be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M1 holds f just-once-valuesFINSEQ-4R2 x implies RevFINSEQ-5K3 f just-once-valuesFINSEQ-4R2 x"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
    assume A1: "f just-once-valuesFINSEQ-4R2 x"
    then have A2: "x inTARSKIR2 rngFUNCT-1K2 f"
      using finseq_4_th_5 sorry
    then have " not x inTARSKIR2 rngFUNCT-1K2 (f -|FINSEQ-4K5 x)"
      using finseq_4_th_37 sorry
    then have " not x inTARSKIR2 rngFUNCT-1K2 (RevFINSEQ-5K3 (f -|FINSEQ-4K5 x))"
      using finseq_5_th_57 sorry
    then have A3: " not x inTARSKIR2 rngFUNCT-1K2 (RevFINSEQ-5K3 f  |--FINSEQ-4K6 x)"
      using A1 finseq_6_th_38 sorry
    have "x inTARSKIR2 rngFUNCT-1K2 (RevFINSEQ-5K3 f)"
      using A2 finseq_5_th_57 sorry
    thus "RevFINSEQ-5K3 f just-once-valuesFINSEQ-4R2 x"
      using A3 finseq_4_th_45 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
reserve D for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve p, p1, p2, p3 for "ElementSUBSET-1M1-of D"
reserve f, f1, f2 for "FinSequenceFINSEQ-1M3-of D"
mtheorem finseq_6_th_40:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p =FINSEQ-1R1 (f -|FINSEQ-4K5 p)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies (f -|FINSEQ-4K5 p)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>) =HIDDENR1 f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume "p inTARSKIR2 rngFUNCT-1K2 f"
    then have "(f -|FINSEQ-4K5 p)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>) =HIDDENR1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 f)"
      using finseq_5_th_24 sorry
    also have "... = f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p"
      using finseq_5_def_1 sorry
    finally show "(f -|FINSEQ-4K5 p)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>) =HIDDENR1 f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_41:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K8 (f  |--FINSEQ-4K6 p)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K8 (f  |--FINSEQ-4K6 p) =HIDDENR1 f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume "p inTARSKIR2 rngFUNCT-1K2 f"
    then have "(<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K8 (f  |--FINSEQ-4K6 p) =HIDDENR1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f)"
      using finseq_5_th_35 sorry
    also have "... = f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p"
      using finseq_5_def_2 sorry
    finally show "(<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K8 (f  |--FINSEQ-4K6 p) =HIDDENR1 f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_42:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds f <>HIDDENR2 {}XBOOLE-0K1 implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M inTARSKIR2 rngFUNCT-1K2 f"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds f <>HIDDENR2 {}XBOOLE-0K1 implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M inTARSKIR2 rngFUNCT-1K2 f"
  proof(rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume "f <>HIDDENR2 {}XBOOLE-0K1"
    then have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
      using finseq_5_th_6 sorry
    thus "f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M inTARSKIR2 rngFUNCT-1K2 f"
      using partfun2_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_43:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds f <>HIDDENR2 {}XBOOLE-0K1 implies (f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M)..FINSEQ-4K4 f =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds f <>HIDDENR2 {}XBOOLE-0K1 implies (f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M)..FINSEQ-4K4 f =HIDDENR1 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume "f <>HIDDENR2 {}XBOOLE-0K1"
    then have A1: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
      using finseq_5_th_6 sorry
    have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M inTARSKIR2 {TARSKIK1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M }"
      using tarski_def_1 sorry
    then have A2: "\<one>\<^sub>M inTARSKIR2 f \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,D)\<^esub> {TARSKIK1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M }"
      using A1 partfun2_th_26 sorry
    have "f \<inverse>FUNCT-1K6 {TARSKIK1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M } c=TARSKIR1 domFINSEQ-1K5 f"
      using relat_1_th_132 sorry
    then have A3: "f \<inverse>FUNCT-1K6 {TARSKIK1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M } c=TARSKIR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 f)"
      using finseq_1_def_3 sorry
    have "(f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M)..FINSEQ-4K4 f =HIDDENR1 SgmFINSEQ-1K15 (f \<inverse>FUNCT-1K6 {TARSKIK1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M }) .FUNCT-1K1 \<one>\<^sub>M"
      using finseq_4_def_4 sorry
    also have "... = \<one>\<^sub>M"
      using A3 A2 finseq_6_th_1 sorry
    finally show "(f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M)..FINSEQ-4K4 f =HIDDENR1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_44:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds f <>HIDDENR2 {}XBOOLE-0K1 & f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 p implies f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> p*> & f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p =FINSEQ-1R1 f"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds f <>HIDDENR2 {}XBOOLE-0K1 & f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 p implies f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p =HIDDENR1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> p*> & f =HIDDENR1 f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "f <>HIDDENR2 {}XBOOLE-0K1"
      and A2: "f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 p"
    have A3: "p inTARSKIR2 rngFUNCT-1K2 f"
      using A1 A2 finseq_6_th_42 sorry
    have "p ..FINSEQ-4K4 f =XBOOLE-0R4 \<one>\<^sub>M"
      using A1 A2 finseq_6_th_43 sorry
    then have A4: "f -|FINSEQ-4K5 p =FINSEQ-1R1 {}XBOOLE-0K1"
      using A3 finseq_4_th_40 sorry
    then have "f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p =HIDDENR1 {}XBOOLE-0K1 ^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)"
      using A3 finseq_6_th_40 sorry
    also have "... = <*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>"
      using finseq_1_th_34 sorry
    finally show "f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p =HIDDENR1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>"
       sorry
    have "f =HIDDENR1 ({}XBOOLE-0K1 ^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>))^FINSEQ-1K8 (f  |--FINSEQ-4K6 p)"
      using A3 A4 finseq_4_th_51 sorry
    also have "... = (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K8 (f  |--FINSEQ-4K6 p)"
      using finseq_1_th_34 sorry
    also have "... = f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p"
      using A3 finseq_6_th_41 sorry
    finally show "f =HIDDENR1 f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_45:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds ((<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> f)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M =FINSEQ-1R1 f"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds ((<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> f)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M =FINSEQ-1R1 f"
  proof(rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p1 assume [ty]: "p1 be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    have A1: "((<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> f)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 p1"
      using finseq_5_th_15 sorry
    have "\<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 \<one>\<^sub>M"
       sorry
    then have A2: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)"
      using finseq_1_th_38 sorry
    have "domFINSEQ-1K5 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>) c=TARSKIR1 domFINSEQ-1K5 ((<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> f)"
      using finseq_1_th_26 sorry
    then have "(<*FINSEQ-1K13\<^bsub>(D)\<^esub> ((<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> f)/.PARTFUN1K7\<^bsub>(D)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (((<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> f)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) =HIDDENR1 ((<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> f)/^RFINSEQK2\<^bsub>(D)\<^esub> (0NUMBERSK6)"
      using A2 finseq_5_th_31 sorry
    also have "... = (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> f"
      using finseq_5_th_28 sorry
    finally have "(<*FINSEQ-1K13\<^bsub>(D)\<^esub> ((<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> f)/.PARTFUN1K7\<^bsub>(D)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (((<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> f)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) =HIDDENR1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> f"
       sorry
    thus "((<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> f)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M =FINSEQ-1R1 f"
      using A1 finseq_1_th_33 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_46:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds (<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> p2*>"
  using finseq_6_th_45 sorry

mtheorem finseq_6_th_47:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for p3 be ElementSUBSET-1M1-of D holds (<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M =FINSEQ-1R1 <*FINSEQ-4K2\<^bsub>(D)\<^esub> p2,p3 *>"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for p3 be ElementSUBSET-1M1-of D holds (<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M =FINSEQ-1R1 <*FINSEQ-4K2\<^bsub>(D)\<^esub> p2,p3 *>"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p1 assume [ty]: "p1 be ElementSUBSET-1M1-of D"
    fix p2 assume [ty]: "p2 be ElementSUBSET-1M1-of D"
    fix p3 assume [ty]: "p3 be ElementSUBSET-1M1-of D"
    have "<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *> =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-4K2\<^bsub>(D)\<^esub> p2,p3 *>)"
      using finseq_1_th_43 sorry
    thus "(<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M =FINSEQ-1R1 <*FINSEQ-4K2\<^bsub>(D)\<^esub> p2,p3 *>"
      using finseq_6_th_45 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_48:
" for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds k inTARSKIR2 domFINSEQ-1K5 f & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 k implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> i <>HIDDENR2 f /.PARTFUN1K7\<^bsub>(D)\<^esub> k) implies (f /.PARTFUN1K7\<^bsub>(D)\<^esub> k)..FINSEQ-4K4 f =XBOOLE-0R4 k"
proof-
  have " for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds k inTARSKIR2 domFINSEQ-1K5 f & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 k implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> i <>HIDDENR2 f /.PARTFUN1K7\<^bsub>(D)\<^esub> k) implies ((f /.PARTFUN1K7\<^bsub>(D)\<^esub> k)..FINSEQ-4K4 f <>HIDDENR2 k implies  False )"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "k inTARSKIR2 domFINSEQ-1K5 f"
      and A2: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 k implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> i <>HIDDENR2 f /.PARTFUN1K7\<^bsub>(D)\<^esub> k"
    have A3: "f /.PARTFUN1K7\<^bsub>(D)\<^esub> k inTARSKIR2 rngFUNCT-1K2 f"
      using A1 partfun2_th_2 sorry
    assume A4: "(f /.PARTFUN1K7\<^bsub>(D)\<^esub> k)..FINSEQ-4K4 f <>HIDDENR2 k"
    have "(f /.PARTFUN1K7\<^bsub>(D)\<^esub> k)..FINSEQ-4K4 f <=XXREAL-0R1 k"
      using A1 finseq_5_th_39 sorry
    then have "(f /.PARTFUN1K7\<^bsub>(D)\<^esub> k)..FINSEQ-4K4 f <XXREAL-0R3 k"
      using A4 xxreal_0_th_1 sorry
    then have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> ((f /.PARTFUN1K7\<^bsub>(D)\<^esub> k)..FINSEQ-4K4 f) <>HIDDENR2 f /.PARTFUN1K7\<^bsub>(D)\<^esub> k"
      using A2 A3 finseq_4_th_21 sorry
    thus " False "
      using A3 finseq_5_th_38 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_49:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds p1 <>HIDDENR2 p2 implies (<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2 =FINSEQ-1R1 <*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds p1 <>HIDDENR2 p2 implies (<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2 =HIDDENR1 <*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p1 assume [ty]: "p1 be ElementSUBSET-1M1-of D"
    fix p2 assume [ty]: "p2 be ElementSUBSET-1M1-of D"
    assume A1: "p1 <>HIDDENR2 p2"
    have "rngFUNCT-1K2 (<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>) =XBOOLE-0R4 {TARSKIK2 p1,p2 }"
      using finseq_6_lm_1 sorry
    then have "p2 inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>)"
      using tarski_def_2 sorry
    then have "(<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2 =HIDDENR1 (<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *> -|FINSEQ-4K5 p2)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p2*>)"
      using finseq_6_th_40 sorry
    also have "... = <*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>"
      using A1 finseq_6_th_26 sorry
    finally show "(<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2 =HIDDENR1 <*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_50:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for p3 be ElementSUBSET-1M1-of D holds p1 <>HIDDENR2 p2 implies (<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2 =FINSEQ-1R1 <*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for p3 be ElementSUBSET-1M1-of D holds p1 <>HIDDENR2 p2 implies (<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2 =HIDDENR1 <*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p1 assume [ty]: "p1 be ElementSUBSET-1M1-of D"
    fix p2 assume [ty]: "p2 be ElementSUBSET-1M1-of D"
    fix p3 assume [ty]: "p3 be ElementSUBSET-1M1-of D"
    assume A1: "p1 <>HIDDENR2 p2"
    have "rngFUNCT-1K2 (<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>) =XBOOLE-0R4 {ENUMSET1K1 p1,p2,p3 }"
      using finseq_6_lm_2 sorry
    then have "p2 inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>)"
      using enumset1_def_1 sorry
    then have "(<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2 =HIDDENR1 (<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *> -|FINSEQ-4K5 p2)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p2*>)"
      using finseq_6_th_40 sorry
    also have "... = <*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>"
      using A1 finseq_6_th_27 sorry
    finally show "(<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2 =HIDDENR1 <*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_51:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for p3 be ElementSUBSET-1M1-of D holds p1 <>HIDDENR2 p3 & p2 <>HIDDENR2 p3 implies (<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p3 =FINSEQ-1R1 <*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for p3 be ElementSUBSET-1M1-of D holds p1 <>HIDDENR2 p3 & p2 <>HIDDENR2 p3 implies (<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p3 =HIDDENR1 <*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p1 assume [ty]: "p1 be ElementSUBSET-1M1-of D"
    fix p2 assume [ty]: "p2 be ElementSUBSET-1M1-of D"
    fix p3 assume [ty]: "p3 be ElementSUBSET-1M1-of D"
    assume A1: "p1 <>HIDDENR2 p3"
      and A2: "p2 <>HIDDENR2 p3"
    have "rngFUNCT-1K2 (<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>) =XBOOLE-0R4 {ENUMSET1K1 p1,p2,p3 }"
      using finseq_6_lm_2 sorry
    then have "p3 inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>)"
      using enumset1_def_1 sorry
    then have "(<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p3 =HIDDENR1 (<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *> -|FINSEQ-4K5 p3)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p3*>)"
      using finseq_6_th_40 sorry
    also have "... = (<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p3*>)"
      using A1 A2 finseq_6_th_28 sorry
    also have "... = <*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>"
       sorry
    finally show "(<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p3 =HIDDENR1 <*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_52:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>):-FINSEQ-5K2\<^bsub>(D)\<^esub> p =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> p*> & (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>):-FINSEQ-5K2\<^bsub>(D)\<^esub> p =HIDDENR1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> p*> & (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p =HIDDENR1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>"
  proof(rule ballI,rule ballI,rule conjMI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    have "p inTARSKIR2 {TARSKIK1 p}"
      using tarski_def_1 sorry
    then have A1: "p inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)"
      using finseq_1_th_39 sorry
    then have "(<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>):-FINSEQ-5K2\<^bsub>(D)\<^esub> p =HIDDENR1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>  |--FINSEQ-4K6 p)"
      using finseq_6_th_41 sorry
    also have "... = (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K8 {}XBOOLE-0K1"
      using finseq_6_th_32 sorry
    also have "... = <*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>"
      using finseq_1_th_34 sorry
    finally show "(<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>):-FINSEQ-5K2\<^bsub>(D)\<^esub> p =HIDDENR1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>"
       sorry
    have "(<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p =HIDDENR1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*> -|FINSEQ-4K5 p)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)"
      using A1 finseq_6_th_40 sorry
    also have "... = {}XBOOLE-0K1 ^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)"
      using finseq_6_th_32 sorry
    also have "... = <*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>"
      using finseq_1_th_34 sorry
    finally show "(<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p =HIDDENR1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_53:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds p1 <>HIDDENR2 p2 implies (<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>):-FINSEQ-5K2\<^bsub>(D)\<^esub> p2 =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> p2*>"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds p1 <>HIDDENR2 p2 implies (<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>):-FINSEQ-5K2\<^bsub>(D)\<^esub> p2 =HIDDENR1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> p2*>"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p1 assume [ty]: "p1 be ElementSUBSET-1M1-of D"
    fix p2 assume [ty]: "p2 be ElementSUBSET-1M1-of D"
    assume A1: "p1 <>HIDDENR2 p2"
    have "p2 inTARSKIR2 {TARSKIK2 p1,p2 }"
      using tarski_def_2 sorry
    then have "p2 inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>)"
      using finseq_6_lm_1 sorry
    then have "(<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>):-FINSEQ-5K2\<^bsub>(D)\<^esub> p2 =HIDDENR1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p2*>)^FINSEQ-1K8 (<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>  |--FINSEQ-4K6 p2)"
      using finseq_6_th_41 sorry
    also have "... = (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p2*>)^FINSEQ-1K8 {}XBOOLE-0K1"
      using A1 finseq_6_th_33 sorry
    also have "... = <*FINSEQ-1K13\<^bsub>(D)\<^esub> p2*>"
      using finseq_1_th_34 sorry
    finally show "(<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>):-FINSEQ-5K2\<^bsub>(D)\<^esub> p2 =HIDDENR1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> p2*>"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_54:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for p3 be ElementSUBSET-1M1-of D holds p1 <>HIDDENR2 p2 implies (<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>):-FINSEQ-5K2\<^bsub>(D)\<^esub> p2 =FINSEQ-1R1 <*FINSEQ-4K2\<^bsub>(D)\<^esub> p2,p3 *>"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for p3 be ElementSUBSET-1M1-of D holds p1 <>HIDDENR2 p2 implies (<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>):-FINSEQ-5K2\<^bsub>(D)\<^esub> p2 =HIDDENR1 <*FINSEQ-4K2\<^bsub>(D)\<^esub> p2,p3 *>"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p1 assume [ty]: "p1 be ElementSUBSET-1M1-of D"
    fix p2 assume [ty]: "p2 be ElementSUBSET-1M1-of D"
    fix p3 assume [ty]: "p3 be ElementSUBSET-1M1-of D"
    assume A1: "p1 <>HIDDENR2 p2"
    have "p2 inTARSKIR2 {ENUMSET1K1 p1,p2,p3 }"
      using enumset1_def_1 sorry
    then have "p2 inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>)"
      using finseq_6_lm_2 sorry
    then have "(<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>):-FINSEQ-5K2\<^bsub>(D)\<^esub> p2 =HIDDENR1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p2*>)^FINSEQ-1K8 (<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>  |--FINSEQ-4K6 p2)"
      using finseq_6_th_41 sorry
    also have "... = <*FINSEQ-4K2\<^bsub>(D)\<^esub> p2,p3 *>"
      using A1 finseq_6_th_30 sorry
    finally show "(<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>):-FINSEQ-5K2\<^bsub>(D)\<^esub> p2 =HIDDENR1 <*FINSEQ-4K2\<^bsub>(D)\<^esub> p2,p3 *>"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_55:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for p3 be ElementSUBSET-1M1-of D holds p1 <>HIDDENR2 p3 & p2 <>HIDDENR2 p3 implies (<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>):-FINSEQ-5K2\<^bsub>(D)\<^esub> p3 =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> p3*>"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for p3 be ElementSUBSET-1M1-of D holds p1 <>HIDDENR2 p3 & p2 <>HIDDENR2 p3 implies (<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>):-FINSEQ-5K2\<^bsub>(D)\<^esub> p3 =HIDDENR1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> p3*>"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p1 assume [ty]: "p1 be ElementSUBSET-1M1-of D"
    fix p2 assume [ty]: "p2 be ElementSUBSET-1M1-of D"
    fix p3 assume [ty]: "p3 be ElementSUBSET-1M1-of D"
    assume A1: "p1 <>HIDDENR2 p3"
      and A2: "p2 <>HIDDENR2 p3"
    have "p3 inTARSKIR2 {ENUMSET1K1 p1,p2,p3 }"
      using enumset1_def_1 sorry
    then have "p3 inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>)"
      using finseq_6_lm_2 sorry
    then have "(<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>):-FINSEQ-5K2\<^bsub>(D)\<^esub> p3 =HIDDENR1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p3*>)^FINSEQ-1K8 (<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>  |--FINSEQ-4K6 p3)"
      using finseq_6_th_41 sorry
    also have "... = (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p3*>)^FINSEQ-1K8 {}XBOOLE-0K1"
      using A1 A2 finseq_6_th_34 sorry
    also have "... = <*FINSEQ-1K13\<^bsub>(D)\<^esub> p3*>"
      using finseq_1_th_34 sorry
    finally show "(<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>):-FINSEQ-5K2\<^bsub>(D)\<^esub> p3 =HIDDENR1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> p3*>"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_56:
" for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & p ..FINSEQ-4K4 f >XXREAL-0R4 k implies p ..FINSEQ-4K4 f =XBOOLE-0R4 k +NAT-1K1 p ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)"
proof-
  have " for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & p ..FINSEQ-4K4 f >XXREAL-0R4 k implies p ..FINSEQ-4K4 f =XBOOLE-0R4 k +NAT-1K1 p ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f"
      and A2: "p ..FINSEQ-4K4 f >XXREAL-0R4 k"
    obtain i where 
      [ty]:"i be ElementSUBSET-1M1-of NATNUMBERSK1" and iDef:"i = p ..FINSEQ-4K4 f -XCMPLX-0K6 k"
      using A2 int_1_th_5 sorry
    have A3: "i +XCMPLX-0K2 k <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A1 finseq_4_th_21 sorry
    then have A4: "i <=XXREAL-0R1 lenFINSEQ-1K4 f -XCMPLX-0K6 k"
      using xreal_1_th_19 sorry
    have "k <=XXREAL-0R1 k +NAT-1K1 i"
      using nat_1_th_11 sorry
    then have "k <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A3 xxreal_0_th_2 sorry
    then have A5: "i <=XXREAL-0R1 lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)"
      using A4 rfinseq_def_1 sorry
    have "i <>HIDDENR2 0NUMBERSK6"
      using A2 sorry
    then have "\<one>\<^sub>M <=XXREAL-0R1 i"
      using nat_1_th_14 sorry
    then have A6: "i inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)"
      using A5 finseq_3_th_25 sorry
    have A7: "k +NAT-1K1 i =XBOOLE-0R4 p ..FINSEQ-4K4 f"
       sorry
    have A8: " for j be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 j & j <XXREAL-0R3 i implies (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)/.PARTFUN1K7\<^bsub>(D)\<^esub> j <>HIDDENR2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)/.PARTFUN1K7\<^bsub>(D)\<^esub> i"
    proof(rule ballI,rule impMI ,rule impI)
      fix j assume [ty]: "j be NatNAT-1M1"
      assume A9: "\<one>\<^sub>M <=XXREAL-0R1 j"
        and A10: "j <XXREAL-0R3 i"
      obtain J where 
        [ty]:"J be NatNAT-1M1" and JDef:"J = j"
         sorry
      have "k +XCMPLX-0K2 j >=XXREAL-0R2 j"
        using nat_1_th_11 sorry
      then have A11: "\<one>\<^sub>M <=XXREAL-0R1 k +XCMPLX-0K2 j"
        using A9 xxreal_0_th_2 sorry
      have "j <=XXREAL-0R1 lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)"
        using A5 A10 xxreal_0_th_2 sorry
      then have "j inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)"
        using A9 finseq_3_th_25 sorry
      then have A12: "f /.PARTFUN1K7\<^bsub>(D)\<^esub> (k +XCMPLX-0K2 j) =XBOOLE-0R4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)/.PARTFUN1K7\<^bsub>(D)\<^esub> j"
        using finseq_5_th_27 sorry
      have A13: "k +NAT-1K1 i <=XXREAL-0R1 lenFINSEQ-1K4 f"
        using A1 finseq_4_th_21 sorry
      have "k +XCMPLX-0K2 j <XXREAL-0R3 k +NAT-1K1 i"
        using A10 xreal_1_th_6 sorry
      then have "k +XCMPLX-0K2 j <=XXREAL-0R1 lenFINSEQ-1K4 f"
        using A13 xxreal_0_th_2 sorry
      then have A14: "k +XCMPLX-0K2 J inTARSKIR2 domFINSEQ-1K5 f"
        using A11 finseq_3_th_25 sorry
      have "k +XCMPLX-0K2 j <XXREAL-0R3 p ..FINSEQ-4K4 f"
        using A7 A10 xreal_1_th_6 sorry
      then have A15: "f /.PARTFUN1K7\<^bsub>(D)\<^esub> (k +XCMPLX-0K2 j) <>HIDDENR2 p"
        using A14 finseq_5_th_39 sorry
      have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> (k +NAT-1K1 i) =XBOOLE-0R4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)/.PARTFUN1K7\<^bsub>(D)\<^esub> i"
        using A6 finseq_5_th_27 sorry
      thus "(f /^RFINSEQK2\<^bsub>(D)\<^esub> k)/.PARTFUN1K7\<^bsub>(D)\<^esub> j <>HIDDENR2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)/.PARTFUN1K7\<^bsub>(D)\<^esub> i"
        using A1 A12 A15 finseq_5_th_38 sorry
    qed "sorry"
    have "(f /^RFINSEQK2\<^bsub>(D)\<^esub> k)/.PARTFUN1K7\<^bsub>(D)\<^esub> i =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> (k +NAT-1K1 i)"
      using A6 finseq_5_th_27 sorry
    also have "... = p"
      using A1 finseq_5_th_38 sorry
    finally have "(f /^RFINSEQK2\<^bsub>(D)\<^esub> k)/.PARTFUN1K7\<^bsub>(D)\<^esub> i =HIDDENR1 p"
       sorry
    then have "p ..FINSEQ-4K4 f -XCMPLX-0K6 k =XBOOLE-0R4 p ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)"
      using A6 A8 finseq_6_th_48 sorry
    thus "p ..FINSEQ-4K4 f =XBOOLE-0R4 k +NAT-1K1 p ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_57:
" for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & p ..FINSEQ-4K4 f >XXREAL-0R4 k implies p inTARSKIR2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)"
proof-
  have " for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & p ..FINSEQ-4K4 f >XXREAL-0R4 k implies p inTARSKIR2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f"
      and A2: "p ..FINSEQ-4K4 f >XXREAL-0R4 k"
    have A3: "k +NAT-1K1 p ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k) =XBOOLE-0R4 p ..FINSEQ-4K4 f"
      using A1 A2 finseq_6_th_56 sorry
    then have "p ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k) <>HIDDENR2 0NUMBERSK6"
      using A2 sorry
    then have A4: "\<one>\<^sub>M <=XXREAL-0R1 p ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)"
      using nat_1_th_14 sorry
    have "p ..FINSEQ-4K4 f <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A1 finseq_4_th_21 sorry
    then have "k <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A2 xxreal_0_th_2 sorry
    then have "lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k) =XBOOLE-0R4 lenFINSEQ-1K4 f -XCMPLX-0K6 k"
      using rfinseq_def_1 sorry
    then have A5: "lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k) +XCMPLX-0K2 k =XBOOLE-0R4 lenFINSEQ-1K4 f"
       sorry
    have "k +NAT-1K1 p ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k) <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A1 A3 finseq_4_th_21 sorry
    then have "p ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k) <=XXREAL-0R1 lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)"
      using A5 xreal_1_th_6 sorry
    then have A6: "p ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k) inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)"
      using A4 finseq_3_th_25 sorry
    then have "(f /^RFINSEQK2\<^bsub>(D)\<^esub> k)/.PARTFUN1K7\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)) inTARSKIR2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)"
      using partfun2_th_2 sorry
    then have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> (k +NAT-1K1 p ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)) inTARSKIR2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)"
      using A6 finseq_5_th_27 sorry
    thus "p inTARSKIR2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)"
      using A1 A3 finseq_5_th_38 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_58:
" for i be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds k <XXREAL-0R3 i & i inTARSKIR2 domFINSEQ-1K5 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> i inTARSKIR2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)"
proof-
  have " for i be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds k <XXREAL-0R3 i & i inTARSKIR2 domFINSEQ-1K5 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> i inTARSKIR2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "k <XXREAL-0R3 i"
      and A2: "i inTARSKIR2 domFINSEQ-1K5 f"
    obtain j where 
      [ty]:"j be ElementSUBSET-1M1-of NATNUMBERSK1" and jDef:"j = i -XCMPLX-0K6 k"
      using A1 int_1_th_5 sorry
    have "j >XXREAL-0R4 0NUMBERSK6"
      using A1 xreal_1_th_50 sorry
    then have A3: "\<one>\<^sub>M <=XXREAL-0R1 j"
      using nat_1_th_14 sorry
    have A4: "i =XBOOLE-0R4 j +XCMPLX-0K2 k"
       sorry
    have A5: "i <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A2 finseq_3_th_25 sorry
    then have "k <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A1 xxreal_0_th_2 sorry
    then have "lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k) =XBOOLE-0R4 lenFINSEQ-1K4 f -XCMPLX-0K6 k"
      using rfinseq_def_1 sorry
    then have "lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k) +XCMPLX-0K2 k =XBOOLE-0R4 lenFINSEQ-1K4 f"
       sorry
    then have "j <=XXREAL-0R1 lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)"
      using A4 A5 xreal_1_th_6 sorry
    then have A6: "j inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)"
      using A3 finseq_3_th_25 sorry
    then have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)/.PARTFUN1K7\<^bsub>(D)\<^esub> j"
      using A4 finseq_5_th_27 sorry
    thus "f /.PARTFUN1K7\<^bsub>(D)\<^esub> i inTARSKIR2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)"
      using A6 partfun2_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_59:
" for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & p ..FINSEQ-4K4 f >XXREAL-0R4 k implies (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p =FINSEQ-1R1 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> k"
proof-
  have " for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & p ..FINSEQ-4K4 f >XXREAL-0R4 k implies (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p =FINSEQ-1R1 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> k"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f"
      and A2: "p ..FINSEQ-4K4 f >XXREAL-0R4 k"
    have A3: "p inTARSKIR2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)"
      using A1 A2 finseq_6_th_57 sorry
    have "p ..FINSEQ-4K4 f =XBOOLE-0R4 k +NAT-1K1 p ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)"
      using A1 A2 finseq_6_th_56 sorry
    then have A4: "lenFINSEQ-1K4 ((f /^RFINSEQK2\<^bsub>(D)\<^esub> k)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p) =HIDDENR1 p ..FINSEQ-4K4 f -XCMPLX-0K6 k"
      using A3 finseq_5_th_42 sorry
    also have "... = lenFINSEQ-1K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) -XCMPLX-0K6 k"
      using A1 finseq_5_th_42 sorry
    finally have "lenFINSEQ-1K4 ((f /^RFINSEQK2\<^bsub>(D)\<^esub> k)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p) =HIDDENR1 lenFINSEQ-1K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) -XCMPLX-0K6 k"
       sorry
    have A5: " for m be NatNAT-1M1 holds m inTARSKIR2 domFINSEQ-1K5 ((f /^RFINSEQK2\<^bsub>(D)\<^esub> k)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p) implies ((f /^RFINSEQK2\<^bsub>(D)\<^esub> k)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p).FUNCT-1K1 m =HIDDENR1 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p).FUNCT-1K1 (m +XCMPLX-0K2 k)"
    proof(rule ballI,rule impI)
      fix m assume [ty]: "m be NatNAT-1M1"
      have A6: "m +XCMPLX-0K2 k >=XXREAL-0R2 m"
        using nat_1_th_11 sorry
      obtain M where 
        [ty]:"M be NatNAT-1M1" and MDef:"M = m"
         sorry
      assume A7: "m inTARSKIR2 domFINSEQ-1K5 ((f /^RFINSEQK2\<^bsub>(D)\<^esub> k)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p)"
      then have "m <=XXREAL-0R1 lenFINSEQ-1K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) -XCMPLX-0K6 k"
        using A4 finseq_3_th_25 sorry
      then have A8: "m +XCMPLX-0K2 k <=XXREAL-0R1 lenFINSEQ-1K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)"
        using xreal_1_th_19 sorry
      have "\<one>\<^sub>M <=XXREAL-0R1 m"
        using A7 finseq_3_th_25 sorry
      then have "\<one>\<^sub>M <=XXREAL-0R1 m +XCMPLX-0K2 k"
        using A6 xxreal_0_th_2 sorry
      then have A9: "M +XCMPLX-0K2 k inTARSKIR2 domFINSEQ-1K5 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)"
        using A8 finseq_3_th_25 sorry
      have "lenFINSEQ-1K4 ((f /^RFINSEQK2\<^bsub>(D)\<^esub> k)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 p ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)"
        using A3 finseq_5_th_42 sorry
      then have A10: "m inTARSKIR2 SegFINSEQ-1K2 (p ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k))"
        using A7 finseq_1_def_3 sorry
      have "(f /^RFINSEQK2\<^bsub>(D)\<^esub> k)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p =FINSEQ-1R1 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k) |FINSEQ-1K18\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k))"
        using finseq_5_def_1 sorry
      then have A11: "domFINSEQ-1K5 ((f /^RFINSEQK2\<^bsub>(D)\<^esub> k)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p) c=TARSKIR1 domFINSEQ-1K5 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)"
        using finseq_5_th_18 sorry
      have "lenFINSEQ-1K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 p ..FINSEQ-4K4 f"
        using A1 finseq_5_th_42 sorry
      then have A12: "m +XCMPLX-0K2 k inTARSKIR2 SegFINSEQ-1K2 (p ..FINSEQ-4K4 f)"
        using A9 finseq_1_def_3 sorry
      have "((f /^RFINSEQK2\<^bsub>(D)\<^esub> k)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p).FUNCT-1K1 m =HIDDENR1 ((f /^RFINSEQK2\<^bsub>(D)\<^esub> k)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> m"
        using A7 partfun1_def_6 sorry
      also have "... = (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)/.PARTFUN1K7\<^bsub>(D)\<^esub> m"
        using A3 A10 finseq_5_th_43 sorry
      also have "... = f /.PARTFUN1K7\<^bsub>(D)\<^esub> (m +XCMPLX-0K2 k)"
        using A7 A11 finseq_5_th_27 sorry
      also have "... = (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> (M +XCMPLX-0K2 k)"
        using A1 A12 finseq_5_th_43 sorry
      also have "... = (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p).FUNCT-1K1 (m +XCMPLX-0K2 k)"
        using A9 partfun1_def_6 sorry
      finally show "((f /^RFINSEQK2\<^bsub>(D)\<^esub> k)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p).FUNCT-1K1 m =HIDDENR1 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p).FUNCT-1K1 (m +XCMPLX-0K2 k)"
         sorry
    qed "sorry"
    have "k <=XXREAL-0R1 lenFINSEQ-1K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)"
      using A1 A2 finseq_5_th_42 sorry
    thus "(f /^RFINSEQK2\<^bsub>(D)\<^esub> k)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p =FINSEQ-1R1 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> k"
      using A4 A5 rfinseq_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_60:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & p ..FINSEQ-4K4 f <>HIDDENR2 \<one>\<^sub>M implies (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p =FINSEQ-1R1 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & p ..FINSEQ-4K4 f <>HIDDENR2 \<one>\<^sub>M implies (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p =FINSEQ-1R1 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f"
      and A2: "p ..FINSEQ-4K4 f <>HIDDENR2 \<one>\<^sub>M"
    have "p ..FINSEQ-4K4 f >=XXREAL-0R2 \<one>\<^sub>M"
      using A1 finseq_4_th_21 sorry
    then have "p ..FINSEQ-4K4 f >XXREAL-0R4 \<one>\<^sub>M"
      using A2 xxreal_0_th_1 sorry
    thus "(f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p =FINSEQ-1R1 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M"
      using A1 finseq_6_th_59 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_61:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
  proof(rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    have "rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>) =XBOOLE-0R4 {TARSKIK1 p}"
      using finseq_1_th_39 sorry
    then have A1: "p inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)"
      using tarski_def_1 sorry
    have "f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f)"
      using finseq_5_def_2 sorry
    then have "rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>) \\/XBOOLE-0K2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f)"
      using finseq_1_th_31 sorry
    thus "p inTARSKIR2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
      using A1 xboole_0_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_62:
" for x be setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds (x inTARSKIR2 rngFUNCT-1K2 f & p inTARSKIR2 rngFUNCT-1K2 f) & x ..FINSEQ-4K4 f >=XXREAL-0R2 p ..FINSEQ-4K4 f implies x inTARSKIR2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
proof-
  have " for x be setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds x inTARSKIR2 rngFUNCT-1K2 f & (p inTARSKIR2 rngFUNCT-1K2 f & x ..FINSEQ-4K4 f >=XXREAL-0R2 p ..FINSEQ-4K4 f) implies x inTARSKIR2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "x inTARSKIR2 rngFUNCT-1K2 f"
      and A2: "p inTARSKIR2 rngFUNCT-1K2 f"
      and A3: "x ..FINSEQ-4K4 f >=XXREAL-0R2 p ..FINSEQ-4K4 f"
    show "x inTARSKIR2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
    proof-
      have cases: "x ..FINSEQ-4K4 f >XXREAL-0R4 p ..FINSEQ-4K4 f or x ..FINSEQ-4K4 f =XBOOLE-0R4 p ..FINSEQ-4K4 f"
        using A3 xxreal_0_th_1 sorry
      have case1: "x ..FINSEQ-4K4 f >XXREAL-0R4 p ..FINSEQ-4K4 f implies x inTARSKIR2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
      proof(rule impI)
        assume A4: "x ..FINSEQ-4K4 f >XXREAL-0R4 p ..FINSEQ-4K4 f"
        have "rngFUNCT-1K2 f c=TARSKIR1 D"
          using finseq_1_def_4 sorry
        then obtain q where 
          [ty]:"q be ElementSUBSET-1M1-of D" and qDef:"q = x"
          using A1 sorry
        have "f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f)"
          using finseq_5_def_2 sorry
        then have A5: "rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>) \\/XBOOLE-0K2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f)"
          using finseq_1_th_31 sorry
        have "q inTARSKIR2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f)"
          using A1 A4 finseq_6_th_57 sorry
        thus "x inTARSKIR2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
          using A5 xboole_0_def_3 sorry
      qed
      have case2: "x ..FINSEQ-4K4 f =XBOOLE-0R4 p ..FINSEQ-4K4 f implies x inTARSKIR2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
      proof(rule impI)
        assume "x ..FINSEQ-4K4 f =XBOOLE-0R4 p ..FINSEQ-4K4 f"
        then have "x =HIDDENR1 f .FUNCT-1K1 (p ..FINSEQ-4K4 f)"
          using A1 finseq_4_th_19 sorry
        also have "... = p"
          using A2 finseq_4_th_19 sorry
        finally have "x =HIDDENR1 p"
           sorry
        thus "x inTARSKIR2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
          using finseq_6_th_61 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_63:
" for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds (p inTARSKIR2 rngFUNCT-1K2 f & k <=XXREAL-0R1 lenFINSEQ-1K4 f) & k >=XXREAL-0R2 p ..FINSEQ-4K4 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> k inTARSKIR2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
proof-
  have " for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & (k <=XXREAL-0R1 lenFINSEQ-1K4 f & k >=XXREAL-0R2 p ..FINSEQ-4K4 f) implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> k inTARSKIR2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f"
      and A2: "k <=XXREAL-0R1 lenFINSEQ-1K4 f"
      and A3: "k >=XXREAL-0R2 p ..FINSEQ-4K4 f"
    let ?x = "f /.PARTFUN1K7\<^bsub>(D)\<^esub> k"
    show "f /.PARTFUN1K7\<^bsub>(D)\<^esub> k inTARSKIR2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
    proof-
      have cases: "k >XXREAL-0R4 p ..FINSEQ-4K4 f or k =XBOOLE-0R4 p ..FINSEQ-4K4 f"
        using A3 xxreal_0_th_1 sorry
      have case1: "k >XXREAL-0R4 p ..FINSEQ-4K4 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> k inTARSKIR2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
      proof(rule impI)
        assume A4: "k >XXREAL-0R4 p ..FINSEQ-4K4 f"
        obtain q where 
          [ty]:"q be ElementSUBSET-1M1-of D" and qDef:"q = ?x"
           sorry
        have "\<one>\<^sub>M <=XXREAL-0R1 p ..FINSEQ-4K4 f"
          using A1 finseq_4_th_21 sorry
        then have "\<one>\<^sub>M <=XXREAL-0R1 k"
          using A3 xxreal_0_th_2 sorry
        then have "k inTARSKIR2 domFINSEQ-1K5 f"
          using A2 finseq_3_th_25 sorry
        then have A5: "q inTARSKIR2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f)"
          using A4 finseq_6_th_58 sorry
        have "f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f)"
          using finseq_5_def_2 sorry
        then have "rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>) \\/XBOOLE-0K2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f)"
          using finseq_1_th_31 sorry
        thus "f /.PARTFUN1K7\<^bsub>(D)\<^esub> k inTARSKIR2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
          using A5 xboole_0_def_3 sorry
      qed
      have case2: "k =XBOOLE-0R4 p ..FINSEQ-4K4 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> k inTARSKIR2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
      proof(rule impI)
        assume "k =XBOOLE-0R4 p ..FINSEQ-4K4 f"
        then have "?x =XBOOLE-0R4 p"
          using A1 finseq_5_th_38 sorry
        thus "f /.PARTFUN1K7\<^bsub>(D)\<^esub> k inTARSKIR2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
          using finseq_6_th_61 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_64:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f1 be FinSequenceFINSEQ-1M3-of D holds  for f2 be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f1 implies (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2):-FINSEQ-5K2\<^bsub>(D)\<^esub> p =FINSEQ-1R1 (f1 :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)^FINSEQ-1K9\<^bsub>(D)\<^esub> f2"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f1 be FinSequenceFINSEQ-1M3-of D holds  for f2 be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f1 implies (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2):-FINSEQ-5K2\<^bsub>(D)\<^esub> p =HIDDENR1 (f1 :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)^FINSEQ-1K9\<^bsub>(D)\<^esub> f2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f1 assume [ty]: "f1 be FinSequenceFINSEQ-1M3-of D"
    fix f2 assume [ty]: "f2 be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f1"
    have "rngFUNCT-1K2 (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2) =XBOOLE-0R4 rngFUNCT-1K2 f1 \\/XBOOLE-0K2 rngFUNCT-1K2 f2"
      using finseq_1_th_31 sorry
    then have "p inTARSKIR2 rngFUNCT-1K2 (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)"
      using A1 xboole_0_def_3 sorry
    then have "(f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2):-FINSEQ-5K2\<^bsub>(D)\<^esub> p =HIDDENR1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K8 (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2  |--FINSEQ-4K6 p)"
      using finseq_6_th_41 sorry
    also have "... = (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K8 ((f1  |--FINSEQ-4K6 p)^FINSEQ-1K8 f2)"
      using A1 finseq_6_th_8 sorry
    also have "... = ((<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K8 (f1  |--FINSEQ-4K6 p))^FINSEQ-1K8 f2"
      using finseq_1_th_32 sorry
    also have "... = (f1 :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)^FINSEQ-1K9\<^bsub>(D)\<^esub> f2"
      using A1 finseq_6_th_41 sorry
    finally show "(f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2):-FINSEQ-5K2\<^bsub>(D)\<^esub> p =HIDDENR1 (f1 :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)^FINSEQ-1K9\<^bsub>(D)\<^esub> f2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_65:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f1 be FinSequenceFINSEQ-1M3-of D holds  for f2 be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f2 \\SUBSET-1K6 rngFUNCT-1K2 f1 implies (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2):-FINSEQ-5K2\<^bsub>(D)\<^esub> p =FINSEQ-1R1 f2 :-FINSEQ-5K2\<^bsub>(D)\<^esub> p"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f1 be FinSequenceFINSEQ-1M3-of D holds  for f2 be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f2 \\SUBSET-1K6 rngFUNCT-1K2 f1 implies (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2):-FINSEQ-5K2\<^bsub>(D)\<^esub> p =HIDDENR1 f2 :-FINSEQ-5K2\<^bsub>(D)\<^esub> p"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f1 assume [ty]: "f1 be FinSequenceFINSEQ-1M3-of D"
    fix f2 assume [ty]: "f2 be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f2 \\SUBSET-1K6 rngFUNCT-1K2 f1"
    have "rngFUNCT-1K2 (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2) =XBOOLE-0R4 rngFUNCT-1K2 f1 \\/XBOOLE-0K2 rngFUNCT-1K2 f2"
      using finseq_1_th_31 sorry
    then have "p inTARSKIR2 rngFUNCT-1K2 (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)"
      using A1 xboole_0_def_3 sorry
    then have "(f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2):-FINSEQ-5K2\<^bsub>(D)\<^esub> p =HIDDENR1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K8 (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2  |--FINSEQ-4K6 p)"
      using finseq_6_th_41 sorry
    also have "... = (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K8 (f2  |--FINSEQ-4K6 p)"
      using A1 finseq_6_th_9 sorry
    also have "... = f2 :-FINSEQ-5K2\<^bsub>(D)\<^esub> p"
      using A1 finseq_6_th_41 sorry
    finally show "(f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2):-FINSEQ-5K2\<^bsub>(D)\<^esub> p =HIDDENR1 f2 :-FINSEQ-5K2\<^bsub>(D)\<^esub> p"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_66:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f1 be FinSequenceFINSEQ-1M3-of D holds  for f2 be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f1 implies (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p =FINSEQ-1R1 f1 -:FINSEQ-5K1\<^bsub>(D)\<^esub> p"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f1 be FinSequenceFINSEQ-1M3-of D holds  for f2 be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f1 implies (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p =HIDDENR1 f1 -:FINSEQ-5K1\<^bsub>(D)\<^esub> p"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f1 assume [ty]: "f1 be FinSequenceFINSEQ-1M3-of D"
    fix f2 assume [ty]: "f2 be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f1"
    have "rngFUNCT-1K2 (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2) =XBOOLE-0R4 rngFUNCT-1K2 f1 \\/XBOOLE-0K2 rngFUNCT-1K2 f2"
      using finseq_1_th_31 sorry
    then have "p inTARSKIR2 rngFUNCT-1K2 (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)"
      using A1 xboole_0_def_3 sorry
    then have "(f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p =HIDDENR1 (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2 -|FINSEQ-4K5 p)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)"
      using finseq_6_th_40 sorry
    also have "... = (f1 -|FINSEQ-4K5 p)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)"
      using A1 finseq_6_th_12 sorry
    also have "... = f1 -:FINSEQ-5K1\<^bsub>(D)\<^esub> p"
      using A1 finseq_6_th_40 sorry
    finally show "(f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p =HIDDENR1 f1 -:FINSEQ-5K1\<^bsub>(D)\<^esub> p"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_67:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f1 be FinSequenceFINSEQ-1M3-of D holds  for f2 be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f2 \\SUBSET-1K6 rngFUNCT-1K2 f1 implies (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p =FINSEQ-1R1 f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> (f2 -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f1 be FinSequenceFINSEQ-1M3-of D holds  for f2 be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f2 \\SUBSET-1K6 rngFUNCT-1K2 f1 implies (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p =HIDDENR1 f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> (f2 -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f1 assume [ty]: "f1 be FinSequenceFINSEQ-1M3-of D"
    fix f2 assume [ty]: "f2 be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f2 \\SUBSET-1K6 rngFUNCT-1K2 f1"
    have "rngFUNCT-1K2 (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2) =XBOOLE-0R4 rngFUNCT-1K2 f1 \\/XBOOLE-0K2 rngFUNCT-1K2 f2"
      using finseq_1_th_31 sorry
    then have "p inTARSKIR2 rngFUNCT-1K2 (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)"
      using A1 xboole_0_def_3 sorry
    then have "(f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p =HIDDENR1 (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2 -|FINSEQ-4K5 p)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)"
      using finseq_6_th_40 sorry
    also have "... = (f1 ^FINSEQ-1K8 (f2 -|FINSEQ-4K5 p))^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)"
      using A1 finseq_6_th_15 sorry
    also have "... = f1 ^FINSEQ-1K8 ((f2 -|FINSEQ-4K5 p)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>))"
      using finseq_1_th_32 sorry
    also have "... = f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> (f2 -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)"
      using A1 finseq_6_th_40 sorry
    finally show "(f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p =HIDDENR1 f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> (f2 -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_68:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p):-FINSEQ-5K2\<^bsub>(D)\<^esub> p =FINSEQ-1R1 f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p):-FINSEQ-5K2\<^bsub>(D)\<^esub> p =HIDDENR1 f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p"
  proof(rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    have A1: "((<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f))/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 p"
      using finseq_5_th_15 sorry
    have "(f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p):-FINSEQ-5K2\<^bsub>(D)\<^esub> p =HIDDENR1 ((<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f)):-FINSEQ-5K2\<^bsub>(D)\<^esub> p"
      using finseq_5_def_2 sorry
    also have "... = (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f)"
      using A1 finseq_6_th_44 sorry
    also have "... = f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p"
      using finseq_5_def_2 sorry
    finally show "(f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p):-FINSEQ-5K2\<^bsub>(D)\<^esub> p =HIDDENR1 f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_69:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p1 inTARSKIR2 rngFUNCT-1K2 f & p2 inTARSKIR2 rngFUNCT-1K2 f \\SUBSET-1K6 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1) implies f  |--FINSEQ-4K6 p2 =FINSEQ-1R1 (f  |--FINSEQ-4K6 p1) |--FINSEQ-4K6 p2"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p1 inTARSKIR2 rngFUNCT-1K2 f & p2 inTARSKIR2 rngFUNCT-1K2 f \\SUBSET-1K6 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1) implies f  |--FINSEQ-4K6 p2 =HIDDENR1 (f  |--FINSEQ-4K6 p1) |--FINSEQ-4K6 p2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p1 assume [ty]: "p1 be ElementSUBSET-1M1-of D"
    fix p2 assume [ty]: "p2 be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p1 inTARSKIR2 rngFUNCT-1K2 f"
      and A2: "p2 inTARSKIR2 rngFUNCT-1K2 f \\SUBSET-1K6 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)"
    have " not p2 inTARSKIR2 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)"
      using A2 xboole_0_def_5 sorry
    then have A3: " not p2 inTARSKIR2 rngFUNCT-1K2 ((f -|FINSEQ-4K5 p1)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>))"
      using A1 finseq_6_th_40 sorry
    have "f =FINSEQ-1R1 ((f -|FINSEQ-4K5 p1)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>))^FINSEQ-1K8 (f  |--FINSEQ-4K6 p1)"
      using A1 finseq_4_th_51 sorry
    then have "rngFUNCT-1K2 f =XBOOLE-0R4 rngFUNCT-1K2 ((f -|FINSEQ-4K5 p1)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)) \\/XBOOLE-0K2 rngFUNCT-1K2 (f  |--FINSEQ-4K6 p1)"
      using finseq_1_th_31 sorry
    then have "p2 inTARSKIR2 rngFUNCT-1K2 (f  |--FINSEQ-4K6 p1)"
      using A2 A3 xboole_0_def_3 sorry
    then have A4: "p2 inTARSKIR2 rngFUNCT-1K2 (f  |--FINSEQ-4K6 p1) \\SUBSET-1K6 rngFUNCT-1K2 ((f -|FINSEQ-4K5 p1)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>))"
      using A3 xboole_0_def_5 sorry
    have "f  |--FINSEQ-4K6 p2 =HIDDENR1 ((f -|FINSEQ-4K5 p1)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>))^FINSEQ-1K8 (f  |--FINSEQ-4K6 p1)  |--FINSEQ-4K6 p2"
      using A1 finseq_4_th_51 sorry
    also have "... = (f  |--FINSEQ-4K6 p1) |--FINSEQ-4K6 p2"
      using A4 finseq_6_th_9 sorry
    finally show "f  |--FINSEQ-4K6 p2 =HIDDENR1 (f  |--FINSEQ-4K6 p1) |--FINSEQ-4K6 p2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_70:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies rngFUNCT-1K2 f =XBOOLE-0R4 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) \\/XBOOLE-0K2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies rngFUNCT-1K2 f =HIDDENR1 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) \\/XBOOLE-0K2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f"
    then have "f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p =FINSEQ-1R1 (f -|FINSEQ-4K5 p)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)"
      using finseq_6_th_40 sorry
    then have A2: "rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 rngFUNCT-1K2 (f -|FINSEQ-4K5 p) \\/XBOOLE-0K2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)"
      using finseq_1_th_31 sorry
    have "f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K8 (f  |--FINSEQ-4K6 p)"
      using A1 finseq_6_th_41 sorry
    then have A3: "rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>) \\/XBOOLE-0K2 rngFUNCT-1K2 (f  |--FINSEQ-4K6 p)"
      using finseq_1_th_31 sorry
    have "f =FINSEQ-1R1 ((f -|FINSEQ-4K5 p)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>))^FINSEQ-1K8 (f  |--FINSEQ-4K6 p)"
      using A1 finseq_4_th_51 sorry
    then have "rngFUNCT-1K2 f =HIDDENR1 rngFUNCT-1K2 ((f -|FINSEQ-4K5 p)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)) \\/XBOOLE-0K2 rngFUNCT-1K2 (f  |--FINSEQ-4K6 p)"
      using finseq_1_th_31 sorry
    also have "... = (rngFUNCT-1K2 (f -|FINSEQ-4K5 p) \\/XBOOLE-0K2 (rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>) \\/XBOOLE-0K2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)))\\/XBOOLE-0K2 rngFUNCT-1K2 (f  |--FINSEQ-4K6 p)"
      using finseq_1_th_31 sorry
    also have "... = ((rngFUNCT-1K2 (f -|FINSEQ-4K5 p) \\/XBOOLE-0K2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>))\\/XBOOLE-0K2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>))\\/XBOOLE-0K2 rngFUNCT-1K2 (f  |--FINSEQ-4K6 p)"
      using xboole_1_th_4 sorry
    also have "... = rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) \\/XBOOLE-0K2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
      using A2 A3 xboole_1_th_4 sorry
    finally show "rngFUNCT-1K2 f =HIDDENR1 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) \\/XBOOLE-0K2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_71:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p1 inTARSKIR2 rngFUNCT-1K2 f & p2 inTARSKIR2 rngFUNCT-1K2 f \\SUBSET-1K6 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1) implies (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1):-FINSEQ-5K2\<^bsub>(D)\<^esub> p2 =FINSEQ-1R1 f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p2"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p1 inTARSKIR2 rngFUNCT-1K2 f & p2 inTARSKIR2 rngFUNCT-1K2 f \\SUBSET-1K6 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1) implies (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1):-FINSEQ-5K2\<^bsub>(D)\<^esub> p2 =HIDDENR1 f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p1 assume [ty]: "p1 be ElementSUBSET-1M1-of D"
    fix p2 assume [ty]: "p2 be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p1 inTARSKIR2 rngFUNCT-1K2 f"
      and A2: "p2 inTARSKIR2 rngFUNCT-1K2 f \\SUBSET-1K6 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)"
    have A3: " not p2 inTARSKIR2 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)"
      using A2 xboole_0_def_5 sorry
    have "f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1 =FINSEQ-1R1 (f -|FINSEQ-4K5 p1)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)"
      using A1 finseq_6_th_40 sorry
    then have "rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1) =XBOOLE-0R4 rngFUNCT-1K2 (f -|FINSEQ-4K5 p1) \\/XBOOLE-0K2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)"
      using finseq_1_th_31 sorry
    then have A4: " not p2 inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)"
      using A3 xboole_0_def_3 sorry
    have "rngFUNCT-1K2 f =XBOOLE-0R4 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1) \\/XBOOLE-0K2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)"
      using A1 finseq_6_th_70 sorry
    then have A5: "p2 inTARSKIR2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)"
      using A2 A3 xboole_0_def_3 sorry
    have "f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1 =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)^FINSEQ-1K8 (f  |--FINSEQ-4K6 p1)"
      using A1 finseq_6_th_41 sorry
    then have "rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1) =XBOOLE-0R4 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>) \\/XBOOLE-0K2 rngFUNCT-1K2 (f  |--FINSEQ-4K6 p1)"
      using finseq_1_th_31 sorry
    then have "p2 inTARSKIR2 rngFUNCT-1K2 (f  |--FINSEQ-4K6 p1)"
      using A5 A4 xboole_0_def_3 sorry
    then have A6: "p2 inTARSKIR2 rngFUNCT-1K2 (f  |--FINSEQ-4K6 p1) \\SUBSET-1K6 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)"
      using A4 xboole_0_def_5 sorry
    have "(f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1):-FINSEQ-5K2\<^bsub>(D)\<^esub> p2 =HIDDENR1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p2*>)^FINSEQ-1K8 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1  |--FINSEQ-4K6 p2)"
      using A5 finseq_6_th_41 sorry
    also have "... = (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p2*>)^FINSEQ-1K8 ((<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)^FINSEQ-1K8 (f  |--FINSEQ-4K6 p1)  |--FINSEQ-4K6 p2)"
      using A1 finseq_6_th_41 sorry
    also have "... = (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p2*>)^FINSEQ-1K8 ((f  |--FINSEQ-4K6 p1) |--FINSEQ-4K6 p2)"
      using A6 finseq_6_th_9 sorry
    also have "... = (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p2*>)^FINSEQ-1K8 (f  |--FINSEQ-4K6 p2)"
      using A1 A2 finseq_6_th_69 sorry
    also have "... = f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p2"
      using A2 finseq_6_th_41 sorry
    finally show "(f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1):-FINSEQ-5K2\<^bsub>(D)\<^esub> p2 =HIDDENR1 f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_72:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies p ..FINSEQ-4K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 p ..FINSEQ-4K4 f"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies p ..FINSEQ-4K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 p ..FINSEQ-4K4 f"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f"
    then have A2: "p ..FINSEQ-4K4 f <=XXREAL-0R1 lenFINSEQ-1K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)"
      using finseq_5_th_42 sorry
    have A3: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 p ..FINSEQ-4K4 f implies (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> i <>HIDDENR2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 f)"
    proof(rule ballI,rule impMI ,rule impI)
      have "p ..FINSEQ-4K4 f <>HIDDENR2 0NUMBERSK6"
        using A1 finseq_4_th_21 sorry
      then have "p ..FINSEQ-4K4 f inTARSKIR2 SegFINSEQ-1K2 (p ..FINSEQ-4K4 f)"
        using finseq_1_th_3 sorry
      then have A4: "(f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 f) =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 f)"
        using A1 finseq_5_th_43 sorry
      fix i assume [ty]: "i be NatNAT-1M1"
      assume A5: "\<one>\<^sub>M <=XXREAL-0R1 i"
        and A6: "i <XXREAL-0R3 p ..FINSEQ-4K4 f"
      have "i inTARSKIR2 SegFINSEQ-1K2 (p ..FINSEQ-4K4 f)"
        using A5 A6 sorry
      then have A7: "(f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> i"
        using A1 finseq_5_th_43 sorry
      have "p ..FINSEQ-4K4 f <=XXREAL-0R1 lenFINSEQ-1K4 f"
        using A1 finseq_4_th_21 sorry
      then have "i <=XXREAL-0R1 lenFINSEQ-1K4 f"
        using A6 xxreal_0_th_2 sorry
      then have A8: "i inTARSKIR2 domFINSEQ-1K5 f"
        using A5 finseq_3_th_25 sorry
      have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 f) =XBOOLE-0R4 p"
        using A1 finseq_5_th_38 sorry
      thus "(f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> i <>HIDDENR2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 f)"
        using A6 A7 A4 A8 finseq_5_th_39 sorry
    qed "sorry"
    have "\<one>\<^sub>M <=XXREAL-0R1 p ..FINSEQ-4K4 f"
      using A1 finseq_4_th_21 sorry
    then have A9: "p ..FINSEQ-4K4 f inTARSKIR2 domFINSEQ-1K5 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)"
      using A2 finseq_3_th_25 sorry
    have "(f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 f) =XBOOLE-0R4 p"
      using A1 finseq_5_th_45 sorry
    thus "p ..FINSEQ-4K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 p ..FINSEQ-4K4 f"
      using A9 A3 finseq_6_th_48 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_73:
" for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i) |FINSEQ-1K18\<^bsub>(D)\<^esub> i =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i"
   sorry

mtheorem finseq_6_th_74:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p =FINSEQ-1R1 f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p =HIDDENR1 f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume "p inTARSKIR2 rngFUNCT-1K2 f"
    then have A1: "p ..FINSEQ-4K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 p ..FINSEQ-4K4 f"
      using finseq_6_th_72 sorry
    have "(f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p =HIDDENR1 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) |FINSEQ-1K18\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p))"
      using finseq_5_def_1 sorry
    also have "... = (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 f)) |FINSEQ-1K18\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 f)"
      using A1 finseq_5_def_1 sorry
    also have "... = f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p"
      using finseq_5_def_1 sorry
    finally show "(f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p =HIDDENR1 f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_75:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p1 inTARSKIR2 rngFUNCT-1K2 f & p2 inTARSKIR2 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1) implies (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2 =FINSEQ-1R1 f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p2"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p1 inTARSKIR2 rngFUNCT-1K2 f & p2 inTARSKIR2 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1) implies (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2 =FINSEQ-1R1 f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p1 assume [ty]: "p1 be ElementSUBSET-1M1-of D"
    fix p2 assume [ty]: "p2 be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p1 inTARSKIR2 rngFUNCT-1K2 f"
      and A2: "p2 inTARSKIR2 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)"
    show "(f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2 =FINSEQ-1R1 f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p2"
    proof-
      have cases: "p1 =XBOOLE-0R4 p2 or p1 <>HIDDENR2 p2"
         sorry
      have case1: "p1 =XBOOLE-0R4 p2 implies (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2 =FINSEQ-1R1 f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p2"
      proof(rule impI)
        assume "p1 =XBOOLE-0R4 p2"
        thus "(f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2 =FINSEQ-1R1 f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p2"
          using A1 finseq_6_th_74 sorry
      qed
      have case2: "p1 <>HIDDENR2 p2 implies (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2 =HIDDENR1 f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p2"
      proof(rule impI)
        assume "p1 <>HIDDENR2 p2"
        then have " not p2 inTARSKIR2 {TARSKIK1 p1}"
          using tarski_def_1 sorry
        then have A3: " not p2 inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)"
          using finseq_1_th_39 sorry
        have "f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1 =FINSEQ-1R1 (f -|FINSEQ-4K5 p1)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)"
          using A1 finseq_6_th_40 sorry
        then have "rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1) =XBOOLE-0R4 rngFUNCT-1K2 (f -|FINSEQ-4K5 p1) \\/XBOOLE-0K2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)"
          using finseq_1_th_31 sorry
        then have A4: "p2 inTARSKIR2 rngFUNCT-1K2 (f -|FINSEQ-4K5 p1)"
          using A2 A3 xboole_0_def_3 sorry
        have A5: "rngFUNCT-1K2 (f -|FINSEQ-4K5 p1) c=TARSKIR1 rngFUNCT-1K2 f"
          using A1 finseq_4_th_39 sorry
        have "(f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2 =HIDDENR1 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1 -|FINSEQ-4K5 p2)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p2*>)"
          using A2 finseq_6_th_40 sorry
        also have "... = ((f -|FINSEQ-4K5 p1)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>) -|FINSEQ-4K5 p2)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p2*>)"
          using A1 finseq_6_th_40 sorry
        also have "... = ((f -|FINSEQ-4K5 p1)-|FINSEQ-4K5 p2)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p2*>)"
          using A4 finseq_6_th_12 sorry
        also have "... = (f -|FINSEQ-4K5 p2)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p2*>)"
          using A1 A4 finseq_6_th_35 sorry
        also have "... = f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p2"
          using A4 A5 finseq_6_th_40 sorry
        finally show "(f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2 =HIDDENR1 f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p2"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_76:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) =FINSEQ-1R1 f"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) =HIDDENR1 f"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    have A1: "rngFUNCT-1K2 f c=TARSKIR1 D"
      using finseq_1_def_4 sorry
    assume A2: "p inTARSKIR2 rngFUNCT-1K2 f"
    then have "rngFUNCT-1K2 (f  |--FINSEQ-4K6 p) c=TARSKIR1 rngFUNCT-1K2 f"
      using finseq_4_th_44 sorry
    then have "rngFUNCT-1K2 (f  |--FINSEQ-4K6 p) c=TARSKIR1 D"
      using A1 sorry
    then obtain f1 where 
      [ty]:"f1 be FinSequenceFINSEQ-1M3-of D" and f1Def:"f1 = f  |--FINSEQ-4K6 p"
      using finseq_1_def_4 sorry
    have "(f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) =HIDDENR1 ((f -|FINSEQ-4K5 p)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>))^FINSEQ-1K8 ((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
      using A2 finseq_6_th_40 sorry
    also have "... = ((f -|FINSEQ-4K5 p)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>))^FINSEQ-1K8 (((<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> f1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
      using A2 finseq_6_th_41 sorry
    also have "... = ((f -|FINSEQ-4K5 p)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>))^FINSEQ-1K8 (f  |--FINSEQ-4K6 p)"
      using finseq_6_th_45 sorry
    also have "... = f"
      using A2 finseq_4_th_51 sorry
    finally show "(f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) =HIDDENR1 f"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_77:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be FinSequenceFINSEQ-1M3-of D holds  for f2 be FinSequenceFINSEQ-1M3-of D holds f1 <>HIDDENR2 {}XBOOLE-0K1 implies (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M =FINSEQ-1R1 (f1 /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)^FINSEQ-1K9\<^bsub>(D)\<^esub> f2"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be FinSequenceFINSEQ-1M3-of D holds  for f2 be FinSequenceFINSEQ-1M3-of D holds f1 <>HIDDENR2 {}XBOOLE-0K1 implies (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M =HIDDENR1 (f1 /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)^FINSEQ-1K9\<^bsub>(D)\<^esub> f2"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be FinSequenceFINSEQ-1M3-of D"
    fix f2 assume [ty]: "f2 be FinSequenceFINSEQ-1M3-of D"
    assume "f1 <>HIDDENR2 {}XBOOLE-0K1"
    then obtain p df1 where
      [ty]:"p be ElementSUBSET-1M1-of D" "df1 be FinSequenceFINSEQ-1M3-of D" and 
      "p =XBOOLE-0R4 f1 .FUNCT-1K1 \<one>\<^sub>M"and A1: "f1 =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> df1"
      using finseq_3_th_102 sorry
    have "(f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M =HIDDENR1 ((<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (df1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2))/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M"
      using A1 finseq_1_th_32 sorry
    also have "... = df1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2"
      using finseq_6_th_45 sorry
    also have "... = (f1 /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)^FINSEQ-1K9\<^bsub>(D)\<^esub> f2"
      using A1 finseq_6_th_45 sorry
    finally show "(f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M =HIDDENR1 (f1 /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)^FINSEQ-1K9\<^bsub>(D)\<^esub> f2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_78:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p2 be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p2 inTARSKIR2 rngFUNCT-1K2 f & p2 ..FINSEQ-4K4 f <>HIDDENR2 \<one>\<^sub>M implies p2 inTARSKIR2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p2 be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p2 inTARSKIR2 rngFUNCT-1K2 f & p2 ..FINSEQ-4K4 f <>HIDDENR2 \<one>\<^sub>M implies ( not p2 inTARSKIR2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) implies  False )"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p2 assume [ty]: "p2 be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p2 inTARSKIR2 rngFUNCT-1K2 f"
      and A2: "p2 ..FINSEQ-4K4 f <>HIDDENR2 \<one>\<^sub>M"
    have "f =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
      using A1 finseq_5_th_29 relat_1_th_38 sorry
    then have A3: "rngFUNCT-1K2 f =XBOOLE-0R4 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M*>) \\/XBOOLE-0K2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
      using finseq_1_th_31 sorry
    assume " not p2 inTARSKIR2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
    then have "p2 inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M*>)"
      using A1 A3 xboole_0_def_3 sorry
    then have "p2 inTARSKIR2 {TARSKIK1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M }"
      using finseq_1_th_39 sorry
    then have "p2 =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
      using tarski_def_1 sorry
    thus " False "
      using A1 A2 finseq_6_th_43 relat_1_th_38 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_79:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p ..FINSEQ-4K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p ..FINSEQ-4K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    have "(f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 p"
      using finseq_5_th_53 sorry
    thus "p ..FINSEQ-4K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 \<one>\<^sub>M"
      using finseq_6_th_43 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma finseq_6_lm_3:
" for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & p ..FINSEQ-4K4 f >XXREAL-0R4 i implies i +NAT-1K1 p ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i) =XBOOLE-0R4 p ..FINSEQ-4K4 f"
proof-
  have " for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & p ..FINSEQ-4K4 f >XXREAL-0R4 i implies i +NAT-1K1 p ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i) =XBOOLE-0R4 p ..FINSEQ-4K4 f"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f"
      and A2: "p ..FINSEQ-4K4 f >XXREAL-0R4 i"
    obtain k where 
      [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = p ..FINSEQ-4K4 f -XCMPLX-0K6 i"
      using A2 int_1_th_5 sorry
    have A3: "p ..FINSEQ-4K4 f <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A1 finseq_4_th_21 sorry
    then have A4: "i <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A2 xxreal_0_th_2 sorry
    have "p ..FINSEQ-4K4 f -XCMPLX-0K6 i <=XXREAL-0R1 lenFINSEQ-1K4 f -XCMPLX-0K6 i"
      using A3 xreal_1_th_9 sorry
    then have A5: "k <=XXREAL-0R1 lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i)"
      using A4 rfinseq_def_1 sorry
    have "k <>HIDDENR2 0NUMBERSK6"
      using A2 sorry
    then have "\<one>\<^sub>M <=XXREAL-0R1 k"
      using nat_1_th_14 sorry
    then have A6: "k inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i)"
      using A5 finseq_3_th_25 sorry
    have A7: " for j be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 j & j <XXREAL-0R3 k implies (f /^RFINSEQK2\<^bsub>(D)\<^esub> i).FUNCT-1K1 j <>HIDDENR2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i).FUNCT-1K1 k"
    proof(rule ballI,rule impMI ,rule impI)
      fix j assume [ty]: "j be NatNAT-1M1"
      assume A8: "\<one>\<^sub>M <=XXREAL-0R1 j"
        and A9: "j <XXREAL-0R3 k"
      have "j <=XXREAL-0R1 i +XCMPLX-0K2 j"
        using nat_1_th_11 sorry
      then have A10: "\<one>\<^sub>M <=XXREAL-0R1 i +XCMPLX-0K2 j"
        using A8 xxreal_0_th_2 sorry
      have "i +NAT-1K1 k =XBOOLE-0R4 p ..FINSEQ-4K4 f"
         sorry
      then have A11: "i +XCMPLX-0K2 j <XXREAL-0R3 p ..FINSEQ-4K4 f"
        using A9 xreal_1_th_6 sorry
      then have "i +XCMPLX-0K2 j <=XXREAL-0R1 lenFINSEQ-1K4 f"
        using A3 xxreal_0_th_2 sorry
      then have A12: "i +XCMPLX-0K2 j inTARSKIR2 domFINSEQ-1K5 f"
        using A10 finseq_3_th_25 sorry
      have "j <=XXREAL-0R1 lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i)"
        using A5 A9 xxreal_0_th_2 sorry
      then have "j inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i)"
        using A8 finseq_3_th_25 sorry
      then have A13: "f .FUNCT-1K1 (i +XCMPLX-0K2 j) =XBOOLE-0R4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i).FUNCT-1K1 j"
        using A4 rfinseq_def_1 sorry
      have "f .FUNCT-1K1 (i +NAT-1K1 k) =XBOOLE-0R4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i).FUNCT-1K1 k"
        using A4 A6 rfinseq_def_1 sorry
      thus "(f /^RFINSEQK2\<^bsub>(D)\<^esub> i).FUNCT-1K1 j <>HIDDENR2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i).FUNCT-1K1 k"
        using A1 A13 A11 A12 finseq_4_th_19 finseq_4_th_24 sorry
    qed "sorry"
    have "(f /^RFINSEQK2\<^bsub>(D)\<^esub> i).FUNCT-1K1 k =HIDDENR1 f .FUNCT-1K1 (k +XCMPLX-0K2 i)"
      using A4 A6 rfinseq_def_1 sorry
    also have "... = p"
      using A1 finseq_4_th_19 sorry
    finally have "(f /^RFINSEQK2\<^bsub>(D)\<^esub> i).FUNCT-1K1 k =HIDDENR1 p"
       sorry
    then have "p ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i) =XBOOLE-0R4 k"
      using A6 A7 finseq_6_th_2 sorry
    thus "i +NAT-1K1 p ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i) =XBOOLE-0R4 p ..FINSEQ-4K4 f"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_80:
" for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds <*>FINSEQ-1K7 D /^RFINSEQK2\<^bsub>(D)\<^esub> k =FINSEQ-1R1 <*>FINSEQ-1K7 D"
proof-
  have " for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds <*>FINSEQ-1K7 D /^RFINSEQK2\<^bsub>(D)\<^esub> k =FINSEQ-1R1 <*>FINSEQ-1K7 D"
  proof(rule ballI,rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    show "<*>FINSEQ-1K7 D /^RFINSEQK2\<^bsub>(D)\<^esub> k =FINSEQ-1R1 <*>FINSEQ-1K7 D"
    proof-
      have cases: "k =XBOOLE-0R4 0NUMBERSK6 or k >XXREAL-0R4 0NUMBERSK6"
         sorry
      have case1: "k =XBOOLE-0R4 0NUMBERSK6 implies <*>FINSEQ-1K7 D /^RFINSEQK2\<^bsub>(D)\<^esub> k =FINSEQ-1R1 <*>FINSEQ-1K7 D"
      proof(rule impI)
        assume "k =XBOOLE-0R4 0NUMBERSK6"
        thus "<*>FINSEQ-1K7 D /^RFINSEQK2\<^bsub>(D)\<^esub> k =FINSEQ-1R1 <*>FINSEQ-1K7 D"
          using finseq_5_th_28 sorry
      qed
      have case2: "k >XXREAL-0R4 0NUMBERSK6 implies <*>FINSEQ-1K7 D /^RFINSEQK2\<^bsub>(D)\<^esub> k =FINSEQ-1R1 <*>FINSEQ-1K7 D"
      proof(rule impI)
        assume "k >XXREAL-0R4 0NUMBERSK6"
        then have "k >XXREAL-0R4 lenFINSEQ-1K4 <*>FINSEQ-1K7 D"
           sorry
        thus "<*>FINSEQ-1K7 D /^RFINSEQK2\<^bsub>(D)\<^esub> k =FINSEQ-1R1 <*>FINSEQ-1K7 D"
          using rfinseq_def_1 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_81:
" for i be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds f /^RFINSEQK2\<^bsub>(D)\<^esub> (i +XCMPLX-0K2 k) =FINSEQ-1R1 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i)/^RFINSEQK2\<^bsub>(D)\<^esub> k"
proof-
  have " for i be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds f /^RFINSEQK2\<^bsub>(D)\<^esub> (i +XCMPLX-0K2 k) =FINSEQ-1R1 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i)/^RFINSEQK2\<^bsub>(D)\<^esub> k"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    show "f /^RFINSEQK2\<^bsub>(D)\<^esub> (i +XCMPLX-0K2 k) =FINSEQ-1R1 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i)/^RFINSEQK2\<^bsub>(D)\<^esub> k"
    proof-
      have cases: "(i +XCMPLX-0K2 k <=XXREAL-0R1 lenFINSEQ-1K4 f or i +XCMPLX-0K2 k >XXREAL-0R4 lenFINSEQ-1K4 f & i <=XXREAL-0R1 lenFINSEQ-1K4 f) or i +XCMPLX-0K2 k >XXREAL-0R4 lenFINSEQ-1K4 f & i >XXREAL-0R4 lenFINSEQ-1K4 f"
         sorry
      have case1: "i +XCMPLX-0K2 k <=XXREAL-0R1 lenFINSEQ-1K4 f implies f /^RFINSEQK2\<^bsub>(D)\<^esub> (i +XCMPLX-0K2 k) =FINSEQ-1R1 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i)/^RFINSEQK2\<^bsub>(D)\<^esub> k"
      proof(rule impI)
        assume A1: "i +XCMPLX-0K2 k <=XXREAL-0R1 lenFINSEQ-1K4 f"
        have "i <=XXREAL-0R1 i +XCMPLX-0K2 k"
          using nat_1_th_11 sorry
        then have A2: "i <=XXREAL-0R1 lenFINSEQ-1K4 f"
          using A1 xxreal_0_th_2 sorry
        then have A3: "lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i) =XBOOLE-0R4 lenFINSEQ-1K4 f -XCMPLX-0K6 i"
          using rfinseq_def_1 sorry
        then have A4: "k <=XXREAL-0R1 lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i)"
          using A1 xreal_1_th_19 sorry
        have A5: " for m be NatNAT-1M1 holds m inTARSKIR2 domFINSEQ-1K5 ((f /^RFINSEQK2\<^bsub>(D)\<^esub> i)/^RFINSEQK2\<^bsub>(D)\<^esub> k) implies ((f /^RFINSEQK2\<^bsub>(D)\<^esub> i)/^RFINSEQK2\<^bsub>(D)\<^esub> k).FUNCT-1K1 m =HIDDENR1 f .FUNCT-1K1 (m +XCMPLX-0K2 (i +XCMPLX-0K2 k))"
        proof(rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          assume A6: "m inTARSKIR2 domFINSEQ-1K5 ((f /^RFINSEQK2\<^bsub>(D)\<^esub> i)/^RFINSEQK2\<^bsub>(D)\<^esub> k)"
          then have A7: "m +XCMPLX-0K2 k inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i)"
            using finseq_5_th_26 sorry
          have "((f /^RFINSEQK2\<^bsub>(D)\<^esub> i)/^RFINSEQK2\<^bsub>(D)\<^esub> k).FUNCT-1K1 m =HIDDENR1 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i).FUNCT-1K1 (m +XCMPLX-0K2 k)"
            using A4 A6 rfinseq_def_1 sorry
          also have "... = f .FUNCT-1K1 ((m +XCMPLX-0K2 k)+XCMPLX-0K2 i)"
            using A2 A7 rfinseq_def_1 sorry
          also have "... = f .FUNCT-1K1 (m +XCMPLX-0K2 (i +XCMPLX-0K2 k))"
             sorry
          finally show "((f /^RFINSEQK2\<^bsub>(D)\<^esub> i)/^RFINSEQK2\<^bsub>(D)\<^esub> k).FUNCT-1K1 m =HIDDENR1 f .FUNCT-1K1 (m +XCMPLX-0K2 (i +XCMPLX-0K2 k))"
             sorry
        qed "sorry"
        have "lenFINSEQ-1K4 ((f /^RFINSEQK2\<^bsub>(D)\<^esub> i)/^RFINSEQK2\<^bsub>(D)\<^esub> k) =HIDDENR1 lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i) -XCMPLX-0K6 k"
          using A4 rfinseq_def_1 sorry
        also have "... = lenFINSEQ-1K4 f -XCMPLX-0K6 (i +XCMPLX-0K2 k)"
          using A3 sorry
        finally have "lenFINSEQ-1K4 ((f /^RFINSEQK2\<^bsub>(D)\<^esub> i)/^RFINSEQK2\<^bsub>(D)\<^esub> k) =HIDDENR1 lenFINSEQ-1K4 f -XCMPLX-0K6 (i +XCMPLX-0K2 k)"
           sorry
        thus "f /^RFINSEQK2\<^bsub>(D)\<^esub> (i +XCMPLX-0K2 k) =FINSEQ-1R1 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i)/^RFINSEQK2\<^bsub>(D)\<^esub> k"
          using A1 A5 rfinseq_def_1 sorry
      qed
      have case2: "i +XCMPLX-0K2 k >XXREAL-0R4 lenFINSEQ-1K4 f & i <=XXREAL-0R1 lenFINSEQ-1K4 f implies f /^RFINSEQK2\<^bsub>(D)\<^esub> (i +XCMPLX-0K2 k) =HIDDENR1 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i)/^RFINSEQK2\<^bsub>(D)\<^esub> k"
      proof(rule impMI ,rule impI)
        assume A8: "i +XCMPLX-0K2 k >XXREAL-0R4 lenFINSEQ-1K4 f"
          and A9: "i <=XXREAL-0R1 lenFINSEQ-1K4 f"
        have "lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i) =XBOOLE-0R4 lenFINSEQ-1K4 f -XCMPLX-0K6 i"
          using A9 rfinseq_def_1 sorry
        then have "lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i) +XCMPLX-0K2 i =XBOOLE-0R4 lenFINSEQ-1K4 f"
           sorry
        then have A10: "k >XXREAL-0R4 lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i)"
          using A8 xreal_1_th_6 sorry
        have "f /^RFINSEQK2\<^bsub>(D)\<^esub> (i +XCMPLX-0K2 k) =HIDDENR1 <*>FINSEQ-1K7 D"
          using A8 rfinseq_def_1 sorry
        also have "... = (f /^RFINSEQK2\<^bsub>(D)\<^esub> i)/^RFINSEQK2\<^bsub>(D)\<^esub> k"
          using A10 rfinseq_def_1 sorry
        finally show "f /^RFINSEQK2\<^bsub>(D)\<^esub> (i +XCMPLX-0K2 k) =HIDDENR1 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i)/^RFINSEQK2\<^bsub>(D)\<^esub> k"
           sorry
      qed
      have case3: "i +XCMPLX-0K2 k >XXREAL-0R4 lenFINSEQ-1K4 f & i >XXREAL-0R4 lenFINSEQ-1K4 f implies f /^RFINSEQK2\<^bsub>(D)\<^esub> (i +XCMPLX-0K2 k) =HIDDENR1 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i)/^RFINSEQK2\<^bsub>(D)\<^esub> k"
      proof(rule impMI ,rule impI)
        assume A11: "i +XCMPLX-0K2 k >XXREAL-0R4 lenFINSEQ-1K4 f"
          and A12: "i >XXREAL-0R4 lenFINSEQ-1K4 f"
        have "f /^RFINSEQK2\<^bsub>(D)\<^esub> (i +XCMPLX-0K2 k) =HIDDENR1 <*>FINSEQ-1K7 D"
          using A11 rfinseq_def_1 sorry
        also have "... = <*>FINSEQ-1K7 D /^RFINSEQK2\<^bsub>(D)\<^esub> k"
          using finseq_6_th_80 sorry
        also have "... = (f /^RFINSEQK2\<^bsub>(D)\<^esub> i)/^RFINSEQK2\<^bsub>(D)\<^esub> k"
          using A12 rfinseq_def_1 sorry
        finally show "f /^RFINSEQK2\<^bsub>(D)\<^esub> (i +XCMPLX-0K2 k) =HIDDENR1 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i)/^RFINSEQK2\<^bsub>(D)\<^esub> k"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_82:
" for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & p ..FINSEQ-4K4 f >XXREAL-0R4 k implies (f /^RFINSEQK2\<^bsub>(D)\<^esub> k):-FINSEQ-5K2\<^bsub>(D)\<^esub> p =FINSEQ-1R1 f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p"
proof-
  have " for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & p ..FINSEQ-4K4 f >XXREAL-0R4 k implies (f /^RFINSEQK2\<^bsub>(D)\<^esub> k):-FINSEQ-5K2\<^bsub>(D)\<^esub> p =HIDDENR1 f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f"
      and A2: "p ..FINSEQ-4K4 f >XXREAL-0R4 k"
    have "(f /^RFINSEQK2\<^bsub>(D)\<^esub> k):-FINSEQ-5K2\<^bsub>(D)\<^esub> p =HIDDENR1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f /^RFINSEQK2\<^bsub>(D)\<^esub> k)/^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k))"
      using finseq_5_def_2 sorry
    also have "... = (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> (k +NAT-1K1 p ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)))"
      using finseq_6_th_81 sorry
    also have "... = (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f)"
      using A1 A2 finseq_6_lm_3 sorry
    also have "... = f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p"
      using finseq_5_def_2 sorry
    finally show "(f /^RFINSEQK2\<^bsub>(D)\<^esub> k):-FINSEQ-5K2\<^bsub>(D)\<^esub> p =HIDDENR1 f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_83:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & p ..FINSEQ-4K4 f <>HIDDENR2 \<one>\<^sub>M implies (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M):-FINSEQ-5K2\<^bsub>(D)\<^esub> p =FINSEQ-1R1 f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & p ..FINSEQ-4K4 f <>HIDDENR2 \<one>\<^sub>M implies (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M):-FINSEQ-5K2\<^bsub>(D)\<^esub> p =FINSEQ-1R1 f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f"
      and A2: "p ..FINSEQ-4K4 f <>HIDDENR2 \<one>\<^sub>M"
    have "p ..FINSEQ-4K4 f >=XXREAL-0R2 \<one>\<^sub>M"
      using A1 finseq_4_th_21 sorry
    then have "p ..FINSEQ-4K4 f >XXREAL-0R4 \<one>\<^sub>M"
      using A2 xxreal_0_th_1 sorry
    thus "(f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M):-FINSEQ-5K2\<^bsub>(D)\<^esub> p =FINSEQ-1R1 f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p"
      using A1 finseq_6_th_82 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_84:
" for i be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds i +XCMPLX-0K2 k =XBOOLE-0R4 lenFINSEQ-1K4 f implies RevFINSEQ-5K4\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> k) =FINSEQ-1R1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i"
proof-
  have " for i be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds i +XCMPLX-0K2 k =XBOOLE-0R4 lenFINSEQ-1K4 f implies RevFINSEQ-5K4\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> k) =FINSEQ-1R1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "i +XCMPLX-0K2 k =XBOOLE-0R4 lenFINSEQ-1K4 f"
    then have A2: "k <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using nat_1_th_11 sorry
    have "i <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A1 nat_1_th_11 sorry
    then have "i <=XXREAL-0R1 lenFINSEQ-1K4 (RevFINSEQ-5K4\<^bsub>(D)\<^esub> f)"
      using finseq_5_def_3 sorry
    then have A3: "lenFINSEQ-1K4 (RevFINSEQ-5K4\<^bsub>(D)\<^esub> f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i) =HIDDENR1 lenFINSEQ-1K4 f -XCMPLX-0K6 k"
      using A1 finseq_1_th_59 sorry
    also have "... = lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)"
      using A2 rfinseq_def_1 sorry
    finally have "lenFINSEQ-1K4 (RevFINSEQ-5K4\<^bsub>(D)\<^esub> f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i) =HIDDENR1 lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)"
       sorry
    have " for j be NatNAT-1M1 holds j inTARSKIR2 domFINSEQ-1K5 (RevFINSEQ-5K4\<^bsub>(D)\<^esub> f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i) implies (RevFINSEQ-5K4\<^bsub>(D)\<^esub> f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i).FUNCT-1K1 j =HIDDENR1 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k).FUNCT-1K1 ((lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k) -XCMPLX-0K6 j)+XCMPLX-0K2 \<one>\<^sub>M)"
    proof(rule ballI,rule impI)
      have A4: "lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k) =XBOOLE-0R4 lenFINSEQ-1K4 f -XCMPLX-0K6 k"
        using A2 rfinseq_def_1 sorry
      fix j assume [ty]: "j be NatNAT-1M1"
      have A5: "domFINSEQ-1K5 (RevFINSEQ-5K4\<^bsub>(D)\<^esub> f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i) c=TARSKIR1 domFINSEQ-1K5 (RevFINSEQ-5K4\<^bsub>(D)\<^esub> f)"
        using finseq_5_th_18 sorry
      assume A6: "j inTARSKIR2 domFINSEQ-1K5 (RevFINSEQ-5K4\<^bsub>(D)\<^esub> f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i)"
      then have "j <=XXREAL-0R1 lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)"
        using A3 finseq_3_th_25 sorry
      then obtain m where 
        [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and mDef:"m = lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k) -XCMPLX-0K6 j"
        using int_1_th_5 sorry
      have "j >=XXREAL-0R2 \<one>\<^sub>M"
        using A6 finseq_3_th_25 sorry
      then have "lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k) -XCMPLX-0K6 j <=XXREAL-0R1 lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k) -XCMPLX-0K6 \<one>\<^sub>M"
        using xreal_1_th_10 sorry
      then have A7: "(lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k) -XCMPLX-0K6 j)+XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)"
        using xreal_1_th_19 sorry
      have "\<one>\<^sub>M <=XXREAL-0R1 m +NAT-1K1 \<one>\<^sub>M"
        using nat_1_th_11 sorry
      then have A8: "m +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)"
        using A7 finseq_3_th_25 sorry
      have "(RevFINSEQ-5K4\<^bsub>(D)\<^esub> f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i).FUNCT-1K1 j =HIDDENR1 (RevFINSEQ-5K4\<^bsub>(D)\<^esub> f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i)/.PARTFUN1K7\<^bsub>(D)\<^esub> j"
        using A6 partfun1_def_6 sorry
      also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> j"
        using A6 finseq_4_th_70 sorry
      also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> f .FUNCT-1K1 j"
        using A6 A5 partfun1_def_6 sorry
      also have "... = f .FUNCT-1K1 (((lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k) +XCMPLX-0K2 k)-XCMPLX-0K6 j)+XCMPLX-0K2 \<one>\<^sub>M)"
        using A6 A5 A4 finseq_5_def_3 sorry
      also have "... = f .FUNCT-1K1 ((m +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k)"
         sorry
      also have "... = (f /^RFINSEQK2\<^bsub>(D)\<^esub> k).FUNCT-1K1 ((lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k) -XCMPLX-0K6 j)+XCMPLX-0K2 \<one>\<^sub>M)"
        using A2 A8 rfinseq_def_1 sorry
      finally show "(RevFINSEQ-5K4\<^bsub>(D)\<^esub> f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i).FUNCT-1K1 j =HIDDENR1 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k).FUNCT-1K1 ((lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k) -XCMPLX-0K6 j)+XCMPLX-0K2 \<one>\<^sub>M)"
         sorry
    qed "sorry"
    thus "RevFINSEQ-5K4\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> k) =FINSEQ-1R1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i"
      using A3 finseq_5_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_85:
" for i be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds i +XCMPLX-0K2 k =XBOOLE-0R4 lenFINSEQ-1K4 f implies RevFINSEQ-5K4\<^bsub>(D)\<^esub> (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> k) =FINSEQ-1R1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f /^RFINSEQK2\<^bsub>(D)\<^esub> i"
proof-
  have " for i be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds i +XCMPLX-0K2 k =XBOOLE-0R4 lenFINSEQ-1K4 f implies RevFINSEQ-5K4\<^bsub>(D)\<^esub> (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> k) =HIDDENR1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f /^RFINSEQK2\<^bsub>(D)\<^esub> i"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume "i +XCMPLX-0K2 k =XBOOLE-0R4 lenFINSEQ-1K4 f"
    then have A1: "i +XCMPLX-0K2 k =XBOOLE-0R4 lenFINSEQ-1K4 (RevFINSEQ-5K4\<^bsub>(D)\<^esub> f)"
      using finseq_5_def_3 sorry
    have "RevFINSEQ-5K4\<^bsub>(D)\<^esub> (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> k) =HIDDENR1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> (RevFINSEQ-5K4\<^bsub>(D)\<^esub> (RevFINSEQ-5K4\<^bsub>(D)\<^esub> f)  |FINSEQ-1K18\<^bsub>(D)\<^esub> k)"
       sorry
    also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> (RevFINSEQ-5K4\<^bsub>(D)\<^esub> (RevFINSEQ-5K4\<^bsub>(D)\<^esub> f /^RFINSEQK2\<^bsub>(D)\<^esub> i))"
      using A1 finseq_6_th_84 sorry
    also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> f /^RFINSEQK2\<^bsub>(D)\<^esub> i"
       sorry
    finally show "RevFINSEQ-5K4\<^bsub>(D)\<^esub> (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> k) =HIDDENR1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f /^RFINSEQK2\<^bsub>(D)\<^esub> i"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_86:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds f just-once-valuesFINSEQ-4R2 p implies RevFINSEQ-5K3 (f  |--FINSEQ-4K6 p) =FINSEQ-1R1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f -|FINSEQ-4K5 p"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds f just-once-valuesFINSEQ-4R2 p implies RevFINSEQ-5K3 (f  |--FINSEQ-4K6 p) =FINSEQ-1R1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f -|FINSEQ-4K5 p"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "f just-once-valuesFINSEQ-4R2 p"
    then have A2: "p inTARSKIR2 rngFUNCT-1K2 f"
      using finseq_4_th_5 sorry
    then have A3: "p inTARSKIR2 rngFUNCT-1K2 (RevFINSEQ-5K4\<^bsub>(D)\<^esub> f)"
      using finseq_5_th_57 sorry
    then obtain n where 
      [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = p ..FINSEQ-4K4 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f -XCMPLX-0K6 \<one>\<^sub>M"
      using finseq_4_th_21 int_1_th_5 sorry
    have "p ..FINSEQ-4K4 f +NAT-1K1 p ..FINSEQ-4K4 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f =XBOOLE-0R4 lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M"
      using A1 finseq_6_th_37 sorry
    then have A4: "n +NAT-1K1 p ..FINSEQ-4K4 f =XBOOLE-0R4 lenFINSEQ-1K4 f"
       sorry
    have "RevFINSEQ-5K3 (f  |--FINSEQ-4K6 p) =HIDDENR1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f)"
      using A2 finseq_5_th_35 sorry
    also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n"
      using A4 finseq_6_th_84 sorry
    also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> f  |RELSET-1K5\<^bsub>(omegaORDINAL1K4,D)\<^esub> SegFINSEQ-1K2 n"
       sorry
    finally have "RevFINSEQ-5K3 (f  |--FINSEQ-4K6 p) =HIDDENR1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f  |RELSET-1K5\<^bsub>(omegaORDINAL1K4,D)\<^esub> SegFINSEQ-1K2 n"
       sorry
    thus "RevFINSEQ-5K3 (f  |--FINSEQ-4K6 p) =FINSEQ-1R1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f -|FINSEQ-4K5 p"
      using A3 finseq_4_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_87:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds f just-once-valuesFINSEQ-4R2 p implies RevFINSEQ-5K4\<^bsub>(D)\<^esub> (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =FINSEQ-1R1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds f just-once-valuesFINSEQ-4R2 p implies RevFINSEQ-5K4\<^bsub>(D)\<^esub> (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =HIDDENR1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "f just-once-valuesFINSEQ-4R2 p"
    then have A2: "p inTARSKIR2 rngFUNCT-1K2 f"
      using finseq_4_th_5 sorry
    then have A3: "p inTARSKIR2 rngFUNCT-1K2 (RevFINSEQ-5K4\<^bsub>(D)\<^esub> f)"
      using finseq_5_th_57 sorry
    have "RevFINSEQ-5K4\<^bsub>(D)\<^esub> (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =HIDDENR1 RevFINSEQ-5K3 ((<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K8 (f  |--FINSEQ-4K6 p))"
      using A2 finseq_6_th_41 sorry
    also have "... = RevFINSEQ-5K3 (f  |--FINSEQ-4K6 p) ^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)"
      using finseq_6_th_24 sorry
    also have "... = (RevFINSEQ-5K4\<^bsub>(D)\<^esub> f -|FINSEQ-4K5 p)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)"
      using A1 finseq_6_th_86 sorry
    also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p"
      using A3 finseq_6_th_40 sorry
    finally show "RevFINSEQ-5K4\<^bsub>(D)\<^esub> (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =HIDDENR1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_88:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds f just-once-valuesFINSEQ-4R2 p implies RevFINSEQ-5K4\<^bsub>(D)\<^esub> (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) =FINSEQ-1R1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds f just-once-valuesFINSEQ-4R2 p implies RevFINSEQ-5K4\<^bsub>(D)\<^esub> (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) =HIDDENR1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "f just-once-valuesFINSEQ-4R2 p"
    then have A2: "p inTARSKIR2 rngFUNCT-1K2 f"
      using finseq_4_th_5 sorry
    then have A3: "p inTARSKIR2 rngFUNCT-1K2 (RevFINSEQ-5K4\<^bsub>(D)\<^esub> f)"
      using finseq_5_th_57 sorry
    have "RevFINSEQ-5K4\<^bsub>(D)\<^esub> (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) =HIDDENR1 RevFINSEQ-5K3 ((f -|FINSEQ-4K5 p)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>))"
      using A2 finseq_6_th_40 sorry
    also have "... = (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K8 RevFINSEQ-5K3 (f -|FINSEQ-4K5 p)"
      using finseq_5_th_63 sorry
    also have "... = (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K8 (RevFINSEQ-5K4\<^bsub>(D)\<^esub> f  |--FINSEQ-4K6 p)"
      using A1 finseq_6_th_38 sorry
    also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p"
      using A3 finseq_6_th_41 sorry
    finally show "RevFINSEQ-5K4\<^bsub>(D)\<^esub> (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) =HIDDENR1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mdef finseq_6_def_1 ("circularFINSEQ-6V1\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"attr circularFINSEQ-6V1\<^bsub>(D)\<^esub> for FinSequenceFINSEQ-1M3-of D means
  (\<lambda>IT. IT /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 IT /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 IT)"..

mdef finseq_6_def_2 ("RotateFINSEQ-6K1\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]164 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FinSequenceFINSEQ-1M3-of D", "p be ElementSUBSET-1M1-of D"
"func RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) \<rightarrow> FinSequenceFINSEQ-1M3-of D equals
  (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) if p inTARSKIR2 rngFUNCT-1K2 f otherwise f"
proof-
  (*coherence*)
    show "(p inTARSKIR2 rngFUNCT-1K2 f implies (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) be FinSequenceFINSEQ-1M3-of D) & ( not p inTARSKIR2 rngFUNCT-1K2 f implies f be FinSequenceFINSEQ-1M3-of D)"
       sorry
  (*consistency*)
    show " for it be FinSequenceFINSEQ-1M3-of D holds  True "
       sorry
qed "sorry"

mtheorem finseq_6_cl_4:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be  non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M3-of D", "p be ElementSUBSET-1M1-of D"
"cluster RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) be  non emptyXBOOLE-0V1"
  proof-
    have " not RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) be emptyXBOOLE-0V1"
    proof-
      show " not RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) be emptyXBOOLE-0V1"
      proof-
        have cases: "p inTARSKIR2 rngFUNCT-1K2 f or  not p inTARSKIR2 rngFUNCT-1K2 f"
           sorry
        have case1: "p inTARSKIR2 rngFUNCT-1K2 f implies  not RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) be emptyXBOOLE-0V1"
        proof(rule impI)
          assume A1: "p inTARSKIR2 rngFUNCT-1K2 f"
          have "(f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) be  non emptyXBOOLE-0V1"
             sorry
          thus " not RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) be emptyXBOOLE-0V1"
            using A1 finseq_6_def_2 sorry
        qed
        have case2: " not p inTARSKIR2 rngFUNCT-1K2 f implies  not RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) be emptyXBOOLE-0V1"
        proof(rule impI)
          assume " not p inTARSKIR2 rngFUNCT-1K2 f"
          thus " not RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) be emptyXBOOLE-0V1"
            using finseq_6_def_2 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finseq_6_cl_5:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster circularFINSEQ-6V1\<^bsub>(D)\<^esub>\<bar>\<one>\<^sub>M -elementCARD-1V3 for FinSequenceFINSEQ-1M3-of D"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M3-of D st it be circularFINSEQ-6V1\<^bsub>(D)\<^esub>\<bar>\<one>\<^sub>M -elementCARD-1V3"
  proof-
    have " ex tVar1 be FinSequenceFINSEQ-1M3-of D st tVar1 be circularFINSEQ-6V1\<^bsub>(D)\<^esub> & tVar1 be \<one>\<^sub>M -elementCARD-1V3"
    proof-
      let ?d = "the ElementSUBSET-1M1-of D"
      show " ex tVar1 be FinSequenceFINSEQ-1M3-of D st tVar1 be circularFINSEQ-6V1\<^bsub>(D)\<^esub> & tVar1 be \<one>\<^sub>M -elementCARD-1V3"
      proof(rule bexI[of _ "<*FINSEQ-1K13\<^bsub>(D)\<^esub> ?d*>"],rule conjMI)
        show "<*FINSEQ-1K13\<^bsub>(D)\<^esub> the ElementSUBSET-1M1-of D *> be circularFINSEQ-6V1\<^bsub>(D)\<^esub>"
          using finseq_1_th_39 sorry
        show "<*FINSEQ-1K13\<^bsub>(D)\<^esub> the ElementSUBSET-1M1-of D *> be \<one>\<^sub>M -elementCARD-1V3"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finseq_6_cl_6:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster circularFINSEQ-6V1\<^bsub>(D)\<^esub>\<bar> non trivialZFMISC-1V1 for FinSequenceFINSEQ-1M3-of D"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M3-of D st it be circularFINSEQ-6V1\<^bsub>(D)\<^esub>\<bar> non trivialZFMISC-1V1"
  proof-
    have " ex tVar2 be FinSequenceFINSEQ-1M3-of D st tVar2 be circularFINSEQ-6V1\<^bsub>(D)\<^esub> &  not tVar2 be trivialZFMISC-1V1"
    proof-
      let ?d = "the ElementSUBSET-1M1-of D"
      show " ex tVar2 be FinSequenceFINSEQ-1M3-of D st tVar2 be circularFINSEQ-6V1\<^bsub>(D)\<^esub> &  not tVar2 be trivialZFMISC-1V1"
      proof(rule bexI[of _ "<*FINSEQ-4K2\<^bsub>(D)\<^esub> ?d,?d *>"],rule conjMI)
        have "lenFINSEQ-1K4 (<*FINSEQ-4K2\<^bsub>(D)\<^esub> ?d,?d *>) =XBOOLE-0R4 \<two>\<^sub>M"
          using finseq_1_th_44 sorry
        then have "(<*FINSEQ-4K2\<^bsub>(D)\<^esub> ?d,?d *>)/.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 (<*FINSEQ-4K2\<^bsub>(D)\<^esub> ?d,?d *>) =HIDDENR1 ?d"
          using finseq_4_th_17 sorry
        also have "... = (<*FINSEQ-4K2\<^bsub>(D)\<^esub> ?d,?d *>)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
          using finseq_4_th_17 sorry
        finally have "(<*FINSEQ-4K2\<^bsub>(D)\<^esub> ?d,?d *>)/.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 (<*FINSEQ-4K2\<^bsub>(D)\<^esub> ?d,?d *>) =HIDDENR1 (<*FINSEQ-4K2\<^bsub>(D)\<^esub> ?d,?d *>)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
           sorry
        thus "<*FINSEQ-4K2\<^bsub>(D)\<^esub> the ElementSUBSET-1M1-of D,the ElementSUBSET-1M1-of D *> be circularFINSEQ-6V1\<^bsub>(D)\<^esub>"
           sorry
        show " not <*FINSEQ-4K2\<^bsub>(D)\<^esub> the ElementSUBSET-1M1-of D,the ElementSUBSET-1M1-of D *> be trivialZFMISC-1V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finseq_6_th_89:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M) =FINSEQ-1R1 f"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M) =HIDDENR1 f"
  proof(rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    have A1: "lenFINSEQ-1K4 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M*>) =XBOOLE-0R4 \<one>\<^sub>M"
      using finseq_1_th_39 sorry
    show "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M) =HIDDENR1 f"
    proof-
      have cases: "f be  non emptyXBOOLE-0V1 or f be emptyXBOOLE-0V1"
         sorry
      have case1: "f be  non emptyXBOOLE-0V1 implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M) =HIDDENR1 f"
      proof(rule impI)
        assume A2: "f be  non emptyXBOOLE-0V1"
        then have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M inTARSKIR2 rngFUNCT-1K2 f"
          using finseq_6_th_42 sorry
        then have "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M) =HIDDENR1 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using finseq_6_def_2 sorry
        also have "... = f ^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using A2 finseq_6_th_44 sorry
        also have "... = f ^FINSEQ-1K9\<^bsub>(D)\<^esub> ((<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M*>)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using A2 finseq_6_th_44 sorry
        also have "... = f ^FINSEQ-1K8 {}XBOOLE-0K1"
          using A1 finseq_5_th_32 sorry
        also have "... = f"
          using finseq_1_th_34 sorry
        finally show "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M) =HIDDENR1 f"
           sorry
      qed
      have case2: "f be emptyXBOOLE-0V1 implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M) =FINSEQ-1R1 f"
      proof(rule impI)
        assume "f be emptyXBOOLE-0V1"
        thus "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M) =FINSEQ-1R1 f"
          using finseq_6_def_2 relat_1_th_38 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_cl_7:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "p be ElementSUBSET-1M1-of D", "f be circularFINSEQ-6V1\<^bsub>(D)\<^esub>\<bar> non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M3-of D"
"cluster RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) as-term-is circularFINSEQ-6V1\<^bsub>(D)\<^esub>"
proof
(*coherence*)
  show "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) be circularFINSEQ-6V1\<^bsub>(D)\<^esub>"
  proof-
    show "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) be circularFINSEQ-6V1\<^bsub>(D)\<^esub>"
    proof-
      have cases: "( not p inTARSKIR2 rngFUNCT-1K2 f or p inTARSKIR2 rngFUNCT-1K2 f & p <>HIDDENR2 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M) or p inTARSKIR2 rngFUNCT-1K2 f & p =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
         sorry
      have case1: " not p inTARSKIR2 rngFUNCT-1K2 f implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) be circularFINSEQ-6V1\<^bsub>(D)\<^esub>"
      proof(rule impI)
        assume " not p inTARSKIR2 rngFUNCT-1K2 f"
        thus "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) be circularFINSEQ-6V1\<^bsub>(D)\<^esub>"
          using finseq_6_def_2 sorry
      qed
      have case2: "p inTARSKIR2 rngFUNCT-1K2 f & p <>HIDDENR2 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) be circularFINSEQ-6V1\<^bsub>(D)\<^esub>"
      proof(rule impMI ,rule impI)
        assume A1: "p inTARSKIR2 rngFUNCT-1K2 f"
          and A2: "p <>HIDDENR2 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
        have A3: "p ..FINSEQ-4K4 f >=XXREAL-0R2 \<one>\<^sub>M"
          using A1 finseq_4_th_21 sorry
        have A4: "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) =FINSEQ-1R1 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using A1 finseq_6_def_2 sorry
        have "p ..FINSEQ-4K4 f <>HIDDENR2 \<one>\<^sub>M"
          using A1 A2 finseq_5_th_38 sorry
        then have "p ..FINSEQ-4K4 f >XXREAL-0R4 \<one>\<^sub>M"
          using A3 xxreal_0_th_1 sorry
        then have "p ..FINSEQ-4K4 f >=XXREAL-0R2 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_13 sorry
        then have A5: "lenFINSEQ-1K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) >=XXREAL-0R2 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
          using A1 finseq_5_th_42 sorry
        then have "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)"
          using xxreal_0_th_2 sorry
        then have A6: "lenFINSEQ-1K4 ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) =XBOOLE-0R4 lenFINSEQ-1K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) -XCMPLX-0K6 \<one>\<^sub>M"
          using rfinseq_def_1 sorry
        then have "lenFINSEQ-1K4 ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)"
           sorry
        then have "lenFINSEQ-1K4 ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) >=XXREAL-0R2 \<one>\<^sub>M"
          using A5 xreal_1_th_6 sorry
        then have A7: "lenFINSEQ-1K4 ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) inTARSKIR2 domFINSEQ-1K5 ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using finseq_3_th_25 sorry
        have Cut1975: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
          using finseq_5_th_6 sorry
        have "(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =HIDDENR1 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
        proof-
          have "(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =HIDDENR1 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
            using A4 finseq_4_th_68 Cut1975 sorry
          also have "... = p"
            using finseq_5_th_53 sorry
          also have "... = (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 f)"
            using A1 finseq_5_th_45 sorry
          also have "... = (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> (lenFINSEQ-1K4 ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
            using A1 A6 finseq_5_th_42 sorry
          also have "... = ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)/.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
            using A7 finseq_5_th_27 sorry
          also have "... = ((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(D)\<^esub> (lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) +NAT-1K1 lenFINSEQ-1K4 ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M))"
            using A7 finseq_4_th_69 sorry
          also have "... = (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
            using A4 finseq_1_th_22 sorry
          finally show "(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =HIDDENR1 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
             sorry
        qed
        thus "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) be circularFINSEQ-6V1\<^bsub>(D)\<^esub>"
          using finseq_6_def_1 sorry
      qed
      have case3: "p inTARSKIR2 rngFUNCT-1K2 f & p =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) be circularFINSEQ-6V1\<^bsub>(D)\<^esub>"
      proof(rule impI)
        assume "p inTARSKIR2 rngFUNCT-1K2 f & p =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
        thus "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) be circularFINSEQ-6V1\<^bsub>(D)\<^esub>"
          using finseq_6_th_89 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed
qed "sorry"

mtheorem finseq_6_th_90:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds f be circularFINSEQ-6V1\<^bsub>(D)\<^esub> & p inTARSKIR2 rngFUNCT-1K2 f implies rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)) =XBOOLE-0R4 rngFUNCT-1K2 f"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds f be circularFINSEQ-6V1\<^bsub>(D)\<^esub> & p inTARSKIR2 rngFUNCT-1K2 f implies rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)) =XBOOLE-0R4 rngFUNCT-1K2 f"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "f be circularFINSEQ-6V1\<^bsub>(D)\<^esub>"
      and A2: "p inTARSKIR2 rngFUNCT-1K2 f"
    have A3: "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) =FINSEQ-1R1 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
      using A2 finseq_6_def_2 sorry
    have A4: "rngFUNCT-1K2 ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) c=TARSKIR1 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)"
      using finseq_5_th_33 sorry
    have "rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) c=TARSKIR1 rngFUNCT-1K2 f"
      using finseq_5_th_48 sorry
    then have A5: "rngFUNCT-1K2 ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) c=TARSKIR1 rngFUNCT-1K2 f"
      using A4 sorry
    have A6: "rngFUNCT-1K2 ((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)) =XBOOLE-0R4 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) \\/XBOOLE-0K2 rngFUNCT-1K2 ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
      using finseq_1_th_31 sorry
    have Cut2003: "rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) c=TARSKIR1 rngFUNCT-1K2 f"
      using A2 finseq_5_th_55 sorry
    have "rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)) c=TARSKIR1 rngFUNCT-1K2 f & rngFUNCT-1K2 f c=TARSKIR1 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
    proof(rule conjMI)
      show "rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)) c=TARSKIR1 rngFUNCT-1K2 f"
        using A3 A6 A5 xboole_1_th_8 Cut2003 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 f"
        then obtain i where
          [ty]:"i be NatNAT-1M1" and 
          A7: "i inTARSKIR2 domFINSEQ-1K5 f"and A8: "f .FUNCT-1K1 i =HIDDENR1 x"
          using finseq_2_th_10 sorry
        have A9: "x =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> i"
          using A7 A8 partfun1_def_6 sorry
        show "x inHIDDENR3 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
        proof-
          have cases: "(i =XBOOLE-0R4 \<one>\<^sub>M or i <=XXREAL-0R1 p ..FINSEQ-4K4 f & i <>HIDDENR2 \<one>\<^sub>M) or i >XXREAL-0R4 p ..FINSEQ-4K4 f"
             sorry
          have case1: "i =XBOOLE-0R4 \<one>\<^sub>M implies x inHIDDENR3 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
          proof(rule impI)
            assume A10: "i =XBOOLE-0R4 \<one>\<^sub>M"
            have "lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =HIDDENR1 lenFINSEQ-1K4 ((<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f))"
              using finseq_5_def_2 sorry
            also have "... = lenFINSEQ-1K4 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>) +NAT-1K1 lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f)"
              using finseq_1_th_22 sorry
            also have "... = \<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f)"
              using finseq_1_th_39 sorry
            finally have "lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =HIDDENR1 \<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f)"
               sorry
            then have "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
              using nat_1_th_11 sorry
            then have A11: "lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) inTARSKIR2 domFINSEQ-1K5 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
              using finseq_3_th_25 sorry
            have "x =HIDDENR1 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
              using A2 finseq_5_th_54 A1 A9 A10 sorry
            then have "x inHIDDENR3 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
              using A11 partfun2_th_2 sorry
            thus "x inHIDDENR3 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
              using A3 A6 xboole_0_def_3 sorry
          qed
          have case2: "i <=XXREAL-0R1 p ..FINSEQ-4K4 f & i <>HIDDENR2 \<one>\<^sub>M implies x inHIDDENR3 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
          proof(rule impMI ,rule impI)
            assume A12: "i <=XXREAL-0R1 p ..FINSEQ-4K4 f"
              and A13: "i <>HIDDENR2 \<one>\<^sub>M"
            have A14: "i <>HIDDENR2 0NUMBERSK6"
              using A7 finseq_3_th_25 sorry
            then have A15: "i >XXREAL-0R4 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
              using A13 nat_1_th_25 sorry
            then have A16: "i inTARSKIR2 SegFINSEQ-1K2 (p ..FINSEQ-4K4 f)"
              using A12 sorry
            obtain j where
              [ty]:"j be NatNAT-1M1" and 
              A17: "i =XBOOLE-0R4 j +NAT-1K1 \<one>\<^sub>M"
              using A14 nat_1_th_6 sorry
            have A18: "j >=XXREAL-0R2 \<one>\<^sub>M"
              using A15 A17 nat_1_th_14 sorry
            have A19: "i <=XXREAL-0R1 lenFINSEQ-1K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)"
              using A2 A12 finseq_5_th_42 sorry
            then have "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)"
              using A14 nat_1_th_25 xxreal_0_th_2 sorry
            then have "lenFINSEQ-1K4 ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) =XBOOLE-0R4 lenFINSEQ-1K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) -XCMPLX-0K6 \<one>\<^sub>M"
              using rfinseq_def_1 sorry
            then have "lenFINSEQ-1K4 ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)"
               sorry
            then have "j <=XXREAL-0R1 lenFINSEQ-1K4 ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
              using A17 A19 xreal_1_th_6 sorry
            then have A20: "j inTARSKIR2 domFINSEQ-1K5 ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
              using A18 finseq_3_th_25 sorry
            have A21: "lenFINSEQ-1K4 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M*>) =XBOOLE-0R4 \<one>\<^sub>M"
              using finseq_1_th_39 sorry
            have "f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
              using A2 finseq_5_th_29 finseq_5_th_47 sorry
            then have "((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)/.PARTFUN1K7\<^bsub>(D)\<^esub> j =HIDDENR1 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> i"
              using A17 A20 A21 finseq_4_th_69 sorry
            also have "... = f /.PARTFUN1K7\<^bsub>(D)\<^esub> i"
              using A2 A16 finseq_5_th_43 sorry
            finally have "((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)/.PARTFUN1K7\<^bsub>(D)\<^esub> j =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> i"
               sorry
            then have "x inHIDDENR3 rngFUNCT-1K2 ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
              using A9 A20 partfun2_th_2 sorry
            thus "x inHIDDENR3 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
              using A3 A6 xboole_0_def_3 sorry
          qed
          have case3: "i >XXREAL-0R4 p ..FINSEQ-4K4 f implies x inHIDDENR3 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
          proof(rule impI)
            assume "i >XXREAL-0R4 p ..FINSEQ-4K4 f"
            then obtain j where 
              [ty]:"j be ElementSUBSET-1M1-of NATNUMBERSK1" and jDef:"j = i -XCMPLX-0K6 p ..FINSEQ-4K4 f"
              using int_1_th_5 sorry
            have A22: "j +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 \<one>\<^sub>M"
              using nat_1_th_11 sorry
            have "i <=XXREAL-0R1 lenFINSEQ-1K4 f"
              using A7 finseq_3_th_25 sorry
            then have A23: "j <=XXREAL-0R1 lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f"
              using xreal_1_th_9 sorry
            have "lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 (lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f)+XCMPLX-0K2 \<one>\<^sub>M"
              using A2 finseq_5_th_50 sorry
            then have "j +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
              using A23 xreal_1_th_6 sorry
            then have A24: "j +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
              using A22 finseq_3_th_25 sorry
            have "j +NAT-1K1 p ..FINSEQ-4K4 f =XBOOLE-0R4 i"
               sorry
            then have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> (j +NAT-1K1 \<one>\<^sub>M)"
              using A2 A24 finseq_5_th_52 sorry
            then have "x inHIDDENR3 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
              using A9 A24 partfun2_th_2 sorry
            thus "x inHIDDENR3 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
              using A3 A6 xboole_0_def_3 sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 sorry
        qed
      qed "sorry"
      thus "rngFUNCT-1K2 f c=TARSKIR1 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
        using tarski_def_3 sorry
    qed
    thus "rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)) =XBOOLE-0R4 rngFUNCT-1K2 f"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_91:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies p inTARSKIR2 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies p inTARSKIR2 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    have "p inTARSKIR2 {TARSKIK1 p}"
      using tarski_def_1 sorry
    then have "p inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)"
      using finseq_1_th_39 sorry
    then have "p inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>) \\/XBOOLE-0K2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f)"
      using xboole_0_def_3 sorry
    then have "p inTARSKIR2 rngFUNCT-1K2 ((<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f))"
      using finseq_1_th_31 sorry
    then have A1: "p inTARSKIR2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
      using finseq_5_def_2 sorry
    assume "p inTARSKIR2 rngFUNCT-1K2 f"
    then have "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) =FINSEQ-1R1 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
      using finseq_6_def_2 sorry
    then have "rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)) =XBOOLE-0R4 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) \\/XBOOLE-0K2 rngFUNCT-1K2 ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
      using finseq_1_th_31 sorry
    thus "p inTARSKIR2 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
      using A1 xboole_0_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_92:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 p"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 p"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume "p inTARSKIR2 rngFUNCT-1K2 f"
    then have "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) =HIDDENR1 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
      using finseq_6_def_2 sorry
    also have "... = ((<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f))^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
      using finseq_5_def_2 sorry
    also have "... = (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M))"
      using finseq_1_th_32 sorry
    finally have "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) =HIDDENR1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M))"
       sorry
    thus "(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 p"
      using finseq_5_th_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_93:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p),p) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p),p) =HIDDENR1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)"
  proof(rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    show "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p),p) =HIDDENR1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)"
    proof-
      have cases: "p inTARSKIR2 rngFUNCT-1K2 f or  not p inTARSKIR2 rngFUNCT-1K2 f"
         sorry
      have case1: "p inTARSKIR2 rngFUNCT-1K2 f implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p),p) =HIDDENR1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)"
      proof(rule impI)
        assume A1: "p inTARSKIR2 rngFUNCT-1K2 f"
        then obtain f9 where 
          [ty]:"f9 be  non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M3-of D" and f9Def:"f9 = f"
           sorry
        have A2: "(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 p"
          using A1 finseq_6_th_92 sorry
        then have A3: "(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f9,p)):-FINSEQ-5K2\<^bsub>(D)\<^esub> p =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)"
          using finseq_6_th_44 sorry
        have A4: "p inTARSKIR2 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
          using A1 finseq_6_th_91 sorry
        have A5: "lenFINSEQ-1K4 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>) =XBOOLE-0R4 \<one>\<^sub>M"
          using finseq_1_th_39 sorry
        have "(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f9,p))-:FINSEQ-5K1\<^bsub>(D)\<^esub> p =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>"
          using A2 finseq_6_th_44 sorry
        then have "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p),p) =HIDDENR1 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))^FINSEQ-1K9\<^bsub>(D)\<^esub> ((<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using A3 A4 finseq_6_def_2 sorry
        also have "... = (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))^FINSEQ-1K8 {}XBOOLE-0K1"
          using A5 finseq_5_th_32 sorry
        also have "... = RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)"
          using finseq_1_th_34 sorry
        finally show "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p),p) =HIDDENR1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)"
           sorry
      qed
      have case2: " not p inTARSKIR2 rngFUNCT-1K2 f implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p),p) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)"
      proof(rule impI)
        assume " not p inTARSKIR2 rngFUNCT-1K2 f"
        thus "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p),p) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)"
          using finseq_6_def_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_94:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>,p) =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>,p) =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>"
  proof(rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    have "(<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 p"
      using finseq_4_th_16 sorry
    thus "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>,p) =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>"
      using finseq_6_th_89 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_95:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>,p1) =FINSEQ-1R1 <*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>,p1) =FINSEQ-1R1 <*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>"
  proof(rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p1 assume [ty]: "p1 be ElementSUBSET-1M1-of D"
    fix p2 assume [ty]: "p2 be ElementSUBSET-1M1-of D"
    have "(<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 p1"
      using finseq_4_th_17 sorry
    thus "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>,p1) =FINSEQ-1R1 <*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>"
      using finseq_6_th_89 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_96:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>,p2) =FINSEQ-1R1 <*FINSEQ-4K2\<^bsub>(D)\<^esub> p2,p2 *>"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>,p2) =FINSEQ-1R1 <*FINSEQ-4K2\<^bsub>(D)\<^esub> p2,p2 *>"
  proof(rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p1 assume [ty]: "p1 be ElementSUBSET-1M1-of D"
    fix p2 assume [ty]: "p2 be ElementSUBSET-1M1-of D"
    show "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>,p2) =FINSEQ-1R1 <*FINSEQ-4K2\<^bsub>(D)\<^esub> p2,p2 *>"
    proof-
      have cases: "p1 =XBOOLE-0R4 p2 or p1 <>HIDDENR2 p2"
         sorry
      have case1: "p1 =XBOOLE-0R4 p2 implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>,p2) =FINSEQ-1R1 <*FINSEQ-4K2\<^bsub>(D)\<^esub> p2,p2 *>"
      proof(rule impI)
        assume "p1 =XBOOLE-0R4 p2"
        thus "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>,p2) =FINSEQ-1R1 <*FINSEQ-4K2\<^bsub>(D)\<^esub> p2,p2 *>"
          using finseq_6_th_95 sorry
      qed
      have case2: "p1 <>HIDDENR2 p2 implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>,p2) =HIDDENR1 <*FINSEQ-4K2\<^bsub>(D)\<^esub> p2,p2 *>"
      proof(rule impI)
        assume A1: "p1 <>HIDDENR2 p2"
        have "rngFUNCT-1K2 (<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>) =XBOOLE-0R4 {TARSKIK2 p1,p2 }"
          using finseq_6_lm_1 sorry
        then have "p2 inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>)"
          using tarski_def_2 sorry
        then have "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>,p2) =HIDDENR1 ((<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>):-FINSEQ-5K2\<^bsub>(D)\<^esub> p2)^FINSEQ-1K9\<^bsub>(D)\<^esub> (((<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using finseq_6_def_2 sorry
        also have "... = (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p2*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (((<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using A1 finseq_6_th_53 sorry
        also have "... = (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p2*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using A1 finseq_6_th_49 sorry
        also have "... = <*FINSEQ-4K2\<^bsub>(D)\<^esub> p2,p2 *>"
          using finseq_6_th_46 sorry
        finally show "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>,p2) =HIDDENR1 <*FINSEQ-4K2\<^bsub>(D)\<^esub> p2,p2 *>"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_97:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for p3 be ElementSUBSET-1M1-of D holds RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>,p1) =FINSEQ-1R1 <*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for p3 be ElementSUBSET-1M1-of D holds RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>,p1) =FINSEQ-1R1 <*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p1 assume [ty]: "p1 be ElementSUBSET-1M1-of D"
    fix p2 assume [ty]: "p2 be ElementSUBSET-1M1-of D"
    fix p3 assume [ty]: "p3 be ElementSUBSET-1M1-of D"
    have "(<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 p1"
      using finseq_4_th_18 sorry
    thus "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>,p1) =FINSEQ-1R1 <*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>"
      using finseq_6_th_89 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_98:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for p3 be ElementSUBSET-1M1-of D holds p1 <>HIDDENR2 p2 implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>,p2) =FINSEQ-1R1 <*FINSEQ-4K3\<^bsub>(D)\<^esub> p2,p3,p2 *>"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for p3 be ElementSUBSET-1M1-of D holds p1 <>HIDDENR2 p2 implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>,p2) =HIDDENR1 <*FINSEQ-4K3\<^bsub>(D)\<^esub> p2,p3,p2 *>"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p1 assume [ty]: "p1 be ElementSUBSET-1M1-of D"
    fix p2 assume [ty]: "p2 be ElementSUBSET-1M1-of D"
    fix p3 assume [ty]: "p3 be ElementSUBSET-1M1-of D"
    assume A1: "p1 <>HIDDENR2 p2"
    have "rngFUNCT-1K2 (<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>) =XBOOLE-0R4 {ENUMSET1K1 p1,p2,p3 }"
      using finseq_6_lm_2 sorry
    then have "p2 inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>)"
      using enumset1_def_1 sorry
    then have "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>,p2) =HIDDENR1 ((<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>):-FINSEQ-5K2\<^bsub>(D)\<^esub> p2)^FINSEQ-1K9\<^bsub>(D)\<^esub> (((<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
      using finseq_6_def_2 sorry
    also have "... = (<*FINSEQ-4K2\<^bsub>(D)\<^esub> p2,p3 *>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (((<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
      using A1 finseq_6_th_54 sorry
    also have "... = (<*FINSEQ-4K2\<^bsub>(D)\<^esub> p2,p3 *>)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
      using A1 finseq_6_th_50 sorry
    also have "... = <*FINSEQ-4K3\<^bsub>(D)\<^esub> p2,p3,p2 *>"
      using finseq_6_th_46 sorry
    finally show "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>,p2) =HIDDENR1 <*FINSEQ-4K3\<^bsub>(D)\<^esub> p2,p3,p2 *>"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_99:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for p3 be ElementSUBSET-1M1-of D holds p2 <>HIDDENR2 p3 implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>,p3) =FINSEQ-1R1 <*FINSEQ-4K3\<^bsub>(D)\<^esub> p3,p2,p3 *>"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for p3 be ElementSUBSET-1M1-of D holds p2 <>HIDDENR2 p3 implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>,p3) =FINSEQ-1R1 <*FINSEQ-4K3\<^bsub>(D)\<^esub> p3,p2,p3 *>"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p1 assume [ty]: "p1 be ElementSUBSET-1M1-of D"
    fix p2 assume [ty]: "p2 be ElementSUBSET-1M1-of D"
    fix p3 assume [ty]: "p3 be ElementSUBSET-1M1-of D"
    assume A1: "p2 <>HIDDENR2 p3"
    show "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>,p3) =FINSEQ-1R1 <*FINSEQ-4K3\<^bsub>(D)\<^esub> p3,p2,p3 *>"
    proof-
      have cases: "p1 =XBOOLE-0R4 p3 or p1 <>HIDDENR2 p3"
         sorry
      have case1: "p1 =XBOOLE-0R4 p3 implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>,p3) =FINSEQ-1R1 <*FINSEQ-4K3\<^bsub>(D)\<^esub> p3,p2,p3 *>"
      proof(rule impI)
        assume "p1 =XBOOLE-0R4 p3"
        thus "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>,p3) =FINSEQ-1R1 <*FINSEQ-4K3\<^bsub>(D)\<^esub> p3,p2,p3 *>"
          using finseq_6_th_97 sorry
      qed
      have case2: "p1 <>HIDDENR2 p3 implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>,p3) =HIDDENR1 <*FINSEQ-4K3\<^bsub>(D)\<^esub> p3,p2,p3 *>"
      proof(rule impI)
        assume A2: "p1 <>HIDDENR2 p3"
        have "rngFUNCT-1K2 (<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>) =XBOOLE-0R4 {ENUMSET1K1 p1,p2,p3 }"
          using finseq_6_lm_2 sorry
        then have "p3 inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>)"
          using enumset1_def_1 sorry
        then have "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>,p3) =HIDDENR1 ((<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>):-FINSEQ-5K2\<^bsub>(D)\<^esub> p3)^FINSEQ-1K9\<^bsub>(D)\<^esub> (((<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p3)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using finseq_6_def_2 sorry
        also have "... = (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p3*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (((<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p3)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using A1 A2 finseq_6_th_55 sorry
        also have "... = (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p3*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using A1 A2 finseq_6_th_51 sorry
        also have "... = (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p3*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-4K2\<^bsub>(D)\<^esub> p2,p3 *>)"
          using finseq_6_th_47 sorry
        also have "... = <*FINSEQ-4K3\<^bsub>(D)\<^esub> p3,p2,p3 *>"
          using finseq_1_th_43 sorry
        finally show "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>,p3) =HIDDENR1 <*FINSEQ-4K3\<^bsub>(D)\<^esub> p3,p2,p3 *>"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_100:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be circularFINSEQ-6V1\<^bsub>(D)\<^esub>\<bar> non trivialZFMISC-1V1\<bar>FinSequenceFINSEQ-1M3-of D holds rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) =XBOOLE-0R4 rngFUNCT-1K2 f"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be circularFINSEQ-6V1\<^bsub>(D)\<^esub>\<bar> non trivialZFMISC-1V1\<bar>FinSequenceFINSEQ-1M3-of D holds rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) =XBOOLE-0R4 rngFUNCT-1K2 f"
  proof(rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be circularFINSEQ-6V1\<^bsub>(D)\<^esub>\<bar> non trivialZFMISC-1V1\<bar>FinSequenceFINSEQ-1M3-of D"
    have "rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) c=TARSKIR1 rngFUNCT-1K2 f & rngFUNCT-1K2 f c=TARSKIR1 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
    proof(rule conjMI)
      show "rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) c=TARSKIR1 rngFUNCT-1K2 f"
        using finseq_5_th_33 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        have "f =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using finseq_5_th_29 sorry
        then have A1: "rngFUNCT-1K2 f =XBOOLE-0R4 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M*>) \\/XBOOLE-0K2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using finseq_1_th_31 sorry
        assume A2: "x inHIDDENR3 rngFUNCT-1K2 f"
        show "x inHIDDENR3 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
        proof-
          have cases: "x inHIDDENR3 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M*>) or x inHIDDENR3 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
            using A1 A2 xboole_0_def_3 sorry
          have case1: "x inHIDDENR3 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M*>) implies x inHIDDENR3 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          proof(rule impI)
            assume "x inHIDDENR3 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M*>)"
            then have "x inHIDDENR3 {TARSKIK1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M }"
              using finseq_1_th_39 sorry
            then have "x =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
              using tarski_def_1 sorry
            then have A3: "x =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f"
              using finseq_6_def_1 sorry
            have A4: "lenFINSEQ-1K4 f >=XXREAL-0R2 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
              using nat_d_th_60 sorry
            then have "lenFINSEQ-1K4 f >=XXREAL-0R2 \<one>\<^sub>M"
              using xxreal_0_th_2 sorry
            then have A5: "lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) =XBOOLE-0R4 lenFINSEQ-1K4 f -XCMPLX-0K6 \<one>\<^sub>M"
              using rfinseq_def_1 sorry
            then have "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
              using A4 xreal_1_th_19 sorry
            then have A6: "lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
              using finseq_3_th_25 sorry
            have "lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 f"
              using A5 sorry
            then have "x =HIDDENR1 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)/.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
              using A3 A6 finseq_5_th_27 sorry
            thus "x inHIDDENR3 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
              using A6 partfun2_th_2 sorry
          qed
          have case2: "x inHIDDENR3 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) implies x inHIDDENR3 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          proof(rule impI)
            assume "x inHIDDENR3 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
            thus "x inHIDDENR3 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus "rngFUNCT-1K2 f c=TARSKIR1 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
        using tarski_def_3 sorry
    qed
    thus "rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) =XBOOLE-0R4 rngFUNCT-1K2 f"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_101:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) c=TARSKIR1 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) c=TARSKIR1 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
  proof(rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    show "rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) c=TARSKIR1 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
    proof-
      have cases: "p inTARSKIR2 rngFUNCT-1K2 f or  not p inTARSKIR2 rngFUNCT-1K2 f"
         sorry
      have case1: "p inTARSKIR2 rngFUNCT-1K2 f implies rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) c=TARSKIR1 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
      proof(rule impI)
        assume A1: "p inTARSKIR2 rngFUNCT-1K2 f"
        then have "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) =FINSEQ-1R1 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using finseq_6_def_2 sorry
        then have A2: "rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)) =XBOOLE-0R4 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) \\/XBOOLE-0K2 rngFUNCT-1K2 ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using finseq_1_th_31 sorry
        show "rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) c=TARSKIR1 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) implies x inHIDDENR3 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A3: "x inHIDDENR3 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
            have A4: "rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) c=TARSKIR1 rngFUNCT-1K2 f"
              using finseq_5_th_33 sorry
            then have A5: "x inHIDDENR3 rngFUNCT-1K2 f"
              using A3 sorry
            show "x inHIDDENR3 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
            proof-
              have cases: "(x ..FINSEQ-4K4 f <XXREAL-0R3 p ..FINSEQ-4K4 f & x ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) >=XXREAL-0R2 p ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) or x ..FINSEQ-4K4 f <XXREAL-0R3 p ..FINSEQ-4K4 f & x ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) <=XXREAL-0R1 p ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)) or x ..FINSEQ-4K4 f >=XXREAL-0R2 p ..FINSEQ-4K4 f"
                 sorry
              have case1: "x ..FINSEQ-4K4 f <XXREAL-0R3 p ..FINSEQ-4K4 f & x ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) >=XXREAL-0R2 p ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) implies x inHIDDENR3 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
              proof(rule impMI ,rule impI)
                assume A6: "x ..FINSEQ-4K4 f <XXREAL-0R3 p ..FINSEQ-4K4 f"
                  and A7: "x ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) >=XXREAL-0R2 p ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
                have A8: "p ..FINSEQ-4K4 f >=XXREAL-0R2 \<one>\<^sub>M"
                  using A1 finseq_4_th_21 sorry
                have "p ..FINSEQ-4K4 f <>HIDDENR2 \<one>\<^sub>M"
                  using A3 A4 A6 finseq_4_th_21 sorry
                then have "p ..FINSEQ-4K4 f >XXREAL-0R4 \<one>\<^sub>M"
                  using A8 xxreal_0_th_1 sorry
                then have "p ..FINSEQ-4K4 f =XBOOLE-0R4 p ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
                  using A1 finseq_6_th_56 sorry
                then have A9: "x ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 p ..FINSEQ-4K4 f"
                  using A7 xreal_1_th_6 sorry
                have "rngFUNCT-1K2 f c=TARSKIR1 D"
                  using finseq_1_def_4 sorry
                then obtain q where 
                  [ty]:"q be ElementSUBSET-1M1-of D" and qDef:"q = x"
                  using A5 sorry
                have A10: "x ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
                  using A3 finseq_4_th_20 sorry
                have "f <>HIDDENR2 {}XBOOLE-0K1"
                  using A1 sorry
                then have "lenFINSEQ-1K4 f >=XXREAL-0R2 \<one>\<^sub>M"
                  using nat_1_th_14 sorry
                then have "lenFINSEQ-1K4 f -XCMPLX-0K6 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
                  using rfinseq_def_1 sorry
                then have A11: "lenFINSEQ-1K4 f =XBOOLE-0R4 lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
                   sorry
                have "x ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) <=XXREAL-0R1 lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
                  using A3 finseq_4_th_21 sorry
                then have A12: "x ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
                  using A11 xreal_1_th_6 sorry
                have "q =HIDDENR1 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)/.PARTFUN1K7\<^bsub>(D)\<^esub> (q ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M))"
                  using A3 finseq_5_th_38 sorry
                also have "... = f /.PARTFUN1K7\<^bsub>(D)\<^esub> (q ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
                  using A10 finseq_5_th_27 sorry
                finally have "q =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> (q ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
                   sorry
                then have "x inHIDDENR3 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
                  using A1 A12 A9 finseq_6_th_63 sorry
                thus "x inHIDDENR3 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
                  using A2 xboole_0_def_3 sorry
              qed
              have case2: "x ..FINSEQ-4K4 f <XXREAL-0R3 p ..FINSEQ-4K4 f & x ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) <=XXREAL-0R1 p ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) implies x inHIDDENR3 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
              proof(rule impMI ,rule impI)
                assume A13: "x ..FINSEQ-4K4 f <XXREAL-0R3 p ..FINSEQ-4K4 f"
                  and A14: "x ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) <=XXREAL-0R1 p ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
                have A15: "p ..FINSEQ-4K4 f <>HIDDENR2 \<one>\<^sub>M"
                  using A3 A4 A13 finseq_4_th_21 sorry
                have "p ..FINSEQ-4K4 f >=XXREAL-0R2 \<one>\<^sub>M"
                  using A1 finseq_4_th_21 sorry
                then have "p ..FINSEQ-4K4 f >XXREAL-0R4 \<one>\<^sub>M"
                  using A15 xxreal_0_th_1 sorry
                then have "p inTARSKIR2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
                  using A1 finseq_6_th_57 sorry
                then have "x inHIDDENR3 rngFUNCT-1K2 ((f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p)"
                  using A3 A14 finseq_5_th_46 sorry
                then have "x inHIDDENR3 rngFUNCT-1K2 ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
                  using A1 A15 finseq_6_th_60 sorry
                thus "x inHIDDENR3 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
                  using A2 xboole_0_def_3 sorry
              qed
              have case3: "x ..FINSEQ-4K4 f >=XXREAL-0R2 p ..FINSEQ-4K4 f implies x inHIDDENR3 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
              proof(rule impI)
                assume "x ..FINSEQ-4K4 f >=XXREAL-0R2 p ..FINSEQ-4K4 f"
                then have "x inHIDDENR3 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
                  using A1 A3 A4 finseq_6_th_62 sorry
                thus "x inHIDDENR3 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
                  using A2 xboole_0_def_3 sorry
              qed
              show " ?thesis "
                using cases case1 case2 case3 sorry
            qed
          qed "sorry"
          thus "rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) c=TARSKIR1 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
            using tarski_def_3 sorry
        qed
      qed
      have case2: " not p inTARSKIR2 rngFUNCT-1K2 f implies rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) c=TARSKIR1 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
      proof(rule impI)
        assume " not p inTARSKIR2 rngFUNCT-1K2 f"
        then have "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) =FINSEQ-1R1 f"
          using finseq_6_def_2 sorry
        thus "rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) c=TARSKIR1 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
          using finseq_5_th_33 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_102:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p2 inTARSKIR2 rngFUNCT-1K2 f \\SUBSET-1K6 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1) implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p2 inTARSKIR2 rngFUNCT-1K2 f \\SUBSET-1K6 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1) implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =HIDDENR1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p1 assume [ty]: "p1 be ElementSUBSET-1M1-of D"
    fix p2 assume [ty]: "p2 be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p2 inTARSKIR2 rngFUNCT-1K2 f \\SUBSET-1K6 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)"
    show "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =HIDDENR1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
    proof-
      have cases: "p1 inTARSKIR2 rngFUNCT-1K2 f or  not p1 inTARSKIR2 rngFUNCT-1K2 f"
         sorry
      have case1: "p1 inTARSKIR2 rngFUNCT-1K2 f implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =HIDDENR1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
      proof(rule impI)
        assume A2: "p1 inTARSKIR2 rngFUNCT-1K2 f"
        then have A3: "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1) =FINSEQ-1R1 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using finseq_6_def_2 sorry
        have A4: "p1 ..FINSEQ-4K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1) =XBOOLE-0R4 \<one>\<^sub>M"
          using finseq_6_th_79 sorry
        have "rngFUNCT-1K2 ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) c=TARSKIR1 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)"
          using finseq_5_th_33 sorry
        then have A5: " not p2 inTARSKIR2 rngFUNCT-1K2 ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using A1 xboole_0_def_5 sorry
        have A6: "rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) c=TARSKIR1 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1))"
          using finseq_6_th_101 sorry
        have A7: "f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1 <>HIDDENR2 {}XBOOLE-0K1"
          using A2 finseq_5_th_47 sorry
        have A8: " not p2 inTARSKIR2 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)"
          using A1 xboole_0_def_5 sorry
        have "p1 ..FINSEQ-4K4 f <=XXREAL-0R1 p1 ..FINSEQ-4K4 f"
           sorry
        then have A9: "p1 <>HIDDENR2 p2"
          using A2 A8 finseq_5_th_46 sorry
        have "rngFUNCT-1K2 f =XBOOLE-0R4 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1) \\/XBOOLE-0K2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)"
          using A2 finseq_6_th_70 sorry
        then have A10: "p2 inTARSKIR2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)"
          using A1 A8 xboole_0_def_3 sorry
        have "p1 inTARSKIR2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)"
          using finseq_6_th_61 sorry
        then have A11: "p2 ..FINSEQ-4K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1) <>HIDDENR2 \<one>\<^sub>M"
          using A10 A9 A4 finseq_5_th_9 sorry
        then have "p2 inTARSKIR2 rngFUNCT-1K2 ((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using A10 finseq_6_th_78 sorry
        then have A12: "p2 inTARSKIR2 rngFUNCT-1K2 ((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) \\SUBSET-1K6 rngFUNCT-1K2 ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using A5 xboole_0_def_5 sorry
        have A13: "p2 ..FINSEQ-4K4 f =XBOOLE-0R4 \<one>\<^sub>M implies  False "
        proof(rule impI)
          assume "p2 ..FINSEQ-4K4 f =XBOOLE-0R4 \<one>\<^sub>M"
          then have "p2 ..FINSEQ-4K4 f <=XXREAL-0R1 p1 ..FINSEQ-4K4 f"
            using A2 finseq_4_th_21 sorry
          thus " False "
            using A1 A2 A8 finseq_5_th_46 sorry
        qed
        then have "p2 inTARSKIR2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using A1 finseq_6_th_78 sorry
        then have "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =HIDDENR1 (((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)):-FINSEQ-5K2\<^bsub>(D)\<^esub> p2)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M))-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using A3 A6 finseq_6_def_2 sorry
        also have "... = (((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1):-FINSEQ-5K2\<^bsub>(D)\<^esub> p2)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M))^FINSEQ-1K9\<^bsub>(D)\<^esub> ((((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M))-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using A10 finseq_6_th_64 sorry
        also have "... = ((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p2)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M))^FINSEQ-1K9\<^bsub>(D)\<^esub> ((((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M))-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using A1 A2 finseq_6_th_71 sorry
        also have "... = ((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p2)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M))^FINSEQ-1K9\<^bsub>(D)\<^esub> (((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using A10 finseq_6_th_66 sorry
        also have "... = ((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p2)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M))^FINSEQ-1K9\<^bsub>(D)\<^esub> (((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2)"
          using A10 A11 finseq_6_th_60 sorry
        also have "... = (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p2)^FINSEQ-1K9\<^bsub>(D)\<^esub> (((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)^FINSEQ-1K9\<^bsub>(D)\<^esub> (((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2))"
          using finseq_1_th_32 sorry
        also have "... = (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p2)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M))-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2)"
          using A12 finseq_6_th_67 sorry
        also have "... = (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p2)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M))/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2)"
          using A7 finseq_6_th_77 sorry
        also have "... = (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p2)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2)"
          using A2 finseq_6_th_76 sorry
        also have "... = (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p2)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p2)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using A1 A13 finseq_6_th_60 sorry
        also have "... = RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
          using A1 finseq_6_def_2 sorry
        finally show "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =HIDDENR1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
           sorry
      qed
      have case2: " not p1 inTARSKIR2 rngFUNCT-1K2 f implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
      proof(rule impI)
        assume " not p1 inTARSKIR2 rngFUNCT-1K2 f"
        thus "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
          using finseq_6_def_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_103:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p2 ..FINSEQ-4K4 f <>HIDDENR2 \<one>\<^sub>M & p2 inTARSKIR2 rngFUNCT-1K2 f \\SUBSET-1K6 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1) implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p2 ..FINSEQ-4K4 f <>HIDDENR2 \<one>\<^sub>M & p2 inTARSKIR2 rngFUNCT-1K2 f \\SUBSET-1K6 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1) implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =HIDDENR1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p1 assume [ty]: "p1 be ElementSUBSET-1M1-of D"
    fix p2 assume [ty]: "p2 be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p2 ..FINSEQ-4K4 f <>HIDDENR2 \<one>\<^sub>M"
      and A2: "p2 inTARSKIR2 rngFUNCT-1K2 f \\SUBSET-1K6 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)"
    show "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =HIDDENR1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
    proof-
      have cases: "p1 inTARSKIR2 rngFUNCT-1K2 f or  not p1 inTARSKIR2 rngFUNCT-1K2 f"
         sorry
      have case1: "p1 inTARSKIR2 rngFUNCT-1K2 f implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =HIDDENR1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
      proof(rule impI)
        assume A3: "p1 inTARSKIR2 rngFUNCT-1K2 f"
        then have A4: "f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1 <>HIDDENR2 {}XBOOLE-0K1"
          using finseq_5_th_47 sorry
        have A5: " not p2 inTARSKIR2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)"
          using A2 xboole_0_def_5 sorry
        have "rngFUNCT-1K2 f =XBOOLE-0R4 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1) \\/XBOOLE-0K2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)"
          using A3 finseq_6_th_70 sorry
        then have A6: "p2 inTARSKIR2 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)"
          using A2 A5 xboole_0_def_3 sorry
        have "(f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) =FINSEQ-1R1 f"
          using A3 finseq_6_th_76 sorry
        then have A7: "p2 ..FINSEQ-4K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1) <>HIDDENR2 \<one>\<^sub>M"
          using A1 A6 finseq_6_th_6 sorry
        then have A8: "p2 inTARSKIR2 rngFUNCT-1K2 ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using A6 finseq_6_th_78 sorry
        then have A9: "p2 inTARSKIR2 rngFUNCT-1K2 ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) \\SUBSET-1K6 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)"
          using A5 xboole_0_def_5 sorry
        have A10: "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1) =FINSEQ-1R1 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using A3 finseq_6_def_2 sorry
        then have "rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1)) =XBOOLE-0R4 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1) \\/XBOOLE-0K2 rngFUNCT-1K2 ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using finseq_1_th_31 sorry
        then have "p2 inTARSKIR2 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1))"
          using A8 xboole_0_def_3 sorry
        then have "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =HIDDENR1 (((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)):-FINSEQ-5K2\<^bsub>(D)\<^esub> p2)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M))-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using A10 finseq_6_def_2 sorry
        also have "... = (((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M):-FINSEQ-5K2\<^bsub>(D)\<^esub> p2)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M))-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using A9 finseq_6_th_65 sorry
        also have "... = (((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M):-FINSEQ-5K2\<^bsub>(D)\<^esub> p2)^FINSEQ-1K9\<^bsub>(D)\<^esub> (((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)^FINSEQ-1K9\<^bsub>(D)\<^esub> (((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2))/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using A9 finseq_6_th_67 sorry
        also have "... = (((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M):-FINSEQ-5K2\<^bsub>(D)\<^esub> p2)^FINSEQ-1K9\<^bsub>(D)\<^esub> (((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)^FINSEQ-1K9\<^bsub>(D)\<^esub> (((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2))"
          using finseq_6_th_77 sorry
        also have "... = ((((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M):-FINSEQ-5K2\<^bsub>(D)\<^esub> p2)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M))^FINSEQ-1K9\<^bsub>(D)\<^esub> (((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2)"
          using finseq_1_th_32 sorry
        also have "... = ((((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)):-FINSEQ-5K2\<^bsub>(D)\<^esub> p2)^FINSEQ-1K9\<^bsub>(D)\<^esub> (((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2)"
          using A8 finseq_6_th_64 sorry
        also have "... = ((((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M))/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M):-FINSEQ-5K2\<^bsub>(D)\<^esub> p2)^FINSEQ-1K9\<^bsub>(D)\<^esub> (((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2)"
          using A4 finseq_6_th_77 sorry
        also have "... = ((f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M):-FINSEQ-5K2\<^bsub>(D)\<^esub> p2)^FINSEQ-1K9\<^bsub>(D)\<^esub> (((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2)"
          using A3 finseq_6_th_76 sorry
        also have "... = (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p2)^FINSEQ-1K9\<^bsub>(D)\<^esub> (((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2)"
          using A1 A2 finseq_6_th_83 sorry
        also have "... = (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p2)^FINSEQ-1K9\<^bsub>(D)\<^esub> (((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using A6 A7 finseq_6_th_60 sorry
        also have "... = (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p2)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p2)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using A3 A6 finseq_6_th_75 sorry
        also have "... = RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
          using A2 finseq_6_def_2 sorry
        finally show "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =HIDDENR1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
           sorry
      qed
      have case2: " not p1 inTARSKIR2 rngFUNCT-1K2 f implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
      proof(rule impI)
        assume " not p1 inTARSKIR2 rngFUNCT-1K2 f"
        thus "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
          using finseq_6_def_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_104:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p2 inTARSKIR2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) & f just-once-valuesFINSEQ-4R2 p2 implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p2 inTARSKIR2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) & f just-once-valuesFINSEQ-4R2 p2 implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p1 assume [ty]: "p1 be ElementSUBSET-1M1-of D"
    fix p2 assume [ty]: "p2 be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    show "p2 inTARSKIR2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) & f just-once-valuesFINSEQ-4R2 p2 implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
    proof-
      have cases: "p1 inTARSKIR2 rngFUNCT-1K2 f or  not p1 inTARSKIR2 rngFUNCT-1K2 f"
         sorry
      have case1: "p1 inTARSKIR2 rngFUNCT-1K2 f implies (p2 inTARSKIR2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) & f just-once-valuesFINSEQ-4R2 p2 implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2))"
      proof(rule impI,rule impMI ,rule impI)
        assume A1: "p1 inTARSKIR2 rngFUNCT-1K2 f"
        assume A2: "p2 inTARSKIR2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          and A3: "f just-once-valuesFINSEQ-4R2 p2"
        have "f =FINSEQ-1R1 ((f -|FINSEQ-4K5 p1)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>))^FINSEQ-1K8 (f  |--FINSEQ-4K6 p1)"
          using A1 finseq_4_th_51 sorry
        then have A4: "p2 inTARSKIR2 rngFUNCT-1K2 ((f -|FINSEQ-4K5 p1)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)) \\+\\XBOOLE-0K5 rngFUNCT-1K2 (f  |--FINSEQ-4K6 p1)"
          using A3 finseq_6_th_16 sorry
        have A5: "(p2 inTARSKIR2 rngFUNCT-1K2 ((f -|FINSEQ-4K5 p1)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)) &  not p2 inTARSKIR2 rngFUNCT-1K2 (f  |--FINSEQ-4K6 p1)) & (p2 inTARSKIR2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1) implies p1 =XBOOLE-0R4 p2) or  not p2 inTARSKIR2 rngFUNCT-1K2 ((f -|FINSEQ-4K5 p1)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)) & ( not p2 inTARSKIR2 rngFUNCT-1K2 ((f -|FINSEQ-4K5 p1)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)) implies  not p2 inTARSKIR2 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1))"
        proof-
          show "(p2 inTARSKIR2 rngFUNCT-1K2 ((f -|FINSEQ-4K5 p1)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)) &  not p2 inTARSKIR2 rngFUNCT-1K2 (f  |--FINSEQ-4K6 p1)) & (p2 inTARSKIR2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1) implies p1 =XBOOLE-0R4 p2) or  not p2 inTARSKIR2 rngFUNCT-1K2 ((f -|FINSEQ-4K5 p1)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)) & ( not p2 inTARSKIR2 rngFUNCT-1K2 ((f -|FINSEQ-4K5 p1)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)) implies  not p2 inTARSKIR2 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1))"
          proof-
            have cases: "p2 inTARSKIR2 rngFUNCT-1K2 ((f -|FINSEQ-4K5 p1)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)) &  not p2 inTARSKIR2 rngFUNCT-1K2 (f  |--FINSEQ-4K6 p1) or  not p2 inTARSKIR2 rngFUNCT-1K2 ((f -|FINSEQ-4K5 p1)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>))"
              using A4 xboole_0_th_1 sorry
            have case1: "p2 inTARSKIR2 rngFUNCT-1K2 ((f -|FINSEQ-4K5 p1)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)) &  not p2 inTARSKIR2 rngFUNCT-1K2 (f  |--FINSEQ-4K6 p1) implies (p2 inTARSKIR2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1) implies p1 =XBOOLE-0R4 p2)"
            proof(rule impMI ,rule impI)
              assume "p2 inTARSKIR2 rngFUNCT-1K2 ((f -|FINSEQ-4K5 p1)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>))"
                and A6: " not p2 inTARSKIR2 rngFUNCT-1K2 (f  |--FINSEQ-4K6 p1)"
              have " not p2 inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>) &  not p2 inTARSKIR2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1) or p2 inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>) & (p2 inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>) implies p2 =XBOOLE-0R4 p1)"
              proof-
                show " not p2 inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>) &  not p2 inTARSKIR2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1) or p2 inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>) & (p2 inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>) implies p2 =XBOOLE-0R4 p1)"
                proof-
                  have cases: " not p2 inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>) or p2 inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)"
                     sorry
                  have case1: " not p2 inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>) implies  not p2 inTARSKIR2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)"
                  proof(rule impI)
                    assume " not p2 inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)"
                    then have " not p2 inTARSKIR2 rngFUNCT-1K2 (f  |--FINSEQ-4K6 p1) \\/XBOOLE-0K2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)"
                      using A6 xboole_0_def_3 sorry
                    then have " not p2 inTARSKIR2 rngFUNCT-1K2 ((<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)^FINSEQ-1K8 (f  |--FINSEQ-4K6 p1))"
                      using finseq_1_th_31 sorry
                    thus " not p2 inTARSKIR2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)"
                      using A1 finseq_6_th_41 sorry
                  qed
                  have case2: "p2 inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>) implies p2 =XBOOLE-0R4 p1"
                  proof(rule impI)
                    assume "p2 inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)"
                    then have "p2 inTARSKIR2 {TARSKIK1 p1}"
                      using finseq_1_th_39 sorry
                    thus "p2 =XBOOLE-0R4 p1"
                      using tarski_def_1 sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed
              thus "p2 inTARSKIR2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1) implies p1 =XBOOLE-0R4 p2"
                 sorry
            qed
            have case2: " not p2 inTARSKIR2 rngFUNCT-1K2 ((f -|FINSEQ-4K5 p1)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)) implies  not p2 inTARSKIR2 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)"
            proof(rule impI)
              assume " not p2 inTARSKIR2 rngFUNCT-1K2 ((f -|FINSEQ-4K5 p1)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>))"
              thus " not p2 inTARSKIR2 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)"
                using A1 finseq_6_th_40 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        have A7: "p2 inTARSKIR2 rngFUNCT-1K2 f"
          using A3 finseq_4_th_5 sorry
        then have "f =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using finseq_5_th_29 relat_1_th_38 sorry
        then have "p2 inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M*>) \\+\\XBOOLE-0K5 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using A3 finseq_6_th_16 sorry
        then have " not p2 inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M*>)"
          using A2 xboole_0_th_1 sorry
        then have " not p2 inTARSKIR2 {TARSKIK1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M }"
          using finseq_1_th_39 sorry
        then have "p2 <>HIDDENR2 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
          using tarski_def_1 sorry
        then have A8: "p2 ..FINSEQ-4K4 f <>HIDDENR2 \<one>\<^sub>M"
          using A7 finseq_5_th_38 sorry
        have "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
        proof-
          show "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
          proof-
            have cases: "(p1 =XBOOLE-0R4 p2 or p2 inTARSKIR2 rngFUNCT-1K2 f \\SUBSET-1K6 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)) or p2 inTARSKIR2 rngFUNCT-1K2 f \\SUBSET-1K6 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)"
              using A7 A5 xboole_0_def_5 sorry
            have case1: "p1 =XBOOLE-0R4 p2 implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
            proof(rule impI)
              assume "p1 =XBOOLE-0R4 p2"
              thus "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
                using finseq_6_th_93 sorry
            qed
            have case2: "p2 inTARSKIR2 rngFUNCT-1K2 f \\SUBSET-1K6 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1) implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
            proof(rule impI)
              assume "p2 inTARSKIR2 rngFUNCT-1K2 f \\SUBSET-1K6 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)"
              thus "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
                using finseq_6_th_102 sorry
            qed
            have case3: "p2 inTARSKIR2 rngFUNCT-1K2 f \\SUBSET-1K6 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1) implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
            proof(rule impI)
              assume "p2 inTARSKIR2 rngFUNCT-1K2 f \\SUBSET-1K6 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1)"
              thus "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
                using A8 finseq_6_th_103 sorry
            qed
            show " ?thesis "
              using cases case1 case2 case3 sorry
          qed
        qed
        thus "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
           sorry
      qed
      have case2: " not p1 inTARSKIR2 rngFUNCT-1K2 f implies  not ((p2 inTARSKIR2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) & f just-once-valuesFINSEQ-4R2 p2) &  not RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2))"
      proof(rule impI)
        assume " not p1 inTARSKIR2 rngFUNCT-1K2 f"
        thus " not ((p2 inTARSKIR2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) & f just-once-valuesFINSEQ-4R2 p2) &  not RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2))"
          using finseq_6_def_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_105:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds f be circularFINSEQ-6V1\<^bsub>(D)\<^esub> & f just-once-valuesFINSEQ-4R2 p2 implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds f be circularFINSEQ-6V1\<^bsub>(D)\<^esub> & f just-once-valuesFINSEQ-4R2 p2 implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p1 assume [ty]: "p1 be ElementSUBSET-1M1-of D"
    fix p2 assume [ty]: "p2 be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    show "f be circularFINSEQ-6V1\<^bsub>(D)\<^esub> & f just-once-valuesFINSEQ-4R2 p2 implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
    proof-
      have cases: "p1 inTARSKIR2 rngFUNCT-1K2 f or  not p1 inTARSKIR2 rngFUNCT-1K2 f"
         sorry
      have case1: "p1 inTARSKIR2 rngFUNCT-1K2 f implies (f be circularFINSEQ-6V1\<^bsub>(D)\<^esub> & f just-once-valuesFINSEQ-4R2 p2 implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2))"
      proof(rule impI,rule impMI ,rule impI)
        assume A1: "p1 inTARSKIR2 rngFUNCT-1K2 f"
        assume A2: "f be circularFINSEQ-6V1\<^bsub>(D)\<^esub>"
          and A3: "f just-once-valuesFINSEQ-4R2 p2"
        have A4: "p2 inTARSKIR2 rngFUNCT-1K2 f"
          using A3 finseq_4_th_45 sorry
        have "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
        proof-
          show "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
          proof-
            have cases: "rngFUNCT-1K2 f be trivialZFMISC-1V1 or  not rngFUNCT-1K2 f be trivialZFMISC-1V1"
               sorry
            have case1: "rngFUNCT-1K2 f be trivialZFMISC-1V1 implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
            proof(rule impI)
              assume "rngFUNCT-1K2 f be trivialZFMISC-1V1"
              then have "p1 =XBOOLE-0R4 p2"
                using A1 A4 zfmisc_1_def_10 sorry
              thus "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
                using finseq_6_th_93 sorry
            qed
            have case2: " not rngFUNCT-1K2 f be trivialZFMISC-1V1 implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
            proof(rule impI)
              assume A5: " not rngFUNCT-1K2 f be trivialZFMISC-1V1"
              then have "f =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
                using finseq_5_th_29 relat_1_th_38 sorry
              then have A6: "rngFUNCT-1K2 f =XBOOLE-0R4 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M*>) \\/XBOOLE-0K2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
                using finseq_1_th_31 sorry
              have " not p2 inTARSKIR2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) implies  False "
              proof(rule impI)
                have "f be  non trivialZFMISC-1V1"
                  using A5 sorry
                then have "lenFINSEQ-1K4 f >=XXREAL-0R2 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
                  using nat_d_th_60 sorry
                then have A7: "\<one>\<^sub>M <XXREAL-0R3 lenFINSEQ-1K4 f"
                  using nat_1_th_13 sorry
                assume A8: " not p2 inTARSKIR2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
                then have "p2 inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M*>)"
                  using A4 A6 xboole_0_def_3 sorry
                then have "p2 inTARSKIR2 {TARSKIK1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M }"
                  using finseq_1_th_39 sorry
                then have "p2 =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
                  using tarski_def_1 sorry
                then have A9: "p2 =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f"
                  using A2 sorry
                have "lenFINSEQ-1K4 f inTARSKIR2 domFINSEQ-1K5 f"
                  using A5 finseq_5_th_6 relat_1_th_38 sorry
                thus " False "
                  using A8 A9 A7 finseq_6_th_58 sorry
              qed
              thus "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
                using A3 finseq_6_th_104 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
           sorry
      qed
      have case2: " not p1 inTARSKIR2 rngFUNCT-1K2 f implies  not ((f be circularFINSEQ-6V1\<^bsub>(D)\<^esub> & f just-once-valuesFINSEQ-4R2 p2) &  not RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2))"
      proof(rule impI)
        assume " not p1 inTARSKIR2 rngFUNCT-1K2 f"
        thus " not ((f be circularFINSEQ-6V1\<^bsub>(D)\<^esub> & f just-once-valuesFINSEQ-4R2 p2) &  not RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2))"
          using finseq_6_def_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_106:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds f be circularFINSEQ-6V1\<^bsub>(D)\<^esub> & f just-once-valuesFINSEQ-4R2 p implies RevFINSEQ-5K4\<^bsub>(D)\<^esub> (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RevFINSEQ-5K4\<^bsub>(D)\<^esub> f,p)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds f be circularFINSEQ-6V1\<^bsub>(D)\<^esub> & f just-once-valuesFINSEQ-4R2 p implies RevFINSEQ-5K4\<^bsub>(D)\<^esub> (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)) =HIDDENR1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RevFINSEQ-5K4\<^bsub>(D)\<^esub> f,p)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "f be circularFINSEQ-6V1\<^bsub>(D)\<^esub>"
      and A2: "f just-once-valuesFINSEQ-4R2 p"
    obtain j where 
      [ty]:"j be ElementSUBSET-1M1-of NATNUMBERSK1" and jDef:"j = lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) -XCMPLX-0K6 \<one>\<^sub>M"
      using int_1_th_5 nat_1_th_14 sorry
    have A3: "f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f"
      using A1 sorry
    have A4: "p inTARSKIR2 rngFUNCT-1K2 f"
      using A2 finseq_4_th_45 sorry
    then have A5: "f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p =HIDDENR1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
      using finseq_5_th_29 finseq_5_th_47 sorry
    also have "... = (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
      using A4 finseq_5_th_44 sorry
    finally have "f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p =HIDDENR1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
       sorry
    have A6: "j +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
       sorry
    then have A7: "f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p =HIDDENR1 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) |FINSEQ-1K18\<^bsub>(D)\<^esub> j ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)*>)"
      using finseq_5_th_21 sorry
    also have "... = (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) |FINSEQ-1K18\<^bsub>(D)\<^esub> j ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f*>)"
      using A4 finseq_5_th_54 sorry
    finally have "f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p =HIDDENR1 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) |FINSEQ-1K18\<^bsub>(D)\<^esub> j ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f*>)"
       sorry
    have A8: "p inTARSKIR2 rngFUNCT-1K2 (RevFINSEQ-5K4\<^bsub>(D)\<^esub> f)"
      using A4 finseq_5_th_57 sorry
    have "RevFINSEQ-5K4\<^bsub>(D)\<^esub> (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)) =HIDDENR1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> ((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M))"
      using A4 finseq_6_def_2 sorry
    also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) ^FINSEQ-1K9\<^bsub>(D)\<^esub> RevFINSEQ-5K4\<^bsub>(D)\<^esub> (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
      using finseq_5_th_64 sorry
    also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) ^FINSEQ-1K9\<^bsub>(D)\<^esub> ((<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> RevFINSEQ-5K4\<^bsub>(D)\<^esub> ((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) |FINSEQ-1K18\<^bsub>(D)\<^esub> j))"
      using A7 finseq_5_th_63 sorry
    also have "... = (RevFINSEQ-5K4\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M*>))^FINSEQ-1K9\<^bsub>(D)\<^esub> RevFINSEQ-5K4\<^bsub>(D)\<^esub> ((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) |FINSEQ-1K18\<^bsub>(D)\<^esub> j)"
      using A3 finseq_1_th_32 sorry
    also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) ^FINSEQ-1K9\<^bsub>(D)\<^esub> RevFINSEQ-5K4\<^bsub>(D)\<^esub> ((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) |FINSEQ-1K18\<^bsub>(D)\<^esub> j)"
      using A5 finseq_6_th_24 sorry
    also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) ^FINSEQ-1K9\<^bsub>(D)\<^esub> (RevFINSEQ-5K4\<^bsub>(D)\<^esub> (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
      using A6 finseq_6_th_85 sorry
    also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) ^FINSEQ-1K9\<^bsub>(D)\<^esub> ((RevFINSEQ-5K4\<^bsub>(D)\<^esub> f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
      using A2 finseq_6_th_87 sorry
    also have "... = (RevFINSEQ-5K4\<^bsub>(D)\<^esub> f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((RevFINSEQ-5K4\<^bsub>(D)\<^esub> f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
      using A2 finseq_6_th_88 sorry
    also have "... = RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RevFINSEQ-5K4\<^bsub>(D)\<^esub> f,p)"
      using A8 finseq_6_def_2 sorry
    finally show "RevFINSEQ-5K4\<^bsub>(D)\<^esub> (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)) =HIDDENR1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RevFINSEQ-5K4\<^bsub>(D)\<^esub> f,p)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem finseq_6_th_107:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be trivialZFMISC-1V1\<bar>FinSequenceFINSEQ-1M3-of D holds f be emptyXBOOLE-0V1 or ( ex x be ElementSUBSET-1M1-of D st f =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> x*>)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be trivialZFMISC-1V1\<bar>FinSequenceFINSEQ-1M3-of D holds f be  non emptyXBOOLE-0V1 implies ( ex tVar3 be ElementSUBSET-1M1-of D st tVar3 be ElementSUBSET-1M1-of D & f =FINSEQ-1R1 <*FINSEQ-1K10 tVar3*>)"
  proof(rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be trivialZFMISC-1V1\<bar>FinSequenceFINSEQ-1M3-of D"
    have A1: "rngFUNCT-1K2 f c=TARSKIR1 D"
      using finseq_1_def_4 sorry
    assume "f be  non emptyXBOOLE-0V1"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A2: "f =XBOOLE-0R4 {TARSKIK1 x}"
      using zfmisc_1_th_131 sorry
    have A3: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
      using A2 finseq_5_th_6 sorry
    have A4: "x inHIDDENR3 {TARSKIK1 x}"
      using tarski_def_1 sorry
    then obtain y z where
      [ty]:"y be objectHIDDENM1" "z be objectHIDDENM1" and 
      A5: "x =HIDDENR1 [TARSKIK4 y,z ]"
      using A2 relat_1_def_1 sorry
    have 
      [ty]:"z be setHIDDENM2"
      using tarski_th_1 sorry
    show " ex tVar3 be ElementSUBSET-1M1-of D st tVar3 be ElementSUBSET-1M1-of D & f =FINSEQ-1R1 <*FINSEQ-1K10 tVar3*>"
    proof(rule bexI[of _ "z"],rule conjMI)
      have "z inTARSKIR2 rngFUNCT-1K2 f"
        using A2 A4 A5 xtuple_0_def_13 sorry
      thus "z be ElementSUBSET-1M1-of D"
        using A1 sorry
      have "domFINSEQ-1K5 f =XBOOLE-0R4 {TARSKIK1 y}"
        using A2 A5 relat_1_th_9 sorry
      then have "\<one>\<^sub>M =HIDDENR1 y"
        using A3 tarski_def_1 sorry
      thus "f =FINSEQ-1R1 <*FINSEQ-1K10 z*>"
        using A2 A5 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
reserve D for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
mtheorem finseq_6_th_108:
" for i be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 p <XXREAL-0R3 i & (i <=XXREAL-0R1 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q or i <=XXREAL-0R1 lenFINSEQ-1K4 (p ^FINSEQ-1K8 q)) implies (p ^FINSEQ-1K8 q).FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 (i -XCMPLX-0K6 lenFINSEQ-1K4 p)"
proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix i assume [ty]: "i be NatNAT-1M1"
  fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
  fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
  assume A1: "lenFINSEQ-1K4 p <XXREAL-0R3 i"
    and A2: "i <=XXREAL-0R1 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q or i <=XXREAL-0R1 lenFINSEQ-1K4 (p ^FINSEQ-1K8 q)"
  have "i <=XXREAL-0R1 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q"
    using A2 finseq_1_th_22 sorry
  then have A3: "i -XCMPLX-0K6 lenFINSEQ-1K4 p <=XXREAL-0R1 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q)-XCMPLX-0K6 lenFINSEQ-1K4 p"
    using xreal_1_th_9 sorry
  have "lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i"
    using A1 nat_1_th_13 sorry
  then have A4: "(lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 lenFINSEQ-1K4 p <=XXREAL-0R1 i -XCMPLX-0K6 lenFINSEQ-1K4 p"
    using xreal_1_th_9 sorry
  then have A5: "lenFINSEQ-1K4 p +NAT-1K1 (i -'NAT-DK9 lenFINSEQ-1K4 p) =HIDDENR1 lenFINSEQ-1K4 p +XCMPLX-0K2 (i -XCMPLX-0K6 lenFINSEQ-1K4 p)"
    using xreal_0_def_2 sorry
  also have "... = i"
     sorry
  finally have "lenFINSEQ-1K4 p +NAT-1K1 (i -'NAT-DK9 lenFINSEQ-1K4 p) =HIDDENR1 i"
     sorry
  have "i -XCMPLX-0K6 lenFINSEQ-1K4 p =XBOOLE-0R4 i -'NAT-DK9 lenFINSEQ-1K4 p"
    using A4 xreal_0_def_2 sorry
  then have "i -'NAT-DK9 lenFINSEQ-1K4 p inTARSKIR2 domFINSEQ-1K5 q"
    using A4 A3 finseq_3_th_25 sorry
  thus "(p ^FINSEQ-1K8 q).FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 (i -XCMPLX-0K6 lenFINSEQ-1K4 p)"
    using A5 finseq_1_def_7 sorry
qed "sorry"

mtheorem finseq_6_th_109:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f implies (((f ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 f .FUNCT-1K1 \<one>\<^sub>M & (f ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M) & ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 f).FUNCT-1K1 (lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 lenFINSEQ-1K4 f) & ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 f).FUNCT-1K1 (lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f implies (((f ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 f .FUNCT-1K1 \<one>\<^sub>M & (f ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M) & ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 f).FUNCT-1K1 (lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 lenFINSEQ-1K4 f) & ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 f).FUNCT-1K1 (lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix x assume [ty]: "x be setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
    then have A2: "lenFINSEQ-1K4 f inTARSKIR2 domFINSEQ-1K5 f"
      using finseq_3_th_25 sorry
    have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
      using A1 finseq_3_th_25 sorry
    then have A3: "(f ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 f .FUNCT-1K1 \<one>\<^sub>M"
      using finseq_1_def_7 sorry
    have "((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 f).FUNCT-1K1 (lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 f).FUNCT-1K1 (lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>) +NAT-1K1 lenFINSEQ-1K4 f)"
      using finseq_1_th_39 sorry
    also have "... = f .FUNCT-1K1 lenFINSEQ-1K4 f"
      using A2 finseq_1_def_7 sorry
    finally have "((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 f).FUNCT-1K1 (lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 f .FUNCT-1K1 lenFINSEQ-1K4 f"
       sorry
    thus "(((f ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 f .FUNCT-1K1 \<one>\<^sub>M & (f ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M) & ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 f).FUNCT-1K1 (lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 lenFINSEQ-1K4 f) & ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 f).FUNCT-1K1 (lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f"
      using A1 A3 finseq_4_th_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_110:
" for f be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 f =XBOOLE-0R4 \<one>\<^sub>M implies RevFINSEQ-5K3 f =FINSEQ-1R1 f"
proof(rule ballI,rule impI)
  fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
  assume "lenFINSEQ-1K4 f =XBOOLE-0R4 \<one>\<^sub>M"
  then have "f =FINSEQ-1R1 <*FINSEQ-1K10 f .FUNCT-1K1 \<one>\<^sub>M*>"
    using finseq_1_th_40 sorry
  thus "RevFINSEQ-5K3 f =FINSEQ-1R1 f"
    using finseq_5_th_60 sorry
qed "sorry"

mtheorem finseq_6_th_111:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for k be NatNAT-1M1 holds lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k) =XBOOLE-0R4 lenFINSEQ-1K4 f -'NAT-DK9 k"
  using rfinseq_th_29 sorry

mdef finseq_6_def_3 ("midFINSEQ-6K2'( _ , _ , _ ')" [0,0,0]164 ) where
  mlet "f be FinSequenceFINSEQ-1M1", "k1 be NatNAT-1M1", "k2 be NatNAT-1M1"
"func midFINSEQ-6K2(f,k1,k2) \<rightarrow> FinSequenceFINSEQ-1M1 equals
  (f /^RFINSEQK1 (k1 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M) if k1 <=XXREAL-0R1 k2 otherwise RevFINSEQ-5K3 ((f /^RFINSEQK1 (k2 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M))"
proof-
  (*coherence*)
    show "(k1 <=XXREAL-0R1 k2 implies (f /^RFINSEQK1 (k1 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M) be FinSequenceFINSEQ-1M1) & ( not k1 <=XXREAL-0R1 k2 implies RevFINSEQ-5K3 ((f /^RFINSEQK1 (k2 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M)) be FinSequenceFINSEQ-1M1)"
       sorry
  (*consistency*)
    show " for it be FinSequenceFINSEQ-1M1 holds  True "
       sorry
qed "sorry"

syntax FINSEQ_6K3 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("midFINSEQ-6K3\<^bsub>'( _ ')\<^esub>'( _ , _ , _ ')" [0,0,0,0]164)
translations "midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,k1,k2)" \<rightharpoonup> "midFINSEQ-6K2(f,k1,k2)"

mtheorem finseq_6_add_1:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FinSequenceFINSEQ-1M3-of D", "k1 be NatNAT-1M1", "k2 be NatNAT-1M1"
"cluster midFINSEQ-6K2(f,k1,k2) as-term-is FinSequenceFINSEQ-1M3-of D"
proof
(*coherence*)
  show "midFINSEQ-6K2(f,k1,k2) be FinSequenceFINSEQ-1M3-of D"
  proof-
    have "midFINSEQ-6K2(f,k1,k2) =FINSEQ-1R1 (f /^RFINSEQK2\<^bsub>(D)\<^esub> (k1 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K18\<^bsub>(D)\<^esub> ((k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M) or midFINSEQ-6K2(f,k1,k2) =FINSEQ-1R1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> ((f /^RFINSEQK2\<^bsub>(D)\<^esub> (k2 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K18\<^bsub>(D)\<^esub> ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M))"
      using finseq_6_def_3 sorry
    thus "midFINSEQ-6K2(f,k1,k2) be FinSequenceFINSEQ-1M3-of D"
       sorry
  qed
qed "sorry"

(*\$CT*)
mtheorem finseq_6_th_113:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds ((\<one>\<^sub>M <=XXREAL-0R1 k1 & k1 <=XXREAL-0R1 lenFINSEQ-1K4 f) & \<one>\<^sub>M <=XXREAL-0R1 k2) & k2 <=XXREAL-0R1 lenFINSEQ-1K4 f implies RevFINSEQ-5K4\<^bsub>(D)\<^esub> (midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,k1,k2)) =FINSEQ-1R1 midFINSEQ-6K3\<^bsub>(D)\<^esub>(RevFINSEQ-5K4\<^bsub>(D)\<^esub> f,(lenFINSEQ-1K4 f -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M,(lenFINSEQ-1K4 f -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k1 & (k1 <=XXREAL-0R1 lenFINSEQ-1K4 f & (\<one>\<^sub>M <=XXREAL-0R1 k2 & k2 <=XXREAL-0R1 lenFINSEQ-1K4 f)) implies RevFINSEQ-5K4\<^bsub>(D)\<^esub> (midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,k1,k2)) =FINSEQ-1R1 midFINSEQ-6K3\<^bsub>(D)\<^esub>(RevFINSEQ-5K4\<^bsub>(D)\<^esub> f,(lenFINSEQ-1K4 f -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M,(lenFINSEQ-1K4 f -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    fix k1 assume [ty]: "k1 be NatNAT-1M1"
    fix k2 assume [ty]: "k2 be NatNAT-1M1"
    assume A1: "\<one>\<^sub>M <=XXREAL-0R1 k1"
      and A2: "k1 <=XXREAL-0R1 lenFINSEQ-1K4 f"
      and A3: "\<one>\<^sub>M <=XXREAL-0R1 k2"
      and A4: "k2 <=XXREAL-0R1 lenFINSEQ-1K4 f"
    show "RevFINSEQ-5K4\<^bsub>(D)\<^esub> (midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,k1,k2)) =FINSEQ-1R1 midFINSEQ-6K3\<^bsub>(D)\<^esub>(RevFINSEQ-5K4\<^bsub>(D)\<^esub> f,(lenFINSEQ-1K4 f -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M,(lenFINSEQ-1K4 f -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M)"
    proof-
      have cases: "k1 <=XXREAL-0R1 k2 or k1 >XXREAL-0R4 k2"
         sorry
      have case1: "k1 <=XXREAL-0R1 k2 implies RevFINSEQ-5K4\<^bsub>(D)\<^esub> (midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,k1,k2)) =FINSEQ-1R1 midFINSEQ-6K3\<^bsub>(D)\<^esub>(RevFINSEQ-5K4\<^bsub>(D)\<^esub> f,(lenFINSEQ-1K4 f -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M,(lenFINSEQ-1K4 f -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M)"
      proof(rule impI)
        assume A5: "k1 <=XXREAL-0R1 k2"
        have A6: "lenFINSEQ-1K4 f -'NAT-DK9 (k1 -'NAT-DK9 \<one>\<^sub>M) =HIDDENR1 lenFINSEQ-1K4 f -XCMPLX-0K6 (k1 -'NAT-DK9 \<one>\<^sub>M)"
          using A2 nat_d_th_50 xreal_1_th_233 sorry
        also have "... = lenFINSEQ-1K4 f -XCMPLX-0K6 (k1 -XCMPLX-0K6 \<one>\<^sub>M)"
          using A1 xreal_1_th_233 sorry
        also have "... = (lenFINSEQ-1K4 f -XCMPLX-0K6 k1)+XCMPLX-0K2 \<one>\<^sub>M"
           sorry
        also have "... = (lenFINSEQ-1K4 f -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M"
          using A2 xreal_1_th_233 sorry
        finally have "lenFINSEQ-1K4 f -'NAT-DK9 (k1 -'NAT-DK9 \<one>\<^sub>M) =HIDDENR1 (lenFINSEQ-1K4 f -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M"
           sorry
        have A7: "lenFINSEQ-1K4 f -'NAT-DK9 k1 =XBOOLE-0R4 lenFINSEQ-1K4 f -XCMPLX-0K6 k1"
          using A2 xreal_1_th_233 sorry
        have A8: "lenFINSEQ-1K4 f -'NAT-DK9 k2 =XBOOLE-0R4 lenFINSEQ-1K4 f -XCMPLX-0K6 k2"
          using A4 xreal_1_th_233 sorry
        have "k2 -XCMPLX-0K6 k1 <=XXREAL-0R1 lenFINSEQ-1K4 f -XCMPLX-0K6 k1"
          using A4 xreal_1_th_9 sorry
        then have "k2 -'NAT-DK9 k1 <=XXREAL-0R1 lenFINSEQ-1K4 f -XCMPLX-0K6 k1"
          using A5 xreal_1_th_233 sorry
        then have "k2 -'NAT-DK9 k1 <=XXREAL-0R1 lenFINSEQ-1K4 f -'NAT-DK9 k1"
          using A2 xreal_1_th_233 sorry
        then have "(k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 (lenFINSEQ-1K4 f -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_6 sorry
        then have A9: "(lenFINSEQ-1K4 f -'NAT-DK9 (k1 -'NAT-DK9 \<one>\<^sub>M))-'NAT-DK9 ((k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((lenFINSEQ-1K4 f -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 ((k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M)"
          using A6 xreal_1_th_233 sorry
        also have "... = ((lenFINSEQ-1K4 f -XCMPLX-0K6 k1)+XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 ((k2 -XCMPLX-0K6 k1)+XCMPLX-0K2 \<one>\<^sub>M)"
          using A5 A7 xreal_1_th_233 sorry
        also have "... = ((lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M)-XCMPLX-0K6 k2"
           sorry
        also have "... = lenFINSEQ-1K4 f -'NAT-DK9 k2"
          using A4 xreal_1_th_233 sorry
        finally have "(lenFINSEQ-1K4 f -'NAT-DK9 (k1 -'NAT-DK9 \<one>\<^sub>M))-'NAT-DK9 ((k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M) =HIDDENR1 lenFINSEQ-1K4 f -'NAT-DK9 k2"
           sorry
        then have A10: "(lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> (k1 -'NAT-DK9 \<one>\<^sub>M)) -'NAT-DK9 ((k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M))+NAT-1K1 ((k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (lenFINSEQ-1K4 f -'NAT-DK9 k2)+NAT-1K1 ((k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M)"
          using rfinseq_th_29 sorry
        also have "... = (lenFINSEQ-1K4 f -XCMPLX-0K6 k2)+XCMPLX-0K2 ((k2 -XCMPLX-0K6 k1)+XCMPLX-0K2 \<one>\<^sub>M)"
          using A5 A8 xreal_1_th_233 sorry
        also have "... = lenFINSEQ-1K4 f -XCMPLX-0K6 (k1 -XCMPLX-0K6 \<one>\<^sub>M)"
           sorry
        also have "... = lenFINSEQ-1K4 f -XCMPLX-0K6 (k1 -'NAT-DK9 \<one>\<^sub>M)"
          using A1 xreal_1_th_233 sorry
        also have "... = lenFINSEQ-1K4 f -'NAT-DK9 (k1 -'NAT-DK9 \<one>\<^sub>M)"
          using A2 nat_d_th_50 xreal_1_th_233 sorry
        also have "... = lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> (k1 -'NAT-DK9 \<one>\<^sub>M))"
          using rfinseq_th_29 sorry
        finally have "(lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> (k1 -'NAT-DK9 \<one>\<^sub>M)) -'NAT-DK9 ((k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M))+NAT-1K1 ((k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M) =HIDDENR1 lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> (k1 -'NAT-DK9 \<one>\<^sub>M))"
           sorry
        have A11: "lenFINSEQ-1K4 f -'NAT-DK9 k1 <=XXREAL-0R1 (lenFINSEQ-1K4 f -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_11 sorry
        have "lenFINSEQ-1K4 f -'NAT-DK9 k1 >=XXREAL-0R2 lenFINSEQ-1K4 f -'NAT-DK9 k2"
          using A5 nat_d_th_41 sorry
        then have A12: "(lenFINSEQ-1K4 f -'NAT-DK9 (k1 -'NAT-DK9 \<one>\<^sub>M))-'NAT-DK9 (lenFINSEQ-1K4 f -'NAT-DK9 k2) =HIDDENR1 ((lenFINSEQ-1K4 f -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 (lenFINSEQ-1K4 f -'NAT-DK9 k2)"
          using A6 A11 xreal_1_th_233 xxreal_0_th_2 sorry
        also have "... = ((lenFINSEQ-1K4 f -XCMPLX-0K6 k1)+XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 (lenFINSEQ-1K4 f -XCMPLX-0K6 k2)"
          using A4 A7 xreal_1_th_233 sorry
        also have "... = (k2 -XCMPLX-0K6 k1)+XCMPLX-0K2 \<one>\<^sub>M"
           sorry
        also have "... = (k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M"
          using A5 xreal_1_th_233 sorry
        finally have "(lenFINSEQ-1K4 f -'NAT-DK9 (k1 -'NAT-DK9 \<one>\<^sub>M))-'NAT-DK9 (lenFINSEQ-1K4 f -'NAT-DK9 k2) =HIDDENR1 (k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M"
           sorry
        have A13: "(lenFINSEQ-1K4 f -'NAT-DK9 (k1 -'NAT-DK9 \<one>\<^sub>M))+NAT-1K1 (k1 -'NAT-DK9 \<one>\<^sub>M) =HIDDENR1 (lenFINSEQ-1K4 f -XCMPLX-0K6 (k1 -'NAT-DK9 \<one>\<^sub>M))+XCMPLX-0K2 (k1 -'NAT-DK9 \<one>\<^sub>M)"
          using A2 nat_d_th_50 xreal_1_th_233 sorry
        also have "... = lenFINSEQ-1K4 f"
           sorry
        finally have "(lenFINSEQ-1K4 f -'NAT-DK9 (k1 -'NAT-DK9 \<one>\<^sub>M))+NAT-1K1 (k1 -'NAT-DK9 \<one>\<^sub>M) =HIDDENR1 lenFINSEQ-1K4 f"
           sorry
        have "lenFINSEQ-1K4 f -'NAT-DK9 k1 >=XXREAL-0R2 lenFINSEQ-1K4 f -'NAT-DK9 k2"
          using A5 nat_d_th_41 sorry
        then have "(lenFINSEQ-1K4 f -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 (lenFINSEQ-1K4 f -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_6 sorry
        then have A14: "(((lenFINSEQ-1K4 f -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 ((lenFINSEQ-1K4 f -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M))+NAT-1K1 \<one>\<^sub>M =HIDDENR1 (((lenFINSEQ-1K4 f -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 ((lenFINSEQ-1K4 f -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<one>\<^sub>M"
          using xreal_1_th_233 sorry
        also have "... = (((lenFINSEQ-1K4 f -XCMPLX-0K6 k1)+XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 ((lenFINSEQ-1K4 f -XCMPLX-0K6 k2)+XCMPLX-0K2 \<one>\<^sub>M))+XCMPLX-0K2 \<one>\<^sub>M"
          using A4 A7 xreal_1_th_233 sorry
        also have "... = (k2 -XCMPLX-0K6 k1)+XCMPLX-0K2 \<one>\<^sub>M"
           sorry
        also have "... = (k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M"
          using A5 xreal_1_th_233 sorry
        finally have "(((lenFINSEQ-1K4 f -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 ((lenFINSEQ-1K4 f -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M))+NAT-1K1 \<one>\<^sub>M =HIDDENR1 (k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M"
           sorry
        have "lenFINSEQ-1K4 f -'NAT-DK9 k1 >=XXREAL-0R2 lenFINSEQ-1K4 f -'NAT-DK9 k2"
          using A5 nat_d_th_41 sorry
        then have "(lenFINSEQ-1K4 f -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 (lenFINSEQ-1K4 f -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_6 sorry
        then have "midFINSEQ-6K3\<^bsub>(D)\<^esub>(RevFINSEQ-5K4\<^bsub>(D)\<^esub> f,(lenFINSEQ-1K4 f -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M,(lenFINSEQ-1K4 f -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (RevFINSEQ-5K4\<^bsub>(D)\<^esub> f /^RFINSEQK2\<^bsub>(D)\<^esub> (((lenFINSEQ-1K4 f -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K18\<^bsub>(D)\<^esub> ((k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M)"
          using A14 finseq_6_def_3 sorry
        also have "... = (RevFINSEQ-5K4\<^bsub>(D)\<^esub> f /^RFINSEQK2\<^bsub>(D)\<^esub> (lenFINSEQ-1K4 f -'NAT-DK9 k2)) |FINSEQ-1K18\<^bsub>(D)\<^esub> ((lenFINSEQ-1K4 f -'NAT-DK9 (k1 -'NAT-DK9 \<one>\<^sub>M))-'NAT-DK9 (lenFINSEQ-1K4 f -'NAT-DK9 k2))"
          using A12 nat_d_th_34 sorry
        also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> f  |FINSEQ-1K18\<^bsub>(D)\<^esub> (lenFINSEQ-1K4 f -'NAT-DK9 (k1 -'NAT-DK9 \<one>\<^sub>M)) /^RFINSEQK2\<^bsub>(D)\<^esub> (lenFINSEQ-1K4 f -'NAT-DK9 k2)"
          using finseq_5_th_80 sorry
        also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> f  |FINSEQ-1K18\<^bsub>(D)\<^esub> (lenFINSEQ-1K4 f -'NAT-DK9 (k1 -'NAT-DK9 \<one>\<^sub>M)) /^RFINSEQK2\<^bsub>(D)\<^esub> (lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> (k1 -'NAT-DK9 \<one>\<^sub>M)) -'NAT-DK9 ((k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M))"
          using A9 rfinseq_th_29 sorry
        also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> (k1 -'NAT-DK9 \<one>\<^sub>M)) /^RFINSEQK2\<^bsub>(D)\<^esub> (lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> (k1 -'NAT-DK9 \<one>\<^sub>M)) -'NAT-DK9 ((k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M))"
          using A13 finseq_6_th_84 sorry
        also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> ((f /^RFINSEQK2\<^bsub>(D)\<^esub> (k1 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K18\<^bsub>(D)\<^esub> ((k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M))"
          using A10 finseq_6_th_85 sorry
        also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> (midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,k1,k2))"
          using A5 finseq_6_def_3 sorry
        finally have "midFINSEQ-6K3\<^bsub>(D)\<^esub>(RevFINSEQ-5K4\<^bsub>(D)\<^esub> f,(lenFINSEQ-1K4 f -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M,(lenFINSEQ-1K4 f -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M) =HIDDENR1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> (midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,k1,k2))"
           sorry
        thus "RevFINSEQ-5K4\<^bsub>(D)\<^esub> (midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,k1,k2)) =FINSEQ-1R1 midFINSEQ-6K3\<^bsub>(D)\<^esub>(RevFINSEQ-5K4\<^bsub>(D)\<^esub> f,(lenFINSEQ-1K4 f -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M,(lenFINSEQ-1K4 f -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M)"
           sorry
      qed
      have case2: "k1 >XXREAL-0R4 k2 implies RevFINSEQ-5K4\<^bsub>(D)\<^esub> (midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,k1,k2)) =FINSEQ-1R1 midFINSEQ-6K3\<^bsub>(D)\<^esub>(RevFINSEQ-5K4\<^bsub>(D)\<^esub> f,(lenFINSEQ-1K4 f -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M,(lenFINSEQ-1K4 f -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M)"
      proof(rule impI)
        assume A15: "k1 >XXREAL-0R4 k2"
        have A16: "lenFINSEQ-1K4 f -'NAT-DK9 (k2 -'NAT-DK9 \<one>\<^sub>M) =HIDDENR1 lenFINSEQ-1K4 f -XCMPLX-0K6 (k2 -'NAT-DK9 \<one>\<^sub>M)"
          using A4 nat_d_th_50 xreal_1_th_233 sorry
        also have "... = lenFINSEQ-1K4 f -XCMPLX-0K6 (k2 -XCMPLX-0K6 \<one>\<^sub>M)"
          using A3 xreal_1_th_233 sorry
        also have "... = (lenFINSEQ-1K4 f -XCMPLX-0K6 k2)+XCMPLX-0K2 \<one>\<^sub>M"
           sorry
        also have "... = (lenFINSEQ-1K4 f -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M"
          using A4 xreal_1_th_233 sorry
        finally have "lenFINSEQ-1K4 f -'NAT-DK9 (k2 -'NAT-DK9 \<one>\<^sub>M) =HIDDENR1 (lenFINSEQ-1K4 f -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M"
           sorry
        have A17: "lenFINSEQ-1K4 f -'NAT-DK9 k2 =XBOOLE-0R4 lenFINSEQ-1K4 f -XCMPLX-0K6 k2"
          using A4 xreal_1_th_233 sorry
        have "lenFINSEQ-1K4 f -'NAT-DK9 k2 >=XXREAL-0R2 lenFINSEQ-1K4 f -'NAT-DK9 k1"
          using A15 nat_d_th_41 sorry
        then have "(lenFINSEQ-1K4 f -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 (lenFINSEQ-1K4 f -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_6 sorry
        then have A18: "(((lenFINSEQ-1K4 f -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 ((lenFINSEQ-1K4 f -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M))+NAT-1K1 \<one>\<^sub>M =HIDDENR1 (((lenFINSEQ-1K4 f -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 ((lenFINSEQ-1K4 f -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<one>\<^sub>M"
          using xreal_1_th_233 sorry
        also have "... = (((lenFINSEQ-1K4 f -XCMPLX-0K6 k2)+XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 ((lenFINSEQ-1K4 f -XCMPLX-0K6 k1)+XCMPLX-0K2 \<one>\<^sub>M))+XCMPLX-0K2 \<one>\<^sub>M"
          using A2 A17 xreal_1_th_233 sorry
        also have "... = (k1 -XCMPLX-0K6 k2)+XCMPLX-0K2 \<one>\<^sub>M"
           sorry
        also have "... = (k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M"
          using A15 xreal_1_th_233 sorry
        finally have "(((lenFINSEQ-1K4 f -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 ((lenFINSEQ-1K4 f -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M))+NAT-1K1 \<one>\<^sub>M =HIDDENR1 (k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M"
           sorry
        have A19: "lenFINSEQ-1K4 f -'NAT-DK9 k1 =XBOOLE-0R4 lenFINSEQ-1K4 f -XCMPLX-0K6 k1"
          using A2 xreal_1_th_233 sorry
        have A20: "lenFINSEQ-1K4 f -'NAT-DK9 k2 <=XXREAL-0R1 (lenFINSEQ-1K4 f -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_11 sorry
        have "lenFINSEQ-1K4 f -'NAT-DK9 k2 >=XXREAL-0R2 lenFINSEQ-1K4 f -'NAT-DK9 k1"
          using A15 nat_d_th_41 sorry
        then have A21: "(lenFINSEQ-1K4 f -'NAT-DK9 (k2 -'NAT-DK9 \<one>\<^sub>M))-'NAT-DK9 (lenFINSEQ-1K4 f -'NAT-DK9 k1) =HIDDENR1 ((lenFINSEQ-1K4 f -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 (lenFINSEQ-1K4 f -'NAT-DK9 k1)"
          using A16 A20 xreal_1_th_233 xxreal_0_th_2 sorry
        also have "... = ((lenFINSEQ-1K4 f -XCMPLX-0K6 k2)+XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 (lenFINSEQ-1K4 f -XCMPLX-0K6 k1)"
          using A2 A17 xreal_1_th_233 sorry
        also have "... = (k1 -XCMPLX-0K6 k2)+XCMPLX-0K2 \<one>\<^sub>M"
           sorry
        also have "... = (k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M"
          using A15 xreal_1_th_233 sorry
        finally have "(lenFINSEQ-1K4 f -'NAT-DK9 (k2 -'NAT-DK9 \<one>\<^sub>M))-'NAT-DK9 (lenFINSEQ-1K4 f -'NAT-DK9 k1) =HIDDENR1 (k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M"
           sorry
        have A22: "(lenFINSEQ-1K4 f -'NAT-DK9 (k2 -'NAT-DK9 \<one>\<^sub>M))+NAT-1K1 (k2 -'NAT-DK9 \<one>\<^sub>M) =HIDDENR1 (lenFINSEQ-1K4 f -XCMPLX-0K6 (k2 -'NAT-DK9 \<one>\<^sub>M))+XCMPLX-0K2 (k2 -'NAT-DK9 \<one>\<^sub>M)"
          using A4 nat_d_th_50 xreal_1_th_233 sorry
        also have "... = lenFINSEQ-1K4 f"
           sorry
        finally have "(lenFINSEQ-1K4 f -'NAT-DK9 (k2 -'NAT-DK9 \<one>\<^sub>M))+NAT-1K1 (k2 -'NAT-DK9 \<one>\<^sub>M) =HIDDENR1 lenFINSEQ-1K4 f"
           sorry
        have "k1 -XCMPLX-0K6 k2 <=XXREAL-0R1 lenFINSEQ-1K4 f -XCMPLX-0K6 k2"
          using A2 xreal_1_th_9 sorry
        then have "k1 -'NAT-DK9 k2 <=XXREAL-0R1 lenFINSEQ-1K4 f -XCMPLX-0K6 k2"
          using A15 xreal_1_th_233 sorry
        then have "k1 -'NAT-DK9 k2 <=XXREAL-0R1 lenFINSEQ-1K4 f -'NAT-DK9 k2"
          using A4 xreal_1_th_233 sorry
        then have "(k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 (lenFINSEQ-1K4 f -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_6 sorry
        then have A23: "(lenFINSEQ-1K4 f -'NAT-DK9 (k2 -'NAT-DK9 \<one>\<^sub>M))-'NAT-DK9 ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((lenFINSEQ-1K4 f -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M)"
          using A16 xreal_1_th_233 sorry
        also have "... = ((lenFINSEQ-1K4 f -XCMPLX-0K6 k2)+XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 ((k1 -XCMPLX-0K6 k2)+XCMPLX-0K2 \<one>\<^sub>M)"
          using A15 A17 xreal_1_th_233 sorry
        also have "... = ((lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M)-XCMPLX-0K6 k1"
           sorry
        also have "... = lenFINSEQ-1K4 f -'NAT-DK9 k1"
          using A2 xreal_1_th_233 sorry
        finally have "(lenFINSEQ-1K4 f -'NAT-DK9 (k2 -'NAT-DK9 \<one>\<^sub>M))-'NAT-DK9 ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M) =HIDDENR1 lenFINSEQ-1K4 f -'NAT-DK9 k1"
           sorry
        then have A24: "(lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> (k2 -'NAT-DK9 \<one>\<^sub>M)) -'NAT-DK9 ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M))+NAT-1K1 ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (lenFINSEQ-1K4 f -'NAT-DK9 k1)+NAT-1K1 ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M)"
          using rfinseq_th_29 sorry
        also have "... = (lenFINSEQ-1K4 f -XCMPLX-0K6 k1)+XCMPLX-0K2 ((k1 -XCMPLX-0K6 k2)+XCMPLX-0K2 \<one>\<^sub>M)"
          using A15 A19 xreal_1_th_233 sorry
        also have "... = lenFINSEQ-1K4 f -XCMPLX-0K6 (k2 -XCMPLX-0K6 \<one>\<^sub>M)"
           sorry
        also have "... = lenFINSEQ-1K4 f -XCMPLX-0K6 (k2 -'NAT-DK9 \<one>\<^sub>M)"
          using A3 xreal_1_th_233 sorry
        also have "... = lenFINSEQ-1K4 f -'NAT-DK9 (k2 -'NAT-DK9 \<one>\<^sub>M)"
          using A4 nat_d_th_50 xreal_1_th_233 sorry
        also have "... = lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> (k2 -'NAT-DK9 \<one>\<^sub>M))"
          using rfinseq_th_29 sorry
        finally have "(lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> (k2 -'NAT-DK9 \<one>\<^sub>M)) -'NAT-DK9 ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M))+NAT-1K1 ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M) =HIDDENR1 lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> (k2 -'NAT-DK9 \<one>\<^sub>M))"
           sorry
        have "lenFINSEQ-1K4 f -XCMPLX-0K6 k2 >XXREAL-0R4 lenFINSEQ-1K4 f -XCMPLX-0K6 k1"
          using A15 xreal_1_th_10 sorry
        then have "(lenFINSEQ-1K4 f -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 (lenFINSEQ-1K4 f -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M"
          using A17 A19 xreal_1_th_6 sorry
        then have "midFINSEQ-6K3\<^bsub>(D)\<^esub>(RevFINSEQ-5K4\<^bsub>(D)\<^esub> f,(lenFINSEQ-1K4 f -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M,(lenFINSEQ-1K4 f -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M) =HIDDENR1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> ((RevFINSEQ-5K4\<^bsub>(D)\<^esub> f /^RFINSEQK2\<^bsub>(D)\<^esub> (((lenFINSEQ-1K4 f -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K18\<^bsub>(D)\<^esub> ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M))"
          using A18 finseq_6_def_3 sorry
        also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> ((RevFINSEQ-5K4\<^bsub>(D)\<^esub> f /^RFINSEQK2\<^bsub>(D)\<^esub> (lenFINSEQ-1K4 f -'NAT-DK9 k1)) |FINSEQ-1K18\<^bsub>(D)\<^esub> ((lenFINSEQ-1K4 f -'NAT-DK9 (k2 -'NAT-DK9 \<one>\<^sub>M))-'NAT-DK9 (lenFINSEQ-1K4 f -'NAT-DK9 k1)))"
          using A21 nat_d_th_34 sorry
        also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> (RevFINSEQ-5K4\<^bsub>(D)\<^esub> f  |FINSEQ-1K18\<^bsub>(D)\<^esub> (lenFINSEQ-1K4 f -'NAT-DK9 (k2 -'NAT-DK9 \<one>\<^sub>M)) /^RFINSEQK2\<^bsub>(D)\<^esub> (lenFINSEQ-1K4 f -'NAT-DK9 k1))"
          using finseq_5_th_80 sorry
        also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> (RevFINSEQ-5K4\<^bsub>(D)\<^esub> f  |FINSEQ-1K18\<^bsub>(D)\<^esub> (lenFINSEQ-1K4 f -'NAT-DK9 (k2 -'NAT-DK9 \<one>\<^sub>M)) /^RFINSEQK2\<^bsub>(D)\<^esub> (lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> (k2 -'NAT-DK9 \<one>\<^sub>M)) -'NAT-DK9 ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M)))"
          using A23 rfinseq_th_29 sorry
        also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> (RevFINSEQ-5K4\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> (k2 -'NAT-DK9 \<one>\<^sub>M)) /^RFINSEQK2\<^bsub>(D)\<^esub> (lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> (k2 -'NAT-DK9 \<one>\<^sub>M)) -'NAT-DK9 ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M)))"
          using A22 finseq_6_th_84 sorry
        also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> (RevFINSEQ-5K4\<^bsub>(D)\<^esub> ((f /^RFINSEQK2\<^bsub>(D)\<^esub> (k2 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K18\<^bsub>(D)\<^esub> ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M)))"
          using A24 finseq_6_th_85 sorry
        also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> (midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,k1,k2))"
          using A15 finseq_6_def_3 sorry
        finally have "midFINSEQ-6K3\<^bsub>(D)\<^esub>(RevFINSEQ-5K4\<^bsub>(D)\<^esub> f,(lenFINSEQ-1K4 f -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M,(lenFINSEQ-1K4 f -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M) =HIDDENR1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> (midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,k1,k2))"
           sorry
        thus "RevFINSEQ-5K4\<^bsub>(D)\<^esub> (midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,k1,k2)) =FINSEQ-1R1 midFINSEQ-6K3\<^bsub>(D)\<^esub>(RevFINSEQ-5K4\<^bsub>(D)\<^esub> f,(lenFINSEQ-1K4 f -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M,(lenFINSEQ-1K4 f -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M)"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_114:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & m +XCMPLX-0K2 n <=XXREAL-0R1 lenFINSEQ-1K4 f implies (f /^RFINSEQK1 n).FUNCT-1K1 m =XBOOLE-0R4 f .FUNCT-1K1 (m +XCMPLX-0K2 n)"
proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix n assume [ty]: "n be NatNAT-1M1"
  fix m assume [ty]: "m be NatNAT-1M1"
  fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
  assume A1: "\<one>\<^sub>M <=XXREAL-0R1 m"
    and A2: "m +XCMPLX-0K2 n <=XXREAL-0R1 lenFINSEQ-1K4 f"
  have A3: "(m +XCMPLX-0K2 n)-XCMPLX-0K6 n <=XXREAL-0R1 lenFINSEQ-1K4 f -XCMPLX-0K6 n"
    using A2 xreal_1_th_9 sorry
  have "n <=XXREAL-0R1 n +XCMPLX-0K2 m"
    using nat_1_th_11 sorry
  then have A4: "n <=XXREAL-0R1 lenFINSEQ-1K4 f"
    using A2 xxreal_0_th_2 sorry
  then have "lenFINSEQ-1K4 (f /^RFINSEQK1 n) =XBOOLE-0R4 lenFINSEQ-1K4 f -XCMPLX-0K6 n"
    using rfinseq_def_1 sorry
  then have "m inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK1 n)"
    using A1 A3 finseq_3_th_25 sorry
  thus "(f /^RFINSEQK1 n).FUNCT-1K1 m =XBOOLE-0R4 f .FUNCT-1K1 (m +XCMPLX-0K2 n)"
    using A4 rfinseq_def_1 sorry
qed "sorry"

mtheorem finseq_6_th_115:
" for i be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 f implies RevFINSEQ-5K3 f .FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M)"
proof(rule ballI,rule ballI,rule impMI ,rule impI)
  fix i assume [ty]: "i be NatNAT-1M1"
  fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
  assume A1: "\<one>\<^sub>M <=XXREAL-0R1 i"
    and A2: "i <=XXREAL-0R1 lenFINSEQ-1K4 f"
  have "i inTARSKIR2 domFINSEQ-1K5 f"
    using A1 A2 finseq_3_th_25 sorry
  thus "RevFINSEQ-5K3 f .FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M)"
    using finseq_5_th_58 sorry
qed "sorry"

mtheorem finseq_6_th_116:
" for f be FinSequenceFINSEQ-1M1 holds  for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k implies midFINSEQ-6K2(f,\<one>\<^sub>M,k) =FINSEQ-1R1 f  |FINSEQ-1K17 k"
proof(rule ballI,rule ballI,rule impI)
  fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
  fix k assume [ty]: "k be NatNAT-1M1"
  have "\<one>\<^sub>M -'NAT-DK9 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
    using xreal_1_th_232 sorry
  then have A1: "f /^RFINSEQK1 (\<one>\<^sub>M -'NAT-DK9 \<one>\<^sub>M) =FINSEQ-1R1 f"
    using finseq_5_th_28 sorry
  assume A2: "\<one>\<^sub>M <=XXREAL-0R1 k"
  then have "midFINSEQ-6K2(f,\<one>\<^sub>M,k) =FINSEQ-1R1 (f /^RFINSEQK1 (\<one>\<^sub>M -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
    using finseq_6_def_3 sorry
  thus "midFINSEQ-6K2(f,\<one>\<^sub>M,k) =FINSEQ-1R1 f  |FINSEQ-1K17 k"
    using A2 A1 xreal_1_th_235 sorry
qed "sorry"

mtheorem finseq_6_th_117:
" for f be FinSequenceFINSEQ-1M1 holds  for k be NatNAT-1M1 holds k <=XXREAL-0R1 lenFINSEQ-1K4 f implies midFINSEQ-6K2(f,k,lenFINSEQ-1K4 f) =FINSEQ-1R1 f /^RFINSEQK1 (k -'NAT-DK9 \<one>\<^sub>M)"
proof(rule ballI,rule ballI,rule impI)
  fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
  fix k assume [ty]: "k be NatNAT-1M1"
  assume A1: "k <=XXREAL-0R1 lenFINSEQ-1K4 f"
  then have A2: "midFINSEQ-6K2(f,k,lenFINSEQ-1K4 f) =FINSEQ-1R1 (f /^RFINSEQK1 (k -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((lenFINSEQ-1K4 f -'NAT-DK9 k)+NAT-1K1 \<one>\<^sub>M)"
    using finseq_6_def_3 sorry
  have "k -'NAT-DK9 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
    using A1 nat_d_th_44 sorry
  then have A3: "lenFINSEQ-1K4 (f /^RFINSEQK1 (k -'NAT-DK9 \<one>\<^sub>M)) =XBOOLE-0R4 lenFINSEQ-1K4 f -XCMPLX-0K6 (k -'NAT-DK9 \<one>\<^sub>M)"
    using rfinseq_def_1 sorry
  have A4: "(lenFINSEQ-1K4 f -'NAT-DK9 k)+NAT-1K1 \<one>\<^sub>M =HIDDENR1 (lenFINSEQ-1K4 f -XCMPLX-0K6 k)+XCMPLX-0K2 \<one>\<^sub>M"
    using A1 xreal_1_th_233 sorry
  also have "... = lenFINSEQ-1K4 f -XCMPLX-0K6 (k -XCMPLX-0K6 \<one>\<^sub>M)"
     sorry
  finally have "(lenFINSEQ-1K4 f -'NAT-DK9 k)+NAT-1K1 \<one>\<^sub>M =HIDDENR1 lenFINSEQ-1K4 f -XCMPLX-0K6 (k -XCMPLX-0K6 \<one>\<^sub>M)"
     sorry
  have "k =XBOOLE-0R4 0NUMBERSK6 & midFINSEQ-6K2(f,k,lenFINSEQ-1K4 f) =FINSEQ-1R1 f /^RFINSEQK1 (k -'NAT-DK9 \<one>\<^sub>M) or k <>HIDDENR2 0NUMBERSK6 & (k <>HIDDENR2 0NUMBERSK6 implies midFINSEQ-6K2(f,k,lenFINSEQ-1K4 f) =HIDDENR1 f /^RFINSEQK1 (k -'NAT-DK9 \<one>\<^sub>M))"
  proof-
    show "k =XBOOLE-0R4 0NUMBERSK6 & midFINSEQ-6K2(f,k,lenFINSEQ-1K4 f) =FINSEQ-1R1 f /^RFINSEQK1 (k -'NAT-DK9 \<one>\<^sub>M) or k <>HIDDENR2 0NUMBERSK6 & (k <>HIDDENR2 0NUMBERSK6 implies midFINSEQ-6K2(f,k,lenFINSEQ-1K4 f) =HIDDENR1 f /^RFINSEQK1 (k -'NAT-DK9 \<one>\<^sub>M))"
    proof-
      have cases: "k =XBOOLE-0R4 0NUMBERSK6 or k <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "k =XBOOLE-0R4 0NUMBERSK6 implies midFINSEQ-6K2(f,k,lenFINSEQ-1K4 f) =FINSEQ-1R1 f /^RFINSEQK1 (k -'NAT-DK9 \<one>\<^sub>M)"
      proof(rule impI)
        assume A5: "k =XBOOLE-0R4 0NUMBERSK6"
        have "0NUMBERSK6 -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 0NUMBERSK6"
           sorry
        then have "k -'NAT-DK9 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
          using A5 xreal_0_def_2 sorry
        then have A6: "f /^RFINSEQK1 (k -'NAT-DK9 \<one>\<^sub>M) =FINSEQ-1R1 f"
          using finseq_5_th_28 sorry
        have "(lenFINSEQ-1K4 f -'NAT-DK9 k)+NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M"
          using A5 nat_d_th_40 sorry
        then have "lenFINSEQ-1K4 f <=XXREAL-0R1 (lenFINSEQ-1K4 f -'NAT-DK9 k)+NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_11 sorry
        then have "SegFINSEQ-1K2 (lenFINSEQ-1K4 f) c=TARSKIR1 SegFINSEQ-1K2 ((lenFINSEQ-1K4 f -'NAT-DK9 k)+NAT-1K1 \<one>\<^sub>M)"
          using finseq_1_th_5 sorry
        then have "domFINSEQ-1K5 (f /^RFINSEQK1 (k -'NAT-DK9 \<one>\<^sub>M)) c=TARSKIR1 SegFINSEQ-1K2 ((lenFINSEQ-1K4 f -'NAT-DK9 k)+NAT-1K1 \<one>\<^sub>M)"
          using A6 finseq_1_def_3 sorry
        then have "(f /^RFINSEQK1 (k -'NAT-DK9 \<one>\<^sub>M)) |RELAT-1K8 SegFINSEQ-1K2 ((lenFINSEQ-1K4 f -'NAT-DK9 k)+NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 f /^RFINSEQK1 (k -'NAT-DK9 \<one>\<^sub>M)"
          using relat_1_th_68 sorry
        thus "midFINSEQ-6K2(f,k,lenFINSEQ-1K4 f) =FINSEQ-1R1 f /^RFINSEQK1 (k -'NAT-DK9 \<one>\<^sub>M)"
          using A2 sorry
      qed
      have case2: "k <>HIDDENR2 0NUMBERSK6 implies midFINSEQ-6K2(f,k,lenFINSEQ-1K4 f) =HIDDENR1 f /^RFINSEQK1 (k -'NAT-DK9 \<one>\<^sub>M)"
      proof(rule impI)
        assume "k <>HIDDENR2 0NUMBERSK6"
        then have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k"
          using nat_1_th_13 sorry
        then have "lenFINSEQ-1K4 (f /^RFINSEQK1 (k -'NAT-DK9 \<one>\<^sub>M)) =XBOOLE-0R4 (lenFINSEQ-1K4 f -'NAT-DK9 k)+NAT-1K1 \<one>\<^sub>M"
          using A3 A4 xreal_1_th_233 sorry
        then have "midFINSEQ-6K2(f,k,lenFINSEQ-1K4 f) =HIDDENR1 (f /^RFINSEQK1 (k -'NAT-DK9 \<one>\<^sub>M)) |RELAT-1K8 SegFINSEQ-1K2 (lenFINSEQ-1K4 (f /^RFINSEQK1 (k -'NAT-DK9 \<one>\<^sub>M)))"
          using A2 sorry
        also have "... = (f /^RFINSEQK1 (k -'NAT-DK9 \<one>\<^sub>M)) |RELAT-1K8 domFINSEQ-1K5 (f /^RFINSEQK1 (k -'NAT-DK9 \<one>\<^sub>M))"
          using finseq_1_def_3 sorry
        also have "... = f /^RFINSEQK1 (k -'NAT-DK9 \<one>\<^sub>M)"
           sorry
        finally show "midFINSEQ-6K2(f,k,lenFINSEQ-1K4 f) =HIDDENR1 f /^RFINSEQK1 (k -'NAT-DK9 \<one>\<^sub>M)"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
  thus "midFINSEQ-6K2(f,k,lenFINSEQ-1K4 f) =FINSEQ-1R1 f /^RFINSEQK1 (k -'NAT-DK9 \<one>\<^sub>M)"
     sorry
qed "sorry"

mtheorem finseq_6_th_118:
" for f be FinSequenceFINSEQ-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds ((\<one>\<^sub>M <=XXREAL-0R1 k1 & k1 <=XXREAL-0R1 lenFINSEQ-1K4 f) & \<one>\<^sub>M <=XXREAL-0R1 k2) & k2 <=XXREAL-0R1 lenFINSEQ-1K4 f implies ((midFINSEQ-6K2(f,k1,k2)).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 f .FUNCT-1K1 k1 & (k1 <=XXREAL-0R1 k2 implies lenFINSEQ-1K4 (midFINSEQ-6K2(f,k1,k2)) =XBOOLE-0R4 (k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 (midFINSEQ-6K2(f,k1,k2)) implies (midFINSEQ-6K2(f,k1,k2)).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((i +XCMPLX-0K2 k1)-'NAT-DK9 \<one>\<^sub>M)))) & (k1 >XXREAL-0R4 k2 implies lenFINSEQ-1K4 (midFINSEQ-6K2(f,k1,k2)) =XBOOLE-0R4 (k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 (midFINSEQ-6K2(f,k1,k2)) implies (midFINSEQ-6K2(f,k1,k2)).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((k1 -'NAT-DK9 i)+NAT-1K1 \<one>\<^sub>M)))"
proof-
  have " for f be FinSequenceFINSEQ-1M1 holds  for k11 be NatNAT-1M1 holds  for k21 be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k11 & (k11 <=XXREAL-0R1 lenFINSEQ-1K4 f & (\<one>\<^sub>M <=XXREAL-0R1 k21 & k21 <=XXREAL-0R1 lenFINSEQ-1K4 f)) implies (midFINSEQ-6K2(f,k11,k21)).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 f .FUNCT-1K1 k11 & ((k11 <=XXREAL-0R1 k21 implies lenFINSEQ-1K4 (midFINSEQ-6K2(f,k11,k21)) =XBOOLE-0R4 (k21 -'NAT-DK9 k11)+NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 (midFINSEQ-6K2(f,k11,k21)) implies (midFINSEQ-6K2(f,k11,k21)).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((i +XCMPLX-0K2 k11)-'NAT-DK9 \<one>\<^sub>M))) & (k11 >XXREAL-0R4 k21 implies lenFINSEQ-1K4 (midFINSEQ-6K2(f,k11,k21)) =XBOOLE-0R4 (k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 (midFINSEQ-6K2(f,k11,k21)) implies (midFINSEQ-6K2(f,k11,k21)).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((k11 -'NAT-DK9 i)+NAT-1K1 \<one>\<^sub>M))))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI,rule conjMI,rule conjMI,rule impI,rule conjMI)
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
    fix k11 assume [ty]: "k11 be NatNAT-1M1"
    fix k21 assume [ty]: "k21 be NatNAT-1M1"
    assume A1: "\<one>\<^sub>M <=XXREAL-0R1 k11"
      and A2: "k11 <=XXREAL-0R1 lenFINSEQ-1K4 f"
      and A3: "\<one>\<^sub>M <=XXREAL-0R1 k21"
      and A4: "k21 <=XXREAL-0R1 lenFINSEQ-1K4 f"
    obtain fa where 
      [ty]:"fa be FinSequenceFINSEQ-1M3-of rngFUNCT-1K2 f" and faDef:"fa = f"
      using finseq_1_def_4 sorry
    have "k21 -'NAT-DK9 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A4 nat_d_th_44 sorry
    then have A5: "lenFINSEQ-1K4 (f /^RFINSEQK1 (k21 -'NAT-DK9 \<one>\<^sub>M)) =XBOOLE-0R4 lenFINSEQ-1K4 f -XCMPLX-0K6 (k21 -'NAT-DK9 \<one>\<^sub>M)"
      using rfinseq_def_1 sorry
    have A6: "k21 -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
      using A3 xreal_1_th_48 sorry
    then have A7: "k21 -'NAT-DK9 \<one>\<^sub>M =XBOOLE-0R4 k21 -XCMPLX-0K6 \<one>\<^sub>M"
      using xreal_0_def_2 sorry
    have A8: " for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds (k1 <=XXREAL-0R1 k2 & \<one>\<^sub>M <=XXREAL-0R1 k1) & k1 <=XXREAL-0R1 lenFINSEQ-1K4 f implies (midFINSEQ-6K2(f,k1,k2)).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 f .FUNCT-1K1 k1"
    proof(rule ballI,rule ballI)
      fix k1 assume [ty]: "k1 be NatNAT-1M1"
      fix k2 assume [ty]: "k2 be NatNAT-1M1"
      have "k1 <=XXREAL-0R1 k2 & (\<one>\<^sub>M <=XXREAL-0R1 k1 & k1 <=XXREAL-0R1 lenFINSEQ-1K4 f) implies (midFINSEQ-6K2(f,k1,k2)).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 f .FUNCT-1K1 k1"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A9: "k1 <=XXREAL-0R1 k2"
          and A10: "\<one>\<^sub>M <=XXREAL-0R1 k1"
          and A11: "k1 <=XXREAL-0R1 lenFINSEQ-1K4 f"
        have A12: "(midFINSEQ-6K2(f,k1,k2)).FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 ((f /^RFINSEQK1 (k1 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 \<one>\<^sub>M"
          using A9 finseq_6_def_3 sorry
        also have "... = ((f /^RFINSEQK1 (k1 -'NAT-DK9 \<one>\<^sub>M)) |RELAT-1K8 SegFINSEQ-1K2 ((k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 \<one>\<^sub>M"
           sorry
        finally have "(midFINSEQ-6K2(f,k1,k2)).FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 ((f /^RFINSEQK1 (k1 -'NAT-DK9 \<one>\<^sub>M)) |RELAT-1K8 SegFINSEQ-1K2 ((k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 \<one>\<^sub>M"
           sorry
        have "k1 -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
          using A10 xreal_1_th_48 sorry
        then have A13: "\<one>\<^sub>M +NAT-1K1 (k1 -'NAT-DK9 \<one>\<^sub>M) =HIDDENR1 \<one>\<^sub>M +XCMPLX-0K2 (k1 -XCMPLX-0K6 \<one>\<^sub>M)"
          using xreal_0_def_2 sorry
        also have "... = k1"
           sorry
        finally have "\<one>\<^sub>M +NAT-1K1 (k1 -'NAT-DK9 \<one>\<^sub>M) =HIDDENR1 k1"
           sorry
        then have "\<one>\<^sub>M +NAT-1K1 (k1 -'NAT-DK9 \<one>\<^sub>M) <=XXREAL-0R1 (lenFINSEQ-1K4 f -XCMPLX-0K6 (k1 -'NAT-DK9 \<one>\<^sub>M))+XCMPLX-0K2 (k1 -'NAT-DK9 \<one>\<^sub>M)"
          using A11 sorry
        then have A14: "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f -XCMPLX-0K6 (k1 -'NAT-DK9 \<one>\<^sub>M)"
          using xreal_1_th_6 sorry
        have A15: "k1 -'NAT-DK9 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
          using A11 nat_d_th_44 sorry
        then have "lenFINSEQ-1K4 (f /^RFINSEQK1 (k1 -'NAT-DK9 \<one>\<^sub>M)) =XBOOLE-0R4 lenFINSEQ-1K4 f -XCMPLX-0K6 (k1 -'NAT-DK9 \<one>\<^sub>M)"
          using rfinseq_def_1 sorry
        then have "\<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 (f /^RFINSEQK1 (k1 -'NAT-DK9 \<one>\<^sub>M)))"
          using A14 sorry
        then have A16: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK1 (k1 -'NAT-DK9 \<one>\<^sub>M))"
          using finseq_1_def_3 sorry
        have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 (k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_6 sorry
        then have "\<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 ((k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M)"
           sorry
        then have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK1 (k1 -'NAT-DK9 \<one>\<^sub>M)) /\\SUBSET-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> SegFINSEQ-1K2 ((k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M)"
          using A16 xboole_0_def_4 sorry
        then have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ((f /^RFINSEQK1 (k1 -'NAT-DK9 \<one>\<^sub>M)) |RELAT-1K8 SegFINSEQ-1K2 ((k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M))"
          using relat_1_th_61 sorry
        then have "(midFINSEQ-6K2(f,k1,k2)).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 (f /^RFINSEQK1 (k1 -'NAT-DK9 \<one>\<^sub>M)).FUNCT-1K1 \<one>\<^sub>M"
          using A12 funct_1_th_47 sorry
        thus "(midFINSEQ-6K2(f,k1,k2)).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 f .FUNCT-1K1 k1"
          using A13 A15 A16 rfinseq_def_1 sorry
      qed
      thus "(k1 <=XXREAL-0R1 k2 & \<one>\<^sub>M <=XXREAL-0R1 k1) & k1 <=XXREAL-0R1 lenFINSEQ-1K4 f implies (midFINSEQ-6K2(f,k1,k2)).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 f .FUNCT-1K1 k1"
         sorry
    qed "sorry"
    show "(midFINSEQ-6K2(f,k11,k21)).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 f .FUNCT-1K1 k11"
    proof-
      show "(midFINSEQ-6K2(f,k11,k21)).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 f .FUNCT-1K1 k11"
      proof-
        have cases: "k11 <=XXREAL-0R1 k21 or k11 >XXREAL-0R4 k21"
           sorry
        have case1: "k11 <=XXREAL-0R1 k21 implies (midFINSEQ-6K2(f,k11,k21)).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 f .FUNCT-1K1 k11"
        proof(rule impI)
          assume "k11 <=XXREAL-0R1 k21"
          thus "(midFINSEQ-6K2(f,k11,k21)).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 f .FUNCT-1K1 k11"
            using A1 A2 A8 sorry
        qed
        have case2: "k11 >XXREAL-0R4 k21 implies (midFINSEQ-6K2(f,k11,k21)).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 f .FUNCT-1K1 k11"
        proof(rule impI)
          assume A17: "k11 >XXREAL-0R4 k21"
          have A18: "k21 -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
            using A3 xreal_1_th_48 sorry
          have A19: "k11 -XCMPLX-0K6 k21 >=XXREAL-0R2 0NUMBERSK6"
            using A17 xreal_1_th_48 sorry
          then have "k11 -'NAT-DK9 k21 =XBOOLE-0R4 k11 -XCMPLX-0K6 k21"
            using xreal_0_def_2 sorry
          then have A20: "(k21 -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 ((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (k21 -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 (k11 -XCMPLX-0K6 (k21 -XCMPLX-0K6 \<one>\<^sub>M))"
            using A18 xreal_0_def_2 sorry
          also have "... = k11"
             sorry
          finally have "(k21 -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 ((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M) =HIDDENR1 k11"
             sorry
          have "k21 -'NAT-DK9 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
            using A4 nat_d_th_44 sorry
          then have A21: "lenFINSEQ-1K4 (f /^RFINSEQK1 (k21 -'NAT-DK9 \<one>\<^sub>M)) =XBOOLE-0R4 lenFINSEQ-1K4 f -XCMPLX-0K6 (k21 -'NAT-DK9 \<one>\<^sub>M)"
            using rfinseq_def_1 sorry
          have A22: "\<one>\<^sub>M <=XXREAL-0R1 (k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M"
            using nat_1_th_11 sorry
          have "(k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M =HIDDENR1 (k11 -XCMPLX-0K6 k21)+XCMPLX-0K2 \<one>\<^sub>M"
            using A19 xreal_0_def_2 sorry
          also have "... = k11 -XCMPLX-0K6 (k21 -XCMPLX-0K6 \<one>\<^sub>M)"
             sorry
          also have "... = k11 -XCMPLX-0K6 (k21 -'NAT-DK9 \<one>\<^sub>M)"
            using A18 xreal_0_def_2 sorry
          finally have "(k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M =HIDDENR1 k11 -XCMPLX-0K6 (k21 -'NAT-DK9 \<one>\<^sub>M)"
             sorry
          then have A23: "(k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 (f /^RFINSEQK1 (k21 -'NAT-DK9 \<one>\<^sub>M))"
            using A2 A21 xreal_1_th_9 sorry
          then have A24: "lenFINSEQ-1K4 ((f /^RFINSEQK1 (k21 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 (k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M"
            using finseq_1_th_59 sorry
          then have A25: "(k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ((f /^RFINSEQK1 (k21 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M))"
            using A22 finseq_3_th_25 sorry
          have a25: "(k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK1 (k21 -'NAT-DK9 \<one>\<^sub>M))"
            using A23 finseq_3_th_25 A22 sorry
          have A26: "(k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK1 (k21 -'NAT-DK9 \<one>\<^sub>M))"
            using A22 A23 finseq_3_th_25 sorry
          have A27: "((f /^RFINSEQK1 (k21 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 lenFINSEQ-1K4 ((f /^RFINSEQK1 (k21 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 ((fa /^RFINSEQK2\<^bsub>(rngFUNCT-1K2 f)\<^esub> (k21 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K18\<^bsub>(rngFUNCT-1K2 f)\<^esub> ((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(rngFUNCT-1K2 f)\<^esub> ((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M)"
            using A22 A24 finseq_4_th_15 sorry
          also have "... = (fa /^RFINSEQK2\<^bsub>(rngFUNCT-1K2 f)\<^esub> (k21 -'NAT-DK9 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(rngFUNCT-1K2 f)\<^esub> ((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M)"
            using A25 finseq_4_th_70 sorry
          also have "... = (f /^RFINSEQK1 (k21 -'NAT-DK9 \<one>\<^sub>M)).FUNCT-1K1 ((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M)"
            using a25 partfun1_def_6 sorry
          also have "... = f .FUNCT-1K1 k11"
            using A20 A26 finseq_5_th_27 sorry
          finally have "((f /^RFINSEQK1 (k21 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 lenFINSEQ-1K4 ((f /^RFINSEQK1 (k21 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 f .FUNCT-1K1 k11"
             sorry
          have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ((f /^RFINSEQK1 (k21 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M))"
            using A22 A24 finseq_3_th_25 sorry
          then have "RevFINSEQ-5K3 ((f /^RFINSEQK1 (k21 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M)) .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 ((f /^RFINSEQK1 (k21 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 ((lenFINSEQ-1K4 ((f /^RFINSEQK1 (k21 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M)) -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M)"
            using finseq_5_th_58 sorry
          also have "... = f .FUNCT-1K1 k11"
            using A27 sorry
          finally have "RevFINSEQ-5K3 ((f /^RFINSEQK1 (k21 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M)) .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 f .FUNCT-1K1 k11"
             sorry
          thus "(midFINSEQ-6K2(f,k11,k21)).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 f .FUNCT-1K1 k11"
            using A17 finseq_6_def_3 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    show "k11 <=XXREAL-0R1 k21 implies lenFINSEQ-1K4 (midFINSEQ-6K2(f,k11,k21)) =XBOOLE-0R4 (k21 -'NAT-DK9 k11)+NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 (midFINSEQ-6K2(f,k11,k21)) implies (midFINSEQ-6K2(f,k11,k21)).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((i +XCMPLX-0K2 k11)-'NAT-DK9 \<one>\<^sub>M))"
    proof-
      have "k11 <=XXREAL-0R1 k21 implies lenFINSEQ-1K4 (midFINSEQ-6K2(f,k11,k21)) =XBOOLE-0R4 (k21 -'NAT-DK9 k11)+NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds  not ((\<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 (midFINSEQ-6K2(f,k11,k21))) &  not (midFINSEQ-6K2(f,k11,k21)).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((i +XCMPLX-0K2 k11)-'NAT-DK9 \<one>\<^sub>M)))"
      proof(rule impI)
        have A28: "k11 -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
          using A1 xreal_1_th_48 sorry
        then have A29: "k11 -'NAT-DK9 \<one>\<^sub>M =XBOOLE-0R4 k11 -XCMPLX-0K6 \<one>\<^sub>M"
          using xreal_0_def_2 sorry
        have "k11 -'NAT-DK9 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
          using A2 nat_d_th_44 sorry
        then have A30: "lenFINSEQ-1K4 (f /^RFINSEQK1 (k11 -'NAT-DK9 \<one>\<^sub>M)) =XBOOLE-0R4 lenFINSEQ-1K4 f -XCMPLX-0K6 (k11 -'NAT-DK9 \<one>\<^sub>M)"
          using rfinseq_def_1 sorry
        assume A31: "k11 <=XXREAL-0R1 k21"
        then have A32: "midFINSEQ-6K2(f,k11,k21) =FINSEQ-1R1 (f /^RFINSEQK1 (k11 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k21 -'NAT-DK9 k11)+NAT-1K1 \<one>\<^sub>M)"
          using finseq_6_def_3 sorry
        have A33: "k21 -XCMPLX-0K6 k11 >=XXREAL-0R2 0NUMBERSK6"
          using A31 xreal_1_th_48 sorry
        then have A34: "k21 -'NAT-DK9 k11 =XBOOLE-0R4 k21 -XCMPLX-0K6 k11"
          using xreal_0_def_2 sorry
        have "(k21 -'NAT-DK9 k11)+NAT-1K1 \<one>\<^sub>M =HIDDENR1 (k21 -XCMPLX-0K6 k11)+XCMPLX-0K2 \<one>\<^sub>M"
          using A33 xreal_0_def_2 sorry
        also have "... = k21 -XCMPLX-0K6 (k11 -XCMPLX-0K6 \<one>\<^sub>M)"
           sorry
        also have "... = k21 -XCMPLX-0K6 (k11 -'NAT-DK9 \<one>\<^sub>M)"
          using A28 xreal_0_def_2 sorry
        finally have "(k21 -'NAT-DK9 k11)+NAT-1K1 \<one>\<^sub>M =HIDDENR1 k21 -XCMPLX-0K6 (k11 -'NAT-DK9 \<one>\<^sub>M)"
           sorry
        then have A35: "(k21 -'NAT-DK9 k11)+NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 (f /^RFINSEQK1 (k11 -'NAT-DK9 \<one>\<^sub>M))"
          using A4 A30 xreal_1_th_9 sorry
        then have A36: "lenFINSEQ-1K4 ((f /^RFINSEQK1 (k11 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k21 -'NAT-DK9 k11)+NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 (k21 -'NAT-DK9 k11)+NAT-1K1 \<one>\<^sub>M"
          using finseq_1_th_59 sorry
        have " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 (midFINSEQ-6K2(f,k11,k21)) implies (midFINSEQ-6K2(f,k11,k21)).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((i +XCMPLX-0K2 k11)-'NAT-DK9 \<one>\<^sub>M)"
        proof(rule ballI,rule impMI ,rule impI)
          fix i assume [ty]: "i be NatNAT-1M1"
          assume A37: "\<one>\<^sub>M <=XXREAL-0R1 i"
            and A38: "i <=XXREAL-0R1 lenFINSEQ-1K4 (midFINSEQ-6K2(f,k11,k21))"
          have A39: "i <=XXREAL-0R1 (k21 -'NAT-DK9 k11)+NAT-1K1 \<one>\<^sub>M"
            using A32 A35 A38 finseq_1_th_59 sorry
          have "i +XCMPLX-0K2 (k11 -XCMPLX-0K6 \<one>\<^sub>M) <=XXREAL-0R1 (k21 -XCMPLX-0K6 (k11 -XCMPLX-0K6 \<one>\<^sub>M))+XCMPLX-0K2 (k11 -XCMPLX-0K6 \<one>\<^sub>M)"
            using A32 A34 A36 A38 xreal_1_th_6 sorry
          then have A40: "i +NAT-1K1 (k11 -'NAT-DK9 \<one>\<^sub>M) <=XXREAL-0R1 lenFINSEQ-1K4 f"
            using A4 A29 xxreal_0_th_2 sorry
          have A41: "k11 <=XXREAL-0R1 k11 +XCMPLX-0K2 i"
            using nat_1_th_11 sorry
          have A42: "i +NAT-1K1 (k11 -'NAT-DK9 \<one>\<^sub>M) =HIDDENR1 i +XCMPLX-0K2 (k11 -XCMPLX-0K6 \<one>\<^sub>M)"
            using A28 xreal_0_def_2 sorry
          also have "... = (i +XCMPLX-0K2 k11)-XCMPLX-0K6 \<one>\<^sub>M"
             sorry
          also have "... = (i +XCMPLX-0K2 k11)-'NAT-DK9 \<one>\<^sub>M"
            using A1 A41 xreal_1_th_233 xxreal_0_th_2 sorry
          finally have "i +NAT-1K1 (k11 -'NAT-DK9 \<one>\<^sub>M) =HIDDENR1 (i +XCMPLX-0K2 k11)-'NAT-DK9 \<one>\<^sub>M"
             sorry
          have "(midFINSEQ-6K2(f,k11,k21)).FUNCT-1K1 i =HIDDENR1 ((f /^RFINSEQK1 (k11 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k21 -'NAT-DK9 k11)+NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 i"
            using A31 finseq_6_def_3 sorry
          also have "... = (f /^RFINSEQK1 (k11 -'NAT-DK9 \<one>\<^sub>M)).FUNCT-1K1 i"
            using A39 finseq_3_th_112 sorry
          also have "... = f .FUNCT-1K1 (i +NAT-1K1 (k11 -'NAT-DK9 \<one>\<^sub>M))"
            using A37 A40 finseq_6_th_114 sorry
          finally have "(midFINSEQ-6K2(f,k11,k21)).FUNCT-1K1 i =HIDDENR1 f .FUNCT-1K1 (i +NAT-1K1 (k11 -'NAT-DK9 \<one>\<^sub>M))"
             sorry
          thus "(midFINSEQ-6K2(f,k11,k21)).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((i +XCMPLX-0K2 k11)-'NAT-DK9 \<one>\<^sub>M)"
            using A42 sorry
        qed "sorry"
        thus "lenFINSEQ-1K4 (midFINSEQ-6K2(f,k11,k21)) =XBOOLE-0R4 (k21 -'NAT-DK9 k11)+NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds  not ((\<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 (midFINSEQ-6K2(f,k11,k21))) &  not (midFINSEQ-6K2(f,k11,k21)).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((i +XCMPLX-0K2 k11)-'NAT-DK9 \<one>\<^sub>M)))"
          using A32 A35 finseq_1_th_59 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A43: "k11 >XXREAL-0R4 k21"
    then have A44: "k11 -XCMPLX-0K6 k21 >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_th_48 sorry
    then have A45: "k11 -'NAT-DK9 k21 =XBOOLE-0R4 k11 -XCMPLX-0K6 k21"
      using xreal_0_def_2 sorry
    have A46: "midFINSEQ-6K2(f,k11,k21) =FINSEQ-1R1 RevFINSEQ-5K3 ((f /^RFINSEQK1 (k21 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M))"
      using A43 finseq_6_def_3 sorry
    then have A47: "lenFINSEQ-1K4 (midFINSEQ-6K2(f,k11,k21)) =XBOOLE-0R4 lenFINSEQ-1K4 ((f /^RFINSEQK1 (k21 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M))"
      using finseq_5_def_3 sorry
    have "(k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M =HIDDENR1 (k11 -XCMPLX-0K6 k21)+XCMPLX-0K2 \<one>\<^sub>M"
      using A44 xreal_0_def_2 sorry
    also have "... = k11 -XCMPLX-0K6 (k21 -XCMPLX-0K6 \<one>\<^sub>M)"
       sorry
    also have "... = k11 -XCMPLX-0K6 (k21 -'NAT-DK9 \<one>\<^sub>M)"
      using A6 xreal_0_def_2 sorry
    finally have "(k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M =HIDDENR1 k11 -XCMPLX-0K6 (k21 -'NAT-DK9 \<one>\<^sub>M)"
       sorry
    then have A48: "(k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 (f /^RFINSEQK1 (k21 -'NAT-DK9 \<one>\<^sub>M))"
      using A2 A5 xreal_1_th_9 sorry
    thus A49: "lenFINSEQ-1K4 (midFINSEQ-6K2(f,k11,k21)) =XBOOLE-0R4 (k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M"
      using A47 finseq_1_th_59 sorry
    have A50: "lenFINSEQ-1K4 ((f /^RFINSEQK1 (k21 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 (k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M"
      using A48 finseq_1_th_59 sorry
    show " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 (midFINSEQ-6K2(f,k11,k21)) implies (midFINSEQ-6K2(f,k11,k21)).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((k11 -'NAT-DK9 i)+NAT-1K1 \<one>\<^sub>M)"
    proof(rule ballI,rule impMI ,rule impI)
      fix i assume [ty]: "i be NatNAT-1M1"
      assume A51: "\<one>\<^sub>M <=XXREAL-0R1 i"
        and A52: "i <=XXREAL-0R1 lenFINSEQ-1K4 (midFINSEQ-6K2(f,k11,k21))"
      have A53: "i +XCMPLX-0K2 (k21 -XCMPLX-0K6 \<one>\<^sub>M) <=XXREAL-0R1 (k11 -XCMPLX-0K6 (k21 -XCMPLX-0K6 \<one>\<^sub>M))+XCMPLX-0K2 (k21 -XCMPLX-0K6 \<one>\<^sub>M)"
        using A45 A49 A52 xreal_1_th_6 sorry
      have "(k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 ((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M)+NAT-1K1 (i -'NAT-DK9 \<one>\<^sub>M)"
        using nat_1_th_11 sorry
      then have "(k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 ((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (i -XCMPLX-0K6 \<one>\<^sub>M)"
        using A51 xreal_1_th_233 sorry
      then have "((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 (i -XCMPLX-0K6 \<one>\<^sub>M) <=XXREAL-0R1 (((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (i -XCMPLX-0K6 \<one>\<^sub>M))-XCMPLX-0K6 (i -XCMPLX-0K6 \<one>\<^sub>M)"
        using xreal_1_th_9 sorry
      then have A54: "(((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 (k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M"
         sorry
      have "i <=XXREAL-0R1 (k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M"
        using A47 A48 A52 finseq_1_th_59 sorry
      then have A55: "(((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 i)+NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 (k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M"
        using A54 xreal_1_th_233 sorry
      have A56: "i +XCMPLX-0K2 k11 <=XXREAL-0R1 i +NAT-1K1 lenFINSEQ-1K4 f"
        using A2 xreal_1_th_6 sorry
      have A57: "i <=XXREAL-0R1 i +NAT-1K1 (k21 -'NAT-DK9 \<one>\<^sub>M)"
        using nat_1_th_11 sorry
      have A58: "((((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 i)+NAT-1K1 \<one>\<^sub>M)+NAT-1K1 (k21 -'NAT-DK9 \<one>\<^sub>M) =HIDDENR1 ((((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 (k21 -'NAT-DK9 \<one>\<^sub>M)"
        using A49 A52 xreal_1_th_233 sorry
      also have "... = (((k11 -XCMPLX-0K6 (k21 -XCMPLX-0K6 \<one>\<^sub>M))-XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 (k21 -XCMPLX-0K6 \<one>\<^sub>M)"
        using A6 A45 xreal_0_def_2 sorry
      also have "... = (k11 -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M"
         sorry
      also have "... = (k11 -'NAT-DK9 i)+NAT-1K1 \<one>\<^sub>M"
        using A7 A53 A57 xreal_1_th_233 xxreal_0_th_2 sorry
      finally have "((((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 i)+NAT-1K1 \<one>\<^sub>M)+NAT-1K1 (k21 -'NAT-DK9 \<one>\<^sub>M) =HIDDENR1 (k11 -'NAT-DK9 i)+NAT-1K1 \<one>\<^sub>M"
         sorry
      have "\<one>\<^sub>M +XCMPLX-0K2 k11 <=XXREAL-0R1 i +XCMPLX-0K2 k11"
        using A51 xreal_1_th_6 sorry
      then have "\<one>\<^sub>M +XCMPLX-0K2 k11 <=XXREAL-0R1 i +NAT-1K1 lenFINSEQ-1K4 f"
        using A56 xxreal_0_th_2 sorry
      then have "(\<one>\<^sub>M +XCMPLX-0K2 k11)-XCMPLX-0K6 i <=XXREAL-0R1 (i +NAT-1K1 lenFINSEQ-1K4 f)-XCMPLX-0K6 i"
        using xreal_1_th_9 sorry
      then have "(k11 -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
         sorry
      then have A59: "((((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 i)+NAT-1K1 \<one>\<^sub>M)+NAT-1K1 (k21 -'NAT-DK9 \<one>\<^sub>M) <=XXREAL-0R1 lenFINSEQ-1K4 f"
        using A7 A53 A57 A58 xreal_1_th_233 xxreal_0_th_2 sorry
      have "(midFINSEQ-6K2(f,k11,k21)).FUNCT-1K1 i =HIDDENR1 ((f /^RFINSEQK1 (k21 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 ((lenFINSEQ-1K4 ((f /^RFINSEQK1 (k21 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M)) -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M)"
        using A46 A47 A51 A52 finseq_6_th_115 sorry
      also have "... = ((f /^RFINSEQK1 (k21 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 ((lenFINSEQ-1K4 ((f /^RFINSEQK1 (k21 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M)) -'NAT-DK9 i)+NAT-1K1 \<one>\<^sub>M)"
        using A47 A52 xreal_1_th_233 sorry
      also have "... = (f /^RFINSEQK1 (k21 -'NAT-DK9 \<one>\<^sub>M)).FUNCT-1K1 ((((k11 -'NAT-DK9 k21)+NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 i)+NAT-1K1 \<one>\<^sub>M)"
        using A50 A55 finseq_3_th_112 sorry
      also have "... = f .FUNCT-1K1 ((k11 -'NAT-DK9 i)+NAT-1K1 \<one>\<^sub>M)"
        using A58 A59 finseq_6_th_114 nat_1_th_11 sorry
      finally have "(midFINSEQ-6K2(f,k11,k21)).FUNCT-1K1 i =HIDDENR1 f .FUNCT-1K1 ((k11 -'NAT-DK9 i)+NAT-1K1 \<one>\<^sub>M)"
         sorry
      thus "(midFINSEQ-6K2(f,k11,k21)).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((k11 -'NAT-DK9 i)+NAT-1K1 \<one>\<^sub>M)"
         sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_119:
" for f be FinSequenceFINSEQ-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds rngFUNCT-1K2 (midFINSEQ-6K2(f,k1,k2)) c=TARSKIR1 rngFUNCT-1K2 f"
proof(rule ballI,rule ballI,rule ballI)
  fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
  fix k1 assume [ty]: "k1 be NatNAT-1M1"
  fix k2 assume [ty]: "k2 be NatNAT-1M1"
  show "rngFUNCT-1K2 (midFINSEQ-6K2(f,k1,k2)) c=TARSKIR1 rngFUNCT-1K2 f"
  proof-
    have cases: "k1 <=XXREAL-0R1 k2 or k1 >XXREAL-0R4 k2"
       sorry
    have case1: "k1 <=XXREAL-0R1 k2 implies rngFUNCT-1K2 (midFINSEQ-6K2(f,k1,k2)) c=TARSKIR1 rngFUNCT-1K2 f"
    proof(rule impI)
      assume "k1 <=XXREAL-0R1 k2"
      then have "midFINSEQ-6K2(f,k1,k2) =FINSEQ-1R1 (f /^RFINSEQK1 (k1 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M)"
        using finseq_6_def_3 sorry
      then have A1: "rngFUNCT-1K2 (midFINSEQ-6K2(f,k1,k2)) c=TARSKIR1 rngFUNCT-1K2 (f /^RFINSEQK1 (k1 -'NAT-DK9 \<one>\<^sub>M))"
        using finseq_5_th_19 sorry
      have "rngFUNCT-1K2 (f /^RFINSEQK1 (k1 -'NAT-DK9 \<one>\<^sub>M)) c=TARSKIR1 rngFUNCT-1K2 f"
        using finseq_5_th_33 sorry
      thus "rngFUNCT-1K2 (midFINSEQ-6K2(f,k1,k2)) c=TARSKIR1 rngFUNCT-1K2 f"
        using A1 sorry
    qed
    have case2: "k1 >XXREAL-0R4 k2 implies rngFUNCT-1K2 (midFINSEQ-6K2(f,k1,k2)) c=TARSKIR1 rngFUNCT-1K2 f"
    proof(rule impI)
      assume "k1 >XXREAL-0R4 k2"
      then have "midFINSEQ-6K2(f,k1,k2) =FINSEQ-1R1 RevFINSEQ-5K3 ((f /^RFINSEQK1 (k2 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M))"
        using finseq_6_def_3 sorry
      then have "rngFUNCT-1K2 (midFINSEQ-6K2(f,k1,k2)) =XBOOLE-0R4 rngFUNCT-1K2 ((f /^RFINSEQK1 (k2 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M))"
        using finseq_5_th_57 sorry
      then have A2: "rngFUNCT-1K2 (midFINSEQ-6K2(f,k1,k2)) c=TARSKIR1 rngFUNCT-1K2 (f /^RFINSEQK1 (k2 -'NAT-DK9 \<one>\<^sub>M))"
        using finseq_5_th_19 sorry
      have "rngFUNCT-1K2 (f /^RFINSEQK1 (k2 -'NAT-DK9 \<one>\<^sub>M)) c=TARSKIR1 rngFUNCT-1K2 f"
        using finseq_5_th_33 sorry
      thus "rngFUNCT-1K2 (midFINSEQ-6K2(f,k1,k2)) c=TARSKIR1 rngFUNCT-1K2 f"
        using A2 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem finseq_6_th_120:
" for f be FinSequenceFINSEQ-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f implies midFINSEQ-6K2(f,\<one>\<^sub>M,lenFINSEQ-1K4 f) =FINSEQ-1R1 f"
proof(rule ballI,rule impI)
  fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
  assume A1: "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
  then have "midFINSEQ-6K2(f,\<one>\<^sub>M,lenFINSEQ-1K4 f) =HIDDENR1 (f /^RFINSEQK1 (\<one>\<^sub>M -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((lenFINSEQ-1K4 f -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
    using finseq_6_def_3 sorry
  also have "... = (f /^RFINSEQK1 (0NUMBERSK6)) |FINSEQ-1K17 ((lenFINSEQ-1K4 f -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
    using xreal_1_th_232 sorry
  also have "... = f  |FINSEQ-1K17 ((lenFINSEQ-1K4 f -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
    using finseq_5_th_28 sorry
  also have "... = f  |FINSEQ-1K17 lenFINSEQ-1K4 f"
    using A1 xreal_1_th_235 sorry
  also have "... = f"
    using finseq_1_th_58 sorry
  finally have "midFINSEQ-6K2(f,\<one>\<^sub>M,lenFINSEQ-1K4 f) =HIDDENR1 f"
     sorry
  thus "midFINSEQ-6K2(f,\<one>\<^sub>M,lenFINSEQ-1K4 f) =FINSEQ-1R1 f"
     sorry
qed "sorry"

mtheorem finseq_6_th_121:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f implies midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,lenFINSEQ-1K4 f,\<one>\<^sub>M) =FINSEQ-1R1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f implies midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,lenFINSEQ-1K4 f,\<one>\<^sub>M) =FINSEQ-1R1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f"
  proof(rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
    have A2: "\<one>\<^sub>M -'NAT-DK9 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
      using xreal_1_th_232 sorry
    show "midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,lenFINSEQ-1K4 f,\<one>\<^sub>M) =FINSEQ-1R1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f"
    proof-
      have cases: "lenFINSEQ-1K4 f <>HIDDENR2 \<one>\<^sub>M or lenFINSEQ-1K4 f =XBOOLE-0R4 \<one>\<^sub>M"
         sorry
      have case1: "lenFINSEQ-1K4 f <>HIDDENR2 \<one>\<^sub>M implies midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,lenFINSEQ-1K4 f,\<one>\<^sub>M) =FINSEQ-1R1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f"
      proof(rule impI)
        assume "lenFINSEQ-1K4 f <>HIDDENR2 \<one>\<^sub>M"
        then have "\<one>\<^sub>M <XXREAL-0R3 lenFINSEQ-1K4 f"
          using A1 xxreal_0_th_1 sorry
        then have "midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,lenFINSEQ-1K4 f,\<one>\<^sub>M) =HIDDENR1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> ((f /^RFINSEQK2\<^bsub>(D)\<^esub> (\<one>\<^sub>M -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K18\<^bsub>(D)\<^esub> ((lenFINSEQ-1K4 f -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))"
          using finseq_6_def_3 sorry
        also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> ((f /^RFINSEQK2\<^bsub>(D)\<^esub> (0NUMBERSK6)) |FINSEQ-1K18\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f)"
          using A1 A2 xreal_1_th_235 sorry
        also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f)"
          using finseq_5_th_28 sorry
        also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> f"
          using finseq_1_th_58 sorry
        finally have "midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,lenFINSEQ-1K4 f,\<one>\<^sub>M) =HIDDENR1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f"
           sorry
        thus "midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,lenFINSEQ-1K4 f,\<one>\<^sub>M) =FINSEQ-1R1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f"
           sorry
      qed
      have case2: "lenFINSEQ-1K4 f =XBOOLE-0R4 \<one>\<^sub>M implies midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,lenFINSEQ-1K4 f,\<one>\<^sub>M) =FINSEQ-1R1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f"
      proof(rule impI)
        assume A3: "lenFINSEQ-1K4 f =XBOOLE-0R4 \<one>\<^sub>M"
        then have A4: "f  |FINSEQ-1K18\<^bsub>(D)\<^esub> \<one>\<^sub>M =FINSEQ-1R1 f"
          using finseq_1_th_58 sorry
        have "midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,lenFINSEQ-1K4 f,\<one>\<^sub>M) =HIDDENR1 (f /^RFINSEQK2\<^bsub>(D)\<^esub> (\<one>\<^sub>M -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K18\<^bsub>(D)\<^esub> ((\<one>\<^sub>M -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
          using A3 finseq_6_def_3 sorry
        also have "... = f  |FINSEQ-1K18\<^bsub>(D)\<^esub> \<one>\<^sub>M"
          using A2 finseq_5_th_28 sorry
        finally have "midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,lenFINSEQ-1K4 f,\<one>\<^sub>M) =HIDDENR1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> \<one>\<^sub>M"
           sorry
        thus "midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,lenFINSEQ-1K4 f,\<one>\<^sub>M) =FINSEQ-1R1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f"
          using A1 A4 finseq_6_th_110 finseq_1_th_59 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_122:
" for f be FinSequenceFINSEQ-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds  for i be NatNAT-1M1 holds (((\<one>\<^sub>M <=XXREAL-0R1 k1 & k1 <=XXREAL-0R1 k2) & k2 <=XXREAL-0R1 lenFINSEQ-1K4 f) & \<one>\<^sub>M <=XXREAL-0R1 i) & ((i <=XXREAL-0R1 (k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M or i <=XXREAL-0R1 (k2 -XCMPLX-0K6 k1)+XCMPLX-0K2 \<one>\<^sub>M) or i <=XXREAL-0R1 (k2 +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 k1) implies (((midFINSEQ-6K2(f,k1,k2)).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((i +XCMPLX-0K2 k1)-'NAT-DK9 \<one>\<^sub>M) & (midFINSEQ-6K2(f,k1,k2)).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((i -'NAT-DK9 \<one>\<^sub>M)+XCMPLX-0K2 k1)) & (midFINSEQ-6K2(f,k1,k2)).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((i +XCMPLX-0K2 k1)-XCMPLX-0K6 \<one>\<^sub>M)) & (midFINSEQ-6K2(f,k1,k2)).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((i -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 k1)"
proof-
  have " for f be FinSequenceFINSEQ-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds  for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k1 & (k1 <=XXREAL-0R1 k2 & (k2 <=XXREAL-0R1 lenFINSEQ-1K4 f & (\<one>\<^sub>M <=XXREAL-0R1 i & ((i <=XXREAL-0R1 (k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M or i <=XXREAL-0R1 (k2 -XCMPLX-0K6 k1)+XCMPLX-0K2 \<one>\<^sub>M) or i <=XXREAL-0R1 (k2 +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 k1)))) implies ((midFINSEQ-6K2(f,k1,k2)).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((i +XCMPLX-0K2 k1)-'NAT-DK9 \<one>\<^sub>M) & (midFINSEQ-6K2(f,k1,k2)).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((i -'NAT-DK9 \<one>\<^sub>M)+XCMPLX-0K2 k1)) & ((midFINSEQ-6K2(f,k1,k2)).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((i +XCMPLX-0K2 k1)-XCMPLX-0K6 \<one>\<^sub>M) & (midFINSEQ-6K2(f,k1,k2)).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((i -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 k1))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI,rule conjMI,rule conjMI)
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
    fix k1 assume [ty]: "k1 be NatNAT-1M1"
    fix k2 assume [ty]: "k2 be NatNAT-1M1"
    fix i assume [ty]: "i be NatNAT-1M1"
    assume A1: "\<one>\<^sub>M <=XXREAL-0R1 k1"
      and A2: "k1 <=XXREAL-0R1 k2"
      and A3: "k2 <=XXREAL-0R1 lenFINSEQ-1K4 f"
      and A4: "\<one>\<^sub>M <=XXREAL-0R1 i"
      and A5: "(i <=XXREAL-0R1 (k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M or i <=XXREAL-0R1 (k2 -XCMPLX-0K6 k1)+XCMPLX-0K2 \<one>\<^sub>M) or i <=XXREAL-0R1 (k2 +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 k1"
    have A6: "k1 <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A2 A3 xxreal_0_th_2 sorry
    have "i +XCMPLX-0K2 k1 >=XXREAL-0R2 \<one>\<^sub>M +XCMPLX-0K2 k1"
      using A4 xreal_1_th_6 sorry
    then have A7: "(i +XCMPLX-0K2 k1)-XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 (\<one>\<^sub>M +XCMPLX-0K2 k1)-XCMPLX-0K6 \<one>\<^sub>M"
      using xreal_1_th_9 sorry
    have A8: "i <=XXREAL-0R1 (k2 -XCMPLX-0K6 k1)+XCMPLX-0K2 \<one>\<^sub>M implies i <=XXREAL-0R1 (k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M"
      using A2 xreal_1_th_233 sorry
    have "i -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
      using A4 xreal_1_th_9 sorry
    then have A9: "(i -'NAT-DK9 \<one>\<^sub>M)+XCMPLX-0K2 k1 =HIDDENR1 (i -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 k1"
      using xreal_0_def_2 sorry
    also have "... = (i +XCMPLX-0K2 k1)-'NAT-DK9 \<one>\<^sub>M"
      using A7 xreal_0_def_2 sorry
    finally have "(i -'NAT-DK9 \<one>\<^sub>M)+XCMPLX-0K2 k1 =HIDDENR1 (i +XCMPLX-0K2 k1)-'NAT-DK9 \<one>\<^sub>M"
       sorry
    have A10: "\<one>\<^sub>M <=XXREAL-0R1 k2"
      using A1 A2 xxreal_0_th_2 sorry
    then have "lenFINSEQ-1K4 (midFINSEQ-6K2(f,k1,k2)) =XBOOLE-0R4 (k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M"
      using A1 A2 A3 A6 finseq_6_th_118 sorry
    thus A11: "(midFINSEQ-6K2(f,k1,k2)).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((i +XCMPLX-0K2 k1)-'NAT-DK9 \<one>\<^sub>M) & (midFINSEQ-6K2(f,k1,k2)).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((i -'NAT-DK9 \<one>\<^sub>M)+XCMPLX-0K2 k1)"
      using A1 A2 A3 A4 A5 A10 A6 A8 A9 finseq_6_th_118 sorry
    thus "(midFINSEQ-6K2(f,k1,k2)).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((i +XCMPLX-0K2 k1)-XCMPLX-0K6 \<one>\<^sub>M)"
      using A7 xreal_0_def_2 sorry
    show "(midFINSEQ-6K2(f,k1,k2)).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((i -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 k1)"
      using A4 A11 xreal_1_th_233 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_123:
" for f be FinSequenceFINSEQ-1M1 holds  for k be NatNAT-1M1 holds  for i be NatNAT-1M1 holds (\<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 k) & k <=XXREAL-0R1 lenFINSEQ-1K4 f implies (midFINSEQ-6K2(f,\<one>\<^sub>M,k)).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 i"
proof-
  have " for f be FinSequenceFINSEQ-1M1 holds  for k be NatNAT-1M1 holds  for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & (i <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 f) implies (midFINSEQ-6K2(f,\<one>\<^sub>M,k)).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 i"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    fix i assume [ty]: "i be NatNAT-1M1"
    assume A1: "\<one>\<^sub>M <=XXREAL-0R1 i"
      and A2: "i <=XXREAL-0R1 k"
      and A3: "k <=XXREAL-0R1 lenFINSEQ-1K4 f"
    have A4: "i <=XXREAL-0R1 (k -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M"
      using A2 sorry
    have "\<one>\<^sub>M <=XXREAL-0R1 k"
      using A1 A2 xxreal_0_th_2 sorry
    then have "(midFINSEQ-6K2(f,\<one>\<^sub>M,k)).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((i +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 \<one>\<^sub>M)"
      using A1 A3 A4 finseq_6_th_122 sorry
    thus "(midFINSEQ-6K2(f,\<one>\<^sub>M,k)).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 i"
      using nat_d_th_34 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_124:
" for f be FinSequenceFINSEQ-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds lenFINSEQ-1K4 (midFINSEQ-6K2(f,k1,k2)) <=XXREAL-0R1 lenFINSEQ-1K4 f"
proof(rule ballI,rule ballI,rule ballI)
  fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
  fix k1 assume [ty]: "k1 be NatNAT-1M1"
  fix k2 assume [ty]: "k2 be NatNAT-1M1"
  show "lenFINSEQ-1K4 (midFINSEQ-6K2(f,k1,k2)) <=XXREAL-0R1 lenFINSEQ-1K4 f"
  proof-
    have cases: "k1 <=XXREAL-0R1 k2 or k1 >XXREAL-0R4 k2"
       sorry
    have case1: "k1 <=XXREAL-0R1 k2 implies lenFINSEQ-1K4 (midFINSEQ-6K2(f,k1,k2)) <=XXREAL-0R1 lenFINSEQ-1K4 f"
    proof(rule impI)
      assume "k1 <=XXREAL-0R1 k2"
      then have A1: "midFINSEQ-6K2(f,k1,k2) =FINSEQ-1R1 (f /^RFINSEQK1 (k1 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M)"
        using finseq_6_def_3 sorry
      show "lenFINSEQ-1K4 (midFINSEQ-6K2(f,k1,k2)) <=XXREAL-0R1 lenFINSEQ-1K4 f"
      proof-
        have cases: "lenFINSEQ-1K4 (f /^RFINSEQK1 (k1 -'NAT-DK9 \<one>\<^sub>M)) <=XXREAL-0R1 (k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M or lenFINSEQ-1K4 (f /^RFINSEQK1 (k1 -'NAT-DK9 \<one>\<^sub>M)) >XXREAL-0R4 (k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M"
           sorry
        have case1: "lenFINSEQ-1K4 (f /^RFINSEQK1 (k1 -'NAT-DK9 \<one>\<^sub>M)) <=XXREAL-0R1 (k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M implies lenFINSEQ-1K4 (midFINSEQ-6K2(f,k1,k2)) <=XXREAL-0R1 lenFINSEQ-1K4 f"
        proof(rule impI)
          assume "lenFINSEQ-1K4 (f /^RFINSEQK1 (k1 -'NAT-DK9 \<one>\<^sub>M)) <=XXREAL-0R1 (k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M"
          then have A2: "midFINSEQ-6K2(f,k1,k2) =FINSEQ-1R1 f /^RFINSEQK1 (k1 -'NAT-DK9 \<one>\<^sub>M)"
            using A1 finseq_1_th_58 sorry
          show "lenFINSEQ-1K4 (midFINSEQ-6K2(f,k1,k2)) <=XXREAL-0R1 lenFINSEQ-1K4 f"
          proof-
            have cases: "k1 -'NAT-DK9 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f or  not k1 -'NAT-DK9 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
               sorry
            have case1: "k1 -'NAT-DK9 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f implies lenFINSEQ-1K4 (midFINSEQ-6K2(f,k1,k2)) <=XXREAL-0R1 lenFINSEQ-1K4 f"
            proof(rule impI)
              assume A3: "k1 -'NAT-DK9 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
              have "lenFINSEQ-1K4 f -XCMPLX-0K6 (k1 -'NAT-DK9 \<one>\<^sub>M) <=XXREAL-0R1 lenFINSEQ-1K4 f -XCMPLX-0K6 0NUMBERSK6"
                using xreal_1_th_10 sorry
              thus "lenFINSEQ-1K4 (midFINSEQ-6K2(f,k1,k2)) <=XXREAL-0R1 lenFINSEQ-1K4 f"
                using A2 A3 rfinseq_def_1 sorry
            qed
            have case2: " not k1 -'NAT-DK9 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f implies lenFINSEQ-1K4 (midFINSEQ-6K2(f,k1,k2)) <=XXREAL-0R1 lenFINSEQ-1K4 f"
            proof(rule impI)
              assume " not k1 -'NAT-DK9 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
              then have "f /^RFINSEQK1 (k1 -'NAT-DK9 \<one>\<^sub>M) =FINSEQ-1R1 {}XBOOLE-0K1"
                using rfinseq_def_1 sorry
              thus "lenFINSEQ-1K4 (midFINSEQ-6K2(f,k1,k2)) <=XXREAL-0R1 lenFINSEQ-1K4 f"
                using A2 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        have case2: "lenFINSEQ-1K4 (f /^RFINSEQK1 (k1 -'NAT-DK9 \<one>\<^sub>M)) >XXREAL-0R4 (k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M implies lenFINSEQ-1K4 (midFINSEQ-6K2(f,k1,k2)) <=XXREAL-0R1 lenFINSEQ-1K4 f"
        proof(rule impI)
          assume "lenFINSEQ-1K4 (f /^RFINSEQK1 (k1 -'NAT-DK9 \<one>\<^sub>M)) >XXREAL-0R4 (k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M"
          then have A5: "lenFINSEQ-1K4 (midFINSEQ-6K2(f,k1,k2)) <=XXREAL-0R1 lenFINSEQ-1K4 (f /^RFINSEQK1 (k1 -'NAT-DK9 \<one>\<^sub>M))"
            using A1 finseq_1_th_59 sorry
          show "lenFINSEQ-1K4 (midFINSEQ-6K2(f,k1,k2)) <=XXREAL-0R1 lenFINSEQ-1K4 f"
          proof-
            have cases: "k1 -'NAT-DK9 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f or  not k1 -'NAT-DK9 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
               sorry
            have case1: "k1 -'NAT-DK9 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f implies lenFINSEQ-1K4 (midFINSEQ-6K2(f,k1,k2)) <=XXREAL-0R1 lenFINSEQ-1K4 f"
            proof(rule impI)
              assume "k1 -'NAT-DK9 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
              then have A6: "lenFINSEQ-1K4 (midFINSEQ-6K2(f,k1,k2)) <=XXREAL-0R1 lenFINSEQ-1K4 f -XCMPLX-0K6 (k1 -'NAT-DK9 \<one>\<^sub>M)"
                using A5 rfinseq_def_1 sorry
              have "lenFINSEQ-1K4 f -XCMPLX-0K6 (k1 -'NAT-DK9 \<one>\<^sub>M) <=XXREAL-0R1 lenFINSEQ-1K4 f -XCMPLX-0K6 0NUMBERSK6"
                using xreal_1_th_10 sorry
              thus "lenFINSEQ-1K4 (midFINSEQ-6K2(f,k1,k2)) <=XXREAL-0R1 lenFINSEQ-1K4 f"
                using A6 xxreal_0_th_2 sorry
            qed
            have case2: " not k1 -'NAT-DK9 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f implies lenFINSEQ-1K4 (midFINSEQ-6K2(f,k1,k2)) <=XXREAL-0R1 lenFINSEQ-1K4 f"
            proof(rule impI)
              assume " not k1 -'NAT-DK9 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
              then have "f /^RFINSEQK1 (k1 -'NAT-DK9 \<one>\<^sub>M) =FINSEQ-1R1 {}XBOOLE-0K1"
                using rfinseq_def_1 sorry
              thus "lenFINSEQ-1K4 (midFINSEQ-6K2(f,k1,k2)) <=XXREAL-0R1 lenFINSEQ-1K4 f"
                using A5 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    have case2: "k1 >XXREAL-0R4 k2 implies lenFINSEQ-1K4 (midFINSEQ-6K2(f,k1,k2)) <=XXREAL-0R1 lenFINSEQ-1K4 f"
    proof(rule impI)
      assume "k1 >XXREAL-0R4 k2"
      then have A7: "midFINSEQ-6K2(f,k1,k2) =FINSEQ-1R1 RevFINSEQ-5K3 ((f /^RFINSEQK1 (k2 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M))"
        using finseq_6_def_3 sorry
      let ?m = "(f /^RFINSEQK1 (k2 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M)"
      have "lenFINSEQ-1K4 ?m <=XXREAL-0R1 lenFINSEQ-1K4 f"
      proof-
        have "lenFINSEQ-1K4 ((f /^RFINSEQK1 (k2 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M)) <=XXREAL-0R1 lenFINSEQ-1K4 f"
        proof-
          show "lenFINSEQ-1K4 ((f /^RFINSEQK1 (k2 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M)) <=XXREAL-0R1 lenFINSEQ-1K4 f"
          proof-
            have cases: "lenFINSEQ-1K4 (f /^RFINSEQK1 (k2 -'NAT-DK9 \<one>\<^sub>M)) <=XXREAL-0R1 (k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M or lenFINSEQ-1K4 (f /^RFINSEQK1 (k2 -'NAT-DK9 \<one>\<^sub>M)) >XXREAL-0R4 (k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M"
               sorry
            have case1: "lenFINSEQ-1K4 (f /^RFINSEQK1 (k2 -'NAT-DK9 \<one>\<^sub>M)) <=XXREAL-0R1 (k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M implies lenFINSEQ-1K4 ((f /^RFINSEQK1 (k2 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M)) <=XXREAL-0R1 lenFINSEQ-1K4 f"
            proof(rule impI)
              assume "lenFINSEQ-1K4 (f /^RFINSEQK1 (k2 -'NAT-DK9 \<one>\<^sub>M)) <=XXREAL-0R1 (k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M"
              then have A8: "?m =FINSEQ-1R1 f /^RFINSEQK1 (k2 -'NAT-DK9 \<one>\<^sub>M)"
                using finseq_1_th_58 sorry
              show "lenFINSEQ-1K4 ((f /^RFINSEQK1 (k2 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M)) <=XXREAL-0R1 lenFINSEQ-1K4 f"
              proof-
                have cases: "k2 -'NAT-DK9 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f or  not k2 -'NAT-DK9 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
                   sorry
                have case1: "k2 -'NAT-DK9 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f implies lenFINSEQ-1K4 ((f /^RFINSEQK1 (k2 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M)) <=XXREAL-0R1 lenFINSEQ-1K4 f"
                proof(rule impI)
                  assume A9: "k2 -'NAT-DK9 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
                  have "lenFINSEQ-1K4 f -XCMPLX-0K6 (k2 -'NAT-DK9 \<one>\<^sub>M) <=XXREAL-0R1 lenFINSEQ-1K4 f -XCMPLX-0K6 0NUMBERSK6"
                    using xreal_1_th_10 sorry
                  thus "lenFINSEQ-1K4 ((f /^RFINSEQK1 (k2 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M)) <=XXREAL-0R1 lenFINSEQ-1K4 f"
                    using A8 A9 rfinseq_def_1 sorry
                qed
                have case2: " not k2 -'NAT-DK9 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f implies lenFINSEQ-1K4 ((f /^RFINSEQK1 (k2 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M)) <=XXREAL-0R1 lenFINSEQ-1K4 f"
                proof(rule impI)
                  assume " not k2 -'NAT-DK9 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
                  then have "f /^RFINSEQK1 (k2 -'NAT-DK9 \<one>\<^sub>M) =FINSEQ-1R1 {}XBOOLE-0K1"
                    using rfinseq_def_1 sorry
                  thus "lenFINSEQ-1K4 ((f /^RFINSEQK1 (k2 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M)) <=XXREAL-0R1 lenFINSEQ-1K4 f"
                     sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            have case2: "lenFINSEQ-1K4 (f /^RFINSEQK1 (k2 -'NAT-DK9 \<one>\<^sub>M)) >XXREAL-0R4 (k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M implies lenFINSEQ-1K4 ((f /^RFINSEQK1 (k2 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M)) <=XXREAL-0R1 lenFINSEQ-1K4 f"
            proof(rule impI)
              assume "lenFINSEQ-1K4 (f /^RFINSEQK1 (k2 -'NAT-DK9 \<one>\<^sub>M)) >XXREAL-0R4 (k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M"
              then have A11: "lenFINSEQ-1K4 ?m <=XXREAL-0R1 lenFINSEQ-1K4 (f /^RFINSEQK1 (k2 -'NAT-DK9 \<one>\<^sub>M))"
                using finseq_1_th_59 sorry
              show "lenFINSEQ-1K4 ((f /^RFINSEQK1 (k2 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M)) <=XXREAL-0R1 lenFINSEQ-1K4 f"
              proof-
                have cases: "k2 -'NAT-DK9 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f or  not k2 -'NAT-DK9 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
                   sorry
                have case1: "k2 -'NAT-DK9 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f implies lenFINSEQ-1K4 ((f /^RFINSEQK1 (k2 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M)) <=XXREAL-0R1 lenFINSEQ-1K4 f"
                proof(rule impI)
                  assume "k2 -'NAT-DK9 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
                  then have A12: "lenFINSEQ-1K4 ?m <=XXREAL-0R1 lenFINSEQ-1K4 f -XCMPLX-0K6 (k2 -'NAT-DK9 \<one>\<^sub>M)"
                    using A11 rfinseq_def_1 sorry
                  have "lenFINSEQ-1K4 f -XCMPLX-0K6 (k2 -'NAT-DK9 \<one>\<^sub>M) <=XXREAL-0R1 lenFINSEQ-1K4 f -XCMPLX-0K6 0NUMBERSK6"
                    using xreal_1_th_10 sorry
                  thus "lenFINSEQ-1K4 ((f /^RFINSEQK1 (k2 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M)) <=XXREAL-0R1 lenFINSEQ-1K4 f"
                    using A12 xxreal_0_th_2 sorry
                qed
                have case2: " not k2 -'NAT-DK9 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f implies lenFINSEQ-1K4 ((f /^RFINSEQK1 (k2 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M)) <=XXREAL-0R1 lenFINSEQ-1K4 f"
                proof(rule impI)
                  assume " not k2 -'NAT-DK9 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
                  then have "f /^RFINSEQK1 (k2 -'NAT-DK9 \<one>\<^sub>M) =FINSEQ-1R1 {}XBOOLE-0K1"
                    using rfinseq_def_1 sorry
                  thus "lenFINSEQ-1K4 ((f /^RFINSEQK1 (k2 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M)) <=XXREAL-0R1 lenFINSEQ-1K4 f"
                     sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus " ?thesis "
           sorry
      qed
      thus "lenFINSEQ-1K4 (midFINSEQ-6K2(f,k1,k2)) <=XXREAL-0R1 lenFINSEQ-1K4 f"
        using A7 finseq_5_def_3 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem finseq_6_th_125:
" for f be FinSequenceFINSEQ-1M1 holds  for k be NatNAT-1M1 holds  for p be setHIDDENM2 holds ((<*FINSEQ-1K10 p*>)^FINSEQ-1K8 f) |FINSEQ-1K17 (k +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 (<*FINSEQ-1K10 p*>)^FINSEQ-1K8 f  |FINSEQ-1K17 k"
proof-
  have " for f be FinSequenceFINSEQ-1M1 holds  for k be NatNAT-1M1 holds  for p be setHIDDENM2 holds ((<*FINSEQ-1K10 p*>)^FINSEQ-1K8 f) |FINSEQ-1K17 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (<*FINSEQ-1K10 p*>)^FINSEQ-1K8 f  |FINSEQ-1K17 k"
  proof(rule ballI,rule ballI,rule ballI)
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    fix p assume [ty]: "p be setHIDDENM2"
    have "((<*FINSEQ-1K10 p*>)^FINSEQ-1K8 f) |FINSEQ-1K17 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((<*FINSEQ-1K10 p*>)^FINSEQ-1K8 f) |RELAT-1K8 SegFINSEQ-1K2 (k +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 p*>))"
      using finseq_1_th_39 sorry
    also have "... = (<*FINSEQ-1K10 p*>)^FINSEQ-1K8 f  |FINSEQ-1K17 k"
      using finseq_6_th_14 sorry
    finally show "((<*FINSEQ-1K10 p*>)^FINSEQ-1K8 f) |FINSEQ-1K17 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (<*FINSEQ-1K10 p*>)^FINSEQ-1K8 f  |FINSEQ-1K17 k"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma finseq_6_lm_4:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds k1 <XXREAL-0R3 k2 & k1 inTARSKIR2 domFINSEQ-1K5 f implies midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,k1,k2) =FINSEQ-1R1 (<*FINSEQ-1K10 f .FUNCT-1K1 k1*>)^FINSEQ-1K8 (midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,k1 +NAT-1K1 \<one>\<^sub>M,k2))"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds k1 <XXREAL-0R3 k2 implies (k1 inTARSKIR2 domFINSEQ-1K5 f implies midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,k1,k2) =HIDDENR1 (<*FINSEQ-1K10 f .FUNCT-1K1 k1*>)^FINSEQ-1K8 (midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,k1 +NAT-1K1 \<one>\<^sub>M,k2)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    fix k1 assume [ty]: "k1 be NatNAT-1M1"
    fix k2 assume [ty]: "k2 be NatNAT-1M1"
    assume A1: "k1 <XXREAL-0R3 k2"
    then have A2: "k1 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k2"
      using nat_1_th_13 sorry
    have A3: "\<one>\<^sub>M <=XXREAL-0R1 k2 -'NAT-DK9 k1"
    proof-
      show "\<one>\<^sub>M <=XXREAL-0R1 k2 -'NAT-DK9 k1"
      proof-
        have cases: "k1 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 k2 or k1 +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 k2"
          using A2 xxreal_0_th_1 sorry
        have case1: "k1 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 k2 implies \<one>\<^sub>M <=XXREAL-0R1 k2 -'NAT-DK9 k1"
        proof(rule impI)
          assume "k1 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 k2"
          thus "\<one>\<^sub>M <=XXREAL-0R1 k2 -'NAT-DK9 k1"
            using nat_d_th_34 sorry
        qed
        have case2: "k1 +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 k2 implies \<one>\<^sub>M <=XXREAL-0R1 k2 -'NAT-DK9 k1"
        proof(rule impI)
          assume A4: "k1 +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 k2"
          have "k2 -'NAT-DK9 k1 <=XXREAL-0R1 \<one>\<^sub>M implies k2 <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 k1"
          proof(rule impI)
            assume "k2 -'NAT-DK9 k1 <=XXREAL-0R1 \<one>\<^sub>M"
            then have "(k2 -'NAT-DK9 k1)+XCMPLX-0K2 k1 <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 k1"
              using xreal_1_th_6 sorry
            thus "k2 <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 k1"
              using A1 xreal_1_th_235 sorry
          qed
          thus "\<one>\<^sub>M <=XXREAL-0R1 k2 -'NAT-DK9 k1"
            using A4 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    then have "k2 -'NAT-DK9 k1 =XBOOLE-0R4 k2 -XCMPLX-0K6 k1"
      using nat_d_th_39 sorry
    then have A5: "(k2 -'NAT-DK9 k1)-'NAT-DK9 \<one>\<^sub>M =HIDDENR1 (k2 -XCMPLX-0K6 k1)-XCMPLX-0K6 \<one>\<^sub>M"
      using A3 xreal_1_th_233 sorry
    also have "... = k2 -XCMPLX-0K6 (k1 +NAT-1K1 \<one>\<^sub>M)"
       sorry
    also have "... = k2 -'NAT-DK9 (k1 +NAT-1K1 \<one>\<^sub>M)"
      using A2 xreal_1_th_233 sorry
    finally have "(k2 -'NAT-DK9 k1)-'NAT-DK9 \<one>\<^sub>M =HIDDENR1 k2 -'NAT-DK9 (k1 +NAT-1K1 \<one>\<^sub>M)"
       sorry
    assume A6: "k1 inTARSKIR2 domFINSEQ-1K5 f"
    then have A7: "f .FUNCT-1K1 k1 =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> k1"
      using partfun1_def_6 sorry
    have "\<one>\<^sub>M <=XXREAL-0R1 k1"
      using A6 finseq_3_th_25 sorry
    then have "(k1 -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 k1"
      using xreal_1_th_235 sorry
    then have "f /^RFINSEQK2\<^bsub>(D)\<^esub> (k1 -'NAT-DK9 \<one>\<^sub>M) =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> k1*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> k1)"
      using A6 finseq_5_th_31 sorry
    then have "midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,k1,k2) =HIDDENR1 ((<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> k1*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> k1)) |FINSEQ-1K18\<^bsub>(D)\<^esub> ((k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M)"
      using A1 finseq_6_def_3 sorry
    also have "... = (<*FINSEQ-1K10 f .FUNCT-1K1 k1*>)^FINSEQ-1K8 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k1) |FINSEQ-1K18\<^bsub>(D)\<^esub> (k2 -'NAT-DK9 k1)"
      using A7 finseq_6_th_125 sorry
    also have "... = (<*FINSEQ-1K10 f .FUNCT-1K1 k1*>)^FINSEQ-1K8 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k1) |FINSEQ-1K18\<^bsub>(D)\<^esub> ((k2 -'NAT-DK9 (k1 +NAT-1K1 \<one>\<^sub>M))+NAT-1K1 \<one>\<^sub>M)"
      using A3 A5 xreal_1_th_235 sorry
    also have "... = (<*FINSEQ-1K10 f .FUNCT-1K1 k1*>)^FINSEQ-1K8 (f /^RFINSEQK2\<^bsub>(D)\<^esub> ((k1 +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K18\<^bsub>(D)\<^esub> ((k2 -'NAT-DK9 (k1 +NAT-1K1 \<one>\<^sub>M))+NAT-1K1 \<one>\<^sub>M)"
      using nat_d_th_34 sorry
    also have "... = (<*FINSEQ-1K10 f .FUNCT-1K1 k1*>)^FINSEQ-1K8 (midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,k1 +NAT-1K1 \<one>\<^sub>M,k2))"
      using A2 finseq_6_def_3 sorry
    finally show "midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,k1,k2) =HIDDENR1 (<*FINSEQ-1K10 f .FUNCT-1K1 k1*>)^FINSEQ-1K8 (midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,k1 +NAT-1K1 \<one>\<^sub>M,k2))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_126:
" for p be FinSequenceFINSEQ-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds k1 <XXREAL-0R3 k2 & k1 inTARSKIR2 domFINSEQ-1K5 p implies midFINSEQ-6K2(p,k1,k2) =FINSEQ-1R1 (<*FINSEQ-1K10 p .FUNCT-1K1 k1*>)^FINSEQ-1K8 (midFINSEQ-6K2(p,k1 +NAT-1K1 \<one>\<^sub>M,k2))"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
  fix k1 assume [ty]: "k1 be NatNAT-1M1"
  fix k2 assume [ty]: "k2 be NatNAT-1M1"
  assume A1: "k1 <XXREAL-0R3 k2 & k1 inTARSKIR2 domFINSEQ-1K5 p"
  then obtain D where 
    [ty]:"D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and DDef:"D = rngFUNCT-1K2 p"
    using funct_1_th_3 sorry
  obtain q where 
    [ty]:"q be FinSequenceFINSEQ-1M3-of D" and qDef:"q = p"
    using finseq_1_def_4 sorry
  have "midFINSEQ-6K3\<^bsub>(D)\<^esub>(q,k1,k2) =FINSEQ-1R1 (<*FINSEQ-1K10 q .FUNCT-1K1 k1*>)^FINSEQ-1K8 (midFINSEQ-6K3\<^bsub>(D)\<^esub>(q,k1 +NAT-1K1 \<one>\<^sub>M,k2))"
    using A1 finseq_6_lm_4 sorry
  thus "midFINSEQ-6K2(p,k1,k2) =FINSEQ-1R1 (<*FINSEQ-1K10 p .FUNCT-1K1 k1*>)^FINSEQ-1K8 (midFINSEQ-6K2(p,k1 +NAT-1K1 \<one>\<^sub>M,k2))"
     sorry
qed "sorry"

(*begin*)
reserve p, q for "FinSequenceFINSEQ-1M1"
reserve X, Y, x, y for "setHIDDENM2"
reserve D for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve i, j, k, l, m, n, r for "NatNAT-1M1"
mtheorem finseq_6_th_127:
" for m be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 n iff ( ex i be NatNAT-1M1 st (m <=XXREAL-0R1 i & i <XXREAL-0R3 n) & k =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M)"
proof-
  have " for m be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 n implies ( ex i be NatNAT-1M1 st m <=XXREAL-0R1 i & (i <XXREAL-0R3 n & k =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M))) & (( ex i be NatNAT-1M1 st (m <=XXREAL-0R1 i & i <XXREAL-0R3 n) & k =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M) implies m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 n)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix m assume [ty]: "m be NatNAT-1M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    show "m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 n implies ( ex i be NatNAT-1M1 st m <=XXREAL-0R1 i & (i <XXREAL-0R3 n & k =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M))"
    proof(rule impMI ,rule impI)
      obtain a19 where 
        [ty]:"a19 be IntegerINT-1M1" and a19Def:"a19 = \<one>\<^sub>M"
         sorry
      obtain k9 where 
        [ty]:"k9 be IntegerINT-1M1" and k9Def:"k9 = k"
         sorry
      assume A1: "m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k"
        and A2: "k <=XXREAL-0R1 n"
      have "\<one>\<^sub>M <=XXREAL-0R1 m +NAT-1K1 \<one>\<^sub>M"
        using nat_1_th_11 sorry
      then have "k9 -XCMPLX-0K6 a19 inTARSKIR2 NATNUMBERSK1"
        using A1 int_1_th_5 xxreal_0_th_2 sorry
      then obtain i where 
        [ty]:"i be NatNAT-1M1" and iDef:"i = k9 -XCMPLX-0K6 a19"
         sorry
      show " ex i be NatNAT-1M1 st m <=XXREAL-0R1 i & (i <XXREAL-0R3 n & k =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M)"
      proof(rule bexI[of _ "i"],rule conjMI,rule conjMI)
        have "(m +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 k -XCMPLX-0K6 \<one>\<^sub>M"
          using A1 xreal_1_th_9 sorry
        thus "m <=XXREAL-0R1 i"
           sorry
        have "k <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_13 sorry
        then have "k -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 (k +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
          using xreal_1_th_9 sorry
        thus "i <XXREAL-0R3 n"
          using A2 xxreal_0_th_2 sorry
        show "k =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M"
           sorry
      qed "sorry"
    qed
    assume Given: " ex i be NatNAT-1M1 st (m <=XXREAL-0R1 i & i <XXREAL-0R3 n) & k =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M"
    then obtain i where
      [ty]:"i be NatNAT-1M1" and 
      A3: "m <=XXREAL-0R1 i"and A4: "i <XXREAL-0R3 n"and A5: "k =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M"
       sorry
    show "m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 n"
      using A3 A4 A5 nat_1_th_13 xreal_1_th_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_128:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for n be NatNAT-1M1 holds q =FINSEQ-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 n implies lenFINSEQ-1K4 q <=XXREAL-0R1 lenFINSEQ-1K4 p & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q implies p .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i)"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for n be NatNAT-1M1 holds q =FINSEQ-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 n implies lenFINSEQ-1K4 q <=XXREAL-0R1 lenFINSEQ-1K4 p & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q implies p .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "q =FINSEQ-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 n"
    show "lenFINSEQ-1K4 q <=XXREAL-0R1 lenFINSEQ-1K4 p & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q implies p .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i)"
    proof-
      have cases: "n <=XXREAL-0R1 lenFINSEQ-1K4 p or lenFINSEQ-1K4 p <=XXREAL-0R1 n"
         sorry
      have case1: "n <=XXREAL-0R1 lenFINSEQ-1K4 p implies lenFINSEQ-1K4 q <=XXREAL-0R1 lenFINSEQ-1K4 p & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q implies p .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i)"
      proof(rule impI,rule conjMI,rule ballI,rule impMI ,rule impI)
        assume A2: "n <=XXREAL-0R1 lenFINSEQ-1K4 p"
        thus "lenFINSEQ-1K4 q <=XXREAL-0R1 lenFINSEQ-1K4 p"
          using A1 finseq_1_th_17 sorry
        fix i assume [ty]: "i be NatNAT-1M1"
        assume A3: "\<one>\<^sub>M <=XXREAL-0R1 i"
          and A4: "i <=XXREAL-0R1 lenFINSEQ-1K4 q"
        have "lenFINSEQ-1K4 q =XBOOLE-0R4 n"
          using A1 A2 finseq_1_th_17 sorry
        then have "i inTARSKIR2 SegFINSEQ-1K2 n"
          using A3 A4 sorry
        thus "p .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i"
          using A1 funct_1_th_49 sorry
      qed "sorry"
      have case2: "lenFINSEQ-1K4 p <=XXREAL-0R1 n implies lenFINSEQ-1K4 q <=XXREAL-0R1 lenFINSEQ-1K4 p & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q implies p .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i)"
      proof(rule impI,rule conjMI,rule ballI,rule impMI ,rule impI)
        assume A5: "lenFINSEQ-1K4 p <=XXREAL-0R1 n"
        thus "lenFINSEQ-1K4 q <=XXREAL-0R1 lenFINSEQ-1K4 p"
          using A1 finseq_2_th_20 sorry
        fix i assume [ty]: "i be NatNAT-1M1"
        assume "\<one>\<^sub>M <=XXREAL-0R1 i"
          and "i <=XXREAL-0R1 lenFINSEQ-1K4 q"
        show "p .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i"
          using A1 A5 finseq_2_th_20 sorry
      qed "sorry"
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_129:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for k be NatNAT-1M1 holds X c=TARSKIR1 SegFINSEQ-1K2 k & Y c=TARSKIR1 domFINSEQ-1K5 (SgmFINSEQ-1K15 X) implies SgmFINSEQ-1K15 X *FUNCT-1K3 SgmFINSEQ-1K15 Y =FUNCT-1R1 SgmFINSEQ-1K15 (rngFUNCT-1K2 (SgmFINSEQ-1K15 X  |RELSET-1K5\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> Y))"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for k be NatNAT-1M1 holds X c=TARSKIR1 SegFINSEQ-1K2 k & Y c=TARSKIR1 domFINSEQ-1K5 (SgmFINSEQ-1K15 X) implies SgmFINSEQ-1K15 X *FUNCT-1K3 SgmFINSEQ-1K15 Y =FUNCT-1R1 SgmFINSEQ-1K15 (rngFUNCT-1K2 (SgmFINSEQ-1K15 X  |RELSET-1K5\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> Y))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix k assume [ty]: "k be NatNAT-1M1"
    assume A1: "X c=TARSKIR1 SegFINSEQ-1K2 k"
      and A2: "Y c=TARSKIR1 domFINSEQ-1K5 (SgmFINSEQ-1K15 X)"
    obtain Y9 where 
      [ty]:"Y9 be finiteFINSET-1V1\<bar>setHIDDENM2" and Y9Def:"Y9 = Y"
      using A2 sorry
    let ?M = "SgmFINSEQ-1K15 X *FUNCT-1K3 SgmFINSEQ-1K15 Y"
    let ?R = "rngFUNCT-1K2 (SgmFINSEQ-1K15 X  |RELSET-1K5\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> Y)"
    have A3: "Y c=TARSKIR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 (SgmFINSEQ-1K15 X))"
      using A2 finseq_1_def_3 sorry
    then have A4: "rngFUNCT-1K2 (SgmFINSEQ-1K15 Y) =XBOOLE-0R4 Y"
      using finseq_1_def_13 sorry
    have "domFINSEQ-1K5 (SgmFINSEQ-1K15 Y9) =XBOOLE-0R4 SegFINSEQ-1K2 (cardCARD-1K4 Y9)"
      using A3 finseq_3_th_40 sorry
    then have A5: "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ?M =XBOOLE-0R4 SegFINSEQ-1K2 (cardCARD-1K4 Y9)"
      using A2 A4 relat_1_th_27 sorry
    have A6: "rngFUNCT-1K2 (SgmFINSEQ-1K15 X) c=TARSKIR1 SegFINSEQ-1K2 k"
      using A1 finseq_1_def_13 sorry
    then have A7: "rngFUNCT-1K2 (SgmFINSEQ-1K15 X) c=TARSKIR1 NATNUMBERSK1"
      using xboole_1_th_1 sorry
    obtain M where 
      [ty]:"M be FinSequenceFINSEQ-1M1" and MDef:"M = ?M"
      using A5 finseq_1_def_2 sorry
    have "rngFUNCT-1K2 M c=TARSKIR1 rngFUNCT-1K2 (SgmFINSEQ-1K15 X)"
      using relat_1_th_26 sorry
    then have "rngFUNCT-1K2 M c=TARSKIR1 NATNUMBERSK1"
      using A7 sorry
    then obtain L where 
      [ty]:"L be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and LDef:"L = SgmFINSEQ-1K15 X *FUNCT-1K3 SgmFINSEQ-1K15 Y"
      using finseq_1_def_4 sorry
    have " for y be objectHIDDENM1 holds (y inHIDDENR3 rngFUNCT-1K2 L implies y inHIDDENR3 rngFUNCT-1K2 (SgmFINSEQ-1K15 X  |RELSET-1K5\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> Y)) & (y inHIDDENR3 rngFUNCT-1K2 (SgmFINSEQ-1K15 X  |RELSET-1K5\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> Y) implies y inHIDDENR3 rngFUNCT-1K2 L)"
    proof(rule ballI,rule conjMI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      show "y inHIDDENR3 rngFUNCT-1K2 L implies y inHIDDENR3 rngFUNCT-1K2 (SgmFINSEQ-1K15 X  |RELSET-1K5\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> Y)"
      proof(rule impI)
        assume "y inHIDDENR3 rngFUNCT-1K2 L"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A8: "x inHIDDENR3 domFINSEQ-1K5 L"and A9: "y =HIDDENR1 L .FUNCT-1K1 x"
          using funct_1_def_3 sorry
        have "x inHIDDENR3 domFINSEQ-1K5 (SgmFINSEQ-1K15 Y)"
          using A8 funct_1_th_11 sorry
        then have A10: "SgmFINSEQ-1K15 Y .FUNCT-1K1 x inTARSKIR2 Y"
          using A4 funct_1_def_3 sorry
        have "y =HIDDENR1 SgmFINSEQ-1K15 X .FUNCT-1K1 (SgmFINSEQ-1K15 Y .FUNCT-1K1 x)"
          using A8 A9 funct_1_th_12 sorry
        thus "y inHIDDENR3 rngFUNCT-1K2 (SgmFINSEQ-1K15 X  |RELSET-1K5\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> Y)"
          using A2 A10 funct_1_th_50 sorry
      qed
      assume "y inHIDDENR3 ?R"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A11: "x inHIDDENR3 domRELSET-1K1\<^bsub>(Y)\<^esub> (SgmFINSEQ-1K15 X  |RELSET-1K5\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> Y)"and A12: "y =HIDDENR1 (SgmFINSEQ-1K15 X  |RELSET-1K5\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> Y).FUNCT-1K1 x"
        using funct_1_def_3 sorry
      have A13: "x inHIDDENR3 domFINSEQ-1K5 (SgmFINSEQ-1K15 X) /\\SUBSET-1K8\<^bsub>(omegaORDINAL1K4)\<^esub> Y"
        using A11 relat_1_th_61 sorry
      then have A14: "x inHIDDENR3 Y"
        using xboole_0_def_4 sorry
      then obtain z where
        [ty]:"z be objectHIDDENM1" and 
        A15: "z inHIDDENR3 domFINSEQ-1K5 (SgmFINSEQ-1K15 Y)"and A16: "x =HIDDENR1 SgmFINSEQ-1K15 Y .FUNCT-1K1 z"
        using A4 funct_1_def_3 sorry
      have "x inHIDDENR3 domFINSEQ-1K5 (SgmFINSEQ-1K15 X)"
        using A13 xboole_0_def_4 sorry
      then have A17: "z inHIDDENR3 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> (SgmFINSEQ-1K15 X *FUNCT-1K3 SgmFINSEQ-1K15 Y)"
        using A15 A16 funct_1_th_11 sorry
      have "y =HIDDENR1 SgmFINSEQ-1K15 X .FUNCT-1K1 x"
        using A12 A14 funct_1_th_49 sorry
      then have "L .FUNCT-1K1 z =HIDDENR1 y"
        using A16 A17 funct_1_th_12 sorry
      thus "y inHIDDENR3 rngFUNCT-1K2 L"
        using A17 funct_1_def_3 sorry
    qed "sorry"
    then have A18: "rngFUNCT-1K2 L =XBOOLE-0R4 ?R"
      using tarski_th_2 sorry
    have A19: " for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 l & (l <XXREAL-0R3 m & (m <=XXREAL-0R1 lenFINSEQ-1K4 L & (k1 =XBOOLE-0R4 L .FUNCT-1K1 l & k2 =XBOOLE-0R4 L .FUNCT-1K1 m))) implies k1 <XXREAL-0R3 k2"
    proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
      fix l assume [ty]: "l be NatNAT-1M1"
      fix m assume [ty]: "m be NatNAT-1M1"
      fix k1 assume [ty]: "k1 be NatNAT-1M1"
      fix k2 assume [ty]: "k2 be NatNAT-1M1"
      assume A20: "\<one>\<^sub>M <=XXREAL-0R1 l"
        and A21: "l <XXREAL-0R3 m"
        and A22: "m <=XXREAL-0R1 lenFINSEQ-1K4 L"
        and A23: "k1 =XBOOLE-0R4 L .FUNCT-1K1 l"
        and A24: "k2 =XBOOLE-0R4 L .FUNCT-1K1 m"
      have "l <=XXREAL-0R1 lenFINSEQ-1K4 L"
        using A21 A22 xxreal_0_th_2 sorry
      then have A25: "l inTARSKIR2 domFINSEQ-1K5 L"
        using A20 finseq_3_th_25 sorry
      then have A26: "L .FUNCT-1K1 l =XBOOLE-0R4 SgmFINSEQ-1K15 X .FUNCT-1K1 (SgmFINSEQ-1K15 Y .FUNCT-1K1 l)"
        using funct_1_th_12 sorry
      have "\<one>\<^sub>M <=XXREAL-0R1 m"
        using A20 A21 xxreal_0_th_2 sorry
      then have A27: "m inTARSKIR2 domFINSEQ-1K5 L"
        using A22 finseq_3_th_25 sorry
      then have A28: "L .FUNCT-1K1 m =XBOOLE-0R4 SgmFINSEQ-1K15 X .FUNCT-1K1 (SgmFINSEQ-1K15 Y .FUNCT-1K1 m)"
        using funct_1_th_12 sorry
      have A29: "SgmFINSEQ-1K15 Y .FUNCT-1K1 l inTARSKIR2 domFINSEQ-1K5 (SgmFINSEQ-1K15 X)"
        using A25 funct_1_th_11 sorry
      have "m inTARSKIR2 domFINSEQ-1K5 (SgmFINSEQ-1K15 Y)"
        using A27 funct_1_th_11 sorry
      then have A30: "m <=XXREAL-0R1 lenFINSEQ-1K4 (SgmFINSEQ-1K15 Y)"
        using finseq_3_th_25 sorry
      have A31: "SgmFINSEQ-1K15 Y .FUNCT-1K1 m inTARSKIR2 domFINSEQ-1K5 (SgmFINSEQ-1K15 X)"
        using A27 funct_1_th_11 sorry
      have 
        [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1" and
        [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1"
        using ordinal1_def_12 sorry
      obtain K1 K2 where 
        [ty]:"K1 be ElementSUBSET-1M1-of NATNUMBERSK1" and K1Def:"K1 = SgmFINSEQ-1K15 Y .FUNCT-1K1 l" and
        [ty]:"K2 be ElementSUBSET-1M1-of NATNUMBERSK1" and K2Def:"K2 = SgmFINSEQ-1K15 Y .FUNCT-1K1 m"
        using ordinal1_def_12 sorry
      have A32: "\<one>\<^sub>M <=XXREAL-0R1 K1"
        using A29 finseq_3_th_25 sorry
      have A33: "K2 <=XXREAL-0R1 lenFINSEQ-1K4 (SgmFINSEQ-1K15 X)"
        using A31 finseq_3_th_25 sorry
      have "K1 <XXREAL-0R3 K2"
        using A3 A20 A21 A30 finseq_1_def_13 sorry
      thus "k1 <XXREAL-0R3 k2"
        using A1 A23 A24 A26 A28 A32 A33 finseq_1_def_13 sorry
    qed "sorry"
    have "?R c=TARSKIR1 rngFUNCT-1K2 (SgmFINSEQ-1K15 X)"
      using relat_1_th_70 sorry
    then have "?R c=TARSKIR1 SegFINSEQ-1K2 k"
      using A6 sorry
    thus "SgmFINSEQ-1K15 X *FUNCT-1K3 SgmFINSEQ-1K15 Y =FUNCT-1R1 SgmFINSEQ-1K15 (rngFUNCT-1K2 (SgmFINSEQ-1K15 X  |RELSET-1K5\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> Y))"
      using A18 A19 finseq_1_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma finseq_6_lm_5:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for F be finiteFINSET-1V1\<bar>setHIDDENM2 holds F =XBOOLE-0R4 {k where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +XCMPLX-0K2 n } implies cardCARD-1K4 F =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
proof-
  have " for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for F be finiteFINSET-1V1\<bar>setHIDDENM2 holds  not (F =XBOOLE-0R4 {k where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +XCMPLX-0K2 n } &  not cardCARD-1K4 F =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M)"
  proof(rule ballI)
    fix m assume [ty]: "m be NatNAT-1M1"
    let ?P = "\<lambda>Lamb1.  for F be finiteFINSET-1V1\<bar>setHIDDENM2 holds F =XBOOLE-0R4 {k where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +XCMPLX-0K2 Lamb1 } implies cardCARD-1K4 F =XBOOLE-0R4 Lamb1 +NAT-1K1 \<one>\<^sub>M"
    have A1: " for n be NatNAT-1M1 holds ( for F be finiteFINSET-1V1\<bar>setHIDDENM2 holds F =XBOOLE-0R4 {k where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +XCMPLX-0K2 n } implies cardCARD-1K4 F =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M) implies ( for F be finiteFINSET-1V1\<bar>setHIDDENM2 holds F =XBOOLE-0R4 {k where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +XCMPLX-0K2 (n +NAT-1K1 \<one>\<^sub>M) } implies cardCARD-1K4 F =XBOOLE-0R4 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix n assume [ty]: "n be NatNAT-1M1"
      assume A2: "?P(n)"
      show " for F be finiteFINSET-1V1\<bar>setHIDDENM2 holds F =XBOOLE-0R4 {k where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +XCMPLX-0K2 (n +NAT-1K1 \<one>\<^sub>M) } implies cardCARD-1K4 F =XBOOLE-0R4 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
      proof-
        have " for F be finiteFINSET-1V1\<bar>setHIDDENM2 holds F =XBOOLE-0R4 {k where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +NAT-1K1 (n +NAT-1K1 \<one>\<^sub>M) } implies cardCARD-1K4 F =XBOOLE-0R4 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
        proof(rule ballI,rule impI)
          have A3: "succORDINAL1K1 (SegmCARD-1K5 (m +XCMPLX-0K2 n)) =XBOOLE-0R4 {k where k be NatNAT-1M1 : k <=XXREAL-0R1 m +XCMPLX-0K2 n }"
            using nat_1_th_54 sorry
          let ?F1 = "{k where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +XCMPLX-0K2 n }"
          have "?F1 c=TARSKIR1 succORDINAL1K1 (SegmCARD-1K5 (m +XCMPLX-0K2 n))"
          proof-
            have "{k where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +XCMPLX-0K2 n } c=TARSKIR1 succORDINAL1K1 (SegmCARD-1K5 (m +XCMPLX-0K2 n))"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 {k where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +XCMPLX-0K2 n } implies x inHIDDENR3 succORDINAL1K1 (SegmCARD-1K5 (m +XCMPLX-0K2 n))"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 ?F1"
                then have " ex k be NatNAT-1M1 st (x =HIDDENR1 k & m <=XXREAL-0R1 k) & k <=XXREAL-0R1 m +XCMPLX-0K2 n"
                   sorry
                thus "x inHIDDENR3 succORDINAL1K1 (SegmCARD-1K5 (m +XCMPLX-0K2 n))"
                  using A3 sorry
              qed "sorry"
              thus "{k where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +XCMPLX-0K2 n } c=TARSKIR1 succORDINAL1K1 (SegmCARD-1K5 (m +XCMPLX-0K2 n))"
                using tarski_def_3 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          then obtain F1 where 
            [ty]:"F1 be finiteFINSET-1V1\<bar>setHIDDENM2" and F1Def:"F1 = ?F1"
             sorry
          fix F assume [ty]: "F be finiteFINSET-1V1\<bar>setHIDDENM2"
          have A4: " not m +NAT-1K1 (n +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 {k where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +XCMPLX-0K2 n }"
          proof-
            have " not ( not m +NAT-1K1 (n +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 {k where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +XCMPLX-0K2 n }) implies  False "
            proof(rule impI)
              assume " not ( not m +NAT-1K1 (n +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 {k where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +XCMPLX-0K2 n })"
              then have " ex k be NatNAT-1M1 st (m +NAT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 k & m <=XXREAL-0R1 k) & k <=XXREAL-0R1 m +XCMPLX-0K2 n"
                 sorry
              then have "(m +XCMPLX-0K2 n)+NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 (m +XCMPLX-0K2 n)+NAT-1K1 0NUMBERSK6"
                 sorry
              thus " False "
                using xreal_1_th_6 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          assume A5: "F =XBOOLE-0R4 {k where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +NAT-1K1 (n +NAT-1K1 \<one>\<^sub>M) }"
          have " for x be objectHIDDENM1 holds (x inHIDDENR3 F implies x inHIDDENR3 F1 \\/XBOOLE-0K2 {TARSKIK1 m +NAT-1K1 (n +NAT-1K1 \<one>\<^sub>M) }) & (x inHIDDENR3 F1 \\/XBOOLE-0K2 {TARSKIK1 m +NAT-1K1 (n +NAT-1K1 \<one>\<^sub>M) } implies x inHIDDENR3 F)"
          proof(rule ballI,rule conjMI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            show "x inHIDDENR3 F implies x inHIDDENR3 F1 \\/XBOOLE-0K2 {TARSKIK1 m +NAT-1K1 (n +NAT-1K1 \<one>\<^sub>M) }"
            proof(rule impI)
              assume "x inHIDDENR3 F"
              then obtain k where
                [ty]:"k be NatNAT-1M1" and 
                A6: "x =HIDDENR1 k"and A7: "m <=XXREAL-0R1 k"and A8: "k <=XXREAL-0R1 m +NAT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
                using A5 sorry
              have "k <=XXREAL-0R1 (m +XCMPLX-0K2 n)+NAT-1K1 \<one>\<^sub>M"
                using A8 sorry
              then have "k <=XXREAL-0R1 m +XCMPLX-0K2 n or k =XBOOLE-0R4 m +NAT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
                using nat_1_th_8 sorry
              then have "k inTARSKIR2 F1 or k inTARSKIR2 {TARSKIK1 m +NAT-1K1 (n +NAT-1K1 \<one>\<^sub>M) }"
                using A7 tarski_def_1 sorry
              thus "x inHIDDENR3 F1 \\/XBOOLE-0K2 {TARSKIK1 m +NAT-1K1 (n +NAT-1K1 \<one>\<^sub>M) }"
                using A6 xboole_0_def_3 sorry
            qed
            assume A9: "x inHIDDENR3 F1 \\/XBOOLE-0K2 {TARSKIK1 m +NAT-1K1 (n +NAT-1K1 \<one>\<^sub>M) }"
            show "x inHIDDENR3 F"
            proof-
              have cases: "x inHIDDENR3 F1 or x inHIDDENR3 {TARSKIK1 m +NAT-1K1 (n +NAT-1K1 \<one>\<^sub>M) }"
                using A9 xboole_0_def_3 sorry
              have case1: "x inHIDDENR3 F1 implies x inHIDDENR3 F"
              proof(rule impI)
                assume "x inHIDDENR3 F1"
                then obtain k where
                  [ty]:"k be NatNAT-1M1" and 
                  A10: "x =HIDDENR1 k"and A11: "m <=XXREAL-0R1 k"and A12: "k <=XXREAL-0R1 m +XCMPLX-0K2 n"
                   sorry
                have "k <=XXREAL-0R1 (m +XCMPLX-0K2 n)+NAT-1K1 \<one>\<^sub>M"
                  using A12 nat_1_th_12 sorry
                thus "x inHIDDENR3 F"
                  using A5 A10 A11 sorry
              qed
              have case2: "x inHIDDENR3 {TARSKIK1 m +NAT-1K1 (n +NAT-1K1 \<one>\<^sub>M) } implies x inHIDDENR3 F"
              proof(rule impI)
                assume A13: "x inHIDDENR3 {TARSKIK1 m +NAT-1K1 (n +NAT-1K1 \<one>\<^sub>M) }"
                then obtain k where 
                  [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = x"
                  using tarski_def_1 sorry
                have A14: "x =HIDDENR1 m +NAT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
                  using A13 tarski_def_1 sorry
                then have "m <=XXREAL-0R1 k"
                  using nat_1_th_11 sorry
                thus "x inHIDDENR3 F"
                  using A5 A14 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed "sorry"
          then have A15: "F =XBOOLE-0R4 ({k where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +XCMPLX-0K2 n })\\/XBOOLE-0K2 {TARSKIK1 m +NAT-1K1 (n +NAT-1K1 \<one>\<^sub>M) }"
            using tarski_th_2 sorry
          have "cardCARD-1K4 F1 =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
            using A2 sorry
          thus "cardCARD-1K4 F =XBOOLE-0R4 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
            using A15 A4 card_2_th_41 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed "sorry"
    have A16: "?P(0NUMBERSK6)"
    proof-
      have " for F be finiteFINSET-1V1\<bar>setHIDDENM2 holds F =XBOOLE-0R4 {k where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +NAT-1K1 0NUMBERSK6 } implies cardCARD-1K4 F =XBOOLE-0R4 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
      proof(rule ballI,rule impI)
        fix F assume [ty]: "F be finiteFINSET-1V1\<bar>setHIDDENM2"
        assume A17: "F =XBOOLE-0R4 {k where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +NAT-1K1 0NUMBERSK6 }"
        have " for x be objectHIDDENM1 holds (x inHIDDENR3 F implies x =HIDDENR1 m) & (x =HIDDENR1 m implies x inHIDDENR3 F)"
        proof(rule ballI,rule conjMI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          show "x inHIDDENR3 F implies x =HIDDENR1 m"
          proof(rule impI)
            assume "x inHIDDENR3 F"
            then have " ex k be NatNAT-1M1 st (x =HIDDENR1 k & m <=XXREAL-0R1 k) & k <=XXREAL-0R1 m +NAT-1K1 0NUMBERSK6"
              using A17 sorry
            thus "x =HIDDENR1 m"
              using xxreal_0_th_1 sorry
          qed
          assume "x =HIDDENR1 m"
          thus "x inHIDDENR3 F"
            using A17 sorry
        qed "sorry"
        then have "F =XBOOLE-0R4 {TARSKIK1 m}"
          using tarski_def_1 sorry
        thus "cardCARD-1K4 F =XBOOLE-0R4 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
          using card_1_th_30 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A16 A1 sorry
    thus " for n be NatNAT-1M1 holds  for F be finiteFINSET-1V1\<bar>setHIDDENM2 holds  not (F =XBOOLE-0R4 {k where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +XCMPLX-0K2 n } &  not cardCARD-1K4 F =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_130:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds cardCARD-1K1 ({k where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +XCMPLX-0K2 n }) =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
proof(rule ballI,rule ballI)
  let ?F = "\<lambda>Lamb1. Lamb1"
  fix m assume [ty]: "m be NatNAT-1M1"
  fix n assume [ty]: "n be NatNAT-1M1"
  let ?P = "\<lambda>Lamb1. m <=XXREAL-0R1 Lamb1"
  let ?FF = "{?F(k) where k be NatNAT-1M1 : k <=XXREAL-0R1 m +XCMPLX-0K2 n & ?P(k) }"
  have "?FF be finiteFINSET-1V1"
    using finseq_1_sch_6 sorry
  then obtain FF where 
    [ty]:"FF be finiteFINSET-1V1\<bar>setHIDDENM2" and FFDef:"FF = ?FF"
     sorry
  have "FF =XBOOLE-0R4 {?F(k) where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +XCMPLX-0K2 n }"
  proof-
    have "FF =XBOOLE-0R4 {k where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +XCMPLX-0K2 n }"
    proof-
      have "FF c=TARSKIR1 {k where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +XCMPLX-0K2 n } & {k where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +XCMPLX-0K2 n } c=TARSKIR1 FF"
      proof(rule conjMI)
        show "FF c=TARSKIR1 {k where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +XCMPLX-0K2 n }"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 FF implies x inHIDDENR3 {k where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +XCMPLX-0K2 n }"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 FF"
            then have " ex k1 be NatNAT-1M1 st (x =HIDDENR1 ?F(k1) & k1 <=XXREAL-0R1 m +XCMPLX-0K2 n) & m <=XXREAL-0R1 k1"
               sorry
            then have " ex k1 be NatNAT-1M1 st (x =HIDDENR1 ?F(k1) & m <=XXREAL-0R1 k1) & k1 <=XXREAL-0R1 m +XCMPLX-0K2 n"
               sorry
            thus "x inHIDDENR3 {k where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +XCMPLX-0K2 n }"
               sorry
          qed "sorry"
          thus "FF c=TARSKIR1 {?F(k) where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +XCMPLX-0K2 n }"
            using tarski_def_3 sorry
        qed
        have " for x be objectHIDDENM1 holds x inHIDDENR3 {k where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +XCMPLX-0K2 n } implies x inHIDDENR3 FF"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 {?F(k) where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +XCMPLX-0K2 n }"
          then have " ex k1 be NatNAT-1M1 st (x =HIDDENR1 ?F(k1) & m <=XXREAL-0R1 k1) & k1 <=XXREAL-0R1 m +XCMPLX-0K2 n"
             sorry
          thus "x inHIDDENR3 FF"
             sorry
        qed "sorry"
        thus "{?F(k) where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +XCMPLX-0K2 n } c=TARSKIR1 FF"
          using tarski_def_3 sorry
      qed
      thus "FF =XBOOLE-0R4 {?F(k) where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +XCMPLX-0K2 n }"
        using xboole_0_def_10 sorry
    qed
    thus " ?thesis "
       sorry
  qed
  then obtain G where 
    [ty]:"G be finiteFINSET-1V1\<bar>setHIDDENM2" and GDef:"G = {?F(k) where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +XCMPLX-0K2 n }"
     sorry
  have "cardCARD-1K4 G =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
    using finseq_6_lm_5 sorry
  thus "cardCARD-1K1 ({k where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +XCMPLX-0K2 n }) =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
     sorry
qed "sorry"

mtheorem finseq_6_th_131:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for l be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 l & l <=XXREAL-0R1 n implies SgmFINSEQ-1K15 ({kk where kk be NatNAT-1M1 : m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 kk & kk <=XXREAL-0R1 m +XCMPLX-0K2 n }) .FUNCT-1K1 l =XBOOLE-0R4 m +XCMPLX-0K2 l"
proof-
  have " for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds ( ex l be NatNAT-1M1 st (\<one>\<^sub>M <=XXREAL-0R1 l & l <=XXREAL-0R1 n) & SgmFINSEQ-1K15 ({kk where kk be NatNAT-1M1 : m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 kk & kk <=XXREAL-0R1 m +XCMPLX-0K2 n }) .FUNCT-1K1 l <>HIDDENR2 m +XCMPLX-0K2 l) implies  False "
  proof(rule ballI,rule ballI,rule impI)
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?F = "SgmFINSEQ-1K15 ({kk where kk be NatNAT-1M1 : m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 kk & kk <=XXREAL-0R1 m +XCMPLX-0K2 n })"
    let ?P = "\<lambda>Lamb1. (\<one>\<^sub>M <=XXREAL-0R1 Lamb1 & Lamb1 <=XXREAL-0R1 n) & ?F .FUNCT-1K1 Lamb1 <>HIDDENR2 m +XCMPLX-0K2 Lamb1"
    let ?rF = "{kk where kk be NatNAT-1M1 : m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 kk & kk <=XXREAL-0R1 m +XCMPLX-0K2 n }"
    have A1: "?rF c=TARSKIR1 SegFINSEQ-1K2 (m +XCMPLX-0K2 n)"
    proof-
      have "{kk where kk be NatNAT-1M1 : m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 kk & kk <=XXREAL-0R1 m +XCMPLX-0K2 n } c=TARSKIR1 SegFINSEQ-1K2 (m +XCMPLX-0K2 n)"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 {kk where kk be NatNAT-1M1 : m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 kk & kk <=XXREAL-0R1 m +XCMPLX-0K2 n } implies x inHIDDENR3 SegFINSEQ-1K2 (m +XCMPLX-0K2 n)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 ?rF"
          then obtain x9 where
            [ty]:"x9 be NatNAT-1M1" and 
            A2: "x9 =HIDDENR1 x"and A3: "m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 x9"and A4: "x9 <=XXREAL-0R1 m +XCMPLX-0K2 n"
             sorry
          have "\<one>\<^sub>M <=XXREAL-0R1 m +NAT-1K1 \<one>\<^sub>M"
            using nat_1_th_11 sorry
          then have "\<one>\<^sub>M <=XXREAL-0R1 x9"
            using A3 xxreal_0_th_2 sorry
          thus "x inHIDDENR3 SegFINSEQ-1K2 (m +XCMPLX-0K2 n)"
            using A2 A4 sorry
        qed "sorry"
        thus "{kk where kk be NatNAT-1M1 : m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 kk & kk <=XXREAL-0R1 m +XCMPLX-0K2 n } c=TARSKIR1 SegFINSEQ-1K2 (m +XCMPLX-0K2 n)"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    then obtain rF where 
      [ty]:"rF be finiteFINSET-1V1\<bar>setHIDDENM2" and rFDef:"rF = ?rF"
       sorry
    assume " ex l be NatNAT-1M1 st (\<one>\<^sub>M <=XXREAL-0R1 l & l <=XXREAL-0R1 n) & SgmFINSEQ-1K15 ({kk where kk be NatNAT-1M1 : m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 kk & kk <=XXREAL-0R1 m +XCMPLX-0K2 n }) .FUNCT-1K1 l <>HIDDENR2 m +XCMPLX-0K2 l"
    then have A5: " ex l be NatNAT-1M1 st ?P(l)"
       sorry
    obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A6: "?P(k)"and A7: " for nn be NatNAT-1M1 holds ?P(nn) implies k <=XXREAL-0R1 nn"
      using nat_1_sch_5 A5 sorry
    have 
      [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    have A8: "m +NAT-1K1 k <=XXREAL-0R1 m +XCMPLX-0K2 n"
      using A6 xreal_1_th_7 sorry
    obtain Fk where 
      [ty]:"Fk be ElementSUBSET-1M1-of NATNUMBERSK1" and FkDef:"Fk = ?F .FUNCT-1K1 k"
      using ordinal1_def_12 sorry
    have A9: "cardCARD-1K4 rF =XBOOLE-0R4 n"
    proof-
      show "cardCARD-1K4 rF =XBOOLE-0R4 n"
      proof-
        have cases: "n =XBOOLE-0R4 0NUMBERSK6 or 0NUMBERSK6 <XXREAL-0R3 n"
           sorry
        have case1: "n =XBOOLE-0R4 0NUMBERSK6 implies cardCARD-1K4 rF =XBOOLE-0R4 n"
        proof(rule impI)
          assume A10: "n =XBOOLE-0R4 0NUMBERSK6"
          have "rF =XBOOLE-0R4 {}XBOOLE-0K1"
          proof-
            have "rF <>HIDDENR2 {}XBOOLE-0K1 implies  False "
            proof(rule impI)
              assume "rF <>HIDDENR2 {}XBOOLE-0K1"
              then obtain x where
                [ty]:"x be objectHIDDENM1" and 
                A11: "x inHIDDENR3 rF"
                using xboole_0_def_1 sorry
              have " ex x9 be NatNAT-1M1 st (x9 =HIDDENR1 x & m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 x9) & x9 <=XXREAL-0R1 m +XCMPLX-0K2 n"
                using A11 sorry
              then have "m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m +NAT-1K1 0NUMBERSK6"
                using A10 xxreal_0_th_2 sorry
              thus " False "
                using xreal_1_th_6 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          thus "cardCARD-1K4 rF =XBOOLE-0R4 n"
            using A10 sorry
        qed
        have case2: "0NUMBERSK6 <XXREAL-0R3 n implies cardCARD-1K4 rF =XBOOLE-0R4 n"
        proof(rule impI)
          assume "0NUMBERSK6 <XXREAL-0R3 n"
          then have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
            using nat_1_th_13 sorry
          then have "\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 n -XCMPLX-0K6 \<one>\<^sub>M"
            using xreal_1_th_9 sorry
          then have "n -'NAT-DK9 \<one>\<^sub>M =XBOOLE-0R4 n -XCMPLX-0K6 \<one>\<^sub>M"
            using xreal_0_def_2 sorry
          then obtain n1 where 
            [ty]:"n1 be ElementSUBSET-1M1-of NATNUMBERSK1" and n1Def:"n1 = n -XCMPLX-0K6 \<one>\<^sub>M"
             sorry
          have "(m +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 n1 =XBOOLE-0R4 m +XCMPLX-0K2 n"
             sorry
          then have "cardCARD-1K4 rF =XBOOLE-0R4 n1 +NAT-1K1 \<one>\<^sub>M"
            using finseq_6_th_130 sorry
          thus "cardCARD-1K4 rF =XBOOLE-0R4 n"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    then have A12: "lenFINSEQ-1K4 (SgmFINSEQ-1K15 rF) =XBOOLE-0R4 n"
      using A1 finseq_3_th_39 sorry
    have A13: "rngFUNCT-1K2 ?F =XBOOLE-0R4 rF"
      using A1 finseq_1_def_13 sorry
    have " for k be NatNAT-1M1 holds  for Fk be ElementSUBSET-1M1-of NATNUMBERSK1 holds (\<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 n) & Fk =XBOOLE-0R4 SgmFINSEQ-1K15 ({kk where kk be NatNAT-1M1 : m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 kk & kk <=XXREAL-0R1 m +XCMPLX-0K2 n }) .FUNCT-1K1 k implies m +XCMPLX-0K2 k <=XXREAL-0R1 Fk"
    proof-
      let ?P = "\<lambda>Lamb1.  for Fk be ElementSUBSET-1M1-of NATNUMBERSK1 holds (\<one>\<^sub>M <=XXREAL-0R1 Lamb1 & Lamb1 <=XXREAL-0R1 n) & Fk =XBOOLE-0R4 ?F .FUNCT-1K1 Lamb1 implies m +XCMPLX-0K2 Lamb1 <=XXREAL-0R1 Fk"
      have A14: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
      proof-
        have " for k be NatNAT-1M1 holds ?P(k) implies ( for Fk1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds \<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M & (k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n & Fk1 =XBOOLE-0R4 ?F .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)) implies m +XCMPLX-0K2 (k +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 Fk1)"
        proof(rule ballI,rule impI,rule ballI,rule impMI ,rule impMI ,rule impI)
          fix k assume [ty]: "k be NatNAT-1M1"
          assume A15: "?P(k)"
          have A16: "k <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M"
            using nat_1_th_13 sorry
          fix Fk1 assume [ty]: "Fk1 be ElementSUBSET-1M1-of NATNUMBERSK1"
          assume A17: "\<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
            and A18: "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
            and A19: "Fk1 =XBOOLE-0R4 ?F .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
          show "m +XCMPLX-0K2 (k +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 Fk1"
          proof-
            have cases: "\<one>\<^sub>M <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M or \<one>\<^sub>M =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
              using A17 xxreal_0_th_1 sorry
            have case1: "\<one>\<^sub>M <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M implies m +XCMPLX-0K2 (k +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 Fk1"
            proof(rule impI)
              assume A20: "\<one>\<^sub>M <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M"
              obtain Fk where 
                [ty]:"Fk be ElementSUBSET-1M1-of NATNUMBERSK1" and FkDef:"Fk = ?F .FUNCT-1K1 k"
                using ordinal1_def_12 sorry
              have A21: "\<one>\<^sub>M <=XXREAL-0R1 k"
                using A20 nat_1_th_13 sorry
              have "k <=XXREAL-0R1 n"
                using A18 nat_1_th_13 sorry
              then have A22: "m +XCMPLX-0K2 k <=XXREAL-0R1 Fk"
                using A15 A21 sorry
              have "Fk <XXREAL-0R3 Fk1"
                using A1 A12 A18 A19 A16 A21 finseq_1_def_13 sorry
              then have "m +XCMPLX-0K2 k <XXREAL-0R3 Fk1"
                using A22 xxreal_0_th_2 sorry
              then have "(m +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 Fk1"
                using nat_1_th_13 sorry
              thus "m +XCMPLX-0K2 (k +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 Fk1"
                 sorry
            qed
            have case2: "\<one>\<^sub>M =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M implies m +XCMPLX-0K2 (k +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 Fk1"
            proof(rule impI)
              assume A23: "\<one>\<^sub>M =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
              then have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ?F"
                using A12 A18 finseq_3_th_25 sorry
              then have "?F .FUNCT-1K1 \<one>\<^sub>M inTARSKIR2 rngFUNCT-1K2 ?F"
                using funct_1_def_3 sorry
              then have " ex F1 be NatNAT-1M1 st (F1 =XBOOLE-0R4 ?F .FUNCT-1K1 \<one>\<^sub>M & m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 F1) & F1 <=XXREAL-0R1 m +XCMPLX-0K2 n"
                using A13 sorry
              thus "m +XCMPLX-0K2 (k +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 Fk1"
                using A19 A23 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have A24: "?P(0NUMBERSK6)"
         sorry
      show " for k be NatNAT-1M1 holds  for Fk be ElementSUBSET-1M1-of NATNUMBERSK1 holds (\<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 n) & Fk =XBOOLE-0R4 SgmFINSEQ-1K15 ({kk where kk be NatNAT-1M1 : m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 kk & kk <=XXREAL-0R1 m +XCMPLX-0K2 n }) .FUNCT-1K1 k implies m +XCMPLX-0K2 k <=XXREAL-0R1 Fk"
        using nat_1_sch_2 A24 A14 sorry
    qed
    then have A25: "m +NAT-1K1 k <=XXREAL-0R1 Fk"
      using A6 sorry
    have "m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m +NAT-1K1 k"
      using A6 xreal_1_th_7 sorry
    then have "m +NAT-1K1 k inTARSKIR2 rF"
      using A8 sorry
    then have "m +NAT-1K1 k inTARSKIR2 rngFUNCT-1K2 (SgmFINSEQ-1K15 rF)"
      using A1 finseq_1_def_13 sorry
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A26: "x inHIDDENR3 domFINSEQ-1K5 (SgmFINSEQ-1K15 rF)"and A27: "m +NAT-1K1 k =XBOOLE-0R4 SgmFINSEQ-1K15 rF .FUNCT-1K1 x"
      using funct_1_def_3 sorry
    have 
      [ty]:"x be ElementSUBSET-1M1-of NATNUMBERSK1"
      using A26 sorry
    have A28: "domFINSEQ-1K5 (SgmFINSEQ-1K15 rF) =XBOOLE-0R4 SegFINSEQ-1K2 n"
      using A1 A9 finseq_3_th_40 sorry
    then have A29: "\<one>\<^sub>M <=XXREAL-0R1 x"
      using A26 finseq_1_th_1 sorry
    have A30: "x <=XXREAL-0R1 n"
      using A28 A26 finseq_1_th_1 sorry
    show " False "
    proof-
      have cases: "k <XXREAL-0R3 x or k >XXREAL-0R4 x"
        using A6 A27 xxreal_0_th_1 sorry
      have case1: "k <XXREAL-0R3 x implies  False "
      proof(rule impI)
        assume "k <XXREAL-0R3 x"
        thus " False "
          using A6 A1 A12 A27 A25 A30 finseq_1_def_13 sorry
      qed
      have case2: "k >XXREAL-0R4 x implies  False "
      proof(rule impI)
        assume A31: "k >XXREAL-0R4 x"
        have "?F .FUNCT-1K1 x <>HIDDENR2 m +NAT-1K1 x"
          using A6 A27 xcmplx_1_th_2 sorry
        thus " False "
          using A7 A29 A30 A31 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mdef finseq_6_def_4 ("'( _ , _ ')-cutFINSEQ-6K4  _ " [0,0,164]164 ) where
  mlet "p be FinSequenceFINSEQ-1M1", "m be NatNAT-1M1", "n be NatNAT-1M1"
"func (m,n)-cutFINSEQ-6K4 p \<rightarrow> FinSequenceFINSEQ-1M1 means
  \<lambda>it. lenFINSEQ-1K4 it +XCMPLX-0K2 m =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 it implies it .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (m +XCMPLX-0K2 i)) if (\<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 n) & n <=XXREAL-0R1 lenFINSEQ-1K4 p otherwise \<lambda>it. it =FINSEQ-1R1 {}XBOOLE-0K1"
proof-
  (*consistency*)
    show " for it be FinSequenceFINSEQ-1M1 holds  True "
       sorry
  (*existence*)
    show "((\<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 n) & n <=XXREAL-0R1 lenFINSEQ-1K4 p implies ( ex it be FinSequenceFINSEQ-1M1 st lenFINSEQ-1K4 it +XCMPLX-0K2 m =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 it implies it .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (m +XCMPLX-0K2 i)))) & ( not ((\<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 n) & n <=XXREAL-0R1 lenFINSEQ-1K4 p) implies ( ex it be FinSequenceFINSEQ-1M1 st it =FINSEQ-1R1 {}XBOOLE-0K1))"
    proof-
      have "(\<one>\<^sub>M <=XXREAL-0R1 m & (m <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 p) implies ( ex s be FinSequenceFINSEQ-1M1 st lenFINSEQ-1K4 s +XCMPLX-0K2 m =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for k be NatNAT-1M1 holds k <XXREAL-0R3 lenFINSEQ-1K4 s implies s .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 p .FUNCT-1K1 (m +XCMPLX-0K2 k)))) &  not ( not ((\<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 n) & n <=XXREAL-0R1 lenFINSEQ-1K4 p) & ( for VarFor1 be FinSequenceFINSEQ-1M1 holds  not VarFor1 =FINSEQ-1R1 {}XBOOLE-0K1))"
      proof(rule conjMI)
        show "\<one>\<^sub>M <=XXREAL-0R1 m & (m <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 p) implies ( ex s be FinSequenceFINSEQ-1M1 st lenFINSEQ-1K4 s +XCMPLX-0K2 m =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for k be NatNAT-1M1 holds k <XXREAL-0R3 lenFINSEQ-1K4 s implies s .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 p .FUNCT-1K1 (m +XCMPLX-0K2 k)))"
        proof(rule impMI ,rule impMI ,rule impI)
          let ?F = "\<lambda>Lamb1. p .FUNCT-1K1 (m +XCMPLX-0K2 (Lamb1 -XCMPLX-0K6 \<one>\<^sub>M))"
          assume "\<one>\<^sub>M <=XXREAL-0R1 m"
            and A1: "m <=XXREAL-0R1 n"
            and "n <=XXREAL-0R1 lenFINSEQ-1K4 p"
          obtain s where
            [ty]:"s be FinSequenceFINSEQ-1M1" and 
            A2: "lenFINSEQ-1K4 s =XBOOLE-0R4 (n +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 m & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 s implies s .FUNCT-1K1 k =XBOOLE-0R4 ?F(k))"
            using finseq_1_sch_2 sorry
          show " ex s be FinSequenceFINSEQ-1M1 st lenFINSEQ-1K4 s +XCMPLX-0K2 m =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for k be NatNAT-1M1 holds k <XXREAL-0R3 lenFINSEQ-1K4 s implies s .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 p .FUNCT-1K1 (m +XCMPLX-0K2 k))"
          proof(rule bexI[of _ "s"],rule conjMI,rule ballI,rule impI)
            have "n <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
              using xreal_1_th_29 sorry
            then have "m <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
              using A1 xxreal_0_th_2 sorry
            then have "m -XCMPLX-0K6 m <=XXREAL-0R1 (n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 m"
              using xreal_1_th_9 sorry
            then have "lenFINSEQ-1K4 s +XCMPLX-0K2 m =XBOOLE-0R4 ((n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 m)+XCMPLX-0K2 m"
              using A2 xreal_0_def_2 sorry
            thus "lenFINSEQ-1K4 s +XCMPLX-0K2 m =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
               sorry
            fix k assume [ty]: "k be NatNAT-1M1"
            assume "k <XXREAL-0R3 lenFINSEQ-1K4 s"
            then have A3: "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 s"
              using nat_1_th_13 sorry
            have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
              using xreal_1_th_7 sorry
            then have "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 s"
              using A3 finseq_3_th_25 sorry
            then have "s .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 p .FUNCT-1K1 (m +XCMPLX-0K2 ((k +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M))"
              using A2 sorry
            also have "... = p .FUNCT-1K1 (m +XCMPLX-0K2 k)"
               sorry
            finally show "s .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 p .FUNCT-1K1 (m +XCMPLX-0K2 k)"
               sorry
          qed "sorry"
        qed
        show " not ( not ((\<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 n) & n <=XXREAL-0R1 lenFINSEQ-1K4 p) & ( for VarFor1 be FinSequenceFINSEQ-1M1 holds  not VarFor1 =FINSEQ-1R1 {}XBOOLE-0K1))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FinSequenceFINSEQ-1M1 holds  for it2 be FinSequenceFINSEQ-1M1 holds ((\<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 n) & n <=XXREAL-0R1 lenFINSEQ-1K4 p implies ((lenFINSEQ-1K4 it1 +XCMPLX-0K2 m =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 it1 implies it1 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (m +XCMPLX-0K2 i))) & (lenFINSEQ-1K4 it2 +XCMPLX-0K2 m =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 it2 implies it2 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (m +XCMPLX-0K2 i))) implies it1 =HIDDENR1 it2)) & ( not ((\<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 n) & n <=XXREAL-0R1 lenFINSEQ-1K4 p) implies (it1 =FINSEQ-1R1 {}XBOOLE-0K1 & it2 =FINSEQ-1R1 {}XBOOLE-0K1 implies it1 =HIDDENR1 it2))"
    proof-
      have " for s1 be FinSequenceFINSEQ-1M1 holds  for s2 be FinSequenceFINSEQ-1M1 holds (\<one>\<^sub>M <=XXREAL-0R1 m & (m <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 p) implies (lenFINSEQ-1K4 s1 +XCMPLX-0K2 m =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 s1 implies s1 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (m +XCMPLX-0K2 i)) implies (lenFINSEQ-1K4 s2 +XCMPLX-0K2 m =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 s2 implies s2 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (m +XCMPLX-0K2 i)) implies s1 =FINSEQ-1R1 s2))) &  not ((( not ((\<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 n) & n <=XXREAL-0R1 lenFINSEQ-1K4 p) & s1 =FINSEQ-1R1 {}XBOOLE-0K1) & s2 =FINSEQ-1R1 {}XBOOLE-0K1) &  not s1 =HIDDENR1 s2)"
      proof(rule ballI,rule ballI,rule conjMI)
        fix s1 assume [ty]: "s1 be FinSequenceFINSEQ-1M1"
        fix s2 assume [ty]: "s2 be FinSequenceFINSEQ-1M1"
        show "\<one>\<^sub>M <=XXREAL-0R1 m & (m <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 p) implies (lenFINSEQ-1K4 s1 +XCMPLX-0K2 m =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 s1 implies s1 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (m +XCMPLX-0K2 i)) implies (lenFINSEQ-1K4 s2 +XCMPLX-0K2 m =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 s2 implies s2 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (m +XCMPLX-0K2 i)) implies s1 =FINSEQ-1R1 s2))"
        proof(rule impMI ,rule impMI ,rule impI,rule impMI ,rule impI,rule impMI ,rule impI)
          assume "\<one>\<^sub>M <=XXREAL-0R1 m"
            and "m <=XXREAL-0R1 n"
            and "n <=XXREAL-0R1 lenFINSEQ-1K4 p"
          assume A4: "lenFINSEQ-1K4 s1 +XCMPLX-0K2 m =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
            and A5: " for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 s1 implies s1 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (m +XCMPLX-0K2 i)"
          assume A6: "lenFINSEQ-1K4 s2 +XCMPLX-0K2 m =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
            and A7: " for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 s2 implies s2 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (m +XCMPLX-0K2 i)"
          have "lenFINSEQ-1K4 s1 =XBOOLE-0R4 lenFINSEQ-1K4 s1 & (lenFINSEQ-1K4 s2 =XBOOLE-0R4 lenFINSEQ-1K4 s1 & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 s1 implies s1 .FUNCT-1K1 i =HIDDENR1 s2 .FUNCT-1K1 i))"
          proof(rule conjMI,rule conjMI,rule ballI,rule impI)
            show "lenFINSEQ-1K4 s1 =XBOOLE-0R4 lenFINSEQ-1K4 s1"
               sorry
            show "lenFINSEQ-1K4 s2 =XBOOLE-0R4 lenFINSEQ-1K4 s1"
              using A4 A6 sorry
            fix i assume [ty]: "i be NatNAT-1M1"
            assume A8: "i inTARSKIR2 domFINSEQ-1K5 s1"
            have A9: "domFINSEQ-1K5 s1 =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 s1)"
              using finseq_1_def_3 sorry
            have A10: "i <=XXREAL-0R1 lenFINSEQ-1K4 s1"
              using A8 finseq_3_th_25 sorry
            have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i"
              using A9 A8 finseq_1_th_1 sorry
            then obtain k where
              [ty]:"k be NatNAT-1M1" and 
              "0NUMBERSK6 <=XXREAL-0R1 k"and A11: "k <XXREAL-0R3 lenFINSEQ-1K4 s1"and A12: "i =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
              using A10 finseq_6_th_127 sorry
            have "s1 .FUNCT-1K1 i =HIDDENR1 p .FUNCT-1K1 (m +XCMPLX-0K2 k)"
              using A5 A11 A12 sorry
            also have "... = s2 .FUNCT-1K1 i"
              using A4 A6 A7 A11 A12 sorry
            finally show "s1 .FUNCT-1K1 i =HIDDENR1 s2 .FUNCT-1K1 i"
               sorry
          qed "sorry"
          thus "s1 =FINSEQ-1R1 s2"
            using finseq_2_th_9 sorry
        qed
        show " not ((( not ((\<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 n) & n <=XXREAL-0R1 lenFINSEQ-1K4 p) & s1 =FINSEQ-1R1 {}XBOOLE-0K1) & s2 =FINSEQ-1R1 {}XBOOLE-0K1) &  not s1 =HIDDENR1 s2)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mlemma finseq_6_lm_6:
" for p be FinSequenceFINSEQ-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (\<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M) & n <=XXREAL-0R1 lenFINSEQ-1K4 p implies lenFINSEQ-1K4 ((m,n)-cutFINSEQ-6K4 p) +XCMPLX-0K2 m =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 ((m,n)-cutFINSEQ-6K4 p) implies ((m,n)-cutFINSEQ-6K4 p).FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (m +XCMPLX-0K2 i))"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & (m <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M & n <=XXREAL-0R1 lenFINSEQ-1K4 p) implies lenFINSEQ-1K4 ((m,n)-cutFINSEQ-6K4 p) +XCMPLX-0K2 m =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds  not ( not i <XXREAL-0R3 lenFINSEQ-1K4 ((m,n)-cutFINSEQ-6K4 p) &  not ((m,n)-cutFINSEQ-6K4 p).FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (m +XCMPLX-0K2 i)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "\<one>\<^sub>M <=XXREAL-0R1 m"
      and A2: "m <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
      and A3: "n <=XXREAL-0R1 lenFINSEQ-1K4 p"
    have A4: "m =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M or m <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
      using A2 xxreal_0_th_1 sorry
    show "lenFINSEQ-1K4 ((m,n)-cutFINSEQ-6K4 p) +XCMPLX-0K2 m =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds  not ( not i <XXREAL-0R3 lenFINSEQ-1K4 ((m,n)-cutFINSEQ-6K4 p) &  not ((m,n)-cutFINSEQ-6K4 p).FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (m +XCMPLX-0K2 i)))"
    proof-
      have cases: "m =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M or m <=XXREAL-0R1 n"
        using A4 nat_1_th_13 sorry
      have case1: "m =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M implies lenFINSEQ-1K4 ((m,n)-cutFINSEQ-6K4 p) +XCMPLX-0K2 m =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds  not ( not i <XXREAL-0R3 lenFINSEQ-1K4 ((m,n)-cutFINSEQ-6K4 p) &  not ((m,n)-cutFINSEQ-6K4 p).FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (m +XCMPLX-0K2 i)))"
      proof(rule impI,rule conjMI)
        assume A5: "m =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
        then have A6: "n <XXREAL-0R3 m"
          using xreal_1_th_29 sorry
        then have "(m,n)-cutFINSEQ-6K4 p =FINSEQ-1R1 {}XBOOLE-0K1"
          using finseq_6_def_4 sorry
        thus "lenFINSEQ-1K4 ((m,n)-cutFINSEQ-6K4 p) +XCMPLX-0K2 m =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
          using A5 sorry
        show " for i be NatNAT-1M1 holds  not ( not i <XXREAL-0R3 lenFINSEQ-1K4 ((m,n)-cutFINSEQ-6K4 p) &  not ((m,n)-cutFINSEQ-6K4 p).FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (m +XCMPLX-0K2 i))"
          using A6 finseq_6_def_4 card_1_th_27 sorry
      qed
      have case2: "m <=XXREAL-0R1 n implies lenFINSEQ-1K4 ((m,n)-cutFINSEQ-6K4 p) +XCMPLX-0K2 m =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds  not ( not i <XXREAL-0R3 lenFINSEQ-1K4 ((m,n)-cutFINSEQ-6K4 p) &  not ((m,n)-cutFINSEQ-6K4 p).FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (m +XCMPLX-0K2 i)))"
      proof(rule impI)
        assume "m <=XXREAL-0R1 n"
        thus "lenFINSEQ-1K4 ((m,n)-cutFINSEQ-6K4 p) +XCMPLX-0K2 m =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds  not ( not i <XXREAL-0R3 lenFINSEQ-1K4 ((m,n)-cutFINSEQ-6K4 p) &  not ((m,n)-cutFINSEQ-6K4 p).FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (m +XCMPLX-0K2 i)))"
          using A1 A3 finseq_6_def_4 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_132:
" for p be FinSequenceFINSEQ-1M1 holds  for m be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 p implies (m,m)-cutFINSEQ-6K4 p =FINSEQ-1R1 <*FINSEQ-1K10 p .FUNCT-1K1 m*>"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for m be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 p implies (m,m)-cutFINSEQ-6K4 p =FINSEQ-1R1 <*FINSEQ-1K10 p .FUNCT-1K1 m*>"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    assume A1: "\<one>\<^sub>M <=XXREAL-0R1 m"
      and A2: "m <=XXREAL-0R1 lenFINSEQ-1K4 p"
    let ?mp = "(m,m)-cutFINSEQ-6K4 p"
    have A3: "lenFINSEQ-1K4 ?mp +XCMPLX-0K2 m =XBOOLE-0R4 m +NAT-1K1 \<one>\<^sub>M"
      using A1 A2 finseq_6_def_4 sorry
    then have "?mp .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 p .FUNCT-1K1 (m +NAT-1K1 0NUMBERSK6)"
      using A1 A2 finseq_6_def_4 sorry
    also have "... = p .FUNCT-1K1 m"
       sorry
    finally have "?mp .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 p .FUNCT-1K1 m"
       sorry
    thus "(m,m)-cutFINSEQ-6K4 p =FINSEQ-1R1 <*FINSEQ-1K10 p .FUNCT-1K1 m*>"
      using A3 finseq_1_th_40 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_133:
" for p be FinSequenceFINSEQ-1M1 holds (\<one>\<^sub>M,lenFINSEQ-1K4 p)-cutFINSEQ-6K4 p =FINSEQ-1R1 p"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds (\<one>\<^sub>M,lenFINSEQ-1K4 p)-cutFINSEQ-6K4 p =FINSEQ-1R1 p"
  proof(rule ballI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    let ?cp = "(\<one>\<^sub>M,lenFINSEQ-1K4 p)-cutFINSEQ-6K4 p"
    have "lenFINSEQ-1K4 ((\<one>\<^sub>M,lenFINSEQ-1K4 p)-cutFINSEQ-6K4 p) =XBOOLE-0R4 lenFINSEQ-1K4 p & (lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 p & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 ((\<one>\<^sub>M,lenFINSEQ-1K4 p)-cutFINSEQ-6K4 p) implies ((\<one>\<^sub>M,lenFINSEQ-1K4 p)-cutFINSEQ-6K4 p).FUNCT-1K1 i =XBOOLE-0R4 p .FUNCT-1K1 i))"
    proof(rule conjMI,rule conjMI,rule ballI,rule impI)
      have A1: "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M"
        using nat_1_th_11 sorry
      then have A2: "lenFINSEQ-1K4 ?cp +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M"
        using finseq_6_lm_6 sorry
      thus "lenFINSEQ-1K4 ((\<one>\<^sub>M,lenFINSEQ-1K4 p)-cutFINSEQ-6K4 p) =XBOOLE-0R4 lenFINSEQ-1K4 p"
         sorry
      show "lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 p"
         sorry
      fix i assume [ty]: "i be NatNAT-1M1"
      assume A3: "i inTARSKIR2 domFINSEQ-1K5 ?cp"
      have A4: "domFINSEQ-1K5 ?cp =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
        using A2 finseq_1_def_3 sorry
      then have A5: "i <=XXREAL-0R1 lenFINSEQ-1K4 p"
        using A3 finseq_1_th_1 sorry
      have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i"
        using A4 A3 finseq_1_th_1 sorry
      then have " ex k be NatNAT-1M1 st (0NUMBERSK6 <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 ?cp) & i =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
        using A2 A5 finseq_6_th_127 sorry
      thus "((\<one>\<^sub>M,lenFINSEQ-1K4 p)-cutFINSEQ-6K4 p).FUNCT-1K1 i =XBOOLE-0R4 p .FUNCT-1K1 i"
        using A1 finseq_6_lm_6 sorry
    qed "sorry"
    thus "(\<one>\<^sub>M,lenFINSEQ-1K4 p)-cutFINSEQ-6K4 p =FINSEQ-1R1 p"
      using finseq_2_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_134:
" for p be FinSequenceFINSEQ-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for r be NatNAT-1M1 holds (m <=XXREAL-0R1 n & n <=XXREAL-0R1 r) & r <=XXREAL-0R1 lenFINSEQ-1K4 p implies ((m +NAT-1K1 \<one>\<^sub>M,n)-cutFINSEQ-6K4 p)^FINSEQ-1K8 ((n +NAT-1K1 \<one>\<^sub>M,r)-cutFINSEQ-6K4 p) =FINSEQ-1R1 (m +NAT-1K1 \<one>\<^sub>M,r)-cutFINSEQ-6K4 p"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for r be NatNAT-1M1 holds m <=XXREAL-0R1 n & (n <=XXREAL-0R1 r & r <=XXREAL-0R1 lenFINSEQ-1K4 p) implies ((m +NAT-1K1 \<one>\<^sub>M,n)-cutFINSEQ-6K4 p)^FINSEQ-1K8 ((n +NAT-1K1 \<one>\<^sub>M,r)-cutFINSEQ-6K4 p) =FINSEQ-1R1 (m +NAT-1K1 \<one>\<^sub>M,r)-cutFINSEQ-6K4 p"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix r assume [ty]: "r be NatNAT-1M1"
    assume A1: "m <=XXREAL-0R1 n"
      and A2: "n <=XXREAL-0R1 r"
      and A3: "r <=XXREAL-0R1 lenFINSEQ-1K4 p"
    let ?p3 = "(m +NAT-1K1 \<one>\<^sub>M,r)-cutFINSEQ-6K4 p"
    let ?p2 = "(n +NAT-1K1 \<one>\<^sub>M,r)-cutFINSEQ-6K4 p"
    let ?p1 = "(m +NAT-1K1 \<one>\<^sub>M,n)-cutFINSEQ-6K4 p"
    let ?p12 = "?p1 ^FINSEQ-1K8 ?p2"
    have "lenFINSEQ-1K4 ?p12 =XBOOLE-0R4 lenFINSEQ-1K4 ?p12 & (lenFINSEQ-1K4 ?p3 =XBOOLE-0R4 lenFINSEQ-1K4 ?p12 & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 ?p12 implies (((m +NAT-1K1 \<one>\<^sub>M,n)-cutFINSEQ-6K4 p)^FINSEQ-1K8 ((n +NAT-1K1 \<one>\<^sub>M,r)-cutFINSEQ-6K4 p)).FUNCT-1K1 i =HIDDENR1 ((m +NAT-1K1 \<one>\<^sub>M,r)-cutFINSEQ-6K4 p).FUNCT-1K1 i))"
    proof(rule conjMI,rule conjMI,rule ballI,rule impI)
      obtain n9 where 
        [ty]:"n9 be IntegerINT-1M1" and n9Def:"n9 = n"
         sorry
      obtain m9 where 
        [ty]:"m9 be IntegerINT-1M1" and m9Def:"m9 = m"
         sorry
      show "lenFINSEQ-1K4 (((m +NAT-1K1 \<one>\<^sub>M,n)-cutFINSEQ-6K4 p)^FINSEQ-1K8 ((n +NAT-1K1 \<one>\<^sub>M,r)-cutFINSEQ-6K4 p)) =XBOOLE-0R4 lenFINSEQ-1K4 (((m +NAT-1K1 \<one>\<^sub>M,n)-cutFINSEQ-6K4 p)^FINSEQ-1K8 ((n +NAT-1K1 \<one>\<^sub>M,r)-cutFINSEQ-6K4 p))"
         sorry
      have A4: "domFINSEQ-1K5 ?p12 =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?p12)"
        using finseq_1_def_3 sorry
      obtain nm where 
        [ty]:"nm be ElementSUBSET-1M1-of NATNUMBERSK1" and nmDef:"nm = n9 -XCMPLX-0K6 m9"
        using A1 int_1_th_5 sorry
      have A5: "\<one>\<^sub>M <=XXREAL-0R1 m +NAT-1K1 \<one>\<^sub>M"
        using nat_1_th_11 sorry
      have "m <=XXREAL-0R1 r"
        using A1 A2 xxreal_0_th_2 sorry
      then have A6: "m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 r +NAT-1K1 \<one>\<^sub>M"
        using xreal_1_th_6 sorry
      have A7: "m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
        using A1 xreal_1_th_6 sorry
      have A8: "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 r +NAT-1K1 \<one>\<^sub>M"
        using A2 xreal_1_th_6 sorry
      then have "m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 r +NAT-1K1 \<one>\<^sub>M"
        using A7 xxreal_0_th_2 sorry
      then have A9: "lenFINSEQ-1K4 ?p3 +NAT-1K1 (m +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 r +NAT-1K1 \<one>\<^sub>M"
        using A3 A5 finseq_6_lm_6 sorry
      have A10: "n <=XXREAL-0R1 lenFINSEQ-1K4 p"
        using A2 A3 xxreal_0_th_2 sorry
      then have A11: "lenFINSEQ-1K4 ?p1 +NAT-1K1 (m +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
        using A5 A7 finseq_6_lm_6 sorry
      have A12: "\<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
        using nat_1_th_11 sorry
      then have "lenFINSEQ-1K4 ?p2 +NAT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 r +NAT-1K1 \<one>\<^sub>M"
        using A3 A8 finseq_6_lm_6 sorry
      then have A13: "lenFINSEQ-1K4 ?p12 =HIDDENR1 (n -XCMPLX-0K6 m)+XCMPLX-0K2 (r +XCMPLX-0K2 (-XCMPLX-0K4 n))"
        using A11 finseq_1_th_22 sorry
      also have "... = r -XCMPLX-0K6 m"
         sorry
      finally have "lenFINSEQ-1K4 ?p12 =HIDDENR1 r -XCMPLX-0K6 m"
         sorry
      thus "lenFINSEQ-1K4 ((m +NAT-1K1 \<one>\<^sub>M,r)-cutFINSEQ-6K4 p) =XBOOLE-0R4 lenFINSEQ-1K4 (((m +NAT-1K1 \<one>\<^sub>M,n)-cutFINSEQ-6K4 p)^FINSEQ-1K8 ((n +NAT-1K1 \<one>\<^sub>M,r)-cutFINSEQ-6K4 p))"
        using A9 sorry
      fix i assume [ty]: "i be NatNAT-1M1"
      assume A14: "i inTARSKIR2 domFINSEQ-1K5 ?p12"
      then have A15: "\<one>\<^sub>M <=XXREAL-0R1 i"
        using A4 finseq_1_th_1 sorry
      have A16: "i <=XXREAL-0R1 lenFINSEQ-1K4 ?p12"
        using A4 A14 finseq_1_th_1 sorry
      show "(((m +NAT-1K1 \<one>\<^sub>M,n)-cutFINSEQ-6K4 p)^FINSEQ-1K8 ((n +NAT-1K1 \<one>\<^sub>M,r)-cutFINSEQ-6K4 p)).FUNCT-1K1 i =HIDDENR1 ((m +NAT-1K1 \<one>\<^sub>M,r)-cutFINSEQ-6K4 p).FUNCT-1K1 i"
      proof-
        have cases: "i <=XXREAL-0R1 nm or nm +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i"
          using nat_1_th_13 sorry
        have case1: "i <=XXREAL-0R1 nm implies (((m +NAT-1K1 \<one>\<^sub>M,n)-cutFINSEQ-6K4 p)^FINSEQ-1K8 ((n +NAT-1K1 \<one>\<^sub>M,r)-cutFINSEQ-6K4 p)).FUNCT-1K1 i =HIDDENR1 ((m +NAT-1K1 \<one>\<^sub>M,r)-cutFINSEQ-6K4 p).FUNCT-1K1 i"
        proof(rule impI)
          assume A17: "i <=XXREAL-0R1 nm"
          have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
             sorry
          then obtain k where
            [ty]:"k be NatNAT-1M1" and 
            "0NUMBERSK6 <=XXREAL-0R1 k"and A18: "k <XXREAL-0R3 nm"and A19: "i =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
            using A15 A17 finseq_6_th_127 sorry
          have "nm <=XXREAL-0R1 r -XCMPLX-0K6 m"
            using A2 xreal_1_th_9 sorry
          then have A20: "k <XXREAL-0R3 lenFINSEQ-1K4 ?p3"
            using A9 A18 xxreal_0_th_2 sorry
          have "i inTARSKIR2 domFINSEQ-1K5 ?p1"
            using A11 A15 A17 finseq_3_th_25 sorry
          then have "(((m +NAT-1K1 \<one>\<^sub>M,n)-cutFINSEQ-6K4 p)^FINSEQ-1K8 ((n +NAT-1K1 \<one>\<^sub>M,r)-cutFINSEQ-6K4 p)).FUNCT-1K1 i =HIDDENR1 ((m +NAT-1K1 \<one>\<^sub>M,n)-cutFINSEQ-6K4 p).FUNCT-1K1 i"
            using finseq_1_def_7 sorry
          also have "... = p .FUNCT-1K1 ((m +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k)"
            using A5 A7 A10 A11 A18 A19 finseq_6_lm_6 sorry
          also have "... = ((m +NAT-1K1 \<one>\<^sub>M,r)-cutFINSEQ-6K4 p).FUNCT-1K1 i"
            using A3 A5 A6 A19 A20 finseq_6_lm_6 sorry
          finally show "(((m +NAT-1K1 \<one>\<^sub>M,n)-cutFINSEQ-6K4 p)^FINSEQ-1K8 ((n +NAT-1K1 \<one>\<^sub>M,r)-cutFINSEQ-6K4 p)).FUNCT-1K1 i =HIDDENR1 ((m +NAT-1K1 \<one>\<^sub>M,r)-cutFINSEQ-6K4 p).FUNCT-1K1 i"
             sorry
        qed
        have case2: "nm +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i implies (((m +NAT-1K1 \<one>\<^sub>M,n)-cutFINSEQ-6K4 p)^FINSEQ-1K8 ((n +NAT-1K1 \<one>\<^sub>M,r)-cutFINSEQ-6K4 p)).FUNCT-1K1 i =HIDDENR1 ((m +NAT-1K1 \<one>\<^sub>M,r)-cutFINSEQ-6K4 p).FUNCT-1K1 i"
        proof(rule impI)
          assume "nm +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i"
          then obtain k where
            [ty]:"k be NatNAT-1M1" and 
            A21: "nm <=XXREAL-0R1 k"and A22: "k <XXREAL-0R3 lenFINSEQ-1K4 ?p12"and A23: "i =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
            using A16 finseq_6_th_127 sorry
          obtain k99 where 
            [ty]:"k99 be IntegerINT-1M1" and k99Def:"k99 = k"
             sorry
          obtain k9 where 
            [ty]:"k9 be ElementSUBSET-1M1-of NATNUMBERSK1" and k9Def:"k9 = k99 -XCMPLX-0K6 nm"
            using A21 int_1_th_5 sorry
          have A24: "\<one>\<^sub>M <=XXREAL-0R1 k9 +NAT-1K1 \<one>\<^sub>M"
            using nat_1_th_11 sorry
          have "lenFINSEQ-1K4 ?p12 =XBOOLE-0R4 lenFINSEQ-1K4 ?p2 +NAT-1K1 lenFINSEQ-1K4 ?p1"
            using finseq_1_th_22 sorry
          then have "lenFINSEQ-1K4 ?p2 =XBOOLE-0R4 lenFINSEQ-1K4 ?p12 -XCMPLX-0K6 lenFINSEQ-1K4 ?p1"
             sorry
          then have A25: "k9 <XXREAL-0R3 lenFINSEQ-1K4 ?p2"
            using A11 A22 xreal_1_th_9 sorry
          then have "k9 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 ?p2"
            using nat_1_th_13 sorry
          then have A26: "k9 +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ?p2"
            using A24 finseq_3_th_25 sorry
          have A27: "(n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 k9 =XBOOLE-0R4 (m +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k"
             sorry
          have "i =XBOOLE-0R4 nm +NAT-1K1 (k9 +NAT-1K1 \<one>\<^sub>M)"
            using A23 sorry
          then have "(((m +NAT-1K1 \<one>\<^sub>M,n)-cutFINSEQ-6K4 p)^FINSEQ-1K8 ((n +NAT-1K1 \<one>\<^sub>M,r)-cutFINSEQ-6K4 p)).FUNCT-1K1 i =HIDDENR1 ((n +NAT-1K1 \<one>\<^sub>M,r)-cutFINSEQ-6K4 p).FUNCT-1K1 (k9 +NAT-1K1 \<one>\<^sub>M)"
            using A11 A26 finseq_1_def_7 sorry
          also have "... = p .FUNCT-1K1 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 k9)"
            using A3 A12 A8 A25 finseq_6_lm_6 sorry
          also have "... = ((m +NAT-1K1 \<one>\<^sub>M,r)-cutFINSEQ-6K4 p).FUNCT-1K1 i"
            using A3 A5 A6 A13 A9 A22 A23 A27 finseq_6_lm_6 sorry
          finally show "(((m +NAT-1K1 \<one>\<^sub>M,n)-cutFINSEQ-6K4 p)^FINSEQ-1K8 ((n +NAT-1K1 \<one>\<^sub>M,r)-cutFINSEQ-6K4 p)).FUNCT-1K1 i =HIDDENR1 ((m +NAT-1K1 \<one>\<^sub>M,r)-cutFINSEQ-6K4 p).FUNCT-1K1 i"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus "((m +NAT-1K1 \<one>\<^sub>M,n)-cutFINSEQ-6K4 p)^FINSEQ-1K8 ((n +NAT-1K1 \<one>\<^sub>M,r)-cutFINSEQ-6K4 p) =FINSEQ-1R1 (m +NAT-1K1 \<one>\<^sub>M,r)-cutFINSEQ-6K4 p"
      using finseq_2_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_135:
" for p be FinSequenceFINSEQ-1M1 holds  for m be NatNAT-1M1 holds m <=XXREAL-0R1 lenFINSEQ-1K4 p implies ((\<one>\<^sub>M,m)-cutFINSEQ-6K4 p)^FINSEQ-1K8 ((m +NAT-1K1 \<one>\<^sub>M,lenFINSEQ-1K4 p)-cutFINSEQ-6K4 p) =FINSEQ-1R1 p"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for m be NatNAT-1M1 holds m <=XXREAL-0R1 lenFINSEQ-1K4 p implies ((\<one>\<^sub>M,m)-cutFINSEQ-6K4 p)^FINSEQ-1K8 ((m +NAT-1K1 \<one>\<^sub>M,lenFINSEQ-1K4 p)-cutFINSEQ-6K4 p) =HIDDENR1 p"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    let ?cp1 = "(\<one>\<^sub>M,m)-cutFINSEQ-6K4 p"
    let ?cpm = "(m +NAT-1K1 \<one>\<^sub>M,lenFINSEQ-1K4 p)-cutFINSEQ-6K4 p"
    have A1: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
       sorry
    assume "m <=XXREAL-0R1 lenFINSEQ-1K4 p"
    then have "((\<one>\<^sub>M,m)-cutFINSEQ-6K4 p)^FINSEQ-1K8 ((m +NAT-1K1 \<one>\<^sub>M,lenFINSEQ-1K4 p)-cutFINSEQ-6K4 p) =HIDDENR1 (\<one>\<^sub>M,lenFINSEQ-1K4 p)-cutFINSEQ-6K4 p"
      using A1 finseq_6_th_134 sorry
    also have "... = p"
      using finseq_6_th_133 sorry
    finally show "((\<one>\<^sub>M,m)-cutFINSEQ-6K4 p)^FINSEQ-1K8 ((m +NAT-1K1 \<one>\<^sub>M,lenFINSEQ-1K4 p)-cutFINSEQ-6K4 p) =HIDDENR1 p"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_136:
" for p be FinSequenceFINSEQ-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds m <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 p implies (((\<one>\<^sub>M,m)-cutFINSEQ-6K4 p)^FINSEQ-1K8 ((m +NAT-1K1 \<one>\<^sub>M,n)-cutFINSEQ-6K4 p))^FINSEQ-1K8 ((n +NAT-1K1 \<one>\<^sub>M,lenFINSEQ-1K4 p)-cutFINSEQ-6K4 p) =FINSEQ-1R1 p"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds m <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 p implies (((\<one>\<^sub>M,m)-cutFINSEQ-6K4 p)^FINSEQ-1K8 ((m +NAT-1K1 \<one>\<^sub>M,n)-cutFINSEQ-6K4 p))^FINSEQ-1K8 ((n +NAT-1K1 \<one>\<^sub>M,lenFINSEQ-1K4 p)-cutFINSEQ-6K4 p) =HIDDENR1 p"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "m <=XXREAL-0R1 n"
      and A2: "n <=XXREAL-0R1 lenFINSEQ-1K4 p"
    let ?cp3 = "(n +NAT-1K1 \<one>\<^sub>M,lenFINSEQ-1K4 p)-cutFINSEQ-6K4 p"
    let ?cp2 = "(m +NAT-1K1 \<one>\<^sub>M,n)-cutFINSEQ-6K4 p"
    let ?cp1 = "(\<one>\<^sub>M,m)-cutFINSEQ-6K4 p"
    have A3: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
       sorry
    then have "(((\<one>\<^sub>M,m)-cutFINSEQ-6K4 p)^FINSEQ-1K8 ((m +NAT-1K1 \<one>\<^sub>M,n)-cutFINSEQ-6K4 p))^FINSEQ-1K8 ((n +NAT-1K1 \<one>\<^sub>M,lenFINSEQ-1K4 p)-cutFINSEQ-6K4 p) =HIDDENR1 ((\<one>\<^sub>M,n)-cutFINSEQ-6K4 p)^FINSEQ-1K8 ((n +NAT-1K1 \<one>\<^sub>M,lenFINSEQ-1K4 p)-cutFINSEQ-6K4 p)"
      using A1 A2 finseq_6_th_134 sorry
    also have "... = (\<one>\<^sub>M,lenFINSEQ-1K4 p)-cutFINSEQ-6K4 p"
      using A2 A3 finseq_6_th_134 sorry
    also have "... = p"
      using finseq_6_th_133 sorry
    finally show "(((\<one>\<^sub>M,m)-cutFINSEQ-6K4 p)^FINSEQ-1K8 ((m +NAT-1K1 \<one>\<^sub>M,n)-cutFINSEQ-6K4 p))^FINSEQ-1K8 ((n +NAT-1K1 \<one>\<^sub>M,lenFINSEQ-1K4 p)-cutFINSEQ-6K4 p) =HIDDENR1 p"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_137:
" for p be FinSequenceFINSEQ-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds rngFUNCT-1K2 ((m,n)-cutFINSEQ-6K4 p) c=TARSKIR1 rngFUNCT-1K2 p"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds rngFUNCT-1K2 ((m,n)-cutFINSEQ-6K4 p) c=TARSKIR1 rngFUNCT-1K2 p"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?c = "(m,n)-cutFINSEQ-6K4 p"
    have A1: "\<one>\<^sub>M <=XXREAL-0R1 m & (m <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 p) implies rngFUNCT-1K2 ((m,n)-cutFINSEQ-6K4 p) c=TARSKIR1 rngFUNCT-1K2 p"
    proof(rule impMI ,rule impMI ,rule impI)
      assume A2: "\<one>\<^sub>M <=XXREAL-0R1 m"
        and A3: "m <=XXREAL-0R1 n"
        and A4: "n <=XXREAL-0R1 lenFINSEQ-1K4 p"
      have "n <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
        using nat_1_th_11 sorry
      then have A5: "m <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
        using A3 xxreal_0_th_2 sorry
      show "rngFUNCT-1K2 ((m,n)-cutFINSEQ-6K4 p) c=TARSKIR1 rngFUNCT-1K2 p"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 ((m,n)-cutFINSEQ-6K4 p) implies x inHIDDENR3 rngFUNCT-1K2 p"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 rngFUNCT-1K2 ?c"
          then obtain z where
            [ty]:"z be objectHIDDENM1" and 
            A6: "z inHIDDENR3 domFINSEQ-1K5 ?c"and A7: "x =HIDDENR1 ?c .FUNCT-1K1 z"
            using funct_1_def_3 sorry
          have 
            [ty]:"z be ElementSUBSET-1M1-of NATNUMBERSK1"
            using A6 sorry
          have A8: "z <=XXREAL-0R1 lenFINSEQ-1K4 ?c"
            using A6 finseq_3_th_25 sorry
          have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 z"
            using A6 finseq_3_th_25 sorry
          then obtain i where
            [ty]:"i be NatNAT-1M1" and 
            "0NUMBERSK6 <=XXREAL-0R1 i"and A9: "i <XXREAL-0R3 lenFINSEQ-1K4 ?c"and A10: "z =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M"
            using A8 finseq_6_th_127 sorry
          have "m +XCMPLX-0K2 i <XXREAL-0R3 lenFINSEQ-1K4 ?c +XCMPLX-0K2 m"
            using A9 xreal_1_th_6 sorry
          then have "m +XCMPLX-0K2 i <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
            using A2 A4 A5 finseq_6_lm_6 sorry
          then have "m +XCMPLX-0K2 i <=XXREAL-0R1 n"
            using nat_1_th_13 sorry
          then have A11: "m +XCMPLX-0K2 i <=XXREAL-0R1 lenFINSEQ-1K4 p"
            using A4 xxreal_0_th_2 sorry
          have "\<one>\<^sub>M <=XXREAL-0R1 m +XCMPLX-0K2 i"
            using A2 nat_1_th_12 sorry
          then have A12: "m +XCMPLX-0K2 i inTARSKIR2 domFINSEQ-1K5 p"
            using A11 finseq_3_th_25 sorry
          have "?c .FUNCT-1K1 z =XBOOLE-0R4 p .FUNCT-1K1 (m +XCMPLX-0K2 i)"
            using A2 A4 A5 A9 A10 finseq_6_lm_6 sorry
          thus "x inHIDDENR3 rngFUNCT-1K2 p"
            using A7 A12 funct_1_def_3 sorry
        qed "sorry"
        thus "rngFUNCT-1K2 ((m,n)-cutFINSEQ-6K4 p) c=TARSKIR1 rngFUNCT-1K2 p"
          using tarski_def_3 sorry
      qed
    qed
    have " not ((\<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 n) & n <=XXREAL-0R1 lenFINSEQ-1K4 p) implies rngFUNCT-1K2 ((m,n)-cutFINSEQ-6K4 p) c=TARSKIR1 rngFUNCT-1K2 p"
    proof(rule impI)
      assume " not ((\<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 n) & n <=XXREAL-0R1 lenFINSEQ-1K4 p)"
      then have "?c =FINSEQ-1R1 {}XBOOLE-0K1"
        using finseq_6_def_4 sorry
      then have "rngFUNCT-1K2 ?c =XBOOLE-0R4 {}XBOOLE-0K1"
         sorry
      thus "rngFUNCT-1K2 ((m,n)-cutFINSEQ-6K4 p) c=TARSKIR1 rngFUNCT-1K2 p"
         sorry
    qed
    thus "rngFUNCT-1K2 ((m,n)-cutFINSEQ-6K4 p) c=TARSKIR1 rngFUNCT-1K2 p"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax FINSEQ_6K5 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("'( _ , _ ')-cutFINSEQ-6K5\<^bsub>'( _ ')\<^esub>  _ " [0,0,0,164]164)
translations "(m,n)-cutFINSEQ-6K5\<^bsub>(D)\<^esub> p" \<rightharpoonup> "(m,n)-cutFINSEQ-6K4 p"

mtheorem finseq_6_add_2:
  mlet "D be setHIDDENM2", "p be FinSequenceFINSEQ-1M3-of D", "m be NatNAT-1M1", "n be NatNAT-1M1"
"cluster (m,n)-cutFINSEQ-6K4 p as-term-is FinSequenceFINSEQ-1M3-of D"
proof
(*coherence*)
  show "(m,n)-cutFINSEQ-6K4 p be FinSequenceFINSEQ-1M3-of D"
  proof-
    have A1: "rngFUNCT-1K2 p c=TARSKIR1 D"
      using finseq_1_def_4 sorry
    have "rngFUNCT-1K2 ((m,n)-cutFINSEQ-6K4 p) c=TARSKIR1 rngFUNCT-1K2 p"
      using finseq_6_th_137 sorry
    then have "rngFUNCT-1K2 ((m,n)-cutFINSEQ-6K4 p) c=TARSKIR1 D"
      using A1 sorry
    thus "(m,n)-cutFINSEQ-6K4 p be FinSequenceFINSEQ-1M3-of D"
      using finseq_1_def_4 sorry
  qed
qed "sorry"

mtheorem finseq_6_th_138:
" for p be FinSequenceFINSEQ-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (\<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 n) & n <=XXREAL-0R1 lenFINSEQ-1K4 p implies ((m,n)-cutFINSEQ-6K4 p).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 p .FUNCT-1K1 m & ((m,n)-cutFINSEQ-6K4 p).FUNCT-1K1 lenFINSEQ-1K4 ((m,n)-cutFINSEQ-6K4 p) =XBOOLE-0R4 p .FUNCT-1K1 n"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & (m <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 p) implies ((m,n)-cutFINSEQ-6K4 p).FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 p .FUNCT-1K1 m & ((m,n)-cutFINSEQ-6K4 p).FUNCT-1K1 lenFINSEQ-1K4 ((m,n)-cutFINSEQ-6K4 p) =XBOOLE-0R4 p .FUNCT-1K1 n"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?c = "(m,n)-cutFINSEQ-6K4 p"
    assume A1: "\<one>\<^sub>M <=XXREAL-0R1 m"
      and A2: "m <=XXREAL-0R1 n"
      and A3: "n <=XXREAL-0R1 lenFINSEQ-1K4 p"
    have A4: "m <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
      using A2 nat_1_th_12 sorry
    then have A5: "lenFINSEQ-1K4 ?c +XCMPLX-0K2 m =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
      using A1 A3 finseq_6_lm_6 sorry
    have A6: "lenFINSEQ-1K4 ((m,n)-cutFINSEQ-6K4 p) =XBOOLE-0R4 0NUMBERSK6 implies  False "
    proof(rule impI)
      assume "lenFINSEQ-1K4 ?c =XBOOLE-0R4 0NUMBERSK6"
      then have "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 0NUMBERSK6"
        using A2 A5 sorry
      thus " False "
        using xreal_1_th_6 sorry
    qed
    then have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 ?c"
      using nat_1_th_13 sorry
    then obtain i where
      [ty]:"i be NatNAT-1M1" and 
      "0NUMBERSK6 <=XXREAL-0R1 i"and A7: "i <XXREAL-0R3 lenFINSEQ-1K4 ?c"and A8: "lenFINSEQ-1K4 ?c =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M"
      using finseq_6_th_127 sorry
    have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
       sorry
    then have "((m,n)-cutFINSEQ-6K4 p).FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 p .FUNCT-1K1 (m +NAT-1K1 0NUMBERSK6)"
      using A1 A3 A4 A6 finseq_6_lm_6 sorry
    also have "... = p .FUNCT-1K1 m"
       sorry
    finally show "((m,n)-cutFINSEQ-6K4 p).FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 p .FUNCT-1K1 m"
       sorry
    have "m +XCMPLX-0K2 i =XBOOLE-0R4 n"
      using A5 A8 sorry
    thus "((m,n)-cutFINSEQ-6K4 p).FUNCT-1K1 lenFINSEQ-1K4 ((m,n)-cutFINSEQ-6K4 p) =XBOOLE-0R4 p .FUNCT-1K1 n"
      using A1 A3 A4 A7 A8 finseq_6_lm_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mdef finseq_6_def_5 (" _ ^''FINSEQ-6K6  _ " [164,164]164 ) where
  mlet "p be FinSequenceFINSEQ-1M1", "q be FinSequenceFINSEQ-1M1"
"func p ^'FINSEQ-6K6 q \<rightarrow> FinSequenceFINSEQ-1M1 equals
  p ^FINSEQ-1K8 ((\<two>\<^sub>M,lenFINSEQ-1K4 q)-cutFINSEQ-6K4 q)"
proof-
  (*coherence*)
    show "p ^FINSEQ-1K8 ((\<two>\<^sub>M,lenFINSEQ-1K4 q)-cutFINSEQ-6K4 q) be FinSequenceFINSEQ-1M1"
       sorry
qed "sorry"

mtheorem finseq_6_th_139:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds q <>HIDDENR2 {}XBOOLE-0K1 implies lenFINSEQ-1K4 (p ^'FINSEQ-6K6 q) +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds q <>HIDDENR2 {}XBOOLE-0K1 implies lenFINSEQ-1K4 (p ^'FINSEQ-6K6 q) +NAT-1K1 \<one>\<^sub>M =HIDDENR1 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    let ?r = "p ^'FINSEQ-6K6 q"
    let ?qc = "(\<two>\<^sub>M,lenFINSEQ-1K4 q)-cutFINSEQ-6K4 q"
    assume "q <>HIDDENR2 {}XBOOLE-0K1"
    then have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 q"
      using nat_1_th_13 sorry
    then have "\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M"
      using xreal_1_th_7 sorry
    then have A1: "lenFINSEQ-1K4 ?qc +NAT-1K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M"
      using finseq_6_lm_6 sorry
    have "lenFINSEQ-1K4 (p ^'FINSEQ-6K6 q) +NAT-1K1 \<one>\<^sub>M =HIDDENR1 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 ((\<two>\<^sub>M,lenFINSEQ-1K4 q)-cutFINSEQ-6K4 q))+NAT-1K1 \<one>\<^sub>M"
      using finseq_1_th_22 sorry
    also have "... = lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q"
      using A1 sorry
    finally show "lenFINSEQ-1K4 (p ^'FINSEQ-6K6 q) +NAT-1K1 \<one>\<^sub>M =HIDDENR1 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_140:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 p implies (p ^'FINSEQ-6K6 q).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 p implies (p ^'FINSEQ-6K6 q).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    assume A1: "\<one>\<^sub>M <=XXREAL-0R1 k"
      and A2: "k <=XXREAL-0R1 lenFINSEQ-1K4 p"
    have "k inTARSKIR2 domFINSEQ-1K5 p"
      using A1 A2 finseq_3_th_25 sorry
    thus "(p ^'FINSEQ-6K6 q).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k"
      using finseq_1_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_141:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 q implies (p ^'FINSEQ-6K6 q).FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 k) =XBOOLE-0R4 q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 q implies (p ^'FINSEQ-6K6 q).FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 k) =XBOOLE-0R4 q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    let ?qc = "(\<two>\<^sub>M,lenFINSEQ-1K4 q)-cutFINSEQ-6K4 q"
    assume A1: "\<one>\<^sub>M <=XXREAL-0R1 k"
      and A2: "k <XXREAL-0R3 lenFINSEQ-1K4 q"
    show "(p ^'FINSEQ-6K6 q).FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 k) =XBOOLE-0R4 q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have cases: "q =FINSEQ-1R1 {}XBOOLE-0K1 or q <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "q =FINSEQ-1R1 {}XBOOLE-0K1 implies (p ^'FINSEQ-6K6 q).FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 k) =XBOOLE-0R4 q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
      proof(rule impI)
        assume "q =FINSEQ-1R1 {}XBOOLE-0K1"
        thus "(p ^'FINSEQ-6K6 q).FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 k) =XBOOLE-0R4 q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
          using A2 sorry
      qed
      have case2: "q <>HIDDENR2 {}XBOOLE-0K1 implies (p ^'FINSEQ-6K6 q).FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 k) =HIDDENR1 q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
      proof(rule impI)
        assume "q <>HIDDENR2 {}XBOOLE-0K1"
        then have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 q"
          using nat_1_th_13 sorry
        then have A3: "\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_7 sorry
        then have "lenFINSEQ-1K4 ?qc +NAT-1K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M"
          using finseq_6_lm_6 sorry
        then have "(lenFINSEQ-1K4 ?qc +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M"
           sorry
        then have A4: "k <=XXREAL-0R1 lenFINSEQ-1K4 ?qc"
          using A2 nat_1_th_13 sorry
        have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k"
          using A1 sorry
        then obtain i where
          [ty]:"i be NatNAT-1M1" and 
          "0NUMBERSK6 <=XXREAL-0R1 i"and A5: "i <XXREAL-0R3 lenFINSEQ-1K4 ?qc"and A6: "k =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M"
          using A4 finseq_6_th_127 sorry
        have "k inTARSKIR2 domFINSEQ-1K5 ?qc"
          using A1 A4 finseq_3_th_25 sorry
        then have "(p ^'FINSEQ-6K6 q).FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 k) =HIDDENR1 ((\<two>\<^sub>M,lenFINSEQ-1K4 q)-cutFINSEQ-6K4 q).FUNCT-1K1 k"
          using finseq_1_def_7 sorry
        also have "... = q .FUNCT-1K1 ((\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 i)"
          using A3 A5 A6 finseq_6_lm_6 sorry
        also have "... = q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
          using A6 sorry
        finally show "(p ^'FINSEQ-6K6 q).FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 k) =HIDDENR1 q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_142:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds \<one>\<^sub>M <XXREAL-0R3 lenFINSEQ-1K4 q implies (p ^'FINSEQ-6K6 q).FUNCT-1K1 lenFINSEQ-1K4 (p ^'FINSEQ-6K6 q) =XBOOLE-0R4 q .FUNCT-1K1 lenFINSEQ-1K4 q"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds \<one>\<^sub>M <XXREAL-0R3 lenFINSEQ-1K4 q implies (p ^'FINSEQ-6K6 q).FUNCT-1K1 lenFINSEQ-1K4 (p ^'FINSEQ-6K6 q) =XBOOLE-0R4 q .FUNCT-1K1 lenFINSEQ-1K4 q"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    let ?r = "p ^'FINSEQ-6K6 q"
    let ?qc = "(\<two>\<^sub>M,lenFINSEQ-1K4 q)-cutFINSEQ-6K4 q"
    assume A1: "\<one>\<^sub>M <XXREAL-0R3 lenFINSEQ-1K4 q"
    then have "\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 q"
      using nat_1_th_13 sorry
    then have A2: "(\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 q -XCMPLX-0K6 \<one>\<^sub>M"
      using xreal_1_th_9 sorry
    have "q <>HIDDENR2 {}XBOOLE-0K1"
      using A1 sorry
    then have "(lenFINSEQ-1K4 ?r +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M =XBOOLE-0R4 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q)-XCMPLX-0K6 \<one>\<^sub>M"
      using finseq_6_th_139 sorry
    then have A3: "lenFINSEQ-1K4 ?r =XBOOLE-0R4 lenFINSEQ-1K4 p +XCMPLX-0K2 (lenFINSEQ-1K4 q -XCMPLX-0K6 \<one>\<^sub>M)"
       sorry
    have "\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M"
      using A1 xreal_1_th_7 sorry
    then have "lenFINSEQ-1K4 ?qc +NAT-1K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M"
      using finseq_6_lm_6 sorry
    then have A4: "(lenFINSEQ-1K4 ?qc +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M"
       sorry
    then have "lenFINSEQ-1K4 ?qc <XXREAL-0R3 lenFINSEQ-1K4 q"
      using nat_1_th_13 sorry
    thus "(p ^'FINSEQ-6K6 q).FUNCT-1K1 lenFINSEQ-1K4 (p ^'FINSEQ-6K6 q) =XBOOLE-0R4 q .FUNCT-1K1 lenFINSEQ-1K4 q"
      using A3 A4 A2 finseq_6_th_141 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_143:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds rngFUNCT-1K2 (p ^'FINSEQ-6K6 q) c=TARSKIR1 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds rngFUNCT-1K2 (p ^'FINSEQ-6K6 q) c=TARSKIR1 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    let ?r = "p ^'FINSEQ-6K6 q"
    let ?qc = "(\<two>\<^sub>M,lenFINSEQ-1K4 q)-cutFINSEQ-6K4 q"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (p ^'FINSEQ-6K6 q) implies x inHIDDENR3 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 rngFUNCT-1K2 ?r"
      then have "x inHIDDENR3 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 ?qc"
        using finseq_1_th_31 sorry
      then have A1: "x inHIDDENR3 rngFUNCT-1K2 p or x inHIDDENR3 rngFUNCT-1K2 ?qc"
        using xboole_0_def_3 sorry
      have "rngFUNCT-1K2 ?qc c=TARSKIR1 rngFUNCT-1K2 q"
        using finseq_6_th_137 sorry
      thus "x inHIDDENR3 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q"
        using A1 xboole_0_def_3 sorry
    qed "sorry"
    thus "rngFUNCT-1K2 (p ^'FINSEQ-6K6 q) c=TARSKIR1 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax FINSEQ_6K7 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ ^''FINSEQ-6K7\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164)
translations "p ^'FINSEQ-6K7\<^bsub>(D)\<^esub> q" \<rightharpoonup> "p ^'FINSEQ-6K6 q"

mtheorem finseq_6_add_3:
  mlet "D be setHIDDENM2", "p be FinSequenceFINSEQ-1M3-of D", "q be FinSequenceFINSEQ-1M3-of D"
"cluster p ^'FINSEQ-6K6 q as-term-is FinSequenceFINSEQ-1M3-of D"
proof
(*coherence*)
  show "p ^'FINSEQ-6K6 q be FinSequenceFINSEQ-1M3-of D"
  proof-
    have A1: "rngFUNCT-1K2 (p ^'FINSEQ-6K6 q) c=TARSKIR1 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q"
      using finseq_6_th_143 sorry
    have A2: "rngFUNCT-1K2 q c=TARSKIR1 D"
      using finseq_1_def_4 sorry
    have "rngFUNCT-1K2 p c=TARSKIR1 D"
      using finseq_1_def_4 sorry
    then have "rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q c=TARSKIR1 D"
      using A2 xboole_1_th_8 sorry
    then have "rngFUNCT-1K2 (p ^'FINSEQ-6K6 q) c=TARSKIR1 D"
      using A1 sorry
    thus "p ^'FINSEQ-6K6 q be FinSequenceFINSEQ-1M3-of D"
      using finseq_1_def_4 sorry
  qed
qed "sorry"

mtheorem finseq_6_th_144:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds (p <>HIDDENR2 {}XBOOLE-0K1 & q <>HIDDENR2 {}XBOOLE-0K1) & p .FUNCT-1K1 lenFINSEQ-1K4 p =XBOOLE-0R4 q .FUNCT-1K1 \<one>\<^sub>M implies rngFUNCT-1K2 (p ^'FINSEQ-6K6 q) =XBOOLE-0R4 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds p <>HIDDENR2 {}XBOOLE-0K1 & (q <>HIDDENR2 {}XBOOLE-0K1 & p .FUNCT-1K1 lenFINSEQ-1K4 p =XBOOLE-0R4 q .FUNCT-1K1 \<one>\<^sub>M) implies rngFUNCT-1K2 (p ^'FINSEQ-6K6 q) =XBOOLE-0R4 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    let ?r = "p ^'FINSEQ-6K6 q"
    let ?qc = "(\<two>\<^sub>M,lenFINSEQ-1K4 q)-cutFINSEQ-6K4 q"
    assume A1: "p <>HIDDENR2 {}XBOOLE-0K1"
      and A2: "q <>HIDDENR2 {}XBOOLE-0K1"
      and A3: "p .FUNCT-1K1 lenFINSEQ-1K4 p =XBOOLE-0R4 q .FUNCT-1K1 \<one>\<^sub>M"
    have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 q"
      using A2 nat_1_th_13 sorry
    then have A4: "\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M"
      using xreal_1_th_7 sorry
    then have "lenFINSEQ-1K4 ?qc +NAT-1K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M"
      using finseq_6_lm_6 sorry
    then have A5: "(lenFINSEQ-1K4 ?qc +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M"
       sorry
    have " for x be objectHIDDENM1 holds (x inHIDDENR3 rngFUNCT-1K2 (p ^'FINSEQ-6K6 q) implies x inHIDDENR3 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q) & (x inHIDDENR3 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q implies ( not x inHIDDENR3 rngFUNCT-1K2 ?r implies  False ))"
    proof(rule ballI,rule conjMI,rule impI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      show "x inHIDDENR3 rngFUNCT-1K2 (p ^'FINSEQ-6K6 q) implies x inHIDDENR3 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q"
      proof(rule impI)
        assume "x inHIDDENR3 rngFUNCT-1K2 ?r"
        then have "x inHIDDENR3 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 ?qc"
          using finseq_1_th_31 sorry
        then have A6: "x inHIDDENR3 rngFUNCT-1K2 p or x inHIDDENR3 rngFUNCT-1K2 ?qc"
          using xboole_0_def_3 sorry
        have "rngFUNCT-1K2 ?qc c=TARSKIR1 rngFUNCT-1K2 q"
          using finseq_6_th_137 sorry
        thus "x inHIDDENR3 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q"
          using A6 xboole_0_def_3 sorry
      qed
      assume "x inHIDDENR3 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q"
      then have A7: "x inHIDDENR3 rngFUNCT-1K2 p or x inHIDDENR3 rngFUNCT-1K2 q"
        using xboole_0_def_3 sorry
      assume " not x inHIDDENR3 rngFUNCT-1K2 ?r"
      then have A8: " not x inHIDDENR3 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 ?qc"
        using finseq_1_th_31 sorry
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A9: "y inHIDDENR3 domFINSEQ-1K5 q"and A10: "x =HIDDENR1 q .FUNCT-1K1 y"
        using A7 funct_1_def_3 xboole_0_def_3 sorry
      have A11: " not x inHIDDENR3 rngFUNCT-1K2 p"
        using A8 xboole_0_def_3 sorry
      have 
        [ty]:"y be ElementSUBSET-1M1-of NATNUMBERSK1"
        using A9 sorry
      have A12: "\<one>\<^sub>M <=XXREAL-0R1 y"
        using A9 finseq_3_th_25 sorry
      have A13: "y <=XXREAL-0R1 lenFINSEQ-1K4 q"
        using A9 finseq_3_th_25 sorry
      have A14: " not x inHIDDENR3 rngFUNCT-1K2 ?qc"
        using A8 xboole_0_def_3 sorry
      show " False "
      proof-
        have cases: "y =XBOOLE-0R4 \<one>\<^sub>M or \<one>\<^sub>M <XXREAL-0R3 y"
          using A12 xxreal_0_th_1 sorry
        have case1: "y =XBOOLE-0R4 \<one>\<^sub>M implies  False "
        proof(rule impI)
          assume A15: "y =XBOOLE-0R4 \<one>\<^sub>M"
          have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p"
            using A1 nat_1_th_13 sorry
          then have "lenFINSEQ-1K4 p inTARSKIR2 domFINSEQ-1K5 p"
            using finseq_3_th_25 sorry
          thus " False "
            using A3 A11 A10 A15 funct_1_def_3 sorry
        qed
        have case2: "\<one>\<^sub>M <XXREAL-0R3 y implies  False "
        proof(rule impI)
          assume "\<one>\<^sub>M <XXREAL-0R3 y"
          then have "\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 y"
            using nat_1_th_13 sorry
          then obtain i where
            [ty]:"i be NatNAT-1M1" and 
            A16: "\<one>\<^sub>M <=XXREAL-0R1 i"and A17: "i <XXREAL-0R3 lenFINSEQ-1K4 q"and A18: "y =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M"
            using A13 finseq_6_th_127 sorry
          have A19: "i <=XXREAL-0R1 lenFINSEQ-1K4 ?qc"
            using A5 A17 nat_1_th_13 sorry
          then have A20: "i inTARSKIR2 domFINSEQ-1K5 ?qc"
            using A16 finseq_3_th_25 sorry
          have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i"
            using A16 sorry
          then obtain j where
            [ty]:"j be NatNAT-1M1" and 
            "0NUMBERSK6 <=XXREAL-0R1 j"and A21: "j <XXREAL-0R3 lenFINSEQ-1K4 ?qc"and A22: "i =XBOOLE-0R4 j +NAT-1K1 \<one>\<^sub>M"
            using A19 finseq_6_th_127 sorry
          have "?qc .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 q .FUNCT-1K1 ((\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 j)"
            using A4 A21 finseq_6_lm_6 sorry
          also have "... = q .FUNCT-1K1 y"
            using A18 A22 sorry
          finally have "?qc .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 q .FUNCT-1K1 y"
             sorry
          thus " False "
            using A14 A10 A22 A20 funct_1_def_3 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus "rngFUNCT-1K2 (p ^'FINSEQ-6K6 q) =XBOOLE-0R4 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mdef finseq_6_def_6 ("TwoValuedFINSEQ-6V2" 70 ) where
"attr TwoValuedFINSEQ-6V2 for FinSequenceFINSEQ-1M1 means
  (\<lambda>f. cardCARD-1K4 (rngFUNCT-1K2 f) =XBOOLE-0R4 \<two>\<^sub>M)"..

mlemma finseq_6_lm_7:
"lenFINSEQ-1K4 (<*FINSEQ-4K2\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M,\<two>\<^sub>M *>) >XXREAL-0R4 \<one>\<^sub>M & (\<one>\<^sub>M <>HIDDENR2 \<two>\<^sub>M & rngFUNCT-1K2 (<*FINSEQ-4K2\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M,\<two>\<^sub>M *>) =HIDDENR1 {TARSKIK2 \<one>\<^sub>M,\<two>\<^sub>M })"
proof(rule conjMI,rule conjMI)
  let ?p = "<*FINSEQ-4K2\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M,\<two>\<^sub>M *>"
  have "\<two>\<^sub>M >XXREAL-0R4 \<one>\<^sub>M"
     sorry
  thus "lenFINSEQ-1K4 (<*FINSEQ-4K2\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M,\<two>\<^sub>M *>) >XXREAL-0R4 \<one>\<^sub>M"
    using finseq_1_th_44 sorry
  show "\<one>\<^sub>M <>HIDDENR2 \<two>\<^sub>M"
     sorry
  have "rngFUNCT-1K2 (<*FINSEQ-4K2\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M,\<two>\<^sub>M *>) =HIDDENR1 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M*>) \\/XBOOLE-0K2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> \<two>\<^sub>M*>)"
    using finseq_1_th_31 sorry
  also have "... = {TARSKIK1 \<one>\<^sub>M} \\/XBOOLE-0K2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> \<two>\<^sub>M*>)"
    using finseq_1_th_38 sorry
  also have "... = {TARSKIK1 \<one>\<^sub>M} \\/XBOOLE-0K2 {TARSKIK1 \<two>\<^sub>M}"
    using finseq_1_th_38 sorry
  also have "... = {TARSKIK2 \<one>\<^sub>M,\<two>\<^sub>M }"
    using enumset1_th_1 sorry
  finally show "rngFUNCT-1K2 (<*FINSEQ-4K2\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M,\<two>\<^sub>M *>) =HIDDENR1 {TARSKIK2 \<one>\<^sub>M,\<two>\<^sub>M }"
     sorry
qed

mtheorem finseq_6_th_145:
" for p be FinSequenceFINSEQ-1M1 holds p be TwoValuedFINSEQ-6V2 iff lenFINSEQ-1K4 p >XXREAL-0R4 \<one>\<^sub>M & ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st x <>HIDDENR2 y & rngFUNCT-1K2 p =XBOOLE-0R4 {TARSKIK2 x,y })"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds (p be TwoValuedFINSEQ-6V2 implies lenFINSEQ-1K4 p >XXREAL-0R4 \<one>\<^sub>M & ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st x <>HIDDENR2 y & rngFUNCT-1K2 p =XBOOLE-0R4 {TARSKIK2 x,y })) & (lenFINSEQ-1K4 p >XXREAL-0R4 \<one>\<^sub>M implies (( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st x <>HIDDENR2 y & rngFUNCT-1K2 p =XBOOLE-0R4 {TARSKIK2 x,y }) implies p be TwoValuedFINSEQ-6V2))"
  proof(rule ballI,rule conjMI,rule impI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    show "p be TwoValuedFINSEQ-6V2 implies lenFINSEQ-1K4 p >XXREAL-0R4 \<one>\<^sub>M & ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st x <>HIDDENR2 y & rngFUNCT-1K2 p =XBOOLE-0R4 {TARSKIK2 x,y })"
    proof(rule impI,rule conjMI)
      assume "p be TwoValuedFINSEQ-6V2"
      then have "cardCARD-1K4 (rngFUNCT-1K2 p) =XBOOLE-0R4 \<two>\<^sub>M"
         sorry
      then obtain x y where
        [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
        A1: "x <>HIDDENR2 y"and A2: "rngFUNCT-1K2 p =XBOOLE-0R4 {TARSKIK2 x,y }"
        using card_2_th_60 sorry
      show "lenFINSEQ-1K4 p >XXREAL-0R4 \<one>\<^sub>M"
      proof-
        have "lenFINSEQ-1K4 p <=XXREAL-0R1 \<one>\<^sub>M implies  False "
        proof(rule impI)
          let ?l = "lenFINSEQ-1K4 p"
          assume A3: "lenFINSEQ-1K4 p <=XXREAL-0R1 \<one>\<^sub>M"
          show " False "
          proof-
            have cases: "?l =XBOOLE-0R4 0NUMBERSK6 or ?l =XBOOLE-0R4 \<one>\<^sub>M"
              using A3 nat_1_th_25 sorry
            have case1: "lenFINSEQ-1K4 p =XBOOLE-0R4 0NUMBERSK6 implies  False "
            proof(rule impI)
              assume "?l =XBOOLE-0R4 0NUMBERSK6"
              then have "p =FINSEQ-1R1 {}XBOOLE-0K1"
                 sorry
              thus " False "
                using A2 sorry
            qed
            have case2: "lenFINSEQ-1K4 p =XBOOLE-0R4 \<one>\<^sub>M implies  False "
            proof(rule impI)
              assume A4: "?l =XBOOLE-0R4 \<one>\<^sub>M"
              then have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
                using finseq_3_th_25 sorry
              then obtain z where
                [ty]:"z be objectHIDDENM1" and 
                A5: "[TARSKIK4 \<one>\<^sub>M,z ] inHIDDENR3 p"
                using xtuple_0_def_12 sorry
              have "z =HIDDENR1 p .FUNCT-1K1 \<one>\<^sub>M"
                using A5 funct_1_th_1 sorry
              then have "p =FINSEQ-1R1 <*FINSEQ-1K10 z*>"
                using A4 finseq_1_th_40 sorry
              then have A6: "rngFUNCT-1K2 p =XBOOLE-0R4 {TARSKIK1 z}"
                using finseq_1_th_39 sorry
              then have "z =HIDDENR1 x"
                using A2 zfmisc_1_th_4 sorry
              thus " False "
                using A1 A2 A6 zfmisc_1_th_4 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus " ?thesis "
           sorry
      qed
      show " ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st x <>HIDDENR2 y & rngFUNCT-1K2 p =XBOOLE-0R4 {TARSKIK2 x,y }"
        using A1 A2 sorry
    qed
    assume "lenFINSEQ-1K4 p >XXREAL-0R4 \<one>\<^sub>M"
    assume Given: " ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st x <>HIDDENR2 y & rngFUNCT-1K2 p =XBOOLE-0R4 {TARSKIK2 x,y }"
    then obtain x y where
      [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
      A7: "x <>HIDDENR2 y"and A8: "rngFUNCT-1K2 p =XBOOLE-0R4 {TARSKIK2 x,y }"
       sorry
    have "cardCARD-1K4 (rngFUNCT-1K2 p) =XBOOLE-0R4 \<two>\<^sub>M"
      using A7 A8 card_2_th_57 sorry
    thus "p be TwoValuedFINSEQ-6V2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma finseq_6_lm_8:
"<*FINSEQ-4K2\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M,\<two>\<^sub>M *> be TwoValuedFINSEQ-6V2"
  using finseq_6_lm_7 sorry

mlemma finseq_6_lm_9:
" for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 (<*FINSEQ-4K2\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M,\<two>\<^sub>M *>) implies (<*FINSEQ-4K2\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M,\<two>\<^sub>M *>).FUNCT-1K1 i <>HIDDENR2 (<*FINSEQ-4K2\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M,\<two>\<^sub>M *>).FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)"
proof(rule ballI,rule impMI ,rule impI)
  fix i assume [ty]: "i be NatNAT-1M1"
  let ?p = "<*FINSEQ-4K2\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M,\<two>\<^sub>M *>"
  assume A1: "\<one>\<^sub>M <=XXREAL-0R1 i"
    and A2: "i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 ?p"
  have "i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
    using A2 finseq_1_th_44 sorry
  then have "i <=XXREAL-0R1 \<one>\<^sub>M"
    using xreal_1_th_6 sorry
  then have A3: "i =XBOOLE-0R4 \<one>\<^sub>M"
    using A1 xxreal_0_th_1 sorry
  then have "?p .FUNCT-1K1 i =XBOOLE-0R4 \<one>\<^sub>M"
    using finseq_1_th_44 sorry
  thus "(<*FINSEQ-4K2\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M,\<two>\<^sub>M *>).FUNCT-1K1 i <>HIDDENR2 (<*FINSEQ-4K2\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M,\<two>\<^sub>M *>).FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)"
    using A3 finseq_1_th_44 sorry
qed "sorry"

mdef finseq_6_def_7 ("AlternatingFINSEQ-6V3" 70 ) where
"attr AlternatingFINSEQ-6V3 for FinSequenceFINSEQ-1M1 means
  (\<lambda>f.  for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f implies f .FUNCT-1K1 i <>HIDDENR2 f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))"..

mlemma finseq_6_lm_10:
"<*FINSEQ-4K2\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M,\<two>\<^sub>M *> be AlternatingFINSEQ-6V3"
  using finseq_6_lm_9 sorry

mtheorem finseq_6_cl_8:
"cluster TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3 for FinSequenceFINSEQ-1M1"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M1 st it be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3"
    using finseq_6_lm_8 finseq_6_lm_10 sorry
qed "sorry"

reserve a, a1, a2 for "TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1"
mtheorem finseq_6_th_146:
" for a1 be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1 holds  for a2 be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1 holds (lenFINSEQ-1K4 a1 =XBOOLE-0R4 lenFINSEQ-1K4 a2 & rngFUNCT-1K2 a1 =XBOOLE-0R4 rngFUNCT-1K2 a2) & a1 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 a2 .FUNCT-1K1 \<one>\<^sub>M implies a1 =FINSEQ-1R1 a2"
proof-
  have " for a1 be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1 holds  for a2 be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 a1 =XBOOLE-0R4 lenFINSEQ-1K4 a2 & (rngFUNCT-1K2 a1 =XBOOLE-0R4 rngFUNCT-1K2 a2 & a1 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 a2 .FUNCT-1K1 \<one>\<^sub>M) implies a1 =FINSEQ-1R1 a2"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a1 assume [ty]: "a1 be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1"
    fix a2 assume [ty]: "a2 be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1"
    assume A1: "lenFINSEQ-1K4 a1 =XBOOLE-0R4 lenFINSEQ-1K4 a2"
      and A2: "rngFUNCT-1K2 a1 =XBOOLE-0R4 rngFUNCT-1K2 a2"
      and A3: "a1 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 a2 .FUNCT-1K1 \<one>\<^sub>M"
    let ?P = "\<lambda>Lamb1. \<one>\<^sub>M <=XXREAL-0R1 Lamb1 & Lamb1 <=XXREAL-0R1 lenFINSEQ-1K4 a1 implies a1 .FUNCT-1K1 Lamb1 =XBOOLE-0R4 a2 .FUNCT-1K1 Lamb1"
    have A4: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds (\<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 a1 implies a1 .FUNCT-1K1 k =XBOOLE-0R4 a2 .FUNCT-1K1 k) implies (\<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M & k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 a1 implies a1 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 a2 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))"
      proof(rule ballI,rule impI,rule impMI ,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A5: "\<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 a1 implies a1 .FUNCT-1K1 k =XBOOLE-0R4 a2 .FUNCT-1K1 k"
        have A6: "0NUMBERSK6 =XBOOLE-0R4 k or 0NUMBERSK6 <XXREAL-0R3 k & 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
           sorry
        assume A7: "\<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
          and A8: "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 a1"
        have A9: "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 a1"
          using A7 A8 finseq_3_th_25 sorry
        show "a1 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 a2 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
        proof-
          have cases: "0NUMBERSK6 =XBOOLE-0R4 k or \<one>\<^sub>M <=XXREAL-0R1 k"
            using A6 nat_1_th_13 sorry
          have case1: "0NUMBERSK6 =XBOOLE-0R4 k implies a1 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 a2 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
          proof(rule impI)
            assume "0NUMBERSK6 =XBOOLE-0R4 k"
            thus "a1 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 a2 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
              using A3 sorry
          qed
          have case2: "\<one>\<^sub>M <=XXREAL-0R1 k implies a1 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 a2 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
          proof(rule impI)
            assume A10: "\<one>\<^sub>M <=XXREAL-0R1 k"
            have A11: "domFINSEQ-1K5 a2 =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 a2)"
              using finseq_1_def_3 sorry
            obtain X Y where
              [ty]:"X be objectHIDDENM1" "Y be objectHIDDENM1" and 
              "X <>HIDDENR2 Y"and A12: "rngFUNCT-1K2 a1 =XBOOLE-0R4 {TARSKIK2 X,Y }"
              using finseq_6_th_145 sorry
            have "a1 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngFUNCT-1K2 a1"
              using A9 funct_1_def_3 sorry
            then have A13: "a1 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 X or a1 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Y"
              using A12 tarski_def_2 sorry
            have "domFINSEQ-1K5 a1 =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 a1)"
              using finseq_1_def_3 sorry
            then have "a2 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngFUNCT-1K2 a2"
              using A1 A9 A11 funct_1_def_3 sorry
            then have A14: "a2 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 X or a2 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Y"
              using A2 A12 tarski_def_2 sorry
            have "k <=XXREAL-0R1 lenFINSEQ-1K4 a1"
              using A8 nat_1_th_13 sorry
            then have "k inTARSKIR2 domFINSEQ-1K5 a1"
              using A10 finseq_3_th_25 sorry
            then have "a1 .FUNCT-1K1 k inTARSKIR2 rngFUNCT-1K2 a1"
              using funct_1_def_3 sorry
            then have "a1 .FUNCT-1K1 k =HIDDENR1 X or a1 .FUNCT-1K1 k =HIDDENR1 Y"
              using A12 tarski_def_2 sorry
            thus "a1 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 a2 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
              using A1 A5 A8 A10 A13 A14 finseq_6_def_7 nat_1_th_13 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A15: "?P(0NUMBERSK6)"
       sorry
    have " for i be NatNAT-1M1 holds ?P(i)"
      using nat_1_sch_2 A15 A4 sorry
    thus "a1 =FINSEQ-1R1 a2"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_147:
" for a1 be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1 holds  for a2 be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1 holds (a1 <>HIDDENR2 a2 & lenFINSEQ-1K4 a1 =XBOOLE-0R4 lenFINSEQ-1K4 a2) & rngFUNCT-1K2 a1 =XBOOLE-0R4 rngFUNCT-1K2 a2 implies ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 a1 implies a1 .FUNCT-1K1 i <>HIDDENR2 a2 .FUNCT-1K1 i)"
proof-
  have " for a1 be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1 holds  for a2 be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1 holds a1 <>HIDDENR2 a2 & (lenFINSEQ-1K4 a1 =XBOOLE-0R4 lenFINSEQ-1K4 a2 & rngFUNCT-1K2 a1 =XBOOLE-0R4 rngFUNCT-1K2 a2) implies ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 a1 implies a1 .FUNCT-1K1 i <>HIDDENR2 a2 .FUNCT-1K1 i)"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a1 assume [ty]: "a1 be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1"
    fix a2 assume [ty]: "a2 be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1"
    assume A1: "a1 <>HIDDENR2 a2"
      and A2: "lenFINSEQ-1K4 a1 =XBOOLE-0R4 lenFINSEQ-1K4 a2"
      and A3: "rngFUNCT-1K2 a1 =XBOOLE-0R4 rngFUNCT-1K2 a2"
    let ?P = "\<lambda>Lamb1. \<one>\<^sub>M <=XXREAL-0R1 Lamb1 & Lamb1 <=XXREAL-0R1 lenFINSEQ-1K4 a1 implies a1 .FUNCT-1K1 Lamb1 <>HIDDENR2 a2 .FUNCT-1K1 Lamb1"
    have A4: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds (\<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 a1 implies a1 .FUNCT-1K1 k <>HIDDENR2 a2 .FUNCT-1K1 k) implies (\<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M & k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 a1 implies  not a1 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 a2 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))"
      proof(rule ballI,rule impI,rule impMI ,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A5: "\<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 a1 implies a1 .FUNCT-1K1 k <>HIDDENR2 a2 .FUNCT-1K1 k"
        have A6: "0NUMBERSK6 =XBOOLE-0R4 k or 0NUMBERSK6 <XXREAL-0R3 k & 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
           sorry
        assume A7: "\<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
          and A8: "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 a1"
        have A9: "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 a1"
          using A7 A8 finseq_3_th_25 sorry
        show " not a1 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 a2 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
        proof-
          have cases: "0NUMBERSK6 =XBOOLE-0R4 k or \<one>\<^sub>M <=XXREAL-0R1 k"
            using A6 nat_1_th_13 sorry
          have case1: "0NUMBERSK6 =XBOOLE-0R4 k implies  not a1 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 a2 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
          proof(rule impI)
            assume "0NUMBERSK6 =XBOOLE-0R4 k"
            thus " not a1 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 a2 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
              using A1 A2 A3 finseq_6_th_146 sorry
          qed
          have case2: "\<one>\<^sub>M <=XXREAL-0R1 k implies  not a1 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 a2 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
          proof(rule impI)
            assume A10: "\<one>\<^sub>M <=XXREAL-0R1 k"
            have "k <=XXREAL-0R1 lenFINSEQ-1K4 a1"
              using A8 nat_1_th_13 sorry
            then have A11: "k inTARSKIR2 domFINSEQ-1K5 a1"
              using A10 finseq_3_th_25 sorry
            have A12: "domFINSEQ-1K5 a2 =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 a2)"
              using finseq_1_def_3 sorry
            obtain X Y where
              [ty]:"X be objectHIDDENM1" "Y be objectHIDDENM1" and 
              "X <>HIDDENR2 Y"and A13: "rngFUNCT-1K2 a1 =XBOOLE-0R4 {TARSKIK2 X,Y }"
              using finseq_6_th_145 sorry
            have "a1 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngFUNCT-1K2 a1"
              using A9 funct_1_def_3 sorry
            then have A14: "a1 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 X or a1 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Y"
              using A13 tarski_def_2 sorry
            have "domFINSEQ-1K5 a1 =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 a1)"
              using finseq_1_def_3 sorry
            then have "a2 .FUNCT-1K1 k inTARSKIR2 rngFUNCT-1K2 a2"
              using A2 A11 A12 funct_1_def_3 sorry
            then have A15: "a2 .FUNCT-1K1 k =HIDDENR1 X or a2 .FUNCT-1K1 k =HIDDENR1 Y"
              using A3 A13 tarski_def_2 sorry
            have "a1 .FUNCT-1K1 k inTARSKIR2 rngFUNCT-1K2 a1"
              using A11 funct_1_def_3 sorry
            then have "a1 .FUNCT-1K1 k =HIDDENR1 X or a1 .FUNCT-1K1 k =HIDDENR1 Y"
              using A13 tarski_def_2 sorry
            thus " not a1 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 a2 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
              using A2 A5 A8 A10 A15 A14 finseq_6_def_7 nat_1_th_13 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A16: "?P(0NUMBERSK6)"
       sorry
    show " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 a1 implies a1 .FUNCT-1K1 i <>HIDDENR2 a2 .FUNCT-1K1 i"
      using nat_1_sch_2 A16 A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_148:
" for a1 be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1 holds  for a2 be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1 holds (a1 <>HIDDENR2 a2 & lenFINSEQ-1K4 a1 =XBOOLE-0R4 lenFINSEQ-1K4 a2) & rngFUNCT-1K2 a1 =XBOOLE-0R4 rngFUNCT-1K2 a2 implies ( for a be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 a1 & rngFUNCT-1K2 a =XBOOLE-0R4 rngFUNCT-1K2 a1 implies a =FINSEQ-1R1 a1 or a =FINSEQ-1R1 a2)"
proof-
  have " for a1 be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1 holds  for a2 be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1 holds a1 <>HIDDENR2 a2 & (lenFINSEQ-1K4 a1 =XBOOLE-0R4 lenFINSEQ-1K4 a2 & rngFUNCT-1K2 a1 =XBOOLE-0R4 rngFUNCT-1K2 a2) implies ( for a be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 a1 & rngFUNCT-1K2 a =XBOOLE-0R4 rngFUNCT-1K2 a1 implies (a <>HIDDENR2 a1 implies a =FINSEQ-1R1 a2))"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule ballI,rule impMI ,rule impI,rule impI)
    fix a1 assume [ty]: "a1 be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1"
    fix a2 assume [ty]: "a2 be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1"
    assume A1: "a1 <>HIDDENR2 a2"
      and A2: "lenFINSEQ-1K4 a1 =XBOOLE-0R4 lenFINSEQ-1K4 a2"
      and A3: "rngFUNCT-1K2 a1 =XBOOLE-0R4 rngFUNCT-1K2 a2"
    fix a assume [ty]: "a be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1"
    assume A4: "lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 a1"
      and A5: "rngFUNCT-1K2 a =XBOOLE-0R4 rngFUNCT-1K2 a1"
    assume A6: "a <>HIDDENR2 a1"
    have " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 a implies a .FUNCT-1K1 i =XBOOLE-0R4 a2 .FUNCT-1K1 i"
    proof(rule ballI,rule impMI ,rule impI)
      fix i assume [ty]: "i be NatNAT-1M1"
      assume A7: "\<one>\<^sub>M <=XXREAL-0R1 i"
        and A8: "i <=XXREAL-0R1 lenFINSEQ-1K4 a"
      obtain X Y where
        [ty]:"X be objectHIDDENM1" "Y be objectHIDDENM1" and 
        "X <>HIDDENR2 Y"and A9: "rngFUNCT-1K2 a =XBOOLE-0R4 {TARSKIK2 X,Y }"
        using finseq_6_th_145 sorry
      have A10: "i inTARSKIR2 domFINSEQ-1K5 a"
        using A7 A8 finseq_3_th_25 sorry
      then have "a .FUNCT-1K1 i inTARSKIR2 rngFUNCT-1K2 a"
        using funct_1_def_3 sorry
      then have A11: "a .FUNCT-1K1 i =HIDDENR1 X or a .FUNCT-1K1 i =HIDDENR1 Y"
        using A9 tarski_def_2 sorry
      have A12: "domFINSEQ-1K5 a =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 a)"
        using finseq_1_def_3 sorry
      have "domFINSEQ-1K5 a1 =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 a1)"
        using finseq_1_def_3 sorry
      then have "a1 .FUNCT-1K1 i inTARSKIR2 rngFUNCT-1K2 a1"
        using A4 A10 A12 funct_1_def_3 sorry
      then have A13: "a1 .FUNCT-1K1 i =HIDDENR1 X or a1 .FUNCT-1K1 i =HIDDENR1 Y"
        using A5 A9 tarski_def_2 sorry
      have "domFINSEQ-1K5 a2 =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 a2)"
        using finseq_1_def_3 sorry
      then have "a2 .FUNCT-1K1 i inTARSKIR2 rngFUNCT-1K2 a2"
        using A2 A4 A10 A12 funct_1_def_3 sorry
      then have "a2 .FUNCT-1K1 i =HIDDENR1 X or a2 .FUNCT-1K1 i =HIDDENR1 Y"
        using A3 A5 A9 tarski_def_2 sorry
      thus "a .FUNCT-1K1 i =XBOOLE-0R4 a2 .FUNCT-1K1 i"
        using A1 A2 A3 A4 A5 A6 A7 A8 A11 A13 finseq_6_th_147 sorry
    qed "sorry"
    thus "a =FINSEQ-1R1 a2"
      using A2 A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_149:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for n be NatNAT-1M1 holds X <>HIDDENR2 Y & n >XXREAL-0R4 \<one>\<^sub>M implies ( ex a1 be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1 st (rngFUNCT-1K2 a1 =XBOOLE-0R4 {TARSKIK2 X,Y } & lenFINSEQ-1K4 a1 =XBOOLE-0R4 n) & a1 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 X)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for n be NatNAT-1M1 holds X <>HIDDENR2 Y & n >XXREAL-0R4 \<one>\<^sub>M implies ( ex tVar6 be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1 st rngFUNCT-1K2 tVar6 =XBOOLE-0R4 {TARSKIK2 X,Y } & (lenFINSEQ-1K4 tVar6 =XBOOLE-0R4 n & tVar6 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 X))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?F = "\<lambda>Lamb1. \<lambda>Lamb2. \<three>\<^sub>M -'NAT-DK9 Lamb2"
    assume A1: "X <>HIDDENR2 Y"
      and A2: "n >XXREAL-0R4 \<one>\<^sub>M"
    let ?p = "<*FINSEQ-1K11 X,Y *>"
    have A3: "?p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 X"
      using finseq_1_th_44 sorry
    have A4: "\<three>\<^sub>M -'NAT-DK9 \<two>\<^sub>M =HIDDENR1 (\<one>\<^sub>M +NAT-1K1 \<two>\<^sub>M)-XCMPLX-0K6 \<two>\<^sub>M"
      using xreal_0_def_2 sorry
    also have "... = \<one>\<^sub>M"
       sorry
    finally have "\<three>\<^sub>M -'NAT-DK9 \<two>\<^sub>M =HIDDENR1 \<one>\<^sub>M"
       sorry
    have A5: "?p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 Y"
      using finseq_1_th_44 sorry
    obtain f1 where
      [ty]:"f1 be sequenceNAT-1M2-of NATNUMBERSK1" and 
      A6: "f1 .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 \<two>\<^sub>M & ( for n be NatNAT-1M1 holds f1 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 ?F(n,f1 .FUNCT-1K1 n))"
      using nat_1_sch_12 sorry
    let ?P = "\<lambda>Lamb1. (f1 .FUNCT-1K1 Lamb1 =XBOOLE-0R4 \<one>\<^sub>M or f1 .FUNCT-1K1 Lamb1 =XBOOLE-0R4 \<two>\<^sub>M) & f1 .FUNCT-1K1 Lamb1 <>HIDDENR2 f1 .FUNCT-1K1 (Lamb1 +NAT-1K1 \<one>\<^sub>M)"
    have A7: "\<three>\<^sub>M -'NAT-DK9 \<one>\<^sub>M =HIDDENR1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
      using xreal_0_def_2 sorry
    also have "... = \<two>\<^sub>M"
       sorry
    finally have "\<three>\<^sub>M -'NAT-DK9 \<one>\<^sub>M =HIDDENR1 \<two>\<^sub>M"
       sorry
    have A8: " for i be NatNAT-1M1 holds ?P(i) implies ?P(i +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for i be NatNAT-1M1 holds (f1 .FUNCT-1K1 i =XBOOLE-0R4 \<one>\<^sub>M or f1 .FUNCT-1K1 i =XBOOLE-0R4 \<two>\<^sub>M) & f1 .FUNCT-1K1 i <>HIDDENR2 f1 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) implies (f1 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<one>\<^sub>M or f1 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M) &  not f1 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 f1 .FUNCT-1K1 ((i +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI,rule impMI ,rule impI,rule conjMI)
        fix i assume [ty]: "i be NatNAT-1M1"
        assume A9: "f1 .FUNCT-1K1 i =XBOOLE-0R4 \<one>\<^sub>M or f1 .FUNCT-1K1 i =XBOOLE-0R4 \<two>\<^sub>M"
          and "f1 .FUNCT-1K1 i <>HIDDENR2 f1 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)"
        show "f1 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<one>\<^sub>M or f1 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M"
          using A6 A4 A7 A9 sorry
        thus " not f1 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 f1 .FUNCT-1K1 ((i +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
          using A6 A4 A7 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A10: "?P(0NUMBERSK6)"
      using A6 A4 sorry
    have A11: " for i be NatNAT-1M1 holds ?P(i)"
      using nat_1_sch_2 A10 A8 sorry
    let ?F = "\<lambda>Lamb1. ?p .FUNCT-1K1 (f1 .FUNCT-1K1 Lamb1)"
    obtain p1 where
      [ty]:"p1 be FinSequenceFINSEQ-1M1" and 
      A12: "lenFINSEQ-1K4 p1 =XBOOLE-0R4 n & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p1 implies p1 .FUNCT-1K1 k =XBOOLE-0R4 ?F(k))"
      using finseq_1_sch_2 sorry
    have A13: "f1 .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<one>\<^sub>M"
      using A6 A4 sorry
    then have A14: "f1 .FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M"
      using A6 A7 sorry
    have A15: " for y be objectHIDDENM1 holds (y inHIDDENR3 {TARSKIK2 X,Y } implies ( ex x be objectHIDDENM1 st x inHIDDENR3 domFINSEQ-1K5 p1 & y =HIDDENR1 p1 .FUNCT-1K1 x)) & (( ex x be objectHIDDENM1 st x inHIDDENR3 domFINSEQ-1K5 p1 & y =HIDDENR1 p1 .FUNCT-1K1 x) implies y inHIDDENR3 {TARSKIK2 X,Y })"
    proof(rule ballI,rule conjMI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      show "y inHIDDENR3 {TARSKIK2 X,Y } implies ( ex x be objectHIDDENM1 st x inHIDDENR3 domFINSEQ-1K5 p1 & y =HIDDENR1 p1 .FUNCT-1K1 x)"
      proof(rule impI)
        assume "y inHIDDENR3 {TARSKIK2 X,Y }"
        then have A16: "y =HIDDENR1 X or y =HIDDENR1 Y"
          using tarski_def_2 sorry
        have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p1"
          using A2 A12 finseq_3_th_25 sorry
        then have A17: "p1 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 X"
          using A3 A13 A12 sorry
        have A18: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p1"
          using A2 A12 finseq_3_th_25 sorry
        have "\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
          using A2 nat_1_th_13 sorry
        then have A19: "\<two>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p1"
          using A12 finseq_3_th_25 sorry
        then have "p1 .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 Y"
          using A5 A14 A12 sorry
        thus " ex x be objectHIDDENM1 st x inHIDDENR3 domFINSEQ-1K5 p1 & y =HIDDENR1 p1 .FUNCT-1K1 x"
          using A16 A19 A17 A18 sorry
      qed
      assume Given: " ex x be objectHIDDENM1 st x inHIDDENR3 domFINSEQ-1K5 p1 & y =HIDDENR1 p1 .FUNCT-1K1 x"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A20: "x inHIDDENR3 domFINSEQ-1K5 p1"and A21: "y =HIDDENR1 p1 .FUNCT-1K1 x"
         sorry
      have "x inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 p1)"
        using A20 finseq_1_def_3 sorry
      then obtain x9 where
        [ty]:"x9 be NatNAT-1M1" and 
        A22: "x9 =HIDDENR1 x"and A23: "\<one>\<^sub>M <=XXREAL-0R1 x9"and A24: "x9 <=XXREAL-0R1 lenFINSEQ-1K4 p1"
         sorry
      have "x9 inTARSKIR2 domFINSEQ-1K5 p1"
        using A23 A24 finseq_3_th_25 sorry
      then have A25: "p1 .FUNCT-1K1 x9 =XBOOLE-0R4 ?p .FUNCT-1K1 (f1 .FUNCT-1K1 x9)"
        using A12 sorry
      have "f1 .FUNCT-1K1 x9 =XBOOLE-0R4 \<one>\<^sub>M or f1 .FUNCT-1K1 x9 =XBOOLE-0R4 \<two>\<^sub>M"
        using A11 sorry
      thus "y inHIDDENR3 {TARSKIK2 X,Y }"
        using A3 A5 A21 A22 A25 tarski_def_2 sorry
    qed "sorry"
    then have "rngFUNCT-1K2 p1 =XBOOLE-0R4 {TARSKIK2 X,Y }"
      using funct_1_def_3 sorry
    then have 
      [ty]:"p1 be TwoValuedFINSEQ-6V2\<bar>FinSequenceFINSEQ-1M1"
      using A1 A2 A12 finseq_6_th_145 sorry
    have " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p1 implies p1 .FUNCT-1K1 i <>HIDDENR2 p1 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)"
    proof(rule ballI,rule impMI ,rule impI)
      fix i assume [ty]: "i be NatNAT-1M1"
      assume A26: "\<one>\<^sub>M <=XXREAL-0R1 i"
        and A27: "i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p1"
      have "\<one>\<^sub>M <=XXREAL-0R1 i +NAT-1K1 \<one>\<^sub>M"
        using A26 nat_1_th_13 sorry
      then have "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p1"
        using A27 finseq_3_th_25 sorry
      then have A28: "p1 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 ?p .FUNCT-1K1 (f1 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))"
        using A12 sorry
      have A29: "f1 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<one>\<^sub>M or f1 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M"
        using A11 sorry
      have "i <=XXREAL-0R1 n"
        using A12 A27 nat_1_th_13 sorry
      then have "i inTARSKIR2 domFINSEQ-1K5 p1"
        using A12 A26 finseq_3_th_25 sorry
      then have "p1 .FUNCT-1K1 i =XBOOLE-0R4 ?p .FUNCT-1K1 (f1 .FUNCT-1K1 i)"
        using A12 sorry
      thus "p1 .FUNCT-1K1 i <>HIDDENR2 p1 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)"
        using A1 A3 A5 A11 A28 A29 sorry
    qed "sorry"
    then have 
      [ty]:"p1 be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1"
      using finseq_6_def_7 sorry
    show " ex tVar6 be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1 st rngFUNCT-1K2 tVar6 =XBOOLE-0R4 {TARSKIK2 X,Y } & (lenFINSEQ-1K4 tVar6 =XBOOLE-0R4 n & tVar6 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 X)"
    proof(rule bexI[of _ "p1"],rule conjMI,rule conjMI)
      show "rngFUNCT-1K2 p1 =XBOOLE-0R4 {TARSKIK2 X,Y }"
        using A15 funct_1_def_3 sorry
      show "lenFINSEQ-1K4 p1 =XBOOLE-0R4 n"
        using A12 sorry
      have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p1"
        using A2 A12 finseq_3_th_25 sorry
      thus "p1 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 X"
        using A3 A13 A12 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem finseq_6_cl_9:
  mlet "X be setHIDDENM2", "fs be FinSequenceFINSEQ-1M3-of X"
"cluster note-that FinSubsequence-likeFINSEQ-1V2 for SubsetSUBSET-1M2-of fs"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of fs holds it be FinSubsequence-likeFINSEQ-1V2"
  proof-
    have " for IT be SubsetSUBSET-1M2-of fs holds IT be FinSubsequence-likeFINSEQ-1V2"
    proof(rule ballI)
      fix IT assume [ty]: "IT be SubsetSUBSET-1M2-of fs"
      have Cut4563: "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> IT c=TARSKIR1 domFINSEQ-1K5 fs"
        using relat_1_th_11 sorry
      have "domRELAT-1K1 IT c=TARSKIR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 fs)"
      proof-
        show "domRELAT-1K1 IT c=TARSKIR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 fs)"
          using finseq_1_def_3 Cut4563 sorry
      qed
      thus "IT be FinSubsequence-likeFINSEQ-1V2"
        using bexI[of _ "lenFINSEQ-1K4 fs"] finseq_1_def_12 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finseq_6_th_150:
" for f be FinSubsequenceFINSEQ-1M4 holds  for g be FinSequenceFINSEQ-1M1 holds  for h be FinSequenceFINSEQ-1M1 holds  for fg be FinSequenceFINSEQ-1M1 holds  for fh be FinSequenceFINSEQ-1M1 holds  for fgh be FinSequenceFINSEQ-1M1 holds (((rngFUNCT-1K2 g c=TARSKIR1 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> f & rngFUNCT-1K2 h c=TARSKIR1 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> f) & fg =FUNCT-1R1 f *FUNCT-1K3 g) & fh =FUNCT-1R1 f *FUNCT-1K3 h) & fgh =FUNCT-1R1 f *FUNCT-1K3 (g ^FINSEQ-1K8 h) implies fgh =FINSEQ-1R1 fg ^FINSEQ-1K8 fh"
proof-
  have " for f be FinSubsequenceFINSEQ-1M4 holds  for g be FinSequenceFINSEQ-1M1 holds  for h be FinSequenceFINSEQ-1M1 holds  for fg be FinSequenceFINSEQ-1M1 holds  for fh be FinSequenceFINSEQ-1M1 holds  for fgh be FinSequenceFINSEQ-1M1 holds rngFUNCT-1K2 g c=TARSKIR1 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> f & (rngFUNCT-1K2 h c=TARSKIR1 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> f & (fg =FUNCT-1R1 f *FUNCT-1K3 g & (fh =FUNCT-1R1 f *FUNCT-1K3 h & fgh =FUNCT-1R1 f *FUNCT-1K3 (g ^FINSEQ-1K8 h)))) implies fgh =FINSEQ-1R1 fg ^FINSEQ-1K8 fh"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix f assume [ty]: "f be FinSubsequenceFINSEQ-1M4"
    fix g assume [ty]: "g be FinSequenceFINSEQ-1M1"
    fix h assume [ty]: "h be FinSequenceFINSEQ-1M1"
    fix fg assume [ty]: "fg be FinSequenceFINSEQ-1M1"
    fix fh assume [ty]: "fh be FinSequenceFINSEQ-1M1"
    fix fgh assume [ty]: "fgh be FinSequenceFINSEQ-1M1"
    assume A1: "rngFUNCT-1K2 g c=TARSKIR1 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> f"
      and A2: "rngFUNCT-1K2 h c=TARSKIR1 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> f"
      and A3: "fg =FUNCT-1R1 f *FUNCT-1K3 g"
      and A4: "fh =FUNCT-1R1 f *FUNCT-1K3 h"
      and A5: "fgh =FUNCT-1R1 f *FUNCT-1K3 (g ^FINSEQ-1K8 h)"
    have "lenFINSEQ-1K4 fgh =HIDDENR1 lenFINSEQ-1K4 g +NAT-1K1 lenFINSEQ-1K4 h & (lenFINSEQ-1K4 (fg ^FINSEQ-1K8 fh) =XBOOLE-0R4 lenFINSEQ-1K4 g +NAT-1K1 lenFINSEQ-1K4 h & ( for j be NatNAT-1M1 holds j inTARSKIR2 domFINSEQ-1K5 fgh implies fgh .FUNCT-1K1 j =HIDDENR1 (fg ^FINSEQ-1K8 fh).FUNCT-1K1 j))"
    proof(rule conjMI,rule conjMI,rule ballI,rule impI)
      have "rngFUNCT-1K2 (g ^FINSEQ-1K8 h) =XBOOLE-0R4 rngFUNCT-1K2 g \\/XBOOLE-0K2 rngFUNCT-1K2 h"
        using finseq_1_th_31 sorry
      then have "lenFINSEQ-1K4 fgh =HIDDENR1 lenFINSEQ-1K4 (g ^FINSEQ-1K8 h)"
        using A1 A2 A5 finseq_2_th_29 xboole_1_th_8 sorry
      also have "... = lenFINSEQ-1K4 g +NAT-1K1 lenFINSEQ-1K4 h"
        using finseq_1_th_22 sorry
      finally show "lenFINSEQ-1K4 fgh =HIDDENR1 lenFINSEQ-1K4 g +NAT-1K1 lenFINSEQ-1K4 h"
         sorry
      then have A6: "domFINSEQ-1K5 fgh =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 g +NAT-1K1 lenFINSEQ-1K4 h)"
        using finseq_1_def_3 sorry
      have A7: "domFINSEQ-1K5 fh =XBOOLE-0R4 domFINSEQ-1K5 h"
        using A2 A4 relat_1_th_27 sorry
      have A8: "domFINSEQ-1K5 fg =XBOOLE-0R4 domFINSEQ-1K5 g"
        using A1 A3 relat_1_th_27 sorry
      have A9: "lenFINSEQ-1K4 fg =XBOOLE-0R4 lenFINSEQ-1K4 g"
        using A1 A3 finseq_2_th_29 sorry
      have "lenFINSEQ-1K4 fh =XBOOLE-0R4 lenFINSEQ-1K4 h"
        using A2 A4 finseq_2_th_29 sorry
      thus "lenFINSEQ-1K4 (fg ^FINSEQ-1K8 fh) =XBOOLE-0R4 lenFINSEQ-1K4 g +NAT-1K1 lenFINSEQ-1K4 h"
        using A9 finseq_1_th_22 sorry
      fix j assume [ty]: "j be NatNAT-1M1"
      assume A10: "j inTARSKIR2 domFINSEQ-1K5 fgh"
      then have A11: "\<one>\<^sub>M <=XXREAL-0R1 j"
        using A6 finseq_1_th_1 sorry
      have A12: "j <=XXREAL-0R1 lenFINSEQ-1K4 g +NAT-1K1 lenFINSEQ-1K4 h"
        using A6 A10 finseq_1_th_1 sorry
      show "fgh .FUNCT-1K1 j =HIDDENR1 (fg ^FINSEQ-1K8 fh).FUNCT-1K1 j"
      proof-
        have cases: "j <=XXREAL-0R1 lenFINSEQ-1K4 g or lenFINSEQ-1K4 g <XXREAL-0R3 j"
           sorry
        have case1: "j <=XXREAL-0R1 lenFINSEQ-1K4 g implies fgh .FUNCT-1K1 j =HIDDENR1 (fg ^FINSEQ-1K8 fh).FUNCT-1K1 j"
        proof(rule impI)
          assume "j <=XXREAL-0R1 lenFINSEQ-1K4 g"
          then have A13: "j inTARSKIR2 domFINSEQ-1K5 g"
            using A11 finseq_3_th_25 sorry
          have "fgh .FUNCT-1K1 j =HIDDENR1 f .FUNCT-1K1 ((g ^FINSEQ-1K8 h).FUNCT-1K1 j)"
            using A5 A10 funct_1_th_12 sorry
          also have "... = f .FUNCT-1K1 (g .FUNCT-1K1 j)"
            using A13 finseq_1_def_7 sorry
          also have "... = fg .FUNCT-1K1 j"
            using A3 A13 funct_1_th_13 sorry
          also have "... = (fg ^FINSEQ-1K8 fh).FUNCT-1K1 j"
            using A8 A13 finseq_1_def_7 sorry
          finally show "fgh .FUNCT-1K1 j =HIDDENR1 (fg ^FINSEQ-1K8 fh).FUNCT-1K1 j"
             sorry
        qed
        have case2: "lenFINSEQ-1K4 g <XXREAL-0R3 j implies fgh .FUNCT-1K1 j =HIDDENR1 (fg ^FINSEQ-1K8 fh).FUNCT-1K1 j"
        proof(rule impI)
          assume "lenFINSEQ-1K4 g <XXREAL-0R3 j"
          then have "lenFINSEQ-1K4 g +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 j"
            using nat_1_th_13 sorry
          then have A14: "\<one>\<^sub>M <=XXREAL-0R1 j -XCMPLX-0K6 lenFINSEQ-1K4 g"
            using xreal_1_th_19 sorry
          then have "j -'NAT-DK9 lenFINSEQ-1K4 g =XBOOLE-0R4 j -XCMPLX-0K6 lenFINSEQ-1K4 g"
            using xreal_0_def_2 sorry
          then obtain j9 where 
            [ty]:"j9 be ElementSUBSET-1M1-of NATNUMBERSK1" and j9Def:"j9 = j -XCMPLX-0K6 lenFINSEQ-1K4 g"
             sorry
          have A15: "j =XBOOLE-0R4 lenFINSEQ-1K4 g +NAT-1K1 j9"
             sorry
          then have "j9 <=XXREAL-0R1 lenFINSEQ-1K4 h"
            using A12 xreal_1_th_6 sorry
          then have A16: "j9 inTARSKIR2 domFINSEQ-1K5 h"
            using A14 finseq_3_th_25 sorry
          have "fgh .FUNCT-1K1 j =HIDDENR1 f .FUNCT-1K1 ((g ^FINSEQ-1K8 h).FUNCT-1K1 j)"
            using A5 A10 funct_1_th_12 sorry
          also have "... = f .FUNCT-1K1 (h .FUNCT-1K1 j9)"
            using A15 A16 finseq_1_def_7 sorry
          also have "... = fh .FUNCT-1K1 j9"
            using A4 A16 funct_1_th_13 sorry
          also have "... = (fg ^FINSEQ-1K8 fh).FUNCT-1K1 j"
            using A9 A7 A15 A16 finseq_1_def_7 sorry
          finally show "fgh .FUNCT-1K1 j =HIDDENR1 (fg ^FINSEQ-1K8 fh).FUNCT-1K1 j"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus "fgh =FINSEQ-1R1 fg ^FINSEQ-1K8 fh"
      using finseq_2_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve fs, fs1, fs2 for "FinSequenceFINSEQ-1M3-of X"
reserve fss, fss2 for "SubsetSUBSET-1M2-of fs"
mtheorem finseq_6_th_151:
" for X be setHIDDENM2 holds  for fs be FinSequenceFINSEQ-1M3-of X holds  for fss be SubsetSUBSET-1M2-of fs holds domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss c=TARSKIR1 domFINSEQ-1K5 fs & rngFUNCT-1K2 fss c=TARSKIR1 rngFUNCT-1K2 fs"
  using relat_1_th_11 sorry

mtheorem finseq_6_th_152:
" for X be setHIDDENM2 holds  for fs be FinSequenceFINSEQ-1M3-of X holds fs be SubsetSUBSET-1M2-of fs"
proof-
  have " for X be setHIDDENM2 holds  for fs be FinSequenceFINSEQ-1M3-of X holds fs be SubsetSUBSET-1M2-of fs"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix fs assume [ty]: "fs be FinSequenceFINSEQ-1M3-of X"
    have "fs c=RELSET-1R1\<^bsub>(omegaORDINAL1K4,X)\<^esub> fs"
       sorry
    thus "fs be SubsetSUBSET-1M2-of fs"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_153:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for fs be FinSequenceFINSEQ-1M3-of X holds  for fss be SubsetSUBSET-1M2-of fs holds fss  |RELAT-1K8 Y be SubsetSUBSET-1M2-of fs"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for fs be FinSequenceFINSEQ-1M3-of X holds  for fss be SubsetSUBSET-1M2-of fs holds fss  |RELAT-1K8 Y be SubsetSUBSET-1M2-of fs"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix fs assume [ty]: "fs be FinSequenceFINSEQ-1M3-of X"
    fix fss assume [ty]: "fss be SubsetSUBSET-1M2-of fs"
    obtain f where 
      [ty]:"f be FinSubsequenceFINSEQ-1M4" and fDef:"f = fss  |RELAT-1K8 Y"
       sorry
    have "f c=RELAT-1R2 fss"
      using relat_1_th_59 sorry
    thus "fss  |RELAT-1K8 Y be SubsetSUBSET-1M2-of fs"
      using xboole_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_154:
" for X be setHIDDENM2 holds  for fs be FinSequenceFINSEQ-1M3-of X holds  for fs1 be FinSequenceFINSEQ-1M3-of X holds  for fs2 be FinSequenceFINSEQ-1M3-of X holds  for fss be SubsetSUBSET-1M2-of fs holds  for fss2 be SubsetSUBSET-1M2-of fs holds  for fss1 be SubsetSUBSET-1M2-of fs1 holds (SeqFINSEQ-1K16 fss =FINSEQ-1R1 fs1 & SeqFINSEQ-1K16 fss1 =FINSEQ-1R1 fs2) & fss2 =FUNCT-1R1 fss  |RELAT-1K8 rngFUNCT-1K2 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss)  |RELSET-1K5\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss1) implies SeqFINSEQ-1K16 fss2 =FINSEQ-1R1 fs2"
proof-
  have " for X be setHIDDENM2 holds  for fs be FinSequenceFINSEQ-1M3-of X holds  for fs1 be FinSequenceFINSEQ-1M3-of X holds  for fs2 be FinSequenceFINSEQ-1M3-of X holds  for fss be SubsetSUBSET-1M2-of fs holds  for fss2 be SubsetSUBSET-1M2-of fs holds  for fss1 be SubsetSUBSET-1M2-of fs1 holds SeqFINSEQ-1K16 fss =FINSEQ-1R1 fs1 & (SeqFINSEQ-1K16 fss1 =FINSEQ-1R1 fs2 & fss2 =FUNCT-1R1 fss  |RELAT-1K8 rngFUNCT-1K2 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss)  |RELSET-1K5\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss1)) implies SeqFINSEQ-1K16 fss2 =FINSEQ-1R1 fs2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix fs assume [ty]: "fs be FinSequenceFINSEQ-1M3-of X"
    fix fs1 assume [ty]: "fs1 be FinSequenceFINSEQ-1M3-of X"
    fix fs2 assume [ty]: "fs2 be FinSequenceFINSEQ-1M3-of X"
    fix fss assume [ty]: "fss be SubsetSUBSET-1M2-of fs"
    fix fss2 assume [ty]: "fss2 be SubsetSUBSET-1M2-of fs"
    fix fss1 assume [ty]: "fss1 be SubsetSUBSET-1M2-of fs1"
    assume A1: "SeqFINSEQ-1K16 fss =FINSEQ-1R1 fs1"
      and A2: "SeqFINSEQ-1K16 fss1 =FINSEQ-1R1 fs2"
      and A3: "fss2 =FUNCT-1R1 fss  |RELAT-1K8 rngFUNCT-1K2 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss)  |RELSET-1K5\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss1)"
    obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A4: "domFINSEQ-1K5 fs =XBOOLE-0R4 SegFINSEQ-1K2 k"
      using finseq_1_def_2 sorry
    obtain d2 where 
      [ty]:"d2 be finiteFINSET-1V1\<bar>setHIDDENM2" and d2Def:"d2 = domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss2"
       sorry
    obtain d1 where 
      [ty]:"d1 be finiteFINSET-1V1\<bar>setHIDDENM2" and d1Def:"d1 = domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss1"
       sorry
    have A5: " ex l be NatNAT-1M1 st domFINSEQ-1K5 fs1 =XBOOLE-0R4 SegFINSEQ-1K2 l"
      using finseq_1_def_2 sorry
    then have A6: "domFINSEQ-1K5 (SgmFINSEQ-1K15 d1) =XBOOLE-0R4 SegFINSEQ-1K2 (cardCARD-1K4 d1)"
      using finseq_3_th_40 relat_1_th_11 sorry
    have 
      [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    have A7: "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss c=TARSKIR1 SegFINSEQ-1K2 k"
      using A4 relat_1_th_11 sorry
    then have "rngFUNCT-1K2 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss)) c=TARSKIR1 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss"
      using finseq_1_def_13 sorry
    then have A8: "domFINSEQ-1K5 fs1 =XBOOLE-0R4 domFINSEQ-1K5 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss))"
      using A1 relat_1_th_27 sorry
    have "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss2 c=TARSKIR1 SegFINSEQ-1K2 k"
      using A4 relat_1_th_11 sorry
    then have A9: "rngFUNCT-1K2 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss2)) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss2"
      using finseq_1_def_13 sorry
    have A10: "SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss)  |RELSET-1K5\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss1 c=RELSET-1R1\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss)"
      using relat_1_th_59 sorry
    then have A11: "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss)  |RELSET-1K5\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss1) c=TARSKIR1 domFINSEQ-1K5 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss))"
      using relat_1_th_11 sorry
    have "rngFUNCT-1K2 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss)  |RELSET-1K5\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss1) c=TARSKIR1 rngFUNCT-1K2 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss))"
      using A10 relat_1_th_11 sorry
    then have "rngFUNCT-1K2 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss)  |RELSET-1K5\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss1) c=TARSKIR1 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss"
      using A7 finseq_1_def_13 sorry
    then have A12: "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss2 =XBOOLE-0R4 rngFUNCT-1K2 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss)  |RELSET-1K5\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss1)"
      using A3 relat_1_th_62 sorry
    have A13: "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss1 c=TARSKIR1 domFINSEQ-1K5 fs1"
      using relat_1_th_11 sorry
    have " ex Z be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 omegaORDINAL1K4,omegaORDINAL1K4 :]) st ( for x be objectHIDDENM1 holds x inHIDDENR3 d1 implies ( ex y be objectHIDDENM1 st y inHIDDENR3 d2 & [TARSKIK4 x,y ] inHIDDENR3 Z)) & (( for y be objectHIDDENM1 holds y inHIDDENR3 d2 implies ( ex x be objectHIDDENM1 st x inHIDDENR3 d1 & [TARSKIK4 x,y ] inHIDDENR3 Z)) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  for u be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 Z & [TARSKIK4 z,u ] inHIDDENR3 Z implies (x =HIDDENR1 z implies y =HIDDENR1 u) & (y =HIDDENR1 u implies (x <>HIDDENR2 z implies  False ))))"
    proof-
      obtain Z where 
        [ty]:"Z be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 omegaORDINAL1K4,omegaORDINAL1K4 :])" and ZDef:"Z = SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss)  |RELSET-1K5\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss1"
         sorry
      show " ex Z be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 omegaORDINAL1K4,omegaORDINAL1K4 :]) st ( for x be objectHIDDENM1 holds x inHIDDENR3 d1 implies ( ex y be objectHIDDENM1 st y inHIDDENR3 d2 & [TARSKIK4 x,y ] inHIDDENR3 Z)) & (( for y be objectHIDDENM1 holds y inHIDDENR3 d2 implies ( ex x be objectHIDDENM1 st x inHIDDENR3 d1 & [TARSKIK4 x,y ] inHIDDENR3 Z)) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  for u be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 Z & [TARSKIK4 z,u ] inHIDDENR3 Z implies (x =HIDDENR1 z implies y =HIDDENR1 u) & (y =HIDDENR1 u implies (x <>HIDDENR2 z implies  False ))))"
      proof(rule bexI[of _ "Z"],rule conjMI,rule conjMI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule impI,rule impI)
        have A14: "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> Z =XBOOLE-0R4 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss1"
          using A8 relat_1_th_11 relat_1_th_62 sorry
        show " for x be objectHIDDENM1 holds x inHIDDENR3 d1 implies ( ex y be objectHIDDENM1 st y inHIDDENR3 d2 & [TARSKIK4 x,y ] inHIDDENR3 Z)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A15: "x inHIDDENR3 d1"
          obtain y where 
            [ty]:"y be objectHIDDENM1" and yDef:"y = Z .FUNCT-1K1 x"
             sorry
          show " ex y be objectHIDDENM1 st y inHIDDENR3 d2 & [TARSKIK4 x,y ] inHIDDENR3 Z"
          proof(rule bexI[of _ "y"],rule conjMI)
            show "y inHIDDENR3 d2"
              using A12 A14 A15 funct_1_def_3 sorry
            show "[TARSKIK4 x,y ] inHIDDENR3 Z"
              using A14 A15 funct_1_th_1 sorry
          qed "sorry"
        qed "sorry"
        show " for y be objectHIDDENM1 holds y inHIDDENR3 d2 implies ( ex x be objectHIDDENM1 st x inHIDDENR3 d1 & [TARSKIK4 x,y ] inHIDDENR3 Z)"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "y inHIDDENR3 d2"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A16: "x inHIDDENR3 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> Z"and A17: "y =HIDDENR1 Z .FUNCT-1K1 x"
            using A12 funct_1_def_3 sorry
          have 
            [ty]:"x be objectHIDDENM1"
             sorry
          show " ex x be objectHIDDENM1 st x inHIDDENR3 d1 & [TARSKIK4 x,y ] inHIDDENR3 Z"
          proof(rule bexI[of _ "x"])
            show "x inHIDDENR3 d1 & [TARSKIK4 x,y ] inHIDDENR3 Z"
              using A13 A8 A16 A17 funct_1_th_1 relat_1_th_62 sorry
          qed "sorry"
        qed "sorry"
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        fix z assume [ty]: "z be objectHIDDENM1"
        fix u assume [ty]: "u be objectHIDDENM1"
        assume A18: "[TARSKIK4 x,y ] inHIDDENR3 Z"
          and A19: "[TARSKIK4 z,u ] inHIDDENR3 Z"
        have A20: "z inHIDDENR3 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> Z"
          using A19 funct_1_th_1 sorry
        have A21: "u =HIDDENR1 Z .FUNCT-1K1 z"
          using A19 funct_1_th_1 sorry
        have A22: "u =HIDDENR1 SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss) .FUNCT-1K1 z"
          using A20 A21 funct_1_th_47 sorry
        have A23: "y =HIDDENR1 Z .FUNCT-1K1 x"
          using A18 funct_1_th_1 sorry
        thus "x =HIDDENR1 z implies y =HIDDENR1 u"
          using A19 funct_1_th_1 sorry
        have A24: "x inHIDDENR3 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> Z"
          using A18 funct_1_th_1 sorry
        then have A25: "y =HIDDENR1 SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss) .FUNCT-1K1 x"
          using A23 funct_1_th_47 sorry
        assume A26: "y =HIDDENR1 u"
        assume A27: "x <>HIDDENR2 z"
        have 
          [ty]:"x be ElementSUBSET-1M1-of NATNUMBERSK1" and
          [ty]:"z be ElementSUBSET-1M1-of NATNUMBERSK1"
          using A24 A20 sorry
        have A28: "x <=XXREAL-0R1 lenFINSEQ-1K4 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss))"
          using A11 A24 finseq_3_th_25 sorry
        have A29: "z <=XXREAL-0R1 lenFINSEQ-1K4 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss))"
          using A11 A20 finseq_3_th_25 sorry
        have A30: "\<one>\<^sub>M <=XXREAL-0R1 z"
          using A11 A20 finseq_3_th_25 sorry
        have A31: "\<one>\<^sub>M <=XXREAL-0R1 x"
          using A11 A24 finseq_3_th_25 sorry
        show " False "
        proof-
          have cases: "x <XXREAL-0R3 z or z <XXREAL-0R3 x"
            using A27 xxreal_0_th_1 sorry
          have case1: "x <XXREAL-0R3 z implies  False "
          proof(rule impI)
            assume "x <XXREAL-0R3 z"
            thus " False "
              using A7 A25 A22 A26 A31 A29 finseq_1_def_13 sorry
          qed
          have case2: "z <XXREAL-0R3 x implies  False "
          proof(rule impI)
            assume "z <XXREAL-0R3 x"
            thus " False "
              using A7 A25 A22 A26 A28 A30 finseq_1_def_13 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
    qed
    then have "(d1,d2)are-equipotentTARSKIR3"
       sorry
    then have "cardCARD-1K4 d1 =XBOOLE-0R4 cardCARD-1K4 d2"
      using card_1_th_5 sorry
    then have A32: "domFINSEQ-1K5 (SgmFINSEQ-1K15 d2) =XBOOLE-0R4 SegFINSEQ-1K2 (cardCARD-1K4 d1)"
      using A4 finseq_3_th_40 relat_1_th_11 sorry
    have A33: "rngFUNCT-1K2 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss1)) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss1"
      using A13 A5 finseq_1_def_13 sorry
    have "domFINSEQ-1K5 fs2 =XBOOLE-0R4 domFINSEQ-1K5 (SeqFINSEQ-1K16 fss2) & (domFINSEQ-1K5 fs2 =XBOOLE-0R4 domFINSEQ-1K5 fs2 & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 fs2 implies SeqFINSEQ-1K16 fss2 .FUNCT-1K1 k =HIDDENR1 fs2 .FUNCT-1K1 k))"
    proof(rule conjMI,rule conjMI,rule ballI,rule impI)
      have " for x be objectHIDDENM1 holds (x inHIDDENR3 domFINSEQ-1K5 fs2 implies x inHIDDENR3 domFINSEQ-1K5 (SeqFINSEQ-1K16 fss2)) & (x inHIDDENR3 domFINSEQ-1K5 (SeqFINSEQ-1K16 fss2) implies x inHIDDENR3 domFINSEQ-1K5 fs2)"
      proof(rule ballI,rule conjMI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        show "x inHIDDENR3 domFINSEQ-1K5 fs2 implies x inHIDDENR3 domFINSEQ-1K5 (SeqFINSEQ-1K16 fss2)"
        proof(rule impI)
          assume "x inHIDDENR3 domFINSEQ-1K5 fs2"
          then have A34: "x inHIDDENR3 domFINSEQ-1K5 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss2))"
            using A2 A6 A32 funct_1_th_11 sorry
          then have "SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss2) .FUNCT-1K1 x inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss2"
            using A9 funct_1_def_3 sorry
          thus "x inHIDDENR3 domFINSEQ-1K5 (SeqFINSEQ-1K16 fss2)"
            using A34 funct_1_th_11 sorry
        qed
        assume "x inHIDDENR3 domFINSEQ-1K5 (SeqFINSEQ-1K16 fss2)"
        then have A35: "x inHIDDENR3 domFINSEQ-1K5 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss1))"
          using A6 A32 funct_1_th_11 sorry
        then have "SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss1) .FUNCT-1K1 x inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss1"
          using A33 funct_1_def_3 sorry
        thus "x inHIDDENR3 domFINSEQ-1K5 fs2"
          using A2 A35 funct_1_th_11 sorry
      qed "sorry"
      thus A36: "domFINSEQ-1K5 fs2 =XBOOLE-0R4 domFINSEQ-1K5 (SeqFINSEQ-1K16 fss2)"
        using tarski_th_2 sorry
      show "domFINSEQ-1K5 fs2 =XBOOLE-0R4 domFINSEQ-1K5 fs2"
         sorry
      fix k assume [ty]: "k be NatNAT-1M1"
      assume A37: "k inTARSKIR2 domFINSEQ-1K5 fs2"
      then have A38: "SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss1) .FUNCT-1K1 k inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss1"
        using A2 funct_1_th_11 sorry
      have A39: "SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss2) .FUNCT-1K1 k inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss2"
        using A36 A37 funct_1_th_11 sorry
      have A40: "SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss1) .FUNCT-1K1 k inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss1"
        using A2 A37 funct_1_th_11 sorry
      then have A41: "fss1 .FUNCT-1K1 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss1) .FUNCT-1K1 k) =XBOOLE-0R4 SeqFINSEQ-1K16 fss .FUNCT-1K1 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss1) .FUNCT-1K1 k)"
        using A1 grfunc_1_th_2 sorry
      have A42: "SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss2) .FUNCT-1K1 k =XBOOLE-0R4 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss) *FUNCT-1K3 SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss1)).FUNCT-1K1 k"
        using A7 A12 A8 finseq_6_th_129 relat_1_th_11 sorry
      have "k inTARSKIR2 domFINSEQ-1K5 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss1))"
        using A2 A37 funct_1_th_11 sorry
      then have "k inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss) *FUNCT-1K3 SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss1))"
        using A13 A8 A38 funct_1_th_11 sorry
      then have A43: "SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss2) .FUNCT-1K1 k =XBOOLE-0R4 SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss) .FUNCT-1K1 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss1) .FUNCT-1K1 k)"
        using A42 funct_1_th_12 sorry
      have A44: "fss2 c=RELAT-1R2 fss"
        using A3 relat_1_th_59 sorry
      have "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss1 c=TARSKIR1 domFINSEQ-1K5 (SeqFINSEQ-1K16 fss)"
        using A1 relat_1_th_11 sorry
      then have A45: "SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss1) .FUNCT-1K1 k inTARSKIR2 domFINSEQ-1K5 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss))"
        using A40 funct_1_th_11 sorry
      have "SeqFINSEQ-1K16 fss2 .FUNCT-1K1 k =HIDDENR1 fss2 .FUNCT-1K1 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss2) .FUNCT-1K1 k)"
        using A36 A37 funct_1_th_12 sorry
      also have "... = fss .FUNCT-1K1 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss) .FUNCT-1K1 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss1) .FUNCT-1K1 k))"
        using A43 A44 A39 grfunc_1_th_2 sorry
      also have "... = fss1 .FUNCT-1K1 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss1) .FUNCT-1K1 k)"
        using A45 A41 funct_1_th_13 sorry
      also have "... = fs2 .FUNCT-1K1 k"
        using A2 A37 funct_1_th_12 sorry
      finally show "SeqFINSEQ-1K16 fss2 .FUNCT-1K1 k =HIDDENR1 fs2 .FUNCT-1K1 k"
         sorry
    qed "sorry"
    thus "SeqFINSEQ-1K16 fss2 =FINSEQ-1R1 fs2"
      using finseq_1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem finseq_6_th_155:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be  non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M3-of D holds  for f2 be FinSequenceFINSEQ-1M3-of D holds (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be  non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M3-of D holds  for f2 be FinSequenceFINSEQ-1M3-of D holds (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =HIDDENR1 f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be  non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M3-of D"
    fix f2 assume [ty]: "f2 be FinSequenceFINSEQ-1M3-of D"
    have A1: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f1"
      using finseq_5_th_6 sorry
    have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> ((\<two>\<^sub>M,lenFINSEQ-1K4 f2)-cutFINSEQ-6K5\<^bsub>(D)\<^esub> f2))"
      using finseq_5_th_6 sorry
    then have "(f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =HIDDENR1 (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> ((\<two>\<^sub>M,lenFINSEQ-1K4 f2)-cutFINSEQ-6K5\<^bsub>(D)\<^esub> f2)).FUNCT-1K1 \<one>\<^sub>M"
      using partfun1_def_6 sorry
    also have "... = f1 .FUNCT-1K1 \<one>\<^sub>M"
      using A1 finseq_1_def_7 sorry
    also have "... = f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
      using A1 partfun1_def_6 sorry
    finally show "(f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =HIDDENR1 f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_156:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be FinSequenceFINSEQ-1M3-of D holds  for f2 be  non trivialZFMISC-1V1\<bar>FinSequenceFINSEQ-1M3-of D holds (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2)/.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2) =XBOOLE-0R4 f2 /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f2"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be FinSequenceFINSEQ-1M3-of D holds  for f2 be  non trivialZFMISC-1V1\<bar>FinSequenceFINSEQ-1M3-of D holds (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2)/.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2) =HIDDENR1 f2 /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f2"
  proof(rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be FinSequenceFINSEQ-1M3-of D"
    fix f2 assume [ty]: "f2 be  non trivialZFMISC-1V1\<bar>FinSequenceFINSEQ-1M3-of D"
    have A1: "lenFINSEQ-1K4 (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2) +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 f1 +NAT-1K1 lenFINSEQ-1K4 f2"
      using finseq_6_th_139 sorry
    have "\<two>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f2"
      using nat_d_th_60 sorry
    then have A2: "\<one>\<^sub>M <XXREAL-0R3 lenFINSEQ-1K4 f2"
      using xxreal_0_th_2 sorry
    then have "\<one>\<^sub>M +NAT-1K1 0NUMBERSK6 <XXREAL-0R3 lenFINSEQ-1K4 f1 +NAT-1K1 lenFINSEQ-1K4 f2"
      using xreal_1_th_8 sorry
    then have "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2)"
      using A1 nat_1_th_13 sorry
    then have "(f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2)/.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2) =HIDDENR1 (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2).FUNCT-1K1 lenFINSEQ-1K4 (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2)"
      using finseq_4_th_15 sorry
    also have "... = f2 .FUNCT-1K1 lenFINSEQ-1K4 f2"
      using A2 finseq_6_th_142 sorry
    also have "... = f2 /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f2"
      using A2 finseq_4_th_15 sorry
    finally show "(f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2)/.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2) =HIDDENR1 f2 /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_157:
" for f be FinSequenceFINSEQ-1M1 holds f ^'FINSEQ-6K6 {}XBOOLE-0K1 =FINSEQ-1R1 f"
proof-
  have " for f be FinSequenceFINSEQ-1M1 holds f ^'FINSEQ-6K6 {}XBOOLE-0K1 =HIDDENR1 f"
  proof(rule ballI)
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
    have "f ^'FINSEQ-6K6 {}XBOOLE-0K1 =HIDDENR1 f ^FINSEQ-1K8 {}XBOOLE-0K1"
      using finseq_6_def_4 sorry
    also have "... = f"
      using finseq_1_th_34 sorry
    finally show "f ^'FINSEQ-6K6 {}XBOOLE-0K1 =HIDDENR1 f"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_158:
" for x be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M1 holds f ^'FINSEQ-6K6 (<*FINSEQ-1K10 x*>) =FINSEQ-1R1 f"
proof-
  have " for x be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M1 holds f ^'FINSEQ-6K6 (<*FINSEQ-1K10 x*>) =FINSEQ-1R1 f"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
    have "lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>) =XBOOLE-0R4 \<one>\<^sub>M"
      using finseq_1_th_39 sorry
    then have "(\<two>\<^sub>M,lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>))-cutFINSEQ-6K4 (<*FINSEQ-1K10 x*>) =FINSEQ-1R1 {}XBOOLE-0K1"
      using finseq_6_def_4 sorry
    thus "f ^'FINSEQ-6K6 (<*FINSEQ-1K10 x*>) =FINSEQ-1R1 f"
      using finseq_1_th_34 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_159:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for n be NatNAT-1M1 holds  for f1 be FinSequenceFINSEQ-1M3-of D holds  for f2 be FinSequenceFINSEQ-1M3-of D holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 f1 implies (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2)/.PARTFUN1K7\<^bsub>(D)\<^esub> n =XBOOLE-0R4 f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> n"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for n be NatNAT-1M1 holds  for f1 be FinSequenceFINSEQ-1M3-of D holds  for f2 be FinSequenceFINSEQ-1M3-of D holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 f1 implies (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2)/.PARTFUN1K7\<^bsub>(D)\<^esub> n =XBOOLE-0R4 f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> n"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix f1 assume [ty]: "f1 be FinSequenceFINSEQ-1M3-of D"
    fix f2 assume [ty]: "f2 be FinSequenceFINSEQ-1M3-of D"
    assume A1: "\<one>\<^sub>M <=XXREAL-0R1 n"
      and A2: "n <=XXREAL-0R1 lenFINSEQ-1K4 f1"
    show "(f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2)/.PARTFUN1K7\<^bsub>(D)\<^esub> n =XBOOLE-0R4 f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> n"
    proof-
      have cases: "f2 =FINSEQ-1R1 {}XBOOLE-0K1 or f2 <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "f2 =FINSEQ-1R1 {}XBOOLE-0K1 implies (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2)/.PARTFUN1K7\<^bsub>(D)\<^esub> n =XBOOLE-0R4 f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> n"
      proof(rule impI)
        assume "f2 =FINSEQ-1R1 {}XBOOLE-0K1"
        thus "(f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2)/.PARTFUN1K7\<^bsub>(D)\<^esub> n =XBOOLE-0R4 f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> n"
          using finseq_6_th_157 sorry
      qed
      have case2: "f2 <>HIDDENR2 {}XBOOLE-0K1 implies (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2)/.PARTFUN1K7\<^bsub>(D)\<^esub> n =HIDDENR1 f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> n"
      proof(rule impI)
        assume A3: "f2 <>HIDDENR2 {}XBOOLE-0K1"
        then have A4: "lenFINSEQ-1K4 f1 +NAT-1K1 0NUMBERSK6 <XXREAL-0R3 lenFINSEQ-1K4 f1 +NAT-1K1 lenFINSEQ-1K4 f2"
          using xreal_1_th_6 sorry
        have "lenFINSEQ-1K4 (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2) +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 f1 +NAT-1K1 lenFINSEQ-1K4 f2"
          using A3 finseq_6_th_139 sorry
        then have "n <XXREAL-0R3 lenFINSEQ-1K4 (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2) +NAT-1K1 \<one>\<^sub>M"
          using A2 A4 xxreal_0_th_2 sorry
        then have "n <=XXREAL-0R1 lenFINSEQ-1K4 (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2)"
          using nat_1_th_13 sorry
        then have "(f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2)/.PARTFUN1K7\<^bsub>(D)\<^esub> n =HIDDENR1 (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2).FUNCT-1K1 n"
          using A1 finseq_4_th_15 sorry
        also have "... = f1 .FUNCT-1K1 n"
          using A1 A2 finseq_6_th_140 sorry
        also have "... = f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> n"
          using A1 A2 finseq_4_th_15 sorry
        finally show "(f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2)/.PARTFUN1K7\<^bsub>(D)\<^esub> n =HIDDENR1 f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> n"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_160:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for n be NatNAT-1M1 holds  for f1 be FinSequenceFINSEQ-1M3-of D holds  for f2 be FinSequenceFINSEQ-1M3-of D holds \<one>\<^sub>M <=XXREAL-0R1 n & n <XXREAL-0R3 lenFINSEQ-1K4 f2 implies (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2)/.PARTFUN1K7\<^bsub>(D)\<^esub> (lenFINSEQ-1K4 f1 +XCMPLX-0K2 n) =XBOOLE-0R4 f2 /.PARTFUN1K7\<^bsub>(D)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for n be NatNAT-1M1 holds  for f1 be FinSequenceFINSEQ-1M3-of D holds  for f2 be FinSequenceFINSEQ-1M3-of D holds \<one>\<^sub>M <=XXREAL-0R1 n & n <XXREAL-0R3 lenFINSEQ-1K4 f2 implies (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2)/.PARTFUN1K7\<^bsub>(D)\<^esub> (lenFINSEQ-1K4 f1 +XCMPLX-0K2 n) =HIDDENR1 f2 /.PARTFUN1K7\<^bsub>(D)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix f1 assume [ty]: "f1 be FinSequenceFINSEQ-1M3-of D"
    fix f2 assume [ty]: "f2 be FinSequenceFINSEQ-1M3-of D"
    assume A1: "\<one>\<^sub>M <=XXREAL-0R1 n"
      and A2: "n <XXREAL-0R3 lenFINSEQ-1K4 f2"
    have A3: "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f2"
      using A2 nat_1_th_13 sorry
    have A4: "lenFINSEQ-1K4 f1 +XCMPLX-0K2 n <=XXREAL-0R1 lenFINSEQ-1K4 (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2)"
    proof-
      show "lenFINSEQ-1K4 f1 +XCMPLX-0K2 n <=XXREAL-0R1 lenFINSEQ-1K4 (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2)"
      proof-
        have cases: "f2 <>HIDDENR2 {}XBOOLE-0K1 or f2 =FINSEQ-1R1 {}XBOOLE-0K1"
           sorry
        have case1: "f2 <>HIDDENR2 {}XBOOLE-0K1 implies lenFINSEQ-1K4 f1 +XCMPLX-0K2 n <=XXREAL-0R1 lenFINSEQ-1K4 (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2)"
        proof(rule impI)
          assume A5: "f2 <>HIDDENR2 {}XBOOLE-0K1"
          have A6: "lenFINSEQ-1K4 f1 +XCMPLX-0K2 n <XXREAL-0R3 lenFINSEQ-1K4 f1 +NAT-1K1 lenFINSEQ-1K4 f2"
            using A2 xreal_1_th_6 sorry
          have "lenFINSEQ-1K4 (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2) +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 f1 +NAT-1K1 lenFINSEQ-1K4 f2"
            using A5 finseq_6_th_139 sorry
          thus "lenFINSEQ-1K4 f1 +XCMPLX-0K2 n <=XXREAL-0R1 lenFINSEQ-1K4 (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2)"
            using A6 nat_1_th_13 sorry
        qed
        have case2: "f2 =FINSEQ-1R1 {}XBOOLE-0K1 implies lenFINSEQ-1K4 f1 +XCMPLX-0K2 n <=XXREAL-0R1 lenFINSEQ-1K4 (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2)"
        proof(rule impI)
          assume "f2 =FINSEQ-1R1 {}XBOOLE-0K1"
          thus "lenFINSEQ-1K4 f1 +XCMPLX-0K2 n <=XXREAL-0R1 lenFINSEQ-1K4 (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2)"
            using A2 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    have A7: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
      using xreal_1_th_6 sorry
    have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f1 +XCMPLX-0K2 n"
      using A1 xreal_1_th_7 sorry
    then have "(f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2)/.PARTFUN1K7\<^bsub>(D)\<^esub> (lenFINSEQ-1K4 f1 +XCMPLX-0K2 n) =HIDDENR1 (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2).FUNCT-1K1 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 n)"
      using A4 finseq_4_th_15 sorry
    also have "... = f2 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
      using A1 A2 finseq_6_th_141 sorry
    also have "... = f2 /.PARTFUN1K7\<^bsub>(D)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
      using A7 A3 finseq_4_th_15 sorry
    finally show "(f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2)/.PARTFUN1K7\<^bsub>(D)\<^esub> (lenFINSEQ-1K4 f1 +XCMPLX-0K2 n) =HIDDENR1 f2 /.PARTFUN1K7\<^bsub>(D)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef finseq_6_def_8 ("min-atFINSEQ-6K8'( _ , _ , _ ')" [0,0,0]164 ) where
  mlet "F be FinSequenceFINSEQ-1M3-of INTINT-1K1", "m be NatNAT-1M1", "n be NatNAT-1M1"
"assume \<one>\<^sub>M <=XXREAL-0R1 m & (m <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 F) func min-atFINSEQ-6K8(F,m,n) \<rightarrow> NatNAT-1M1 means
  \<lambda>it.  ex X be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of INTINT-1K1 st X =XBOOLE-0R4 rngFUNCT-1K2 ((m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F) & it +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 minXXREAL-2K5 X ..FINSEQ-4K4 ((m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F) +XCMPLX-0K2 m"
proof-
  (*existence*)
    show "\<one>\<^sub>M <=XXREAL-0R1 m & (m <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 F) implies ( ex it be NatNAT-1M1 st  ex X be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of INTINT-1K1 st X =XBOOLE-0R4 rngFUNCT-1K2 ((m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F) & it +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 minXXREAL-2K5 X ..FINSEQ-4K4 ((m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F) +XCMPLX-0K2 m)"
    proof(rule impI)
      assume Assume: "\<one>\<^sub>M <=XXREAL-0R1 m & (m <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 F)"
      have A1: "\<one>\<^sub>M <=XXREAL-0R1 m"
        using Assume sorry
      have A2: "m <=XXREAL-0R1 n"
        using Assume sorry
      have A3: "n <=XXREAL-0R1 lenFINSEQ-1K4 F"
        using Assume sorry
      show " ex it be NatNAT-1M1 st  ex X be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of INTINT-1K1 st X =XBOOLE-0R4 rngFUNCT-1K2 ((m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F) & it +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 minXXREAL-2K5 X ..FINSEQ-4K4 ((m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F) +XCMPLX-0K2 m"
      proof-
        have " ex tVar11 be NatNAT-1M1 st  ex tVar12 be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>SubsetSUBSET-1M2-of INTINT-1K1 st tVar12 =XBOOLE-0R4 rngFUNCT-1K2 ((m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F) & tVar11 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 minXXREAL-2K5 tVar12 ..FINSEQ-4K4 ((m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F) +XCMPLX-0K2 m"
        proof-
          let ?Cut = "(m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F"
          let ?X = "rngFUNCT-1K2 ?Cut"
          have "m <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
            using A2 nat_1_th_13 sorry
          then have A4: "m -XCMPLX-0K6 m <XXREAL-0R3 (n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 m"
            using xreal_1_th_9 sorry
          have "lenFINSEQ-1K4 ?Cut +XCMPLX-0K2 m =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
            using A1 A2 A3 finseq_6_def_4 sorry
          then have A5: "?Cut be  non emptyXBOOLE-0V1"
            using A4 sorry
          have "rngRELSET-1K2\<^bsub>(INTINT-1K1)\<^esub> ?Cut be SubsetSUBSET-1M2-of INTINT-1K1"
             sorry
          then obtain X where 
            [ty]:"X be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of INTINT-1K1" and XDef:"X = ?X"
            using A5 sorry
          let ?q = "(minXXREAL-2K5 X ..FINSEQ-4K4 ?Cut +XCMPLX-0K2 m)-XCMPLX-0K6 \<one>\<^sub>M"
          have "\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 m -XCMPLX-0K6 \<one>\<^sub>M"
            using A1 xreal_1_th_9 sorry
          then have "0NUMBERSK6 +NAT-1K1 0NUMBERSK6 <=XXREAL-0R1 minXXREAL-2K5 X ..FINSEQ-4K4 ?Cut +XCMPLX-0K2 (m -XCMPLX-0K6 \<one>\<^sub>M)"
             sorry
          then obtain q where 
            [ty]:"q be ElementSUBSET-1M1-of NATNUMBERSK1" and qDef:"q = ?q"
            using int_1_th_3 sorry
          show " ex tVar11 be NatNAT-1M1 st  ex tVar12 be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>SubsetSUBSET-1M2-of INTINT-1K1 st tVar12 =XBOOLE-0R4 rngFUNCT-1K2 ((m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F) & tVar11 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 minXXREAL-2K5 tVar12 ..FINSEQ-4K4 ((m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F) +XCMPLX-0K2 m"
          proof(rule bexI[of _ "q"])
            show " ex tVar12 be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>SubsetSUBSET-1M2-of INTINT-1K1 st tVar12 =XBOOLE-0R4 rngFUNCT-1K2 ((m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F) & q +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 minXXREAL-2K5 tVar12 ..FINSEQ-4K4 ((m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F) +XCMPLX-0K2 m"
            proof(rule bexI[of _ "X"],rule conjMI)
              show "X =XBOOLE-0R4 rngFUNCT-1K2 ((m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F)"
                 sorry
              show "q +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 minXXREAL-2K5 X ..FINSEQ-4K4 ((m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F) +XCMPLX-0K2 m"
                 sorry
            qed "sorry"
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show "\<one>\<^sub>M <=XXREAL-0R1 m & (m <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 F) implies ( for it1 be NatNAT-1M1 holds  for it2 be NatNAT-1M1 holds ( ex X be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of INTINT-1K1 st X =XBOOLE-0R4 rngFUNCT-1K2 ((m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F) & it1 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 minXXREAL-2K5 X ..FINSEQ-4K4 ((m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F) +XCMPLX-0K2 m) & ( ex X be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of INTINT-1K1 st X =XBOOLE-0R4 rngFUNCT-1K2 ((m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F) & it2 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 minXXREAL-2K5 X ..FINSEQ-4K4 ((m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F) +XCMPLX-0K2 m) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "\<one>\<^sub>M <=XXREAL-0R1 m & (m <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 F)"
      have A1: "\<one>\<^sub>M <=XXREAL-0R1 m"
        using Assume sorry
      have A2: "m <=XXREAL-0R1 n"
        using Assume sorry
      have A3: "n <=XXREAL-0R1 lenFINSEQ-1K4 F"
        using Assume sorry
      show " for it1 be NatNAT-1M1 holds  for it2 be NatNAT-1M1 holds ( ex X be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of INTINT-1K1 st X =XBOOLE-0R4 rngFUNCT-1K2 ((m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F) & it1 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 minXXREAL-2K5 X ..FINSEQ-4K4 ((m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F) +XCMPLX-0K2 m) & ( ex X be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of INTINT-1K1 st X =XBOOLE-0R4 rngFUNCT-1K2 ((m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F) & it2 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 minXXREAL-2K5 X ..FINSEQ-4K4 ((m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F) +XCMPLX-0K2 m) implies it1 =HIDDENR1 it2"
         sorry
    qed
qed "sorry"

reserve F, F1 for "FinSequenceFINSEQ-1M3-of INTINT-1K1"
reserve k, m, n, ma for "NatNAT-1M1"
mtheorem finseq_6_th_161:
" for F be FinSequenceFINSEQ-1M3-of INTINT-1K1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for ma be NatNAT-1M1 holds (\<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 n) & n <=XXREAL-0R1 lenFINSEQ-1K4 F implies (ma =XBOOLE-0R4 min-atFINSEQ-6K8(F,m,n) iff ((m <=XXREAL-0R1 ma & ma <=XXREAL-0R1 n) & ( for i be NatNAT-1M1 holds m <=XXREAL-0R1 i & i <=XXREAL-0R1 n implies F .FUNCT-1K1 ma <=XXREAL-0R1 F .FUNCT-1K1 i)) & ( for i be NatNAT-1M1 holds m <=XXREAL-0R1 i & i <XXREAL-0R3 ma implies F .FUNCT-1K1 ma <XXREAL-0R3 F .FUNCT-1K1 i))"
proof-
  have " for F be FinSequenceFINSEQ-1M3-of INTINT-1K1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for ma be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & (m <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 F) implies (ma =XBOOLE-0R4 min-atFINSEQ-6K8(F,m,n) implies (m <=XXREAL-0R1 ma & ma <=XXREAL-0R1 n) & (( for i be NatNAT-1M1 holds m <=XXREAL-0R1 i & i <=XXREAL-0R1 n implies F .FUNCT-1K1 ma <=XXREAL-0R1 F .FUNCT-1K1 i) & ( for i be NatNAT-1M1 holds m <=XXREAL-0R1 i & i <XXREAL-0R3 ma implies F .FUNCT-1K1 ma <XXREAL-0R3 F .FUNCT-1K1 i))) & (m <=XXREAL-0R1 ma & (ma <=XXREAL-0R1 n & (( for i be NatNAT-1M1 holds m <=XXREAL-0R1 i & i <=XXREAL-0R1 n implies F .FUNCT-1K1 ma <=XXREAL-0R1 F .FUNCT-1K1 i) & ( for i be NatNAT-1M1 holds m <=XXREAL-0R1 i & i <XXREAL-0R3 ma implies F .FUNCT-1K1 ma <XXREAL-0R3 F .FUNCT-1K1 i))) implies ma =XBOOLE-0R4 min-atFINSEQ-6K8(F,m,n))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix F assume [ty]: "F be FinSequenceFINSEQ-1M3-of INTINT-1K1"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix ma assume [ty]: "ma be NatNAT-1M1"
    assume A1: "\<one>\<^sub>M <=XXREAL-0R1 m"
      and A2: "m <=XXREAL-0R1 n"
      and A3: "n <=XXREAL-0R1 lenFINSEQ-1K4 F"
    let ?Cut = "(m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F"
    have A4: "lenFINSEQ-1K4 ?Cut +XCMPLX-0K2 m =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
      using A1 A2 A3 finseq_6_def_4 sorry
    show "ma =XBOOLE-0R4 min-atFINSEQ-6K8(F,m,n) implies (m <=XXREAL-0R1 ma & ma <=XXREAL-0R1 n) & (( for i be NatNAT-1M1 holds m <=XXREAL-0R1 i & i <=XXREAL-0R1 n implies F .FUNCT-1K1 ma <=XXREAL-0R1 F .FUNCT-1K1 i) & ( for i be NatNAT-1M1 holds m <=XXREAL-0R1 i & i <XXREAL-0R3 ma implies F .FUNCT-1K1 ma <XXREAL-0R3 F .FUNCT-1K1 i))"
    proof(rule impI,rule conjMI,rule conjMI,rule ballI,rule impMI ,rule impI)
      have A5: "n -XCMPLX-0K6 m <XXREAL-0R3 (n -XCMPLX-0K6 m)+XCMPLX-0K2 \<one>\<^sub>M"
        using xreal_1_th_29 sorry
      assume "ma =XBOOLE-0R4 min-atFINSEQ-6K8(F,m,n)"
      then obtain X where
        [ty]:"X be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of INTINT-1K1" and 
        A6: "X =XBOOLE-0R4 rngFUNCT-1K2 ?Cut"and A7: "ma +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 minXXREAL-2K5 X ..FINSEQ-4K4 ?Cut +XCMPLX-0K2 m"
        using A1 A2 A3 finseq_6_def_8 sorry
      have A8: "ma =XBOOLE-0R4 (minXXREAL-2K5 X ..FINSEQ-4K4 ?Cut -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 m"
        using A7 sorry
      have A9: "ma =XBOOLE-0R4 (minXXREAL-2K5 X ..FINSEQ-4K4 ?Cut +XCMPLX-0K2 m)-XCMPLX-0K6 \<one>\<^sub>M"
        using A7 sorry
      have A10: "minXXREAL-2K5 X inHIDDENR3 X"
        using xxreal_2_def_7 sorry
      then have A11: "\<one>\<^sub>M <=XXREAL-0R1 minXXREAL-2K5 X ..FINSEQ-4K4 ?Cut"
        using A6 finseq_4_th_21 sorry
      then have "\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 minXXREAL-2K5 X ..FINSEQ-4K4 ?Cut -XCMPLX-0K6 \<one>\<^sub>M"
        using xreal_1_th_9 sorry
      then obtain i1 where 
        [ty]:"i1 be ElementSUBSET-1M1-of NATNUMBERSK1" and i1Def:"i1 = minXXREAL-2K5 X ..FINSEQ-4K4 ?Cut -XCMPLX-0K6 \<one>\<^sub>M"
        using int_1_th_3 sorry
      have A12: "minXXREAL-2K5 X ..FINSEQ-4K4 ?Cut <=XXREAL-0R1 lenFINSEQ-1K4 ?Cut"
        using A6 A10 finseq_4_th_21 sorry
      then have "i1 <XXREAL-0R3 lenFINSEQ-1K4 ?Cut"
        using xreal_1_th_146 xxreal_0_th_2 sorry
      then have A13: "F .FUNCT-1K1 ma =HIDDENR1 ?Cut .FUNCT-1K1 (i1 +NAT-1K1 \<one>\<^sub>M)"
        using A1 A2 A3 A8 finseq_6_def_4 sorry
      also have "... = ?Cut .FUNCT-1K1 ((ma +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 m)"
        using A7 sorry
      finally have "F .FUNCT-1K1 ma =HIDDENR1 ?Cut .FUNCT-1K1 ((ma +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 m)"
         sorry
      have "minXXREAL-2K5 X ..FINSEQ-4K4 ?Cut +XCMPLX-0K2 m <=XXREAL-0R1 lenFINSEQ-1K4 ?Cut +XCMPLX-0K2 m"
        using A12 xreal_1_th_6 sorry
      then have A14: "ma <=XXREAL-0R1 (lenFINSEQ-1K4 ?Cut +XCMPLX-0K2 m)-XCMPLX-0K6 \<one>\<^sub>M"
        using A9 xreal_1_th_9 sorry
      have "m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 minXXREAL-2K5 X ..FINSEQ-4K4 ?Cut +XCMPLX-0K2 m"
        using A11 xreal_1_th_6 sorry
      then have "(m +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 ma"
        using A9 xreal_1_th_9 sorry
      thus "m <=XXREAL-0R1 ma & ma <=XXREAL-0R1 n"
        using A4 A14 sorry
      have A15: "?Cut .FUNCT-1K1 (minXXREAL-2K5 X ..FINSEQ-4K4 ?Cut) =HIDDENR1 minXXREAL-2K5 X"
        using A6 A10 finseq_4_th_19 sorry
      show A16: " for i be NatNAT-1M1 holds m <=XXREAL-0R1 i & i <=XXREAL-0R1 n implies F .FUNCT-1K1 ma <=XXREAL-0R1 F .FUNCT-1K1 i"
      proof(rule ballI,rule impMI ,rule impI)
        fix i assume [ty]: "i be NatNAT-1M1"
        assume A17: "m <=XXREAL-0R1 i"
          and A18: "i <=XXREAL-0R1 n"
        have "m -XCMPLX-0K6 m <=XXREAL-0R1 i -XCMPLX-0K6 m"
          using A17 xreal_1_th_9 sorry
        then obtain i1 where 
          [ty]:"i1 be ElementSUBSET-1M1-of NATNUMBERSK1" and i1Def:"i1 = i -XCMPLX-0K6 m"
          using int_1_th_3 sorry
        have A19: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i1 +NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_6 sorry
        have A20: "n -XCMPLX-0K6 m <XXREAL-0R3 (n -XCMPLX-0K6 m)+XCMPLX-0K2 \<one>\<^sub>M"
          using xreal_1_th_29 sorry
        have "i1 <=XXREAL-0R1 n -XCMPLX-0K6 m"
          using A18 xreal_1_th_9 sorry
        then have A21: "i1 <XXREAL-0R3 lenFINSEQ-1K4 ?Cut"
          using A4 A20 xxreal_0_th_2 sorry
        then have "i1 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 ?Cut"
          using nat_1_th_13 sorry
        then have A22: "i1 +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ?Cut"
          using A19 finseq_3_th_25 sorry
        have "?Cut .FUNCT-1K1 (i1 +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 F .FUNCT-1K1 (m +NAT-1K1 i1)"
          using A1 A2 A3 A21 finseq_6_def_4 sorry
        then have "F .FUNCT-1K1 i inTARSKIR2 rngFUNCT-1K2 ?Cut"
          using A22 funct_1_def_3 sorry
        thus "F .FUNCT-1K1 ma <=XXREAL-0R1 F .FUNCT-1K1 i"
          using A6 A7 A13 A15 xxreal_2_def_7 sorry
      qed "sorry"
      fix i assume [ty]: "i be NatNAT-1M1"
      assume A23: "m <=XXREAL-0R1 i"
        and A24: "i <XXREAL-0R3 ma"
      have A25: "i <=XXREAL-0R1 n"
        using A4 A14 A24 xxreal_0_th_2 sorry
      then have A26: "F .FUNCT-1K1 ma <=XXREAL-0R1 F .FUNCT-1K1 i"
        using A16 A23 sorry
      have "m -XCMPLX-0K6 m <=XXREAL-0R1 i -XCMPLX-0K6 m"
        using A23 xreal_1_th_9 sorry
      then obtain i1 where 
        [ty]:"i1 be ElementSUBSET-1M1-of NATNUMBERSK1" and i1Def:"i1 = i -XCMPLX-0K6 m"
        using int_1_th_3 sorry
      obtain k where 
        [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = i1 +NAT-1K1 \<one>\<^sub>M"
         sorry
      have "i <=XXREAL-0R1 (lenFINSEQ-1K4 ?Cut -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 m"
        using A14 A24 xxreal_0_th_2 sorry
      then have "i -XCMPLX-0K6 m <=XXREAL-0R1 lenFINSEQ-1K4 ?Cut -XCMPLX-0K6 \<one>\<^sub>M"
        using xreal_1_th_20 sorry
      then have A27: "k <=XXREAL-0R1 lenFINSEQ-1K4 ?Cut"
        using xreal_1_th_19 sorry
      have "i1 <=XXREAL-0R1 n -XCMPLX-0K6 m"
        using A25 xreal_1_th_9 sorry
      then have A28: "i1 <XXREAL-0R3 lenFINSEQ-1K4 ?Cut"
        using A4 A5 xxreal_0_th_2 sorry
      have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k"
        using xreal_1_th_6 sorry
      then have A29: "k inTARSKIR2 domFINSEQ-1K5 ?Cut"
        using A27 finseq_3_th_25 sorry
      have "i -XCMPLX-0K6 m <XXREAL-0R3 ma -XCMPLX-0K6 m"
        using A24 xreal_1_th_9 sorry
      then have A30: "k <XXREAL-0R3 (ma -XCMPLX-0K6 m)+XCMPLX-0K2 \<one>\<^sub>M"
        using xreal_1_th_6 sorry
      have "F .FUNCT-1K1 i =HIDDENR1 F .FUNCT-1K1 (i1 +XCMPLX-0K2 m)"
         sorry
      also have "... = ?Cut .FUNCT-1K1 k"
        using A1 A2 A3 A28 finseq_6_def_4 sorry
      finally have "F .FUNCT-1K1 i =HIDDENR1 ?Cut .FUNCT-1K1 k"
         sorry
      then have "F .FUNCT-1K1 i <>HIDDENR2 F .FUNCT-1K1 ma"
        using A6 A7 A10 A13 A30 A29 finseq_4_th_19 finseq_4_th_24 sorry
      thus "F .FUNCT-1K1 ma <XXREAL-0R3 F .FUNCT-1K1 i"
        using A26 xxreal_0_th_1 sorry
    qed "sorry"
    let ?Cut = "(m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F"
    have A31: "lenFINSEQ-1K4 ?Cut +XCMPLX-0K2 m =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
      using A1 A2 A3 finseq_6_def_4 sorry
    then have A32: "lenFINSEQ-1K4 ?Cut =XBOOLE-0R4 (n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 m"
       sorry
    let ?X = "rngFUNCT-1K2 ?Cut"
    have A33: "rngRELSET-1K2\<^bsub>(INTINT-1K1)\<^esub> ?Cut be SubsetSUBSET-1M2-of INTINT-1K1"
       sorry
    have "m <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
      using A2 nat_1_th_13 sorry
    then have "m -XCMPLX-0K6 m <XXREAL-0R3 (n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 m"
      using xreal_1_th_9 sorry
    then have "?Cut be  non emptyXBOOLE-0V1"
      using A31 sorry
    then obtain X where 
      [ty]:"X be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of INTINT-1K1" and XDef:"X = ?X"
      using A33 sorry
    obtain rX where 
      [ty]:"rX be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2" and rXDef:"rX = X"
      using membered_th_3 sorry
    assume A34: "m <=XXREAL-0R1 ma"
      and A35: "ma <=XXREAL-0R1 n"
      and A36: " for i be NatNAT-1M1 holds m <=XXREAL-0R1 i & i <=XXREAL-0R1 n implies F .FUNCT-1K1 ma <=XXREAL-0R1 F .FUNCT-1K1 i"
      and A37: " for i be NatNAT-1M1 holds m <=XXREAL-0R1 i & i <XXREAL-0R3 ma implies F .FUNCT-1K1 ma <XXREAL-0R3 F .FUNCT-1K1 i"
    have "m -XCMPLX-0K6 m <=XXREAL-0R1 ma -XCMPLX-0K6 m"
      using A34 xreal_1_th_9 sorry
    then obtain qm where 
      [ty]:"qm be ElementSUBSET-1M1-of NATNUMBERSK1" and qmDef:"qm = ma -XCMPLX-0K6 m"
      using int_1_th_3 sorry
    have A38: "qm +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 (ma +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 m"
       sorry
    then obtain q1 where 
      [ty]:"q1 be ElementSUBSET-1M1-of NATNUMBERSK1" and q1Def:"q1 = (ma +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 m"
       sorry
    have "ma +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
      using A35 xreal_1_th_6 sorry
    then have A39: "q1 <=XXREAL-0R1 lenFINSEQ-1K4 ?Cut"
      using A32 xreal_1_th_9 sorry
    have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 qm +NAT-1K1 \<one>\<^sub>M"
      using xreal_1_th_6 sorry
    then have A40: "q1 inTARSKIR2 domFINSEQ-1K5 ?Cut"
      using A39 finseq_3_th_25 sorry
    have A41: "ma =XBOOLE-0R4 qm +XCMPLX-0K2 m"
       sorry
    have "qm <XXREAL-0R3 lenFINSEQ-1K4 ?Cut"
      using A38 A39 nat_1_th_13 sorry
    then have A42: "F .FUNCT-1K1 ma =XBOOLE-0R4 ?Cut .FUNCT-1K1 ((ma +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 m)"
      using A1 A2 A3 A38 A41 finseq_6_def_4 sorry
    have "F .FUNCT-1K1 ma inTARSKIR2 X & ( for k be ExtRealXXREAL-0M1 holds k inHIDDENR3 X implies F .FUNCT-1K1 ma <=XXREAL-0R1 k)"
    proof(rule conjMI,rule ballI,rule impI)
      show "F .FUNCT-1K1 ma inTARSKIR2 X"
        using A40 A42 funct_1_def_3 sorry
      fix k assume [ty]: "k be ExtRealXXREAL-0M1"
      assume "k inHIDDENR3 X"
      then obtain dk where
        [ty]:"dk be objectHIDDENM1" and 
        A43: "dk inHIDDENR3 domFINSEQ-1K5 ?Cut"and A44: "?Cut .FUNCT-1K1 dk =HIDDENR1 k"
        using funct_1_def_3 sorry
      have 
        [ty]:"dk be ElementSUBSET-1M1-of NATNUMBERSK1"
        using A43 sorry
      have "\<one>\<^sub>M <=XXREAL-0R1 dk"
        using A43 finseq_3_th_25 sorry
      then have "\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 dk -XCMPLX-0K6 \<one>\<^sub>M"
        using xreal_1_th_9 sorry
      then obtain dk1 where 
        [ty]:"dk1 be ElementSUBSET-1M1-of NATNUMBERSK1" and dk1Def:"dk1 = dk -XCMPLX-0K6 \<one>\<^sub>M"
        using int_1_th_3 sorry
      have A45: "dk <=XXREAL-0R1 lenFINSEQ-1K4 ?Cut"
        using A43 finseq_3_th_25 sorry
      then have "dk +XCMPLX-0K2 m <=XXREAL-0R1 lenFINSEQ-1K4 ?Cut +XCMPLX-0K2 m"
        using xreal_1_th_6 sorry
      then have A46: "(dk +XCMPLX-0K2 m)-XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 n"
        using A4 xreal_1_th_20 sorry
      have "dk1 <XXREAL-0R3 lenFINSEQ-1K4 ?Cut"
        using A45 xreal_1_th_146 xxreal_0_th_2 sorry
      then have "F .FUNCT-1K1 (dk1 +XCMPLX-0K2 m) =HIDDENR1 ?Cut .FUNCT-1K1 (dk1 +NAT-1K1 \<one>\<^sub>M)"
        using A1 A2 A3 finseq_6_def_4 sorry
      also have "... = ?Cut .FUNCT-1K1 dk"
         sorry
      finally have "F .FUNCT-1K1 (dk1 +XCMPLX-0K2 m) =HIDDENR1 ?Cut .FUNCT-1K1 dk"
         sorry
      thus "F .FUNCT-1K1 ma <=XXREAL-0R1 k"
        using A36 A44 A46 nat_1_th_12 sorry
    qed "sorry"
    then have A47: "F .FUNCT-1K1 ma =HIDDENR1 minXXREAL-2K5 rX"
      using xxreal_2_def_7 sorry
    let ?mX = "minXXREAL-2K5 X"
    let ?mXC = "?mX ..FINSEQ-4K4 ?Cut"
    have A48: "?mX inHIDDENR3 X"
      using xxreal_2_def_7 sorry
    then have "\<one>\<^sub>M <=XXREAL-0R1 ?mXC"
      using finseq_4_th_21 sorry
    then have "\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 ?mXC -XCMPLX-0K6 \<one>\<^sub>M"
      using xreal_1_th_9 sorry
    then obtain mXC1 where 
      [ty]:"mXC1 be ElementSUBSET-1M1-of NATNUMBERSK1" and mXC1Def:"mXC1 = ?mXC -XCMPLX-0K6 \<one>\<^sub>M"
      using int_1_th_3 sorry
    let ?mXCm = "mXC1 +XCMPLX-0K2 m"
    have "?mXC <=XXREAL-0R1 lenFINSEQ-1K4 ?Cut"
      using A48 finseq_4_th_21 sorry
    then have A49: "mXC1 <XXREAL-0R3 lenFINSEQ-1K4 ?Cut"
      using xreal_1_th_146 xxreal_0_th_2 sorry
    have "?mXC =XBOOLE-0R4 mXC1 +NAT-1K1 \<one>\<^sub>M"
       sorry
    then have A50: "F .FUNCT-1K1 ?mXCm =XBOOLE-0R4 ?Cut .FUNCT-1K1 ?mXC"
      using A1 A2 A3 A49 finseq_6_def_4 sorry
    have A51: "m <=XXREAL-0R1 ?mXCm"
      using nat_1_th_12 sorry
    have A52: "?Cut .FUNCT-1K1 (?mX ..FINSEQ-4K4 ?Cut) =HIDDENR1 ?mX"
      using A48 finseq_4_th_19 sorry
    have "q1 <>HIDDENR2 ?mXC implies  False "
    proof(rule impI)
      assume A53: "q1 <>HIDDENR2 ?mXC"
      show " False "
      proof-
        have cases: "q1 <XXREAL-0R3 ?mXC or q1 >XXREAL-0R4 ?mXC"
          using A53 xxreal_0_th_1 sorry
        have case1: "q1 <XXREAL-0R3 minXXREAL-2K5 X ..FINSEQ-4K4 ((m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F) implies  False "
        proof(rule impI)
          assume "q1 <XXREAL-0R3 ?mXC"
          thus " False "
            using A40 A42 A47 finseq_4_th_24 sorry
        qed
        have case2: "q1 >XXREAL-0R4 minXXREAL-2K5 X ..FINSEQ-4K4 ((m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F) implies  False "
        proof(rule impI)
          assume "q1 >XXREAL-0R4 ?mXC"
          then have "?mXC +XCMPLX-0K2 m <XXREAL-0R3 ma +NAT-1K1 \<one>\<^sub>M"
            using xreal_1_th_20 sorry
          then have "(?mXC +XCMPLX-0K2 m)-XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 ma"
            using xreal_1_th_19 sorry
          thus " False "
            using A37 A52 A47 A51 A50 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    then have "ma +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 ?mX ..FINSEQ-4K4 ?Cut +XCMPLX-0K2 m"
       sorry
    thus "ma =XBOOLE-0R4 min-atFINSEQ-6K8(F,m,n)"
      using A1 A2 A3 finseq_6_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_162:
" for F be FinSequenceFINSEQ-1M3-of INTINT-1K1 holds  for m be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 F implies min-atFINSEQ-6K8(F,m,m) =XBOOLE-0R4 m"
proof-
  have " for F be FinSequenceFINSEQ-1M3-of INTINT-1K1 holds  for m be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 F implies min-atFINSEQ-6K8(F,m,m) =XBOOLE-0R4 m"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix F assume [ty]: "F be FinSequenceFINSEQ-1M3-of INTINT-1K1"
    fix m assume [ty]: "m be NatNAT-1M1"
    assume A1: "\<one>\<^sub>M <=XXREAL-0R1 m"
      and A2: "m <=XXREAL-0R1 lenFINSEQ-1K4 F"
    have A3: " for i be NatNAT-1M1 holds m <=XXREAL-0R1 i & i <XXREAL-0R3 m implies F .FUNCT-1K1 m <XXREAL-0R3 F .FUNCT-1K1 i"
       sorry
    have " for i be NatNAT-1M1 holds m <=XXREAL-0R1 i & i <=XXREAL-0R1 m implies F .FUNCT-1K1 m <=XXREAL-0R1 F .FUNCT-1K1 i"
      using xxreal_0_th_1 sorry
    thus "min-atFINSEQ-6K8(F,m,m) =XBOOLE-0R4 m"
      using A1 A2 A3 finseq_6_th_161 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef finseq_6_def_9 (" _ is-non-decreasing-onFINSEQ-6R1'( _ , _ ')" [50,0,0]50 ) where
  mlet "F be FinSequenceFINSEQ-1M3-of INTINT-1K1", "m be NatNAT-1M1", "n be NatNAT-1M1"
"pred F is-non-decreasing-onFINSEQ-6R1(m,n) means
   for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds (m <=XXREAL-0R1 i & i <=XXREAL-0R1 j) & j <=XXREAL-0R1 n implies F .FUNCT-1K1 i <=XXREAL-0R1 F .FUNCT-1K1 j"..

mdef finseq_6_def_10 (" _ is-split-atFINSEQ-6R2  _ " [50,50]50 ) where
  mlet "F be FinSequenceFINSEQ-1M3-of INTINT-1K1", "n be NatNAT-1M1"
"pred F is-split-atFINSEQ-6R2 n means
   for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds ((\<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 n) & n <XXREAL-0R3 j) & j <=XXREAL-0R1 lenFINSEQ-1K4 F implies F .FUNCT-1K1 i <=XXREAL-0R1 F .FUNCT-1K1 j"..

mtheorem finseq_6_th_163:
" for F be FinSequenceFINSEQ-1M3-of INTINT-1K1 holds  for F1 be FinSequenceFINSEQ-1M3-of INTINT-1K1 holds  for k be NatNAT-1M1 holds  for ma be NatNAT-1M1 holds (((k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 F & ma =XBOOLE-0R4 min-atFINSEQ-6K8(F,k +NAT-1K1 \<one>\<^sub>M,lenFINSEQ-1K4 F)) & F is-split-atFINSEQ-6R2 k) & F is-non-decreasing-onFINSEQ-6R1(\<one>\<^sub>M,k)) & F1 =FUNCT-1R1 (F +*FUNCT-7K1(k +NAT-1K1 \<one>\<^sub>M,F .FUNCT-1K1 ma))+*FUNCT-7K1(ma,F .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)) implies F1 is-non-decreasing-onFINSEQ-6R1(\<one>\<^sub>M,k +NAT-1K1 \<one>\<^sub>M)"
proof-
  have " for F be FinSequenceFINSEQ-1M3-of INTINT-1K1 holds  for F1 be FinSequenceFINSEQ-1M3-of INTINT-1K1 holds  for k be NatNAT-1M1 holds  for ma be NatNAT-1M1 holds k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 F & (ma =XBOOLE-0R4 min-atFINSEQ-6K8(F,k +NAT-1K1 \<one>\<^sub>M,lenFINSEQ-1K4 F) & (F is-split-atFINSEQ-6R2 k & (F is-non-decreasing-onFINSEQ-6R1(\<one>\<^sub>M,k) & F1 =FUNCT-1R1 (F +*FUNCT-7K1(k +NAT-1K1 \<one>\<^sub>M,F .FUNCT-1K1 ma))+*FUNCT-7K1(ma,F .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))))) implies F1 is-non-decreasing-onFINSEQ-6R1(\<one>\<^sub>M,k +NAT-1K1 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix F assume [ty]: "F be FinSequenceFINSEQ-1M3-of INTINT-1K1"
    fix F1 assume [ty]: "F1 be FinSequenceFINSEQ-1M3-of INTINT-1K1"
    fix k assume [ty]: "k be NatNAT-1M1"
    fix ma assume [ty]: "ma be NatNAT-1M1"
    assume A1: "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 F"
      and A2: "ma =XBOOLE-0R4 min-atFINSEQ-6K8(F,k +NAT-1K1 \<one>\<^sub>M,lenFINSEQ-1K4 F)"
      and A3: "F is-split-atFINSEQ-6R2 k"
      and A4: "F is-non-decreasing-onFINSEQ-6R1(\<one>\<^sub>M,k)"
      and A5: "F1 =FUNCT-1R1 (F +*FUNCT-7K1(k +NAT-1K1 \<one>\<^sub>M,F .FUNCT-1K1 ma))+*FUNCT-7K1(ma,F .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))"
    have A6: "\<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_12 sorry
    let ?Fk = "F +*FUNCT-7K1(k +NAT-1K1 \<one>\<^sub>M,F .FUNCT-1K1 ma)"
    have A7: "domFINSEQ-1K5 F1 =XBOOLE-0R4 domRELAT-1K1 ?Fk"
      using A5 funct_7_th_30 sorry
    have A8: "domRELAT-1K1 ?Fk =XBOOLE-0R4 domFINSEQ-1K5 F"
      using funct_7_th_30 sorry
    then have A9: "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 F1"
      using A1 A7 A6 finseq_3_th_25 sorry
    have " for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & (i <=XXREAL-0R1 j & j <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M) implies F1 .FUNCT-1K1 i <=XXREAL-0R1 F1 .FUNCT-1K1 j"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix i assume [ty]: "i be NatNAT-1M1"
      fix j assume [ty]: "j be NatNAT-1M1"
      assume A10: "\<one>\<^sub>M <=XXREAL-0R1 i"
        and A11: "i <=XXREAL-0R1 j"
        and A12: "j <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
      have A13: "j <=XXREAL-0R1 lenFINSEQ-1K4 F"
        using A1 A12 xxreal_0_th_2 sorry
      have "\<one>\<^sub>M <=XXREAL-0R1 j"
        using A10 A11 xxreal_0_th_2 sorry
      then have A14: "j inTARSKIR2 domFINSEQ-1K5 F1"
        using A7 A8 A13 finseq_3_th_25 sorry
      show "F1 .FUNCT-1K1 i <=XXREAL-0R1 F1 .FUNCT-1K1 j"
      proof-
        have cases: "j <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M or j =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
          using A12 xxreal_0_th_1 sorry
        have case1: "j <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M implies F1 .FUNCT-1K1 i <=XXREAL-0R1 F1 .FUNCT-1K1 j"
        proof(rule impI)
          assume A15: "j <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M"
          then have "i <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M"
            using A11 xxreal_0_th_2 sorry
          then have "i <>HIDDENR2 ma"
            using A1 A2 A6 finseq_6_th_161 sorry
          then have A16: "F1 .FUNCT-1K1 i =HIDDENR1 ?Fk .FUNCT-1K1 i"
            using A5 funct_7_th_32 sorry
          also have "... = F .FUNCT-1K1 i"
            using A11 A15 funct_7_th_32 sorry
          finally have "F1 .FUNCT-1K1 i =HIDDENR1 F .FUNCT-1K1 i"
             sorry
          have "j <>HIDDENR2 ma"
            using A1 A2 A6 A15 finseq_6_th_161 sorry
          then have A17: "F1 .FUNCT-1K1 j =HIDDENR1 ?Fk .FUNCT-1K1 j"
            using A5 funct_7_th_32 sorry
          also have "... = F .FUNCT-1K1 j"
            using A15 funct_7_th_32 sorry
          finally have "F1 .FUNCT-1K1 j =HIDDENR1 F .FUNCT-1K1 j"
             sorry
          have "j <=XXREAL-0R1 k"
            using A15 nat_1_th_13 sorry
          thus "F1 .FUNCT-1K1 i <=XXREAL-0R1 F1 .FUNCT-1K1 j"
            using A4 A10 A11 A16 A17 sorry
        qed
        have case2: "j =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M implies F1 .FUNCT-1K1 i <=XXREAL-0R1 F1 .FUNCT-1K1 j"
        proof(rule impI)
          assume A18: "j =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
          show "F1 .FUNCT-1K1 i <=XXREAL-0R1 F1 .FUNCT-1K1 j"
          proof-
            show "F1 .FUNCT-1K1 i <=XXREAL-0R1 F1 .FUNCT-1K1 j"
            proof-
              have cases: "i <XXREAL-0R3 j or i =XBOOLE-0R4 j"
                using A11 xxreal_0_th_1 sorry
              have case1: "i <XXREAL-0R3 j implies F1 .FUNCT-1K1 i <=XXREAL-0R1 F1 .FUNCT-1K1 j"
              proof(rule impI)
                assume A19: "i <XXREAL-0R3 j"
                then have "i <>HIDDENR2 ma"
                  using A1 A2 A6 A18 finseq_6_th_161 sorry
                then have A20: "F1 .FUNCT-1K1 i =HIDDENR1 ?Fk .FUNCT-1K1 i"
                  using A5 funct_7_th_32 sorry
                also have "... = F .FUNCT-1K1 i"
                  using A18 A19 funct_7_th_32 sorry
                finally have "F1 .FUNCT-1K1 i =HIDDENR1 F .FUNCT-1K1 i"
                   sorry
                have A21: "i <=XXREAL-0R1 k"
                  using A18 A19 nat_1_th_13 sorry
                have A22: "k <XXREAL-0R3 j"
                  using A18 nat_1_th_13 sorry
                show "F1 .FUNCT-1K1 i <=XXREAL-0R1 F1 .FUNCT-1K1 j"
                proof-
                  show "F1 .FUNCT-1K1 i <=XXREAL-0R1 F1 .FUNCT-1K1 j"
                  proof-
                    have cases: "k +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 ma or k +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 ma"
                       sorry
                    have case1: "k +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 ma implies F1 .FUNCT-1K1 i <=XXREAL-0R1 F1 .FUNCT-1K1 j"
                    proof(rule impI)
                      assume "k +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 ma"
                      then have "F1 .FUNCT-1K1 j =XBOOLE-0R4 F .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
                        using A5 A7 A9 A18 funct_7_th_31 sorry
                      thus "F1 .FUNCT-1K1 i <=XXREAL-0R1 F1 .FUNCT-1K1 j"
                        using A1 A3 A10 A18 A20 A21 A22 sorry
                    qed
                    have case2: "k +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 ma implies F1 .FUNCT-1K1 i <=XXREAL-0R1 F1 .FUNCT-1K1 j"
                    proof(rule impI)
                      assume A23: "k +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 ma"
                      have A24: "ma <=XXREAL-0R1 lenFINSEQ-1K4 F"
                        using A1 A2 A6 finseq_6_th_161 sorry
                      have "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 ma"
                        using A1 A2 A6 finseq_6_th_161 sorry
                      then have A25: "k <XXREAL-0R3 ma"
                        using nat_1_th_13 sorry
                      have "F1 .FUNCT-1K1 j =HIDDENR1 ?Fk .FUNCT-1K1 j"
                        using A5 A18 A23 funct_7_th_32 sorry
                      also have "... = F .FUNCT-1K1 ma"
                        using A7 A8 A14 A18 funct_7_th_31 sorry
                      finally have "F1 .FUNCT-1K1 j =HIDDENR1 F .FUNCT-1K1 ma"
                         sorry
                      thus "F1 .FUNCT-1K1 i <=XXREAL-0R1 F1 .FUNCT-1K1 j"
                        using A3 A10 A20 A21 A25 A24 sorry
                    qed
                    show " ?thesis "
                      using cases case1 case2 sorry
                  qed
                qed
              qed
              have case2: "i =XBOOLE-0R4 j implies F1 .FUNCT-1K1 i <=XXREAL-0R1 F1 .FUNCT-1K1 j"
              proof(rule impI)
                assume "i =XBOOLE-0R4 j"
                thus "F1 .FUNCT-1K1 i <=XXREAL-0R1 F1 .FUNCT-1K1 j"
                   sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus "F1 is-non-decreasing-onFINSEQ-6R1(\<one>\<^sub>M,k +NAT-1K1 \<one>\<^sub>M)"
      using finseq_6_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_164:
" for F be FinSequenceFINSEQ-1M3-of INTINT-1K1 holds  for F1 be FinSequenceFINSEQ-1M3-of INTINT-1K1 holds  for k be NatNAT-1M1 holds  for ma be NatNAT-1M1 holds ((k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 F & ma =XBOOLE-0R4 min-atFINSEQ-6K8(F,k +NAT-1K1 \<one>\<^sub>M,lenFINSEQ-1K4 F)) & F is-split-atFINSEQ-6R2 k) & F1 =FUNCT-1R1 (F +*FUNCT-7K1(k +NAT-1K1 \<one>\<^sub>M,F .FUNCT-1K1 ma))+*FUNCT-7K1(ma,F .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)) implies F1 is-split-atFINSEQ-6R2 k +NAT-1K1 \<one>\<^sub>M"
proof-
  have " for F be FinSequenceFINSEQ-1M3-of INTINT-1K1 holds  for F1 be FinSequenceFINSEQ-1M3-of INTINT-1K1 holds  for k be NatNAT-1M1 holds  for ma be NatNAT-1M1 holds k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 F & (ma =XBOOLE-0R4 min-atFINSEQ-6K8(F,k +NAT-1K1 \<one>\<^sub>M,lenFINSEQ-1K4 F) & (F is-split-atFINSEQ-6R2 k & F1 =FUNCT-1R1 (F +*FUNCT-7K1(k +NAT-1K1 \<one>\<^sub>M,F .FUNCT-1K1 ma))+*FUNCT-7K1(ma,F .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))) implies F1 is-split-atFINSEQ-6R2 k +NAT-1K1 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix F assume [ty]: "F be FinSequenceFINSEQ-1M3-of INTINT-1K1"
    fix F1 assume [ty]: "F1 be FinSequenceFINSEQ-1M3-of INTINT-1K1"
    fix k assume [ty]: "k be NatNAT-1M1"
    fix ma assume [ty]: "ma be NatNAT-1M1"
    assume A1: "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 F"
      and A2: "ma =XBOOLE-0R4 min-atFINSEQ-6K8(F,k +NAT-1K1 \<one>\<^sub>M,lenFINSEQ-1K4 F)"
      and A3: "F is-split-atFINSEQ-6R2 k"
      and A4: "F1 =FUNCT-1R1 (F +*FUNCT-7K1(k +NAT-1K1 \<one>\<^sub>M,F .FUNCT-1K1 ma))+*FUNCT-7K1(ma,F .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))"
    have A5: "domFINSEQ-1K5 F1 =XBOOLE-0R4 domRELAT-1K1 (F +*FUNCT-7K1(k +NAT-1K1 \<one>\<^sub>M,F .FUNCT-1K1 ma))"
      using A4 funct_7_th_30 sorry
    have A6: "k <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_13 sorry
    have A7: "\<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_12 sorry
    have " for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & (i <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M & (k +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 j & j <=XXREAL-0R1 lenFINSEQ-1K4 F1)) implies F1 .FUNCT-1K1 i <=XXREAL-0R1 F1 .FUNCT-1K1 j"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
      fix i assume [ty]: "i be NatNAT-1M1"
      fix j assume [ty]: "j be NatNAT-1M1"
      assume A8: "\<one>\<^sub>M <=XXREAL-0R1 i"
        and A9: "i <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
        and A10: "k +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 j"
        and A11: "j <=XXREAL-0R1 lenFINSEQ-1K4 F1"
      have A12: "k <XXREAL-0R3 j"
        using A10 nat_1_th_13 sorry
      have A13: "domRELAT-1K1 (F +*FUNCT-7K1(k +NAT-1K1 \<one>\<^sub>M,F .FUNCT-1K1 ma)) =XBOOLE-0R4 domFINSEQ-1K5 F"
        using funct_7_th_30 sorry
      then have A14: "lenFINSEQ-1K4 F1 =XBOOLE-0R4 lenFINSEQ-1K4 F"
        using A5 finseq_3_th_29 sorry
      then have A15: "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 F"
        using A10 A11 xxreal_0_th_2 sorry
      have "i <=XXREAL-0R1 lenFINSEQ-1K4 F1"
        using A1 A14 A9 xxreal_0_th_2 sorry
      then have A16: "i inTARSKIR2 domFINSEQ-1K5 F1"
        using A8 finseq_3_th_25 sorry
      have "\<one>\<^sub>M <=XXREAL-0R1 j"
        using A10 nat_1_th_12 sorry
      then have A17: "j inTARSKIR2 domFINSEQ-1K5 F1"
        using A11 finseq_3_th_25 sorry
      show "F1 .FUNCT-1K1 i <=XXREAL-0R1 F1 .FUNCT-1K1 j"
      proof-
        have cases: "i <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M or i =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
          using A9 xxreal_0_th_1 sorry
        have case1: "i <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M implies F1 .FUNCT-1K1 i <=XXREAL-0R1 F1 .FUNCT-1K1 j"
        proof(rule impI)
          assume A18: "i <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M"
          then have "i <>HIDDENR2 ma"
            using A1 A2 A7 finseq_6_th_161 sorry
          then have A19: "F1 .FUNCT-1K1 i =HIDDENR1 (F +*FUNCT-7K1(k +NAT-1K1 \<one>\<^sub>M,F .FUNCT-1K1 ma)).FUNCT-1K1 i"
            using A4 funct_7_th_32 sorry
          also have "... = F .FUNCT-1K1 i"
            using A18 funct_7_th_32 sorry
          finally have "F1 .FUNCT-1K1 i =HIDDENR1 F .FUNCT-1K1 i"
             sorry
          have A20: "i <=XXREAL-0R1 k"
            using A18 nat_1_th_13 sorry
          show "F1 .FUNCT-1K1 i <=XXREAL-0R1 F1 .FUNCT-1K1 j"
          proof-
            show "F1 .FUNCT-1K1 i <=XXREAL-0R1 F1 .FUNCT-1K1 j"
            proof-
              have cases: "j <>HIDDENR2 ma or j =XBOOLE-0R4 ma"
                 sorry
              have case1: "j <>HIDDENR2 ma implies F1 .FUNCT-1K1 i <=XXREAL-0R1 F1 .FUNCT-1K1 j"
              proof(rule impI)
                assume "j <>HIDDENR2 ma"
                then have "F1 .FUNCT-1K1 j =HIDDENR1 (F +*FUNCT-7K1(k +NAT-1K1 \<one>\<^sub>M,F .FUNCT-1K1 ma)).FUNCT-1K1 j"
                  using A4 funct_7_th_32 sorry
                also have "... = F .FUNCT-1K1 j"
                  using A10 funct_7_th_32 sorry
                finally have "F1 .FUNCT-1K1 j =HIDDENR1 F .FUNCT-1K1 j"
                   sorry
                thus "F1 .FUNCT-1K1 i <=XXREAL-0R1 F1 .FUNCT-1K1 j"
                  using A3 A14 A8 A11 A12 A20 A19 sorry
              qed
              have case2: "j =XBOOLE-0R4 ma implies F1 .FUNCT-1K1 i <=XXREAL-0R1 F1 .FUNCT-1K1 j"
              proof(rule impI)
                assume "j =XBOOLE-0R4 ma"
                then have "F1 .FUNCT-1K1 j =XBOOLE-0R4 F .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
                  using A4 A5 A17 funct_7_th_31 sorry
                thus "F1 .FUNCT-1K1 i <=XXREAL-0R1 F1 .FUNCT-1K1 j"
                  using A3 A6 A8 A15 A20 A19 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
        qed
        have case2: "i =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M implies F1 .FUNCT-1K1 i <=XXREAL-0R1 F1 .FUNCT-1K1 j"
        proof(rule impI)
          assume A21: "i =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
          have A22: "F1 .FUNCT-1K1 i =XBOOLE-0R4 F .FUNCT-1K1 ma"
          proof-
            show "F1 .FUNCT-1K1 i =XBOOLE-0R4 F .FUNCT-1K1 ma"
            proof-
              have cases: "k +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 ma or k +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 ma"
                 sorry
              have case1: "k +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 ma implies F1 .FUNCT-1K1 i =XBOOLE-0R4 F .FUNCT-1K1 ma"
              proof(rule impI)
                assume "k +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 ma"
                thus "F1 .FUNCT-1K1 i =XBOOLE-0R4 F .FUNCT-1K1 ma"
                  using A4 A5 A16 A21 funct_7_th_31 sorry
              qed
              have case2: "k +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 ma implies F1 .FUNCT-1K1 i =HIDDENR1 F .FUNCT-1K1 ma"
              proof(rule impI)
                assume "k +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 ma"
                then have "F1 .FUNCT-1K1 i =HIDDENR1 (F +*FUNCT-7K1(k +NAT-1K1 \<one>\<^sub>M,F .FUNCT-1K1 ma)).FUNCT-1K1 i"
                  using A4 A21 funct_7_th_32 sorry
                also have "... = F .FUNCT-1K1 ma"
                  using A5 A13 A16 A21 funct_7_th_31 sorry
                finally show "F1 .FUNCT-1K1 i =HIDDENR1 F .FUNCT-1K1 ma"
                   sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          show "F1 .FUNCT-1K1 i <=XXREAL-0R1 F1 .FUNCT-1K1 j"
          proof-
            show "F1 .FUNCT-1K1 i <=XXREAL-0R1 F1 .FUNCT-1K1 j"
            proof-
              have cases: "j =XBOOLE-0R4 ma or j <>HIDDENR2 ma"
                 sorry
              have case1: "j =XBOOLE-0R4 ma implies F1 .FUNCT-1K1 i <=XXREAL-0R1 F1 .FUNCT-1K1 j"
              proof(rule impI)
                assume "j =XBOOLE-0R4 ma"
                then have "F1 .FUNCT-1K1 j =XBOOLE-0R4 F .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
                  using A4 A5 A17 funct_7_th_31 sorry
                thus "F1 .FUNCT-1K1 i <=XXREAL-0R1 F1 .FUNCT-1K1 j"
                  using A1 A2 A7 A22 finseq_6_th_161 sorry
              qed
              have case2: "j <>HIDDENR2 ma implies F1 .FUNCT-1K1 i <=XXREAL-0R1 F1 .FUNCT-1K1 j"
              proof(rule impI)
                assume "j <>HIDDENR2 ma"
                then have "F1 .FUNCT-1K1 j =HIDDENR1 (F +*FUNCT-7K1(k +NAT-1K1 \<one>\<^sub>M,F .FUNCT-1K1 ma)).FUNCT-1K1 j"
                  using A4 funct_7_th_32 sorry
                also have "... = F .FUNCT-1K1 j"
                  using A10 funct_7_th_32 sorry
                finally have "F1 .FUNCT-1K1 j =HIDDENR1 F .FUNCT-1K1 j"
                   sorry
                thus "F1 .FUNCT-1K1 i <=XXREAL-0R1 F1 .FUNCT-1K1 j"
                  using A1 A2 A14 A7 A10 A11 A22 finseq_6_th_161 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus "F1 is-split-atFINSEQ-6R2 k +NAT-1K1 \<one>\<^sub>M"
      using finseq_6_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_165:
" for f be FinSequenceFINSEQ-1M3-of INTINT-1K1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds m >=XXREAL-0R2 n implies f is-non-decreasing-onFINSEQ-6R1(m,n)"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of INTINT-1K1"
  fix m assume [ty]: "m be NatNAT-1M1"
  fix n assume [ty]: "n be NatNAT-1M1"
  assume A1: "m >=XXREAL-0R2 n"
  have " for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds (m <=XXREAL-0R1 i & i <=XXREAL-0R1 j) & j <=XXREAL-0R1 n implies f .FUNCT-1K1 i <=XXREAL-0R1 f .FUNCT-1K1 j"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix j assume [ty]: "j be NatNAT-1M1"
    assume A2: "m <=XXREAL-0R1 i & i <=XXREAL-0R1 j"
      and A3: "j <=XXREAL-0R1 n"
    have A4: "m <=XXREAL-0R1 j"
      using A2 xxreal_0_th_2 sorry
    show "f .FUNCT-1K1 i <=XXREAL-0R1 f .FUNCT-1K1 j"
    proof-
      have cases: "m =XBOOLE-0R4 n or m >XXREAL-0R4 n"
        using A1 xxreal_0_th_1 sorry
      have case1: "m =XBOOLE-0R4 n implies f .FUNCT-1K1 i <=XXREAL-0R1 f .FUNCT-1K1 j"
      proof(rule impI)
        assume "m =XBOOLE-0R4 n"
        then have "j =XBOOLE-0R4 m"
          using A3 A4 xxreal_0_th_1 sorry
        thus "f .FUNCT-1K1 i <=XXREAL-0R1 f .FUNCT-1K1 j"
          using A2 xxreal_0_th_1 sorry
      qed
      have case2: "m >XXREAL-0R4 n implies f .FUNCT-1K1 i <=XXREAL-0R1 f .FUNCT-1K1 j"
      proof(rule impI)
        assume "m >XXREAL-0R4 n"
        thus "f .FUNCT-1K1 i <=XXREAL-0R1 f .FUNCT-1K1 j"
          using A3 A4 xxreal_0_th_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus "f is-non-decreasing-onFINSEQ-6R1(m,n)"
    using finseq_6_def_9 sorry
qed "sorry"

(*begin*)
reserve i, j, k, m, n for "NatNAT-1M1"
reserve D for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve p for "ElementSUBSET-1M1-of D"
reserve f for "FinSequenceFINSEQ-1M3-of D"
syntax FINSEQ_6V4 :: " Set \<Rightarrow> Ty" ("constantFINSEQ-6V4\<^bsub>'( _ ')\<^esub>" [0]70)
translations "constantFINSEQ-6V4\<^bsub>(D)\<^esub>" \<rightharpoonup> "constantFUNCT-1V5"

mtheorem finseq_6_def_11:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FinSequenceFINSEQ-1M3-of D"
"redefine attr constantFINSEQ-6V4\<^bsub>(D)\<^esub> for FinSequenceFINSEQ-1M3-of D means
  (\<lambda>f.  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 f & m inTARSKIR2 domFINSEQ-1K5 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> n =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> m)"
proof
(*compatibility*)
  show " for f be FinSequenceFINSEQ-1M3-of D holds f be constantFINSEQ-6V4\<^bsub>(D)\<^esub> iff ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 f & m inTARSKIR2 domFINSEQ-1K5 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> n =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> m)"
  proof(rule ballI)
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    show "f be constantFINSEQ-6V4\<^bsub>(D)\<^esub> iff ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 f & m inTARSKIR2 domFINSEQ-1K5 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> n =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> m)"
    proof-
      have "(f be constantFUNCT-1V5 implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 f & m inTARSKIR2 domFINSEQ-1K5 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> n =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> m)) & (( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 f & m inTARSKIR2 domFINSEQ-1K5 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> n =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> m) implies f be constantFUNCT-1V5)"
      proof(rule conjMI,rule impI)
        show "f be constantFUNCT-1V5 implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 f & m inTARSKIR2 domFINSEQ-1K5 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> n =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> m)"
        proof(rule impI,rule ballI,rule ballI,rule impMI ,rule impI)
          assume A1: "f be constantFUNCT-1V5"
          fix n assume [ty]: "n be NatNAT-1M1"
          fix m assume [ty]: "m be NatNAT-1M1"
          assume A2: "n inTARSKIR2 domFINSEQ-1K5 f"
            and A3: "m inTARSKIR2 domFINSEQ-1K5 f"
          have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> n =HIDDENR1 f .FUNCT-1K1 n"
            using A2 partfun1_def_6 sorry
          also have "... = f .FUNCT-1K1 m"
            using A1 A2 A3 sorry
          also have "... = f /.PARTFUN1K7\<^bsub>(D)\<^esub> m"
            using A3 partfun1_def_6 sorry
          finally show "f /.PARTFUN1K7\<^bsub>(D)\<^esub> n =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> m"
             sorry
        qed "sorry"
        assume A4: " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 f & m inTARSKIR2 domFINSEQ-1K5 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> n =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> m"
        have " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 f & m inTARSKIR2 domFINSEQ-1K5 f implies f .FUNCT-1K1 n =HIDDENR1 f .FUNCT-1K1 m"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix n assume [ty]: "n be NatNAT-1M1"
          fix m assume [ty]: "m be NatNAT-1M1"
          assume A5: "n inTARSKIR2 domFINSEQ-1K5 f"
            and A6: "m inTARSKIR2 domFINSEQ-1K5 f"
          have "f .FUNCT-1K1 n =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> n"
            using A5 partfun1_def_6 sorry
          also have "... = f /.PARTFUN1K7\<^bsub>(D)\<^esub> m"
            using A4 A5 A6 sorry
          also have "... = f .FUNCT-1K1 m"
            using A6 partfun1_def_6 sorry
          finally show "f .FUNCT-1K1 n =HIDDENR1 f .FUNCT-1K1 m"
             sorry
        qed "sorry"
        thus "f be constantFUNCT-1V5"
          using seqm_3_def_10 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

mtheorem finseq_6_th_166:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds f just-once-valuesFINSEQ-4R2 f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f implies (f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f)..FINSEQ-4K4 f =XBOOLE-0R4 lenFINSEQ-1K4 f"
proof(rule ballI,rule ballI,rule impI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
  assume A1: "f just-once-valuesFINSEQ-4R2 f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f"
  then obtain f9 where 
    [ty]:"f9 be  non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M3-of D" and f9Def:"f9 = f"
    using finseq_4_th_5 relat_1_th_38 sorry
  have "(f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f)..FINSEQ-4K4 f +NAT-1K1 \<one>\<^sub>M =HIDDENR1 (f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f)..FINSEQ-4K4 f +NAT-1K1 (RevFINSEQ-5K4\<^bsub>(D)\<^esub> f9 /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M)..FINSEQ-4K4 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f9"
    using finseq_6_th_43 sorry
  also have "... = (f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f)..FINSEQ-4K4 f +NAT-1K1 (f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f)..FINSEQ-4K4 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f"
    using finseq_5_th_65 sorry
  also have "... = lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M"
    using A1 finseq_6_th_37 sorry
  finally have "(f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f)..FINSEQ-4K4 f +NAT-1K1 \<one>\<^sub>M =HIDDENR1 lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M"
     sorry
  thus "(f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f)..FINSEQ-4K4 f =XBOOLE-0R4 lenFINSEQ-1K4 f"
     sorry
qed "sorry"

mtheorem finseq_6_th_167:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds f /^RFINSEQK2\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f =FINSEQ-1R1 {}XBOOLE-0K1"
  using rfinseq_th_27 sorry

mtheorem finseq_6_th_168:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be  non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M3-of D holds f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f inTARSKIR2 rngFUNCT-1K2 f"
proof(rule ballI,rule ballI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix f assume [ty]: "f be  non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M3-of D"
  have "lenFINSEQ-1K4 f inTARSKIR2 domFINSEQ-1K5 f"
    using finseq_5_th_6 sorry
  thus "f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f inTARSKIR2 rngFUNCT-1K2 f"
    using partfun2_th_2 sorry
qed "sorry"

syntax FINSEQ_6R3 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> o" (" _ just-once-valuesFINSEQ-6R3\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50)
translations "f just-once-valuesFINSEQ-6R3\<^bsub>(D)\<^esub> y" \<rightharpoonup> "f just-once-valuesFINSEQ-4R2 y"

mtheorem finseq_6_def_12:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FinSequenceFINSEQ-1M3-of D", "y be setHIDDENM2"
"redefine pred f just-once-valuesFINSEQ-6R3\<^bsub>(D)\<^esub> y means
   ex x be setHIDDENM2 st (x inTARSKIR2 domFINSEQ-1K5 f & y =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> x) & ( for z be setHIDDENM2 holds z inTARSKIR2 domFINSEQ-1K5 f & z <>HIDDENR2 x implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> z <>HIDDENR2 y)"
proof
(*compatibility*)
  show "f just-once-valuesFINSEQ-6R3\<^bsub>(D)\<^esub> y iff ( ex x be setHIDDENM2 st (x inTARSKIR2 domFINSEQ-1K5 f & y =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> x) & ( for z be setHIDDENM2 holds z inTARSKIR2 domFINSEQ-1K5 f & z <>HIDDENR2 x implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> z <>HIDDENR2 y))"
  proof-
    have "(f just-once-valuesFINSEQ-4R2 y implies ( ex x be setHIDDENM2 st x inTARSKIR2 domFINSEQ-1K5 f & (y =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> x & ( for z be setHIDDENM2 holds z inTARSKIR2 domFINSEQ-1K5 f & z <>HIDDENR2 x implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> z <>HIDDENR2 y)))) & (( ex x be setHIDDENM2 st (x inTARSKIR2 domFINSEQ-1K5 f & y =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> x) & ( for z be setHIDDENM2 holds z inTARSKIR2 domFINSEQ-1K5 f & z <>HIDDENR2 x implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> z <>HIDDENR2 y)) implies f just-once-valuesFINSEQ-4R2 y)"
    proof(rule conjMI,rule impI)
      show "f just-once-valuesFINSEQ-4R2 y implies ( ex x be setHIDDENM2 st x inTARSKIR2 domFINSEQ-1K5 f & (y =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> x & ( for z be setHIDDENM2 holds z inTARSKIR2 domFINSEQ-1K5 f & z <>HIDDENR2 x implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> z <>HIDDENR2 y)))"
      proof(rule impI)
        assume "f just-once-valuesFINSEQ-4R2 y"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A1: "x inHIDDENR3 domFINSEQ-1K5 f"and A2: "y =XBOOLE-0R4 f .FUNCT-1K1 x"and A3: " for z be objectHIDDENM1 holds z inHIDDENR3 domFINSEQ-1K5 f & z <>HIDDENR2 x implies f .FUNCT-1K1 z <>HIDDENR2 y"
          using finseq_4_th_7 sorry
        have 
          [ty]:"x be setHIDDENM2"
          using tarski_th_1 sorry
        show " ex x be setHIDDENM2 st x inTARSKIR2 domFINSEQ-1K5 f & (y =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> x & ( for z be setHIDDENM2 holds z inTARSKIR2 domFINSEQ-1K5 f & z <>HIDDENR2 x implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> z <>HIDDENR2 y))"
        proof(rule bexI[of _ "x"],rule conjMI,rule conjMI,rule ballI,rule impMI ,rule impI)
          show "x inTARSKIR2 domFINSEQ-1K5 f"
            using A1 sorry
          show "y =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> x"
            using A1 A2 partfun1_def_6 sorry
          fix z assume [ty]: "z be setHIDDENM2"
          assume A4: "z inTARSKIR2 domFINSEQ-1K5 f"
            and A5: "z <>HIDDENR2 x"
          have "f .FUNCT-1K1 z <>HIDDENR2 y"
            using A3 A4 A5 sorry
          thus "f /.PARTFUN1K7\<^bsub>(D)\<^esub> z <>HIDDENR2 y"
            using A4 partfun1_def_6 sorry
        qed "sorry"
      qed
      assume Given: " ex x be setHIDDENM2 st (x inTARSKIR2 domFINSEQ-1K5 f & y =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> x) & ( for z be setHIDDENM2 holds z inTARSKIR2 domFINSEQ-1K5 f & z <>HIDDENR2 x implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> z <>HIDDENR2 y)"
      then obtain x where
        [ty]:"x be setHIDDENM2" and 
        A6: "x inTARSKIR2 domFINSEQ-1K5 f"and A7: "y =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> x"and A8: " for z be setHIDDENM2 holds z inTARSKIR2 domFINSEQ-1K5 f & z <>HIDDENR2 x implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> z <>HIDDENR2 y"
         sorry
      have A9: " for z be objectHIDDENM1 holds z inHIDDENR3 domFINSEQ-1K5 f & z <>HIDDENR2 x implies f .FUNCT-1K1 z <>HIDDENR2 y"
      proof-
        have " for z be objectHIDDENM1 holds z inHIDDENR3 domFINSEQ-1K5 f & z <>HIDDENR2 x implies  not f .FUNCT-1K1 z <>HIDDENR2 y"
        proof(rule ballI,rule impMI ,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          assume A10: "z inHIDDENR3 domFINSEQ-1K5 f"
            and A11: "z <>HIDDENR2 x"
          have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> z <>HIDDENR2 y"
            using A8 A10 A11 sorry
          thus " not f .FUNCT-1K1 z <>HIDDENR2 y"
            using A10 partfun1_def_6 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have "y =XBOOLE-0R4 f .FUNCT-1K1 x"
        using A6 A7 partfun1_def_6 sorry
      thus "f just-once-valuesFINSEQ-4R2 y"
        using A6 A9 finseq_4_th_7 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finseq_6_th_169:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds f just-once-valuesFINSEQ-6R3\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f implies f -:FINSEQ-5K1\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f =FINSEQ-1R1 f"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds f just-once-valuesFINSEQ-6R3\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f implies f -:FINSEQ-5K1\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f =HIDDENR1 f"
  proof(rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "f just-once-valuesFINSEQ-6R3\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f"
    have "f -:FINSEQ-5K1\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f =HIDDENR1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> ((f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f)..FINSEQ-4K4 f)"
      using finseq_5_def_1 sorry
    also have "... = f  |FINSEQ-1K18\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f"
      using A1 finseq_6_th_166 sorry
    also have "... = f"
      using finseq_1_th_58 sorry
    finally show "f -:FINSEQ-5K1\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f =HIDDENR1 f"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_170:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds f just-once-valuesFINSEQ-6R3\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f implies f :-FINSEQ-5K2\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f*>"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds f just-once-valuesFINSEQ-6R3\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f implies f :-FINSEQ-5K2\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f =HIDDENR1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f*>"
  proof(rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "f just-once-valuesFINSEQ-6R3\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f"
    have "f :-FINSEQ-5K2\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f =HIDDENR1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> (f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f)..FINSEQ-4K4 f)"
      using finseq_5_def_2 sorry
    also have "... = (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f)"
      using A1 finseq_6_th_166 sorry
    also have "... = (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f*>)^FINSEQ-1K8 {}XBOOLE-0K1"
      using rfinseq_th_27 sorry
    also have "... = <*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f*>"
      using finseq_1_th_34 sorry
    finally show "f :-FINSEQ-5K2\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f =HIDDENR1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f*>"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_171:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
  proof(rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    have "lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =HIDDENR1 lenFINSEQ-1K4 ((<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f))"
      using finseq_5_def_2 sorry
    also have "... = lenFINSEQ-1K4 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>) +NAT-1K1 lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f)"
      using finseq_1_th_22 sorry
    also have "... = \<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f)"
      using finseq_1_th_39 sorry
    finally have "lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =HIDDENR1 \<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f)"
       sorry
    thus "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
      using nat_1_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_172:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) <=XXREAL-0R1 lenFINSEQ-1K4 f"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
  fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
  assume A1: "p inTARSKIR2 rngFUNCT-1K2 f"
  then have "\<one>\<^sub>M <=XXREAL-0R1 p ..FINSEQ-4K4 f"
    using finseq_4_th_21 sorry
  then have A2: "lenFINSEQ-1K4 f -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f"
    using xreal_1_th_10 sorry
  have "lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 (lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f)+XCMPLX-0K2 \<one>\<^sub>M"
    using A1 finseq_5_th_50 sorry
  then have "lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) -XCMPLX-0K6 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f"
     sorry
  thus "lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) <=XXREAL-0R1 lenFINSEQ-1K4 f"
    using A2 xreal_1_th_9 sorry
qed "sorry"

mtheorem finseq_6_th_173:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be circularFINSEQ-6V1\<^bsub>(D)\<^esub>\<bar> non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M3-of D holds RevFINSEQ-5K4\<^bsub>(D)\<^esub> f be circularFINSEQ-6V1\<^bsub>(D)\<^esub>"
proof(rule ballI,rule ballI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix f assume [ty]: "f be circularFINSEQ-6V1\<^bsub>(D)\<^esub>\<bar> non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M3-of D"
  have "RevFINSEQ-5K4\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =HIDDENR1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 (RevFINSEQ-5K4\<^bsub>(D)\<^esub> f)"
  proof-
    have "RevFINSEQ-5K4\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f"
      using finseq_5_th_65 sorry
    also have "... = f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
      using finseq_6_def_1 sorry
    also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f"
      using finseq_5_th_65 sorry
    also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 (RevFINSEQ-5K4\<^bsub>(D)\<^esub> f)"
      using finseq_5_def_3 sorry
    finally show "RevFINSEQ-5K4\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =HIDDENR1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 (RevFINSEQ-5K4\<^bsub>(D)\<^esub> f)"
       sorry
  qed
  thus "RevFINSEQ-5K4\<^bsub>(D)\<^esub> f be circularFINSEQ-6V1\<^bsub>(D)\<^esub>"
    using finseq_6_def_1 sorry
qed "sorry"

(*begin*)
reserve D for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve p for "ElementSUBSET-1M1-of D"
reserve f for "FinSequenceFINSEQ-1M3-of D"
mtheorem finseq_6_th_174:
" for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds (p inTARSKIR2 rngFUNCT-1K2 f & \<one>\<^sub>M <=XXREAL-0R1 i) & i <=XXREAL-0R1 lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) implies (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> ((i -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 p ..FINSEQ-4K4 f)"
proof-
  have " for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & (\<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)) implies (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> i =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> ((i -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 p ..FINSEQ-4K4 f)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f"
      and A2: "\<one>\<^sub>M <=XXREAL-0R1 i"
      and A3: "i <=XXREAL-0R1 lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
    have A4: "i inTARSKIR2 domFINSEQ-1K5 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
      using A2 A3 finseq_3_th_25 sorry
    have A5: "i =XBOOLE-0R4 (i -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
      using A2 xreal_1_th_235 sorry
    have "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) =FINSEQ-1R1 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
      using A1 finseq_6_def_2 sorry
    then have "(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> i =HIDDENR1 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> i"
      using A4 finseq_4_th_68 sorry
    also have "... = f /.PARTFUN1K7\<^bsub>(D)\<^esub> ((i -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 p ..FINSEQ-4K4 f)"
      using A1 A5 A4 finseq_5_th_52 sorry
    finally show "(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> i =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> ((i -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 p ..FINSEQ-4K4 f)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_175:
" for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds (p inTARSKIR2 rngFUNCT-1K2 f & p ..FINSEQ-4K4 f <=XXREAL-0R1 i) & i <=XXREAL-0R1 lenFINSEQ-1K4 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> ((i +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 p ..FINSEQ-4K4 f)"
proof-
  have " for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & (p ..FINSEQ-4K4 f <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 f) implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> ((i +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 p ..FINSEQ-4K4 f)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f"
      and A2: "p ..FINSEQ-4K4 f <=XXREAL-0R1 i"
      and A3: "i <=XXREAL-0R1 lenFINSEQ-1K4 f"
    have A4: "\<one>\<^sub>M +NAT-1K1 p ..FINSEQ-4K4 f <=XXREAL-0R1 i +NAT-1K1 \<one>\<^sub>M"
      using A2 xreal_1_th_6 sorry
    have "i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M"
      using A3 xreal_1_th_6 sorry
    then have "i <=XXREAL-0R1 i +NAT-1K1 \<one>\<^sub>M & (i +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 p ..FINSEQ-4K4 f <=XXREAL-0R1 (lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 p ..FINSEQ-4K4 f"
      using nat_1_th_11 xreal_1_th_9 sorry
    then have "(i +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 p ..FINSEQ-4K4 f <=XXREAL-0R1 (lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f)+XCMPLX-0K2 \<one>\<^sub>M"
      using A2 xreal_1_th_233 xxreal_0_th_2 sorry
    then have A5: "(i +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 p ..FINSEQ-4K4 f <=XXREAL-0R1 lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
      using A1 finseq_5_th_50 sorry
    have "(((i +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 p ..FINSEQ-4K4 f)-'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 p ..FINSEQ-4K4 f =HIDDENR1 (((i -'NAT-DK9 p ..FINSEQ-4K4 f)+NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 p ..FINSEQ-4K4 f"
      using A2 nat_d_th_38 sorry
    also have "... = (i -'NAT-DK9 p ..FINSEQ-4K4 f)+NAT-1K1 p ..FINSEQ-4K4 f"
      using nat_d_th_34 sorry
    also have "... = i"
      using A2 xreal_1_th_235 sorry
    finally have "(((i +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 p ..FINSEQ-4K4 f)-'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 p ..FINSEQ-4K4 f =HIDDENR1 i"
       sorry
    thus "f /.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> ((i +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 p ..FINSEQ-4K4 f)"
      using A1 A4 A5 finseq_6_th_174 nat_d_th_55 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_176:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    have A1: "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
      using finseq_6_th_171 sorry
    assume A2: "p inTARSKIR2 rngFUNCT-1K2 f"
    then have "p ..FINSEQ-4K4 f <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using finseq_4_th_21 sorry
    then obtain x where 
      [ty]:"x be ElementSUBSET-1M1-of NATNUMBERSK1" and xDef:"x = lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f"
      using int_1_th_5 sorry
    have "(lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 p ..FINSEQ-4K4 f =HIDDENR1 ((x +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 p ..FINSEQ-4K4 f"
      using A2 finseq_5_th_50 sorry
    also have "... = (lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f)+XCMPLX-0K2 p ..FINSEQ-4K4 f"
      using nat_d_th_34 sorry
    also have "... = lenFINSEQ-1K4 f"
       sorry
    finally have "(lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 p ..FINSEQ-4K4 f =HIDDENR1 lenFINSEQ-1K4 f"
       sorry
    thus "(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f"
      using A1 A2 finseq_6_th_174 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma finseq_6_lm_11:
" for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds j <XXREAL-0R3 i implies (i -'NAT-DK9 (j +NAT-1K1 \<one>\<^sub>M))+NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 i -'NAT-DK9 j"
proof-
  have " for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds j <XXREAL-0R3 i implies (i -'NAT-DK9 (j +NAT-1K1 \<one>\<^sub>M))+NAT-1K1 \<one>\<^sub>M =HIDDENR1 i -'NAT-DK9 j"
  proof(rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix j assume [ty]: "j be NatNAT-1M1"
    assume A1: "j <XXREAL-0R3 i"
    then have "j +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i"
      using nat_1_th_13 sorry
    then have "(i -'NAT-DK9 (j +NAT-1K1 \<one>\<^sub>M))+NAT-1K1 \<one>\<^sub>M =HIDDENR1 (i -XCMPLX-0K6 (j +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<one>\<^sub>M"
      using xreal_1_th_233 sorry
    also have "... = i -XCMPLX-0K6 j"
       sorry
    also have "... = i -'NAT-DK9 j"
      using A1 xreal_1_th_233 sorry
    finally show "(i -'NAT-DK9 (j +NAT-1K1 \<one>\<^sub>M))+NAT-1K1 \<one>\<^sub>M =HIDDENR1 i -'NAT-DK9 j"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_177:
" for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds (p inTARSKIR2 rngFUNCT-1K2 f & lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) <XXREAL-0R3 i) & i <=XXREAL-0R1 lenFINSEQ-1K4 f implies (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> ((i +NAT-1K1 p ..FINSEQ-4K4 f)-'NAT-DK9 lenFINSEQ-1K4 f)"
proof-
  have " for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & (lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) <XXREAL-0R3 i & i <=XXREAL-0R1 lenFINSEQ-1K4 f) implies (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> i =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> ((i +NAT-1K1 p ..FINSEQ-4K4 f)-'NAT-DK9 lenFINSEQ-1K4 f)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f"
      and A2: "lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) <XXREAL-0R3 i"
      and A3: "i <=XXREAL-0R1 lenFINSEQ-1K4 f"
    have A4: "lenFINSEQ-1K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 p ..FINSEQ-4K4 f"
      using A1 finseq_5_th_42 sorry
    have A5: "(i -'NAT-DK9 lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p))+NAT-1K1 lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 i & RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) =FINSEQ-1R1 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
      using A1 A2 finseq_6_def_2 xreal_1_th_235 sorry
    have "f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p be  non emptyXBOOLE-0V1"
      using A1 finseq_5_th_47 sorry
    then have "lenFINSEQ-1K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) >=XXREAL-0R2 \<one>\<^sub>M"
      using nat_1_th_14 sorry
    then have A6: "lenFINSEQ-1K4 ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) =XBOOLE-0R4 lenFINSEQ-1K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) -XCMPLX-0K6 \<one>\<^sub>M"
      using rfinseq_def_1 sorry
    have "i +NAT-1K1 p ..FINSEQ-4K4 f <=XXREAL-0R1 p ..FINSEQ-4K4 f +NAT-1K1 lenFINSEQ-1K4 f"
      using A3 xreal_1_th_6 sorry
    then have A7: "(i +NAT-1K1 p ..FINSEQ-4K4 f)-'NAT-DK9 lenFINSEQ-1K4 f <=XXREAL-0R1 p ..FINSEQ-4K4 f"
      using nat_d_th_53 sorry
    have A8: "p ..FINSEQ-4K4 f <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A1 finseq_4_th_21 sorry
    then have "lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f =XBOOLE-0R4 lenFINSEQ-1K4 f -'NAT-DK9 p ..FINSEQ-4K4 f"
      using xreal_1_th_233 sorry
    then have A9: "lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 (lenFINSEQ-1K4 f -'NAT-DK9 p ..FINSEQ-4K4 f)+NAT-1K1 \<one>\<^sub>M"
      using A1 finseq_5_th_50 sorry
    then have A10: "lenFINSEQ-1K4 f -'NAT-DK9 p ..FINSEQ-4K4 f <XXREAL-0R3 i"
      using A2 nat_1_th_13 sorry
    then have A11: "lenFINSEQ-1K4 f <XXREAL-0R3 i +NAT-1K1 p ..FINSEQ-4K4 f"
      using nat_d_th_55 sorry
    then have "lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i +NAT-1K1 p ..FINSEQ-4K4 f"
      using nat_1_th_13 sorry
    then have "\<one>\<^sub>M <=XXREAL-0R1 (i +NAT-1K1 p ..FINSEQ-4K4 f)-'NAT-DK9 lenFINSEQ-1K4 f"
      using nat_d_th_55 sorry
    then have A12: "(i +NAT-1K1 p ..FINSEQ-4K4 f)-'NAT-DK9 lenFINSEQ-1K4 f inTARSKIR2 SegFINSEQ-1K2 (p ..FINSEQ-4K4 f)"
      using A7 sorry
    have "i <=XXREAL-0R1 p ..FINSEQ-4K4 f +NAT-1K1 (lenFINSEQ-1K4 f -'NAT-DK9 p ..FINSEQ-4K4 f)"
      using A3 A8 xreal_1_th_235 sorry
    then have "i -'NAT-DK9 (lenFINSEQ-1K4 f -'NAT-DK9 p ..FINSEQ-4K4 f) <=XXREAL-0R1 p ..FINSEQ-4K4 f"
      using nat_d_th_53 sorry
    then have "(i -'NAT-DK9 ((lenFINSEQ-1K4 f -'NAT-DK9 p ..FINSEQ-4K4 f)+NAT-1K1 \<one>\<^sub>M))+NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 p ..FINSEQ-4K4 f"
      using A10 finseq_6_lm_11 sorry
    then have A13: "i -'NAT-DK9 lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) <=XXREAL-0R1 lenFINSEQ-1K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) -XCMPLX-0K6 \<one>\<^sub>M"
      using A9 A4 xreal_1_th_19 sorry
    have "((lenFINSEQ-1K4 f -'NAT-DK9 p ..FINSEQ-4K4 f)+NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i"
      using A2 A9 nat_1_th_13 sorry
    then have A14: "\<one>\<^sub>M <=XXREAL-0R1 i -'NAT-DK9 ((lenFINSEQ-1K4 f -'NAT-DK9 p ..FINSEQ-4K4 f)+NAT-1K1 \<one>\<^sub>M)"
      using nat_d_th_55 sorry
    then have A15: "i -'NAT-DK9 ((lenFINSEQ-1K4 f -'NAT-DK9 p ..FINSEQ-4K4 f)+NAT-1K1 \<one>\<^sub>M) inTARSKIR2 domFINSEQ-1K5 ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
      using A9 A6 A13 finseq_3_th_25 sorry
    have "lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f =XBOOLE-0R4 lenFINSEQ-1K4 f -'NAT-DK9 p ..FINSEQ-4K4 f"
      using A8 xreal_1_th_233 sorry
    then have "\<one>\<^sub>M <=XXREAL-0R1 i -'NAT-DK9 lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
      using A1 A14 finseq_5_th_50 sorry
    then have "i -'NAT-DK9 lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) inTARSKIR2 domFINSEQ-1K5 ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
      using A6 A13 finseq_3_th_25 sorry
    then have "(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> i =HIDDENR1 ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)/.PARTFUN1K7\<^bsub>(D)\<^esub> (i -'NAT-DK9 ((lenFINSEQ-1K4 f -'NAT-DK9 p ..FINSEQ-4K4 f)+NAT-1K1 \<one>\<^sub>M))"
      using A9 A5 finseq_4_th_69 sorry
    also have "... = (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> ((i -'NAT-DK9 ((lenFINSEQ-1K4 f -'NAT-DK9 p ..FINSEQ-4K4 f)+NAT-1K1 \<one>\<^sub>M))+NAT-1K1 \<one>\<^sub>M)"
      using A15 finseq_5_th_27 sorry
    also have "... = (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> (i -'NAT-DK9 (lenFINSEQ-1K4 f -'NAT-DK9 p ..FINSEQ-4K4 f))"
      using A10 finseq_6_lm_11 sorry
    also have "... = (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> (i -XCMPLX-0K6 (lenFINSEQ-1K4 f -'NAT-DK9 p ..FINSEQ-4K4 f))"
      using A10 xreal_1_th_233 sorry
    also have "... = (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> (i -XCMPLX-0K6 (lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f))"
      using A8 xreal_1_th_233 sorry
    also have "... = (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> ((i +NAT-1K1 p ..FINSEQ-4K4 f)-XCMPLX-0K6 lenFINSEQ-1K4 f)"
       sorry
    also have "... = (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> ((i +NAT-1K1 p ..FINSEQ-4K4 f)-'NAT-DK9 lenFINSEQ-1K4 f)"
      using A11 xreal_1_th_233 sorry
    also have "... = f /.PARTFUN1K7\<^bsub>(D)\<^esub> ((i +NAT-1K1 p ..FINSEQ-4K4 f)-'NAT-DK9 lenFINSEQ-1K4 f)"
      using A1 A12 finseq_5_th_43 sorry
    finally show "(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> i =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> ((i +NAT-1K1 p ..FINSEQ-4K4 f)-'NAT-DK9 lenFINSEQ-1K4 f)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_178:
" for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds (p inTARSKIR2 rngFUNCT-1K2 f & \<one>\<^sub>M <XXREAL-0R3 i) & i <=XXREAL-0R1 p ..FINSEQ-4K4 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> ((i +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 p ..FINSEQ-4K4 f)"
proof-
  have " for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & (\<one>\<^sub>M <XXREAL-0R3 i & i <=XXREAL-0R1 p ..FINSEQ-4K4 f) implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> ((i +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 p ..FINSEQ-4K4 f)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f"
      and A2: "\<one>\<^sub>M <XXREAL-0R3 i"
      and A3: "i <=XXREAL-0R1 p ..FINSEQ-4K4 f"
    have A4: "lenFINSEQ-1K4 f -'NAT-DK9 p ..FINSEQ-4K4 f <=XXREAL-0R1 lenFINSEQ-1K4 f -'NAT-DK9 i"
      using A3 nat_d_th_41 sorry
    have A5: "p ..FINSEQ-4K4 f <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A1 finseq_4_th_21 sorry
    then have "i <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A3 xxreal_0_th_2 sorry
    then have "(lenFINSEQ-1K4 f -'NAT-DK9 p ..FINSEQ-4K4 f)+XCMPLX-0K2 i <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A4 nat_d_th_54 sorry
    then have A6: "(i +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 p ..FINSEQ-4K4 f <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A5 nat_d_th_38 sorry
    have "lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 i +NAT-1K1 lenFINSEQ-1K4 f"
      using A2 xreal_1_th_6 sorry
    then have "(lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 p ..FINSEQ-4K4 f <XXREAL-0R3 (i +NAT-1K1 lenFINSEQ-1K4 f)-XCMPLX-0K6 p ..FINSEQ-4K4 f"
      using xreal_1_th_9 sorry
    then have "(lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f)+XCMPLX-0K2 \<one>\<^sub>M <XXREAL-0R3 i +XCMPLX-0K2 (lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f)"
       sorry
    then have "(lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f)+XCMPLX-0K2 \<one>\<^sub>M <XXREAL-0R3 i +NAT-1K1 (lenFINSEQ-1K4 f -'NAT-DK9 p ..FINSEQ-4K4 f)"
      using A5 xreal_1_th_233 sorry
    then have "(lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f)+XCMPLX-0K2 \<one>\<^sub>M <XXREAL-0R3 (i +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 p ..FINSEQ-4K4 f"
      using A5 nat_d_th_38 sorry
    then have A7: "lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) <XXREAL-0R3 (i +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 p ..FINSEQ-4K4 f"
      using A1 finseq_5_th_50 sorry
    have "lenFINSEQ-1K4 f <=XXREAL-0R1 i +NAT-1K1 lenFINSEQ-1K4 f"
      using nat_1_th_11 sorry
    then have "(((i +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 p ..FINSEQ-4K4 f)+NAT-1K1 p ..FINSEQ-4K4 f)-'NAT-DK9 lenFINSEQ-1K4 f =HIDDENR1 (i +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 lenFINSEQ-1K4 f"
      using A5 xreal_1_th_235 xxreal_0_th_2 sorry
    also have "... = i"
      using nat_d_th_34 sorry
    finally have "(((i +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 p ..FINSEQ-4K4 f)+NAT-1K1 p ..FINSEQ-4K4 f)-'NAT-DK9 lenFINSEQ-1K4 f =HIDDENR1 i"
       sorry
    thus "f /.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> ((i +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 p ..FINSEQ-4K4 f)"
      using A1 A7 A6 finseq_6_th_177 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_179:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds lenFINSEQ-1K4 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)) =XBOOLE-0R4 lenFINSEQ-1K4 f"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds lenFINSEQ-1K4 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)) =XBOOLE-0R4 lenFINSEQ-1K4 f"
  proof(rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    show "lenFINSEQ-1K4 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)) =XBOOLE-0R4 lenFINSEQ-1K4 f"
    proof-
      have cases: " not p inTARSKIR2 rngFUNCT-1K2 f or p inTARSKIR2 rngFUNCT-1K2 f"
         sorry
      have case1: " not p inTARSKIR2 rngFUNCT-1K2 f implies lenFINSEQ-1K4 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)) =XBOOLE-0R4 lenFINSEQ-1K4 f"
      proof(rule impI)
        assume " not p inTARSKIR2 rngFUNCT-1K2 f"
        thus "lenFINSEQ-1K4 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)) =XBOOLE-0R4 lenFINSEQ-1K4 f"
          using finseq_6_def_2 sorry
      qed
      have case2: "p inTARSKIR2 rngFUNCT-1K2 f implies lenFINSEQ-1K4 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)) =HIDDENR1 lenFINSEQ-1K4 f"
      proof(rule impI)
        assume A1: "p inTARSKIR2 rngFUNCT-1K2 f"
        then have "f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p <>HIDDENR2 {}XBOOLE-0K1"
          using finseq_5_th_47 sorry
        then have A2: "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)"
          using nat_1_th_14 sorry
        have "lenFINSEQ-1K4 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)) =HIDDENR1 lenFINSEQ-1K4 ((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M))"
          using A1 finseq_6_def_2 sorry
        also have "... = lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) +NAT-1K1 lenFINSEQ-1K4 ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using finseq_1_th_22 sorry
        also have "... = lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) +XCMPLX-0K2 (lenFINSEQ-1K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) -XCMPLX-0K6 \<one>\<^sub>M)"
          using A2 rfinseq_def_1 sorry
        also have "... = (lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) +NAT-1K1 lenFINSEQ-1K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p))-XCMPLX-0K6 \<one>\<^sub>M"
           sorry
        also have "... = (((lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f)+XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 lenFINSEQ-1K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p))-XCMPLX-0K6 \<one>\<^sub>M"
          using A1 finseq_5_th_50 sorry
        also have "... = (lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f)+XCMPLX-0K2 lenFINSEQ-1K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)"
           sorry
        also have "... = (lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f)+XCMPLX-0K2 p ..FINSEQ-4K4 f"
          using A1 finseq_5_th_42 sorry
        also have "... = lenFINSEQ-1K4 f"
           sorry
        finally show "lenFINSEQ-1K4 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)) =HIDDENR1 lenFINSEQ-1K4 f"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_180:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds domFINSEQ-1K5 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)) =XBOOLE-0R4 domFINSEQ-1K5 f"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds domFINSEQ-1K5 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)) =XBOOLE-0R4 domFINSEQ-1K5 f"
  proof(rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    have "lenFINSEQ-1K4 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)) =XBOOLE-0R4 lenFINSEQ-1K4 f"
      using finseq_6_th_179 sorry
    thus "domFINSEQ-1K5 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)) =XBOOLE-0R4 domFINSEQ-1K5 f"
      using finseq_3_th_29 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_181:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be circularFINSEQ-6V1\<^bsub>(D)\<^esub>\<bar>FinSequenceFINSEQ-1M3-of D holds  for p be ElementSUBSET-1M1-of D holds ( for i be NatNAT-1M1 holds \<one>\<^sub>M <XXREAL-0R3 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> i <>HIDDENR2 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M) implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p),f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M) =FINSEQ-1R1 f"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be circularFINSEQ-6V1\<^bsub>(D)\<^esub>\<bar>FinSequenceFINSEQ-1M3-of D holds  for p be ElementSUBSET-1M1-of D holds ( for i be NatNAT-1M1 holds \<one>\<^sub>M <XXREAL-0R3 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> i <>HIDDENR2 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M) implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p),f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M) =HIDDENR1 f"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be circularFINSEQ-6V1\<^bsub>(D)\<^esub>\<bar>FinSequenceFINSEQ-1M3-of D"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    assume A1: " for i be NatNAT-1M1 holds \<one>\<^sub>M <XXREAL-0R3 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> i <>HIDDENR2 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
    show "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p),f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M) =HIDDENR1 f"
    proof-
      have cases: "( not p inTARSKIR2 rngFUNCT-1K2 f or p =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M) or p inTARSKIR2 rngFUNCT-1K2 f & p <>HIDDENR2 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
         sorry
      have case1: " not p inTARSKIR2 rngFUNCT-1K2 f implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p),f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M) =HIDDENR1 f"
      proof(rule impI)
        assume " not p inTARSKIR2 rngFUNCT-1K2 f"
        then have "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p),f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M) =HIDDENR1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using finseq_6_def_2 sorry
        also have "... = f"
          using finseq_6_th_89 sorry
        finally show "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p),f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M) =HIDDENR1 f"
           sorry
      qed
      have case2: "p =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p),f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M) =HIDDENR1 f"
      proof(rule impI)
        assume "p =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
        then have "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p),f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M) =HIDDENR1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using finseq_6_th_93 sorry
        also have "... = f"
          using finseq_6_th_89 sorry
        finally show "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p),f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M) =HIDDENR1 f"
           sorry
      qed
      have case3: "p inTARSKIR2 rngFUNCT-1K2 f & p <>HIDDENR2 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p),f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M) =HIDDENR1 f"
      proof(rule impMI ,rule impI)
        assume A2: "p inTARSKIR2 rngFUNCT-1K2 f"
          and A3: "p <>HIDDENR2 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
        have A4: "f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
          using A2 finseq_5_th_44 sorry
        have A5: "f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f"
          using finseq_6_def_1 sorry
        then have A6: "f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
          using A2 finseq_5_th_54 sorry
        then have A7: "f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M inTARSKIR2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
          using finseq_6_th_168 sorry
        have A8: "f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p just-once-valuesFINSEQ-6R3\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
        proof-
          have "p ..FINSEQ-4K4 f <>HIDDENR2 \<one>\<^sub>M & p ..FINSEQ-4K4 f >=XXREAL-0R2 \<one>\<^sub>M"
            using A2 A3 finseq_4_th_21 finseq_5_th_38 sorry
          then have A9: "p ..FINSEQ-4K4 f >XXREAL-0R4 \<one>\<^sub>M"
            using xxreal_0_th_1 sorry
          have "lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) inTARSKIR2 domFINSEQ-1K5 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) & (f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) & ( for z be setHIDDENM2 holds z inTARSKIR2 domFINSEQ-1K5 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) implies (z <>HIDDENR2 lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) implies  not (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> z <>HIDDENR2 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M)))"
          proof(rule conjMI,rule conjMI,rule ballI,rule impI,rule impI)
            show "lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) inTARSKIR2 domFINSEQ-1K5 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
              using finseq_5_th_6 sorry
            show "f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
              using A2 A5 finseq_5_th_54 sorry
            fix z assume [ty]: "z be setHIDDENM2"
            assume A10: "z inTARSKIR2 domFINSEQ-1K5 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
            then obtain k where 
              [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = z"
               sorry
            have "k <>HIDDENR2 0NUMBERSK6"
              using A10 finseq_3_th_25 sorry
            then obtain i where
              [ty]:"i be NatNAT-1M1" and 
              A11: "k =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M"
              using nat_1_th_6 sorry
            assume A12: "z <>HIDDENR2 lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
            have 
              [ty]:"i be ElementSUBSET-1M1-of NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "k <=XXREAL-0R1 lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
              using A10 finseq_3_th_25 sorry
            then have "k <XXREAL-0R3 lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
              using A12 xxreal_0_th_1 sorry
            then have "i +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 (lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f)+XCMPLX-0K2 \<one>\<^sub>M"
              using A2 A11 finseq_5_th_50 sorry
            then have "i <XXREAL-0R3 lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f"
              using xreal_1_th_6 sorry
            then have A13: "i +NAT-1K1 p ..FINSEQ-4K4 f <XXREAL-0R3 lenFINSEQ-1K4 f"
              using xreal_1_th_20 sorry
            have "p ..FINSEQ-4K4 f <=XXREAL-0R1 i +NAT-1K1 p ..FINSEQ-4K4 f"
              using nat_1_th_11 sorry
            then have A14: "\<one>\<^sub>M <XXREAL-0R3 i +NAT-1K1 p ..FINSEQ-4K4 f"
              using A9 xxreal_0_th_2 sorry
            have "(f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> (i +NAT-1K1 p ..FINSEQ-4K4 f)"
              using A2 A10 A11 finseq_5_th_52 sorry
            thus " not (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> z <>HIDDENR2 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
              using A1 A11 A14 A13 sorry
          qed "sorry"
          thus "f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p just-once-valuesFINSEQ-6R3\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
            using bexI[of _ "lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"] finseq_6_def_12 sorry
        qed
        have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M inTARSKIR2 rngFUNCT-1K2 f"
          using A2 finseq_6_th_42 relat_1_th_38 sorry
        then have A15: "f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M inTARSKIR2 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
          using A2 finseq_6_th_90 sorry
        have "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) =FINSEQ-1R1 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using A2 finseq_6_def_2 sorry
        then have "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p),f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M) =HIDDENR1 (((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)):-FINSEQ-5K2\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M))-:FINSEQ-5K1\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using A15 finseq_6_def_2 sorry
        also have "... = (((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p):-FINSEQ-5K2\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M))^FINSEQ-1K9\<^bsub>(D)\<^esub> ((((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M))-:FINSEQ-5K1\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using A7 finseq_6_th_64 sorry
        also have "... = (((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p):-FINSEQ-5K2\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M))^FINSEQ-1K9\<^bsub>(D)\<^esub> (((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)-:FINSEQ-5K1\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using A7 finseq_6_th_66 sorry
        also have "... = ((<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M))^FINSEQ-1K9\<^bsub>(D)\<^esub> (((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)-:FINSEQ-5K1\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using A6 A8 finseq_6_th_170 sorry
        also have "... = (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)^FINSEQ-1K9\<^bsub>(D)\<^esub> (((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)-:FINSEQ-5K1\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using A2 A4 finseq_5_th_29 finseq_5_th_47 sorry
        also have "... = (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
          using A6 A8 finseq_6_th_169 sorry
        also have "... = f"
          using A2 finseq_6_th_76 sorry
        finally show "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p),f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M) =HIDDENR1 f"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
reserve f for "circularFINSEQ-6V1\<^bsub>(D)\<^esub>\<bar>FinSequenceFINSEQ-1M3-of D"
mtheorem finseq_6_th_182:
" for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be circularFINSEQ-6V1\<^bsub>(D)\<^esub>\<bar>FinSequenceFINSEQ-1M3-of D holds (p inTARSKIR2 rngFUNCT-1K2 f & lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) <=XXREAL-0R1 i) & i <=XXREAL-0R1 lenFINSEQ-1K4 f implies (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> ((i +NAT-1K1 p ..FINSEQ-4K4 f)-'NAT-DK9 lenFINSEQ-1K4 f)"
proof-
  have " for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be circularFINSEQ-6V1\<^bsub>(D)\<^esub>\<bar>FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & (lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 f) implies (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> i =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> ((i +NAT-1K1 p ..FINSEQ-4K4 f)-'NAT-DK9 lenFINSEQ-1K4 f)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be circularFINSEQ-6V1\<^bsub>(D)\<^esub>\<bar>FinSequenceFINSEQ-1M3-of D"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f"
      and A2: "lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) <=XXREAL-0R1 i"
      and A3: "i <=XXREAL-0R1 lenFINSEQ-1K4 f"
    have A4: "p ..FINSEQ-4K4 f <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A1 finseq_4_th_21 sorry
    then have A5: "lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f =XBOOLE-0R4 lenFINSEQ-1K4 f -'NAT-DK9 p ..FINSEQ-4K4 f"
      using xreal_1_th_233 sorry
    show "(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> i =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> ((i +NAT-1K1 p ..FINSEQ-4K4 f)-'NAT-DK9 lenFINSEQ-1K4 f)"
    proof-
      have cases: "i =XBOOLE-0R4 lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) or i >XXREAL-0R4 lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
        using A2 xxreal_0_th_1 sorry
      have case1: "i =XBOOLE-0R4 lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) implies (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> i =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> ((i +NAT-1K1 p ..FINSEQ-4K4 f)-'NAT-DK9 lenFINSEQ-1K4 f)"
      proof(rule impI)
        assume A6: "i =XBOOLE-0R4 lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
        then have A7: "i =XBOOLE-0R4 (lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f)+XCMPLX-0K2 \<one>\<^sub>M"
          using A1 finseq_5_th_50 sorry
        then have "i >=XXREAL-0R2 \<one>\<^sub>M"
          using A5 nat_1_th_11 sorry
        then have "(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> i =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> ((i -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 p ..FINSEQ-4K4 f)"
          using A1 A6 finseq_6_th_174 sorry
        also have "... = f /.PARTFUN1K7\<^bsub>(D)\<^esub> ((lenFINSEQ-1K4 f -'NAT-DK9 p ..FINSEQ-4K4 f)+NAT-1K1 p ..FINSEQ-4K4 f)"
          using A5 A7 nat_d_th_34 sorry
        also have "... = f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f"
          using A4 xreal_1_th_235 sorry
        also have "... = f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
          using finseq_6_def_1 sorry
        also have "... = f /.PARTFUN1K7\<^bsub>(D)\<^esub> ((lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 lenFINSEQ-1K4 f)"
          using nat_d_th_34 sorry
        also have "... = f /.PARTFUN1K7\<^bsub>(D)\<^esub> ((i +NAT-1K1 p ..FINSEQ-4K4 f)-'NAT-DK9 lenFINSEQ-1K4 f)"
          using A7 sorry
        finally show "(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> i =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> ((i +NAT-1K1 p ..FINSEQ-4K4 f)-'NAT-DK9 lenFINSEQ-1K4 f)"
           sorry
      qed
      have case2: "i >XXREAL-0R4 lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) implies (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> ((i +NAT-1K1 p ..FINSEQ-4K4 f)-'NAT-DK9 lenFINSEQ-1K4 f)"
      proof(rule impI)
        assume "i >XXREAL-0R4 lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
        thus "(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> ((i +NAT-1K1 p ..FINSEQ-4K4 f)-'NAT-DK9 lenFINSEQ-1K4 f)"
          using A1 A3 finseq_6_th_177 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_th_183:
" for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be circularFINSEQ-6V1\<^bsub>(D)\<^esub>\<bar>FinSequenceFINSEQ-1M3-of D holds (p inTARSKIR2 rngFUNCT-1K2 f & \<one>\<^sub>M <=XXREAL-0R1 i) & i <=XXREAL-0R1 p ..FINSEQ-4K4 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> ((i +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 p ..FINSEQ-4K4 f)"
proof-
  have " for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be circularFINSEQ-6V1\<^bsub>(D)\<^esub>\<bar>FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & (\<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 p ..FINSEQ-4K4 f) implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> ((i +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 p ..FINSEQ-4K4 f)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be circularFINSEQ-6V1\<^bsub>(D)\<^esub>\<bar>FinSequenceFINSEQ-1M3-of D"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f"
      and A2: "\<one>\<^sub>M <=XXREAL-0R1 i"
      and A3: "i <=XXREAL-0R1 p ..FINSEQ-4K4 f"
    have A4: "lenFINSEQ-1K4 f -'NAT-DK9 p ..FINSEQ-4K4 f <=XXREAL-0R1 lenFINSEQ-1K4 f -'NAT-DK9 i"
      using A3 nat_d_th_41 sorry
    have A5: "p ..FINSEQ-4K4 f <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A1 finseq_4_th_21 sorry
    then have "i <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A3 xxreal_0_th_2 sorry
    then have "(lenFINSEQ-1K4 f -'NAT-DK9 p ..FINSEQ-4K4 f)+XCMPLX-0K2 i <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A4 nat_d_th_54 sorry
    then have A6: "(i +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 p ..FINSEQ-4K4 f <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A5 nat_d_th_38 sorry
    have "lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i +NAT-1K1 lenFINSEQ-1K4 f"
      using A2 xreal_1_th_6 sorry
    then have "(lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 p ..FINSEQ-4K4 f <=XXREAL-0R1 (i +NAT-1K1 lenFINSEQ-1K4 f)-XCMPLX-0K6 p ..FINSEQ-4K4 f"
      using xreal_1_th_9 sorry
    then have "(lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f)+XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 i +XCMPLX-0K2 (lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f)"
       sorry
    then have "(lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f)+XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 i +NAT-1K1 (lenFINSEQ-1K4 f -'NAT-DK9 p ..FINSEQ-4K4 f)"
      using A5 xreal_1_th_233 sorry
    then have "(lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f)+XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 (i +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 p ..FINSEQ-4K4 f"
      using A5 nat_d_th_38 sorry
    then have A7: "lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) <=XXREAL-0R1 (i +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 p ..FINSEQ-4K4 f"
      using A1 finseq_5_th_50 sorry
    have "lenFINSEQ-1K4 f <=XXREAL-0R1 i +NAT-1K1 lenFINSEQ-1K4 f"
      using nat_1_th_11 sorry
    then have "(((i +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 p ..FINSEQ-4K4 f)+NAT-1K1 p ..FINSEQ-4K4 f)-'NAT-DK9 lenFINSEQ-1K4 f =HIDDENR1 (i +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 lenFINSEQ-1K4 f"
      using A5 xreal_1_th_235 xxreal_0_th_2 sorry
    also have "... = i"
      using nat_d_th_34 sorry
    finally have "(((i +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 p ..FINSEQ-4K4 f)+NAT-1K1 p ..FINSEQ-4K4 f)-'NAT-DK9 lenFINSEQ-1K4 f =HIDDENR1 i"
       sorry
    thus "f /.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> ((i +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 p ..FINSEQ-4K4 f)"
      using A1 A7 A6 finseq_6_th_182 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_6_cl_10:
  mlet "D be  non trivialZFMISC-1V1\<bar>setHIDDENM2"
"cluster  non constantFUNCT-1V5\<bar>circularFINSEQ-6V1\<^bsub>(D)\<^esub> for FinSequenceFINSEQ-1M3-of D"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M3-of D st it be  non constantFUNCT-1V5\<bar>circularFINSEQ-6V1\<^bsub>(D)\<^esub>"
  proof-
    have " ex f be FinSequenceFINSEQ-1M3-of D st  not f be constantFUNCT-1V5 & f be circularFINSEQ-6V1\<^bsub>(D)\<^esub>"
    proof-
      obtain d1 d2 where
        [ty]:"d1 be ElementSUBSET-1M1-of D" "d2 be ElementSUBSET-1M1-of D" and 
        A1: "d1 <>HIDDENR2 d2"
        using subset_1_def_7 sorry
      obtain f where 
        [ty]:"f be FinSequenceFINSEQ-1M3-of D" and fDef:"f = <*FINSEQ-4K3\<^bsub>(D)\<^esub> d1,d2,d1 *>"
         sorry
      show " ex f be FinSequenceFINSEQ-1M3-of D st  not f be constantFUNCT-1V5 & f be circularFINSEQ-6V1\<^bsub>(D)\<^esub>"
      proof(rule bexI[of _ "f"],rule conjMI)
        have A2: "f .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 d1 & f .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 d2"
          using finseq_1_th_45 sorry
        have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f & \<two>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
          using finseq_1_th_81 sorry
        thus " not f be constantFUNCT-1V5"
          using A1 A2 sorry
        have A3: "lenFINSEQ-1K4 f =XBOOLE-0R4 \<three>\<^sub>M"
          using finseq_1_th_45 sorry
        have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f"
        proof-
          have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =HIDDENR1 d1"
            using finseq_4_th_18 sorry
          also have "... = f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f"
            using A3 finseq_4_th_18 sorry
          finally show "f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f"
             sorry
        qed
        thus "f be circularFINSEQ-6V1\<^bsub>(D)\<^esub>"
          using finseq_6_def_1 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finseq_6_cl_11:
  mlet "D be  non trivialZFMISC-1V1\<bar>setHIDDENM2", "p be ElementSUBSET-1M1-of D", "f be  non constantFUNCT-1V5\<bar>circularFINSEQ-6V1\<^bsub>(D)\<^esub>\<bar>FinSequenceFINSEQ-1M3-of D"
"cluster RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) as-term-is  non constantFUNCT-1V5"
proof
(*coherence*)
  show "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) be  non constantFUNCT-1V5"
  proof-
    have " not RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) be constantFUNCT-1V5"
    proof-
      show " not RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) be constantFUNCT-1V5"
      proof-
        have cases: " not p inTARSKIR2 rngFUNCT-1K2 f or p inTARSKIR2 rngFUNCT-1K2 f"
           sorry
        have case1: " not p inTARSKIR2 rngFUNCT-1K2 f implies  not RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) be constantFUNCT-1V5"
        proof(rule impI)
          assume " not p inTARSKIR2 rngFUNCT-1K2 f"
          thus " not RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) be constantFUNCT-1V5"
            using finseq_6_def_2 sorry
        qed
        have case2: "p inTARSKIR2 rngFUNCT-1K2 f implies  not RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) be constantFUNCT-1V5"
        proof(rule impI)
          assume A1: "p inTARSKIR2 rngFUNCT-1K2 f"
          have A2: "domFINSEQ-1K5 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)) =XBOOLE-0R4 domFINSEQ-1K5 f"
            using finseq_6_th_180 sorry
          obtain n m where
            [ty]:"n be NatNAT-1M1" "m be NatNAT-1M1" and 
            A3: "n inTARSKIR2 domFINSEQ-1K5 f"and A4: "m inTARSKIR2 domFINSEQ-1K5 f"and A5: "f /.PARTFUN1K7\<^bsub>(D)\<^esub> n <>HIDDENR2 f /.PARTFUN1K7\<^bsub>(D)\<^esub> m"
            using finseq_6_def_11 sorry
          have A6: "n <=XXREAL-0R1 lenFINSEQ-1K4 f"
            using A3 finseq_3_th_25 sorry
          have A7: "m <=XXREAL-0R1 lenFINSEQ-1K4 f"
            using A4 finseq_3_th_25 sorry
          have A8: "\<one>\<^sub>M <=XXREAL-0R1 m"
            using A4 finseq_3_th_25 sorry
          have A9: "\<one>\<^sub>M <=XXREAL-0R1 n"
            using A3 finseq_3_th_25 sorry
          show " not RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) be constantFUNCT-1V5"
          proof-
            have A10: "\<one>\<^sub>M <=XXREAL-0R1 p ..FINSEQ-4K4 f"
              using A1 finseq_4_th_21 sorry
            have A11: "p ..FINSEQ-4K4 f <=XXREAL-0R1 lenFINSEQ-1K4 f"
              using A1 finseq_4_th_21 sorry
            show " not RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) be constantFUNCT-1V5"
            proof-
              have cases: "((n <=XXREAL-0R1 p ..FINSEQ-4K4 f & m <=XXREAL-0R1 p ..FINSEQ-4K4 f or n <=XXREAL-0R1 p ..FINSEQ-4K4 f & m >=XXREAL-0R2 p ..FINSEQ-4K4 f) or m <=XXREAL-0R1 p ..FINSEQ-4K4 f & n >=XXREAL-0R2 p ..FINSEQ-4K4 f) or m >=XXREAL-0R2 p ..FINSEQ-4K4 f & n >=XXREAL-0R2 p ..FINSEQ-4K4 f"
                 sorry
              have case1: "n <=XXREAL-0R1 p ..FINSEQ-4K4 f & m <=XXREAL-0R1 p ..FINSEQ-4K4 f implies  not RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) be constantFUNCT-1V5"
              proof(rule impMI ,rule impI)
                assume A12: "n <=XXREAL-0R1 p ..FINSEQ-4K4 f"
                  and A13: "m <=XXREAL-0R1 p ..FINSEQ-4K4 f"
                have "n <=XXREAL-0R1 n +NAT-1K1 (lenFINSEQ-1K4 f -'NAT-DK9 p ..FINSEQ-4K4 f)"
                  using nat_1_th_11 sorry
                then have "\<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 (lenFINSEQ-1K4 f -'NAT-DK9 p ..FINSEQ-4K4 f)"
                  using A9 xxreal_0_th_2 sorry
                then have A14: "\<one>\<^sub>M <=XXREAL-0R1 (n +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 p ..FINSEQ-4K4 f"
                  using A11 nat_d_th_38 sorry
                have "m <=XXREAL-0R1 m +NAT-1K1 (lenFINSEQ-1K4 f -'NAT-DK9 p ..FINSEQ-4K4 f)"
                  using nat_1_th_11 sorry
                then have "\<one>\<^sub>M <=XXREAL-0R1 m +NAT-1K1 (lenFINSEQ-1K4 f -'NAT-DK9 p ..FINSEQ-4K4 f)"
                  using A8 xxreal_0_th_2 sorry
                then have A15: "\<one>\<^sub>M <=XXREAL-0R1 (m +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 p ..FINSEQ-4K4 f"
                  using A11 nat_d_th_38 sorry
                have "m +NAT-1K1 lenFINSEQ-1K4 f <=XXREAL-0R1 lenFINSEQ-1K4 f +NAT-1K1 p ..FINSEQ-4K4 f"
                  using A13 xreal_1_th_6 sorry
                then have "(m +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 p ..FINSEQ-4K4 f <=XXREAL-0R1 lenFINSEQ-1K4 f"
                  using nat_d_th_53 sorry
                then have A16: "(m +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 p ..FINSEQ-4K4 f inTARSKIR2 domFINSEQ-1K5 f"
                  using A15 finseq_3_th_25 sorry
                have "n +NAT-1K1 lenFINSEQ-1K4 f <=XXREAL-0R1 lenFINSEQ-1K4 f +NAT-1K1 p ..FINSEQ-4K4 f"
                  using A12 xreal_1_th_6 sorry
                then have "(n +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 p ..FINSEQ-4K4 f <=XXREAL-0R1 lenFINSEQ-1K4 f"
                  using nat_d_th_53 sorry
                then have A17: "(n +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 p ..FINSEQ-4K4 f inTARSKIR2 domFINSEQ-1K5 f"
                  using A14 finseq_3_th_25 sorry
                have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> n =XBOOLE-0R4 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> ((n +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 p ..FINSEQ-4K4 f) & f /.PARTFUN1K7\<^bsub>(D)\<^esub> m =XBOOLE-0R4 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> ((m +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 p ..FINSEQ-4K4 f)"
                  using A1 A9 A8 A12 A13 finseq_6_th_183 sorry
                thus " not RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) be constantFUNCT-1V5"
                  using A5 A2 A17 A16 sorry
              qed
              have case2: "n <=XXREAL-0R1 p ..FINSEQ-4K4 f & m >=XXREAL-0R2 p ..FINSEQ-4K4 f implies  not RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) be constantFUNCT-1V5"
              proof(rule impMI ,rule impI)
                assume A18: "n <=XXREAL-0R1 p ..FINSEQ-4K4 f"
                  and A19: "m >=XXREAL-0R2 p ..FINSEQ-4K4 f"
                have "\<one>\<^sub>M +NAT-1K1 p ..FINSEQ-4K4 f <=XXREAL-0R1 m +NAT-1K1 \<one>\<^sub>M"
                  using A19 xreal_1_th_6 sorry
                then have A20: "\<one>\<^sub>M <=XXREAL-0R1 (m +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 p ..FINSEQ-4K4 f"
                  using nat_d_th_55 sorry
                have "n <=XXREAL-0R1 n +NAT-1K1 (lenFINSEQ-1K4 f -'NAT-DK9 p ..FINSEQ-4K4 f)"
                  using nat_1_th_11 sorry
                then have "\<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 (lenFINSEQ-1K4 f -'NAT-DK9 p ..FINSEQ-4K4 f)"
                  using A9 xxreal_0_th_2 sorry
                then have A21: "\<one>\<^sub>M <=XXREAL-0R1 (n +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 p ..FINSEQ-4K4 f"
                  using A11 nat_d_th_38 sorry
                have "n +NAT-1K1 lenFINSEQ-1K4 f <=XXREAL-0R1 lenFINSEQ-1K4 f +NAT-1K1 p ..FINSEQ-4K4 f"
                  using A18 xreal_1_th_6 sorry
                then have "(n +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 p ..FINSEQ-4K4 f <=XXREAL-0R1 lenFINSEQ-1K4 f"
                  using nat_d_th_53 sorry
                then have A22: "(n +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 p ..FINSEQ-4K4 f inTARSKIR2 domFINSEQ-1K5 f"
                  using A21 finseq_3_th_25 sorry
                have "m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f +NAT-1K1 p ..FINSEQ-4K4 f"
                  using A7 A10 xreal_1_th_7 sorry
                then have "(m +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 p ..FINSEQ-4K4 f <=XXREAL-0R1 lenFINSEQ-1K4 f"
                  using nat_d_th_53 sorry
                then have A23: "(m +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 p ..FINSEQ-4K4 f inTARSKIR2 domFINSEQ-1K5 f"
                  using A20 finseq_3_th_25 sorry
                have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> n =XBOOLE-0R4 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> ((n +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 p ..FINSEQ-4K4 f) & f /.PARTFUN1K7\<^bsub>(D)\<^esub> m =XBOOLE-0R4 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> ((m +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 p ..FINSEQ-4K4 f)"
                  using A1 A9 A7 A18 A19 finseq_6_th_175 finseq_6_th_183 sorry
                thus " not RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) be constantFUNCT-1V5"
                  using A5 A2 A22 A23 sorry
              qed
              have case3: "m <=XXREAL-0R1 p ..FINSEQ-4K4 f & n >=XXREAL-0R2 p ..FINSEQ-4K4 f implies  not RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) be constantFUNCT-1V5"
              proof(rule impMI ,rule impI)
                assume A24: "m <=XXREAL-0R1 p ..FINSEQ-4K4 f"
                  and A25: "n >=XXREAL-0R2 p ..FINSEQ-4K4 f"
                have "\<one>\<^sub>M +NAT-1K1 p ..FINSEQ-4K4 f <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
                  using A25 xreal_1_th_6 sorry
                then have A26: "\<one>\<^sub>M <=XXREAL-0R1 (n +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 p ..FINSEQ-4K4 f"
                  using nat_d_th_55 sorry
                have "m <=XXREAL-0R1 m +NAT-1K1 (lenFINSEQ-1K4 f -'NAT-DK9 p ..FINSEQ-4K4 f)"
                  using nat_1_th_11 sorry
                then have "\<one>\<^sub>M <=XXREAL-0R1 m +NAT-1K1 (lenFINSEQ-1K4 f -'NAT-DK9 p ..FINSEQ-4K4 f)"
                  using A8 xxreal_0_th_2 sorry
                then have A27: "\<one>\<^sub>M <=XXREAL-0R1 (m +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 p ..FINSEQ-4K4 f"
                  using A11 nat_d_th_38 sorry
                have "m +NAT-1K1 lenFINSEQ-1K4 f <=XXREAL-0R1 lenFINSEQ-1K4 f +NAT-1K1 p ..FINSEQ-4K4 f"
                  using A24 xreal_1_th_6 sorry
                then have "(m +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 p ..FINSEQ-4K4 f <=XXREAL-0R1 lenFINSEQ-1K4 f"
                  using nat_d_th_53 sorry
                then have A28: "(m +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 p ..FINSEQ-4K4 f inTARSKIR2 domFINSEQ-1K5 f"
                  using A27 finseq_3_th_25 sorry
                have "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f +NAT-1K1 p ..FINSEQ-4K4 f"
                  using A6 A10 xreal_1_th_7 sorry
                then have "(n +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 p ..FINSEQ-4K4 f <=XXREAL-0R1 lenFINSEQ-1K4 f"
                  using nat_d_th_53 sorry
                then have A29: "(n +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 p ..FINSEQ-4K4 f inTARSKIR2 domFINSEQ-1K5 f"
                  using A26 finseq_3_th_25 sorry
                have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> m =XBOOLE-0R4 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> ((m +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 p ..FINSEQ-4K4 f) & f /.PARTFUN1K7\<^bsub>(D)\<^esub> n =XBOOLE-0R4 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 p ..FINSEQ-4K4 f)"
                  using A1 A6 A8 A24 A25 finseq_6_th_175 finseq_6_th_183 sorry
                thus " not RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) be constantFUNCT-1V5"
                  using A5 A2 A28 A29 sorry
              qed
              have case4: "m >=XXREAL-0R2 p ..FINSEQ-4K4 f & n >=XXREAL-0R2 p ..FINSEQ-4K4 f implies  not RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) be constantFUNCT-1V5"
              proof(rule impMI ,rule impI)
                assume A30: "m >=XXREAL-0R2 p ..FINSEQ-4K4 f"
                  and A31: "n >=XXREAL-0R2 p ..FINSEQ-4K4 f"
                have "\<one>\<^sub>M +NAT-1K1 p ..FINSEQ-4K4 f <=XXREAL-0R1 m +NAT-1K1 \<one>\<^sub>M"
                  using A30 xreal_1_th_6 sorry
                then have A32: "\<one>\<^sub>M <=XXREAL-0R1 (m +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 p ..FINSEQ-4K4 f"
                  using nat_d_th_55 sorry
                have "\<one>\<^sub>M +NAT-1K1 p ..FINSEQ-4K4 f <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
                  using A31 xreal_1_th_6 sorry
                then have A33: "\<one>\<^sub>M <=XXREAL-0R1 (n +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 p ..FINSEQ-4K4 f"
                  using nat_d_th_55 sorry
                have "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f +NAT-1K1 p ..FINSEQ-4K4 f"
                  using A6 A10 xreal_1_th_7 sorry
                then have "(n +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 p ..FINSEQ-4K4 f <=XXREAL-0R1 lenFINSEQ-1K4 f"
                  using nat_d_th_53 sorry
                then have A34: "(n +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 p ..FINSEQ-4K4 f inTARSKIR2 domFINSEQ-1K5 f"
                  using A33 finseq_3_th_25 sorry
                have "m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f +NAT-1K1 p ..FINSEQ-4K4 f"
                  using A7 A10 xreal_1_th_7 sorry
                then have "(m +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 p ..FINSEQ-4K4 f <=XXREAL-0R1 lenFINSEQ-1K4 f"
                  using nat_d_th_53 sorry
                then have A35: "(m +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 p ..FINSEQ-4K4 f inTARSKIR2 domFINSEQ-1K5 f"
                  using A32 finseq_3_th_25 sorry
                have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> m =XBOOLE-0R4 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> ((m +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 p ..FINSEQ-4K4 f) & f /.PARTFUN1K7\<^bsub>(D)\<^esub> n =XBOOLE-0R4 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 p ..FINSEQ-4K4 f)"
                  using A1 A6 A7 A30 A31 finseq_6_th_175 sorry
                thus " not RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) be constantFUNCT-1V5"
                  using A5 A2 A35 A34 sorry
              qed
              show " ?thesis "
                using cases case1 case2 case3 case4 sorry
            qed
          qed
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

end
