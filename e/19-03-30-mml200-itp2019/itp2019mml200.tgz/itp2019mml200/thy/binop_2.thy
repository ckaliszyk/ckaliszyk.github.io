theory binop_2
  imports setwiseo valued_0
   "../mizar_extension/E_number"
begin
(*begin*)
theorem binop_2_sch_1:
  fixes Cf0 Df0 Ff1 
  assumes
[ty]: "Cf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be ElementSUBSET-1M1-of Cf0 \<Longrightarrow> Ff1(x1) be objectHIDDENM1"
  shows " for f1 be FunctionFUNCT-2M1-of(Cf0,Df0) holds  for f2 be FunctionFUNCT-2M1-of(Cf0,Df0) holds ( for x be ElementSUBSET-1M1-of Cf0 holds f1 .FUNCT-2K3\<^bsub>(Cf0,Df0)\<^esub> x =HIDDENR1 Ff1(x)) & ( for x be ElementSUBSET-1M1-of Cf0 holds f2 .FUNCT-2K3\<^bsub>(Cf0,Df0)\<^esub> x =HIDDENR1 Ff1(x)) implies f1 =FUNCT-2R2\<^bsub>(Cf0,Df0)\<^esub> f2"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix f1 assume [ty]: "f1 be FunctionFUNCT-2M1-of(Cf0,Df0)"
    fix f2 assume [ty]: "f2 be FunctionFUNCT-2M1-of(Cf0,Df0)"
    assume A1: " for x be ElementSUBSET-1M1-of Cf0 holds f1 .FUNCT-2K3\<^bsub>(Cf0,Df0)\<^esub> x =HIDDENR1 Ff1(x)"
      and A2: " for x be ElementSUBSET-1M1-of Cf0 holds f2 .FUNCT-2K3\<^bsub>(Cf0,Df0)\<^esub> x =HIDDENR1 Ff1(x)"
    have " for x be ElementSUBSET-1M1-of Cf0 holds f1 .FUNCT-2K3\<^bsub>(Cf0,Df0)\<^esub> x =HIDDENR1 f2 .FUNCT-2K3\<^bsub>(Cf0,Df0)\<^esub> x"
    proof(rule ballI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of Cf0"
      have "f1 .FUNCT-2K3\<^bsub>(Cf0,Df0)\<^esub> x =HIDDENR1 Ff1(x)"
        using A1 sorry
      also have "... = f2 .FUNCT-2K3\<^bsub>(Cf0,Df0)\<^esub> x"
        using A2 sorry
      finally show "f1 .FUNCT-2K3\<^bsub>(Cf0,Df0)\<^esub> x =HIDDENR1 f2 .FUNCT-2K3\<^bsub>(Cf0,Df0)\<^esub> x"
         sorry
    qed "sorry"
    thus "f1 =FUNCT-2R2\<^bsub>(Cf0,Df0)\<^esub> f2"
      using funct_2_th_63 sorry
  qed "sorry"

theorem binop_2_sch_2:
  fixes Af0 Of2 
  assumes
[ty]: "Af0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be ElementSUBSET-1M1-of Af0 \<Longrightarrow> x2 be ElementSUBSET-1M1-of Af0 \<Longrightarrow> Of2(x1,x2) be objectHIDDENM1"
  shows " for o1 be BinOpBINOP-1M2-of Af0 holds  for o2 be BinOpBINOP-1M2-of Af0 holds ( for a be ElementSUBSET-1M1-of Af0 holds  for b be ElementSUBSET-1M1-of Af0 holds o1 .BINOP-1K4\<^bsub>(Af0)\<^esub>(a,b) =HIDDENR1 Of2(a,b)) & ( for a be ElementSUBSET-1M1-of Af0 holds  for b be ElementSUBSET-1M1-of Af0 holds o2 .BINOP-1K4\<^bsub>(Af0)\<^esub>(a,b) =HIDDENR1 Of2(a,b)) implies o1 =BINOP-1R13\<^bsub>(Af0,Af0,Af0)\<^esub> o2"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix o1 assume [ty]: "o1 be BinOpBINOP-1M2-of Af0"
    fix o2 assume [ty]: "o2 be BinOpBINOP-1M2-of Af0"
    assume A1: " for a be ElementSUBSET-1M1-of Af0 holds  for b be ElementSUBSET-1M1-of Af0 holds o1 .BINOP-1K4\<^bsub>(Af0)\<^esub>(a,b) =HIDDENR1 Of2(a,b)"
      and A2: " for a be ElementSUBSET-1M1-of Af0 holds  for b be ElementSUBSET-1M1-of Af0 holds o2 .BINOP-1K4\<^bsub>(Af0)\<^esub>(a,b) =HIDDENR1 Of2(a,b)"
    have " for a be ElementSUBSET-1M1-of Af0 holds  for b be ElementSUBSET-1M1-of Af0 holds o1 .BINOP-1K4\<^bsub>(Af0)\<^esub>(a,b) =HIDDENR1 o2 .BINOP-1K4\<^bsub>(Af0)\<^esub>(a,b)"
    proof(rule ballI,rule ballI)
      fix a assume [ty]: "a be ElementSUBSET-1M1-of Af0"
      fix b assume [ty]: "b be ElementSUBSET-1M1-of Af0"
      have "o1 .BINOP-1K4\<^bsub>(Af0)\<^esub>(a,b) =HIDDENR1 Of2(a,b)"
        using A1 sorry
      also have "... = o2 .BINOP-1K4\<^bsub>(Af0)\<^esub>(a,b)"
        using A2 sorry
      finally show "o1 .BINOP-1K4\<^bsub>(Af0)\<^esub>(a,b) =HIDDENR1 o2 .BINOP-1K4\<^bsub>(Af0)\<^esub>(a,b)"
         sorry
    qed "sorry"
    thus "o1 =BINOP-1R13\<^bsub>(Af0,Af0,Af0)\<^esub> o2"
       sorry
  qed "sorry"

theorem binop_2_sch_3:
  fixes Ff1 
  assumes
[ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1"
  shows " for f1 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds ( for x be ComplexXCMPLX-0M1 holds f1 .FUNCT-1K1 x =HIDDENR1 Ff1(x)) & ( for x be ComplexXCMPLX-0M1 holds f2 .FUNCT-1K1 x =HIDDENR1 Ff1(x)) implies f1 =FUNCT-2R2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix f1 assume [ty]: "f1 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    assume A1: " for x be ComplexXCMPLX-0M1 holds f1 .FUNCT-1K1 x =HIDDENR1 Ff1(x)"
      and A2: " for x be ComplexXCMPLX-0M1 holds f2 .FUNCT-1K1 x =HIDDENR1 Ff1(x)"
    have " for x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds f1 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 f2 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> x"
    proof(rule ballI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
      have "f1 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 Ff1(x)"
        using A1 sorry
      also have "... = f2 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> x"
        using A2 sorry
      finally show "f1 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 f2 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> x"
         sorry
    qed "sorry"
    thus "f1 =FUNCT-2R2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2"
      using funct_2_th_63 sorry
  qed "sorry"

theorem binop_2_sch_4:
  fixes Ff1 
  assumes
[ty_func]: "\<And> x1. x1 be RealXREAL-0M1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1"
  shows " for f1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for x be RealXREAL-0M1 holds f1 .FUNCT-1K1 x =HIDDENR1 Ff1(x)) & ( for x be RealXREAL-0M1 holds f2 .FUNCT-1K1 x =HIDDENR1 Ff1(x)) implies f1 =FUNCT-2R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix f1 assume [ty]: "f1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: " for x be RealXREAL-0M1 holds f1 .FUNCT-1K1 x =HIDDENR1 Ff1(x)"
      and A2: " for x be RealXREAL-0M1 holds f2 .FUNCT-1K1 x =HIDDENR1 Ff1(x)"
    have " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds f1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x =HIDDENR1 f2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x"
    proof(rule ballI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
      have "f1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x =HIDDENR1 Ff1(x)"
        using A1 sorry
      also have "... = f2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x"
        using A2 sorry
      finally show "f1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x =HIDDENR1 f2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x"
         sorry
    qed "sorry"
    thus "f1 =FUNCT-2R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2"
      using funct_2_th_63 sorry
  qed "sorry"

mtheorem binop_2_cl_1:
"cluster note-that rationalRAT-1V1 for ElementSUBSET-1M1-of RATRAT-1K1"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of RATRAT-1K1 holds it be rationalRAT-1V1"
    using rat_1_def_2 sorry
qed "sorry"

theorem binop_2_sch_5:
  fixes Ff1 
  assumes
[ty_func]: "\<And> x1. x1 be RationalRAT-1M1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1"
  shows " for f1 be FunctionFUNCT-2M1-of(RATRAT-1K1,RATRAT-1K1) holds  for f2 be FunctionFUNCT-2M1-of(RATRAT-1K1,RATRAT-1K1) holds ( for x be RationalRAT-1M1 holds f1 .FUNCT-1K1 x =HIDDENR1 Ff1(x)) & ( for x be RationalRAT-1M1 holds f2 .FUNCT-1K1 x =HIDDENR1 Ff1(x)) implies f1 =FUNCT-2R2\<^bsub>(RATRAT-1K1,RATRAT-1K1)\<^esub> f2"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix f1 assume [ty]: "f1 be FunctionFUNCT-2M1-of(RATRAT-1K1,RATRAT-1K1)"
    fix f2 assume [ty]: "f2 be FunctionFUNCT-2M1-of(RATRAT-1K1,RATRAT-1K1)"
    assume A1: " for x be RationalRAT-1M1 holds f1 .FUNCT-1K1 x =HIDDENR1 Ff1(x)"
      and A2: " for x be RationalRAT-1M1 holds f2 .FUNCT-1K1 x =HIDDENR1 Ff1(x)"
    have " for x be ElementSUBSET-1M1-of RATRAT-1K1 holds f1 .FUNCT-2K3\<^bsub>(RATRAT-1K1,RATRAT-1K1)\<^esub> x =HIDDENR1 f2 .FUNCT-2K3\<^bsub>(RATRAT-1K1,RATRAT-1K1)\<^esub> x"
    proof(rule ballI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of RATRAT-1K1"
      have "f1 .FUNCT-2K3\<^bsub>(RATRAT-1K1,RATRAT-1K1)\<^esub> x =HIDDENR1 Ff1(x)"
        using A1 sorry
      also have "... = f2 .FUNCT-2K3\<^bsub>(RATRAT-1K1,RATRAT-1K1)\<^esub> x"
        using A2 sorry
      finally show "f1 .FUNCT-2K3\<^bsub>(RATRAT-1K1,RATRAT-1K1)\<^esub> x =HIDDENR1 f2 .FUNCT-2K3\<^bsub>(RATRAT-1K1,RATRAT-1K1)\<^esub> x"
         sorry
    qed "sorry"
    thus "f1 =FUNCT-2R2\<^bsub>(RATRAT-1K1,RATRAT-1K1)\<^esub> f2"
      using funct_2_th_63 sorry
  qed "sorry"

theorem binop_2_sch_6:
  fixes Ff1 
  assumes
[ty_func]: "\<And> x1. x1 be IntegerINT-1M1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1"
  shows " for f1 be FunctionFUNCT-2M1-of(INTNUMBERSK5,INTNUMBERSK5) holds  for f2 be FunctionFUNCT-2M1-of(INTNUMBERSK5,INTNUMBERSK5) holds ( for x be IntegerINT-1M1 holds f1 .FUNCT-1K1 x =HIDDENR1 Ff1(x)) & ( for x be IntegerINT-1M1 holds f2 .FUNCT-1K1 x =HIDDENR1 Ff1(x)) implies f1 =FUNCT-2R2\<^bsub>(INTNUMBERSK5,INTNUMBERSK5)\<^esub> f2"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix f1 assume [ty]: "f1 be FunctionFUNCT-2M1-of(INTNUMBERSK5,INTNUMBERSK5)"
    fix f2 assume [ty]: "f2 be FunctionFUNCT-2M1-of(INTNUMBERSK5,INTNUMBERSK5)"
    assume A1: " for x be IntegerINT-1M1 holds f1 .FUNCT-1K1 x =HIDDENR1 Ff1(x)"
      and A2: " for x be IntegerINT-1M1 holds f2 .FUNCT-1K1 x =HIDDENR1 Ff1(x)"
    have " for x be ElementSUBSET-1M1-of INTNUMBERSK5 holds f1 .FUNCT-2K3\<^bsub>(INTNUMBERSK5,INTNUMBERSK5)\<^esub> x =HIDDENR1 f2 .FUNCT-2K3\<^bsub>(INTNUMBERSK5,INTNUMBERSK5)\<^esub> x"
    proof(rule ballI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of INTNUMBERSK5"
      have "f1 .FUNCT-2K3\<^bsub>(INTNUMBERSK5,INTNUMBERSK5)\<^esub> x =HIDDENR1 Ff1(x)"
        using A1 sorry
      also have "... = f2 .FUNCT-2K3\<^bsub>(INTNUMBERSK5,INTNUMBERSK5)\<^esub> x"
        using A2 sorry
      finally show "f1 .FUNCT-2K3\<^bsub>(INTNUMBERSK5,INTNUMBERSK5)\<^esub> x =HIDDENR1 f2 .FUNCT-2K3\<^bsub>(INTNUMBERSK5,INTNUMBERSK5)\<^esub> x"
         sorry
    qed "sorry"
    thus "f1 =FUNCT-2R2\<^bsub>(INTNUMBERSK5,INTNUMBERSK5)\<^esub> f2"
      using funct_2_th_63 sorry
  qed "sorry"

theorem binop_2_sch_7:
  fixes Ff1 
  assumes
[ty_func]: "\<And> x1. x1 be NatNAT-1M1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1"
  shows " for f1 be sequenceNAT-1M2-of NATNUMBERSK1 holds  for f2 be sequenceNAT-1M2-of NATNUMBERSK1 holds ( for x be NatNAT-1M1 holds f1 .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> x =HIDDENR1 Ff1(x)) & ( for x be NatNAT-1M1 holds f2 .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> x =HIDDENR1 Ff1(x)) implies f1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> f2"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix f1 assume [ty]: "f1 be sequenceNAT-1M2-of NATNUMBERSK1"
    fix f2 assume [ty]: "f2 be sequenceNAT-1M2-of NATNUMBERSK1"
    assume A1: " for x be NatNAT-1M1 holds f1 .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> x =HIDDENR1 Ff1(x)"
      and A2: " for x be NatNAT-1M1 holds f2 .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> x =HIDDENR1 Ff1(x)"
    have " for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds f1 .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> x =HIDDENR1 f2 .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> x"
    proof(rule ballI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "f1 .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> x =HIDDENR1 Ff1(x)"
        using A1 sorry
      also have "... = f2 .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> x"
        using A2 sorry
      finally show "f1 .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> x =HIDDENR1 f2 .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> x"
         sorry
    qed "sorry"
    thus "f1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> f2"
      using funct_2_th_63 sorry
  qed "sorry"

theorem binop_2_sch_8:
  fixes Of2 
  assumes
[ty_func]: "\<And> x1 x2. x1 be ComplexXCMPLX-0M1 \<Longrightarrow> x2 be ComplexXCMPLX-0M1 \<Longrightarrow> Of2(x1,x2) be objectHIDDENM1"
  shows " for o1 be BinOpBINOP-1M2-of COMPLEXNUMBERSK3 holds  for o2 be BinOpBINOP-1M2-of COMPLEXNUMBERSK3 holds ( for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds o1 .BINOP-1K1(a,b) =HIDDENR1 Of2(a,b)) & ( for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds o2 .BINOP-1K1(a,b) =HIDDENR1 Of2(a,b)) implies o1 =BINOP-1R13\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> o2"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix o1 assume [ty]: "o1 be BinOpBINOP-1M2-of COMPLEXNUMBERSK3"
    fix o2 assume [ty]: "o2 be BinOpBINOP-1M2-of COMPLEXNUMBERSK3"
    assume A1: " for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds o1 .BINOP-1K1(a,b) =HIDDENR1 Of2(a,b)"
      and A2: " for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds o2 .BINOP-1K1(a,b) =HIDDENR1 Of2(a,b)"
    have " for a be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for b be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds o1 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(a,b) =HIDDENR1 o2 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(a,b)"
    proof(rule ballI,rule ballI)
      fix a assume [ty]: "a be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
      fix b assume [ty]: "b be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
      have "o1 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(a,b) =HIDDENR1 Of2(a,b)"
        using A1 sorry
      also have "... = o2 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(a,b)"
        using A2 sorry
      finally show "o1 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(a,b) =HIDDENR1 o2 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(a,b)"
         sorry
    qed "sorry"
    thus "o1 =BINOP-1R13\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> o2"
       sorry
  qed "sorry"

theorem binop_2_sch_9:
  fixes Of2 
  assumes
[ty_func]: "\<And> x1 x2. x1 be RealXREAL-0M1 \<Longrightarrow> x2 be RealXREAL-0M1 \<Longrightarrow> Of2(x1,x2) be objectHIDDENM1"
  shows " for o1 be BinOpBINOP-1M2-of REALNUMBERSK2 holds  for o2 be BinOpBINOP-1M2-of REALNUMBERSK2 holds ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds o1 .BINOP-1K1(a,b) =HIDDENR1 Of2(a,b)) & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds o2 .BINOP-1K1(a,b) =HIDDENR1 Of2(a,b)) implies o1 =BINOP-1R13\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> o2"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix o1 assume [ty]: "o1 be BinOpBINOP-1M2-of REALNUMBERSK2"
    fix o2 assume [ty]: "o2 be BinOpBINOP-1M2-of REALNUMBERSK2"
    assume A1: " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds o1 .BINOP-1K1(a,b) =HIDDENR1 Of2(a,b)"
      and A2: " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds o2 .BINOP-1K1(a,b) =HIDDENR1 Of2(a,b)"
    have " for a be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for b be ElementSUBSET-1M1-of REALNUMBERSK2 holds o1 .BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(a,b) =HIDDENR1 o2 .BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(a,b)"
    proof(rule ballI,rule ballI)
      fix a assume [ty]: "a be ElementSUBSET-1M1-of REALNUMBERSK2"
      fix b assume [ty]: "b be ElementSUBSET-1M1-of REALNUMBERSK2"
      have "o1 .BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(a,b) =HIDDENR1 Of2(a,b)"
        using A1 sorry
      also have "... = o2 .BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(a,b)"
        using A2 sorry
      finally show "o1 .BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(a,b) =HIDDENR1 o2 .BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(a,b)"
         sorry
    qed "sorry"
    thus "o1 =BINOP-1R13\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> o2"
       sorry
  qed "sorry"

theorem binop_2_sch_10:
  fixes Of2 
  assumes
[ty_func]: "\<And> x1 x2. x1 be RationalRAT-1M1 \<Longrightarrow> x2 be RationalRAT-1M1 \<Longrightarrow> Of2(x1,x2) be objectHIDDENM1"
  shows " for o1 be BinOpBINOP-1M2-of RATRAT-1K1 holds  for o2 be BinOpBINOP-1M2-of RATRAT-1K1 holds ( for a be RationalRAT-1M1 holds  for b be RationalRAT-1M1 holds o1 .BINOP-1K1(a,b) =HIDDENR1 Of2(a,b)) & ( for a be RationalRAT-1M1 holds  for b be RationalRAT-1M1 holds o2 .BINOP-1K1(a,b) =HIDDENR1 Of2(a,b)) implies o1 =BINOP-1R13\<^bsub>(RATRAT-1K1,RATRAT-1K1,RATRAT-1K1)\<^esub> o2"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix o1 assume [ty]: "o1 be BinOpBINOP-1M2-of RATRAT-1K1"
    fix o2 assume [ty]: "o2 be BinOpBINOP-1M2-of RATRAT-1K1"
    assume A1: " for a be RationalRAT-1M1 holds  for b be RationalRAT-1M1 holds o1 .BINOP-1K1(a,b) =HIDDENR1 Of2(a,b)"
      and A2: " for a be RationalRAT-1M1 holds  for b be RationalRAT-1M1 holds o2 .BINOP-1K1(a,b) =HIDDENR1 Of2(a,b)"
    have " for a be ElementSUBSET-1M1-of RATRAT-1K1 holds  for b be ElementSUBSET-1M1-of RATRAT-1K1 holds o1 .BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(a,b) =HIDDENR1 o2 .BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(a,b)"
    proof(rule ballI,rule ballI)
      fix a assume [ty]: "a be ElementSUBSET-1M1-of RATRAT-1K1"
      fix b assume [ty]: "b be ElementSUBSET-1M1-of RATRAT-1K1"
      have "o1 .BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(a,b) =HIDDENR1 Of2(a,b)"
        using A1 sorry
      also have "... = o2 .BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(a,b)"
        using A2 sorry
      finally show "o1 .BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(a,b) =HIDDENR1 o2 .BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(a,b)"
         sorry
    qed "sorry"
    thus "o1 =BINOP-1R13\<^bsub>(RATRAT-1K1,RATRAT-1K1,RATRAT-1K1)\<^esub> o2"
       sorry
  qed "sorry"

theorem binop_2_sch_11:
  fixes Of2 
  assumes
[ty_func]: "\<And> x1 x2. x1 be IntegerINT-1M1 \<Longrightarrow> x2 be IntegerINT-1M1 \<Longrightarrow> Of2(x1,x2) be objectHIDDENM1"
  shows " for o1 be BinOpBINOP-1M2-of INTNUMBERSK5 holds  for o2 be BinOpBINOP-1M2-of INTNUMBERSK5 holds ( for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds o1 .BINOP-1K1(a,b) =HIDDENR1 Of2(a,b)) & ( for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds o2 .BINOP-1K1(a,b) =HIDDENR1 Of2(a,b)) implies o1 =BINOP-1R13\<^bsub>(INTNUMBERSK5,INTNUMBERSK5,INTNUMBERSK5)\<^esub> o2"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix o1 assume [ty]: "o1 be BinOpBINOP-1M2-of INTNUMBERSK5"
    fix o2 assume [ty]: "o2 be BinOpBINOP-1M2-of INTNUMBERSK5"
    assume A1: " for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds o1 .BINOP-1K1(a,b) =HIDDENR1 Of2(a,b)"
      and A2: " for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds o2 .BINOP-1K1(a,b) =HIDDENR1 Of2(a,b)"
    have " for a be ElementSUBSET-1M1-of INTNUMBERSK5 holds  for b be ElementSUBSET-1M1-of INTNUMBERSK5 holds o1 .BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(a,b) =HIDDENR1 o2 .BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(a,b)"
    proof(rule ballI,rule ballI)
      fix a assume [ty]: "a be ElementSUBSET-1M1-of INTNUMBERSK5"
      fix b assume [ty]: "b be ElementSUBSET-1M1-of INTNUMBERSK5"
      have "o1 .BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(a,b) =HIDDENR1 Of2(a,b)"
        using A1 sorry
      also have "... = o2 .BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(a,b)"
        using A2 sorry
      finally show "o1 .BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(a,b) =HIDDENR1 o2 .BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(a,b)"
         sorry
    qed "sorry"
    thus "o1 =BINOP-1R13\<^bsub>(INTNUMBERSK5,INTNUMBERSK5,INTNUMBERSK5)\<^esub> o2"
       sorry
  qed "sorry"

theorem binop_2_sch_12:
  fixes Of2 
  assumes
[ty_func]: "\<And> x1 x2. x1 be NatNAT-1M1 \<Longrightarrow> x2 be NatNAT-1M1 \<Longrightarrow> Of2(x1,x2) be objectHIDDENM1"
  shows " for o1 be BinOpBINOP-1M2-of NATNUMBERSK1 holds  for o2 be BinOpBINOP-1M2-of NATNUMBERSK1 holds ( for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds o1 .BINOP-1K1(a,b) =HIDDENR1 Of2(a,b)) & ( for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds o2 .BINOP-1K1(a,b) =HIDDENR1 Of2(a,b)) implies o1 =BINOP-1R13\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1)\<^esub> o2"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix o1 assume [ty]: "o1 be BinOpBINOP-1M2-of NATNUMBERSK1"
    fix o2 assume [ty]: "o2 be BinOpBINOP-1M2-of NATNUMBERSK1"
    assume A1: " for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds o1 .BINOP-1K1(a,b) =HIDDENR1 Of2(a,b)"
      and A2: " for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds o2 .BINOP-1K1(a,b) =HIDDENR1 Of2(a,b)"
    have " for a be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for b be ElementSUBSET-1M1-of NATNUMBERSK1 holds o1 .NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(a,b) =HIDDENR1 o2 .NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(a,b)"
    proof(rule ballI,rule ballI)
      fix a assume [ty]: "a be ElementSUBSET-1M1-of NATNUMBERSK1"
      fix b assume [ty]: "b be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "o1 .NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(a,b) =HIDDENR1 Of2(a,b)"
        using A1 sorry
      also have "... = o2 .NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(a,b)"
        using A2 sorry
      finally show "o1 .NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(a,b) =HIDDENR1 o2 .NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(a,b)"
         sorry
    qed "sorry"
    thus "o1 =BINOP-1R13\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1)\<^esub> o2"
       sorry
  qed "sorry"

theorem binop_2_sch_13:
  fixes Ff2 
  assumes
[ty_func]: "\<And> x1 x2. x1 be ComplexXCMPLX-0M1 \<Longrightarrow> x2 be ComplexXCMPLX-0M1 \<Longrightarrow> Ff2(x1,x2) be ComplexXCMPLX-0M1"
  shows " ex f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 COMPLEXNUMBERSK3,COMPLEXNUMBERSK3 :],COMPLEXNUMBERSK3) st  for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds f .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y)"
  proof-
    have " ex tVar2 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 COMPLEXNUMBERSK3,COMPLEXNUMBERSK3 :],COMPLEXNUMBERSK3) st  for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds tVar2 .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y)"
    proof-
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3. Lamb3 =HIDDENR1 Ff2(Lamb1,Lamb2)"
      have A1: " for x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for y be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  ex z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 st ?P(x,y,z)"
      proof-
        have " for x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for y be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  ex tVar1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 st tVar1 =HIDDENR1 Ff2(x,y)"
        proof(rule ballI,rule ballI)
          fix x assume [ty]: "x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
          fix y assume [ty]: "y be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
          obtain z where 
            [ty]:"z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and zDef:"z = Ff2(x,y)"
            using xcmplx_0_def_2 sorry
          show " ex tVar1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 st tVar1 =HIDDENR1 Ff2(x,y)"
          proof(rule bexI[of _ "z"])
            show "z =HIDDENR1 Ff2(x,y)"
               sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain f where
        [ty]:"f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 COMPLEXNUMBERSK3,COMPLEXNUMBERSK3 :],COMPLEXNUMBERSK3)" and 
        A2: " for x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for y be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds ?P(x,y,f .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(x,y))"
        using binop_1_sch_3 A1 sorry
      show " ex tVar2 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 COMPLEXNUMBERSK3,COMPLEXNUMBERSK3 :],COMPLEXNUMBERSK3) st  for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds tVar2 .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y)"
      proof(rule bexI[of _ "f"],rule ballI,rule ballI)
        fix x assume [ty]: "x be ComplexXCMPLX-0M1"
        fix y assume [ty]: "y be ComplexXCMPLX-0M1"
        have 
          [ty]:"x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and
          [ty]:"y be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
          using xcmplx_0_def_2 sorry
        have "?P(x,y,f .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(x,y))"
          using A2 sorry
        then have "f .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(x,y) =HIDDENR1 Ff2(x,y)"
           sorry
        thus "f .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y)"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem binop_2_sch_14:
  fixes Ff2 
  assumes
[ty_func]: "\<And> x1 x2. x1 be RealXREAL-0M1 \<Longrightarrow> x2 be RealXREAL-0M1 \<Longrightarrow> Ff2(x1,x2) be RealXREAL-0M1"
  shows " ex f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 REALNUMBERSK2,REALNUMBERSK2 :],REALNUMBERSK2) st  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds f .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y)"
  proof-
    have " ex tVar4 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 REALNUMBERSK2,REALNUMBERSK2 :],REALNUMBERSK2) st  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds tVar4 .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y)"
    proof-
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3. Lamb3 =HIDDENR1 Ff2(Lamb1,Lamb2)"
      have A1: " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds  ex z be ElementSUBSET-1M1-of REALNUMBERSK2 st ?P(x,y,z)"
      proof-
        have " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds  ex tVar3 be ElementSUBSET-1M1-of REALNUMBERSK2 st tVar3 =HIDDENR1 Ff2(x,y)"
        proof(rule ballI,rule ballI)
          fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
          fix y assume [ty]: "y be ElementSUBSET-1M1-of REALNUMBERSK2"
          obtain z where 
            [ty]:"z be ElementSUBSET-1M1-of REALNUMBERSK2" and zDef:"z = Ff2(x,y)"
            using xreal_0_def_1 sorry
          show " ex tVar3 be ElementSUBSET-1M1-of REALNUMBERSK2 st tVar3 =HIDDENR1 Ff2(x,y)"
          proof(rule bexI[of _ "z"])
            show "z =HIDDENR1 Ff2(x,y)"
               sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain f where
        [ty]:"f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 REALNUMBERSK2,REALNUMBERSK2 :],REALNUMBERSK2)" and 
        A2: " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds ?P(x,y,f .BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x,y))"
        using binop_1_sch_3 A1 sorry
      show " ex tVar4 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 REALNUMBERSK2,REALNUMBERSK2 :],REALNUMBERSK2) st  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds tVar4 .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y)"
      proof(rule bexI[of _ "f"],rule ballI,rule ballI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        fix y assume [ty]: "y be RealXREAL-0M1"
        have 
          [ty]:"x be ElementSUBSET-1M1-of REALNUMBERSK2" and
          [ty]:"y be ElementSUBSET-1M1-of REALNUMBERSK2"
          using xreal_0_def_1 sorry
        have "?P(x,y,f .BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x,y))"
          using A2 sorry
        then have "f .BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x,y) =HIDDENR1 Ff2(x,y)"
           sorry
        thus "f .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y)"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem binop_2_sch_15:
  fixes Ff2 
  assumes
[ty_func]: "\<And> x1 x2. x1 be RationalRAT-1M1 \<Longrightarrow> x2 be RationalRAT-1M1 \<Longrightarrow> Ff2(x1,x2) be RationalRAT-1M1"
  shows " ex f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 RATRAT-1K1,RATRAT-1K1 :],RATRAT-1K1) st  for x be RationalRAT-1M1 holds  for y be RationalRAT-1M1 holds f .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y)"
  proof-
    have " ex tVar6 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 RATRAT-1K1,RATRAT-1K1 :],RATRAT-1K1) st  for x be RationalRAT-1M1 holds  for y be RationalRAT-1M1 holds tVar6 .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y)"
    proof-
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3. Lamb3 =HIDDENR1 Ff2(Lamb1,Lamb2)"
      have A1: " for x be ElementSUBSET-1M1-of RATRAT-1K1 holds  for y be ElementSUBSET-1M1-of RATRAT-1K1 holds  ex z be ElementSUBSET-1M1-of RATRAT-1K1 st ?P(x,y,z)"
      proof-
        have " for x be ElementSUBSET-1M1-of RATRAT-1K1 holds  for y be ElementSUBSET-1M1-of RATRAT-1K1 holds  ex tVar5 be ElementSUBSET-1M1-of RATRAT-1K1 st tVar5 =HIDDENR1 Ff2(x,y)"
        proof(rule ballI,rule ballI)
          fix x assume [ty]: "x be ElementSUBSET-1M1-of RATRAT-1K1"
          fix y assume [ty]: "y be ElementSUBSET-1M1-of RATRAT-1K1"
          obtain z where 
            [ty]:"z be ElementSUBSET-1M1-of RATRAT-1K1" and zDef:"z = Ff2(x,y)"
            using rat_1_def_2 sorry
          show " ex tVar5 be ElementSUBSET-1M1-of RATRAT-1K1 st tVar5 =HIDDENR1 Ff2(x,y)"
          proof(rule bexI[of _ "z"])
            show "z =HIDDENR1 Ff2(x,y)"
               sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain f where
        [ty]:"f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 RATRAT-1K1,RATRAT-1K1 :],RATRAT-1K1)" and 
        A2: " for x be ElementSUBSET-1M1-of RATRAT-1K1 holds  for y be ElementSUBSET-1M1-of RATRAT-1K1 holds ?P(x,y,f .BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(x,y))"
        using binop_1_sch_3 A1 sorry
      show " ex tVar6 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 RATRAT-1K1,RATRAT-1K1 :],RATRAT-1K1) st  for x be RationalRAT-1M1 holds  for y be RationalRAT-1M1 holds tVar6 .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y)"
      proof(rule bexI[of _ "f"],rule ballI,rule ballI)
        fix x assume [ty]: "x be RationalRAT-1M1"
        fix y assume [ty]: "y be RationalRAT-1M1"
        have 
          [ty]:"x be ElementSUBSET-1M1-of RATRAT-1K1" and
          [ty]:"y be ElementSUBSET-1M1-of RATRAT-1K1"
          using rat_1_def_2 sorry
        have "?P(x,y,f .BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(x,y))"
          using A2 sorry
        then have "f .BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(x,y) =HIDDENR1 Ff2(x,y)"
           sorry
        thus "f .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y)"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem binop_2_sch_16:
  fixes Ff2 
  assumes
[ty_func]: "\<And> x1 x2. x1 be IntegerINT-1M1 \<Longrightarrow> x2 be IntegerINT-1M1 \<Longrightarrow> Ff2(x1,x2) be IntegerINT-1M1"
  shows " ex f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 INTNUMBERSK5,INTNUMBERSK5 :],INTNUMBERSK5) st  for x be IntegerINT-1M1 holds  for y be IntegerINT-1M1 holds f .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y)"
  proof-
    have " ex tVar8 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 INTNUMBERSK5,INTNUMBERSK5 :],INTNUMBERSK5) st  for x be IntegerINT-1M1 holds  for y be IntegerINT-1M1 holds tVar8 .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y)"
    proof-
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3. Lamb3 =HIDDENR1 Ff2(Lamb1,Lamb2)"
      have A1: " for x be ElementSUBSET-1M1-of INTNUMBERSK5 holds  for y be ElementSUBSET-1M1-of INTNUMBERSK5 holds  ex z be ElementSUBSET-1M1-of INTNUMBERSK5 st ?P(x,y,z)"
      proof-
        have " for x be ElementSUBSET-1M1-of INTNUMBERSK5 holds  for y be ElementSUBSET-1M1-of INTNUMBERSK5 holds  ex tVar7 be ElementSUBSET-1M1-of INTNUMBERSK5 st tVar7 =HIDDENR1 Ff2(x,y)"
        proof(rule ballI,rule ballI)
          fix x assume [ty]: "x be ElementSUBSET-1M1-of INTNUMBERSK5"
          fix y assume [ty]: "y be ElementSUBSET-1M1-of INTNUMBERSK5"
          obtain z where 
            [ty]:"z be ElementSUBSET-1M1-of INTNUMBERSK5" and zDef:"z = Ff2(x,y)"
            using int_1_def_2 sorry
          show " ex tVar7 be ElementSUBSET-1M1-of INTNUMBERSK5 st tVar7 =HIDDENR1 Ff2(x,y)"
          proof(rule bexI[of _ "z"])
            show "z =HIDDENR1 Ff2(x,y)"
               sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain f where
        [ty]:"f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 INTNUMBERSK5,INTNUMBERSK5 :],INTNUMBERSK5)" and 
        A2: " for x be ElementSUBSET-1M1-of INTNUMBERSK5 holds  for y be ElementSUBSET-1M1-of INTNUMBERSK5 holds ?P(x,y,f .BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(x,y))"
        using binop_1_sch_3 A1 sorry
      show " ex tVar8 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 INTNUMBERSK5,INTNUMBERSK5 :],INTNUMBERSK5) st  for x be IntegerINT-1M1 holds  for y be IntegerINT-1M1 holds tVar8 .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y)"
      proof(rule bexI[of _ "f"],rule ballI,rule ballI)
        fix x assume [ty]: "x be IntegerINT-1M1"
        fix y assume [ty]: "y be IntegerINT-1M1"
        have 
          [ty]:"x be ElementSUBSET-1M1-of INTNUMBERSK5" and
          [ty]:"y be ElementSUBSET-1M1-of INTNUMBERSK5"
          using int_1_def_2 sorry
        have "?P(x,y,f .BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(x,y))"
          using A2 sorry
        then have "f .BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(x,y) =HIDDENR1 Ff2(x,y)"
           sorry
        thus "f .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y)"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem binop_2_sch_17:
  fixes Ff2 
  assumes
[ty_func]: "\<And> x1 x2. x1 be NatNAT-1M1 \<Longrightarrow> x2 be NatNAT-1M1 \<Longrightarrow> Ff2(x1,x2) be NatNAT-1M1"
  shows " ex f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :],NATNUMBERSK1) st  for x be NatNAT-1M1 holds  for y be NatNAT-1M1 holds f .BINOP-1K1(x,y) =XBOOLE-0R4 Ff2(x,y)"
  proof-
    have " ex tVar10 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :],NATNUMBERSK1) st  for x be NatNAT-1M1 holds  for y be NatNAT-1M1 holds tVar10 .BINOP-1K1(x,y) =XBOOLE-0R4 Ff2(x,y)"
    proof-
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3. Lamb3 =XBOOLE-0R4 Ff2(Lamb1,Lamb2)"
      have A1: " for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for y be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex z be ElementSUBSET-1M1-of NATNUMBERSK1 st ?P(x,y,z)"
      proof-
        have " for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for y be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex tVar9 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar9 =XBOOLE-0R4 Ff2(x,y)"
        proof(rule ballI,rule ballI)
          fix x assume [ty]: "x be ElementSUBSET-1M1-of NATNUMBERSK1"
          fix y assume [ty]: "y be ElementSUBSET-1M1-of NATNUMBERSK1"
          obtain z where 
            [ty]:"z be ElementSUBSET-1M1-of NATNUMBERSK1" and zDef:"z = Ff2(x,y)"
            using ordinal1_def_12 sorry
          show " ex tVar9 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar9 =XBOOLE-0R4 Ff2(x,y)"
          proof(rule bexI[of _ "z"])
            show "z =XBOOLE-0R4 Ff2(x,y)"
               sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain f where
        [ty]:"f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :],NATNUMBERSK1)" and 
        A2: " for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for y be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?P(x,y,f .NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(x,y))"
        using binop_1_sch_3 A1 sorry
      show " ex tVar10 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :],NATNUMBERSK1) st  for x be NatNAT-1M1 holds  for y be NatNAT-1M1 holds tVar10 .BINOP-1K1(x,y) =XBOOLE-0R4 Ff2(x,y)"
      proof(rule bexI[of _ "f"],rule ballI,rule ballI)
        fix x assume [ty]: "x be NatNAT-1M1"
        fix y assume [ty]: "y be NatNAT-1M1"
        have 
          [ty]:"x be ElementSUBSET-1M1-of NATNUMBERSK1" and
          [ty]:"y be ElementSUBSET-1M1-of NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "?P(x,y,f .NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(x,y))"
          using A2 sorry
        then have "f .NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(x,y) =XBOOLE-0R4 Ff2(x,y)"
           sorry
        thus "f .BINOP-1K1(x,y) =XBOOLE-0R4 Ff2(x,y)"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem binop_2_sch_18:
  fixes Ff1 
  assumes
[ty_func]: "\<And> x1. x1 be ComplexXCMPLX-0M1 \<Longrightarrow> Ff1(x1) be ComplexXCMPLX-0M1"
  shows " ex f be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) st  for x be ComplexXCMPLX-0M1 holds f .FUNCT-1K1 x =HIDDENR1 Ff1(x)"
  proof-
    have " ex tVar12 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) st  for c be ComplexXCMPLX-0M1 holds tVar12 .FUNCT-1K1 c =HIDDENR1 Ff1(c)"
    proof-
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 =HIDDENR1 Ff1(Lamb1)"
      have A1: " for x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  ex y be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 st ?P(x,y)"
      proof-
        have " for x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  ex tVar11 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 st tVar11 =HIDDENR1 Ff1(x)"
        proof(rule ballI)
          fix x assume [ty]: "x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
          obtain y where 
            [ty]:"y be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and yDef:"y = Ff1(x)"
            using xcmplx_0_def_2 sorry
          show " ex tVar11 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 st tVar11 =HIDDENR1 Ff1(x)"
          proof(rule bexI[of _ "y"])
            show "y =HIDDENR1 Ff1(x)"
               sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain f where
        [ty]:"f be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)" and 
        A2: " for x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds ?P(x,f .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> x)"
        using funct_2_sch_3 A1 sorry
      show " ex tVar12 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) st  for c be ComplexXCMPLX-0M1 holds tVar12 .FUNCT-1K1 c =HIDDENR1 Ff1(c)"
      proof(rule bexI[of _ "f"],rule ballI)
        fix c assume [ty]: "c be ComplexXCMPLX-0M1"
        have 
          [ty]:"c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
          using xcmplx_0_def_2 sorry
        have "?P(c,f .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)"
          using A2 sorry
        thus "f .FUNCT-1K1 c =HIDDENR1 Ff1(c)"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem binop_2_sch_19:
  fixes Ff1 
  assumes
[ty_func]: "\<And> x1. x1 be RealXREAL-0M1 \<Longrightarrow> Ff1(x1) be RealXREAL-0M1"
  shows " ex f be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for x be RealXREAL-0M1 holds f .FUNCT-1K1 x =HIDDENR1 Ff1(x)"
  proof-
    have " ex tVar14 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for c be RealXREAL-0M1 holds tVar14 .FUNCT-1K1 c =HIDDENR1 Ff1(c)"
    proof-
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 =HIDDENR1 Ff1(Lamb1)"
      have A1: " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  ex y be ElementSUBSET-1M1-of REALNUMBERSK2 st ?P(x,y)"
      proof-
        have " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  ex tVar13 be ElementSUBSET-1M1-of REALNUMBERSK2 st tVar13 =HIDDENR1 Ff1(x)"
        proof(rule ballI)
          fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
          obtain y where 
            [ty]:"y be ElementSUBSET-1M1-of REALNUMBERSK2" and yDef:"y = Ff1(x)"
            using xreal_0_def_1 sorry
          show " ex tVar13 be ElementSUBSET-1M1-of REALNUMBERSK2 st tVar13 =HIDDENR1 Ff1(x)"
          proof(rule bexI[of _ "y"])
            show "y =HIDDENR1 Ff1(x)"
               sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain f where
        [ty]:"f be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
        A2: " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds ?P(x,f .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x)"
        using funct_2_sch_3 A1 sorry
      show " ex tVar14 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for c be RealXREAL-0M1 holds tVar14 .FUNCT-1K1 c =HIDDENR1 Ff1(c)"
      proof(rule bexI[of _ "f"],rule ballI)
        fix c assume [ty]: "c be RealXREAL-0M1"
        have 
          [ty]:"c be ElementSUBSET-1M1-of REALNUMBERSK2"
          using xreal_0_def_1 sorry
        have "?P(c,f .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
          using A2 sorry
        thus "f .FUNCT-1K1 c =HIDDENR1 Ff1(c)"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem binop_2_sch_20:
  fixes Ff1 
  assumes
[ty_func]: "\<And> x1. x1 be RationalRAT-1M1 \<Longrightarrow> Ff1(x1) be RationalRAT-1M1"
  shows " ex f be FunctionFUNCT-2M1-of(RATRAT-1K1,RATRAT-1K1) st  for x be RationalRAT-1M1 holds f .FUNCT-1K1 x =HIDDENR1 Ff1(x)"
  proof-
    have " ex tVar16 be FunctionFUNCT-2M1-of(RATRAT-1K1,RATRAT-1K1) st  for c be RationalRAT-1M1 holds tVar16 .FUNCT-1K1 c =HIDDENR1 Ff1(c)"
    proof-
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 =HIDDENR1 Ff1(Lamb1)"
      have A1: " for x be ElementSUBSET-1M1-of RATRAT-1K1 holds  ex y be ElementSUBSET-1M1-of RATRAT-1K1 st ?P(x,y)"
      proof-
        have " for x be ElementSUBSET-1M1-of RATRAT-1K1 holds  ex tVar15 be ElementSUBSET-1M1-of RATRAT-1K1 st tVar15 =HIDDENR1 Ff1(x)"
        proof(rule ballI)
          fix x assume [ty]: "x be ElementSUBSET-1M1-of RATRAT-1K1"
          obtain y where 
            [ty]:"y be ElementSUBSET-1M1-of RATRAT-1K1" and yDef:"y = Ff1(x)"
            using rat_1_def_2 sorry
          show " ex tVar15 be ElementSUBSET-1M1-of RATRAT-1K1 st tVar15 =HIDDENR1 Ff1(x)"
          proof(rule bexI[of _ "y"])
            show "y =HIDDENR1 Ff1(x)"
               sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain f where
        [ty]:"f be FunctionFUNCT-2M1-of(RATRAT-1K1,RATRAT-1K1)" and 
        A2: " for x be ElementSUBSET-1M1-of RATRAT-1K1 holds ?P(x,f .FUNCT-2K3\<^bsub>(RATRAT-1K1,RATRAT-1K1)\<^esub> x)"
        using funct_2_sch_3 A1 sorry
      show " ex tVar16 be FunctionFUNCT-2M1-of(RATRAT-1K1,RATRAT-1K1) st  for c be RationalRAT-1M1 holds tVar16 .FUNCT-1K1 c =HIDDENR1 Ff1(c)"
      proof(rule bexI[of _ "f"],rule ballI)
        fix c assume [ty]: "c be RationalRAT-1M1"
        have 
          [ty]:"c be ElementSUBSET-1M1-of RATRAT-1K1"
          using rat_1_def_2 sorry
        have "?P(c,f .FUNCT-2K3\<^bsub>(RATRAT-1K1,RATRAT-1K1)\<^esub> c)"
          using A2 sorry
        thus "f .FUNCT-1K1 c =HIDDENR1 Ff1(c)"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem binop_2_sch_21:
  fixes Ff1 
  assumes
[ty_func]: "\<And> x1. x1 be IntegerINT-1M1 \<Longrightarrow> Ff1(x1) be IntegerINT-1M1"
  shows " ex f be FunctionFUNCT-2M1-of(INTNUMBERSK5,INTNUMBERSK5) st  for x be IntegerINT-1M1 holds f .FUNCT-1K1 x =HIDDENR1 Ff1(x)"
  proof-
    have " ex tVar18 be FunctionFUNCT-2M1-of(INTNUMBERSK5,INTNUMBERSK5) st  for c be IntegerINT-1M1 holds tVar18 .FUNCT-1K1 c =HIDDENR1 Ff1(c)"
    proof-
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 =HIDDENR1 Ff1(Lamb1)"
      have A1: " for x be ElementSUBSET-1M1-of INTNUMBERSK5 holds  ex y be ElementSUBSET-1M1-of INTNUMBERSK5 st ?P(x,y)"
      proof-
        have " for x be ElementSUBSET-1M1-of INTNUMBERSK5 holds  ex tVar17 be ElementSUBSET-1M1-of INTNUMBERSK5 st tVar17 =HIDDENR1 Ff1(x)"
        proof(rule ballI)
          fix x assume [ty]: "x be ElementSUBSET-1M1-of INTNUMBERSK5"
          obtain y where 
            [ty]:"y be ElementSUBSET-1M1-of INTNUMBERSK5" and yDef:"y = Ff1(x)"
            using int_1_def_2 sorry
          show " ex tVar17 be ElementSUBSET-1M1-of INTNUMBERSK5 st tVar17 =HIDDENR1 Ff1(x)"
          proof(rule bexI[of _ "y"])
            show "y =HIDDENR1 Ff1(x)"
               sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain f where
        [ty]:"f be FunctionFUNCT-2M1-of(INTNUMBERSK5,INTNUMBERSK5)" and 
        A2: " for x be ElementSUBSET-1M1-of INTNUMBERSK5 holds ?P(x,f .FUNCT-2K3\<^bsub>(INTNUMBERSK5,INTNUMBERSK5)\<^esub> x)"
        using funct_2_sch_3 A1 sorry
      show " ex tVar18 be FunctionFUNCT-2M1-of(INTNUMBERSK5,INTNUMBERSK5) st  for c be IntegerINT-1M1 holds tVar18 .FUNCT-1K1 c =HIDDENR1 Ff1(c)"
      proof(rule bexI[of _ "f"],rule ballI)
        fix c assume [ty]: "c be IntegerINT-1M1"
        have 
          [ty]:"c be ElementSUBSET-1M1-of INTNUMBERSK5"
          using int_1_def_2 sorry
        have "?P(c,f .FUNCT-2K3\<^bsub>(INTNUMBERSK5,INTNUMBERSK5)\<^esub> c)"
          using A2 sorry
        thus "f .FUNCT-1K1 c =HIDDENR1 Ff1(c)"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem binop_2_sch_22:
  fixes Ff1 
  assumes
[ty_func]: "\<And> x1. x1 be NatNAT-1M1 \<Longrightarrow> Ff1(x1) be NatNAT-1M1"
  shows " ex f be sequenceNAT-1M2-of NATNUMBERSK1 st  for x be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> x =XBOOLE-0R4 Ff1(x)"
  proof-
    have " ex tVar20 be sequenceNAT-1M2-of NATNUMBERSK1 st  for c be NatNAT-1M1 holds tVar20 .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> c =XBOOLE-0R4 Ff1(c)"
    proof-
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 =XBOOLE-0R4 Ff1(Lamb1)"
      have A1: " for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex y be ElementSUBSET-1M1-of NATNUMBERSK1 st ?P(x,y)"
      proof-
        have " for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex tVar19 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar19 =XBOOLE-0R4 Ff1(x)"
        proof(rule ballI)
          fix x assume [ty]: "x be ElementSUBSET-1M1-of NATNUMBERSK1"
          obtain y where 
            [ty]:"y be ElementSUBSET-1M1-of NATNUMBERSK1" and yDef:"y = Ff1(x)"
            using ordinal1_def_12 sorry
          show " ex tVar19 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar19 =XBOOLE-0R4 Ff1(x)"
          proof(rule bexI[of _ "y"])
            show "y =XBOOLE-0R4 Ff1(x)"
               sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain f where
        [ty]:"f be sequenceNAT-1M2-of NATNUMBERSK1" and 
        A2: " for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?P(x,f .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> x)"
        using funct_2_sch_3 A1 sorry
      show " ex tVar20 be sequenceNAT-1M2-of NATNUMBERSK1 st  for c be NatNAT-1M1 holds tVar20 .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> c =XBOOLE-0R4 Ff1(c)"
      proof(rule bexI[of _ "f"],rule ballI)
        fix c assume [ty]: "c be NatNAT-1M1"
        have 
          [ty]:"c be ElementSUBSET-1M1-of NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "?P(c,f .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> c)"
          using A2 sorry
        thus "f .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> c =XBOOLE-0R4 Ff1(c)"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

reserve c, c1, c2 for "ComplexXCMPLX-0M1"
reserve r, r1, r2 for "RealXREAL-0M1"
reserve w, w1, w2 for "RationalRAT-1M1"
reserve i, i1, i2 for "IntegerINT-1M1"
reserve n1, n2 for "NatNAT-1M1"
mdef binop_2_def_1 ("compcomplexBINOP-2K1" 228 ) where
"func compcomplexBINOP-2K1 \<rightarrow> UnOpBINOP-1M1-of COMPLEXNUMBERSK3 means
  \<lambda>it.  for c be ComplexXCMPLX-0M1 holds it .FUNCT-1K1 c =HIDDENR1 -XCMPLX-0K4 c"
proof-
  (*existence*)
    show " ex it be UnOpBINOP-1M1-of COMPLEXNUMBERSK3 st  for c be ComplexXCMPLX-0M1 holds it .FUNCT-1K1 c =HIDDENR1 -XCMPLX-0K4 c"
      using binop_2_sch_18 sorry
  (*uniqueness*)
    show " for it1 be UnOpBINOP-1M1-of COMPLEXNUMBERSK3 holds  for it2 be UnOpBINOP-1M1-of COMPLEXNUMBERSK3 holds ( for c be ComplexXCMPLX-0M1 holds it1 .FUNCT-1K1 c =HIDDENR1 -XCMPLX-0K4 c) & ( for c be ComplexXCMPLX-0M1 holds it2 .FUNCT-1K1 c =HIDDENR1 -XCMPLX-0K4 c) implies it1 =HIDDENR1 it2"
      using binop_2_sch_3 sorry
qed "sorry"

mdef binop_2_def_2 ("invcomplexBINOP-2K2" 164 ) where
"func invcomplexBINOP-2K2 \<rightarrow> UnOpBINOP-1M1-of COMPLEXNUMBERSK3 means
  \<lambda>it.  for c be ComplexXCMPLX-0M1 holds it .FUNCT-1K1 c =HIDDENR1 c \<inverse>XCMPLX-0K5"
proof-
  (*existence*)
    show " ex it be UnOpBINOP-1M1-of COMPLEXNUMBERSK3 st  for c be ComplexXCMPLX-0M1 holds it .FUNCT-1K1 c =HIDDENR1 c \<inverse>XCMPLX-0K5"
      using binop_2_sch_18 sorry
  (*uniqueness*)
    show " for it1 be UnOpBINOP-1M1-of COMPLEXNUMBERSK3 holds  for it2 be UnOpBINOP-1M1-of COMPLEXNUMBERSK3 holds ( for c be ComplexXCMPLX-0M1 holds it1 .FUNCT-1K1 c =HIDDENR1 c \<inverse>XCMPLX-0K5) & ( for c be ComplexXCMPLX-0M1 holds it2 .FUNCT-1K1 c =HIDDENR1 c \<inverse>XCMPLX-0K5) implies it1 =HIDDENR1 it2"
      using binop_2_sch_3 sorry
qed "sorry"

mdef binop_2_def_3 ("addcomplexBINOP-2K3" 228 ) where
"func addcomplexBINOP-2K3 \<rightarrow> BinOpBINOP-1M2-of COMPLEXNUMBERSK3 means
  \<lambda>it.  for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds it .BINOP-1K1(c1,c2) =XBOOLE-0R4 c1 +XCMPLX-0K2 c2"
proof-
  (*existence*)
    show " ex it be BinOpBINOP-1M2-of COMPLEXNUMBERSK3 st  for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds it .BINOP-1K1(c1,c2) =XBOOLE-0R4 c1 +XCMPLX-0K2 c2"
      using binop_2_sch_13 sorry
  (*uniqueness*)
    show " for it1 be BinOpBINOP-1M2-of COMPLEXNUMBERSK3 holds  for it2 be BinOpBINOP-1M2-of COMPLEXNUMBERSK3 holds ( for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds it1 .BINOP-1K1(c1,c2) =XBOOLE-0R4 c1 +XCMPLX-0K2 c2) & ( for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds it2 .BINOP-1K1(c1,c2) =XBOOLE-0R4 c1 +XCMPLX-0K2 c2) implies it1 =HIDDENR1 it2"
      using binop_2_sch_8 sorry
qed "sorry"

mdef binop_2_def_4 ("diffcomplexBINOP-2K4" 228 ) where
"func diffcomplexBINOP-2K4 \<rightarrow> BinOpBINOP-1M2-of COMPLEXNUMBERSK3 means
  \<lambda>it.  for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds it .BINOP-1K1(c1,c2) =XBOOLE-0R4 c1 -XCMPLX-0K6 c2"
proof-
  (*existence*)
    show " ex it be BinOpBINOP-1M2-of COMPLEXNUMBERSK3 st  for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds it .BINOP-1K1(c1,c2) =XBOOLE-0R4 c1 -XCMPLX-0K6 c2"
      using binop_2_sch_13 sorry
  (*uniqueness*)
    show " for it1 be BinOpBINOP-1M2-of COMPLEXNUMBERSK3 holds  for it2 be BinOpBINOP-1M2-of COMPLEXNUMBERSK3 holds ( for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds it1 .BINOP-1K1(c1,c2) =XBOOLE-0R4 c1 -XCMPLX-0K6 c2) & ( for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds it2 .BINOP-1K1(c1,c2) =XBOOLE-0R4 c1 -XCMPLX-0K6 c2) implies it1 =HIDDENR1 it2"
      using binop_2_sch_8 sorry
qed "sorry"

mdef binop_2_def_5 ("multcomplexBINOP-2K5" 228 ) where
"func multcomplexBINOP-2K5 \<rightarrow> BinOpBINOP-1M2-of COMPLEXNUMBERSK3 means
  \<lambda>it.  for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds it .BINOP-1K1(c1,c2) =XBOOLE-0R4 c1 *XCMPLX-0K3 c2"
proof-
  (*existence*)
    show " ex it be BinOpBINOP-1M2-of COMPLEXNUMBERSK3 st  for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds it .BINOP-1K1(c1,c2) =XBOOLE-0R4 c1 *XCMPLX-0K3 c2"
      using binop_2_sch_13 sorry
  (*uniqueness*)
    show " for it1 be BinOpBINOP-1M2-of COMPLEXNUMBERSK3 holds  for it2 be BinOpBINOP-1M2-of COMPLEXNUMBERSK3 holds ( for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds it1 .BINOP-1K1(c1,c2) =XBOOLE-0R4 c1 *XCMPLX-0K3 c2) & ( for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds it2 .BINOP-1K1(c1,c2) =XBOOLE-0R4 c1 *XCMPLX-0K3 c2) implies it1 =HIDDENR1 it2"
      using binop_2_sch_8 sorry
qed "sorry"

mdef binop_2_def_6 ("divcomplexBINOP-2K6" 164 ) where
"func divcomplexBINOP-2K6 \<rightarrow> BinOpBINOP-1M2-of COMPLEXNUMBERSK3 means
  \<lambda>it.  for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds it .BINOP-1K1(c1,c2) =XBOOLE-0R4 c1 /XCMPLX-0K7 c2"
proof-
  (*existence*)
    show " ex it be BinOpBINOP-1M2-of COMPLEXNUMBERSK3 st  for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds it .BINOP-1K1(c1,c2) =XBOOLE-0R4 c1 /XCMPLX-0K7 c2"
      using binop_2_sch_13 sorry
  (*uniqueness*)
    show " for it1 be BinOpBINOP-1M2-of COMPLEXNUMBERSK3 holds  for it2 be BinOpBINOP-1M2-of COMPLEXNUMBERSK3 holds ( for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds it1 .BINOP-1K1(c1,c2) =XBOOLE-0R4 c1 /XCMPLX-0K7 c2) & ( for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds it2 .BINOP-1K1(c1,c2) =XBOOLE-0R4 c1 /XCMPLX-0K7 c2) implies it1 =HIDDENR1 it2"
      using binop_2_sch_8 sorry
qed "sorry"

mdef binop_2_def_7 ("comprealBINOP-2K7" 164 ) where
"func comprealBINOP-2K7 \<rightarrow> UnOpBINOP-1M1-of REALNUMBERSK2 means
  \<lambda>it.  for r be RealXREAL-0M1 holds it .FUNCT-1K1 r =HIDDENR1 -XCMPLX-0K4 r"
proof-
  (*existence*)
    show " ex it be UnOpBINOP-1M1-of REALNUMBERSK2 st  for r be RealXREAL-0M1 holds it .FUNCT-1K1 r =HIDDENR1 -XCMPLX-0K4 r"
      using binop_2_sch_19 sorry
  (*uniqueness*)
    show " for it1 be UnOpBINOP-1M1-of REALNUMBERSK2 holds  for it2 be UnOpBINOP-1M1-of REALNUMBERSK2 holds ( for r be RealXREAL-0M1 holds it1 .FUNCT-1K1 r =HIDDENR1 -XCMPLX-0K4 r) & ( for r be RealXREAL-0M1 holds it2 .FUNCT-1K1 r =HIDDENR1 -XCMPLX-0K4 r) implies it1 =HIDDENR1 it2"
      using binop_2_sch_4 sorry
qed "sorry"

mdef binop_2_def_8 ("invrealBINOP-2K8" 164 ) where
"func invrealBINOP-2K8 \<rightarrow> UnOpBINOP-1M1-of REALNUMBERSK2 means
  \<lambda>it.  for r be RealXREAL-0M1 holds it .FUNCT-1K1 r =HIDDENR1 r \<inverse>XCMPLX-0K5"
proof-
  (*existence*)
    show " ex it be UnOpBINOP-1M1-of REALNUMBERSK2 st  for r be RealXREAL-0M1 holds it .FUNCT-1K1 r =HIDDENR1 r \<inverse>XCMPLX-0K5"
      using binop_2_sch_19 sorry
  (*uniqueness*)
    show " for it1 be UnOpBINOP-1M1-of REALNUMBERSK2 holds  for it2 be UnOpBINOP-1M1-of REALNUMBERSK2 holds ( for r be RealXREAL-0M1 holds it1 .FUNCT-1K1 r =HIDDENR1 r \<inverse>XCMPLX-0K5) & ( for r be RealXREAL-0M1 holds it2 .FUNCT-1K1 r =HIDDENR1 r \<inverse>XCMPLX-0K5) implies it1 =HIDDENR1 it2"
      using binop_2_sch_4 sorry
qed "sorry"

mdef binop_2_def_9 ("addrealBINOP-2K9" 164 ) where
"func addrealBINOP-2K9 \<rightarrow> BinOpBINOP-1M2-of REALNUMBERSK2 means
  \<lambda>it.  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds it .BINOP-1K1(r1,r2) =XBOOLE-0R4 r1 +XCMPLX-0K2 r2"
proof-
  (*existence*)
    show " ex it be BinOpBINOP-1M2-of REALNUMBERSK2 st  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds it .BINOP-1K1(r1,r2) =XBOOLE-0R4 r1 +XCMPLX-0K2 r2"
      using binop_2_sch_14 sorry
  (*uniqueness*)
    show " for it1 be BinOpBINOP-1M2-of REALNUMBERSK2 holds  for it2 be BinOpBINOP-1M2-of REALNUMBERSK2 holds ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds it1 .BINOP-1K1(r1,r2) =XBOOLE-0R4 r1 +XCMPLX-0K2 r2) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds it2 .BINOP-1K1(r1,r2) =XBOOLE-0R4 r1 +XCMPLX-0K2 r2) implies it1 =HIDDENR1 it2"
      using binop_2_sch_9 sorry
qed "sorry"

mdef binop_2_def_10 ("diffrealBINOP-2K10" 228 ) where
"func diffrealBINOP-2K10 \<rightarrow> BinOpBINOP-1M2-of REALNUMBERSK2 means
  \<lambda>it.  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds it .BINOP-1K1(r1,r2) =XBOOLE-0R4 r1 -XCMPLX-0K6 r2"
proof-
  (*existence*)
    show " ex it be BinOpBINOP-1M2-of REALNUMBERSK2 st  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds it .BINOP-1K1(r1,r2) =XBOOLE-0R4 r1 -XCMPLX-0K6 r2"
      using binop_2_sch_14 sorry
  (*uniqueness*)
    show " for it1 be BinOpBINOP-1M2-of REALNUMBERSK2 holds  for it2 be BinOpBINOP-1M2-of REALNUMBERSK2 holds ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds it1 .BINOP-1K1(r1,r2) =XBOOLE-0R4 r1 -XCMPLX-0K6 r2) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds it2 .BINOP-1K1(r1,r2) =XBOOLE-0R4 r1 -XCMPLX-0K6 r2) implies it1 =HIDDENR1 it2"
      using binop_2_sch_9 sorry
qed "sorry"

mdef binop_2_def_11 ("multrealBINOP-2K11" 164 ) where
"func multrealBINOP-2K11 \<rightarrow> BinOpBINOP-1M2-of REALNUMBERSK2 means
  \<lambda>it.  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds it .BINOP-1K1(r1,r2) =XBOOLE-0R4 r1 *XCMPLX-0K3 r2"
proof-
  (*existence*)
    show " ex it be BinOpBINOP-1M2-of REALNUMBERSK2 st  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds it .BINOP-1K1(r1,r2) =XBOOLE-0R4 r1 *XCMPLX-0K3 r2"
      using binop_2_sch_14 sorry
  (*uniqueness*)
    show " for it1 be BinOpBINOP-1M2-of REALNUMBERSK2 holds  for it2 be BinOpBINOP-1M2-of REALNUMBERSK2 holds ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds it1 .BINOP-1K1(r1,r2) =XBOOLE-0R4 r1 *XCMPLX-0K3 r2) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds it2 .BINOP-1K1(r1,r2) =XBOOLE-0R4 r1 *XCMPLX-0K3 r2) implies it1 =HIDDENR1 it2"
      using binop_2_sch_9 sorry
qed "sorry"

mdef binop_2_def_12 ("divrealBINOP-2K12" 164 ) where
"func divrealBINOP-2K12 \<rightarrow> BinOpBINOP-1M2-of REALNUMBERSK2 means
  \<lambda>it.  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds it .BINOP-1K1(r1,r2) =XBOOLE-0R4 r1 /XCMPLX-0K7 r2"
proof-
  (*existence*)
    show " ex it be BinOpBINOP-1M2-of REALNUMBERSK2 st  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds it .BINOP-1K1(r1,r2) =XBOOLE-0R4 r1 /XCMPLX-0K7 r2"
      using binop_2_sch_14 sorry
  (*uniqueness*)
    show " for it1 be BinOpBINOP-1M2-of REALNUMBERSK2 holds  for it2 be BinOpBINOP-1M2-of REALNUMBERSK2 holds ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds it1 .BINOP-1K1(r1,r2) =XBOOLE-0R4 r1 /XCMPLX-0K7 r2) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds it2 .BINOP-1K1(r1,r2) =XBOOLE-0R4 r1 /XCMPLX-0K7 r2) implies it1 =HIDDENR1 it2"
      using binop_2_sch_9 sorry
qed "sorry"

mdef binop_2_def_13 ("compratBINOP-2K13" 164 ) where
"func compratBINOP-2K13 \<rightarrow> UnOpBINOP-1M1-of RATRAT-1K1 means
  \<lambda>it.  for w be RationalRAT-1M1 holds it .FUNCT-1K1 w =HIDDENR1 -XCMPLX-0K4 w"
proof-
  (*existence*)
    show " ex it be UnOpBINOP-1M1-of RATRAT-1K1 st  for w be RationalRAT-1M1 holds it .FUNCT-1K1 w =HIDDENR1 -XCMPLX-0K4 w"
      using binop_2_sch_20 sorry
  (*uniqueness*)
    show " for it1 be UnOpBINOP-1M1-of RATRAT-1K1 holds  for it2 be UnOpBINOP-1M1-of RATRAT-1K1 holds ( for w be RationalRAT-1M1 holds it1 .FUNCT-1K1 w =HIDDENR1 -XCMPLX-0K4 w) & ( for w be RationalRAT-1M1 holds it2 .FUNCT-1K1 w =HIDDENR1 -XCMPLX-0K4 w) implies it1 =HIDDENR1 it2"
      using binop_2_sch_5 sorry
qed "sorry"

mdef binop_2_def_14 ("invratBINOP-2K14" 164 ) where
"func invratBINOP-2K14 \<rightarrow> UnOpBINOP-1M1-of RATRAT-1K1 means
  \<lambda>it.  for w be RationalRAT-1M1 holds it .FUNCT-1K1 w =HIDDENR1 w \<inverse>XCMPLX-0K5"
proof-
  (*existence*)
    show " ex it be UnOpBINOP-1M1-of RATRAT-1K1 st  for w be RationalRAT-1M1 holds it .FUNCT-1K1 w =HIDDENR1 w \<inverse>XCMPLX-0K5"
      using binop_2_sch_20 sorry
  (*uniqueness*)
    show " for it1 be UnOpBINOP-1M1-of RATRAT-1K1 holds  for it2 be UnOpBINOP-1M1-of RATRAT-1K1 holds ( for w be RationalRAT-1M1 holds it1 .FUNCT-1K1 w =HIDDENR1 w \<inverse>XCMPLX-0K5) & ( for w be RationalRAT-1M1 holds it2 .FUNCT-1K1 w =HIDDENR1 w \<inverse>XCMPLX-0K5) implies it1 =HIDDENR1 it2"
      using binop_2_sch_5 sorry
qed "sorry"

mdef binop_2_def_15 ("addratBINOP-2K15" 164 ) where
"func addratBINOP-2K15 \<rightarrow> BinOpBINOP-1M2-of RATRAT-1K1 means
  \<lambda>it.  for w1 be RationalRAT-1M1 holds  for w2 be RationalRAT-1M1 holds it .BINOP-1K1(w1,w2) =XBOOLE-0R4 w1 +XCMPLX-0K2 w2"
proof-
  (*existence*)
    show " ex it be BinOpBINOP-1M2-of RATRAT-1K1 st  for w1 be RationalRAT-1M1 holds  for w2 be RationalRAT-1M1 holds it .BINOP-1K1(w1,w2) =XBOOLE-0R4 w1 +XCMPLX-0K2 w2"
      using binop_2_sch_15 sorry
  (*uniqueness*)
    show " for it1 be BinOpBINOP-1M2-of RATRAT-1K1 holds  for it2 be BinOpBINOP-1M2-of RATRAT-1K1 holds ( for w1 be RationalRAT-1M1 holds  for w2 be RationalRAT-1M1 holds it1 .BINOP-1K1(w1,w2) =XBOOLE-0R4 w1 +XCMPLX-0K2 w2) & ( for w1 be RationalRAT-1M1 holds  for w2 be RationalRAT-1M1 holds it2 .BINOP-1K1(w1,w2) =XBOOLE-0R4 w1 +XCMPLX-0K2 w2) implies it1 =HIDDENR1 it2"
      using binop_2_sch_10 sorry
qed "sorry"

mdef binop_2_def_16 ("diffratBINOP-2K16" 164 ) where
"func diffratBINOP-2K16 \<rightarrow> BinOpBINOP-1M2-of RATRAT-1K1 means
  \<lambda>it.  for w1 be RationalRAT-1M1 holds  for w2 be RationalRAT-1M1 holds it .BINOP-1K1(w1,w2) =XBOOLE-0R4 w1 -XCMPLX-0K6 w2"
proof-
  (*existence*)
    show " ex it be BinOpBINOP-1M2-of RATRAT-1K1 st  for w1 be RationalRAT-1M1 holds  for w2 be RationalRAT-1M1 holds it .BINOP-1K1(w1,w2) =XBOOLE-0R4 w1 -XCMPLX-0K6 w2"
      using binop_2_sch_15 sorry
  (*uniqueness*)
    show " for it1 be BinOpBINOP-1M2-of RATRAT-1K1 holds  for it2 be BinOpBINOP-1M2-of RATRAT-1K1 holds ( for w1 be RationalRAT-1M1 holds  for w2 be RationalRAT-1M1 holds it1 .BINOP-1K1(w1,w2) =XBOOLE-0R4 w1 -XCMPLX-0K6 w2) & ( for w1 be RationalRAT-1M1 holds  for w2 be RationalRAT-1M1 holds it2 .BINOP-1K1(w1,w2) =XBOOLE-0R4 w1 -XCMPLX-0K6 w2) implies it1 =HIDDENR1 it2"
      using binop_2_sch_10 sorry
qed "sorry"

mdef binop_2_def_17 ("multratBINOP-2K17" 164 ) where
"func multratBINOP-2K17 \<rightarrow> BinOpBINOP-1M2-of RATRAT-1K1 means
  \<lambda>it.  for w1 be RationalRAT-1M1 holds  for w2 be RationalRAT-1M1 holds it .BINOP-1K1(w1,w2) =XBOOLE-0R4 w1 *XCMPLX-0K3 w2"
proof-
  (*existence*)
    show " ex it be BinOpBINOP-1M2-of RATRAT-1K1 st  for w1 be RationalRAT-1M1 holds  for w2 be RationalRAT-1M1 holds it .BINOP-1K1(w1,w2) =XBOOLE-0R4 w1 *XCMPLX-0K3 w2"
      using binop_2_sch_15 sorry
  (*uniqueness*)
    show " for it1 be BinOpBINOP-1M2-of RATRAT-1K1 holds  for it2 be BinOpBINOP-1M2-of RATRAT-1K1 holds ( for w1 be RationalRAT-1M1 holds  for w2 be RationalRAT-1M1 holds it1 .BINOP-1K1(w1,w2) =XBOOLE-0R4 w1 *XCMPLX-0K3 w2) & ( for w1 be RationalRAT-1M1 holds  for w2 be RationalRAT-1M1 holds it2 .BINOP-1K1(w1,w2) =XBOOLE-0R4 w1 *XCMPLX-0K3 w2) implies it1 =HIDDENR1 it2"
      using binop_2_sch_10 sorry
qed "sorry"

mdef binop_2_def_18 ("divratBINOP-2K18" 164 ) where
"func divratBINOP-2K18 \<rightarrow> BinOpBINOP-1M2-of RATRAT-1K1 means
  \<lambda>it.  for w1 be RationalRAT-1M1 holds  for w2 be RationalRAT-1M1 holds it .BINOP-1K1(w1,w2) =XBOOLE-0R4 w1 /XCMPLX-0K7 w2"
proof-
  (*existence*)
    show " ex it be BinOpBINOP-1M2-of RATRAT-1K1 st  for w1 be RationalRAT-1M1 holds  for w2 be RationalRAT-1M1 holds it .BINOP-1K1(w1,w2) =XBOOLE-0R4 w1 /XCMPLX-0K7 w2"
      using binop_2_sch_15 sorry
  (*uniqueness*)
    show " for it1 be BinOpBINOP-1M2-of RATRAT-1K1 holds  for it2 be BinOpBINOP-1M2-of RATRAT-1K1 holds ( for w1 be RationalRAT-1M1 holds  for w2 be RationalRAT-1M1 holds it1 .BINOP-1K1(w1,w2) =XBOOLE-0R4 w1 /XCMPLX-0K7 w2) & ( for w1 be RationalRAT-1M1 holds  for w2 be RationalRAT-1M1 holds it2 .BINOP-1K1(w1,w2) =XBOOLE-0R4 w1 /XCMPLX-0K7 w2) implies it1 =HIDDENR1 it2"
      using binop_2_sch_10 sorry
qed "sorry"

mdef binop_2_def_19 ("compintBINOP-2K19" 164 ) where
"func compintBINOP-2K19 \<rightarrow> UnOpBINOP-1M1-of INTNUMBERSK5 means
  \<lambda>it.  for i be IntegerINT-1M1 holds it .FUNCT-1K1 i =HIDDENR1 -XCMPLX-0K4 i"
proof-
  (*existence*)
    show " ex it be UnOpBINOP-1M1-of INTNUMBERSK5 st  for i be IntegerINT-1M1 holds it .FUNCT-1K1 i =HIDDENR1 -XCMPLX-0K4 i"
      using binop_2_sch_21 sorry
  (*uniqueness*)
    show " for it1 be UnOpBINOP-1M1-of INTNUMBERSK5 holds  for it2 be UnOpBINOP-1M1-of INTNUMBERSK5 holds ( for i be IntegerINT-1M1 holds it1 .FUNCT-1K1 i =HIDDENR1 -XCMPLX-0K4 i) & ( for i be IntegerINT-1M1 holds it2 .FUNCT-1K1 i =HIDDENR1 -XCMPLX-0K4 i) implies it1 =HIDDENR1 it2"
      using binop_2_sch_6 sorry
qed "sorry"

mdef binop_2_def_20 ("addintBINOP-2K20" 164 ) where
"func addintBINOP-2K20 \<rightarrow> BinOpBINOP-1M2-of INTNUMBERSK5 means
  \<lambda>it.  for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds it .BINOP-1K1(i1,i2) =XBOOLE-0R4 i1 +XCMPLX-0K2 i2"
proof-
  (*existence*)
    show " ex it be BinOpBINOP-1M2-of INTNUMBERSK5 st  for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds it .BINOP-1K1(i1,i2) =XBOOLE-0R4 i1 +XCMPLX-0K2 i2"
      using binop_2_sch_16 sorry
  (*uniqueness*)
    show " for it1 be BinOpBINOP-1M2-of INTNUMBERSK5 holds  for it2 be BinOpBINOP-1M2-of INTNUMBERSK5 holds ( for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds it1 .BINOP-1K1(i1,i2) =XBOOLE-0R4 i1 +XCMPLX-0K2 i2) & ( for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds it2 .BINOP-1K1(i1,i2) =XBOOLE-0R4 i1 +XCMPLX-0K2 i2) implies it1 =HIDDENR1 it2"
      using binop_2_sch_11 sorry
qed "sorry"

mdef binop_2_def_21 ("diffintBINOP-2K21" 164 ) where
"func diffintBINOP-2K21 \<rightarrow> BinOpBINOP-1M2-of INTNUMBERSK5 means
  \<lambda>it.  for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds it .BINOP-1K1(i1,i2) =XBOOLE-0R4 i1 -XCMPLX-0K6 i2"
proof-
  (*existence*)
    show " ex it be BinOpBINOP-1M2-of INTNUMBERSK5 st  for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds it .BINOP-1K1(i1,i2) =XBOOLE-0R4 i1 -XCMPLX-0K6 i2"
      using binop_2_sch_16 sorry
  (*uniqueness*)
    show " for it1 be BinOpBINOP-1M2-of INTNUMBERSK5 holds  for it2 be BinOpBINOP-1M2-of INTNUMBERSK5 holds ( for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds it1 .BINOP-1K1(i1,i2) =XBOOLE-0R4 i1 -XCMPLX-0K6 i2) & ( for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds it2 .BINOP-1K1(i1,i2) =XBOOLE-0R4 i1 -XCMPLX-0K6 i2) implies it1 =HIDDENR1 it2"
      using binop_2_sch_11 sorry
qed "sorry"

mdef binop_2_def_22 ("multintBINOP-2K22" 164 ) where
"func multintBINOP-2K22 \<rightarrow> BinOpBINOP-1M2-of INTNUMBERSK5 means
  \<lambda>it.  for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds it .BINOP-1K1(i1,i2) =XBOOLE-0R4 i1 *XCMPLX-0K3 i2"
proof-
  (*existence*)
    show " ex it be BinOpBINOP-1M2-of INTNUMBERSK5 st  for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds it .BINOP-1K1(i1,i2) =XBOOLE-0R4 i1 *XCMPLX-0K3 i2"
      using binop_2_sch_16 sorry
  (*uniqueness*)
    show " for it1 be BinOpBINOP-1M2-of INTNUMBERSK5 holds  for it2 be BinOpBINOP-1M2-of INTNUMBERSK5 holds ( for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds it1 .BINOP-1K1(i1,i2) =XBOOLE-0R4 i1 *XCMPLX-0K3 i2) & ( for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds it2 .BINOP-1K1(i1,i2) =XBOOLE-0R4 i1 *XCMPLX-0K3 i2) implies it1 =HIDDENR1 it2"
      using binop_2_sch_11 sorry
qed "sorry"

mdef binop_2_def_23 ("addnatBINOP-2K23" 164 ) where
"func addnatBINOP-2K23 \<rightarrow> BinOpBINOP-1M2-of NATNUMBERSK1 means
  \<lambda>it.  for n1 be NatNAT-1M1 holds  for n2 be NatNAT-1M1 holds it .BINOP-1K1(n1,n2) =XBOOLE-0R4 n1 +XCMPLX-0K2 n2"
proof-
  (*existence*)
    show " ex it be BinOpBINOP-1M2-of NATNUMBERSK1 st  for n1 be NatNAT-1M1 holds  for n2 be NatNAT-1M1 holds it .BINOP-1K1(n1,n2) =XBOOLE-0R4 n1 +XCMPLX-0K2 n2"
      using binop_2_sch_17 sorry
  (*uniqueness*)
    show " for it1 be BinOpBINOP-1M2-of NATNUMBERSK1 holds  for it2 be BinOpBINOP-1M2-of NATNUMBERSK1 holds ( for n1 be NatNAT-1M1 holds  for n2 be NatNAT-1M1 holds it1 .BINOP-1K1(n1,n2) =XBOOLE-0R4 n1 +XCMPLX-0K2 n2) & ( for n1 be NatNAT-1M1 holds  for n2 be NatNAT-1M1 holds it2 .BINOP-1K1(n1,n2) =XBOOLE-0R4 n1 +XCMPLX-0K2 n2) implies it1 =HIDDENR1 it2"
      using binop_2_sch_12 sorry
qed "sorry"

mdef binop_2_def_24 ("multnatBINOP-2K24" 164 ) where
"func multnatBINOP-2K24 \<rightarrow> BinOpBINOP-1M2-of NATNUMBERSK1 means
  \<lambda>it.  for n1 be NatNAT-1M1 holds  for n2 be NatNAT-1M1 holds it .BINOP-1K1(n1,n2) =XBOOLE-0R4 n1 *XCMPLX-0K3 n2"
proof-
  (*existence*)
    show " ex it be BinOpBINOP-1M2-of NATNUMBERSK1 st  for n1 be NatNAT-1M1 holds  for n2 be NatNAT-1M1 holds it .BINOP-1K1(n1,n2) =XBOOLE-0R4 n1 *XCMPLX-0K3 n2"
      using binop_2_sch_17 sorry
  (*uniqueness*)
    show " for it1 be BinOpBINOP-1M2-of NATNUMBERSK1 holds  for it2 be BinOpBINOP-1M2-of NATNUMBERSK1 holds ( for n1 be NatNAT-1M1 holds  for n2 be NatNAT-1M1 holds it1 .BINOP-1K1(n1,n2) =XBOOLE-0R4 n1 *XCMPLX-0K3 n2) & ( for n1 be NatNAT-1M1 holds  for n2 be NatNAT-1M1 holds it2 .BINOP-1K1(n1,n2) =XBOOLE-0R4 n1 *XCMPLX-0K3 n2) implies it1 =HIDDENR1 it2"
      using binop_2_sch_12 sorry
qed "sorry"

mtheorem binop_2_cl_2:
"cluster addcomplexBINOP-2K3 as-term-is commutativeBINOP-1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>"
proof
(*coherence*)
  show "addcomplexBINOP-2K3 be commutativeBINOP-1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>"
  proof-
    have "addcomplexBINOP-2K3 be commutativeBINOP-1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> & addcomplexBINOP-2K3 be associativeBINOP-1V2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>"
    proof(rule conjMI)
      show "addcomplexBINOP-2K3 be commutativeBINOP-1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>"
      proof-
        have " for c1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for c2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c2) =HIDDENR1 addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c2,c1)"
        proof(rule ballI,rule ballI)
          fix c1 assume [ty]: "c1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
          fix c2 assume [ty]: "c2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
          have "addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c2) =HIDDENR1 c1 +XCMPLX-0K2 c2"
            using binop_2_def_3 sorry
          also have "... = addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c2,c1)"
            using binop_2_def_3 sorry
          finally show "addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c2) =HIDDENR1 addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c2,c1)"
             sorry
        qed "sorry"
        thus "addcomplexBINOP-2K3 be commutativeBINOP-1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>"
          using binop_1_def_2 sorry
      qed
      have " for c1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for c2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for c3 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c2,c3)) =HIDDENR1 addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c2),c3)"
      proof(rule ballI,rule ballI,rule ballI)
        fix c1 assume [ty]: "c1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
        fix c2 assume [ty]: "c2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
        fix c3 assume [ty]: "c3 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
        have "addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c2,c3)) =HIDDENR1 c1 +XCMPLX-0K2 addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c2,c3)"
          using binop_2_def_3 sorry
        also have "... = c1 +XCMPLX-0K2 (c2 +XCMPLX-0K2 c3)"
          using binop_2_def_3 sorry
        also have "... = (c1 +XCMPLX-0K2 c2)+XCMPLX-0K2 c3"
           sorry
        also have "... = addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c2) +XCMPLX-0K2 c3"
          using binop_2_def_3 sorry
        also have "... = addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c2),c3)"
          using binop_2_def_3 sorry
        finally show "addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c2,c3)) =HIDDENR1 addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c2),c3)"
           sorry
      qed "sorry"
      thus "addcomplexBINOP-2K3 be associativeBINOP-1V2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>"
        using binop_1_def_3 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem binop_2_cl_3:
"cluster multcomplexBINOP-2K5 as-term-is commutativeBINOP-1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>"
proof
(*coherence*)
  show "multcomplexBINOP-2K5 be commutativeBINOP-1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>"
  proof-
    have "multcomplexBINOP-2K5 be commutativeBINOP-1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> & multcomplexBINOP-2K5 be associativeBINOP-1V2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>"
    proof(rule conjMI)
      show "multcomplexBINOP-2K5 be commutativeBINOP-1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>"
      proof-
        have " for c1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for c2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c2) =HIDDENR1 multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c2,c1)"
        proof(rule ballI,rule ballI)
          fix c1 assume [ty]: "c1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
          fix c2 assume [ty]: "c2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
          have "multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c2) =HIDDENR1 c1 *XCMPLX-0K3 c2"
            using binop_2_def_5 sorry
          also have "... = multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c2,c1)"
            using binop_2_def_5 sorry
          finally show "multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c2) =HIDDENR1 multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c2,c1)"
             sorry
        qed "sorry"
        thus "multcomplexBINOP-2K5 be commutativeBINOP-1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>"
          using binop_1_def_2 sorry
      qed
      have " for c1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for c2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for c3 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c2,c3)) =HIDDENR1 multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c2),c3)"
      proof(rule ballI,rule ballI,rule ballI)
        fix c1 assume [ty]: "c1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
        fix c2 assume [ty]: "c2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
        fix c3 assume [ty]: "c3 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
        have "multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c2,c3)) =HIDDENR1 c1 *XCMPLX-0K3 multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c2,c3)"
          using binop_2_def_5 sorry
        also have "... = c1 *XCMPLX-0K3 (c2 *XCMPLX-0K3 c3)"
          using binop_2_def_5 sorry
        also have "... = (c1 *XCMPLX-0K3 c2)*XCMPLX-0K3 c3"
           sorry
        also have "... = multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c2) *XCMPLX-0K3 c3"
          using binop_2_def_5 sorry
        also have "... = multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c2),c3)"
          using binop_2_def_5 sorry
        finally show "multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c2,c3)) =HIDDENR1 multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c2),c3)"
           sorry
      qed "sorry"
      thus "multcomplexBINOP-2K5 be associativeBINOP-1V2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>"
        using binop_1_def_3 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem binop_2_cl_4:
"cluster addrealBINOP-2K9 as-term-is commutativeBINOP-1V1\<^bsub>(REALNUMBERSK2)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(REALNUMBERSK2)\<^esub>"
proof
(*coherence*)
  show "addrealBINOP-2K9 be commutativeBINOP-1V1\<^bsub>(REALNUMBERSK2)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(REALNUMBERSK2)\<^esub>"
  proof-
    have "addrealBINOP-2K9 be commutativeBINOP-1V1\<^bsub>(REALNUMBERSK2)\<^esub> & addrealBINOP-2K9 be associativeBINOP-1V2\<^bsub>(REALNUMBERSK2)\<^esub>"
    proof(rule conjMI)
      show "addrealBINOP-2K9 be commutativeBINOP-1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
      proof-
        have " for r1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for r2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds (addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r1,r2) =HIDDENR1 (addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r2,r1)"
        proof(rule ballI,rule ballI)
          fix r1 assume [ty]: "r1 be ElementSUBSET-1M1-of REALNUMBERSK2"
          fix r2 assume [ty]: "r2 be ElementSUBSET-1M1-of REALNUMBERSK2"
          have "(addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r1,r2) =HIDDENR1 r1 +XCMPLX-0K2 r2"
            using binop_2_def_9 sorry
          also have "... = (addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r2,r1)"
            using binop_2_def_9 sorry
          finally show "(addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r1,r2) =HIDDENR1 (addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r2,r1)"
             sorry
        qed "sorry"
        thus "addrealBINOP-2K9 be commutativeBINOP-1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
          using binop_1_def_2 sorry
      qed
      have " for r1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for r2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for r3 be ElementSUBSET-1M1-of REALNUMBERSK2 holds (addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r1,(addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r2,r3)) =HIDDENR1 (addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>((addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r1,r2),r3)"
      proof(rule ballI,rule ballI,rule ballI)
        fix r1 assume [ty]: "r1 be ElementSUBSET-1M1-of REALNUMBERSK2"
        fix r2 assume [ty]: "r2 be ElementSUBSET-1M1-of REALNUMBERSK2"
        fix r3 assume [ty]: "r3 be ElementSUBSET-1M1-of REALNUMBERSK2"
        have "(addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r1,(addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r2,r3)) =HIDDENR1 r1 +XCMPLX-0K2 (addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r2,r3)"
          using binop_2_def_9 sorry
        also have "... = r1 +XCMPLX-0K2 (r2 +XCMPLX-0K2 r3)"
          using binop_2_def_9 sorry
        also have "... = (r1 +XCMPLX-0K2 r2)+XCMPLX-0K2 r3"
           sorry
        also have "... = (addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r1,r2) +XCMPLX-0K2 r3"
          using binop_2_def_9 sorry
        also have "... = (addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>((addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r1,r2),r3)"
          using binop_2_def_9 sorry
        finally show "(addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r1,(addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r2,r3)) =HIDDENR1 (addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>((addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r1,r2),r3)"
           sorry
      qed "sorry"
      thus "addrealBINOP-2K9 be associativeBINOP-1V2\<^bsub>(REALNUMBERSK2)\<^esub>"
        using binop_1_def_3 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem binop_2_cl_5:
"cluster multrealBINOP-2K11 as-term-is commutativeBINOP-1V1\<^bsub>(REALNUMBERSK2)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(REALNUMBERSK2)\<^esub>"
proof
(*coherence*)
  show "multrealBINOP-2K11 be commutativeBINOP-1V1\<^bsub>(REALNUMBERSK2)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(REALNUMBERSK2)\<^esub>"
  proof-
    have "multrealBINOP-2K11 be commutativeBINOP-1V1\<^bsub>(REALNUMBERSK2)\<^esub> & multrealBINOP-2K11 be associativeBINOP-1V2\<^bsub>(REALNUMBERSK2)\<^esub>"
    proof(rule conjMI)
      show "multrealBINOP-2K11 be commutativeBINOP-1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
      proof-
        have " for r1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for r2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds (multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r1,r2) =HIDDENR1 (multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r2,r1)"
        proof(rule ballI,rule ballI)
          fix r1 assume [ty]: "r1 be ElementSUBSET-1M1-of REALNUMBERSK2"
          fix r2 assume [ty]: "r2 be ElementSUBSET-1M1-of REALNUMBERSK2"
          have "(multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r1,r2) =HIDDENR1 r1 *XCMPLX-0K3 r2"
            using binop_2_def_11 sorry
          also have "... = (multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r2,r1)"
            using binop_2_def_11 sorry
          finally show "(multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r1,r2) =HIDDENR1 (multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r2,r1)"
             sorry
        qed "sorry"
        thus "multrealBINOP-2K11 be commutativeBINOP-1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
          using binop_1_def_2 sorry
      qed
      have " for r1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for r2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for r3 be ElementSUBSET-1M1-of REALNUMBERSK2 holds (multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r1,(multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r2,r3)) =HIDDENR1 (multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>((multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r1,r2),r3)"
      proof(rule ballI,rule ballI,rule ballI)
        fix r1 assume [ty]: "r1 be ElementSUBSET-1M1-of REALNUMBERSK2"
        fix r2 assume [ty]: "r2 be ElementSUBSET-1M1-of REALNUMBERSK2"
        fix r3 assume [ty]: "r3 be ElementSUBSET-1M1-of REALNUMBERSK2"
        have "(multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r1,(multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r2,r3)) =HIDDENR1 r1 *XCMPLX-0K3 (multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r2,r3)"
          using binop_2_def_11 sorry
        also have "... = r1 *XCMPLX-0K3 (r2 *XCMPLX-0K3 r3)"
          using binop_2_def_11 sorry
        also have "... = (r1 *XCMPLX-0K3 r2)*XCMPLX-0K3 r3"
           sorry
        also have "... = (multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r1,r2) *XCMPLX-0K3 r3"
          using binop_2_def_11 sorry
        also have "... = (multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>((multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r1,r2),r3)"
          using binop_2_def_11 sorry
        finally show "(multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r1,(multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r2,r3)) =HIDDENR1 (multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>((multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r1,r2),r3)"
           sorry
      qed "sorry"
      thus "multrealBINOP-2K11 be associativeBINOP-1V2\<^bsub>(REALNUMBERSK2)\<^esub>"
        using binop_1_def_3 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem binop_2_cl_6:
"cluster addratBINOP-2K15 as-term-is commutativeBINOP-1V1\<^bsub>(RATRAT-1K1)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(RATRAT-1K1)\<^esub>"
proof
(*coherence*)
  show "addratBINOP-2K15 be commutativeBINOP-1V1\<^bsub>(RATRAT-1K1)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(RATRAT-1K1)\<^esub>"
  proof-
    have "addratBINOP-2K15 be commutativeBINOP-1V1\<^bsub>(RATRAT-1K1)\<^esub> & addratBINOP-2K15 be associativeBINOP-1V2\<^bsub>(RATRAT-1K1)\<^esub>"
    proof(rule conjMI)
      show "addratBINOP-2K15 be commutativeBINOP-1V1\<^bsub>(RATRAT-1K1)\<^esub>"
      proof-
        have " for w1 be ElementSUBSET-1M1-of RATRAT-1K1 holds  for w2 be ElementSUBSET-1M1-of RATRAT-1K1 holds (addratBINOP-2K15).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(w1,w2) =HIDDENR1 (addratBINOP-2K15).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(w2,w1)"
        proof(rule ballI,rule ballI)
          fix w1 assume [ty]: "w1 be ElementSUBSET-1M1-of RATRAT-1K1"
          fix w2 assume [ty]: "w2 be ElementSUBSET-1M1-of RATRAT-1K1"
          have "(addratBINOP-2K15).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(w1,w2) =HIDDENR1 w1 +XCMPLX-0K2 w2"
            using binop_2_def_15 sorry
          also have "... = (addratBINOP-2K15).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(w2,w1)"
            using binop_2_def_15 sorry
          finally show "(addratBINOP-2K15).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(w1,w2) =HIDDENR1 (addratBINOP-2K15).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(w2,w1)"
             sorry
        qed "sorry"
        thus "addratBINOP-2K15 be commutativeBINOP-1V1\<^bsub>(RATRAT-1K1)\<^esub>"
          using binop_1_def_2 sorry
      qed
      have " for w1 be ElementSUBSET-1M1-of RATRAT-1K1 holds  for w2 be ElementSUBSET-1M1-of RATRAT-1K1 holds  for w3 be ElementSUBSET-1M1-of RATRAT-1K1 holds (addratBINOP-2K15).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(w1,(addratBINOP-2K15).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(w2,w3)) =HIDDENR1 (addratBINOP-2K15).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>((addratBINOP-2K15).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(w1,w2),w3)"
      proof(rule ballI,rule ballI,rule ballI)
        fix w1 assume [ty]: "w1 be ElementSUBSET-1M1-of RATRAT-1K1"
        fix w2 assume [ty]: "w2 be ElementSUBSET-1M1-of RATRAT-1K1"
        fix w3 assume [ty]: "w3 be ElementSUBSET-1M1-of RATRAT-1K1"
        have "(addratBINOP-2K15).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(w1,(addratBINOP-2K15).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(w2,w3)) =HIDDENR1 w1 +XCMPLX-0K2 (addratBINOP-2K15).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(w2,w3)"
          using binop_2_def_15 sorry
        also have "... = w1 +XCMPLX-0K2 (w2 +XCMPLX-0K2 w3)"
          using binop_2_def_15 sorry
        also have "... = (w1 +XCMPLX-0K2 w2)+XCMPLX-0K2 w3"
           sorry
        also have "... = (addratBINOP-2K15).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(w1,w2) +XCMPLX-0K2 w3"
          using binop_2_def_15 sorry
        also have "... = (addratBINOP-2K15).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>((addratBINOP-2K15).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(w1,w2),w3)"
          using binop_2_def_15 sorry
        finally show "(addratBINOP-2K15).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(w1,(addratBINOP-2K15).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(w2,w3)) =HIDDENR1 (addratBINOP-2K15).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>((addratBINOP-2K15).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(w1,w2),w3)"
           sorry
      qed "sorry"
      thus "addratBINOP-2K15 be associativeBINOP-1V2\<^bsub>(RATRAT-1K1)\<^esub>"
        using binop_1_def_3 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem binop_2_cl_7:
"cluster multratBINOP-2K17 as-term-is commutativeBINOP-1V1\<^bsub>(RATRAT-1K1)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(RATRAT-1K1)\<^esub>"
proof
(*coherence*)
  show "multratBINOP-2K17 be commutativeBINOP-1V1\<^bsub>(RATRAT-1K1)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(RATRAT-1K1)\<^esub>"
  proof-
    have "multratBINOP-2K17 be commutativeBINOP-1V1\<^bsub>(RATRAT-1K1)\<^esub> & multratBINOP-2K17 be associativeBINOP-1V2\<^bsub>(RATRAT-1K1)\<^esub>"
    proof(rule conjMI)
      show "multratBINOP-2K17 be commutativeBINOP-1V1\<^bsub>(RATRAT-1K1)\<^esub>"
      proof-
        have " for w1 be ElementSUBSET-1M1-of RATRAT-1K1 holds  for w2 be ElementSUBSET-1M1-of RATRAT-1K1 holds (multratBINOP-2K17).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(w1,w2) =HIDDENR1 (multratBINOP-2K17).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(w2,w1)"
        proof(rule ballI,rule ballI)
          fix w1 assume [ty]: "w1 be ElementSUBSET-1M1-of RATRAT-1K1"
          fix w2 assume [ty]: "w2 be ElementSUBSET-1M1-of RATRAT-1K1"
          have "(multratBINOP-2K17).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(w1,w2) =HIDDENR1 w1 *XCMPLX-0K3 w2"
            using binop_2_def_17 sorry
          also have "... = (multratBINOP-2K17).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(w2,w1)"
            using binop_2_def_17 sorry
          finally show "(multratBINOP-2K17).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(w1,w2) =HIDDENR1 (multratBINOP-2K17).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(w2,w1)"
             sorry
        qed "sorry"
        thus "multratBINOP-2K17 be commutativeBINOP-1V1\<^bsub>(RATRAT-1K1)\<^esub>"
          using binop_1_def_2 sorry
      qed
      have " for w1 be ElementSUBSET-1M1-of RATRAT-1K1 holds  for w2 be ElementSUBSET-1M1-of RATRAT-1K1 holds  for w3 be ElementSUBSET-1M1-of RATRAT-1K1 holds (multratBINOP-2K17).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(w1,(multratBINOP-2K17).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(w2,w3)) =HIDDENR1 (multratBINOP-2K17).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>((multratBINOP-2K17).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(w1,w2),w3)"
      proof(rule ballI,rule ballI,rule ballI)
        fix w1 assume [ty]: "w1 be ElementSUBSET-1M1-of RATRAT-1K1"
        fix w2 assume [ty]: "w2 be ElementSUBSET-1M1-of RATRAT-1K1"
        fix w3 assume [ty]: "w3 be ElementSUBSET-1M1-of RATRAT-1K1"
        have "(multratBINOP-2K17).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(w1,(multratBINOP-2K17).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(w2,w3)) =HIDDENR1 w1 *XCMPLX-0K3 (multratBINOP-2K17).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(w2,w3)"
          using binop_2_def_17 sorry
        also have "... = w1 *XCMPLX-0K3 (w2 *XCMPLX-0K3 w3)"
          using binop_2_def_17 sorry
        also have "... = (w1 *XCMPLX-0K3 w2)*XCMPLX-0K3 w3"
           sorry
        also have "... = (multratBINOP-2K17).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(w1,w2) *XCMPLX-0K3 w3"
          using binop_2_def_17 sorry
        also have "... = (multratBINOP-2K17).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>((multratBINOP-2K17).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(w1,w2),w3)"
          using binop_2_def_17 sorry
        finally show "(multratBINOP-2K17).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(w1,(multratBINOP-2K17).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(w2,w3)) =HIDDENR1 (multratBINOP-2K17).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>((multratBINOP-2K17).BINOP-1K4\<^bsub>(RATRAT-1K1)\<^esub>(w1,w2),w3)"
           sorry
      qed "sorry"
      thus "multratBINOP-2K17 be associativeBINOP-1V2\<^bsub>(RATRAT-1K1)\<^esub>"
        using binop_1_def_3 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem binop_2_cl_8:
"cluster addintBINOP-2K20 as-term-is commutativeBINOP-1V1\<^bsub>(INTNUMBERSK5)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(INTNUMBERSK5)\<^esub>"
proof
(*coherence*)
  show "addintBINOP-2K20 be commutativeBINOP-1V1\<^bsub>(INTNUMBERSK5)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(INTNUMBERSK5)\<^esub>"
  proof-
    have "addintBINOP-2K20 be commutativeBINOP-1V1\<^bsub>(INTNUMBERSK5)\<^esub> & addintBINOP-2K20 be associativeBINOP-1V2\<^bsub>(INTNUMBERSK5)\<^esub>"
    proof(rule conjMI)
      show "addintBINOP-2K20 be commutativeBINOP-1V1\<^bsub>(INTNUMBERSK5)\<^esub>"
      proof-
        have " for i1 be ElementSUBSET-1M1-of INTNUMBERSK5 holds  for i2 be ElementSUBSET-1M1-of INTNUMBERSK5 holds (addintBINOP-2K20).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(i1,i2) =HIDDENR1 (addintBINOP-2K20).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(i2,i1)"
        proof(rule ballI,rule ballI)
          fix i1 assume [ty]: "i1 be ElementSUBSET-1M1-of INTNUMBERSK5"
          fix i2 assume [ty]: "i2 be ElementSUBSET-1M1-of INTNUMBERSK5"
          have "(addintBINOP-2K20).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(i1,i2) =HIDDENR1 i1 +XCMPLX-0K2 i2"
            using binop_2_def_20 sorry
          also have "... = (addintBINOP-2K20).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(i2,i1)"
            using binop_2_def_20 sorry
          finally show "(addintBINOP-2K20).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(i1,i2) =HIDDENR1 (addintBINOP-2K20).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(i2,i1)"
             sorry
        qed "sorry"
        thus "addintBINOP-2K20 be commutativeBINOP-1V1\<^bsub>(INTNUMBERSK5)\<^esub>"
          using binop_1_def_2 sorry
      qed
      have " for i1 be ElementSUBSET-1M1-of INTNUMBERSK5 holds  for i2 be ElementSUBSET-1M1-of INTNUMBERSK5 holds  for i3 be ElementSUBSET-1M1-of INTNUMBERSK5 holds (addintBINOP-2K20).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(i1,(addintBINOP-2K20).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(i2,i3)) =HIDDENR1 (addintBINOP-2K20).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>((addintBINOP-2K20).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(i1,i2),i3)"
      proof(rule ballI,rule ballI,rule ballI)
        fix i1 assume [ty]: "i1 be ElementSUBSET-1M1-of INTNUMBERSK5"
        fix i2 assume [ty]: "i2 be ElementSUBSET-1M1-of INTNUMBERSK5"
        fix i3 assume [ty]: "i3 be ElementSUBSET-1M1-of INTNUMBERSK5"
        have "(addintBINOP-2K20).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(i1,(addintBINOP-2K20).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(i2,i3)) =HIDDENR1 i1 +XCMPLX-0K2 (addintBINOP-2K20).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(i2,i3)"
          using binop_2_def_20 sorry
        also have "... = i1 +XCMPLX-0K2 (i2 +XCMPLX-0K2 i3)"
          using binop_2_def_20 sorry
        also have "... = (i1 +XCMPLX-0K2 i2)+XCMPLX-0K2 i3"
           sorry
        also have "... = (addintBINOP-2K20).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(i1,i2) +XCMPLX-0K2 i3"
          using binop_2_def_20 sorry
        also have "... = (addintBINOP-2K20).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>((addintBINOP-2K20).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(i1,i2),i3)"
          using binop_2_def_20 sorry
        finally show "(addintBINOP-2K20).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(i1,(addintBINOP-2K20).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(i2,i3)) =HIDDENR1 (addintBINOP-2K20).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>((addintBINOP-2K20).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(i1,i2),i3)"
           sorry
      qed "sorry"
      thus "addintBINOP-2K20 be associativeBINOP-1V2\<^bsub>(INTNUMBERSK5)\<^esub>"
        using binop_1_def_3 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem binop_2_cl_9:
"cluster multintBINOP-2K22 as-term-is commutativeBINOP-1V1\<^bsub>(INTNUMBERSK5)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(INTNUMBERSK5)\<^esub>"
proof
(*coherence*)
  show "multintBINOP-2K22 be commutativeBINOP-1V1\<^bsub>(INTNUMBERSK5)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(INTNUMBERSK5)\<^esub>"
  proof-
    have "multintBINOP-2K22 be commutativeBINOP-1V1\<^bsub>(INTNUMBERSK5)\<^esub> & multintBINOP-2K22 be associativeBINOP-1V2\<^bsub>(INTNUMBERSK5)\<^esub>"
    proof(rule conjMI)
      show "multintBINOP-2K22 be commutativeBINOP-1V1\<^bsub>(INTNUMBERSK5)\<^esub>"
      proof-
        have " for i1 be ElementSUBSET-1M1-of INTNUMBERSK5 holds  for i2 be ElementSUBSET-1M1-of INTNUMBERSK5 holds (multintBINOP-2K22).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(i1,i2) =HIDDENR1 (multintBINOP-2K22).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(i2,i1)"
        proof(rule ballI,rule ballI)
          fix i1 assume [ty]: "i1 be ElementSUBSET-1M1-of INTNUMBERSK5"
          fix i2 assume [ty]: "i2 be ElementSUBSET-1M1-of INTNUMBERSK5"
          have "(multintBINOP-2K22).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(i1,i2) =HIDDENR1 i1 *XCMPLX-0K3 i2"
            using binop_2_def_22 sorry
          also have "... = (multintBINOP-2K22).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(i2,i1)"
            using binop_2_def_22 sorry
          finally show "(multintBINOP-2K22).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(i1,i2) =HIDDENR1 (multintBINOP-2K22).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(i2,i1)"
             sorry
        qed "sorry"
        thus "multintBINOP-2K22 be commutativeBINOP-1V1\<^bsub>(INTNUMBERSK5)\<^esub>"
          using binop_1_def_2 sorry
      qed
      have " for i1 be ElementSUBSET-1M1-of INTNUMBERSK5 holds  for i2 be ElementSUBSET-1M1-of INTNUMBERSK5 holds  for i3 be ElementSUBSET-1M1-of INTNUMBERSK5 holds (multintBINOP-2K22).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(i1,(multintBINOP-2K22).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(i2,i3)) =HIDDENR1 (multintBINOP-2K22).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>((multintBINOP-2K22).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(i1,i2),i3)"
      proof(rule ballI,rule ballI,rule ballI)
        fix i1 assume [ty]: "i1 be ElementSUBSET-1M1-of INTNUMBERSK5"
        fix i2 assume [ty]: "i2 be ElementSUBSET-1M1-of INTNUMBERSK5"
        fix i3 assume [ty]: "i3 be ElementSUBSET-1M1-of INTNUMBERSK5"
        have "(multintBINOP-2K22).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(i1,(multintBINOP-2K22).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(i2,i3)) =HIDDENR1 i1 *XCMPLX-0K3 (multintBINOP-2K22).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(i2,i3)"
          using binop_2_def_22 sorry
        also have "... = i1 *XCMPLX-0K3 (i2 *XCMPLX-0K3 i3)"
          using binop_2_def_22 sorry
        also have "... = (i1 *XCMPLX-0K3 i2)*XCMPLX-0K3 i3"
           sorry
        also have "... = (multintBINOP-2K22).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(i1,i2) *XCMPLX-0K3 i3"
          using binop_2_def_22 sorry
        also have "... = (multintBINOP-2K22).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>((multintBINOP-2K22).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(i1,i2),i3)"
          using binop_2_def_22 sorry
        finally show "(multintBINOP-2K22).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(i1,(multintBINOP-2K22).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(i2,i3)) =HIDDENR1 (multintBINOP-2K22).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>((multintBINOP-2K22).BINOP-1K4\<^bsub>(INTNUMBERSK5)\<^esub>(i1,i2),i3)"
           sorry
      qed "sorry"
      thus "multintBINOP-2K22 be associativeBINOP-1V2\<^bsub>(INTNUMBERSK5)\<^esub>"
        using binop_1_def_3 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem binop_2_cl_10:
"cluster addnatBINOP-2K23 as-term-is commutativeBINOP-1V1\<^bsub>(NATNUMBERSK1)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(NATNUMBERSK1)\<^esub>"
proof
(*coherence*)
  show "addnatBINOP-2K23 be commutativeBINOP-1V1\<^bsub>(NATNUMBERSK1)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(NATNUMBERSK1)\<^esub>"
  proof-
    have "addnatBINOP-2K23 be commutativeBINOP-1V1\<^bsub>(NATNUMBERSK1)\<^esub> & addnatBINOP-2K23 be associativeBINOP-1V2\<^bsub>(NATNUMBERSK1)\<^esub>"
    proof(rule conjMI)
      show "addnatBINOP-2K23 be commutativeBINOP-1V1\<^bsub>(NATNUMBERSK1)\<^esub>"
      proof-
        have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds (addnatBINOP-2K23).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n1,n2) =HIDDENR1 (addnatBINOP-2K23).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n2,n1)"
        proof(rule ballI,rule ballI)
          fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
          fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
          have "(addnatBINOP-2K23).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n1,n2) =HIDDENR1 n1 +NAT-1K1 n2"
            using binop_2_def_23 sorry
          also have "... = (addnatBINOP-2K23).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n2,n1)"
            using binop_2_def_23 sorry
          finally show "(addnatBINOP-2K23).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n1,n2) =HIDDENR1 (addnatBINOP-2K23).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n2,n1)"
             sorry
        qed "sorry"
        thus "addnatBINOP-2K23 be commutativeBINOP-1V1\<^bsub>(NATNUMBERSK1)\<^esub>"
          using binop_1_def_2 sorry
      qed
      have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds (addnatBINOP-2K23).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n1,(addnatBINOP-2K23).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n2,n3)) =HIDDENR1 (addnatBINOP-2K23).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>((addnatBINOP-2K23).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n1,n2),n3)"
      proof(rule ballI,rule ballI,rule ballI)
        fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
        fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
        fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
        have "(addnatBINOP-2K23).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n1,(addnatBINOP-2K23).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n2,n3)) =HIDDENR1 n1 +NAT-1K1 (addnatBINOP-2K23).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n2,n3)"
          using binop_2_def_23 sorry
        also have "... = n1 +NAT-1K1 (n2 +NAT-1K1 n3)"
          using binop_2_def_23 sorry
        also have "... = (n1 +NAT-1K1 n2)+NAT-1K1 n3"
           sorry
        also have "... = (addnatBINOP-2K23).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n1,n2) +NAT-1K1 n3"
          using binop_2_def_23 sorry
        also have "... = (addnatBINOP-2K23).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>((addnatBINOP-2K23).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n1,n2),n3)"
          using binop_2_def_23 sorry
        finally show "(addnatBINOP-2K23).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n1,(addnatBINOP-2K23).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n2,n3)) =HIDDENR1 (addnatBINOP-2K23).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>((addnatBINOP-2K23).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n1,n2),n3)"
           sorry
      qed "sorry"
      thus "addnatBINOP-2K23 be associativeBINOP-1V2\<^bsub>(NATNUMBERSK1)\<^esub>"
        using binop_1_def_3 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem binop_2_cl_11:
"cluster multnatBINOP-2K24 as-term-is commutativeBINOP-1V1\<^bsub>(NATNUMBERSK1)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(NATNUMBERSK1)\<^esub>"
proof
(*coherence*)
  show "multnatBINOP-2K24 be commutativeBINOP-1V1\<^bsub>(NATNUMBERSK1)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(NATNUMBERSK1)\<^esub>"
  proof-
    have "multnatBINOP-2K24 be commutativeBINOP-1V1\<^bsub>(NATNUMBERSK1)\<^esub> & multnatBINOP-2K24 be associativeBINOP-1V2\<^bsub>(NATNUMBERSK1)\<^esub>"
    proof(rule conjMI)
      show "multnatBINOP-2K24 be commutativeBINOP-1V1\<^bsub>(NATNUMBERSK1)\<^esub>"
      proof-
        have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds (multnatBINOP-2K24).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n1,n2) =HIDDENR1 (multnatBINOP-2K24).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n2,n1)"
        proof(rule ballI,rule ballI)
          fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
          fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
          have "(multnatBINOP-2K24).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n1,n2) =HIDDENR1 n1 *NAT-1K2 n2"
            using binop_2_def_24 sorry
          also have "... = (multnatBINOP-2K24).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n2,n1)"
            using binop_2_def_24 sorry
          finally show "(multnatBINOP-2K24).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n1,n2) =HIDDENR1 (multnatBINOP-2K24).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n2,n1)"
             sorry
        qed "sorry"
        thus "multnatBINOP-2K24 be commutativeBINOP-1V1\<^bsub>(NATNUMBERSK1)\<^esub>"
          using binop_1_def_2 sorry
      qed
      have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds (multnatBINOP-2K24).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n1,(multnatBINOP-2K24).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n2,n3)) =HIDDENR1 (multnatBINOP-2K24).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>((multnatBINOP-2K24).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n1,n2),n3)"
      proof(rule ballI,rule ballI,rule ballI)
        fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
        fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
        fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
        have "(multnatBINOP-2K24).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n1,(multnatBINOP-2K24).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n2,n3)) =HIDDENR1 n1 *NAT-1K2 (multnatBINOP-2K24).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n2,n3)"
          using binop_2_def_24 sorry
        also have "... = n1 *NAT-1K2 (n2 *NAT-1K2 n3)"
          using binop_2_def_24 sorry
        also have "... = (n1 *NAT-1K2 n2)*NAT-1K2 n3"
           sorry
        also have "... = (multnatBINOP-2K24).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n1,n2) *NAT-1K2 n3"
          using binop_2_def_24 sorry
        also have "... = (multnatBINOP-2K24).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>((multnatBINOP-2K24).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n1,n2),n3)"
          using binop_2_def_24 sorry
        finally show "(multnatBINOP-2K24).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n1,(multnatBINOP-2K24).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n2,n3)) =HIDDENR1 (multnatBINOP-2K24).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>((multnatBINOP-2K24).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n1,n2),n3)"
           sorry
      qed "sorry"
      thus "multnatBINOP-2K24 be associativeBINOP-1V2\<^bsub>(NATNUMBERSK1)\<^esub>"
        using binop_1_def_3 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mlemma binop_2_lm_1:
"0NUMBERSK6 inHIDDENR3 NATNUMBERSK1"
   sorry

mlemma binop_2_lm_2:
"0NUMBERSK6 is-a-unity-wrtBINOP-1R3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> addcomplexBINOP-2K3"
proof-
  have "( for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds addcomplexBINOP-2K3 .BINOP-1K1(0NUMBERSK6,c) =XBOOLE-0R4 c) & 0NUMBERSK6 is-a-right-unity-wrtBINOP-1R2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> addcomplexBINOP-2K3"
  proof(rule conjMI)
    show " for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds addcomplexBINOP-2K3 .BINOP-1K1(0NUMBERSK6,c) =XBOOLE-0R4 c"
    proof-
      have " for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds addcomplexBINOP-2K3 .BINOP-1K1(0NUMBERSK6,c) =HIDDENR1 c"
      proof(rule ballI)
        fix c assume [ty]: "c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
        have "addcomplexBINOP-2K3 .BINOP-1K1(0NUMBERSK6,c) =HIDDENR1 0NUMBERSK6 +XCMPLX-0K2 c"
          using binop_2_def_3 sorry
        also have "... = c"
           sorry
        finally show "addcomplexBINOP-2K3 .BINOP-1K1(0NUMBERSK6,c) =HIDDENR1 c"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds addcomplexBINOP-2K3 .BINOP-1K1(c,0NUMBERSK6) =HIDDENR1 c"
    proof(rule ballI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
      have "addcomplexBINOP-2K3 .BINOP-1K1(c,0NUMBERSK6) =HIDDENR1 c +XCMPLX-0K2 0NUMBERSK6"
        using binop_2_def_3 sorry
      also have "... = c"
         sorry
      finally show "addcomplexBINOP-2K3 .BINOP-1K1(c,0NUMBERSK6) =HIDDENR1 c"
         sorry
    qed "sorry"
    thus "0NUMBERSK6 is-a-right-unity-wrtBINOP-1R2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> addcomplexBINOP-2K3"
      using binop_1_def_17 sorry
  qed
  thus "0NUMBERSK6 is-a-unity-wrtBINOP-1R3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> addcomplexBINOP-2K3"
    using binop_1_def_7 binop_1_def_16 sorry
qed

mlemma binop_2_lm_3:
"InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2) is-a-unity-wrtBINOP-1R3\<^bsub>(REALNUMBERSK2)\<^esub> addrealBINOP-2K9"
proof-
  have "( for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds (addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2),r) =XBOOLE-0R4 r) & InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2) is-a-right-unity-wrtBINOP-1R2\<^bsub>(REALNUMBERSK2)\<^esub> addrealBINOP-2K9"
  proof(rule conjMI)
    show " for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds (addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2),r) =XBOOLE-0R4 r"
    proof-
      have " for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds (addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2),r) =HIDDENR1 r"
      proof(rule ballI)
        fix r assume [ty]: "r be ElementSUBSET-1M1-of REALNUMBERSK2"
        have "(addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2),r) =HIDDENR1 0NUMBERSK6 +XCMPLX-0K2 r"
          using binop_2_def_9 sorry
        also have "... = r"
           sorry
        finally show "(addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2),r) =HIDDENR1 r"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds (addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r,InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)) =HIDDENR1 r"
    proof(rule ballI)
      fix r assume [ty]: "r be ElementSUBSET-1M1-of REALNUMBERSK2"
      have "(addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r,InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)) =HIDDENR1 r +XCMPLX-0K2 0NUMBERSK6"
        using binop_2_def_9 sorry
      also have "... = r"
         sorry
      finally show "(addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r,InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)) =HIDDENR1 r"
         sorry
    qed "sorry"
    thus "InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2) is-a-right-unity-wrtBINOP-1R2\<^bsub>(REALNUMBERSK2)\<^esub> addrealBINOP-2K9"
      using binop_1_def_17 sorry
  qed
  thus "InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2) is-a-unity-wrtBINOP-1R3\<^bsub>(REALNUMBERSK2)\<^esub> addrealBINOP-2K9"
    using binop_1_def_7 binop_1_def_16 sorry
qed

mlemma binop_2_lm_4:
"0NUMBERSK6 is-a-unity-wrtBINOP-1R3\<^bsub>(RATRAT-1K1)\<^esub> addratBINOP-2K15"
proof-
  have "( for w be ElementSUBSET-1M1-of RATRAT-1K1 holds (addratBINOP-2K15).BINOP-1K1(0NUMBERSK6,w) =XBOOLE-0R4 w) & 0NUMBERSK6 is-a-right-unity-wrtBINOP-1R2\<^bsub>(RATRAT-1K1)\<^esub> addratBINOP-2K15"
  proof(rule conjMI)
    show " for w be ElementSUBSET-1M1-of RATRAT-1K1 holds (addratBINOP-2K15).BINOP-1K1(0NUMBERSK6,w) =XBOOLE-0R4 w"
    proof-
      have " for w be ElementSUBSET-1M1-of RATRAT-1K1 holds (addratBINOP-2K15).BINOP-1K1(0NUMBERSK6,w) =HIDDENR1 w"
      proof(rule ballI)
        fix w assume [ty]: "w be ElementSUBSET-1M1-of RATRAT-1K1"
        have "(addratBINOP-2K15).BINOP-1K1(0NUMBERSK6,w) =HIDDENR1 0NUMBERSK6 +XCMPLX-0K2 w"
          using binop_2_def_15 sorry
        also have "... = w"
           sorry
        finally show "(addratBINOP-2K15).BINOP-1K1(0NUMBERSK6,w) =HIDDENR1 w"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for w be ElementSUBSET-1M1-of RATRAT-1K1 holds (addratBINOP-2K15).BINOP-1K1(w,0NUMBERSK6) =HIDDENR1 w"
    proof(rule ballI)
      fix w assume [ty]: "w be ElementSUBSET-1M1-of RATRAT-1K1"
      have "(addratBINOP-2K15).BINOP-1K1(w,0NUMBERSK6) =HIDDENR1 w +XCMPLX-0K2 0NUMBERSK6"
        using binop_2_def_15 sorry
      also have "... = w"
         sorry
      finally show "(addratBINOP-2K15).BINOP-1K1(w,0NUMBERSK6) =HIDDENR1 w"
         sorry
    qed "sorry"
    thus "0NUMBERSK6 is-a-right-unity-wrtBINOP-1R2\<^bsub>(RATRAT-1K1)\<^esub> addratBINOP-2K15"
      using binop_1_def_17 sorry
  qed
  thus "0NUMBERSK6 is-a-unity-wrtBINOP-1R3\<^bsub>(RATRAT-1K1)\<^esub> addratBINOP-2K15"
    using binop_1_def_7 binop_1_def_16 sorry
qed

mlemma binop_2_lm_5:
"0NUMBERSK6 is-a-unity-wrtBINOP-1R3\<^bsub>(INTNUMBERSK5)\<^esub> addintBINOP-2K20"
proof-
  have "( for i be ElementSUBSET-1M1-of INTNUMBERSK5 holds (addintBINOP-2K20).BINOP-1K1(0NUMBERSK6,i) =XBOOLE-0R4 i) & 0NUMBERSK6 is-a-right-unity-wrtBINOP-1R2\<^bsub>(INTNUMBERSK5)\<^esub> addintBINOP-2K20"
  proof(rule conjMI)
    show " for i be ElementSUBSET-1M1-of INTNUMBERSK5 holds (addintBINOP-2K20).BINOP-1K1(0NUMBERSK6,i) =XBOOLE-0R4 i"
    proof-
      have " for i be ElementSUBSET-1M1-of INTNUMBERSK5 holds (addintBINOP-2K20).BINOP-1K1(0NUMBERSK6,i) =HIDDENR1 i"
      proof(rule ballI)
        fix i assume [ty]: "i be ElementSUBSET-1M1-of INTNUMBERSK5"
        have "(addintBINOP-2K20).BINOP-1K1(0NUMBERSK6,i) =HIDDENR1 0NUMBERSK6 +XCMPLX-0K2 i"
          using binop_2_def_20 sorry
        also have "... = i"
           sorry
        finally show "(addintBINOP-2K20).BINOP-1K1(0NUMBERSK6,i) =HIDDENR1 i"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for i be ElementSUBSET-1M1-of INTNUMBERSK5 holds (addintBINOP-2K20).BINOP-1K1(i,0NUMBERSK6) =HIDDENR1 i"
    proof(rule ballI)
      fix i assume [ty]: "i be ElementSUBSET-1M1-of INTNUMBERSK5"
      have "(addintBINOP-2K20).BINOP-1K1(i,0NUMBERSK6) =HIDDENR1 i +XCMPLX-0K2 0NUMBERSK6"
        using binop_2_def_20 sorry
      also have "... = i"
         sorry
      finally show "(addintBINOP-2K20).BINOP-1K1(i,0NUMBERSK6) =HIDDENR1 i"
         sorry
    qed "sorry"
    thus "0NUMBERSK6 is-a-right-unity-wrtBINOP-1R2\<^bsub>(INTNUMBERSK5)\<^esub> addintBINOP-2K20"
      using binop_1_def_17 sorry
  qed
  thus "0NUMBERSK6 is-a-unity-wrtBINOP-1R3\<^bsub>(INTNUMBERSK5)\<^esub> addintBINOP-2K20"
    using binop_1_def_7 binop_1_def_16 sorry
qed

mlemma binop_2_lm_6:
"0NUMBERSK6 is-a-unity-wrtBINOP-1R3\<^bsub>(NATNUMBERSK1)\<^esub> addnatBINOP-2K23"
proof-
  have "( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (addnatBINOP-2K23).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(0NUMBERSK6,n) =XBOOLE-0R4 n) & 0NUMBERSK6 is-a-right-unity-wrtBINOP-1R2\<^bsub>(NATNUMBERSK1)\<^esub> addnatBINOP-2K23"
  proof(rule conjMI)
    show " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (addnatBINOP-2K23).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(0NUMBERSK6,n) =XBOOLE-0R4 n"
    proof-
      have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (addnatBINOP-2K23).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(0NUMBERSK6,n) =HIDDENR1 n"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have "(addnatBINOP-2K23).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(0NUMBERSK6,n) =HIDDENR1 0NUMBERSK6 +NAT-1K1 n"
          using binop_2_def_23 sorry
        also have "... = n"
           sorry
        finally show "(addnatBINOP-2K23).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(0NUMBERSK6,n) =HIDDENR1 n"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (addnatBINOP-2K23).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n,0NUMBERSK6) =HIDDENR1 n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(addnatBINOP-2K23).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n,0NUMBERSK6) =HIDDENR1 n +NAT-1K1 0NUMBERSK6"
        using binop_2_def_23 sorry
      also have "... = n"
         sorry
      finally show "(addnatBINOP-2K23).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n,0NUMBERSK6) =HIDDENR1 n"
         sorry
    qed "sorry"
    thus "0NUMBERSK6 is-a-right-unity-wrtBINOP-1R2\<^bsub>(NATNUMBERSK1)\<^esub> addnatBINOP-2K23"
      using binop_1_def_17 sorry
  qed
  thus "0NUMBERSK6 is-a-unity-wrtBINOP-1R3\<^bsub>(NATNUMBERSK1)\<^esub> addnatBINOP-2K23"
    using binop_1_def_7 binop_1_def_16 sorry
qed

mlemma binop_2_lm_7:
"\<one>\<^sub>M inHIDDENR3 NATNUMBERSK1"
   sorry

mlemma binop_2_lm_8:
"\<one>\<^sub>M is-a-unity-wrtBINOP-1R3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> multcomplexBINOP-2K5"
proof-
  have "( for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds multcomplexBINOP-2K5 .BINOP-1K1(\<one>\<^sub>M,c) =XBOOLE-0R4 c) & \<one>\<^sub>M is-a-right-unity-wrtBINOP-1R2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> multcomplexBINOP-2K5"
  proof(rule conjMI)
    show " for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds multcomplexBINOP-2K5 .BINOP-1K1(\<one>\<^sub>M,c) =XBOOLE-0R4 c"
    proof-
      have " for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds multcomplexBINOP-2K5 .BINOP-1K1(\<one>\<^sub>M,c) =HIDDENR1 c"
      proof(rule ballI)
        fix c assume [ty]: "c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
        have "multcomplexBINOP-2K5 .BINOP-1K1(\<one>\<^sub>M,c) =HIDDENR1 \<one>\<^sub>M *XCMPLX-0K3 c"
          using binop_2_def_5 sorry
        also have "... = c"
           sorry
        finally show "multcomplexBINOP-2K5 .BINOP-1K1(\<one>\<^sub>M,c) =HIDDENR1 c"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds multcomplexBINOP-2K5 .BINOP-1K1(c,\<one>\<^sub>M) =HIDDENR1 c"
    proof(rule ballI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
      have "multcomplexBINOP-2K5 .BINOP-1K1(c,\<one>\<^sub>M) =HIDDENR1 c *XCMPLX-0K3 \<one>\<^sub>M"
        using binop_2_def_5 sorry
      also have "... = c"
         sorry
      finally show "multcomplexBINOP-2K5 .BINOP-1K1(c,\<one>\<^sub>M) =HIDDENR1 c"
         sorry
    qed "sorry"
    thus "\<one>\<^sub>M is-a-right-unity-wrtBINOP-1R2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> multcomplexBINOP-2K5"
      using binop_1_def_17 sorry
  qed
  thus "\<one>\<^sub>M is-a-unity-wrtBINOP-1R3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> multcomplexBINOP-2K5"
    using binop_1_def_7 binop_1_def_16 sorry
qed

mlemma binop_2_lm_9:
"\<one>\<^sub>M is-a-unity-wrtBINOP-1R3\<^bsub>(REALNUMBERSK2)\<^esub> multrealBINOP-2K11"
proof-
  have "\<one>\<^sub>M inHIDDENR3 NATNUMBERSK1"
     sorry
  then obtain j where 
    [ty]:"j be ElementSUBSET-1M1-of REALNUMBERSK2" and jDef:"j = \<one>\<^sub>M"
    using numbers_th_19 sorry
  have "( for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds (multrealBINOP-2K11).BINOP-1K1(\<one>\<^sub>M,r) =XBOOLE-0R4 r) & \<one>\<^sub>M is-a-right-unity-wrtBINOP-1R2\<^bsub>(REALNUMBERSK2)\<^esub> multrealBINOP-2K11"
  proof(rule conjMI)
    show " for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds (multrealBINOP-2K11).BINOP-1K1(\<one>\<^sub>M,r) =XBOOLE-0R4 r"
    proof-
      have " for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds (multrealBINOP-2K11).BINOP-1K1(\<one>\<^sub>M,r) =HIDDENR1 r"
      proof(rule ballI)
        fix r assume [ty]: "r be ElementSUBSET-1M1-of REALNUMBERSK2"
        have "(multrealBINOP-2K11).BINOP-1K1(\<one>\<^sub>M,r) =HIDDENR1 \<one>\<^sub>M *XCMPLX-0K3 r"
          using binop_2_def_11 sorry
        also have "... = r"
           sorry
        finally show "(multrealBINOP-2K11).BINOP-1K1(\<one>\<^sub>M,r) =HIDDENR1 r"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds (multrealBINOP-2K11).BINOP-1K1(r,\<one>\<^sub>M) =HIDDENR1 r"
    proof(rule ballI)
      fix r assume [ty]: "r be ElementSUBSET-1M1-of REALNUMBERSK2"
      have "(multrealBINOP-2K11).BINOP-1K1(r,\<one>\<^sub>M) =HIDDENR1 r *XCMPLX-0K3 \<one>\<^sub>M"
        using binop_2_def_11 sorry
      also have "... = r"
         sorry
      finally show "(multrealBINOP-2K11).BINOP-1K1(r,\<one>\<^sub>M) =HIDDENR1 r"
         sorry
    qed "sorry"
    thus "\<one>\<^sub>M is-a-right-unity-wrtBINOP-1R2\<^bsub>(REALNUMBERSK2)\<^esub> multrealBINOP-2K11"
      using binop_1_def_17 sorry
  qed
  thus "\<one>\<^sub>M is-a-unity-wrtBINOP-1R3\<^bsub>(REALNUMBERSK2)\<^esub> multrealBINOP-2K11"
    using binop_1_def_7 binop_1_def_16 sorry
qed

mlemma binop_2_lm_10:
"\<one>\<^sub>M is-a-unity-wrtBINOP-1R3\<^bsub>(RATRAT-1K1)\<^esub> multratBINOP-2K17"
proof-
  have "( for w be ElementSUBSET-1M1-of RATRAT-1K1 holds (multratBINOP-2K17).BINOP-1K1(\<one>\<^sub>M,w) =XBOOLE-0R4 w) & \<one>\<^sub>M is-a-right-unity-wrtBINOP-1R2\<^bsub>(RATRAT-1K1)\<^esub> multratBINOP-2K17"
  proof(rule conjMI)
    show " for w be ElementSUBSET-1M1-of RATRAT-1K1 holds (multratBINOP-2K17).BINOP-1K1(\<one>\<^sub>M,w) =XBOOLE-0R4 w"
    proof-
      have " for w be ElementSUBSET-1M1-of RATRAT-1K1 holds (multratBINOP-2K17).BINOP-1K1(\<one>\<^sub>M,w) =HIDDENR1 w"
      proof(rule ballI)
        fix w assume [ty]: "w be ElementSUBSET-1M1-of RATRAT-1K1"
        have "(multratBINOP-2K17).BINOP-1K1(\<one>\<^sub>M,w) =HIDDENR1 \<one>\<^sub>M *XCMPLX-0K3 w"
          using binop_2_def_17 sorry
        also have "... = w"
           sorry
        finally show "(multratBINOP-2K17).BINOP-1K1(\<one>\<^sub>M,w) =HIDDENR1 w"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for w be ElementSUBSET-1M1-of RATRAT-1K1 holds (multratBINOP-2K17).BINOP-1K1(w,\<one>\<^sub>M) =HIDDENR1 w"
    proof(rule ballI)
      fix w assume [ty]: "w be ElementSUBSET-1M1-of RATRAT-1K1"
      have "(multratBINOP-2K17).BINOP-1K1(w,\<one>\<^sub>M) =HIDDENR1 w *XCMPLX-0K3 \<one>\<^sub>M"
        using binop_2_def_17 sorry
      also have "... = w"
         sorry
      finally show "(multratBINOP-2K17).BINOP-1K1(w,\<one>\<^sub>M) =HIDDENR1 w"
         sorry
    qed "sorry"
    thus "\<one>\<^sub>M is-a-right-unity-wrtBINOP-1R2\<^bsub>(RATRAT-1K1)\<^esub> multratBINOP-2K17"
      using binop_1_def_17 sorry
  qed
  thus "\<one>\<^sub>M is-a-unity-wrtBINOP-1R3\<^bsub>(RATRAT-1K1)\<^esub> multratBINOP-2K17"
    using binop_1_def_7 binop_1_def_16 sorry
qed

mlemma binop_2_lm_11:
"\<one>\<^sub>M is-a-unity-wrtBINOP-1R3\<^bsub>(INTNUMBERSK5)\<^esub> multintBINOP-2K22"
proof-
  have "( for i be ElementSUBSET-1M1-of INTNUMBERSK5 holds (multintBINOP-2K22).BINOP-1K1(\<one>\<^sub>M,i) =XBOOLE-0R4 i) & \<one>\<^sub>M is-a-right-unity-wrtBINOP-1R2\<^bsub>(INTNUMBERSK5)\<^esub> multintBINOP-2K22"
  proof(rule conjMI)
    show " for i be ElementSUBSET-1M1-of INTNUMBERSK5 holds (multintBINOP-2K22).BINOP-1K1(\<one>\<^sub>M,i) =XBOOLE-0R4 i"
    proof-
      have " for i be ElementSUBSET-1M1-of INTNUMBERSK5 holds (multintBINOP-2K22).BINOP-1K1(\<one>\<^sub>M,i) =HIDDENR1 i"
      proof(rule ballI)
        fix i assume [ty]: "i be ElementSUBSET-1M1-of INTNUMBERSK5"
        have "(multintBINOP-2K22).BINOP-1K1(\<one>\<^sub>M,i) =HIDDENR1 \<one>\<^sub>M *XCMPLX-0K3 i"
          using binop_2_def_22 sorry
        also have "... = i"
           sorry
        finally show "(multintBINOP-2K22).BINOP-1K1(\<one>\<^sub>M,i) =HIDDENR1 i"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for i be ElementSUBSET-1M1-of INTNUMBERSK5 holds (multintBINOP-2K22).BINOP-1K1(i,\<one>\<^sub>M) =HIDDENR1 i"
    proof(rule ballI)
      fix i assume [ty]: "i be ElementSUBSET-1M1-of INTNUMBERSK5"
      have "(multintBINOP-2K22).BINOP-1K1(i,\<one>\<^sub>M) =HIDDENR1 i *XCMPLX-0K3 \<one>\<^sub>M"
        using binop_2_def_22 sorry
      also have "... = i"
         sorry
      finally show "(multintBINOP-2K22).BINOP-1K1(i,\<one>\<^sub>M) =HIDDENR1 i"
         sorry
    qed "sorry"
    thus "\<one>\<^sub>M is-a-right-unity-wrtBINOP-1R2\<^bsub>(INTNUMBERSK5)\<^esub> multintBINOP-2K22"
      using binop_1_def_17 sorry
  qed
  thus "\<one>\<^sub>M is-a-unity-wrtBINOP-1R3\<^bsub>(INTNUMBERSK5)\<^esub> multintBINOP-2K22"
    using binop_1_def_7 binop_1_def_16 sorry
qed

mlemma binop_2_lm_12:
"\<one>\<^sub>M is-a-unity-wrtBINOP-1R3\<^bsub>(NATNUMBERSK1)\<^esub> multnatBINOP-2K24"
proof-
  have "( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (multnatBINOP-2K24).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(\<one>\<^sub>M,n) =XBOOLE-0R4 n) & \<one>\<^sub>M is-a-right-unity-wrtBINOP-1R2\<^bsub>(NATNUMBERSK1)\<^esub> multnatBINOP-2K24"
  proof(rule conjMI)
    show " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (multnatBINOP-2K24).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(\<one>\<^sub>M,n) =XBOOLE-0R4 n"
    proof-
      have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (multnatBINOP-2K24).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(\<one>\<^sub>M,n) =HIDDENR1 n"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have "(multnatBINOP-2K24).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(\<one>\<^sub>M,n) =HIDDENR1 \<one>\<^sub>M *NAT-1K2 n"
          using binop_2_def_24 sorry
        also have "... = n"
           sorry
        finally show "(multnatBINOP-2K24).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(\<one>\<^sub>M,n) =HIDDENR1 n"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (multnatBINOP-2K24).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n,\<one>\<^sub>M) =HIDDENR1 n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(multnatBINOP-2K24).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n,\<one>\<^sub>M) =HIDDENR1 n *NAT-1K2 \<one>\<^sub>M"
        using binop_2_def_24 sorry
      also have "... = n"
         sorry
      finally show "(multnatBINOP-2K24).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>(n,\<one>\<^sub>M) =HIDDENR1 n"
         sorry
    qed "sorry"
    thus "\<one>\<^sub>M is-a-right-unity-wrtBINOP-1R2\<^bsub>(NATNUMBERSK1)\<^esub> multnatBINOP-2K24"
      using binop_1_def_17 sorry
  qed
  thus "\<one>\<^sub>M is-a-unity-wrtBINOP-1R3\<^bsub>(NATNUMBERSK1)\<^esub> multnatBINOP-2K24"
    using binop_1_def_7 binop_1_def_16 sorry
qed

mtheorem binop_2_cl_12:
"cluster addcomplexBINOP-2K3 as-term-is having-a-unitySETWISEOV1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>"
proof
(*coherence*)
  show "addcomplexBINOP-2K3 be having-a-unitySETWISEOV1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>"
    using binop_2_lm_1 numbers_th_20 binop_2_lm_2 setwiseo_def_2 sorry
qed "sorry"

mtheorem binop_2_cl_13:
"cluster addrealBINOP-2K9 as-term-is having-a-unitySETWISEOV1\<^bsub>(REALNUMBERSK2)\<^esub>"
proof
(*coherence*)
  show "addrealBINOP-2K9 be having-a-unitySETWISEOV1\<^bsub>(REALNUMBERSK2)\<^esub>"
    using binop_2_lm_3 setwiseo_def_2 sorry
qed "sorry"

mtheorem binop_2_cl_14:
"cluster addratBINOP-2K15 as-term-is having-a-unitySETWISEOV1\<^bsub>(RATRAT-1K1)\<^esub>"
proof
(*coherence*)
  show "addratBINOP-2K15 be having-a-unitySETWISEOV1\<^bsub>(RATRAT-1K1)\<^esub>"
    using binop_2_lm_1 numbers_th_18 binop_2_lm_4 setwiseo_def_2 sorry
qed "sorry"

mtheorem binop_2_cl_15:
"cluster addintBINOP-2K20 as-term-is having-a-unitySETWISEOV1\<^bsub>(INTNUMBERSK5)\<^esub>"
proof
(*coherence*)
  show "addintBINOP-2K20 be having-a-unitySETWISEOV1\<^bsub>(INTNUMBERSK5)\<^esub>"
    using binop_2_lm_1 numbers_th_17 binop_2_lm_5 setwiseo_def_2 sorry
qed "sorry"

mtheorem binop_2_cl_16:
"cluster addnatBINOP-2K23 as-term-is having-a-unitySETWISEOV1\<^bsub>(NATNUMBERSK1)\<^esub>"
proof
(*coherence*)
  show "addnatBINOP-2K23 be having-a-unitySETWISEOV1\<^bsub>(NATNUMBERSK1)\<^esub>"
    using binop_2_lm_6 setwiseo_def_2 sorry
qed "sorry"

mtheorem binop_2_cl_17:
"cluster multcomplexBINOP-2K5 as-term-is having-a-unitySETWISEOV1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>"
proof
(*coherence*)
  show "multcomplexBINOP-2K5 be having-a-unitySETWISEOV1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>"
    using binop_2_lm_7 numbers_th_20 binop_2_lm_8 setwiseo_def_2 sorry
qed "sorry"

mtheorem binop_2_cl_18:
"cluster multrealBINOP-2K11 as-term-is having-a-unitySETWISEOV1\<^bsub>(REALNUMBERSK2)\<^esub>"
proof
(*coherence*)
  show "multrealBINOP-2K11 be having-a-unitySETWISEOV1\<^bsub>(REALNUMBERSK2)\<^esub>"
    using binop_2_lm_7 numbers_th_19 binop_2_lm_9 setwiseo_def_2 sorry
qed "sorry"

mtheorem binop_2_cl_19:
"cluster multratBINOP-2K17 as-term-is having-a-unitySETWISEOV1\<^bsub>(RATRAT-1K1)\<^esub>"
proof
(*coherence*)
  show "multratBINOP-2K17 be having-a-unitySETWISEOV1\<^bsub>(RATRAT-1K1)\<^esub>"
    using binop_2_lm_7 numbers_th_18 binop_2_lm_10 setwiseo_def_2 sorry
qed "sorry"

mtheorem binop_2_cl_20:
"cluster multintBINOP-2K22 as-term-is having-a-unitySETWISEOV1\<^bsub>(INTNUMBERSK5)\<^esub>"
proof
(*coherence*)
  show "multintBINOP-2K22 be having-a-unitySETWISEOV1\<^bsub>(INTNUMBERSK5)\<^esub>"
    using binop_2_lm_7 numbers_th_17 binop_2_lm_11 setwiseo_def_2 sorry
qed "sorry"

mtheorem binop_2_cl_21:
"cluster multnatBINOP-2K24 as-term-is having-a-unitySETWISEOV1\<^bsub>(NATNUMBERSK1)\<^esub>"
proof
(*coherence*)
  show "multnatBINOP-2K24 be having-a-unitySETWISEOV1\<^bsub>(NATNUMBERSK1)\<^esub>"
    using binop_2_lm_12 setwiseo_def_2 sorry
qed "sorry"

mtheorem binop_2_th_1:
"the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (addcomplexBINOP-2K3) =XBOOLE-0R4 0NUMBERSK6"
  using binop_2_lm_1 numbers_th_20 binop_2_lm_2 binop_1_def_8 sorry

mtheorem binop_2_th_2:
"the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> (addrealBINOP-2K9) =XBOOLE-0R4 0NUMBERSK6"
  using binop_2_lm_3 binop_1_def_8 sorry

mtheorem binop_2_th_3:
"the-unity-wrtBINOP-1K3\<^bsub>(RATRAT-1K1)\<^esub> (addratBINOP-2K15) =XBOOLE-0R4 0NUMBERSK6"
  using binop_2_lm_1 numbers_th_18 binop_2_lm_4 binop_1_def_8 sorry

mtheorem binop_2_th_4:
"the-unity-wrtBINOP-1K3\<^bsub>(INTNUMBERSK5)\<^esub> (addintBINOP-2K20) =XBOOLE-0R4 0NUMBERSK6"
  using binop_2_lm_1 numbers_th_17 binop_2_lm_5 binop_1_def_8 sorry

mtheorem binop_2_th_5:
"the-unity-wrtBINOP-1K3\<^bsub>(NATNUMBERSK1)\<^esub> (addnatBINOP-2K23) =XBOOLE-0R4 0NUMBERSK6"
  using binop_2_lm_6 binop_1_def_8 sorry

mtheorem binop_2_th_6:
"the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (multcomplexBINOP-2K5) =XBOOLE-0R4 \<one>\<^sub>M"
  using binop_2_lm_7 numbers_th_20 binop_2_lm_8 binop_1_def_8 sorry

mtheorem binop_2_th_7:
"the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> (multrealBINOP-2K11) =XBOOLE-0R4 \<one>\<^sub>M"
  using binop_2_lm_7 numbers_th_19 binop_2_lm_9 binop_1_def_8 sorry

mtheorem binop_2_th_8:
"the-unity-wrtBINOP-1K3\<^bsub>(RATRAT-1K1)\<^esub> (multratBINOP-2K17) =XBOOLE-0R4 \<one>\<^sub>M"
  using binop_2_lm_7 numbers_th_18 binop_2_lm_10 binop_1_def_8 sorry

mtheorem binop_2_th_9:
"the-unity-wrtBINOP-1K3\<^bsub>(INTNUMBERSK5)\<^esub> (multintBINOP-2K22) =XBOOLE-0R4 \<one>\<^sub>M"
  using binop_2_lm_7 numbers_th_17 binop_2_lm_11 binop_1_def_8 sorry

mtheorem binop_2_th_10:
"the-unity-wrtBINOP-1K3\<^bsub>(NATNUMBERSK1)\<^esub> (multnatBINOP-2K24) =XBOOLE-0R4 \<one>\<^sub>M"
  using binop_2_lm_12 binop_1_def_8 sorry

mtheorem binop_2_cl_22:
  mlet "f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1", "a be objectHIDDENM1", "b be objectHIDDENM1"
"cluster f .BINOP-1K1(a,b) as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "f .BINOP-1K1(a,b) be realXREAL-0V1"
     sorry
qed "sorry"

end
