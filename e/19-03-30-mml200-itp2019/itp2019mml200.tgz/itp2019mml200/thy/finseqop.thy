theory finseqop
  imports eqrel_1 finseq_2
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x, y for "setHIDDENM2"
reserve C, C9, D, D9, E for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve c for "ElementSUBSET-1M1-of C"
reserve c9 for "ElementSUBSET-1M1-of C9"
reserve d, d1, d2, d3, d4, e for "ElementSUBSET-1M1-of D"
reserve d9 for "ElementSUBSET-1M1-of D9"
mtheorem finseqop_th_1:
" for f be FunctionFUNCT-1M1 holds <:FUNCT-3K14 {}XBOOLE-0K1,f :> =FUNCT-1R1 {}XBOOLE-0K1 & <:FUNCT-3K14 f,{}XBOOLE-0K1 :> =FUNCT-1R1 {}XBOOLE-0K1"
proof(rule ballI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  have "domRELAT-1K1 (<:FUNCT-3K14 {}XBOOLE-0K1,f :>) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ({}XBOOLE-0K1) /\\SUBSET-1K8\<^bsub>(omegaORDINAL1K4)\<^esub> domRELAT-1K1 f & domRELAT-1K1 (<:FUNCT-3K14 f,{}XBOOLE-0K1 :>) =XBOOLE-0R4 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ({}XBOOLE-0K1)"
    using funct_3_def_7 sorry
  thus "<:FUNCT-3K14 {}XBOOLE-0K1,f :> =FUNCT-1R1 {}XBOOLE-0K1 & <:FUNCT-3K14 f,{}XBOOLE-0K1 :> =FUNCT-1R1 {}XBOOLE-0K1"
     sorry
qed "sorry"

mtheorem finseqop_th_2:
" for f be FunctionFUNCT-1M1 holds [:FUNCT-3K16 {}XBOOLE-0K1,f :] =FUNCT-1R1 {}XBOOLE-0K1 & [:FUNCT-3K16 f,{}XBOOLE-0K1 :] =FUNCT-1R1 {}XBOOLE-0K1"
proof(rule ballI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  have "domRELAT-1K1 ([:FUNCT-3K16 {}XBOOLE-0K1,f :]) =XBOOLE-0R4 [:ZFMISC-1K2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ({}XBOOLE-0K1),domRELAT-1K1 f :] & domRELAT-1K1 ([:FUNCT-3K16 f,{}XBOOLE-0K1 :]) =XBOOLE-0R4 [:ZFMISC-1K2 domRELAT-1K1 f,domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ({}XBOOLE-0K1) :]"
    using funct_3_def_8 sorry
  thus "[:FUNCT-3K16 {}XBOOLE-0K1,f :] =FUNCT-1R1 {}XBOOLE-0K1 & [:FUNCT-3K16 f,{}XBOOLE-0K1 :] =FUNCT-1R1 {}XBOOLE-0K1"
    using zfmisc_1_th_90 sorry
qed "sorry"

mtheorem finseqop_th_3:
" for F be FunctionFUNCT-1M1 holds  for f be FunctionFUNCT-1M1 holds F .:FUNCOP-1K3({}XBOOLE-0K1,f) =FUNCT-1R1 {}XBOOLE-0K1 & F .:FUNCOP-1K3(f,{}XBOOLE-0K1) =FUNCT-1R1 {}XBOOLE-0K1"
proof(rule ballI,rule ballI)
  fix F assume [ty]: "F be FunctionFUNCT-1M1"
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  have "F .:FUNCOP-1K3({}XBOOLE-0K1,f) =FUNCT-1R1 F *FUNCT-1K3 {}XBOOLE-0K1"
    using finseqop_th_1 sorry
  thus "F .:FUNCOP-1K3({}XBOOLE-0K1,f) =FUNCT-1R1 {}XBOOLE-0K1 & F .:FUNCOP-1K3(f,{}XBOOLE-0K1) =FUNCT-1R1 {}XBOOLE-0K1"
    using finseqop_th_1 sorry
qed "sorry"

mtheorem finseqop_th_4:
" for x be setHIDDENM2 holds  for F be FunctionFUNCT-1M1 holds F [:]FUNCOP-1K4({}XBOOLE-0K1,x) =FUNCT-1R1 {}XBOOLE-0K1"
proof-
  have " for x be setHIDDENM2 holds  for F be FunctionFUNCT-1M1 holds F [:]FUNCOP-1K4({}XBOOLE-0K1,x) =FUNCT-1R1 {}XBOOLE-0K1"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix F assume [ty]: "F be FunctionFUNCT-1M1"
    have "F [:]FUNCOP-1K4({}XBOOLE-0K1,x) =FUNCT-1R1 F .:FUNCOP-1K3({}XBOOLE-0K1,domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ({}XBOOLE-0K1) -->FUNCOP-1K7 x)"
       sorry
    thus "F [:]FUNCOP-1K4({}XBOOLE-0K1,x) =FUNCT-1R1 {}XBOOLE-0K1"
      using finseqop_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_5:
" for x be setHIDDENM2 holds  for F be FunctionFUNCT-1M1 holds F [;]FUNCOP-1K5(x,{}XBOOLE-0K1) =FUNCT-1R1 {}XBOOLE-0K1"
proof-
  have " for x be setHIDDENM2 holds  for F be FunctionFUNCT-1M1 holds F [;]FUNCOP-1K5(x,{}XBOOLE-0K1) =FUNCT-1R1 {}XBOOLE-0K1"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix F assume [ty]: "F be FunctionFUNCT-1M1"
    have "F [;]FUNCOP-1K5(x,{}XBOOLE-0K1) =FUNCT-1R1 F .:FUNCOP-1K3(domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ({}XBOOLE-0K1) -->FUNCOP-1K7 x,{}XBOOLE-0K1)"
       sorry
    thus "F [;]FUNCOP-1K5(x,{}XBOOLE-0K1) =FUNCT-1R1 {}XBOOLE-0K1"
      using finseqop_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_6:
" for X be setHIDDENM2 holds  for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds <:FUNCT-3K15\<^bsub>(X,{TARSKIK1 x1},{TARSKIK1 x2})\<^esub> X -->FUNCOP-1K7 x1,X -->FUNCOP-1K7 x2 :> =FUNCT-2R1\<^bsub>(X,[:ZFMISC-1K2 {TARSKIK1 x1},{TARSKIK1 x2} :],X,{TARSKIK1 [TARSKIK4 x1,x2 ] })\<^esub> X -->FUNCOP-1K7 [TARSKIK4 x1,x2 ]"
proof(rule ballI,rule ballI,rule ballI)
  fix X assume [ty]: "X be setHIDDENM2"
  fix x1 assume [ty]: "x1 be setHIDDENM2"
  fix x2 assume [ty]: "x2 be setHIDDENM2"
  let ?f = "X -->FUNCOP-1K7 x1"
  let ?g = "X -->FUNCOP-1K7 x2"
  let ?fg = "<:FUNCT-3K15\<^bsub>(X,{TARSKIK1 x1},{TARSKIK1 x2})\<^esub> ?f,?g :>"
  have "<:FUNCT-3K15\<^bsub>(X,{TARSKIK1 x1},{TARSKIK1 x2})\<^esub> X -->FUNCOP-1K7 x1,X -->FUNCOP-1K7 x2 :> =FUNCT-2R1\<^bsub>(X,[:ZFMISC-1K2 {TARSKIK1 x1},{TARSKIK1 x2} :],X,{TARSKIK1 [TARSKIK4 x1,x2 ] })\<^esub> X -->FUNCOP-1K7 [TARSKIK4 x1,x2 ]"
  proof-
    show "<:FUNCT-3K15\<^bsub>(X,{TARSKIK1 x1},{TARSKIK1 x2})\<^esub> X -->FUNCOP-1K7 x1,X -->FUNCOP-1K7 x2 :> =FUNCT-2R1\<^bsub>(X,[:ZFMISC-1K2 {TARSKIK1 x1},{TARSKIK1 x2} :],X,{TARSKIK1 [TARSKIK4 x1,x2 ] })\<^esub> X -->FUNCOP-1K7 [TARSKIK4 x1,x2 ]"
    proof-
      have cases: "X =XBOOLE-0R4 {}XBOOLE-0K1 or X <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "X =XBOOLE-0R4 {}XBOOLE-0K1 implies <:FUNCT-3K15\<^bsub>(X,{TARSKIK1 x1},{TARSKIK1 x2})\<^esub> X -->FUNCOP-1K7 x1,X -->FUNCOP-1K7 x2 :> =FUNCT-2R1\<^bsub>(X,[:ZFMISC-1K2 {TARSKIK1 x1},{TARSKIK1 x2} :],X,{TARSKIK1 [TARSKIK4 x1,x2 ] })\<^esub> X -->FUNCOP-1K7 [TARSKIK4 x1,x2 ]"
      proof(rule impI)
        assume A1: "X =XBOOLE-0R4 {}XBOOLE-0K1"
        show "<:FUNCT-3K15\<^bsub>(X,{TARSKIK1 x1},{TARSKIK1 x2})\<^esub> X -->FUNCOP-1K7 x1,X -->FUNCOP-1K7 x2 :> =FUNCT-2R1\<^bsub>(X,[:ZFMISC-1K2 {TARSKIK1 x1},{TARSKIK1 x2} :],X,{TARSKIK1 [TARSKIK4 x1,x2 ] })\<^esub> X -->FUNCOP-1K7 [TARSKIK4 x1,x2 ]"
          using A1 sorry
      qed
      have case2: "X <>HIDDENR2 {}XBOOLE-0K1 implies <:FUNCT-3K15\<^bsub>(X,{TARSKIK1 x1},{TARSKIK1 x2})\<^esub> X -->FUNCOP-1K7 x1,X -->FUNCOP-1K7 x2 :> =FUNCT-2R1\<^bsub>(X,[:ZFMISC-1K2 {TARSKIK1 x1},{TARSKIK1 x2} :],X,{TARSKIK1 [TARSKIK4 x1,x2 ] })\<^esub> X -->FUNCOP-1K7 [TARSKIK4 x1,x2 ]"
      proof(rule impI)
        assume A2: "X <>HIDDENR2 {}XBOOLE-0K1"
        have "rngRELSET-1K2\<^bsub>([:ZFMISC-1K2 {TARSKIK1 x1},{TARSKIK1 x2} :])\<^esub> ?fg c=RELSET-1R1\<^bsub>({TARSKIK1 x1},{TARSKIK1 x2})\<^esub> [:ZFMISC-1K2 {TARSKIK1 x1},{TARSKIK1 x2} :]"
           sorry
        then have A3: "rngRELSET-1K2\<^bsub>([:ZFMISC-1K2 {TARSKIK1 x1},{TARSKIK1 x2} :])\<^esub> ?fg c=RELSET-1R1\<^bsub>({TARSKIK1 x1},{TARSKIK1 x2})\<^esub> {TARSKIK1 [TARSKIK4 x1,x2 ] }"
          using zfmisc_1_th_29 sorry
        let ?x = "the ElementSUBSET-1M1-of X"
        have A4: "domRELSET-1K1\<^bsub>(X)\<^esub> ?f =XBOOLE-0R4 X & domRELSET-1K1\<^bsub>(X)\<^esub> ?g =XBOOLE-0R4 X"
          using funcop_1_th_13 sorry
        then have A5: "domRELSET-1K1\<^bsub>(X)\<^esub> ?fg =XBOOLE-0R4 X"
          using funct_3_th_50 sorry
        have "?f .FUNCT-1K1 ?x =XBOOLE-0R4 x1 & ?g .FUNCT-1K1 ?x =XBOOLE-0R4 x2"
          using A2 funcop_1_th_7 sorry
        then have "?fg .FUNCT-1K1 ?x =HIDDENR1 [TARSKIK4 x1,x2 ]"
          using A2 A4 funct_3_th_49 sorry
        then have "[TARSKIK4 x1,x2 ] inHIDDENR3 rngRELSET-1K2\<^bsub>([:ZFMISC-1K2 {TARSKIK1 x1},{TARSKIK1 x2} :])\<^esub> ?fg"
          using A2 A5 funct_1_def_3 sorry
        then have "{TARSKIK1 [TARSKIK4 x1,x2 ] } c=RELAT-1R2 rngRELSET-1K2\<^bsub>([:ZFMISC-1K2 {TARSKIK1 x1},{TARSKIK1 x2} :])\<^esub> ?fg"
          using zfmisc_1_th_31 sorry
        then have "rngRELSET-1K2\<^bsub>([:ZFMISC-1K2 {TARSKIK1 x1},{TARSKIK1 x2} :])\<^esub> ?fg =RELAT-1R1 {TARSKIK1 [TARSKIK4 x1,x2 ] }"
          using A3 xboole_0_def_10 sorry
        thus "<:FUNCT-3K15\<^bsub>(X,{TARSKIK1 x1},{TARSKIK1 x2})\<^esub> X -->FUNCOP-1K7 x1,X -->FUNCOP-1K7 x2 :> =FUNCT-2R1\<^bsub>(X,[:ZFMISC-1K2 {TARSKIK1 x1},{TARSKIK1 x2} :],X,{TARSKIK1 [TARSKIK4 x1,x2 ] })\<^esub> X -->FUNCOP-1K7 [TARSKIK4 x1,x2 ]"
          using A5 funcop_1_th_9 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
  thus "<:FUNCT-3K15\<^bsub>(X,{TARSKIK1 x1},{TARSKIK1 x2})\<^esub> X -->FUNCOP-1K7 x1,X -->FUNCOP-1K7 x2 :> =FUNCT-2R1\<^bsub>(X,[:ZFMISC-1K2 {TARSKIK1 x1},{TARSKIK1 x2} :],X,{TARSKIK1 [TARSKIK4 x1,x2 ] })\<^esub> X -->FUNCOP-1K7 [TARSKIK4 x1,x2 ]"
     sorry
qed "sorry"

mtheorem finseqop_th_7:
" for F be FunctionFUNCT-1M1 holds  for X be setHIDDENM2 holds  for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds [TARSKIK4 x1,x2 ] inHIDDENR3 domRELAT-1K1 F implies F .:FUNCOP-1K3(X -->FUNCOP-1K7 x1,X -->FUNCOP-1K7 x2) =FUNCT-1R1 X -->FUNCOP-1K7 F .BINOP-1K1(x1,x2)"
proof-
  have " for F be FunctionFUNCT-1M1 holds  for X be setHIDDENM2 holds  for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds [TARSKIK4 x1,x2 ] inHIDDENR3 domRELAT-1K1 F implies F .:FUNCOP-1K3(X -->FUNCOP-1K7 x1,X -->FUNCOP-1K7 x2) =HIDDENR1 X -->FUNCOP-1K7 F .BINOP-1K1(x1,x2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix F assume [ty]: "F be FunctionFUNCT-1M1"
    fix X assume [ty]: "X be setHIDDENM2"
    fix x1 assume [ty]: "x1 be setHIDDENM2"
    fix x2 assume [ty]: "x2 be setHIDDENM2"
    assume A1: "[TARSKIK4 x1,x2 ] inHIDDENR3 domRELAT-1K1 F"
    let ?f = "X -->FUNCOP-1K7 x1"
    let ?g = "X -->FUNCOP-1K7 x2"
    have "F .:FUNCOP-1K3(X -->FUNCOP-1K7 x1,X -->FUNCOP-1K7 x2) =HIDDENR1 F *FUNCT-1K3 (X -->FUNCOP-1K7 [TARSKIK4 x1,x2 ])"
      using finseqop_th_6 sorry
    also have "... = X -->FUNCOP-1K7 F .BINOP-1K1(x1,x2)"
      using A1 funcop_1_th_17 sorry
    finally show "F .:FUNCOP-1K3(X -->FUNCOP-1K7 x1,X -->FUNCOP-1K7 x2) =HIDDENR1 X -->FUNCOP-1K7 F .BINOP-1K1(x1,x2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve i, j for "naturalORDINAL1V7\<bar>NumberORDINAL1M1"
reserve F for "FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E)"
reserve p, q for "FinSequenceFINSEQ-1M3-of D"
reserve p9, q9 for "FinSequenceFINSEQ-1M3-of D9"
syntax FINSEQOPK1 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ .:FINSEQOPK1\<^bsub>'( _ , _ , _ ')\<^esub>'( _ , _ ')" [200,0,0,0,0,0]200)
translations "F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(p,p9)" \<rightharpoonup> "F .:FUNCOP-1K3(p,p9)"

mtheorem finseqop_add_1:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E)", "p be FinSequenceFINSEQ-1M3-of D", "p9 be FinSequenceFINSEQ-1M3-of D9"
"cluster F .:FUNCOP-1K3(p,p9) as-term-is FinSequenceFINSEQ-1M3-of E"
proof
(*coherence*)
  show "F .:FUNCOP-1K3(p,p9) be FinSequenceFINSEQ-1M3-of E"
    using finseq_2_th_70 sorry
qed "sorry"

syntax FINSEQOPK2 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ [:]FINSEQOPK2\<^bsub>'( _ , _ , _ ')\<^esub>'( _ , _ ')" [180,0,0,0,0,0]180)
translations "F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p,d9)" \<rightharpoonup> "F [:]FUNCOP-1K4(p,d9)"

mtheorem finseqop_add_2:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E)", "p be FinSequenceFINSEQ-1M3-of D", "d9 be ElementSUBSET-1M1-of D9"
"cluster F [:]FUNCOP-1K4(p,d9) as-term-is FinSequenceFINSEQ-1M3-of E"
proof
(*coherence*)
  show "F [:]FUNCOP-1K4(p,d9) be FinSequenceFINSEQ-1M3-of E"
    using finseq_2_th_83 sorry
qed "sorry"

syntax FINSEQOPK3 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ [;]FINSEQOPK3\<^bsub>'( _ , _ , _ ')\<^esub>'( _ , _ ')" [180,0,0,0,0,0]180)
translations "F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9)" \<rightharpoonup> "F [;]FUNCOP-1K5(d,p9)"

mtheorem finseqop_add_3:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E)", "d be ElementSUBSET-1M1-of D", "p9 be FinSequenceFINSEQ-1M3-of D9"
"cluster F [;]FUNCOP-1K5(d,p9) as-term-is FinSequenceFINSEQ-1M3-of E"
proof
(*coherence*)
  show "F [;]FUNCOP-1K5(d,p9) be FinSequenceFINSEQ-1M3-of E"
    using finseq_2_th_77 sorry
qed "sorry"

reserve f, f9 for "FunctionFUNCT-2M1-of(C,D)"
reserve h for "FunctionFUNCT-2M1-of(D,E)"
syntax FINSEQOPK4 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ *FINSEQOPK4\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p" \<rightharpoonup> "p *RELAT-1K6 h"

mtheorem finseqop_add_4:
  mlet "D be setHIDDENM2", "E be setHIDDENM2", "p be FinSequenceFINSEQ-1M3-of D", "h be FunctionFUNCT-2M1-of(D,E)"
"cluster p *RELAT-1K6 h as-term-is FinSequenceFINSEQ-1M3-of E"
proof
(*coherence*)
  show "p *RELAT-1K6 h be FinSequenceFINSEQ-1M3-of E"
    using finseq_2_th_32 sorry
qed "sorry"

mtheorem finseqop_th_8:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds  for h be FunctionFUNCT-2M1-of(D,E) holds h *FINSEQOPK4\<^bsub>(D,E)\<^esub> (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p)^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d*>)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds  for h be FunctionFUNCT-2M1-of(D,E) holds h *FINSEQOPK4\<^bsub>(D,E)\<^esub> (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p)^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d*>)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of D"
    fix h assume [ty]: "h be FunctionFUNCT-2M1-of(D,E)"
    let ?q = "h *FINSEQOPK4\<^bsub>(D,E)\<^esub> (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>))"
    let ?r = "(h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p)^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d*>)"
    let ?i = "lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M"
    have A1: "lenFINSEQ-1K4 ?q =XBOOLE-0R4 lenFINSEQ-1K4 (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>))"
      using finseq_2_th_33 sorry
    have A2: "lenFINSEQ-1K4 (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p) =XBOOLE-0R4 lenFINSEQ-1K4 p"
      using finseq_2_th_33 sorry
    have "lenFINSEQ-1K4 (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)) =XBOOLE-0R4 ?i"
      using finseq_2_th_16 sorry
    then have A3: "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ?q =XBOOLE-0R4 SegFINSEQ-1K2 ?i"
      using A1 finseq_1_def_3 sorry
    have A4: " for j be NatNAT-1M1 holds j inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>))) implies (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>))).FUNCT-1K1 j =XBOOLE-0R4 ((h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p)^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d*>)).FUNCT-1K1 j"
    proof(rule ballI,rule impI)
      fix j assume [ty]: "j be NatNAT-1M1"
      have A5: "SegFINSEQ-1K2 (lenFINSEQ-1K4 p) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> p"
        using finseq_1_def_3 sorry
      have A6: "SegFINSEQ-1K2 (lenFINSEQ-1K4 (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p)) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p)"
        using finseq_1_def_3 sorry
      assume A7: "j inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ?q"
      have "h .FUNCT-1K1 ((p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)).FUNCT-1K1 j) =HIDDENR1 ((h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p)^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d*>)).FUNCT-1K1 j"
      proof-
        show "h .FUNCT-1K1 ((p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)).FUNCT-1K1 j) =HIDDENR1 ((h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p)^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d*>)).FUNCT-1K1 j"
        proof-
          have cases: "j inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> p or j =XBOOLE-0R4 ?i"
            using A3 A7 A5 finseq_2_th_7 sorry
          have case1: "j inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> p implies h .FUNCT-1K1 ((p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)).FUNCT-1K1 j) =HIDDENR1 ((h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p)^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d*>)).FUNCT-1K1 j"
          proof(rule impI)
            assume A8: "j inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> p"
            then have "h .FUNCT-1K1 ((p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)).FUNCT-1K1 j) =HIDDENR1 h .FUNCT-1K1 (p .FUNCT-1K1 j)"
              using finseq_1_def_7 sorry
            also have "... = (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p).FUNCT-1K1 j"
              using A2 A5 A6 A8 funct_1_th_12 sorry
            also have "... = ((h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p)^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d*>)).FUNCT-1K1 j"
              using A2 A5 A6 A8 finseq_1_def_7 sorry
            finally show "h .FUNCT-1K1 ((p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)).FUNCT-1K1 j) =HIDDENR1 ((h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p)^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d*>)).FUNCT-1K1 j"
               sorry
          qed
          have case2: "j =XBOOLE-0R4 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M implies h .FUNCT-1K1 ((p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)).FUNCT-1K1 j) =HIDDENR1 ((h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p)^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d*>)).FUNCT-1K1 j"
          proof(rule impI)
            assume A9: "j =XBOOLE-0R4 ?i"
            then have "h .FUNCT-1K1 ((p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)).FUNCT-1K1 j) =HIDDENR1 h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d"
              using finseq_1_th_42 sorry
            also have "... = ((h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p)^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d*>)).FUNCT-1K1 j"
              using A2 A9 finseq_1_th_42 sorry
            finally show "h .FUNCT-1K1 ((p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)).FUNCT-1K1 j) =HIDDENR1 ((h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p)^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d*>)).FUNCT-1K1 j"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "(h *FINSEQOPK4\<^bsub>(D,E)\<^esub> (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>))).FUNCT-1K1 j =XBOOLE-0R4 ((h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p)^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d*>)).FUNCT-1K1 j"
        using A7 funct_1_th_12 sorry
    qed "sorry"
    have "lenFINSEQ-1K4 ?r =XBOOLE-0R4 lenFINSEQ-1K4 (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p) +NAT-1K1 \<one>\<^sub>M"
      using finseq_2_th_16 sorry
    thus "h *FINSEQOPK4\<^bsub>(D,E)\<^esub> (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p)^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d*>)"
      using A1 A2 A4 finseq_2_th_9 finseq_2_th_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_9:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M3-of D holds  for q be FinSequenceFINSEQ-1M3-of D holds  for h be FunctionFUNCT-2M1-of(D,E) holds h *FINSEQOPK4\<^bsub>(D,E)\<^esub> (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p)^FINSEQ-1K9\<^bsub>(E)\<^esub> (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> q)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M3-of D holds  for q be FinSequenceFINSEQ-1M3-of D holds  for h be FunctionFUNCT-2M1-of(D,E) holds h *FINSEQOPK4\<^bsub>(D,E)\<^esub> (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p)^FINSEQ-1K9\<^bsub>(E)\<^esub> (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> q)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of D"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of D"
    fix h assume [ty]: "h be FunctionFUNCT-2M1-of(D,E)"
    let ?P = "\<lambda>Lamb1. h *FINSEQOPK4\<^bsub>(D,E)\<^esub> (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> Lamb1) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p)^FINSEQ-1K9\<^bsub>(E)\<^esub> (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> Lamb1)"
    have A1: " for q be FinSequenceFINSEQ-1M3-of D holds  for d be ElementSUBSET-1M1-of D holds ?P(q) implies ?P(q ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>))"
    proof-
      have " for q be FinSequenceFINSEQ-1M3-of D holds  for d be ElementSUBSET-1M1-of D holds h *FINSEQOPK4\<^bsub>(D,E)\<^esub> (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p)^FINSEQ-1K9\<^bsub>(E)\<^esub> (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> q) implies h *FINSEQOPK4\<^bsub>(D,E)\<^esub> (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (q ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>))) =HIDDENR1 (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p)^FINSEQ-1K9\<^bsub>(E)\<^esub> (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> (q ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)))"
      proof(rule ballI,rule ballI,rule impI)
        fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of D"
        fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
        assume A2: "h *FINSEQOPK4\<^bsub>(D,E)\<^esub> (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p)^FINSEQ-1K9\<^bsub>(E)\<^esub> (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> q)"
        have "h *FINSEQOPK4\<^bsub>(D,E)\<^esub> (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (q ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>))) =HIDDENR1 h *FINSEQOPK4\<^bsub>(D,E)\<^esub> ((p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q)^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>))"
          using finseq_1_th_32 sorry
        also have "... = (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q))^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d*>)"
          using finseqop_th_8 sorry
        also have "... = (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p)^FINSEQ-1K9\<^bsub>(E)\<^esub> ((h *FINSEQOPK4\<^bsub>(D,E)\<^esub> q)^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d*>))"
          using A2 finseq_1_th_32 sorry
        also have "... = (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p)^FINSEQ-1K9\<^bsub>(E)\<^esub> (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> (q ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)))"
          using finseqop_th_8 sorry
        finally show "h *FINSEQOPK4\<^bsub>(D,E)\<^esub> (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (q ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>))) =HIDDENR1 (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p)^FINSEQ-1K9\<^bsub>(E)\<^esub> (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> (q ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "h *FINSEQOPK4\<^bsub>(D,E)\<^esub> (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> <*>FINSEQ-1K7 D) =HIDDENR1 h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p"
      using finseq_1_th_34 sorry
    also have "... = (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p)^FINSEQ-1K9\<^bsub>(E)\<^esub> (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> <*>FINSEQ-1K7 D)"
      using finseq_1_th_34 sorry
    finally have "h *FINSEQOPK4\<^bsub>(D,E)\<^esub> (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> <*>FINSEQ-1K7 D) =HIDDENR1 (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p)^FINSEQ-1K9\<^bsub>(E)\<^esub> (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> <*>FINSEQ-1K7 D)"
       sorry
    then have A3: "?P(<*>FINSEQ-1K7 D)"
       sorry
    have " for q be FinSequenceFINSEQ-1M3-of D holds ?P(q)"
      using finseq_2_sch_2 A3 A1 sorry
    thus "h *FINSEQOPK4\<^bsub>(D,E)\<^esub> (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p)^FINSEQ-1K9\<^bsub>(E)\<^esub> (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> q)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve T, T1, T2, T3 for "TupleFINSEQ-2M3-of(i,D)"
reserve T9 for "TupleFINSEQ-2M3-of(i,D9)"
reserve S for "TupleFINSEQ-2M3-of(j,D)"
reserve S9 for "TupleFINSEQ-2M3-of(j,D9)"
mlemma finseqop_lm_1:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds  for T9 be TupleFINSEQ-2M3-of(i,D9) holds  for T be TupleFINSEQ-2M3-of(0NUMBERSK6,D) holds F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T,T9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> <*>FINSEQ-1K7 E"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds  for T9 be TupleFINSEQ-2M3-of(i,D9) holds  for T be TupleFINSEQ-2M3-of(0NUMBERSK6,D) holds F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T,T9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> <*>FINSEQ-1K7 E"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D9 assume [ty]: "D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix F assume [ty]: "F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E)"
    fix T9 assume [ty]: "T9 be TupleFINSEQ-2M3-of(i,D9)"
    fix T assume [ty]: "T be TupleFINSEQ-2M3-of(0NUMBERSK6,D)"
    have "T =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D"
       sorry
    thus "F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T,T9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> <*>FINSEQ-1K7 E"
      using finseq_2_th_73 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma finseqop_lm_2:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds  for T9 be TupleFINSEQ-2M3-of(0NUMBERSK6,D9) holds F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,T9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> <*>FINSEQ-1K7 E"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds  for T9 be TupleFINSEQ-2M3-of(0NUMBERSK6,D9) holds F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,T9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> <*>FINSEQ-1K7 E"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D9 assume [ty]: "D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E)"
    fix T9 assume [ty]: "T9 be TupleFINSEQ-2M3-of(0NUMBERSK6,D9)"
    have "T9 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D9)\<^esub> <*>FINSEQ-1K7 D9"
       sorry
    thus "F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,T9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> <*>FINSEQ-1K7 E"
      using finseq_2_th_79 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma finseqop_lm_3:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d9 be ElementSUBSET-1M1-of D9 holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds  for T be TupleFINSEQ-2M3-of(0NUMBERSK6,D) holds F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(T,d9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> <*>FINSEQ-1K7 E"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d9 be ElementSUBSET-1M1-of D9 holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds  for T be TupleFINSEQ-2M3-of(0NUMBERSK6,D) holds F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(T,d9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> <*>FINSEQ-1K7 E"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D9 assume [ty]: "D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d9 assume [ty]: "d9 be ElementSUBSET-1M1-of D9"
    fix F assume [ty]: "F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E)"
    fix T assume [ty]: "T be TupleFINSEQ-2M3-of(0NUMBERSK6,D)"
    have "T =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D"
       sorry
    thus "F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(T,d9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> <*>FINSEQ-1K7 E"
      using finseq_2_th_85 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_10:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for d9 be ElementSUBSET-1M1-of D9 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds  for T be TupleFINSEQ-2M3-of(i,D) holds  for T9 be TupleFINSEQ-2M3-of(i,D9) holds F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>),T9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>)) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T,T9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for d9 be ElementSUBSET-1M1-of D9 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds  for T be TupleFINSEQ-2M3-of(i,D) holds  for T9 be TupleFINSEQ-2M3-of(i,D9) holds F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>),T9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>)) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T,T9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D9 assume [ty]: "D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix d9 assume [ty]: "d9 be ElementSUBSET-1M1-of D9"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix F assume [ty]: "F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E)"
    fix T assume [ty]: "T be TupleFINSEQ-2M3-of(i,D)"
    fix T9 assume [ty]: "T9 be TupleFINSEQ-2M3-of(i,D9)"
    let ?p = "T ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)"
    let ?q = "T9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>)"
    let ?pq = "F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T,T9)"
    let ?r = "F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(?p,?q)"
    let ?s = "?pq ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)"
    have A1: "lenFINSEQ-1K4 T9 =HIDDENR1 i"
      using card_1_def_7 sorry
    then have A2: "lenFINSEQ-1K4 ?q =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M"
      using finseq_2_th_16 sorry
    have A3: "lenFINSEQ-1K4 T =HIDDENR1 i"
      using card_1_def_7 sorry
    then have A4: "lenFINSEQ-1K4 ?pq =HIDDENR1 i"
      using A1 finseq_2_th_72 sorry
    have "lenFINSEQ-1K4 ?p =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M"
      using A3 finseq_2_th_16 sorry
    then have A5: "lenFINSEQ-1K4 ?r =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M"
      using A2 finseq_2_th_72 sorry
    then have A6: "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ?r =XBOOLE-0R4 SegFINSEQ-1K2 (i +NAT-1K1 \<one>\<^sub>M)"
      using finseq_1_def_3 sorry
    have A7: " for j be NatNAT-1M1 holds j inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> (F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>),T9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>))) implies (F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>),T9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>))).FUNCT-1K1 j =XBOOLE-0R4 (F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T,T9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)).FUNCT-1K1 j"
    proof(rule ballI,rule impI)
      fix j assume [ty]: "j be NatNAT-1M1"
      assume A8: "j inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ?r"
      have "F .BINOP-1K1((T ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)).FUNCT-1K1 j,(T9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>)).FUNCT-1K1 j) =HIDDENR1 (F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T,T9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)).FUNCT-1K1 j"
      proof-
        show "F .BINOP-1K1((T ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)).FUNCT-1K1 j,(T9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>)).FUNCT-1K1 j) =HIDDENR1 (F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T,T9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)).FUNCT-1K1 j"
        proof-
          have cases: "j inTARSKIR2 SegFINSEQ-1K1 i or j =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M"
            using A6 A8 finseq_2_th_7 sorry
          have case1: "j inTARSKIR2 SegFINSEQ-1K1 i implies F .BINOP-1K1((T ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)).FUNCT-1K1 j,(T9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>)).FUNCT-1K1 j) =HIDDENR1 (F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T,T9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)).FUNCT-1K1 j"
          proof(rule impI)
            assume A9: "j inTARSKIR2 SegFINSEQ-1K1 i"
            have "SegFINSEQ-1K2 (lenFINSEQ-1K4 T) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> T"
              using finseq_1_def_3 sorry
            then have A10: "?p .FUNCT-1K1 j =XBOOLE-0R4 T .FUNCT-1K1 j"
              using A3 A9 finseq_1_def_7 sorry
            have A11: "SegFINSEQ-1K2 (lenFINSEQ-1K4 ?pq) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ?pq"
              using finseq_1_def_3 sorry
            have "SegFINSEQ-1K2 (lenFINSEQ-1K4 T9) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> T9"
              using finseq_1_def_3 sorry
            then have A12: "?q .FUNCT-1K1 j =XBOOLE-0R4 T9 .FUNCT-1K1 j"
              using A1 A9 finseq_1_def_7 sorry
            have "j inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ?pq"
              using A4 A9 finseq_1_def_3 sorry
            then have "F .BINOP-1K1((T ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)).FUNCT-1K1 j,(T9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>)).FUNCT-1K1 j) =HIDDENR1 (F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T,T9)).FUNCT-1K1 j"
              using A10 A12 funcop_1_th_22 sorry
            also have "... = (F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T,T9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)).FUNCT-1K1 j"
              using A4 A9 A11 finseq_1_def_7 sorry
            finally show "F .BINOP-1K1((T ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)).FUNCT-1K1 j,(T9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>)).FUNCT-1K1 j) =HIDDENR1 (F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T,T9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)).FUNCT-1K1 j"
               sorry
          qed
          have case2: "j =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M implies F .BINOP-1K1((T ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)).FUNCT-1K1 j,(T9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>)).FUNCT-1K1 j) =XBOOLE-0R4 (F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T,T9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)).FUNCT-1K1 j"
          proof(rule impI)
            assume A13: "j =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M"
            then have "?p .FUNCT-1K1 j =XBOOLE-0R4 d & ?q .FUNCT-1K1 j =XBOOLE-0R4 d9"
              using A3 A1 finseq_1_th_42 sorry
            thus "F .BINOP-1K1((T ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)).FUNCT-1K1 j,(T9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>)).FUNCT-1K1 j) =XBOOLE-0R4 (F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T,T9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)).FUNCT-1K1 j"
              using A4 A13 finseq_1_th_42 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "(F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>),T9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>))).FUNCT-1K1 j =XBOOLE-0R4 (F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T,T9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)).FUNCT-1K1 j"
        using A8 funcop_1_th_22 sorry
    qed "sorry"
    have "lenFINSEQ-1K4 ?s =XBOOLE-0R4 lenFINSEQ-1K4 ?pq +NAT-1K1 \<one>\<^sub>M"
      using finseq_2_th_16 sorry
    thus "F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>),T9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>)) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T,T9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)"
      using A5 A4 A7 finseq_2_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_11:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds  for T be TupleFINSEQ-2M3-of(i,D) holds  for T9 be TupleFINSEQ-2M3-of(i,D9) holds  for S be TupleFINSEQ-2M3-of(j,D) holds  for S9 be TupleFINSEQ-2M3-of(j,D9) holds F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T ^FINSEQ-1K9\<^bsub>(D)\<^esub> S,T9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> S9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T,T9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(S,S9)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds  for T be TupleFINSEQ-2M3-of(i,D) holds  for T9 be TupleFINSEQ-2M3-of(i,D9) holds  for S be TupleFINSEQ-2M3-of(j,D) holds  for S9 be TupleFINSEQ-2M3-of(j,D9) holds F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T ^FINSEQ-1K9\<^bsub>(D)\<^esub> S,T9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> S9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T,T9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(S,S9)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D9 assume [ty]: "D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix j assume [ty]: "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix F assume [ty]: "F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E)"
    fix T assume [ty]: "T be TupleFINSEQ-2M3-of(i,D)"
    fix T9 assume [ty]: "T9 be TupleFINSEQ-2M3-of(i,D9)"
    fix S assume [ty]: "S be TupleFINSEQ-2M3-of(j,D)"
    fix S9 assume [ty]: "S9 be TupleFINSEQ-2M3-of(j,D9)"
    have A0: "i be NatNAT-1M1 & j be NatNAT-1M1"
      using tarski_th_1 sorry
    let ?P = "\<lambda>Lamb1.  for S be TupleFINSEQ-2M3-of(Lamb1,D) holds  for S9 be TupleFINSEQ-2M3-of(Lamb1,D9) holds F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T ^FINSEQ-1K9\<^bsub>(D)\<^esub> S,T9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> S9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T,T9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(S,S9)"
    have " for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds ( for S be TupleFINSEQ-2M3-of(j,D) holds  for S9 be TupleFINSEQ-2M3-of(j,D9) holds F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T ^FINSEQ-1K9\<^bsub>(D)\<^esub> S,T9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> S9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T,T9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(S,S9)) implies ( for S be TupleFINSEQ-2M3-of(j +NAT-1K1 \<one>\<^sub>M,D) holds  for S9 be TupleFINSEQ-2M3-of(j +NAT-1K1 \<one>\<^sub>M,D9) holds F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T ^FINSEQ-1K9\<^bsub>(D)\<^esub> S,T9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> S9) =HIDDENR1 F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T,T9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(S,S9))"
    proof(rule ballI,rule impI,rule ballI,rule ballI)
      fix j assume [ty]: "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
      assume A1: " for S be TupleFINSEQ-2M3-of(j,D) holds  for S9 be TupleFINSEQ-2M3-of(j,D9) holds F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T ^FINSEQ-1K9\<^bsub>(D)\<^esub> S,T9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> S9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T,T9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(S,S9)"
      fix S assume [ty]: "S be TupleFINSEQ-2M3-of(j +NAT-1K1 \<one>\<^sub>M,D)"
      fix S9 assume [ty]: "S9 be TupleFINSEQ-2M3-of(j +NAT-1K1 \<one>\<^sub>M,D9)"
      obtain S1 d where
        [ty]:"S1 be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of j -tuples-onFINSEQ-2K4 D" "d be ElementSUBSET-1M1-of D" and 
        A2: "S =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> S1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)"
        using finseq_2_th_117 sorry
      have A3: "T ^FINSEQ-1K9\<^bsub>(D)\<^esub> S =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> (T ^FINSEQ-1K9\<^bsub>(D)\<^esub> S1)^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)"
        using A2 finseq_1_th_32 sorry
      have 
        [ty]:"S1 be TupleFINSEQ-2M3-of(j,D)"
         sorry
      obtain S19 d9 where
        [ty]:"S19 be ElementFINSEQ-2M2\<^bsub>(D9)\<^esub>-of j -tuples-onFINSEQ-2K4 D9" "d9 be ElementSUBSET-1M1-of D9" and 
        A4: "S9 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D9)\<^esub> S19 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>)"
        using finseq_2_th_117 sorry
      have A5: "T9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> S9 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D9)\<^esub> (T9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> S19)^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>)"
        using A4 finseq_1_th_32 sorry
      have 
        [ty]:"S19 be TupleFINSEQ-2M3-of(j,D9)"
         sorry
      have "F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T ^FINSEQ-1K9\<^bsub>(D)\<^esub> S,T9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> S9) =HIDDENR1 F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T ^FINSEQ-1K9\<^bsub>(D)\<^esub> S1,T9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> S19) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)"
        using A3 A5 finseqop_th_10 sorry
      also have "... = (F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T,T9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(S1,S19))^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)"
        using A1 sorry
      also have "... = F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T,T9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(S1,S19) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>))"
        using finseq_1_th_32 sorry
      also have "... = F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T,T9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(S,S9)"
        using A2 A4 finseqop_th_10 sorry
      finally show "F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T ^FINSEQ-1K9\<^bsub>(D)\<^esub> S,T9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> S9) =HIDDENR1 F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T,T9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(S,S9)"
         sorry
    qed "sorry"
    then have A6: " for j be NatNAT-1M1 holds ?P(j) implies ?P(j +NAT-1K1 \<one>\<^sub>M)"
       sorry
    have " for S be TupleFINSEQ-2M3-of(0NUMBERSK6,D) holds  for S9 be TupleFINSEQ-2M3-of(0NUMBERSK6,D9) holds F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T ^FINSEQ-1K9\<^bsub>(D)\<^esub> S,T9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> S9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T,T9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(S,S9)"
    proof(rule ballI,rule ballI)
      fix S assume [ty]: "S be TupleFINSEQ-2M3-of(0NUMBERSK6,D)"
      fix S9 assume [ty]: "S9 be TupleFINSEQ-2M3-of(0NUMBERSK6,D9)"
      have "S =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D"
         sorry
      then have A7: "F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(S,S9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> <*>FINSEQ-1K7 E"
        using finseq_2_th_73 sorry
      have "T ^FINSEQ-1K9\<^bsub>(D)\<^esub> S =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T & T9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> S9 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D9)\<^esub> T9"
        using finseq_2_th_95 sorry
      thus "F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T ^FINSEQ-1K9\<^bsub>(D)\<^esub> S,T9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> S9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T,T9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(S,S9)"
        using A7 finseq_1_th_34 sorry
    qed "sorry"
    then have A8: "?P(0NUMBERSK6)"
       sorry
    have " for j be NatNAT-1M1 holds ?P(j)"
      using nat_1_sch_2 A8 A6 sorry
    thus "F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T ^FINSEQ-1K9\<^bsub>(D)\<^esub> S,T9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> S9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(T,T9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(S,S9)"
      using A0 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_12:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for d9 be ElementSUBSET-1M1-of D9 holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds  for p9 be FinSequenceFINSEQ-1M3-of D9 holds F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>)) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for d9 be ElementSUBSET-1M1-of D9 holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds  for p9 be FinSequenceFINSEQ-1M3-of D9 holds F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>)) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D9 assume [ty]: "D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix d9 assume [ty]: "d9 be ElementSUBSET-1M1-of D9"
    fix F assume [ty]: "F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E)"
    fix p9 assume [ty]: "p9 be FinSequenceFINSEQ-1M3-of D9"
    let ?pd = "p9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>)"
    let ?q = "F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9)"
    let ?r = "F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,?pd)"
    let ?s = "?q ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)"
    let ?i = "lenFINSEQ-1K4 p9"
    have A1: "lenFINSEQ-1K4 ?q =XBOOLE-0R4 ?i"
      using finseq_2_th_78 sorry
    have "lenFINSEQ-1K4 ?pd =XBOOLE-0R4 ?i +NAT-1K1 \<one>\<^sub>M"
      using finseq_2_th_16 sorry
    then have A2: "lenFINSEQ-1K4 ?r =XBOOLE-0R4 ?i +NAT-1K1 \<one>\<^sub>M"
      using finseq_2_th_78 sorry
    then have A3: "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ?r =XBOOLE-0R4 SegFINSEQ-1K2 (?i +NAT-1K1 \<one>\<^sub>M)"
      using finseq_1_def_3 sorry
    have A4: " for j be NatNAT-1M1 holds j inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> (F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>))) implies (F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>))).FUNCT-1K1 j =XBOOLE-0R4 (F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)).FUNCT-1K1 j"
    proof(rule ballI,rule impI)
      fix j assume [ty]: "j be NatNAT-1M1"
      assume A5: "j inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ?r"
      have "F .BINOP-1K1(d,(p9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>)).FUNCT-1K1 j) =HIDDENR1 (F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)).FUNCT-1K1 j"
      proof-
        show "F .BINOP-1K1(d,(p9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>)).FUNCT-1K1 j) =HIDDENR1 (F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)).FUNCT-1K1 j"
        proof-
          have cases: "j inTARSKIR2 SegFINSEQ-1K2 ?i or j =XBOOLE-0R4 ?i +NAT-1K1 \<one>\<^sub>M"
            using A3 A5 finseq_2_th_7 sorry
          have case1: "j inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p9) implies F .BINOP-1K1(d,(p9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>)).FUNCT-1K1 j) =HIDDENR1 (F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)).FUNCT-1K1 j"
          proof(rule impI)
            assume A6: "j inTARSKIR2 SegFINSEQ-1K2 ?i"
            then have A7: "j inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ?q"
              using A1 finseq_1_def_3 sorry
            have A8: "SegFINSEQ-1K2 (lenFINSEQ-1K4 ?q) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ?q"
              using finseq_1_def_3 sorry
            have "SegFINSEQ-1K2 (lenFINSEQ-1K4 p9) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> p9"
              using finseq_1_def_3 sorry
            then have "F .BINOP-1K1(d,(p9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>)).FUNCT-1K1 j) =HIDDENR1 F .BINOP-1K1(d,p9 .FUNCT-1K1 j)"
              using A6 finseq_1_def_7 sorry
            also have "... = (F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9)).FUNCT-1K1 j"
              using A7 funcop_1_th_32 sorry
            also have "... = (F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)).FUNCT-1K1 j"
              using A1 A6 A8 finseq_1_def_7 sorry
            finally show "F .BINOP-1K1(d,(p9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>)).FUNCT-1K1 j) =HIDDENR1 (F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)).FUNCT-1K1 j"
               sorry
          qed
          have case2: "j =XBOOLE-0R4 lenFINSEQ-1K4 p9 +NAT-1K1 \<one>\<^sub>M implies F .BINOP-1K1(d,(p9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>)).FUNCT-1K1 j) =HIDDENR1 (F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)).FUNCT-1K1 j"
          proof(rule impI)
            assume A9: "j =XBOOLE-0R4 ?i +NAT-1K1 \<one>\<^sub>M"
            then have "F .BINOP-1K1(d,(p9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>)).FUNCT-1K1 j) =HIDDENR1 F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)"
              using finseq_1_th_42 sorry
            also have "... = (F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)).FUNCT-1K1 j"
              using A1 A9 finseq_1_th_42 sorry
            finally show "F .BINOP-1K1(d,(p9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>)).FUNCT-1K1 j) =HIDDENR1 (F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)).FUNCT-1K1 j"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "(F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>))).FUNCT-1K1 j =XBOOLE-0R4 (F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)).FUNCT-1K1 j"
        using A5 funcop_1_th_32 sorry
    qed "sorry"
    have "lenFINSEQ-1K4 ?s =XBOOLE-0R4 lenFINSEQ-1K4 ?q +NAT-1K1 \<one>\<^sub>M"
      using finseq_2_th_16 sorry
    thus "F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>)) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)"
      using A1 A2 A4 finseq_2_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_13:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds  for p9 be FinSequenceFINSEQ-1M3-of D9 holds  for q9 be FinSequenceFINSEQ-1M3-of D9 holds F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> q9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,q9)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds  for p9 be FinSequenceFINSEQ-1M3-of D9 holds  for q9 be FinSequenceFINSEQ-1M3-of D9 holds F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> q9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,q9)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D9 assume [ty]: "D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E)"
    fix p9 assume [ty]: "p9 be FinSequenceFINSEQ-1M3-of D9"
    fix q9 assume [ty]: "q9 be FinSequenceFINSEQ-1M3-of D9"
    let ?P = "\<lambda>Lamb1. F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> Lamb1) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,Lamb1)"
    have A1: " for q9 be FinSequenceFINSEQ-1M3-of D9 holds  for d9 be ElementSUBSET-1M1-of D9 holds ?P(q9) implies ?P(q9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>))"
    proof-
      have " for q9 be FinSequenceFINSEQ-1M3-of D9 holds  for d9 be ElementSUBSET-1M1-of D9 holds F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> q9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,q9) implies F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (q9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>))) =HIDDENR1 F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,q9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>))"
      proof(rule ballI,rule ballI,rule impI)
        fix q9 assume [ty]: "q9 be FinSequenceFINSEQ-1M3-of D9"
        fix d9 assume [ty]: "d9 be ElementSUBSET-1M1-of D9"
        assume A2: "F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> q9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,q9)"
        have "F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (q9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>))) =HIDDENR1 F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,(p9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> q9)^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>))"
          using finseq_1_th_32 sorry
        also have "... = F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> q9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)"
          using finseqop_th_12 sorry
        also have "... = F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,q9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>))"
          using A2 finseq_1_th_32 sorry
        also have "... = F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,q9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>))"
          using finseqop_th_12 sorry
        finally show "F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (q9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>))) =HIDDENR1 F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,q9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> (<*FINSEQ-1K13\<^bsub>(D9)\<^esub> d9*>))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> <*>FINSEQ-1K7 D9) =HIDDENR1 F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9)"
      using finseq_1_th_34 sorry
    also have "... = F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> <*>FINSEQ-1K7 E"
      using finseq_1_th_34 sorry
    also have "... = F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,<*>FINSEQ-1K7 D9)"
      using finseq_2_th_79 sorry
    finally have "F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> <*>FINSEQ-1K7 D9) =HIDDENR1 F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,<*>FINSEQ-1K7 D9)"
       sorry
    then have A3: "?P(<*>FINSEQ-1K7 D9)"
       sorry
    have " for q9 be FinSequenceFINSEQ-1M3-of D9 holds ?P(q9)"
      using finseq_2_sch_2 A3 A1 sorry
    thus "F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9 ^FINSEQ-1K9\<^bsub>(D9)\<^esub> q9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,p9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,q9)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_14:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for d9 be ElementSUBSET-1M1-of D9 holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds  for p be FinSequenceFINSEQ-1M3-of D holds F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>),d9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p,d9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for d9 be ElementSUBSET-1M1-of D9 holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds  for p be FinSequenceFINSEQ-1M3-of D holds F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>),d9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p,d9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D9 assume [ty]: "D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix d9 assume [ty]: "d9 be ElementSUBSET-1M1-of D9"
    fix F assume [ty]: "F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E)"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of D"
    let ?pd = "p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)"
    let ?q = "F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p,d9)"
    let ?r = "F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(?pd,d9)"
    let ?s = "?q ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)"
    let ?i = "lenFINSEQ-1K4 p"
    have A1: "lenFINSEQ-1K4 ?q =XBOOLE-0R4 ?i"
      using finseq_2_th_84 sorry
    have "lenFINSEQ-1K4 ?pd =XBOOLE-0R4 ?i +NAT-1K1 \<one>\<^sub>M"
      using finseq_2_th_16 sorry
    then have A2: "lenFINSEQ-1K4 ?r =XBOOLE-0R4 ?i +NAT-1K1 \<one>\<^sub>M"
      using finseq_2_th_84 sorry
    then have A3: "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ?r =XBOOLE-0R4 SegFINSEQ-1K2 (?i +NAT-1K1 \<one>\<^sub>M)"
      using finseq_1_def_3 sorry
    have A4: " for j be NatNAT-1M1 holds j inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> (F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>),d9)) implies (F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>),d9)).FUNCT-1K1 j =XBOOLE-0R4 (F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p,d9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)).FUNCT-1K1 j"
    proof(rule ballI,rule impI)
      fix j assume [ty]: "j be NatNAT-1M1"
      assume A5: "j inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ?r"
      have "F .BINOP-1K1((p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)).FUNCT-1K1 j,d9) =HIDDENR1 (F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p,d9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)).FUNCT-1K1 j"
      proof-
        show "F .BINOP-1K1((p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)).FUNCT-1K1 j,d9) =HIDDENR1 (F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p,d9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)).FUNCT-1K1 j"
        proof-
          have cases: "j inTARSKIR2 SegFINSEQ-1K2 ?i or j =XBOOLE-0R4 ?i +NAT-1K1 \<one>\<^sub>M"
            using A3 A5 finseq_2_th_7 sorry
          have case1: "j inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p) implies F .BINOP-1K1((p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)).FUNCT-1K1 j,d9) =HIDDENR1 (F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p,d9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)).FUNCT-1K1 j"
          proof(rule impI)
            assume A6: "j inTARSKIR2 SegFINSEQ-1K2 ?i"
            then have A7: "j inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ?q"
              using A1 finseq_1_def_3 sorry
            have "SegFINSEQ-1K2 (lenFINSEQ-1K4 p) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> p"
              using finseq_1_def_3 sorry
            then have "F .BINOP-1K1((p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)).FUNCT-1K1 j,d9) =HIDDENR1 F .BINOP-1K1(p .FUNCT-1K1 j,d9)"
              using A6 finseq_1_def_7 sorry
            also have "... = (F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p,d9)).FUNCT-1K1 j"
              using A7 funcop_1_th_27 sorry
            also have "... = (F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p,d9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)).FUNCT-1K1 j"
              using A7 finseq_1_def_7 sorry
            finally show "F .BINOP-1K1((p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)).FUNCT-1K1 j,d9) =HIDDENR1 (F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p,d9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)).FUNCT-1K1 j"
               sorry
          qed
          have case2: "j =XBOOLE-0R4 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M implies F .BINOP-1K1((p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)).FUNCT-1K1 j,d9) =HIDDENR1 (F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p,d9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)).FUNCT-1K1 j"
          proof(rule impI)
            assume A8: "j =XBOOLE-0R4 ?i +NAT-1K1 \<one>\<^sub>M"
            then have "F .BINOP-1K1((p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)).FUNCT-1K1 j,d9) =HIDDENR1 F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)"
              using finseq_1_th_42 sorry
            also have "... = (F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p,d9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)).FUNCT-1K1 j"
              using A1 A8 finseq_1_th_42 sorry
            finally show "F .BINOP-1K1((p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)).FUNCT-1K1 j,d9) =HIDDENR1 (F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p,d9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)).FUNCT-1K1 j"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "(F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>),d9)).FUNCT-1K1 j =XBOOLE-0R4 (F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p,d9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)).FUNCT-1K1 j"
        using A5 funcop_1_th_27 sorry
    qed "sorry"
    have "lenFINSEQ-1K4 ?s =XBOOLE-0R4 lenFINSEQ-1K4 ?q +NAT-1K1 \<one>\<^sub>M"
      using finseq_2_th_16 sorry
    thus "F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>),d9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p,d9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)"
      using A1 A2 A4 finseq_2_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_15:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d9 be ElementSUBSET-1M1-of D9 holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds  for p be FinSequenceFINSEQ-1M3-of D holds  for q be FinSequenceFINSEQ-1M3-of D holds F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q,d9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p,d9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(q,d9)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d9 be ElementSUBSET-1M1-of D9 holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds  for p be FinSequenceFINSEQ-1M3-of D holds  for q be FinSequenceFINSEQ-1M3-of D holds F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q,d9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p,d9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(q,d9)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D9 assume [ty]: "D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d9 assume [ty]: "d9 be ElementSUBSET-1M1-of D9"
    fix F assume [ty]: "F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E)"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of D"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of D"
    let ?P = "\<lambda>Lamb1. F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p ^FINSEQ-1K9\<^bsub>(D)\<^esub> Lamb1,d9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p,d9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(Lamb1,d9)"
    have A1: " for q be FinSequenceFINSEQ-1M3-of D holds  for d be ElementSUBSET-1M1-of D holds ?P(q) implies ?P(q ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>))"
    proof-
      have " for q be FinSequenceFINSEQ-1M3-of D holds  for d be ElementSUBSET-1M1-of D holds F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q,d9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p,d9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(q,d9) implies F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (q ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)),d9) =HIDDENR1 F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p,d9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(q ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>),d9)"
      proof(rule ballI,rule ballI,rule impI)
        fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of D"
        fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
        assume A2: "F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q,d9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p,d9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(q,d9)"
        have "F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (q ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)),d9) =HIDDENR1 F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>((p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q)^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>),d9)"
          using finseq_1_th_32 sorry
        also have "... = F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q,d9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>)"
          using finseqop_th_14 sorry
        also have "... = F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p,d9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(q,d9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)*>))"
          using A2 finseq_1_th_32 sorry
        also have "... = F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p,d9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(q ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>),d9)"
          using finseqop_th_14 sorry
        finally show "F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (q ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)),d9) =HIDDENR1 F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p,d9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(q ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>),d9)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p ^FINSEQ-1K9\<^bsub>(D)\<^esub> <*>FINSEQ-1K7 D,d9) =HIDDENR1 F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p,d9)"
      using finseq_1_th_34 sorry
    also have "... = F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p,d9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> <*>FINSEQ-1K7 E"
      using finseq_1_th_34 sorry
    also have "... = F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p,d9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(<*>FINSEQ-1K7 D,d9)"
      using finseq_2_th_85 sorry
    finally have "F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p ^FINSEQ-1K9\<^bsub>(D)\<^esub> <*>FINSEQ-1K7 D,d9) =HIDDENR1 F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p,d9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(<*>FINSEQ-1K7 D,d9)"
       sorry
    then have A3: "?P(<*>FINSEQ-1K7 D)"
       sorry
    have " for q be FinSequenceFINSEQ-1M3-of D holds ?P(q)"
      using finseq_2_sch_2 A3 A1 sorry
    thus "F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q,d9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(p,d9) ^FINSEQ-1K9\<^bsub>(E)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(q,d9)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_16:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for h be FunctionFUNCT-2M1-of(D,E) holds h *FINSEQOPK4\<^bsub>(D,E)\<^esub> (i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> i  |->FINSEQ-2K5\<^bsub>(E)\<^esub> h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for h be FunctionFUNCT-2M1-of(D,E) holds h *FINSEQOPK4\<^bsub>(D,E)\<^esub> (i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> i  |->FINSEQ-2K5\<^bsub>(E)\<^esub> h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix h assume [ty]: "h be FunctionFUNCT-2M1-of(D,E)"
    have "d inTARSKIR2 D"
       sorry
    then have "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> h"
      using funct_2_def_1 sorry
    thus "h *FINSEQOPK4\<^bsub>(D,E)\<^esub> (i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> i  |->FINSEQ-2K5\<^bsub>(E)\<^esub> h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d"
      using funcop_1_th_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_17:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for d9 be ElementSUBSET-1M1-of D9 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d,i  |->FINSEQ-2K5\<^bsub>(D9)\<^esub> d9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> i  |->FINSEQ-2K5\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for d9 be ElementSUBSET-1M1-of D9 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d,i  |->FINSEQ-2K5\<^bsub>(D9)\<^esub> d9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> i  |->FINSEQ-2K5\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D9 assume [ty]: "D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix d9 assume [ty]: "d9 be ElementSUBSET-1M1-of D9"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix F assume [ty]: "F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E)"
    have "[TARSKIK4 d,d9 ] inHIDDENR3 [:ZFMISC-1K2 D,D9 :]"
      using zfmisc_1_def_2 sorry
    then have "[TARSKIK4 d,d9 ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 D,D9 :])\<^esub> F"
      using funct_2_def_1 sorry
    thus "F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d,i  |->FINSEQ-2K5\<^bsub>(D9)\<^esub> d9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> i  |->FINSEQ-2K5\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)"
      using finseqop_th_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_18:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for d9 be ElementSUBSET-1M1-of D9 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,i  |->FINSEQ-2K5\<^bsub>(D9)\<^esub> d9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> i  |->FINSEQ-2K5\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for d9 be ElementSUBSET-1M1-of D9 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,i  |->FINSEQ-2K5\<^bsub>(D9)\<^esub> d9) =HIDDENR1 i  |->FINSEQ-2K5\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D9 assume [ty]: "D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix d9 assume [ty]: "d9 be ElementSUBSET-1M1-of D9"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix F assume [ty]: "F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E)"
    have "F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,i  |->FINSEQ-2K5\<^bsub>(D9)\<^esub> d9) =HIDDENR1 F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d,i  |->FINSEQ-2K5\<^bsub>(D9)\<^esub> d9)"
      using funcop_1_th_13 sorry
    also have "... = i  |->FINSEQ-2K5\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)"
      using finseqop_th_17 sorry
    finally show "F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,i  |->FINSEQ-2K5\<^bsub>(D9)\<^esub> d9) =HIDDENR1 i  |->FINSEQ-2K5\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_19:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for d9 be ElementSUBSET-1M1-of D9 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d,d9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> i  |->FINSEQ-2K5\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for d9 be ElementSUBSET-1M1-of D9 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d,d9) =HIDDENR1 i  |->FINSEQ-2K5\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D9 assume [ty]: "D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix d9 assume [ty]: "d9 be ElementSUBSET-1M1-of D9"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix F assume [ty]: "F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E)"
    have "F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d,d9) =HIDDENR1 F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d,i  |->FINSEQ-2K5\<^bsub>(D9)\<^esub> d9)"
      using funcop_1_th_13 sorry
    also have "... = i  |->FINSEQ-2K5\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)"
      using finseqop_th_17 sorry
    finally show "F [:]FINSEQOPK2\<^bsub>(D,D9,E)\<^esub>(i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d,d9) =HIDDENR1 i  |->FINSEQ-2K5\<^bsub>(E)\<^esub> F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(d,d9)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_20:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds  for T9 be TupleFINSEQ-2M3-of(i,D9) holds F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d,T9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,T9)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds  for T9 be TupleFINSEQ-2M3-of(i,D9) holds F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d,T9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,T9)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D9 assume [ty]: "D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix F assume [ty]: "F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E)"
    fix T9 assume [ty]: "T9 be TupleFINSEQ-2M3-of(i,D9)"
    have "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> T9 =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 T9)"
      using finseq_1_def_3 sorry
    also have "... = SegFINSEQ-1K1 i"
      using card_1_def_7 sorry
    finally have "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> T9 =HIDDENR1 SegFINSEQ-1K1 i"
       sorry
    thus "F .:FINSEQOPK1\<^bsub>(D,D9,E)\<^esub>(i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d,T9) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,T9)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_21:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds  for T be TupleFINSEQ-2M3-of(i,D) holds F .:FUNCOP-1K3(T,i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d) =FUNCT-1R1 F [:]FUNCOP-1K4(T,d)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds  for T be TupleFINSEQ-2M3-of(i,D) holds F .:FUNCOP-1K3(T,i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d) =FUNCT-1R1 F [:]FUNCOP-1K4(T,d)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D9 assume [ty]: "D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix F assume [ty]: "F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E)"
    fix T assume [ty]: "T be TupleFINSEQ-2M3-of(i,D)"
    have "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> T =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 T)"
      using finseq_1_def_3 sorry
    also have "... = SegFINSEQ-1K1 i"
      using card_1_def_7 sorry
    finally have "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> T =HIDDENR1 SegFINSEQ-1K1 i"
       sorry
    thus "F .:FUNCOP-1K3(T,i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d) =FUNCT-1R1 F [:]FUNCOP-1K4(T,d)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_22:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds  for T9 be TupleFINSEQ-2M3-of(i,D9) holds F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,T9) =FUNCT-1R1 F [;]FUNCOP-1K5(d,idPARTFUN1K6 D9) *FUNCT-1K3 T9"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds  for T9 be TupleFINSEQ-2M3-of(i,D9) holds F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,T9) =HIDDENR1 F [;]FUNCOP-1K5(d,idPARTFUN1K6 D9) *FUNCT-1K3 T9"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D9 assume [ty]: "D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix F assume [ty]: "F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E)"
    fix T9 assume [ty]: "T9 be TupleFINSEQ-2M3-of(i,D9)"
    have "rngRELSET-1K2\<^bsub>(D9)\<^esub> T9 c=TARSKIR1 D9"
       sorry
    then have "F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,T9) =HIDDENR1 F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,idPARTFUN1K6 D9 *FINSEQOPK4\<^bsub>(D9,D9)\<^esub> T9)"
      using relat_1_th_53 sorry
    also have "... = F [;]FUNCOP-1K5(d,idPARTFUN1K6 D9) *FUNCT-1K3 T9"
      using funcop_1_th_34 sorry
    finally show "F [;]FINSEQOPK3\<^bsub>(D,D9,E)\<^esub>(d,T9) =HIDDENR1 F [;]FUNCOP-1K5(d,idPARTFUN1K6 D9) *FUNCT-1K3 T9"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_23:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds  for T be TupleFINSEQ-2M3-of(i,D) holds F [:]FUNCOP-1K4(T,d) =FUNCT-1R1 F [:]FUNCOP-1K4(idPARTFUN1K6 D,d) *FUNCT-1K3 T"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds  for T be TupleFINSEQ-2M3-of(i,D) holds F [:]FUNCOP-1K4(T,d) =HIDDENR1 F [:]FUNCOP-1K4(idPARTFUN1K6 D,d) *FUNCT-1K3 T"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D9 assume [ty]: "D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix F assume [ty]: "F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E)"
    fix T assume [ty]: "T be TupleFINSEQ-2M3-of(i,D)"
    have "rngRELSET-1K2\<^bsub>(D)\<^esub> T c=TARSKIR1 D"
       sorry
    then have "F [:]FUNCOP-1K4(T,d) =HIDDENR1 F [:]FUNCOP-1K4(idPARTFUN1K6 D *FINSEQOPK4\<^bsub>(D,D)\<^esub> T,d)"
      using relat_1_th_53 sorry
    also have "... = F [:]FUNCOP-1K4(idPARTFUN1K6 D,d) *FUNCT-1K3 T"
      using funcop_1_th_29 sorry
    finally show "F [:]FUNCOP-1K4(T,d) =HIDDENR1 F [:]FUNCOP-1K4(idPARTFUN1K6 D,d) *FUNCT-1K3 T"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve F, G for "BinOpBINOP-1M2-of D"
reserve u for "UnOpBINOP-1M1-of D"
reserve H for "BinOpBINOP-1M2-of E"
mlemma finseqop_lm_4:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T be TupleFINSEQ-2M3-of(i,D) holds T be FunctionFUNCT-2M1-of(SegFINSEQ-1K1 i,D)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T be TupleFINSEQ-2M3-of(i,D) holds T be FunctionFUNCT-2M1-of(SegFINSEQ-1K1 i,D)"
  proof(rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix T assume [ty]: "T be TupleFINSEQ-2M3-of(i,D)"
    have "lenFINSEQ-1K4 T =HIDDENR1 i"
      using card_1_def_7 sorry
    then have "SegFINSEQ-1K1 i =XBOOLE-0R4 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> T"
      using finseq_1_def_3 sorry
    thus "T be FunctionFUNCT-2M1-of(SegFINSEQ-1K1 i,D)"
      using finseq_2_th_26 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_24:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for f9 be FunctionFUNCT-2M1-of(C,D) holds  for F be BinOpBINOP-1M2-of D holds F be associativeBINOP-1V2\<^bsub>(D)\<^esub> implies F [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9) =FUNCT-2R2\<^bsub>(C,D)\<^esub> F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f,f9)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for f9 be FunctionFUNCT-2M1-of(C,D) holds  for F be BinOpBINOP-1M2-of D holds F be associativeBINOP-1V2\<^bsub>(D)\<^esub> implies F [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9) =FUNCT-2R2\<^bsub>(C,D)\<^esub> F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f,f9)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
    fix f9 assume [ty]: "f9 be FunctionFUNCT-2M1-of(C,D)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    assume A1: "F be associativeBINOP-1V2\<^bsub>(D)\<^esub>"
    have " for c be ElementSUBSET-1M1-of C holds (F [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 (F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f,f9)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
    proof(rule ballI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      have "(F [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 (F [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D)).FUNCT-2K3\<^bsub>(D,D)\<^esub> ((F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
        using funct_2_th_15 sorry
      also have "... = (F [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D)).FUNCT-2K3\<^bsub>(D,D)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c,f9 .FUNCT-2K3\<^bsub>(C,D)\<^esub> c))"
        using funcop_1_th_37 sorry
      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(d,idPARTFUN1K6 D .FUNCT-2K3\<^bsub>(D,D)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c,f9 .FUNCT-2K3\<^bsub>(C,D)\<^esub> c)))"
        using funcop_1_th_53 sorry
      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(d,F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c,f9 .FUNCT-2K3\<^bsub>(C,D)\<^esub> c))"
         sorry
      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d,f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c),f9 .FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
        using A1 sorry
      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>((F [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d,f)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c,f9 .FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
        using funcop_1_th_53 sorry
      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>((F [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f).FUNCT-2K3\<^bsub>(C,D)\<^esub> c,f9 .FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
        using funcop_1_th_55 sorry
      also have "... = (F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f,f9)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
        using funcop_1_th_37 sorry
      finally show "(F [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 (F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f,f9)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
         sorry
    qed "sorry"
    thus "F [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9) =FUNCT-2R2\<^bsub>(C,D)\<^esub> F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f,f9)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_25:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for f9 be FunctionFUNCT-2M1-of(C,D) holds  for F be BinOpBINOP-1M2-of D holds F be associativeBINOP-1V2\<^bsub>(D)\<^esub> implies F [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d) *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9) =FUNCT-2R2\<^bsub>(C,D)\<^esub> F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,F [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d) *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f9)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for f9 be FunctionFUNCT-2M1-of(C,D) holds  for F be BinOpBINOP-1M2-of D holds F be associativeBINOP-1V2\<^bsub>(D)\<^esub> implies F [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d) *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9) =FUNCT-2R2\<^bsub>(C,D)\<^esub> F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,F [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d) *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f9)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
    fix f9 assume [ty]: "f9 be FunctionFUNCT-2M1-of(C,D)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    assume A1: "F be associativeBINOP-1V2\<^bsub>(D)\<^esub>"
    have " for c be ElementSUBSET-1M1-of C holds (F [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d) *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 (F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,F [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d) *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f9)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
    proof(rule ballI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      have "(F [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d) *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 (F [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d)).FUNCT-2K3\<^bsub>(D,D)\<^esub> ((F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
        using funct_2_th_15 sorry
      also have "... = (F [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d)).FUNCT-2K3\<^bsub>(D,D)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c,f9 .FUNCT-2K3\<^bsub>(C,D)\<^esub> c))"
        using funcop_1_th_37 sorry
      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(idPARTFUN1K6 D .FUNCT-2K3\<^bsub>(D,D)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c,f9 .FUNCT-2K3\<^bsub>(C,D)\<^esub> c)),d)"
        using funcop_1_th_48 sorry
      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c,f9 .FUNCT-2K3\<^bsub>(C,D)\<^esub> c),d)"
         sorry
      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c,F .BINOP-1K4\<^bsub>(D)\<^esub>(f9 .FUNCT-2K3\<^bsub>(C,D)\<^esub> c,d))"
        using A1 sorry
      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c,(F [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f9,d)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
        using funcop_1_th_48 sorry
      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c,(F [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d) *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f9).FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
        using funcop_1_th_50 sorry
      also have "... = (F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,F [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d) *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f9)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
        using funcop_1_th_37 sorry
      finally show "(F [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d) *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 (F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,F [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d) *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f9)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
         sorry
    qed "sorry"
    thus "F [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d) *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9) =FUNCT-2R2\<^bsub>(C,D)\<^esub> F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,F [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d) *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f9)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_26:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T1 be TupleFINSEQ-2M3-of(i,D) holds  for T2 be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds F be associativeBINOP-1V2\<^bsub>(D)\<^esub> implies F [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *FINSEQOPK4\<^bsub>(D,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *FINSEQOPK4\<^bsub>(D,D)\<^esub> T1,T2)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T1 be TupleFINSEQ-2M3-of(i,D) holds  for T2 be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds F be associativeBINOP-1V2\<^bsub>(D)\<^esub> implies F [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *FINSEQOPK4\<^bsub>(D,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *FINSEQOPK4\<^bsub>(D,D)\<^esub> T1,T2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix T1 assume [ty]: "T1 be TupleFINSEQ-2M3-of(i,D)"
    fix T2 assume [ty]: "T2 be TupleFINSEQ-2M3-of(i,D)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    assume A1: "F be associativeBINOP-1V2\<^bsub>(D)\<^esub>"
    show "F [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *FINSEQOPK4\<^bsub>(D,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *FINSEQOPK4\<^bsub>(D,D)\<^esub> T1,T2)"
    proof-
      have cases: "i =HIDDENR1 0NUMBERSK6 or i <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "i =HIDDENR1 0NUMBERSK6 implies F [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *FINSEQOPK4\<^bsub>(D,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *FINSEQOPK4\<^bsub>(D,D)\<^esub> T1,T2)"
      proof(rule impI)
        assume A2: "i =HIDDENR1 0NUMBERSK6"
        then have "F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D"
          using finseqop_lm_1 sorry
        then have A3: "F [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *FINSEQOPK4\<^bsub>(D,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D"
           sorry
        have "T2 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D"
          using A2 sorry
        thus "F [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *FINSEQOPK4\<^bsub>(D,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *FINSEQOPK4\<^bsub>(D,D)\<^esub> T1,T2)"
          using A3 finseq_2_th_73 sorry
      qed
      have case2: "i <>HIDDENR2 0NUMBERSK6 implies F [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *FINSEQOPK4\<^bsub>(D,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *FINSEQOPK4\<^bsub>(D,D)\<^esub> T1,T2)"
      proof(rule impI)
        assume "i <>HIDDENR2 0NUMBERSK6"
        then obtain C where 
          [ty]:"C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and CDef:"C = SegFINSEQ-1K1 i"
           sorry
        have "T1 be FunctionFUNCT-2M1-of(C,D) & T2 be FunctionFUNCT-2M1-of(C,D)"
          using finseqop_lm_4 sorry
        thus "F [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *FINSEQOPK4\<^bsub>(D,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *FINSEQOPK4\<^bsub>(D,D)\<^esub> T1,T2)"
          using A1 finseqop_th_24 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_27:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T1 be TupleFINSEQ-2M3-of(i,D) holds  for T2 be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds F be associativeBINOP-1V2\<^bsub>(D)\<^esub> implies F [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d) *FINSEQOPK4\<^bsub>(D,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,F [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d) *FINSEQOPK4\<^bsub>(D,D)\<^esub> T2)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T1 be TupleFINSEQ-2M3-of(i,D) holds  for T2 be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds F be associativeBINOP-1V2\<^bsub>(D)\<^esub> implies F [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d) *FINSEQOPK4\<^bsub>(D,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,F [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d) *FINSEQOPK4\<^bsub>(D,D)\<^esub> T2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix T1 assume [ty]: "T1 be TupleFINSEQ-2M3-of(i,D)"
    fix T2 assume [ty]: "T2 be TupleFINSEQ-2M3-of(i,D)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    assume A1: "F be associativeBINOP-1V2\<^bsub>(D)\<^esub>"
    show "F [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d) *FINSEQOPK4\<^bsub>(D,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,F [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d) *FINSEQOPK4\<^bsub>(D,D)\<^esub> T2)"
    proof-
      have cases: "i =HIDDENR1 0NUMBERSK6 or i <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "i =HIDDENR1 0NUMBERSK6 implies F [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d) *FINSEQOPK4\<^bsub>(D,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,F [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d) *FINSEQOPK4\<^bsub>(D,D)\<^esub> T2)"
      proof(rule impI)
        assume A2: "i =HIDDENR1 0NUMBERSK6"
        then have "F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D"
          using finseqop_lm_1 sorry
        then have A3: "F [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d) *FINSEQOPK4\<^bsub>(D,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D"
           sorry
        have "T1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D"
          using A2 sorry
        thus "F [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d) *FINSEQOPK4\<^bsub>(D,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,F [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d) *FINSEQOPK4\<^bsub>(D,D)\<^esub> T2)"
          using A3 finseq_2_th_73 sorry
      qed
      have case2: "i <>HIDDENR2 0NUMBERSK6 implies F [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d) *FINSEQOPK4\<^bsub>(D,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,F [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d) *FINSEQOPK4\<^bsub>(D,D)\<^esub> T2)"
      proof(rule impI)
        assume "i <>HIDDENR2 0NUMBERSK6"
        then obtain C where 
          [ty]:"C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and CDef:"C = SegFINSEQ-1K1 i"
           sorry
        have "T1 be FunctionFUNCT-2M1-of(C,D) & T2 be FunctionFUNCT-2M1-of(C,D)"
          using finseqop_lm_4 sorry
        thus "F [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d) *FINSEQOPK4\<^bsub>(D,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,F [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d) *FINSEQOPK4\<^bsub>(D,D)\<^esub> T2)"
          using A1 finseqop_th_25 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_28:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T1 be TupleFINSEQ-2M3-of(i,D) holds  for T2 be TupleFINSEQ-2M3-of(i,D) holds  for T3 be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds F be associativeBINOP-1V2\<^bsub>(D)\<^esub> implies F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2),T3) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T2,T3))"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T1 be TupleFINSEQ-2M3-of(i,D) holds  for T2 be TupleFINSEQ-2M3-of(i,D) holds  for T3 be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds F be associativeBINOP-1V2\<^bsub>(D)\<^esub> implies F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2),T3) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T2,T3))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix T1 assume [ty]: "T1 be TupleFINSEQ-2M3-of(i,D)"
    fix T2 assume [ty]: "T2 be TupleFINSEQ-2M3-of(i,D)"
    fix T3 assume [ty]: "T3 be TupleFINSEQ-2M3-of(i,D)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    assume A1: "F be associativeBINOP-1V2\<^bsub>(D)\<^esub>"
    show "F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2),T3) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T2,T3))"
    proof-
      have cases: "i =HIDDENR1 0NUMBERSK6 or i <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "i =HIDDENR1 0NUMBERSK6 implies F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2),T3) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T2,T3))"
      proof(rule impI)
        assume A2: "i =HIDDENR1 0NUMBERSK6"
        then have "F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D"
          using finseqop_lm_1 sorry
        then have A3: "F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2),T3) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D"
          using finseq_2_th_73 sorry
        have "F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T2,T3) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D"
          using A2 finseqop_lm_1 sorry
        thus "F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2),T3) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T2,T3))"
          using A3 finseq_2_th_73 sorry
      qed
      have case2: "i <>HIDDENR2 0NUMBERSK6 implies F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2),T3) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T2,T3))"
      proof(rule impI)
        assume "i <>HIDDENR2 0NUMBERSK6"
        then obtain C where 
          [ty]:"C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and CDef:"C = SegFINSEQ-1K1 i"
           sorry
        have A4: "T3 be FunctionFUNCT-2M1-of(C,D)"
          using finseqop_lm_4 sorry
        have "T1 be FunctionFUNCT-2M1-of(C,D) & T2 be FunctionFUNCT-2M1-of(C,D)"
          using finseqop_lm_4 sorry
        thus "F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2),T3) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T2,T3))"
          using A1 A4 funcop_1_th_61 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_29:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds F be associativeBINOP-1V2\<^bsub>(D)\<^esub> implies F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d1,T),d2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d1,F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d2))"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds F be associativeBINOP-1V2\<^bsub>(D)\<^esub> implies F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d1,T),d2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d1,F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d2))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of D"
    fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of D"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix T assume [ty]: "T be TupleFINSEQ-2M3-of(i,D)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    assume A1: "F be associativeBINOP-1V2\<^bsub>(D)\<^esub>"
    show "F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d1,T),d2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d1,F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d2))"
    proof-
      have cases: "i =HIDDENR1 0NUMBERSK6 or i <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "i =HIDDENR1 0NUMBERSK6 implies F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d1,T),d2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d1,F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d2))"
      proof(rule impI)
        assume A2: "i =HIDDENR1 0NUMBERSK6"
        then have "F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d1,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D"
          using finseqop_lm_2 sorry
        then have A3: "F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d1,T),d2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D"
          using finseq_2_th_85 sorry
        have "F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D"
          using A2 finseqop_lm_3 sorry
        thus "F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d1,T),d2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d1,F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d2))"
          using A3 finseq_2_th_79 sorry
      qed
      have case2: "i <>HIDDENR2 0NUMBERSK6 implies F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d1,T),d2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d1,F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d2))"
      proof(rule impI)
        assume "i <>HIDDENR2 0NUMBERSK6"
        then obtain C where 
          [ty]:"C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and CDef:"C = SegFINSEQ-1K1 i"
           sorry
        have "T be FunctionFUNCT-2M1-of(C,D)"
          using finseqop_lm_4 sorry
        thus "F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d1,T),d2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d1,F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d2))"
          using A1 funcop_1_th_59 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_30:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T1 be TupleFINSEQ-2M3-of(i,D) holds  for T2 be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds F be associativeBINOP-1V2\<^bsub>(D)\<^esub> implies F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T1,d),T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,T2))"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T1 be TupleFINSEQ-2M3-of(i,D) holds  for T2 be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds F be associativeBINOP-1V2\<^bsub>(D)\<^esub> implies F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T1,d),T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,T2))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix T1 assume [ty]: "T1 be TupleFINSEQ-2M3-of(i,D)"
    fix T2 assume [ty]: "T2 be TupleFINSEQ-2M3-of(i,D)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    assume A1: "F be associativeBINOP-1V2\<^bsub>(D)\<^esub>"
    show "F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T1,d),T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,T2))"
    proof-
      have cases: "i =HIDDENR1 0NUMBERSK6 or i <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "i =HIDDENR1 0NUMBERSK6 implies F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T1,d),T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,T2))"
      proof(rule impI)
        assume A2: "i =HIDDENR1 0NUMBERSK6"
        then have "F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T1,d) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D"
          using finseqop_lm_3 sorry
        then have A3: "F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T1,d),T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D"
          using finseq_2_th_73 sorry
        have "F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D"
          using A2 finseqop_lm_2 sorry
        thus "F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T1,d),T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,T2))"
          using A3 finseq_2_th_73 sorry
      qed
      have case2: "i <>HIDDENR2 0NUMBERSK6 implies F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T1,d),T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,T2))"
      proof(rule impI)
        assume "i <>HIDDENR2 0NUMBERSK6"
        then obtain C where 
          [ty]:"C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and CDef:"C = SegFINSEQ-1K1 i"
           sorry
        have "T1 be FunctionFUNCT-2M1-of(C,D) & T2 be FunctionFUNCT-2M1-of(C,D)"
          using finseqop_lm_4 sorry
        thus "F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T1,d),T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,T2))"
          using A1 funcop_1_th_60 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_31:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds F be associativeBINOP-1V2\<^bsub>(D)\<^esub> implies F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d1,F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d2,T))"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds F be associativeBINOP-1V2\<^bsub>(D)\<^esub> implies F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d1,F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d2,T))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of D"
    fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of D"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix T assume [ty]: "T be TupleFINSEQ-2M3-of(i,D)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    assume A1: "F be associativeBINOP-1V2\<^bsub>(D)\<^esub>"
    show "F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d1,F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d2,T))"
    proof-
      have cases: "i =HIDDENR1 0NUMBERSK6 or i <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "i =HIDDENR1 0NUMBERSK6 implies F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d1,F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d2,T))"
      proof(rule impI)
        assume "i =HIDDENR1 0NUMBERSK6"
        then have "T =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D & F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d2,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D"
          using finseqop_lm_2 sorry
        thus "F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d1,F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d2,T))"
           sorry
      qed
      have case2: "i <>HIDDENR2 0NUMBERSK6 implies F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d1,F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d2,T))"
      proof(rule impI)
        assume "i <>HIDDENR2 0NUMBERSK6"
        then obtain C where 
          [ty]:"C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and CDef:"C = SegFINSEQ-1K1 i"
           sorry
        have "T be FunctionFUNCT-2M1-of(C,D)"
          using finseqop_lm_4 sorry
        thus "F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d1,F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d2,T))"
          using A1 funcop_1_th_62 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_32:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds F be associativeBINOP-1V2\<^bsub>(D)\<^esub> implies F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d1),d2)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds F be associativeBINOP-1V2\<^bsub>(D)\<^esub> implies F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d1),d2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of D"
    fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of D"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix T assume [ty]: "T be TupleFINSEQ-2M3-of(i,D)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    assume A1: "F be associativeBINOP-1V2\<^bsub>(D)\<^esub>"
    show "F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d1),d2)"
    proof-
      have cases: "i =HIDDENR1 0NUMBERSK6 or i <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "i =HIDDENR1 0NUMBERSK6 implies F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d1),d2)"
      proof(rule impI)
        assume "i =HIDDENR1 0NUMBERSK6"
        then have "T =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D & F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d1) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D"
          using finseqop_lm_3 sorry
        thus "F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d1),d2)"
           sorry
      qed
      have case2: "i <>HIDDENR2 0NUMBERSK6 implies F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d1),d2)"
      proof(rule impI)
        assume "i <>HIDDENR2 0NUMBERSK6"
        then obtain C where 
          [ty]:"C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and CDef:"C = SegFINSEQ-1K1 i"
           sorry
        have "T be FunctionFUNCT-2M1-of(C,D)"
          using finseqop_lm_4 sorry
        thus "F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d1),d2)"
          using A1 funcop_1_th_63 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_33:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T1 be TupleFINSEQ-2M3-of(i,D) holds  for T2 be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds F be commutativeBINOP-1V1\<^bsub>(D)\<^esub> implies F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T2,T1)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T1 be TupleFINSEQ-2M3-of(i,D) holds  for T2 be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds F be commutativeBINOP-1V1\<^bsub>(D)\<^esub> implies F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T2,T1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix T1 assume [ty]: "T1 be TupleFINSEQ-2M3-of(i,D)"
    fix T2 assume [ty]: "T2 be TupleFINSEQ-2M3-of(i,D)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    assume A1: "F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>"
    show "F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T2,T1)"
    proof-
      have cases: "i =HIDDENR1 0NUMBERSK6 or i <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "i =HIDDENR1 0NUMBERSK6 implies F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T2,T1)"
      proof(rule impI)
        assume A2: "i =HIDDENR1 0NUMBERSK6"
        then have "F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D"
          using finseqop_lm_1 sorry
        thus "F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T2,T1)"
          using A2 finseqop_lm_1 sorry
      qed
      have case2: "i <>HIDDENR2 0NUMBERSK6 implies F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T2,T1)"
      proof(rule impI)
        assume "i <>HIDDENR2 0NUMBERSK6"
        then obtain C where 
          [ty]:"C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and CDef:"C = SegFINSEQ-1K1 i"
           sorry
        have "T1 be FunctionFUNCT-2M1-of(C,D) & T2 be FunctionFUNCT-2M1-of(C,D)"
          using finseqop_lm_4 sorry
        thus "F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T2,T1)"
          using A1 funcop_1_th_65 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_34:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds F be commutativeBINOP-1V1\<^bsub>(D)\<^esub> implies F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds F be commutativeBINOP-1V1\<^bsub>(D)\<^esub> implies F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix T assume [ty]: "T be TupleFINSEQ-2M3-of(i,D)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    assume A1: "F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>"
    show "F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d)"
    proof-
      have cases: "i =HIDDENR1 0NUMBERSK6 or i <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "i =HIDDENR1 0NUMBERSK6 implies F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d)"
      proof(rule impI)
        assume A2: "i =HIDDENR1 0NUMBERSK6"
        then have "F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D"
          using finseqop_lm_2 sorry
        thus "F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d)"
          using A2 finseqop_lm_3 sorry
      qed
      have case2: "i <>HIDDENR2 0NUMBERSK6 implies F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d)"
      proof(rule impI)
        assume "i <>HIDDENR2 0NUMBERSK6"
        then obtain C where 
          [ty]:"C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and CDef:"C = SegFINSEQ-1K1 i"
           sorry
        have "T be FunctionFUNCT-2M1-of(C,D)"
          using finseqop_lm_4 sorry
        thus "F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d)"
          using A1 funcop_1_th_64 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_35:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds F is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> G implies F [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),f) =FUNCT-2R2\<^bsub>(C,D)\<^esub> G .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d1,f),F [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d2,f))"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds F is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> G implies F [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),f) =FUNCT-2R2\<^bsub>(C,D)\<^esub> G .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d1,f),F [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d2,f))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of D"
    fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix G assume [ty]: "G be BinOpBINOP-1M2-of D"
    assume A1: "F is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> G"
    have " for c be ElementSUBSET-1M1-of C holds (F [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),f)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 (G .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d1,f),F [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d2,f))).FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
    proof(rule ballI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      have "(F [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),f)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
        using funcop_1_th_53 sorry
      also have "... = G .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c),F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c))"
        using A1 binop_1_th_11 sorry
      also have "... = G .BINOP-1K4\<^bsub>(D)\<^esub>((F [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d1,f)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c,F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c))"
        using funcop_1_th_53 sorry
      also have "... = G .BINOP-1K4\<^bsub>(D)\<^esub>((F [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d1,f)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c,(F [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d2,f)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
        using funcop_1_th_53 sorry
      also have "... = (G .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d1,f),F [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d2,f))).FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
        using funcop_1_th_37 sorry
      finally show "(F [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),f)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 (G .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d1,f),F [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d2,f))).FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
         sorry
    qed "sorry"
    thus "F [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),f) =FUNCT-2R2\<^bsub>(C,D)\<^esub> G .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d1,f),F [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d2,f))"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_36:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds F is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> G implies F [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =FUNCT-2R2\<^bsub>(C,D)\<^esub> G .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(F [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d1),F [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d2))"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds F is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> G implies F [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =FUNCT-2R2\<^bsub>(C,D)\<^esub> G .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(F [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d1),F [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d2))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of D"
    fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix G assume [ty]: "G be BinOpBINOP-1M2-of D"
    assume A1: "F is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> G"
    have " for c be ElementSUBSET-1M1-of C holds (F [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2))).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 (G .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(F [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d1),F [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d2))).FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
    proof(rule ballI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      have "(F [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2))).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c,G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2))"
        using funcop_1_th_48 sorry
      also have "... = G .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c,d1),F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c,d2))"
        using A1 binop_1_th_11 sorry
      also have "... = G .BINOP-1K4\<^bsub>(D)\<^esub>((F [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d1)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c,F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c,d2))"
        using funcop_1_th_48 sorry
      also have "... = G .BINOP-1K4\<^bsub>(D)\<^esub>((F [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d1)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c,(F [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d2)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
        using funcop_1_th_48 sorry
      also have "... = (G .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(F [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d1),F [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d2))).FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
        using funcop_1_th_37 sorry
      finally show "(F [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2))).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 (G .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(F [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d1),F [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d2))).FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
         sorry
    qed "sorry"
    thus "F [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =FUNCT-2R2\<^bsub>(C,D)\<^esub> G .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(F [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d1),F [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d2))"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_37:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for f9 be FunctionFUNCT-2M1-of(C,D) holds  for h be FunctionFUNCT-2M1-of(D,E) holds  for F be BinOpBINOP-1M2-of D holds  for H be BinOpBINOP-1M2-of E holds ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 H .BINOP-1K4\<^bsub>(E)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d1,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d2)) implies h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9) =FUNCT-2R2\<^bsub>(C,E)\<^esub> H .:FUNCOP-1K6\<^bsub>(E,C)\<^esub>(h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f,h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f9)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for f9 be FunctionFUNCT-2M1-of(C,D) holds  for h be FunctionFUNCT-2M1-of(D,E) holds  for F be BinOpBINOP-1M2-of D holds  for H be BinOpBINOP-1M2-of E holds ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 H .BINOP-1K4\<^bsub>(E)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d1,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d2)) implies h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9) =FUNCT-2R2\<^bsub>(C,E)\<^esub> H .:FUNCOP-1K6\<^bsub>(E,C)\<^esub>(h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f,h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f9)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
    fix f9 assume [ty]: "f9 be FunctionFUNCT-2M1-of(C,D)"
    fix h assume [ty]: "h be FunctionFUNCT-2M1-of(D,E)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix H assume [ty]: "H be BinOpBINOP-1M2-of E"
    assume A1: " for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 H .BINOP-1K4\<^bsub>(E)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d1,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d2)"
    have " for c be ElementSUBSET-1M1-of C holds (h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9)).FUNCT-2K3\<^bsub>(C,E)\<^esub> c =HIDDENR1 (H .:FUNCOP-1K6\<^bsub>(E,C)\<^esub>(h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f,h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f9)).FUNCT-2K3\<^bsub>(C,E)\<^esub> c"
    proof(rule ballI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      have "(h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9)).FUNCT-2K3\<^bsub>(C,E)\<^esub> c =HIDDENR1 h .FUNCT-2K3\<^bsub>(D,E)\<^esub> ((F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
        using funct_2_th_15 sorry
      also have "... = h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c,f9 .FUNCT-2K3\<^bsub>(C,D)\<^esub> c))"
        using funcop_1_th_37 sorry
      also have "... = H .BINOP-1K4\<^bsub>(E)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c),h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (f9 .FUNCT-2K3\<^bsub>(C,D)\<^esub> c))"
        using A1 sorry
      also have "... = H .BINOP-1K4\<^bsub>(E)\<^esub>((h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f).FUNCT-2K3\<^bsub>(C,E)\<^esub> c,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (f9 .FUNCT-2K3\<^bsub>(C,D)\<^esub> c))"
        using funct_2_th_15 sorry
      also have "... = H .BINOP-1K4\<^bsub>(E)\<^esub>((h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f).FUNCT-2K3\<^bsub>(C,E)\<^esub> c,(h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f9).FUNCT-2K3\<^bsub>(C,E)\<^esub> c)"
        using funct_2_th_15 sorry
      also have "... = (H .:FUNCOP-1K6\<^bsub>(E,C)\<^esub>(h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f,h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f9)).FUNCT-2K3\<^bsub>(C,E)\<^esub> c"
        using funcop_1_th_37 sorry
      finally show "(h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9)).FUNCT-2K3\<^bsub>(C,E)\<^esub> c =HIDDENR1 (H .:FUNCOP-1K6\<^bsub>(E,C)\<^esub>(h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f,h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f9)).FUNCT-2K3\<^bsub>(C,E)\<^esub> c"
         sorry
    qed "sorry"
    thus "h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9) =FUNCT-2R2\<^bsub>(C,E)\<^esub> H .:FUNCOP-1K6\<^bsub>(E,C)\<^esub>(h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f,h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f9)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_38:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for h be FunctionFUNCT-2M1-of(D,E) holds  for F be BinOpBINOP-1M2-of D holds  for H be BinOpBINOP-1M2-of E holds ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 H .BINOP-1K4\<^bsub>(E)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d1,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d2)) implies h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> F [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d,f) =FUNCT-2R2\<^bsub>(C,E)\<^esub> H [;]FUNCOP-1K10\<^bsub>(E,C)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d,h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for h be FunctionFUNCT-2M1-of(D,E) holds  for F be BinOpBINOP-1M2-of D holds  for H be BinOpBINOP-1M2-of E holds ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 H .BINOP-1K4\<^bsub>(E)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d1,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d2)) implies h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> F [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d,f) =HIDDENR1 H [;]FUNCOP-1K10\<^bsub>(E,C)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d,h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
    fix h assume [ty]: "h be FunctionFUNCT-2M1-of(D,E)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix H assume [ty]: "H be BinOpBINOP-1M2-of E"
    assume A1: " for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 H .BINOP-1K4\<^bsub>(E)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d1,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d2)"
    obtain g where 
      [ty]:"g be FunctionFUNCT-2M1-of(C,D)" and gDef:"g = C -->FUNCOP-1K8\<^bsub>(D)\<^esub> d"
       sorry
    have A2: "domRELSET-1K1\<^bsub>(D)\<^esub> h =XBOOLE-0R4 D & domRELSET-1K1\<^bsub>(C)\<^esub> (h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f) =XBOOLE-0R4 C"
      using funct_2_def_1 sorry
    have "h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> F [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d,f) =HIDDENR1 h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(g,f)"
      using funct_2_def_1 sorry
    also have "... = H .:FUNCOP-1K6\<^bsub>(E,C)\<^esub>(h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> g,h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f)"
      using A1 finseqop_th_37 sorry
    also have "... = H [;]FUNCOP-1K10\<^bsub>(E,C)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d,h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f)"
      using A2 funcop_1_th_17 sorry
    finally show "h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> F [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d,f) =HIDDENR1 H [;]FUNCOP-1K10\<^bsub>(E,C)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d,h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_39:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for h be FunctionFUNCT-2M1-of(D,E) holds  for F be BinOpBINOP-1M2-of D holds  for H be BinOpBINOP-1M2-of E holds ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 H .BINOP-1K4\<^bsub>(E)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d1,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d2)) implies h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> F [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d) =FUNCT-2R2\<^bsub>(C,E)\<^esub> H [:]FUNCOP-1K9\<^bsub>(E,C)\<^esub>(h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for h be FunctionFUNCT-2M1-of(D,E) holds  for F be BinOpBINOP-1M2-of D holds  for H be BinOpBINOP-1M2-of E holds ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 H .BINOP-1K4\<^bsub>(E)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d1,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d2)) implies h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> F [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d) =HIDDENR1 H [:]FUNCOP-1K9\<^bsub>(E,C)\<^esub>(h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
    fix h assume [ty]: "h be FunctionFUNCT-2M1-of(D,E)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix H assume [ty]: "H be BinOpBINOP-1M2-of E"
    assume A1: " for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 H .BINOP-1K4\<^bsub>(E)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d1,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d2)"
    obtain g where 
      [ty]:"g be FunctionFUNCT-2M1-of(C,D)" and gDef:"g = C -->FUNCOP-1K8\<^bsub>(D)\<^esub> d"
       sorry
    have A2: "domRELSET-1K1\<^bsub>(D)\<^esub> h =XBOOLE-0R4 D & domRELSET-1K1\<^bsub>(C)\<^esub> (h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f) =XBOOLE-0R4 C"
      using funct_2_def_1 sorry
    have "h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> F [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d) =HIDDENR1 h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,g)"
      using funct_2_def_1 sorry
    also have "... = H .:FUNCOP-1K6\<^bsub>(E,C)\<^esub>(h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f,h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> g)"
      using A1 finseqop_th_37 sorry
    also have "... = H [:]FUNCOP-1K9\<^bsub>(E,C)\<^esub>(h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d)"
      using A2 funcop_1_th_17 sorry
    finally show "h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> F [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d) =HIDDENR1 H [:]FUNCOP-1K9\<^bsub>(E,C)\<^esub>(h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_40:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for f9 be FunctionFUNCT-2M1-of(C,D) holds  for F be BinOpBINOP-1M2-of D holds  for u be UnOpBINOP-1M1-of D holds u is-distributive-wrtBINOP-1R12\<^bsub>(D)\<^esub> F implies u *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9) =FUNCT-2R2\<^bsub>(C,D)\<^esub> F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(u *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f,u *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f9)"
  using finseqop_th_37 sorry

mtheorem finseqop_th_41:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for F be BinOpBINOP-1M2-of D holds  for u be UnOpBINOP-1M1-of D holds u is-distributive-wrtBINOP-1R12\<^bsub>(D)\<^esub> F implies u *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> F [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d,f) =FUNCT-2R2\<^bsub>(C,D)\<^esub> F [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d,u *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f)"
  using finseqop_th_38 sorry

mtheorem finseqop_th_42:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for F be BinOpBINOP-1M2-of D holds  for u be UnOpBINOP-1M1-of D holds u is-distributive-wrtBINOP-1R12\<^bsub>(D)\<^esub> F implies u *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> F [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d) =FUNCT-2R2\<^bsub>(C,D)\<^esub> F [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(u *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f,u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d)"
  using finseqop_th_39 sorry

mtheorem finseqop_th_43:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for F be BinOpBINOP-1M2-of D holds F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(C -->FUNCOP-1K8\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,f) =FUNCT-2R2\<^bsub>(C,D)\<^esub> f & F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,C -->FUNCOP-1K8\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) =FUNCT-2R2\<^bsub>(C,D)\<^esub> f"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for F be BinOpBINOP-1M2-of D holds F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(C -->FUNCOP-1K8\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,f) =FUNCT-2R2\<^bsub>(C,D)\<^esub> f & F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,C -->FUNCOP-1K8\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) =FUNCT-2R2\<^bsub>(C,D)\<^esub> f"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    let ?e = "the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
    obtain g where 
      [ty]:"g be FunctionFUNCT-2M1-of(C,D)" and gDef:"g = C -->FUNCOP-1K8\<^bsub>(D)\<^esub> ?e"
       sorry
    assume A1: "F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
    have " for c be ElementSUBSET-1M1-of C holds (F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(g,f)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
    proof(rule ballI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      have "(F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(g,f)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(g .FUNCT-2K3\<^bsub>(C,D)\<^esub> c,f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
        using funcop_1_th_37 sorry
      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
        using funcop_1_th_7 sorry
      also have "... = f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
        using A1 setwiseo_th_15 sorry
      finally show "(F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(g,f)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
         sorry
    qed "sorry"
    thus "F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(C -->FUNCOP-1K8\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,f) =FUNCT-2R2\<^bsub>(C,D)\<^esub> f"
      using funct_2_th_63 sorry
    have " for c be ElementSUBSET-1M1-of C holds (F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,g)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
    proof(rule ballI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      have "(F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,g)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c,g .FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
        using funcop_1_th_37 sorry
      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c,the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F)"
        using funcop_1_th_7 sorry
      also have "... = f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
        using A1 setwiseo_th_15 sorry
      finally show "(F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,g)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
         sorry
    qed "sorry"
    thus "F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,C -->FUNCOP-1K8\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) =FUNCT-2R2\<^bsub>(C,D)\<^esub> f"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_44:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for F be BinOpBINOP-1M2-of D holds F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies F [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,f) =FUNCT-2R2\<^bsub>(C,D)\<^esub> f"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for F be BinOpBINOP-1M2-of D holds F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies F [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,f) =FUNCT-2R2\<^bsub>(C,D)\<^esub> f"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    let ?e = "the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
    assume A1: "F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
    have " for c be ElementSUBSET-1M1-of C holds (F [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,f)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
    proof(rule ballI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      have "(F [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,f)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
        using funcop_1_th_53 sorry
      also have "... = f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
        using A1 setwiseo_th_15 sorry
      finally show "(F [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,f)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
         sorry
    qed "sorry"
    thus "F [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,f) =FUNCT-2R2\<^bsub>(C,D)\<^esub> f"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_45:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for F be BinOpBINOP-1M2-of D holds F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies F [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) =FUNCT-2R2\<^bsub>(C,D)\<^esub> f"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for F be BinOpBINOP-1M2-of D holds F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies F [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) =FUNCT-2R2\<^bsub>(C,D)\<^esub> f"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    let ?e = "the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
    assume A1: "F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
    have " for c be ElementSUBSET-1M1-of C holds (F [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
    proof(rule ballI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      have "(F [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c,the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F)"
        using funcop_1_th_48 sorry
      also have "... = f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
        using A1 setwiseo_th_15 sorry
      finally show "(F [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
         sorry
    qed "sorry"
    thus "F [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) =FUNCT-2R2\<^bsub>(C,D)\<^esub> f"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_46:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds F is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> G implies F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> G .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d1,T),F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d2,T))"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds F is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> G implies F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> G .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d1,T),F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d2,T))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of D"
    fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of D"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix T assume [ty]: "T be TupleFINSEQ-2M3-of(i,D)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix G assume [ty]: "G be BinOpBINOP-1M2-of D"
    assume A1: "F is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> G"
    show "F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> G .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d1,T),F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d2,T))"
    proof-
      have cases: "i =HIDDENR1 0NUMBERSK6 or i <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "i =HIDDENR1 0NUMBERSK6 implies F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> G .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d1,T),F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d2,T))"
      proof(rule impI)
        assume "i =HIDDENR1 0NUMBERSK6"
        then have "F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d1,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D & F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D"
          using finseqop_lm_2 sorry
        thus "F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> G .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d1,T),F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d2,T))"
          using finseq_2_th_73 sorry
      qed
      have case2: "i <>HIDDENR2 0NUMBERSK6 implies F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> G .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d1,T),F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d2,T))"
      proof(rule impI)
        assume "i <>HIDDENR2 0NUMBERSK6"
        then obtain C where 
          [ty]:"C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and CDef:"C = SegFINSEQ-1K1 i"
           sorry
        have "T be FunctionFUNCT-2M1-of(C,D)"
          using finseqop_lm_4 sorry
        thus "F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> G .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d1,T),F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d2,T))"
          using A1 finseqop_th_35 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_47:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds F is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> G implies F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> G .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d1),F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d2))"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds F is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> G implies F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> G .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d1),F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d2))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of D"
    fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of D"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix T assume [ty]: "T be TupleFINSEQ-2M3-of(i,D)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix G assume [ty]: "G be BinOpBINOP-1M2-of D"
    assume A1: "F is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> G"
    show "F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> G .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d1),F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d2))"
    proof-
      have cases: "i =HIDDENR1 0NUMBERSK6 or i <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "i =HIDDENR1 0NUMBERSK6 implies F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> G .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d1),F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d2))"
      proof(rule impI)
        assume "i =HIDDENR1 0NUMBERSK6"
        then have "F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d1) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D & F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D"
          using finseqop_lm_3 sorry
        thus "F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> G .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d1),F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d2))"
          using finseq_2_th_73 sorry
      qed
      have case2: "i <>HIDDENR2 0NUMBERSK6 implies F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> G .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d1),F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d2))"
      proof(rule impI)
        assume "i <>HIDDENR2 0NUMBERSK6"
        then obtain C where 
          [ty]:"C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and CDef:"C = SegFINSEQ-1K1 i"
           sorry
        have "T be FunctionFUNCT-2M1-of(C,D)"
          using finseqop_lm_4 sorry
        thus "F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> G .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d1),F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d2))"
          using A1 finseqop_th_36 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_48:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for h be FunctionFUNCT-2M1-of(D,E) holds  for T1 be TupleFINSEQ-2M3-of(i,D) holds  for T2 be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds  for H be BinOpBINOP-1M2-of E holds ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 H .BINOP-1K4\<^bsub>(E)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d1,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d2)) implies h *FINSEQOPK4\<^bsub>(D,E)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> H .:FINSEQOPK1\<^bsub>(E,E,E)\<^esub>(h *FINSEQOPK4\<^bsub>(D,E)\<^esub> T1,h *FINSEQOPK4\<^bsub>(D,E)\<^esub> T2)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for h be FunctionFUNCT-2M1-of(D,E) holds  for T1 be TupleFINSEQ-2M3-of(i,D) holds  for T2 be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds  for H be BinOpBINOP-1M2-of E holds ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 H .BINOP-1K4\<^bsub>(E)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d1,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d2)) implies h *FINSEQOPK4\<^bsub>(D,E)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> H .:FINSEQOPK1\<^bsub>(E,E,E)\<^esub>(h *FINSEQOPK4\<^bsub>(D,E)\<^esub> T1,h *FINSEQOPK4\<^bsub>(D,E)\<^esub> T2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix h assume [ty]: "h be FunctionFUNCT-2M1-of(D,E)"
    fix T1 assume [ty]: "T1 be TupleFINSEQ-2M3-of(i,D)"
    fix T2 assume [ty]: "T2 be TupleFINSEQ-2M3-of(i,D)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix H assume [ty]: "H be BinOpBINOP-1M2-of E"
    assume A1: " for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 H .BINOP-1K4\<^bsub>(E)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d1,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d2)"
    show "h *FINSEQOPK4\<^bsub>(D,E)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> H .:FINSEQOPK1\<^bsub>(E,E,E)\<^esub>(h *FINSEQOPK4\<^bsub>(D,E)\<^esub> T1,h *FINSEQOPK4\<^bsub>(D,E)\<^esub> T2)"
    proof-
      have cases: "i =HIDDENR1 0NUMBERSK6 or i <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "i =HIDDENR1 0NUMBERSK6 implies h *FINSEQOPK4\<^bsub>(D,E)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> H .:FINSEQOPK1\<^bsub>(E,E,E)\<^esub>(h *FINSEQOPK4\<^bsub>(D,E)\<^esub> T1,h *FINSEQOPK4\<^bsub>(D,E)\<^esub> T2)"
      proof(rule impI)
        assume A2: "i =HIDDENR1 0NUMBERSK6"
        then have "F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D"
          using finseqop_lm_1 sorry
        then have A3: "h *FINSEQOPK4\<^bsub>(D,E)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> <*>FINSEQ-1K7 E"
           sorry
        have "h *FINSEQOPK4\<^bsub>(D,E)\<^esub> T1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> <*>FINSEQ-1K7 E"
          using A2 sorry
        thus "h *FINSEQOPK4\<^bsub>(D,E)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> H .:FINSEQOPK1\<^bsub>(E,E,E)\<^esub>(h *FINSEQOPK4\<^bsub>(D,E)\<^esub> T1,h *FINSEQOPK4\<^bsub>(D,E)\<^esub> T2)"
          using A3 finseq_2_th_73 sorry
      qed
      have case2: "i <>HIDDENR2 0NUMBERSK6 implies h *FINSEQOPK4\<^bsub>(D,E)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> H .:FINSEQOPK1\<^bsub>(E,E,E)\<^esub>(h *FINSEQOPK4\<^bsub>(D,E)\<^esub> T1,h *FINSEQOPK4\<^bsub>(D,E)\<^esub> T2)"
      proof(rule impI)
        assume "i <>HIDDENR2 0NUMBERSK6"
        then obtain C where 
          [ty]:"C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and CDef:"C = SegFINSEQ-1K1 i"
           sorry
        have "T1 be FunctionFUNCT-2M1-of(C,D) & T2 be FunctionFUNCT-2M1-of(C,D)"
          using finseqop_lm_4 sorry
        thus "h *FINSEQOPK4\<^bsub>(D,E)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> H .:FINSEQOPK1\<^bsub>(E,E,E)\<^esub>(h *FINSEQOPK4\<^bsub>(D,E)\<^esub> T1,h *FINSEQOPK4\<^bsub>(D,E)\<^esub> T2)"
          using A1 finseqop_th_37 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_49:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for h be FunctionFUNCT-2M1-of(D,E) holds  for T be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds  for H be BinOpBINOP-1M2-of E holds ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 H .BINOP-1K4\<^bsub>(E)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d1,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d2)) implies h *FINSEQOPK4\<^bsub>(D,E)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> H [;]FINSEQOPK3\<^bsub>(E,E,E)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d,h *FINSEQOPK4\<^bsub>(D,E)\<^esub> T)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for h be FunctionFUNCT-2M1-of(D,E) holds  for T be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds  for H be BinOpBINOP-1M2-of E holds ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 H .BINOP-1K4\<^bsub>(E)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d1,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d2)) implies h *FINSEQOPK4\<^bsub>(D,E)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> H [;]FINSEQOPK3\<^bsub>(E,E,E)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d,h *FINSEQOPK4\<^bsub>(D,E)\<^esub> T)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix h assume [ty]: "h be FunctionFUNCT-2M1-of(D,E)"
    fix T assume [ty]: "T be TupleFINSEQ-2M3-of(i,D)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix H assume [ty]: "H be BinOpBINOP-1M2-of E"
    assume A1: " for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 H .BINOP-1K4\<^bsub>(E)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d1,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d2)"
    show "h *FINSEQOPK4\<^bsub>(D,E)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> H [;]FINSEQOPK3\<^bsub>(E,E,E)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d,h *FINSEQOPK4\<^bsub>(D,E)\<^esub> T)"
    proof-
      have cases: "i =HIDDENR1 0NUMBERSK6 or i <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "i =HIDDENR1 0NUMBERSK6 implies h *FINSEQOPK4\<^bsub>(D,E)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> H [;]FINSEQOPK3\<^bsub>(E,E,E)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d,h *FINSEQOPK4\<^bsub>(D,E)\<^esub> T)"
      proof(rule impI)
        assume A2: "i =HIDDENR1 0NUMBERSK6"
        then have "F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D"
          using finseqop_lm_2 sorry
        then have A3: "h *FINSEQOPK4\<^bsub>(D,E)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> <*>FINSEQ-1K7 E"
           sorry
        have "h *FINSEQOPK4\<^bsub>(D,E)\<^esub> T =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> <*>FINSEQ-1K7 E"
          using A2 sorry
        thus "h *FINSEQOPK4\<^bsub>(D,E)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> H [;]FINSEQOPK3\<^bsub>(E,E,E)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d,h *FINSEQOPK4\<^bsub>(D,E)\<^esub> T)"
          using A3 finseq_2_th_79 sorry
      qed
      have case2: "i <>HIDDENR2 0NUMBERSK6 implies h *FINSEQOPK4\<^bsub>(D,E)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> H [;]FINSEQOPK3\<^bsub>(E,E,E)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d,h *FINSEQOPK4\<^bsub>(D,E)\<^esub> T)"
      proof(rule impI)
        assume "i <>HIDDENR2 0NUMBERSK6"
        then obtain C where 
          [ty]:"C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and CDef:"C = SegFINSEQ-1K1 i"
           sorry
        have "T be FunctionFUNCT-2M1-of(C,D)"
          using finseqop_lm_4 sorry
        thus "h *FINSEQOPK4\<^bsub>(D,E)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> H [;]FINSEQOPK3\<^bsub>(E,E,E)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d,h *FINSEQOPK4\<^bsub>(D,E)\<^esub> T)"
          using A1 finseqop_th_38 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_50:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for h be FunctionFUNCT-2M1-of(D,E) holds  for T be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds  for H be BinOpBINOP-1M2-of E holds ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 H .BINOP-1K4\<^bsub>(E)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d1,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d2)) implies h *FINSEQOPK4\<^bsub>(D,E)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> H [:]FINSEQOPK2\<^bsub>(E,E,E)\<^esub>(h *FINSEQOPK4\<^bsub>(D,E)\<^esub> T,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for h be FunctionFUNCT-2M1-of(D,E) holds  for T be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds  for H be BinOpBINOP-1M2-of E holds ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 H .BINOP-1K4\<^bsub>(E)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d1,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d2)) implies h *FINSEQOPK4\<^bsub>(D,E)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> H [:]FINSEQOPK2\<^bsub>(E,E,E)\<^esub>(h *FINSEQOPK4\<^bsub>(D,E)\<^esub> T,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix h assume [ty]: "h be FunctionFUNCT-2M1-of(D,E)"
    fix T assume [ty]: "T be TupleFINSEQ-2M3-of(i,D)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix H assume [ty]: "H be BinOpBINOP-1M2-of E"
    assume A1: " for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 H .BINOP-1K4\<^bsub>(E)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d1,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d2)"
    show "h *FINSEQOPK4\<^bsub>(D,E)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> H [:]FINSEQOPK2\<^bsub>(E,E,E)\<^esub>(h *FINSEQOPK4\<^bsub>(D,E)\<^esub> T,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d)"
    proof-
      have cases: "i =HIDDENR1 0NUMBERSK6 or i <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "i =HIDDENR1 0NUMBERSK6 implies h *FINSEQOPK4\<^bsub>(D,E)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> H [:]FINSEQOPK2\<^bsub>(E,E,E)\<^esub>(h *FINSEQOPK4\<^bsub>(D,E)\<^esub> T,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d)"
      proof(rule impI)
        assume A2: "i =HIDDENR1 0NUMBERSK6"
        then have "F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D"
          using finseqop_lm_3 sorry
        then have A3: "h *FINSEQOPK4\<^bsub>(D,E)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> <*>FINSEQ-1K7 E"
           sorry
        have "h *FINSEQOPK4\<^bsub>(D,E)\<^esub> T =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> <*>FINSEQ-1K7 E"
          using A2 sorry
        thus "h *FINSEQOPK4\<^bsub>(D,E)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> H [:]FINSEQOPK2\<^bsub>(E,E,E)\<^esub>(h *FINSEQOPK4\<^bsub>(D,E)\<^esub> T,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d)"
          using A3 finseq_2_th_85 sorry
      qed
      have case2: "i <>HIDDENR2 0NUMBERSK6 implies h *FINSEQOPK4\<^bsub>(D,E)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> H [:]FINSEQOPK2\<^bsub>(E,E,E)\<^esub>(h *FINSEQOPK4\<^bsub>(D,E)\<^esub> T,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d)"
      proof(rule impI)
        assume "i <>HIDDENR2 0NUMBERSK6"
        then obtain C where 
          [ty]:"C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and CDef:"C = SegFINSEQ-1K1 i"
           sorry
        have "T be FunctionFUNCT-2M1-of(C,D)"
          using finseqop_lm_4 sorry
        thus "h *FINSEQOPK4\<^bsub>(D,E)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,E)\<^esub> H [:]FINSEQOPK2\<^bsub>(E,E,E)\<^esub>(h *FINSEQOPK4\<^bsub>(D,E)\<^esub> T,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d)"
          using A1 finseqop_th_39 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_51:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T1 be TupleFINSEQ-2M3-of(i,D) holds  for T2 be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds  for u be UnOpBINOP-1M1-of D holds u is-distributive-wrtBINOP-1R12\<^bsub>(D)\<^esub> F implies u *FINSEQOPK4\<^bsub>(D,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(u *FINSEQOPK4\<^bsub>(D,D)\<^esub> T1,u *FINSEQOPK4\<^bsub>(D,D)\<^esub> T2)"
  using finseqop_th_48 sorry

mtheorem finseqop_th_52:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds  for u be UnOpBINOP-1M1-of D holds u is-distributive-wrtBINOP-1R12\<^bsub>(D)\<^esub> F implies u *FINSEQOPK4\<^bsub>(D,D)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d,u *FINSEQOPK4\<^bsub>(D,D)\<^esub> T)"
  using finseqop_th_49 sorry

mtheorem finseqop_th_53:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds  for u be UnOpBINOP-1M1-of D holds u is-distributive-wrtBINOP-1R12\<^bsub>(D)\<^esub> F implies u *FINSEQOPK4\<^bsub>(D,D)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,d) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(u *FINSEQOPK4\<^bsub>(D,D)\<^esub> T,u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d)"
  using finseqop_th_50 sorry

mtheorem finseqop_th_54:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for u be UnOpBINOP-1M1-of D holds G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F & u =FUNCT-2R2\<^bsub>(D,D)\<^esub> G [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) implies u is-distributive-wrtBINOP-1R12\<^bsub>(D)\<^esub> F"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for u be UnOpBINOP-1M1-of D holds G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F & u =FUNCT-2R2\<^bsub>(D,D)\<^esub> G [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) implies u is-distributive-wrtBINOP-1R12\<^bsub>(D)\<^esub> F"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix G assume [ty]: "G be BinOpBINOP-1M2-of D"
    fix u assume [ty]: "u be UnOpBINOP-1M1-of D"
    assume A1: "G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F"
      and A2: "u =FUNCT-2R2\<^bsub>(D,D)\<^esub> G [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D)"
    have " for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds u .FUNCT-2K3\<^bsub>(D,D)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1,u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d2)"
    proof(rule ballI,rule ballI)
      fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of D"
      fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of D"
      have "u .FUNCT-2K3\<^bsub>(D,D)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =HIDDENR1 G .BINOP-1K4\<^bsub>(D)\<^esub>(d,idPARTFUN1K6 D .FUNCT-2K3\<^bsub>(D,D)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)))"
        using A2 funcop_1_th_53 sorry
      also have "... = G .BINOP-1K4\<^bsub>(D)\<^esub>(d,F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2))"
         sorry
      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d,d1),G .BINOP-1K4\<^bsub>(D)\<^esub>(d,d2))"
        using A1 binop_1_th_11 sorry
      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d,idPARTFUN1K6 D .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1),G .BINOP-1K4\<^bsub>(D)\<^esub>(d,d2))"
         sorry
      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d,idPARTFUN1K6 D .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1),G .BINOP-1K4\<^bsub>(D)\<^esub>(d,idPARTFUN1K6 D .FUNCT-2K3\<^bsub>(D,D)\<^esub> d2))"
         sorry
      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1,G .BINOP-1K4\<^bsub>(D)\<^esub>(d,idPARTFUN1K6 D .FUNCT-2K3\<^bsub>(D,D)\<^esub> d2))"
        using A2 funcop_1_th_53 sorry
      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1,u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d2)"
        using A2 funcop_1_th_53 sorry
      finally show "u .FUNCT-2K3\<^bsub>(D,D)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1,u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d2)"
         sorry
    qed "sorry"
    thus "u is-distributive-wrtBINOP-1R12\<^bsub>(D)\<^esub> F"
      using binop_1_def_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_55:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for u be UnOpBINOP-1M1-of D holds G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F & u =FUNCT-2R2\<^bsub>(D,D)\<^esub> G [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d) implies u is-distributive-wrtBINOP-1R12\<^bsub>(D)\<^esub> F"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for u be UnOpBINOP-1M1-of D holds G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F & u =FUNCT-2R2\<^bsub>(D,D)\<^esub> G [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d) implies u is-distributive-wrtBINOP-1R12\<^bsub>(D)\<^esub> F"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix G assume [ty]: "G be BinOpBINOP-1M2-of D"
    fix u assume [ty]: "u be UnOpBINOP-1M1-of D"
    assume A1: "G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F"
      and A2: "u =FUNCT-2R2\<^bsub>(D,D)\<^esub> G [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d)"
    have " for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds u .FUNCT-2K3\<^bsub>(D,D)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1,u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d2)"
    proof(rule ballI,rule ballI)
      fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of D"
      fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of D"
      have "u .FUNCT-2K3\<^bsub>(D,D)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =HIDDENR1 G .BINOP-1K4\<^bsub>(D)\<^esub>(idPARTFUN1K6 D .FUNCT-2K3\<^bsub>(D,D)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)),d)"
        using A2 funcop_1_th_48 sorry
      also have "... = G .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),d)"
         sorry
      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d),G .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d))"
        using A1 binop_1_th_11 sorry
      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(idPARTFUN1K6 D .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1,d),G .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d))"
         sorry
      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(idPARTFUN1K6 D .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1,d),G .BINOP-1K4\<^bsub>(D)\<^esub>(idPARTFUN1K6 D .FUNCT-2K3\<^bsub>(D,D)\<^esub> d2,d))"
         sorry
      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1,G .BINOP-1K4\<^bsub>(D)\<^esub>(idPARTFUN1K6 D .FUNCT-2K3\<^bsub>(D,D)\<^esub> d2,d))"
        using A2 funcop_1_th_48 sorry
      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1,u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d2)"
        using A2 funcop_1_th_48 sorry
      finally show "u .FUNCT-2K3\<^bsub>(D,D)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1,u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d2)"
         sorry
    qed "sorry"
    thus "u is-distributive-wrtBINOP-1R12\<^bsub>(D)\<^esub> F"
      using binop_1_def_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_56:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T & F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T,i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T & F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T,i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix T assume [ty]: "T be TupleFINSEQ-2M3-of(i,D)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    assume A1: "F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
    show "F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T & F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T,i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T"
    proof-
      have cases: "i =HIDDENR1 0NUMBERSK6 or i <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "i =HIDDENR1 0NUMBERSK6 implies F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T & F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T,i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T"
      proof(rule impI)
        assume A2: "i =HIDDENR1 0NUMBERSK6"
        then have "T =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D"
           sorry
        thus "F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T & F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T,i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T"
          using A2 finseqop_lm_1 sorry
      qed
      have case2: "i <>HIDDENR2 0NUMBERSK6 implies F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T & F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T,i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T"
      proof(rule impI)
        assume "i <>HIDDENR2 0NUMBERSK6"
        then obtain C where 
          [ty]:"C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and CDef:"C = SegFINSEQ-1K1 i"
           sorry
        have "T be FunctionFUNCT-2M1-of(C,D)"
          using finseqop_lm_4 sorry
        thus "F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T & F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T,i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T"
          using A1 finseqop_th_43 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_57:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix T assume [ty]: "T be TupleFINSEQ-2M3-of(i,D)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    assume A1: "F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
    show "F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T"
    proof-
      have cases: "i =HIDDENR1 0NUMBERSK6 or i <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "i =HIDDENR1 0NUMBERSK6 implies F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T"
      proof(rule impI)
        assume "i =HIDDENR1 0NUMBERSK6"
        then have "T =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D"
           sorry
        thus "F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T"
          using finseqop_lm_2 sorry
      qed
      have case2: "i <>HIDDENR2 0NUMBERSK6 implies F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T"
      proof(rule impI)
        assume "i <>HIDDENR2 0NUMBERSK6"
        then obtain C where 
          [ty]:"C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and CDef:"C = SegFINSEQ-1K1 i"
           sorry
        have "T be FunctionFUNCT-2M1-of(C,D)"
          using finseqop_lm_4 sorry
        thus "F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T"
          using A1 finseqop_th_44 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_58:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix T assume [ty]: "T be TupleFINSEQ-2M3-of(i,D)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    assume A1: "F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
    show "F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T"
    proof-
      have cases: "i =HIDDENR1 0NUMBERSK6 or i <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "i =HIDDENR1 0NUMBERSK6 implies F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T"
      proof(rule impI)
        assume "i =HIDDENR1 0NUMBERSK6"
        then have "T =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D"
           sorry
        thus "F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T"
          using finseqop_lm_3 sorry
      qed
      have case2: "i <>HIDDENR2 0NUMBERSK6 implies F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T"
      proof(rule impI)
        assume "i <>HIDDENR2 0NUMBERSK6"
        then obtain C where 
          [ty]:"C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and CDef:"C = SegFINSEQ-1K1 i"
           sorry
        have "T be FunctionFUNCT-2M1-of(C,D)"
          using finseqop_lm_4 sorry
        thus "F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(T,the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T"
          using A1 finseqop_th_45 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef finseqop_def_1 (" _ is-an-inverseOp-wrtFINSEQOPR1\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "u be UnOpBINOP-1M1-of D", "F be BinOpBINOP-1M2-of D"
"pred u is-an-inverseOp-wrtFINSEQOPR1\<^bsub>(D)\<^esub> F means
   for d be ElementSUBSET-1M1-of D holds F .BINOP-1K4\<^bsub>(D)\<^esub>(d,u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d) =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F & F .BINOP-1K4\<^bsub>(D)\<^esub>(u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d,d) =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"..

mdef finseqop_def_2 ("having-an-inverseOpFINSEQOPV1\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"attr having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> for BinOpBINOP-1M2-of D means
  (\<lambda>F.  ex u be UnOpBINOP-1M1-of D st u is-an-inverseOp-wrtFINSEQOPR1\<^bsub>(D)\<^esub> F)"..

mdef finseqop_def_3 ("the-inverseOp-wrtFINSEQOPK5\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be BinOpBINOP-1M2-of D"
"assume F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & (F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) func the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F \<rightarrow> UnOpBINOP-1M1-of D means
  \<lambda>it. it is-an-inverseOp-wrtFINSEQOPR1\<^bsub>(D)\<^esub> F"
proof-
  (*existence*)
    show "F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & (F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) implies ( ex it be UnOpBINOP-1M1-of D st it is-an-inverseOp-wrtFINSEQOPR1\<^bsub>(D)\<^esub> F)"
    proof(rule impI)
      assume Assume: "F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & (F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>)"
      have A1: "F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
        using Assume sorry
      have A2: "F be associativeBINOP-1V2\<^bsub>(D)\<^esub>"
        using Assume sorry
      have A3: "F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>"
        using Assume sorry
      show " ex it be UnOpBINOP-1M1-of D st it is-an-inverseOp-wrtFINSEQOPR1\<^bsub>(D)\<^esub> F"
        using A3 sorry
    qed
  (*uniqueness*)
    show "F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & (F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) implies ( for it1 be UnOpBINOP-1M1-of D holds  for it2 be UnOpBINOP-1M1-of D holds it1 is-an-inverseOp-wrtFINSEQOPR1\<^bsub>(D)\<^esub> F & it2 is-an-inverseOp-wrtFINSEQOPR1\<^bsub>(D)\<^esub> F implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & (F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>)"
      have A1: "F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
        using Assume sorry
      have A2: "F be associativeBINOP-1V2\<^bsub>(D)\<^esub>"
        using Assume sorry
      have A3: "F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>"
        using Assume sorry
      show " for it1 be UnOpBINOP-1M1-of D holds  for it2 be UnOpBINOP-1M1-of D holds it1 is-an-inverseOp-wrtFINSEQOPR1\<^bsub>(D)\<^esub> F & it2 is-an-inverseOp-wrtFINSEQOPR1\<^bsub>(D)\<^esub> F implies it1 =HIDDENR1 it2"
      proof-
        have " for u1 be UnOpBINOP-1M1-of D holds  for u2 be UnOpBINOP-1M1-of D holds  not ((u1 is-an-inverseOp-wrtFINSEQOPR1\<^bsub>(D)\<^esub> F & u2 is-an-inverseOp-wrtFINSEQOPR1\<^bsub>(D)\<^esub> F) &  not u1 =HIDDENR1 u2)"
        proof(rule ballI,rule ballI)
          let ?e = "the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
          fix u1 assume [ty]: "u1 be UnOpBINOP-1M1-of D"
          fix u2 assume [ty]: "u2 be UnOpBINOP-1M1-of D"
          have "( for d be ElementSUBSET-1M1-of D holds F .BINOP-1K4\<^bsub>(D)\<^esub>(d,u1 .FUNCT-2K3\<^bsub>(D,D)\<^esub> d) =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F & F .BINOP-1K4\<^bsub>(D)\<^esub>(u1 .FUNCT-2K3\<^bsub>(D,D)\<^esub> d,d) =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) & ( for d be ElementSUBSET-1M1-of D holds F .BINOP-1K4\<^bsub>(D)\<^esub>(d,u2 .FUNCT-2K3\<^bsub>(D,D)\<^esub> d) =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F & F .BINOP-1K4\<^bsub>(D)\<^esub>(u2 .FUNCT-2K3\<^bsub>(D,D)\<^esub> d,d) =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) implies u1 =HIDDENR1 u2"
          proof(rule impMI ,rule impI)
            assume A4: " for d be ElementSUBSET-1M1-of D holds F .BINOP-1K4\<^bsub>(D)\<^esub>(d,u1 .FUNCT-2K3\<^bsub>(D,D)\<^esub> d) =XBOOLE-0R4 ?e & F .BINOP-1K4\<^bsub>(D)\<^esub>(u1 .FUNCT-2K3\<^bsub>(D,D)\<^esub> d,d) =XBOOLE-0R4 ?e"
              and A5: " for d be ElementSUBSET-1M1-of D holds F .BINOP-1K4\<^bsub>(D)\<^esub>(d,u2 .FUNCT-2K3\<^bsub>(D,D)\<^esub> d) =XBOOLE-0R4 ?e & F .BINOP-1K4\<^bsub>(D)\<^esub>(u2 .FUNCT-2K3\<^bsub>(D,D)\<^esub> d,d) =XBOOLE-0R4 ?e"
            have " for d be ElementSUBSET-1M1-of D holds u1 .FUNCT-2K3\<^bsub>(D,D)\<^esub> d =HIDDENR1 u2 .FUNCT-2K3\<^bsub>(D,D)\<^esub> d"
            proof(rule ballI)
              fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
              let ?d1 = "u1 .FUNCT-2K3\<^bsub>(D,D)\<^esub> d"
              let ?d2 = "u2 .FUNCT-2K3\<^bsub>(D,D)\<^esub> d"
              have "u1 .FUNCT-2K3\<^bsub>(D,D)\<^esub> d =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(u1 .FUNCT-2K3\<^bsub>(D,D)\<^esub> d,the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F)"
                using A1 setwiseo_th_15 sorry
              also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(u1 .FUNCT-2K3\<^bsub>(D,D)\<^esub> d,F .BINOP-1K4\<^bsub>(D)\<^esub>(d,u2 .FUNCT-2K3\<^bsub>(D,D)\<^esub> d))"
                using A5 sorry
              also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(u1 .FUNCT-2K3\<^bsub>(D,D)\<^esub> d,d),u2 .FUNCT-2K3\<^bsub>(D,D)\<^esub> d)"
                using A2 sorry
              also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,u2 .FUNCT-2K3\<^bsub>(D,D)\<^esub> d)"
                using A4 sorry
              also have "... = u2 .FUNCT-2K3\<^bsub>(D,D)\<^esub> d"
                using A1 setwiseo_th_15 sorry
              finally show "u1 .FUNCT-2K3\<^bsub>(D,D)\<^esub> d =HIDDENR1 u2 .FUNCT-2K3\<^bsub>(D,D)\<^esub> d"
                 sorry
            qed "sorry"
            thus "u1 =HIDDENR1 u2"
              using funct_2_th_63 sorry
          qed
          thus " not ((u1 is-an-inverseOp-wrtFINSEQOPR1\<^bsub>(D)\<^esub> F & u2 is-an-inverseOp-wrtFINSEQOPR1\<^bsub>(D)\<^esub> F) &  not u1 =HIDDENR1 u2)"
            using finseqop_def_1 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem finseqop_th_59:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds (F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> implies F .BINOP-1K4\<^bsub>(D)\<^esub>((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d,d) =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F & F .BINOP-1K4\<^bsub>(D)\<^esub>(d,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d) =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds (F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> implies F .BINOP-1K4\<^bsub>(D)\<^esub>((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d,d) =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F & F .BINOP-1K4\<^bsub>(D)\<^esub>(d,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d) =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    assume "(F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>"
    then have "the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F is-an-inverseOp-wrtFINSEQOPR1\<^bsub>(D)\<^esub> F"
      using finseqop_def_3 sorry
    thus "F .BINOP-1K4\<^bsub>(D)\<^esub>((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d,d) =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F & F .BINOP-1K4\<^bsub>(D)\<^esub>(d,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d) =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_60:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds ((F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2) =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F implies d1 =XBOOLE-0R4 (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d2 & (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d1 =XBOOLE-0R4 d2"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & (F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & (F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> & F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2) =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F)) implies d1 =XBOOLE-0R4 (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d2 & (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d1 =XBOOLE-0R4 d2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of D"
    fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    assume A1: "F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
      and A2: "F be associativeBINOP-1V2\<^bsub>(D)\<^esub>"
      and A3: "F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>"
      and A4: "F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2) =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
    let ?e = "the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
    let ?d3 = "(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d2"
    have "F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),?d3) =XBOOLE-0R4 ?d3"
      using A1 A4 setwiseo_th_15 sorry
    then have "F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,?d3)) =XBOOLE-0R4 ?d3"
      using A2 sorry
    then have "F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,?e) =XBOOLE-0R4 ?d3"
      using A1 A2 A3 finseqop_th_59 sorry
    thus "d1 =XBOOLE-0R4 (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d2"
      using A1 setwiseo_th_15 sorry
    let ?d3 = "(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d1"
    have "F .BINOP-1K4\<^bsub>(D)\<^esub>(?d3,F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 ?d3"
      using A1 A4 setwiseo_th_15 sorry
    then have "F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(?d3,d1),d2) =XBOOLE-0R4 ?d3"
      using A2 sorry
    then have "F .BINOP-1K4\<^bsub>(D)\<^esub>(?e,d2) =XBOOLE-0R4 ?d3"
      using A1 A2 A3 finseqop_th_59 sorry
    thus "(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d1 =XBOOLE-0R4 d2"
      using A1 setwiseo_th_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_61:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of D holds (F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> implies (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of D holds F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & (F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) implies (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    assume A1: "F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
      and A2: "F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>"
    let ?e = "the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
    have "F .BINOP-1K4\<^bsub>(D)\<^esub>(?e,?e) =XBOOLE-0R4 ?e"
      using A1 setwiseo_th_15 sorry
    thus "(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
      using A1 A2 finseqop_th_60 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_62:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds (F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> implies (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> ((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d) =XBOOLE-0R4 d"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds (F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> implies (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> ((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d) =XBOOLE-0R4 d"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    assume A1: "(F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>"
    then have "F .BINOP-1K4\<^bsub>(D)\<^esub>(d,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d) =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
      using finseqop_th_59 sorry
    thus "(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> ((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d) =XBOOLE-0R4 d"
      using A1 finseqop_th_60 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_63:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of D holds ((F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> implies the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F is-distributive-wrtBINOP-1R12\<^bsub>(D)\<^esub> F"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of D holds F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & (F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & (F be commutativeBINOP-1V1\<^bsub>(D)\<^esub> & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>)) implies the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F is-distributive-wrtBINOP-1R12\<^bsub>(D)\<^esub> F"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    assume A1: "F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
      and A2: "F be associativeBINOP-1V2\<^bsub>(D)\<^esub>"
      and A3: "F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>"
      and A4: "F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>"
    have " for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d1,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d2)"
    proof(rule ballI,rule ballI)
      fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of D"
      fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of D"
      let ?e = "the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
      let ?u = "the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F"
      have "F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(?u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1,?u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d2),F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(?u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1,F .BINOP-1K4\<^bsub>(D)\<^esub>(?u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d2,F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)))"
        using A2 sorry
      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(?u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1,F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(?u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d2,d1),d2))"
        using A2 sorry
      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(?u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1,F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,?u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d2),d2))"
        using A3 sorry
      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(?u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1,F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,F .BINOP-1K4\<^bsub>(D)\<^esub>(?u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d2,d2)))"
        using A2 sorry
      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(?u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1,F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,?e))"
        using A1 A2 A4 finseqop_th_59 sorry
      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(?u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1,d1),?e)"
        using A2 sorry
      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(?e,?e)"
        using A1 A2 A4 finseqop_th_59 sorry
      also have "... = ?e"
        using A1 setwiseo_th_15 sorry
      finally have "F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(?u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1,?u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d2),F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =HIDDENR1 ?e"
         sorry
      thus "(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d1,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d2)"
        using A1 A2 A4 finseqop_th_60 sorry
    qed "sorry"
    thus "the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F is-distributive-wrtBINOP-1R12\<^bsub>(D)\<^esub> F"
      using binop_1_def_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_64:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds ((F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & (F .BINOP-1K4\<^bsub>(D)\<^esub>(d,d1) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(d,d2) or F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d)) implies d1 =XBOOLE-0R4 d2"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & (F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & (F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> & (F .BINOP-1K4\<^bsub>(D)\<^esub>(d,d1) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(d,d2) or F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d)))) implies d1 =HIDDENR1 d2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of D"
    fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    assume A1: "F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
      and A2: "F be associativeBINOP-1V2\<^bsub>(D)\<^esub>"
      and A3: "F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>"
      and A4: "F .BINOP-1K4\<^bsub>(D)\<^esub>(d,d1) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(d,d2) or F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d)"
    let ?e = "the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
    let ?u = "the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F"
    show "d1 =HIDDENR1 d2"
    proof-
      have cases: "F .BINOP-1K4\<^bsub>(D)\<^esub>(d,d1) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(d,d2) or F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d)"
        using A4 sorry
      have case1: "F .BINOP-1K4\<^bsub>(D)\<^esub>(d,d1) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(d,d2) implies d1 =HIDDENR1 d2"
      proof(rule impI)
        assume A5: "F .BINOP-1K4\<^bsub>(D)\<^esub>(d,d1) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(d,d2)"
        have "d1 =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,d1)"
          using A1 setwiseo_th_15 sorry
        also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d,d),d1)"
          using A1 A2 A3 finseqop_th_59 sorry
        also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d,F .BINOP-1K4\<^bsub>(D)\<^esub>(d,d2))"
          using A2 A5 sorry
        also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d,d),d2)"
          using A2 sorry
        also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,d2)"
          using A1 A2 A3 finseqop_th_59 sorry
        also have "... = d2"
          using A1 setwiseo_th_15 sorry
        finally show "d1 =HIDDENR1 d2"
           sorry
      qed
      have case2: "F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d) implies d1 =HIDDENR1 d2"
      proof(rule impI)
        assume A6: "F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d)"
        have "d1 =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F)"
          using A1 setwiseo_th_15 sorry
        also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,F .BINOP-1K4\<^bsub>(D)\<^esub>(d,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d))"
          using A1 A2 A3 finseqop_th_59 sorry
        also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d),(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d)"
          using A2 A6 sorry
        also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,F .BINOP-1K4\<^bsub>(D)\<^esub>(d,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d))"
          using A2 sorry
        also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F)"
          using A1 A2 A3 finseqop_th_59 sorry
        also have "... = d2"
          using A1 setwiseo_th_15 sorry
        finally show "d1 =HIDDENR1 d2"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_65:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds ((F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2) =XBOOLE-0R4 d2 or F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d1) =XBOOLE-0R4 d2) implies d1 =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & (F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) implies (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2) =XBOOLE-0R4 d2 or F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d1) =XBOOLE-0R4 d2 implies d1 =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of D"
    fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    assume A1: "F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
      and A2: "F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>"
    let ?e = "the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
    assume "F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2) =XBOOLE-0R4 d2 or F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d1) =XBOOLE-0R4 d2"
    then have "F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(?e,d2) or F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d1) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,?e)"
      using A1 setwiseo_th_15 sorry
    thus "d1 =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
      using A1 A2 finseqop_th_64 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_66:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds (((F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F) & e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F implies ( for d be ElementSUBSET-1M1-of D holds G .BINOP-1K4\<^bsub>(D)\<^esub>(e,d) =XBOOLE-0R4 e & G .BINOP-1K4\<^bsub>(D)\<^esub>(d,e) =XBOOLE-0R4 e)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & (F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & (F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> & (G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F & e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F))) implies ( for d be ElementSUBSET-1M1-of D holds G .BINOP-1K4\<^bsub>(D)\<^esub>(e,d) =XBOOLE-0R4 e & G .BINOP-1K4\<^bsub>(D)\<^esub>(d,e) =XBOOLE-0R4 e)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI,rule ballI,rule conjMI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix e assume [ty]: "e be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix G assume [ty]: "G be BinOpBINOP-1M2-of D"
    assume A1: "F be associativeBINOP-1V2\<^bsub>(D)\<^esub>"
      and A2: "F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
      and A3: "F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>"
      and A4: "G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F"
      and A5: "e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    let ?ed = "G .BINOP-1K4\<^bsub>(D)\<^esub>(e,d)"
    have "F .BINOP-1K4\<^bsub>(D)\<^esub>(?ed,?ed) =HIDDENR1 G .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(e,e),d)"
      using A4 binop_1_th_11 sorry
    also have "... = ?ed"
      using A2 A5 setwiseo_th_15 sorry
    finally have "F .BINOP-1K4\<^bsub>(D)\<^esub>(?ed,?ed) =HIDDENR1 ?ed"
       sorry
    thus "G .BINOP-1K4\<^bsub>(D)\<^esub>(e,d) =XBOOLE-0R4 e"
      using A1 A2 A3 A5 finseqop_th_65 sorry
    let ?de = "G .BINOP-1K4\<^bsub>(D)\<^esub>(d,e)"
    have "F .BINOP-1K4\<^bsub>(D)\<^esub>(?de,?de) =HIDDENR1 G .BINOP-1K4\<^bsub>(D)\<^esub>(d,F .BINOP-1K4\<^bsub>(D)\<^esub>(e,e))"
      using A4 binop_1_th_11 sorry
    also have "... = ?de"
      using A2 A5 setwiseo_th_15 sorry
    finally have "F .BINOP-1K4\<^bsub>(D)\<^esub>(?de,?de) =HIDDENR1 ?de"
       sorry
    thus "G .BINOP-1K4\<^bsub>(D)\<^esub>(d,e) =XBOOLE-0R4 e"
      using A1 A2 A3 A5 finseqop_th_65 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_67:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for u be UnOpBINOP-1M1-of D holds (((F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & u =FUNCT-2R2\<^bsub>(D,D)\<^esub> the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F) & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F implies u .FUNCT-2K3\<^bsub>(D,D)\<^esub> (G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 G .BINOP-1K4\<^bsub>(D)\<^esub>(u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1,d2) & u .FUNCT-2K3\<^bsub>(D,D)\<^esub> (G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d2)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for u be UnOpBINOP-1M1-of D holds ((F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & (u =FUNCT-2R2\<^bsub>(D,D)\<^esub> the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F) implies u .FUNCT-2K3\<^bsub>(D,D)\<^esub> (G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 G .BINOP-1K4\<^bsub>(D)\<^esub>(u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1,d2) & u .FUNCT-2K3\<^bsub>(D,D)\<^esub> (G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of D"
    fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix G assume [ty]: "G be BinOpBINOP-1M2-of D"
    fix u assume [ty]: "u be UnOpBINOP-1M1-of D"
    assume A1: "(F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>"
      and A2: "u =FUNCT-2R2\<^bsub>(D,D)\<^esub> the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F"
      and A3: "G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F"
    let ?e = "the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
    have "F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),G .BINOP-1K4\<^bsub>(D)\<^esub>(u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1,d2)) =HIDDENR1 G .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1),d2)"
      using A3 binop_1_th_11 sorry
    also have "... = G .BINOP-1K4\<^bsub>(D)\<^esub>(?e,d2)"
      using A1 A2 finseqop_th_59 sorry
    also have "... = ?e"
      using A1 A3 finseqop_th_66 sorry
    finally have "F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),G .BINOP-1K4\<^bsub>(D)\<^esub>(u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1,d2)) =HIDDENR1 ?e"
       sorry
    thus "u .FUNCT-2K3\<^bsub>(D,D)\<^esub> (G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 G .BINOP-1K4\<^bsub>(D)\<^esub>(u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1,d2)"
      using A1 A2 finseqop_th_60 sorry
    have "F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d2)) =HIDDENR1 G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d2))"
      using A3 binop_1_th_11 sorry
    also have "... = G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,?e)"
      using A1 A2 finseqop_th_59 sorry
    also have "... = ?e"
      using A1 A3 finseqop_th_66 sorry
    finally have "F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d2)) =HIDDENR1 ?e"
       sorry
    thus "u .FUNCT-2K3\<^bsub>(D,D)\<^esub> (G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d2)"
      using A1 A2 finseqop_th_60 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_68:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for u be UnOpBINOP-1M1-of D holds ((((F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & u =FUNCT-2R2\<^bsub>(D,D)\<^esub> the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F) & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F) & G be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies G [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(u .FUNCT-2K3\<^bsub>(D,D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> G,idPARTFUN1K6 D) =FUNCT-2R2\<^bsub>(D,D)\<^esub> u"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for u be UnOpBINOP-1M1-of D holds ((((F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & u =FUNCT-2R2\<^bsub>(D,D)\<^esub> the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F) & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F) & G be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies G [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(u .FUNCT-2K3\<^bsub>(D,D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> G,idPARTFUN1K6 D) =FUNCT-2R2\<^bsub>(D,D)\<^esub> u"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix G assume [ty]: "G be BinOpBINOP-1M2-of D"
    fix u assume [ty]: "u be UnOpBINOP-1M1-of D"
    assume A1: "(((F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & u =FUNCT-2R2\<^bsub>(D,D)\<^esub> the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F) & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F"
      and A2: "G be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
    let ?o = "the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> G"
    have " for d be ElementSUBSET-1M1-of D holds (G [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(u .FUNCT-2K3\<^bsub>(D,D)\<^esub> ?o,idPARTFUN1K6 D)).FUNCT-2K3\<^bsub>(D,D)\<^esub> d =XBOOLE-0R4 u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d"
    proof-
      have " for d be ElementSUBSET-1M1-of D holds (G [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(u .FUNCT-2K3\<^bsub>(D,D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> G,idPARTFUN1K6 D)).FUNCT-2K3\<^bsub>(D,D)\<^esub> d =HIDDENR1 u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d"
      proof(rule ballI)
        fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
        have "(G [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(u .FUNCT-2K3\<^bsub>(D,D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> G,idPARTFUN1K6 D)).FUNCT-2K3\<^bsub>(D,D)\<^esub> d =HIDDENR1 G .BINOP-1K4\<^bsub>(D)\<^esub>(u .FUNCT-2K3\<^bsub>(D,D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> G,idPARTFUN1K6 D .FUNCT-2K3\<^bsub>(D,D)\<^esub> d)"
          using funcop_1_th_53 sorry
        also have "... = G .BINOP-1K4\<^bsub>(D)\<^esub>(u .FUNCT-2K3\<^bsub>(D,D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> G,d)"
           sorry
        also have "... = u .FUNCT-2K3\<^bsub>(D,D)\<^esub> (G .BINOP-1K4\<^bsub>(D)\<^esub>(the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> G,d))"
          using A1 finseqop_th_67 sorry
        also have "... = u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d"
          using A2 setwiseo_th_15 sorry
        finally show "(G [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(u .FUNCT-2K3\<^bsub>(D,D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> G,idPARTFUN1K6 D)).FUNCT-2K3\<^bsub>(D,D)\<^esub> d =HIDDENR1 u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "G [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(u .FUNCT-2K3\<^bsub>(D,D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> G,idPARTFUN1K6 D) =FUNCT-2R2\<^bsub>(D,D)\<^esub> u"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_69:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds ((F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F implies (G [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D)).FUNCT-2K3\<^bsub>(D,D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & (F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & (F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F)) implies (G [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D)).FUNCT-2K3\<^bsub>(D,D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix G assume [ty]: "G be BinOpBINOP-1M2-of D"
    assume A1: "F be associativeBINOP-1V2\<^bsub>(D)\<^esub>"
      and A2: "F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
      and A3: "F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>"
      and A4: "G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F"
    let ?e = "the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
    let ?i = "the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F"
    have "G .BINOP-1K4\<^bsub>(D)\<^esub>(d,?e) =HIDDENR1 G .BINOP-1K4\<^bsub>(D)\<^esub>(d,F .BINOP-1K4\<^bsub>(D)\<^esub>(?e,?e))"
      using A2 setwiseo_th_15 sorry
    also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d,?e),G .BINOP-1K4\<^bsub>(D)\<^esub>(d,?e))"
      using A4 binop_1_th_11 sorry
    finally have "G .BINOP-1K4\<^bsub>(D)\<^esub>(d,?e) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d,?e),G .BINOP-1K4\<^bsub>(D)\<^esub>(d,?e))"
       sorry
    then have "?e =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d,?e),G .BINOP-1K4\<^bsub>(D)\<^esub>(d,?e)),?i .FUNCT-2K3\<^bsub>(D,D)\<^esub> (G .BINOP-1K4\<^bsub>(D)\<^esub>(d,?e)))"
      using A1 A2 A3 finseqop_th_59 sorry
    then have "?e =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d,?e),F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d,?e),?i .FUNCT-2K3\<^bsub>(D,D)\<^esub> (G .BINOP-1K4\<^bsub>(D)\<^esub>(d,?e))))"
      using A1 sorry
    then have "?e =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d,?e),?e)"
      using A1 A2 A3 finseqop_th_59 sorry
    then have "?e =XBOOLE-0R4 G .BINOP-1K4\<^bsub>(D)\<^esub>(d,?e)"
      using A2 setwiseo_th_15 sorry
    then have "G .BINOP-1K4\<^bsub>(D)\<^esub>(d,idPARTFUN1K6 D .FUNCT-2K3\<^bsub>(D,D)\<^esub> ?e) =XBOOLE-0R4 ?e"
       sorry
    thus "(G [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D)).FUNCT-2K3\<^bsub>(D,D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
      using funcop_1_th_53 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_70:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds ((F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F implies (G [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d)).FUNCT-2K3\<^bsub>(D,D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & (F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & (F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F)) implies (G [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d)).FUNCT-2K3\<^bsub>(D,D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix G assume [ty]: "G be BinOpBINOP-1M2-of D"
    assume A1: "F be associativeBINOP-1V2\<^bsub>(D)\<^esub>"
      and A2: "F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
      and A3: "F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>"
      and A4: "G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F"
    let ?e = "the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
    let ?i = "the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F"
    have "G .BINOP-1K4\<^bsub>(D)\<^esub>(?e,d) =HIDDENR1 G .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(?e,?e),d)"
      using A2 setwiseo_th_15 sorry
    also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(?e,d),G .BINOP-1K4\<^bsub>(D)\<^esub>(?e,d))"
      using A4 binop_1_th_11 sorry
    finally have "G .BINOP-1K4\<^bsub>(D)\<^esub>(?e,d) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(?e,d),G .BINOP-1K4\<^bsub>(D)\<^esub>(?e,d))"
       sorry
    then have "?e =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(?e,d),G .BINOP-1K4\<^bsub>(D)\<^esub>(?e,d)),?i .FUNCT-2K3\<^bsub>(D,D)\<^esub> (G .BINOP-1K4\<^bsub>(D)\<^esub>(?e,d)))"
      using A1 A2 A3 finseqop_th_59 sorry
    then have "?e =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(?e,d),F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(?e,d),?i .FUNCT-2K3\<^bsub>(D,D)\<^esub> (G .BINOP-1K4\<^bsub>(D)\<^esub>(?e,d))))"
      using A1 sorry
    then have "?e =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(?e,d),?e)"
      using A1 A2 A3 finseqop_th_59 sorry
    then have "?e =XBOOLE-0R4 G .BINOP-1K4\<^bsub>(D)\<^esub>(?e,d)"
      using A2 setwiseo_th_15 sorry
    then have "G .BINOP-1K4\<^bsub>(D)\<^esub>(idPARTFUN1K6 D .FUNCT-2K3\<^bsub>(D,D)\<^esub> ?e,d) =XBOOLE-0R4 ?e"
       sorry
    thus "(G [:]FUNCOP-1K9\<^bsub>(D,D)\<^esub>(idPARTFUN1K6 D,d)).FUNCT-2K3\<^bsub>(D,D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
      using funcop_1_th_48 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_71:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for F be BinOpBINOP-1M2-of D holds (F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> implies F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f) =FUNCT-2R2\<^bsub>(C,D)\<^esub> C -->FUNCOP-1K8\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F & F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f,f) =FUNCT-2R2\<^bsub>(C,D)\<^esub> C -->FUNCOP-1K8\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for F be BinOpBINOP-1M2-of D holds (F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> implies F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f) =FUNCT-2R2\<^bsub>(C,D)\<^esub> C -->FUNCOP-1K8\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F & F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f,f) =FUNCT-2R2\<^bsub>(C,D)\<^esub> C -->FUNCOP-1K8\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    let ?u = "the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F"
    obtain g where 
      [ty]:"g be FunctionFUNCT-2M1-of(C,D)" and gDef:"g = C -->FUNCOP-1K8\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
       sorry
    assume A1: "(F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>"
    have " for c be ElementSUBSET-1M1-of C holds (F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 g .FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
    proof(rule ballI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      have "(F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c,((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f).FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
        using funcop_1_th_37 sorry
      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> (f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c))"
        using funct_2_th_15 sorry
      also have "... = the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
        using A1 finseqop_th_59 sorry
      also have "... = g .FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
        using funcop_1_th_7 sorry
      finally show "(F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 g .FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
         sorry
    qed "sorry"
    thus "F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f) =FUNCT-2R2\<^bsub>(C,D)\<^esub> C -->FUNCOP-1K8\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
      using funct_2_th_63 sorry
    have " for c be ElementSUBSET-1M1-of C holds (F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f,f)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 g .FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
    proof(rule ballI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      have "(F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f,f)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f).FUNCT-2K3\<^bsub>(C,D)\<^esub> c,f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
        using funcop_1_th_37 sorry
      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> (f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c),f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
        using funct_2_th_15 sorry
      also have "... = the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
        using A1 finseqop_th_59 sorry
      also have "... = g .FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
        using funcop_1_th_7 sorry
      finally show "(F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f,f)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 g .FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
         sorry
    qed "sorry"
    thus "F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f,f) =FUNCT-2R2\<^bsub>(C,D)\<^esub> C -->FUNCOP-1K8\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_72:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for f9 be FunctionFUNCT-2M1-of(C,D) holds  for F be BinOpBINOP-1M2-of D holds ((F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9) =FUNCT-2R2\<^bsub>(C,D)\<^esub> C -->FUNCOP-1K8\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F implies f =FUNCT-2R2\<^bsub>(C,D)\<^esub> (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f9 & (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f =FUNCT-2R2\<^bsub>(C,D)\<^esub> f9"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for f9 be FunctionFUNCT-2M1-of(C,D) holds  for F be BinOpBINOP-1M2-of D holds ((F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9) =FUNCT-2R2\<^bsub>(C,D)\<^esub> C -->FUNCOP-1K8\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F implies f =FUNCT-2R2\<^bsub>(C,D)\<^esub> (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f9 & (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f =FUNCT-2R2\<^bsub>(C,D)\<^esub> f9"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
    fix f9 assume [ty]: "f9 be FunctionFUNCT-2M1-of(C,D)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    assume A1: "(F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
      and A2: "F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9) =FUNCT-2R2\<^bsub>(C,D)\<^esub> C -->FUNCOP-1K8\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
    let ?u = "the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F"
    let ?e = "the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
    obtain g where 
      [ty]:"g be FunctionFUNCT-2M1-of(C,D)" and gDef:"g = C -->FUNCOP-1K8\<^bsub>(D)\<^esub> ?e"
       sorry
    have " for c be ElementSUBSET-1M1-of C holds f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 ((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f9).FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
    proof(rule ballI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      have "F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c,f9 .FUNCT-2K3\<^bsub>(C,D)\<^esub> c) =HIDDENR1 g .FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
        using A2 funcop_1_th_37 sorry
      also have "... = ?e"
        using funcop_1_th_7 sorry
      finally have "F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c,f9 .FUNCT-2K3\<^bsub>(C,D)\<^esub> c) =HIDDENR1 ?e"
         sorry
      then have "f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> (f9 .FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
        using A1 finseqop_th_60 sorry
      also have "... = ((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f9).FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
        using funct_2_th_15 sorry
      finally show "f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 ((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f9).FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
         sorry
    qed "sorry"
    thus "f =FUNCT-2R2\<^bsub>(C,D)\<^esub> (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f9"
      using funct_2_th_63 sorry
    have " for c be ElementSUBSET-1M1-of C holds ((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =XBOOLE-0R4 f9 .FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
    proof(rule ballI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      have "F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c,f9 .FUNCT-2K3\<^bsub>(C,D)\<^esub> c) =HIDDENR1 g .FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
        using A2 funcop_1_th_37 sorry
      also have "... = ?e"
        using funcop_1_th_7 sorry
      finally have "F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c,f9 .FUNCT-2K3\<^bsub>(C,D)\<^esub> c) =HIDDENR1 ?e"
         sorry
      then have "f9 .FUNCT-2K3\<^bsub>(C,D)\<^esub> c =XBOOLE-0R4 ?u .FUNCT-2K3\<^bsub>(D,D)\<^esub> (f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
        using A1 finseqop_th_60 sorry
      thus "((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =XBOOLE-0R4 f9 .FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
        using funct_2_th_15 sorry
    qed "sorry"
    thus "(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f =FUNCT-2R2\<^bsub>(C,D)\<^esub> f9"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_73:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds (F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> implies F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*FINSEQOPK4\<^bsub>(D,D)\<^esub> T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F & F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*FINSEQOPK4\<^bsub>(D,D)\<^esub> T,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds (F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> implies F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*FINSEQOPK4\<^bsub>(D,D)\<^esub> T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F & F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*FINSEQOPK4\<^bsub>(D,D)\<^esub> T,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix T assume [ty]: "T be TupleFINSEQ-2M3-of(i,D)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    assume A1: "(F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>"
    obtain uT where 
      [ty]:"uT be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of i -tuples-onFINSEQ-2K4 D" and uTDef:"uT = (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*FINSEQOPK4\<^bsub>(D,D)\<^esub> T"
      using finseq_2_th_113 sorry
    show "F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*FINSEQOPK4\<^bsub>(D,D)\<^esub> T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F & F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*FINSEQOPK4\<^bsub>(D,D)\<^esub> T,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
    proof-
      have cases: "i =HIDDENR1 0NUMBERSK6 or i <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "i =HIDDENR1 0NUMBERSK6 implies F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*FINSEQOPK4\<^bsub>(D,D)\<^esub> T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F & F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*FINSEQOPK4\<^bsub>(D,D)\<^esub> T,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
      proof(rule impI)
        assume A2: "i =HIDDENR1 0NUMBERSK6"
        then have "F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T,uT) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D & F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(uT,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D"
          using finseqop_lm_1 sorry
        thus "F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*FINSEQOPK4\<^bsub>(D,D)\<^esub> T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F & F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*FINSEQOPK4\<^bsub>(D,D)\<^esub> T,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
          using A2 sorry
      qed
      have case2: "i <>HIDDENR2 0NUMBERSK6 implies F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*FINSEQOPK4\<^bsub>(D,D)\<^esub> T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F & F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*FINSEQOPK4\<^bsub>(D,D)\<^esub> T,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
      proof(rule impI)
        assume "i <>HIDDENR2 0NUMBERSK6"
        then obtain C where 
          [ty]:"C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and CDef:"C = SegFINSEQ-1K1 i"
           sorry
        have "T be FunctionFUNCT-2M1-of(C,D)"
          using finseqop_lm_4 sorry
        thus "F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*FINSEQOPK4\<^bsub>(D,D)\<^esub> T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F & F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*FINSEQOPK4\<^bsub>(D,D)\<^esub> T,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
          using A1 finseqop_th_71 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_74:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T1 be TupleFINSEQ-2M3-of(i,D) holds  for T2 be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds ((F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F implies T1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*FINSEQOPK4\<^bsub>(D,D)\<^esub> T2 & (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*FINSEQOPK4\<^bsub>(D,D)\<^esub> T1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T2"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T1 be TupleFINSEQ-2M3-of(i,D) holds  for T2 be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds ((F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F implies T1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*FINSEQOPK4\<^bsub>(D,D)\<^esub> T2 & (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*FINSEQOPK4\<^bsub>(D,D)\<^esub> T1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix T1 assume [ty]: "T1 be TupleFINSEQ-2M3-of(i,D)"
    fix T2 assume [ty]: "T2 be TupleFINSEQ-2M3-of(i,D)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    assume A1: "((F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
    show "T1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*FINSEQOPK4\<^bsub>(D,D)\<^esub> T2 & (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*FINSEQOPK4\<^bsub>(D,D)\<^esub> T1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T2"
    proof-
      have cases: "i =HIDDENR1 0NUMBERSK6 or i <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "i =HIDDENR1 0NUMBERSK6 implies T1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*FINSEQOPK4\<^bsub>(D,D)\<^esub> T2 & (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*FINSEQOPK4\<^bsub>(D,D)\<^esub> T1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T2"
      proof(rule impI)
        assume "i =HIDDENR1 0NUMBERSK6"
        then have "T1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D & T2 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D"
           sorry
        thus "T1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*FINSEQOPK4\<^bsub>(D,D)\<^esub> T2 & (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*FINSEQOPK4\<^bsub>(D,D)\<^esub> T1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T2"
           sorry
      qed
      have case2: "i <>HIDDENR2 0NUMBERSK6 implies T1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*FINSEQOPK4\<^bsub>(D,D)\<^esub> T2 & (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*FINSEQOPK4\<^bsub>(D,D)\<^esub> T1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T2"
      proof(rule impI)
        assume "i <>HIDDENR2 0NUMBERSK6"
        then obtain C where 
          [ty]:"C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and CDef:"C = SegFINSEQ-1K1 i"
           sorry
        have "T1 be FunctionFUNCT-2M1-of(C,D) & T2 be FunctionFUNCT-2M1-of(C,D)"
          using finseqop_lm_4 sorry
        thus "T1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*FINSEQOPK4\<^bsub>(D,D)\<^esub> T2 & (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*FINSEQOPK4\<^bsub>(D,D)\<^esub> T1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> T2"
          using A1 finseqop_th_72 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_75:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e be ElementSUBSET-1M1-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds (((F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F implies G [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(e,f) =FUNCT-2R2\<^bsub>(C,D)\<^esub> C -->FUNCOP-1K8\<^bsub>(D)\<^esub> e"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e be ElementSUBSET-1M1-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds (((F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F implies G [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(e,f) =FUNCT-2R2\<^bsub>(C,D)\<^esub> C -->FUNCOP-1K8\<^bsub>(D)\<^esub> e"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix e assume [ty]: "e be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix G assume [ty]: "G be BinOpBINOP-1M2-of D"
    obtain g where 
      [ty]:"g be FunctionFUNCT-2M1-of(C,D)" and gDef:"g = C -->FUNCOP-1K8\<^bsub>(D)\<^esub> e"
       sorry
    assume A1: "(((F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F"
    have " for c be ElementSUBSET-1M1-of C holds (G [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(e,f)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 g .FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
    proof(rule ballI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      have "(G [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(e,f)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 G .BINOP-1K4\<^bsub>(D)\<^esub>(e,f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
        using funcop_1_th_53 sorry
      also have "... = e"
        using A1 finseqop_th_66 sorry
      also have "... = g .FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
        using funcop_1_th_7 sorry
      finally show "(G [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(e,f)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 g .FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
         sorry
    qed "sorry"
    thus "G [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(e,f) =FUNCT-2R2\<^bsub>(C,D)\<^esub> C -->FUNCOP-1K8\<^bsub>(D)\<^esub> e"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_76:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds (((F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F implies G [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(e,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> e"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e be ElementSUBSET-1M1-of D holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds (((F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F implies G [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(e,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> e"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix e assume [ty]: "e be ElementSUBSET-1M1-of D"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix T assume [ty]: "T be TupleFINSEQ-2M3-of(i,D)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix G assume [ty]: "G be BinOpBINOP-1M2-of D"
    assume A1: "(((F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F"
    show "G [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(e,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> e"
    proof-
      have cases: "i =HIDDENR1 0NUMBERSK6 or i <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "i =HIDDENR1 0NUMBERSK6 implies G [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(e,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> e"
      proof(rule impI)
        assume A2: "i =HIDDENR1 0NUMBERSK6"
        then have "G [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(e,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D"
          using finseqop_lm_2 sorry
        thus "G [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(e,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> e"
          using A2 sorry
      qed
      have case2: "i <>HIDDENR2 0NUMBERSK6 implies G [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(e,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> e"
      proof(rule impI)
        assume "i <>HIDDENR2 0NUMBERSK6"
        then obtain C where 
          [ty]:"C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and CDef:"C = SegFINSEQ-1K1 i"
           sorry
        have "T be FunctionFUNCT-2M1-of(C,D)"
          using finseqop_lm_4 sorry
        thus "G [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(e,T) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> e"
          using A1 finseqop_th_75 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef finseqop_def_4 (" _ *FINSEQOPK6'( _ , _ ')" [164,0,0]164 ) where
  mlet "F be FunctionFUNCT-1M1", "f be FunctionFUNCT-1M1", "g be FunctionFUNCT-1M1"
"func F *FINSEQOPK6(f,g) \<rightarrow> FunctionFUNCT-1M1 equals
  F *FUNCT-1K3 ([:FUNCT-3K16 f,g :])"
proof-
  (*coherence*)
    show "F *FUNCT-1K3 ([:FUNCT-3K16 f,g :]) be FunctionFUNCT-1M1"
       sorry
qed "sorry"

mtheorem finseqop_th_77:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for F be FunctionFUNCT-1M1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 (F *FINSEQOPK6(f,g)) implies (F *FINSEQOPK6(f,g)).BINOP-1K1(x,y) =XBOOLE-0R4 F .BINOP-1K1(f .FUNCT-1K1 x,g .FUNCT-1K1 y)"
proof-
  have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for F be FunctionFUNCT-1M1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 (F *FINSEQOPK6(f,g)) implies (F *FINSEQOPK6(f,g)).BINOP-1K1(x,y) =XBOOLE-0R4 F .BINOP-1K1(f .FUNCT-1K1 x,g .FUNCT-1K1 y)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    fix F assume [ty]: "F be FunctionFUNCT-1M1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "[TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 (F *FINSEQOPK6(f,g))"
    have "[TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 ([:FUNCT-3K16 f,g :])"
      using A1 funct_1_th_11 sorry
    then have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :]"
      using funct_3_def_8 sorry
    then have "([:FUNCT-3K16 f,g :]).BINOP-1K1(x,y) =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 y ]"
      using funct_3_th_65 sorry
    thus "(F *FINSEQOPK6(f,g)).BINOP-1K1(x,y) =XBOOLE-0R4 F .BINOP-1K1(f .FUNCT-1K1 x,g .FUNCT-1K1 y)"
      using A1 funct_1_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CT*)
mtheorem finseqop_th_79:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for g be FunctionFUNCT-2M1-of(C9,D9) holds F *FINSEQOPK6(f,g) be FunctionFUNCT-2M1-of([:ZFMISC-1K2 C,C9 :],E)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for g be FunctionFUNCT-2M1-of(C9,D9) holds F *FINSEQOPK6(f,g) be FunctionFUNCT-2M1-of([:ZFMISC-1K2 C,C9 :],E)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix C9 assume [ty]: "C9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D9 assume [ty]: "D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E)"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(C9,D9)"
    have "F *FINSEQOPK6(f,g) =FUNCT-1R1 F *PARTFUN1K1\<^bsub>([:ZFMISC-1K2 C,C9 :],[:ZFMISC-1K2 D,D9 :],[:ZFMISC-1K2 D,D9 :],E)\<^esub> ([:FUNCT-3K17\<^bsub>(C,C9,D,D9)\<^esub> f,g :])"
       sorry
    thus "F *FINSEQOPK6(f,g) be FunctionFUNCT-2M1-of([:ZFMISC-1K2 C,C9 :],E)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_80:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of D holds  for u be FunctionFUNCT-2M1-of(D,D) holds  for u9 be FunctionFUNCT-2M1-of(D,D) holds F *FINSEQOPK6(u,u9) be BinOpBINOP-1M2-of D"
  using finseqop_th_79 sorry

syntax FINSEQOPK7 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ *FINSEQOPK7\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [164,0,0,0]164)
translations "F *FINSEQOPK7\<^bsub>(D)\<^esub>(f,f9)" \<rightharpoonup> "F *FINSEQOPK6(f,f9)"

mtheorem finseqop_add_5:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be BinOpBINOP-1M2-of D", "f be FunctionFUNCT-2M1-of(D,D)", "f9 be FunctionFUNCT-2M1-of(D,D)"
"cluster F *FINSEQOPK6(f,f9) as-term-is BinOpBINOP-1M2-of D"
proof
(*coherence*)
  show "F *FINSEQOPK6(f,f9) be BinOpBINOP-1M2-of D"
    using finseqop_th_79 sorry
qed "sorry"

mtheorem finseqop_th_81:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for c9 be ElementSUBSET-1M1-of C9 holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for g be FunctionFUNCT-2M1-of(C9,D9) holds (F *FINSEQOPK6(f,g)).BINOP-1K1(c,c9) =XBOOLE-0R4 F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c,g .FUNCT-2K3\<^bsub>(C9,D9)\<^esub> c9)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for c9 be ElementSUBSET-1M1-of C9 holds  for F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E) holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for g be FunctionFUNCT-2M1-of(C9,D9) holds (F *FINSEQOPK6(f,g)).BINOP-1K1(c,c9) =XBOOLE-0R4 F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c,g .FUNCT-2K3\<^bsub>(C9,D9)\<^esub> c9)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix C9 assume [ty]: "C9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D9 assume [ty]: "D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix c9 assume [ty]: "c9 be ElementSUBSET-1M1-of C9"
    fix F assume [ty]: "F be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D,D9 :],E)"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(C9,D9)"
    let ?H = "F *FINSEQOPK6(f,g)"
    have "?H be FunctionFUNCT-2M1-of([:ZFMISC-1K2 C,C9 :],E)"
      using finseqop_th_79 sorry
    then have "domRELAT-1K1 ?H =XBOOLE-0R4 [:ZFMISC-1K2 C,C9 :]"
      using funct_2_def_1 sorry
    then have "[TARSKIK4 c,c9 ] inHIDDENR3 domRELAT-1K1 ?H"
      using zfmisc_1_def_2 sorry
    thus "(F *FINSEQOPK6(f,g)).BINOP-1K1(c,c9) =XBOOLE-0R4 F .BINOP-1K2\<^bsub>(D,D9,E)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c,g .FUNCT-2K3\<^bsub>(C9,D9)\<^esub> c9)"
      using finseqop_th_77 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_82:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for u be FunctionFUNCT-2M1-of(D,D) holds (F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,u)).BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d2) & (F *FINSEQOPK7\<^bsub>(D)\<^esub>(u,idPARTFUN1K6 D)).BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1,d2)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for u be FunctionFUNCT-2M1-of(D,D) holds (F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,u)).BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d2) & (F *FINSEQOPK7\<^bsub>(D)\<^esub>(u,idPARTFUN1K6 D)).BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1,d2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of D"
    fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix u assume [ty]: "u be FunctionFUNCT-2M1-of(D,D)"
    have "idPARTFUN1K6 D .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1 =XBOOLE-0R4 d1 & idPARTFUN1K6 D .FUNCT-2K3\<^bsub>(D,D)\<^esub> d2 =XBOOLE-0R4 d2"
       sorry
    thus "(F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,u)).BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d2) & (F *FINSEQOPK7\<^bsub>(D)\<^esub>(u,idPARTFUN1K6 D)).BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1,d2)"
      using finseqop_th_81 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_83:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for f9 be FunctionFUNCT-2M1-of(C,D) holds  for F be BinOpBINOP-1M2-of D holds  for u be UnOpBINOP-1M1-of D holds (F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,u)).:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9) =FUNCT-2R2\<^bsub>(C,D)\<^esub> F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,u *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f9)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for f9 be FunctionFUNCT-2M1-of(C,D) holds  for F be BinOpBINOP-1M2-of D holds  for u be UnOpBINOP-1M1-of D holds (F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,u)).:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9) =FUNCT-2R2\<^bsub>(C,D)\<^esub> F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,u *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f9)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
    fix f9 assume [ty]: "f9 be FunctionFUNCT-2M1-of(C,D)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix u assume [ty]: "u be UnOpBINOP-1M1-of D"
    have " for c be ElementSUBSET-1M1-of C holds ((F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,u)).:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 (F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,u *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f9)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
    proof(rule ballI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      have "((F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,u)).:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 (F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,u)).BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c,f9 .FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
        using funcop_1_th_37 sorry
      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c,u .FUNCT-2K3\<^bsub>(D,D)\<^esub> (f9 .FUNCT-2K3\<^bsub>(C,D)\<^esub> c))"
        using finseqop_th_82 sorry
      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c,(u *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f9).FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
        using funct_2_th_15 sorry
      also have "... = (F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,u *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f9)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
        using funcop_1_th_37 sorry
      finally show "((F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,u)).:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c =HIDDENR1 (F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,u *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f9)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
         sorry
    qed "sorry"
    thus "(F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,u)).:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9) =FUNCT-2R2\<^bsub>(C,D)\<^esub> F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,u *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f9)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_84:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T1 be TupleFINSEQ-2M3-of(i,D) holds  for T2 be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds  for u be UnOpBINOP-1M1-of D holds (F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,u)).:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,u *FINSEQOPK4\<^bsub>(D,D)\<^esub> T2)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for T1 be TupleFINSEQ-2M3-of(i,D) holds  for T2 be TupleFINSEQ-2M3-of(i,D) holds  for F be BinOpBINOP-1M2-of D holds  for u be UnOpBINOP-1M1-of D holds (F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,u)).:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,u *FINSEQOPK4\<^bsub>(D,D)\<^esub> T2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix T1 assume [ty]: "T1 be TupleFINSEQ-2M3-of(i,D)"
    fix T2 assume [ty]: "T2 be TupleFINSEQ-2M3-of(i,D)"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix u assume [ty]: "u be UnOpBINOP-1M1-of D"
    have "(F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,u)).:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,u *FINSEQOPK4\<^bsub>(D,D)\<^esub> T2)"
    proof-
      show "(F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,u)).:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,u *FINSEQOPK4\<^bsub>(D,D)\<^esub> T2)"
      proof-
        have cases: "i =HIDDENR1 0NUMBERSK6 or i <>HIDDENR2 0NUMBERSK6"
           sorry
        have case1: "i =HIDDENR1 0NUMBERSK6 implies (F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,u)).:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,u *FINSEQOPK4\<^bsub>(D,D)\<^esub> T2)"
        proof(rule impI)
          assume "i =HIDDENR1 0NUMBERSK6"
          then have "(F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,u)).:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D & u *FINSEQOPK4\<^bsub>(D,D)\<^esub> T2 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*>FINSEQ-1K7 D"
            using finseqop_lm_1 sorry
          thus "(F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,u)).:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,u *FINSEQOPK4\<^bsub>(D,D)\<^esub> T2)"
            using finseq_2_th_73 sorry
        qed
        have case2: "i <>HIDDENR2 0NUMBERSK6 implies (F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,u)).:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,u *FINSEQOPK4\<^bsub>(D,D)\<^esub> T2)"
        proof(rule impI)
          assume "i <>HIDDENR2 0NUMBERSK6"
          then obtain C where 
            [ty]:"C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and CDef:"C = SegFINSEQ-1K1 i"
             sorry
          have "T1 be FunctionFUNCT-2M1-of(C,D) & T2 be FunctionFUNCT-2M1-of(C,D)"
            using finseqop_lm_4 sorry
          thus "(F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,u)).:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,u *FINSEQOPK4\<^bsub>(D,D)\<^esub> T2)"
            using finseqop_th_83 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "(F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,u)).:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,u *FINSEQOPK4\<^bsub>(D,D)\<^esub> T2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_85:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for u be UnOpBINOP-1M1-of D holds (((F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & u =FUNCT-2R2\<^bsub>(D,D)\<^esub> the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F implies u .FUNCT-2K3\<^bsub>(D,D)\<^esub> ((F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,u)).BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 (F *FINSEQOPK7\<^bsub>(D)\<^esub>(u,idPARTFUN1K6 D)).BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2) & (F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,u)).BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2) =XBOOLE-0R4 u .FUNCT-2K3\<^bsub>(D,D)\<^esub> ((F *FINSEQOPK7\<^bsub>(D)\<^esub>(u,idPARTFUN1K6 D)).BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2))"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for u be UnOpBINOP-1M1-of D holds (F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & (F be commutativeBINOP-1V1\<^bsub>(D)\<^esub> & (F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> & u =FUNCT-2R2\<^bsub>(D,D)\<^esub> the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)) implies u .FUNCT-2K3\<^bsub>(D,D)\<^esub> ((F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,u)).BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =HIDDENR1 (F *FINSEQOPK7\<^bsub>(D)\<^esub>(u,idPARTFUN1K6 D)).BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2) & (F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,u)).BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2) =XBOOLE-0R4 u .FUNCT-2K3\<^bsub>(D,D)\<^esub> ((F *FINSEQOPK7\<^bsub>(D)\<^esub>(u,idPARTFUN1K6 D)).BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of D"
    fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix u assume [ty]: "u be UnOpBINOP-1M1-of D"
    assume A1: "F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
      and A2: "F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>"
      and A3: "F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> & u =FUNCT-2R2\<^bsub>(D,D)\<^esub> the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F"
    have A4: "u is-distributive-wrtBINOP-1R12\<^bsub>(D)\<^esub> F"
      using A1 A2 A3 finseqop_th_63 sorry
    have "u .FUNCT-2K3\<^bsub>(D,D)\<^esub> ((F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,u)).BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =HIDDENR1 u .FUNCT-2K3\<^bsub>(D,D)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d2))"
      using finseqop_th_82 sorry
    also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1,u .FUNCT-2K3\<^bsub>(D,D)\<^esub> (u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d2))"
      using A4 sorry
    also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1,d2)"
      using A1 A3 finseqop_th_62 sorry
    also have "... = (F *FINSEQOPK7\<^bsub>(D)\<^esub>(u,idPARTFUN1K6 D)).BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)"
      using finseqop_th_82 sorry
    finally show "u .FUNCT-2K3\<^bsub>(D,D)\<^esub> ((F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,u)).BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =HIDDENR1 (F *FINSEQOPK7\<^bsub>(D)\<^esub>(u,idPARTFUN1K6 D)).BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)"
       sorry
    thus "(F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,u)).BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2) =XBOOLE-0R4 u .FUNCT-2K3\<^bsub>(D,D)\<^esub> ((F *FINSEQOPK7\<^bsub>(D)\<^esub>(u,idPARTFUN1K6 D)).BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2))"
      using A1 A3 finseqop_th_62 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_86:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds (F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> implies (F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)).BINOP-1K4\<^bsub>(D)\<^esub>(d,d) =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds (F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> implies (F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)).BINOP-1K4\<^bsub>(D)\<^esub>(d,d) =HIDDENR1 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    assume A1: "(F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>"
    let ?u = "the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F"
    have "(F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)).BINOP-1K4\<^bsub>(D)\<^esub>(d,d) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(d,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d)"
      using finseqop_th_82 sorry
    also have "... = the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
      using A1 finseqop_th_59 sorry
    finally show "(F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)).BINOP-1K4\<^bsub>(D)\<^esub>(d,d) =HIDDENR1 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_87:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds (F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> implies (F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)).BINOP-1K4\<^bsub>(D)\<^esub>(d,the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) =XBOOLE-0R4 d"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & (F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) implies (F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)).BINOP-1K4\<^bsub>(D)\<^esub>(d,the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) =HIDDENR1 d"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    assume A1: "F be associativeBINOP-1V2\<^bsub>(D)\<^esub>"
      and A2: "F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
      and A3: "F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>"
    let ?u = "the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F"
    let ?e = "the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
    have "(F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)).BINOP-1K4\<^bsub>(D)\<^esub>(d,the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(d,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F)"
      using finseqop_th_82 sorry
    also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(d,the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F)"
      using A1 A2 A3 finseqop_th_61 sorry
    also have "... = d"
      using A2 setwiseo_th_15 sorry
    finally show "(F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)).BINOP-1K4\<^bsub>(D)\<^esub>(d,the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) =HIDDENR1 d"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_88:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for u be UnOpBINOP-1M1-of D holds F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies (F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,u)).BINOP-1K4\<^bsub>(D)\<^esub>(the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,d) =XBOOLE-0R4 u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for u be UnOpBINOP-1M1-of D holds F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies (F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,u)).BINOP-1K4\<^bsub>(D)\<^esub>(the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,d) =HIDDENR1 u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix u assume [ty]: "u be UnOpBINOP-1M1-of D"
    assume A1: "F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
    let ?e = "the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
    have "(F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,u)).BINOP-1K4\<^bsub>(D)\<^esub>(the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,d) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d)"
      using finseqop_th_82 sorry
    also have "... = u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d"
      using A1 setwiseo_th_15 sorry
    finally show "(F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,u)).BINOP-1K4\<^bsub>(D)\<^esub>(the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,d) =HIDDENR1 u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseqop_th_89:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds (((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & G =BINOP-1R13\<^bsub>(D,D,D)\<^esub> F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F) implies ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for d3 be ElementSUBSET-1M1-of D holds  for d4 be ElementSUBSET-1M1-of D holds F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),G .BINOP-1K4\<^bsub>(D)\<^esub>(d3,d4)) =XBOOLE-0R4 G .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d3),F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d4)))"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds F be commutativeBINOP-1V1\<^bsub>(D)\<^esub> & (F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & ((F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & G =BINOP-1R13\<^bsub>(D,D,D)\<^esub> F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F))) implies ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for d3 be ElementSUBSET-1M1-of D holds  for d4 be ElementSUBSET-1M1-of D holds F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),G .BINOP-1K4\<^bsub>(D)\<^esub>(d3,d4)) =HIDDENR1 G .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d3),F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d4)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix G assume [ty]: "G be BinOpBINOP-1M2-of D"
    assume A1: "F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>"
      and A2: "F be associativeBINOP-1V2\<^bsub>(D)\<^esub>"
      and A3: "F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>"
      and A4: "G =BINOP-1R13\<^bsub>(D,D,D)\<^esub> F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)"
    let ?u = "the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F"
    have A5: "?u is-distributive-wrtBINOP-1R12\<^bsub>(D)\<^esub> F"
      using A1 A2 A3 finseqop_th_63 sorry
    fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of D"
    fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of D"
    fix d3 assume [ty]: "d3 be ElementSUBSET-1M1-of D"
    fix d4 assume [ty]: "d4 be ElementSUBSET-1M1-of D"
    have "F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),G .BINOP-1K4\<^bsub>(D)\<^esub>(d3,d4)) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d2),G .BINOP-1K4\<^bsub>(D)\<^esub>(d3,d4))"
      using A4 finseqop_th_82 sorry
    also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d2),F .BINOP-1K4\<^bsub>(D)\<^esub>(d3,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d4))"
      using A4 finseqop_th_82 sorry
    also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,F .BINOP-1K4\<^bsub>(D)\<^esub>((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d2,F .BINOP-1K4\<^bsub>(D)\<^esub>(d3,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d4)))"
      using A2 sorry
    also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d2,d3),(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d4))"
      using A2 sorry
    also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d3,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d2),(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d4))"
      using A1 sorry
    also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,F .BINOP-1K4\<^bsub>(D)\<^esub>(d3,F .BINOP-1K4\<^bsub>(D)\<^esub>((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d2,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d4)))"
      using A2 sorry
    also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d3),F .BINOP-1K4\<^bsub>(D)\<^esub>((the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d2,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> d4))"
      using A2 sorry
    also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d3),(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d4)))"
      using A5 sorry
    also have "... = G .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d3),F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d4))"
      using A4 finseqop_th_82 sorry
    finally show "F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),G .BINOP-1K4\<^bsub>(D)\<^esub>(d3,d4)) =HIDDENR1 G .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d3),F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d4))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
