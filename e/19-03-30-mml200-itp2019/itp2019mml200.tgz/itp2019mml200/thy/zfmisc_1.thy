theory zfmisc_1
  imports xregular 
begin
(*begin*)
reserve u, v, x, x1, x2, y, y1, y2, z, p, a for "objectHIDDENM1"
reserve A, B, X, X1, X2, X3, X4, Y, Y1, Y2, Z, N, M for "setHIDDENM2"
mlemma zfmisc_1_lm_1:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds {TARSKIK1 x} c=TARSKIR1 X iff x inHIDDENR3 X"
proof-
  have " for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds ({TARSKIK1 x} c=TARSKIR1 X implies x inHIDDENR3 X) & (x inHIDDENR3 X implies {TARSKIK1 x} c=TARSKIR1 X)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    have "x inHIDDENR3 {TARSKIK1 x}"
      using tarski_def_1 sorry
    thus "{TARSKIK1 x} c=TARSKIR1 X implies x inHIDDENR3 X"
       sorry
    assume A1: "x inHIDDENR3 X"
    have " for y be objectHIDDENM1 holds  not (y inHIDDENR3 {TARSKIK1 x} &  not y inHIDDENR3 X)"
    proof(rule ballI)
      fix y assume [ty]: "y be objectHIDDENM1"
      show " not (y inHIDDENR3 {TARSKIK1 x} &  not y inHIDDENR3 X)"
        using A1 tarski_def_1 sorry
    qed "sorry"
    thus "{TARSKIK1 x} c=TARSKIR1 X"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma zfmisc_1_lm_2:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds Y c=TARSKIR1 X &  not x inHIDDENR3 Y implies Y c=TARSKIR1 X \\XBOOLE-0K4 {TARSKIK1 x}"
proof-
  have " for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds Y c=TARSKIR1 X &  not x inHIDDENR3 Y implies Y c=TARSKIR1 X \\XBOOLE-0K4 {TARSKIK1 x}"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "Y c=TARSKIR1 X &  not x inHIDDENR3 Y"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Y implies y inHIDDENR3 X \\XBOOLE-0K4 {TARSKIK1 x}"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 Y"
      then have "y inHIDDENR3 X &  not y inHIDDENR3 {TARSKIK1 x}"
        using A1 tarski_def_1 sorry
      thus "y inHIDDENR3 X \\XBOOLE-0K4 {TARSKIK1 x}"
        using xboole_0_def_5 sorry
    qed "sorry"
    thus "Y c=TARSKIR1 X \\XBOOLE-0K4 {TARSKIK1 x}"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma zfmisc_1_lm_3:
" for x be objectHIDDENM1 holds  for Y be setHIDDENM2 holds Y c=TARSKIR1 {TARSKIK1 x} iff Y =XBOOLE-0R4 {}XBOOLE-0K1 or Y =XBOOLE-0R4 {TARSKIK1 x}"
proof-
  have " for x be objectHIDDENM1 holds  for Y be setHIDDENM2 holds (Y c=TARSKIR1 {TARSKIK1 x} implies Y =XBOOLE-0R4 {}XBOOLE-0K1 or Y =XBOOLE-0R4 {TARSKIK1 x}) &  not ( not ( not Y =XBOOLE-0R4 {}XBOOLE-0K1 &  not Y =XBOOLE-0R4 {TARSKIK1 x}) &  not Y c=TARSKIR1 {TARSKIK1 x})"
  proof(rule ballI,rule ballI,rule conjMI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix Y assume [ty]: "Y be setHIDDENM2"
    show "Y c=TARSKIR1 {TARSKIK1 x} implies Y =XBOOLE-0R4 {}XBOOLE-0K1 or Y =XBOOLE-0R4 {TARSKIK1 x}"
    proof-
      have "Y c=TARSKIR1 {TARSKIK1 x} implies  not ( not Y =XBOOLE-0R4 {}XBOOLE-0K1 &  not Y =XBOOLE-0R4 {TARSKIK1 x})"
      proof(rule impI)
        assume A1: "Y c=TARSKIR1 {TARSKIK1 x}"
        have "x inHIDDENR3 Y or  not x inHIDDENR3 Y"
           sorry
        then have "{TARSKIK1 x} c=TARSKIR1 Y or Y c=TARSKIR1 {TARSKIK1 x} \\XBOOLE-0K4 {TARSKIK1 x}"
          using A1 zfmisc_1_lm_1 zfmisc_1_lm_2 sorry
        then have "{TARSKIK1 x} =XBOOLE-0R4 Y or Y c=TARSKIR1 {}XBOOLE-0K1"
          using A1 xboole_1_th_37 sorry
        thus " not ( not Y =XBOOLE-0R4 {}XBOOLE-0K1 &  not Y =XBOOLE-0R4 {TARSKIK1 x})"
          using xboole_1_th_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    show " not ( not ( not Y =XBOOLE-0R4 {}XBOOLE-0K1 &  not Y =XBOOLE-0R4 {TARSKIK1 x}) &  not Y c=TARSKIR1 {TARSKIK1 x})"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef zfmisc_1_def_1 ("boolZFMISC-1K1  _ " [228]228 ) where
  mlet "X be setHIDDENM2"
"func boolZFMISC-1K1 X \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for Z be setHIDDENM2 holds Z inTARSKIR2 it iff Z c=TARSKIR1 X"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for Z be setHIDDENM2 holds Z inTARSKIR2 it iff Z c=TARSKIR1 X"
    proof-
      let ?IT = "\<lambda>Lamb1. Lamb1 c=TARSKIR1 X"
      show " ex it be setHIDDENM2 st  for Z be setHIDDENM2 holds Z inTARSKIR2 it iff Z c=TARSKIR1 X"
      proof-
        have " ex tVar1 be setHIDDENM2 st  for Z be setHIDDENM2 holds  not (Z inTARSKIR2 tVar1 &  not Z c=TARSKIR1 X) &  not (Z c=TARSKIR1 X &  not Z inTARSKIR2 tVar1)"
        proof-
          obtain M where
            [ty]:"M be setHIDDENM2" and 
            A1: "X inTARSKIR2 M & ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 M & Y c=TARSKIR1 X implies Y inTARSKIR2 M)"and " for X be setHIDDENM2 holds X inTARSKIR2 M implies ( ex Z be setHIDDENM2 st Z inTARSKIR2 M & ( for Y be setHIDDENM2 holds Y c=TARSKIR1 X implies Y inTARSKIR2 Z))"and " for X be setHIDDENM2 holds X c=TARSKIR1 M implies (X,M)are-equipotentTARSKIR3 or X inTARSKIR2 M"
            using tarski_a_th_1 sorry
          obtain IT where
            [ty]:"IT be setHIDDENM2" and 
            A2: " for Y be setHIDDENM2 holds Y inTARSKIR2 IT iff Y inTARSKIR2 M & ?IT(Y)"
            using xfamily_sch_1 sorry
          show " ex tVar1 be setHIDDENM2 st  for Z be setHIDDENM2 holds  not (Z inTARSKIR2 tVar1 &  not Z c=TARSKIR1 X) &  not (Z c=TARSKIR1 X &  not Z inTARSKIR2 tVar1)"
          proof(rule bexI[of _ "IT"])
            show " for Z be setHIDDENM2 holds  not (Z inTARSKIR2 IT &  not Z c=TARSKIR1 X) &  not (Z c=TARSKIR1 X &  not Z inTARSKIR2 IT)"
              using A2 A1 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for Z be setHIDDENM2 holds Z inTARSKIR2 it1 iff Z c=TARSKIR1 X) & ( for Z be setHIDDENM2 holds Z inTARSKIR2 it2 iff Z c=TARSKIR1 X) implies it1 =HIDDENR1 it2"
    proof-
      let ?IT = "\<lambda>Lamb1. Lamb1 c=TARSKIR1 X"
      show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for Z be setHIDDENM2 holds Z inTARSKIR2 it1 iff Z c=TARSKIR1 X) & ( for Z be setHIDDENM2 holds Z inTARSKIR2 it2 iff Z c=TARSKIR1 X) implies it1 =HIDDENR1 it2"
      proof-
        have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds ( for x be setHIDDENM2 holds x inTARSKIR2 X1 iff x c=TARSKIR1 X) & ( for x be setHIDDENM2 holds x inTARSKIR2 X2 iff x c=TARSKIR1 X) implies X1 =XBOOLE-0R4 X2"
        proof-
          show " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds ( for x be setHIDDENM2 holds x inTARSKIR2 X1 iff x c=TARSKIR1 X) & ( for x be setHIDDENM2 holds x inTARSKIR2 X2 iff x c=TARSKIR1 X) implies X1 =XBOOLE-0R4 X2"
            using xfamily_sch_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mdef zfmisc_1_def_2 ("[:ZFMISC-1K2 _ , _ :]" [0,0]164 ) where
  mlet "X1 be setHIDDENM2", "X2 be setHIDDENM2"
"func [:ZFMISC-1K2 X1,X2 :] \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for z be objectHIDDENM1 holds z inHIDDENR3 it iff ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st (x inHIDDENR3 X1 & y inHIDDENR3 X2) & z =HIDDENR1 [TARSKIK4 x,y ])"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for z be objectHIDDENM1 holds z inHIDDENR3 it iff ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st (x inHIDDENR3 X1 & y inHIDDENR3 X2) & z =HIDDENR1 [TARSKIK4 x,y ])"
    proof-
      let ?X = "\<lambda>Lamb1.  ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st (x inHIDDENR3 X1 & y inHIDDENR3 X2) & Lamb1 =HIDDENR1 [TARSKIK4 x,y ]"
      show " ex it be setHIDDENM2 st  for z be objectHIDDENM1 holds z inHIDDENR3 it iff ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st (x inHIDDENR3 X1 & y inHIDDENR3 X2) & z =HIDDENR1 [TARSKIK4 x,y ])"
      proof-
        have " ex tVar2 be setHIDDENM2 st  for z be objectHIDDENM1 holds (z inHIDDENR3 tVar2 implies ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st (x inHIDDENR3 X1 & y inHIDDENR3 X2) & z =HIDDENR1 [TARSKIK4 x,y ])) & (( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st (x inHIDDENR3 X1 & y inHIDDENR3 X2) & z =HIDDENR1 [TARSKIK4 x,y ]) implies z inHIDDENR3 tVar2)"
        proof-
          have A1: "X1 c=TARSKIR1 X1 \\/XBOOLE-0K2 X2"
            using xboole_1_th_7 sorry
          obtain X where
            [ty]:"X be setHIDDENM2" and 
            A2: " for z be objectHIDDENM1 holds z inHIDDENR3 X iff z inHIDDENR3 boolZFMISC-1K1 (boolZFMISC-1K1 (X1 \\/XBOOLE-0K2 X2)) & ?X(z)"
            using xboole_0_sch_1 sorry
          show " ex tVar2 be setHIDDENM2 st  for z be objectHIDDENM1 holds (z inHIDDENR3 tVar2 implies ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st (x inHIDDENR3 X1 & y inHIDDENR3 X2) & z =HIDDENR1 [TARSKIK4 x,y ])) & (( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st (x inHIDDENR3 X1 & y inHIDDENR3 X2) & z =HIDDENR1 [TARSKIK4 x,y ]) implies z inHIDDENR3 tVar2)"
          proof(rule bexI[of _ "X"],rule ballI,rule conjMI,rule impI)
            fix z assume [ty]: "z be objectHIDDENM1"
            show "z inHIDDENR3 X implies ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st (x inHIDDENR3 X1 & y inHIDDENR3 X2) & z =HIDDENR1 [TARSKIK4 x,y ])"
              using A2 sorry
            assume Given: " ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st (x inHIDDENR3 X1 & y inHIDDENR3 X2) & z =HIDDENR1 [TARSKIK4 x,y ]"
            then obtain x y where
              [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
              A3: "x inHIDDENR3 X1"and A4: "y inHIDDENR3 X2"and A5: "z =HIDDENR1 [TARSKIK4 x,y ]"
               sorry
            have "{TARSKIK2 x,y } c=TARSKIR1 X1 \\/XBOOLE-0K2 X2"
            proof-
              have " for z be objectHIDDENM1 holds z inHIDDENR3 {TARSKIK2 x,y } implies z inHIDDENR3 X1 \\/XBOOLE-0K2 X2"
              proof(rule ballI,rule impI)
                fix z assume [ty]: "z be objectHIDDENM1"
                assume "z inHIDDENR3 {TARSKIK2 x,y }"
                then have "z =HIDDENR1 x or z =HIDDENR1 y"
                  using tarski_def_2 sorry
                thus "z inHIDDENR3 X1 \\/XBOOLE-0K2 X2"
                  using A3 A4 xboole_0_def_3 sorry
              qed "sorry"
              thus "{TARSKIK2 x,y } c=TARSKIR1 X1 \\/XBOOLE-0K2 X2"
                using tarski_def_3 sorry
            qed
            then have A6: "{TARSKIK2 x,y } inTARSKIR2 boolZFMISC-1K1 (X1 \\/XBOOLE-0K2 X2)"
              using zfmisc_1_def_1 sorry
            have "{TARSKIK1 x} c=TARSKIR1 X1 \\/XBOOLE-0K2 X2"
              using A1 A3 zfmisc_1_lm_1 sorry
            then have A7: "{TARSKIK1 x} inTARSKIR2 boolZFMISC-1K1 (X1 \\/XBOOLE-0K2 X2)"
              using zfmisc_1_def_1 sorry
            have "{TARSKIK2 {TARSKIK2 x,y },{TARSKIK1 x} } c=TARSKIR1 boolZFMISC-1K1 (X1 \\/XBOOLE-0K2 X2)"
              using A7 A6 tarski_def_2 sorry
            then have "{TARSKIK2 {TARSKIK2 x,y },{TARSKIK1 x} } inTARSKIR2 boolZFMISC-1K1 (boolZFMISC-1K1 (X1 \\/XBOOLE-0K2 X2))"
              using zfmisc_1_def_1 sorry
            thus "z inHIDDENR3 X"
              using A2 A3 A4 A5 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for z be objectHIDDENM1 holds z inHIDDENR3 it1 iff ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st (x inHIDDENR3 X1 & y inHIDDENR3 X2) & z =HIDDENR1 [TARSKIK4 x,y ])) & ( for z be objectHIDDENM1 holds z inHIDDENR3 it2 iff ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st (x inHIDDENR3 X1 & y inHIDDENR3 X2) & z =HIDDENR1 [TARSKIK4 x,y ])) implies it1 =HIDDENR1 it2"
    proof-
      let ?X = "\<lambda>Lamb1.  ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st (x inHIDDENR3 X1 & y inHIDDENR3 X2) & Lamb1 =HIDDENR1 [TARSKIK4 x,y ]"
      show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for z be objectHIDDENM1 holds z inHIDDENR3 it1 iff ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st (x inHIDDENR3 X1 & y inHIDDENR3 X2) & z =HIDDENR1 [TARSKIK4 x,y ])) & ( for z be objectHIDDENM1 holds z inHIDDENR3 it2 iff ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st (x inHIDDENR3 X1 & y inHIDDENR3 X2) & z =HIDDENR1 [TARSKIK4 x,y ])) implies it1 =HIDDENR1 it2"
      proof-
        have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 X1 iff ( ex xc be objectHIDDENM1 st  ex y be objectHIDDENM1 st (xc inHIDDENR3 X1 & y inHIDDENR3 X2) & x =HIDDENR1 [TARSKIK4 xc,y ])) & ( for x be objectHIDDENM1 holds x inHIDDENR3 X2 iff ( ex xc be objectHIDDENM1 st  ex y be objectHIDDENM1 st (xc inHIDDENR3 X1 & y inHIDDENR3 X2) & x =HIDDENR1 [TARSKIK4 xc,y ])) implies X1 =XBOOLE-0R4 X2"
        proof-
          show " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 X1 iff ( ex xc be objectHIDDENM1 st  ex y be objectHIDDENM1 st (xc inHIDDENR3 X1 & y inHIDDENR3 X2) & x =HIDDENR1 [TARSKIK4 xc,y ])) & ( for x be objectHIDDENM1 holds x inHIDDENR3 X2 iff ( ex xc be objectHIDDENM1 st  ex y be objectHIDDENM1 st (xc inHIDDENR3 X1 & y inHIDDENR3 X2) & x =HIDDENR1 [TARSKIK4 xc,y ])) implies X1 =XBOOLE-0R4 X2"
            using xboole_0_sch_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mdef zfmisc_1_def_3 ("[:ZFMISC-1K3 _ , _ , _ :]" [0,0,0]164 ) where
  mlet "X1 be setHIDDENM2", "X2 be setHIDDENM2", "X3 be setHIDDENM2"
"func [:ZFMISC-1K3 X1,X2,X3 :] \<rightarrow> setHIDDENM2 equals
  [:ZFMISC-1K2 [:ZFMISC-1K2 X1,X2 :],X3 :]"
proof-
  (*coherence*)
    show "[:ZFMISC-1K2 [:ZFMISC-1K2 X1,X2 :],X3 :] be setHIDDENM2"
       sorry
qed "sorry"

mdef zfmisc_1_def_4 ("[:ZFMISC-1K4 _ , _ , _ , _ :]" [0,0,0,0]164 ) where
  mlet "X1 be setHIDDENM2", "X2 be setHIDDENM2", "X3 be setHIDDENM2", "X4 be setHIDDENM2"
"func [:ZFMISC-1K4 X1,X2,X3,X4 :] \<rightarrow> setHIDDENM2 equals
  [:ZFMISC-1K2 [:ZFMISC-1K3 X1,X2,X3 :],X4 :]"
proof-
  (*coherence*)
    show "[:ZFMISC-1K2 [:ZFMISC-1K3 X1,X2,X3 :],X4 :] be setHIDDENM2"
       sorry
qed "sorry"

(*begin*)
mtheorem zfmisc_1_th_1:
"boolZFMISC-1K1 ({}XBOOLE-0K1) =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
proof-
  have " for x be objectHIDDENM1 holds x inHIDDENR3 boolZFMISC-1K1 ({}XBOOLE-0K1) iff x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
  proof(rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    obtain xx where 
      [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
      using tarski_th_1 sorry
    have "xx c=TARSKIR1 {}XBOOLE-0K1 iff x =HIDDENR1 {}XBOOLE-0K1"
      using xboole_1_th_3 sorry
    thus "x inHIDDENR3 boolZFMISC-1K1 ({}XBOOLE-0K1) iff x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
      using zfmisc_1_def_1 tarski_def_1 sorry
  qed "sorry"
  thus "boolZFMISC-1K1 ({}XBOOLE-0K1) =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
    using tarski_th_2 sorry
qed

mtheorem zfmisc_1_th_2:
"unionTARSKIK3 ({}XBOOLE-0K1) =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have "( ex x be objectHIDDENM1 st x inHIDDENR3 unionTARSKIK3 ({}XBOOLE-0K1)) implies  False "
  proof(rule impI)
    assume Given: " ex x be objectHIDDENM1 st x inHIDDENR3 unionTARSKIK3 ({}XBOOLE-0K1)"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A1: "x inHIDDENR3 unionTARSKIK3 ({}XBOOLE-0K1)"
       sorry
    have " ex X be setHIDDENM2 st x inHIDDENR3 X & X inTARSKIR2 {}XBOOLE-0K1"
      using A1 tarski_def_4 sorry
    thus " False "
       sorry
  qed
  thus "unionTARSKIK3 ({}XBOOLE-0K1) =XBOOLE-0R4 {}XBOOLE-0K1"
    using xboole_0_th_7 sorry
qed

mtheorem zfmisc_1_th_3:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds {TARSKIK1 x} c=TARSKIR1 {TARSKIK1 y} implies x =HIDDENR1 y"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ({TARSKIK1 x} c=TARSKIR1 {TARSKIK1 y} &  not x =HIDDENR1 y)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    have "x inHIDDENR3 {TARSKIK1 x}"
      using tarski_def_1 sorry
    then have "{TARSKIK1 x} =XBOOLE-0R4 {TARSKIK1 y} implies x =HIDDENR1 y"
      using tarski_def_1 sorry
    thus " not ({TARSKIK1 x} c=TARSKIR1 {TARSKIK1 y} &  not x =HIDDENR1 y)"
      using zfmisc_1_lm_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_4:
" for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds {TARSKIK1 x} =XBOOLE-0R4 {TARSKIK2 y1,y2 } implies x =HIDDENR1 y1"
proof-
  have " for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds {TARSKIK1 x} =XBOOLE-0R4 {TARSKIK2 y1,y2 } implies x =HIDDENR1 y1"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y1 assume [ty]: "y1 be objectHIDDENM1"
    fix y2 assume [ty]: "y2 be objectHIDDENM1"
    assume "{TARSKIK1 x} =XBOOLE-0R4 {TARSKIK2 y1,y2 }"
    then have "y1 inHIDDENR3 {TARSKIK1 x}"
      using tarski_def_2 sorry
    thus "x =HIDDENR1 y1"
      using tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_5:
" for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds {TARSKIK1 x} =XBOOLE-0R4 {TARSKIK2 y1,y2 } implies y1 =HIDDENR1 y2"
proof-
  have " for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds {TARSKIK1 x} =XBOOLE-0R4 {TARSKIK2 y1,y2 } implies y1 =HIDDENR1 y2"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y1 assume [ty]: "y1 be objectHIDDENM1"
    fix y2 assume [ty]: "y2 be objectHIDDENM1"
    assume A1: "{TARSKIK1 x} =XBOOLE-0R4 {TARSKIK2 y1,y2 }"
    then have "x =HIDDENR1 y1"
      using zfmisc_1_th_4 sorry
    thus "y1 =HIDDENR1 y2"
      using A1 zfmisc_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_6:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds {TARSKIK2 x1,x2 } =XBOOLE-0R4 {TARSKIK2 y1,y2 } implies x1 =HIDDENR1 y1 or x1 =HIDDENR1 y2"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  not (({TARSKIK2 x1,x2 } =XBOOLE-0R4 {TARSKIK2 y1,y2 } &  not x1 =HIDDENR1 y1) &  not x1 =HIDDENR1 y2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix y1 assume [ty]: "y1 be objectHIDDENM1"
    fix y2 assume [ty]: "y2 be objectHIDDENM1"
    have "x1 inHIDDENR3 {TARSKIK2 x1,x2 }"
      using tarski_def_2 sorry
    thus " not (({TARSKIK2 x1,x2 } =XBOOLE-0R4 {TARSKIK2 y1,y2 } &  not x1 =HIDDENR1 y1) &  not x1 =HIDDENR1 y2)"
      using tarski_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_7:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds {TARSKIK1 x} c=TARSKIR1 {TARSKIK2 x,y }"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds {TARSKIK1 x} c=TARSKIR1 {TARSKIK2 x,y }"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    have " for z be objectHIDDENM1 holds z inHIDDENR3 {TARSKIK1 x} implies z inHIDDENR3 {TARSKIK2 x,y }"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be objectHIDDENM1"
      assume "z inHIDDENR3 {TARSKIK1 x}"
      then have "z =HIDDENR1 x"
        using tarski_def_1 sorry
      thus "z inHIDDENR3 {TARSKIK2 x,y }"
        using tarski_def_2 sorry
    qed "sorry"
    thus "{TARSKIK1 x} c=TARSKIR1 {TARSKIK2 x,y }"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma zfmisc_1_lm_4:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds {TARSKIK1 x} \\/XBOOLE-0K2 X c=TARSKIR1 X implies x inHIDDENR3 X"
proof-
  have " for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds {TARSKIK1 x} \\/XBOOLE-0K2 X c=TARSKIR1 X implies ( not x inHIDDENR3 X implies  not  True )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "{TARSKIK1 x} \\/XBOOLE-0K2 X c=TARSKIR1 X"
    assume " not x inHIDDENR3 X"
    then have " not x inHIDDENR3 {TARSKIK1 x} \\/XBOOLE-0K2 X"
      using A1 sorry
    then have " not x inHIDDENR3 {TARSKIK1 x}"
      using xboole_0_def_3 sorry
    thus " not  True "
      using tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_8:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds {TARSKIK1 x} \\/XBOOLE-0K2 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 x} implies x =HIDDENR1 y"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds {TARSKIK1 x} \\/XBOOLE-0K2 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 x} implies x =HIDDENR1 y"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    assume "{TARSKIK1 x} \\/XBOOLE-0K2 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 x}"
    then have "y inHIDDENR3 {TARSKIK1 x} or x inHIDDENR3 {TARSKIK1 y}"
      using zfmisc_1_lm_4 sorry
    thus "x =HIDDENR1 y"
      using tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_9:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds {TARSKIK1 x} \\/XBOOLE-0K2 {TARSKIK2 x,y } =XBOOLE-0R4 {TARSKIK2 x,y }"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds {TARSKIK1 x} \\/XBOOLE-0K2 {TARSKIK2 x,y } =XBOOLE-0R4 {TARSKIK2 x,y }"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    have "x inHIDDENR3 {TARSKIK2 x,y }"
      using tarski_def_2 sorry
    thus "{TARSKIK1 x} \\/XBOOLE-0K2 {TARSKIK2 x,y } =XBOOLE-0R4 {TARSKIK2 x,y }"
      using zfmisc_1_lm_1 xboole_1_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma zfmisc_1_lm_5:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds {TARSKIK1 x} missesXBOOLE-0R1 X implies  not x inHIDDENR3 X"
proof-
  have " for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  not ({TARSKIK1 x} missesXBOOLE-0R1 X & x inHIDDENR3 X)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    have A1: "x inHIDDENR3 {TARSKIK1 x}"
      using tarski_def_1 sorry
    have "{TARSKIK1 x} /\\XBOOLE-0K3 X =XBOOLE-0R4 {}XBOOLE-0K1 & x inHIDDENR3 X implies  False "
    proof(rule impI)
      assume "{TARSKIK1 x} /\\XBOOLE-0K3 X =XBOOLE-0R4 {}XBOOLE-0K1 & x inHIDDENR3 X"
      thus " False "
        using A1 xboole_0_def_4 sorry
    qed
    thus " not ({TARSKIK1 x} missesXBOOLE-0R1 X & x inHIDDENR3 X)"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_10:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds {TARSKIK1 x} missesXBOOLE-0R1 {TARSKIK1 y} implies x <>HIDDENR2 y"
   sorry

mlemma zfmisc_1_lm_6:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  not x inHIDDENR3 X implies {TARSKIK1 x} missesXBOOLE-0R1 X"
proof-
  have " for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  not x inHIDDENR3 X implies {TARSKIK1 x} missesXBOOLE-0R1 X"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: " not x inHIDDENR3 X"
    have "{TARSKIK1 x} /\\XBOOLE-0K3 X c=TARSKIR1 {}XBOOLE-0K1 & {}XBOOLE-0K1 c=TARSKIR1 {TARSKIK1 x} /\\XBOOLE-0K3 X"
    proof(rule conjMI)
      show "{TARSKIK1 x} /\\XBOOLE-0K3 X c=TARSKIR1 {}XBOOLE-0K1"
      proof-
        have " for y be objectHIDDENM1 holds y inHIDDENR3 {TARSKIK1 x} /\\XBOOLE-0K3 X implies y inHIDDENR3 {}XBOOLE-0K1"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "y inHIDDENR3 {TARSKIK1 x} /\\XBOOLE-0K3 X"
          then have "y inHIDDENR3 {TARSKIK1 x} & y inHIDDENR3 X"
            using xboole_0_def_4 sorry
          thus "y inHIDDENR3 {}XBOOLE-0K1"
            using A1 tarski_def_1 sorry
        qed "sorry"
        thus "{TARSKIK1 x} /\\XBOOLE-0K3 X c=TARSKIR1 {}XBOOLE-0K1"
          using tarski_def_3 sorry
      qed
      show "{}XBOOLE-0K1 c=TARSKIR1 {TARSKIK1 x} /\\XBOOLE-0K3 X"
         sorry
    qed
    thus "{TARSKIK1 x} missesXBOOLE-0R1 X"
      using xboole_0_def_7 xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_11:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x <>HIDDENR2 y implies {TARSKIK1 x} missesXBOOLE-0R1 {TARSKIK1 y}"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x <>HIDDENR2 y implies {TARSKIK1 x} missesXBOOLE-0R1 {TARSKIK1 y}"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    assume "x <>HIDDENR2 y"
    then have " not x inHIDDENR3 {TARSKIK1 y}"
      using tarski_def_1 sorry
    thus "{TARSKIK1 x} missesXBOOLE-0R1 {TARSKIK1 y}"
      using zfmisc_1_lm_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma zfmisc_1_lm_7:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds X /\\XBOOLE-0K3 {TARSKIK1 x} =XBOOLE-0R4 {TARSKIK1 x} implies x inHIDDENR3 X"
proof-
  have " for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds X /\\XBOOLE-0K3 {TARSKIK1 x} =XBOOLE-0R4 {TARSKIK1 x} implies x inHIDDENR3 X"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    assume "X /\\XBOOLE-0K3 {TARSKIK1 x} =XBOOLE-0R4 {TARSKIK1 x}"
    then have "x inHIDDENR3 X /\\XBOOLE-0K3 {TARSKIK1 x}"
      using tarski_def_1 sorry
    thus "x inHIDDENR3 X"
      using xboole_0_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_12:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds {TARSKIK1 x} /\\XBOOLE-0K3 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 x} implies x =HIDDENR1 y"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds {TARSKIK1 x} /\\XBOOLE-0K3 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 x} implies x =HIDDENR1 y"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    assume "{TARSKIK1 x} /\\XBOOLE-0K3 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 x}"
    then have "x inHIDDENR3 {TARSKIK1 y} or y inHIDDENR3 {TARSKIK1 x}"
      using zfmisc_1_lm_7 sorry
    thus "x =HIDDENR1 y"
      using tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma zfmisc_1_lm_8:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds x inHIDDENR3 X implies X /\\XBOOLE-0K3 {TARSKIK1 x} =XBOOLE-0R4 {TARSKIK1 x}"
  using zfmisc_1_lm_1 xboole_1_th_28 sorry

mtheorem zfmisc_1_th_13:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds {TARSKIK1 x} /\\XBOOLE-0K3 {TARSKIK2 x,y } =XBOOLE-0R4 {TARSKIK1 x}"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds {TARSKIK1 x} /\\XBOOLE-0K3 {TARSKIK2 x,y } =XBOOLE-0R4 {TARSKIK1 x}"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    have "x inHIDDENR3 {TARSKIK2 x,y }"
      using tarski_def_2 sorry
    thus "{TARSKIK1 x} /\\XBOOLE-0K3 {TARSKIK2 x,y } =XBOOLE-0R4 {TARSKIK1 x}"
      using zfmisc_1_lm_1 xboole_1_th_28 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma zfmisc_1_lm_9:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds {TARSKIK1 x} \\XBOOLE-0K4 X =XBOOLE-0R4 {TARSKIK1 x} iff  not x inHIDDENR3 X"
  using zfmisc_1_lm_5 zfmisc_1_lm_6 xboole_1_th_83 sorry

mtheorem zfmisc_1_th_14:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds {TARSKIK1 x} \\XBOOLE-0K4 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 x} iff x <>HIDDENR2 y"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ({TARSKIK1 x} \\XBOOLE-0K4 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 x} & x <>HIDDENR2 y) &  not ( not x <>HIDDENR2 y &  not {TARSKIK1 x} \\XBOOLE-0K4 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 x})"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    have "{TARSKIK1 x} \\XBOOLE-0K4 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 x} iff  not x inHIDDENR3 {TARSKIK1 y}"
      using zfmisc_1_lm_5 zfmisc_1_lm_6 xboole_1_th_83 sorry
    thus " not ({TARSKIK1 x} \\XBOOLE-0K4 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 x} & x <>HIDDENR2 y) &  not ( not x <>HIDDENR2 y &  not {TARSKIK1 x} \\XBOOLE-0K4 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 x})"
      using tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma zfmisc_1_lm_10:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds {TARSKIK1 x} \\XBOOLE-0K4 X =XBOOLE-0R4 {}XBOOLE-0K1 iff x inHIDDENR3 X"
  using zfmisc_1_lm_1 xboole_1_th_37 sorry

mtheorem zfmisc_1_th_15:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds {TARSKIK1 x} \\XBOOLE-0K4 {TARSKIK1 y} =XBOOLE-0R4 {}XBOOLE-0K1 implies x =HIDDENR1 y"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds {TARSKIK1 x} \\XBOOLE-0K4 {TARSKIK1 y} =XBOOLE-0R4 {}XBOOLE-0K1 implies x =HIDDENR1 y"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    assume "{TARSKIK1 x} \\XBOOLE-0K4 {TARSKIK1 y} =XBOOLE-0R4 {}XBOOLE-0K1"
    then have "x inHIDDENR3 {TARSKIK1 y}"
      using zfmisc_1_lm_1 xboole_1_th_37 sorry
    thus "x =HIDDENR1 y"
      using tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_16:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds {TARSKIK1 x} \\XBOOLE-0K4 {TARSKIK2 x,y } =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds {TARSKIK1 x} \\XBOOLE-0K4 {TARSKIK2 x,y } =XBOOLE-0R4 {}XBOOLE-0K1"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    have "x inHIDDENR3 {TARSKIK2 x,y }"
      using tarski_def_2 sorry
    thus "{TARSKIK1 x} \\XBOOLE-0K4 {TARSKIK2 x,y } =XBOOLE-0R4 {}XBOOLE-0K1"
      using zfmisc_1_lm_1 xboole_1_th_37 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma zfmisc_1_lm_11:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds {TARSKIK2 x,y } \\XBOOLE-0K4 X =XBOOLE-0R4 {TARSKIK1 x} iff  not x inHIDDENR3 X & (y inHIDDENR3 X or x =HIDDENR1 y)"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds ({TARSKIK2 x,y } \\XBOOLE-0K4 X =XBOOLE-0R4 {TARSKIK1 x} implies  not x inHIDDENR3 X & (y inHIDDENR3 X or x =HIDDENR1 y)) & ( not x inHIDDENR3 X & (y inHIDDENR3 X or x =HIDDENR1 y) implies {TARSKIK2 x,y } \\XBOOLE-0K4 X =XBOOLE-0R4 {TARSKIK1 x})"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    show "{TARSKIK2 x,y } \\XBOOLE-0K4 X =XBOOLE-0R4 {TARSKIK1 x} implies  not x inHIDDENR3 X & (y inHIDDENR3 X or x =HIDDENR1 y)"
    proof-
      have "{TARSKIK2 x,y } \\XBOOLE-0K4 X =XBOOLE-0R4 {TARSKIK1 x} implies  not x inHIDDENR3 X & ( not y inHIDDENR3 X implies x =HIDDENR1 y)"
      proof(rule impI,rule conjMI,rule impI)
        assume A1: "{TARSKIK2 x,y } \\XBOOLE-0K4 X =XBOOLE-0R4 {TARSKIK1 x}"
        then have "x inHIDDENR3 {TARSKIK2 x,y } \\XBOOLE-0K4 X"
          using tarski_def_1 sorry
        thus " not x inHIDDENR3 X"
          using xboole_0_def_5 sorry
        have A2: "y inHIDDENR3 {TARSKIK2 x,y }"
          using tarski_def_2 sorry
        assume " not y inHIDDENR3 X"
        then have "y inHIDDENR3 {TARSKIK1 x}"
          using A1 A2 xboole_0_def_5 sorry
        thus "x =HIDDENR1 y"
          using tarski_def_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A3: " not x inHIDDENR3 X & (y inHIDDENR3 X or x =HIDDENR1 y)"
    have " for z be objectHIDDENM1 holds z inHIDDENR3 {TARSKIK2 x,y } \\XBOOLE-0K4 X iff z =HIDDENR1 x"
    proof-
      have " for z be objectHIDDENM1 holds  not (z inHIDDENR3 {TARSKIK2 x,y } \\XBOOLE-0K4 X &  not z =HIDDENR1 x) &  not (z =HIDDENR1 x &  not z inHIDDENR3 {TARSKIK2 x,y } \\XBOOLE-0K4 X)"
      proof(rule ballI)
        fix z assume [ty]: "z be objectHIDDENM1"
        have "z inHIDDENR3 {TARSKIK2 x,y } \\XBOOLE-0K4 X iff z inHIDDENR3 {TARSKIK2 x,y } &  not z inHIDDENR3 X"
          using xboole_0_def_5 sorry
        thus " not (z inHIDDENR3 {TARSKIK2 x,y } \\XBOOLE-0K4 X &  not z =HIDDENR1 x) &  not (z =HIDDENR1 x &  not z inHIDDENR3 {TARSKIK2 x,y } \\XBOOLE-0K4 X)"
          using A3 tarski_def_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "{TARSKIK2 x,y } \\XBOOLE-0K4 X =XBOOLE-0R4 {TARSKIK1 x}"
      using tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_17:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x <>HIDDENR2 y implies {TARSKIK2 x,y } \\XBOOLE-0K4 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 x}"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x <>HIDDENR2 y implies {TARSKIK2 x,y } \\XBOOLE-0K4 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 x}"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    assume "x <>HIDDENR2 y"
    then have A1: " not x inHIDDENR3 {TARSKIK1 y}"
      using tarski_def_1 sorry
    have "y inHIDDENR3 {TARSKIK1 y}"
      using tarski_def_1 sorry
    thus "{TARSKIK2 x,y } \\XBOOLE-0K4 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 x}"
      using A1 zfmisc_1_lm_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_18:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds {TARSKIK1 x} c=TARSKIR1 {TARSKIK1 y} implies x =HIDDENR1 y"
  using zfmisc_1_th_3 sorry

mtheorem zfmisc_1_th_19:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds {TARSKIK1 z} c=TARSKIR1 {TARSKIK2 x,y } implies z =HIDDENR1 x or z =HIDDENR1 y"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds {TARSKIK1 z} c=TARSKIR1 {TARSKIK2 x,y } implies  not ( not z =HIDDENR1 x &  not z =HIDDENR1 y)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix z assume [ty]: "z be objectHIDDENM1"
    have A1: "z inHIDDENR3 {TARSKIK1 z}"
      using tarski_def_1 sorry
    assume "{TARSKIK1 z} c=TARSKIR1 {TARSKIK2 x,y }"
    then have "z inHIDDENR3 {TARSKIK2 x,y }"
      using A1 sorry
    thus " not ( not z =HIDDENR1 x &  not z =HIDDENR1 y)"
      using tarski_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_20:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds {TARSKIK2 x,y } c=TARSKIR1 {TARSKIK1 z} implies x =HIDDENR1 z"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds {TARSKIK2 x,y } c=TARSKIR1 {TARSKIK1 z} implies x =HIDDENR1 z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix z assume [ty]: "z be objectHIDDENM1"
    have A1: "x inHIDDENR3 {TARSKIK2 x,y }"
      using tarski_def_2 sorry
    assume "{TARSKIK2 x,y } c=TARSKIR1 {TARSKIK1 z}"
    then have "x inHIDDENR3 {TARSKIK1 z}"
      using A1 sorry
    thus "x =HIDDENR1 z"
      using tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_21:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds {TARSKIK2 x,y } c=TARSKIR1 {TARSKIK1 z} implies {TARSKIK2 x,y } =XBOOLE-0R4 {TARSKIK1 z}"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds {TARSKIK2 x,y } c=TARSKIR1 {TARSKIK1 z} implies {TARSKIK2 x,y } =XBOOLE-0R4 {TARSKIK1 z}"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix z assume [ty]: "z be objectHIDDENM1"
    assume "{TARSKIK2 x,y } c=TARSKIR1 {TARSKIK1 z}"
    then have "x =HIDDENR1 z & y =HIDDENR1 z"
      using zfmisc_1_th_20 sorry
    thus "{TARSKIK2 x,y } =XBOOLE-0R4 {TARSKIK1 z}"
      using enumset1_th_29 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma zfmisc_1_lm_12:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds X <>HIDDENR2 {TARSKIK1 x} & X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex y be objectHIDDENM1 st y inHIDDENR3 X & y <>HIDDENR2 x)"
proof-
  have " for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds X <>HIDDENR2 {TARSKIK1 x} & X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex tVar3 be objectHIDDENM1 st tVar3 inHIDDENR3 X &  not tVar3 <>HIDDENR2 x)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "X <>HIDDENR2 {TARSKIK1 x}"
      and A2: "X <>HIDDENR2 {}XBOOLE-0K1"
    show " ex tVar3 be objectHIDDENM1 st tVar3 inHIDDENR3 X &  not tVar3 <>HIDDENR2 x"
    proof-
      have cases: " not x inHIDDENR3 X or x inHIDDENR3 X"
         sorry
      have case1: " not x inHIDDENR3 X implies ( ex tVar3 be objectHIDDENM1 st tVar3 inHIDDENR3 X &  not tVar3 <>HIDDENR2 x)"
      proof(rule impI)
        assume A3: " not x inHIDDENR3 X"
        obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A4: "y inHIDDENR3 X"
          using A2 xboole_0_th_7 sorry
        show " ex tVar3 be objectHIDDENM1 st tVar3 inHIDDENR3 X &  not tVar3 <>HIDDENR2 x"
        proof(rule bexI[of _ "y"])
          show "y inHIDDENR3 X &  not y <>HIDDENR2 x"
            using A3 A4 sorry
        qed "sorry"
      qed
      have case2: "x inHIDDENR3 X implies ( ex tVar4 be objectHIDDENM1 st tVar4 inHIDDENR3 X &  not tVar4 <>HIDDENR2 x)"
      proof(rule impI)
        assume A5: "x inHIDDENR3 X"
        obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A6: "y inHIDDENR3 X &  not y inHIDDENR3 {TARSKIK1 x} or y inHIDDENR3 {TARSKIK1 x} &  not y inHIDDENR3 X"
          using A1 tarski_th_2 sorry
        show " ex tVar4 be objectHIDDENM1 st tVar4 inHIDDENR3 X &  not tVar4 <>HIDDENR2 x"
        proof(rule bexI[of _ "y"])
          show "y inHIDDENR3 X &  not y <>HIDDENR2 x"
            using A5 A6 tarski_def_1 sorry
        qed "sorry"
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma zfmisc_1_lm_13:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for Z be setHIDDENM2 holds Z c=TARSKIR1 {TARSKIK2 x1,x2 } iff ((Z =XBOOLE-0R4 {}XBOOLE-0K1 or Z =XBOOLE-0R4 {TARSKIK1 x1}) or Z =XBOOLE-0R4 {TARSKIK1 x2}) or Z =XBOOLE-0R4 {TARSKIK2 x1,x2 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for Z be setHIDDENM2 holds (Z c=TARSKIR1 {TARSKIK2 x1,x2 } implies ((Z =XBOOLE-0R4 {}XBOOLE-0K1 or Z =XBOOLE-0R4 {TARSKIK1 x1}) or Z =XBOOLE-0R4 {TARSKIK1 x2}) or Z =XBOOLE-0R4 {TARSKIK2 x1,x2 }) &  not ( not ((( not Z =XBOOLE-0R4 {}XBOOLE-0K1 &  not Z =XBOOLE-0R4 {TARSKIK1 x1}) &  not Z =XBOOLE-0R4 {TARSKIK1 x2}) &  not Z =XBOOLE-0R4 {TARSKIK2 x1,x2 }) &  not Z c=TARSKIR1 {TARSKIK2 x1,x2 })"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix Z assume [ty]: "Z be setHIDDENM2"
    show "Z c=TARSKIR1 {TARSKIK2 x1,x2 } implies ((Z =XBOOLE-0R4 {}XBOOLE-0K1 or Z =XBOOLE-0R4 {TARSKIK1 x1}) or Z =XBOOLE-0R4 {TARSKIK1 x2}) or Z =XBOOLE-0R4 {TARSKIK2 x1,x2 }"
    proof-
      have "Z c=TARSKIR1 {TARSKIK2 x1,x2 } & (Z <>HIDDENR2 {}XBOOLE-0K1 & (Z <>HIDDENR2 {TARSKIK1 x1} & Z <>HIDDENR2 {TARSKIK1 x2})) implies Z =XBOOLE-0R4 {TARSKIK2 x1,x2 }"
      proof(rule impMI ,rule impMI ,rule impMI ,rule impI)
        assume A1: "Z c=TARSKIR1 {TARSKIK2 x1,x2 }"
          and A2: "Z <>HIDDENR2 {}XBOOLE-0K1"
          and A3: "Z <>HIDDENR2 {TARSKIK1 x1}"
          and A4: "Z <>HIDDENR2 {TARSKIK1 x2}"
        have " for z be objectHIDDENM1 holds (z inHIDDENR3 Z implies z inHIDDENR3 {TARSKIK2 x1,x2 }) & (z inHIDDENR3 {TARSKIK2 x1,x2 } implies z inHIDDENR3 Z)"
        proof(rule ballI,rule conjMI,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          show "z inHIDDENR3 Z implies z inHIDDENR3 {TARSKIK2 x1,x2 }"
            using A1 sorry
          have A5: " not x1 inHIDDENR3 Z implies  False "
          proof(rule impI)
            assume A6: " not x1 inHIDDENR3 Z"
            obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A7: "y inHIDDENR3 Z"and A8: "y <>HIDDENR2 x2"
              using A2 A4 zfmisc_1_lm_12 sorry
            have "y inHIDDENR3 {TARSKIK2 x1,x2 }"
              using A1 A7 sorry
            thus " False "
              using A6 A7 A8 tarski_def_2 sorry
          qed
          have A9: " not x2 inHIDDENR3 Z implies  False "
          proof(rule impI)
            assume A10: " not x2 inHIDDENR3 Z"
            obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A11: "y inHIDDENR3 Z"and A12: "y <>HIDDENR2 x1"
              using A2 A3 zfmisc_1_lm_12 sorry
            have "y inHIDDENR3 {TARSKIK2 x1,x2 }"
              using A1 A11 sorry
            thus " False "
              using A10 A11 A12 tarski_def_2 sorry
          qed
          assume "z inHIDDENR3 {TARSKIK2 x1,x2 }"
          thus "z inHIDDENR3 Z"
            using A5 A9 tarski_def_2 sorry
        qed "sorry"
        thus "Z =XBOOLE-0R4 {TARSKIK2 x1,x2 }"
          using tarski_th_2 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    show " not ( not ((( not Z =XBOOLE-0R4 {}XBOOLE-0K1 &  not Z =XBOOLE-0R4 {TARSKIK1 x1}) &  not Z =XBOOLE-0R4 {TARSKIK1 x2}) &  not Z =XBOOLE-0R4 {TARSKIK2 x1,x2 }) &  not Z c=TARSKIR1 {TARSKIK2 x1,x2 })"
      using zfmisc_1_th_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_22:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds {TARSKIK2 x1,x2 } c=TARSKIR1 {TARSKIK2 y1,y2 } implies x1 =HIDDENR1 y1 or x1 =HIDDENR1 y2"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds {TARSKIK2 x1,x2 } c=TARSKIR1 {TARSKIK2 y1,y2 } implies  not ( not x1 =HIDDENR1 y1 &  not x1 =HIDDENR1 y2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix y1 assume [ty]: "y1 be objectHIDDENM1"
    fix y2 assume [ty]: "y2 be objectHIDDENM1"
    assume "{TARSKIK2 x1,x2 } c=TARSKIR1 {TARSKIK2 y1,y2 }"
    then have "(({TARSKIK2 x1,x2 } =XBOOLE-0R4 {}XBOOLE-0K1 or {TARSKIK2 x1,x2 } =XBOOLE-0R4 {TARSKIK1 y1}) or {TARSKIK2 x1,x2 } =XBOOLE-0R4 {TARSKIK1 y2}) or {TARSKIK2 x1,x2 } =XBOOLE-0R4 {TARSKIK2 y1,y2 }"
      using zfmisc_1_lm_13 sorry
    thus " not ( not x1 =HIDDENR1 y1 &  not x1 =HIDDENR1 y2)"
      using zfmisc_1_th_4 zfmisc_1_th_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_23:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x <>HIDDENR2 y implies {TARSKIK1 x} \\+\\XBOOLE-0K5 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK2 x,y }"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x <>HIDDENR2 y implies {TARSKIK1 x} \\+\\XBOOLE-0K5 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK2 x,y }"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    assume A1: "x <>HIDDENR2 y"
    have " for z be objectHIDDENM1 holds z inHIDDENR3 {TARSKIK1 x} \\+\\XBOOLE-0K5 {TARSKIK1 y} iff z =HIDDENR1 x or z =HIDDENR1 y"
    proof-
      have " for z be objectHIDDENM1 holds  not ((z inHIDDENR3 {TARSKIK1 x} \\+\\XBOOLE-0K5 {TARSKIK1 y} &  not z =HIDDENR1 x) &  not z =HIDDENR1 y) &  not ( not ( not z =HIDDENR1 x &  not z =HIDDENR1 y) &  not z inHIDDENR3 {TARSKIK1 x} \\+\\XBOOLE-0K5 {TARSKIK1 y})"
      proof(rule ballI)
        fix z assume [ty]: "z be objectHIDDENM1"
        have A2: "z inHIDDENR3 {TARSKIK1 y} iff z =HIDDENR1 y"
          using tarski_def_1 sorry
        have "z inHIDDENR3 {TARSKIK1 x} iff z =HIDDENR1 x"
          using tarski_def_1 sorry
        thus " not ((z inHIDDENR3 {TARSKIK1 x} \\+\\XBOOLE-0K5 {TARSKIK1 y} &  not z =HIDDENR1 x) &  not z =HIDDENR1 y) &  not ( not ( not z =HIDDENR1 x &  not z =HIDDENR1 y) &  not z inHIDDENR3 {TARSKIK1 x} \\+\\XBOOLE-0K5 {TARSKIK1 y})"
          using A1 A2 xboole_0_th_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "{TARSKIK1 x} \\+\\XBOOLE-0K5 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK2 x,y }"
      using tarski_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_24:
" for x be objectHIDDENM1 holds boolZFMISC-1K1 {TARSKIK1 x} =XBOOLE-0R4 {TARSKIK2 {}XBOOLE-0K1,{TARSKIK1 x} }"
proof-
  have " for x be objectHIDDENM1 holds boolZFMISC-1K1 {TARSKIK1 x} =XBOOLE-0R4 {TARSKIK2 {}XBOOLE-0K1,{TARSKIK1 x} }"
  proof(rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 boolZFMISC-1K1 {TARSKIK1 x} iff y inHIDDENR3 {TARSKIK2 {}XBOOLE-0K1,{TARSKIK1 x} }"
    proof(rule ballI)
      fix y assume [ty]: "y be objectHIDDENM1"
      obtain yy where 
        [ty]:"yy be setHIDDENM2" and yyDef:"yy = y"
        using tarski_th_1 sorry
      have "yy c=TARSKIR1 {TARSKIK1 x} iff y =HIDDENR1 {}XBOOLE-0K1 or y =HIDDENR1 {TARSKIK1 x}"
        using zfmisc_1_lm_3 sorry
      thus "y inHIDDENR3 boolZFMISC-1K1 {TARSKIK1 x} iff y inHIDDENR3 {TARSKIK2 {}XBOOLE-0K1,{TARSKIK1 x} }"
        using zfmisc_1_def_1 tarski_def_2 sorry
    qed "sorry"
    thus "boolZFMISC-1K1 {TARSKIK1 x} =XBOOLE-0R4 {TARSKIK2 {}XBOOLE-0K1,{TARSKIK1 x} }"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma zfmisc_1_lm_14:
" for A be setHIDDENM2 holds  for X be setHIDDENM2 holds X inTARSKIR2 A implies X c=TARSKIR1 unionTARSKIK3 A"
  using tarski_def_4 sorry

mtheorem zfmisc_1_reduce_1:
  mlet "x be objectHIDDENM1"
"reduce unionTARSKIK3 {TARSKIK1 x} to x"
proof
(*reducibility*)
  show "unionTARSKIK3 {TARSKIK1 x} =HIDDENR1 x"
  proof-
    obtain X where 
      [ty]:"X be setHIDDENM2" and XDef:"X = x"
      using tarski_th_1 sorry
    have A1: "unionTARSKIK3 {TARSKIK1 X} c=TARSKIR1 X"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 unionTARSKIK3 {TARSKIK1 X} implies y inHIDDENR3 X"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 unionTARSKIK3 {TARSKIK1 X}"
        then have " ex Y be setHIDDENM2 st y inHIDDENR3 Y & Y inTARSKIR2 {TARSKIK1 X}"
          using tarski_def_4 sorry
        thus "y inHIDDENR3 X"
          using tarski_def_1 sorry
      qed "sorry"
      thus "unionTARSKIK3 {TARSKIK1 X} c=TARSKIR1 X"
        using tarski_def_3 sorry
    qed
    have "X inTARSKIR2 {TARSKIK1 X}"
      using tarski_def_1 sorry
    then have "X c=TARSKIR1 unionTARSKIK3 {TARSKIK1 X}"
      using zfmisc_1_lm_14 sorry
    thus "unionTARSKIK3 {TARSKIK1 x} =HIDDENR1 x"
      using A1 xboole_0_def_10 sorry
  qed
qed "sorry"

mtheorem zfmisc_1_th_25:
" for x be objectHIDDENM1 holds unionTARSKIK3 {TARSKIK1 x} =HIDDENR1 x"
   sorry

mlemma zfmisc_1_lm_15:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds unionTARSKIK3 {TARSKIK2 X,Y } =XBOOLE-0R4 X \\/XBOOLE-0K2 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds unionTARSKIK3 {TARSKIK2 X,Y } =XBOOLE-0R4 X \\/XBOOLE-0K2 Y"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 {TARSKIK2 X,Y } iff x inHIDDENR3 X or x inHIDDENR3 Y"
    proof-
      have " for x be objectHIDDENM1 holds (x inHIDDENR3 unionTARSKIK3 {TARSKIK2 X,Y } implies x inHIDDENR3 X or x inHIDDENR3 Y) &  not ( not ( not x inHIDDENR3 X &  not x inHIDDENR3 Y) &  not x inHIDDENR3 unionTARSKIK3 {TARSKIK2 X,Y })"
      proof(rule ballI,rule conjMI)
        fix x assume [ty]: "x be objectHIDDENM1"
        show "x inHIDDENR3 unionTARSKIK3 {TARSKIK2 X,Y } implies x inHIDDENR3 X or x inHIDDENR3 Y"
        proof-
          have "x inHIDDENR3 unionTARSKIK3 {TARSKIK2 X,Y } implies  not ( not x inHIDDENR3 X &  not x inHIDDENR3 Y)"
          proof(rule impI)
            assume "x inHIDDENR3 unionTARSKIK3 {TARSKIK2 X,Y }"
            then have " ex Z be setHIDDENM2 st x inHIDDENR3 Z & Z inTARSKIR2 {TARSKIK2 X,Y }"
              using tarski_def_4 sorry
            thus " not ( not x inHIDDENR3 X &  not x inHIDDENR3 Y)"
              using tarski_def_2 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have "X inTARSKIR2 {TARSKIK2 X,Y } & Y inTARSKIR2 {TARSKIK2 X,Y }"
          using tarski_def_2 sorry
        thus " not ( not ( not x inHIDDENR3 X &  not x inHIDDENR3 Y) &  not x inHIDDENR3 unionTARSKIK3 {TARSKIK2 X,Y })"
          using tarski_def_4 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "unionTARSKIK3 {TARSKIK2 X,Y } =XBOOLE-0R4 X \\/XBOOLE-0K2 Y"
      using xboole_0_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_26:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds unionTARSKIK3 {TARSKIK2 {TARSKIK1 x},{TARSKIK1 y} } =XBOOLE-0R4 {TARSKIK2 x,y }"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds unionTARSKIK3 {TARSKIK2 {TARSKIK1 x},{TARSKIK1 y} } =HIDDENR1 {TARSKIK2 x,y }"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    have "unionTARSKIK3 {TARSKIK2 {TARSKIK1 x},{TARSKIK1 y} } =HIDDENR1 {TARSKIK1 x} \\/XBOOLE-0K2 {TARSKIK1 y}"
      using zfmisc_1_lm_15 sorry
    also have "... = {TARSKIK2 x,y }"
      using enumset1_th_1 sorry
    finally show "unionTARSKIK3 {TARSKIK2 {TARSKIK1 x},{TARSKIK1 y} } =HIDDENR1 {TARSKIK2 x,y }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma zfmisc_1_lm_16:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :] iff x inHIDDENR3 X & y inHIDDENR3 Y"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds ([TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :] implies x inHIDDENR3 X & y inHIDDENR3 Y) &  not ((x inHIDDENR3 X & y inHIDDENR3 Y) &  not [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :])"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    show "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :] implies x inHIDDENR3 X & y inHIDDENR3 Y"
    proof(rule impI)
      assume "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
      then have " ex x1 be objectHIDDENM1 st  ex y1 be objectHIDDENM1 st (x1 inHIDDENR3 X & y1 inHIDDENR3 Y) & [TARSKIK4 x,y ] =HIDDENR1 [TARSKIK4 x1,y1 ]"
        using zfmisc_1_def_2 sorry
      thus "x inHIDDENR3 X & y inHIDDENR3 Y"
        using xtuple_0_th_1 sorry
    qed
    show " not ((x inHIDDENR3 X & y inHIDDENR3 Y) &  not [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :])"
      using zfmisc_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CT*)
mtheorem zfmisc_1_th_28:
" for x be objectHIDDENM1 holds  for x1 be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 x1},{TARSKIK1 y1} :] iff x =HIDDENR1 x1 & y =HIDDENR1 y1"
proof-
  have " for x be objectHIDDENM1 holds  for x1 be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 x1},{TARSKIK1 y1} :] &  not (x =HIDDENR1 x1 & y =HIDDENR1 y1)) &  not ((x =HIDDENR1 x1 & y =HIDDENR1 y1) &  not [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 x1},{TARSKIK1 y1} :])"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix y1 assume [ty]: "y1 be objectHIDDENM1"
    have "x =HIDDENR1 x1 & y =HIDDENR1 y1 iff x inHIDDENR3 {TARSKIK1 x1} & y inHIDDENR3 {TARSKIK1 y1}"
      using tarski_def_1 sorry
    thus " not ([TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 x1},{TARSKIK1 y1} :] &  not (x =HIDDENR1 x1 & y =HIDDENR1 y1)) &  not ((x =HIDDENR1 x1 & y =HIDDENR1 y1) &  not [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 x1},{TARSKIK1 y1} :])"
      using zfmisc_1_lm_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_29:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [:ZFMISC-1K2 {TARSKIK1 x},{TARSKIK1 y} :] =XBOOLE-0R4 {TARSKIK1 [TARSKIK4 x,y ] }"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [:ZFMISC-1K2 {TARSKIK1 x},{TARSKIK1 y} :] =XBOOLE-0R4 {TARSKIK1 [TARSKIK4 x,y ] }"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    have " for z be objectHIDDENM1 holds (z inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 x},{TARSKIK1 y} :] implies z inHIDDENR3 {TARSKIK1 [TARSKIK4 x,y ] }) & (z inHIDDENR3 {TARSKIK1 [TARSKIK4 x,y ] } implies z inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 x},{TARSKIK1 y} :])"
    proof(rule ballI,rule conjMI,rule impI)
      fix z assume [ty]: "z be objectHIDDENM1"
      show "z inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 x},{TARSKIK1 y} :] implies z inHIDDENR3 {TARSKIK1 [TARSKIK4 x,y ] }"
      proof(rule impI)
        assume "z inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 x},{TARSKIK1 y} :]"
        then obtain x1 y1 where
          [ty]:"x1 be objectHIDDENM1" "y1 be objectHIDDENM1" and 
          A1: "x1 inHIDDENR3 {TARSKIK1 x} & y1 inHIDDENR3 {TARSKIK1 y}"and A2: "z =HIDDENR1 [TARSKIK4 x1,y1 ]"
          using zfmisc_1_def_2 sorry
        have "x1 =HIDDENR1 x & y1 =HIDDENR1 y"
          using A1 tarski_def_1 sorry
        thus "z inHIDDENR3 {TARSKIK1 [TARSKIK4 x,y ] }"
          using A2 tarski_def_1 sorry
      qed
      assume "z inHIDDENR3 {TARSKIK1 [TARSKIK4 x,y ] }"
      then have A3: "z =HIDDENR1 [TARSKIK4 x,y ]"
        using tarski_def_1 sorry
      have "x inHIDDENR3 {TARSKIK1 x} & y inHIDDENR3 {TARSKIK1 y}"
        using tarski_def_1 sorry
      thus "z inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 x},{TARSKIK1 y} :]"
        using A3 zfmisc_1_lm_16 sorry
    qed "sorry"
    thus "[:ZFMISC-1K2 {TARSKIK1 x},{TARSKIK1 y} :] =XBOOLE-0R4 {TARSKIK1 [TARSKIK4 x,y ] }"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_30:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds [:ZFMISC-1K2 {TARSKIK1 x},{TARSKIK2 y,z } :] =XBOOLE-0R4 {TARSKIK2 [TARSKIK4 x,y ],[TARSKIK4 x,z ] } & [:ZFMISC-1K2 {TARSKIK2 x,y },{TARSKIK1 z} :] =XBOOLE-0R4 {TARSKIK2 [TARSKIK4 x,z ],[TARSKIK4 y,z ] }"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds [:ZFMISC-1K2 {TARSKIK1 x},{TARSKIK2 y,z } :] =XBOOLE-0R4 {TARSKIK2 [TARSKIK4 x,y ],[TARSKIK4 x,z ] } & [:ZFMISC-1K2 {TARSKIK2 x,y },{TARSKIK1 z} :] =XBOOLE-0R4 {TARSKIK2 [TARSKIK4 x,z ],[TARSKIK4 y,z ] }"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix z assume [ty]: "z be objectHIDDENM1"
    have " for v be objectHIDDENM1 holds (v inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 x},{TARSKIK2 y,z } :] implies v inHIDDENR3 {TARSKIK2 [TARSKIK4 x,y ],[TARSKIK4 x,z ] }) & (v inHIDDENR3 {TARSKIK2 [TARSKIK4 x,y ],[TARSKIK4 x,z ] } implies v inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 x},{TARSKIK2 y,z } :])"
    proof(rule ballI,rule conjMI,rule impI)
      fix v assume [ty]: "v be objectHIDDENM1"
      have A1: "z inHIDDENR3 {TARSKIK2 y,z }"
        using tarski_def_2 sorry
      show "v inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 x},{TARSKIK2 y,z } :] implies v inHIDDENR3 {TARSKIK2 [TARSKIK4 x,y ],[TARSKIK4 x,z ] }"
      proof(rule impI)
        assume "v inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 x},{TARSKIK2 y,z } :]"
        then obtain x1 y1 where
          [ty]:"x1 be objectHIDDENM1" "y1 be objectHIDDENM1" and 
          A2: "x1 inHIDDENR3 {TARSKIK1 x}"and A3: "y1 inHIDDENR3 {TARSKIK2 y,z }"and A4: "v =HIDDENR1 [TARSKIK4 x1,y1 ]"
          using zfmisc_1_def_2 sorry
        have A5: "y1 =HIDDENR1 y or y1 =HIDDENR1 z"
          using A3 tarski_def_2 sorry
        have "x1 =HIDDENR1 x"
          using A2 tarski_def_1 sorry
        thus "v inHIDDENR3 {TARSKIK2 [TARSKIK4 x,y ],[TARSKIK4 x,z ] }"
          using A4 A5 tarski_def_2 sorry
      qed
      assume "v inHIDDENR3 {TARSKIK2 [TARSKIK4 x,y ],[TARSKIK4 x,z ] }"
      then have A6: "v =HIDDENR1 [TARSKIK4 x,y ] or v =HIDDENR1 [TARSKIK4 x,z ]"
        using tarski_def_2 sorry
      have "x inHIDDENR3 {TARSKIK1 x} & y inHIDDENR3 {TARSKIK2 y,z }"
        using tarski_def_1 tarski_def_2 sorry
      thus "v inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 x},{TARSKIK2 y,z } :]"
        using A6 A1 zfmisc_1_lm_16 sorry
    qed "sorry"
    thus "[:ZFMISC-1K2 {TARSKIK1 x},{TARSKIK2 y,z } :] =XBOOLE-0R4 {TARSKIK2 [TARSKIK4 x,y ],[TARSKIK4 x,z ] }"
      using tarski_th_2 sorry
    have " for v be objectHIDDENM1 holds (v inHIDDENR3 [:ZFMISC-1K2 {TARSKIK2 x,y },{TARSKIK1 z} :] implies v inHIDDENR3 {TARSKIK2 [TARSKIK4 x,z ],[TARSKIK4 y,z ] }) & (v inHIDDENR3 {TARSKIK2 [TARSKIK4 x,z ],[TARSKIK4 y,z ] } implies v inHIDDENR3 [:ZFMISC-1K2 {TARSKIK2 x,y },{TARSKIK1 z} :])"
    proof(rule ballI,rule conjMI,rule impI)
      fix v assume [ty]: "v be objectHIDDENM1"
      have A7: "z inHIDDENR3 {TARSKIK1 z}"
        using tarski_def_1 sorry
      show "v inHIDDENR3 [:ZFMISC-1K2 {TARSKIK2 x,y },{TARSKIK1 z} :] implies v inHIDDENR3 {TARSKIK2 [TARSKIK4 x,z ],[TARSKIK4 y,z ] }"
      proof(rule impI)
        assume "v inHIDDENR3 [:ZFMISC-1K2 {TARSKIK2 x,y },{TARSKIK1 z} :]"
        then obtain x1 y1 where
          [ty]:"x1 be objectHIDDENM1" "y1 be objectHIDDENM1" and 
          A8: "x1 inHIDDENR3 {TARSKIK2 x,y }"and A9: "y1 inHIDDENR3 {TARSKIK1 z}"and A10: "v =HIDDENR1 [TARSKIK4 x1,y1 ]"
          using zfmisc_1_def_2 sorry
        have A11: "x1 =HIDDENR1 x or x1 =HIDDENR1 y"
          using A8 tarski_def_2 sorry
        have "y1 =HIDDENR1 z"
          using A9 tarski_def_1 sorry
        thus "v inHIDDENR3 {TARSKIK2 [TARSKIK4 x,z ],[TARSKIK4 y,z ] }"
          using A10 A11 tarski_def_2 sorry
      qed
      assume "v inHIDDENR3 {TARSKIK2 [TARSKIK4 x,z ],[TARSKIK4 y,z ] }"
      then have A12: "v =HIDDENR1 [TARSKIK4 x,z ] or v =HIDDENR1 [TARSKIK4 y,z ]"
        using tarski_def_2 sorry
      have "x inHIDDENR3 {TARSKIK2 x,y } & y inHIDDENR3 {TARSKIK2 x,y }"
        using tarski_def_2 sorry
      thus "v inHIDDENR3 [:ZFMISC-1K2 {TARSKIK2 x,y },{TARSKIK1 z} :]"
        using A12 A7 zfmisc_1_lm_16 sorry
    qed "sorry"
    thus "[:ZFMISC-1K2 {TARSKIK2 x,y },{TARSKIK1 z} :] =XBOOLE-0R4 {TARSKIK2 [TARSKIK4 x,z ],[TARSKIK4 y,z ] }"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_31:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds {TARSKIK1 x} c=TARSKIR1 X iff x inHIDDENR3 X"
  using zfmisc_1_lm_1 sorry

mtheorem zfmisc_1_th_32:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for Z be setHIDDENM2 holds {TARSKIK2 x1,x2 } c=TARSKIR1 Z iff x1 inHIDDENR3 Z & x2 inHIDDENR3 Z"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for Z be setHIDDENM2 holds ({TARSKIK2 x1,x2 } c=TARSKIR1 Z implies x1 inHIDDENR3 Z & x2 inHIDDENR3 Z) & (x1 inHIDDENR3 Z & x2 inHIDDENR3 Z implies {TARSKIK2 x1,x2 } c=TARSKIR1 Z)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have "x1 inHIDDENR3 {TARSKIK2 x1,x2 } & x2 inHIDDENR3 {TARSKIK2 x1,x2 }"
      using tarski_def_2 sorry
    thus "{TARSKIK2 x1,x2 } c=TARSKIR1 Z implies x1 inHIDDENR3 Z & x2 inHIDDENR3 Z"
       sorry
    assume A1: "x1 inHIDDENR3 Z & x2 inHIDDENR3 Z"
    have " for z be objectHIDDENM1 holds z inHIDDENR3 {TARSKIK2 x1,x2 } implies z inHIDDENR3 Z"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be objectHIDDENM1"
      assume "z inHIDDENR3 {TARSKIK2 x1,x2 }"
      thus "z inHIDDENR3 Z"
        using A1 tarski_def_2 sorry
    qed "sorry"
    thus "{TARSKIK2 x1,x2 } c=TARSKIR1 Z"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_33:
" for x be objectHIDDENM1 holds  for Y be setHIDDENM2 holds Y c=TARSKIR1 {TARSKIK1 x} iff Y =XBOOLE-0R4 {}XBOOLE-0K1 or Y =XBOOLE-0R4 {TARSKIK1 x}"
  using zfmisc_1_lm_3 sorry

mtheorem zfmisc_1_th_34:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds Y c=TARSKIR1 X &  not x inHIDDENR3 Y implies Y c=TARSKIR1 X \\XBOOLE-0K4 {TARSKIK1 x}"
  using zfmisc_1_lm_2 sorry

mtheorem zfmisc_1_th_35:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds X <>HIDDENR2 {TARSKIK1 x} & X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex y be objectHIDDENM1 st y inHIDDENR3 X & y <>HIDDENR2 x)"
  using zfmisc_1_lm_12 sorry

mtheorem zfmisc_1_th_36:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for Z be setHIDDENM2 holds Z c=TARSKIR1 {TARSKIK2 x1,x2 } iff ((Z =XBOOLE-0R4 {}XBOOLE-0K1 or Z =XBOOLE-0R4 {TARSKIK1 x1}) or Z =XBOOLE-0R4 {TARSKIK1 x2}) or Z =XBOOLE-0R4 {TARSKIK2 x1,x2 }"
  using zfmisc_1_lm_13 sorry

mtheorem zfmisc_1_th_37:
" for z be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds {TARSKIK1 z} =XBOOLE-0R4 X \\/XBOOLE-0K2 Y implies (X =XBOOLE-0R4 {TARSKIK1 z} & Y =XBOOLE-0R4 {TARSKIK1 z} or X =XBOOLE-0R4 {}XBOOLE-0K1 & Y =XBOOLE-0R4 {TARSKIK1 z}) or X =XBOOLE-0R4 {TARSKIK1 z} & Y =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for z be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds {TARSKIK1 z} =XBOOLE-0R4 X \\/XBOOLE-0K2 Y implies  not (( not (X =XBOOLE-0R4 {TARSKIK1 z} & Y =XBOOLE-0R4 {TARSKIK1 z}) &  not (X =XBOOLE-0R4 {}XBOOLE-0K1 & Y =XBOOLE-0R4 {TARSKIK1 z})) &  not (X =XBOOLE-0R4 {TARSKIK1 z} & Y =XBOOLE-0R4 {}XBOOLE-0K1))"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix z assume [ty]: "z be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "{TARSKIK1 z} =XBOOLE-0R4 X \\/XBOOLE-0K2 Y"
    have "X <>HIDDENR2 {}XBOOLE-0K1 or Y <>HIDDENR2 {}XBOOLE-0K1"
      using A1 sorry
    thus " not (( not (X =XBOOLE-0R4 {TARSKIK1 z} & Y =XBOOLE-0R4 {TARSKIK1 z}) &  not (X =XBOOLE-0R4 {}XBOOLE-0K1 & Y =XBOOLE-0R4 {TARSKIK1 z})) &  not (X =XBOOLE-0R4 {TARSKIK1 z} & Y =XBOOLE-0R4 {}XBOOLE-0K1))"
      using A1 zfmisc_1_lm_3 xboole_1_th_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_38:
" for z be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds {TARSKIK1 z} =XBOOLE-0R4 X \\/XBOOLE-0K2 Y & X <>HIDDENR2 Y implies X =XBOOLE-0R4 {}XBOOLE-0K1 or Y =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for z be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds {TARSKIK1 z} =XBOOLE-0R4 X \\/XBOOLE-0K2 Y implies  not (( not X <>HIDDENR2 Y &  not X =XBOOLE-0R4 {}XBOOLE-0K1) &  not Y =XBOOLE-0R4 {}XBOOLE-0K1)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix z assume [ty]: "z be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume "{TARSKIK1 z} =XBOOLE-0R4 X \\/XBOOLE-0K2 Y"
    then have "(X =XBOOLE-0R4 {TARSKIK1 z} & Y =XBOOLE-0R4 {TARSKIK1 z} or X =XBOOLE-0R4 {}XBOOLE-0K1 & Y =XBOOLE-0R4 {TARSKIK1 z}) or X =XBOOLE-0R4 {TARSKIK1 z} & Y =XBOOLE-0R4 {}XBOOLE-0K1"
      using zfmisc_1_th_37 sorry
    thus " not (( not X <>HIDDENR2 Y &  not X =XBOOLE-0R4 {}XBOOLE-0K1) &  not Y =XBOOLE-0R4 {}XBOOLE-0K1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_39:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds {TARSKIK1 x} \\/XBOOLE-0K2 X c=TARSKIR1 X implies x inHIDDENR3 X"
  using zfmisc_1_lm_4 sorry

mtheorem zfmisc_1_th_40:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds x inHIDDENR3 X implies {TARSKIK1 x} \\/XBOOLE-0K2 X =XBOOLE-0R4 X"
  using zfmisc_1_lm_1 xboole_1_th_12 sorry

mtheorem zfmisc_1_th_41:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for Z be setHIDDENM2 holds {TARSKIK2 x,y } \\/XBOOLE-0K2 Z c=TARSKIR1 Z implies x inHIDDENR3 Z"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for Z be setHIDDENM2 holds {TARSKIK2 x,y } \\/XBOOLE-0K2 Z c=TARSKIR1 Z implies ( not x inHIDDENR3 Z implies  not  True )"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume A1: "{TARSKIK2 x,y } \\/XBOOLE-0K2 Z c=TARSKIR1 Z"
    assume " not x inHIDDENR3 Z"
    then have " not x inHIDDENR3 {TARSKIK2 x,y } \\/XBOOLE-0K2 Z"
      using A1 sorry
    then have " not x inHIDDENR3 {TARSKIK2 x,y }"
      using xboole_0_def_3 sorry
    thus " not  True "
      using tarski_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_42:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for Z be setHIDDENM2 holds x inHIDDENR3 Z & y inHIDDENR3 Z implies {TARSKIK2 x,y } \\/XBOOLE-0K2 Z =XBOOLE-0R4 Z"
  using zfmisc_1_th_32 xboole_1_th_12 sorry

mtheorem zfmisc_1_th_43:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds {TARSKIK1 x} \\/XBOOLE-0K2 X <>HIDDENR2 {}XBOOLE-0K1"
   sorry

mtheorem zfmisc_1_th_44:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds {TARSKIK2 x,y } \\/XBOOLE-0K2 X <>HIDDENR2 {}XBOOLE-0K1"
   sorry

mtheorem zfmisc_1_th_45:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds X /\\XBOOLE-0K3 {TARSKIK1 x} =XBOOLE-0R4 {TARSKIK1 x} implies x inHIDDENR3 X"
  using zfmisc_1_lm_7 sorry

mtheorem zfmisc_1_th_46:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds x inHIDDENR3 X implies X /\\XBOOLE-0K3 {TARSKIK1 x} =XBOOLE-0R4 {TARSKIK1 x}"
  using zfmisc_1_lm_1 xboole_1_th_28 sorry

mtheorem zfmisc_1_th_47:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for Z be setHIDDENM2 holds x inHIDDENR3 Z & y inHIDDENR3 Z implies {TARSKIK2 x,y } /\\XBOOLE-0K3 Z =XBOOLE-0R4 {TARSKIK2 x,y }"
  using zfmisc_1_th_32 xboole_1_th_28 sorry

mtheorem zfmisc_1_th_48:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds {TARSKIK1 x} missesXBOOLE-0R1 X implies  not x inHIDDENR3 X"
  using zfmisc_1_lm_5 sorry

mtheorem zfmisc_1_th_49:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for Z be setHIDDENM2 holds {TARSKIK2 x,y } missesXBOOLE-0R1 Z implies  not x inHIDDENR3 Z"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for Z be setHIDDENM2 holds  not ({TARSKIK2 x,y } missesXBOOLE-0R1 Z & x inHIDDENR3 Z)"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have A1: "x inHIDDENR3 {TARSKIK2 x,y }"
      using tarski_def_2 sorry
    have "{TARSKIK2 x,y } /\\XBOOLE-0K3 Z =XBOOLE-0R4 {}XBOOLE-0K1 & x inHIDDENR3 Z implies  False "
    proof(rule impI)
      assume "{TARSKIK2 x,y } /\\XBOOLE-0K3 Z =XBOOLE-0R4 {}XBOOLE-0K1 & x inHIDDENR3 Z"
      thus " False "
        using A1 xboole_0_def_4 sorry
    qed
    thus " not ({TARSKIK2 x,y } missesXBOOLE-0R1 Z & x inHIDDENR3 Z)"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_50:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  not x inHIDDENR3 X implies {TARSKIK1 x} missesXBOOLE-0R1 X"
  using zfmisc_1_lm_6 sorry

mtheorem zfmisc_1_th_51:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for Z be setHIDDENM2 holds  not x inHIDDENR3 Z &  not y inHIDDENR3 Z implies {TARSKIK2 x,y } missesXBOOLE-0R1 Z"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for Z be setHIDDENM2 holds  not x inHIDDENR3 Z &  not y inHIDDENR3 Z implies ({TARSKIK2 x,y } meetsXBOOLE-0R5 Z implies  False )"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume A1: " not x inHIDDENR3 Z &  not y inHIDDENR3 Z"
    assume "{TARSKIK2 x,y } meetsXBOOLE-0R5 Z"
    then obtain z where
      [ty]:"z be objectHIDDENM1" and 
      A2: "z inHIDDENR3 {TARSKIK2 x,y } /\\XBOOLE-0K3 Z"
      using xboole_0_th_4 sorry
    have "z inHIDDENR3 {TARSKIK2 x,y } & z inHIDDENR3 Z"
      using A2 xboole_0_def_4 sorry
    thus " False "
      using A1 tarski_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_52:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds {TARSKIK1 x} missesXBOOLE-0R1 X or {TARSKIK1 x} /\\XBOOLE-0K3 X =XBOOLE-0R4 {TARSKIK1 x}"
  using zfmisc_1_lm_6 zfmisc_1_lm_8 sorry

mtheorem zfmisc_1_th_53:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds {TARSKIK2 x,y } /\\XBOOLE-0K3 X =XBOOLE-0R4 {TARSKIK1 x} implies  not y inHIDDENR3 X or x =HIDDENR1 y"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds {TARSKIK2 x,y } /\\XBOOLE-0K3 X =XBOOLE-0R4 {TARSKIK1 x} & y inHIDDENR3 X implies x =HIDDENR1 y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    have A1: "y inHIDDENR3 {TARSKIK2 x,y }"
      using tarski_def_2 sorry
    assume "{TARSKIK2 x,y } /\\XBOOLE-0K3 X =XBOOLE-0R4 {TARSKIK1 x} & y inHIDDENR3 X"
    then have "y inHIDDENR3 {TARSKIK1 x}"
      using A1 xboole_0_def_4 sorry
    thus "x =HIDDENR1 y"
      using tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_54:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds x inHIDDENR3 X & ( not y inHIDDENR3 X or x =HIDDENR1 y) implies {TARSKIK2 x,y } /\\XBOOLE-0K3 X =XBOOLE-0R4 {TARSKIK1 x}"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds x inHIDDENR3 X & ( not y inHIDDENR3 X or x =HIDDENR1 y) implies {TARSKIK2 x,y } /\\XBOOLE-0K3 X =XBOOLE-0R4 {TARSKIK1 x}"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "x inHIDDENR3 X & ( not y inHIDDENR3 X or x =HIDDENR1 y)"
    have " for z be objectHIDDENM1 holds z inHIDDENR3 {TARSKIK2 x,y } /\\XBOOLE-0K3 X iff z =HIDDENR1 x"
    proof-
      have " for z be objectHIDDENM1 holds  not (z inHIDDENR3 {TARSKIK2 x,y } /\\XBOOLE-0K3 X &  not z =HIDDENR1 x) &  not (z =HIDDENR1 x &  not z inHIDDENR3 {TARSKIK2 x,y } /\\XBOOLE-0K3 X)"
      proof(rule ballI)
        fix z assume [ty]: "z be objectHIDDENM1"
        have "z inHIDDENR3 {TARSKIK2 x,y } /\\XBOOLE-0K3 X iff z inHIDDENR3 {TARSKIK2 x,y } & z inHIDDENR3 X"
          using xboole_0_def_4 sorry
        thus " not (z inHIDDENR3 {TARSKIK2 x,y } /\\XBOOLE-0K3 X &  not z =HIDDENR1 x) &  not (z =HIDDENR1 x &  not z inHIDDENR3 {TARSKIK2 x,y } /\\XBOOLE-0K3 X)"
          using A1 tarski_def_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "{TARSKIK2 x,y } /\\XBOOLE-0K3 X =XBOOLE-0R4 {TARSKIK1 x}"
      using tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_55:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds {TARSKIK2 x,y } /\\XBOOLE-0K3 X =XBOOLE-0R4 {TARSKIK2 x,y } implies x inHIDDENR3 X"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds {TARSKIK2 x,y } /\\XBOOLE-0K3 X =XBOOLE-0R4 {TARSKIK2 x,y } implies x inHIDDENR3 X"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    assume "{TARSKIK2 x,y } /\\XBOOLE-0K3 X =XBOOLE-0R4 {TARSKIK2 x,y }"
    then have "x inHIDDENR3 {TARSKIK2 x,y } /\\XBOOLE-0K3 X & y inHIDDENR3 {TARSKIK2 x,y } /\\XBOOLE-0K3 X or x inHIDDENR3 X /\\XBOOLE-0K3 {TARSKIK2 x,y } & y inHIDDENR3 X /\\XBOOLE-0K3 {TARSKIK2 x,y }"
      using tarski_def_2 sorry
    thus "x inHIDDENR3 X"
      using xboole_0_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_56:
" for x be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  for X be setHIDDENM2 holds z inHIDDENR3 X \\XBOOLE-0K4 {TARSKIK1 x} iff z inHIDDENR3 X & z <>HIDDENR2 x"
proof-
  have " for x be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  for X be setHIDDENM2 holds  not (z inHIDDENR3 X \\XBOOLE-0K4 {TARSKIK1 x} &  not (z inHIDDENR3 X &  not z <>HIDDENR2 x)) &  not ((z inHIDDENR3 X &  not z <>HIDDENR2 x) &  not z inHIDDENR3 X \\XBOOLE-0K4 {TARSKIK1 x})"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix z assume [ty]: "z be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    have "z inHIDDENR3 X \\XBOOLE-0K4 {TARSKIK1 x} iff z inHIDDENR3 X &  not z inHIDDENR3 {TARSKIK1 x}"
      using xboole_0_def_5 sorry
    thus " not (z inHIDDENR3 X \\XBOOLE-0K4 {TARSKIK1 x} &  not (z inHIDDENR3 X &  not z <>HIDDENR2 x)) &  not ((z inHIDDENR3 X &  not z <>HIDDENR2 x) &  not z inHIDDENR3 X \\XBOOLE-0K4 {TARSKIK1 x})"
      using tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_57:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds X \\XBOOLE-0K4 {TARSKIK1 x} =XBOOLE-0R4 X iff  not x inHIDDENR3 X"
proof-
  have " for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  not (X \\XBOOLE-0K4 {TARSKIK1 x} =XBOOLE-0R4 X & x inHIDDENR3 X) &  not ( not x inHIDDENR3 X &  not X \\XBOOLE-0K4 {TARSKIK1 x} =XBOOLE-0R4 X)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    have "X \\XBOOLE-0K4 {TARSKIK1 x} =XBOOLE-0R4 X iff X missesXBOOLE-0R1 {TARSKIK1 x}"
      using xboole_1_th_83 sorry
    thus " not (X \\XBOOLE-0K4 {TARSKIK1 x} =XBOOLE-0R4 X & x inHIDDENR3 X) &  not ( not x inHIDDENR3 X &  not X \\XBOOLE-0K4 {TARSKIK1 x} =XBOOLE-0R4 X)"
      using zfmisc_1_lm_5 zfmisc_1_lm_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_58:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds X \\XBOOLE-0K4 {TARSKIK1 x} =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1 or X =XBOOLE-0R4 {TARSKIK1 x}"
proof-
  have " for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds X \\XBOOLE-0K4 {TARSKIK1 x} =XBOOLE-0R4 {}XBOOLE-0K1 implies  not ( not X =XBOOLE-0R4 {}XBOOLE-0K1 &  not X =XBOOLE-0R4 {TARSKIK1 x})"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    assume "X \\XBOOLE-0K4 {TARSKIK1 x} =XBOOLE-0R4 {}XBOOLE-0K1"
    then have "X c=TARSKIR1 {TARSKIK1 x}"
      using xboole_1_th_37 sorry
    thus " not ( not X =XBOOLE-0R4 {}XBOOLE-0K1 &  not X =XBOOLE-0R4 {TARSKIK1 x})"
      using zfmisc_1_lm_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_59:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds {TARSKIK1 x} \\XBOOLE-0K4 X =XBOOLE-0R4 {TARSKIK1 x} iff  not x inHIDDENR3 X"
  using zfmisc_1_lm_5 zfmisc_1_lm_6 xboole_1_th_83 sorry

mtheorem zfmisc_1_th_60:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds {TARSKIK1 x} \\XBOOLE-0K4 X =XBOOLE-0R4 {}XBOOLE-0K1 iff x inHIDDENR3 X"
  using zfmisc_1_lm_1 xboole_1_th_37 sorry

mtheorem zfmisc_1_th_61:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds {TARSKIK1 x} \\XBOOLE-0K4 X =XBOOLE-0R4 {}XBOOLE-0K1 or {TARSKIK1 x} \\XBOOLE-0K4 X =XBOOLE-0R4 {TARSKIK1 x}"
  using zfmisc_1_lm_9 zfmisc_1_lm_10 sorry

mtheorem zfmisc_1_th_62:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds {TARSKIK2 x,y } \\XBOOLE-0K4 X =XBOOLE-0R4 {TARSKIK1 x} iff  not x inHIDDENR3 X & (y inHIDDENR3 X or x =HIDDENR1 y)"
  using zfmisc_1_lm_11 sorry

mtheorem zfmisc_1_th_63:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds {TARSKIK2 x,y } \\XBOOLE-0K4 X =XBOOLE-0R4 {TARSKIK2 x,y } iff  not x inHIDDENR3 X &  not y inHIDDENR3 X"
  using zfmisc_1_th_49 zfmisc_1_th_51 xboole_1_th_83 sorry

mtheorem zfmisc_1_th_64:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds {TARSKIK2 x,y } \\XBOOLE-0K4 X =XBOOLE-0R4 {}XBOOLE-0K1 iff x inHIDDENR3 X & y inHIDDENR3 X"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  not ({TARSKIK2 x,y } \\XBOOLE-0K4 X =XBOOLE-0R4 {}XBOOLE-0K1 &  not (x inHIDDENR3 X & y inHIDDENR3 X)) &  not ((x inHIDDENR3 X & y inHIDDENR3 X) &  not {TARSKIK2 x,y } \\XBOOLE-0K4 X =XBOOLE-0R4 {}XBOOLE-0K1)"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    have "{TARSKIK2 x,y } \\XBOOLE-0K4 X =XBOOLE-0R4 {}XBOOLE-0K1 iff {TARSKIK2 x,y } c=TARSKIR1 X"
      using xboole_1_th_37 sorry
    thus " not ({TARSKIK2 x,y } \\XBOOLE-0K4 X =XBOOLE-0R4 {}XBOOLE-0K1 &  not (x inHIDDENR3 X & y inHIDDENR3 X)) &  not ((x inHIDDENR3 X & y inHIDDENR3 X) &  not {TARSKIK2 x,y } \\XBOOLE-0K4 X =XBOOLE-0R4 {}XBOOLE-0K1)"
      using zfmisc_1_th_32 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_65:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds (({TARSKIK2 x,y } \\XBOOLE-0K4 X =XBOOLE-0R4 {}XBOOLE-0K1 or {TARSKIK2 x,y } \\XBOOLE-0K4 X =XBOOLE-0R4 {TARSKIK1 x}) or {TARSKIK2 x,y } \\XBOOLE-0K4 X =XBOOLE-0R4 {TARSKIK1 y}) or {TARSKIK2 x,y } \\XBOOLE-0K4 X =XBOOLE-0R4 {TARSKIK2 x,y }"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds {TARSKIK2 x,y } \\XBOOLE-0K4 X <>HIDDENR2 {}XBOOLE-0K1 & ({TARSKIK2 x,y } \\XBOOLE-0K4 X <>HIDDENR2 {TARSKIK1 x} & {TARSKIK2 x,y } \\XBOOLE-0K4 X <>HIDDENR2 {TARSKIK1 y}) implies {TARSKIK2 x,y } \\XBOOLE-0K4 X =XBOOLE-0R4 {TARSKIK2 x,y }"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "{TARSKIK2 x,y } \\XBOOLE-0K4 X <>HIDDENR2 {}XBOOLE-0K1"
      and A2: "{TARSKIK2 x,y } \\XBOOLE-0K4 X <>HIDDENR2 {TARSKIK1 x}"
      and A3: "{TARSKIK2 x,y } \\XBOOLE-0K4 X <>HIDDENR2 {TARSKIK1 y}"
    have A4: " not x inHIDDENR3 X & x <>HIDDENR2 y or y inHIDDENR3 X"
      using A3 zfmisc_1_lm_11 sorry
    have "x inHIDDENR3 X or  not y inHIDDENR3 X & x <>HIDDENR2 y"
      using A2 zfmisc_1_lm_11 sorry
    thus "{TARSKIK2 x,y } \\XBOOLE-0K4 X =XBOOLE-0R4 {TARSKIK2 x,y }"
      using A1 A4 zfmisc_1_th_51 zfmisc_1_th_64 xboole_1_th_83 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_66:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds X \\XBOOLE-0K4 {TARSKIK2 x,y } =XBOOLE-0R4 {}XBOOLE-0K1 iff ((X =XBOOLE-0R4 {}XBOOLE-0K1 or X =XBOOLE-0R4 {TARSKIK1 x}) or X =XBOOLE-0R4 {TARSKIK1 y}) or X =XBOOLE-0R4 {TARSKIK2 x,y }"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  not ((((X \\XBOOLE-0K4 {TARSKIK2 x,y } =XBOOLE-0R4 {}XBOOLE-0K1 &  not X =XBOOLE-0R4 {}XBOOLE-0K1) &  not X =XBOOLE-0R4 {TARSKIK1 x}) &  not X =XBOOLE-0R4 {TARSKIK1 y}) &  not X =XBOOLE-0R4 {TARSKIK2 x,y }) &  not ( not ((( not X =XBOOLE-0R4 {}XBOOLE-0K1 &  not X =XBOOLE-0R4 {TARSKIK1 x}) &  not X =XBOOLE-0R4 {TARSKIK1 y}) &  not X =XBOOLE-0R4 {TARSKIK2 x,y }) &  not X \\XBOOLE-0K4 {TARSKIK2 x,y } =XBOOLE-0R4 {}XBOOLE-0K1)"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    have "X \\XBOOLE-0K4 {TARSKIK2 x,y } =XBOOLE-0R4 {}XBOOLE-0K1 iff X c=TARSKIR1 {TARSKIK2 x,y }"
      using xboole_1_th_37 sorry
    thus " not ((((X \\XBOOLE-0K4 {TARSKIK2 x,y } =XBOOLE-0R4 {}XBOOLE-0K1 &  not X =XBOOLE-0R4 {}XBOOLE-0K1) &  not X =XBOOLE-0R4 {TARSKIK1 x}) &  not X =XBOOLE-0R4 {TARSKIK1 y}) &  not X =XBOOLE-0R4 {TARSKIK2 x,y }) &  not ( not ((( not X =XBOOLE-0R4 {}XBOOLE-0K1 &  not X =XBOOLE-0R4 {TARSKIK1 x}) &  not X =XBOOLE-0R4 {TARSKIK1 y}) &  not X =XBOOLE-0R4 {TARSKIK2 x,y }) &  not X \\XBOOLE-0K4 {TARSKIK2 x,y } =XBOOLE-0R4 {}XBOOLE-0K1)"
      using zfmisc_1_lm_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_67:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds A c=TARSKIR1 B implies boolZFMISC-1K1 A c=TARSKIR1 boolZFMISC-1K1 B"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds A c=TARSKIR1 B implies boolZFMISC-1K1 A c=TARSKIR1 boolZFMISC-1K1 B"
  proof(rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    assume A1: "A c=TARSKIR1 B"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 boolZFMISC-1K1 A implies x inHIDDENR3 boolZFMISC-1K1 B"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      obtain xx where 
        [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
        using tarski_th_1 sorry
      assume "x inHIDDENR3 boolZFMISC-1K1 A"
      then have "xx c=TARSKIR1 A"
        using zfmisc_1_def_1 sorry
      then have "xx c=TARSKIR1 B"
        using A1 sorry
      thus "x inHIDDENR3 boolZFMISC-1K1 B"
        using zfmisc_1_def_1 sorry
    qed "sorry"
    thus "boolZFMISC-1K1 A c=TARSKIR1 boolZFMISC-1K1 B"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_68:
" for A be setHIDDENM2 holds {TARSKIK1 A} c=TARSKIR1 boolZFMISC-1K1 A"
proof-
  have " for A be setHIDDENM2 holds {TARSKIK1 A} c=TARSKIR1 boolZFMISC-1K1 A"
  proof(rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    have "A inTARSKIR2 boolZFMISC-1K1 A"
      using zfmisc_1_def_1 sorry
    thus "{TARSKIK1 A} c=TARSKIR1 boolZFMISC-1K1 A"
      using zfmisc_1_lm_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_69:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds boolZFMISC-1K1 A \\/XBOOLE-0K2 boolZFMISC-1K1 B c=TARSKIR1 boolZFMISC-1K1 (A \\/XBOOLE-0K2 B)"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds boolZFMISC-1K1 A \\/XBOOLE-0K2 boolZFMISC-1K1 B c=TARSKIR1 boolZFMISC-1K1 (A \\/XBOOLE-0K2 B)"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 boolZFMISC-1K1 A \\/XBOOLE-0K2 boolZFMISC-1K1 B implies x inHIDDENR3 boolZFMISC-1K1 (A \\/XBOOLE-0K2 B)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      obtain xx where 
        [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
        using tarski_th_1 sorry
      assume "x inHIDDENR3 boolZFMISC-1K1 A \\/XBOOLE-0K2 boolZFMISC-1K1 B"
      then have "x inHIDDENR3 boolZFMISC-1K1 A or x inHIDDENR3 boolZFMISC-1K1 B"
        using xboole_0_def_3 sorry
      then have A1: "xx c=TARSKIR1 A or xx c=TARSKIR1 B"
        using zfmisc_1_def_1 sorry
      have "A c=TARSKIR1 A \\/XBOOLE-0K2 B & B c=TARSKIR1 A \\/XBOOLE-0K2 B"
        using xboole_1_th_7 sorry
      then have "xx c=TARSKIR1 A \\/XBOOLE-0K2 B"
        using A1 sorry
      thus "x inHIDDENR3 boolZFMISC-1K1 (A \\/XBOOLE-0K2 B)"
        using zfmisc_1_def_1 sorry
    qed "sorry"
    thus "boolZFMISC-1K1 A \\/XBOOLE-0K2 boolZFMISC-1K1 B c=TARSKIR1 boolZFMISC-1K1 (A \\/XBOOLE-0K2 B)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_70:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds boolZFMISC-1K1 A \\/XBOOLE-0K2 boolZFMISC-1K1 B =XBOOLE-0R4 boolZFMISC-1K1 (A \\/XBOOLE-0K2 B) implies (A,B)are-c=-comparableXBOOLE-0R3"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds boolZFMISC-1K1 A \\/XBOOLE-0K2 boolZFMISC-1K1 B =XBOOLE-0R4 boolZFMISC-1K1 (A \\/XBOOLE-0K2 B) implies (A,B)are-c=-comparableXBOOLE-0R3"
  proof(rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    assume A1: "boolZFMISC-1K1 A \\/XBOOLE-0K2 boolZFMISC-1K1 B =XBOOLE-0R4 boolZFMISC-1K1 (A \\/XBOOLE-0K2 B)"
    have "A \\/XBOOLE-0K2 B inTARSKIR2 boolZFMISC-1K1 (A \\/XBOOLE-0K2 B)"
      using zfmisc_1_def_1 sorry
    then have "A \\/XBOOLE-0K2 B inTARSKIR2 boolZFMISC-1K1 A or A \\/XBOOLE-0K2 B inTARSKIR2 boolZFMISC-1K1 B"
      using A1 xboole_0_def_3 sorry
    then have A2: "A \\/XBOOLE-0K2 B c=TARSKIR1 A or A \\/XBOOLE-0K2 B c=TARSKIR1 B"
      using zfmisc_1_def_1 sorry
    have Cut905: "A c=TARSKIR1 A \\/XBOOLE-0K2 B & B c=TARSKIR1 A \\/XBOOLE-0K2 B"
      using xboole_1_th_7 sorry
    have "A c=TARSKIR1 B or B c=TARSKIR1 A"
    proof-
      show "A c=TARSKIR1 B or B c=TARSKIR1 A"
        using A2 Cut905 sorry
    qed
    thus "(A,B)are-c=-comparableXBOOLE-0R3"
      using xboole_0_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_71:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds boolZFMISC-1K1 (A /\\XBOOLE-0K3 B) =XBOOLE-0R4 boolZFMISC-1K1 A /\\XBOOLE-0K3 boolZFMISC-1K1 B"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds boolZFMISC-1K1 (A /\\XBOOLE-0K3 B) =XBOOLE-0R4 boolZFMISC-1K1 A /\\XBOOLE-0K3 boolZFMISC-1K1 B"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 boolZFMISC-1K1 (A /\\XBOOLE-0K3 B) iff x inHIDDENR3 boolZFMISC-1K1 A /\\XBOOLE-0K3 boolZFMISC-1K1 B"
    proof(rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      obtain xx where 
        [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
        using tarski_th_1 sorry
      have "A /\\XBOOLE-0K3 B c=TARSKIR1 A & A /\\XBOOLE-0K3 B c=TARSKIR1 B"
        using xboole_1_th_17 sorry
      then have "xx c=TARSKIR1 A & xx c=TARSKIR1 B iff xx c=TARSKIR1 A /\\XBOOLE-0K3 B"
        using xboole_1_th_19 sorry
      then have "x inHIDDENR3 boolZFMISC-1K1 A & x inHIDDENR3 boolZFMISC-1K1 B iff x inHIDDENR3 boolZFMISC-1K1 (A /\\XBOOLE-0K3 B)"
        using zfmisc_1_def_1 sorry
      thus "x inHIDDENR3 boolZFMISC-1K1 (A /\\XBOOLE-0K3 B) iff x inHIDDENR3 boolZFMISC-1K1 A /\\XBOOLE-0K3 boolZFMISC-1K1 B"
        using xboole_0_def_4 sorry
    qed "sorry"
    thus "boolZFMISC-1K1 (A /\\XBOOLE-0K3 B) =XBOOLE-0R4 boolZFMISC-1K1 A /\\XBOOLE-0K3 boolZFMISC-1K1 B"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_72:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds boolZFMISC-1K1 (A \\XBOOLE-0K4 B) c=TARSKIR1 {TARSKIK1 {}XBOOLE-0K1 } \\/XBOOLE-0K2 (boolZFMISC-1K1 A \\XBOOLE-0K4 boolZFMISC-1K1 B)"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds boolZFMISC-1K1 (A \\XBOOLE-0K4 B) c=TARSKIR1 {TARSKIK1 {}XBOOLE-0K1 } \\/XBOOLE-0K2 (boolZFMISC-1K1 A \\XBOOLE-0K4 boolZFMISC-1K1 B)"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 boolZFMISC-1K1 (A \\XBOOLE-0K4 B) implies x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 } \\/XBOOLE-0K2 (boolZFMISC-1K1 A \\XBOOLE-0K4 boolZFMISC-1K1 B)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      obtain xx where 
        [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
        using tarski_th_1 sorry
      assume "x inHIDDENR3 boolZFMISC-1K1 (A \\XBOOLE-0K4 B)"
      then have A1: "xx c=TARSKIR1 A \\XBOOLE-0K4 B"
        using zfmisc_1_def_1 sorry
      then have "xx missesXBOOLE-0R1 B"
        using xboole_1_th_63 xboole_1_th_79 sorry
      then have "A \\XBOOLE-0K4 B c=TARSKIR1 A & xx /\\XBOOLE-0K3 B =XBOOLE-0R4 {}XBOOLE-0K1"
        using xboole_1_th_36 sorry
      then have "x =HIDDENR1 {}XBOOLE-0K1 or xx c=TARSKIR1 A &  not xx c=TARSKIR1 B"
        using A1 xboole_1_th_28 sorry
      then have "x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 } or x inHIDDENR3 boolZFMISC-1K1 A &  not x inHIDDENR3 boolZFMISC-1K1 B"
        using zfmisc_1_def_1 tarski_def_1 sorry
      then have "x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 } or x inHIDDENR3 boolZFMISC-1K1 A \\XBOOLE-0K4 boolZFMISC-1K1 B"
        using xboole_0_def_5 sorry
      thus "x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 } \\/XBOOLE-0K2 (boolZFMISC-1K1 A \\XBOOLE-0K4 boolZFMISC-1K1 B)"
        using xboole_0_def_3 sorry
    qed "sorry"
    thus "boolZFMISC-1K1 (A \\XBOOLE-0K4 B) c=TARSKIR1 {TARSKIK1 {}XBOOLE-0K1 } \\/XBOOLE-0K2 (boolZFMISC-1K1 A \\XBOOLE-0K4 boolZFMISC-1K1 B)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_73:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds boolZFMISC-1K1 (A \\XBOOLE-0K4 B) \\/XBOOLE-0K2 boolZFMISC-1K1 (B \\XBOOLE-0K4 A) c=TARSKIR1 boolZFMISC-1K1 (A \\+\\XBOOLE-0K5 B)"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds boolZFMISC-1K1 (A \\XBOOLE-0K4 B) \\/XBOOLE-0K2 boolZFMISC-1K1 (B \\XBOOLE-0K4 A) c=TARSKIR1 boolZFMISC-1K1 (A \\+\\XBOOLE-0K5 B)"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 boolZFMISC-1K1 (A \\XBOOLE-0K4 B) \\/XBOOLE-0K2 boolZFMISC-1K1 (B \\XBOOLE-0K4 A) implies x inHIDDENR3 boolZFMISC-1K1 (A \\+\\XBOOLE-0K5 B)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      obtain xx where 
        [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
        using tarski_th_1 sorry
      assume "x inHIDDENR3 boolZFMISC-1K1 (A \\XBOOLE-0K4 B) \\/XBOOLE-0K2 boolZFMISC-1K1 (B \\XBOOLE-0K4 A)"
      then have "x inHIDDENR3 boolZFMISC-1K1 (A \\XBOOLE-0K4 B) or x inHIDDENR3 boolZFMISC-1K1 (B \\XBOOLE-0K4 A)"
        using xboole_0_def_3 sorry
      then have A1: "xx c=TARSKIR1 A \\XBOOLE-0K4 B or xx c=TARSKIR1 B \\XBOOLE-0K4 A"
        using zfmisc_1_def_1 sorry
      have "xx c=TARSKIR1 (A \\XBOOLE-0K4 B)\\/XBOOLE-0K2 (B \\XBOOLE-0K4 A)"
      proof-
        have " for z be objectHIDDENM1 holds z inHIDDENR3 xx implies z inHIDDENR3 (A \\XBOOLE-0K4 B)\\/XBOOLE-0K2 (B \\XBOOLE-0K4 A)"
        proof(rule ballI,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          assume "z inHIDDENR3 xx"
          then have "z inHIDDENR3 A \\XBOOLE-0K4 B or z inHIDDENR3 B \\XBOOLE-0K4 A"
            using A1 sorry
          thus "z inHIDDENR3 (A \\XBOOLE-0K4 B)\\/XBOOLE-0K2 (B \\XBOOLE-0K4 A)"
            using xboole_0_def_3 sorry
        qed "sorry"
        thus "xx c=TARSKIR1 (A \\XBOOLE-0K4 B)\\/XBOOLE-0K2 (B \\XBOOLE-0K4 A)"
          using tarski_def_3 sorry
      qed
      thus "x inHIDDENR3 boolZFMISC-1K1 (A \\+\\XBOOLE-0K5 B)"
        using zfmisc_1_def_1 sorry
    qed "sorry"
    thus "boolZFMISC-1K1 (A \\XBOOLE-0K4 B) \\/XBOOLE-0K2 boolZFMISC-1K1 (B \\XBOOLE-0K4 A) c=TARSKIR1 boolZFMISC-1K1 (A \\+\\XBOOLE-0K5 B)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_74:
" for A be setHIDDENM2 holds  for X be setHIDDENM2 holds X inTARSKIR2 A implies X c=TARSKIR1 unionTARSKIK3 A"
  using zfmisc_1_lm_14 sorry

mtheorem zfmisc_1_th_75:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds unionTARSKIK3 {TARSKIK2 X,Y } =XBOOLE-0R4 X \\/XBOOLE-0K2 Y"
  using zfmisc_1_lm_15 sorry

mtheorem zfmisc_1_th_76:
" for A be setHIDDENM2 holds  for Z be setHIDDENM2 holds ( for X be setHIDDENM2 holds X inTARSKIR2 A implies X c=TARSKIR1 Z) implies unionTARSKIK3 A c=TARSKIR1 Z"
proof-
  have " for A be setHIDDENM2 holds  for Z be setHIDDENM2 holds ( for X be setHIDDENM2 holds X inTARSKIR2 A implies X c=TARSKIR1 Z) implies unionTARSKIK3 A c=TARSKIR1 Z"
  proof(rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume A1: " for X be setHIDDENM2 holds X inTARSKIR2 A implies X c=TARSKIR1 Z"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 unionTARSKIK3 A implies y inHIDDENR3 Z"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 unionTARSKIK3 A"
      then obtain Y where
        [ty]:"Y be setHIDDENM2" and 
        A2: "y inHIDDENR3 Y"and A3: "Y inTARSKIR2 A"
        using tarski_def_4 sorry
      have "Y c=TARSKIR1 Z"
        using A1 A3 sorry
      thus "y inHIDDENR3 Z"
        using A2 sorry
    qed "sorry"
    thus "unionTARSKIK3 A c=TARSKIR1 Z"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_77:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds A c=TARSKIR1 B implies unionTARSKIK3 A c=TARSKIR1 unionTARSKIK3 B"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds A c=TARSKIR1 B implies unionTARSKIK3 A c=TARSKIR1 unionTARSKIK3 B"
  proof(rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    assume A1: "A c=TARSKIR1 B"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 A implies x inHIDDENR3 unionTARSKIK3 B"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 unionTARSKIK3 A"
      then obtain Y where
        [ty]:"Y be setHIDDENM2" and 
        A2: "x inHIDDENR3 Y"and A3: "Y inTARSKIR2 A"
        using tarski_def_4 sorry
      have "Y inTARSKIR2 B"
        using A1 A3 sorry
      thus "x inHIDDENR3 unionTARSKIK3 B"
        using A2 tarski_def_4 sorry
    qed "sorry"
    thus "unionTARSKIK3 A c=TARSKIR1 unionTARSKIK3 B"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_78:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds unionTARSKIK3 (A \\/XBOOLE-0K2 B) =XBOOLE-0R4 unionTARSKIK3 A \\/XBOOLE-0K2 unionTARSKIK3 B"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds unionTARSKIK3 (A \\/XBOOLE-0K2 B) =XBOOLE-0R4 unionTARSKIK3 A \\/XBOOLE-0K2 unionTARSKIK3 B"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    have A1: "unionTARSKIK3 (A \\/XBOOLE-0K2 B) c=TARSKIR1 unionTARSKIK3 A \\/XBOOLE-0K2 unionTARSKIK3 B"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 (A \\/XBOOLE-0K2 B) implies x inHIDDENR3 unionTARSKIK3 A \\/XBOOLE-0K2 unionTARSKIK3 B"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 unionTARSKIK3 (A \\/XBOOLE-0K2 B)"
        then obtain Y where
          [ty]:"Y be setHIDDENM2" and 
          A2: "x inHIDDENR3 Y"and A3: "Y inTARSKIR2 A \\/XBOOLE-0K2 B"
          using tarski_def_4 sorry
        have "Y inTARSKIR2 A or Y inTARSKIR2 B"
          using A3 xboole_0_def_3 sorry
        then have "x inHIDDENR3 unionTARSKIK3 A or x inHIDDENR3 unionTARSKIK3 B"
          using A2 tarski_def_4 sorry
        thus "x inHIDDENR3 unionTARSKIK3 A \\/XBOOLE-0K2 unionTARSKIK3 B"
          using xboole_0_def_3 sorry
      qed "sorry"
      thus "unionTARSKIK3 (A \\/XBOOLE-0K2 B) c=TARSKIR1 unionTARSKIK3 A \\/XBOOLE-0K2 unionTARSKIK3 B"
        using tarski_def_3 sorry
    qed
    have "unionTARSKIK3 A c=TARSKIR1 unionTARSKIK3 (A \\/XBOOLE-0K2 B) & unionTARSKIK3 B c=TARSKIR1 unionTARSKIK3 (A \\/XBOOLE-0K2 B)"
      using zfmisc_1_th_77 xboole_1_th_7 sorry
    thus "unionTARSKIK3 (A \\/XBOOLE-0K2 B) =XBOOLE-0R4 unionTARSKIK3 A \\/XBOOLE-0K2 unionTARSKIK3 B"
      using A1 xboole_1_th_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_79:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds unionTARSKIK3 (A /\\XBOOLE-0K3 B) c=TARSKIR1 unionTARSKIK3 A /\\XBOOLE-0K3 unionTARSKIK3 B"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds unionTARSKIK3 (A /\\XBOOLE-0K3 B) c=TARSKIR1 unionTARSKIK3 A /\\XBOOLE-0K3 unionTARSKIK3 B"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 (A /\\XBOOLE-0K3 B) implies x inHIDDENR3 unionTARSKIK3 A /\\XBOOLE-0K3 unionTARSKIK3 B"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 unionTARSKIK3 (A /\\XBOOLE-0K3 B)"
      then obtain Y where
        [ty]:"Y be setHIDDENM2" and 
        A1: "x inHIDDENR3 Y"and A2: "Y inTARSKIR2 A /\\XBOOLE-0K3 B"
        using tarski_def_4 sorry
      have "Y inTARSKIR2 B"
        using A2 xboole_0_def_4 sorry
      then have A3: "x inHIDDENR3 unionTARSKIK3 B"
        using A1 tarski_def_4 sorry
      have "Y inTARSKIR2 A"
        using A2 xboole_0_def_4 sorry
      then have "x inHIDDENR3 unionTARSKIK3 A"
        using A1 tarski_def_4 sorry
      thus "x inHIDDENR3 unionTARSKIK3 A /\\XBOOLE-0K3 unionTARSKIK3 B"
        using A3 xboole_0_def_4 sorry
    qed "sorry"
    thus "unionTARSKIK3 (A /\\XBOOLE-0K3 B) c=TARSKIR1 unionTARSKIK3 A /\\XBOOLE-0K3 unionTARSKIK3 B"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_80:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds ( for X be setHIDDENM2 holds X inTARSKIR2 A implies X missesXBOOLE-0R1 B) implies unionTARSKIK3 A missesXBOOLE-0R1 B"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds ( for X be setHIDDENM2 holds X inTARSKIR2 A implies X missesXBOOLE-0R1 B) implies (unionTARSKIK3 A meetsXBOOLE-0R5 B implies  False )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    assume A1: " for X be setHIDDENM2 holds X inTARSKIR2 A implies X missesXBOOLE-0R1 B"
    assume "unionTARSKIK3 A meetsXBOOLE-0R5 B"
    then obtain z where
      [ty]:"z be objectHIDDENM1" and 
      A2: "z inHIDDENR3 unionTARSKIK3 A /\\XBOOLE-0K3 B"
      using xboole_0_th_4 sorry
    have "z inHIDDENR3 unionTARSKIK3 A"
      using A2 xboole_0_def_4 sorry
    then obtain X where
      [ty]:"X be setHIDDENM2" and 
      A3: "z inHIDDENR3 X"and A4: "X inTARSKIR2 A"
      using tarski_def_4 sorry
    have "z inHIDDENR3 B"
      using A2 xboole_0_def_4 sorry
    then have "z inHIDDENR3 X /\\XBOOLE-0K3 B"
      using A3 xboole_0_def_4 sorry
    thus " False "
      using A1 A4 xboole_0_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_81:
" for A be setHIDDENM2 holds unionTARSKIK3 (boolZFMISC-1K1 A) =XBOOLE-0R4 A"
proof-
  have " for A be setHIDDENM2 holds unionTARSKIK3 (boolZFMISC-1K1 A) =XBOOLE-0R4 A"
  proof(rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    have " for x be objectHIDDENM1 holds (x inHIDDENR3 unionTARSKIK3 (boolZFMISC-1K1 A) implies x inHIDDENR3 A) & (x inHIDDENR3 A implies x inHIDDENR3 unionTARSKIK3 (boolZFMISC-1K1 A))"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      show "x inHIDDENR3 unionTARSKIK3 (boolZFMISC-1K1 A) implies x inHIDDENR3 A"
      proof(rule impI)
        assume "x inHIDDENR3 unionTARSKIK3 (boolZFMISC-1K1 A)"
        then obtain X where
          [ty]:"X be setHIDDENM2" and 
          A1: "x inHIDDENR3 X"and A2: "X inTARSKIR2 boolZFMISC-1K1 A"
          using tarski_def_4 sorry
        have "X c=TARSKIR1 A"
          using A2 zfmisc_1_def_1 sorry
        thus "x inHIDDENR3 A"
          using A1 sorry
      qed
      assume "x inHIDDENR3 A"
      then have "{TARSKIK1 x} c=TARSKIR1 A"
        using zfmisc_1_lm_1 sorry
      then have A3: "{TARSKIK1 x} inTARSKIR2 boolZFMISC-1K1 A"
        using zfmisc_1_def_1 sorry
      have "x inHIDDENR3 {TARSKIK1 x}"
        using tarski_def_1 sorry
      thus "x inHIDDENR3 unionTARSKIK3 (boolZFMISC-1K1 A)"
        using A3 tarski_def_4 sorry
    qed "sorry"
    thus "unionTARSKIK3 (boolZFMISC-1K1 A) =XBOOLE-0R4 A"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_82:
" for A be setHIDDENM2 holds A c=TARSKIR1 boolZFMISC-1K1 (unionTARSKIK3 A)"
proof-
  have " for A be setHIDDENM2 holds A c=TARSKIR1 boolZFMISC-1K1 (unionTARSKIK3 A)"
  proof(rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 A implies x inHIDDENR3 boolZFMISC-1K1 (unionTARSKIK3 A)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      obtain xx where 
        [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
        using tarski_th_1 sorry
      assume "x inHIDDENR3 A"
      then have "xx c=TARSKIR1 unionTARSKIK3 A"
        using zfmisc_1_lm_14 sorry
      thus "x inHIDDENR3 boolZFMISC-1K1 (unionTARSKIK3 A)"
        using zfmisc_1_def_1 sorry
    qed "sorry"
    thus "A c=TARSKIR1 boolZFMISC-1K1 (unionTARSKIK3 A)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_83:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (X <>HIDDENR2 Y & X inTARSKIR2 A \\/XBOOLE-0K2 B) & Y inTARSKIR2 A \\/XBOOLE-0K2 B implies X missesXBOOLE-0R1 Y) implies unionTARSKIK3 (A /\\XBOOLE-0K3 B) =XBOOLE-0R4 unionTARSKIK3 A /\\XBOOLE-0K3 unionTARSKIK3 B"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (X <>HIDDENR2 Y & X inTARSKIR2 A \\/XBOOLE-0K2 B) & Y inTARSKIR2 A \\/XBOOLE-0K2 B implies X missesXBOOLE-0R1 Y) implies unionTARSKIK3 (A /\\XBOOLE-0K3 B) =XBOOLE-0R4 unionTARSKIK3 A /\\XBOOLE-0K3 unionTARSKIK3 B"
  proof(rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    assume A1: " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (X <>HIDDENR2 Y & X inTARSKIR2 A \\/XBOOLE-0K2 B) & Y inTARSKIR2 A \\/XBOOLE-0K2 B implies X missesXBOOLE-0R1 Y"
    have "unionTARSKIK3 A /\\XBOOLE-0K3 unionTARSKIK3 B c=TARSKIR1 unionTARSKIK3 (A /\\XBOOLE-0K3 B)"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 A /\\XBOOLE-0K3 unionTARSKIK3 B implies x inHIDDENR3 unionTARSKIK3 (A /\\XBOOLE-0K3 B)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A2: "x inHIDDENR3 unionTARSKIK3 A /\\XBOOLE-0K3 unionTARSKIK3 B"
        then have "x inHIDDENR3 unionTARSKIK3 A"
          using xboole_0_def_4 sorry
        then obtain X where
          [ty]:"X be setHIDDENM2" and 
          A3: "x inHIDDENR3 X"and A4: "X inTARSKIR2 A"
          using tarski_def_4 sorry
        have "x inHIDDENR3 unionTARSKIK3 B"
          using A2 xboole_0_def_4 sorry
        then obtain Y where
          [ty]:"Y be setHIDDENM2" and 
          A5: "x inHIDDENR3 Y"and A6: "Y inTARSKIR2 B"
          using tarski_def_4 sorry
        have "X <>HIDDENR2 Y implies  False "
        proof(rule impI)
          have A7: "x inHIDDENR3 X /\\XBOOLE-0K3 Y"
            using A3 A5 xboole_0_def_4 sorry
          assume A8: "X <>HIDDENR2 Y"
          have "X inTARSKIR2 A \\/XBOOLE-0K2 B & Y inTARSKIR2 A \\/XBOOLE-0K2 B"
            using A4 A6 xboole_0_def_3 sorry
          thus " False "
            using A1 A8 A7 xboole_0_th_4 sorry
        qed
        then have "Y inTARSKIR2 A /\\XBOOLE-0K3 B"
          using A4 A6 xboole_0_def_4 sorry
        thus "x inHIDDENR3 unionTARSKIK3 (A /\\XBOOLE-0K3 B)"
          using A5 tarski_def_4 sorry
      qed "sorry"
      thus "unionTARSKIK3 A /\\XBOOLE-0K3 unionTARSKIK3 B c=TARSKIR1 unionTARSKIK3 (A /\\XBOOLE-0K3 B)"
        using tarski_def_3 sorry
    qed
    thus "unionTARSKIK3 (A /\\XBOOLE-0K3 B) =XBOOLE-0R4 unionTARSKIK3 A /\\XBOOLE-0K3 unionTARSKIK3 B"
      using zfmisc_1_th_79 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_84:
" for z be objectHIDDENM1 holds  for A be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds A c=TARSKIR1 [:ZFMISC-1K2 X,Y :] & z inHIDDENR3 A implies ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st (x inHIDDENR3 X & y inHIDDENR3 Y) & z =HIDDENR1 [TARSKIK4 x,y ])"
proof-
  have " for z be objectHIDDENM1 holds  for A be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds A c=TARSKIR1 [:ZFMISC-1K2 X,Y :] & z inHIDDENR3 A implies  not ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ((x inHIDDENR3 X & y inHIDDENR3 Y) & z =HIDDENR1 [TARSKIK4 x,y ]))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix z assume [ty]: "z be objectHIDDENM1"
    fix A assume [ty]: "A be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume "A c=TARSKIR1 [:ZFMISC-1K2 X,Y :] & z inHIDDENR3 A"
    then have "z inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
       sorry
    thus " not ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ((x inHIDDENR3 X & y inHIDDENR3 Y) & z =HIDDENR1 [TARSKIK4 x,y ]))"
      using zfmisc_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_85:
" for z be objectHIDDENM1 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds z inHIDDENR3 ([:ZFMISC-1K2 X1,Y1 :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 X2,Y2 :]) implies ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st (z =HIDDENR1 [TARSKIK4 x,y ] & x inHIDDENR3 X1 /\\XBOOLE-0K3 X2) & y inHIDDENR3 Y1 /\\XBOOLE-0K3 Y2)"
proof-
  have " for z be objectHIDDENM1 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds z inHIDDENR3 ([:ZFMISC-1K2 X1,Y1 :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 X2,Y2 :]) implies  not ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ((z =HIDDENR1 [TARSKIK4 x,y ] & x inHIDDENR3 X1 /\\XBOOLE-0K3 X2) & y inHIDDENR3 Y1 /\\XBOOLE-0K3 Y2))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix z assume [ty]: "z be objectHIDDENM1"
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix Y2 assume [ty]: "Y2 be setHIDDENM2"
    assume A1: "z inHIDDENR3 ([:ZFMISC-1K2 X1,Y1 :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 X2,Y2 :])"
    then have "z inHIDDENR3 [:ZFMISC-1K2 X1,Y1 :]"
      using xboole_0_def_4 sorry
    then obtain x1 y1 where
      [ty]:"x1 be objectHIDDENM1" "y1 be objectHIDDENM1" and 
      A2: "x1 inHIDDENR3 X1"and A3: "y1 inHIDDENR3 Y1"and A4: "z =HIDDENR1 [TARSKIK4 x1,y1 ]"
      using zfmisc_1_def_2 sorry
    have "z inHIDDENR3 [:ZFMISC-1K2 X2,Y2 :]"
      using A1 xboole_0_def_4 sorry
    then obtain x2 y2 where
      [ty]:"x2 be objectHIDDENM1" "y2 be objectHIDDENM1" and 
      A5: "x2 inHIDDENR3 X2"and A6: "y2 inHIDDENR3 Y2"and A7: "z =HIDDENR1 [TARSKIK4 x2,y2 ]"
      using zfmisc_1_def_2 sorry
    have "y1 =HIDDENR1 y2"
      using A4 A7 xtuple_0_th_1 sorry
    then have A8: "y1 inHIDDENR3 Y1 /\\XBOOLE-0K3 Y2"
      using A3 A6 xboole_0_def_4 sorry
    have "x1 =HIDDENR1 x2"
      using A4 A7 xtuple_0_th_1 sorry
    then have "x1 inHIDDENR3 X1 /\\XBOOLE-0K3 X2"
      using A2 A5 xboole_0_def_4 sorry
    thus " not ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ((z =HIDDENR1 [TARSKIK4 x,y ] & x inHIDDENR3 X1 /\\XBOOLE-0K3 X2) & y inHIDDENR3 Y1 /\\XBOOLE-0K3 Y2))"
      using A4 A8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_86:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds [:ZFMISC-1K2 X,Y :] c=TARSKIR1 boolZFMISC-1K1 (boolZFMISC-1K1 (X \\/XBOOLE-0K2 Y))"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds [:ZFMISC-1K2 X,Y :] c=TARSKIR1 boolZFMISC-1K1 (boolZFMISC-1K1 (X \\/XBOOLE-0K2 Y))"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have " for z be objectHIDDENM1 holds z inHIDDENR3 [:ZFMISC-1K2 X,Y :] implies z inHIDDENR3 boolZFMISC-1K1 (boolZFMISC-1K1 (X \\/XBOOLE-0K2 Y))"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be objectHIDDENM1"
      obtain zz where 
        [ty]:"zz be setHIDDENM2" and zzDef:"zz = z"
        using tarski_th_1 sorry
      assume "z inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
      then obtain x y where
        [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
        A1: "x inHIDDENR3 X"and A2: "y inHIDDENR3 Y"and A3: "z =HIDDENR1 [TARSKIK4 x,y ]"
        using zfmisc_1_def_2 sorry
      have "zz c=TARSKIR1 boolZFMISC-1K1 (X \\/XBOOLE-0K2 Y)"
      proof-
        have " for u be objectHIDDENM1 holds u inHIDDENR3 zz implies u inHIDDENR3 boolZFMISC-1K1 (X \\/XBOOLE-0K2 Y)"
        proof(rule ballI,rule impI)
          fix u assume [ty]: "u be objectHIDDENM1"
          assume "u inHIDDENR3 zz"
          then have A4: "u =HIDDENR1 {TARSKIK2 x,y } or u =HIDDENR1 {TARSKIK1 x}"
            using A3 tarski_def_2 sorry
          have "X c=TARSKIR1 X \\/XBOOLE-0K2 Y & {TARSKIK1 x} c=TARSKIR1 X"
            using A1 zfmisc_1_lm_1 xboole_1_th_7 sorry
          then have A5: "{TARSKIK1 x} c=TARSKIR1 X \\/XBOOLE-0K2 Y"
             sorry
          have "x inHIDDENR3 X \\/XBOOLE-0K2 Y & y inHIDDENR3 X \\/XBOOLE-0K2 Y"
            using A1 A2 xboole_0_def_3 sorry
          then have "{TARSKIK2 x,y } c=TARSKIR1 X \\/XBOOLE-0K2 Y"
            using zfmisc_1_th_32 sorry
          thus "u inHIDDENR3 boolZFMISC-1K1 (X \\/XBOOLE-0K2 Y)"
            using A5 A4 zfmisc_1_def_1 sorry
        qed "sorry"
        thus "zz c=TARSKIR1 boolZFMISC-1K1 (X \\/XBOOLE-0K2 Y)"
          using tarski_def_3 sorry
      qed
      thus "z inHIDDENR3 boolZFMISC-1K1 (boolZFMISC-1K1 (X \\/XBOOLE-0K2 Y))"
        using zfmisc_1_def_1 sorry
    qed "sorry"
    thus "[:ZFMISC-1K2 X,Y :] c=TARSKIR1 boolZFMISC-1K1 (boolZFMISC-1K1 (X \\/XBOOLE-0K2 Y))"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_87:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :] iff x inHIDDENR3 X & y inHIDDENR3 Y"
  using zfmisc_1_lm_16 sorry

mtheorem zfmisc_1_th_88:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :] implies [TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Y,X :]"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ([TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :] &  not [TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Y,X :])"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :] implies x inHIDDENR3 X & y inHIDDENR3 Y"
      using zfmisc_1_lm_16 sorry
    thus " not ([TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :] &  not [TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Y,X :])"
      using zfmisc_1_lm_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_89:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X1,Y1 :] iff [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X2,Y2 :]) implies [:ZFMISC-1K2 X1,Y1 :] =XBOOLE-0R4 [:ZFMISC-1K2 X2,Y2 :]"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X1,Y1 :] iff [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X2,Y2 :]) implies [:ZFMISC-1K2 X1,Y1 :] =XBOOLE-0R4 [:ZFMISC-1K2 X2,Y2 :]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix Y2 assume [ty]: "Y2 be setHIDDENM2"
    assume A1: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X1,Y1 :] iff [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X2,Y2 :]"
    have " for z be objectHIDDENM1 holds (z inHIDDENR3 [:ZFMISC-1K2 X1,Y1 :] implies z inHIDDENR3 [:ZFMISC-1K2 X2,Y2 :]) & (z inHIDDENR3 [:ZFMISC-1K2 X2,Y2 :] implies z inHIDDENR3 [:ZFMISC-1K2 X1,Y1 :])"
    proof(rule ballI,rule conjMI,rule impI)
      fix z assume [ty]: "z be objectHIDDENM1"
      show "z inHIDDENR3 [:ZFMISC-1K2 X1,Y1 :] implies z inHIDDENR3 [:ZFMISC-1K2 X2,Y2 :]"
      proof(rule impI)
        assume A2: "z inHIDDENR3 [:ZFMISC-1K2 X1,Y1 :]"
        then have " ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st (x inHIDDENR3 X1 & y inHIDDENR3 Y1) & [TARSKIK4 x,y ] =HIDDENR1 z"
          using zfmisc_1_def_2 sorry
        thus "z inHIDDENR3 [:ZFMISC-1K2 X2,Y2 :]"
          using A1 A2 sorry
      qed
      assume A3: "z inHIDDENR3 [:ZFMISC-1K2 X2,Y2 :]"
      then have " ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st (x inHIDDENR3 X2 & y inHIDDENR3 Y2) & [TARSKIK4 x,y ] =HIDDENR1 z"
        using zfmisc_1_def_2 sorry
      thus "z inHIDDENR3 [:ZFMISC-1K2 X1,Y1 :]"
        using A1 A3 sorry
    qed "sorry"
    thus "[:ZFMISC-1K2 X1,Y1 :] =XBOOLE-0R4 [:ZFMISC-1K2 X2,Y2 :]"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma zfmisc_1_lm_17:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds (A c=TARSKIR1 [:ZFMISC-1K2 X1,Y1 :] & B c=TARSKIR1 [:ZFMISC-1K2 X2,Y2 :]) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 A iff [TARSKIK4 x,y ] inHIDDENR3 B) implies A =XBOOLE-0R4 B"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds A c=TARSKIR1 [:ZFMISC-1K2 X1,Y1 :] & (B c=TARSKIR1 [:ZFMISC-1K2 X2,Y2 :] & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 A iff [TARSKIK4 x,y ] inHIDDENR3 B)) implies A =XBOOLE-0R4 B"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix Y2 assume [ty]: "Y2 be setHIDDENM2"
    assume A1: "A c=TARSKIR1 [:ZFMISC-1K2 X1,Y1 :]"
      and A2: "B c=TARSKIR1 [:ZFMISC-1K2 X2,Y2 :]"
      and A3: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 A iff [TARSKIK4 x,y ] inHIDDENR3 B"
    have " for z be objectHIDDENM1 holds z inHIDDENR3 A iff z inHIDDENR3 B"
    proof(rule ballI)
      fix z assume [ty]: "z be objectHIDDENM1"
      have A4: "z inHIDDENR3 B implies ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st (x inHIDDENR3 X2 & y inHIDDENR3 Y2) & z =HIDDENR1 [TARSKIK4 x,y ])"
        using A2 zfmisc_1_th_84 sorry
      have "z inHIDDENR3 A implies ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st (x inHIDDENR3 X1 & y inHIDDENR3 Y1) & z =HIDDENR1 [TARSKIK4 x,y ])"
        using A1 zfmisc_1_th_84 sorry
      thus "z inHIDDENR3 A iff z inHIDDENR3 B"
        using A3 A4 sorry
    qed "sorry"
    thus "A =XBOOLE-0R4 B"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma zfmisc_1_lm_18:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds (( for z be objectHIDDENM1 holds z inHIDDENR3 A implies ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st z =HIDDENR1 [TARSKIK4 x,y ])) & ( for z be objectHIDDENM1 holds z inHIDDENR3 B implies ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st z =HIDDENR1 [TARSKIK4 x,y ]))) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 A iff [TARSKIK4 x,y ] inHIDDENR3 B) implies A =XBOOLE-0R4 B"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds ( for z be objectHIDDENM1 holds z inHIDDENR3 A implies ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st z =HIDDENR1 [TARSKIK4 x,y ])) & (( for z be objectHIDDENM1 holds z inHIDDENR3 B implies ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st z =HIDDENR1 [TARSKIK4 x,y ])) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 A iff [TARSKIK4 x,y ] inHIDDENR3 B)) implies A =XBOOLE-0R4 B"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    assume A1: " for z be objectHIDDENM1 holds z inHIDDENR3 A implies ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st z =HIDDENR1 [TARSKIK4 x,y ])"
      and A2: " for z be objectHIDDENM1 holds z inHIDDENR3 B implies ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st z =HIDDENR1 [TARSKIK4 x,y ])"
      and A3: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 A iff [TARSKIK4 x,y ] inHIDDENR3 B"
    have " for z be objectHIDDENM1 holds z inHIDDENR3 A iff z inHIDDENR3 B"
    proof(rule ballI)
      fix z assume [ty]: "z be objectHIDDENM1"
      have A4: "z inHIDDENR3 B implies ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st z =HIDDENR1 [TARSKIK4 x,y ])"
        using A2 sorry
      have "z inHIDDENR3 A implies ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st z =HIDDENR1 [TARSKIK4 x,y ])"
        using A1 sorry
      thus "z inHIDDENR3 A iff z inHIDDENR3 B"
        using A3 A4 sorry
    qed "sorry"
    thus "A =XBOOLE-0R4 B"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_90:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds [:ZFMISC-1K2 X,Y :] =XBOOLE-0R4 {}XBOOLE-0K1 iff X =XBOOLE-0R4 {}XBOOLE-0K1 or Y =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds ([:ZFMISC-1K2 X,Y :] =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1 or Y =XBOOLE-0R4 {}XBOOLE-0K1) & ( not ( not ( not ( not X =XBOOLE-0R4 {}XBOOLE-0K1 &  not Y =XBOOLE-0R4 {}XBOOLE-0K1) &  not [:ZFMISC-1K2 X,Y :] =XBOOLE-0R4 {}XBOOLE-0K1)) implies  False )"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    show "[:ZFMISC-1K2 X,Y :] =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1 or Y =XBOOLE-0R4 {}XBOOLE-0K1"
    proof-
      have "[:ZFMISC-1K2 X,Y :] =XBOOLE-0R4 {}XBOOLE-0K1 implies (X <>HIDDENR2 {}XBOOLE-0K1 implies (Y <>HIDDENR2 {}XBOOLE-0K1 implies  False ))"
      proof(rule impI,rule impI,rule impI)
        assume A1: "[:ZFMISC-1K2 X,Y :] =XBOOLE-0R4 {}XBOOLE-0K1"
        assume "X <>HIDDENR2 {}XBOOLE-0K1"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A2: "x inHIDDENR3 X"
          using xboole_0_th_7 sorry
        assume "Y <>HIDDENR2 {}XBOOLE-0K1"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A3: "y inHIDDENR3 Y"
          using xboole_0_th_7 sorry
        have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
          using A2 A3 zfmisc_1_def_2 sorry
        thus " False "
          using A1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A4: " not ( not ( not ( not X =XBOOLE-0R4 {}XBOOLE-0K1 &  not Y =XBOOLE-0R4 {}XBOOLE-0K1) &  not [:ZFMISC-1K2 X,Y :] =XBOOLE-0R4 {}XBOOLE-0K1))"
    then obtain z where
      [ty]:"z be objectHIDDENM1" and 
      A5: "z inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
      using xboole_0_th_7 sorry
    have " ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st (x inHIDDENR3 X & y inHIDDENR3 Y) & [TARSKIK4 x,y ] =HIDDENR1 z"
      using A5 zfmisc_1_def_2 sorry
    thus " False "
      using A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_91:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (X <>HIDDENR2 {}XBOOLE-0K1 & Y <>HIDDENR2 {}XBOOLE-0K1) & [:ZFMISC-1K2 X,Y :] =XBOOLE-0R4 [:ZFMISC-1K2 Y,X :] implies X =XBOOLE-0R4 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X <>HIDDENR2 {}XBOOLE-0K1 implies (Y <>HIDDENR2 {}XBOOLE-0K1 implies ([:ZFMISC-1K2 X,Y :] =XBOOLE-0R4 [:ZFMISC-1K2 Y,X :] implies X =XBOOLE-0R4 Y))"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume "X <>HIDDENR2 {}XBOOLE-0K1"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A1: "x inHIDDENR3 X"
      using xboole_0_th_7 sorry
    assume "Y <>HIDDENR2 {}XBOOLE-0K1"
    then obtain y where
      [ty]:"y be objectHIDDENM1" and 
      A2: "y inHIDDENR3 Y"
      using xboole_0_th_7 sorry
    assume A3: "[:ZFMISC-1K2 X,Y :] =XBOOLE-0R4 [:ZFMISC-1K2 Y,X :]"
    have " for z be objectHIDDENM1 holds z inHIDDENR3 X iff z inHIDDENR3 Y"
    proof-
      have " for z be objectHIDDENM1 holds (z inHIDDENR3 X implies z inHIDDENR3 Y) & (z inHIDDENR3 Y implies z inHIDDENR3 X)"
      proof(rule ballI,rule conjMI,rule impI)
        fix z assume [ty]: "z be objectHIDDENM1"
        show "z inHIDDENR3 X implies z inHIDDENR3 Y"
        proof(rule impI)
          assume "z inHIDDENR3 X"
          then have "[TARSKIK4 z,y ] inHIDDENR3 [:ZFMISC-1K2 Y,X :]"
            using A2 A3 zfmisc_1_lm_16 sorry
          thus "z inHIDDENR3 Y"
            using zfmisc_1_lm_16 sorry
        qed
        assume "z inHIDDENR3 Y"
        then have "[TARSKIK4 z,x ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
          using A1 A3 zfmisc_1_lm_16 sorry
        thus "z inHIDDENR3 X"
          using zfmisc_1_lm_16 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "X =XBOOLE-0R4 Y"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_92:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds [:ZFMISC-1K2 X,X :] =XBOOLE-0R4 [:ZFMISC-1K2 Y,Y :] implies X =XBOOLE-0R4 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds [:ZFMISC-1K2 X,X :] =XBOOLE-0R4 [:ZFMISC-1K2 Y,Y :] implies X =XBOOLE-0R4 Y"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "[:ZFMISC-1K2 X,X :] =XBOOLE-0R4 [:ZFMISC-1K2 Y,Y :]"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X iff x inHIDDENR3 Y"
    proof-
      have " for x be objectHIDDENM1 holds  not (x inHIDDENR3 X &  not x inHIDDENR3 Y) &  not (x inHIDDENR3 Y &  not x inHIDDENR3 X)"
      proof(rule ballI)
        fix x assume [ty]: "x be objectHIDDENM1"
        have "x inHIDDENR3 X iff [TARSKIK4 x,x ] inHIDDENR3 [:ZFMISC-1K2 X,X :]"
          using zfmisc_1_lm_16 sorry
        thus " not (x inHIDDENR3 X &  not x inHIDDENR3 Y) &  not (x inHIDDENR3 Y &  not x inHIDDENR3 X)"
          using A1 zfmisc_1_lm_16 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "X =XBOOLE-0R4 Y"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma zfmisc_1_lm_19:
" for z be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds z inHIDDENR3 [:ZFMISC-1K2 X,Y :] implies ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st [TARSKIK4 x,y ] =HIDDENR1 z)"
proof-
  have " for z be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds z inHIDDENR3 [:ZFMISC-1K2 X,Y :] implies  not ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not [TARSKIK4 x,y ] =HIDDENR1 z)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix z assume [ty]: "z be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume "z inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
    then have " ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st (x inHIDDENR3 X & y inHIDDENR3 Y) & [TARSKIK4 x,y ] =HIDDENR1 z"
      using zfmisc_1_def_2 sorry
    thus " not ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not [TARSKIK4 x,y ] =HIDDENR1 z)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_93:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 [:ZFMISC-1K2 X,Y :] implies X =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 [:ZFMISC-1K2 X,Y :] implies (X <>HIDDENR2 {}XBOOLE-0K1 implies  False )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "X c=TARSKIR1 [:ZFMISC-1K2 X,Y :]"
    assume "X <>HIDDENR2 {}XBOOLE-0K1"
    then obtain z where
      [ty]:"z be objectHIDDENM1" and 
      A2: "z inHIDDENR3 X"
      using xboole_0_th_7 sorry
    obtain M where
      [ty]:"M be setHIDDENM2" and 
      A3: "M inTARSKIR2 X \\/XBOOLE-0K2 unionTARSKIK3 X"and A4: "X \\/XBOOLE-0K2 unionTARSKIK3 X missesXBOOLE-0R1 M"
      using A2 xregular_th_1 sorry
    have "M inTARSKIR2 X implies  False "
    proof(rule impI)
      assume A5: "M inTARSKIR2 X"
      then obtain x y where
        [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
        A6: "M =HIDDENR1 [TARSKIK4 x,y ]"
        using zfmisc_1_lm_19 A1 sorry
      have A7: "{TARSKIK1 x} inTARSKIR2 M"
        using A6 tarski_def_2 sorry
      have "M c=TARSKIR1 unionTARSKIK3 X"
        using A5 zfmisc_1_lm_14 sorry
      then have "{TARSKIK1 x} inTARSKIR2 unionTARSKIK3 X"
        using A7 sorry
      then have "{TARSKIK1 x} inTARSKIR2 X \\/XBOOLE-0K2 unionTARSKIK3 X"
        using xboole_0_def_3 sorry
      thus " False "
        using A4 A7 xboole_0_th_3 sorry
    qed
    then have "M inTARSKIR2 unionTARSKIK3 X"
      using A3 xboole_0_def_3 sorry
    then obtain Z where
      [ty]:"Z be setHIDDENM2" and 
      A8: "M inTARSKIR2 Z"and A9: "Z inTARSKIR2 X"
      using tarski_def_4 sorry
    have "Z inTARSKIR2 [:ZFMISC-1K2 X,Y :]"
      using A1 A9 sorry
    then obtain x y where
      [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
      A10: "x inHIDDENR3 X"and "y inHIDDENR3 Y"and A11: "Z =HIDDENR1 [TARSKIK4 x,y ]"
      using zfmisc_1_def_2 sorry
    have "M =XBOOLE-0R4 {TARSKIK1 x} or M =XBOOLE-0R4 {TARSKIK2 x,y }"
      using A8 A11 tarski_def_2 sorry
    then have A12: "x inHIDDENR3 M"
      using tarski_def_1 tarski_def_2 sorry
    have "x inHIDDENR3 X \\/XBOOLE-0K2 unionTARSKIK3 X"
      using A10 xboole_0_def_3 sorry
    thus " False "
      using A4 A12 xboole_0_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_94:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds Z <>HIDDENR2 {}XBOOLE-0K1 & ([:ZFMISC-1K2 X,Z :] c=TARSKIR1 [:ZFMISC-1K2 Y,Z :] or [:ZFMISC-1K2 Z,X :] c=TARSKIR1 [:ZFMISC-1K2 Z,Y :]) implies X c=TARSKIR1 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds Z <>HIDDENR2 {}XBOOLE-0K1 implies ([:ZFMISC-1K2 X,Z :] c=TARSKIR1 [:ZFMISC-1K2 Y,Z :] or [:ZFMISC-1K2 Z,X :] c=TARSKIR1 [:ZFMISC-1K2 Z,Y :] implies X c=TARSKIR1 Y)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume "Z <>HIDDENR2 {}XBOOLE-0K1"
    then obtain z where
      [ty]:"z be objectHIDDENM1" and 
      A1: "z inHIDDENR3 Z"
      using xboole_0_th_7 sorry
    assume A2: "[:ZFMISC-1K2 X,Z :] c=TARSKIR1 [:ZFMISC-1K2 Y,Z :] or [:ZFMISC-1K2 Z,X :] c=TARSKIR1 [:ZFMISC-1K2 Z,Y :]"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 Y"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 X"
      then have "[TARSKIK4 x,z ] inHIDDENR3 [:ZFMISC-1K2 X,Z :] & [TARSKIK4 z,x ] inHIDDENR3 [:ZFMISC-1K2 Z,X :]"
        using A1 zfmisc_1_def_2 sorry
      then have "[TARSKIK4 x,z ] inHIDDENR3 [:ZFMISC-1K2 Y,Z :] or [TARSKIK4 z,x ] inHIDDENR3 [:ZFMISC-1K2 Z,Y :]"
        using A2 sorry
      thus "x inHIDDENR3 Y"
        using zfmisc_1_lm_16 sorry
    qed "sorry"
    thus "X c=TARSKIR1 Y"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_95:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X c=TARSKIR1 Y implies [:ZFMISC-1K2 X,Z :] c=TARSKIR1 [:ZFMISC-1K2 Y,Z :] & [:ZFMISC-1K2 Z,X :] c=TARSKIR1 [:ZFMISC-1K2 Z,Y :]"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X c=TARSKIR1 Y implies [:ZFMISC-1K2 X,Z :] c=TARSKIR1 [:ZFMISC-1K2 Y,Z :] & [:ZFMISC-1K2 Z,X :] c=TARSKIR1 [:ZFMISC-1K2 Z,Y :]"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume A1: "X c=TARSKIR1 Y"
    show "[:ZFMISC-1K2 X,Z :] c=TARSKIR1 [:ZFMISC-1K2 Y,Z :]"
    proof-
      have " for z be objectHIDDENM1 holds z inHIDDENR3 [:ZFMISC-1K2 X,Z :] implies z inHIDDENR3 [:ZFMISC-1K2 Y,Z :]"
      proof(rule ballI,rule impI)
        fix z assume [ty]: "z be objectHIDDENM1"
        assume "z inHIDDENR3 [:ZFMISC-1K2 X,Z :]"
        then obtain x y where
          [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
          A2: "x inHIDDENR3 X"and A3: "y inHIDDENR3 Z & z =HIDDENR1 [TARSKIK4 x,y ]"
          using zfmisc_1_def_2 sorry
        have "x inHIDDENR3 Y"
          using A1 A2 sorry
        thus "z inHIDDENR3 [:ZFMISC-1K2 Y,Z :]"
          using A3 zfmisc_1_def_2 sorry
      qed "sorry"
      thus "[:ZFMISC-1K2 X,Z :] c=TARSKIR1 [:ZFMISC-1K2 Y,Z :]"
        using tarski_def_3 sorry
    qed
    have " for z be objectHIDDENM1 holds z inHIDDENR3 [:ZFMISC-1K2 Z,X :] implies z inHIDDENR3 [:ZFMISC-1K2 Z,Y :]"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be objectHIDDENM1"
      assume "z inHIDDENR3 [:ZFMISC-1K2 Z,X :]"
      then obtain y x where
        [ty]:"y be objectHIDDENM1" "x be objectHIDDENM1" and 
        A4: "y inHIDDENR3 Z"and A5: "x inHIDDENR3 X"and A6: "z =HIDDENR1 [TARSKIK4 y,x ]"
        using zfmisc_1_def_2 sorry
      have "x inHIDDENR3 Y"
        using A1 A5 sorry
      thus "z inHIDDENR3 [:ZFMISC-1K2 Z,Y :]"
        using A4 A6 zfmisc_1_def_2 sorry
    qed "sorry"
    thus "[:ZFMISC-1K2 Z,X :] c=TARSKIR1 [:ZFMISC-1K2 Z,Y :]"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_96:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds X1 c=TARSKIR1 Y1 & X2 c=TARSKIR1 Y2 implies [:ZFMISC-1K2 X1,X2 :] c=TARSKIR1 [:ZFMISC-1K2 Y1,Y2 :]"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds X1 c=TARSKIR1 Y1 & X2 c=TARSKIR1 Y2 implies [:ZFMISC-1K2 X1,X2 :] c=TARSKIR1 [:ZFMISC-1K2 Y1,Y2 :]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix Y2 assume [ty]: "Y2 be setHIDDENM2"
    assume "X1 c=TARSKIR1 Y1 & X2 c=TARSKIR1 Y2"
    then have "[:ZFMISC-1K2 X1,X2 :] c=TARSKIR1 [:ZFMISC-1K2 Y1,X2 :] & [:ZFMISC-1K2 Y1,X2 :] c=TARSKIR1 [:ZFMISC-1K2 Y1,Y2 :]"
      using zfmisc_1_th_95 sorry
    thus "[:ZFMISC-1K2 X1,X2 :] c=TARSKIR1 [:ZFMISC-1K2 Y1,Y2 :]"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_97:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds [:ZFMISC-1K2 X \\/XBOOLE-0K2 Y,Z :] =XBOOLE-0R4 [:ZFMISC-1K2 X,Z :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,Z :] & [:ZFMISC-1K2 Z,X \\/XBOOLE-0K2 Y :] =XBOOLE-0R4 [:ZFMISC-1K2 Z,X :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Z,Y :]"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds [:ZFMISC-1K2 X \\/XBOOLE-0K2 Y,Z :] =XBOOLE-0R4 [:ZFMISC-1K2 X,Z :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,Z :] & [:ZFMISC-1K2 Z,X \\/XBOOLE-0K2 Y :] =XBOOLE-0R4 [:ZFMISC-1K2 Z,X :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Z,Y :]"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have A1: " for z be objectHIDDENM1 holds z inHIDDENR3 [:ZFMISC-1K2 X \\/XBOOLE-0K2 Y,Z :] implies ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st z =HIDDENR1 [TARSKIK4 x,y ])"
      using zfmisc_1_lm_19 sorry
    have A2: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X \\/XBOOLE-0K2 Y,Z :] iff [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Z :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,Z :]"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X \\/XBOOLE-0K2 Y,Z :] implies [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Z :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,Z :]) & ([TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Z :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,Z :] implies [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X \\/XBOOLE-0K2 Y,Z :])"
      proof(rule ballI,rule ballI,rule conjMI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        show "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X \\/XBOOLE-0K2 Y,Z :] implies [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Z :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,Z :]"
        proof(rule impI)
          assume A3: "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X \\/XBOOLE-0K2 Y,Z :]"
          then have "x inHIDDENR3 X \\/XBOOLE-0K2 Y"
            using zfmisc_1_lm_16 sorry
          then have A4: "x inHIDDENR3 X or x inHIDDENR3 Y"
            using xboole_0_def_3 sorry
          have "y inHIDDENR3 Z"
            using A3 zfmisc_1_lm_16 sorry
          then have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Z :] or [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Y,Z :]"
            using A4 zfmisc_1_lm_16 sorry
          thus "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Z :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,Z :]"
            using xboole_0_def_3 sorry
        qed
        assume "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Z :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,Z :]"
        then have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Z :] or [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Y,Z :]"
          using xboole_0_def_3 sorry
        then have A5: "x inHIDDENR3 X & y inHIDDENR3 Z or x inHIDDENR3 Y & y inHIDDENR3 Z"
          using zfmisc_1_lm_16 sorry
        then have "x inHIDDENR3 X \\/XBOOLE-0K2 Y"
          using xboole_0_def_3 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X \\/XBOOLE-0K2 Y,Z :]"
          using A5 zfmisc_1_lm_16 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A6: " for z be objectHIDDENM1 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds z inHIDDENR3 [:ZFMISC-1K2 X1,X2 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y1,Y2 :] implies ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st z =HIDDENR1 [TARSKIK4 x,y ])"
    proof-
      have " for z be objectHIDDENM1 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds z inHIDDENR3 [:ZFMISC-1K2 X1,X2 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y1,Y2 :] implies  not ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not z =HIDDENR1 [TARSKIK4 x,y ])"
      proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
        fix z assume [ty]: "z be objectHIDDENM1"
        fix X1 assume [ty]: "X1 be setHIDDENM2"
        fix X2 assume [ty]: "X2 be setHIDDENM2"
        fix Y1 assume [ty]: "Y1 be setHIDDENM2"
        fix Y2 assume [ty]: "Y2 be setHIDDENM2"
        assume "z inHIDDENR3 [:ZFMISC-1K2 X1,X2 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y1,Y2 :]"
        then have "z inHIDDENR3 [:ZFMISC-1K2 X1,X2 :] or z inHIDDENR3 [:ZFMISC-1K2 Y1,Y2 :]"
          using xboole_0_def_3 sorry
        thus " not ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not z =HIDDENR1 [TARSKIK4 x,y ])"
          using zfmisc_1_lm_19 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have " for z be objectHIDDENM1 holds z inHIDDENR3 [:ZFMISC-1K2 X,Z :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,Z :] implies ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st z =HIDDENR1 [TARSKIK4 x,y ])"
       sorry
    thus A7: "[:ZFMISC-1K2 X \\/XBOOLE-0K2 Y,Z :] =XBOOLE-0R4 [:ZFMISC-1K2 X,Z :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,Z :]"
      using A1 A2 zfmisc_1_lm_18 sorry
    have A8: " for y be objectHIDDENM1 holds  for x be objectHIDDENM1 holds [TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,X \\/XBOOLE-0K2 Y :] iff [TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,X :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Z,Y :]"
    proof-
      have " for y be objectHIDDENM1 holds  for x be objectHIDDENM1 holds  not ([TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,X \\/XBOOLE-0K2 Y :] &  not [TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,X :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Z,Y :]) &  not ([TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,X :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Z,Y :] &  not [TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,X \\/XBOOLE-0K2 Y :])"
      proof(rule ballI,rule ballI)
        fix y assume [ty]: "y be objectHIDDENM1"
        fix x assume [ty]: "x be objectHIDDENM1"
        have A9: "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Z :] or [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Y,Z :] iff [TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,X :] or [TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,Y :]"
          using zfmisc_1_th_88 sorry
        have "[TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,X \\/XBOOLE-0K2 Y :] iff [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X \\/XBOOLE-0K2 Y,Z :]"
          using zfmisc_1_th_88 sorry
        thus " not ([TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,X \\/XBOOLE-0K2 Y :] &  not [TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,X :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Z,Y :]) &  not ([TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,X :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Z,Y :] &  not [TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,X \\/XBOOLE-0K2 Y :])"
          using A7 A9 xboole_0_def_3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A10: " for z be objectHIDDENM1 holds z inHIDDENR3 [:ZFMISC-1K2 Z,X \\/XBOOLE-0K2 Y :] implies ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st z =HIDDENR1 [TARSKIK4 x,y ])"
      using zfmisc_1_lm_19 sorry
    have " for z be objectHIDDENM1 holds z inHIDDENR3 [:ZFMISC-1K2 Z,X :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Z,Y :] implies ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st z =HIDDENR1 [TARSKIK4 x,y ])"
      using A6 sorry
    thus "[:ZFMISC-1K2 Z,X \\/XBOOLE-0K2 Y :] =XBOOLE-0R4 [:ZFMISC-1K2 Z,X :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Z,Y :]"
      using A10 A8 zfmisc_1_lm_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_98:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds [:ZFMISC-1K2 X1 \\/XBOOLE-0K2 X2,Y1 \\/XBOOLE-0K2 Y2 :] =XBOOLE-0R4 (([:ZFMISC-1K2 X1,Y1 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X1,Y2 :])\\/XBOOLE-0K2 [:ZFMISC-1K2 X2,Y1 :])\\/XBOOLE-0K2 [:ZFMISC-1K2 X2,Y2 :]"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds [:ZFMISC-1K2 X1 \\/XBOOLE-0K2 X2,Y1 \\/XBOOLE-0K2 Y2 :] =HIDDENR1 (([:ZFMISC-1K2 X1,Y1 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X1,Y2 :])\\/XBOOLE-0K2 [:ZFMISC-1K2 X2,Y1 :])\\/XBOOLE-0K2 [:ZFMISC-1K2 X2,Y2 :]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix Y2 assume [ty]: "Y2 be setHIDDENM2"
    have "[:ZFMISC-1K2 X1 \\/XBOOLE-0K2 X2,Y1 \\/XBOOLE-0K2 Y2 :] =HIDDENR1 [:ZFMISC-1K2 X1,Y1 \\/XBOOLE-0K2 Y2 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X2,Y1 \\/XBOOLE-0K2 Y2 :]"
      using zfmisc_1_th_97 sorry
    also have "... = ([:ZFMISC-1K2 X1,Y1 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X1,Y2 :])\\/XBOOLE-0K2 [:ZFMISC-1K2 X2,Y1 \\/XBOOLE-0K2 Y2 :]"
      using zfmisc_1_th_97 sorry
    also have "... = ([:ZFMISC-1K2 X1,Y1 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X1,Y2 :])\\/XBOOLE-0K2 ([:ZFMISC-1K2 X2,Y1 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X2,Y2 :])"
      using zfmisc_1_th_97 sorry
    also have "... = (([:ZFMISC-1K2 X1,Y1 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X1,Y2 :])\\/XBOOLE-0K2 [:ZFMISC-1K2 X2,Y1 :])\\/XBOOLE-0K2 [:ZFMISC-1K2 X2,Y2 :]"
      using xboole_1_th_4 sorry
    finally show "[:ZFMISC-1K2 X1 \\/XBOOLE-0K2 X2,Y1 \\/XBOOLE-0K2 Y2 :] =HIDDENR1 (([:ZFMISC-1K2 X1,Y1 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X1,Y2 :])\\/XBOOLE-0K2 [:ZFMISC-1K2 X2,Y1 :])\\/XBOOLE-0K2 [:ZFMISC-1K2 X2,Y2 :]"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_99:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds [:ZFMISC-1K2 X /\\XBOOLE-0K3 Y,Z :] =XBOOLE-0R4 ([:ZFMISC-1K2 X,Z :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 Y,Z :]) & [:ZFMISC-1K2 Z,X /\\XBOOLE-0K3 Y :] =XBOOLE-0R4 ([:ZFMISC-1K2 Z,X :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 Z,Y :])"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds [:ZFMISC-1K2 X /\\XBOOLE-0K3 Y,Z :] =XBOOLE-0R4 ([:ZFMISC-1K2 X,Z :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 Y,Z :]) & [:ZFMISC-1K2 Z,X /\\XBOOLE-0K3 Y :] =XBOOLE-0R4 ([:ZFMISC-1K2 Z,X :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 Z,Y :])"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have A1: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X /\\XBOOLE-0K3 Y,Z :] iff [TARSKIK4 x,y ] inHIDDENR3 ([:ZFMISC-1K2 X,Z :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 Y,Z :])"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X /\\XBOOLE-0K3 Y,Z :] implies [TARSKIK4 x,y ] inHIDDENR3 ([:ZFMISC-1K2 X,Z :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 Y,Z :])) & ([TARSKIK4 x,y ] inHIDDENR3 ([:ZFMISC-1K2 X,Z :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 Y,Z :]) implies [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X /\\XBOOLE-0K3 Y,Z :])"
      proof(rule ballI,rule ballI,rule conjMI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        show "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X /\\XBOOLE-0K3 Y,Z :] implies [TARSKIK4 x,y ] inHIDDENR3 ([:ZFMISC-1K2 X,Z :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 Y,Z :])"
        proof(rule impI)
          assume A2: "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X /\\XBOOLE-0K3 Y,Z :]"
          then have A3: "x inHIDDENR3 X /\\XBOOLE-0K3 Y"
            using zfmisc_1_lm_16 sorry
          have A4: "y inHIDDENR3 Z"
            using A2 zfmisc_1_lm_16 sorry
          have "x inHIDDENR3 Y"
            using A3 xboole_0_def_4 sorry
          then have A5: "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Y,Z :]"
            using A4 zfmisc_1_lm_16 sorry
          have "x inHIDDENR3 X"
            using A3 xboole_0_def_4 sorry
          then have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Z :]"
            using A4 zfmisc_1_lm_16 sorry
          thus "[TARSKIK4 x,y ] inHIDDENR3 ([:ZFMISC-1K2 X,Z :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 Y,Z :])"
            using A5 xboole_0_def_4 sorry
        qed
        assume A6: "[TARSKIK4 x,y ] inHIDDENR3 ([:ZFMISC-1K2 X,Z :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 Y,Z :])"
        then have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Y,Z :]"
          using xboole_0_def_4 sorry
        then have A7: "x inHIDDENR3 Y"
          using zfmisc_1_lm_16 sorry
        have A8: "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Z :]"
          using A6 xboole_0_def_4 sorry
        then have "x inHIDDENR3 X"
          using zfmisc_1_lm_16 sorry
        then have A9: "x inHIDDENR3 X /\\XBOOLE-0K3 Y"
          using A7 xboole_0_def_4 sorry
        have "y inHIDDENR3 Z"
          using A8 zfmisc_1_lm_16 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X /\\XBOOLE-0K3 Y,Z :]"
          using A9 zfmisc_1_lm_16 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "([:ZFMISC-1K2 X,Z :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 Y,Z :]) c=TARSKIR1 [:ZFMISC-1K2 X,Z :]"
      using xboole_1_th_17 sorry
    thus A10: "[:ZFMISC-1K2 X /\\XBOOLE-0K3 Y,Z :] =XBOOLE-0R4 ([:ZFMISC-1K2 X,Z :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 Y,Z :])"
      using A1 zfmisc_1_lm_17 sorry
    have A11: " for y be objectHIDDENM1 holds  for x be objectHIDDENM1 holds [TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,X /\\XBOOLE-0K3 Y :] iff [TARSKIK4 y,x ] inHIDDENR3 ([:ZFMISC-1K2 Z,X :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 Z,Y :])"
    proof-
      have " for y be objectHIDDENM1 holds  for x be objectHIDDENM1 holds  not ([TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,X /\\XBOOLE-0K3 Y :] &  not [TARSKIK4 y,x ] inHIDDENR3 ([:ZFMISC-1K2 Z,X :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 Z,Y :])) &  not ([TARSKIK4 y,x ] inHIDDENR3 ([:ZFMISC-1K2 Z,X :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 Z,Y :]) &  not [TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,X /\\XBOOLE-0K3 Y :])"
      proof(rule ballI,rule ballI)
        fix y assume [ty]: "y be objectHIDDENM1"
        fix x assume [ty]: "x be objectHIDDENM1"
        have A12: "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Z :] & [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Y,Z :] iff [TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,X :] & [TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,Y :]"
          using zfmisc_1_th_88 sorry
        have "[TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,X /\\XBOOLE-0K3 Y :] iff [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X /\\XBOOLE-0K3 Y,Z :]"
          using zfmisc_1_th_88 sorry
        thus " not ([TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,X /\\XBOOLE-0K3 Y :] &  not [TARSKIK4 y,x ] inHIDDENR3 ([:ZFMISC-1K2 Z,X :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 Z,Y :])) &  not ([TARSKIK4 y,x ] inHIDDENR3 ([:ZFMISC-1K2 Z,X :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 Z,Y :]) &  not [TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,X /\\XBOOLE-0K3 Y :])"
          using A10 A12 xboole_0_def_4 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "([:ZFMISC-1K2 Z,X :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 Z,Y :]) c=TARSKIR1 [:ZFMISC-1K2 Z,X :]"
      using xboole_1_th_17 sorry
    thus "[:ZFMISC-1K2 Z,X /\\XBOOLE-0K3 Y :] =XBOOLE-0R4 ([:ZFMISC-1K2 Z,X :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 Z,Y :])"
      using A11 zfmisc_1_lm_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_100:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds [:ZFMISC-1K2 X1 /\\XBOOLE-0K3 X2,Y1 /\\XBOOLE-0K3 Y2 :] =XBOOLE-0R4 ([:ZFMISC-1K2 X1,Y1 :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 X2,Y2 :])"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds [:ZFMISC-1K2 X1 /\\XBOOLE-0K3 X2,Y1 /\\XBOOLE-0K3 Y2 :] =XBOOLE-0R4 ([:ZFMISC-1K2 X1,Y1 :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 X2,Y2 :])"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix Y2 assume [ty]: "Y2 be setHIDDENM2"
    have "Y1 /\\XBOOLE-0K3 Y2 c=TARSKIR1 Y2 & X1 /\\XBOOLE-0K3 X2 c=TARSKIR1 X2"
      using xboole_1_th_17 sorry
    then have A1: "[:ZFMISC-1K2 X1 /\\XBOOLE-0K3 X2,Y1 /\\XBOOLE-0K3 Y2 :] c=TARSKIR1 [:ZFMISC-1K2 X2,Y2 :]"
      using zfmisc_1_th_96 sorry
    have A2: "([:ZFMISC-1K2 X1,Y1 :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 X2,Y2 :]) c=TARSKIR1 [:ZFMISC-1K2 X1 /\\XBOOLE-0K3 X2,Y1 /\\XBOOLE-0K3 Y2 :]"
    proof-
      have " for z be objectHIDDENM1 holds z inHIDDENR3 ([:ZFMISC-1K2 X1,Y1 :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 X2,Y2 :]) implies z inHIDDENR3 [:ZFMISC-1K2 X1 /\\XBOOLE-0K3 X2,Y1 /\\XBOOLE-0K3 Y2 :]"
      proof(rule ballI,rule impI)
        fix z assume [ty]: "z be objectHIDDENM1"
        assume "z inHIDDENR3 ([:ZFMISC-1K2 X1,Y1 :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 X2,Y2 :])"
        then have " ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st (z =HIDDENR1 [TARSKIK4 x,y ] & x inHIDDENR3 X1 /\\XBOOLE-0K3 X2) & y inHIDDENR3 Y1 /\\XBOOLE-0K3 Y2"
          using zfmisc_1_th_85 sorry
        thus "z inHIDDENR3 [:ZFMISC-1K2 X1 /\\XBOOLE-0K3 X2,Y1 /\\XBOOLE-0K3 Y2 :]"
          using zfmisc_1_def_2 sorry
      qed "sorry"
      thus "([:ZFMISC-1K2 X1,Y1 :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 X2,Y2 :]) c=TARSKIR1 [:ZFMISC-1K2 X1 /\\XBOOLE-0K3 X2,Y1 /\\XBOOLE-0K3 Y2 :]"
        using tarski_def_3 sorry
    qed
    have "Y1 /\\XBOOLE-0K3 Y2 c=TARSKIR1 Y1 & X1 /\\XBOOLE-0K3 X2 c=TARSKIR1 X1"
      using xboole_1_th_17 sorry
    then have "[:ZFMISC-1K2 X1 /\\XBOOLE-0K3 X2,Y1 /\\XBOOLE-0K3 Y2 :] c=TARSKIR1 [:ZFMISC-1K2 X1,Y1 :]"
      using zfmisc_1_th_96 sorry
    thus "[:ZFMISC-1K2 X1 /\\XBOOLE-0K3 X2,Y1 /\\XBOOLE-0K3 Y2 :] =XBOOLE-0R4 ([:ZFMISC-1K2 X1,Y1 :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 X2,Y2 :])"
      using A2 A1 xboole_1_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_101:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds A c=TARSKIR1 X & B c=TARSKIR1 Y implies ([:ZFMISC-1K2 A,Y :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 X,B :]) =XBOOLE-0R4 [:ZFMISC-1K2 A,B :]"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds A c=TARSKIR1 X & B c=TARSKIR1 Y implies ([:ZFMISC-1K2 A,Y :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 X,B :]) =XBOOLE-0R4 [:ZFMISC-1K2 A,B :]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "A c=TARSKIR1 X"
      and A2: "B c=TARSKIR1 Y"
    have A3: "([:ZFMISC-1K2 A,Y :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 X,B :]) =XBOOLE-0R4 [:ZFMISC-1K2 A /\\XBOOLE-0K3 X,Y /\\XBOOLE-0K3 B :]"
      using zfmisc_1_th_100 sorry
    have "A /\\XBOOLE-0K3 X =XBOOLE-0R4 A"
      using A1 xboole_1_th_28 sorry
    thus "([:ZFMISC-1K2 A,Y :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 X,B :]) =XBOOLE-0R4 [:ZFMISC-1K2 A,B :]"
      using A2 A3 xboole_1_th_28 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_102:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds [:ZFMISC-1K2 X \\XBOOLE-0K4 Y,Z :] =XBOOLE-0R4 [:ZFMISC-1K2 X,Z :] \\XBOOLE-0K4 [:ZFMISC-1K2 Y,Z :] & [:ZFMISC-1K2 Z,X \\XBOOLE-0K4 Y :] =XBOOLE-0R4 [:ZFMISC-1K2 Z,X :] \\XBOOLE-0K4 [:ZFMISC-1K2 Z,Y :]"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds [:ZFMISC-1K2 X \\XBOOLE-0K4 Y,Z :] =XBOOLE-0R4 [:ZFMISC-1K2 X,Z :] \\XBOOLE-0K4 [:ZFMISC-1K2 Y,Z :] & [:ZFMISC-1K2 Z,X \\XBOOLE-0K4 Y :] =XBOOLE-0R4 [:ZFMISC-1K2 Z,X :] \\XBOOLE-0K4 [:ZFMISC-1K2 Z,Y :]"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have A1: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X \\XBOOLE-0K4 Y,Z :] iff [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Z :] \\XBOOLE-0K4 [:ZFMISC-1K2 Y,Z :]"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X \\XBOOLE-0K4 Y,Z :] implies [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Z :] \\XBOOLE-0K4 [:ZFMISC-1K2 Y,Z :]) & ([TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Z :] \\XBOOLE-0K4 [:ZFMISC-1K2 Y,Z :] implies [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X \\XBOOLE-0K4 Y,Z :])"
      proof(rule ballI,rule ballI,rule conjMI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        show "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X \\XBOOLE-0K4 Y,Z :] implies [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Z :] \\XBOOLE-0K4 [:ZFMISC-1K2 Y,Z :]"
        proof(rule impI)
          assume A2: "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X \\XBOOLE-0K4 Y,Z :]"
          then have A3: "x inHIDDENR3 X \\XBOOLE-0K4 Y"
            using zfmisc_1_lm_16 sorry
          then have A4: "x inHIDDENR3 X"
            using xboole_0_def_5 sorry
          have " not x inHIDDENR3 Y"
            using A3 xboole_0_def_5 sorry
          then have A5: " not [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Y,Z :]"
            using zfmisc_1_lm_16 sorry
          have "y inHIDDENR3 Z"
            using A2 zfmisc_1_lm_16 sorry
          then have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Z :]"
            using A4 zfmisc_1_lm_16 sorry
          thus "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Z :] \\XBOOLE-0K4 [:ZFMISC-1K2 Y,Z :]"
            using A5 xboole_0_def_5 sorry
        qed
        assume A6: "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Z :] \\XBOOLE-0K4 [:ZFMISC-1K2 Y,Z :]"
        then have A7: "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Z :]"
          using xboole_0_def_5 sorry
        then have A8: "y inHIDDENR3 Z"
          using zfmisc_1_lm_16 sorry
        have " not [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Y,Z :]"
          using A6 xboole_0_def_5 sorry
        then have A9: " not (x inHIDDENR3 Y & y inHIDDENR3 Z)"
          using zfmisc_1_lm_16 sorry
        have "x inHIDDENR3 X"
          using A7 zfmisc_1_lm_16 sorry
        then have "x inHIDDENR3 X \\XBOOLE-0K4 Y"
          using A7 A9 zfmisc_1_lm_16 xboole_0_def_5 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X \\XBOOLE-0K4 Y,Z :]"
          using A8 zfmisc_1_lm_16 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "[:ZFMISC-1K2 X,Z :] \\XBOOLE-0K4 [:ZFMISC-1K2 Y,Z :] c=TARSKIR1 [:ZFMISC-1K2 X,Z :]"
      using xboole_1_th_36 sorry
    thus A10: "[:ZFMISC-1K2 X \\XBOOLE-0K4 Y,Z :] =XBOOLE-0R4 [:ZFMISC-1K2 X,Z :] \\XBOOLE-0K4 [:ZFMISC-1K2 Y,Z :]"
      using A1 zfmisc_1_lm_17 sorry
    have A11: " for y be objectHIDDENM1 holds  for x be objectHIDDENM1 holds [TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,X \\XBOOLE-0K4 Y :] iff [TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,X :] \\XBOOLE-0K4 [:ZFMISC-1K2 Z,Y :]"
    proof-
      have " for y be objectHIDDENM1 holds  for x be objectHIDDENM1 holds  not ([TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,X \\XBOOLE-0K4 Y :] &  not [TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,X :] \\XBOOLE-0K4 [:ZFMISC-1K2 Z,Y :]) &  not ([TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,X :] \\XBOOLE-0K4 [:ZFMISC-1K2 Z,Y :] &  not [TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,X \\XBOOLE-0K4 Y :])"
      proof(rule ballI,rule ballI)
        fix y assume [ty]: "y be objectHIDDENM1"
        fix x assume [ty]: "x be objectHIDDENM1"
        have A12: "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Z :] &  not [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Y,Z :] iff [TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,X :] &  not [TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,Y :]"
          using zfmisc_1_th_88 sorry
        have "[TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,X \\XBOOLE-0K4 Y :] iff [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X \\XBOOLE-0K4 Y,Z :]"
          using zfmisc_1_th_88 sorry
        thus " not ([TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,X \\XBOOLE-0K4 Y :] &  not [TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,X :] \\XBOOLE-0K4 [:ZFMISC-1K2 Z,Y :]) &  not ([TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,X :] \\XBOOLE-0K4 [:ZFMISC-1K2 Z,Y :] &  not [TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,X \\XBOOLE-0K4 Y :])"
          using A10 A12 xboole_0_def_5 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "[:ZFMISC-1K2 Z,X :] \\XBOOLE-0K4 [:ZFMISC-1K2 Z,Y :] c=TARSKIR1 [:ZFMISC-1K2 Z,X :]"
      using xboole_1_th_36 sorry
    thus "[:ZFMISC-1K2 Z,X \\XBOOLE-0K4 Y :] =XBOOLE-0R4 [:ZFMISC-1K2 Z,X :] \\XBOOLE-0K4 [:ZFMISC-1K2 Z,Y :]"
      using A11 zfmisc_1_lm_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_103:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds [:ZFMISC-1K2 X1,X2 :] \\XBOOLE-0K4 [:ZFMISC-1K2 Y1,Y2 :] =XBOOLE-0R4 [:ZFMISC-1K2 X1 \\XBOOLE-0K4 Y1,X2 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X1,X2 \\XBOOLE-0K4 Y2 :]"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds [:ZFMISC-1K2 X1,X2 :] \\XBOOLE-0K4 [:ZFMISC-1K2 Y1,Y2 :] =XBOOLE-0R4 [:ZFMISC-1K2 X1 \\XBOOLE-0K4 Y1,X2 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X1,X2 \\XBOOLE-0K4 Y2 :]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix Y2 assume [ty]: "Y2 be setHIDDENM2"
    have A1: "([:ZFMISC-1K2 Y1,X2 :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 X1,Y2 :]) =XBOOLE-0R4 [:ZFMISC-1K2 Y1 /\\XBOOLE-0K3 X1,X2 /\\XBOOLE-0K3 Y2 :]"
      using zfmisc_1_th_100 sorry
    have "Y1 /\\XBOOLE-0K3 X1 c=TARSKIR1 Y1 & X2 /\\XBOOLE-0K3 Y2 c=TARSKIR1 Y2"
      using xboole_1_th_17 sorry
    then have A2: "[:ZFMISC-1K2 Y1 /\\XBOOLE-0K3 X1,X2 /\\XBOOLE-0K3 Y2 :] c=TARSKIR1 [:ZFMISC-1K2 Y1,Y2 :]"
      using zfmisc_1_th_96 sorry
    have A3: "[:ZFMISC-1K2 X1 \\XBOOLE-0K4 Y1,X2 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X1,X2 \\XBOOLE-0K4 Y2 :] c=TARSKIR1 [:ZFMISC-1K2 X1,X2 :] \\XBOOLE-0K4 [:ZFMISC-1K2 Y1,Y2 :]"
    proof-
      have " for z be objectHIDDENM1 holds z inHIDDENR3 [:ZFMISC-1K2 X1 \\XBOOLE-0K4 Y1,X2 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X1,X2 \\XBOOLE-0K4 Y2 :] implies z inHIDDENR3 [:ZFMISC-1K2 X1,X2 :] \\XBOOLE-0K4 [:ZFMISC-1K2 Y1,Y2 :]"
      proof(rule ballI,rule impI)
        fix z assume [ty]: "z be objectHIDDENM1"
        have A4: "z inHIDDENR3 [:ZFMISC-1K2 X1 \\XBOOLE-0K4 Y1,X2 :] implies  not (z inHIDDENR3 [:ZFMISC-1K2 X1 \\XBOOLE-0K4 Y1,X2 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X1,X2 \\XBOOLE-0K4 Y2 :] &  not z inHIDDENR3 [:ZFMISC-1K2 X1,X2 :] \\XBOOLE-0K4 [:ZFMISC-1K2 Y1,Y2 :])"
        proof(rule impI)
          assume "z inHIDDENR3 [:ZFMISC-1K2 X1 \\XBOOLE-0K4 Y1,X2 :]"
          then obtain x y where
            [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
            A5: "x inHIDDENR3 X1 \\XBOOLE-0K4 Y1"and A6: "y inHIDDENR3 X2"and A7: "z =HIDDENR1 [TARSKIK4 x,y ]"
            using zfmisc_1_def_2 sorry
          have " not x inHIDDENR3 Y1"
            using A5 xboole_0_def_5 sorry
          then have A8: " not z inHIDDENR3 [:ZFMISC-1K2 Y1,Y2 :]"
            using A7 zfmisc_1_lm_16 sorry
          have "x inHIDDENR3 X1"
            using A5 xboole_0_def_5 sorry
          then have "z inHIDDENR3 [:ZFMISC-1K2 X1,X2 :]"
            using A6 A7 zfmisc_1_lm_16 sorry
          thus " not (z inHIDDENR3 [:ZFMISC-1K2 X1 \\XBOOLE-0K4 Y1,X2 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X1,X2 \\XBOOLE-0K4 Y2 :] &  not z inHIDDENR3 [:ZFMISC-1K2 X1,X2 :] \\XBOOLE-0K4 [:ZFMISC-1K2 Y1,Y2 :])"
            using A8 xboole_0_def_5 sorry
        qed
        have A9: "z inHIDDENR3 [:ZFMISC-1K2 X1,X2 \\XBOOLE-0K4 Y2 :] implies  not (z inHIDDENR3 [:ZFMISC-1K2 X1 \\XBOOLE-0K4 Y1,X2 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X1,X2 \\XBOOLE-0K4 Y2 :] &  not z inHIDDENR3 [:ZFMISC-1K2 X1,X2 :] \\XBOOLE-0K4 [:ZFMISC-1K2 Y1,Y2 :])"
        proof(rule impI)
          assume "z inHIDDENR3 [:ZFMISC-1K2 X1,X2 \\XBOOLE-0K4 Y2 :]"
          then obtain x y where
            [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
            A10: "x inHIDDENR3 X1"and A11: "y inHIDDENR3 X2 \\XBOOLE-0K4 Y2"and A12: "z =HIDDENR1 [TARSKIK4 x,y ]"
            using zfmisc_1_def_2 sorry
          have " not y inHIDDENR3 Y2"
            using A11 xboole_0_def_5 sorry
          then have A13: " not z inHIDDENR3 [:ZFMISC-1K2 Y1,Y2 :]"
            using A12 zfmisc_1_lm_16 sorry
          have "y inHIDDENR3 X2"
            using A11 xboole_0_def_5 sorry
          then have "z inHIDDENR3 [:ZFMISC-1K2 X1,X2 :]"
            using A10 A12 zfmisc_1_lm_16 sorry
          thus " not (z inHIDDENR3 [:ZFMISC-1K2 X1 \\XBOOLE-0K4 Y1,X2 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X1,X2 \\XBOOLE-0K4 Y2 :] &  not z inHIDDENR3 [:ZFMISC-1K2 X1,X2 :] \\XBOOLE-0K4 [:ZFMISC-1K2 Y1,Y2 :])"
            using A13 xboole_0_def_5 sorry
        qed
        assume "z inHIDDENR3 [:ZFMISC-1K2 X1 \\XBOOLE-0K4 Y1,X2 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X1,X2 \\XBOOLE-0K4 Y2 :]"
        thus "z inHIDDENR3 [:ZFMISC-1K2 X1,X2 :] \\XBOOLE-0K4 [:ZFMISC-1K2 Y1,Y2 :]"
          using A4 A9 xboole_0_def_3 sorry
      qed "sorry"
      thus "[:ZFMISC-1K2 X1 \\XBOOLE-0K4 Y1,X2 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X1,X2 \\XBOOLE-0K4 Y2 :] c=TARSKIR1 [:ZFMISC-1K2 X1,X2 :] \\XBOOLE-0K4 [:ZFMISC-1K2 Y1,Y2 :]"
        using tarski_def_3 sorry
    qed
    have "[:ZFMISC-1K2 X1 \\XBOOLE-0K4 Y1,X2 :] =XBOOLE-0R4 [:ZFMISC-1K2 X1,X2 :] \\XBOOLE-0K4 [:ZFMISC-1K2 Y1,X2 :] & [:ZFMISC-1K2 X1,X2 \\XBOOLE-0K4 Y2 :] =XBOOLE-0R4 [:ZFMISC-1K2 X1,X2 :] \\XBOOLE-0K4 [:ZFMISC-1K2 X1,Y2 :]"
      using zfmisc_1_th_102 sorry
    then have "[:ZFMISC-1K2 X1 \\XBOOLE-0K4 Y1,X2 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X1,X2 \\XBOOLE-0K4 Y2 :] =XBOOLE-0R4 [:ZFMISC-1K2 X1,X2 :] \\XBOOLE-0K4 [:ZFMISC-1K2 Y1 /\\XBOOLE-0K3 X1,X2 /\\XBOOLE-0K3 Y2 :]"
      using A1 xboole_1_th_54 sorry
    thus "[:ZFMISC-1K2 X1,X2 :] \\XBOOLE-0K4 [:ZFMISC-1K2 Y1,Y2 :] =XBOOLE-0R4 [:ZFMISC-1K2 X1 \\XBOOLE-0K4 Y1,X2 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X1,X2 \\XBOOLE-0K4 Y2 :]"
      using A3 A2 xboole_1_th_34 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_104:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds X1 missesXBOOLE-0R1 X2 or Y1 missesXBOOLE-0R1 Y2 implies [:ZFMISC-1K2 X1,Y1 :] missesXBOOLE-0R1 [:ZFMISC-1K2 X2,Y2 :]"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds X1 missesXBOOLE-0R1 X2 or Y1 missesXBOOLE-0R1 Y2 implies ( not [:ZFMISC-1K2 X1,Y1 :] missesXBOOLE-0R1 [:ZFMISC-1K2 X2,Y2 :] implies  False )"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix Y2 assume [ty]: "Y2 be setHIDDENM2"
    assume A1: "X1 missesXBOOLE-0R1 X2 or Y1 missesXBOOLE-0R1 Y2"
    assume " not [:ZFMISC-1K2 X1,Y1 :] missesXBOOLE-0R1 [:ZFMISC-1K2 X2,Y2 :]"
    then obtain z where
      [ty]:"z be objectHIDDENM1" and 
      A2: "z inHIDDENR3 ([:ZFMISC-1K2 X1,Y1 :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 X2,Y2 :])"
      using xboole_0_th_4 sorry
    have " ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st (z =HIDDENR1 [TARSKIK4 x,y ] & x inHIDDENR3 X1 /\\XBOOLE-0K3 X2) & y inHIDDENR3 Y1 /\\XBOOLE-0K3 Y2"
      using A2 zfmisc_1_th_85 sorry
    thus " False "
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_105:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  for Y be setHIDDENM2 holds [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 z},Y :] iff x =HIDDENR1 z & y inHIDDENR3 Y"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  for Y be setHIDDENM2 holds ([TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 z},Y :] implies x =HIDDENR1 z & y inHIDDENR3 Y) &  not ((x =HIDDENR1 z & y inHIDDENR3 Y) &  not [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 z},Y :])"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix z assume [ty]: "z be objectHIDDENM1"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have A1: "x inHIDDENR3 {TARSKIK1 z} iff x =HIDDENR1 z"
      using tarski_def_1 sorry
    thus "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 z},Y :] implies x =HIDDENR1 z & y inHIDDENR3 Y"
      using zfmisc_1_lm_16 sorry
    show " not ((x =HIDDENR1 z & y inHIDDENR3 Y) &  not [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 z},Y :])"
      using A1 zfmisc_1_lm_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_106:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  for X be setHIDDENM2 holds [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,{TARSKIK1 z} :] iff x inHIDDENR3 X & y =HIDDENR1 z"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  for X be setHIDDENM2 holds ([TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,{TARSKIK1 z} :] implies x inHIDDENR3 X & y =HIDDENR1 z) &  not ((x inHIDDENR3 X & y =HIDDENR1 z) &  not [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,{TARSKIK1 z} :])"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix z assume [ty]: "z be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    have A1: "y inHIDDENR3 {TARSKIK1 z} iff y =HIDDENR1 z"
      using tarski_def_1 sorry
    thus "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,{TARSKIK1 z} :] implies x inHIDDENR3 X & y =HIDDENR1 z"
      using zfmisc_1_lm_16 sorry
    show " not ((x inHIDDENR3 X & y =HIDDENR1 z) &  not [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,{TARSKIK1 z} :])"
      using A1 zfmisc_1_lm_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_107:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds X <>HIDDENR2 {}XBOOLE-0K1 implies [:ZFMISC-1K2 {TARSKIK1 x},X :] <>HIDDENR2 {}XBOOLE-0K1 & [:ZFMISC-1K2 X,{TARSKIK1 x} :] <>HIDDENR2 {}XBOOLE-0K1"
  using zfmisc_1_th_90 sorry

mtheorem zfmisc_1_th_108:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds x <>HIDDENR2 y implies [:ZFMISC-1K2 {TARSKIK1 x},X :] missesXBOOLE-0R1 [:ZFMISC-1K2 {TARSKIK1 y},Y :] & [:ZFMISC-1K2 X,{TARSKIK1 x} :] missesXBOOLE-0R1 [:ZFMISC-1K2 Y,{TARSKIK1 y} :]"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds x <>HIDDENR2 y implies [:ZFMISC-1K2 {TARSKIK1 x},X :] missesXBOOLE-0R1 [:ZFMISC-1K2 {TARSKIK1 y},Y :] & [:ZFMISC-1K2 X,{TARSKIK1 x} :] missesXBOOLE-0R1 [:ZFMISC-1K2 Y,{TARSKIK1 y} :]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume "x <>HIDDENR2 y"
    then have "{TARSKIK1 x} missesXBOOLE-0R1 {TARSKIK1 y}"
      using zfmisc_1_th_11 sorry
    thus "[:ZFMISC-1K2 {TARSKIK1 x},X :] missesXBOOLE-0R1 [:ZFMISC-1K2 {TARSKIK1 y},Y :] & [:ZFMISC-1K2 X,{TARSKIK1 x} :] missesXBOOLE-0R1 [:ZFMISC-1K2 Y,{TARSKIK1 y} :]"
      using zfmisc_1_th_104 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_109:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds [:ZFMISC-1K2 {TARSKIK2 x,y },X :] =XBOOLE-0R4 [:ZFMISC-1K2 {TARSKIK1 x},X :] \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 y},X :] & [:ZFMISC-1K2 X,{TARSKIK2 x,y } :] =XBOOLE-0R4 [:ZFMISC-1K2 X,{TARSKIK1 x} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X,{TARSKIK1 y} :]"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds [:ZFMISC-1K2 {TARSKIK2 x,y },X :] =XBOOLE-0R4 [:ZFMISC-1K2 {TARSKIK1 x},X :] \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 y},X :] & [:ZFMISC-1K2 X,{TARSKIK2 x,y } :] =XBOOLE-0R4 [:ZFMISC-1K2 X,{TARSKIK1 x} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X,{TARSKIK1 y} :]"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    have "{TARSKIK2 x,y } =XBOOLE-0R4 {TARSKIK1 x} \\/XBOOLE-0K2 {TARSKIK1 y}"
      using enumset1_th_1 sorry
    thus "[:ZFMISC-1K2 {TARSKIK2 x,y },X :] =XBOOLE-0R4 [:ZFMISC-1K2 {TARSKIK1 x},X :] \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 y},X :] & [:ZFMISC-1K2 X,{TARSKIK2 x,y } :] =XBOOLE-0R4 [:ZFMISC-1K2 X,{TARSKIK1 x} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X,{TARSKIK1 y} :]"
      using zfmisc_1_th_97 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_110:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds (X1 <>HIDDENR2 {}XBOOLE-0K1 & Y1 <>HIDDENR2 {}XBOOLE-0K1) & [:ZFMISC-1K2 X1,Y1 :] =XBOOLE-0R4 [:ZFMISC-1K2 X2,Y2 :] implies X1 =XBOOLE-0R4 X2 & Y1 =XBOOLE-0R4 Y2"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds X1 <>HIDDENR2 {}XBOOLE-0K1 implies (Y1 <>HIDDENR2 {}XBOOLE-0K1 implies ([:ZFMISC-1K2 X1,Y1 :] =XBOOLE-0R4 [:ZFMISC-1K2 X2,Y2 :] implies X1 =XBOOLE-0R4 X2 & Y1 =XBOOLE-0R4 Y2))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI,rule impI,rule conjMI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix Y2 assume [ty]: "Y2 be setHIDDENM2"
    assume A1: "X1 <>HIDDENR2 {}XBOOLE-0K1"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A2: "x inHIDDENR3 X1"
      using xboole_0_th_7 sorry
    assume A3: "Y1 <>HIDDENR2 {}XBOOLE-0K1"
    then obtain y where
      [ty]:"y be objectHIDDENM1" and 
      A4: "y inHIDDENR3 Y1"
      using xboole_0_th_7 sorry
    assume A5: "[:ZFMISC-1K2 X1,Y1 :] =XBOOLE-0R4 [:ZFMISC-1K2 X2,Y2 :]"
    then have A6: "[:ZFMISC-1K2 X2,Y2 :] <>HIDDENR2 {}XBOOLE-0K1"
      using A1 A3 zfmisc_1_th_90 sorry
    then have A7: "Y2 <>HIDDENR2 {}XBOOLE-0K1"
      using zfmisc_1_th_90 sorry
    have " for z be objectHIDDENM1 holds z inHIDDENR3 X1 iff z inHIDDENR3 X2"
    proof-
      have " for z be objectHIDDENM1 holds (z inHIDDENR3 X1 implies z inHIDDENR3 X2) & (z inHIDDENR3 X2 implies z inHIDDENR3 X1)"
      proof(rule ballI,rule conjMI,rule impI)
        fix z assume [ty]: "z be objectHIDDENM1"
        obtain y2 where
          [ty]:"y2 be objectHIDDENM1" and 
          A8: "y2 inHIDDENR3 Y2"
          using A7 xboole_0_th_7 sorry
        show "z inHIDDENR3 X1 implies z inHIDDENR3 X2"
        proof(rule impI)
          assume "z inHIDDENR3 X1"
          then have "[TARSKIK4 z,y ] inHIDDENR3 [:ZFMISC-1K2 X2,Y2 :]"
            using A4 A5 zfmisc_1_lm_16 sorry
          thus "z inHIDDENR3 X2"
            using zfmisc_1_lm_16 sorry
        qed
        assume "z inHIDDENR3 X2"
        then have "[TARSKIK4 z,y2 ] inHIDDENR3 [:ZFMISC-1K2 X2,Y2 :]"
          using A8 zfmisc_1_lm_16 sorry
        thus "z inHIDDENR3 X1"
          using A5 zfmisc_1_lm_16 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "X1 =XBOOLE-0R4 X2"
      using tarski_th_2 sorry
    have A9: "X2 <>HIDDENR2 {}XBOOLE-0K1"
      using A6 zfmisc_1_th_90 sorry
    have " for z be objectHIDDENM1 holds z inHIDDENR3 Y1 iff z inHIDDENR3 Y2"
    proof-
      have " for z be objectHIDDENM1 holds (z inHIDDENR3 Y1 implies z inHIDDENR3 Y2) & (z inHIDDENR3 Y2 implies z inHIDDENR3 Y1)"
      proof(rule ballI,rule conjMI,rule impI)
        fix z assume [ty]: "z be objectHIDDENM1"
        obtain x2 where
          [ty]:"x2 be objectHIDDENM1" and 
          A10: "x2 inHIDDENR3 X2"
          using A9 xboole_0_th_7 sorry
        show "z inHIDDENR3 Y1 implies z inHIDDENR3 Y2"
        proof(rule impI)
          assume "z inHIDDENR3 Y1"
          then have "[TARSKIK4 x,z ] inHIDDENR3 [:ZFMISC-1K2 X2,Y2 :]"
            using A2 A5 zfmisc_1_lm_16 sorry
          thus "z inHIDDENR3 Y2"
            using zfmisc_1_lm_16 sorry
        qed
        assume "z inHIDDENR3 Y2"
        then have "[TARSKIK4 x2,z ] inHIDDENR3 [:ZFMISC-1K2 X2,Y2 :]"
          using A10 zfmisc_1_lm_16 sorry
        thus "z inHIDDENR3 Y1"
          using A5 zfmisc_1_lm_16 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "Y1 =XBOOLE-0R4 Y2"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_111:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 [:ZFMISC-1K2 X,Y :] or X c=TARSKIR1 [:ZFMISC-1K2 Y,X :] implies X =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 [:ZFMISC-1K2 X,Y :] or X c=TARSKIR1 [:ZFMISC-1K2 Y,X :] implies (X <>HIDDENR2 {}XBOOLE-0K1 implies  not  True )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "X c=TARSKIR1 [:ZFMISC-1K2 X,Y :] or X c=TARSKIR1 [:ZFMISC-1K2 Y,X :]"
    assume A2: "X <>HIDDENR2 {}XBOOLE-0K1"
    have A3: "X c=TARSKIR1 [:ZFMISC-1K2 Y,X :] implies  False "
    proof(rule impI)
      let ?P = "\<lambda>Lamb1.  ex Y be setHIDDENM2 st Lamb1 =HIDDENR1 Y & ( ex z be objectHIDDENM1 st z inHIDDENR3 Y & z inHIDDENR3 X)"
      obtain Z where
        [ty]:"Z be setHIDDENM2" and 
        A4: " for y be objectHIDDENM1 holds y inHIDDENR3 Z iff y inHIDDENR3 unionTARSKIK3 X & ?P(y)"
        using xboole_0_sch_1 sorry
      obtain Y2 where
        [ty]:"Y2 be setHIDDENM2" and 
        A5: "Y2 inTARSKIR2 X \\/XBOOLE-0K2 Z"and A6: "X \\/XBOOLE-0K2 Z missesXBOOLE-0R1 Y2"
        using A2 xregular_th_1 sorry
      have " not ( ex Y2 be setHIDDENM2 st Y2 inTARSKIR2 X & ( for Y1 be setHIDDENM2 holds Y1 inTARSKIR2 Y2 implies ( for z be objectHIDDENM1 holds  not z inHIDDENR3 Y1 or  not z inHIDDENR3 X))) implies  False "
      proof(rule impI)
        assume A7: " not ( ex Y2 be setHIDDENM2 st Y2 inTARSKIR2 X & ( for Y1 be setHIDDENM2 holds Y1 inTARSKIR2 Y2 implies ( for z be objectHIDDENM1 holds  not z inHIDDENR3 Y1 or  not z inHIDDENR3 X)))"
        have "Y2 inTARSKIR2 X implies  False "
        proof(rule impI)
          assume A8: "Y2 inTARSKIR2 X"
          then obtain Y1 where
            [ty]:"Y1 be setHIDDENM2" and 
            A9: "Y1 inTARSKIR2 Y2"and A10: " ex z be objectHIDDENM1 st z inHIDDENR3 Y1 & z inHIDDENR3 X"
            using A7 sorry
          have "Y1 inTARSKIR2 unionTARSKIK3 X"
            using A8 A9 tarski_def_4 sorry
          then have "Y1 inTARSKIR2 Z"
            using A4 A10 sorry
          then have "Y1 inTARSKIR2 X \\/XBOOLE-0K2 Z"
            using xboole_0_def_3 sorry
          thus " False "
            using A6 A9 xboole_0_th_3 sorry
        qed
        then have "Y2 inTARSKIR2 Z"
          using A5 xboole_0_def_3 sorry
        then have " ex X2 be setHIDDENM2 st Y2 =XBOOLE-0R4 X2 & ( ex z be objectHIDDENM1 st z inHIDDENR3 X2 & z inHIDDENR3 X)"
          using A4 sorry
        then obtain z where
          [ty]:"z be objectHIDDENM1" and 
          A11: "z inHIDDENR3 Y2"and A12: "z inHIDDENR3 X"
           sorry
        have "z inHIDDENR3 X \\/XBOOLE-0K2 Z"
          using A12 xboole_0_def_3 sorry
        thus " False "
          using A6 A11 xboole_0_th_3 sorry
      qed
      then obtain Y1 where
        [ty]:"Y1 be setHIDDENM2" and 
        A13: "Y1 inTARSKIR2 X"and A14: " not ( ex Y2 be setHIDDENM2 st Y2 inTARSKIR2 Y1 & ( ex z be objectHIDDENM1 st z inHIDDENR3 Y2 & z inHIDDENR3 X))"
         sorry
      have A15: "( ex y be objectHIDDENM1 st  ex x be objectHIDDENM1 st x inHIDDENR3 X & Y1 =HIDDENR1 [TARSKIK4 y,x ]) implies  False "
      proof(rule impI)
        assume Given: " ex y be objectHIDDENM1 st  ex x be objectHIDDENM1 st x inHIDDENR3 X & Y1 =HIDDENR1 [TARSKIK4 y,x ]"
        then obtain y x where
          [ty]:"y be objectHIDDENM1" "x be objectHIDDENM1" and 
          A16: "x inHIDDENR3 X"and A17: "Y1 =HIDDENR1 [TARSKIK4 y,x ]"
           sorry
        have A18: "x inHIDDENR3 {TARSKIK2 y,x }"
          using tarski_def_2 sorry
        have "{TARSKIK2 y,x } inTARSKIR2 Y1"
          using A17 tarski_def_2 sorry
        thus " False "
          using A14 A16 A18 sorry
      qed
      assume "X c=TARSKIR1 [:ZFMISC-1K2 Y,X :]"
      then have "Y1 inTARSKIR2 [:ZFMISC-1K2 Y,X :]"
        using A13 sorry
      then have " ex y be objectHIDDENM1 st  ex x be objectHIDDENM1 st (y inHIDDENR3 Y & x inHIDDENR3 X) & Y1 =HIDDENR1 [TARSKIK4 y,x ]"
        using zfmisc_1_def_2 sorry
      thus " False "
        using A15 sorry
    qed
    have "X c=TARSKIR1 [:ZFMISC-1K2 X,Y :] implies  False "
    proof(rule impI)
      obtain z where
        [ty]:"z be objectHIDDENM1" and 
        A19: "z inHIDDENR3 X"
        using A2 xboole_0_th_7 sorry
      obtain Y1 where
        [ty]:"Y1 be setHIDDENM2" and 
        A20: "Y1 inTARSKIR2 X \\/XBOOLE-0K2 unionTARSKIK3 X"and A21: "X \\/XBOOLE-0K2 unionTARSKIK3 X missesXBOOLE-0R1 Y1"
        using A19 xregular_th_1 sorry
      assume A22: "X c=TARSKIR1 [:ZFMISC-1K2 X,Y :]"
      have "Y1 inTARSKIR2 X implies  False "
      proof(rule impI)
        assume A23: "Y1 inTARSKIR2 X"
        then obtain x y where
          [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
          A24: "Y1 =HIDDENR1 [TARSKIK4 x,y ]"
          using zfmisc_1_lm_19 A22 sorry
        have A25: "{TARSKIK1 x} inTARSKIR2 Y1"
          using A24 tarski_def_2 sorry
        have "Y1 c=TARSKIR1 unionTARSKIK3 X"
          using A23 zfmisc_1_lm_14 sorry
        then have "{TARSKIK1 x} inTARSKIR2 unionTARSKIK3 X"
          using A25 sorry
        then have "{TARSKIK1 x} inTARSKIR2 X \\/XBOOLE-0K2 unionTARSKIK3 X"
          using xboole_0_def_3 sorry
        thus " False "
          using A21 A25 xboole_0_th_3 sorry
      qed
      then have "Y1 inTARSKIR2 unionTARSKIK3 X"
        using A20 xboole_0_def_3 sorry
      then obtain Y2 where
        [ty]:"Y2 be setHIDDENM2" and 
        A26: "Y1 inTARSKIR2 Y2"and A27: "Y2 inTARSKIR2 X"
        using tarski_def_4 sorry
      have "Y2 inTARSKIR2 [:ZFMISC-1K2 X,Y :]"
        using A22 A27 sorry
      then obtain x y where
        [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
        A28: "x inHIDDENR3 X"and "y inHIDDENR3 Y"and A29: "Y2 =HIDDENR1 [TARSKIK4 x,y ]"
        using zfmisc_1_def_2 sorry
      have "Y1 =XBOOLE-0R4 {TARSKIK1 x} or Y1 =XBOOLE-0R4 {TARSKIK2 x,y }"
        using A26 A29 tarski_def_2 sorry
      then have A30: "x inHIDDENR3 Y1"
        using tarski_def_1 tarski_def_2 sorry
      have "x inHIDDENR3 X \\/XBOOLE-0K2 unionTARSKIK3 X"
        using A28 xboole_0_def_3 sorry
      thus " False "
        using A21 A30 xboole_0_th_3 sorry
    qed
    thus " not  True "
      using A1 A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_112:
" for N be setHIDDENM2 holds  ex M be setHIDDENM2 st ((N inTARSKIR2 M & ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 M & Y c=TARSKIR1 X implies Y inTARSKIR2 M)) & ( for X be setHIDDENM2 holds X inTARSKIR2 M implies boolZFMISC-1K1 X inTARSKIR2 M)) & ( for X be setHIDDENM2 holds X c=TARSKIR1 M implies (X,M)are-equipotentTARSKIR3 or X inTARSKIR2 M)"
proof-
  have " for N be setHIDDENM2 holds  ex tVar5 be setHIDDENM2 st N inTARSKIR2 tVar5 & (( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 tVar5 & Y c=TARSKIR1 X implies Y inTARSKIR2 tVar5) & (( for X be setHIDDENM2 holds X inTARSKIR2 tVar5 implies boolZFMISC-1K1 X inTARSKIR2 tVar5) & ( for X be setHIDDENM2 holds  not ((X c=TARSKIR1 tVar5 &  not (X,tVar5)are-equipotentTARSKIR3) &  not X inTARSKIR2 tVar5))))"
  proof(rule ballI)
    fix N assume [ty]: "N be setHIDDENM2"
    obtain M where
      [ty]:"M be setHIDDENM2" and 
      A1: "N inTARSKIR2 M"and A2: " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 M & Y c=TARSKIR1 X implies Y inTARSKIR2 M"and A3: " for X be setHIDDENM2 holds X inTARSKIR2 M implies ( ex Z be setHIDDENM2 st Z inTARSKIR2 M & ( for Y be setHIDDENM2 holds Y c=TARSKIR1 X implies Y inTARSKIR2 Z))"and A4: " for X be setHIDDENM2 holds X c=TARSKIR1 M implies (X,M)are-equipotentTARSKIR3 or X inTARSKIR2 M"
      using tarski_a_th_1 sorry
    show " ex tVar5 be setHIDDENM2 st N inTARSKIR2 tVar5 & (( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 tVar5 & Y c=TARSKIR1 X implies Y inTARSKIR2 tVar5) & (( for X be setHIDDENM2 holds X inTARSKIR2 tVar5 implies boolZFMISC-1K1 X inTARSKIR2 tVar5) & ( for X be setHIDDENM2 holds  not ((X c=TARSKIR1 tVar5 &  not (X,tVar5)are-equipotentTARSKIR3) &  not X inTARSKIR2 tVar5))))"
    proof(rule bexI[of _ "M"],rule conjMI,rule conjMI,rule conjMI)
      show "N inTARSKIR2 M"
        using A1 sorry
      show " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 M & Y c=TARSKIR1 X implies Y inTARSKIR2 M"
        using A2 sorry
      show " for X be setHIDDENM2 holds X inTARSKIR2 M implies boolZFMISC-1K1 X inTARSKIR2 M"
      proof(rule ballI,rule impI)
        fix X assume [ty]: "X be setHIDDENM2"
        assume "X inTARSKIR2 M"
        then obtain Z where
          [ty]:"Z be setHIDDENM2" and 
          A5: "Z inTARSKIR2 M"and A6: " for Y be setHIDDENM2 holds Y c=TARSKIR1 X implies Y inTARSKIR2 Z"
          using A3 sorry
        have " for Y be objectHIDDENM1 holds Y inHIDDENR3 boolZFMISC-1K1 X implies Y inHIDDENR3 Z"
        proof(rule ballI,rule impI)
          fix Y assume [ty]: "Y be objectHIDDENM1"
          obtain YY where 
            [ty]:"YY be setHIDDENM2" and YYDef:"YY = Y"
            using tarski_th_1 sorry
          assume "Y inHIDDENR3 boolZFMISC-1K1 X"
          then have "YY c=TARSKIR1 X"
            using zfmisc_1_def_1 sorry
          thus "Y inHIDDENR3 Z"
            using A6 sorry
        qed "sorry"
        thus "boolZFMISC-1K1 X inTARSKIR2 M"
          using A2 A5 tarski_def_3 sorry
      qed "sorry"
      show " for X be setHIDDENM2 holds  not ((X c=TARSKIR1 M &  not (X,M)are-equipotentTARSKIR3) &  not X inTARSKIR2 M)"
        using A4 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve e for "objectHIDDENM1"
reserve X, X1, X2, Y1, Y2 for "setHIDDENM2"
mtheorem zfmisc_1_th_113:
" for e be objectHIDDENM1 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds e inHIDDENR3 [:ZFMISC-1K2 X1,Y1 :] & e inHIDDENR3 [:ZFMISC-1K2 X2,Y2 :] implies e inHIDDENR3 [:ZFMISC-1K2 X1 /\\XBOOLE-0K3 X2,Y1 /\\XBOOLE-0K3 Y2 :]"
proof-
  have " for e be objectHIDDENM1 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds e inHIDDENR3 [:ZFMISC-1K2 X1,Y1 :] & e inHIDDENR3 [:ZFMISC-1K2 X2,Y2 :] implies e inHIDDENR3 [:ZFMISC-1K2 X1 /\\XBOOLE-0K3 X2,Y1 /\\XBOOLE-0K3 Y2 :]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix e assume [ty]: "e be objectHIDDENM1"
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix Y2 assume [ty]: "Y2 be setHIDDENM2"
    assume "e inHIDDENR3 [:ZFMISC-1K2 X1,Y1 :] & e inHIDDENR3 [:ZFMISC-1K2 X2,Y2 :]"
    then have "e inHIDDENR3 ([:ZFMISC-1K2 X1,Y1 :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 X2,Y2 :])"
      using xboole_0_def_4 sorry
    thus "e inHIDDENR3 [:ZFMISC-1K2 X1 /\\XBOOLE-0K3 X2,Y1 /\\XBOOLE-0K3 Y2 :]"
      using zfmisc_1_th_100 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem zfmisc_1_th_114:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds [:ZFMISC-1K2 X1,X2 :] c=TARSKIR1 [:ZFMISC-1K2 Y1,Y2 :] & [:ZFMISC-1K2 X1,X2 :] <>HIDDENR2 {}XBOOLE-0K1 implies X1 c=TARSKIR1 Y1 & X2 c=TARSKIR1 Y2"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds [:ZFMISC-1K2 X1,X2 :] c=TARSKIR1 [:ZFMISC-1K2 Y1,Y2 :] & [:ZFMISC-1K2 X1,X2 :] <>HIDDENR2 {}XBOOLE-0K1 implies X1 c=TARSKIR1 Y1 & X2 c=TARSKIR1 Y2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix Y2 assume [ty]: "Y2 be setHIDDENM2"
    assume A1: "[:ZFMISC-1K2 X1,X2 :] c=TARSKIR1 [:ZFMISC-1K2 Y1,Y2 :]"
      and A2: "[:ZFMISC-1K2 X1,X2 :] <>HIDDENR2 {}XBOOLE-0K1"
    have A3: "[:ZFMISC-1K2 X1,X2 :] =HIDDENR1 ([:ZFMISC-1K2 X1,X2 :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 Y1,Y2 :])"
      using A1 xboole_1_th_28 sorry
    also have "... = [:ZFMISC-1K2 X1 /\\XBOOLE-0K3 Y1,X2 /\\XBOOLE-0K3 Y2 :]"
      using zfmisc_1_th_100 sorry
    finally have "[:ZFMISC-1K2 X1,X2 :] =HIDDENR1 [:ZFMISC-1K2 X1 /\\XBOOLE-0K3 Y1,X2 /\\XBOOLE-0K3 Y2 :]"
       sorry
    have "X1 <>HIDDENR2 {}XBOOLE-0K1 & X2 <>HIDDENR2 {}XBOOLE-0K1"
      using A2 zfmisc_1_th_90 sorry
    then have "X1 =XBOOLE-0R4 X1 /\\XBOOLE-0K3 Y1 & X2 =XBOOLE-0R4 X2 /\\XBOOLE-0K3 Y2"
      using A3 zfmisc_1_th_110 sorry
    thus "X1 c=TARSKIR1 Y1 & X2 c=TARSKIR1 Y2"
      using xboole_1_th_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_115:
" for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be setHIDDENM2 holds  for C be setHIDDENM2 holds  for D be setHIDDENM2 holds [:ZFMISC-1K2 A,B :] c=TARSKIR1 [:ZFMISC-1K2 C,D :] or [:ZFMISC-1K2 B,A :] c=TARSKIR1 [:ZFMISC-1K2 D,C :] implies B c=TARSKIR1 D"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix B assume [ty]: "B be setHIDDENM2"
  fix C assume [ty]: "C be setHIDDENM2"
  fix D assume [ty]: "D be setHIDDENM2"
  assume A1: "[:ZFMISC-1K2 A,B :] c=TARSKIR1 [:ZFMISC-1K2 C,D :] or [:ZFMISC-1K2 B,A :] c=TARSKIR1 [:ZFMISC-1K2 D,C :]"
  show "B c=TARSKIR1 D"
  proof-
    have cases: "B =XBOOLE-0R4 {}XBOOLE-0K1 or B <>HIDDENR2 {}XBOOLE-0K1"
       sorry
    have case1: "B =XBOOLE-0R4 {}XBOOLE-0K1 implies B c=TARSKIR1 D"
    proof(rule impI)
      assume "B =XBOOLE-0R4 {}XBOOLE-0K1"
      thus "B c=TARSKIR1 D"
         sorry
    qed
    have case2: "B <>HIDDENR2 {}XBOOLE-0K1 implies B c=TARSKIR1 D"
    proof(rule impI)
      assume "B <>HIDDENR2 {}XBOOLE-0K1"
      then have "[:ZFMISC-1K2 A,B :] <>HIDDENR2 {}XBOOLE-0K1 & [:ZFMISC-1K2 B,A :] <>HIDDENR2 {}XBOOLE-0K1"
        using zfmisc_1_th_90 sorry
      thus "B c=TARSKIR1 D"
        using A1 zfmisc_1_th_114 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem zfmisc_1_th_116:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds x inHIDDENR3 X implies (X \\XBOOLE-0K4 {TARSKIK1 x})\\/XBOOLE-0K2 {TARSKIK1 x} =XBOOLE-0R4 X"
proof-
  have " for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds x inHIDDENR3 X implies (X \\XBOOLE-0K4 {TARSKIK1 x})\\/XBOOLE-0K2 {TARSKIK1 x} =XBOOLE-0R4 X"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "x inHIDDENR3 X"
    have "(X \\XBOOLE-0K4 {TARSKIK1 x})\\/XBOOLE-0K2 {TARSKIK1 x} c=TARSKIR1 X & X c=TARSKIR1 (X \\XBOOLE-0K4 {TARSKIK1 x})\\/XBOOLE-0K2 {TARSKIK1 x}"
    proof(rule conjMI)
      show "(X \\XBOOLE-0K4 {TARSKIK1 x})\\/XBOOLE-0K2 {TARSKIK1 x} c=TARSKIR1 X"
      proof-
        have " for y be objectHIDDENM1 holds y inHIDDENR3 (X \\XBOOLE-0K4 {TARSKIK1 x})\\/XBOOLE-0K2 {TARSKIK1 x} implies y inHIDDENR3 X"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "y inHIDDENR3 (X \\XBOOLE-0K4 {TARSKIK1 x})\\/XBOOLE-0K2 {TARSKIK1 x}"
          then have "y inHIDDENR3 X \\XBOOLE-0K4 {TARSKIK1 x} or y inHIDDENR3 {TARSKIK1 x}"
            using xboole_0_def_3 sorry
          thus "y inHIDDENR3 X"
            using A1 zfmisc_1_th_56 tarski_def_1 sorry
        qed "sorry"
        thus "(X \\XBOOLE-0K4 {TARSKIK1 x})\\/XBOOLE-0K2 {TARSKIK1 x} c=TARSKIR1 X"
          using tarski_def_3 sorry
      qed
      show "X c=TARSKIR1 (X \\XBOOLE-0K4 {TARSKIK1 x})\\/XBOOLE-0K2 {TARSKIK1 x}"
      proof-
        have " for y be objectHIDDENM1 holds y inHIDDENR3 X implies y inHIDDENR3 (X \\XBOOLE-0K4 {TARSKIK1 x})\\/XBOOLE-0K2 {TARSKIK1 x}"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "y inHIDDENR3 X"
          then have "y inHIDDENR3 {TARSKIK1 x} or y inHIDDENR3 X \\XBOOLE-0K4 {TARSKIK1 x}"
            using xboole_0_def_5 sorry
          thus "y inHIDDENR3 (X \\XBOOLE-0K4 {TARSKIK1 x})\\/XBOOLE-0K2 {TARSKIK1 x}"
            using xboole_0_def_3 sorry
        qed "sorry"
        thus "X c=TARSKIR1 (X \\XBOOLE-0K4 {TARSKIK1 x})\\/XBOOLE-0K2 {TARSKIK1 x}"
          using tarski_def_3 sorry
      qed
    qed
    thus "(X \\XBOOLE-0K4 {TARSKIK1 x})\\/XBOOLE-0K2 {TARSKIK1 x} =XBOOLE-0R4 X"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_117:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  not x inHIDDENR3 X implies (X \\/XBOOLE-0K2 {TARSKIK1 x})\\XBOOLE-0K4 {TARSKIK1 x} =XBOOLE-0R4 X"
proof-
  have " for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  not x inHIDDENR3 X implies (X \\/XBOOLE-0K2 {TARSKIK1 x})\\XBOOLE-0K4 {TARSKIK1 x} =XBOOLE-0R4 X"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    have A1: "(X \\/XBOOLE-0K2 {TARSKIK1 x})\\XBOOLE-0K4 {TARSKIK1 x} =XBOOLE-0R4 X \\XBOOLE-0K4 {TARSKIK1 x}"
      using xboole_1_th_40 sorry
    assume " not x inHIDDENR3 X"
    thus "(X \\/XBOOLE-0K2 {TARSKIK1 x})\\XBOOLE-0K4 {TARSKIK1 x} =XBOOLE-0R4 X"
      using A1 zfmisc_1_th_57 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_118:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds  for Z be setHIDDENM2 holds Z c=TARSKIR1 {ENUMSET1K1 x,y,z } iff ((((((Z =XBOOLE-0R4 {}XBOOLE-0K1 or Z =XBOOLE-0R4 {TARSKIK1 x}) or Z =XBOOLE-0R4 {TARSKIK1 y}) or Z =XBOOLE-0R4 {TARSKIK1 z}) or Z =XBOOLE-0R4 {TARSKIK2 x,y }) or Z =XBOOLE-0R4 {TARSKIK2 y,z }) or Z =XBOOLE-0R4 {TARSKIK2 x,z }) or Z =XBOOLE-0R4 {ENUMSET1K1 x,y,z }"
proof-
  have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds  for Z be setHIDDENM2 holds (Z c=TARSKIR1 {ENUMSET1K1 x,y,z } & (Z <>HIDDENR2 {}XBOOLE-0K1 & (Z <>HIDDENR2 {TARSKIK1 x} & (Z <>HIDDENR2 {TARSKIK1 y} & (Z <>HIDDENR2 {TARSKIK1 z} & (Z <>HIDDENR2 {TARSKIK2 x,y } & (Z <>HIDDENR2 {TARSKIK2 y,z } & Z <>HIDDENR2 {TARSKIK2 x,z })))))) implies Z =XBOOLE-0R4 {ENUMSET1K1 x,y,z }) & (((((((Z =XBOOLE-0R4 {}XBOOLE-0K1 or Z =XBOOLE-0R4 {TARSKIK1 x}) or Z =XBOOLE-0R4 {TARSKIK1 y}) or Z =XBOOLE-0R4 {TARSKIK1 z}) or Z =XBOOLE-0R4 {TARSKIK2 x,y }) or Z =XBOOLE-0R4 {TARSKIK2 y,z }) or Z =XBOOLE-0R4 {TARSKIK2 x,z }) or Z =XBOOLE-0R4 {ENUMSET1K1 x,y,z } implies Z c=TARSKIR1 {ENUMSET1K1 x,y,z })"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    fix z assume [ty]: "z be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    show "Z c=TARSKIR1 {ENUMSET1K1 x,y,z } & (Z <>HIDDENR2 {}XBOOLE-0K1 & (Z <>HIDDENR2 {TARSKIK1 x} & (Z <>HIDDENR2 {TARSKIK1 y} & (Z <>HIDDENR2 {TARSKIK1 z} & (Z <>HIDDENR2 {TARSKIK2 x,y } & (Z <>HIDDENR2 {TARSKIK2 y,z } & Z <>HIDDENR2 {TARSKIK2 x,z })))))) implies Z =XBOOLE-0R4 {ENUMSET1K1 x,y,z }"
    proof(rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
      assume A1: "Z c=TARSKIR1 {ENUMSET1K1 x,y,z }"
        and A2: "Z <>HIDDENR2 {}XBOOLE-0K1"
        and A3: "Z <>HIDDENR2 {TARSKIK1 x}"
        and A4: "Z <>HIDDENR2 {TARSKIK1 y}"
        and A5: "Z <>HIDDENR2 {TARSKIK1 z}"
        and A6: "Z <>HIDDENR2 {TARSKIK2 x,y }"
        and A7: "Z <>HIDDENR2 {TARSKIK2 y,z }"
        and A8: "Z <>HIDDENR2 {TARSKIK2 x,z }"
      have "{ENUMSET1K1 x,y,z } c=TARSKIR1 Z"
      proof-
        have " for a be objectHIDDENM1 holds a inHIDDENR3 {ENUMSET1K1 x,y,z } implies a inHIDDENR3 Z"
        proof(rule ballI,rule impI)
          fix a assume [ty]: "a be objectHIDDENM1"
          have A9: " not x inTARSKIR2 Z implies  False "
          proof(rule impI)
            have "{ENUMSET1K1 x,y,z } \\XBOOLE-0K4 {TARSKIK1 x} =HIDDENR1 ({TARSKIK1 x} \\/XBOOLE-0K2 {TARSKIK2 y,z })\\XBOOLE-0K4 {TARSKIK1 x}"
              using enumset1_th_2 sorry
            also have "... = {TARSKIK2 y,z } \\XBOOLE-0K4 {TARSKIK1 x}"
              using xboole_1_th_40 sorry
            finally have "{ENUMSET1K1 x,y,z } \\XBOOLE-0K4 {TARSKIK1 x} =HIDDENR1 {TARSKIK2 y,z } \\XBOOLE-0K4 {TARSKIK1 x}"
               sorry
            then have A10: "{ENUMSET1K1 x,y,z } \\XBOOLE-0K4 {TARSKIK1 x} c=TARSKIR1 {TARSKIK2 y,z }"
              using xboole_1_th_36 sorry
            assume " not x inTARSKIR2 Z"
            then have "Z c=TARSKIR1 {ENUMSET1K1 x,y,z } \\XBOOLE-0K4 {TARSKIK1 x}"
              using A1 zfmisc_1_lm_2 sorry
            thus " False "
              using A2 A4 A5 A7 zfmisc_1_lm_13 A10 xboole_1_th_1 sorry
          qed
          have A11: " not y inTARSKIR2 Z implies  False "
          proof(rule impI)
            have "{ENUMSET1K1 x,y,z } \\XBOOLE-0K4 {TARSKIK1 y} =HIDDENR1 ({TARSKIK2 x,y } \\/XBOOLE-0K2 {TARSKIK1 z})\\XBOOLE-0K4 {TARSKIK1 y}"
              using enumset1_th_3 sorry
            also have "... = (({TARSKIK1 x} \\/XBOOLE-0K2 {TARSKIK1 y})\\/XBOOLE-0K2 {TARSKIK1 z})\\XBOOLE-0K4 {TARSKIK1 y}"
              using enumset1_th_1 sorry
            also have "... = (({TARSKIK1 x} \\/XBOOLE-0K2 {TARSKIK1 z})\\/XBOOLE-0K2 {TARSKIK1 y})\\XBOOLE-0K4 {TARSKIK1 y}"
              using xboole_1_th_4 sorry
            also have "... = ({TARSKIK2 x,z } \\/XBOOLE-0K2 {TARSKIK1 y})\\XBOOLE-0K4 {TARSKIK1 y}"
              using enumset1_th_1 sorry
            also have "... = {TARSKIK2 x,z } \\XBOOLE-0K4 {TARSKIK1 y}"
              using xboole_1_th_40 sorry
            finally have "{ENUMSET1K1 x,y,z } \\XBOOLE-0K4 {TARSKIK1 y} =HIDDENR1 {TARSKIK2 x,z } \\XBOOLE-0K4 {TARSKIK1 y}"
               sorry
            then have A12: "{ENUMSET1K1 x,y,z } \\XBOOLE-0K4 {TARSKIK1 y} c=TARSKIR1 {TARSKIK2 x,z }"
              using xboole_1_th_36 sorry
            assume " not y inTARSKIR2 Z"
            then have "Z c=TARSKIR1 {ENUMSET1K1 x,y,z } \\XBOOLE-0K4 {TARSKIK1 y}"
              using A1 zfmisc_1_lm_2 sorry
            thus " False "
              using A2 A3 A5 A8 zfmisc_1_lm_13 A12 xboole_1_th_1 sorry
          qed
          have A13: " not z inTARSKIR2 Z implies  False "
          proof(rule impI)
            have "{ENUMSET1K1 x,y,z } \\XBOOLE-0K4 {TARSKIK1 z} =HIDDENR1 ({TARSKIK2 x,y } \\/XBOOLE-0K2 {TARSKIK1 z})\\XBOOLE-0K4 {TARSKIK1 z}"
              using enumset1_th_3 sorry
            also have "... = {TARSKIK2 x,y } \\XBOOLE-0K4 {TARSKIK1 z}"
              using xboole_1_th_40 sorry
            finally have "{ENUMSET1K1 x,y,z } \\XBOOLE-0K4 {TARSKIK1 z} =HIDDENR1 {TARSKIK2 x,y } \\XBOOLE-0K4 {TARSKIK1 z}"
               sorry
            then have A14: "{ENUMSET1K1 x,y,z } \\XBOOLE-0K4 {TARSKIK1 z} c=TARSKIR1 {TARSKIK2 x,y }"
              using xboole_1_th_36 sorry
            assume " not z inTARSKIR2 Z"
            then have "Z c=TARSKIR1 {ENUMSET1K1 x,y,z } \\XBOOLE-0K4 {TARSKIK1 z}"
              using A1 zfmisc_1_lm_2 sorry
            thus " False "
              using A2 A3 A4 A6 zfmisc_1_lm_13 A14 xboole_1_th_1 sorry
          qed
          assume "a inHIDDENR3 {ENUMSET1K1 x,y,z }"
          thus "a inHIDDENR3 Z"
            using A9 A11 A13 enumset1_def_1 sorry
        qed "sorry"
        thus "{ENUMSET1K1 x,y,z } c=TARSKIR1 Z"
          using tarski_def_3 sorry
      qed
      thus "Z =XBOOLE-0R4 {ENUMSET1K1 x,y,z }"
        using A1 sorry
    qed
    assume A15: "((((((Z =XBOOLE-0R4 {}XBOOLE-0K1 or Z =XBOOLE-0R4 {TARSKIK1 x}) or Z =XBOOLE-0R4 {TARSKIK1 y}) or Z =XBOOLE-0R4 {TARSKIK1 z}) or Z =XBOOLE-0R4 {TARSKIK2 x,y }) or Z =XBOOLE-0R4 {TARSKIK2 y,z }) or Z =XBOOLE-0R4 {TARSKIK2 x,z }) or Z =XBOOLE-0R4 {ENUMSET1K1 x,y,z }"
    show "Z c=TARSKIR1 {ENUMSET1K1 x,y,z }"
    proof-
      have cases: "((((((Z =XBOOLE-0R4 {}XBOOLE-0K1 or Z =XBOOLE-0R4 {TARSKIK1 x}) or Z =XBOOLE-0R4 {TARSKIK1 y}) or Z =XBOOLE-0R4 {TARSKIK1 z}) or Z =XBOOLE-0R4 {TARSKIK2 x,y }) or Z =XBOOLE-0R4 {TARSKIK2 y,z }) or Z =XBOOLE-0R4 {TARSKIK2 x,z }) or Z =XBOOLE-0R4 {ENUMSET1K1 x,y,z }"
        using A15 sorry
      have case1: "Z =XBOOLE-0R4 {}XBOOLE-0K1 implies Z c=TARSKIR1 {ENUMSET1K1 x,y,z }"
      proof(rule impI)
        assume "Z =XBOOLE-0R4 {}XBOOLE-0K1"
        thus "Z c=TARSKIR1 {ENUMSET1K1 x,y,z }"
           sorry
      qed
      have case2: "Z =XBOOLE-0R4 {TARSKIK1 x} implies Z c=TARSKIR1 {ENUMSET1K1 x,y,z }"
      proof(rule impI)
        assume "Z =XBOOLE-0R4 {TARSKIK1 x}"
        then have "Z c=TARSKIR1 {TARSKIK1 x} \\/XBOOLE-0K2 {TARSKIK2 y,z }"
          using xboole_1_th_7 sorry
        thus "Z c=TARSKIR1 {ENUMSET1K1 x,y,z }"
          using enumset1_th_2 sorry
      qed
      have case3: "Z =XBOOLE-0R4 {TARSKIK1 y} implies Z c=TARSKIR1 {ENUMSET1K1 x,y,z }"
      proof(rule impI)
        assume A16: "Z =XBOOLE-0R4 {TARSKIK1 y}"
        have "{TARSKIK2 x,y } c=TARSKIR1 {TARSKIK2 x,y } \\/XBOOLE-0K2 {TARSKIK1 z}"
          using xboole_1_th_7 sorry
        then have A17: "{TARSKIK2 x,y } c=TARSKIR1 {ENUMSET1K1 x,y,z }"
          using enumset1_th_3 sorry
        have "Z c=TARSKIR1 {TARSKIK2 x,y }"
          using A16 zfmisc_1_th_7 sorry
        thus "Z c=TARSKIR1 {ENUMSET1K1 x,y,z }"
          using A17 sorry
      qed
      have case4: "Z =XBOOLE-0R4 {TARSKIK1 z} implies Z c=TARSKIR1 {ENUMSET1K1 x,y,z }"
      proof(rule impI)
        assume "Z =XBOOLE-0R4 {TARSKIK1 z}"
        then have "Z c=TARSKIR1 {TARSKIK2 x,y } \\/XBOOLE-0K2 {TARSKIK1 z}"
          using xboole_1_th_7 sorry
        thus "Z c=TARSKIR1 {ENUMSET1K1 x,y,z }"
          using enumset1_th_3 sorry
      qed
      have case5: "Z =XBOOLE-0R4 {TARSKIK2 x,y } implies Z c=TARSKIR1 {ENUMSET1K1 x,y,z }"
      proof(rule impI)
        assume "Z =XBOOLE-0R4 {TARSKIK2 x,y }"
        then have "Z c=TARSKIR1 {TARSKIK2 x,y } \\/XBOOLE-0K2 {TARSKIK1 z}"
          using xboole_1_th_7 sorry
        thus "Z c=TARSKIR1 {ENUMSET1K1 x,y,z }"
          using enumset1_th_3 sorry
      qed
      have case6: "Z =XBOOLE-0R4 {TARSKIK2 y,z } implies Z c=TARSKIR1 {ENUMSET1K1 x,y,z }"
      proof(rule impI)
        assume "Z =XBOOLE-0R4 {TARSKIK2 y,z }"
        then have "Z c=TARSKIR1 {TARSKIK1 x} \\/XBOOLE-0K2 {TARSKIK2 y,z }"
          using xboole_1_th_7 sorry
        thus "Z c=TARSKIR1 {ENUMSET1K1 x,y,z }"
          using enumset1_th_2 sorry
      qed
      have case7: "Z =XBOOLE-0R4 {TARSKIK2 x,z } implies Z c=TARSKIR1 {ENUMSET1K1 x,y,z }"
      proof(rule impI)
        assume A18: "Z =XBOOLE-0R4 {TARSKIK2 x,z }"
        have A19: "{TARSKIK2 x,z } \\/XBOOLE-0K2 {TARSKIK1 y} =HIDDENR1 ({TARSKIK1 x} \\/XBOOLE-0K2 {TARSKIK1 z})\\/XBOOLE-0K2 {TARSKIK1 y}"
          using enumset1_th_1 sorry
        also have "... = {TARSKIK1 x} \\/XBOOLE-0K2 ({TARSKIK1 y} \\/XBOOLE-0K2 {TARSKIK1 z})"
          using xboole_1_th_4 sorry
        also have "... = {TARSKIK1 x} \\/XBOOLE-0K2 {TARSKIK2 y,z }"
          using enumset1_th_1 sorry
        finally have "{TARSKIK2 x,z } \\/XBOOLE-0K2 {TARSKIK1 y} =HIDDENR1 {TARSKIK1 x} \\/XBOOLE-0K2 {TARSKIK2 y,z }"
           sorry
        have "Z c=TARSKIR1 {TARSKIK2 x,z } \\/XBOOLE-0K2 {TARSKIK1 y}"
          using A18 xboole_1_th_7 sorry
        thus "Z c=TARSKIR1 {ENUMSET1K1 x,y,z }"
          using A19 enumset1_th_2 sorry
      qed
      have case8: "Z =XBOOLE-0R4 {ENUMSET1K1 x,y,z } implies Z c=TARSKIR1 {ENUMSET1K1 x,y,z }"
      proof(rule impI)
        assume "Z =XBOOLE-0R4 {ENUMSET1K1 x,y,z }"
        thus "Z c=TARSKIR1 {ENUMSET1K1 x,y,z }"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 case4 case5 case6 case7 case8 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_119:
" for N be setHIDDENM2 holds  for M be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds N c=TARSKIR1 [:ZFMISC-1K2 X1,Y1 :] & M c=TARSKIR1 [:ZFMISC-1K2 X2,Y2 :] implies N \\/XBOOLE-0K2 M c=TARSKIR1 [:ZFMISC-1K2 X1 \\/XBOOLE-0K2 X2,Y1 \\/XBOOLE-0K2 Y2 :]"
proof-
  have " for N be setHIDDENM2 holds  for M be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds N c=TARSKIR1 [:ZFMISC-1K2 X1,Y1 :] & M c=TARSKIR1 [:ZFMISC-1K2 X2,Y2 :] implies N \\/XBOOLE-0K2 M c=TARSKIR1 [:ZFMISC-1K2 X1 \\/XBOOLE-0K2 X2,Y1 \\/XBOOLE-0K2 Y2 :]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix N assume [ty]: "N be setHIDDENM2"
    fix M assume [ty]: "M be setHIDDENM2"
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix Y2 assume [ty]: "Y2 be setHIDDENM2"
    assume "N c=TARSKIR1 [:ZFMISC-1K2 X1,Y1 :] & M c=TARSKIR1 [:ZFMISC-1K2 X2,Y2 :]"
    then have A1: "N \\/XBOOLE-0K2 M c=TARSKIR1 [:ZFMISC-1K2 X1,Y1 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X2,Y2 :]"
      using xboole_1_th_13 sorry
    have "X1 c=TARSKIR1 X1 \\/XBOOLE-0K2 X2 & Y1 c=TARSKIR1 Y1 \\/XBOOLE-0K2 Y2"
      using xboole_1_th_7 sorry
    then have A2: "[:ZFMISC-1K2 X1,Y1 :] c=TARSKIR1 [:ZFMISC-1K2 X1 \\/XBOOLE-0K2 X2,Y1 \\/XBOOLE-0K2 Y2 :]"
      using zfmisc_1_th_96 sorry
    have "Y2 c=TARSKIR1 Y1 \\/XBOOLE-0K2 Y2 & X2 c=TARSKIR1 X1 \\/XBOOLE-0K2 X2"
      using xboole_1_th_7 sorry
    then have "[:ZFMISC-1K2 X2,Y2 :] c=TARSKIR1 [:ZFMISC-1K2 X1 \\/XBOOLE-0K2 X2,Y1 \\/XBOOLE-0K2 Y2 :]"
      using zfmisc_1_th_96 sorry
    then have "[:ZFMISC-1K2 X1,Y1 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X2,Y2 :] c=TARSKIR1 [:ZFMISC-1K2 X1 \\/XBOOLE-0K2 X2,Y1 \\/XBOOLE-0K2 Y2 :]"
      using A2 xboole_1_th_8 sorry
    thus "N \\/XBOOLE-0K2 M c=TARSKIR1 [:ZFMISC-1K2 X1 \\/XBOOLE-0K2 X2,Y1 \\/XBOOLE-0K2 Y2 :]"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma zfmisc_1_lm_20:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  not x inHIDDENR3 X &  not y inHIDDENR3 X implies {TARSKIK2 x,y } missesXBOOLE-0R1 X"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  not x inHIDDENR3 X &  not y inHIDDENR3 X implies {TARSKIK2 x,y } missesXBOOLE-0R1 X"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: " not x inHIDDENR3 X &  not y inHIDDENR3 X"
    have "{TARSKIK2 x,y } /\\XBOOLE-0K3 X c=TARSKIR1 {}XBOOLE-0K1 & {}XBOOLE-0K1 c=TARSKIR1 {TARSKIK2 x,y } /\\XBOOLE-0K3 X"
    proof(rule conjMI)
      show "{TARSKIK2 x,y } /\\XBOOLE-0K3 X c=TARSKIR1 {}XBOOLE-0K1"
      proof-
        have " for z be objectHIDDENM1 holds z inHIDDENR3 {TARSKIK2 x,y } /\\XBOOLE-0K3 X implies z inHIDDENR3 {}XBOOLE-0K1"
        proof(rule ballI,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          assume "z inHIDDENR3 {TARSKIK2 x,y } /\\XBOOLE-0K3 X"
          then have "z inHIDDENR3 {TARSKIK2 x,y } & z inHIDDENR3 X"
            using xboole_0_def_4 sorry
          thus "z inHIDDENR3 {}XBOOLE-0K1"
            using A1 tarski_def_2 sorry
        qed "sorry"
        thus "{TARSKIK2 x,y } /\\XBOOLE-0K3 X c=TARSKIR1 {}XBOOLE-0K1"
          using tarski_def_3 sorry
      qed
      show "{}XBOOLE-0K1 c=TARSKIR1 {TARSKIK2 x,y } /\\XBOOLE-0K3 X"
         sorry
    qed
    thus "{TARSKIK2 x,y } missesXBOOLE-0R1 X"
      using xboole_0_def_7 xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_120:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  not x inHIDDENR3 X &  not y inHIDDENR3 X implies X =XBOOLE-0R4 X \\XBOOLE-0K4 {TARSKIK2 x,y }"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  not (( not x inHIDDENR3 X &  not y inHIDDENR3 X) &  not X =XBOOLE-0R4 X \\XBOOLE-0K4 {TARSKIK2 x,y })"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    have "X \\XBOOLE-0K4 {TARSKIK2 x,y } =XBOOLE-0R4 X iff X missesXBOOLE-0R1 {TARSKIK2 x,y }"
      using xboole_1_th_83 sorry
    thus " not (( not x inHIDDENR3 X &  not y inHIDDENR3 X) &  not X =XBOOLE-0R4 X \\XBOOLE-0K4 {TARSKIK2 x,y })"
      using zfmisc_1_lm_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_121:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  not x inHIDDENR3 X &  not y inHIDDENR3 X implies X =XBOOLE-0R4 (X \\/XBOOLE-0K2 {TARSKIK2 x,y })\\XBOOLE-0K4 {TARSKIK2 x,y }"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  not x inHIDDENR3 X &  not y inHIDDENR3 X implies X =XBOOLE-0R4 (X \\/XBOOLE-0K2 {TARSKIK2 x,y })\\XBOOLE-0K4 {TARSKIK2 x,y }"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    have A1: "(X \\/XBOOLE-0K2 {TARSKIK2 x,y })\\XBOOLE-0K4 {TARSKIK2 x,y } =XBOOLE-0R4 X \\XBOOLE-0K4 {TARSKIK2 x,y }"
      using xboole_1_th_40 sorry
    assume " not x inHIDDENR3 X &  not y inHIDDENR3 X"
    thus "X =XBOOLE-0R4 (X \\/XBOOLE-0K2 {TARSKIK2 x,y })\\XBOOLE-0K4 {TARSKIK2 x,y }"
      using A1 zfmisc_1_th_120 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef zfmisc_1_def_5 ("'( _ , _ , _ ')are-mutually-distinctZFMISC-1R1" [0,0,0]50 ) where
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1"
"pred (x1,x2,x3)are-mutually-distinctZFMISC-1R1 means
  (x1 <>HIDDENR2 x2 & x1 <>HIDDENR2 x3) & x2 <>HIDDENR2 x3"..

mdef zfmisc_1_def_6 ("'( _ , _ , _ , _ ')are-mutually-distinctZFMISC-1R2" [0,0,0,0]50 ) where
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1"
"pred (x1,x2,x3,x4)are-mutually-distinctZFMISC-1R2 means
  ((((x1 <>HIDDENR2 x2 & x1 <>HIDDENR2 x3) & x1 <>HIDDENR2 x4) & x2 <>HIDDENR2 x3) & x2 <>HIDDENR2 x4) & x3 <>HIDDENR2 x4"..

mdef zfmisc_1_def_7 ("'( _ , _ , _ , _ , _ ')are-mutually-distinctZFMISC-1R3" [0,0,0,0,0]50 ) where
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1", "x5 be objectHIDDENM1"
"pred (x1,x2,x3,x4,x5)are-mutually-distinctZFMISC-1R3 means
  ((((((((x1 <>HIDDENR2 x2 & x1 <>HIDDENR2 x3) & x1 <>HIDDENR2 x4) & x1 <>HIDDENR2 x5) & x2 <>HIDDENR2 x3) & x2 <>HIDDENR2 x4) & x2 <>HIDDENR2 x5) & x3 <>HIDDENR2 x4) & x3 <>HIDDENR2 x5) & x4 <>HIDDENR2 x5"..

mdef zfmisc_1_def_8 ("'( _ , _ , _ , _ , _ , _ ')are-mutually-distinctZFMISC-1R4" [0,0,0,0,0,0]50 ) where
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1", "x5 be objectHIDDENM1", "x6 be objectHIDDENM1"
"pred (x1,x2,x3,x4,x5,x6)are-mutually-distinctZFMISC-1R4 means
  (((((((((((((x1 <>HIDDENR2 x2 & x1 <>HIDDENR2 x3) & x1 <>HIDDENR2 x4) & x1 <>HIDDENR2 x5) & x1 <>HIDDENR2 x6) & x2 <>HIDDENR2 x3) & x2 <>HIDDENR2 x4) & x2 <>HIDDENR2 x5) & x2 <>HIDDENR2 x6) & x3 <>HIDDENR2 x4) & x3 <>HIDDENR2 x5) & x3 <>HIDDENR2 x6) & x4 <>HIDDENR2 x5) & x4 <>HIDDENR2 x6) & x5 <>HIDDENR2 x6"..

mdef zfmisc_1_def_9 ("'( _ , _ , _ , _ , _ , _ , _ ')are-mutually-distinctZFMISC-1R5" [0,0,0,0,0,0,0]50 ) where
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1", "x5 be objectHIDDENM1", "x6 be objectHIDDENM1", "x7 be objectHIDDENM1"
"pred (x1,x2,x3,x4,x5,x6,x7)are-mutually-distinctZFMISC-1R5 means
  (((((((((((((((((((x1 <>HIDDENR2 x2 & x1 <>HIDDENR2 x3) & x1 <>HIDDENR2 x4) & x1 <>HIDDENR2 x5) & x1 <>HIDDENR2 x6) & x1 <>HIDDENR2 x7) & x2 <>HIDDENR2 x3) & x2 <>HIDDENR2 x4) & x2 <>HIDDENR2 x5) & x2 <>HIDDENR2 x6) & x2 <>HIDDENR2 x7) & x3 <>HIDDENR2 x4) & x3 <>HIDDENR2 x5) & x3 <>HIDDENR2 x6) & x3 <>HIDDENR2 x7) & x4 <>HIDDENR2 x5) & x4 <>HIDDENR2 x6) & x4 <>HIDDENR2 x7) & x5 <>HIDDENR2 x6) & x5 <>HIDDENR2 x7) & x6 <>HIDDENR2 x7"..

mtheorem zfmisc_1_th_122:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds [:ZFMISC-1K2 {TARSKIK2 x1,x2 },{TARSKIK2 y1,y2 } :] =XBOOLE-0R4 {ENUMSET1K2 [TARSKIK4 x1,y1 ],[TARSKIK4 x1,y2 ],[TARSKIK4 x2,y1 ],[TARSKIK4 x2,y2 ] }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds [:ZFMISC-1K2 {TARSKIK2 x1,x2 },{TARSKIK2 y1,y2 } :] =HIDDENR1 {ENUMSET1K2 [TARSKIK4 x1,y1 ],[TARSKIK4 x1,y2 ],[TARSKIK4 x2,y1 ],[TARSKIK4 x2,y2 ] }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix y1 assume [ty]: "y1 be objectHIDDENM1"
    fix y2 assume [ty]: "y2 be objectHIDDENM1"
    have "[:ZFMISC-1K2 {TARSKIK2 x1,x2 },{TARSKIK2 y1,y2 } :] =HIDDENR1 [:ZFMISC-1K2 {TARSKIK1 x1} \\/XBOOLE-0K2 {TARSKIK1 x2},{TARSKIK2 y1,y2 } :]"
      using enumset1_th_1 sorry
    also have "... = [:ZFMISC-1K2 {TARSKIK1 x1},{TARSKIK2 y1,y2 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 x2},{TARSKIK2 y1,y2 } :]"
      using zfmisc_1_th_97 sorry
    also have "... = {TARSKIK2 [TARSKIK4 x1,y1 ],[TARSKIK4 x1,y2 ] } \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 x2},{TARSKIK2 y1,y2 } :]"
      using zfmisc_1_th_30 sorry
    also have "... = {TARSKIK2 [TARSKIK4 x1,y1 ],[TARSKIK4 x1,y2 ] } \\/XBOOLE-0K2 {TARSKIK2 [TARSKIK4 x2,y1 ],[TARSKIK4 x2,y2 ] }"
      using zfmisc_1_th_30 sorry
    also have "... = {ENUMSET1K2 [TARSKIK4 x1,y1 ],[TARSKIK4 x1,y2 ],[TARSKIK4 x2,y1 ],[TARSKIK4 x2,y2 ] }"
      using enumset1_th_5 sorry
    finally show "[:ZFMISC-1K2 {TARSKIK2 x1,x2 },{TARSKIK2 y1,y2 } :] =HIDDENR1 {ENUMSET1K2 [TARSKIK4 x1,y1 ],[TARSKIK4 x1,y2 ],[TARSKIK4 x2,y1 ],[TARSKIK4 x2,y2 ] }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_123:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for A be setHIDDENM2 holds x <>HIDDENR2 y implies (A \\/XBOOLE-0K2 {TARSKIK1 x})\\XBOOLE-0K4 {TARSKIK1 y} =XBOOLE-0R4 (A \\XBOOLE-0K4 {TARSKIK1 y})\\/XBOOLE-0K2 {TARSKIK1 x}"
  using zfmisc_1_th_11 xboole_1_th_87 sorry

mdef zfmisc_1_def_10 ("trivialZFMISC-1V1" 70 ) where
"attr trivialZFMISC-1V1 for setHIDDENM2 means
  (\<lambda>X.  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 X & y inHIDDENR3 X implies x =HIDDENR1 y)"..

mtheorem zfmisc_1_cl_1:
"cluster emptyXBOOLE-0V1 also-is trivialZFMISC-1V1 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be emptyXBOOLE-0V1 implies it be trivialZFMISC-1V1"
     sorry
qed "sorry"

mtheorem zfmisc_1_cl_2:
"cluster  non trivialZFMISC-1V1 also-is  non emptyXBOOLE-0V1 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be  non trivialZFMISC-1V1 implies it be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem zfmisc_1_cl_3:
  mlet "x be objectHIDDENM1"
"cluster {TARSKIK1 x} as-term-is trivialZFMISC-1V1"
proof
(*coherence*)
  show "{TARSKIK1 x} be trivialZFMISC-1V1"
  proof-
    have " for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds y inHIDDENR3 {TARSKIK1 x} & z inHIDDENR3 {TARSKIK1 x} implies y =HIDDENR1 z"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      fix z assume [ty]: "z be objectHIDDENM1"
      assume A1: "y inHIDDENR3 {TARSKIK1 x}"
        and A2: "z inHIDDENR3 {TARSKIK1 x}"
      have "y =HIDDENR1 x"
        using A1 tarski_def_1 sorry
      thus "y =HIDDENR1 z"
        using A2 tarski_def_1 sorry
    qed "sorry"
    thus "{TARSKIK1 x} be trivialZFMISC-1V1"
      using zfmisc_1_def_10 sorry
  qed
qed "sorry"

mtheorem zfmisc_1_cl_4:
"cluster trivialZFMISC-1V1\<bar> non emptyXBOOLE-0V1 for setHIDDENM2"
proof
(*existence*)
  show " ex it be setHIDDENM2 st it be trivialZFMISC-1V1\<bar> non emptyXBOOLE-0V1"
  proof-
    have " ex tVar6 be setHIDDENM2 st tVar6 be trivialZFMISC-1V1 &  not tVar6 be emptyXBOOLE-0V1"
    proof-
      show " ex tVar6 be setHIDDENM2 st tVar6 be trivialZFMISC-1V1 &  not tVar6 be emptyXBOOLE-0V1"
      proof(rule bexI[of _ "{TARSKIK1 {}XBOOLE-0K1 }"])
        show "{TARSKIK1 {}XBOOLE-0K1 } be trivialZFMISC-1V1 &  not {TARSKIK1 {}XBOOLE-0K1 } be emptyXBOOLE-0V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem zfmisc_1_th_124:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for C be setHIDDENM2 holds  for p be objectHIDDENM1 holds (A c=TARSKIR1 B & B /\\XBOOLE-0K3 C =XBOOLE-0R4 {TARSKIK1 p}) & p inHIDDENR3 A implies A /\\XBOOLE-0K3 C =XBOOLE-0R4 {TARSKIK1 p}"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for C be setHIDDENM2 holds  for p be objectHIDDENM1 holds A c=TARSKIR1 B implies (B /\\XBOOLE-0K3 C =XBOOLE-0R4 {TARSKIK1 p} implies (p inHIDDENR3 A implies A /\\XBOOLE-0K3 C =XBOOLE-0R4 {TARSKIK1 p}))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    fix C assume [ty]: "C be setHIDDENM2"
    fix p assume [ty]: "p be objectHIDDENM1"
    assume A1: "A c=TARSKIR1 B"
    assume A2: "B /\\XBOOLE-0K3 C =XBOOLE-0R4 {TARSKIK1 p}"
    have "p inHIDDENR3 B /\\XBOOLE-0K3 C"
      using A2 tarski_def_1 sorry
    then have A3: "p inHIDDENR3 C"
      using xboole_0_def_4 sorry
    assume "p inHIDDENR3 A"
    then have "p inHIDDENR3 A /\\XBOOLE-0K3 C"
      using A3 xboole_0_def_4 sorry
    thus "A /\\XBOOLE-0K3 C =XBOOLE-0R4 {TARSKIK1 p}"
      using A2 zfmisc_1_lm_3 A1 xboole_1_th_26 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_125:
" for p be objectHIDDENM1 holds  for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for C be setHIDDENM2 holds (A /\\XBOOLE-0K3 B c=TARSKIR1 {TARSKIK1 p} & p inHIDDENR3 C) & C missesXBOOLE-0R1 B implies A \\/XBOOLE-0K2 C missesXBOOLE-0R1 B"
proof-
  have " for p be objectHIDDENM1 holds  for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for C be setHIDDENM2 holds A /\\XBOOLE-0K3 B c=TARSKIR1 {TARSKIK1 p} & (p inHIDDENR3 C & C missesXBOOLE-0R1 B) implies A \\/XBOOLE-0K2 C missesXBOOLE-0R1 B"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix p assume [ty]: "p be objectHIDDENM1"
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    fix C assume [ty]: "C be setHIDDENM2"
    assume A1: "A /\\XBOOLE-0K3 B c=TARSKIR1 {TARSKIK1 p}"
      and A2: "p inHIDDENR3 C"
      and A3: "C missesXBOOLE-0R1 B"
    have "{TARSKIK1 p} c=TARSKIR1 C"
      using A2 zfmisc_1_lm_1 sorry
    then have "A /\\XBOOLE-0K3 B c=TARSKIR1 C"
      using A1 sorry
    then have "(A /\\XBOOLE-0K3 B)/\\XBOOLE-0K3 B c=TARSKIR1 C /\\XBOOLE-0K3 B"
      using xboole_1_th_27 sorry
    then have A4: "A /\\XBOOLE-0K3 (B /\\XBOOLE-0K3 B) c=TARSKIR1 C /\\XBOOLE-0K3 B"
      using xboole_1_th_16 sorry
    have "(A \\/XBOOLE-0K2 C)/\\XBOOLE-0K3 B =HIDDENR1 A /\\XBOOLE-0K3 B \\/XBOOLE-0K2 C /\\XBOOLE-0K3 B"
      using xboole_1_th_23 sorry
    also have "... = {}XBOOLE-0K1"
      using A3 A4 xboole_1_th_12 sorry
    finally have "(A \\/XBOOLE-0K2 C)/\\XBOOLE-0K3 B =HIDDENR1 {}XBOOLE-0K1"
       sorry
    thus "A \\/XBOOLE-0K2 C missesXBOOLE-0R1 B"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_126:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds ( for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 A & y inTARSKIR2 B implies x missesXBOOLE-0R1 y) implies unionTARSKIK3 A missesXBOOLE-0R1 unionTARSKIK3 B"
proof(rule ballI,rule ballI,rule impI)
  fix A assume [ty]: "A be setHIDDENM2"
  fix B assume [ty]: "B be setHIDDENM2"
  assume A1: " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 A & y inTARSKIR2 B implies x missesXBOOLE-0R1 y"
  have " for y be setHIDDENM2 holds y inTARSKIR2 B implies unionTARSKIK3 A missesXBOOLE-0R1 y"
  proof(rule ballI,rule impI)
    fix y assume [ty]: "y be setHIDDENM2"
    assume "y inTARSKIR2 B"
    then have " for x be setHIDDENM2 holds x inTARSKIR2 A implies x missesXBOOLE-0R1 y"
      using A1 sorry
    thus "unionTARSKIK3 A missesXBOOLE-0R1 y"
      using zfmisc_1_th_80 sorry
  qed "sorry"
  thus "unionTARSKIK3 A missesXBOOLE-0R1 unionTARSKIK3 B"
    using zfmisc_1_th_80 sorry
qed "sorry"

mtheorem zfmisc_1_cl_5:
  mlet "X be setHIDDENM2", "Y be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster [:ZFMISC-1K2 X,Y :] as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "[:ZFMISC-1K2 X,Y :] be emptyXBOOLE-0V1"
    using zfmisc_1_th_90 sorry
qed "sorry"

mtheorem zfmisc_1_cl_6:
  mlet "X be emptyXBOOLE-0V1\<bar>setHIDDENM2", "Y be setHIDDENM2"
"cluster [:ZFMISC-1K2 X,Y :] as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "[:ZFMISC-1K2 X,Y :] be emptyXBOOLE-0V1"
    using zfmisc_1_th_90 sorry
qed "sorry"

mtheorem zfmisc_1_th_127:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  not A inTARSKIR2 [:ZFMISC-1K2 A,B :]"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds A inTARSKIR2 [:ZFMISC-1K2 A,B :] implies  False "
  proof(rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    assume "A inTARSKIR2 [:ZFMISC-1K2 A,B :]"
    then obtain x y where
      [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
      A1: "(x inHIDDENR3 A & y inHIDDENR3 B) & A =HIDDENR1 [TARSKIK4 x,y ]"
      using zfmisc_1_th_84 sorry
    have 
      [ty]:"x be setHIDDENM2"
      using tarski_th_1 sorry
    have "x =XBOOLE-0R4 {TARSKIK1 x} or x =XBOOLE-0R4 {TARSKIK2 x,y }"
      using A1 tarski_def_2 sorry
    then have "x inTARSKIR2 x"
      using tarski_def_1 tarski_def_2 sorry
    thus " False "
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_128:
" for x be objectHIDDENM1 holds  for B be setHIDDENM2 holds B =HIDDENR1 [TARSKIK4 x,{TARSKIK1 x} ] implies B inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 x},B :]"
proof-
  have " for x be objectHIDDENM1 holds  for B be setHIDDENM2 holds B =HIDDENR1 [TARSKIK4 x,{TARSKIK1 x} ] implies B inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 x},B :]"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix B assume [ty]: "B be setHIDDENM2"
    assume A1: "B =HIDDENR1 [TARSKIK4 x,{TARSKIK1 x} ]"
    then have "[:ZFMISC-1K2 {TARSKIK1 x},B :] =XBOOLE-0R4 {TARSKIK2 [TARSKIK4 x,{TARSKIK1 x} ],[TARSKIK4 x,{TARSKIK2 x,{TARSKIK1 x} } ] }"
      using zfmisc_1_th_30 sorry
    thus "B inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 x},B :]"
      using tarski_def_2 A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_129:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds B inTARSKIR2 [:ZFMISC-1K2 A,B :] implies ( ex x be objectHIDDENM1 st x inHIDDENR3 A & B =HIDDENR1 [TARSKIK4 x,{TARSKIK1 x} ])"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds B inTARSKIR2 [:ZFMISC-1K2 A,B :] implies ( ex tVar7 be objectHIDDENM1 st tVar7 inHIDDENR3 A & B =HIDDENR1 [TARSKIK4 tVar7,{TARSKIK1 tVar7} ])"
  proof(rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    assume "B inTARSKIR2 [:ZFMISC-1K2 A,B :]"
    then obtain x y where
      [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
      A1: "(x inHIDDENR3 A & y inHIDDENR3 B) & B =HIDDENR1 [TARSKIK4 x,y ]"
      using zfmisc_1_th_84 sorry
    show " ex tVar7 be objectHIDDENM1 st tVar7 inHIDDENR3 A & B =HIDDENR1 [TARSKIK4 tVar7,{TARSKIK1 tVar7} ]"
    proof(rule bexI[of _ "x"],rule conjMI)
      show "x inHIDDENR3 A"
        using A1 sorry
      show "B =HIDDENR1 [TARSKIK4 x,{TARSKIK1 x} ]"
      proof-
        have cases: "y =HIDDENR1 {TARSKIK1 x} or y =HIDDENR1 {TARSKIK2 x,y }"
          using A1 tarski_def_2 sorry
        have case1: "y =HIDDENR1 {TARSKIK1 x} implies B =HIDDENR1 [TARSKIK4 x,{TARSKIK1 x} ]"
        proof(rule impI)
          assume "y =HIDDENR1 {TARSKIK1 x}"
          thus "B =HIDDENR1 [TARSKIK4 x,{TARSKIK1 x} ]"
            using A1 sorry
        qed
        have case2: "y =HIDDENR1 {TARSKIK2 x,y } implies B =HIDDENR1 [TARSKIK4 x,{TARSKIK1 x} ]"
        proof(rule impI)
          assume A2: "y =HIDDENR1 {TARSKIK2 x,y }"
          have 
            [ty]:"y be setHIDDENM2"
            using tarski_th_1 sorry
          have "y inTARSKIR2 y"
            using tarski_def_2 A2 sorry
          thus "B =HIDDENR1 [TARSKIK4 x,{TARSKIK1 x} ]"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_130:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds B c=TARSKIR1 A & A be trivialZFMISC-1V1 implies B be trivialZFMISC-1V1"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds B c=TARSKIR1 A & A be trivialZFMISC-1V1 implies B be trivialZFMISC-1V1"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    assume A1: "B c=TARSKIR1 A"
      and A2: "A be trivialZFMISC-1V1"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 B & y inHIDDENR3 B implies x =HIDDENR1 y"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "x inHIDDENR3 B & y inHIDDENR3 B"
      then have "x inHIDDENR3 A & y inHIDDENR3 A"
        using A1 sorry
      thus "x =HIDDENR1 y"
        using A2 sorry
    qed "sorry"
    thus "B be trivialZFMISC-1V1"
      using zfmisc_1_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_cl_7:
"cluster  non trivialZFMISC-1V1 for setHIDDENM2"
proof
(*existence*)
  show " ex it be setHIDDENM2 st it be  non trivialZFMISC-1V1"
  proof-
    have " ex tVar8 be setHIDDENM2 st  not tVar8 be trivialZFMISC-1V1"
    proof-
      show " ex tVar8 be setHIDDENM2 st  not tVar8 be trivialZFMISC-1V1"
      proof(rule bexI[of _ "{TARSKIK2 {}XBOOLE-0K1,{TARSKIK1 {}XBOOLE-0K1 } }"])
        have " ex tVar10 be objectHIDDENM1 st ({}XBOOLE-0K1 inTARSKIR2 {TARSKIK2 {}XBOOLE-0K1,tVar10 } & tVar10 inTARSKIR2 {TARSKIK2 {}XBOOLE-0K1,tVar10 }) & {}XBOOLE-0K1 <>HIDDENR2 tVar10"
        proof(rule bexI[of _ "{TARSKIK1 {}XBOOLE-0K1 }"],rule conjMI)
          show "{}XBOOLE-0K1 inTARSKIR2 {TARSKIK2 {}XBOOLE-0K1,{TARSKIK1 {}XBOOLE-0K1 } } & {TARSKIK1 {}XBOOLE-0K1 } inTARSKIR2 {TARSKIK2 {}XBOOLE-0K1,{TARSKIK1 {}XBOOLE-0K1 } }"
            using tarski_def_2 sorry
          show "{}XBOOLE-0K1 <>HIDDENR2 {TARSKIK1 {}XBOOLE-0K1 }"
             sorry
        qed "sorry"
        thus " not {TARSKIK2 {}XBOOLE-0K1,{TARSKIK1 {}XBOOLE-0K1 } } be trivialZFMISC-1V1"
          using bexI[of _ "{}XBOOLE-0K1"] zfmisc_1_def_10 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem zfmisc_1_th_131:
" for X be setHIDDENM2 holds X be  non emptyXBOOLE-0V1\<bar>trivialZFMISC-1V1 implies ( ex x be objectHIDDENM1 st X =XBOOLE-0R4 {TARSKIK1 x})"
proof-
  have " for X be setHIDDENM2 holds X be  non emptyXBOOLE-0V1 implies (X be trivialZFMISC-1V1 implies ( ex tVar11 be objectHIDDENM1 st X =XBOOLE-0R4 {TARSKIK1 tVar11}))"
  proof(rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    assume "X be  non emptyXBOOLE-0V1"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A1: "x inHIDDENR3 X"
       sorry
    assume A2: "X be trivialZFMISC-1V1"
    show " ex tVar11 be objectHIDDENM1 st X =XBOOLE-0R4 {TARSKIK1 tVar11}"
    proof(rule bexI[of _ "x"])
      have " for y be objectHIDDENM1 holds y inHIDDENR3 X iff x =HIDDENR1 y"
        using A2 A1 sorry
      thus "X =XBOOLE-0R4 {TARSKIK1 x}"
        using tarski_def_1 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_132:
" for x be setHIDDENM2 holds  for X be trivialZFMISC-1V1\<bar>setHIDDENM2 holds x inTARSKIR2 X implies X =XBOOLE-0R4 {TARSKIK1 x}"
proof(rule ballI,rule ballI,rule impI)
  fix x assume [ty]: "x be setHIDDENM2"
  fix X assume [ty]: "X be trivialZFMISC-1V1\<bar>setHIDDENM2"
  assume A1: "x inTARSKIR2 X"
  then have " ex x be objectHIDDENM1 st X =XBOOLE-0R4 {TARSKIK1 x}"
    using zfmisc_1_th_131 sorry
  thus "X =XBOOLE-0R4 {TARSKIK1 x}"
    using A1 tarski_def_1 sorry
qed "sorry"

mtheorem zfmisc_1_th_133:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds  for X be setHIDDENM2 holds (a inTARSKIR2 X & b inTARSKIR2 X) & c inTARSKIR2 X implies {ENUMSET1K1 a,b,c } c=TARSKIR1 X"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix a assume [ty]: "a be setHIDDENM2"
  fix b assume [ty]: "b be setHIDDENM2"
  fix c assume [ty]: "c be setHIDDENM2"
  fix X assume [ty]: "X be setHIDDENM2"
  assume "(a inTARSKIR2 X & b inTARSKIR2 X) & c inTARSKIR2 X"
  then have "{TARSKIK2 a,b } c=TARSKIR1 X & {TARSKIK1 c} c=TARSKIR1 X"
    using zfmisc_1_lm_1 zfmisc_1_th_32 sorry
  then have "{TARSKIK2 a,b } \\/XBOOLE-0K2 {TARSKIK1 c} c=TARSKIR1 X"
    using xboole_1_th_8 sorry
  thus "{ENUMSET1K1 a,b,c } c=TARSKIR1 X"
    using enumset1_th_3 sorry
qed "sorry"

mtheorem zfmisc_1_th_134:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds [TARSKIK4 x,y ] inHIDDENR3 X implies x inHIDDENR3 unionTARSKIK3 (unionTARSKIK3 X) & y inHIDDENR3 unionTARSKIK3 (unionTARSKIK3 X)"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds [TARSKIK4 x,y ] inHIDDENR3 X implies x inHIDDENR3 unionTARSKIK3 (unionTARSKIK3 X) & y inHIDDENR3 unionTARSKIK3 (unionTARSKIK3 X)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "[TARSKIK4 x,y ] inHIDDENR3 X"
    have "{TARSKIK1 x} inTARSKIR2 {TARSKIK2 {TARSKIK1 x},{TARSKIK2 x,y } }"
      using tarski_def_2 sorry
    then have A2: "{TARSKIK1 x} inTARSKIR2 unionTARSKIK3 X"
      using A1 tarski_def_4 sorry
    have "{TARSKIK2 x,y } inTARSKIR2 {TARSKIK2 {TARSKIK1 x},{TARSKIK2 x,y } }"
      using tarski_def_2 sorry
    then have A3: "{TARSKIK2 x,y } inTARSKIR2 unionTARSKIK3 X"
      using A1 tarski_def_4 sorry
    have "y inHIDDENR3 {TARSKIK2 x,y } & x inHIDDENR3 {TARSKIK1 x}"
      using tarski_def_1 tarski_def_2 sorry
    thus "x inHIDDENR3 unionTARSKIK3 (unionTARSKIK3 X) & y inHIDDENR3 unionTARSKIK3 (unionTARSKIK3 X)"
      using A3 A2 tarski_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_135:
" for x be objectHIDDENM1 holds  for Y be setHIDDENM2 holds  for X be setHIDDENM2 holds X c=TARSKIR1 Y \\/XBOOLE-0K2 {TARSKIK1 x} implies x inHIDDENR3 X or X c=TARSKIR1 Y"
proof-
  have " for x be objectHIDDENM1 holds  for Y be setHIDDENM2 holds  for X be setHIDDENM2 holds X c=TARSKIR1 Y \\/XBOOLE-0K2 {TARSKIK1 x} &  not x inHIDDENR3 X implies X c=TARSKIR1 Y"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "X c=TARSKIR1 Y \\/XBOOLE-0K2 {TARSKIK1 x}"
      and A2: " not x inHIDDENR3 X"
    have "X =HIDDENR1 X /\\XBOOLE-0K3 (Y \\/XBOOLE-0K2 {TARSKIK1 x})"
      using A1 xboole_1_th_28 sorry
    also have "... = X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 X /\\XBOOLE-0K3 {TARSKIK1 x}"
      using xboole_1_th_23 sorry
    also have "... = X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 {}XBOOLE-0K1"
      using A2 zfmisc_1_lm_6 xboole_0_def_7 sorry
    also have "... = X /\\XBOOLE-0K3 Y"
       sorry
    finally have "X =HIDDENR1 X /\\XBOOLE-0K3 Y"
       sorry
    thus "X c=TARSKIR1 Y"
      using xboole_1_th_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_136:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds x inHIDDENR3 X \\/XBOOLE-0K2 {TARSKIK1 y} iff x inHIDDENR3 X or x =HIDDENR1 y"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  not ((x inHIDDENR3 X \\/XBOOLE-0K2 {TARSKIK1 y} &  not x inHIDDENR3 X) &  not x =HIDDENR1 y) &  not ( not ( not x inHIDDENR3 X &  not x =HIDDENR1 y) &  not x inHIDDENR3 X \\/XBOOLE-0K2 {TARSKIK1 y})"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    have "x inHIDDENR3 X \\/XBOOLE-0K2 {TARSKIK1 y} iff x inHIDDENR3 X or x inHIDDENR3 {TARSKIK1 y}"
      using xboole_0_def_3 sorry
    thus " not ((x inHIDDENR3 X \\/XBOOLE-0K2 {TARSKIK1 y} &  not x inHIDDENR3 X) &  not x =HIDDENR1 y) &  not ( not ( not x inHIDDENR3 X &  not x =HIDDENR1 y) &  not x inHIDDENR3 X \\/XBOOLE-0K2 {TARSKIK1 y})"
      using tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_137:
" for x be objectHIDDENM1 holds  for Y be setHIDDENM2 holds  for X be setHIDDENM2 holds X \\/XBOOLE-0K2 {TARSKIK1 x} c=TARSKIR1 Y iff x inHIDDENR3 Y & X c=TARSKIR1 Y"
proof-
  have " for x be objectHIDDENM1 holds  for Y be setHIDDENM2 holds  for X be setHIDDENM2 holds  not (X \\/XBOOLE-0K2 {TARSKIK1 x} c=TARSKIR1 Y &  not (x inHIDDENR3 Y & X c=TARSKIR1 Y)) &  not ((x inHIDDENR3 Y & X c=TARSKIR1 Y) &  not X \\/XBOOLE-0K2 {TARSKIK1 x} c=TARSKIR1 Y)"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    have "X c=TARSKIR1 Y & {TARSKIK1 x} c=TARSKIR1 Y implies X \\/XBOOLE-0K2 {TARSKIK1 x} c=TARSKIR1 Y"
      using xboole_1_th_8 sorry
    thus " not (X \\/XBOOLE-0K2 {TARSKIK1 x} c=TARSKIR1 Y &  not (x inHIDDENR3 Y & X c=TARSKIR1 Y)) &  not ((x inHIDDENR3 Y & X c=TARSKIR1 Y) &  not X \\/XBOOLE-0K2 {TARSKIK1 x} c=TARSKIR1 Y)"
      using zfmisc_1_lm_1 xboole_1_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_th_138:
" for a be objectHIDDENM1 holds  for A be setHIDDENM2 holds  for B be setHIDDENM2 holds A c=TARSKIR1 B & B c=TARSKIR1 A \\/XBOOLE-0K2 {TARSKIK1 a} implies A \\/XBOOLE-0K2 {TARSKIK1 a} =XBOOLE-0R4 B or A =XBOOLE-0R4 B"
proof-
  have " for a be objectHIDDENM1 holds  for A be setHIDDENM2 holds  for B be setHIDDENM2 holds A c=TARSKIR1 B & B c=TARSKIR1 A \\/XBOOLE-0K2 {TARSKIK1 a} implies (A \\/XBOOLE-0K2 {TARSKIK1 a} <>HIDDENR2 B & A <>HIDDENR2 B implies  not  True )"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule impMI ,rule impI)
    fix a assume [ty]: "a be objectHIDDENM1"
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    assume A1: "A c=TARSKIR1 B"
      and A2: "B c=TARSKIR1 A \\/XBOOLE-0K2 {TARSKIK1 a}"
    assume A3: "A \\/XBOOLE-0K2 {TARSKIK1 a} <>HIDDENR2 B"
      and A4: "A <>HIDDENR2 B"
    have " not a inHIDDENR3 B"
    proof-
      have "a inHIDDENR3 B implies  not  True "
      proof(rule impI)
        assume "a inHIDDENR3 B"
        then have "{TARSKIK1 a} c=TARSKIR1 B"
          using zfmisc_1_lm_1 sorry
        thus " not  True "
          using A1 A2 A3 xboole_1_th_8 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus " not  True "
      using A2 zfmisc_1_th_135 A1 A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem zfmisc_1_cl_8:
  mlet "A be trivialZFMISC-1V1\<bar>setHIDDENM2", "B be trivialZFMISC-1V1\<bar>setHIDDENM2"
"cluster [:ZFMISC-1K2 A,B :] as-term-is trivialZFMISC-1V1"
proof
(*coherence*)
  show "[:ZFMISC-1K2 A,B :] be trivialZFMISC-1V1"
  proof-
    show "[:ZFMISC-1K2 A,B :] be trivialZFMISC-1V1"
    proof-
      have cases: "(A be emptyXBOOLE-0V1 or B be emptyXBOOLE-0V1) or  not A be emptyXBOOLE-0V1 &  not B be emptyXBOOLE-0V1"
         sorry
      have case1: "A be emptyXBOOLE-0V1 or B be emptyXBOOLE-0V1 implies [:ZFMISC-1K2 A,B :] be trivialZFMISC-1V1"
      proof(rule impI)
        assume "A be emptyXBOOLE-0V1 or B be emptyXBOOLE-0V1"
        thus "[:ZFMISC-1K2 A,B :] be trivialZFMISC-1V1"
           sorry
      qed
      have case2: " not A be emptyXBOOLE-0V1 &  not B be emptyXBOOLE-0V1 implies [:ZFMISC-1K2 A,B :] be trivialZFMISC-1V1"
      proof(rule impMI ,rule impI)
        assume A1: " not A be emptyXBOOLE-0V1"
          and A2: " not B be emptyXBOOLE-0V1"
        obtain a where
          [ty]:"a be objectHIDDENM1" and 
          A3: "A =XBOOLE-0R4 {TARSKIK1 a}"
          using A1 zfmisc_1_th_131 sorry
        obtain b where
          [ty]:"b be objectHIDDENM1" and 
          A4: "B =XBOOLE-0R4 {TARSKIK1 b}"
          using A2 zfmisc_1_th_131 sorry
        have "[:ZFMISC-1K2 A,B :] =XBOOLE-0R4 {TARSKIK1 [TARSKIK4 a,b ] }"
          using A3 A4 zfmisc_1_th_29 sorry
        thus "[:ZFMISC-1K2 A,B :] be trivialZFMISC-1V1"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
qed "sorry"

mtheorem zfmisc_1_th_139:
" for X be setHIDDENM2 holds X be  non trivialZFMISC-1V1 iff ( for x be objectHIDDENM1 holds X \\XBOOLE-0K4 {TARSKIK1 x} be  non emptyXBOOLE-0V1)"
proof-
  have " for X be setHIDDENM2 holds (X be  non trivialZFMISC-1V1 implies ( for x be objectHIDDENM1 holds X \\XBOOLE-0K4 {TARSKIK1 x} be  non emptyXBOOLE-0V1)) & (( for x be objectHIDDENM1 holds X \\XBOOLE-0K4 {TARSKIK1 x} be  non emptyXBOOLE-0V1) implies  not X be trivialZFMISC-1V1)"
  proof(rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    show "X be  non trivialZFMISC-1V1 implies ( for x be objectHIDDENM1 holds X \\XBOOLE-0K4 {TARSKIK1 x} be  non emptyXBOOLE-0V1)"
    proof(rule impI,rule ballI)
      assume A1: "X be  non trivialZFMISC-1V1"
      fix x assume [ty]: "x be objectHIDDENM1"
      have "X <>HIDDENR2 {TARSKIK1 x}"
        using A1 sorry
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A2: "y inHIDDENR3 X"and A3: "x <>HIDDENR2 y"
        using A1 zfmisc_1_lm_12 sorry
      have " not y inHIDDENR3 {TARSKIK1 x}"
        using A3 tarski_def_1 sorry
      thus "X \\XBOOLE-0K4 {TARSKIK1 x} be  non emptyXBOOLE-0V1"
        using A2 xboole_0_def_5 sorry
    qed "sorry"
    assume A4: " for x be objectHIDDENM1 holds X \\XBOOLE-0K4 {TARSKIK1 x} be  non emptyXBOOLE-0V1"
    have "X \\XBOOLE-0K4 {TARSKIK1 {}XBOOLE-0K1 } c=TARSKIR1 X"
      using xboole_1_th_36 sorry
    then have "X be  non emptyXBOOLE-0V1"
      using A4 sorry
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A5: "x inHIDDENR3 X"
       sorry
    have "X \\XBOOLE-0K4 {TARSKIK1 x} be  non emptyXBOOLE-0V1"
      using A4 sorry
    then obtain y where
      [ty]:"y be objectHIDDENM1" and 
      A6: "y inHIDDENR3 X \\XBOOLE-0K4 {TARSKIK1 x}"
       sorry
    have 
      [ty]:"x be setHIDDENM2" and
      [ty]:"y be setHIDDENM2"
      using tarski_th_1 sorry
    have " ex tVar13 be objectHIDDENM1 st x inTARSKIR2 X & (tVar13 inTARSKIR2 X & x <>HIDDENR2 tVar13)"
    proof(rule bexI[of _ "y"],rule conjMI,rule conjMI)
      show "x inTARSKIR2 X"
        using A5 sorry
      have "X \\XBOOLE-0K4 {TARSKIK1 x} c=TARSKIR1 X"
        using xboole_1_th_36 sorry
      thus "y inTARSKIR2 X"
        using A6 sorry
      have "x inTARSKIR2 {TARSKIK1 x}"
        using tarski_def_1 sorry
      thus "x <>HIDDENR2 y"
        using A6 xboole_0_def_5 sorry
    qed "sorry"
    thus " not X be trivialZFMISC-1V1"
      using bexI[of _ "x"] zfmisc_1_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
