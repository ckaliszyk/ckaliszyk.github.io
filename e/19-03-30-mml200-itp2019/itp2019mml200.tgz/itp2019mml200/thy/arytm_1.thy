theory arytm_1
  imports arytm_2
begin
(*begin*)
reserve x, y, z for "ElementSUBSET-1M1-of REAL+ARYTM-2K2"
mtheorem arytm_1_th_1:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x +ARYTM-2K7 y =HIDDENR1 y implies x =HIDDENR1 {}ARYTM-3K12"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x +ARYTM-2K7 y =HIDDENR1 y implies x =HIDDENR1 {}ARYTM-3K12"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    obtain o where 
      [ty]:"o be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and oDef:"o = {}ARYTM-3K12"
      using arytm_2_th_20 sorry
    assume "x +ARYTM-2K7 y =HIDDENR1 y"
    then have "x +ARYTM-2K7 y =HIDDENR1 y +ARYTM-2K7 o"
      using arytm_2_def_8 sorry
    thus "x =HIDDENR1 {}ARYTM-3K12"
      using arytm_2_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_1_lm_1:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x *'ARYTM-2K8 y =HIDDENR1 x *'ARYTM-2K8 z & x <>HIDDENR2 {}ARYTM-3K12 implies y =HIDDENR1 z"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x *'ARYTM-2K8 y =HIDDENR1 x *'ARYTM-2K8 z implies (x <>HIDDENR2 {}ARYTM-3K12 implies y =HIDDENR1 z)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "x *'ARYTM-2K8 y =HIDDENR1 x *'ARYTM-2K8 z"
    assume "x <>HIDDENR2 {}ARYTM-3K12"
    then obtain x1 where
      [ty]:"x1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
      A2: "x *'ARYTM-2K8 x1 =HIDDENR1 oneARYTM-3K13"
      using arytm_2_th_14 sorry
    have "y =HIDDENR1 (x *'ARYTM-2K8 x1)*'ARYTM-2K8 y"
      using A2 arytm_2_th_15 sorry
    also have "... = x1 *'ARYTM-2K8 (x *'ARYTM-2K8 z)"
      using A1 arytm_2_th_12 sorry
    also have "... = (x *'ARYTM-2K8 x1)*'ARYTM-2K8 z"
      using arytm_2_th_12 sorry
    also have "... = z"
      using A2 arytm_2_th_15 sorry
    finally show "y =HIDDENR1 z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_1_th_2:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x *'ARYTM-2K8 y =HIDDENR1 {}ARYTM-3K12 implies x =HIDDENR1 {}ARYTM-3K12 or y =HIDDENR1 {}ARYTM-3K12"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x *'ARYTM-2K8 y =HIDDENR1 {}ARYTM-3K12 implies (x <>HIDDENR2 {}ARYTM-3K12 implies y =HIDDENR1 {}ARYTM-3K12)"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "x *'ARYTM-2K8 y =HIDDENR1 {}ARYTM-3K12"
    assume "x <>HIDDENR2 {}ARYTM-3K12"
    then obtain x1 where
      [ty]:"x1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
      A2: "x *'ARYTM-2K8 x1 =HIDDENR1 oneARYTM-3K13"
      using arytm_2_th_14 sorry
    have "y =HIDDENR1 (x *'ARYTM-2K8 x1)*'ARYTM-2K8 y"
      using A2 arytm_2_th_15 sorry
    also have "... = (x *'ARYTM-2K8 y)*'ARYTM-2K8 x1"
      using arytm_2_th_12 sorry
    also have "... = {}ARYTM-3K12"
      using A1 arytm_2_th_4 sorry
    finally show "y =HIDDENR1 {}ARYTM-3K12"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_1_th_3:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x <='ARYTM-2R1 y & y <='ARYTM-2R1 z implies x <='ARYTM-2R1 z"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x <='ARYTM-2R1 y implies (y <='ARYTM-2R1 z implies x <='ARYTM-2R1 z)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume "x <='ARYTM-2R1 y"
    then obtain z1 where
      [ty]:"z1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
      A1: "x +ARYTM-2K7 z1 =HIDDENR1 y"
      using arytm_2_th_9 sorry
    assume "y <='ARYTM-2R1 z"
    then obtain z2 where
      [ty]:"z2 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
      A2: "y +ARYTM-2K7 z2 =HIDDENR1 z"
      using arytm_2_th_9 sorry
    have "z =HIDDENR1 x +ARYTM-2K7 (z1 +ARYTM-2K7 z2)"
      using A1 A2 arytm_2_th_6 sorry
    thus "x <='ARYTM-2R1 z"
      using arytm_2_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_1_th_4:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x <='ARYTM-2R1 y & y <='ARYTM-2R1 x implies x =HIDDENR1 y"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x <='ARYTM-2R1 y implies (y <='ARYTM-2R1 x implies x =HIDDENR1 y)"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume "x <='ARYTM-2R1 y"
    then obtain z1 where
      [ty]:"z1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
      A1: "x +ARYTM-2K7 z1 =HIDDENR1 y"
      using arytm_2_th_9 sorry
    assume "y <='ARYTM-2R1 x"
    then obtain z2 where
      [ty]:"z2 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
      A2: "y +ARYTM-2K7 z2 =HIDDENR1 x"
      using arytm_2_th_9 sorry
    have "x =HIDDENR1 x +ARYTM-2K7 (z1 +ARYTM-2K7 z2)"
      using A1 A2 arytm_2_th_6 sorry
    then have "z1 =HIDDENR1 {}ARYTM-3K12"
      using arytm_1_th_1 arytm_2_th_5 sorry
    thus "x =HIDDENR1 y"
      using A1 arytm_2_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_1_th_5:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x <='ARYTM-2R1 y & y =HIDDENR1 {}ARYTM-3K12 implies x =HIDDENR1 {}ARYTM-3K12"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x <='ARYTM-2R1 y implies  not (y =HIDDENR1 {}ARYTM-3K12 &  not x =HIDDENR1 {}ARYTM-3K12)"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume "x <='ARYTM-2R1 y"
    then have " ex z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st x +ARYTM-2K7 z =HIDDENR1 y"
      using arytm_2_th_9 sorry
    thus " not (y =HIDDENR1 {}ARYTM-3K12 &  not x =HIDDENR1 {}ARYTM-3K12)"
      using arytm_2_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_1_th_6:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x =HIDDENR1 {}ARYTM-3K12 implies x <='ARYTM-2R1 y"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x =HIDDENR1 {}ARYTM-3K12 implies x <='ARYTM-2R1 y"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume "x =HIDDENR1 {}ARYTM-3K12"
    then have "x +ARYTM-2K7 y =HIDDENR1 y"
      using arytm_2_def_8 sorry
    thus "x <='ARYTM-2R1 y"
      using arytm_2_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_1_th_7:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x <='ARYTM-2R1 y iff x +ARYTM-2K7 z <='ARYTM-2R1 y +ARYTM-2K7 z"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds (x <='ARYTM-2R1 y implies x +ARYTM-2K7 z <='ARYTM-2R1 y +ARYTM-2K7 z) & (x +ARYTM-2K7 z <='ARYTM-2R1 y +ARYTM-2K7 z implies x <='ARYTM-2R1 y)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    show "x <='ARYTM-2R1 y implies x +ARYTM-2K7 z <='ARYTM-2R1 y +ARYTM-2K7 z"
    proof(rule impI)
      assume "x <='ARYTM-2R1 y"
      then obtain z0 where
        [ty]:"z0 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A1: "x +ARYTM-2K7 z0 =HIDDENR1 y"
        using arytm_2_th_9 sorry
      have "(x +ARYTM-2K7 z)+ARYTM-2K7 z0 =HIDDENR1 y +ARYTM-2K7 z"
        using A1 arytm_2_th_6 sorry
      thus "x +ARYTM-2K7 z <='ARYTM-2R1 y +ARYTM-2K7 z"
        using arytm_2_th_19 sorry
    qed
    assume "x +ARYTM-2K7 z <='ARYTM-2R1 y +ARYTM-2K7 z"
    then obtain z0 where
      [ty]:"z0 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
      A2: "(x +ARYTM-2K7 z)+ARYTM-2K7 z0 =HIDDENR1 y +ARYTM-2K7 z"
      using arytm_2_th_9 sorry
    have "y +ARYTM-2K7 z =HIDDENR1 (x +ARYTM-2K7 z0)+ARYTM-2K7 z"
      using A2 arytm_2_th_6 sorry
    thus "x <='ARYTM-2R1 y"
      using arytm_2_th_11 arytm_2_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_1_th_8:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x <='ARYTM-2R1 y implies x *'ARYTM-2K8 z <='ARYTM-2R1 y *'ARYTM-2K8 z"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x <='ARYTM-2R1 y implies x *'ARYTM-2K8 z <='ARYTM-2R1 y *'ARYTM-2K8 z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume "x <='ARYTM-2R1 y"
    then obtain z0 where
      [ty]:"z0 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
      A1: "x +ARYTM-2K7 z0 =HIDDENR1 y"
      using arytm_2_th_9 sorry
    have "y *'ARYTM-2K8 z =HIDDENR1 x *'ARYTM-2K8 z +ARYTM-2K7 z0 *'ARYTM-2K8 z"
      using A1 arytm_2_th_13 sorry
    thus "x *'ARYTM-2K8 z <='ARYTM-2R1 y *'ARYTM-2K8 z"
      using arytm_2_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_1_lm_2:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x *'ARYTM-2K8 y <='ARYTM-2R1 x *'ARYTM-2K8 z & x <>HIDDENR2 {}ARYTM-3K12 implies y <='ARYTM-2R1 z"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x *'ARYTM-2K8 y <='ARYTM-2R1 x *'ARYTM-2K8 z implies (x <>HIDDENR2 {}ARYTM-3K12 implies y <='ARYTM-2R1 z)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    obtain u where 
      [ty]:"u be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and uDef:"u = oneARYTM-3K13"
      using arytm_2_th_20 sorry
    assume "x *'ARYTM-2K8 y <='ARYTM-2R1 x *'ARYTM-2K8 z"
    then obtain z0 where
      [ty]:"z0 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
      A1: "x *'ARYTM-2K8 y +ARYTM-2K7 z0 =HIDDENR1 x *'ARYTM-2K8 z"
      using arytm_2_th_9 sorry
    assume A2: "x <>HIDDENR2 {}ARYTM-3K12"
    then obtain x1 where
      [ty]:"x1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
      A3: "x *'ARYTM-2K8 x1 =HIDDENR1 oneARYTM-3K13"
      using arytm_2_th_14 sorry
    have "x *'ARYTM-2K8 z =HIDDENR1 x *'ARYTM-2K8 y +ARYTM-2K7 u *'ARYTM-2K8 z0"
      using A1 arytm_2_th_15 sorry
    also have "... = x *'ARYTM-2K8 y +ARYTM-2K7 x *'ARYTM-2K8 (x1 *'ARYTM-2K8 z0)"
      using A3 arytm_2_th_12 sorry
    also have "... = x *'ARYTM-2K8 (y +ARYTM-2K7 x1 *'ARYTM-2K8 z0)"
      using arytm_2_th_13 sorry
    finally have "x *'ARYTM-2K8 z =HIDDENR1 x *'ARYTM-2K8 (y +ARYTM-2K7 x1 *'ARYTM-2K8 z0)"
       sorry
    thus "y <='ARYTM-2R1 z"
      using A2 arytm_1_lm_1 arytm_2_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef arytm_1_def_1 (" _ -''ARYTM-1K1  _ " [132,132]132 ) where
  mlet "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2", "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
"func x -'ARYTM-1K1 y \<rightarrow> ElementSUBSET-1M1-of REAL+ARYTM-2K2 means
  \<lambda>it. it +ARYTM-2K7 y =HIDDENR1 x if y <='ARYTM-2R1 x otherwise \<lambda>it. it =HIDDENR1 {}ARYTM-3K12"
proof-
  (*existence*)
    show "(y <='ARYTM-2R1 x implies ( ex it be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st it +ARYTM-2K7 y =HIDDENR1 x)) & ( not y <='ARYTM-2R1 x implies ( ex it be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st it =HIDDENR1 {}ARYTM-3K12))"
    proof-
      have "(y <='ARYTM-2R1 x implies ( ex IT be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st IT +ARYTM-2K7 y =HIDDENR1 x)) &  not ( not y <='ARYTM-2R1 x & ( for VarFor1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not VarFor1 =HIDDENR1 {}ARYTM-3K12))"
      proof(rule conjMI)
        show "y <='ARYTM-2R1 x implies ( ex IT be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st IT +ARYTM-2K7 y =HIDDENR1 x)"
        proof(rule impI)
          assume "y <='ARYTM-2R1 x"
          then have " ex IT be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st y +ARYTM-2K7 IT =HIDDENR1 x"
            using arytm_2_th_9 sorry
          thus " ex IT be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st IT +ARYTM-2K7 y =HIDDENR1 x"
             sorry
        qed
        show " not ( not y <='ARYTM-2R1 x & ( for VarFor1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not VarFor1 =HIDDENR1 {}ARYTM-3K12))"
          using arytm_2_th_20 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*consistency*)
    show " for it be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  True "
      using arytm_2_th_11 sorry
  (*uniqueness*)
    show " for it1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for it2 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds (y <='ARYTM-2R1 x implies (it1 +ARYTM-2K7 y =HIDDENR1 x & it2 +ARYTM-2K7 y =HIDDENR1 x implies it1 =HIDDENR1 it2)) & ( not y <='ARYTM-2R1 x implies (it1 =HIDDENR1 {}ARYTM-3K12 & it2 =HIDDENR1 {}ARYTM-3K12 implies it1 =HIDDENR1 it2))"
      using arytm_2_th_11 sorry
qed "sorry"

mlemma arytm_1_lm_3:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x -'ARYTM-1K1 x =HIDDENR1 {}ARYTM-3K12"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x -'ARYTM-1K1 x =HIDDENR1 {}ARYTM-3K12"
  proof(rule ballI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    have "x <='ARYTM-2R1 x"
       sorry
    then have "(x -'ARYTM-1K1 x)+ARYTM-2K7 x =HIDDENR1 x"
      using arytm_1_def_1 sorry
    thus "x -'ARYTM-1K1 x =HIDDENR1 {}ARYTM-3K12"
      using arytm_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_1_th_9:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x <='ARYTM-2R1 y or x -'ARYTM-1K1 y <>HIDDENR2 {}ARYTM-3K12"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not x <='ARYTM-2R1 y implies (x -'ARYTM-1K1 y =HIDDENR1 {}ARYTM-3K12 implies  False )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: " not x <='ARYTM-2R1 y"
    assume A2: "x -'ARYTM-1K1 y =HIDDENR1 {}ARYTM-3K12"
    have "(x -'ARYTM-1K1 y)+ARYTM-2K7 y =HIDDENR1 x"
      using A1 arytm_1_def_1 sorry
    then have "x =HIDDENR1 y"
      using A2 arytm_2_def_8 sorry
    thus " False "
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_1_th_10:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x <='ARYTM-2R1 y & y -'ARYTM-1K1 x =HIDDENR1 {}ARYTM-3K12 implies x =HIDDENR1 y"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x <='ARYTM-2R1 y implies (y -'ARYTM-1K1 x =HIDDENR1 {}ARYTM-3K12 implies x =HIDDENR1 y)"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "x <='ARYTM-2R1 y"
    assume "y -'ARYTM-1K1 x =HIDDENR1 {}ARYTM-3K12"
    then have "y <='ARYTM-2R1 x"
      using arytm_1_th_9 sorry
    thus "x =HIDDENR1 y"
      using A1 arytm_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_1_th_11:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x -'ARYTM-1K1 y <='ARYTM-2R1 x"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x -'ARYTM-1K1 y <='ARYTM-2R1 x"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    show "x -'ARYTM-1K1 y <='ARYTM-2R1 x"
    proof-
      have cases: "y <='ARYTM-2R1 x or  not y <='ARYTM-2R1 x"
         sorry
      have case1: "y <='ARYTM-2R1 x implies x -'ARYTM-1K1 y <='ARYTM-2R1 x"
      proof(rule impI)
        assume "y <='ARYTM-2R1 x"
        then have "(x -'ARYTM-1K1 y)+ARYTM-2K7 y =HIDDENR1 x"
          using arytm_1_def_1 sorry
        thus "x -'ARYTM-1K1 y <='ARYTM-2R1 x"
          using arytm_2_th_19 sorry
      qed
      have case2: " not y <='ARYTM-2R1 x implies x -'ARYTM-1K1 y <='ARYTM-2R1 x"
      proof(rule impI)
        assume " not y <='ARYTM-2R1 x"
        then have "x -'ARYTM-1K1 y =HIDDENR1 {}ARYTM-3K12"
          using arytm_1_def_1 sorry
        thus "x -'ARYTM-1K1 y <='ARYTM-2R1 x"
          using arytm_1_th_6 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_1_lm_4:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x =HIDDENR1 {}ARYTM-3K12 implies y -'ARYTM-1K1 x =HIDDENR1 y"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x =HIDDENR1 {}ARYTM-3K12 implies y -'ARYTM-1K1 x =HIDDENR1 y"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "x =HIDDENR1 {}ARYTM-3K12"
    then have A2: "x <='ARYTM-2R1 y"
      using arytm_1_th_6 sorry
    have "y -'ARYTM-1K1 x =HIDDENR1 (y -'ARYTM-1K1 x)+ARYTM-2K7 x"
      using A1 arytm_2_def_8 sorry
    also have "... = y"
      using A2 arytm_1_def_1 sorry
    finally show "y -'ARYTM-1K1 x =HIDDENR1 y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_1_lm_5:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds (x +ARYTM-2K7 y)-'ARYTM-1K1 y =HIDDENR1 x"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds (x +ARYTM-2K7 y)-'ARYTM-1K1 y =HIDDENR1 x"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    have "y <='ARYTM-2R1 x +ARYTM-2K7 y"
      using arytm_2_th_19 sorry
    thus "(x +ARYTM-2K7 y)-'ARYTM-1K1 y =HIDDENR1 x"
      using arytm_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_1_lm_6:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x <='ARYTM-2R1 y implies y -'ARYTM-1K1 (y -'ARYTM-1K1 x) =HIDDENR1 x"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x <='ARYTM-2R1 y implies y -'ARYTM-1K1 (y -'ARYTM-1K1 x) =HIDDENR1 x"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "x <='ARYTM-2R1 y"
    have "y -'ARYTM-1K1 x <='ARYTM-2R1 y"
      using arytm_1_th_11 sorry
    then have "(y -'ARYTM-1K1 (y -'ARYTM-1K1 x))+ARYTM-2K7 (y -'ARYTM-1K1 x) =HIDDENR1 y"
      using arytm_1_def_1 sorry
    also have "... = (y -'ARYTM-1K1 x)+ARYTM-2K7 x"
      using A1 arytm_1_def_1 sorry
    finally have "(y -'ARYTM-1K1 (y -'ARYTM-1K1 x))+ARYTM-2K7 (y -'ARYTM-1K1 x) =HIDDENR1 (y -'ARYTM-1K1 x)+ARYTM-2K7 x"
       sorry
    thus "y -'ARYTM-1K1 (y -'ARYTM-1K1 x) =HIDDENR1 x"
      using arytm_2_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_1_lm_7:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds z -'ARYTM-1K1 y <='ARYTM-2R1 x iff z <='ARYTM-2R1 x +ARYTM-2K7 y"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not (z -'ARYTM-1K1 y <='ARYTM-2R1 x &  not z <='ARYTM-2R1 x +ARYTM-2K7 y) &  not (z <='ARYTM-2R1 x +ARYTM-2K7 y &  not z -'ARYTM-1K1 y <='ARYTM-2R1 x)"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    show " not (z -'ARYTM-1K1 y <='ARYTM-2R1 x &  not z <='ARYTM-2R1 x +ARYTM-2K7 y) &  not (z <='ARYTM-2R1 x +ARYTM-2K7 y &  not z -'ARYTM-1K1 y <='ARYTM-2R1 x)"
    proof-
      have cases: "y <='ARYTM-2R1 z or  not y <='ARYTM-2R1 z"
         sorry
      have case1: "y <='ARYTM-2R1 z implies  not (z -'ARYTM-1K1 y <='ARYTM-2R1 x &  not z <='ARYTM-2R1 x +ARYTM-2K7 y) &  not (z <='ARYTM-2R1 x +ARYTM-2K7 y &  not z -'ARYTM-1K1 y <='ARYTM-2R1 x)"
      proof(rule impI)
        assume "y <='ARYTM-2R1 z"
        then have "(z -'ARYTM-1K1 y)+ARYTM-2K7 y =HIDDENR1 z"
          using arytm_1_def_1 sorry
        thus " not (z -'ARYTM-1K1 y <='ARYTM-2R1 x &  not z <='ARYTM-2R1 x +ARYTM-2K7 y) &  not (z <='ARYTM-2R1 x +ARYTM-2K7 y &  not z -'ARYTM-1K1 y <='ARYTM-2R1 x)"
          using arytm_1_th_7 sorry
      qed
      have case2: " not y <='ARYTM-2R1 z implies  not (z -'ARYTM-1K1 y <='ARYTM-2R1 x &  not z <='ARYTM-2R1 x +ARYTM-2K7 y) &  not (z <='ARYTM-2R1 x +ARYTM-2K7 y &  not z -'ARYTM-1K1 y <='ARYTM-2R1 x)"
      proof(rule impI)
        assume A1: " not y <='ARYTM-2R1 z"
        have A2: "y <='ARYTM-2R1 x +ARYTM-2K7 y"
          using arytm_2_th_19 sorry
        have "z -'ARYTM-1K1 y =HIDDENR1 {}ARYTM-3K12"
          using A1 arytm_1_def_1 sorry
        thus " not (z -'ARYTM-1K1 y <='ARYTM-2R1 x &  not z <='ARYTM-2R1 x +ARYTM-2K7 y) &  not (z <='ARYTM-2R1 x +ARYTM-2K7 y &  not z -'ARYTM-1K1 y <='ARYTM-2R1 x)"
          using A1 A2 arytm_1_th_3 arytm_1_th_6 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_1_lm_8:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds y <='ARYTM-2R1 x implies (z +ARYTM-2K7 y <='ARYTM-2R1 x iff z <='ARYTM-2R1 x -'ARYTM-1K1 y)"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds y <='ARYTM-2R1 x implies  not (z +ARYTM-2K7 y <='ARYTM-2R1 x &  not z <='ARYTM-2R1 x -'ARYTM-1K1 y) &  not (z <='ARYTM-2R1 x -'ARYTM-1K1 y &  not z +ARYTM-2K7 y <='ARYTM-2R1 x)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume "y <='ARYTM-2R1 x"
    then have "(x -'ARYTM-1K1 y)+ARYTM-2K7 y =HIDDENR1 x"
      using arytm_1_def_1 sorry
    thus " not (z +ARYTM-2K7 y <='ARYTM-2R1 x &  not z <='ARYTM-2R1 x -'ARYTM-1K1 y) &  not (z <='ARYTM-2R1 x -'ARYTM-1K1 y &  not z +ARYTM-2K7 y <='ARYTM-2R1 x)"
      using arytm_1_th_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_1_lm_9:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds (z -'ARYTM-1K1 y)-'ARYTM-1K1 x =HIDDENR1 z -'ARYTM-1K1 (x +ARYTM-2K7 y)"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds (z -'ARYTM-1K1 y)-'ARYTM-1K1 x =HIDDENR1 z -'ARYTM-1K1 (x +ARYTM-2K7 y)"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    show "(z -'ARYTM-1K1 y)-'ARYTM-1K1 x =HIDDENR1 z -'ARYTM-1K1 (x +ARYTM-2K7 y)"
    proof-
      have cases: "((x +ARYTM-2K7 y <='ARYTM-2R1 z or x =HIDDENR1 {}ARYTM-3K12) or  not y <='ARYTM-2R1 z & x <>HIDDENR2 {}ARYTM-3K12) or  not x +ARYTM-2K7 y <='ARYTM-2R1 z & y <='ARYTM-2R1 z"
         sorry
      have case1: "x +ARYTM-2K7 y <='ARYTM-2R1 z implies (z -'ARYTM-1K1 y)-'ARYTM-1K1 x =HIDDENR1 z -'ARYTM-1K1 (x +ARYTM-2K7 y)"
      proof(rule impI)
        assume A1: "x +ARYTM-2K7 y <='ARYTM-2R1 z"
        have "y <='ARYTM-2R1 x +ARYTM-2K7 y"
          using arytm_2_th_19 sorry
        then have A2: "y <='ARYTM-2R1 z"
          using A1 arytm_1_th_3 sorry
        then have A3: "x <='ARYTM-2R1 z -'ARYTM-1K1 y"
          using A1 arytm_1_lm_8 sorry
        have "((z -'ARYTM-1K1 y)-'ARYTM-1K1 x)+ARYTM-2K7 (x +ARYTM-2K7 y) =HIDDENR1 (((z -'ARYTM-1K1 y)-'ARYTM-1K1 x)+ARYTM-2K7 x)+ARYTM-2K7 y"
          using arytm_2_th_6 sorry
        also have "... = (z -'ARYTM-1K1 y)+ARYTM-2K7 y"
          using A3 arytm_1_def_1 sorry
        also have "... = z"
          using A2 arytm_1_def_1 sorry
        finally have "((z -'ARYTM-1K1 y)-'ARYTM-1K1 x)+ARYTM-2K7 (x +ARYTM-2K7 y) =HIDDENR1 z"
           sorry
        thus "(z -'ARYTM-1K1 y)-'ARYTM-1K1 x =HIDDENR1 z -'ARYTM-1K1 (x +ARYTM-2K7 y)"
          using A1 arytm_1_def_1 sorry
      qed
      have case2: "x =HIDDENR1 {}ARYTM-3K12 implies (z -'ARYTM-1K1 y)-'ARYTM-1K1 x =HIDDENR1 z -'ARYTM-1K1 (x +ARYTM-2K7 y)"
      proof(rule impI)
        assume A4: "x =HIDDENR1 {}ARYTM-3K12"
        then have "(z -'ARYTM-1K1 y)-'ARYTM-1K1 x =HIDDENR1 z -'ARYTM-1K1 y"
          using arytm_1_lm_4 sorry
        also have "... = z -'ARYTM-1K1 (x +ARYTM-2K7 y)"
          using A4 arytm_2_def_8 sorry
        finally show "(z -'ARYTM-1K1 y)-'ARYTM-1K1 x =HIDDENR1 z -'ARYTM-1K1 (x +ARYTM-2K7 y)"
           sorry
      qed
      have case3: " not y <='ARYTM-2R1 z & x <>HIDDENR2 {}ARYTM-3K12 implies (z -'ARYTM-1K1 y)-'ARYTM-1K1 x =HIDDENR1 z -'ARYTM-1K1 (x +ARYTM-2K7 y)"
      proof(rule impMI ,rule impI)
        assume A5: " not y <='ARYTM-2R1 z"
          and A6: "x <>HIDDENR2 {}ARYTM-3K12"
        have "y <='ARYTM-2R1 y +ARYTM-2K7 x"
          using arytm_2_th_19 sorry
        then have A7: " not x +ARYTM-2K7 y <='ARYTM-2R1 z"
          using A5 arytm_1_th_3 sorry
        have "x <='ARYTM-2R1 z -'ARYTM-1K1 y implies  False "
        proof(rule impI)
          assume A8: "x <='ARYTM-2R1 z -'ARYTM-1K1 y"
          have "z -'ARYTM-1K1 y =HIDDENR1 {}ARYTM-3K12"
            using A5 arytm_1_def_1 sorry
          thus " False "
            using A6 A8 arytm_1_th_5 sorry
        qed
        then have "(z -'ARYTM-1K1 y)-'ARYTM-1K1 x =HIDDENR1 {}ARYTM-3K12"
          using arytm_1_def_1 sorry
        also have "... = z -'ARYTM-1K1 (x +ARYTM-2K7 y)"
          using A7 arytm_1_def_1 sorry
        finally show "(z -'ARYTM-1K1 y)-'ARYTM-1K1 x =HIDDENR1 z -'ARYTM-1K1 (x +ARYTM-2K7 y)"
           sorry
      qed
      have case4: " not x +ARYTM-2K7 y <='ARYTM-2R1 z & y <='ARYTM-2R1 z implies (z -'ARYTM-1K1 y)-'ARYTM-1K1 x =HIDDENR1 z -'ARYTM-1K1 (x +ARYTM-2K7 y)"
      proof(rule impMI ,rule impI)
        assume A9: " not x +ARYTM-2K7 y <='ARYTM-2R1 z"
          and A10: "y <='ARYTM-2R1 z"
        have " not x <='ARYTM-2R1 z -'ARYTM-1K1 y"
          using A9 A10 arytm_1_lm_8 sorry
        then have "(z -'ARYTM-1K1 y)-'ARYTM-1K1 x =HIDDENR1 {}ARYTM-3K12"
          using arytm_1_def_1 sorry
        also have "... = z -'ARYTM-1K1 (x +ARYTM-2K7 y)"
          using A9 arytm_1_def_1 sorry
        finally show "(z -'ARYTM-1K1 y)-'ARYTM-1K1 x =HIDDENR1 z -'ARYTM-1K1 (x +ARYTM-2K7 y)"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 case4 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_1_lm_10:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds (y -'ARYTM-1K1 z)-'ARYTM-1K1 x =HIDDENR1 (y -'ARYTM-1K1 x)-'ARYTM-1K1 z"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds (y -'ARYTM-1K1 z)-'ARYTM-1K1 x =HIDDENR1 (y -'ARYTM-1K1 x)-'ARYTM-1K1 z"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    have "(y -'ARYTM-1K1 z)-'ARYTM-1K1 x =HIDDENR1 y -'ARYTM-1K1 (x +ARYTM-2K7 z)"
      using arytm_1_lm_9 sorry
    also have "... = (y -'ARYTM-1K1 x)-'ARYTM-1K1 z"
      using arytm_1_lm_9 sorry
    finally show "(y -'ARYTM-1K1 z)-'ARYTM-1K1 x =HIDDENR1 (y -'ARYTM-1K1 x)-'ARYTM-1K1 z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_1_th_12:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds y <='ARYTM-2R1 x & y <='ARYTM-2R1 z implies x +ARYTM-2K7 (z -'ARYTM-1K1 y) =HIDDENR1 (x -'ARYTM-1K1 y)+ARYTM-2K7 z"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds y <='ARYTM-2R1 x & y <='ARYTM-2R1 z implies x +ARYTM-2K7 (z -'ARYTM-1K1 y) =HIDDENR1 (x -'ARYTM-1K1 y)+ARYTM-2K7 z"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "y <='ARYTM-2R1 x"
      and A2: "y <='ARYTM-2R1 z"
    have "(x +ARYTM-2K7 (z -'ARYTM-1K1 y))+ARYTM-2K7 y =HIDDENR1 x +ARYTM-2K7 ((z -'ARYTM-1K1 y)+ARYTM-2K7 y)"
      using arytm_2_th_6 sorry
    also have "... = x +ARYTM-2K7 z"
      using A2 arytm_1_def_1 sorry
    also have "... = ((x -'ARYTM-1K1 y)+ARYTM-2K7 y)+ARYTM-2K7 z"
      using A1 arytm_1_def_1 sorry
    also have "... = ((x -'ARYTM-1K1 y)+ARYTM-2K7 z)+ARYTM-2K7 y"
      using arytm_2_th_6 sorry
    finally have "(x +ARYTM-2K7 (z -'ARYTM-1K1 y))+ARYTM-2K7 y =HIDDENR1 ((x -'ARYTM-1K1 y)+ARYTM-2K7 z)+ARYTM-2K7 y"
       sorry
    thus "x +ARYTM-2K7 (z -'ARYTM-1K1 y) =HIDDENR1 (x -'ARYTM-1K1 y)+ARYTM-2K7 z"
      using arytm_2_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_1_th_13:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds z <='ARYTM-2R1 y implies x +ARYTM-2K7 (y -'ARYTM-1K1 z) =HIDDENR1 (x +ARYTM-2K7 y)-'ARYTM-1K1 z"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds z <='ARYTM-2R1 y implies x +ARYTM-2K7 (y -'ARYTM-1K1 z) =HIDDENR1 (x +ARYTM-2K7 y)-'ARYTM-1K1 z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "z <='ARYTM-2R1 y"
    have "y <='ARYTM-2R1 x +ARYTM-2K7 y"
      using arytm_2_th_19 sorry
    then have A2: "z <='ARYTM-2R1 x +ARYTM-2K7 y"
      using A1 arytm_1_th_3 sorry
    have "(x +ARYTM-2K7 (y -'ARYTM-1K1 z))+ARYTM-2K7 z =HIDDENR1 x +ARYTM-2K7 ((y -'ARYTM-1K1 z)+ARYTM-2K7 z)"
      using arytm_2_th_6 sorry
    also have "... = x +ARYTM-2K7 y"
      using A1 arytm_1_def_1 sorry
    also have "... = ((x +ARYTM-2K7 y)-'ARYTM-1K1 z)+ARYTM-2K7 z"
      using A2 arytm_1_def_1 sorry
    finally have "(x +ARYTM-2K7 (y -'ARYTM-1K1 z))+ARYTM-2K7 z =HIDDENR1 ((x +ARYTM-2K7 y)-'ARYTM-1K1 z)+ARYTM-2K7 z"
       sorry
    thus "x +ARYTM-2K7 (y -'ARYTM-1K1 z) =HIDDENR1 (x +ARYTM-2K7 y)-'ARYTM-1K1 z"
      using arytm_2_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_1_lm_11:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds y <='ARYTM-2R1 z implies x -'ARYTM-1K1 (z -'ARYTM-1K1 y) =HIDDENR1 (x +ARYTM-2K7 y)-'ARYTM-1K1 z"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds y <='ARYTM-2R1 z implies x -'ARYTM-1K1 (z -'ARYTM-1K1 y) =HIDDENR1 (x +ARYTM-2K7 y)-'ARYTM-1K1 z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "y <='ARYTM-2R1 z"
    show "x -'ARYTM-1K1 (z -'ARYTM-1K1 y) =HIDDENR1 (x +ARYTM-2K7 y)-'ARYTM-1K1 z"
    proof-
      have cases: "z -'ARYTM-1K1 y <='ARYTM-2R1 x or  not z -'ARYTM-1K1 y <='ARYTM-2R1 x"
         sorry
      have case1: "z -'ARYTM-1K1 y <='ARYTM-2R1 x implies x -'ARYTM-1K1 (z -'ARYTM-1K1 y) =HIDDENR1 (x +ARYTM-2K7 y)-'ARYTM-1K1 z"
      proof(rule impI)
        assume A2: "z -'ARYTM-1K1 y <='ARYTM-2R1 x"
        then have A3: "z <='ARYTM-2R1 x +ARYTM-2K7 y"
          using arytm_1_lm_7 sorry
        have "(x -'ARYTM-1K1 (z -'ARYTM-1K1 y))+ARYTM-2K7 (z -'ARYTM-1K1 y) =HIDDENR1 x"
          using A2 arytm_1_def_1 sorry
        also have "... = (x +ARYTM-2K7 z)-'ARYTM-1K1 z"
          using arytm_1_lm_5 sorry
        also have "... = (x +ARYTM-2K7 (y +ARYTM-2K7 (z -'ARYTM-1K1 y)))-'ARYTM-1K1 z"
          using A1 arytm_1_def_1 sorry
        also have "... = ((x +ARYTM-2K7 y)+ARYTM-2K7 (z -'ARYTM-1K1 y))-'ARYTM-1K1 z"
          using arytm_2_th_6 sorry
        also have "... = ((x +ARYTM-2K7 y)-'ARYTM-1K1 z)+ARYTM-2K7 (z -'ARYTM-1K1 y)"
          using A3 arytm_1_th_13 sorry
        finally have "(x -'ARYTM-1K1 (z -'ARYTM-1K1 y))+ARYTM-2K7 (z -'ARYTM-1K1 y) =HIDDENR1 ((x +ARYTM-2K7 y)-'ARYTM-1K1 z)+ARYTM-2K7 (z -'ARYTM-1K1 y)"
           sorry
        thus "x -'ARYTM-1K1 (z -'ARYTM-1K1 y) =HIDDENR1 (x +ARYTM-2K7 y)-'ARYTM-1K1 z"
          using arytm_2_th_11 sorry
      qed
      have case2: " not z -'ARYTM-1K1 y <='ARYTM-2R1 x implies x -'ARYTM-1K1 (z -'ARYTM-1K1 y) =HIDDENR1 (x +ARYTM-2K7 y)-'ARYTM-1K1 z"
      proof(rule impI)
        assume A4: " not z -'ARYTM-1K1 y <='ARYTM-2R1 x"
        then have A5: " not z <='ARYTM-2R1 x +ARYTM-2K7 y"
          using arytm_1_lm_7 sorry
        have "x -'ARYTM-1K1 (z -'ARYTM-1K1 y) =HIDDENR1 {}ARYTM-3K12"
          using A4 arytm_1_def_1 sorry
        also have "... = (x +ARYTM-2K7 y)-'ARYTM-1K1 z"
          using A5 arytm_1_def_1 sorry
        finally show "x -'ARYTM-1K1 (z -'ARYTM-1K1 y) =HIDDENR1 (x +ARYTM-2K7 y)-'ARYTM-1K1 z"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_1_lm_12:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds z <='ARYTM-2R1 x & y <='ARYTM-2R1 z implies x -'ARYTM-1K1 (z -'ARYTM-1K1 y) =HIDDENR1 (x -'ARYTM-1K1 z)+ARYTM-2K7 y"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds z <='ARYTM-2R1 x & y <='ARYTM-2R1 z implies x -'ARYTM-1K1 (z -'ARYTM-1K1 y) =HIDDENR1 (x -'ARYTM-1K1 z)+ARYTM-2K7 y"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "z <='ARYTM-2R1 x"
      and A2: "y <='ARYTM-2R1 z"
    have "x -'ARYTM-1K1 (z -'ARYTM-1K1 y) =HIDDENR1 (x +ARYTM-2K7 y)-'ARYTM-1K1 z"
      using A2 arytm_1_lm_11 sorry
    also have "... = (x -'ARYTM-1K1 z)+ARYTM-2K7 y"
      using A1 arytm_1_th_13 sorry
    finally show "x -'ARYTM-1K1 (z -'ARYTM-1K1 y) =HIDDENR1 (x -'ARYTM-1K1 z)+ARYTM-2K7 y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_1_lm_13:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x <='ARYTM-2R1 z & y <='ARYTM-2R1 z implies x -'ARYTM-1K1 (z -'ARYTM-1K1 y) =HIDDENR1 y -'ARYTM-1K1 (z -'ARYTM-1K1 x)"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x <='ARYTM-2R1 z & y <='ARYTM-2R1 z implies x -'ARYTM-1K1 (z -'ARYTM-1K1 y) =HIDDENR1 y -'ARYTM-1K1 (z -'ARYTM-1K1 x)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "x <='ARYTM-2R1 z"
      and A2: "y <='ARYTM-2R1 z"
    have "x -'ARYTM-1K1 (z -'ARYTM-1K1 y) =HIDDENR1 (x +ARYTM-2K7 y)-'ARYTM-1K1 z"
      using A2 arytm_1_lm_11 sorry
    also have "... = y -'ARYTM-1K1 (z -'ARYTM-1K1 x)"
      using A1 arytm_1_lm_11 sorry
    finally show "x -'ARYTM-1K1 (z -'ARYTM-1K1 y) =HIDDENR1 y -'ARYTM-1K1 (z -'ARYTM-1K1 x)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_1_th_14:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds z <='ARYTM-2R1 x & y <='ARYTM-2R1 z implies (x -'ARYTM-1K1 z)+ARYTM-2K7 y =HIDDENR1 x -'ARYTM-1K1 (z -'ARYTM-1K1 y)"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds z <='ARYTM-2R1 x & y <='ARYTM-2R1 z implies x -'ARYTM-1K1 (z -'ARYTM-1K1 y) =HIDDENR1 (x -'ARYTM-1K1 z)+ARYTM-2K7 y"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "z <='ARYTM-2R1 x"
      and A2: "y <='ARYTM-2R1 z"
    have "x -'ARYTM-1K1 (z -'ARYTM-1K1 y) =HIDDENR1 (x +ARYTM-2K7 y)-'ARYTM-1K1 z"
      using A2 arytm_1_lm_11 sorry
    also have "... = (x -'ARYTM-1K1 z)+ARYTM-2K7 y"
      using A1 arytm_1_th_13 sorry
    finally show "x -'ARYTM-1K1 (z -'ARYTM-1K1 y) =HIDDENR1 (x -'ARYTM-1K1 z)+ARYTM-2K7 y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_1_th_15:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds y <='ARYTM-2R1 x & y <='ARYTM-2R1 z implies (z -'ARYTM-1K1 y)+ARYTM-2K7 x =HIDDENR1 (x -'ARYTM-1K1 y)+ARYTM-2K7 z"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds y <='ARYTM-2R1 x & y <='ARYTM-2R1 z implies (z -'ARYTM-1K1 y)+ARYTM-2K7 x =HIDDENR1 (x -'ARYTM-1K1 y)+ARYTM-2K7 z"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "y <='ARYTM-2R1 x"
      and A2: "y <='ARYTM-2R1 z"
    have "((z -'ARYTM-1K1 y)+ARYTM-2K7 x)+ARYTM-2K7 y =HIDDENR1 ((z -'ARYTM-1K1 y)+ARYTM-2K7 y)+ARYTM-2K7 x"
      using arytm_2_th_6 sorry
    also have "... = z +ARYTM-2K7 x"
      using A2 arytm_1_def_1 sorry
    also have "... = ((x -'ARYTM-1K1 y)+ARYTM-2K7 y)+ARYTM-2K7 z"
      using A1 arytm_1_def_1 sorry
    also have "... = ((x -'ARYTM-1K1 y)+ARYTM-2K7 z)+ARYTM-2K7 y"
      using arytm_2_th_6 sorry
    finally have "((z -'ARYTM-1K1 y)+ARYTM-2K7 x)+ARYTM-2K7 y =HIDDENR1 ((x -'ARYTM-1K1 y)+ARYTM-2K7 z)+ARYTM-2K7 y"
       sorry
    thus "(z -'ARYTM-1K1 y)+ARYTM-2K7 x =HIDDENR1 (x -'ARYTM-1K1 y)+ARYTM-2K7 z"
      using arytm_2_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_1_th_16:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x <='ARYTM-2R1 y implies z -'ARYTM-1K1 y <='ARYTM-2R1 z -'ARYTM-1K1 x"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x <='ARYTM-2R1 y implies z -'ARYTM-1K1 y <='ARYTM-2R1 z -'ARYTM-1K1 x"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "x <='ARYTM-2R1 y"
    show "z -'ARYTM-1K1 y <='ARYTM-2R1 z -'ARYTM-1K1 x"
    proof-
      have cases: "y <='ARYTM-2R1 z or  not y <='ARYTM-2R1 z"
         sorry
      have case1: "y <='ARYTM-2R1 z implies z -'ARYTM-1K1 y <='ARYTM-2R1 z -'ARYTM-1K1 x"
      proof(rule impI)
        assume A2: "y <='ARYTM-2R1 z"
        have "(z -'ARYTM-1K1 y)+ARYTM-2K7 x <='ARYTM-2R1 (z -'ARYTM-1K1 y)+ARYTM-2K7 y"
          using A1 arytm_1_th_7 sorry
        then have A3: "(z -'ARYTM-1K1 y)+ARYTM-2K7 x <='ARYTM-2R1 z"
          using A2 arytm_1_def_1 sorry
        have "x <='ARYTM-2R1 z"
          using A1 A2 arytm_1_th_3 sorry
        then have "(z -'ARYTM-1K1 y)+ARYTM-2K7 x <='ARYTM-2R1 (z -'ARYTM-1K1 x)+ARYTM-2K7 x"
          using A3 arytm_1_def_1 sorry
        thus "z -'ARYTM-1K1 y <='ARYTM-2R1 z -'ARYTM-1K1 x"
          using arytm_1_th_7 sorry
      qed
      have case2: " not y <='ARYTM-2R1 z implies z -'ARYTM-1K1 y <='ARYTM-2R1 z -'ARYTM-1K1 x"
      proof(rule impI)
        assume " not y <='ARYTM-2R1 z"
        then have "z -'ARYTM-1K1 y =HIDDENR1 {}ARYTM-3K12"
          using arytm_1_def_1 sorry
        thus "z -'ARYTM-1K1 y <='ARYTM-2R1 z -'ARYTM-1K1 x"
          using arytm_1_th_6 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_1_th_17:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x <='ARYTM-2R1 y implies x -'ARYTM-1K1 z <='ARYTM-2R1 y -'ARYTM-1K1 z"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x <='ARYTM-2R1 y implies x -'ARYTM-1K1 z <='ARYTM-2R1 y -'ARYTM-1K1 z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "x <='ARYTM-2R1 y"
    show "x -'ARYTM-1K1 z <='ARYTM-2R1 y -'ARYTM-1K1 z"
    proof-
      have cases: "z <='ARYTM-2R1 x or  not z <='ARYTM-2R1 x"
         sorry
      have case1: "z <='ARYTM-2R1 x implies x -'ARYTM-1K1 z <='ARYTM-2R1 y -'ARYTM-1K1 z"
      proof(rule impI)
        assume A2: "z <='ARYTM-2R1 x"
        then have "z <='ARYTM-2R1 y"
          using A1 arytm_1_th_3 sorry
        then have A3: "(y -'ARYTM-1K1 z)+ARYTM-2K7 z =HIDDENR1 y"
          using arytm_1_def_1 sorry
        have "(x -'ARYTM-1K1 z)+ARYTM-2K7 z =HIDDENR1 x"
          using A2 arytm_1_def_1 sorry
        thus "x -'ARYTM-1K1 z <='ARYTM-2R1 y -'ARYTM-1K1 z"
          using A1 A3 arytm_1_th_7 sorry
      qed
      have case2: " not z <='ARYTM-2R1 x implies x -'ARYTM-1K1 z <='ARYTM-2R1 y -'ARYTM-1K1 z"
      proof(rule impI)
        assume " not z <='ARYTM-2R1 x"
        then have "x -'ARYTM-1K1 z =HIDDENR1 {}ARYTM-3K12"
          using arytm_1_def_1 sorry
        thus "x -'ARYTM-1K1 z <='ARYTM-2R1 y -'ARYTM-1K1 z"
          using arytm_1_th_6 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_1_lm_14:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x *'ARYTM-2K8 (y -'ARYTM-1K1 z) =HIDDENR1 x *'ARYTM-2K8 y -'ARYTM-1K1 x *'ARYTM-2K8 z"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x *'ARYTM-2K8 (y -'ARYTM-1K1 z) =HIDDENR1 x *'ARYTM-2K8 y -'ARYTM-1K1 x *'ARYTM-2K8 z"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    show "x *'ARYTM-2K8 (y -'ARYTM-1K1 z) =HIDDENR1 x *'ARYTM-2K8 y -'ARYTM-1K1 x *'ARYTM-2K8 z"
    proof-
      have cases: "(z <='ARYTM-2R1 y or x =HIDDENR1 {}ARYTM-3K12) or  not z <='ARYTM-2R1 y & x <>HIDDENR2 {}ARYTM-3K12"
         sorry
      have case1: "z <='ARYTM-2R1 y implies x *'ARYTM-2K8 (y -'ARYTM-1K1 z) =HIDDENR1 x *'ARYTM-2K8 y -'ARYTM-1K1 x *'ARYTM-2K8 z"
      proof(rule impI)
        assume A1: "z <='ARYTM-2R1 y"
        then have A2: "x *'ARYTM-2K8 z <='ARYTM-2R1 x *'ARYTM-2K8 y"
          using arytm_1_th_8 sorry
        have "x *'ARYTM-2K8 (y -'ARYTM-1K1 z) +ARYTM-2K7 x *'ARYTM-2K8 z =HIDDENR1 x *'ARYTM-2K8 ((y -'ARYTM-1K1 z)+ARYTM-2K7 z)"
          using arytm_2_th_13 sorry
        also have "... = x *'ARYTM-2K8 y"
          using A1 arytm_1_def_1 sorry
        also have "... = (x *'ARYTM-2K8 y -'ARYTM-1K1 x *'ARYTM-2K8 z)+ARYTM-2K7 x *'ARYTM-2K8 z"
          using A2 arytm_1_def_1 sorry
        finally have "x *'ARYTM-2K8 (y -'ARYTM-1K1 z) +ARYTM-2K7 x *'ARYTM-2K8 z =HIDDENR1 (x *'ARYTM-2K8 y -'ARYTM-1K1 x *'ARYTM-2K8 z)+ARYTM-2K7 x *'ARYTM-2K8 z"
           sorry
        thus "x *'ARYTM-2K8 (y -'ARYTM-1K1 z) =HIDDENR1 x *'ARYTM-2K8 y -'ARYTM-1K1 x *'ARYTM-2K8 z"
          using arytm_2_th_11 sorry
      qed
      have case2: "x =HIDDENR1 {}ARYTM-3K12 implies x *'ARYTM-2K8 (y -'ARYTM-1K1 z) =HIDDENR1 x *'ARYTM-2K8 y -'ARYTM-1K1 x *'ARYTM-2K8 z"
      proof(rule impI)
        assume A3: "x =HIDDENR1 {}ARYTM-3K12"
        then have "x *'ARYTM-2K8 y =HIDDENR1 {}ARYTM-3K12"
          using arytm_2_th_4 sorry
        then have "x *'ARYTM-2K8 (y -'ARYTM-1K1 z) =HIDDENR1 x *'ARYTM-2K8 y"
          using A3 arytm_2_th_4 sorry
        also have "... = x *'ARYTM-2K8 y -'ARYTM-1K1 x *'ARYTM-2K8 z"
          using A3 arytm_1_lm_4 arytm_2_th_4 sorry
        finally show "x *'ARYTM-2K8 (y -'ARYTM-1K1 z) =HIDDENR1 x *'ARYTM-2K8 y -'ARYTM-1K1 x *'ARYTM-2K8 z"
           sorry
      qed
      have case3: " not z <='ARYTM-2R1 y & x <>HIDDENR2 {}ARYTM-3K12 implies x *'ARYTM-2K8 (y -'ARYTM-1K1 z) =HIDDENR1 x *'ARYTM-2K8 y -'ARYTM-1K1 x *'ARYTM-2K8 z"
      proof(rule impI)
        assume A4: " not z <='ARYTM-2R1 y & x <>HIDDENR2 {}ARYTM-3K12"
        then have A5: " not x *'ARYTM-2K8 z <='ARYTM-2R1 x *'ARYTM-2K8 y"
          using arytm_1_lm_2 sorry
        have "y -'ARYTM-1K1 z =HIDDENR1 {}ARYTM-3K12"
          using A4 arytm_1_def_1 sorry
        then have "x *'ARYTM-2K8 (y -'ARYTM-1K1 z) =HIDDENR1 {}ARYTM-3K12"
          using arytm_2_th_4 sorry
        also have "... = x *'ARYTM-2K8 y -'ARYTM-1K1 x *'ARYTM-2K8 z"
          using A5 arytm_1_def_1 sorry
        finally show "x *'ARYTM-2K8 (y -'ARYTM-1K1 z) =HIDDENR1 x *'ARYTM-2K8 y -'ARYTM-1K1 x *'ARYTM-2K8 z"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef arytm_1_def_2 (" _ -ARYTM-1K2  _ " [132,132]132 ) where
  mlet "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2", "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
"func x -ARYTM-1K2 y \<rightarrow> setHIDDENM2 equals
  x -'ARYTM-1K1 y if y <='ARYTM-2R1 x otherwise [TARSKIK4 {}ARYTM-3K12,y -'ARYTM-1K1 x ]"
proof-
  (*coherence*)
    show "(y <='ARYTM-2R1 x implies x -'ARYTM-1K1 y be setHIDDENM2) & ( not y <='ARYTM-2R1 x implies [TARSKIK4 {}ARYTM-3K12,y -'ARYTM-1K1 x ] be setHIDDENM2)"
      using tarski_th_1 sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
      using tarski_th_1 sorry
qed "sorry"

mtheorem arytm_1_th_18:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x -ARYTM-1K2 x =HIDDENR1 {}ARYTM-3K12"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x -ARYTM-1K2 x =HIDDENR1 {}ARYTM-3K12"
  proof(rule ballI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    have "x <='ARYTM-2R1 x"
       sorry
    then have "x -ARYTM-1K2 x =HIDDENR1 x -'ARYTM-1K1 x"
      using arytm_1_def_2 sorry
    thus "x -ARYTM-1K2 x =HIDDENR1 {}ARYTM-3K12"
      using arytm_1_lm_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_1_th_19:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x =HIDDENR1 {}ARYTM-3K12 & y <>HIDDENR2 {}ARYTM-3K12 implies x -ARYTM-1K2 y =HIDDENR1 [TARSKIK4 {}ARYTM-3K12,y ]"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x =HIDDENR1 {}ARYTM-3K12 & y <>HIDDENR2 {}ARYTM-3K12 implies x -ARYTM-1K2 y =HIDDENR1 [TARSKIK4 {}ARYTM-3K12,y ]"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "x =HIDDENR1 {}ARYTM-3K12"
      and A2: "y <>HIDDENR2 {}ARYTM-3K12"
    have "x <='ARYTM-2R1 y"
      using A1 arytm_1_th_6 sorry
    then have " not y <='ARYTM-2R1 x"
      using A1 A2 arytm_1_th_4 sorry
    then have "x -ARYTM-1K2 y =HIDDENR1 [TARSKIK4 {}ARYTM-3K12,y -'ARYTM-1K1 x ]"
      using arytm_1_def_2 sorry
    also have "... = [TARSKIK4 {}ARYTM-3K12,y ]"
      using A1 arytm_1_lm_4 sorry
    finally show "x -ARYTM-1K2 y =HIDDENR1 [TARSKIK4 {}ARYTM-3K12,y ]"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_1_th_20:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds z <='ARYTM-2R1 y implies x +ARYTM-2K7 (y -'ARYTM-1K1 z) =HIDDENR1 (x +ARYTM-2K7 y)-ARYTM-1K2 z"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds z <='ARYTM-2R1 y implies x +ARYTM-2K7 (y -'ARYTM-1K1 z) =HIDDENR1 (x +ARYTM-2K7 y)-ARYTM-1K2 z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "z <='ARYTM-2R1 y"
    have "y <='ARYTM-2R1 x +ARYTM-2K7 y"
      using arytm_2_th_19 sorry
    then have "z <='ARYTM-2R1 x +ARYTM-2K7 y"
      using A1 arytm_1_th_3 sorry
    then have "(x +ARYTM-2K7 y)-ARYTM-1K2 z =HIDDENR1 (x +ARYTM-2K7 y)-'ARYTM-1K1 z"
      using arytm_1_def_2 sorry
    thus "x +ARYTM-2K7 (y -'ARYTM-1K1 z) =HIDDENR1 (x +ARYTM-2K7 y)-ARYTM-1K2 z"
      using A1 arytm_1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_1_th_21:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not z <='ARYTM-2R1 y implies x -ARYTM-1K2 (z -'ARYTM-1K1 y) =HIDDENR1 (x +ARYTM-2K7 y)-ARYTM-1K2 z"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not z <='ARYTM-2R1 y implies x -ARYTM-1K2 (z -'ARYTM-1K1 y) =HIDDENR1 (x +ARYTM-2K7 y)-ARYTM-1K2 z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: " not z <='ARYTM-2R1 y"
    show "x -ARYTM-1K2 (z -'ARYTM-1K1 y) =HIDDENR1 (x +ARYTM-2K7 y)-ARYTM-1K2 z"
    proof-
      have cases: "z -'ARYTM-1K1 y <='ARYTM-2R1 x or  not z -'ARYTM-1K1 y <='ARYTM-2R1 x"
         sorry
      have case1: "z -'ARYTM-1K1 y <='ARYTM-2R1 x implies x -ARYTM-1K2 (z -'ARYTM-1K1 y) =HIDDENR1 (x +ARYTM-2K7 y)-ARYTM-1K2 z"
      proof(rule impI)
        assume A2: "z -'ARYTM-1K1 y <='ARYTM-2R1 x"
        then have "z <='ARYTM-2R1 x +ARYTM-2K7 y"
          using arytm_1_lm_7 sorry
        then have A3: "(x +ARYTM-2K7 y)-ARYTM-1K2 z =HIDDENR1 (x +ARYTM-2K7 y)-'ARYTM-1K1 z"
          using arytm_1_def_2 sorry
        have "x -ARYTM-1K2 (z -'ARYTM-1K1 y) =HIDDENR1 x -'ARYTM-1K1 (z -'ARYTM-1K1 y)"
          using A2 arytm_1_def_2 sorry
        thus "x -ARYTM-1K2 (z -'ARYTM-1K1 y) =HIDDENR1 (x +ARYTM-2K7 y)-ARYTM-1K2 z"
          using A1 A3 arytm_1_lm_11 sorry
      qed
      have case2: " not z -'ARYTM-1K1 y <='ARYTM-2R1 x implies x -ARYTM-1K2 (z -'ARYTM-1K1 y) =HIDDENR1 (x +ARYTM-2K7 y)-ARYTM-1K2 z"
      proof(rule impI)
        assume A4: " not z -'ARYTM-1K1 y <='ARYTM-2R1 x"
        then have A5: " not z <='ARYTM-2R1 x +ARYTM-2K7 y"
          using arytm_1_lm_7 sorry
        have "(z -'ARYTM-1K1 y)-'ARYTM-1K1 x =HIDDENR1 z -'ARYTM-1K1 (x +ARYTM-2K7 y)"
          using arytm_1_lm_9 sorry
        then have "x -ARYTM-1K2 (z -'ARYTM-1K1 y) =HIDDENR1 [TARSKIK4 {}ARYTM-3K12,z -'ARYTM-1K1 (x +ARYTM-2K7 y) ]"
          using A4 arytm_1_def_2 sorry
        also have "... = (x +ARYTM-2K7 y)-ARYTM-1K2 z"
          using A5 arytm_1_def_2 sorry
        finally show "x -ARYTM-1K2 (z -'ARYTM-1K1 y) =HIDDENR1 (x +ARYTM-2K7 y)-ARYTM-1K2 z"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_1_th_22:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds y <='ARYTM-2R1 x &  not y <='ARYTM-2R1 z implies x -ARYTM-1K2 (y -'ARYTM-1K1 z) =HIDDENR1 (x -'ARYTM-1K1 y)+ARYTM-2K7 z"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds y <='ARYTM-2R1 x &  not y <='ARYTM-2R1 z implies x -ARYTM-1K2 (y -'ARYTM-1K1 z) =HIDDENR1 (x -'ARYTM-1K1 y)+ARYTM-2K7 z"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "y <='ARYTM-2R1 x"
      and A2: " not y <='ARYTM-2R1 z"
    have "y -'ARYTM-1K1 z <='ARYTM-2R1 y"
      using arytm_1_th_11 sorry
    then have "y -'ARYTM-1K1 z <='ARYTM-2R1 x"
      using A1 arytm_1_th_3 sorry
    then have "x -ARYTM-1K2 (y -'ARYTM-1K1 z) =HIDDENR1 x -'ARYTM-1K1 (y -'ARYTM-1K1 z)"
      using arytm_1_def_2 sorry
    thus "x -ARYTM-1K2 (y -'ARYTM-1K1 z) =HIDDENR1 (x -'ARYTM-1K1 y)+ARYTM-2K7 z"
      using A1 A2 arytm_1_lm_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_1_th_23:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not y <='ARYTM-2R1 x &  not y <='ARYTM-2R1 z implies x -ARYTM-1K2 (y -'ARYTM-1K1 z) =HIDDENR1 z -ARYTM-1K2 (y -'ARYTM-1K1 x)"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not y <='ARYTM-2R1 x &  not y <='ARYTM-2R1 z implies x -ARYTM-1K2 (y -'ARYTM-1K1 z) =HIDDENR1 z -ARYTM-1K2 (y -'ARYTM-1K1 x)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: " not y <='ARYTM-2R1 x &  not y <='ARYTM-2R1 z"
    show "x -ARYTM-1K2 (y -'ARYTM-1K1 z) =HIDDENR1 z -ARYTM-1K2 (y -'ARYTM-1K1 x)"
    proof-
      have cases: "y <='ARYTM-2R1 x +ARYTM-2K7 z or  not y <='ARYTM-2R1 x +ARYTM-2K7 z"
         sorry
      have case1: "y <='ARYTM-2R1 x +ARYTM-2K7 z implies x -ARYTM-1K2 (y -'ARYTM-1K1 z) =HIDDENR1 z -ARYTM-1K2 (y -'ARYTM-1K1 x)"
      proof(rule impI)
        assume A2: "y <='ARYTM-2R1 x +ARYTM-2K7 z"
        then have "y -'ARYTM-1K1 x <='ARYTM-2R1 z"
          using arytm_1_lm_7 sorry
        then have A3: "z -ARYTM-1K2 (y -'ARYTM-1K1 x) =HIDDENR1 z -'ARYTM-1K1 (y -'ARYTM-1K1 x)"
          using arytm_1_def_2 sorry
        have "y -'ARYTM-1K1 z <='ARYTM-2R1 x"
          using A2 arytm_1_lm_7 sorry
        then have "x -ARYTM-1K2 (y -'ARYTM-1K1 z) =HIDDENR1 x -'ARYTM-1K1 (y -'ARYTM-1K1 z)"
          using arytm_1_def_2 sorry
        thus "x -ARYTM-1K2 (y -'ARYTM-1K1 z) =HIDDENR1 z -ARYTM-1K2 (y -'ARYTM-1K1 x)"
          using A1 A3 arytm_1_lm_13 sorry
      qed
      have case2: " not y <='ARYTM-2R1 x +ARYTM-2K7 z implies x -ARYTM-1K2 (y -'ARYTM-1K1 z) =HIDDENR1 z -ARYTM-1K2 (y -'ARYTM-1K1 x)"
      proof(rule impI)
        assume A4: " not y <='ARYTM-2R1 x +ARYTM-2K7 z"
        then have A5: " not y -'ARYTM-1K1 x <='ARYTM-2R1 z"
          using arytm_1_lm_7 sorry
        have A6: "(y -'ARYTM-1K1 z)-'ARYTM-1K1 x =HIDDENR1 (y -'ARYTM-1K1 x)-'ARYTM-1K1 z"
          using arytm_1_lm_10 sorry
        have " not y -'ARYTM-1K1 z <='ARYTM-2R1 x"
          using A4 arytm_1_lm_7 sorry
        then have "x -ARYTM-1K2 (y -'ARYTM-1K1 z) =HIDDENR1 [TARSKIK4 {}ARYTM-3K12,(y -'ARYTM-1K1 x)-'ARYTM-1K1 z ]"
          using A6 arytm_1_def_2 sorry
        also have "... = z -ARYTM-1K2 (y -'ARYTM-1K1 x)"
          using A5 arytm_1_def_2 sorry
        finally show "x -ARYTM-1K2 (y -'ARYTM-1K1 z) =HIDDENR1 z -ARYTM-1K2 (y -'ARYTM-1K1 x)"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_1_th_24:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds y <='ARYTM-2R1 x implies x -ARYTM-1K2 (y +ARYTM-2K7 z) =HIDDENR1 (x -'ARYTM-1K1 y)-ARYTM-1K2 z"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds y <='ARYTM-2R1 x implies x -ARYTM-1K2 (y +ARYTM-2K7 z) =HIDDENR1 (x -'ARYTM-1K1 y)-ARYTM-1K2 z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "y <='ARYTM-2R1 x"
    show "x -ARYTM-1K2 (y +ARYTM-2K7 z) =HIDDENR1 (x -'ARYTM-1K1 y)-ARYTM-1K2 z"
    proof-
      have cases: "(y +ARYTM-2K7 z <='ARYTM-2R1 x or  not y +ARYTM-2K7 z <='ARYTM-2R1 x & x <='ARYTM-2R1 y) or  not y +ARYTM-2K7 z <='ARYTM-2R1 x &  not x <='ARYTM-2R1 y"
         sorry
      have case1: "y +ARYTM-2K7 z <='ARYTM-2R1 x implies x -ARYTM-1K2 (y +ARYTM-2K7 z) =HIDDENR1 (x -'ARYTM-1K1 y)-ARYTM-1K2 z"
      proof(rule impI)
        assume A2: "y +ARYTM-2K7 z <='ARYTM-2R1 x"
        then have "z <='ARYTM-2R1 x -'ARYTM-1K1 y"
          using A1 arytm_1_lm_8 sorry
        then have A3: "(x -'ARYTM-1K1 y)-ARYTM-1K2 z =HIDDENR1 (x -'ARYTM-1K1 y)-'ARYTM-1K1 z"
          using arytm_1_def_2 sorry
        have "x -ARYTM-1K2 (y +ARYTM-2K7 z) =HIDDENR1 x -'ARYTM-1K1 (y +ARYTM-2K7 z)"
          using A2 arytm_1_def_2 sorry
        thus "x -ARYTM-1K2 (y +ARYTM-2K7 z) =HIDDENR1 (x -'ARYTM-1K1 y)-ARYTM-1K2 z"
          using A3 arytm_1_lm_9 sorry
      qed
      have case2: " not y +ARYTM-2K7 z <='ARYTM-2R1 x & x <='ARYTM-2R1 y implies x -ARYTM-1K2 (y +ARYTM-2K7 z) =HIDDENR1 (x -'ARYTM-1K1 y)-ARYTM-1K2 z"
      proof(rule impMI ,rule impI)
        assume A4: " not y +ARYTM-2K7 z <='ARYTM-2R1 x"
          and A5: "x <='ARYTM-2R1 y"
        have A6: " not z <='ARYTM-2R1 x -'ARYTM-1K1 y"
          using A1 A4 arytm_1_lm_8 sorry
        have A7: "(x +ARYTM-2K7 z)-'ARYTM-1K1 x =HIDDENR1 z"
          using arytm_1_lm_5 sorry
        also have "... = z -'ARYTM-1K1 (x -'ARYTM-1K1 x)"
          using arytm_1_lm_3 arytm_1_lm_4 sorry
        finally have "(x +ARYTM-2K7 z)-'ARYTM-1K1 x =HIDDENR1 z -'ARYTM-1K1 (x -'ARYTM-1K1 x)"
           sorry
        have "x =HIDDENR1 y"
          using A1 A5 arytm_1_th_4 sorry
        then have "x -ARYTM-1K2 (y +ARYTM-2K7 z) =HIDDENR1 [TARSKIK4 {}ARYTM-3K12,z -'ARYTM-1K1 (x -'ARYTM-1K1 y) ]"
          using A4 A7 arytm_1_def_2 sorry
        also have "... = (x -'ARYTM-1K1 y)-ARYTM-1K2 z"
          using A6 arytm_1_def_2 sorry
        finally show "x -ARYTM-1K2 (y +ARYTM-2K7 z) =HIDDENR1 (x -'ARYTM-1K1 y)-ARYTM-1K2 z"
           sorry
      qed
      have case3: " not y +ARYTM-2K7 z <='ARYTM-2R1 x &  not x <='ARYTM-2R1 y implies x -ARYTM-1K2 (y +ARYTM-2K7 z) =HIDDENR1 (x -'ARYTM-1K1 y)-ARYTM-1K2 z"
      proof(rule impMI ,rule impI)
        assume A8: " not y +ARYTM-2K7 z <='ARYTM-2R1 x"
          and A9: " not x <='ARYTM-2R1 y"
        have A10: " not z <='ARYTM-2R1 x -'ARYTM-1K1 y"
          using A1 A8 arytm_1_lm_8 sorry
        have "(y +ARYTM-2K7 z)-'ARYTM-1K1 x =HIDDENR1 z -'ARYTM-1K1 (x -'ARYTM-1K1 y)"
          using A9 arytm_1_lm_11 sorry
        then have "x -ARYTM-1K2 (y +ARYTM-2K7 z) =HIDDENR1 [TARSKIK4 {}ARYTM-3K12,z -'ARYTM-1K1 (x -'ARYTM-1K1 y) ]"
          using A8 arytm_1_def_2 sorry
        also have "... = (x -'ARYTM-1K1 y)-ARYTM-1K2 z"
          using A10 arytm_1_def_2 sorry
        finally show "x -ARYTM-1K2 (y +ARYTM-2K7 z) =HIDDENR1 (x -'ARYTM-1K1 y)-ARYTM-1K2 z"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_1_th_25:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x <='ARYTM-2R1 y & z <='ARYTM-2R1 y implies (y -'ARYTM-1K1 z)-ARYTM-1K2 x =HIDDENR1 (y -'ARYTM-1K1 x)-ARYTM-1K2 z"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x <='ARYTM-2R1 y & z <='ARYTM-2R1 y implies (y -'ARYTM-1K1 z)-ARYTM-1K2 x =HIDDENR1 (y -'ARYTM-1K1 x)-ARYTM-1K2 z"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "x <='ARYTM-2R1 y"
      and A2: "z <='ARYTM-2R1 y"
    show "(y -'ARYTM-1K1 z)-ARYTM-1K2 x =HIDDENR1 (y -'ARYTM-1K1 x)-ARYTM-1K2 z"
    proof-
      have cases: "((x +ARYTM-2K7 z <='ARYTM-2R1 y or  not x +ARYTM-2K7 z <='ARYTM-2R1 y & y <='ARYTM-2R1 x) or  not x +ARYTM-2K7 z <='ARYTM-2R1 y & y <='ARYTM-2R1 z) or  not x +ARYTM-2K7 z <='ARYTM-2R1 y & ( not y <='ARYTM-2R1 x &  not y <='ARYTM-2R1 z)"
         sorry
      have case1: "x +ARYTM-2K7 z <='ARYTM-2R1 y implies (y -'ARYTM-1K1 z)-ARYTM-1K2 x =HIDDENR1 (y -'ARYTM-1K1 x)-ARYTM-1K2 z"
      proof(rule impI)
        assume A3: "x +ARYTM-2K7 z <='ARYTM-2R1 y"
        then have "z <='ARYTM-2R1 y -'ARYTM-1K1 x"
          using A1 arytm_1_lm_8 sorry
        then have A4: "(y -'ARYTM-1K1 x)-'ARYTM-1K1 z =HIDDENR1 (y -'ARYTM-1K1 x)-ARYTM-1K2 z"
          using arytm_1_def_2 sorry
        have "x <='ARYTM-2R1 y -'ARYTM-1K1 z"
          using A2 A3 arytm_1_lm_8 sorry
        then have "(y -'ARYTM-1K1 z)-'ARYTM-1K1 x =HIDDENR1 (y -'ARYTM-1K1 z)-ARYTM-1K2 x"
          using arytm_1_def_2 sorry
        thus "(y -'ARYTM-1K1 z)-ARYTM-1K2 x =HIDDENR1 (y -'ARYTM-1K1 x)-ARYTM-1K2 z"
          using A4 arytm_1_lm_10 sorry
      qed
      have case2: " not x +ARYTM-2K7 z <='ARYTM-2R1 y & y <='ARYTM-2R1 x implies (y -'ARYTM-1K1 z)-ARYTM-1K2 x =HIDDENR1 (y -'ARYTM-1K1 x)-ARYTM-1K2 z"
      proof(rule impMI ,rule impI)
        assume A5: " not x +ARYTM-2K7 z <='ARYTM-2R1 y"
          and A6: "y <='ARYTM-2R1 x"
        have A7: " not x <='ARYTM-2R1 y -'ARYTM-1K1 z"
          using A2 A5 arytm_1_lm_8 sorry
        have A8: " not z <='ARYTM-2R1 y -'ARYTM-1K1 x"
          using A1 A5 arytm_1_lm_8 sorry
        have A9: "x =HIDDENR1 y"
          using A1 A6 arytm_1_th_4 sorry
        then have "x -'ARYTM-1K1 (x -'ARYTM-1K1 z) =HIDDENR1 z"
          using A2 arytm_1_lm_6 sorry
        also have "... = z -'ARYTM-1K1 (x -'ARYTM-1K1 x)"
          using arytm_1_lm_3 arytm_1_lm_4 sorry
        finally have "x -'ARYTM-1K1 (x -'ARYTM-1K1 z) =HIDDENR1 z -'ARYTM-1K1 (x -'ARYTM-1K1 x)"
           sorry
        then have "(y -'ARYTM-1K1 z)-ARYTM-1K2 x =HIDDENR1 [TARSKIK4 {}ARYTM-3K12,z -'ARYTM-1K1 (y -'ARYTM-1K1 x) ]"
          using A7 A9 arytm_1_def_2 sorry
        also have "... = (y -'ARYTM-1K1 x)-ARYTM-1K2 z"
          using A8 arytm_1_def_2 sorry
        finally show "(y -'ARYTM-1K1 z)-ARYTM-1K2 x =HIDDENR1 (y -'ARYTM-1K1 x)-ARYTM-1K2 z"
           sorry
      qed
      have case3: " not x +ARYTM-2K7 z <='ARYTM-2R1 y & y <='ARYTM-2R1 z implies (y -'ARYTM-1K1 z)-ARYTM-1K2 x =HIDDENR1 (y -'ARYTM-1K1 x)-ARYTM-1K2 z"
      proof(rule impMI ,rule impI)
        assume A10: " not x +ARYTM-2K7 z <='ARYTM-2R1 y"
          and A11: "y <='ARYTM-2R1 z"
        have A12: " not x <='ARYTM-2R1 y -'ARYTM-1K1 z"
          using A2 A10 arytm_1_lm_8 sorry
        have A13: " not z <='ARYTM-2R1 y -'ARYTM-1K1 x"
          using A1 A10 arytm_1_lm_8 sorry
        have A14: "z =HIDDENR1 y"
          using A2 A11 arytm_1_th_4 sorry
        have "x -'ARYTM-1K1 (z -'ARYTM-1K1 z) =HIDDENR1 x"
          using arytm_1_lm_3 arytm_1_lm_4 sorry
        also have "... = z -'ARYTM-1K1 (z -'ARYTM-1K1 x)"
          using A1 A14 arytm_1_lm_6 sorry
        finally have "x -'ARYTM-1K1 (z -'ARYTM-1K1 z) =HIDDENR1 z -'ARYTM-1K1 (z -'ARYTM-1K1 x)"
           sorry
        then have "(y -'ARYTM-1K1 z)-ARYTM-1K2 x =HIDDENR1 [TARSKIK4 {}ARYTM-3K12,z -'ARYTM-1K1 (y -'ARYTM-1K1 x) ]"
          using A12 A14 arytm_1_def_2 sorry
        also have "... = (y -'ARYTM-1K1 x)-ARYTM-1K2 z"
          using A13 arytm_1_def_2 sorry
        finally show "(y -'ARYTM-1K1 z)-ARYTM-1K2 x =HIDDENR1 (y -'ARYTM-1K1 x)-ARYTM-1K2 z"
           sorry
      qed
      have case4: " not x +ARYTM-2K7 z <='ARYTM-2R1 y & ( not y <='ARYTM-2R1 x &  not y <='ARYTM-2R1 z) implies (y -'ARYTM-1K1 z)-ARYTM-1K2 x =HIDDENR1 (y -'ARYTM-1K1 x)-ARYTM-1K2 z"
      proof(rule impMI ,rule impI)
        assume A15: " not x +ARYTM-2K7 z <='ARYTM-2R1 y"
          and A16: " not y <='ARYTM-2R1 x &  not y <='ARYTM-2R1 z"
        have A17: " not z <='ARYTM-2R1 y -'ARYTM-1K1 x"
          using A1 A15 arytm_1_lm_8 sorry
        have " not x <='ARYTM-2R1 y -'ARYTM-1K1 z & x -'ARYTM-1K1 (y -'ARYTM-1K1 z) =HIDDENR1 z -'ARYTM-1K1 (y -'ARYTM-1K1 x)"
          using A15 A16 arytm_1_lm_8 arytm_1_lm_13 sorry
        then have "(y -'ARYTM-1K1 z)-ARYTM-1K2 x =HIDDENR1 [TARSKIK4 {}ARYTM-3K12,z -'ARYTM-1K1 (y -'ARYTM-1K1 x) ]"
          using arytm_1_def_2 sorry
        also have "... = (y -'ARYTM-1K1 x)-ARYTM-1K2 z"
          using A17 arytm_1_def_2 sorry
        finally show "(y -'ARYTM-1K1 z)-ARYTM-1K2 x =HIDDENR1 (y -'ARYTM-1K1 x)-ARYTM-1K2 z"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 case4 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_1_th_26:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds z <='ARYTM-2R1 y implies x *'ARYTM-2K8 (y -'ARYTM-1K1 z) =HIDDENR1 x *'ARYTM-2K8 y -ARYTM-1K2 x *'ARYTM-2K8 z"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds z <='ARYTM-2R1 y implies x *'ARYTM-2K8 (y -'ARYTM-1K1 z) =HIDDENR1 x *'ARYTM-2K8 y -ARYTM-1K2 x *'ARYTM-2K8 z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume "z <='ARYTM-2R1 y"
    then have "x *'ARYTM-2K8 z <='ARYTM-2R1 x *'ARYTM-2K8 y"
      using arytm_1_th_8 sorry
    then have "x *'ARYTM-2K8 y -ARYTM-1K2 x *'ARYTM-2K8 z =HIDDENR1 x *'ARYTM-2K8 y -'ARYTM-1K1 x *'ARYTM-2K8 z"
      using arytm_1_def_2 sorry
    thus "x *'ARYTM-2K8 (y -'ARYTM-1K1 z) =HIDDENR1 x *'ARYTM-2K8 y -ARYTM-1K2 x *'ARYTM-2K8 z"
      using arytm_1_lm_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_1_th_27:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not z <='ARYTM-2R1 y & x <>HIDDENR2 {}ARYTM-3K12 implies [TARSKIK4 {}ARYTM-3K12,x *'ARYTM-2K8 (z -'ARYTM-1K1 y) ] =HIDDENR1 x *'ARYTM-2K8 y -ARYTM-1K2 x *'ARYTM-2K8 z"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not z <='ARYTM-2R1 y & x <>HIDDENR2 {}ARYTM-3K12 implies [TARSKIK4 {}ARYTM-3K12,x *'ARYTM-2K8 (z -'ARYTM-1K1 y) ] =HIDDENR1 x *'ARYTM-2K8 y -ARYTM-1K2 x *'ARYTM-2K8 z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume " not z <='ARYTM-2R1 y & x <>HIDDENR2 {}ARYTM-3K12"
    then have A1: " not x *'ARYTM-2K8 z <='ARYTM-2R1 x *'ARYTM-2K8 y"
      using arytm_1_lm_2 sorry
    have "[TARSKIK4 {}ARYTM-3K12,x *'ARYTM-2K8 (z -'ARYTM-1K1 y) ] =HIDDENR1 [TARSKIK4 {}ARYTM-3K12,x *'ARYTM-2K8 z -'ARYTM-1K1 x *'ARYTM-2K8 y ]"
      using arytm_1_lm_14 sorry
    also have "... = x *'ARYTM-2K8 y -ARYTM-1K2 x *'ARYTM-2K8 z"
      using A1 arytm_1_def_2 sorry
    finally show "[TARSKIK4 {}ARYTM-3K12,x *'ARYTM-2K8 (z -'ARYTM-1K1 y) ] =HIDDENR1 x *'ARYTM-2K8 y -ARYTM-1K2 x *'ARYTM-2K8 z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_1_th_28:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds (y -'ARYTM-1K1 z <>HIDDENR2 {}ARYTM-3K12 & z <='ARYTM-2R1 y) & x <>HIDDENR2 {}ARYTM-3K12 implies x *'ARYTM-2K8 z -ARYTM-1K2 x *'ARYTM-2K8 y =HIDDENR1 [TARSKIK4 {}ARYTM-3K12,x *'ARYTM-2K8 (y -'ARYTM-1K1 z) ]"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds y -'ARYTM-1K1 z <>HIDDENR2 {}ARYTM-3K12 implies (z <='ARYTM-2R1 y implies  not ( not x <>HIDDENR2 {}ARYTM-3K12 &  not x *'ARYTM-2K8 z -ARYTM-1K2 x *'ARYTM-2K8 y =HIDDENR1 [TARSKIK4 {}ARYTM-3K12,x *'ARYTM-2K8 (y -'ARYTM-1K1 z) ]))"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume "y -'ARYTM-1K1 z <>HIDDENR2 {}ARYTM-3K12"
    then have A1: "y <>HIDDENR2 z"
      using arytm_1_lm_3 sorry
    assume "z <='ARYTM-2R1 y"
    then have " not y <='ARYTM-2R1 z"
      using A1 arytm_1_th_4 sorry
    thus " not ( not x <>HIDDENR2 {}ARYTM-3K12 &  not x *'ARYTM-2K8 z -ARYTM-1K2 x *'ARYTM-2K8 y =HIDDENR1 [TARSKIK4 {}ARYTM-3K12,x *'ARYTM-2K8 (y -'ARYTM-1K1 z) ])"
      using arytm_1_th_27 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
