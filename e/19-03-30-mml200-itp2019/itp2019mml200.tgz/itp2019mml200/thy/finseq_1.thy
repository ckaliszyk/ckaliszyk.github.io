theory finseq_1
  imports valued_0 axioms card_2
   "../mizar_extension/E_number"
begin
(*begin*)
reserve a for "naturalORDINAL1V7\<bar>NumberORDINAL1M1"
reserve k, l, m, n, k1, b, c, i for "NatNAT-1M1"
reserve x, y, z, y1, y2 for "objectHIDDENM1"
reserve X, Y for "setHIDDENM2"
reserve f, g for "FunctionFUNCT-1M1"
mdef finseq_1_def_1 ("SegFINSEQ-1K1  _ " [228]228 ) where
  mlet "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"func SegFINSEQ-1K1 n \<rightarrow> setHIDDENM2 equals
  {k where k be NatNAT-1M1 : \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 n }"
proof-
  (*coherence*)
    show "{k where k be NatNAT-1M1 : \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 n } be setHIDDENM2"
       sorry
qed "sorry"

abbreviation(input) FINSEQ_1K2("SegFINSEQ-1K2  _ " [228]228) where
  "SegFINSEQ-1K2 n \<equiv> SegFINSEQ-1K1 n"

mtheorem finseq_1_add_1:
  mlet "n be NatNAT-1M1"
"cluster SegFINSEQ-1K1 n as-term-is SubsetSUBSET-1M2-of NATNUMBERSK1"
proof
(*coherence*)
  show "SegFINSEQ-1K1 n be SubsetSUBSET-1M2-of NATNUMBERSK1"
  proof-
    let ?X = "SegFINSEQ-1K1 n"
    have "?X c=TARSKIR1 NATNUMBERSK1"
    proof-
      have "SegFINSEQ-1K1 n c=TARSKIR1 NATNUMBERSK1"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 SegFINSEQ-1K1 n implies x inHIDDENR3 NATNUMBERSK1"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 ?X"
          then have " ex k be NatNAT-1M1 st (x =HIDDENR1 k & \<one>\<^sub>M <=XXREAL-0R1 k) & k <=XXREAL-0R1 n"
             sorry
          thus "x inHIDDENR3 NATNUMBERSK1"
            using ordinal1_def_12 sorry
        qed "sorry"
        thus "SegFINSEQ-1K1 n c=TARSKIR1 NATNUMBERSK1"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus "SegFINSEQ-1K1 n be SubsetSUBSET-1M2-of NATNUMBERSK1"
       sorry
  qed
qed "sorry"

mtheorem finseq_1_th_1:
" for a be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for b be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds a inHIDDENR3 SegFINSEQ-1K1 b iff \<one>\<^sub>M <=XXREAL-0R1 a & a <=XXREAL-0R1 b"
proof-
  have " for a be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for b be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  not (a inHIDDENR3 SegFINSEQ-1K1 b &  not (\<one>\<^sub>M <=XXREAL-0R1 a & a <=XXREAL-0R1 b)) &  not ((\<one>\<^sub>M <=XXREAL-0R1 a & a <=XXREAL-0R1 b) &  not a inHIDDENR3 SegFINSEQ-1K1 b)"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix b assume [ty]: "b be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have A1: "a be NatNAT-1M1 & b be NatNAT-1M1"
      using tarski_th_1 sorry
    have "a inHIDDENR3 {m where m be NatNAT-1M1 : \<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 b } iff ( ex m be NatNAT-1M1 st (a =HIDDENR1 m & \<one>\<^sub>M <=XXREAL-0R1 m) & m <=XXREAL-0R1 b)"
       sorry
    thus " not (a inHIDDENR3 SegFINSEQ-1K1 b &  not (\<one>\<^sub>M <=XXREAL-0R1 a & a <=XXREAL-0R1 b)) &  not ((\<one>\<^sub>M <=XXREAL-0R1 a & a <=XXREAL-0R1 b) &  not a inHIDDENR3 SegFINSEQ-1K1 b)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_cl_1:
  mlet "n be zeroORDINAL1V8\<bar>naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster SegFINSEQ-1K1 n as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "SegFINSEQ-1K1 n be emptyXBOOLE-0V1"
  proof-
    have " not SegFINSEQ-1K1 n be emptyXBOOLE-0V1 implies  False "
    proof(rule impI)
      assume " not SegFINSEQ-1K1 n be emptyXBOOLE-0V1"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A1: "x inHIDDENR3 SegFINSEQ-1K1 n"
         sorry
      have " ex k be NatNAT-1M1 st (k =HIDDENR1 x & \<one>\<^sub>M <=XXREAL-0R1 k) & k <=XXREAL-0R1 0NUMBERSK6"
        using A1 sorry
      thus " False "
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finseq_1_th_2:
"SegFINSEQ-1K2 \<one>\<^sub>M =XBOOLE-0R4 {TARSKIK1 \<one>\<^sub>M} & SegFINSEQ-1K2 \<two>\<^sub>M =XBOOLE-0R4 {TARSKIK2 \<one>\<^sub>M,\<two>\<^sub>M }"
proof(rule conjMI)
  have " for x be objectHIDDENM1 holds (x inHIDDENR3 SegFINSEQ-1K2 \<one>\<^sub>M implies x inHIDDENR3 {TARSKIK1 \<one>\<^sub>M}) & (x inHIDDENR3 {TARSKIK1 \<one>\<^sub>M} implies x inHIDDENR3 SegFINSEQ-1K2 \<one>\<^sub>M)"
  proof(rule ballI,rule conjMI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    show "x inHIDDENR3 SegFINSEQ-1K2 \<one>\<^sub>M implies x inHIDDENR3 {TARSKIK1 \<one>\<^sub>M}"
    proof(rule impI)
      assume "x inHIDDENR3 SegFINSEQ-1K2 \<one>\<^sub>M"
      then obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A1: "x =HIDDENR1 k"and A2: "\<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 \<one>\<^sub>M"
         sorry
      have "k =XBOOLE-0R4 \<one>\<^sub>M"
        using A2 xxreal_0_th_1 sorry
      thus "x inHIDDENR3 {TARSKIK1 \<one>\<^sub>M}"
        using A1 tarski_def_1 sorry
    qed
    assume "x inHIDDENR3 {TARSKIK1 \<one>\<^sub>M}"
    then have "x =HIDDENR1 \<one>\<^sub>M"
      using tarski_def_1 sorry
    thus "x inHIDDENR3 SegFINSEQ-1K2 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus "SegFINSEQ-1K2 \<one>\<^sub>M =XBOOLE-0R4 {TARSKIK1 \<one>\<^sub>M}"
    using tarski_th_2 sorry
  have " for x be objectHIDDENM1 holds (x inHIDDENR3 SegFINSEQ-1K2 \<two>\<^sub>M implies x inHIDDENR3 {TARSKIK2 \<one>\<^sub>M,\<two>\<^sub>M }) & (x inHIDDENR3 {TARSKIK2 \<one>\<^sub>M,\<two>\<^sub>M } implies x inHIDDENR3 SegFINSEQ-1K2 \<two>\<^sub>M)"
  proof(rule ballI,rule conjMI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    show "x inHIDDENR3 SegFINSEQ-1K2 \<two>\<^sub>M implies x inHIDDENR3 {TARSKIK2 \<one>\<^sub>M,\<two>\<^sub>M }"
    proof(rule impI)
      assume "x inHIDDENR3 SegFINSEQ-1K2 \<two>\<^sub>M"
      then obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A3: "x =HIDDENR1 k"and A4: "\<one>\<^sub>M <=XXREAL-0R1 k"and A5: "k <=XXREAL-0R1 \<two>\<^sub>M"
         sorry
      have "k <=XXREAL-0R1 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
        using A5 sorry
      then have "k =XBOOLE-0R4 \<one>\<^sub>M or k =XBOOLE-0R4 \<two>\<^sub>M"
        using A4 nat_1_th_9 sorry
      thus "x inHIDDENR3 {TARSKIK2 \<one>\<^sub>M,\<two>\<^sub>M }"
        using A3 tarski_def_2 sorry
    qed
    assume "x inHIDDENR3 {TARSKIK2 \<one>\<^sub>M,\<two>\<^sub>M }"
    then have "x =HIDDENR1 \<one>\<^sub>M or x =HIDDENR1 \<two>\<^sub>M"
      using tarski_def_2 sorry
    thus "x inHIDDENR3 SegFINSEQ-1K2 \<two>\<^sub>M"
       sorry
  qed "sorry"
  thus "SegFINSEQ-1K2 \<two>\<^sub>M =XBOOLE-0R4 {TARSKIK2 \<one>\<^sub>M,\<two>\<^sub>M }"
    using tarski_th_2 sorry
qed

mtheorem finseq_1_th_3:
" for a be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds a =HIDDENR1 0NUMBERSK6 or a inHIDDENR3 SegFINSEQ-1K1 a"
proof-
  have " for a be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds a <>HIDDENR2 0NUMBERSK6 implies a inHIDDENR3 SegFINSEQ-1K1 a"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume "a <>HIDDENR2 0NUMBERSK6"
    then have " ex b be NatNAT-1M1 st a =HIDDENR1 b +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_6 sorry
    then have "a inHIDDENR3 NATNUMBERSK1 & \<one>\<^sub>M <=XXREAL-0R1 a"
      using nat_1_th_11 sorry
    thus "a inHIDDENR3 SegFINSEQ-1K1 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_cl_2:
  mlet "n be  non zeroORDINAL1V8\<bar>naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster SegFINSEQ-1K1 n as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "SegFINSEQ-1K1 n be  non emptyXBOOLE-0V1"
    using finseq_1_th_3 sorry
qed "sorry"

mtheorem finseq_1_th_4:
" for a be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds a +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (a +NAT-1K1 \<one>\<^sub>M)"
  using finseq_1_th_3 sorry

mtheorem finseq_1_th_5:
" for a be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for b be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds a <=XXREAL-0R1 b iff SegFINSEQ-1K1 a c=TARSKIR1 SegFINSEQ-1K1 b"
proof-
  have " for a be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for b be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (a <=XXREAL-0R1 b implies SegFINSEQ-1K1 a c=TARSKIR1 SegFINSEQ-1K1 b) & (SegFINSEQ-1K1 a c=TARSKIR1 SegFINSEQ-1K1 b implies a <=XXREAL-0R1 b)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix a assume [ty]: "a be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix b assume [ty]: "b be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    show "a <=XXREAL-0R1 b implies SegFINSEQ-1K1 a c=TARSKIR1 SegFINSEQ-1K1 b"
    proof(rule impI)
      assume A1: "a <=XXREAL-0R1 b"
      have " for x be objectHIDDENM1 holds x inHIDDENR3 SegFINSEQ-1K1 a implies x inHIDDENR3 SegFINSEQ-1K1 b"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 SegFINSEQ-1K1 a"
        then obtain c where
          [ty]:"c be NatNAT-1M1" and 
          A3: "(x =HIDDENR1 c & \<one>\<^sub>M <=XXREAL-0R1 c) & c <=XXREAL-0R1 a"
           sorry
        have "c <=XXREAL-0R1 b"
          using A1 A3 xxreal_0_th_2 sorry
        thus "x inHIDDENR3 SegFINSEQ-1K1 b"
          using A3 sorry
      qed "sorry"
      thus "SegFINSEQ-1K1 a c=TARSKIR1 SegFINSEQ-1K1 b"
        using tarski_def_3 sorry
    qed
    assume A4: "SegFINSEQ-1K1 a c=TARSKIR1 SegFINSEQ-1K1 b"
    have "a <>HIDDENR2 0NUMBERSK6 implies a <=XXREAL-0R1 b"
    proof(rule impI)
      assume "a <>HIDDENR2 0NUMBERSK6"
      then have "a inHIDDENR3 SegFINSEQ-1K1 a"
        using finseq_1_th_3 sorry
      thus "a <=XXREAL-0R1 b"
        using A4 finseq_1_th_1 sorry
    qed
    thus "a <=XXREAL-0R1 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_6:
" for a be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for b be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds SegFINSEQ-1K1 a =XBOOLE-0R4 SegFINSEQ-1K1 b implies a =HIDDENR1 b"
proof(rule ballI,rule ballI,rule impI)
  fix a assume [ty]: "a be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
  fix b assume [ty]: "b be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
  assume "SegFINSEQ-1K1 a =XBOOLE-0R4 SegFINSEQ-1K1 b"
  then have "a <=XXREAL-0R1 b & b <=XXREAL-0R1 a"
    using finseq_1_th_5 sorry
  thus "a =HIDDENR1 b"
    using xxreal_0_th_1 sorry
qed "sorry"

mtheorem finseq_1_th_7:
" for a be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for b be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for c be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds c <=XXREAL-0R1 a implies SegFINSEQ-1K1 c =XBOOLE-0R4 SegFINSEQ-1K1 a /\\XBOOLE-0K3 SegFINSEQ-1K1 c"
  using finseq_1_th_5 xboole_1_th_28 sorry

mtheorem finseq_1_th_8:
" for a be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for c be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds SegFINSEQ-1K1 c =XBOOLE-0R4 SegFINSEQ-1K1 c /\\XBOOLE-0K3 SegFINSEQ-1K1 a implies c <=XXREAL-0R1 a"
  using finseq_1_th_6 finseq_1_th_7 sorry

mtheorem finseq_1_th_9:
" for a be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds SegFINSEQ-1K1 a \\/XBOOLE-0K2 {TARSKIK1 a +NAT-1K1 \<one>\<^sub>M } =XBOOLE-0R4 SegFINSEQ-1K2 (a +NAT-1K1 \<one>\<^sub>M)"
proof(rule ballI)
  fix a assume [ty]: "a be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
  have "SegFINSEQ-1K1 a \\/XBOOLE-0K2 {TARSKIK1 a +NAT-1K1 \<one>\<^sub>M } c=TARSKIR1 SegFINSEQ-1K2 (a +NAT-1K1 \<one>\<^sub>M) & SegFINSEQ-1K2 (a +NAT-1K1 \<one>\<^sub>M) c=TARSKIR1 SegFINSEQ-1K1 a \\/XBOOLE-0K2 {TARSKIK1 a +NAT-1K1 \<one>\<^sub>M }"
  proof(rule conjMI)
    show "SegFINSEQ-1K1 a \\/XBOOLE-0K2 {TARSKIK1 a +NAT-1K1 \<one>\<^sub>M } c=TARSKIR1 SegFINSEQ-1K2 (a +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have "a +NAT-1K1 0NUMBERSK6 <=XXREAL-0R1 a +NAT-1K1 \<one>\<^sub>M"
        using xreal_1_th_7 sorry
      then have A1: "SegFINSEQ-1K1 a c=TARSKIR1 SegFINSEQ-1K2 (a +NAT-1K1 \<one>\<^sub>M)"
        using finseq_1_th_5 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 SegFINSEQ-1K1 a \\/XBOOLE-0K2 {TARSKIK1 a +NAT-1K1 \<one>\<^sub>M } implies x inHIDDENR3 SegFINSEQ-1K2 (a +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 SegFINSEQ-1K1 a \\/XBOOLE-0K2 {TARSKIK1 a +NAT-1K1 \<one>\<^sub>M }"
        then have "x inHIDDENR3 SegFINSEQ-1K1 a or x inHIDDENR3 {TARSKIK1 a +NAT-1K1 \<one>\<^sub>M }"
          using xboole_0_def_3 sorry
        then have "x inHIDDENR3 SegFINSEQ-1K2 (a +NAT-1K1 \<one>\<^sub>M) or x =HIDDENR1 a +NAT-1K1 \<one>\<^sub>M"
          using A1 tarski_def_1 sorry
        thus "x inHIDDENR3 SegFINSEQ-1K2 (a +NAT-1K1 \<one>\<^sub>M)"
          using finseq_1_th_3 sorry
      qed "sorry"
      thus "SegFINSEQ-1K1 a \\/XBOOLE-0K2 {TARSKIK1 a +NAT-1K1 \<one>\<^sub>M } c=TARSKIR1 SegFINSEQ-1K2 (a +NAT-1K1 \<one>\<^sub>M)"
        using tarski_def_3 sorry
    qed
    have " for x be objectHIDDENM1 holds x inHIDDENR3 SegFINSEQ-1K2 (a +NAT-1K1 \<one>\<^sub>M) implies x inHIDDENR3 SegFINSEQ-1K1 a \\/XBOOLE-0K2 {TARSKIK1 a +NAT-1K1 \<one>\<^sub>M }"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A2: "x inHIDDENR3 SegFINSEQ-1K2 (a +NAT-1K1 \<one>\<^sub>M)"
      then have 
        [ty]:"x be ElementSUBSET-1M1-of NATNUMBERSK1"
         sorry
      have A3: "x <=XXREAL-0R1 a +NAT-1K1 \<one>\<^sub>M"
        using A2 finseq_1_th_1 sorry
      have A4: "\<one>\<^sub>M <=XXREAL-0R1 x"
        using A2 finseq_1_th_1 sorry
      have "x <=XXREAL-0R1 a or x =XBOOLE-0R4 a +NAT-1K1 \<one>\<^sub>M"
        using A3 nat_1_th_8 sorry
      then have "x inTARSKIR2 SegFINSEQ-1K1 a or x inTARSKIR2 {TARSKIK1 a +NAT-1K1 \<one>\<^sub>M }"
        using A4 tarski_def_1 sorry
      thus "x inHIDDENR3 SegFINSEQ-1K1 a \\/XBOOLE-0K2 {TARSKIK1 a +NAT-1K1 \<one>\<^sub>M }"
        using xboole_0_def_3 sorry
    qed "sorry"
    thus "SegFINSEQ-1K2 (a +NAT-1K1 \<one>\<^sub>M) c=TARSKIR1 SegFINSEQ-1K1 a \\/XBOOLE-0K2 {TARSKIK1 a +NAT-1K1 \<one>\<^sub>M }"
      using tarski_def_3 sorry
  qed
  thus "SegFINSEQ-1K1 a \\/XBOOLE-0K2 {TARSKIK1 a +NAT-1K1 \<one>\<^sub>M } =XBOOLE-0R4 SegFINSEQ-1K2 (a +NAT-1K1 \<one>\<^sub>M)"
    using xboole_0_def_10 sorry
qed "sorry"

mtheorem finseq_1_th_10:
" for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds SegFINSEQ-1K1 k =XBOOLE-0R4 SegFINSEQ-1K2 (k +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 k +NAT-1K1 \<one>\<^sub>M }"
proof(rule ballI)
  fix k assume [ty]: "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
  have A1: "SegFINSEQ-1K2 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 SegFINSEQ-1K1 k \\/XBOOLE-0K2 {TARSKIK1 k +NAT-1K1 \<one>\<^sub>M }"
    using finseq_1_th_9 sorry
  have "SegFINSEQ-1K1 k missesXBOOLE-0R1 {TARSKIK1 k +NAT-1K1 \<one>\<^sub>M }"
  proof-
    have " not SegFINSEQ-1K1 k missesXBOOLE-0R1 {TARSKIK1 k +NAT-1K1 \<one>\<^sub>M } implies  not  True "
    proof(rule impI)
      assume " not SegFINSEQ-1K1 k missesXBOOLE-0R1 {TARSKIK1 k +NAT-1K1 \<one>\<^sub>M }"
      then have A2: "SegFINSEQ-1K1 k /\\XBOOLE-0K3 {TARSKIK1 k +NAT-1K1 \<one>\<^sub>M } <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      let ?x = "the ElementSUBSET-1M1-of SegFINSEQ-1K1 k /\\XBOOLE-0K3 {TARSKIK1 k +NAT-1K1 \<one>\<^sub>M }"
      have A3: "?x inTARSKIR2 SegFINSEQ-1K1 k"
        using A2 xboole_0_def_4 sorry
      have "?x inTARSKIR2 {TARSKIK1 k +NAT-1K1 \<one>\<^sub>M }"
        using A2 xboole_0_def_4 sorry
      then have "?x =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
        using tarski_def_1 sorry
      thus " not  True "
        using A3 finseq_1_th_1 xreal_1_th_29 sorry
    qed
    thus " ?thesis "
       sorry
  qed
  thus "SegFINSEQ-1K1 k =XBOOLE-0R4 SegFINSEQ-1K2 (k +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 k +NAT-1K1 \<one>\<^sub>M }"
    using A1 xboole_1_th_88 sorry
qed "sorry"

mdef finseq_1_def_2 ("FinSequence-likeFINSEQ-1V1" 70 ) where
"attr FinSequence-likeFINSEQ-1V1 for RelationRELAT-1M1 means
  (\<lambda>IT.  ex n be NatNAT-1M1 st domRELAT-1K1 IT =XBOOLE-0R4 SegFINSEQ-1K2 n)"..

mtheorem finseq_1_cl_3:
"cluster emptyXBOOLE-0V1 also-is FinSequence-likeFINSEQ-1V1 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be emptyXBOOLE-0V1 implies it be FinSequence-likeFINSEQ-1V1"
  proof-
    have " for R be RelationRELAT-1M1 holds R be emptyXBOOLE-0V1 implies R be FinSequence-likeFINSEQ-1V1"
    proof(rule ballI,rule impI)
      fix R assume [ty]: "R be RelationRELAT-1M1"
      assume A1: "R be emptyXBOOLE-0V1"
      have "domRELAT-1K1 R =XBOOLE-0R4 SegFINSEQ-1K2 (0NUMBERSK6)"
      proof-
        show "domRELAT-1K1 R =XBOOLE-0R4 SegFINSEQ-1K2 (0NUMBERSK6)"
          using A1 sorry
      qed
      thus "R be FinSequence-likeFINSEQ-1V1"
        using bexI[of _ "0NUMBERSK6"] finseq_1_def_2 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax FINSEQ_1M1 :: "Ty" ("FinSequenceFINSEQ-1M1" 70)
translations "FinSequenceFINSEQ-1M1" \<rightharpoonup> "FinSequence-likeFINSEQ-1V1\<bar>FunctionFUNCT-1M1"

reserve p, q, r, s, t for "FinSequenceFINSEQ-1M1"
mtheorem finseq_1_cl_4:
  mlet "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster SegFINSEQ-1K1 n as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "SegFINSEQ-1K1 n be finiteFINSET-1V1"
  proof-
    have 
      [ty]:"n be NatNAT-1M1"
      using tarski_th_1 sorry
    have "SegFINSEQ-1K2 n be finiteFINSET-1V1"
    proof-
      have A1: "n =XBOOLE-0R4 {k where k be NatNAT-1M1 : k <XXREAL-0R3 n }"
        using axioms_th_4 sorry
      have A2: " for x be objectHIDDENM1 holds x inHIDDENR3 n implies ( ex y be objectHIDDENM1 st  ex k be NatNAT-1M1 st x =HIDDENR1 k & y =HIDDENR1 k +NAT-1K1 \<one>\<^sub>M)"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 n implies ( ex tVar2 be objectHIDDENM1 st  ex kc be NatNAT-1M1 st x =HIDDENR1 kc & tVar2 =HIDDENR1 kc +NAT-1K1 \<one>\<^sub>M)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 n"
          then have " ex k be NatNAT-1M1 st x =HIDDENR1 k & k <XXREAL-0R3 n"
            using A1 sorry
          then obtain k where 
            [ty]:"k be NatNAT-1M1" and kDef:"k = x"
             sorry
          show " ex tVar2 be objectHIDDENM1 st  ex kc be NatNAT-1M1 st x =HIDDENR1 kc & tVar2 =HIDDENR1 kc +NAT-1K1 \<one>\<^sub>M"
          proof(rule bexI[of _ "k +NAT-1K1 \<one>\<^sub>M"])
            show " ex kc be NatNAT-1M1 st x =HIDDENR1 kc & k +NAT-1K1 \<one>\<^sub>M =HIDDENR1 kc +NAT-1K1 \<one>\<^sub>M"
               sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A3: "domRELAT-1K1 f =XBOOLE-0R4 n"and A4: " for x be objectHIDDENM1 holds x inHIDDENR3 n implies ( ex k be NatNAT-1M1 st x =HIDDENR1 k & f .FUNCT-1K1 x =HIDDENR1 k +NAT-1K1 \<one>\<^sub>M)"
        using classes1_sch_1 A2 sorry
      have "rngFUNCT-1K2 f =XBOOLE-0R4 SegFINSEQ-1K2 n & domRELAT-1K1 f inTARSKIR2 omegaORDINAL1K4"
      proof(rule conjMI)
        show "rngFUNCT-1K2 f =XBOOLE-0R4 SegFINSEQ-1K2 n"
        proof-
          have "rngFUNCT-1K2 f c=TARSKIR1 SegFINSEQ-1K2 n & SegFINSEQ-1K2 n c=TARSKIR1 rngFUNCT-1K2 f"
          proof(rule conjMI)
            show "rngFUNCT-1K2 f c=TARSKIR1 SegFINSEQ-1K2 n"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 SegFINSEQ-1K2 n"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 rngFUNCT-1K2 f"
                then obtain y where
                  [ty]:"y be objectHIDDENM1" and 
                  A5: "y inHIDDENR3 domRELAT-1K1 f"and A6: "x =HIDDENR1 f .FUNCT-1K1 y"
                  using funct_1_def_3 sorry
                obtain k where
                  [ty]:"k be NatNAT-1M1" and 
                  A7: "y =HIDDENR1 k"and A8: "x =HIDDENR1 k +NAT-1K1 \<one>\<^sub>M"
                  using A3 A4 A5 A6 sorry
                have " ex m be NatNAT-1M1 st m =HIDDENR1 y & m <XXREAL-0R3 n"
                  using A1 A3 A5 sorry
                then have "\<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M & k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
                  using A7 nat_1_th_11 nat_1_th_13 sorry
                thus "x inHIDDENR3 SegFINSEQ-1K2 n"
                  using A8 sorry
              qed "sorry"
              thus "rngFUNCT-1K2 f c=TARSKIR1 SegFINSEQ-1K2 n"
                using tarski_def_3 sorry
            qed
            have " for x be objectHIDDENM1 holds x inHIDDENR3 SegFINSEQ-1K2 n implies x inHIDDENR3 rngFUNCT-1K2 f"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 SegFINSEQ-1K2 n"
              then obtain k where
                [ty]:"k be NatNAT-1M1" and 
                A9: "x =HIDDENR1 k"and A10: "\<one>\<^sub>M <=XXREAL-0R1 k"and A11: "k <=XXREAL-0R1 n"
                 sorry
              obtain i where
                [ty]:"i be NatNAT-1M1" and 
                A12: "\<one>\<^sub>M +XCMPLX-0K2 i =XBOOLE-0R4 k"
                using A10 nat_1_th_10 sorry
              have "i inTARSKIR2 NATNUMBERSK1 & i <XXREAL-0R3 n"
                using A11 A12 nat_1_th_13 ordinal1_def_12 sorry
              then have A13: "i inTARSKIR2 n"
                using A1 sorry
              then have " ex k be NatNAT-1M1 st i =HIDDENR1 k & f .FUNCT-1K1 i =HIDDENR1 k +NAT-1K1 \<one>\<^sub>M"
                using A4 sorry
              thus "x inHIDDENR3 rngFUNCT-1K2 f"
                using A3 A9 A12 A13 funct_1_def_3 sorry
            qed "sorry"
            thus "SegFINSEQ-1K2 n c=TARSKIR1 rngFUNCT-1K2 f"
              using tarski_def_3 sorry
          qed
          thus "rngFUNCT-1K2 f =XBOOLE-0R4 SegFINSEQ-1K2 n"
            using xboole_0_def_10 sorry
        qed
        show "domRELAT-1K1 f inTARSKIR2 omegaORDINAL1K4"
          using A3 ordinal1_def_12 sorry
      qed
      thus "SegFINSEQ-1K2 n be finiteFINSET-1V1"
        using bexI[of _ "f"] finset_1_def_1 sorry
    qed
    thus "SegFINSEQ-1K1 n be finiteFINSET-1V1"
       sorry
  qed
qed "sorry"

mtheorem finseq_1_cl_5:
"cluster FinSequence-likeFINSEQ-1V1 also-is finiteFINSET-1V1 for FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be FunctionFUNCT-1M1 holds it be FinSequence-likeFINSEQ-1V1 implies it be finiteFINSET-1V1"
  proof-
    have " for f be FunctionFUNCT-1M1 holds  not (f be FinSequence-likeFINSEQ-1V1 &  not f be finiteFINSET-1V1)"
    proof(rule ballI)
      fix f assume [ty]: "f be FunctionFUNCT-1M1"
      have "( ex n be NatNAT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 SegFINSEQ-1K2 n) implies f be finiteFINSET-1V1"
      proof(rule impI)
        assume Given: " ex n be NatNAT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 SegFINSEQ-1K2 n"
        then obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A1: "domRELAT-1K1 f =XBOOLE-0R4 SegFINSEQ-1K2 n"
           sorry
        have "rngFUNCT-1K2 f be finiteFINSET-1V1"
          using A1 finset_1_th_8 sorry
        then have "[:ZFMISC-1K2 domRELAT-1K1 f,rngFUNCT-1K2 f :] be finiteFINSET-1V1"
          using A1 sorry
        thus "f be finiteFINSET-1V1"
          using finset_1_th_1 relat_1_th_7 sorry
      qed
      thus " not (f be FinSequence-likeFINSEQ-1V1 &  not f be finiteFINSET-1V1)"
        using finseq_1_def_2 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mlemma finseq_1_lm_1:
" for n be NatNAT-1M1 holds (SegFINSEQ-1K2 n,n)are-equipotentWELLORD2R2"
proof-
  have " for n be NatNAT-1M1 holds (SegFINSEQ-1K2 n,n)are-equipotentWELLORD2R2"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?P = "\<lambda>Lamb1. (SegFINSEQ-1K2 Lamb1,Lamb1)are-equipotentWELLORD2R2"
    have A1: "?P(0NUMBERSK6)"
       sorry
    have A2: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds (SegFINSEQ-1K2 n,n)are-equipotentWELLORD2R2 implies (SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),n +NAT-1K1 \<one>\<^sub>M)are-equipotentWELLORD2R2"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A3: "(SegFINSEQ-1K2 n,n)are-equipotentWELLORD2R2"
        have A4: "SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 succORDINAL1K1 (SegmCARD-1K5 n)"
          using nat_1_th_38 sorry
        also have "... = n \\/XBOOLE-0K2 {TARSKIK1 n}"
           sorry
        finally have "SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 n \\/XBOOLE-0K2 {TARSKIK1 n}"
           sorry
        have A5: "SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 SegFINSEQ-1K2 n \\/XBOOLE-0K2 {TARSKIK1 n +NAT-1K1 \<one>\<^sub>M } & ({TARSKIK1 n +NAT-1K1 \<one>\<^sub>M },{TARSKIK1 n})are-equipotentWELLORD2R2"
          using finseq_1_th_9 card_1_th_28 sorry
        have A6: "n meetsXBOOLE-0R5 {TARSKIK1 n} implies  False "
        proof(rule impI)
          assume "n meetsXBOOLE-0R5 {TARSKIK1 n}"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A7: "x inHIDDENR3 n"and A8: "x inHIDDENR3 {TARSKIK1 n}"
            using xboole_0_th_3 sorry
          have A: "x =HIDDENR1 n"
            using A8 tarski_def_1 sorry
          obtain xx where 
            [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
            using tarski_th_1 sorry
          have " not xx inTARSKIR2 xx"
             sorry
          thus " False "
            using A7 A sorry
        qed
        have "SegFINSEQ-1K2 n meetsXBOOLE-0R5 {TARSKIK1 n +NAT-1K1 \<one>\<^sub>M } implies  False "
        proof(rule impI)
          assume "SegFINSEQ-1K2 n meetsXBOOLE-0R5 {TARSKIK1 n +NAT-1K1 \<one>\<^sub>M }"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A9: "x inHIDDENR3 SegFINSEQ-1K2 n"and A10: "x inHIDDENR3 {TARSKIK1 n +NAT-1K1 \<one>\<^sub>M }"
            using xboole_0_th_3 sorry
          have A11: "x =HIDDENR1 n +NAT-1K1 \<one>\<^sub>M"
            using A10 tarski_def_1 sorry
          have " not n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
            using nat_1_th_13 sorry
          thus " False "
            using A9 A11 finseq_1_th_1 sorry
        qed
        thus "(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),n +NAT-1K1 \<one>\<^sub>M)are-equipotentWELLORD2R2"
          using A3 A4 A5 A6 card_1_th_31 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A1 A2 sorry
    thus "(SegFINSEQ-1K2 n,n)are-equipotentWELLORD2R2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_cl_6:
  mlet "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster SegFINSEQ-1K1 n as-term-is n -elementCARD-1V3"
proof
(*coherence*)
  show "SegFINSEQ-1K1 n be n -elementCARD-1V3"
  proof-
    have "n be NatNAT-1M1"
      using tarski_th_1 sorry
    thus "SegFINSEQ-1K1 n be n -elementCARD-1V3"
      using finseq_1_lm_1 card_1_def_2 sorry
  qed
qed "sorry"

abbreviation(input) FINSEQ_1K3("lenFINSEQ-1K3  _ " [228]228) where
  "lenFINSEQ-1K3 p \<equiv> cardCARD-1K1 p"

abbreviation(input) FINSEQ_1K4("lenFINSEQ-1K4  _ " [228]228) where
  "lenFINSEQ-1K4 p \<equiv> cardCARD-1K1 p"

mtheorem finseq_1_def_3:
  mlet "p be FinSequenceFINSEQ-1M1"
"redefine func lenFINSEQ-1K4 p \<rightarrow> ElementSUBSET-1M1-of NATNUMBERSK1 means
  \<lambda>it. SegFINSEQ-1K2 it =XBOOLE-0R4 domRELAT-1K1 p"
proof
(*compatibility*)
  show " for it be ElementSUBSET-1M1-of NATNUMBERSK1 holds it =HIDDENR1 lenFINSEQ-1K4 p iff SegFINSEQ-1K2 it =XBOOLE-0R4 domRELAT-1K1 p"
  proof-
    have " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds (k =XBOOLE-0R4 cardCARD-1K4 p implies SegFINSEQ-1K2 k =XBOOLE-0R4 domRELAT-1K1 p) & (SegFINSEQ-1K2 k =XBOOLE-0R4 domRELAT-1K1 p implies k =XBOOLE-0R4 cardCARD-1K4 p)"
    proof(rule ballI,rule conjMI,rule impI)
      fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
      obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A1: "domRELAT-1K1 p =XBOOLE-0R4 SegFINSEQ-1K2 n"
        using finseq_1_def_2 sorry
      have "(domRELAT-1K1 p,p)are-equipotentWELLORD2R2"
      proof-
        let ?F = "\<lambda>Lamb1. [TARSKIK4 Lamb1,p .FUNCT-1K1 Lamb1 ]"
        obtain g where
          [ty]:"g be FunctionFUNCT-1M1" and 
          A2: "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 p"and A3: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 p implies g .FUNCT-1K1 x =HIDDENR1 ?F(x)"
          using funct_1_sch_3 sorry
        have "g be one-to-oneFUNCT-1V2 & (domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 p & rngRELAT-1K2 g =HIDDENR1 p)"
        proof(rule conjMI,rule conjMI)
          show "g be one-to-oneFUNCT-1V2"
          proof-
            have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g & y inHIDDENR3 domRELAT-1K1 g implies (g .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 y implies x =HIDDENR1 y)"
            proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              fix y assume [ty]: "y be objectHIDDENM1"
              assume A4: "x inHIDDENR3 domRELAT-1K1 g"
                and A5: "y inHIDDENR3 domRELAT-1K1 g"
              assume "g .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 y"
              then have "[TARSKIK4 x,p .FUNCT-1K1 x ] =HIDDENR1 g .FUNCT-1K1 y"
                using A2 A3 A4 sorry
              also have "... = [TARSKIK4 y,p .FUNCT-1K1 y ]"
                using A2 A3 A5 sorry
              finally have "[TARSKIK4 x,p .FUNCT-1K1 x ] =HIDDENR1 [TARSKIK4 y,p .FUNCT-1K1 y ]"
                 sorry
              thus "x =HIDDENR1 y"
                using xtuple_0_th_1 sorry
            qed "sorry"
            thus "g be one-to-oneFUNCT-1V2"
              using funct_1_def_4 sorry
          qed
          show "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 p"
            using A2 sorry
          have "rngFUNCT-1K2 g c=TARSKIR1 p & p c=TARSKIR1 rngRELAT-1K2 g"
          proof(rule conjMI)
            show "rngFUNCT-1K2 g c=TARSKIR1 p"
            proof-
              have " for i be objectHIDDENM1 holds i inHIDDENR3 rngFUNCT-1K2 g implies i inHIDDENR3 p"
              proof(rule ballI,rule impI)
                fix i assume [ty]: "i be objectHIDDENM1"
                assume "i inHIDDENR3 rngFUNCT-1K2 g"
                then obtain x where
                  [ty]:"x be objectHIDDENM1" and 
                  A6: "x inHIDDENR3 domRELAT-1K1 g"and A7: "g .FUNCT-1K1 x =HIDDENR1 i"
                  using funct_1_def_3 sorry
                have "g .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 x,p .FUNCT-1K1 x ]"
                  using A2 A3 A6 sorry
                thus "i inHIDDENR3 p"
                  using A2 A6 A7 funct_1_th_1 sorry
              qed "sorry"
              thus "rngFUNCT-1K2 g c=TARSKIR1 p"
                using tarski_def_3 sorry
            qed
            have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 p implies [TARSKIK4 x,y ] inHIDDENR3 rngRELAT-1K2 g"
            proof(rule ballI,rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              fix y assume [ty]: "y be objectHIDDENM1"
              assume A8: "[TARSKIK4 x,y ] inHIDDENR3 p"
              then have A9: "x inHIDDENR3 domRELAT-1K1 p"
                using funct_1_th_1 sorry
              have "y =HIDDENR1 p .FUNCT-1K1 x"
                using A8 funct_1_th_1 sorry
              then have "g .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 x,y ]"
                using A3 A8 funct_1_th_1 sorry
              thus "[TARSKIK4 x,y ] inHIDDENR3 rngRELAT-1K2 g"
                using A2 A9 funct_1_def_3 sorry
            qed "sorry"
            thus "p c=TARSKIR1 rngRELAT-1K2 g"
              using relat_1_def_3 sorry
          qed
          thus "rngRELAT-1K2 g =HIDDENR1 p"
            using xboole_0_def_10 sorry
        qed
        thus "(domRELAT-1K1 p,p)are-equipotentWELLORD2R2"
          using bexI[of _ "g"] wellord2_def_4 sorry
      qed
      then have A10: "cardCARD-1K4 p =XBOOLE-0R4 cardCARD-1K1 (domRELAT-1K1 p)"
        using card_1_th_5 sorry
      show "k =XBOOLE-0R4 cardCARD-1K4 p implies SegFINSEQ-1K2 k =XBOOLE-0R4 domRELAT-1K1 p"
        using A1 A10 finseq_1_lm_1 card_1_def_2 sorry
      assume "SegFINSEQ-1K2 k =XBOOLE-0R4 domRELAT-1K1 p"
      thus "k =XBOOLE-0R4 cardCARD-1K4 p"
        using A10 finseq_1_lm_1 card_1_def_2 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finseq_1_add_2:
  mlet "p be FinSequenceFINSEQ-1M1"
"cluster cardCARD-1K1 p as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "cardCARD-1K1 p be ElementSUBSET-1M1-of NATNUMBERSK1"
  proof-
    have "cardCARD-1K4 p =XBOOLE-0R4 cardCARD-1K4 p"
       sorry
    thus "cardCARD-1K1 p be ElementSUBSET-1M1-of NATNUMBERSK1"
       sorry
  qed
qed "sorry"

abbreviation(input) FINSEQ_1K5("domFINSEQ-1K5  _ " [228]228) where
  "domFINSEQ-1K5 p \<equiv> domRELAT-1K1 p"

mtheorem finseq_1_add_3:
  mlet "p be FinSequenceFINSEQ-1M1"
"cluster domRELAT-1K1 p as-term-is SubsetSUBSET-1M2-of NATNUMBERSK1"
proof
(*coherence*)
  show "domRELAT-1K1 p be SubsetSUBSET-1M2-of NATNUMBERSK1"
  proof-
    have "domRELAT-1K1 p =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
      using finseq_1_def_3 sorry
    thus "domRELAT-1K1 p be SubsetSUBSET-1M2-of NATNUMBERSK1"
       sorry
  qed
qed "sorry"

mtheorem finseq_1_th_11:
" for f be FunctionFUNCT-1M1 holds ( ex k be NatNAT-1M1 st domRELAT-1K1 f c=TARSKIR1 SegFINSEQ-1K2 k) implies ( ex p be FinSequenceFINSEQ-1M1 st f c=RELAT-1R2 p)"
proof-
  have " for f be FunctionFUNCT-1M1 holds ( ex k be NatNAT-1M1 st domRELAT-1K1 f c=TARSKIR1 SegFINSEQ-1K2 k) implies ( ex tVar5 be FinSequenceFINSEQ-1M1 st f c=RELAT-1R2 tVar5)"
  proof(rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume Given: " ex k be NatNAT-1M1 st domRELAT-1K1 f c=TARSKIR1 SegFINSEQ-1K2 k"
    then obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A1: "domRELAT-1K1 f c=TARSKIR1 SegFINSEQ-1K2 k"
       sorry
    let ?F = "\<lambda>Lamb1. f .FUNCT-1K1 Lamb1"
    obtain g where
      [ty]:"g be FunctionFUNCT-1M1" and 
      A2: "domRELAT-1K1 g =XBOOLE-0R4 SegFINSEQ-1K2 k & ( for x be objectHIDDENM1 holds x inHIDDENR3 SegFINSEQ-1K2 k implies g .FUNCT-1K1 x =XBOOLE-0R4 ?F(x))"
      using funct_1_sch_3 sorry
    have 
      [ty]:"g be FinSequenceFINSEQ-1M1"
      using A2 finseq_1_def_2 sorry
    show " ex tVar5 be FinSequenceFINSEQ-1M1 st f c=RELAT-1R2 tVar5"
    proof(rule bexI[of _ "g"])
      have " for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds [TARSKIK4 y,z ] inHIDDENR3 f implies [TARSKIK4 y,z ] inHIDDENR3 g"
      proof(rule ballI,rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        fix z assume [ty]: "z be objectHIDDENM1"
        assume A3: "[TARSKIK4 y,z ] inHIDDENR3 f"
        then have A4: "y inHIDDENR3 domRELAT-1K1 f"
          using xtuple_0_def_12 sorry
        have 
          [ty]:"z be setHIDDENM2"
          using tarski_th_1 sorry
        have A5: "f .FUNCT-1K1 y =XBOOLE-0R4 z"
          using A3 funct_1_def_2 A4 sorry
        have "[TARSKIK4 y,g .FUNCT-1K1 y ] inHIDDENR3 g"
          using A1 A2 A4 funct_1_th_1 sorry
        thus "[TARSKIK4 y,z ] inHIDDENR3 g"
          using A1 A2 A4 A5 sorry
      qed "sorry"
      thus "f c=RELAT-1R2 g"
        using relat_1_def_3 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem finseq_1_sch_1:
  fixes Af0 Pp2 
  assumes
[ty]: "Af0 be NatNAT-1M1" and
   A1: " for k be NatNAT-1M1 holds k inTARSKIR2 SegFINSEQ-1K2 Af0 implies ( ex x be objectHIDDENM1 st Pp2(k,x))"
  shows " ex p be FinSequenceFINSEQ-1M1 st domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 Af0 & ( for k be NatNAT-1M1 holds k inTARSKIR2 SegFINSEQ-1K2 Af0 implies Pp2(k,p .FUNCT-1K1 k))"
  proof-
    have " ex tVar6 be FinSequenceFINSEQ-1M1 st domFINSEQ-1K5 tVar6 =XBOOLE-0R4 SegFINSEQ-1K2 Af0 & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 SegFINSEQ-1K2 Af0 &  not Pp2(k,tVar6 .FUNCT-1K1 k)))"
    proof-
      have A2: " for x be objectHIDDENM1 holds x inHIDDENR3 SegFINSEQ-1K2 Af0 implies ( ex y be objectHIDDENM1 st Pp2(x,y))"
        using A1 sorry
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A3: "domRELAT-1K1 f =XBOOLE-0R4 SegFINSEQ-1K2 Af0 & ( for x be objectHIDDENM1 holds x inHIDDENR3 SegFINSEQ-1K2 Af0 implies Pp2(x,f .FUNCT-1K1 x))"
        using classes1_sch_1 A2 sorry
      obtain p where 
        [ty]:"p be FinSequenceFINSEQ-1M1" and pDef:"p = f"
        using A3 finseq_1_def_2 sorry
      show " ex tVar6 be FinSequenceFINSEQ-1M1 st domFINSEQ-1K5 tVar6 =XBOOLE-0R4 SegFINSEQ-1K2 Af0 & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 SegFINSEQ-1K2 Af0 &  not Pp2(k,tVar6 .FUNCT-1K1 k)))"
      proof(rule bexI[of _ "p"])
        show "domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 Af0 & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 SegFINSEQ-1K2 Af0 &  not Pp2(k,p .FUNCT-1K1 k)))"
          using A3 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem finseq_1_sch_2:
  fixes Af0 Ff1 
  assumes
[ty]: "Af0 be NatNAT-1M1" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1"
  shows " ex p be FinSequenceFINSEQ-1M1 st lenFINSEQ-1K4 p =XBOOLE-0R4 Af0 & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p implies p .FUNCT-1K1 k =HIDDENR1 Ff1(k))"
  proof-
    have " ex tVar7 be FinSequenceFINSEQ-1M1 st lenFINSEQ-1K4 tVar7 =XBOOLE-0R4 Af0 & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 domFINSEQ-1K5 tVar7 &  not tVar7 .FUNCT-1K1 k =HIDDENR1 Ff1(k)))"
    proof-
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A1: "domRELAT-1K1 f =XBOOLE-0R4 SegFINSEQ-1K2 Af0 & ( for x be objectHIDDENM1 holds x inHIDDENR3 SegFINSEQ-1K2 Af0 implies f .FUNCT-1K1 x =HIDDENR1 Ff1(x))"
        using funct_1_sch_3 sorry
      have A2: "Af0 inTARSKIR2 NATNUMBERSK1"
        using ordinal1_def_12 sorry
      obtain p where 
        [ty]:"p be FinSequenceFINSEQ-1M1" and pDef:"p = f"
        using A1 finseq_1_def_2 sorry
      show " ex tVar7 be FinSequenceFINSEQ-1M1 st lenFINSEQ-1K4 tVar7 =XBOOLE-0R4 Af0 & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 domFINSEQ-1K5 tVar7 &  not tVar7 .FUNCT-1K1 k =HIDDENR1 Ff1(k)))"
      proof(rule bexI[of _ "p"])
        show "lenFINSEQ-1K4 p =XBOOLE-0R4 Af0 & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 domFINSEQ-1K5 p &  not p .FUNCT-1K1 k =HIDDENR1 Ff1(k)))"
          using A1 A2 finseq_1_def_3 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem finseq_1_th_12:
" for z be objectHIDDENM1 holds  for p be FinSequenceFINSEQ-1M1 holds z inHIDDENR3 p implies ( ex k be NatNAT-1M1 st k inTARSKIR2 domFINSEQ-1K5 p & z =HIDDENR1 [TARSKIK4 k,p .FUNCT-1K1 k ])"
proof-
  have " for z be objectHIDDENM1 holds  for p be FinSequenceFINSEQ-1M1 holds z inHIDDENR3 p implies ( ex tVar8 be NatNAT-1M1 st tVar8 inTARSKIR2 domFINSEQ-1K5 p & z =HIDDENR1 [TARSKIK4 tVar8,p .FUNCT-1K1 tVar8 ])"
  proof(rule ballI,rule ballI,rule impI)
    fix z assume [ty]: "z be objectHIDDENM1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    assume A1: "z inHIDDENR3 p"
    then obtain x y where
      [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
      A2: "z =HIDDENR1 [TARSKIK4 x,y ]"
      using relat_1_def_1 sorry
    have "x inHIDDENR3 domFINSEQ-1K5 p"
      using A1 A2 funct_1_th_1 sorry
    then obtain k where 
      [ty]:"k be NatNAT-1M1" and kDef:"k = x"
       sorry
    show " ex tVar8 be NatNAT-1M1 st tVar8 inTARSKIR2 domFINSEQ-1K5 p & z =HIDDENR1 [TARSKIK4 tVar8,p .FUNCT-1K1 tVar8 ]"
    proof(rule bexI[of _ "k"])
      show "k inTARSKIR2 domFINSEQ-1K5 p & z =HIDDENR1 [TARSKIK4 k,p .FUNCT-1K1 k ]"
        using A1 A2 funct_1_th_1 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_13:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds domFINSEQ-1K5 p =XBOOLE-0R4 domFINSEQ-1K5 q & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p implies p .FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 k) implies p =FUNCT-1R1 q"
   sorry

mtheorem finseq_1_th_14:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 p implies p .FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 k) implies p =FUNCT-1R1 q"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 p implies p .FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 k) implies p =FUNCT-1R1 q"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    assume A1: "lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q"
      and A2: " for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 p implies p .FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 k"
    have A3: "domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
      using finseq_1_def_3 sorry
    have A4: "domFINSEQ-1K5 q =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
      using finseq_1_def_3 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domFINSEQ-1K5 p implies p .FUNCT-1K1 x =XBOOLE-0R4 q .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A5: "x inHIDDENR3 domFINSEQ-1K5 p"
      then obtain k where 
        [ty]:"k be NatNAT-1M1" and kDef:"k = x"
         sorry
      have "\<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 p"
        using A3 A5 finseq_1_th_1 sorry
      thus "p .FUNCT-1K1 x =XBOOLE-0R4 q .FUNCT-1K1 x"
        using A2 sorry
    qed "sorry"
    thus "p =FUNCT-1R1 q"
      using A1 A3 A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_15:
" for a be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for p be FinSequenceFINSEQ-1M1 holds p  |RELAT-1K8 SegFINSEQ-1K1 a be FinSequenceFINSEQ-1M1"
proof-
  have " for a be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for p be FinSequenceFINSEQ-1M1 holds p  |RELAT-1K8 SegFINSEQ-1K1 a be FinSequenceFINSEQ-1M1"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    have A0: "a be NatNAT-1M1"
      using tarski_th_1 sorry
    have A1: "domRELAT-1K1 (p  |RELAT-1K8 SegFINSEQ-1K1 a) =HIDDENR1 domFINSEQ-1K5 p /\\SUBSET-1K8\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K1 a"
      using relat_1_th_61 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 p) /\\SUBSET-1K8\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K1 a"
      using finseq_1_def_3 sorry
    finally have "domRELAT-1K1 (p  |RELAT-1K8 SegFINSEQ-1K1 a) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 p) /\\SUBSET-1K8\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K1 a"
       sorry
    have "lenFINSEQ-1K4 p <=XXREAL-0R1 a or a <=XXREAL-0R1 lenFINSEQ-1K4 p"
       sorry
    then have "domRELAT-1K1 (p  |RELAT-1K8 SegFINSEQ-1K1 a) =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p) or domRELAT-1K1 (p  |RELAT-1K8 SegFINSEQ-1K1 a) =XBOOLE-0R4 SegFINSEQ-1K1 a"
      using A1 finseq_1_th_5 xboole_1_th_28 sorry
    thus "p  |RELAT-1K8 SegFINSEQ-1K1 a be FinSequenceFINSEQ-1M1"
      using A0 finseq_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_16:
" for f be FunctionFUNCT-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds rngFUNCT-1K2 p c=TARSKIR1 domRELAT-1K1 f implies f *FUNCT-1K3 p be FinSequenceFINSEQ-1M1"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds rngFUNCT-1K2 p c=TARSKIR1 domRELAT-1K1 f implies f *FUNCT-1K3 p be FinSequenceFINSEQ-1M1"
  proof(rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    assume "rngFUNCT-1K2 p c=TARSKIR1 domRELAT-1K1 f"
    then have "domRELAT-1K1 (f *FUNCT-1K3 p) =HIDDENR1 domFINSEQ-1K5 p"
      using relat_1_th_27 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
      using finseq_1_def_3 sorry
    finally have "domRELAT-1K1 (f *FUNCT-1K3 p) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
       sorry
    thus "f *FUNCT-1K3 p be FinSequenceFINSEQ-1M1"
      using finseq_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_17:
" for a be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds a <=XXREAL-0R1 lenFINSEQ-1K4 p & q =FUNCT-1R1 p  |RELAT-1K8 SegFINSEQ-1K1 a implies lenFINSEQ-1K4 q =HIDDENR1 a & domFINSEQ-1K5 q =XBOOLE-0R4 SegFINSEQ-1K1 a"
proof-
  have " for a be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds a <=XXREAL-0R1 lenFINSEQ-1K4 p & q =FUNCT-1R1 p  |RELAT-1K8 SegFINSEQ-1K1 a implies lenFINSEQ-1K4 q =HIDDENR1 a & domFINSEQ-1K5 q =XBOOLE-0R4 SegFINSEQ-1K1 a"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    assume A1: "a <=XXREAL-0R1 lenFINSEQ-1K4 p"
      and A2: "q =FUNCT-1R1 p  |RELAT-1K8 SegFINSEQ-1K1 a"
    have "SegFINSEQ-1K1 a c=TARSKIR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
      using A1 finseq_1_th_5 sorry
    then have "SegFINSEQ-1K1 a c=TARSKIR1 domFINSEQ-1K5 p"
      using finseq_1_def_3 sorry
    then have "a inHIDDENR3 NATNUMBERSK1 & domFINSEQ-1K5 q =XBOOLE-0R4 SegFINSEQ-1K1 a"
      using A2 ordinal1_def_12 relat_1_th_62 sorry
    thus "lenFINSEQ-1K4 q =HIDDENR1 a & domFINSEQ-1K5 q =XBOOLE-0R4 SegFINSEQ-1K1 a"
      using finseq_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef finseq_1_def_4 ("FinSequenceFINSEQ-1M2-of  _ " [70]70 ) where
  mlet "D be setHIDDENM2"
"mode FinSequenceFINSEQ-1M2-of D \<rightarrow> FinSequenceFINSEQ-1M1 means
  (\<lambda>it. rngFUNCT-1K2 it c=TARSKIR1 D)"
proof-
  (*existence*)
    show " ex it be FinSequenceFINSEQ-1M1 st rngFUNCT-1K2 it c=TARSKIR1 D"
    proof-
      have " not ( for VarFor1 be FinSequenceFINSEQ-1M1 holds  not rngFUNCT-1K2 VarFor1 c=TARSKIR1 D)"
      proof-
        have "rngFUNCT-1K2 ({}XBOOLE-0K1) c=RELAT-1R2 D"
           sorry
        thus " not ( for VarFor1 be FinSequenceFINSEQ-1M1 holds  not rngFUNCT-1K2 VarFor1 c=TARSKIR1 D)"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem finseq_1_cl_7:
  mlet "D be setHIDDENM2"
"cluster note-that D -valuedRELAT-1V5 for FinSequenceFINSEQ-1M2-of D"
proof
(*coherence*)
  show " for it be FinSequenceFINSEQ-1M2-of D holds it be D -valuedRELAT-1V5"
  proof-
    have " for f be FinSequenceFINSEQ-1M2-of D holds f be D -valuedRELAT-1V5"
    proof(rule ballI)
      fix f assume [ty]: "f be FinSequenceFINSEQ-1M2-of D"
      have "rngFUNCT-1K2 f c=TARSKIR1 D"
      proof-
        show "rngFUNCT-1K2 f c=TARSKIR1 D"
          using finseq_1_def_4 sorry
      qed
      thus "f be D -valuedRELAT-1V5"
        using relat_1_def_19 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mlemma finseq_1_lm_2:
" for D be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M2-of D holds f be PartFuncPARTFUN1M1-of(NATNUMBERSK1,D)"
proof(rule ballI,rule ballI)
  fix D assume [ty]: "D be setHIDDENM2"
  fix f assume [ty]: "f be FinSequenceFINSEQ-1M2-of D"
  have "domFINSEQ-1K5 f c=TARSKIR1 NATNUMBERSK1 & rngFUNCT-1K2 f c=TARSKIR1 D"
    using finseq_1_def_4 sorry
  thus "f be PartFuncPARTFUN1M1-of(NATNUMBERSK1,D)"
    using relset_1_th_4 sorry
qed "sorry"

mtheorem finseq_1_cl_8:
"cluster emptyXBOOLE-0V1 also-is FinSequence-likeFINSEQ-1V1 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be emptyXBOOLE-0V1 implies it be FinSequence-likeFINSEQ-1V1"
     sorry
qed "sorry"

mtheorem finseq_1_cl_9:
  mlet "D be setHIDDENM2"
"cluster FinSequence-likeFINSEQ-1V1 for PartFuncPARTFUN1M1-of(NATNUMBERSK1,D)"
proof
(*existence*)
  show " ex it be PartFuncPARTFUN1M1-of(NATNUMBERSK1,D) st it be FinSequence-likeFINSEQ-1V1"
  proof-
    have " not ( for VarFor1 be PartFuncPARTFUN1M1-of(NATNUMBERSK1,D) holds  not VarFor1 be FinSequence-likeFINSEQ-1V1)"
    proof-
      have "{}XBOOLE-0K1 be PartFuncPARTFUN1M1-of(NATNUMBERSK1,D)"
        using relset_1_th_12 sorry
      thus " not ( for VarFor1 be PartFuncPARTFUN1M1-of(NATNUMBERSK1,D) holds  not VarFor1 be FinSequence-likeFINSEQ-1V1)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

abbreviation(input) FINSEQ_1M3("FinSequenceFINSEQ-1M3-of  _ " [70]70) where
  "FinSequenceFINSEQ-1M3-of D \<equiv> FinSequenceFINSEQ-1M2-of D"

mtheorem finseq_1_add_4:
  mlet "D be setHIDDENM2"
"cluster note-that FinSequence-likeFINSEQ-1V1\<bar>PartFuncPARTFUN1M1-of(NATNUMBERSK1,D) for FinSequenceFINSEQ-1M2-of D"
proof
(*coherence*)
  show " for it be FinSequenceFINSEQ-1M2-of D holds it be FinSequence-likeFINSEQ-1V1\<bar>PartFuncPARTFUN1M1-of(NATNUMBERSK1,D)"
    using finseq_1_lm_2 sorry
qed "sorry"

reserve D for "setHIDDENM2"
mtheorem finseq_1_th_18:
" for a be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for D be setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M3-of D holds p  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,D)\<^esub> SegFINSEQ-1K1 a be FinSequenceFINSEQ-1M3-of D"
proof-
  have " for a be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for D be setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M3-of D holds p  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,D)\<^esub> SegFINSEQ-1K1 a be FinSequenceFINSEQ-1M3-of D"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix D assume [ty]: "D be setHIDDENM2"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of D"
    have A1: "p  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,D)\<^esub> SegFINSEQ-1K1 a be FinSequenceFINSEQ-1M1"
      using finseq_1_th_15 sorry
    have "rngFUNCT-1K2 (p  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,D)\<^esub> SegFINSEQ-1K1 a) c=TARSKIR1 rngFUNCT-1K2 p & rngFUNCT-1K2 p c=TARSKIR1 D"
      using finseq_1_def_4 relat_1_th_70 sorry
    thus "p  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,D)\<^esub> SegFINSEQ-1K1 a be FinSequenceFINSEQ-1M3-of D"
      using A1 finseq_1_def_4 xboole_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_19:
" for a be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  ex p be FinSequenceFINSEQ-1M3-of D st lenFINSEQ-1K4 p =HIDDENR1 a"
proof-
  have " for a be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  ex tVar9 be FinSequenceFINSEQ-1M3-of D st lenFINSEQ-1K4 tVar9 =HIDDENR1 a"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    have 
      [ty]:"a be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    let ?y = "the ElementSUBSET-1M1-of D"
    let ?p = "SegFINSEQ-1K2 a -->FUNCOP-1K8\<^bsub>(D)\<^esub> ?y"
    have A1: "domRELAT-1K1 ?p =XBOOLE-0R4 SegFINSEQ-1K2 a"
      using funcop_1_th_13 sorry
    then obtain p where 
      [ty]:"p be FinSequenceFINSEQ-1M1" and pDef:"p = ?p"
      using finseq_1_def_2 sorry
    have "rngFUNCT-1K2 p c=TARSKIR1 {TARSKIK1 ?y} & {TARSKIK1 ?y} c=TARSKIR1 D"
      using funcop_1_th_13 zfmisc_1_th_31 sorry
    then obtain q where 
      [ty]:"q be FinSequenceFINSEQ-1M3-of D" and qDef:"q = p"
      using finseq_1_def_4 xboole_1_th_1 sorry
    show " ex tVar9 be FinSequenceFINSEQ-1M3-of D st lenFINSEQ-1K4 tVar9 =HIDDENR1 a"
    proof(rule bexI[of _ "q"])
      show "lenFINSEQ-1K4 q =HIDDENR1 a"
        using A1 finseq_1_def_3 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma finseq_1_lm_3:
" for q be FinSequenceFINSEQ-1M1 holds q =FUNCT-1R1 {}XBOOLE-0K1 iff lenFINSEQ-1K4 q =XBOOLE-0R4 0NUMBERSK6"
   sorry

mtheorem finseq_1_th_20:
" for p be FinSequenceFINSEQ-1M1 holds p <>HIDDENR2 {}XBOOLE-0K1 iff lenFINSEQ-1K4 p >=XXREAL-0R2 \<one>\<^sub>M"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds (p <>HIDDENR2 {}XBOOLE-0K1 implies lenFINSEQ-1K4 p >=XXREAL-0R2 \<one>\<^sub>M) & (lenFINSEQ-1K4 p >=XXREAL-0R2 \<one>\<^sub>M implies  not p <>HIDDENR2 {}XBOOLE-0K1)"
  proof(rule ballI,rule conjMI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    show "p <>HIDDENR2 {}XBOOLE-0K1 implies lenFINSEQ-1K4 p >=XXREAL-0R2 \<one>\<^sub>M"
    proof(rule impI)
      assume "p <>HIDDENR2 {}XBOOLE-0K1"
      then have "lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
        using xreal_1_th_8 sorry
      thus "lenFINSEQ-1K4 p >=XXREAL-0R2 \<one>\<^sub>M"
        using nat_1_th_13 sorry
    qed
    assume "lenFINSEQ-1K4 p >=XXREAL-0R2 \<one>\<^sub>M"
    thus " not p <>HIDDENR2 {}XBOOLE-0K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef finseq_1_def_5 ("<*FINSEQ-1K6  _ *>" [0]164 ) where
  mlet "x be objectHIDDENM1"
"func <*FINSEQ-1K6 x*> \<rightarrow> setHIDDENM2 equals
  {TARSKIK1 [TARSKIK4 \<one>\<^sub>M,x ] }"
proof-
  (*coherence*)
    show "{TARSKIK1 [TARSKIK4 \<one>\<^sub>M,x ] } be setHIDDENM2"
       sorry
qed "sorry"

mdef finseq_1_def_6 ("<*>FINSEQ-1K7  _ " [354]354 ) where
  mlet "D be setHIDDENM2"
"func <*>FINSEQ-1K7 D \<rightarrow> FinSequenceFINSEQ-1M3-of D equals
  {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "{}XBOOLE-0K1 be FinSequenceFINSEQ-1M3-of D"
    proof-
      have "rngFUNCT-1K2 ({}XBOOLE-0K1) c=RELAT-1R2 D"
         sorry
      thus "{}XBOOLE-0K1 be FinSequenceFINSEQ-1M3-of D"
        using finseq_1_def_4 sorry
    qed
qed "sorry"

mtheorem finseq_1_cl_10:
  mlet "D be setHIDDENM2"
"cluster <*>FINSEQ-1K7 D as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "<*>FINSEQ-1K7 D be emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem finseq_1_cl_11:
  mlet "D be setHIDDENM2"
"cluster emptyXBOOLE-0V1 for FinSequenceFINSEQ-1M3-of D"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M3-of D st it be emptyXBOOLE-0V1"
  proof-
    have " ex tVar10 be FinSequenceFINSEQ-1M3-of D st tVar10 be emptyXBOOLE-0V1"
    proof-
      show " ex tVar10 be FinSequenceFINSEQ-1M3-of D st tVar10 be emptyXBOOLE-0V1"
      proof(rule bexI[of _ "<*>FINSEQ-1K7 D"])
        show "<*>FINSEQ-1K7 D be emptyXBOOLE-0V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef finseq_1_def_7 (" _ ^FINSEQ-1K8  _ " [164,164]164 ) where
  mlet "p be FinSequenceFINSEQ-1M1", "q be FinSequenceFINSEQ-1M1"
"func p ^FINSEQ-1K8 q \<rightarrow> FinSequenceFINSEQ-1M1 means
  \<lambda>it. (domFINSEQ-1K5 it =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q) & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p implies it .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k)) & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 q implies it .FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 k) =XBOOLE-0R4 q .FUNCT-1K1 k)"
proof-
  (*existence*)
    show " ex it be FinSequenceFINSEQ-1M1 st (domFINSEQ-1K5 it =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q) & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p implies it .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k)) & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 q implies it .FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 k) =XBOOLE-0R4 q .FUNCT-1K1 k)"
    proof-
      have " ex tVar11 be FinSequenceFINSEQ-1M1 st (domFINSEQ-1K5 tVar11 =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q) & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 domFINSEQ-1K5 p &  not tVar11 .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k))) & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 domFINSEQ-1K5 q &  not tVar11 .FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 k) =XBOOLE-0R4 q .FUNCT-1K1 k))"
      proof-
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. ( for k be NatNAT-1M1 holds (k =HIDDENR1 Lamb1 & \<one>\<^sub>M <=XXREAL-0R1 k) & k <=XXREAL-0R1 lenFINSEQ-1K4 p implies Lamb2 =HIDDENR1 p .FUNCT-1K1 k) & ( for k be NatNAT-1M1 holds (k =HIDDENR1 Lamb1 & lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k) & k <=XXREAL-0R1 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q implies Lamb2 =HIDDENR1 q .FUNCT-1K1 (k -XCMPLX-0K6 lenFINSEQ-1K4 p))"
        have A1: " for x be objectHIDDENM1 holds x inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q) implies ( ex y be objectHIDDENM1 st ?P(x,y))"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q) implies  not ( for y be objectHIDDENM1 holds  not (( for k be NatNAT-1M1 holds (k =HIDDENR1 x & \<one>\<^sub>M <=XXREAL-0R1 k) & k <=XXREAL-0R1 lenFINSEQ-1K4 p implies y =HIDDENR1 p .FUNCT-1K1 k) & ( for k be NatNAT-1M1 holds (k =HIDDENR1 x & lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k) & k <=XXREAL-0R1 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q implies y =HIDDENR1 q .FUNCT-1K1 (k -XCMPLX-0K6 lenFINSEQ-1K4 p))))"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q)"
            then obtain m where 
              [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and mDef:"m = x"
               sorry
            have A2: "lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m implies  not ( for y be objectHIDDENM1 holds  not (( for k be NatNAT-1M1 holds (k =HIDDENR1 x & \<one>\<^sub>M <=XXREAL-0R1 k) & k <=XXREAL-0R1 lenFINSEQ-1K4 p implies y =HIDDENR1 p .FUNCT-1K1 k) & ( for k be NatNAT-1M1 holds (k =HIDDENR1 x & lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k) & k <=XXREAL-0R1 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q implies y =HIDDENR1 q .FUNCT-1K1 (k -XCMPLX-0K6 lenFINSEQ-1K4 p))))"
            proof(rule impI)
              assume A3: "lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m"
              let ?y = "q .FUNCT-1K1 (m -XCMPLX-0K6 lenFINSEQ-1K4 p)"
              have A4: " for k be NatNAT-1M1 holds (k =HIDDENR1 x & \<one>\<^sub>M <=XXREAL-0R1 k) & k <=XXREAL-0R1 lenFINSEQ-1K4 p implies ?y =XBOOLE-0R4 p .FUNCT-1K1 k"
              proof-
                have " for k be NatNAT-1M1 holds k =HIDDENR1 x & (\<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 p) implies q .FUNCT-1K1 (m -XCMPLX-0K6 lenFINSEQ-1K4 p) =XBOOLE-0R4 p .FUNCT-1K1 k"
                proof(rule ballI,rule impMI ,rule impMI ,rule impI)
                  fix k assume [ty]: "k be NatNAT-1M1"
                  assume A5: "k =HIDDENR1 x"
                    and "\<one>\<^sub>M <=XXREAL-0R1 k"
                    and A6: "k <=XXREAL-0R1 lenFINSEQ-1K4 p"
                  have "m +NAT-1K1 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 m +NAT-1K1 lenFINSEQ-1K4 p"
                    using A3 A5 A6 xreal_1_th_7 sorry
                  then have "(m +NAT-1K1 lenFINSEQ-1K4 p)+NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 (m +NAT-1K1 lenFINSEQ-1K4 p)+NAT-1K1 0NUMBERSK6"
                     sorry
                  thus "q .FUNCT-1K1 (m -XCMPLX-0K6 lenFINSEQ-1K4 p) =XBOOLE-0R4 p .FUNCT-1K1 k"
                    using xreal_1_th_6 sorry
                qed "sorry"
                thus " ?thesis "
                   sorry
              qed
              have " for k be NatNAT-1M1 holds (k =HIDDENR1 x & lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k) & k <=XXREAL-0R1 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q implies ?y =XBOOLE-0R4 q .FUNCT-1K1 (k -XCMPLX-0K6 lenFINSEQ-1K4 p)"
                 sorry
              thus " not ( for y be objectHIDDENM1 holds  not (( for k be NatNAT-1M1 holds (k =HIDDENR1 x & \<one>\<^sub>M <=XXREAL-0R1 k) & k <=XXREAL-0R1 lenFINSEQ-1K4 p implies y =HIDDENR1 p .FUNCT-1K1 k) & ( for k be NatNAT-1M1 holds (k =HIDDENR1 x & lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k) & k <=XXREAL-0R1 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q implies y =HIDDENR1 q .FUNCT-1K1 (k -XCMPLX-0K6 lenFINSEQ-1K4 p))))"
                using A4 sorry
            qed
            have " not lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m implies  not ( for y be objectHIDDENM1 holds  not (( for k be NatNAT-1M1 holds (k =HIDDENR1 x & \<one>\<^sub>M <=XXREAL-0R1 k) & k <=XXREAL-0R1 lenFINSEQ-1K4 p implies y =HIDDENR1 p .FUNCT-1K1 k) & ( for k be NatNAT-1M1 holds (k =HIDDENR1 x & lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k) & k <=XXREAL-0R1 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q implies y =HIDDENR1 q .FUNCT-1K1 (k -XCMPLX-0K6 lenFINSEQ-1K4 p))))"
            proof(rule impI)
              assume A7: " not lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m"
              let ?y = "p .FUNCT-1K1 m"
              have "( for k be NatNAT-1M1 holds (k =HIDDENR1 x & \<one>\<^sub>M <=XXREAL-0R1 k) & k <=XXREAL-0R1 lenFINSEQ-1K4 p implies ?y =XBOOLE-0R4 p .FUNCT-1K1 k) & ( for k be NatNAT-1M1 holds (k =HIDDENR1 x & lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k) & k <=XXREAL-0R1 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q implies ?y =XBOOLE-0R4 q .FUNCT-1K1 (k -XCMPLX-0K6 lenFINSEQ-1K4 p))"
                using A7 sorry
              thus " not ( for y be objectHIDDENM1 holds  not (( for k be NatNAT-1M1 holds (k =HIDDENR1 x & \<one>\<^sub>M <=XXREAL-0R1 k) & k <=XXREAL-0R1 lenFINSEQ-1K4 p implies y =HIDDENR1 p .FUNCT-1K1 k) & ( for k be NatNAT-1M1 holds (k =HIDDENR1 x & lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k) & k <=XXREAL-0R1 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q implies y =HIDDENR1 q .FUNCT-1K1 (k -XCMPLX-0K6 lenFINSEQ-1K4 p))))"
                 sorry
            qed
            thus " not ( for y be objectHIDDENM1 holds  not (( for k be NatNAT-1M1 holds (k =HIDDENR1 x & \<one>\<^sub>M <=XXREAL-0R1 k) & k <=XXREAL-0R1 lenFINSEQ-1K4 p implies y =HIDDENR1 p .FUNCT-1K1 k) & ( for k be NatNAT-1M1 holds (k =HIDDENR1 x & lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k) & k <=XXREAL-0R1 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q implies y =HIDDENR1 q .FUNCT-1K1 (k -XCMPLX-0K6 lenFINSEQ-1K4 p))))"
              using A2 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain f where
          [ty]:"f be FunctionFUNCT-1M1" and 
          A8: "domRELAT-1K1 f =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q) & ( for x be objectHIDDENM1 holds x inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q) implies ?P(x,f .FUNCT-1K1 x))"
          using classes1_sch_1 A1 sorry
        have A9: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p implies f .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k"
        proof(rule ballI,rule impI)
          fix k assume [ty]: "k be NatNAT-1M1"
          assume "k inTARSKIR2 domFINSEQ-1K5 p"
          then have A10: "k inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
            using finseq_1_def_3 sorry
          then have A11: "\<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 p"
            using finseq_1_th_1 sorry
          have "SegFINSEQ-1K2 (lenFINSEQ-1K4 p) c=TARSKIR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q)"
            using finseq_1_th_5 nat_1_th_11 sorry
          thus "f .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k"
            using A8 A10 A11 sorry
        qed "sorry"
        have A12: " for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 q implies f .FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 n) =XBOOLE-0R4 q .FUNCT-1K1 n"
        proof(rule ballI,rule impI)
          fix n assume [ty]: "n be NatNAT-1M1"
          assume "n inTARSKIR2 domFINSEQ-1K5 q"
          then have A13: "n inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
            using finseq_1_def_3 sorry
          then have A14: "\<one>\<^sub>M <=XXREAL-0R1 n"
            using finseq_1_th_1 sorry
          have A15: "n <=XXREAL-0R1 lenFINSEQ-1K4 q"
            using A13 finseq_1_th_1 sorry
          have A16: "lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p +XCMPLX-0K2 n"
            using A14 xreal_1_th_7 sorry
          have A17: "lenFINSEQ-1K4 p +XCMPLX-0K2 n <=XXREAL-0R1 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q"
            using A15 xreal_1_th_7 sorry
          have "lenFINSEQ-1K4 p +XCMPLX-0K2 n <=XXREAL-0R1 (lenFINSEQ-1K4 p +XCMPLX-0K2 n)+NAT-1K1 lenFINSEQ-1K4 p"
            using nat_1_th_11 sorry
          then have "lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 (lenFINSEQ-1K4 p +XCMPLX-0K2 n)+NAT-1K1 lenFINSEQ-1K4 p"
            using A16 xxreal_0_th_2 sorry
          then have "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p +XCMPLX-0K2 n"
            using xreal_1_th_6 sorry
          then have "lenFINSEQ-1K4 p +XCMPLX-0K2 n inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q)"
            using A17 sorry
          then have "f .FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 n) =XBOOLE-0R4 q .FUNCT-1K1 ((n +NAT-1K1 lenFINSEQ-1K4 p)-XCMPLX-0K6 lenFINSEQ-1K4 p)"
            using A8 A16 A17 sorry
          thus "f .FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 n) =XBOOLE-0R4 q .FUNCT-1K1 n"
             sorry
        qed "sorry"
        obtain r where 
          [ty]:"r be FinSequenceFINSEQ-1M1" and rDef:"r = f"
          using A8 finseq_1_def_2 sorry
        show " ex tVar11 be FinSequenceFINSEQ-1M1 st (domFINSEQ-1K5 tVar11 =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q) & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 domFINSEQ-1K5 p &  not tVar11 .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k))) & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 domFINSEQ-1K5 q &  not tVar11 .FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 k) =XBOOLE-0R4 q .FUNCT-1K1 k))"
        proof(rule bexI[of _ "r"])
          show "(domFINSEQ-1K5 r =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q) & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 domFINSEQ-1K5 p &  not r .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k))) & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 domFINSEQ-1K5 q &  not r .FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 k) =XBOOLE-0R4 q .FUNCT-1K1 k))"
            using A8 A9 A12 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FinSequenceFINSEQ-1M1 holds  for it2 be FinSequenceFINSEQ-1M1 holds ((domFINSEQ-1K5 it1 =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q) & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p implies it1 .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k)) & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 q implies it1 .FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 k) =XBOOLE-0R4 q .FUNCT-1K1 k)) & ((domFINSEQ-1K5 it2 =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q) & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p implies it2 .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k)) & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 q implies it2 .FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 k) =XBOOLE-0R4 q .FUNCT-1K1 k)) implies it1 =HIDDENR1 it2"
    proof-
      have " for f be FinSequenceFINSEQ-1M1 holds  for g be FinSequenceFINSEQ-1M1 holds domFINSEQ-1K5 f =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q) & (( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p implies f .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k) & (( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 q implies f .FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 k) =XBOOLE-0R4 q .FUNCT-1K1 k) & (domFINSEQ-1K5 g =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q) & (( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p implies g .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k) & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 q implies g .FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 k) =XBOOLE-0R4 q .FUNCT-1K1 k))))) implies f =HIDDENR1 g"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
        fix g assume [ty]: "g be FinSequenceFINSEQ-1M1"
        assume A18: "domFINSEQ-1K5 f =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q)"
          and A19: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p implies f .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k"
          and A20: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 q implies f .FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 k) =XBOOLE-0R4 q .FUNCT-1K1 k"
          and A21: "domFINSEQ-1K5 g =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q)"
          and A22: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p implies g .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k"
          and A23: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 q implies g .FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 k) =XBOOLE-0R4 q .FUNCT-1K1 k"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q) implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A24: "x inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q)"
          then obtain k where 
            [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = x"
             sorry
          have A25: "\<one>\<^sub>M <=XXREAL-0R1 k"
            using A24 finseq_1_th_1 sorry
          have A26: "lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
          proof(rule impI)
            assume "lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k"
            then obtain m where
              [ty]:"m be NatNAT-1M1" and 
              A27: "(lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 m =XBOOLE-0R4 k"
              using nat_1_th_10 sorry
            have "lenFINSEQ-1K4 p +XCMPLX-0K2 (\<one>\<^sub>M +XCMPLX-0K2 m) <=XXREAL-0R1 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q"
              using A24 A27 finseq_1_th_1 sorry
            then have "\<one>\<^sub>M +NAT-1K1 0NUMBERSK6 <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 m & \<one>\<^sub>M +XCMPLX-0K2 m <=XXREAL-0R1 lenFINSEQ-1K4 q"
              using xreal_1_th_6 sorry
            then have "\<one>\<^sub>M +XCMPLX-0K2 m inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
               sorry
            then have A28: "\<one>\<^sub>M +XCMPLX-0K2 m inTARSKIR2 domFINSEQ-1K5 q"
              using finseq_1_def_3 sorry
            then have "g .FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 (\<one>\<^sub>M +XCMPLX-0K2 m)) =XBOOLE-0R4 q .FUNCT-1K1 (\<one>\<^sub>M +XCMPLX-0K2 m)"
              using A23 sorry
            thus "f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
              using A20 A27 A28 sorry
          qed
          have " not lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
          proof(rule impI)
            assume " not lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k"
            then have "k <=XXREAL-0R1 lenFINSEQ-1K4 p"
              using nat_1_th_8 sorry
            then have "k inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
              using A25 sorry
            then have A29: "k inTARSKIR2 domFINSEQ-1K5 p"
              using finseq_1_def_3 sorry
            then have "f .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k"
              using A19 sorry
            thus "f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
              using A22 A29 sorry
          qed
          thus "f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
            using A26 sorry
        qed "sorry"
        thus "f =HIDDENR1 g"
          using A18 A21 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem finseq_1_th_21:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds p =FUNCT-1R1 (p ^FINSEQ-1K8 q) |RELAT-1K8 domFINSEQ-1K5 p"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds p =FUNCT-1R1 (p ^FINSEQ-1K8 q) |RELAT-1K8 domFINSEQ-1K5 p"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    have A1: "domFINSEQ-1K5 (p ^FINSEQ-1K8 q) =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q)"
      using finseq_1_def_7 sorry
    have A2: "domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
      using finseq_1_def_3 sorry
    then have A3: "domFINSEQ-1K5 p =XBOOLE-0R4 domFINSEQ-1K5 (p ^FINSEQ-1K8 q) /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
      using A1 finseq_1_th_7 nat_1_th_12 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domFINSEQ-1K5 p implies p .FUNCT-1K1 x =XBOOLE-0R4 (p ^FINSEQ-1K8 q).FUNCT-1K1 x"
      using finseq_1_def_7 sorry
    thus "p =FUNCT-1R1 (p ^FINSEQ-1K8 q) |RELAT-1K8 domFINSEQ-1K5 p"
      using A2 A3 funct_1_th_46 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_22:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 (p ^FINSEQ-1K8 q) =XBOOLE-0R4 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 (p ^FINSEQ-1K8 q) =XBOOLE-0R4 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    have "domFINSEQ-1K5 (p ^FINSEQ-1K8 q) =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q)"
      using finseq_1_def_7 sorry
    thus "lenFINSEQ-1K4 (p ^FINSEQ-1K8 q) =XBOOLE-0R4 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q"
      using finseq_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_23:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for k be NatNAT-1M1 holds lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q implies (p ^FINSEQ-1K8 q).FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 (k -XCMPLX-0K6 lenFINSEQ-1K4 p)"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for k be NatNAT-1M1 holds lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q implies (p ^FINSEQ-1K8 q).FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 (k -XCMPLX-0K6 lenFINSEQ-1K4 p)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    assume A1: "lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k"
      and A2: "k <=XXREAL-0R1 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q"
    obtain m where
      [ty]:"m be NatNAT-1M1" and 
      A3: "(lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 m =XBOOLE-0R4 k"
      using A1 nat_1_th_10 sorry
    have A4: "lenFINSEQ-1K4 p +XCMPLX-0K2 (\<one>\<^sub>M +XCMPLX-0K2 m) =XBOOLE-0R4 k"
      using A3 sorry
    have "\<one>\<^sub>M +XCMPLX-0K2 m =XBOOLE-0R4 k -XCMPLX-0K6 lenFINSEQ-1K4 p"
      using A3 sorry
    then have A5: "\<one>\<^sub>M <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 m"
      using A1 xreal_1_th_19 sorry
    have "k -XCMPLX-0K6 lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 q"
      using A2 xreal_1_th_20 sorry
    then have "\<one>\<^sub>M +XCMPLX-0K2 m inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
      using A3 A5 sorry
    then have "\<one>\<^sub>M +XCMPLX-0K2 m inTARSKIR2 domFINSEQ-1K5 q"
      using finseq_1_def_3 sorry
    thus "(p ^FINSEQ-1K8 q).FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 (k -XCMPLX-0K6 lenFINSEQ-1K4 p)"
      using A4 finseq_1_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_24:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for k be NatNAT-1M1 holds lenFINSEQ-1K4 p <XXREAL-0R3 k & k <=XXREAL-0R1 lenFINSEQ-1K4 (p ^FINSEQ-1K8 q) implies (p ^FINSEQ-1K8 q).FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 (k -XCMPLX-0K6 lenFINSEQ-1K4 p)"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for k be NatNAT-1M1 holds lenFINSEQ-1K4 p <XXREAL-0R3 k & k <=XXREAL-0R1 lenFINSEQ-1K4 (p ^FINSEQ-1K8 q) implies (p ^FINSEQ-1K8 q).FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 (k -XCMPLX-0K6 lenFINSEQ-1K4 p)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    assume "lenFINSEQ-1K4 p <XXREAL-0R3 k & k <=XXREAL-0R1 lenFINSEQ-1K4 (p ^FINSEQ-1K8 q)"
    then have "lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q"
      using finseq_1_th_22 nat_1_th_13 sorry
    thus "(p ^FINSEQ-1K8 q).FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 (k -XCMPLX-0K6 lenFINSEQ-1K4 p)"
      using finseq_1_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_25:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 (p ^FINSEQ-1K8 q) implies k inTARSKIR2 domFINSEQ-1K5 p or ( ex n be NatNAT-1M1 st n inTARSKIR2 domFINSEQ-1K5 q & k =XBOOLE-0R4 lenFINSEQ-1K4 p +XCMPLX-0K2 n)"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 (p ^FINSEQ-1K8 q) implies  not ( not k inTARSKIR2 domFINSEQ-1K5 p & ( for n be NatNAT-1M1 holds  not (n inTARSKIR2 domFINSEQ-1K5 q & k =XBOOLE-0R4 lenFINSEQ-1K4 p +XCMPLX-0K2 n)))"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    assume "k inTARSKIR2 domFINSEQ-1K5 (p ^FINSEQ-1K8 q)"
    then have A1: "k inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 (p ^FINSEQ-1K8 q))"
      using finseq_1_def_3 sorry
    then have A2: "k inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q)"
      using finseq_1_th_22 sorry
    have A3: "k inTARSKIR2 NATNUMBERSK1 & \<one>\<^sub>M <=XXREAL-0R1 k"
      using A1 finseq_1_th_1 sorry
    have A4: " not lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k implies  not ( not k inTARSKIR2 domFINSEQ-1K5 p & ( for n be NatNAT-1M1 holds  not (n inTARSKIR2 domFINSEQ-1K5 q & k =XBOOLE-0R4 lenFINSEQ-1K4 p +XCMPLX-0K2 n)))"
    proof(rule impI)
      assume " not lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k"
      then have "k <=XXREAL-0R1 lenFINSEQ-1K4 p"
        using nat_1_th_8 sorry
      then have "k inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
        using A3 sorry
      thus " not ( not k inTARSKIR2 domFINSEQ-1K5 p & ( for n be NatNAT-1M1 holds  not (n inTARSKIR2 domFINSEQ-1K5 q & k =XBOOLE-0R4 lenFINSEQ-1K4 p +XCMPLX-0K2 n)))"
        using finseq_1_def_3 sorry
    qed
    have "lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k implies  not ( not k inTARSKIR2 domFINSEQ-1K5 p & ( for n be NatNAT-1M1 holds  not (n inTARSKIR2 domFINSEQ-1K5 q & k =XBOOLE-0R4 lenFINSEQ-1K4 p +XCMPLX-0K2 n)))"
    proof(rule impI)
      assume "lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k"
      then obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A5: "k =XBOOLE-0R4 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 n"
        using nat_1_th_10 sorry
      have "lenFINSEQ-1K4 p +XCMPLX-0K2 (\<one>\<^sub>M +XCMPLX-0K2 n) <=XXREAL-0R1 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q"
        using A2 A5 finseq_1_th_1 sorry
      then have A6: "\<one>\<^sub>M +XCMPLX-0K2 n <=XXREAL-0R1 lenFINSEQ-1K4 q"
        using xreal_1_th_6 sorry
      have "\<one>\<^sub>M <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 n"
        using nat_1_th_11 sorry
      then have "\<one>\<^sub>M +XCMPLX-0K2 n inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
        using A6 sorry
      then have A7: "\<one>\<^sub>M +XCMPLX-0K2 n inTARSKIR2 domFINSEQ-1K5 q"
        using finseq_1_def_3 sorry
      have "k =XBOOLE-0R4 lenFINSEQ-1K4 p +XCMPLX-0K2 (\<one>\<^sub>M +XCMPLX-0K2 n)"
        using A5 sorry
      thus " not ( not k inTARSKIR2 domFINSEQ-1K5 p & ( for n be NatNAT-1M1 holds  not (n inTARSKIR2 domFINSEQ-1K5 q & k =XBOOLE-0R4 lenFINSEQ-1K4 p +XCMPLX-0K2 n)))"
        using A7 sorry
    qed
    thus " not ( not k inTARSKIR2 domFINSEQ-1K5 p & ( for n be NatNAT-1M1 holds  not (n inTARSKIR2 domFINSEQ-1K5 q & k =XBOOLE-0R4 lenFINSEQ-1K4 p +XCMPLX-0K2 n)))"
      using A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_26:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds domFINSEQ-1K5 p c=TARSKIR1 domFINSEQ-1K5 (p ^FINSEQ-1K8 q)"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds domFINSEQ-1K5 p c=TARSKIR1 domFINSEQ-1K5 (p ^FINSEQ-1K8 q)"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    have "SegFINSEQ-1K2 (lenFINSEQ-1K4 p) c=TARSKIR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q)"
      using finseq_1_th_5 nat_1_th_11 sorry
    then have "SegFINSEQ-1K2 (lenFINSEQ-1K4 p) c=TARSKIR1 domFINSEQ-1K5 (p ^FINSEQ-1K8 q)"
      using finseq_1_def_7 sorry
    thus "domFINSEQ-1K5 p c=TARSKIR1 domFINSEQ-1K5 (p ^FINSEQ-1K8 q)"
      using finseq_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_27:
" for x be objectHIDDENM1 holds  for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds x inHIDDENR3 domFINSEQ-1K5 q implies ( ex k be NatNAT-1M1 st k =HIDDENR1 x & lenFINSEQ-1K4 p +XCMPLX-0K2 k inTARSKIR2 domFINSEQ-1K5 (p ^FINSEQ-1K8 q))"
proof-
  have " for x be objectHIDDENM1 holds  for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds x inHIDDENR3 domFINSEQ-1K5 q implies ( ex tVar12 be NatNAT-1M1 st tVar12 =HIDDENR1 x & lenFINSEQ-1K4 p +XCMPLX-0K2 tVar12 inTARSKIR2 domFINSEQ-1K5 (p ^FINSEQ-1K8 q))"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    assume A1: "x inHIDDENR3 domFINSEQ-1K5 q"
    then have A2: "x inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
      using finseq_1_def_3 sorry
    obtain k where 
      [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = x"
      using A1 sorry
    show " ex tVar12 be NatNAT-1M1 st tVar12 =HIDDENR1 x & lenFINSEQ-1K4 p +XCMPLX-0K2 tVar12 inTARSKIR2 domFINSEQ-1K5 (p ^FINSEQ-1K8 q)"
    proof(rule bexI[of _ "k"])
      have A3: "\<one>\<^sub>M <=XXREAL-0R1 k"
        using A2 finseq_1_th_1 sorry
      have A4: "k <=XXREAL-0R1 lenFINSEQ-1K4 q"
        using A2 finseq_1_th_1 sorry
      have "k <=XXREAL-0R1 lenFINSEQ-1K4 p +NAT-1K1 k"
        using nat_1_th_11 sorry
      then have A5: "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p +NAT-1K1 k"
        using A3 xxreal_0_th_2 sorry
      have "lenFINSEQ-1K4 p +NAT-1K1 k <=XXREAL-0R1 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q"
        using A4 xreal_1_th_7 sorry
      then have "lenFINSEQ-1K4 p +NAT-1K1 k inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q)"
        using A5 sorry
      thus "k =HIDDENR1 x & lenFINSEQ-1K4 p +XCMPLX-0K2 k inTARSKIR2 domFINSEQ-1K5 (p ^FINSEQ-1K8 q)"
        using finseq_1_def_7 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_28:
" for k be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds k inTARSKIR2 domFINSEQ-1K5 q implies lenFINSEQ-1K4 p +XCMPLX-0K2 k inTARSKIR2 domFINSEQ-1K5 (p ^FINSEQ-1K8 q)"
proof-
  have " for k be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds k inTARSKIR2 domFINSEQ-1K5 q implies lenFINSEQ-1K4 p +XCMPLX-0K2 k inTARSKIR2 domFINSEQ-1K5 (p ^FINSEQ-1K8 q)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    assume "k inTARSKIR2 domFINSEQ-1K5 q"
    then have " ex n be NatNAT-1M1 st n =XBOOLE-0R4 k & lenFINSEQ-1K4 p +XCMPLX-0K2 n inTARSKIR2 domFINSEQ-1K5 (p ^FINSEQ-1K8 q)"
      using finseq_1_th_27 sorry
    thus "lenFINSEQ-1K4 p +XCMPLX-0K2 k inTARSKIR2 domFINSEQ-1K5 (p ^FINSEQ-1K8 q)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_29:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds rngFUNCT-1K2 p c=TARSKIR1 rngFUNCT-1K2 (p ^FINSEQ-1K8 q)"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds rngFUNCT-1K2 p c=TARSKIR1 rngFUNCT-1K2 (p ^FINSEQ-1K8 q)"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p implies x inHIDDENR3 rngFUNCT-1K2 (p ^FINSEQ-1K8 q)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 rngFUNCT-1K2 p"
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A1: "y inHIDDENR3 domFINSEQ-1K5 p"and A2: "x =HIDDENR1 p .FUNCT-1K1 y"
        using funct_1_def_3 sorry
      obtain k where 
        [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = y"
        using A1 sorry
      have A3: "domFINSEQ-1K5 p c=TARSKIR1 domFINSEQ-1K5 (p ^FINSEQ-1K8 q)"
        using finseq_1_th_26 sorry
      have "(p ^FINSEQ-1K8 q).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k"
        using A1 finseq_1_def_7 sorry
      thus "x inHIDDENR3 rngFUNCT-1K2 (p ^FINSEQ-1K8 q)"
        using A1 A2 A3 funct_1_def_3 sorry
    qed "sorry"
    thus "rngFUNCT-1K2 p c=TARSKIR1 rngFUNCT-1K2 (p ^FINSEQ-1K8 q)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_30:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds rngFUNCT-1K2 q c=TARSKIR1 rngFUNCT-1K2 (p ^FINSEQ-1K8 q)"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds rngFUNCT-1K2 q c=TARSKIR1 rngFUNCT-1K2 (p ^FINSEQ-1K8 q)"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 q implies x inHIDDENR3 rngFUNCT-1K2 (p ^FINSEQ-1K8 q)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 rngFUNCT-1K2 q"
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A1: "y inHIDDENR3 domFINSEQ-1K5 q"and A2: "x =HIDDENR1 q .FUNCT-1K1 y"
        using funct_1_def_3 sorry
      obtain k where 
        [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = y"
        using A1 sorry
      have "lenFINSEQ-1K4 p +NAT-1K1 k inTARSKIR2 domFINSEQ-1K5 (p ^FINSEQ-1K8 q) & (p ^FINSEQ-1K8 q).FUNCT-1K1 (lenFINSEQ-1K4 p +NAT-1K1 k) =XBOOLE-0R4 q .FUNCT-1K1 k"
        using A1 finseq_1_def_7 finseq_1_th_28 sorry
      thus "x inHIDDENR3 rngFUNCT-1K2 (p ^FINSEQ-1K8 q)"
        using A2 funct_1_def_3 sorry
    qed "sorry"
    thus "rngFUNCT-1K2 q c=TARSKIR1 rngFUNCT-1K2 (p ^FINSEQ-1K8 q)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_31:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds rngFUNCT-1K2 (p ^FINSEQ-1K8 q) =XBOOLE-0R4 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds rngFUNCT-1K2 (p ^FINSEQ-1K8 q) =XBOOLE-0R4 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (p ^FINSEQ-1K8 q) implies x inHIDDENR3 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 rngFUNCT-1K2 (p ^FINSEQ-1K8 q)"
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A1: "y inHIDDENR3 domFINSEQ-1K5 (p ^FINSEQ-1K8 q)"and A2: "x =HIDDENR1 (p ^FINSEQ-1K8 q).FUNCT-1K1 y"
        using funct_1_def_3 sorry
      have A3: "y inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q)"
        using A1 finseq_1_def_7 sorry
      obtain k where 
        [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = y"
        using A1 sorry
      have A4: "\<one>\<^sub>M <=XXREAL-0R1 k"
        using A3 finseq_1_th_1 sorry
      have A5: "k <=XXREAL-0R1 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q"
        using A3 finseq_1_th_1 sorry
      have A6: "lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k implies x inHIDDENR3 rngFUNCT-1K2 q"
      proof(rule impI)
        assume A7: "lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k"
        then have A8: "q .FUNCT-1K1 (k -XCMPLX-0K6 lenFINSEQ-1K4 p) =HIDDENR1 x"
          using A2 A5 finseq_1_th_23 sorry
        obtain m where
          [ty]:"m be NatNAT-1M1" and 
          A9: "(lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 m =XBOOLE-0R4 k"
          using A7 nat_1_th_10 sorry
        have "lenFINSEQ-1K4 p +XCMPLX-0K2 (\<one>\<^sub>M +XCMPLX-0K2 m) =XBOOLE-0R4 k"
          using A9 sorry
        then have "\<one>\<^sub>M +NAT-1K1 0NUMBERSK6 <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 m & \<one>\<^sub>M +XCMPLX-0K2 m <=XXREAL-0R1 lenFINSEQ-1K4 q"
          using A3 finseq_1_th_1 xreal_1_th_6 sorry
        then have "\<one>\<^sub>M +XCMPLX-0K2 m inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
           sorry
        then have "k -XCMPLX-0K6 lenFINSEQ-1K4 p inTARSKIR2 domFINSEQ-1K5 q"
          using A9 finseq_1_def_3 sorry
        thus "x inHIDDENR3 rngFUNCT-1K2 q"
          using A8 funct_1_def_3 sorry
      qed
      have " not lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k implies x inHIDDENR3 rngFUNCT-1K2 p"
      proof(rule impI)
        assume " not lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k"
        then have "k <=XXREAL-0R1 lenFINSEQ-1K4 p"
          using nat_1_th_8 sorry
        then have "k inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
          using A4 sorry
        then have A10: "k inTARSKIR2 domFINSEQ-1K5 p"
          using finseq_1_def_3 sorry
        then have "p .FUNCT-1K1 k =HIDDENR1 x"
          using A2 finseq_1_def_7 sorry
        thus "x inHIDDENR3 rngFUNCT-1K2 p"
          using A10 funct_1_def_3 sorry
      qed
      thus "x inHIDDENR3 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q"
        using A6 xboole_0_def_3 sorry
    qed "sorry"
    then have A11: "rngFUNCT-1K2 (p ^FINSEQ-1K8 q) c=TARSKIR1 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q"
       sorry
    have "rngFUNCT-1K2 p c=TARSKIR1 rngFUNCT-1K2 (p ^FINSEQ-1K8 q) & rngFUNCT-1K2 q c=TARSKIR1 rngFUNCT-1K2 (p ^FINSEQ-1K8 q)"
      using finseq_1_th_29 finseq_1_th_30 sorry
    then have "rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q c=TARSKIR1 rngFUNCT-1K2 (p ^FINSEQ-1K8 q)"
      using xboole_1_th_8 sorry
    thus "rngFUNCT-1K2 (p ^FINSEQ-1K8 q) =XBOOLE-0R4 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q"
      using A11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_32:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for r be FinSequenceFINSEQ-1M1 holds (p ^FINSEQ-1K8 q)^FINSEQ-1K8 r =FUNCT-1R1 p ^FINSEQ-1K8 (q ^FINSEQ-1K8 r)"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for r be FinSequenceFINSEQ-1M1 holds (p ^FINSEQ-1K8 q)^FINSEQ-1K8 r =FUNCT-1R1 p ^FINSEQ-1K8 (q ^FINSEQ-1K8 r)"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    fix r assume [ty]: "r be FinSequenceFINSEQ-1M1"
    have A1: "domFINSEQ-1K5 ((p ^FINSEQ-1K8 q)^FINSEQ-1K8 r) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 (p ^FINSEQ-1K8 q) +NAT-1K1 lenFINSEQ-1K4 r)"
      using finseq_1_def_7 sorry
    also have "... = SegFINSEQ-1K2 ((lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q)+NAT-1K1 lenFINSEQ-1K4 r)"
      using finseq_1_th_22 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 p +NAT-1K1 (lenFINSEQ-1K4 q +NAT-1K1 lenFINSEQ-1K4 r))"
       sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 (q ^FINSEQ-1K8 r))"
      using finseq_1_th_22 sorry
    finally have "domFINSEQ-1K5 ((p ^FINSEQ-1K8 q)^FINSEQ-1K8 r) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 (q ^FINSEQ-1K8 r))"
       sorry
    have A2: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p implies ((p ^FINSEQ-1K8 q)^FINSEQ-1K8 r).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k"
    proof-
      have " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p implies ((p ^FINSEQ-1K8 q)^FINSEQ-1K8 r).FUNCT-1K1 k =HIDDENR1 p .FUNCT-1K1 k"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A3: "k inTARSKIR2 domFINSEQ-1K5 p"
        have "domFINSEQ-1K5 p c=TARSKIR1 domFINSEQ-1K5 (p ^FINSEQ-1K8 q)"
          using finseq_1_th_26 sorry
        then have "((p ^FINSEQ-1K8 q)^FINSEQ-1K8 r).FUNCT-1K1 k =HIDDENR1 (p ^FINSEQ-1K8 q).FUNCT-1K1 k"
          using A3 finseq_1_def_7 sorry
        also have "... = p .FUNCT-1K1 k"
          using A3 finseq_1_def_7 sorry
        finally show "((p ^FINSEQ-1K8 q)^FINSEQ-1K8 r).FUNCT-1K1 k =HIDDENR1 p .FUNCT-1K1 k"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 (q ^FINSEQ-1K8 r) implies ((p ^FINSEQ-1K8 q)^FINSEQ-1K8 r).FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 k) =XBOOLE-0R4 (q ^FINSEQ-1K8 r).FUNCT-1K1 k"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume A4: "k inTARSKIR2 domFINSEQ-1K5 (q ^FINSEQ-1K8 r)"
      have A5: "k inTARSKIR2 domFINSEQ-1K5 q implies ((p ^FINSEQ-1K8 q)^FINSEQ-1K8 r).FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 k) =HIDDENR1 (q ^FINSEQ-1K8 r).FUNCT-1K1 k"
      proof(rule impI)
        assume A6: "k inTARSKIR2 domFINSEQ-1K5 q"
        then have "lenFINSEQ-1K4 p +XCMPLX-0K2 k inTARSKIR2 domFINSEQ-1K5 (p ^FINSEQ-1K8 q)"
          using finseq_1_th_28 sorry
        then have "((p ^FINSEQ-1K8 q)^FINSEQ-1K8 r).FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 k) =HIDDENR1 (p ^FINSEQ-1K8 q).FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 k)"
          using finseq_1_def_7 sorry
        also have "... = q .FUNCT-1K1 k"
          using A6 finseq_1_def_7 sorry
        also have "... = (q ^FINSEQ-1K8 r).FUNCT-1K1 k"
          using A6 finseq_1_def_7 sorry
        finally show "((p ^FINSEQ-1K8 q)^FINSEQ-1K8 r).FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 k) =HIDDENR1 (q ^FINSEQ-1K8 r).FUNCT-1K1 k"
           sorry
      qed
      have " not k inTARSKIR2 domFINSEQ-1K5 q implies ((p ^FINSEQ-1K8 q)^FINSEQ-1K8 r).FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 k) =HIDDENR1 (q ^FINSEQ-1K8 r).FUNCT-1K1 k"
      proof(rule impI)
        assume " not k inTARSKIR2 domFINSEQ-1K5 q"
        then obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A7: "n inTARSKIR2 domFINSEQ-1K5 r"and A8: "k =XBOOLE-0R4 lenFINSEQ-1K4 q +XCMPLX-0K2 n"
          using A4 finseq_1_th_25 sorry
        have "((p ^FINSEQ-1K8 q)^FINSEQ-1K8 r).FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 k) =HIDDENR1 ((p ^FINSEQ-1K8 q)^FINSEQ-1K8 r).FUNCT-1K1 ((lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q)+XCMPLX-0K2 n)"
          using A8 sorry
        also have "... = ((p ^FINSEQ-1K8 q)^FINSEQ-1K8 r).FUNCT-1K1 (lenFINSEQ-1K4 (p ^FINSEQ-1K8 q) +XCMPLX-0K2 n)"
          using finseq_1_th_22 sorry
        also have "... = r .FUNCT-1K1 n"
          using A7 finseq_1_def_7 sorry
        also have "... = (q ^FINSEQ-1K8 r).FUNCT-1K1 k"
          using A7 A8 finseq_1_def_7 sorry
        finally show "((p ^FINSEQ-1K8 q)^FINSEQ-1K8 r).FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 k) =HIDDENR1 (q ^FINSEQ-1K8 r).FUNCT-1K1 k"
           sorry
      qed
      thus "((p ^FINSEQ-1K8 q)^FINSEQ-1K8 r).FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 k) =XBOOLE-0R4 (q ^FINSEQ-1K8 r).FUNCT-1K1 k"
        using A5 sorry
    qed "sorry"
    thus "(p ^FINSEQ-1K8 q)^FINSEQ-1K8 r =FUNCT-1R1 p ^FINSEQ-1K8 (q ^FINSEQ-1K8 r)"
      using A1 A2 finseq_1_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_33:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for r be FinSequenceFINSEQ-1M1 holds p ^FINSEQ-1K8 r =FUNCT-1R1 q ^FINSEQ-1K8 r or r ^FINSEQ-1K8 p =FUNCT-1R1 r ^FINSEQ-1K8 q implies p =FUNCT-1R1 q"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for r be FinSequenceFINSEQ-1M1 holds p ^FINSEQ-1K8 r =FUNCT-1R1 q ^FINSEQ-1K8 r or r ^FINSEQ-1K8 p =FUNCT-1R1 r ^FINSEQ-1K8 q implies p =FUNCT-1R1 q"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    fix r assume [ty]: "r be FinSequenceFINSEQ-1M1"
    assume A1: "p ^FINSEQ-1K8 r =FUNCT-1R1 q ^FINSEQ-1K8 r or r ^FINSEQ-1K8 p =FUNCT-1R1 r ^FINSEQ-1K8 q"
    have A2: "p ^FINSEQ-1K8 r =FUNCT-1R1 q ^FINSEQ-1K8 r implies p =FUNCT-1R1 q"
    proof(rule impI)
      assume A3: "p ^FINSEQ-1K8 r =FUNCT-1R1 q ^FINSEQ-1K8 r"
      then have "lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 r =XBOOLE-0R4 lenFINSEQ-1K4 (q ^FINSEQ-1K8 r)"
        using finseq_1_th_22 sorry
      then have "lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 r =XBOOLE-0R4 lenFINSEQ-1K4 q +NAT-1K1 lenFINSEQ-1K4 r"
        using finseq_1_th_22 sorry
      then have A4: "domFINSEQ-1K5 p =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
        using finseq_1_def_3 sorry
      also have "... = domFINSEQ-1K5 q"
        using finseq_1_def_3 sorry
      finally have "domFINSEQ-1K5 p =HIDDENR1 domFINSEQ-1K5 q"
         sorry
      have " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p implies p .FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 k"
      proof-
        have " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p implies p .FUNCT-1K1 k =HIDDENR1 q .FUNCT-1K1 k"
        proof(rule ballI,rule impI)
          fix k assume [ty]: "k be NatNAT-1M1"
          assume A5: "k inTARSKIR2 domFINSEQ-1K5 p"
          then have "p .FUNCT-1K1 k =HIDDENR1 (q ^FINSEQ-1K8 r).FUNCT-1K1 k"
            using A3 finseq_1_def_7 sorry
          also have "... = q .FUNCT-1K1 k"
            using A4 A5 finseq_1_def_7 sorry
          finally show "p .FUNCT-1K1 k =HIDDENR1 q .FUNCT-1K1 k"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus "p =FUNCT-1R1 q"
        using A4 sorry
    qed
    have "r ^FINSEQ-1K8 p =FUNCT-1R1 r ^FINSEQ-1K8 q implies p =FUNCT-1R1 q"
    proof(rule impI)
      assume A6: "r ^FINSEQ-1K8 p =FUNCT-1R1 r ^FINSEQ-1K8 q"
      then have "lenFINSEQ-1K4 r +NAT-1K1 lenFINSEQ-1K4 p =HIDDENR1 lenFINSEQ-1K4 (r ^FINSEQ-1K8 q)"
        using finseq_1_th_22 sorry
      also have "... = lenFINSEQ-1K4 r +NAT-1K1 lenFINSEQ-1K4 q"
        using finseq_1_th_22 sorry
      finally have "lenFINSEQ-1K4 r +NAT-1K1 lenFINSEQ-1K4 p =HIDDENR1 lenFINSEQ-1K4 r +NAT-1K1 lenFINSEQ-1K4 q"
         sorry
      then have A7: "domFINSEQ-1K5 p =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
        using finseq_1_def_3 sorry
      also have "... = domFINSEQ-1K5 q"
        using finseq_1_def_3 sorry
      finally have "domFINSEQ-1K5 p =HIDDENR1 domFINSEQ-1K5 q"
         sorry
      have " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p implies p .FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 k"
      proof-
        have " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p implies p .FUNCT-1K1 k =HIDDENR1 q .FUNCT-1K1 k"
        proof(rule ballI,rule impI)
          fix k assume [ty]: "k be NatNAT-1M1"
          assume A8: "k inTARSKIR2 domFINSEQ-1K5 p"
          then have "p .FUNCT-1K1 k =HIDDENR1 (r ^FINSEQ-1K8 q).FUNCT-1K1 (lenFINSEQ-1K4 r +XCMPLX-0K2 k)"
            using A6 finseq_1_def_7 sorry
          also have "... = q .FUNCT-1K1 k"
            using A7 A8 finseq_1_def_7 sorry
          finally show "p .FUNCT-1K1 k =HIDDENR1 q .FUNCT-1K1 k"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus "p =FUNCT-1R1 q"
        using A7 sorry
    qed
    thus "p =FUNCT-1R1 q"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_34:
" for p be FinSequenceFINSEQ-1M1 holds p ^FINSEQ-1K8 {}XBOOLE-0K1 =FUNCT-1R1 p & {}XBOOLE-0K1 ^FINSEQ-1K8 p =FUNCT-1R1 p"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds p ^FINSEQ-1K8 {}XBOOLE-0K1 =FUNCT-1R1 p & {}XBOOLE-0K1 ^FINSEQ-1K8 p =FUNCT-1R1 p"
  proof(rule ballI,rule conjMI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    have A1: "domFINSEQ-1K5 (p ^FINSEQ-1K8 {}XBOOLE-0K1) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 (p ^FINSEQ-1K8 {}XBOOLE-0K1))"
      using finseq_1_def_3 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 ({}XBOOLE-0K1))"
      using finseq_1_th_22 sorry
    also have "... = domFINSEQ-1K5 p"
      using finseq_1_def_3 sorry
    finally have "domFINSEQ-1K5 (p ^FINSEQ-1K8 {}XBOOLE-0K1) =HIDDENR1 domFINSEQ-1K5 p"
       sorry
    have " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p implies p .FUNCT-1K1 k =XBOOLE-0R4 (p ^FINSEQ-1K8 {}XBOOLE-0K1).FUNCT-1K1 k"
      using finseq_1_def_7 sorry
    thus "p ^FINSEQ-1K8 {}XBOOLE-0K1 =FUNCT-1R1 p"
      using A1 sorry
    have A2: "domFINSEQ-1K5 ({}XBOOLE-0K1 ^FINSEQ-1K8 p) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 ({}XBOOLE-0K1 ^FINSEQ-1K8 p))"
      using finseq_1_def_3 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 ({}XBOOLE-0K1) +NAT-1K1 lenFINSEQ-1K4 p)"
      using finseq_1_th_22 sorry
    also have "... = domFINSEQ-1K5 p"
      using finseq_1_def_3 sorry
    finally have "domFINSEQ-1K5 ({}XBOOLE-0K1 ^FINSEQ-1K8 p) =HIDDENR1 domFINSEQ-1K5 p"
       sorry
    have " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p implies p .FUNCT-1K1 k =XBOOLE-0R4 ({}XBOOLE-0K1 ^FINSEQ-1K8 p).FUNCT-1K1 k"
    proof-
      have " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p implies ({}XBOOLE-0K1 ^FINSEQ-1K8 p).FUNCT-1K1 k =HIDDENR1 p .FUNCT-1K1 k"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A3: "k inTARSKIR2 domFINSEQ-1K5 p"
        have "({}XBOOLE-0K1 ^FINSEQ-1K8 p).FUNCT-1K1 k =HIDDENR1 ({}XBOOLE-0K1 ^FINSEQ-1K8 p).FUNCT-1K1 (lenFINSEQ-1K4 ({}XBOOLE-0K1) +XCMPLX-0K2 k)"
           sorry
        also have "... = p .FUNCT-1K1 k"
          using A3 finseq_1_def_7 sorry
        finally show "({}XBOOLE-0K1 ^FINSEQ-1K8 p).FUNCT-1K1 k =HIDDENR1 p .FUNCT-1K1 k"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "{}XBOOLE-0K1 ^FINSEQ-1K8 p =FUNCT-1R1 p"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_35:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds p ^FINSEQ-1K8 q =FUNCT-1R1 {}XBOOLE-0K1 implies p =FUNCT-1R1 {}XBOOLE-0K1 & q =FUNCT-1R1 {}XBOOLE-0K1"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds p ^FINSEQ-1K8 q =FUNCT-1R1 {}XBOOLE-0K1 implies p =FUNCT-1R1 {}XBOOLE-0K1 & q =FUNCT-1R1 {}XBOOLE-0K1"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    assume "p ^FINSEQ-1K8 q =FUNCT-1R1 {}XBOOLE-0K1"
    then have "0NUMBERSK6 =HIDDENR1 lenFINSEQ-1K4 (p ^FINSEQ-1K8 q)"
       sorry
    also have "... = lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q"
      using finseq_1_th_22 sorry
    finally have "0NUMBERSK6 =HIDDENR1 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q"
       sorry
    thus "p =FUNCT-1R1 {}XBOOLE-0K1 & q =FUNCT-1R1 {}XBOOLE-0K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax FINSEQ_1K9 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ ^FINSEQ-1K9\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164)
translations "p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q" \<rightharpoonup> "p ^FINSEQ-1K8 q"

mtheorem finseq_1_add_5:
  mlet "D be setHIDDENM2", "p be FinSequenceFINSEQ-1M3-of D", "q be FinSequenceFINSEQ-1M3-of D"
"cluster p ^FINSEQ-1K8 q as-term-is FinSequenceFINSEQ-1M3-of D"
proof
(*coherence*)
  show "p ^FINSEQ-1K8 q be FinSequenceFINSEQ-1M3-of D"
  proof-
    have A1: "rngFUNCT-1K2 (p ^FINSEQ-1K8 q) =XBOOLE-0R4 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q & rngFUNCT-1K2 p c=TARSKIR1 D"
      using finseq_1_def_4 finseq_1_th_31 sorry
    have Cut1143: "rngFUNCT-1K2 q c=TARSKIR1 D"
      using finseq_1_def_4 sorry
    have "rngFUNCT-1K2 (p ^FINSEQ-1K8 q) c=TARSKIR1 D"
    proof-
      show "rngFUNCT-1K2 (p ^FINSEQ-1K8 q) c=TARSKIR1 D"
        using A1 xboole_1_th_8 Cut1143 sorry
    qed
    thus "p ^FINSEQ-1K8 q be FinSequenceFINSEQ-1M3-of D"
      using finseq_1_def_4 sorry
  qed
qed "sorry"

mlemma finseq_1_lm_4:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for x1 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 {TARSKIK1 [TARSKIK4 x1,y1 ] } implies x =HIDDENR1 x1 & y =HIDDENR1 y1"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for x1 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 {TARSKIK1 [TARSKIK4 x1,y1 ] } implies x =HIDDENR1 x1 & y =HIDDENR1 y1"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix y1 assume [ty]: "y1 be objectHIDDENM1"
    assume "[TARSKIK4 x,y ] inHIDDENR3 {TARSKIK1 [TARSKIK4 x1,y1 ] }"
    then have "[TARSKIK4 x,y ] =HIDDENR1 [TARSKIK4 x1,y1 ]"
      using tarski_def_1 sorry
    thus "x =HIDDENR1 x1 & y =HIDDENR1 y1"
      using xtuple_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) FINSEQ_1K10("<*FINSEQ-1K10  _ *>" [0]164) where
  "<*FINSEQ-1K10 x*> \<equiv> <*FINSEQ-1K6 x*>"

mtheorem finseq_1_def_8:
  mlet "x be objectHIDDENM1"
"redefine func <*FINSEQ-1K10 x*> \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 SegFINSEQ-1K2 \<one>\<^sub>M & it .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x"
proof
(*compatibility*)
  show " for it be FunctionFUNCT-1M1 holds it =HIDDENR1 <*FINSEQ-1K10 x*> iff domRELAT-1K1 it =XBOOLE-0R4 SegFINSEQ-1K2 \<one>\<^sub>M & it .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x"
  proof-
    have " for f be FunctionFUNCT-1M1 holds (f =XBOOLE-0R4 <*FINSEQ-1K6 x*> implies domRELAT-1K1 f =XBOOLE-0R4 SegFINSEQ-1K2 \<one>\<^sub>M & f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x) & (domRELAT-1K1 f =XBOOLE-0R4 SegFINSEQ-1K2 \<one>\<^sub>M & f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x implies f =HIDDENR1 <*FINSEQ-1K6 x*>)"
    proof(rule ballI,rule conjMI,rule impMI ,rule impI)
      fix f assume [ty]: "f be FunctionFUNCT-1M1"
      show "f =XBOOLE-0R4 <*FINSEQ-1K6 x*> implies domRELAT-1K1 f =XBOOLE-0R4 SegFINSEQ-1K2 \<one>\<^sub>M & f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x"
      proof(rule impI,rule conjMI)
        assume A1: "f =XBOOLE-0R4 <*FINSEQ-1K6 x*>"
        thus "domRELAT-1K1 f =XBOOLE-0R4 SegFINSEQ-1K2 \<one>\<^sub>M"
          using finseq_1_th_2 relat_1_th_9 sorry
        have "[TARSKIK4 \<one>\<^sub>M,x ] inHIDDENR3 f"
          using A1 tarski_def_1 sorry
        thus "f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x"
          using funct_1_th_1 sorry
      qed
      assume A2: "domRELAT-1K1 f =XBOOLE-0R4 SegFINSEQ-1K2 \<one>\<^sub>M"
        and A3: "f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x"
      obtain g where 
        [ty]:"g be FunctionFUNCT-1M1" and gDef:"g = {TARSKIK1 [TARSKIK4 \<one>\<^sub>M,f .FUNCT-1K1 \<one>\<^sub>M ] }"
         sorry
      have " for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds [TARSKIK4 y,z ] inHIDDENR3 f iff [TARSKIK4 y,z ] inHIDDENR3 g"
      proof-
        have " for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds ([TARSKIK4 y,z ] inHIDDENR3 f implies [TARSKIK4 y,z ] inHIDDENR3 g) & ([TARSKIK4 y,z ] inHIDDENR3 g implies [TARSKIK4 y,z ] inHIDDENR3 f)"
        proof(rule ballI,rule ballI,rule conjMI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          fix z assume [ty]: "z be objectHIDDENM1"
          show "[TARSKIK4 y,z ] inHIDDENR3 f implies [TARSKIK4 y,z ] inHIDDENR3 g"
          proof(rule impI)
            assume A4: "[TARSKIK4 y,z ] inHIDDENR3 f"
            then have A5: "y inHIDDENR3 {TARSKIK1 \<one>\<^sub>M}"
              using A2 finseq_1_th_2 xtuple_0_def_12 sorry
            have A6: "z inHIDDENR3 rngFUNCT-1K2 f"
              using A4 xtuple_0_def_13 sorry
            have A7: "rngFUNCT-1K2 f =XBOOLE-0R4 {TARSKIK1 f .FUNCT-1K1 \<one>\<^sub>M }"
              using A2 finseq_1_th_2 funct_1_th_4 sorry
            have A8: "y =HIDDENR1 \<one>\<^sub>M"
              using A5 tarski_def_1 sorry
            have "z =HIDDENR1 f .FUNCT-1K1 \<one>\<^sub>M"
              using A6 A7 tarski_def_1 sorry
            thus "[TARSKIK4 y,z ] inHIDDENR3 g"
              using A8 tarski_def_1 sorry
          qed
          assume "[TARSKIK4 y,z ] inHIDDENR3 g"
          then have A9: "y =HIDDENR1 \<one>\<^sub>M & z =HIDDENR1 f .FUNCT-1K1 \<one>\<^sub>M"
            using finseq_1_lm_4 sorry
          have "\<one>\<^sub>M inTARSKIR2 domRELAT-1K1 f"
            using A2 sorry
          thus "[TARSKIK4 y,z ] inHIDDENR3 f"
            using A9 funct_1_def_2 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus "f =HIDDENR1 <*FINSEQ-1K6 x*>"
        using A3 relat_1_def_2 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finseq_1_add_6:
  mlet "x be objectHIDDENM1"
"cluster <*FINSEQ-1K6 x*> as-term-is FunctionFUNCT-1M1"
proof
(*coherence*)
  show "<*FINSEQ-1K6 x*> be FunctionFUNCT-1M1"
     sorry
qed "sorry"

mtheorem finseq_1_cl_12:
  mlet "x be objectHIDDENM1"
"cluster <*FINSEQ-1K10 x*> as-term-is Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "<*FINSEQ-1K10 x*> be Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
     sorry
qed "sorry"

mtheorem finseq_1_cl_13:
  mlet "x be objectHIDDENM1"
"cluster <*FINSEQ-1K10 x*> as-term-is FinSequence-likeFINSEQ-1V1"
proof
(*coherence*)
  show "<*FINSEQ-1K10 x*> be FinSequence-likeFINSEQ-1V1"
    using finseq_1_def_8 sorry
qed "sorry"

mtheorem finseq_1_th_36:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for D be setHIDDENM2 holds p ^FINSEQ-1K8 q be FinSequenceFINSEQ-1M3-of D implies p be FinSequenceFINSEQ-1M3-of D & q be FinSequenceFINSEQ-1M3-of D"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for D be setHIDDENM2 holds p ^FINSEQ-1K8 q be FinSequenceFINSEQ-1M3-of D implies p be FinSequenceFINSEQ-1M3-of D & q be FinSequenceFINSEQ-1M3-of D"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    fix D assume [ty]: "D be setHIDDENM2"
    assume "p ^FINSEQ-1K8 q be FinSequenceFINSEQ-1M3-of D"
    then have "rngFUNCT-1K2 (p ^FINSEQ-1K8 q) c=TARSKIR1 D"
      using finseq_1_def_4 sorry
    then have A1: "rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q c=TARSKIR1 D"
      using finseq_1_th_31 sorry
    have "rngFUNCT-1K2 p c=TARSKIR1 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q"
      using xboole_1_th_7 sorry
    thus "p be FinSequenceFINSEQ-1M3-of D"
      using finseq_1_def_4 A1 xboole_1_th_1 sorry
    have "rngFUNCT-1K2 q c=TARSKIR1 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q"
      using xboole_1_th_7 sorry
    thus "q be FinSequenceFINSEQ-1M3-of D"
      using finseq_1_def_4 A1 xboole_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef finseq_1_def_9 ("<*FINSEQ-1K11 _ , _ *>" [0,0]164 ) where
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1"
"func <*FINSEQ-1K11 x,y *> \<rightarrow> setHIDDENM2 equals
  (<*FINSEQ-1K10 x*>)^FINSEQ-1K8 (<*FINSEQ-1K10 y*>)"
proof-
  (*coherence*)
    show "(<*FINSEQ-1K10 x*>)^FINSEQ-1K8 (<*FINSEQ-1K10 y*>) be setHIDDENM2"
       sorry
qed "sorry"

mdef finseq_1_def_10 ("<*FINSEQ-1K12 _ , _ , _ *>" [0,0,0]164 ) where
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1", "z be objectHIDDENM1"
"func <*FINSEQ-1K12 x,y,z *> \<rightarrow> setHIDDENM2 equals
  ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 (<*FINSEQ-1K10 y*>))^FINSEQ-1K8 (<*FINSEQ-1K10 z*>)"
proof-
  (*coherence*)
    show "((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 (<*FINSEQ-1K10 y*>))^FINSEQ-1K8 (<*FINSEQ-1K10 z*>) be setHIDDENM2"
       sorry
qed "sorry"

mtheorem finseq_1_cl_14:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1"
"cluster <*FINSEQ-1K11 x,y *> as-term-is Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "<*FINSEQ-1K11 x,y *> be Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
     sorry
qed "sorry"

mtheorem finseq_1_cl_15:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1", "z be objectHIDDENM1"
"cluster <*FINSEQ-1K12 x,y,z *> as-term-is Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "<*FINSEQ-1K12 x,y,z *> be Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
     sorry
qed "sorry"

mtheorem finseq_1_cl_16:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1"
"cluster <*FINSEQ-1K11 x,y *> as-term-is FinSequence-likeFINSEQ-1V1"
proof
(*coherence*)
  show "<*FINSEQ-1K11 x,y *> be FinSequence-likeFINSEQ-1V1"
     sorry
qed "sorry"

mtheorem finseq_1_cl_17:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1", "z be objectHIDDENM1"
"cluster <*FINSEQ-1K12 x,y,z *> as-term-is FinSequence-likeFINSEQ-1V1"
proof
(*coherence*)
  show "<*FINSEQ-1K12 x,y,z *> be FinSequence-likeFINSEQ-1V1"
     sorry
qed "sorry"

mtheorem finseq_1_th_37:
" for x be objectHIDDENM1 holds <*FINSEQ-1K10 x*> =FUNCT-1R1 {TARSKIK1 [TARSKIK4 \<one>\<^sub>M,x ] }"
   sorry

mtheorem finseq_1_th_38:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds p =FUNCT-1R1 <*FINSEQ-1K10 x*> iff domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 \<one>\<^sub>M & rngFUNCT-1K2 p =XBOOLE-0R4 {TARSKIK1 x}"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds (p =FUNCT-1R1 <*FINSEQ-1K10 x*> implies domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 \<one>\<^sub>M & rngFUNCT-1K2 p =XBOOLE-0R4 {TARSKIK1 x}) & (domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 \<one>\<^sub>M & rngFUNCT-1K2 p =XBOOLE-0R4 {TARSKIK1 x} implies p =FUNCT-1R1 <*FINSEQ-1K10 x*>)"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    show "p =FUNCT-1R1 <*FINSEQ-1K10 x*> implies domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 \<one>\<^sub>M & rngFUNCT-1K2 p =XBOOLE-0R4 {TARSKIK1 x}"
    proof(rule impI,rule conjMI)
      assume A1: "p =FUNCT-1R1 <*FINSEQ-1K10 x*>"
      thus "domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 \<one>\<^sub>M"
        using finseq_1_def_8 sorry
      have "domFINSEQ-1K5 p =XBOOLE-0R4 {TARSKIK1 \<one>\<^sub>M}"
        using A1 finseq_1_def_8 finseq_1_th_2 sorry
      then have "rngFUNCT-1K2 p =XBOOLE-0R4 {TARSKIK1 p .FUNCT-1K1 \<one>\<^sub>M }"
        using funct_1_th_4 sorry
      thus "rngFUNCT-1K2 p =XBOOLE-0R4 {TARSKIK1 x}"
        using A1 finseq_1_def_8 sorry
    qed
    assume A2: "domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 \<one>\<^sub>M"
      and A3: "rngFUNCT-1K2 p =XBOOLE-0R4 {TARSKIK1 x}"
    have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
      using A2 sorry
    then have "p .FUNCT-1K1 \<one>\<^sub>M inTARSKIR2 {TARSKIK1 x}"
      using A3 funct_1_def_3 sorry
    then have "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x"
      using tarski_def_1 sorry
    thus "p =FUNCT-1R1 <*FINSEQ-1K10 x*>"
      using A2 finseq_1_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_39:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds p =FUNCT-1R1 <*FINSEQ-1K10 x*> iff lenFINSEQ-1K4 p =XBOOLE-0R4 \<one>\<^sub>M & rngFUNCT-1K2 p =XBOOLE-0R4 {TARSKIK1 x}"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds  not (p =FUNCT-1R1 <*FINSEQ-1K10 x*> &  not (lenFINSEQ-1K4 p =XBOOLE-0R4 \<one>\<^sub>M & rngFUNCT-1K2 p =XBOOLE-0R4 {TARSKIK1 x})) &  not ((lenFINSEQ-1K4 p =XBOOLE-0R4 \<one>\<^sub>M & rngFUNCT-1K2 p =XBOOLE-0R4 {TARSKIK1 x}) &  not p =FUNCT-1R1 <*FINSEQ-1K10 x*>)"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    have "lenFINSEQ-1K4 p =XBOOLE-0R4 \<one>\<^sub>M iff domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 \<one>\<^sub>M"
      using finseq_1_def_3 sorry
    thus " not (p =FUNCT-1R1 <*FINSEQ-1K10 x*> &  not (lenFINSEQ-1K4 p =XBOOLE-0R4 \<one>\<^sub>M & rngFUNCT-1K2 p =XBOOLE-0R4 {TARSKIK1 x})) &  not ((lenFINSEQ-1K4 p =XBOOLE-0R4 \<one>\<^sub>M & rngFUNCT-1K2 p =XBOOLE-0R4 {TARSKIK1 x}) &  not p =FUNCT-1R1 <*FINSEQ-1K10 x*>)"
      using finseq_1_th_38 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_40:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds p =FUNCT-1R1 <*FINSEQ-1K10 x*> iff lenFINSEQ-1K4 p =XBOOLE-0R4 \<one>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds  not (p =FUNCT-1R1 <*FINSEQ-1K10 x*> &  not (lenFINSEQ-1K4 p =XBOOLE-0R4 \<one>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x)) &  not ((lenFINSEQ-1K4 p =XBOOLE-0R4 \<one>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x) &  not p =FUNCT-1R1 <*FINSEQ-1K10 x*>)"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    have "lenFINSEQ-1K4 p =XBOOLE-0R4 \<one>\<^sub>M iff domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 \<one>\<^sub>M"
      using finseq_1_def_3 sorry
    thus " not (p =FUNCT-1R1 <*FINSEQ-1K10 x*> &  not (lenFINSEQ-1K4 p =XBOOLE-0R4 \<one>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x)) &  not ((lenFINSEQ-1K4 p =XBOOLE-0R4 \<one>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x) &  not p =FUNCT-1R1 <*FINSEQ-1K10 x*>)"
      using finseq_1_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_41:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 p).FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 p).FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    have "\<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 \<one>\<^sub>M"
       sorry
    then have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 x*>)"
      using finseq_1_def_8 sorry
    then have "((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 p).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 (<*FINSEQ-1K10 x*>).FUNCT-1K1 \<one>\<^sub>M"
      using finseq_1_def_7 sorry
    thus "((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 p).FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x"
      using finseq_1_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_42:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 x"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 x"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    have "domFINSEQ-1K5 (<*FINSEQ-1K10 x*>) =XBOOLE-0R4 SegFINSEQ-1K2 \<one>\<^sub>M"
      using finseq_1_def_8 sorry
    then have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 x*>)"
       sorry
    then have "(p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (<*FINSEQ-1K10 x*>).FUNCT-1K1 \<one>\<^sub>M"
      using finseq_1_def_7 sorry
    also have "... = x"
      using finseq_1_def_8 sorry
    finally show "(p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 x"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_43:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds <*FINSEQ-1K12 x,y,z *> =FUNCT-1R1 (<*FINSEQ-1K10 x*>)^FINSEQ-1K8 (<*FINSEQ-1K11 y,z *>) & <*FINSEQ-1K12 x,y,z *> =FUNCT-1R1 (<*FINSEQ-1K11 x,y *>)^FINSEQ-1K8 (<*FINSEQ-1K10 z*>)"
  using finseq_1_th_32 sorry

mtheorem finseq_1_th_44:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds p =FUNCT-1R1 <*FINSEQ-1K11 x,y *> iff (lenFINSEQ-1K4 p =XBOOLE-0R4 \<two>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x) & p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 y"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (p =FUNCT-1R1 <*FINSEQ-1K11 x,y *> implies (lenFINSEQ-1K4 p =XBOOLE-0R4 \<two>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x) & p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 y) & (lenFINSEQ-1K4 p =XBOOLE-0R4 \<two>\<^sub>M & (p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x & p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 y) implies p =FUNCT-1R1 <*FINSEQ-1K11 x,y *>)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impMI ,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    show "p =FUNCT-1R1 <*FINSEQ-1K11 x,y *> implies (lenFINSEQ-1K4 p =XBOOLE-0R4 \<two>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x) & p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 y"
    proof-
      have "p =FUNCT-1R1 <*FINSEQ-1K11 x,y *> implies lenFINSEQ-1K4 p =HIDDENR1 \<two>\<^sub>M & (p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x & p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 y)"
      proof(rule impI,rule conjMI,rule conjMI)
        assume A1: "p =FUNCT-1R1 <*FINSEQ-1K11 x,y *>"
        then have "lenFINSEQ-1K4 p =HIDDENR1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>) +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 y*>)"
          using finseq_1_th_22 sorry
        also have "... = \<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 y*>)"
          using finseq_1_th_39 sorry
        also have "... = \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
          using finseq_1_th_39 sorry
        also have "... = \<two>\<^sub>M"
           sorry
        finally show "lenFINSEQ-1K4 p =HIDDENR1 \<two>\<^sub>M"
           sorry
        have A2: "\<one>\<^sub>M inTARSKIR2 {TARSKIK1 \<one>\<^sub>M}"
          using tarski_def_1 sorry
        then have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 x*>)"
          using finseq_1_def_8 finseq_1_th_2 sorry
        then have "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 (<*FINSEQ-1K10 x*>).FUNCT-1K1 \<one>\<^sub>M"
          using A1 finseq_1_def_7 sorry
        also have "... = x"
          using finseq_1_def_8 sorry
        finally show "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x"
           sorry
        have A3: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 y*>)"
          using A2 finseq_1_def_8 finseq_1_th_2 sorry
        have "p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 (<*FINSEQ-1K10 y*>)).FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
          using A1 sorry
        also have "... = ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 (<*FINSEQ-1K10 y*>)).FUNCT-1K1 (lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>) +NAT-1K1 \<one>\<^sub>M)"
          using finseq_1_th_39 sorry
        also have "... = (<*FINSEQ-1K10 y*>).FUNCT-1K1 \<one>\<^sub>M"
          using A3 finseq_1_def_7 sorry
        also have "... = y"
          using finseq_1_def_8 sorry
        finally show "p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 y"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A4: "lenFINSEQ-1K4 p =XBOOLE-0R4 \<two>\<^sub>M"
      and A5: "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x"
      and A6: "p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 y"
    have A7: "domFINSEQ-1K5 p =HIDDENR1 SegFINSEQ-1K2 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
      using A4 finseq_1_def_3 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>) +NAT-1K1 \<one>\<^sub>M)"
      using finseq_1_th_39 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>) +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 y*>))"
      using finseq_1_th_39 sorry
    finally have "domFINSEQ-1K5 p =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>) +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 y*>))"
       sorry
    have A8: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 x*>) implies p .FUNCT-1K1 k =XBOOLE-0R4 (<*FINSEQ-1K10 x*>).FUNCT-1K1 k"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume "k inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 x*>)"
      then have "k inTARSKIR2 {TARSKIK1 \<one>\<^sub>M}"
        using finseq_1_def_8 finseq_1_th_2 sorry
      then have "k =XBOOLE-0R4 \<one>\<^sub>M"
        using tarski_def_1 sorry
      thus "p .FUNCT-1K1 k =XBOOLE-0R4 (<*FINSEQ-1K10 x*>).FUNCT-1K1 k"
        using A5 finseq_1_def_8 sorry
    qed "sorry"
    have " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 y*>) implies p .FUNCT-1K1 (lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>) +XCMPLX-0K2 k) =XBOOLE-0R4 (<*FINSEQ-1K10 y*>).FUNCT-1K1 k"
    proof-
      have " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 y*>) implies p .FUNCT-1K1 (lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>) +XCMPLX-0K2 k) =HIDDENR1 (<*FINSEQ-1K10 y*>).FUNCT-1K1 k"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume "k inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 y*>)"
        then have A9: "k inTARSKIR2 {TARSKIK1 \<one>\<^sub>M}"
          using finseq_1_def_8 finseq_1_th_2 sorry
        have "p .FUNCT-1K1 (lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>) +XCMPLX-0K2 k) =HIDDENR1 p .FUNCT-1K1 (\<one>\<^sub>M +XCMPLX-0K2 k)"
          using finseq_1_th_39 sorry
        also have "... = p .FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
          using A9 tarski_def_1 sorry
        also have "... = (<*FINSEQ-1K10 y*>).FUNCT-1K1 \<one>\<^sub>M"
          using A6 finseq_1_def_8 sorry
        also have "... = (<*FINSEQ-1K10 y*>).FUNCT-1K1 k"
          using A9 tarski_def_1 sorry
        finally show "p .FUNCT-1K1 (lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>) +XCMPLX-0K2 k) =HIDDENR1 (<*FINSEQ-1K10 y*>).FUNCT-1K1 k"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "p =FUNCT-1R1 <*FINSEQ-1K11 x,y *>"
      using A7 A8 finseq_1_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_45:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds p =FUNCT-1R1 <*FINSEQ-1K12 x,y,z *> iff ((lenFINSEQ-1K4 p =XBOOLE-0R4 \<three>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x) & p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 y) & p .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 z"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds (p =FUNCT-1R1 <*FINSEQ-1K12 x,y,z *> implies ((lenFINSEQ-1K4 p =XBOOLE-0R4 \<three>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x) & p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 y) & p .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 z) & (lenFINSEQ-1K4 p =XBOOLE-0R4 \<three>\<^sub>M & (p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x & (p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 y & p .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 z)) implies p =FUNCT-1R1 <*FINSEQ-1K12 x,y,z *>)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix z assume [ty]: "z be objectHIDDENM1"
    show "p =FUNCT-1R1 <*FINSEQ-1K12 x,y,z *> implies ((lenFINSEQ-1K4 p =XBOOLE-0R4 \<three>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x) & p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 y) & p .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 z"
    proof-
      have "p =FUNCT-1R1 <*FINSEQ-1K12 x,y,z *> implies lenFINSEQ-1K4 p =HIDDENR1 \<three>\<^sub>M & (p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x & (p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 y & p .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 z))"
      proof(rule impI,rule conjMI,rule conjMI,rule conjMI)
        assume A1: "p =FUNCT-1R1 <*FINSEQ-1K12 x,y,z *>"
        then have "lenFINSEQ-1K4 p =HIDDENR1 lenFINSEQ-1K4 (<*FINSEQ-1K11 x,y *>) +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 z*>)"
          using finseq_1_th_22 sorry
        also have "... = \<two>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 z*>)"
          using finseq_1_th_44 sorry
        also have "... = \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
          using finseq_1_th_39 sorry
        also have "... = \<three>\<^sub>M"
           sorry
        finally show "lenFINSEQ-1K4 p =HIDDENR1 \<three>\<^sub>M"
           sorry
        have A2: "\<one>\<^sub>M inTARSKIR2 {TARSKIK1 \<one>\<^sub>M}"
          using tarski_def_1 sorry
        then have A3: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 x*>)"
          using finseq_1_def_8 finseq_1_th_2 sorry
        have "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 (<*FINSEQ-1K11 y,z *>)).FUNCT-1K1 \<one>\<^sub>M"
          using A1 finseq_1_th_32 sorry
        also have "... = (<*FINSEQ-1K10 x*>).FUNCT-1K1 \<one>\<^sub>M"
          using A3 finseq_1_def_7 sorry
        also have "... = x"
          using finseq_1_def_8 sorry
        finally show "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x"
           sorry
        have "\<two>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 \<two>\<^sub>M & lenFINSEQ-1K4 (<*FINSEQ-1K11 x,y *>) =XBOOLE-0R4 \<two>\<^sub>M"
          using finseq_1_th_44 sorry
        then have "\<two>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K11 x,y *>)"
          using finseq_1_def_3 sorry
        then have "p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 (<*FINSEQ-1K11 x,y *>).FUNCT-1K1 \<two>\<^sub>M"
          using A1 finseq_1_def_7 sorry
        also have "... = y"
          using finseq_1_th_44 sorry
        finally show "p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 y"
           sorry
        have A4: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 z*>)"
          using A2 finseq_1_def_8 finseq_1_th_2 sorry
        have "p .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 ((<*FINSEQ-1K11 x,y *>)^FINSEQ-1K8 (<*FINSEQ-1K10 z*>)).FUNCT-1K1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
          using A1 sorry
        also have "... = ((<*FINSEQ-1K11 x,y *>)^FINSEQ-1K8 (<*FINSEQ-1K10 z*>)).FUNCT-1K1 (lenFINSEQ-1K4 (<*FINSEQ-1K11 x,y *>) +NAT-1K1 \<one>\<^sub>M)"
          using finseq_1_th_44 sorry
        also have "... = (<*FINSEQ-1K10 z*>).FUNCT-1K1 \<one>\<^sub>M"
          using A4 finseq_1_def_7 sorry
        also have "... = z"
          using finseq_1_def_8 sorry
        finally show "p .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 z"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A5: "lenFINSEQ-1K4 p =XBOOLE-0R4 \<three>\<^sub>M"
      and A6: "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x"
      and A7: "p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 y"
      and A8: "p .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 z"
    have A9: "domFINSEQ-1K5 p =HIDDENR1 SegFINSEQ-1K2 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
      using A5 finseq_1_def_3 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 (<*FINSEQ-1K11 x,y *>) +NAT-1K1 \<one>\<^sub>M)"
      using finseq_1_th_44 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 (<*FINSEQ-1K11 x,y *>) +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 z*>))"
      using finseq_1_th_39 sorry
    finally have "domFINSEQ-1K5 p =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 (<*FINSEQ-1K11 x,y *>) +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 z*>))"
       sorry
    have A10: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K11 x,y *>) implies p .FUNCT-1K1 k =XBOOLE-0R4 (<*FINSEQ-1K11 x,y *>).FUNCT-1K1 k"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume A11: "k inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K11 x,y *>)"
      have "lenFINSEQ-1K4 (<*FINSEQ-1K11 x,y *>) =XBOOLE-0R4 \<two>\<^sub>M"
        using finseq_1_th_44 sorry
      then have A12: "k inTARSKIR2 SegFINSEQ-1K2 \<two>\<^sub>M"
        using A11 finseq_1_def_3 sorry
      have A13: "k =XBOOLE-0R4 \<one>\<^sub>M implies p .FUNCT-1K1 k =XBOOLE-0R4 (<*FINSEQ-1K11 x,y *>).FUNCT-1K1 k"
        using A6 finseq_1_th_44 sorry
      have "k =XBOOLE-0R4 \<two>\<^sub>M implies p .FUNCT-1K1 k =XBOOLE-0R4 (<*FINSEQ-1K11 x,y *>).FUNCT-1K1 k"
        using A7 finseq_1_th_44 sorry
      thus "p .FUNCT-1K1 k =XBOOLE-0R4 (<*FINSEQ-1K11 x,y *>).FUNCT-1K1 k"
        using A12 A13 finseq_1_th_2 tarski_def_2 sorry
    qed "sorry"
    have " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 z*>) implies p .FUNCT-1K1 (lenFINSEQ-1K4 (<*FINSEQ-1K11 x,y *>) +XCMPLX-0K2 k) =XBOOLE-0R4 (<*FINSEQ-1K10 z*>).FUNCT-1K1 k"
    proof-
      have " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 z*>) implies p .FUNCT-1K1 (lenFINSEQ-1K4 (<*FINSEQ-1K11 x,y *>) +XCMPLX-0K2 k) =HIDDENR1 (<*FINSEQ-1K10 z*>).FUNCT-1K1 k"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume "k inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 z*>)"
        then have "k inTARSKIR2 {TARSKIK1 \<one>\<^sub>M}"
          using finseq_1_def_8 finseq_1_th_2 sorry
        then have A14: "k =XBOOLE-0R4 \<one>\<^sub>M"
          using tarski_def_1 sorry
        then have "p .FUNCT-1K1 (lenFINSEQ-1K4 (<*FINSEQ-1K11 x,y *>) +XCMPLX-0K2 k) =HIDDENR1 p .FUNCT-1K1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
          using finseq_1_th_44 sorry
        also have "... = (<*FINSEQ-1K10 z*>).FUNCT-1K1 k"
          using A8 A14 finseq_1_def_8 sorry
        finally show "p .FUNCT-1K1 (lenFINSEQ-1K4 (<*FINSEQ-1K11 x,y *>) +XCMPLX-0K2 k) =HIDDENR1 (<*FINSEQ-1K10 z*>).FUNCT-1K1 k"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "p =FUNCT-1R1 <*FINSEQ-1K12 x,y,z *>"
      using A9 A10 finseq_1_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_46:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds p <>HIDDENR2 {}XBOOLE-0K1 implies ( ex q be FinSequenceFINSEQ-1M1 st  ex x be objectHIDDENM1 st p =FUNCT-1R1 q ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds p <>HIDDENR2 {}XBOOLE-0K1 implies ( ex tVar13 be FinSequenceFINSEQ-1M1 st  ex tVar14 be objectHIDDENM1 st tVar13 ^FINSEQ-1K8 (<*FINSEQ-1K10 tVar14*>) =FUNCT-1R1 p)"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume "p <>HIDDENR2 {}XBOOLE-0K1"
    then obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A1: "lenFINSEQ-1K4 p =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_6 sorry
    have 
      [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    obtain q where 
      [ty]:"q be FinSequenceFINSEQ-1M1" and qDef:"q = p  |RELAT-1K8 SegFINSEQ-1K2 n"
      using finseq_1_th_15 sorry
    show " ex tVar13 be FinSequenceFINSEQ-1M1 st  ex tVar14 be objectHIDDENM1 st tVar13 ^FINSEQ-1K8 (<*FINSEQ-1K10 tVar14*>) =FUNCT-1R1 p"
    proof(rule bexI[of _ "q"])
      show " ex tVar14 be objectHIDDENM1 st q ^FINSEQ-1K8 (<*FINSEQ-1K10 tVar14*>) =FUNCT-1R1 p"
      proof(rule bexI[of _ "p .FUNCT-1K1 lenFINSEQ-1K4 p"])
        have A2: "domFINSEQ-1K5 q =HIDDENR1 domFINSEQ-1K5 p /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 n"
          using relat_1_th_61 sorry
        also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 p) /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 n"
          using finseq_1_def_3 sorry
        finally have "domFINSEQ-1K5 q =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 p) /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 n"
           sorry
        have "SegFINSEQ-1K2 n c=TARSKIR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
          using finseq_1_th_5 A1 nat_1_th_11 sorry
        then have A3: "domFINSEQ-1K5 q =XBOOLE-0R4 SegFINSEQ-1K2 n"
          using A2 xboole_1_th_28 sorry
        have A4: "domFINSEQ-1K5 (q ^FINSEQ-1K8 (<*FINSEQ-1K10 p .FUNCT-1K1 lenFINSEQ-1K4 p*>)) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 (q ^FINSEQ-1K8 (<*FINSEQ-1K10 p .FUNCT-1K1 lenFINSEQ-1K4 p*>)))"
          using finseq_1_def_3 sorry
        also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 q +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 p .FUNCT-1K1 lenFINSEQ-1K4 p*>))"
          using finseq_1_th_22 sorry
        also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M)"
          using finseq_1_th_39 sorry
        also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
          using A1 A3 finseq_1_def_3 sorry
        also have "... = domFINSEQ-1K5 p"
          using finseq_1_def_3 sorry
        finally have "domFINSEQ-1K5 (q ^FINSEQ-1K8 (<*FINSEQ-1K10 p .FUNCT-1K1 lenFINSEQ-1K4 p*>)) =HIDDENR1 domFINSEQ-1K5 p"
           sorry
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domFINSEQ-1K5 p implies p .FUNCT-1K1 x =XBOOLE-0R4 (q ^FINSEQ-1K8 (<*FINSEQ-1K10 p .FUNCT-1K1 lenFINSEQ-1K4 p*>)).FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A5: "x inHIDDENR3 domFINSEQ-1K5 p"
          then obtain k where 
            [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = x"
             sorry
          have "k inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
            using A1 A5 finseq_1_def_3 sorry
          then have A6: "k inTARSKIR2 SegFINSEQ-1K2 n \\/XBOOLE-0K2 {TARSKIK1 n +NAT-1K1 \<one>\<^sub>M }"
            using finseq_1_th_9 sorry
          have A7: "k inTARSKIR2 SegFINSEQ-1K2 n implies p .FUNCT-1K1 k =HIDDENR1 (q ^FINSEQ-1K8 (<*FINSEQ-1K10 p .FUNCT-1K1 lenFINSEQ-1K4 p*>)).FUNCT-1K1 k"
          proof(rule impI)
            assume A8: "k inTARSKIR2 SegFINSEQ-1K2 n"
            then have "p .FUNCT-1K1 k =HIDDENR1 q .FUNCT-1K1 k"
              using A3 funct_1_th_47 sorry
            also have "... = (q ^FINSEQ-1K8 (<*FINSEQ-1K10 p .FUNCT-1K1 lenFINSEQ-1K4 p*>)).FUNCT-1K1 k"
              using A3 A8 finseq_1_def_7 sorry
            finally show "p .FUNCT-1K1 k =HIDDENR1 (q ^FINSEQ-1K8 (<*FINSEQ-1K10 p .FUNCT-1K1 lenFINSEQ-1K4 p*>)).FUNCT-1K1 k"
               sorry
          qed
          have "k inTARSKIR2 {TARSKIK1 n +NAT-1K1 \<one>\<^sub>M } implies (q ^FINSEQ-1K8 (<*FINSEQ-1K10 p .FUNCT-1K1 lenFINSEQ-1K4 p*>)).FUNCT-1K1 k =HIDDENR1 p .FUNCT-1K1 k"
          proof(rule impI)
            assume A9: "k inTARSKIR2 {TARSKIK1 n +NAT-1K1 \<one>\<^sub>M }"
            have "\<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 \<one>\<^sub>M"
               sorry
            then have A10: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 p .FUNCT-1K1 lenFINSEQ-1K4 p*>)"
              using finseq_1_def_8 sorry
            have "(q ^FINSEQ-1K8 (<*FINSEQ-1K10 p .FUNCT-1K1 lenFINSEQ-1K4 p*>)).FUNCT-1K1 k =HIDDENR1 (q ^FINSEQ-1K8 (<*FINSEQ-1K10 p .FUNCT-1K1 lenFINSEQ-1K4 p*>)).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
              using A9 tarski_def_1 sorry
            also have "... = (q ^FINSEQ-1K8 (<*FINSEQ-1K10 p .FUNCT-1K1 lenFINSEQ-1K4 p*>)).FUNCT-1K1 (lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M)"
              using A3 finseq_1_def_3 sorry
            also have "... = (<*FINSEQ-1K10 p .FUNCT-1K1 lenFINSEQ-1K4 p*>).FUNCT-1K1 \<one>\<^sub>M"
              using A10 finseq_1_def_7 sorry
            also have "... = p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
              using A1 finseq_1_def_8 sorry
            also have "... = p .FUNCT-1K1 k"
              using A9 tarski_def_1 sorry
            finally show "(q ^FINSEQ-1K8 (<*FINSEQ-1K10 p .FUNCT-1K1 lenFINSEQ-1K4 p*>)).FUNCT-1K1 k =HIDDENR1 p .FUNCT-1K1 k"
               sorry
          qed
          thus "p .FUNCT-1K1 x =XBOOLE-0R4 (q ^FINSEQ-1K8 (<*FINSEQ-1K10 p .FUNCT-1K1 lenFINSEQ-1K4 p*>)).FUNCT-1K1 x"
            using A6 A7 xboole_0_def_3 sorry
        qed "sorry"
        thus "q ^FINSEQ-1K8 (<*FINSEQ-1K10 p .FUNCT-1K1 lenFINSEQ-1K4 p*>) =FUNCT-1R1 p"
          using A4 sorry
      qed "sorry"
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax FINSEQ_1K13 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("<*FINSEQ-1K13\<^bsub>'( _ ')\<^esub>  _ *>" [0,0]164)
translations "<*FINSEQ-1K13\<^bsub>(D)\<^esub> x*>" \<rightharpoonup> "<*FINSEQ-1K6 x*>"

mtheorem finseq_1_add_7:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x be ElementSUBSET-1M1-of D"
"cluster <*FINSEQ-1K6 x*> as-term-is FinSequenceFINSEQ-1M3-of D"
proof
(*coherence*)
  show "<*FINSEQ-1K6 x*> be FinSequenceFINSEQ-1M3-of D"
  proof-
    have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 (<*FINSEQ-1K10 x*>) implies y inHIDDENR3 D"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 rngFUNCT-1K2 (<*FINSEQ-1K10 x*>)"
      then have "y inHIDDENR3 {TARSKIK1 x}"
        using finseq_1_th_39 sorry
      then have "y =HIDDENR1 x"
        using tarski_def_1 sorry
      thus "y inHIDDENR3 D"
         sorry
    qed "sorry"
    thus "<*FINSEQ-1K6 x*> be FinSequenceFINSEQ-1M3-of D"
      using tarski_def_3 finseq_1_def_4 sorry
  qed
qed "sorry"

theorem finseq_1_sch_3:
  fixes Pp1 
  assumes
    A1: "Pp1({}XBOOLE-0K1)" and
   A2: " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds Pp1(p) implies Pp1(p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
  shows " for p be FinSequenceFINSEQ-1M1 holds Pp1(p)"
  proof(rule ballI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    let ?R = "\<lambda>Lamb1.  for p be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 p =XBOOLE-0R4 Lamb1 implies Pp1(p)"
    obtain X where
      [ty]:"X be SubsetSUBSET-1M2-of REALNUMBERSK2" and 
      A3: " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds x inTARSKIR2 X iff ?R(x)"
      using subset_1_sch_3 sorry
    have " for k be NatNAT-1M1 holds k inTARSKIR2 X"
    proof-
      have " for n be NatNAT-1M1 holds n inTARSKIR2 X"
      proof-
        have A4: "0NUMBERSK6 inTARSKIR2 REALNUMBERSK2"
          using xreal_0_def_1 sorry
        let ?S = "\<lambda>Lamb1. Lamb1 inTARSKIR2 X"
        have " for q be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 q =XBOOLE-0R4 0NUMBERSK6 implies Pp1(q)"
          using A1 finseq_1_lm_3 sorry
        then have A5: "?S(0NUMBERSK6)"
          using A3 A4 sorry
        have " for n be NatNAT-1M1 holds n inTARSKIR2 X implies n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 X"
        proof(rule ballI,rule impI)
          fix n assume [ty]: "n be NatNAT-1M1"
          assume A6: "n inTARSKIR2 X"
          have A7: "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 REALNUMBERSK2"
            using numbers_th_19 sorry
          have " for q be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 q =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M implies Pp1(q)"
          proof(rule ballI,rule impI)
            fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
            assume A8: "lenFINSEQ-1K4 q =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
            then have "q <>HIDDENR2 {}XBOOLE-0K1"
               sorry
            then obtain r x where
              [ty]:"r be FinSequenceFINSEQ-1M1" "x be objectHIDDENM1" and 
              A9: "q =FUNCT-1R1 r ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)"
              using finseq_1_th_46 sorry
            have "lenFINSEQ-1K4 q =HIDDENR1 lenFINSEQ-1K4 r +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>)"
              using A9 finseq_1_th_22 sorry
            also have "... = lenFINSEQ-1K4 r +NAT-1K1 \<one>\<^sub>M"
              using finseq_1_th_39 sorry
            finally have "lenFINSEQ-1K4 q =HIDDENR1 lenFINSEQ-1K4 r +NAT-1K1 \<one>\<^sub>M"
               sorry
            thus "Pp1(q)"
              using A2 A9 A3 A6 A8 sorry
          qed "sorry"
          thus "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 X"
            using A3 A7 sorry
        qed "sorry"
        then have A10: " for n be NatNAT-1M1 holds ?S(n) implies ?S(n +NAT-1K1 \<one>\<^sub>M)"
           sorry
        show " for n be NatNAT-1M1 holds n inTARSKIR2 X"
          using nat_1_sch_2 A5 A10 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    then have "lenFINSEQ-1K4 p inTARSKIR2 X"
       sorry
    thus "Pp1(p)"
      using A3 sorry
  qed "sorry"

mtheorem finseq_1_th_47:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for r be FinSequenceFINSEQ-1M1 holds  for s be FinSequenceFINSEQ-1M1 holds p ^FINSEQ-1K8 q =FUNCT-1R1 r ^FINSEQ-1K8 s & lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 r implies ( ex t be FinSequenceFINSEQ-1M1 st p ^FINSEQ-1K8 t =FUNCT-1R1 r)"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for r be FinSequenceFINSEQ-1M1 holds  for s be FinSequenceFINSEQ-1M1 holds  not ((p ^FINSEQ-1K8 q =FUNCT-1R1 r ^FINSEQ-1K8 s & lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 r) & ( for t be FinSequenceFINSEQ-1M1 holds  not p ^FINSEQ-1K8 t =FUNCT-1R1 r))"
  proof-
    let ?S = "\<lambda>Lamb1.  for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for s be FinSequenceFINSEQ-1M1 holds p ^FINSEQ-1K8 q =FUNCT-1R1 Lamb1 ^FINSEQ-1K8 s & lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 Lamb1 implies ( ex t be FinSequenceFINSEQ-1M1 st p ^FINSEQ-1K8 t =FUNCT-1R1 Lamb1)"
    have A1: "?S({}XBOOLE-0K1)"
    proof-
      have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for s be FinSequenceFINSEQ-1M1 holds p ^FINSEQ-1K8 q =FUNCT-1R1 {}XBOOLE-0K1 ^FINSEQ-1K8 s & lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 ({}XBOOLE-0K1) implies ( ex tVar15 be FinSequenceFINSEQ-1M1 st p ^FINSEQ-1K8 tVar15 =HIDDENR1 tVar15)"
      proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
        fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
        fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
        fix s assume [ty]: "s be FinSequenceFINSEQ-1M1"
        assume "p ^FINSEQ-1K8 q =FUNCT-1R1 {}XBOOLE-0K1 ^FINSEQ-1K8 s"
          and A2: "lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 ({}XBOOLE-0K1)"
        show " ex tVar15 be FinSequenceFINSEQ-1M1 st p ^FINSEQ-1K8 tVar15 =HIDDENR1 tVar15"
        proof(rule bexI[of _ "{}XBOOLE-0K1"])
          have "p ^FINSEQ-1K8 {}XBOOLE-0K1 =HIDDENR1 p"
            using finseq_1_th_34 sorry
          also have "... = {}XBOOLE-0K1"
            using A2 sorry
          finally show "p ^FINSEQ-1K8 {}XBOOLE-0K1 =HIDDENR1 {}XBOOLE-0K1"
             sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A3: " for r be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds ?S(r) implies ?S(r ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
    proof-
      have " for r be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds ( for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for s be FinSequenceFINSEQ-1M1 holds p ^FINSEQ-1K8 q =FUNCT-1R1 r ^FINSEQ-1K8 s & lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 r implies ( ex t be FinSequenceFINSEQ-1M1 st p ^FINSEQ-1K8 t =FUNCT-1R1 r)) implies ( for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for s be FinSequenceFINSEQ-1M1 holds p ^FINSEQ-1K8 q =FUNCT-1R1 (r ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))^FINSEQ-1K8 s & lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 (r ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) implies  not ( for t be FinSequenceFINSEQ-1M1 holds  not p ^FINSEQ-1K8 t =FUNCT-1R1 r ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)))"
      proof(rule ballI,rule ballI,rule impI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
        fix r assume [ty]: "r be FinSequenceFINSEQ-1M1"
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A4: " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for s be FinSequenceFINSEQ-1M1 holds p ^FINSEQ-1K8 q =FUNCT-1R1 r ^FINSEQ-1K8 s & lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 r implies ( ex t be FinSequenceFINSEQ-1M1 st p ^FINSEQ-1K8 t =FUNCT-1R1 r)"
        fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
        fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
        fix s assume [ty]: "s be FinSequenceFINSEQ-1M1"
        assume A5: "p ^FINSEQ-1K8 q =FUNCT-1R1 (r ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))^FINSEQ-1K8 s"
          and A6: "lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 (r ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
        have A7: "lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 (r ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) implies  not ( for t be FinSequenceFINSEQ-1M1 holds  not p ^FINSEQ-1K8 t =FUNCT-1R1 r ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
        proof(rule impI)
          assume "lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 (r ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
          then have A8: "domFINSEQ-1K5 p =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 (r ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)))"
            using finseq_1_def_3 sorry
          also have "... = domFINSEQ-1K5 (r ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
            using finseq_1_def_3 sorry
          finally have "domFINSEQ-1K5 p =HIDDENR1 domFINSEQ-1K5 (r ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
             sorry
          have A9: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p implies p .FUNCT-1K1 k =XBOOLE-0R4 (r ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 k"
          proof-
            have " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p implies p .FUNCT-1K1 k =HIDDENR1 (r ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 k"
            proof(rule ballI,rule impI)
              fix k assume [ty]: "k be NatNAT-1M1"
              assume A10: "k inTARSKIR2 domFINSEQ-1K5 p"
              then have "p .FUNCT-1K1 k =HIDDENR1 ((r ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))^FINSEQ-1K8 s).FUNCT-1K1 k"
                using A5 finseq_1_def_7 sorry
              also have "... = (r ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 k"
                using A8 A10 finseq_1_def_7 sorry
              finally show "p .FUNCT-1K1 k =HIDDENR1 (r ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 k"
                 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have "p ^FINSEQ-1K8 {}XBOOLE-0K1 =HIDDENR1 p"
            using finseq_1_th_34 sorry
          also have "... = r ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)"
            using A8 A9 sorry
          finally have "p ^FINSEQ-1K8 {}XBOOLE-0K1 =HIDDENR1 r ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)"
             sorry
          thus " not ( for t be FinSequenceFINSEQ-1M1 holds  not p ^FINSEQ-1K8 t =FUNCT-1R1 r ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
             sorry
        qed
        have "lenFINSEQ-1K4 p <>HIDDENR2 lenFINSEQ-1K4 (r ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) implies  not ( for t be FinSequenceFINSEQ-1M1 holds  not p ^FINSEQ-1K8 t =FUNCT-1R1 r ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
        proof(rule impI)
          assume "lenFINSEQ-1K4 p <>HIDDENR2 lenFINSEQ-1K4 (r ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
          then have "lenFINSEQ-1K4 p <>HIDDENR2 lenFINSEQ-1K4 r +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>)"
            using finseq_1_th_22 sorry
          then have A11: "lenFINSEQ-1K4 p <>HIDDENR2 lenFINSEQ-1K4 r +NAT-1K1 \<one>\<^sub>M"
            using finseq_1_th_39 sorry
          have "lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 r +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>)"
            using A6 finseq_1_th_22 sorry
          then have A12: "lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 r +NAT-1K1 \<one>\<^sub>M"
            using finseq_1_th_39 sorry
          have "p ^FINSEQ-1K8 q =FUNCT-1R1 r ^FINSEQ-1K8 ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 s)"
            using A5 finseq_1_th_32 sorry
          then obtain t where
            [ty]:"t be FinSequenceFINSEQ-1M1" and 
            A13: "p ^FINSEQ-1K8 t =FUNCT-1R1 r"
            using A4 A11 A12 nat_1_th_8 sorry
          have "p ^FINSEQ-1K8 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) =FUNCT-1R1 r ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)"
            using A13 finseq_1_th_32 sorry
          thus " not ( for t be FinSequenceFINSEQ-1M1 holds  not p ^FINSEQ-1K8 t =FUNCT-1R1 r ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
             sorry
        qed
        thus " not ( for t be FinSequenceFINSEQ-1M1 holds  not p ^FINSEQ-1K8 t =FUNCT-1R1 r ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
          using A7 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for r be FinSequenceFINSEQ-1M1 holds ?S(r)"
      using finseq_1_sch_3 A1 A3 sorry
    thus " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for r be FinSequenceFINSEQ-1M1 holds  for s be FinSequenceFINSEQ-1M1 holds  not ((p ^FINSEQ-1K8 q =FUNCT-1R1 r ^FINSEQ-1K8 s & lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 r) & ( for t be FinSequenceFINSEQ-1M1 holds  not p ^FINSEQ-1K8 t =FUNCT-1R1 r))"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_cl_18:
"cluster note-that NATNUMBERSK1 -definedRELAT-1V4 for FinSequenceFINSEQ-1M1"
proof
(*coherence*)
  show " for it be FinSequenceFINSEQ-1M1 holds it be NATNUMBERSK1 -definedRELAT-1V4"
  proof-
    have " for f be FinSequenceFINSEQ-1M1 holds f be NATNUMBERSK1 -definedRELAT-1V4"
    proof(rule ballI)
      fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
      have "domFINSEQ-1K5 f c=TARSKIR1 NATNUMBERSK1"
      proof-
        show "domFINSEQ-1K5 f c=TARSKIR1 NATNUMBERSK1"
           sorry
      qed
      thus "f be NATNUMBERSK1 -definedRELAT-1V4"
        using relat_1_def_18 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef finseq_1_def_11 (" _ * FINSEQ-1K14" [164]164 ) where
  mlet "D be setHIDDENM2"
"func D * FINSEQ-1K14 \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff x be FinSequenceFINSEQ-1M3-of D"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff x be FinSequenceFINSEQ-1M3-of D"
    proof-
      have " ex tVar16 be setHIDDENM2 st  for x be objectHIDDENM1 holds (x inHIDDENR3 tVar16 implies x be FinSequenceFINSEQ-1M3-of D) & (x be FinSequenceFINSEQ-1M3-of D implies x inHIDDENR3 tVar16)"
      proof-
        let ?P = "\<lambda>Lamb1. Lamb1 be FinSequenceFINSEQ-1M3-of D"
        obtain X where
          [ty]:"X be setHIDDENM2" and 
          A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X iff x inHIDDENR3 boolZFMISC-1K1 ([:ZFMISC-1K2 NATNUMBERSK1,D :]) & ?P(x)"
          using xboole_0_sch_1 sorry
        show " ex tVar16 be setHIDDENM2 st  for x be objectHIDDENM1 holds (x inHIDDENR3 tVar16 implies x be FinSequenceFINSEQ-1M3-of D) & (x be FinSequenceFINSEQ-1M3-of D implies x inHIDDENR3 tVar16)"
        proof(rule bexI[of _ "X"],rule ballI,rule conjMI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          show "x inHIDDENR3 X implies x be FinSequenceFINSEQ-1M3-of D"
            using A1 sorry
          assume "x be FinSequenceFINSEQ-1M3-of D"
          then obtain p where 
            [ty]:"p be FinSequenceFINSEQ-1M3-of D" and pDef:"p = x"
             sorry
          have "p c=RELAT-1R2 [:ZFMISC-1K2 NATNUMBERSK1,D :]"
             sorry
          thus "x inHIDDENR3 X"
            using A1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff x be FinSequenceFINSEQ-1M3-of D) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff x be FinSequenceFINSEQ-1M3-of D) implies it1 =HIDDENR1 it2"
    proof-
      have " for D1 be setHIDDENM2 holds  for D2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 D1 iff x be FinSequenceFINSEQ-1M3-of D) & ( for x be objectHIDDENM1 holds x inHIDDENR3 D2 iff x be FinSequenceFINSEQ-1M3-of D) implies D1 =HIDDENR1 D2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix D1 assume [ty]: "D1 be setHIDDENM2"
        fix D2 assume [ty]: "D2 be setHIDDENM2"
        assume A2: " for x be objectHIDDENM1 holds x inHIDDENR3 D1 iff x be FinSequenceFINSEQ-1M3-of D"
          and A3: " for x be objectHIDDENM1 holds x inHIDDENR3 D2 iff x be FinSequenceFINSEQ-1M3-of D"
        have " for x be objectHIDDENM1 holds (x inHIDDENR3 D1 implies x inHIDDENR3 D2) & (x inHIDDENR3 D2 implies x inHIDDENR3 D1)"
        proof(rule ballI,rule conjMI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          show "x inHIDDENR3 D1 implies x inHIDDENR3 D2"
          proof(rule impI)
            assume "x inHIDDENR3 D1"
            then have "x be FinSequenceFINSEQ-1M3-of D"
              using A2 sorry
            thus "x inHIDDENR3 D2"
              using A3 sorry
          qed
          assume "x inHIDDENR3 D2"
          then have "x be FinSequenceFINSEQ-1M3-of D"
            using A3 sorry
          thus "x inHIDDENR3 D1"
            using A2 sorry
        qed "sorry"
        thus "D1 =HIDDENR1 D2"
          using tarski_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem finseq_1_cl_19:
  mlet "D be setHIDDENM2"
"cluster D * FINSEQ-1K14 as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "D * FINSEQ-1K14 be  non emptyXBOOLE-0V1"
  proof-
    have " not D * FINSEQ-1K14 be emptyXBOOLE-0V1"
    proof-
      let ?f = "the FinSequenceFINSEQ-1M3-of D"
      have "?f inTARSKIR2 D * FINSEQ-1K14"
        using finseq_1_def_11 sorry
      thus " not D * FINSEQ-1K14 be emptyXBOOLE-0V1"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finseq_1_th_48:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds (rngFUNCT-1K2 p =XBOOLE-0R4 rngFUNCT-1K2 q & p be one-to-oneFUNCT-1V2) & q be one-to-oneFUNCT-1V2 implies lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  not (((rngFUNCT-1K2 p =XBOOLE-0R4 rngFUNCT-1K2 q & p be one-to-oneFUNCT-1V2) & q be one-to-oneFUNCT-1V2) &  not lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q)"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    let ?P = "\<lambda>Lamb1. Lamb1 be one-to-oneFUNCT-1V2 implies ( for q be FinSequenceFINSEQ-1M1 holds rngFUNCT-1K2 Lamb1 =XBOOLE-0R4 rngFUNCT-1K2 q & q be one-to-oneFUNCT-1V2 implies lenFINSEQ-1K4 Lamb1 =XBOOLE-0R4 lenFINSEQ-1K4 q)"
    have A1: "?P({}XBOOLE-0K1)"
      using relat_1_th_41 sorry
    have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds (p be one-to-oneFUNCT-1V2 implies ( for q be FinSequenceFINSEQ-1M1 holds rngFUNCT-1K2 p =XBOOLE-0R4 rngFUNCT-1K2 q & q be one-to-oneFUNCT-1V2 implies lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q)) implies (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>) be one-to-oneFUNCT-1V2 implies ( for q be FinSequenceFINSEQ-1M1 holds rngFUNCT-1K2 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) =XBOOLE-0R4 rngFUNCT-1K2 q & q be one-to-oneFUNCT-1V2 implies lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) =XBOOLE-0R4 lenFINSEQ-1K4 q))"
    proof(rule ballI,rule ballI,rule impI,rule impI,rule ballI,rule impMI ,rule impI)
      fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A2: "p be one-to-oneFUNCT-1V2 implies ( for q be FinSequenceFINSEQ-1M1 holds rngFUNCT-1K2 p =XBOOLE-0R4 rngFUNCT-1K2 q & q be one-to-oneFUNCT-1V2 implies lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q)"
      assume A3: "p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>) be one-to-oneFUNCT-1V2"
      fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
      assume A4: "rngFUNCT-1K2 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) =XBOOLE-0R4 rngFUNCT-1K2 q"
        and A5: "q be one-to-oneFUNCT-1V2"
      have A6: "rngFUNCT-1K2 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) =HIDDENR1 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 (<*FINSEQ-1K10 x*>)"
        using finseq_1_th_31 sorry
      also have "... = rngFUNCT-1K2 p \\/XBOOLE-0K2 {TARSKIK1 x}"
        using finseq_1_th_38 sorry
      finally have "rngFUNCT-1K2 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) =HIDDENR1 rngFUNCT-1K2 p \\/XBOOLE-0K2 {TARSKIK1 x}"
         sorry
      have "x inHIDDENR3 {TARSKIK1 x}"
        using tarski_def_1 sorry
      then have "x inHIDDENR3 rngFUNCT-1K2 q"
        using A4 A6 xboole_0_def_3 sorry
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A7: "y inHIDDENR3 domFINSEQ-1K5 q"and A8: "x =HIDDENR1 q .FUNCT-1K1 y"
        using funct_1_def_3 sorry
      have A9: "y inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
        using A7 finseq_1_def_3 sorry
      have 
        [ty]:"y be ElementSUBSET-1M1-of NATNUMBERSK1"
        using A7 sorry
      have A10: "\<one>\<^sub>M <=XXREAL-0R1 y"
        using A9 finseq_1_th_1 sorry
      then obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A11: "\<one>\<^sub>M +XCMPLX-0K2 k =XBOOLE-0R4 y"
        using nat_1_th_10 sorry
      have A12: "y <=XXREAL-0R1 lenFINSEQ-1K4 q"
        using A9 finseq_1_th_1 sorry
      then obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A13: "y +XCMPLX-0K2 n =XBOOLE-0R4 lenFINSEQ-1K4 q"
        using nat_1_th_10 sorry
      have 
        [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and
        [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
        using ordinal1_def_12 sorry
      obtain q1 where 
        [ty]:"q1 be FinSequenceFINSEQ-1M1" and q1Def:"q1 = q  |RELAT-1K8 SegFINSEQ-1K2 k"
        using finseq_1_th_15 sorry
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 =HIDDENR1 q .FUNCT-1K1 (y +XCMPLX-0K2 Lamb1)"
      have A14: " for j be NatNAT-1M1 holds j inTARSKIR2 SegFINSEQ-1K2 n implies ( ex x be objectHIDDENM1 st ?P(j,x))"
         sorry
      obtain q2 where
        [ty]:"q2 be FinSequenceFINSEQ-1M1" and 
        A15: "domFINSEQ-1K5 q2 =XBOOLE-0R4 SegFINSEQ-1K2 n"and A16: " for j be NatNAT-1M1 holds j inTARSKIR2 SegFINSEQ-1K2 n implies ?P(j,q2 .FUNCT-1K1 j)"
        using finseq_1_sch_1 A14 sorry
      have A17: "k <=XXREAL-0R1 y"
        using A11 nat_1_th_12 sorry
      then have A18: "k <=XXREAL-0R1 lenFINSEQ-1K4 q"
        using A12 xxreal_0_th_2 sorry
      then have A19: "lenFINSEQ-1K4 q1 =XBOOLE-0R4 k"
        using finseq_1_th_17 sorry
      have "lenFINSEQ-1K4 (q1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) +NAT-1K1 lenFINSEQ-1K4 q2 =HIDDENR1 (lenFINSEQ-1K4 q1 +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>))+NAT-1K1 lenFINSEQ-1K4 q2"
        using finseq_1_th_22 sorry
      also have "... = (k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 lenFINSEQ-1K4 q2"
        using A19 finseq_1_th_39 sorry
      also have "... = lenFINSEQ-1K4 q"
        using A11 A13 A15 finseq_1_def_3 sorry
      finally have "lenFINSEQ-1K4 (q1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) +NAT-1K1 lenFINSEQ-1K4 q2 =HIDDENR1 lenFINSEQ-1K4 q"
         sorry
      then have A20: "domFINSEQ-1K5 q =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 (q1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) +NAT-1K1 lenFINSEQ-1K4 q2)"
        using finseq_1_def_3 sorry
      have A21: "rngFUNCT-1K2 (q1 ^FINSEQ-1K8 q2) =XBOOLE-0R4 rngFUNCT-1K2 q \\SUBSET-1K6 {TARSKIK1 x}"
      proof-
        have "rngFUNCT-1K2 (q1 ^FINSEQ-1K8 q2) c=TARSKIR1 rngFUNCT-1K2 q \\SUBSET-1K6 {TARSKIK1 x} & rngFUNCT-1K2 q \\SUBSET-1K6 {TARSKIK1 x} c=TARSKIR1 rngFUNCT-1K2 (q1 ^FINSEQ-1K8 q2)"
        proof(rule conjMI)
          show "rngFUNCT-1K2 (q1 ^FINSEQ-1K8 q2) c=TARSKIR1 rngFUNCT-1K2 q \\SUBSET-1K6 {TARSKIK1 x}"
          proof-
            have " for z be objectHIDDENM1 holds z inHIDDENR3 rngFUNCT-1K2 (q1 ^FINSEQ-1K8 q2) implies z inHIDDENR3 rngFUNCT-1K2 q \\SUBSET-1K6 {TARSKIK1 x}"
            proof(rule ballI,rule impI)
              fix z assume [ty]: "z be objectHIDDENM1"
              assume "z inHIDDENR3 rngFUNCT-1K2 (q1 ^FINSEQ-1K8 q2)"
              then have A22: "z inHIDDENR3 rngFUNCT-1K2 q1 \\/XBOOLE-0K2 rngFUNCT-1K2 q2"
                using finseq_1_th_31 sorry
              have A23: "z inHIDDENR3 rngFUNCT-1K2 q1 implies z inHIDDENR3 rngFUNCT-1K2 q \\SUBSET-1K6 {TARSKIK1 x}"
              proof(rule impI)
                assume A24: "z inHIDDENR3 rngFUNCT-1K2 q1"
                have A25: "rngFUNCT-1K2 q1 =XBOOLE-0R4 q .:FUNCT-1K5 SegFINSEQ-1K2 k & q .:FUNCT-1K5 SegFINSEQ-1K2 k c=TARSKIR1 rngFUNCT-1K2 q"
                  using relat_1_th_111 relat_1_th_115 sorry
                obtain y1 where
                  [ty]:"y1 be objectHIDDENM1" and 
                  A26: "y1 inHIDDENR3 domFINSEQ-1K5 q1"and A27: "q1 .FUNCT-1K1 y1 =HIDDENR1 z"
                  using A24 funct_1_def_3 sorry
                have A28: "q1 .FUNCT-1K1 y1 =XBOOLE-0R4 q .FUNCT-1K1 y1"
                  using A26 funct_1_th_47 sorry
                have A29: "y1 inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 q1)"
                  using A26 finseq_1_def_3 sorry
                have 
                  [ty]:"y1 be ElementSUBSET-1M1-of NATNUMBERSK1"
                  using A26 sorry
                have A30: "y1 <=XXREAL-0R1 k"
                  using A19 A29 finseq_1_th_1 sorry
                have A31: "k <XXREAL-0R3 y"
                  using A11 xreal_1_th_29 sorry
                have "SegFINSEQ-1K2 k c=TARSKIR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
                  using A17 finseq_1_th_5 A12 xxreal_0_th_2 sorry
                then have "domFINSEQ-1K5 q1 c=TARSKIR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
                  using A18 finseq_1_th_17 sorry
                then have "domFINSEQ-1K5 q1 c=TARSKIR1 domFINSEQ-1K5 q"
                  using finseq_1_def_3 sorry
                then have "x <>HIDDENR2 z"
                  using A5 A7 A8 A26 A27 A28 A30 A31 sorry
                then have " not z inHIDDENR3 {TARSKIK1 x}"
                  using tarski_def_1 sorry
                thus "z inHIDDENR3 rngFUNCT-1K2 q \\SUBSET-1K6 {TARSKIK1 x}"
                  using A24 A25 xboole_0_def_5 sorry
              qed
              have "z inHIDDENR3 rngFUNCT-1K2 q2 implies z inHIDDENR3 rngFUNCT-1K2 q \\SUBSET-1K6 {TARSKIK1 x}"
              proof(rule impI)
                assume "z inHIDDENR3 rngFUNCT-1K2 q2"
                then obtain y1 where
                  [ty]:"y1 be objectHIDDENM1" and 
                  A32: "y1 inHIDDENR3 domFINSEQ-1K5 q2"and A33: "q2 .FUNCT-1K1 y1 =HIDDENR1 z"
                  using funct_1_def_3 sorry
                have 
                  [ty]:"y1 be ElementSUBSET-1M1-of NATNUMBERSK1"
                  using A32 sorry
                have A34: "q2 .FUNCT-1K1 y1 =XBOOLE-0R4 q .FUNCT-1K1 (y +NAT-1K1 y1)"
                  using A15 A16 A32 sorry
                have A35: "\<one>\<^sub>M <=XXREAL-0R1 y +NAT-1K1 y1"
                  using A10 nat_1_th_12 sorry
                have "y1 <=XXREAL-0R1 n"
                  using A15 A32 finseq_1_th_1 sorry
                then have "y +NAT-1K1 y1 <=XXREAL-0R1 lenFINSEQ-1K4 q"
                  using A13 xreal_1_th_7 sorry
                then have "y +NAT-1K1 y1 inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
                  using A35 sorry
                then have A36: "y +NAT-1K1 y1 inTARSKIR2 domFINSEQ-1K5 q"
                  using finseq_1_def_3 sorry
                then have A37: "z inHIDDENR3 rngFUNCT-1K2 q"
                  using A33 A34 funct_1_def_3 sorry
                have "y1 <>HIDDENR2 0NUMBERSK6"
                  using A15 A32 finseq_1_th_1 sorry
                then have "y <>HIDDENR2 y +NAT-1K1 y1"
                   sorry
                then have "x <>HIDDENR2 z"
                  using A5 A7 A8 A33 A34 A36 sorry
                then have " not z inHIDDENR3 {TARSKIK1 x}"
                  using tarski_def_1 sorry
                thus "z inHIDDENR3 rngFUNCT-1K2 q \\SUBSET-1K6 {TARSKIK1 x}"
                  using A37 xboole_0_def_5 sorry
              qed
              thus "z inHIDDENR3 rngFUNCT-1K2 q \\SUBSET-1K6 {TARSKIK1 x}"
                using A22 A23 xboole_0_def_3 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 (q1 ^FINSEQ-1K8 q2) c=TARSKIR1 rngFUNCT-1K2 q \\SUBSET-1K6 {TARSKIK1 x}"
              using tarski_def_3 sorry
          qed
          have " for z be objectHIDDENM1 holds z inHIDDENR3 rngFUNCT-1K2 q \\SUBSET-1K6 {TARSKIK1 x} implies z inHIDDENR3 rngFUNCT-1K2 (q1 ^FINSEQ-1K8 q2)"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be objectHIDDENM1"
            assume A38: "z inHIDDENR3 rngFUNCT-1K2 q \\SUBSET-1K6 {TARSKIK1 x}"
            then obtain y1 where
              [ty]:"y1 be objectHIDDENM1" and 
              A39: "y1 inHIDDENR3 domFINSEQ-1K5 q"and A40: "z =HIDDENR1 q .FUNCT-1K1 y1"
              using funct_1_def_3 sorry
            have A41: "y1 inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
              using A39 finseq_1_def_3 sorry
            have 
              [ty]:"y1 be ElementSUBSET-1M1-of NATNUMBERSK1"
              using A39 sorry
            have " not z inHIDDENR3 {TARSKIK1 x}"
              using A38 xboole_0_def_5 sorry
            then have A42: "y <>HIDDENR2 y1"
              using A8 A40 tarski_def_1 sorry
            have A43: "y <XXREAL-0R3 y1 implies z inHIDDENR3 rngFUNCT-1K2 q2"
            proof(rule impI)
              assume A44: "y <XXREAL-0R3 y1"
              then obtain j where
                [ty]:"j be NatNAT-1M1" and 
                A45: "y1 =XBOOLE-0R4 y +XCMPLX-0K2 j"
                using nat_1_th_10 sorry
              have A46: "\<one>\<^sub>M <=XXREAL-0R1 j"
                using A44 A45 nat_1_th_19 sorry
              have "j <=XXREAL-0R1 n"
                using A13 A41 A45 finseq_1_th_1 xreal_1_th_6 sorry
              then have A47: "j inTARSKIR2 SegFINSEQ-1K2 n"
                using A46 sorry
              then have "z =HIDDENR1 q2 .FUNCT-1K1 j"
                using A16 A40 A45 sorry
              thus "z inHIDDENR3 rngFUNCT-1K2 q2"
                using A15 A47 funct_1_def_3 sorry
            qed
            have "y1 <XXREAL-0R3 y implies z inHIDDENR3 rngFUNCT-1K2 q1"
            proof(rule impI)
              assume A48: "y1 <XXREAL-0R3 y"
              have A49: "\<one>\<^sub>M <=XXREAL-0R1 y1"
                using A41 finseq_1_th_1 sorry
              have "y1 <=XXREAL-0R1 k"
                using A11 A48 nat_1_th_13 sorry
              then have "y1 inTARSKIR2 SegFINSEQ-1K2 k"
                using A49 sorry
              then have A50: "y1 inTARSKIR2 domFINSEQ-1K5 q1"
                using A18 finseq_1_th_17 sorry
              then have "q1 .FUNCT-1K1 y1 =HIDDENR1 z"
                using A40 funct_1_th_47 sorry
              thus "z inHIDDENR3 rngFUNCT-1K2 q1"
                using A50 funct_1_def_3 sorry
            qed
            then have "z inHIDDENR3 rngFUNCT-1K2 q1 \\/XBOOLE-0K2 rngFUNCT-1K2 q2"
              using A42 A43 xboole_0_def_3 xxreal_0_th_1 sorry
            thus "z inHIDDENR3 rngFUNCT-1K2 (q1 ^FINSEQ-1K8 q2)"
              using finseq_1_th_31 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 q \\SUBSET-1K6 {TARSKIK1 x} c=TARSKIR1 rngFUNCT-1K2 (q1 ^FINSEQ-1K8 q2)"
            using tarski_def_3 sorry
        qed
        thus "rngFUNCT-1K2 (q1 ^FINSEQ-1K8 q2) =XBOOLE-0R4 rngFUNCT-1K2 q \\SUBSET-1K6 {TARSKIK1 x}"
          using xboole_0_def_10 sorry
      qed
      have A51: "p =FUNCT-1R1 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) |RELAT-1K8 domFINSEQ-1K5 p"
        using finseq_1_th_21 sorry
      have A52: "rngFUNCT-1K2 p =XBOOLE-0R4 rngFUNCT-1K2 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) \\SUBSET-1K6 {TARSKIK1 x}"
      proof-
        have "rngFUNCT-1K2 p c=TARSKIR1 rngFUNCT-1K2 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) \\SUBSET-1K6 {TARSKIK1 x} & rngFUNCT-1K2 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) \\SUBSET-1K6 {TARSKIK1 x} c=TARSKIR1 rngFUNCT-1K2 p"
        proof(rule conjMI)
          show "rngFUNCT-1K2 p c=TARSKIR1 rngFUNCT-1K2 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) \\SUBSET-1K6 {TARSKIK1 x}"
          proof-
            have " for z be objectHIDDENM1 holds z inHIDDENR3 rngFUNCT-1K2 p implies z inHIDDENR3 rngFUNCT-1K2 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) \\SUBSET-1K6 {TARSKIK1 x}"
            proof(rule ballI,rule impI)
              fix z assume [ty]: "z be objectHIDDENM1"
              assume A53: "z inHIDDENR3 rngFUNCT-1K2 p"
              have A54: "rngFUNCT-1K2 p c=TARSKIR1 rngFUNCT-1K2 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
                using A51 relat_1_th_70 sorry
              obtain y1 where
                [ty]:"y1 be objectHIDDENM1" and 
                A55: "y1 inHIDDENR3 domFINSEQ-1K5 p"and A56: "p .FUNCT-1K1 y1 =HIDDENR1 z"
                using A53 funct_1_def_3 sorry
              have A57: "y1 inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
                using A55 finseq_1_def_3 sorry
              have 
                [ty]:"y1 be ElementSUBSET-1M1-of NATNUMBERSK1"
                using A55 sorry
              have A58: "(p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 x"
                using finseq_1_th_42 sorry
              have A59: "(p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 y1 =XBOOLE-0R4 p .FUNCT-1K1 y1"
                using A51 A55 funct_1_th_47 sorry
              have A60: "y1 <=XXREAL-0R1 lenFINSEQ-1K4 p"
                using A57 finseq_1_th_1 sorry
              have A61: "lenFINSEQ-1K4 p <XXREAL-0R3 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M"
                using xreal_1_th_29 sorry
              have A62: "\<one>\<^sub>M <=XXREAL-0R1 y1"
                using A57 finseq_1_th_1 sorry
              have "y1 <=XXREAL-0R1 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M"
                using A60 A61 xxreal_0_th_2 sorry
              then have A63: "y1 inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)"
                using A62 sorry
              have A64: "lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)"
                using finseq_1_th_3 sorry
              have A65: "y1 inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>))"
                using A63 finseq_1_th_40 sorry
              have A66: "lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>))"
                using A64 finseq_1_th_40 sorry
              have A67: "y1 inTARSKIR2 domFINSEQ-1K5 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
                using A65 finseq_1_def_7 sorry
              have "lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
                using A66 finseq_1_def_7 sorry
              then have "x <>HIDDENR2 z"
                using A3 A56 A58 A59 A60 A61 A67 sorry
              then have " not z inHIDDENR3 {TARSKIK1 x}"
                using tarski_def_1 sorry
              thus "z inHIDDENR3 rngFUNCT-1K2 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) \\SUBSET-1K6 {TARSKIK1 x}"
                using A53 A54 xboole_0_def_5 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 p c=TARSKIR1 rngFUNCT-1K2 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) \\SUBSET-1K6 {TARSKIK1 x}"
              using tarski_def_3 sorry
          qed
          have " for z be objectHIDDENM1 holds z inHIDDENR3 rngFUNCT-1K2 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) \\SUBSET-1K6 {TARSKIK1 x} implies z inHIDDENR3 rngFUNCT-1K2 p"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be objectHIDDENM1"
            assume A68: "z inHIDDENR3 rngFUNCT-1K2 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) \\SUBSET-1K6 {TARSKIK1 x}"
            then have A69: "z inHIDDENR3 rngFUNCT-1K2 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
               sorry
            have A70: " not z inHIDDENR3 {TARSKIK1 x}"
              using A68 xboole_0_def_5 sorry
            have "z inHIDDENR3 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 (<*FINSEQ-1K10 x*>)"
              using A69 finseq_1_th_31 sorry
            then have "z inHIDDENR3 rngFUNCT-1K2 p or z inHIDDENR3 rngFUNCT-1K2 (<*FINSEQ-1K10 x*>)"
              using xboole_0_def_3 sorry
            thus "z inHIDDENR3 rngFUNCT-1K2 p"
              using A70 finseq_1_th_38 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) \\SUBSET-1K6 {TARSKIK1 x} c=TARSKIR1 rngFUNCT-1K2 p"
            using tarski_def_3 sorry
        qed
        thus "rngFUNCT-1K2 p =XBOOLE-0R4 rngFUNCT-1K2 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) \\SUBSET-1K6 {TARSKIK1 x}"
          using xboole_0_def_10 sorry
      qed
      have A71: "q1 ^FINSEQ-1K8 q2 be one-to-oneFUNCT-1V2"
      proof-
        have " for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds (y1 inHIDDENR3 domFINSEQ-1K5 (q1 ^FINSEQ-1K8 q2) & y2 inHIDDENR3 domFINSEQ-1K5 (q1 ^FINSEQ-1K8 q2)) & (q1 ^FINSEQ-1K8 q2).FUNCT-1K1 y1 =XBOOLE-0R4 (q1 ^FINSEQ-1K8 q2).FUNCT-1K1 y2 implies y1 =HIDDENR1 y2"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix y1 assume [ty]: "y1 be objectHIDDENM1"
          fix y2 assume [ty]: "y2 be objectHIDDENM1"
          assume A72: "y1 inHIDDENR3 domFINSEQ-1K5 (q1 ^FINSEQ-1K8 q2) & y2 inHIDDENR3 domFINSEQ-1K5 (q1 ^FINSEQ-1K8 q2)"
            and A73: "(q1 ^FINSEQ-1K8 q2).FUNCT-1K1 y1 =XBOOLE-0R4 (q1 ^FINSEQ-1K8 q2).FUNCT-1K1 y2"
          obtain m1 m2 where 
            [ty]:"m1 be ElementSUBSET-1M1-of NATNUMBERSK1" and m1Def:"m1 = y1" and
            [ty]:"m2 be ElementSUBSET-1M1-of NATNUMBERSK1" and m2Def:"m2 = y2"
            using A72 sorry
          have A74: "q1 be one-to-oneFUNCT-1V2"
            using A5 funct_1_th_52 sorry
          have A75: "m1 inTARSKIR2 domFINSEQ-1K5 q1 & m2 inTARSKIR2 domFINSEQ-1K5 q1 implies y1 =HIDDENR1 y2"
          proof(rule impI)
            assume A76: "m1 inTARSKIR2 domFINSEQ-1K5 q1 & m2 inTARSKIR2 domFINSEQ-1K5 q1"
            then have "(q1 ^FINSEQ-1K8 q2).FUNCT-1K1 m1 =XBOOLE-0R4 q1 .FUNCT-1K1 m1 & (q1 ^FINSEQ-1K8 q2).FUNCT-1K1 m2 =XBOOLE-0R4 q1 .FUNCT-1K1 m2"
              using finseq_1_def_7 sorry
            thus "y1 =HIDDENR1 y2"
              using A73 A74 A76 sorry
          qed
          have A77: "m1 inTARSKIR2 domFINSEQ-1K5 q1 implies (( ex j be NatNAT-1M1 st j inTARSKIR2 domFINSEQ-1K5 q2 & m2 =XBOOLE-0R4 lenFINSEQ-1K4 q1 +XCMPLX-0K2 j) implies y1 =HIDDENR1 y2)"
          proof(rule impI,rule impI)
            assume A78: "m1 inTARSKIR2 domFINSEQ-1K5 q1"
            assume Given: " ex j be NatNAT-1M1 st j inTARSKIR2 domFINSEQ-1K5 q2 & m2 =XBOOLE-0R4 lenFINSEQ-1K4 q1 +XCMPLX-0K2 j"
            then obtain j where
              [ty]:"j be NatNAT-1M1" and 
              A79: "j inTARSKIR2 domFINSEQ-1K5 q2"and A80: "m2 =XBOOLE-0R4 lenFINSEQ-1K4 q1 +XCMPLX-0K2 j"
               sorry
            have A81: "(q1 ^FINSEQ-1K8 q2).FUNCT-1K1 m2 =XBOOLE-0R4 q2 .FUNCT-1K1 j"
              using A79 A80 finseq_1_def_7 sorry
            have "(q1 ^FINSEQ-1K8 q2).FUNCT-1K1 m1 =XBOOLE-0R4 q1 .FUNCT-1K1 m1 & q1 .FUNCT-1K1 m1 =XBOOLE-0R4 q .FUNCT-1K1 m1"
              using A78 finseq_1_def_7 funct_1_th_47 sorry
            then have A82: "q .FUNCT-1K1 m1 =XBOOLE-0R4 q .FUNCT-1K1 (y +XCMPLX-0K2 j)"
              using A15 A16 A73 A79 A81 sorry
            have "\<one>\<^sub>M <=XXREAL-0R1 j"
              using A15 A79 finseq_1_th_1 sorry
            then have A83: "\<one>\<^sub>M <=XXREAL-0R1 y +XCMPLX-0K2 j"
              using nat_1_th_12 sorry
            have "j <=XXREAL-0R1 n"
              using A15 A79 finseq_1_th_1 sorry
            then have "y +XCMPLX-0K2 j <=XXREAL-0R1 lenFINSEQ-1K4 q"
              using A13 xreal_1_th_7 sorry
            then have "y +XCMPLX-0K2 j inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
              using A83 sorry
            then have A84: "y +XCMPLX-0K2 j inTARSKIR2 domFINSEQ-1K5 q"
              using finseq_1_def_3 sorry
            have "m1 inTARSKIR2 SegFINSEQ-1K2 k"
              using A18 A78 finseq_1_th_17 sorry
            then have A85: "m1 <=XXREAL-0R1 k"
              using finseq_1_th_1 sorry
            have "k <XXREAL-0R3 y"
              using A11 xreal_1_th_29 sorry
            then have A86: "m1 <XXREAL-0R3 y"
              using A85 xxreal_0_th_2 sorry
            have "domFINSEQ-1K5 q1 c=TARSKIR1 domFINSEQ-1K5 q & y <=XXREAL-0R1 y +XCMPLX-0K2 j"
              using nat_1_th_12 relat_1_th_60 sorry
            thus "y1 =HIDDENR1 y2"
              using A5 A78 A82 A84 A86 sorry
          qed
          have A87: "m2 inTARSKIR2 domFINSEQ-1K5 q1 implies (( ex j be NatNAT-1M1 st j inTARSKIR2 domFINSEQ-1K5 q2 & m1 =XBOOLE-0R4 lenFINSEQ-1K4 q1 +XCMPLX-0K2 j) implies y1 =HIDDENR1 y2)"
          proof(rule impI,rule impI)
            assume A88: "m2 inTARSKIR2 domFINSEQ-1K5 q1"
            assume Given: " ex j be NatNAT-1M1 st j inTARSKIR2 domFINSEQ-1K5 q2 & m1 =XBOOLE-0R4 lenFINSEQ-1K4 q1 +XCMPLX-0K2 j"
            then obtain j where
              [ty]:"j be NatNAT-1M1" and 
              A89: "j inTARSKIR2 domFINSEQ-1K5 q2"and A90: "m1 =XBOOLE-0R4 lenFINSEQ-1K4 q1 +XCMPLX-0K2 j"
               sorry
            have A91: "(q1 ^FINSEQ-1K8 q2).FUNCT-1K1 m1 =XBOOLE-0R4 q2 .FUNCT-1K1 j"
              using A89 A90 finseq_1_def_7 sorry
            have "(q1 ^FINSEQ-1K8 q2).FUNCT-1K1 m2 =XBOOLE-0R4 q1 .FUNCT-1K1 m2 & q1 .FUNCT-1K1 m2 =XBOOLE-0R4 q .FUNCT-1K1 m2"
              using A88 finseq_1_def_7 funct_1_th_47 sorry
            then have A92: "q .FUNCT-1K1 m2 =XBOOLE-0R4 q .FUNCT-1K1 (y +XCMPLX-0K2 j)"
              using A15 A16 A73 A89 A91 sorry
            have "\<one>\<^sub>M <=XXREAL-0R1 j"
              using A15 A89 finseq_1_th_1 sorry
            then have A93: "\<one>\<^sub>M <=XXREAL-0R1 y +XCMPLX-0K2 j"
              using nat_1_th_12 sorry
            have "j <=XXREAL-0R1 n"
              using A15 A89 finseq_1_th_1 sorry
            then have "y +XCMPLX-0K2 j <=XXREAL-0R1 lenFINSEQ-1K4 q"
              using A13 xreal_1_th_7 sorry
            then have "y +XCMPLX-0K2 j inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
              using A93 sorry
            then have A94: "y +XCMPLX-0K2 j inTARSKIR2 domFINSEQ-1K5 q"
              using finseq_1_def_3 sorry
            have "m2 inTARSKIR2 SegFINSEQ-1K2 k"
              using A18 A88 finseq_1_th_17 sorry
            then have A95: "m2 <=XXREAL-0R1 k"
              using finseq_1_th_1 sorry
            have "k <XXREAL-0R3 y"
              using A11 xreal_1_th_29 sorry
            then have A96: "m2 <XXREAL-0R3 y"
              using A95 xxreal_0_th_2 sorry
            have "domFINSEQ-1K5 q1 c=TARSKIR1 domFINSEQ-1K5 q & y <=XXREAL-0R1 y +XCMPLX-0K2 j"
              using nat_1_th_12 relat_1_th_60 sorry
            thus "y1 =HIDDENR1 y2"
              using A5 A88 A92 A94 A96 sorry
          qed
          have "( ex j1 be NatNAT-1M1 st j1 inTARSKIR2 domFINSEQ-1K5 q2 & m1 =XBOOLE-0R4 lenFINSEQ-1K4 q1 +XCMPLX-0K2 j1) implies (( ex j2 be NatNAT-1M1 st j2 inTARSKIR2 domFINSEQ-1K5 q2 & m2 =XBOOLE-0R4 lenFINSEQ-1K4 q1 +XCMPLX-0K2 j2) implies y1 =HIDDENR1 y2)"
          proof(rule impI,rule impI)
            assume Given: " ex j1 be NatNAT-1M1 st j1 inTARSKIR2 domFINSEQ-1K5 q2 & m1 =XBOOLE-0R4 lenFINSEQ-1K4 q1 +XCMPLX-0K2 j1"
            then obtain j1 where
              [ty]:"j1 be NatNAT-1M1" and 
              A97: "j1 inTARSKIR2 domFINSEQ-1K5 q2"and A98: "m1 =XBOOLE-0R4 lenFINSEQ-1K4 q1 +XCMPLX-0K2 j1"
               sorry
            assume Given: " ex j2 be NatNAT-1M1 st j2 inTARSKIR2 domFINSEQ-1K5 q2 & m2 =XBOOLE-0R4 lenFINSEQ-1K4 q1 +XCMPLX-0K2 j2"
            then obtain j2 where
              [ty]:"j2 be NatNAT-1M1" and 
              A99: "j2 inTARSKIR2 domFINSEQ-1K5 q2"and A100: "m2 =XBOOLE-0R4 lenFINSEQ-1K4 q1 +XCMPLX-0K2 j2"
               sorry
            have A101: "(q1 ^FINSEQ-1K8 q2).FUNCT-1K1 m1 =XBOOLE-0R4 q2 .FUNCT-1K1 j1"
              using A97 A98 finseq_1_def_7 sorry
            have A102: "(q1 ^FINSEQ-1K8 q2).FUNCT-1K1 m2 =XBOOLE-0R4 q2 .FUNCT-1K1 j2"
              using A99 A100 finseq_1_def_7 sorry
            have A103: "(q1 ^FINSEQ-1K8 q2).FUNCT-1K1 m1 =XBOOLE-0R4 q .FUNCT-1K1 (y +XCMPLX-0K2 j1)"
              using A15 A16 A97 A101 sorry
            have A104: "(q1 ^FINSEQ-1K8 q2).FUNCT-1K1 m2 =XBOOLE-0R4 q .FUNCT-1K1 (y +XCMPLX-0K2 j2)"
              using A15 A16 A99 A102 sorry
            have A105: "\<one>\<^sub>M <=XXREAL-0R1 j1"
              using A15 A97 finseq_1_th_1 sorry
            have A106: "\<one>\<^sub>M <=XXREAL-0R1 j2"
              using A15 A99 finseq_1_th_1 sorry
            have A107: "\<one>\<^sub>M <=XXREAL-0R1 y +XCMPLX-0K2 j1"
              using A105 nat_1_th_12 sorry
            have A108: "\<one>\<^sub>M <=XXREAL-0R1 y +XCMPLX-0K2 j2"
              using A106 nat_1_th_12 sorry
            have A109: "j1 <=XXREAL-0R1 n"
              using A15 A97 finseq_1_th_1 sorry
            have A110: "j2 <=XXREAL-0R1 n"
              using A15 A99 finseq_1_th_1 sorry
            have A111: "y +XCMPLX-0K2 j1 <=XXREAL-0R1 lenFINSEQ-1K4 q"
              using A13 A109 xreal_1_th_7 sorry
            have A112: "y +XCMPLX-0K2 j2 <=XXREAL-0R1 lenFINSEQ-1K4 q"
              using A13 A110 xreal_1_th_7 sorry
            have A113: "y +XCMPLX-0K2 j1 inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
              using A107 A111 sorry
            have A114: "y +XCMPLX-0K2 j2 inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
              using A108 A112 sorry
            have A115: "y +XCMPLX-0K2 j1 inTARSKIR2 domFINSEQ-1K5 q"
              using A113 finseq_1_def_3 sorry
            have "y +XCMPLX-0K2 j2 inTARSKIR2 domFINSEQ-1K5 q"
              using A114 finseq_1_def_3 sorry
            then have "y +XCMPLX-0K2 j1 =XBOOLE-0R4 y +XCMPLX-0K2 j2"
              using A5 A73 A103 A104 A115 sorry
            thus "y1 =HIDDENR1 y2"
              using A98 A100 sorry
          qed
          thus "y1 =HIDDENR1 y2"
            using A72 A75 A77 A87 finseq_1_th_25 sorry
        qed "sorry"
        thus "q1 ^FINSEQ-1K8 q2 be one-to-oneFUNCT-1V2"
          using funct_1_def_4 sorry
      qed
      have A116: " for j be NatNAT-1M1 holds j inTARSKIR2 domFINSEQ-1K5 (q1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) implies q .FUNCT-1K1 j =XBOOLE-0R4 (q1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 j"
      proof(rule ballI,rule impI)
        fix j assume [ty]: "j be NatNAT-1M1"
        assume A117: "j inTARSKIR2 domFINSEQ-1K5 (q1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
        have A118: "j inTARSKIR2 domFINSEQ-1K5 q1 implies q .FUNCT-1K1 j =XBOOLE-0R4 (q1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 j"
        proof(rule impI)
          assume A119: "j inTARSKIR2 domFINSEQ-1K5 q1"
          then have "(q1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 j =XBOOLE-0R4 q1 .FUNCT-1K1 j"
            using finseq_1_def_7 sorry
          thus "q .FUNCT-1K1 j =XBOOLE-0R4 (q1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 j"
            using A119 funct_1_th_47 sorry
        qed
        have "( ex i be NatNAT-1M1 st i inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 x*>) & j =XBOOLE-0R4 lenFINSEQ-1K4 q1 +XCMPLX-0K2 i) implies q .FUNCT-1K1 j =XBOOLE-0R4 (q1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 j"
        proof(rule impI)
          assume Given: " ex i be NatNAT-1M1 st i inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 x*>) & j =XBOOLE-0R4 lenFINSEQ-1K4 q1 +XCMPLX-0K2 i"
          then obtain i where
            [ty]:"i be NatNAT-1M1" and 
            A120: "i inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 x*>)"and A121: "j =XBOOLE-0R4 lenFINSEQ-1K4 q1 +XCMPLX-0K2 i"
             sorry
          have "i inTARSKIR2 {TARSKIK1 \<one>\<^sub>M}"
            using A120 finseq_1_th_2 finseq_1_th_38 sorry
          then have "i =XBOOLE-0R4 \<one>\<^sub>M"
            using tarski_def_1 sorry
          thus "q .FUNCT-1K1 j =XBOOLE-0R4 (q1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 j"
            using A8 A11 A19 A121 finseq_1_th_42 sorry
        qed
        thus "q .FUNCT-1K1 j =XBOOLE-0R4 (q1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 j"
          using A117 A118 finseq_1_th_25 sorry
      qed "sorry"
      have " for j be NatNAT-1M1 holds j inTARSKIR2 domFINSEQ-1K5 q2 implies q2 .FUNCT-1K1 j =HIDDENR1 q .FUNCT-1K1 (lenFINSEQ-1K4 (q1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) +XCMPLX-0K2 j)"
      proof(rule ballI,rule impI)
        fix j assume [ty]: "j be NatNAT-1M1"
        assume "j inTARSKIR2 domFINSEQ-1K5 q2"
        then have "q2 .FUNCT-1K1 j =HIDDENR1 q .FUNCT-1K1 ((lenFINSEQ-1K4 q1 +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 j)"
          using A11 A15 A16 A19 sorry
        also have "... = q .FUNCT-1K1 ((lenFINSEQ-1K4 q1 +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>))+XCMPLX-0K2 j)"
          using finseq_1_th_39 sorry
        also have "... = q .FUNCT-1K1 (lenFINSEQ-1K4 (q1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) +XCMPLX-0K2 j)"
          using finseq_1_th_22 sorry
        finally show "q2 .FUNCT-1K1 j =HIDDENR1 q .FUNCT-1K1 (lenFINSEQ-1K4 (q1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) +XCMPLX-0K2 j)"
           sorry
      qed "sorry"
      then have "(q1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))^FINSEQ-1K8 q2 =FUNCT-1R1 q"
        using A20 A116 finseq_1_def_7 sorry
      then have A122: "lenFINSEQ-1K4 q =HIDDENR1 lenFINSEQ-1K4 (q1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) +NAT-1K1 lenFINSEQ-1K4 q2"
        using finseq_1_th_22 sorry
      also have "... = (lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>) +NAT-1K1 lenFINSEQ-1K4 q1)+NAT-1K1 lenFINSEQ-1K4 q2"
        using finseq_1_th_22 sorry
      also have "... = (\<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 q1)+NAT-1K1 lenFINSEQ-1K4 q2"
        using finseq_1_th_40 sorry
      also have "... = \<one>\<^sub>M +NAT-1K1 (lenFINSEQ-1K4 q1 +NAT-1K1 lenFINSEQ-1K4 q2)"
         sorry
      also have "... = lenFINSEQ-1K4 (q1 ^FINSEQ-1K8 q2) +NAT-1K1 \<one>\<^sub>M"
        using finseq_1_th_22 sorry
      finally have "lenFINSEQ-1K4 q =HIDDENR1 lenFINSEQ-1K4 (q1 ^FINSEQ-1K8 q2) +NAT-1K1 \<one>\<^sub>M"
         sorry
      have "lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) =HIDDENR1 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>)"
        using finseq_1_th_22 sorry
      also have "... = lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M"
        using finseq_1_th_40 sorry
      finally have "lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) =HIDDENR1 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M"
         sorry
      thus "lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) =XBOOLE-0R4 lenFINSEQ-1K4 q"
        using A2 A3 A4 A21 A51 A52 A71 A122 funct_1_th_52 sorry
    qed "sorry"
    then have A123: " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds ?P(p) implies ?P(p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
       sorry
    have " for p be FinSequenceFINSEQ-1M1 holds ?P(p)"
      using finseq_1_sch_3 A1 A123 sorry
    thus " not (((rngFUNCT-1K2 p =XBOOLE-0R4 rngFUNCT-1K2 q & p be one-to-oneFUNCT-1V2) & q be one-to-oneFUNCT-1V2) &  not lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_49:
" for D be setHIDDENM2 holds {}XBOOLE-0K1 inTARSKIR2 D * FINSEQ-1K14"
proof-
  have " for D be setHIDDENM2 holds {}XBOOLE-0K1 inTARSKIR2 D * FINSEQ-1K14"
  proof(rule ballI)
    fix D assume [ty]: "D be setHIDDENM2"
    have "{}XBOOLE-0K1 =FUNCT-1R1 <*>FINSEQ-1K7 D"
       sorry
    thus "{}XBOOLE-0K1 inTARSKIR2 D * FINSEQ-1K14"
      using finseq_1_def_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem finseq_1_sch_4:
  fixes Df0 Pp1 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  shows " ex X be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 X iff ( ex p be FinSequenceFINSEQ-1M1 st (p inTARSKIR2 Df0 * FINSEQ-1K14 & Pp1(p)) & x =HIDDENR1 p)"
  proof-
    have " ex tVar17 be setHIDDENM2 st  for x be objectHIDDENM1 holds  not (x inHIDDENR3 tVar17 & ( for p be FinSequenceFINSEQ-1M1 holds  not ((p inTARSKIR2 Df0 * FINSEQ-1K14 & Pp1(p)) & x =HIDDENR1 p))) &  not ( not ( for p be FinSequenceFINSEQ-1M1 holds  not ((p inTARSKIR2 Df0 * FINSEQ-1K14 & Pp1(p)) & x =HIDDENR1 p)) &  not x inHIDDENR3 tVar17)"
    proof-
      let ?R = "\<lambda>Lamb1.  ex p be FinSequenceFINSEQ-1M1 st Pp1(p) & Lamb1 =HIDDENR1 p"
      obtain Y where
        [ty]:"Y be setHIDDENM2" and 
        A1: " for x be objectHIDDENM1 holds x inHIDDENR3 Y iff x inHIDDENR3 Df0 * FINSEQ-1K14 & ?R(x)"
        using xboole_0_sch_1 sorry
      show " ex tVar17 be setHIDDENM2 st  for x be objectHIDDENM1 holds  not (x inHIDDENR3 tVar17 & ( for p be FinSequenceFINSEQ-1M1 holds  not ((p inTARSKIR2 Df0 * FINSEQ-1K14 & Pp1(p)) & x =HIDDENR1 p))) &  not ( not ( for p be FinSequenceFINSEQ-1M1 holds  not ((p inTARSKIR2 Df0 * FINSEQ-1K14 & Pp1(p)) & x =HIDDENR1 p)) &  not x inHIDDENR3 tVar17)"
      proof(rule bexI[of _ "Y"])
        have " for x be objectHIDDENM1 holds x inHIDDENR3 Y iff ( ex p be FinSequenceFINSEQ-1M1 st (p inTARSKIR2 Df0 * FINSEQ-1K14 & Pp1(p)) & x =HIDDENR1 p)"
        proof-
          have " for x be objectHIDDENM1 holds  not (x inHIDDENR3 Y & ( for p be FinSequenceFINSEQ-1M1 holds  not ((p inTARSKIR2 Df0 * FINSEQ-1K14 & Pp1(p)) & x =HIDDENR1 p))) &  not ( not ( for p be FinSequenceFINSEQ-1M1 holds  not ((p inTARSKIR2 Df0 * FINSEQ-1K14 & Pp1(p)) & x =HIDDENR1 p)) &  not x inHIDDENR3 Y)"
          proof(rule ballI)
            fix x assume [ty]: "x be objectHIDDENM1"
            have "x inHIDDENR3 Y implies ( ex p be FinSequenceFINSEQ-1M1 st (p inTARSKIR2 Df0 * FINSEQ-1K14 & Pp1(p)) & x =HIDDENR1 p)"
            proof(rule impI)
              assume "x inHIDDENR3 Y"
              then have "x inHIDDENR3 Df0 * FINSEQ-1K14 & ( ex p be FinSequenceFINSEQ-1M1 st Pp1(p) & x =HIDDENR1 p)"
                using A1 sorry
              thus " ex p be FinSequenceFINSEQ-1M1 st (p inTARSKIR2 Df0 * FINSEQ-1K14 & Pp1(p)) & x =HIDDENR1 p"
                 sorry
            qed
            thus " not (x inHIDDENR3 Y & ( for p be FinSequenceFINSEQ-1M1 holds  not ((p inTARSKIR2 Df0 * FINSEQ-1K14 & Pp1(p)) & x =HIDDENR1 p))) &  not ( not ( for p be FinSequenceFINSEQ-1M1 holds  not ((p inTARSKIR2 Df0 * FINSEQ-1K14 & Pp1(p)) & x =HIDDENR1 p)) &  not x inHIDDENR3 Y)"
              using A1 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus " for x be objectHIDDENM1 holds  not (x inHIDDENR3 Y & ( for p be FinSequenceFINSEQ-1M1 holds  not ((p inTARSKIR2 Df0 * FINSEQ-1K14 & Pp1(p)) & x =HIDDENR1 p))) &  not ( not ( for p be FinSequenceFINSEQ-1M1 holds  not ((p inTARSKIR2 Df0 * FINSEQ-1K14 & Pp1(p)) & x =HIDDENR1 p)) &  not x inHIDDENR3 Y)"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mdef finseq_1_def_12 ("FinSubsequence-likeFINSEQ-1V2" 70 ) where
"attr FinSubsequence-likeFINSEQ-1V2 for FunctionFUNCT-1M1 means
  (\<lambda>IT.  ex k be NatNAT-1M1 st domRELAT-1K1 IT c=TARSKIR1 SegFINSEQ-1K2 k)"..

mtheorem finseq_1_cl_20:
"cluster FinSubsequence-likeFINSEQ-1V2 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be FinSubsequence-likeFINSEQ-1V2"
  proof-
    have " ex tVar18 be FunctionFUNCT-1M1 st tVar18 be FinSubsequence-likeFINSEQ-1V2"
    proof-
      show " ex tVar18 be FunctionFUNCT-1M1 st tVar18 be FinSubsequence-likeFINSEQ-1V2"
      proof(rule bexI[of _ "{}XBOOLE-0K1"])
        have "domRELAT-1K1 ({}XBOOLE-0K1) c=TARSKIR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 ({}XBOOLE-0K1))"
        proof-
          show "domRELAT-1K1 ({}XBOOLE-0K1) c=TARSKIR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 ({}XBOOLE-0K1))"
             sorry
        qed
        thus "{}XBOOLE-0K1 be FinSubsequence-likeFINSEQ-1V2"
          using bexI[of _ "lenFINSEQ-1K4 ({}XBOOLE-0K1)"] finseq_1_def_12 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax FINSEQ_1M4 :: "Ty" ("FinSubsequenceFINSEQ-1M4" 70)
translations "FinSubsequenceFINSEQ-1M4" \<rightharpoonup> "FinSubsequence-likeFINSEQ-1V2\<bar>FunctionFUNCT-1M1"

mtheorem finseq_1_cl_21:
"cluster FinSequence-likeFINSEQ-1V1 also-is FinSubsequence-likeFINSEQ-1V2 for FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be FunctionFUNCT-1M1 holds it be FinSequence-likeFINSEQ-1V1 implies it be FinSubsequence-likeFINSEQ-1V2"
     sorry
qed "sorry"

mtheorem finseq_1_cl_22:
  mlet "p be FinSubsequenceFINSEQ-1M4", "X be setHIDDENM2"
"cluster p  |RELAT-1K8 X as-term-is FinSubsequence-likeFINSEQ-1V2"
proof
(*coherence*)
  show "p  |RELAT-1K8 X be FinSubsequence-likeFINSEQ-1V2"
  proof-
    obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A1: "domRELAT-1K1 p c=TARSKIR1 SegFINSEQ-1K2 k"
      using finseq_1_def_12 sorry
    have "domRELAT-1K1 (p  |RELAT-1K8 X) c=TARSKIR1 domRELAT-1K1 p"
      using relat_1_th_60 sorry
    thus "p  |RELAT-1K8 X be FinSubsequence-likeFINSEQ-1V2"
      using A1 xboole_1_th_1 sorry
  qed
qed "sorry"

mtheorem finseq_1_cl_23:
  mlet "p be FinSubsequenceFINSEQ-1M4", "X be setHIDDENM2"
"cluster X  |`RELAT-1K9 p as-term-is FinSubsequence-likeFINSEQ-1V2"
proof
(*coherence*)
  show "X  |`RELAT-1K9 p be FinSubsequence-likeFINSEQ-1V2"
  proof-
    obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A2: "domRELAT-1K1 p c=TARSKIR1 SegFINSEQ-1K2 k"
      using finseq_1_def_12 sorry
    have "domRELAT-1K1 (X  |`RELAT-1K9 p) c=TARSKIR1 domRELAT-1K1 p"
      using funct_1_th_56 sorry
    thus "X  |`RELAT-1K9 p be FinSubsequence-likeFINSEQ-1V2"
      using A2 xboole_1_th_1 sorry
  qed
qed "sorry"

mtheorem finseq_1_cl_24:
"cluster note-that NATNUMBERSK1 -definedRELAT-1V4 for FinSubsequenceFINSEQ-1M4"
proof
(*coherence*)
  show " for it be FinSubsequenceFINSEQ-1M4 holds it be NATNUMBERSK1 -definedRELAT-1V4"
  proof-
    have " for f be FinSubsequenceFINSEQ-1M4 holds f be NATNUMBERSK1 -definedRELAT-1V4"
    proof(rule ballI)
      fix f assume [ty]: "f be FinSubsequenceFINSEQ-1M4"
      have Cut2048: " ex n be NatNAT-1M1 st domRELAT-1K1 f c=TARSKIR1 SegFINSEQ-1K2 n"
        using finseq_1_def_12 sorry
      have "domRELAT-1K1 f c=TARSKIR1 NATNUMBERSK1"
      proof-
        show "domRELAT-1K1 f c=TARSKIR1 NATNUMBERSK1"
          using xboole_1_th_1 Cut2048 sorry
      qed
      thus "f be NATNUMBERSK1 -definedRELAT-1V4"
        using relat_1_def_18 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

reserve p9 for "FinSubsequenceFINSEQ-1M4"
mdef finseq_1_def_13 ("SgmFINSEQ-1K15  _ " [228]228 ) where
  mlet "X be setHIDDENM2"
"assume  ex k be NatNAT-1M1 st X c=TARSKIR1 SegFINSEQ-1K2 k func SgmFINSEQ-1K15 X \<rightarrow> FinSequenceFINSEQ-1M3-of NATNUMBERSK1 means
  \<lambda>it. rngFUNCT-1K2 it =XBOOLE-0R4 X & ( for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds (((\<one>\<^sub>M <=XXREAL-0R1 l & l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 it) & k1 =XBOOLE-0R4 it .FUNCT-1K1 l) & k2 =XBOOLE-0R4 it .FUNCT-1K1 m implies k1 <XXREAL-0R3 k2)"
proof-
  (*existence*)
    show "( ex k be NatNAT-1M1 st X c=TARSKIR1 SegFINSEQ-1K2 k) implies ( ex it be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st rngFUNCT-1K2 it =XBOOLE-0R4 X & ( for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds (((\<one>\<^sub>M <=XXREAL-0R1 l & l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 it) & k1 =XBOOLE-0R4 it .FUNCT-1K1 l) & k2 =XBOOLE-0R4 it .FUNCT-1K1 m implies k1 <XXREAL-0R3 k2))"
    proof(rule impI)
      assume Assume: " ex k be NatNAT-1M1 st X c=TARSKIR1 SegFINSEQ-1K2 k"
      have Given: " ex k be NatNAT-1M1 st X c=TARSKIR1 SegFINSEQ-1K2 k"
        using Assume sorry
      then obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A1: "X c=TARSKIR1 SegFINSEQ-1K2 k"
         sorry
      show " ex it be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st rngFUNCT-1K2 it =XBOOLE-0R4 X & ( for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds (((\<one>\<^sub>M <=XXREAL-0R1 l & l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 it) & k1 =XBOOLE-0R4 it .FUNCT-1K1 l) & k2 =XBOOLE-0R4 it .FUNCT-1K1 m implies k1 <XXREAL-0R3 k2)"
      proof-
        have " not ( for VarFor1 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (rngFUNCT-1K2 VarFor1 =XBOOLE-0R4 X & ( for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds  not (((((\<one>\<^sub>M <=XXREAL-0R1 l &  not l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 VarFor1) & k1 =XBOOLE-0R4 VarFor1 .FUNCT-1K1 l) & k2 =XBOOLE-0R4 VarFor1 .FUNCT-1K1 m) & k1 <XXREAL-0R3 k2))))"
        proof-
          let ?P = "\<lambda>Lamb1.  for X be setHIDDENM2 holds X c=TARSKIR1 SegFINSEQ-1K2 Lamb1 implies ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st rngFUNCT-1K2 p =XBOOLE-0R4 X & ( for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds (((\<one>\<^sub>M <=XXREAL-0R1 l & l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 p) & k1 =XBOOLE-0R4 p .FUNCT-1K1 l) & k2 =XBOOLE-0R4 p .FUNCT-1K1 m implies k1 <XXREAL-0R3 k2))"
          have A2: "?P(0NUMBERSK6)"
          proof-
            have " for X be setHIDDENM2 holds X c=TARSKIR1 SegFINSEQ-1K2 (0NUMBERSK6) implies ( ex tVar20 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st rngFUNCT-1K2 tVar20 =XBOOLE-0R4 X & ( for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds  not (((((\<one>\<^sub>M <=XXREAL-0R1 l &  not l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 tVar20) & k1 =XBOOLE-0R4 tVar20 .FUNCT-1K1 l) & k2 =XBOOLE-0R4 tVar20 .FUNCT-1K1 m) & k1 <XXREAL-0R3 k2)))"
            proof(rule ballI,rule impI)
              fix X assume [ty]: "X be setHIDDENM2"
              assume A3: "X c=TARSKIR1 SegFINSEQ-1K2 (0NUMBERSK6)"
              show " ex tVar20 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st rngFUNCT-1K2 tVar20 =XBOOLE-0R4 X & ( for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds  not (((((\<one>\<^sub>M <=XXREAL-0R1 l &  not l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 tVar20) & k1 =XBOOLE-0R4 tVar20 .FUNCT-1K1 l) & k2 =XBOOLE-0R4 tVar20 .FUNCT-1K1 m) & k1 <XXREAL-0R3 k2))"
              proof(rule bexI[of _ "<*>FINSEQ-1K7 NATNUMBERSK1"],rule conjMI)
                show "rngFUNCT-1K2 <*>FINSEQ-1K7 NATNUMBERSK1 =XBOOLE-0R4 X"
                  using A3 sorry
                show " for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds  not (((((\<one>\<^sub>M <=XXREAL-0R1 l &  not l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 <*>FINSEQ-1K7 NATNUMBERSK1) & k1 =XBOOLE-0R4 <*>FINSEQ-1K7 NATNUMBERSK1 .FUNCT-1K1 l) & k2 =XBOOLE-0R4 <*>FINSEQ-1K7 NATNUMBERSK1 .FUNCT-1K1 m) & k1 <XXREAL-0R3 k2)"
                   sorry
              qed "sorry"
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have A4: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
          proof-
            have " for k be NatNAT-1M1 holds ( for X be setHIDDENM2 holds X c=TARSKIR1 SegFINSEQ-1K2 k implies ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st rngFUNCT-1K2 p =XBOOLE-0R4 X & ( for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds (((\<one>\<^sub>M <=XXREAL-0R1 l & l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 p) & k1 =XBOOLE-0R4 p .FUNCT-1K1 l) & k2 =XBOOLE-0R4 p .FUNCT-1K1 m implies k1 <XXREAL-0R3 k2))) implies ( for X be setHIDDENM2 holds X c=TARSKIR1 SegFINSEQ-1K2 (k +NAT-1K1 \<one>\<^sub>M) implies  not ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (rngFUNCT-1K2 p =XBOOLE-0R4 X & ( for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds  not (((((\<one>\<^sub>M <=XXREAL-0R1 l &  not l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 p) & k1 =XBOOLE-0R4 p .FUNCT-1K1 l) & k2 =XBOOLE-0R4 p .FUNCT-1K1 m) & k1 <XXREAL-0R3 k2)))))"
            proof(rule ballI,rule impI,rule ballI,rule impI)
              fix k assume [ty]: "k be NatNAT-1M1"
              assume A5: " for X be setHIDDENM2 holds X c=TARSKIR1 SegFINSEQ-1K2 k implies ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st rngFUNCT-1K2 p =XBOOLE-0R4 X & ( for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds (((\<one>\<^sub>M <=XXREAL-0R1 l & l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 p) & k1 =XBOOLE-0R4 p .FUNCT-1K1 l) & k2 =XBOOLE-0R4 p .FUNCT-1K1 m implies k1 <XXREAL-0R3 k2))"
              fix X assume [ty]: "X be setHIDDENM2"
              assume A6: "X c=TARSKIR1 SegFINSEQ-1K2 (k +NAT-1K1 \<one>\<^sub>M)"
              have " not X c=TARSKIR1 SegFINSEQ-1K2 k implies  not ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (rngFUNCT-1K2 p =XBOOLE-0R4 X & ( for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds  not (((((\<one>\<^sub>M <=XXREAL-0R1 l &  not l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 p) & k1 =XBOOLE-0R4 p .FUNCT-1K1 l) & k2 =XBOOLE-0R4 p .FUNCT-1K1 m) & k1 <XXREAL-0R3 k2))))"
              proof(rule impI)
                assume " not X c=TARSKIR1 SegFINSEQ-1K2 k"
                then obtain x where
                  [ty]:"x be objectHIDDENM1" and 
                  A7: "x inHIDDENR3 X"and A8: " not x inHIDDENR3 SegFINSEQ-1K2 k"
                   sorry
                have "x inHIDDENR3 SegFINSEQ-1K2 (k +NAT-1K1 \<one>\<^sub>M)"
                  using A6 A7 sorry
                then obtain n where 
                  [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = x"
                   sorry
                have A9: "n =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
                proof-
                  have "n <>HIDDENR2 k +NAT-1K1 \<one>\<^sub>M implies  False "
                  proof(rule impI)
                    assume A10: "n <>HIDDENR2 k +NAT-1K1 \<one>\<^sub>M"
                    have A11: "n <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
                      using A6 A7 finseq_1_th_1 sorry
                    have A12: "\<one>\<^sub>M <=XXREAL-0R1 n"
                      using A6 A7 finseq_1_th_1 sorry
                    have "n <=XXREAL-0R1 k"
                      using A10 A11 nat_1_th_8 sorry
                    thus " False "
                      using A8 A12 sorry
                  qed
                  thus " ?thesis "
                     sorry
                qed
                let ?Y = "X \\SUBSET-1K6 {TARSKIK1 k +NAT-1K1 \<one>\<^sub>M }"
                have A13: "?Y c=TARSKIR1 SegFINSEQ-1K2 k"
                proof-
                  have "X \\SUBSET-1K6 {TARSKIK1 k +NAT-1K1 \<one>\<^sub>M } c=TARSKIR1 SegFINSEQ-1K2 k"
                  proof-
                    have " for x be objectHIDDENM1 holds x inHIDDENR3 X \\SUBSET-1K6 {TARSKIK1 k +NAT-1K1 \<one>\<^sub>M } implies x inHIDDENR3 SegFINSEQ-1K2 k"
                    proof(rule ballI,rule impI)
                      fix x assume [ty]: "x be objectHIDDENM1"
                      assume A14: "x inHIDDENR3 ?Y"
                      then have A15: "x inHIDDENR3 X"
                         sorry
                      have A16: " not x inHIDDENR3 {TARSKIK1 k +NAT-1K1 \<one>\<^sub>M }"
                        using A14 xboole_0_def_5 sorry
                      have A17: "x inHIDDENR3 SegFINSEQ-1K2 (k +NAT-1K1 \<one>\<^sub>M)"
                        using A6 A15 sorry
                      have A18: "x <>HIDDENR2 k +NAT-1K1 \<one>\<^sub>M"
                        using A16 tarski_def_1 sorry
                      obtain m where 
                        [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and mDef:"m = x"
                        using A17 sorry
                      have A19: "m <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
                        using A6 A15 finseq_1_th_1 sorry
                      have A20: "\<one>\<^sub>M <=XXREAL-0R1 m"
                        using A6 A15 finseq_1_th_1 sorry
                      have "m <=XXREAL-0R1 k"
                        using A18 A19 nat_1_th_8 sorry
                      thus "x inHIDDENR3 SegFINSEQ-1K2 k"
                        using A20 sorry
                    qed "sorry"
                    thus "X \\SUBSET-1K6 {TARSKIK1 k +NAT-1K1 \<one>\<^sub>M } c=TARSKIR1 SegFINSEQ-1K2 k"
                      using tarski_def_3 sorry
                  qed
                  thus " ?thesis "
                     sorry
                qed
                then obtain p where
                  [ty]:"p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
                  A21: "rngFUNCT-1K2 p =XBOOLE-0R4 ?Y"and A22: " for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds (((\<one>\<^sub>M <=XXREAL-0R1 l & l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 p) & k1 =XBOOLE-0R4 p .FUNCT-1K1 l) & k2 =XBOOLE-0R4 p .FUNCT-1K1 m implies k1 <XXREAL-0R3 k2"
                  using A5 sorry
                obtain q where
                  [ty]:"q be FinSequenceFINSEQ-1M1" and 
                  A23: "q =FUNCT-1R1 p ^FINSEQ-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> (<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> k +NAT-1K1 \<one>\<^sub>M *>)"
                   sorry
                have 
                  [ty]:"q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                  using A23 sorry
                have A24: "rngFUNCT-1K2 q =HIDDENR1 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> k +NAT-1K1 \<one>\<^sub>M *>)"
                  using A23 finseq_1_th_31 sorry
                also have "... = ?Y \\/XBOOLE-0K2 {TARSKIK1 k +NAT-1K1 \<one>\<^sub>M }"
                  using A21 finseq_1_th_38 sorry
                also have "... = X \\/XBOOLE-0K2 {TARSKIK1 k +NAT-1K1 \<one>\<^sub>M }"
                  using xboole_1_th_39 sorry
                also have "... = X"
                  using A7 A9 xboole_1_th_12 zfmisc_1_th_31 sorry
                finally have "rngFUNCT-1K2 q =HIDDENR1 X"
                   sorry
                have " for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds (((\<one>\<^sub>M <=XXREAL-0R1 l & l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 q) & k1 =XBOOLE-0R4 q .FUNCT-1K1 l) & k2 =XBOOLE-0R4 q .FUNCT-1K1 m implies k1 <XXREAL-0R3 k2"
                proof-
                  have " for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 l & (l <XXREAL-0R3 m & (m <=XXREAL-0R1 lenFINSEQ-1K4 q & (k1 =XBOOLE-0R4 q .FUNCT-1K1 l & k2 =XBOOLE-0R4 q .FUNCT-1K1 m))) implies  not k1 <XXREAL-0R3 k2"
                  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
                    fix l assume [ty]: "l be NatNAT-1M1"
                    fix m assume [ty]: "m be NatNAT-1M1"
                    fix k1 assume [ty]: "k1 be NatNAT-1M1"
                    fix k2 assume [ty]: "k2 be NatNAT-1M1"
                    assume A25: "\<one>\<^sub>M <=XXREAL-0R1 l"
                      and A26: "l <XXREAL-0R3 m"
                      and A27: "m <=XXREAL-0R1 lenFINSEQ-1K4 q"
                      and A28: "k1 =XBOOLE-0R4 q .FUNCT-1K1 l"
                      and A29: "k2 =XBOOLE-0R4 q .FUNCT-1K1 m"
                    have "l <XXREAL-0R3 lenFINSEQ-1K4 (p ^FINSEQ-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> (<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> k +NAT-1K1 \<one>\<^sub>M *>))"
                      using A23 A26 A27 xxreal_0_th_2 sorry
                    then have "l <XXREAL-0R3 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> k +NAT-1K1 \<one>\<^sub>M *>)"
                      using finseq_1_th_22 sorry
                    then have "l <XXREAL-0R3 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M"
                      using finseq_1_th_39 sorry
                    then have "l <=XXREAL-0R1 lenFINSEQ-1K4 p"
                      using nat_1_th_13 sorry
                    then have "l inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
                      using A25 sorry
                    then have A30: "l inTARSKIR2 domFINSEQ-1K5 p"
                      using finseq_1_def_3 sorry
                    have A31: "\<one>\<^sub>M <=XXREAL-0R1 m"
                      using A25 A26 xxreal_0_th_2 sorry
                    have A32: "m =XBOOLE-0R4 lenFINSEQ-1K4 q implies  not k1 <XXREAL-0R3 k2"
                    proof(rule impI)
                      assume A33: "m =XBOOLE-0R4 lenFINSEQ-1K4 q"
                      have "k1 =XBOOLE-0R4 p .FUNCT-1K1 l"
                        using A23 A28 A30 finseq_1_def_7 sorry
                      then have "k1 inTARSKIR2 ?Y"
                        using A21 A30 funct_1_def_3 sorry
                      then have A34: "k1 <=XXREAL-0R1 k"
                        using A13 finseq_1_th_1 sorry
                      have "q .FUNCT-1K1 m =HIDDENR1 (p ^FINSEQ-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> (<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> k +NAT-1K1 \<one>\<^sub>M *>)).FUNCT-1K1 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> k +NAT-1K1 \<one>\<^sub>M *>))"
                        using A23 A33 finseq_1_th_22 sorry
                      also have "... = (p ^FINSEQ-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> (<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> k +NAT-1K1 \<one>\<^sub>M *>)).FUNCT-1K1 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)"
                        using finseq_1_th_39 sorry
                      also have "... = k +NAT-1K1 \<one>\<^sub>M"
                        using finseq_1_th_42 sorry
                      finally have "q .FUNCT-1K1 m =HIDDENR1 k +NAT-1K1 \<one>\<^sub>M"
                         sorry
                      thus " not k1 <XXREAL-0R3 k2"
                        using A29 A34 nat_1_th_13 sorry
                    qed
                    have "m <>HIDDENR2 lenFINSEQ-1K4 q implies  not k1 <XXREAL-0R3 k2"
                    proof(rule impI)
                      assume "m <>HIDDENR2 lenFINSEQ-1K4 q"
                      then have "m <XXREAL-0R3 lenFINSEQ-1K4 (p ^FINSEQ-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> (<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> k +NAT-1K1 \<one>\<^sub>M *>))"
                        using A23 A27 xxreal_0_th_1 sorry
                      then have "m <XXREAL-0R3 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> k +NAT-1K1 \<one>\<^sub>M *>)"
                        using finseq_1_th_22 sorry
                      then have "m <XXREAL-0R3 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M"
                        using finseq_1_th_39 sorry
                      then have A35: "m <=XXREAL-0R1 lenFINSEQ-1K4 p"
                        using nat_1_th_13 sorry
                      then have "m inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
                        using A31 sorry
                      then have "m inTARSKIR2 domFINSEQ-1K5 p"
                        using finseq_1_def_3 sorry
                      then have A36: "k2 =XBOOLE-0R4 p .FUNCT-1K1 m"
                        using A23 A29 finseq_1_def_7 sorry
                      have "k1 =XBOOLE-0R4 p .FUNCT-1K1 l"
                        using A23 A28 A30 finseq_1_def_7 sorry
                      thus " not k1 <XXREAL-0R3 k2"
                        using A22 A25 A26 A35 A36 sorry
                    qed
                    thus " not k1 <XXREAL-0R3 k2"
                      using A32 sorry
                  qed "sorry"
                  thus " ?thesis "
                     sorry
                qed
                thus " not ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (rngFUNCT-1K2 p =XBOOLE-0R4 X & ( for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds  not (((((\<one>\<^sub>M <=XXREAL-0R1 l &  not l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 p) & k1 =XBOOLE-0R4 p .FUNCT-1K1 l) & k2 =XBOOLE-0R4 p .FUNCT-1K1 m) & k1 <XXREAL-0R3 k2))))"
                  using A24 sorry
              qed
              thus " not ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (rngFUNCT-1K2 p =XBOOLE-0R4 X & ( for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds  not (((((\<one>\<^sub>M <=XXREAL-0R1 l &  not l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 p) & k1 =XBOOLE-0R4 p .FUNCT-1K1 l) & k2 =XBOOLE-0R4 p .FUNCT-1K1 m) & k1 <XXREAL-0R3 k2))))"
                using A5 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have " for k be NatNAT-1M1 holds ?P(k)"
            using nat_1_sch_2 A2 A4 sorry
          thus " not ( for VarFor1 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (rngFUNCT-1K2 VarFor1 =XBOOLE-0R4 X & ( for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds  not (((((\<one>\<^sub>M <=XXREAL-0R1 l &  not l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 VarFor1) & k1 =XBOOLE-0R4 VarFor1 .FUNCT-1K1 l) & k2 =XBOOLE-0R4 VarFor1 .FUNCT-1K1 m) & k1 <XXREAL-0R3 k2))))"
            using A1 sorry
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show "( ex k be NatNAT-1M1 st X c=TARSKIR1 SegFINSEQ-1K2 k) implies ( for it1 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for it2 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (rngFUNCT-1K2 it1 =XBOOLE-0R4 X & ( for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds (((\<one>\<^sub>M <=XXREAL-0R1 l & l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 it1) & k1 =XBOOLE-0R4 it1 .FUNCT-1K1 l) & k2 =XBOOLE-0R4 it1 .FUNCT-1K1 m implies k1 <XXREAL-0R3 k2)) & (rngFUNCT-1K2 it2 =XBOOLE-0R4 X & ( for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds (((\<one>\<^sub>M <=XXREAL-0R1 l & l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 it2) & k1 =XBOOLE-0R4 it2 .FUNCT-1K1 l) & k2 =XBOOLE-0R4 it2 .FUNCT-1K1 m implies k1 <XXREAL-0R3 k2)) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: " ex k be NatNAT-1M1 st X c=TARSKIR1 SegFINSEQ-1K2 k"
      have Given: " ex k be NatNAT-1M1 st X c=TARSKIR1 SegFINSEQ-1K2 k"
        using Assume sorry
      then obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A1: "X c=TARSKIR1 SegFINSEQ-1K2 k"
         sorry
      show " for it1 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for it2 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (rngFUNCT-1K2 it1 =XBOOLE-0R4 X & ( for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds (((\<one>\<^sub>M <=XXREAL-0R1 l & l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 it1) & k1 =XBOOLE-0R4 it1 .FUNCT-1K1 l) & k2 =XBOOLE-0R4 it1 .FUNCT-1K1 m implies k1 <XXREAL-0R3 k2)) & (rngFUNCT-1K2 it2 =XBOOLE-0R4 X & ( for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds (((\<one>\<^sub>M <=XXREAL-0R1 l & l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 it2) & k1 =XBOOLE-0R4 it2 .FUNCT-1K1 l) & k2 =XBOOLE-0R4 it2 .FUNCT-1K1 m implies k1 <XXREAL-0R3 k2)) implies it1 =HIDDENR1 it2"
      proof-
        have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (rngFUNCT-1K2 p =XBOOLE-0R4 X & ( for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds (((\<one>\<^sub>M <=XXREAL-0R1 l & l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 p) & k1 =XBOOLE-0R4 p .FUNCT-1K1 l) & k2 =XBOOLE-0R4 p .FUNCT-1K1 m implies k1 <XXREAL-0R3 k2)) & (rngFUNCT-1K2 q =XBOOLE-0R4 X & ( for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds (((\<one>\<^sub>M <=XXREAL-0R1 l & l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 q) & k1 =XBOOLE-0R4 q .FUNCT-1K1 l) & k2 =XBOOLE-0R4 q .FUNCT-1K1 m implies k1 <XXREAL-0R3 k2)) implies p =HIDDENR1 q"
        proof(rule ballI,rule ballI,rule impI)
          fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
          fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
          assume A37: "(rngFUNCT-1K2 p =XBOOLE-0R4 X & ( for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds (((\<one>\<^sub>M <=XXREAL-0R1 l & l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 p) & k1 =XBOOLE-0R4 p .FUNCT-1K1 l) & k2 =XBOOLE-0R4 p .FUNCT-1K1 m implies k1 <XXREAL-0R3 k2)) & (rngFUNCT-1K2 q =XBOOLE-0R4 X & ( for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds (((\<one>\<^sub>M <=XXREAL-0R1 l & l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 q) & k1 =XBOOLE-0R4 q .FUNCT-1K1 l) & k2 =XBOOLE-0R4 q .FUNCT-1K1 m implies k1 <XXREAL-0R3 k2))"
          let ?S = "\<lambda>Lamb1.  for X be setHIDDENM2 holds ( ex k be NatNAT-1M1 st X c=TARSKIR1 SegFINSEQ-1K2 k) implies ((Lamb1 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 & rngFUNCT-1K2 Lamb1 =XBOOLE-0R4 X) & ( for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds (((\<one>\<^sub>M <=XXREAL-0R1 l & l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 Lamb1) & k1 =XBOOLE-0R4 Lamb1 .FUNCT-1K1 l) & k2 =XBOOLE-0R4 Lamb1 .FUNCT-1K1 m implies k1 <XXREAL-0R3 k2) implies ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds rngFUNCT-1K2 q =XBOOLE-0R4 X & ( for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds (((\<one>\<^sub>M <=XXREAL-0R1 l & l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 q) & k1 =XBOOLE-0R4 q .FUNCT-1K1 l) & k2 =XBOOLE-0R4 q .FUNCT-1K1 m implies k1 <XXREAL-0R3 k2) implies q =FUNCT-1R1 Lamb1))"
          have A38: "?S({}XBOOLE-0K1)"
             sorry
          have A39: " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds ?S(p) implies ?S(p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
          proof-
            have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds ( for X be setHIDDENM2 holds ( ex k be NatNAT-1M1 st X c=TARSKIR1 SegFINSEQ-1K2 k) implies ((p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 & rngFUNCT-1K2 p =XBOOLE-0R4 X) & ( for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds (((\<one>\<^sub>M <=XXREAL-0R1 l & l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 p) & k1 =XBOOLE-0R4 p .FUNCT-1K1 l) & k2 =XBOOLE-0R4 p .FUNCT-1K1 m implies k1 <XXREAL-0R3 k2) implies ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds rngFUNCT-1K2 q =XBOOLE-0R4 X & ( for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds (((\<one>\<^sub>M <=XXREAL-0R1 l & l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 q) & k1 =XBOOLE-0R4 q .FUNCT-1K1 l) & k2 =XBOOLE-0R4 q .FUNCT-1K1 m implies k1 <XXREAL-0R3 k2) implies q =FUNCT-1R1 p))) implies ( for X be setHIDDENM2 holds ( ex k be NatNAT-1M1 st X c=TARSKIR1 SegFINSEQ-1K2 k) implies (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>) be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 & (rngFUNCT-1K2 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) =XBOOLE-0R4 X & ( for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds (((\<one>\<^sub>M <=XXREAL-0R1 l & l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))) & k1 =XBOOLE-0R4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 l) & k2 =XBOOLE-0R4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 m implies k1 <XXREAL-0R3 k2)) implies ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds rngFUNCT-1K2 q =XBOOLE-0R4 X & ( for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds (((\<one>\<^sub>M <=XXREAL-0R1 l & l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 q) & k1 =XBOOLE-0R4 q .FUNCT-1K1 l) & k2 =XBOOLE-0R4 q .FUNCT-1K1 m implies k1 <XXREAL-0R3 k2) implies q =FUNCT-1R1 p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))))"
            proof(rule ballI,rule ballI,rule impI,rule ballI,rule impI,rule impMI ,rule impMI ,rule impI,rule ballI,rule impMI ,rule impI)
              fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
              fix x assume [ty]: "x be objectHIDDENM1"
              assume A40: "?S(p)"
              fix X assume [ty]: "X be setHIDDENM2"
              assume Given: " ex k be NatNAT-1M1 st X c=TARSKIR1 SegFINSEQ-1K2 k"
              then obtain k where
                [ty]:"k be NatNAT-1M1" and 
                A41: "X c=TARSKIR1 SegFINSEQ-1K2 k"
                 sorry
              assume A42: "p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>) be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                and A43: "rngFUNCT-1K2 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) =XBOOLE-0R4 X"
                and A44: " for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds (((\<one>\<^sub>M <=XXREAL-0R1 l & l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))) & k1 =XBOOLE-0R4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 l) & k2 =XBOOLE-0R4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 m implies k1 <XXREAL-0R3 k2"
              fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
              assume A45: "rngFUNCT-1K2 q =XBOOLE-0R4 X"
                and A46: " for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds (((\<one>\<^sub>M <=XXREAL-0R1 l & l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 q) & k1 =XBOOLE-0R4 q .FUNCT-1K1 l) & k2 =XBOOLE-0R4 q .FUNCT-1K1 m implies k1 <XXREAL-0R3 k2"
              have "\<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 \<one>\<^sub>M"
                 sorry
              then have A47: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 x*>)"
                using finseq_1_def_8 sorry
              have A48: " ex m be NatNAT-1M1 st m =HIDDENR1 x & ( for l be NatNAT-1M1 holds l inTARSKIR2 X & l <>HIDDENR2 x implies l <XXREAL-0R3 m)"
              proof-
                have " ex tVar21 be NatNAT-1M1 st tVar21 =HIDDENR1 x & ( for l be NatNAT-1M1 holds l inTARSKIR2 X & l <>HIDDENR2 x implies l <XXREAL-0R3 tVar21)"
                proof-
                  have "<*FINSEQ-1K10 x*> be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                    using A42 finseq_1_th_36 sorry
                  then have "rngFUNCT-1K2 (<*FINSEQ-1K10 x*>) c=TARSKIR1 NATNUMBERSK1"
                    using finseq_1_def_4 sorry
                  then have "{TARSKIK1 x} c=TARSKIR1 NATNUMBERSK1"
                    using finseq_1_th_38 sorry
                  then obtain m where 
                    [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and mDef:"m = x"
                    using zfmisc_1_th_31 sorry
                  show " ex tVar21 be NatNAT-1M1 st tVar21 =HIDDENR1 x & ( for l be NatNAT-1M1 holds l inTARSKIR2 X & l <>HIDDENR2 x implies l <XXREAL-0R3 tVar21)"
                  proof(rule bexI[of _ "m"],rule conjMI)
                    show "m =HIDDENR1 x"
                       sorry
                    show " for l be NatNAT-1M1 holds l inTARSKIR2 X & l <>HIDDENR2 x implies l <XXREAL-0R3 m"
                    proof-
                      have " for l be NatNAT-1M1 holds l inTARSKIR2 X & l <>HIDDENR2 x implies  not l <XXREAL-0R3 m"
                      proof(rule ballI,rule impMI ,rule impI)
                        fix l assume [ty]: "l be NatNAT-1M1"
                        assume A49: "l inTARSKIR2 X"
                          and A50: "l <>HIDDENR2 x"
                        obtain y where
                          [ty]:"y be objectHIDDENM1" and 
                          A51: "y inHIDDENR3 domFINSEQ-1K5 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"and A52: "l =XBOOLE-0R4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 y"
                          using A43 A49 funct_1_def_3 sorry
                        have A53: "y inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)))"
                          using A51 finseq_1_def_3 sorry
                        obtain k where 
                          [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = y"
                          using A51 sorry
                        have "k <=XXREAL-0R1 lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
                          using A53 finseq_1_th_1 sorry
                        then have "k <=XXREAL-0R1 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>)"
                          using finseq_1_th_22 sorry
                        then have A54: "k <=XXREAL-0R1 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M"
                          using finseq_1_th_39 sorry
                        have A55: "k <>HIDDENR2 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M"
                        proof-
                          have "k =XBOOLE-0R4 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M implies  False "
                          proof(rule impI)
                            assume "k =XBOOLE-0R4 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M"
                            then have "(p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 k =HIDDENR1 (<*FINSEQ-1K10 x*>).FUNCT-1K1 \<one>\<^sub>M"
                              using A47 finseq_1_def_7 sorry
                            also have "... = x"
                              using finseq_1_def_8 sorry
                            finally have "(p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 k =HIDDENR1 x"
                               sorry
                            thus " False "
                              using A50 A52 sorry
                          qed
                          thus " ?thesis "
                             sorry
                        qed
                        have A56: "\<one>\<^sub>M <=XXREAL-0R1 k"
                          using A53 finseq_1_th_1 sorry
                        have "k <XXREAL-0R3 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M"
                          using A54 A55 xxreal_0_th_1 sorry
                        then have "k <XXREAL-0R3 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>)"
                          using finseq_1_th_39 sorry
                        then have A57: "k <XXREAL-0R3 lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
                          using finseq_1_th_22 sorry
                        have "m =HIDDENR1 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)"
                          using finseq_1_th_42 sorry
                        also have "... = (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>))"
                          using finseq_1_th_39 sorry
                        also have "... = (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
                          using finseq_1_th_22 sorry
                        finally have "m =HIDDENR1 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
                           sorry
                        thus " not l <XXREAL-0R3 m"
                          using A44 A52 A56 A57 sorry
                      qed "sorry"
                      thus " ?thesis "
                         sorry
                    qed
                  qed "sorry"
                qed
                thus " ?thesis "
                   sorry
              qed
              then obtain m where 
                [ty]:"m be NatNAT-1M1" and mDef:"m = x"
                 sorry
              have "lenFINSEQ-1K4 q <>HIDDENR2 0NUMBERSK6"
              proof-
                have "lenFINSEQ-1K4 q =XBOOLE-0R4 0NUMBERSK6 implies  False "
                proof(rule impI)
                  assume "lenFINSEQ-1K4 q =XBOOLE-0R4 0NUMBERSK6"
                  then have "p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>) =FUNCT-1R1 {}XBOOLE-0K1"
                    using A43 A45 finseq_1_lm_3 relat_1_th_38 sorry
                  then have "0NUMBERSK6 =HIDDENR1 lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
                     sorry
                  also have "... = lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>)"
                    using finseq_1_th_22 sorry
                  also have "... = \<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 p"
                    using finseq_1_th_39 sorry
                  finally have "0NUMBERSK6 =HIDDENR1 \<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 p"
                     sorry
                  thus " False "
                     sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              then obtain n where
                [ty]:"n be NatNAT-1M1" and 
                A58: "lenFINSEQ-1K4 q =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
                using nat_1_th_6 sorry
              let ?F = "\<lambda>Lamb1. q .FUNCT-1K1 Lamb1"
              have " ex q9 be FinSequenceFINSEQ-1M1 st lenFINSEQ-1K4 q9 =XBOOLE-0R4 n & ( for m be NatNAT-1M1 holds m inTARSKIR2 domFINSEQ-1K5 q9 implies q9 .FUNCT-1K1 m =XBOOLE-0R4 ?F(m))"
                using finseq_1_sch_2 sorry
              then obtain q9 where
                [ty]:"q9 be FinSequenceFINSEQ-1M1" and 
                A59: "lenFINSEQ-1K4 q9 =XBOOLE-0R4 n"and A60: " for m be NatNAT-1M1 holds m inTARSKIR2 domFINSEQ-1K5 q9 implies q9 .FUNCT-1K1 m =XBOOLE-0R4 q .FUNCT-1K1 m"
                 sorry
              have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 q9 implies x inHIDDENR3 NATNUMBERSK1"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 rngFUNCT-1K2 q9"
                then obtain y where
                  [ty]:"y be objectHIDDENM1" and 
                  A61: "y inHIDDENR3 domFINSEQ-1K5 q9"and A62: "x =HIDDENR1 q9 .FUNCT-1K1 y"
                  using funct_1_def_3 sorry
                have A63: "y inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 q9)"
                  using A61 finseq_1_def_3 sorry
                have 
                  [ty]:"y be ElementSUBSET-1M1-of NATNUMBERSK1"
                  using A61 sorry
                have A64: "y <=XXREAL-0R1 n"
                  using A59 A63 finseq_1_th_1 sorry
                have A65: "n <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
                  using nat_1_th_11 sorry
                have A66: "\<one>\<^sub>M <=XXREAL-0R1 y"
                  using A63 finseq_1_th_1 sorry
                have "y <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
                  using A64 A65 xxreal_0_th_2 sorry
                then have "y inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
                  using A66 sorry
                then have "y inTARSKIR2 domFINSEQ-1K5 q"
                  using A58 finseq_1_def_3 sorry
                then have A67: "q .FUNCT-1K1 y inTARSKIR2 rngFUNCT-1K2 q"
                  using funct_1_def_3 sorry
                have "rngFUNCT-1K2 q c=TARSKIR1 NATNUMBERSK1"
                  using finseq_1_def_4 sorry
                then have "q .FUNCT-1K1 y inTARSKIR2 NATNUMBERSK1"
                  using A67 sorry
                thus "x inHIDDENR3 NATNUMBERSK1"
                  using A60 A61 A62 sorry
              qed "sorry"
              then obtain f where 
                [ty]:"f be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and fDef:"f = q9"
                using finseq_1_def_4 tarski_def_3 sorry
              have A68: "domFINSEQ-1K5 q =HIDDENR1 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
                using A58 finseq_1_def_3 sorry
              also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 q9 +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>))"
                using A59 finseq_1_th_39 sorry
              finally have "domFINSEQ-1K5 q =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 q9 +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>))"
                 sorry
              have A69: " for m be NatNAT-1M1 holds m inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 x*>) implies q .FUNCT-1K1 (lenFINSEQ-1K4 q9 +XCMPLX-0K2 m) =XBOOLE-0R4 (<*FINSEQ-1K10 x*>).FUNCT-1K1 m"
              proof(rule ballI,rule impI)
                fix m assume [ty]: "m be NatNAT-1M1"
                assume "m inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 x*>)"
                then have A70: "m inTARSKIR2 {TARSKIK1 \<one>\<^sub>M}"
                  using finseq_1_def_8 finseq_1_th_2 sorry
                then have A71: "m =XBOOLE-0R4 \<one>\<^sub>M"
                  using tarski_def_1 sorry
                have "q .FUNCT-1K1 (lenFINSEQ-1K4 q9 +XCMPLX-0K2 m) =HIDDENR1 x"
                proof-
                  have "q .FUNCT-1K1 (lenFINSEQ-1K4 q9 +XCMPLX-0K2 m) <>HIDDENR2 x implies  False "
                  proof(rule impI)
                    assume "q .FUNCT-1K1 (lenFINSEQ-1K4 q9 +XCMPLX-0K2 m) <>HIDDENR2 x"
                    then have A72: "q .FUNCT-1K1 lenFINSEQ-1K4 q <>HIDDENR2 x"
                      using A58 A59 A70 tarski_def_1 sorry
                    obtain d where
                      [ty]:"d be NatNAT-1M1" and 
                      A73: "d =HIDDENR1 x"and A74: " for l be NatNAT-1M1 holds l inTARSKIR2 X & l <>HIDDENR2 x implies l <XXREAL-0R3 d"
                      using A48 sorry
                    have "x inHIDDENR3 {TARSKIK1 x}"
                      using tarski_def_1 sorry
                    then have "x inHIDDENR3 rngFUNCT-1K2 (<*FINSEQ-1K10 x*>)"
                      using finseq_1_th_38 sorry
                    then have "x inHIDDENR3 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 (<*FINSEQ-1K10 x*>)"
                      using xboole_0_def_3 sorry
                    then have "x inHIDDENR3 rngFUNCT-1K2 q"
                      using A43 A45 finseq_1_th_31 sorry
                    then obtain y where
                      [ty]:"y be objectHIDDENM1" and 
                      A75: "y inHIDDENR3 domFINSEQ-1K5 q"and A76: "x =HIDDENR1 q .FUNCT-1K1 y"
                      using funct_1_def_3 sorry
                    have A77: "y inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
                      using A75 finseq_1_def_3 sorry
                    have 
                      [ty]:"y be ElementSUBSET-1M1-of NATNUMBERSK1"
                      using A75 sorry
                    have A78: "\<one>\<^sub>M <=XXREAL-0R1 y"
                      using A77 finseq_1_th_1 sorry
                    have A79: "y <=XXREAL-0R1 lenFINSEQ-1K4 q"
                      using A77 finseq_1_th_1 sorry
                    then have A80: "y <XXREAL-0R3 lenFINSEQ-1K4 q"
                      using A72 A76 xxreal_0_th_1 sorry
                    have "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 q"
                      using A78 A79 xxreal_0_th_2 sorry
                    then have "lenFINSEQ-1K4 q inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
                       sorry
                    then have A81: "lenFINSEQ-1K4 q inTARSKIR2 domFINSEQ-1K5 q"
                      using finseq_1_def_3 sorry
                    have A82: "q .FUNCT-1K1 lenFINSEQ-1K4 q inTARSKIR2 X"
                      using A45 A81 funct_1_def_3 sorry
                    obtain k where 
                      [ty]:"k be NatNAT-1M1" and kDef:"k = q .FUNCT-1K1 lenFINSEQ-1K4 q"
                       sorry
                    have "k <XXREAL-0R3 d"
                      using A72 A74 A82 sorry
                    thus " False "
                      using A46 A73 A76 A78 A80 sorry
                  qed
                  thus " ?thesis "
                     sorry
                qed
                thus "q .FUNCT-1K1 (lenFINSEQ-1K4 q9 +XCMPLX-0K2 m) =XBOOLE-0R4 (<*FINSEQ-1K10 x*>).FUNCT-1K1 m"
                  using A71 finseq_1_th_40 sorry
              qed "sorry"
              then have A83: "q9 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>) =FUNCT-1R1 q"
                using A60 A68 finseq_1_def_7 sorry
              have A84: " not x inHIDDENR3 rngFUNCT-1K2 p"
              proof-
                have "x inHIDDENR3 rngFUNCT-1K2 p implies  False "
                proof(rule impI)
                  assume "x inHIDDENR3 rngFUNCT-1K2 p"
                  then obtain y where
                    [ty]:"y be objectHIDDENM1" and 
                    A85: "y inHIDDENR3 domFINSEQ-1K5 p"and A86: "x =HIDDENR1 p .FUNCT-1K1 y"
                    using funct_1_def_3 sorry
                  have A87: "y inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
                    using A85 finseq_1_def_3 sorry
                  have 
                    [ty]:"y be ElementSUBSET-1M1-of NATNUMBERSK1"
                    using A85 sorry
                  have A88: "y <=XXREAL-0R1 lenFINSEQ-1K4 p"
                    using A87 finseq_1_th_1 sorry
                  have A89: "lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M =HIDDENR1 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>)"
                    using finseq_1_th_39 sorry
                  also have "... = lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
                    using finseq_1_th_22 sorry
                  finally have "lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M =HIDDENR1 lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
                     sorry
                  have A90: "\<one>\<^sub>M <=XXREAL-0R1 y"
                    using A87 finseq_1_th_1 sorry
                  have A91: "y <XXREAL-0R3 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M"
                    using A88 nat_1_th_13 sorry
                  have A92: "m =XBOOLE-0R4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 y"
                    using A85 A86 finseq_1_def_7 sorry
                  have "m =XBOOLE-0R4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)"
                    using finseq_1_th_42 sorry
                  thus " False "
                    using A44 A89 A90 A91 A92 sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              have A93: "X =HIDDENR1 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 (<*FINSEQ-1K10 x*>)"
                using A43 finseq_1_th_31 sorry
              also have "... = rngFUNCT-1K2 p \\/XBOOLE-0K2 {TARSKIK1 x}"
                using finseq_1_th_39 sorry
              finally have "X =HIDDENR1 rngFUNCT-1K2 p \\/XBOOLE-0K2 {TARSKIK1 x}"
                 sorry
              have A94: " for z be objectHIDDENM1 holds z inHIDDENR3 (rngFUNCT-1K2 p \\/XBOOLE-0K2 {TARSKIK1 x})\\SUBSET-1K6 {TARSKIK1 x} iff z inHIDDENR3 rngFUNCT-1K2 p"
              proof-
                have " for z be objectHIDDENM1 holds (z inHIDDENR3 (rngFUNCT-1K2 p \\/XBOOLE-0K2 {TARSKIK1 x})\\SUBSET-1K6 {TARSKIK1 x} implies z inHIDDENR3 rngFUNCT-1K2 p) & (z inHIDDENR3 rngFUNCT-1K2 p implies z inHIDDENR3 (rngFUNCT-1K2 p \\/XBOOLE-0K2 {TARSKIK1 x})\\SUBSET-1K6 {TARSKIK1 x})"
                proof(rule ballI,rule conjMI,rule impI)
                  fix z assume [ty]: "z be objectHIDDENM1"
                  show "z inHIDDENR3 (rngFUNCT-1K2 p \\/XBOOLE-0K2 {TARSKIK1 x})\\SUBSET-1K6 {TARSKIK1 x} implies z inHIDDENR3 rngFUNCT-1K2 p"
                  proof(rule impI)
                    assume A95: "z inHIDDENR3 (rngFUNCT-1K2 p \\/XBOOLE-0K2 {TARSKIK1 x})\\SUBSET-1K6 {TARSKIK1 x}"
                    then have " not z inHIDDENR3 {TARSKIK1 x}"
                      using xboole_0_def_5 sorry
                    thus "z inHIDDENR3 rngFUNCT-1K2 p"
                      using A95 xboole_0_def_3 sorry
                  qed
                  assume "z inHIDDENR3 rngFUNCT-1K2 p"
                  then have " not z inHIDDENR3 {TARSKIK1 x} & z inHIDDENR3 rngFUNCT-1K2 p \\/XBOOLE-0K2 {TARSKIK1 x}"
                    using A84 tarski_def_1 xboole_0_def_3 sorry
                  thus "z inHIDDENR3 (rngFUNCT-1K2 p \\/XBOOLE-0K2 {TARSKIK1 x})\\SUBSET-1K6 {TARSKIK1 x}"
                    using xboole_0_def_5 sorry
                qed "sorry"
                thus " ?thesis "
                   sorry
              qed
              have A96: " for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds (((\<one>\<^sub>M <=XXREAL-0R1 l & l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 p) & k1 =XBOOLE-0R4 p .FUNCT-1K1 l) & k2 =XBOOLE-0R4 p .FUNCT-1K1 m implies k1 <XXREAL-0R3 k2"
              proof-
                have " for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 l & (l <XXREAL-0R3 m & (m <=XXREAL-0R1 lenFINSEQ-1K4 p & (k1 =XBOOLE-0R4 p .FUNCT-1K1 l & k2 =XBOOLE-0R4 p .FUNCT-1K1 m))) implies  not k1 <XXREAL-0R3 k2"
                proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
                  fix l assume [ty]: "l be NatNAT-1M1"
                  fix m assume [ty]: "m be NatNAT-1M1"
                  fix k1 assume [ty]: "k1 be NatNAT-1M1"
                  fix k2 assume [ty]: "k2 be NatNAT-1M1"
                  assume A97: "\<one>\<^sub>M <=XXREAL-0R1 l"
                    and A98: "l <XXREAL-0R3 m"
                    and A99: "m <=XXREAL-0R1 lenFINSEQ-1K4 p"
                    and A100: "k1 =XBOOLE-0R4 p .FUNCT-1K1 l"
                    and A101: "k2 =XBOOLE-0R4 p .FUNCT-1K1 m"
                  have "l <=XXREAL-0R1 lenFINSEQ-1K4 p"
                    using A98 A99 xxreal_0_th_2 sorry
                  then have "l inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
                    using A97 sorry
                  then have "l inTARSKIR2 domFINSEQ-1K5 p"
                    using finseq_1_def_3 sorry
                  then have A102: "k1 =XBOOLE-0R4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 l"
                    using A100 finseq_1_def_7 sorry
                  have "\<one>\<^sub>M <=XXREAL-0R1 m"
                    using A97 A98 xxreal_0_th_2 sorry
                  then have "m inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
                    using A99 sorry
                  then have "m inTARSKIR2 domFINSEQ-1K5 p"
                    using finseq_1_def_3 sorry
                  then have A103: "k2 =XBOOLE-0R4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 m"
                    using A101 finseq_1_def_7 sorry
                  have "lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M"
                    using nat_1_th_11 sorry
                  then have "m <=XXREAL-0R1 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M"
                    using A99 xxreal_0_th_2 sorry
                  then have "m <=XXREAL-0R1 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>)"
                    using finseq_1_th_39 sorry
                  then have "m <=XXREAL-0R1 lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
                    using finseq_1_th_22 sorry
                  thus " not k1 <XXREAL-0R3 k2"
                    using A44 A97 A98 A102 A103 sorry
                qed "sorry"
                thus " ?thesis "
                   sorry
              qed
              have A104: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                using A42 finseq_1_th_36 sorry
              have A105: "rngFUNCT-1K2 p =XBOOLE-0R4 X \\SUBSET-1K6 {TARSKIK1 x}"
                using A93 A94 tarski_th_2 sorry
              have A106: " not x inHIDDENR3 rngFUNCT-1K2 f"
              proof-
                have "x inHIDDENR3 rngFUNCT-1K2 f implies  False "
                proof(rule impI)
                  assume "x inHIDDENR3 rngFUNCT-1K2 f"
                  then obtain y where
                    [ty]:"y be objectHIDDENM1" and 
                    A107: "y inHIDDENR3 domFINSEQ-1K5 f"and A108: "x =HIDDENR1 f .FUNCT-1K1 y"
                    using funct_1_def_3 sorry
                  have A109: "y inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 f)"
                    using A107 finseq_1_def_3 sorry
                  have 
                    [ty]:"y be ElementSUBSET-1M1-of NATNUMBERSK1"
                    using A107 sorry
                  have A110: "y <=XXREAL-0R1 lenFINSEQ-1K4 f"
                    using A109 finseq_1_th_1 sorry
                  have A111: "lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M =HIDDENR1 lenFINSEQ-1K4 f +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>)"
                    using finseq_1_th_39 sorry
                  also have "... = lenFINSEQ-1K4 (f ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
                    using finseq_1_th_22 sorry
                  finally have "lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M =HIDDENR1 lenFINSEQ-1K4 (f ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
                     sorry
                  have A112: "\<one>\<^sub>M <=XXREAL-0R1 y"
                    using A109 finseq_1_th_1 sorry
                  have A113: "y <XXREAL-0R3 lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M"
                    using A110 nat_1_th_13 sorry
                  have A114: "m =XBOOLE-0R4 q .FUNCT-1K1 y"
                    using A60 A107 A108 sorry
                  have "m =XBOOLE-0R4 q .FUNCT-1K1 (lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M)"
                    using A83 finseq_1_th_42 sorry
                  thus " False "
                    using A46 A83 A111 A112 A113 A114 sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              have A115: "X =HIDDENR1 rngFUNCT-1K2 f \\/XBOOLE-0K2 rngFUNCT-1K2 (<*FINSEQ-1K10 x*>)"
                using A45 A83 finseq_1_th_31 sorry
              also have "... = rngFUNCT-1K2 f \\/XBOOLE-0K2 {TARSKIK1 x}"
                using finseq_1_th_39 sorry
              finally have "X =HIDDENR1 rngFUNCT-1K2 f \\/XBOOLE-0K2 {TARSKIK1 x}"
                 sorry
              have A116: " for z be objectHIDDENM1 holds z inHIDDENR3 (rngFUNCT-1K2 f \\/XBOOLE-0K2 {TARSKIK1 x})\\SUBSET-1K6 {TARSKIK1 x} iff z inHIDDENR3 rngFUNCT-1K2 f"
              proof-
                have " for z be objectHIDDENM1 holds (z inHIDDENR3 (rngFUNCT-1K2 f \\/XBOOLE-0K2 {TARSKIK1 x})\\SUBSET-1K6 {TARSKIK1 x} implies z inHIDDENR3 rngFUNCT-1K2 f) & (z inHIDDENR3 rngFUNCT-1K2 f implies z inHIDDENR3 (rngFUNCT-1K2 f \\/XBOOLE-0K2 {TARSKIK1 x})\\SUBSET-1K6 {TARSKIK1 x})"
                proof(rule ballI,rule conjMI,rule impI)
                  fix z assume [ty]: "z be objectHIDDENM1"
                  show "z inHIDDENR3 (rngFUNCT-1K2 f \\/XBOOLE-0K2 {TARSKIK1 x})\\SUBSET-1K6 {TARSKIK1 x} implies z inHIDDENR3 rngFUNCT-1K2 f"
                  proof(rule impI)
                    assume A117: "z inHIDDENR3 (rngFUNCT-1K2 f \\/XBOOLE-0K2 {TARSKIK1 x})\\SUBSET-1K6 {TARSKIK1 x}"
                    then have " not z inHIDDENR3 {TARSKIK1 x}"
                      using xboole_0_def_5 sorry
                    thus "z inHIDDENR3 rngFUNCT-1K2 f"
                      using A117 xboole_0_def_3 sorry
                  qed
                  assume "z inHIDDENR3 rngFUNCT-1K2 f"
                  then have " not z inHIDDENR3 {TARSKIK1 x} & z inHIDDENR3 rngFUNCT-1K2 f \\/XBOOLE-0K2 {TARSKIK1 x}"
                    using A106 tarski_def_1 xboole_0_def_3 sorry
                  thus "z inHIDDENR3 (rngFUNCT-1K2 f \\/XBOOLE-0K2 {TARSKIK1 x})\\SUBSET-1K6 {TARSKIK1 x}"
                    using xboole_0_def_5 sorry
                qed "sorry"
                thus " ?thesis "
                   sorry
              qed
              have A118: " for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds (((\<one>\<^sub>M <=XXREAL-0R1 l & l <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 f) & k1 =XBOOLE-0R4 f .FUNCT-1K1 l) & k2 =XBOOLE-0R4 f .FUNCT-1K1 m implies k1 <XXREAL-0R3 k2"
              proof-
                have " for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 l & (l <XXREAL-0R3 m & (m <=XXREAL-0R1 lenFINSEQ-1K4 f & (k1 =XBOOLE-0R4 f .FUNCT-1K1 l & k2 =XBOOLE-0R4 f .FUNCT-1K1 m))) implies  not k1 <XXREAL-0R3 k2"
                proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
                  fix l assume [ty]: "l be NatNAT-1M1"
                  fix m assume [ty]: "m be NatNAT-1M1"
                  fix k1 assume [ty]: "k1 be NatNAT-1M1"
                  fix k2 assume [ty]: "k2 be NatNAT-1M1"
                  assume A119: "\<one>\<^sub>M <=XXREAL-0R1 l"
                    and A120: "l <XXREAL-0R3 m"
                    and A121: "m <=XXREAL-0R1 lenFINSEQ-1K4 f"
                    and A122: "k1 =XBOOLE-0R4 f .FUNCT-1K1 l"
                    and A123: "k2 =XBOOLE-0R4 f .FUNCT-1K1 m"
                  have A124: "m <=XXREAL-0R1 lenFINSEQ-1K4 q"
                    using A58 A59 A121 nat_1_th_13 sorry
                  have "l <=XXREAL-0R1 n"
                    using A59 A120 A121 xxreal_0_th_2 sorry
                  then have A125: "l inTARSKIR2 SegFINSEQ-1K2 n"
                    using A119 sorry
                  have "\<one>\<^sub>M <=XXREAL-0R1 m"
                    using A119 A120 xxreal_0_th_2 sorry
                  then have A126: "m inTARSKIR2 SegFINSEQ-1K2 n"
                    using A59 A121 sorry
                  have A127: "l inTARSKIR2 domFINSEQ-1K5 q9"
                    using A59 A125 finseq_1_def_3 sorry
                  have A128: "m inTARSKIR2 domFINSEQ-1K5 q9"
                    using A59 A126 finseq_1_def_3 sorry
                  have A129: "k1 =XBOOLE-0R4 q .FUNCT-1K1 l"
                    using A60 A122 A127 sorry
                  have "k2 =XBOOLE-0R4 q .FUNCT-1K1 m"
                    using A60 A123 A128 sorry
                  thus " not k1 <XXREAL-0R3 k2"
                    using A46 A119 A120 A124 A129 sorry
                qed "sorry"
                thus " ?thesis "
                   sorry
              qed
              have "rngFUNCT-1K2 f =XBOOLE-0R4 X \\SUBSET-1K6 {TARSKIK1 x}"
                using A115 A116 tarski_th_2 sorry
              then have "q9 =FUNCT-1R1 p"
                using A40 A41 A96 A104 A105 A118 xboole_1_th_1 sorry
              thus "q =FUNCT-1R1 p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)"
                using A60 A68 A69 finseq_1_def_7 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have " for p be FinSequenceFINSEQ-1M1 holds ?S(p)"
            using finseq_1_sch_3 A38 A39 sorry
          thus "p =HIDDENR1 q"
            using A1 A37 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem finseq_1_th_50:
" for p9 be FinSubsequenceFINSEQ-1M4 holds rngFUNCT-1K2 (SgmFINSEQ-1K15 (domRELAT-1K1 p9)) =XBOOLE-0R4 domRELAT-1K1 p9"
proof-
  have " for p9 be FinSubsequenceFINSEQ-1M4 holds rngFUNCT-1K2 (SgmFINSEQ-1K15 (domRELAT-1K1 p9)) =XBOOLE-0R4 domRELAT-1K1 p9"
  proof(rule ballI)
    fix p9 assume [ty]: "p9 be FinSubsequenceFINSEQ-1M4"
    have " ex k be NatNAT-1M1 st domRELAT-1K1 p9 c=TARSKIR1 SegFINSEQ-1K2 k"
      using finseq_1_def_12 sorry
    thus "rngFUNCT-1K2 (SgmFINSEQ-1K15 (domRELAT-1K1 p9)) =XBOOLE-0R4 domRELAT-1K1 p9"
      using finseq_1_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef finseq_1_def_14 ("SeqFINSEQ-1K16  _ " [228]228 ) where
  mlet "p9 be FinSubsequenceFINSEQ-1M4"
"func SeqFINSEQ-1K16 p9 \<rightarrow> FunctionFUNCT-1M1 equals
  p9 *FUNCT-1K3 SgmFINSEQ-1K15 (domRELAT-1K1 p9)"
proof-
  (*coherence*)
    show "p9 *FUNCT-1K3 SgmFINSEQ-1K15 (domRELAT-1K1 p9) be FunctionFUNCT-1M1"
       sorry
qed "sorry"

mtheorem finseq_1_cl_25:
  mlet "p9 be FinSubsequenceFINSEQ-1M4"
"cluster SeqFINSEQ-1K16 p9 as-term-is FinSequence-likeFINSEQ-1V1"
proof
(*coherence*)
  show "SeqFINSEQ-1K16 p9 be FinSequence-likeFINSEQ-1V1"
  proof-
    have "rngFUNCT-1K2 (SgmFINSEQ-1K15 (domRELAT-1K1 p9)) =XBOOLE-0R4 domRELAT-1K1 p9"
      using finseq_1_th_50 sorry
    then have "domRELAT-1K1 (p9 *FUNCT-1K3 SgmFINSEQ-1K15 (domRELAT-1K1 p9)) =HIDDENR1 domFINSEQ-1K5 (SgmFINSEQ-1K15 (domRELAT-1K1 p9))"
      using relat_1_th_27 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 (SgmFINSEQ-1K15 (domRELAT-1K1 p9)))"
      using finseq_1_def_3 sorry
    finally have "domRELAT-1K1 (p9 *FUNCT-1K3 SgmFINSEQ-1K15 (domRELAT-1K1 p9)) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 (SgmFINSEQ-1K15 (domRELAT-1K1 p9)))"
       sorry
    thus "SeqFINSEQ-1K16 p9 be FinSequence-likeFINSEQ-1V1"
       sorry
  qed
qed "sorry"

mtheorem finseq_1_th_51:
" for X be setHIDDENM2 holds ( ex k be NatNAT-1M1 st X c=TARSKIR1 SegFINSEQ-1K2 k) implies (SgmFINSEQ-1K15 X =FUNCT-1R1 {}XBOOLE-0K1 iff X =XBOOLE-0R4 {}XBOOLE-0K1)"
proof-
  have " for X be setHIDDENM2 holds ( ex k be NatNAT-1M1 st X c=TARSKIR1 SegFINSEQ-1K2 k) implies (SgmFINSEQ-1K15 X =FUNCT-1R1 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) & (X =XBOOLE-0R4 {}XBOOLE-0K1 implies SgmFINSEQ-1K15 X =FUNCT-1R1 {}XBOOLE-0K1)"
  proof(rule ballI,rule impI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    assume Given: " ex k be NatNAT-1M1 st X c=TARSKIR1 SegFINSEQ-1K2 k"
    then obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A1: "X c=TARSKIR1 SegFINSEQ-1K2 k"
       sorry
    show "SgmFINSEQ-1K15 X =FUNCT-1R1 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1"
    proof-
      have "SgmFINSEQ-1K15 X =FUNCT-1R1 {}XBOOLE-0K1 implies X =HIDDENR1 {}XBOOLE-0K1"
      proof(rule impI)
        assume "SgmFINSEQ-1K15 X =FUNCT-1R1 {}XBOOLE-0K1"
        then have "X =HIDDENR1 rngFUNCT-1K2 ({}XBOOLE-0K1)"
          using A1 finseq_1_def_13 sorry
        also have "... = {}XBOOLE-0K1"
           sorry
        finally show "X =HIDDENR1 {}XBOOLE-0K1"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume "X =XBOOLE-0R4 {}XBOOLE-0K1"
    then have "rngFUNCT-1K2 (SgmFINSEQ-1K15 X) =XBOOLE-0R4 {}XBOOLE-0K1"
      using A1 finseq_1_def_13 sorry
    thus "SgmFINSEQ-1K15 X =FUNCT-1R1 {}XBOOLE-0K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem finseq_1_th_52:
" for D be setHIDDENM2 holds D be finiteFINSET-1V1 iff ( ex p be FinSequenceFINSEQ-1M1 st D =XBOOLE-0R4 rngFUNCT-1K2 p)"
proof-
  have " for D be setHIDDENM2 holds (D be finiteFINSET-1V1 implies ( ex p be FinSequenceFINSEQ-1M1 st D =XBOOLE-0R4 rngFUNCT-1K2 p)) & (( ex p be FinSequenceFINSEQ-1M1 st D =XBOOLE-0R4 rngFUNCT-1K2 p) implies D be finiteFINSET-1V1)"
  proof(rule ballI,rule conjMI,rule impI)
    fix D assume [ty]: "D be setHIDDENM2"
    show "D be finiteFINSET-1V1 implies ( ex p be FinSequenceFINSEQ-1M1 st D =XBOOLE-0R4 rngFUNCT-1K2 p)"
    proof-
      have " not (D be finiteFINSET-1V1 & ( for p be FinSequenceFINSEQ-1M1 holds  not D =XBOOLE-0R4 rngFUNCT-1K2 p))"
      proof-
        have "( ex g be FunctionFUNCT-1M1 st rngFUNCT-1K2 g =XBOOLE-0R4 D & domRELAT-1K1 g inTARSKIR2 omegaORDINAL1K4) implies ( ex tVar22 be FinSequenceFINSEQ-1M1 st D =XBOOLE-0R4 rngFUNCT-1K2 tVar22)"
        proof(rule impI)
          assume Given: " ex g be FunctionFUNCT-1M1 st rngFUNCT-1K2 g =XBOOLE-0R4 D & domRELAT-1K1 g inTARSKIR2 omegaORDINAL1K4"
          then obtain g where
            [ty]:"g be FunctionFUNCT-1M1" and 
            A1: "rngFUNCT-1K2 g =XBOOLE-0R4 D"and A2: "domRELAT-1K1 g inTARSKIR2 omegaORDINAL1K4"
             sorry
          obtain n where 
            [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = domRELAT-1K1 g"
            using A2 sorry
          let ?R = "\<lambda>Lamb1. \<lambda>Lamb2.  ex k be NatNAT-1M1 st Lamb1 =HIDDENR1 k & Lamb1 =HIDDENR1 k +NAT-1K1 \<one>\<^sub>M"
          have A3: " for x be objectHIDDENM1 holds x inHIDDENR3 SegFINSEQ-1K2 n implies ( ex y be objectHIDDENM1 st ?R(x,y))"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 SegFINSEQ-1K2 n implies  not ( for y be objectHIDDENM1 holds  not ( ex k be NatNAT-1M1 st x =HIDDENR1 k & x =HIDDENR1 k +NAT-1K1 \<one>\<^sub>M))"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume A4: "x inHIDDENR3 SegFINSEQ-1K2 n"
              then have 
                [ty]:"x be ElementSUBSET-1M1-of NATNUMBERSK1"
                 sorry
              have "x >=XXREAL-0R2 \<one>\<^sub>M"
                using A4 finseq_1_th_1 sorry
              then have " ex k be NatNAT-1M1 st x =XBOOLE-0R4 \<one>\<^sub>M +XCMPLX-0K2 k"
                using nat_1_th_10 sorry
              thus " not ( for y be objectHIDDENM1 holds  not ( ex k be NatNAT-1M1 st x =HIDDENR1 k & x =HIDDENR1 k +NAT-1K1 \<one>\<^sub>M))"
                 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          obtain f where
            [ty]:"f be FunctionFUNCT-1M1" and 
            A5: "domRELAT-1K1 f =XBOOLE-0R4 SegFINSEQ-1K2 n"and A6: " for x be objectHIDDENM1 holds x inHIDDENR3 SegFINSEQ-1K2 n implies ?R(x,f .FUNCT-1K1 x)"
            using classes1_sch_1 A3 sorry
          have A7: "rngFUNCT-1K2 f =XBOOLE-0R4 domRELAT-1K1 g"
          proof-
            have A8: "n =XBOOLE-0R4 {k where k be NatNAT-1M1 : k <XXREAL-0R3 n }"
              using axioms_th_4 sorry
            have "rngFUNCT-1K2 f c=TARSKIR1 domRELAT-1K1 g & domRELAT-1K1 g c=TARSKIR1 rngFUNCT-1K2 f"
            proof(rule conjMI)
              show "rngFUNCT-1K2 f c=TARSKIR1 domRELAT-1K1 g"
              proof-
                have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 domRELAT-1K1 g"
                proof(rule ballI,rule impI)
                  fix x assume [ty]: "x be objectHIDDENM1"
                  assume "x inHIDDENR3 rngFUNCT-1K2 f"
                  then obtain y where
                    [ty]:"y be objectHIDDENM1" and 
                    A9: "y inHIDDENR3 domRELAT-1K1 f"and A10: "x =HIDDENR1 f .FUNCT-1K1 y"
                    using funct_1_def_3 sorry
                  obtain k where
                    [ty]:"k be NatNAT-1M1" and 
                    A11: "x =HIDDENR1 k"and A12: "y =HIDDENR1 k +NAT-1K1 \<one>\<^sub>M"
                    using A5 A6 A9 A10 sorry
                  have "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
                    using A5 A9 A12 finseq_1_th_1 sorry
                  then have "k <XXREAL-0R3 n"
                    using nat_1_th_13 sorry
                  thus "x inHIDDENR3 domRELAT-1K1 g"
                    using A8 A11 sorry
                qed "sorry"
                thus "rngFUNCT-1K2 f c=TARSKIR1 domRELAT-1K1 g"
                  using tarski_def_3 sorry
              qed
              have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies x inHIDDENR3 rngFUNCT-1K2 f"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 domRELAT-1K1 g"
                then obtain k where
                  [ty]:"k be NatNAT-1M1" and 
                  A13: "x =HIDDENR1 k"and A14: "k <XXREAL-0R3 n"
                  using A8 sorry
                have "\<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M & k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
                  using A14 nat_1_th_11 nat_1_th_13 sorry
                then have A15: "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 n"
                   sorry
                then have " ex k1 be NatNAT-1M1 st f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 k1 & k +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 k1 +NAT-1K1 \<one>\<^sub>M"
                  using A6 sorry
                thus "x inHIDDENR3 rngFUNCT-1K2 f"
                  using A5 A13 A15 funct_1_def_3 sorry
              qed "sorry"
              thus "domRELAT-1K1 g c=TARSKIR1 rngFUNCT-1K2 f"
                using tarski_def_3 sorry
            qed
            thus "rngFUNCT-1K2 f =XBOOLE-0R4 domRELAT-1K1 g"
              using xboole_0_def_10 sorry
          qed
          then have "domRELAT-1K1 (g *FUNCT-1K3 f) =XBOOLE-0R4 SegFINSEQ-1K2 n"
            using A5 relat_1_th_27 sorry
          then obtain p where 
            [ty]:"p be FinSequenceFINSEQ-1M1" and pDef:"p = g *FUNCT-1K3 f"
            using finseq_1_def_2 sorry
          show " ex tVar22 be FinSequenceFINSEQ-1M1 st D =XBOOLE-0R4 rngFUNCT-1K2 tVar22"
          proof(rule bexI[of _ "p"])
            show "D =XBOOLE-0R4 rngFUNCT-1K2 p"
              using A1 A7 relat_1_th_28 sorry
          qed "sorry"
        qed
        thus " not (D be finiteFINSET-1V1 & ( for p be FinSequenceFINSEQ-1M1 holds  not D =XBOOLE-0R4 rngFUNCT-1K2 p))"
          using finset_1_def_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex p be FinSequenceFINSEQ-1M1 st D =XBOOLE-0R4 rngFUNCT-1K2 p"
    then obtain p where
      [ty]:"p be FinSequenceFINSEQ-1M1" and 
      A16: "D =XBOOLE-0R4 rngFUNCT-1K2 p"
       sorry
    obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A17: "domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 n"
      using finseq_1_def_2 sorry
    have A18: "n =XBOOLE-0R4 {k where k be NatNAT-1M1 : k <XXREAL-0R3 n }"
      using axioms_th_4 sorry
    have A19: " for x be objectHIDDENM1 holds x inHIDDENR3 n implies ( ex y be objectHIDDENM1 st  ex k be NatNAT-1M1 st x =HIDDENR1 k & y =HIDDENR1 k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 n implies ( ex tVar23 be objectHIDDENM1 st  ex kc be NatNAT-1M1 st x =HIDDENR1 kc & tVar23 =HIDDENR1 kc +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 n"
        then have " ex k be NatNAT-1M1 st x =HIDDENR1 k & k <XXREAL-0R3 n"
          using A18 sorry
        then obtain k where 
          [ty]:"k be NatNAT-1M1" and kDef:"k = x"
           sorry
        show " ex tVar23 be objectHIDDENM1 st  ex kc be NatNAT-1M1 st x =HIDDENR1 kc & tVar23 =HIDDENR1 kc +NAT-1K1 \<one>\<^sub>M"
        proof(rule bexI[of _ "k +NAT-1K1 \<one>\<^sub>M"])
          show " ex kc be NatNAT-1M1 st x =HIDDENR1 kc & k +NAT-1K1 \<one>\<^sub>M =HIDDENR1 kc +NAT-1K1 \<one>\<^sub>M"
             sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A20: "domRELAT-1K1 f =XBOOLE-0R4 n"and A21: " for x be objectHIDDENM1 holds x inHIDDENR3 n implies ( ex k be NatNAT-1M1 st x =HIDDENR1 k & f .FUNCT-1K1 x =HIDDENR1 k +NAT-1K1 \<one>\<^sub>M)"
      using classes1_sch_1 A19 sorry
    have A22: "rngFUNCT-1K2 f =XBOOLE-0R4 domFINSEQ-1K5 p"
    proof-
      have "rngFUNCT-1K2 f c=TARSKIR1 domFINSEQ-1K5 p & domFINSEQ-1K5 p c=TARSKIR1 rngFUNCT-1K2 f"
      proof(rule conjMI)
        show "rngFUNCT-1K2 f c=TARSKIR1 domFINSEQ-1K5 p"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 domFINSEQ-1K5 p"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 f"
            then obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A23: "y inHIDDENR3 domRELAT-1K1 f"and A24: "x =HIDDENR1 f .FUNCT-1K1 y"
              using funct_1_def_3 sorry
            obtain k where
              [ty]:"k be NatNAT-1M1" and 
              A25: "y =HIDDENR1 k"and A26: "x =HIDDENR1 k +NAT-1K1 \<one>\<^sub>M"
              using A20 A21 A23 A24 sorry
            have " ex m be NatNAT-1M1 st k =XBOOLE-0R4 m & m <XXREAL-0R3 n"
              using A18 A20 A23 A25 sorry
            then have "\<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M & k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
              using nat_1_th_11 nat_1_th_13 sorry
            thus "x inHIDDENR3 domFINSEQ-1K5 p"
              using A17 A26 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 f c=TARSKIR1 domFINSEQ-1K5 p"
            using tarski_def_3 sorry
        qed
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domFINSEQ-1K5 p implies x inHIDDENR3 rngFUNCT-1K2 f"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A27: "x inHIDDENR3 domFINSEQ-1K5 p"
          then have 
            [ty]:"x be ElementSUBSET-1M1-of NATNUMBERSK1"
             sorry
          have "\<one>\<^sub>M <=XXREAL-0R1 x"
            using A17 A27 finseq_1_th_1 sorry
          then obtain m where
            [ty]:"m be NatNAT-1M1" and 
            A28: "x =XBOOLE-0R4 \<one>\<^sub>M +XCMPLX-0K2 m"
            using nat_1_th_10 sorry
          have "x <=XXREAL-0R1 n"
            using A17 A27 finseq_1_th_1 sorry
          then have "m <XXREAL-0R3 n"
            using A28 nat_1_th_13 sorry
          then have A29: "m inTARSKIR2 n"
            using A18 sorry
          then have " ex k be NatNAT-1M1 st m =XBOOLE-0R4 k & f .FUNCT-1K1 m =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
            using A21 sorry
          thus "x inHIDDENR3 rngFUNCT-1K2 f"
            using A20 A28 A29 funct_1_def_3 sorry
        qed "sorry"
        thus "domFINSEQ-1K5 p c=TARSKIR1 rngFUNCT-1K2 f"
          using tarski_def_3 sorry
      qed
      thus "rngFUNCT-1K2 f =XBOOLE-0R4 domFINSEQ-1K5 p"
        using xboole_0_def_10 sorry
    qed
    have "rngFUNCT-1K2 (p *FUNCT-1K3 f) =XBOOLE-0R4 D & domRELAT-1K1 (p *FUNCT-1K3 f) inTARSKIR2 omegaORDINAL1K4"
    proof(rule conjMI)
      show "rngFUNCT-1K2 (p *FUNCT-1K3 f) =XBOOLE-0R4 D"
        using A16 relat_1_th_28 A22 sorry
      have "domRELAT-1K1 (p *FUNCT-1K3 f) =XBOOLE-0R4 domRELAT-1K1 f"
        using A22 relat_1_th_27 sorry
      thus "domRELAT-1K1 (p *FUNCT-1K3 f) inTARSKIR2 omegaORDINAL1K4"
        using A20 ordinal1_def_12 sorry
    qed
    thus "D be finiteFINSET-1V1"
      using bexI[of _ "p *FUNCT-1K3 f"] finset_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem finseq_1_th_53:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (SegFINSEQ-1K2 n,SegFINSEQ-1K2 m)are-equipotentWELLORD2R2 implies n =XBOOLE-0R4 m"
proof-
  have " for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (SegFINSEQ-1K2 n,SegFINSEQ-1K2 m)are-equipotentWELLORD2R2 & n <>HIDDENR2 m implies  False "
  proof(rule ballI,rule ballI,rule impI)
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?P = "\<lambda>Lamb1.  ex n be NatNAT-1M1 st (SegFINSEQ-1K2 n,SegFINSEQ-1K2 Lamb1)are-equipotentWELLORD2R2 & n <>HIDDENR2 Lamb1"
    assume "(SegFINSEQ-1K2 n,SegFINSEQ-1K2 m)are-equipotentWELLORD2R2 & n <>HIDDENR2 m"
    then have A1: " ex m be NatNAT-1M1 st ?P(m)"
       sorry
    obtain m where
      [ty]:"m be NatNAT-1M1" and 
      A2: "?P(m)"and A3: " for k be NatNAT-1M1 holds ?P(k) implies m <=XXREAL-0R1 k"
      using nat_1_sch_5 A1 sorry
    obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A4: "(SegFINSEQ-1K2 n,SegFINSEQ-1K2 m)are-equipotentWELLORD2R2"and A5: "n <>HIDDENR2 m"
      using A2 sorry
    have A6: " ex f be FunctionFUNCT-1M1 st (f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =XBOOLE-0R4 SegFINSEQ-1K2 n) & rngFUNCT-1K2 f =XBOOLE-0R4 SegFINSEQ-1K2 m"
      using A4 sorry
    have A7: "m =XBOOLE-0R4 0NUMBERSK6 implies  False "
    proof(rule impI)
      assume "m =XBOOLE-0R4 0NUMBERSK6"
      then have "SegFINSEQ-1K2 m =XBOOLE-0R4 {}XBOOLE-0K1"
         sorry
      then have "SegFINSEQ-1K2 m =XBOOLE-0R4 SegFINSEQ-1K2 n"
        using A6 relat_1_th_42 sorry
      thus " False "
        using A5 finseq_1_th_6 sorry
    qed
    then obtain m1 where
      [ty]:"m1 be NatNAT-1M1" and 
      A8: "m =XBOOLE-0R4 m1 +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_6 sorry
    have A9: "n =XBOOLE-0R4 0NUMBERSK6 implies  False "
    proof(rule impI)
      assume "n =XBOOLE-0R4 0NUMBERSK6"
      then have "SegFINSEQ-1K2 n =XBOOLE-0R4 {}XBOOLE-0K1"
         sorry
      then have "SegFINSEQ-1K2 m =XBOOLE-0R4 SegFINSEQ-1K2 n"
        using A6 relat_1_th_42 sorry
      thus " False "
        using A5 finseq_1_th_6 sorry
    qed
    then obtain n1 where
      [ty]:"n1 be NatNAT-1M1" and 
      A10: "n =XBOOLE-0R4 n1 +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_6 sorry
    have A11: "n inTARSKIR2 SegFINSEQ-1K2 n"
      using A9 finseq_1_th_3 sorry
    have A12: "m inTARSKIR2 SegFINSEQ-1K2 m"
      using A7 finseq_1_th_3 sorry
    have A13: " not n1 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n1"
      using nat_1_th_13 sorry
    have A14: " not m1 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m1"
      using nat_1_th_13 sorry
    have A15: " not n inTARSKIR2 SegFINSEQ-1K2 n1"
      using A10 A13 finseq_1_th_1 sorry
    have A16: " not m inTARSKIR2 SegFINSEQ-1K2 m1"
      using A8 A14 finseq_1_th_1 sorry
    have A17: "SegFINSEQ-1K2 n1 /\\SUBSET-1K8\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 n} c=TARSKIR1 {}XBOOLE-0K1"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 SegFINSEQ-1K2 n1 /\\SUBSET-1K8\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 n} implies x inHIDDENR3 {}XBOOLE-0K1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 SegFINSEQ-1K2 n1 /\\SUBSET-1K8\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 n}"
        then have "x inHIDDENR3 SegFINSEQ-1K2 n1 & x inHIDDENR3 {TARSKIK1 n}"
          using xboole_0_def_4 sorry
        thus "x inHIDDENR3 {}XBOOLE-0K1"
          using A15 tarski_def_1 sorry
      qed "sorry"
      thus "SegFINSEQ-1K2 n1 /\\SUBSET-1K8\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 n} c=TARSKIR1 {}XBOOLE-0K1"
        using tarski_def_3 sorry
    qed
    have A18: "SegFINSEQ-1K2 m1 /\\SUBSET-1K8\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 m} c=TARSKIR1 {}XBOOLE-0K1"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 SegFINSEQ-1K2 m1 /\\SUBSET-1K8\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 m} implies x inHIDDENR3 {}XBOOLE-0K1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 SegFINSEQ-1K2 m1 /\\SUBSET-1K8\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 m}"
        then have "x inHIDDENR3 SegFINSEQ-1K2 m1 & x inHIDDENR3 {TARSKIK1 m}"
          using xboole_0_def_4 sorry
        thus "x inHIDDENR3 {}XBOOLE-0K1"
          using A16 tarski_def_1 sorry
      qed "sorry"
      thus "SegFINSEQ-1K2 m1 /\\SUBSET-1K8\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 m} c=TARSKIR1 {}XBOOLE-0K1"
        using tarski_def_3 sorry
    qed
    have A19: "SegFINSEQ-1K2 n =XBOOLE-0R4 SegFINSEQ-1K2 n1 \\/XBOOLE-0K2 {TARSKIK1 n}"
      using A10 finseq_1_th_9 sorry
    have A20: "SegFINSEQ-1K2 m =XBOOLE-0R4 SegFINSEQ-1K2 m1 \\/XBOOLE-0K2 {TARSKIK1 m}"
      using A8 finseq_1_th_9 sorry
    have A21: "SegFINSEQ-1K2 n1 /\\SUBSET-1K8\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 n} =XBOOLE-0R4 {}XBOOLE-0K1"
      using A17 sorry
    have A22: "SegFINSEQ-1K2 m1 /\\SUBSET-1K8\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 m} =XBOOLE-0R4 {}XBOOLE-0K1"
      using A18 sorry
    have A23: "SegFINSEQ-1K2 n1 \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 n} =XBOOLE-0R4 (SegFINSEQ-1K2 n1 \\/XBOOLE-0K2 {TARSKIK1 n})\\SUBSET-1K6 {TARSKIK1 n} & SegFINSEQ-1K2 n1 missesXBOOLE-0R1 {TARSKIK1 n}"
      using A21 xboole_1_th_40 sorry
    have A24: "SegFINSEQ-1K2 m1 \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 m} =XBOOLE-0R4 (SegFINSEQ-1K2 m1 \\/XBOOLE-0K2 {TARSKIK1 m})\\SUBSET-1K6 {TARSKIK1 m} & SegFINSEQ-1K2 m1 missesXBOOLE-0R1 {TARSKIK1 m}"
      using A22 xboole_1_th_40 sorry
    have A25: "SegFINSEQ-1K2 n \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 n} =XBOOLE-0R4 SegFINSEQ-1K2 n1"
      using A19 A23 xboole_1_th_83 sorry
    have "SegFINSEQ-1K2 m \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 m} =XBOOLE-0R4 SegFINSEQ-1K2 m1"
      using A20 A24 xboole_1_th_83 sorry
    thus " False "
      using A3 A4 A5 A8 A10 A11 A12 A14 A25 card_1_th_34 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_54:
" for n be NatNAT-1M1 holds (SegFINSEQ-1K2 n,n)are-equipotentWELLORD2R2"
  using finseq_1_lm_1 sorry

mtheorem finseq_1_th_55:
" for n be NatNAT-1M1 holds cardCARD-1K4 (SegFINSEQ-1K2 n) =XBOOLE-0R4 cardCARD-1K4 n"
  using finseq_1_lm_1 card_1_th_5 sorry

mtheorem finseq_1_th_56:
" for X be setHIDDENM2 holds X be finiteFINSET-1V1 implies ( ex n be NatNAT-1M1 st (X,SegFINSEQ-1K2 n)are-equipotentWELLORD2R2)"
proof-
  have " for X be setHIDDENM2 holds X be finiteFINSET-1V1 implies ( ex tVar25 be NatNAT-1M1 st (X,SegFINSEQ-1K2 tVar25)are-equipotentWELLORD2R2)"
  proof(rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    assume "X be finiteFINSET-1V1"
    then obtain n where 
      [ty]:"n be NatNAT-1M1" and nDef:"n = cardCARD-1K1 X"
       sorry
    have A1: "(X,n)are-equipotentWELLORD2R2"
      using card_1_def_2 sorry
    show " ex tVar25 be NatNAT-1M1 st (X,SegFINSEQ-1K2 tVar25)are-equipotentWELLORD2R2"
    proof(rule bexI[of _ "n"])
      have "(n,SegFINSEQ-1K2 n)are-equipotentWELLORD2R2"
        using finseq_1_lm_1 sorry
      thus "(X,SegFINSEQ-1K2 n)are-equipotentWELLORD2R2"
        using A1 wellord2_th_15 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_57:
" for n be NatNAT-1M1 holds cardCARD-1K4 (SegFINSEQ-1K2 n) =XBOOLE-0R4 n"
  using finseq_1_lm_1 card_1_def_2 sorry

(*begin*)
mtheorem finseq_1_cl_26:
  mlet "x be objectHIDDENM1"
"cluster <*FINSEQ-1K10 x*> as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "<*FINSEQ-1K10 x*> be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem finseq_1_cl_27:
"cluster  non emptyXBOOLE-0V1 for FinSequenceFINSEQ-1M1"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M1 st it be  non emptyXBOOLE-0V1"
  proof-
    have " ex tVar26 be FinSequenceFINSEQ-1M1 st  not tVar26 be emptyXBOOLE-0V1"
    proof-
      show " ex tVar26 be FinSequenceFINSEQ-1M1 st  not tVar26 be emptyXBOOLE-0V1"
      proof(rule bexI[of _ "<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>"])
        show " not <*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *> be emptyXBOOLE-0V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finseq_1_cl_28:
  mlet "f1 be FinSequenceFINSEQ-1M1", "f2 be  non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M1"
"cluster f1 ^FINSEQ-1K8 f2 as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "f1 ^FINSEQ-1K8 f2 be  non emptyXBOOLE-0V1"
    using finseq_1_th_35 sorry
qed "sorry"

mtheorem finseq_1_cl_29:
  mlet "f1 be FinSequenceFINSEQ-1M1", "f2 be  non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M1"
"cluster f2 ^FINSEQ-1K8 f1 as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "f2 ^FINSEQ-1K8 f1 be  non emptyXBOOLE-0V1"
    using finseq_1_th_35 sorry
qed "sorry"

mtheorem finseq_1_cl_30:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1"
"cluster <*FINSEQ-1K11 x,y *> as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "<*FINSEQ-1K11 x,y *> be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem finseq_1_cl_31:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1", "z be objectHIDDENM1"
"cluster <*FINSEQ-1K12 x,y,z *> as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "<*FINSEQ-1K12 x,y,z *> be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

theorem finseq_1_sch_5:
  fixes Df0 Af0 Pp2 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Af0 be NatNAT-1M1" and
   A1: " for k be NatNAT-1M1 holds k inTARSKIR2 SegFINSEQ-1K2 Af0 implies ( ex x be ElementSUBSET-1M1-of Df0 st Pp2(k,x))"
  shows " ex p be FinSequenceFINSEQ-1M3-of Df0 st domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 Af0 & ( for k be NatNAT-1M1 holds k inTARSKIR2 SegFINSEQ-1K2 Af0 implies Pp2(k,p .FUNCT-1K1 k))"
  proof-
    have " ex tVar28 be FinSequenceFINSEQ-1M3-of Df0 st domFINSEQ-1K5 tVar28 =XBOOLE-0R4 SegFINSEQ-1K2 Af0 & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 SegFINSEQ-1K2 Af0 &  not Pp2(k,tVar28 .FUNCT-1K1 k)))"
    proof-
      have A2: " for y be objectHIDDENM1 holds y inHIDDENR3 SegFINSEQ-1K2 Af0 implies ( ex x be objectHIDDENM1 st x inHIDDENR3 Df0 & Pp2(y,x))"
      proof-
        have " for y be objectHIDDENM1 holds y inHIDDENR3 SegFINSEQ-1K2 Af0 implies ( ex tVar27 be objectHIDDENM1 st tVar27 inHIDDENR3 Df0 & Pp2(y,tVar27))"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume A3: "y inHIDDENR3 SegFINSEQ-1K2 Af0"
          then obtain k where 
            [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = y"
             sorry
          obtain x where
            [ty]:"x be ElementSUBSET-1M1-of Df0" and 
            A4: "Pp2(k,x)"
            using A1 A3 sorry
          show " ex tVar27 be objectHIDDENM1 st tVar27 inHIDDENR3 Df0 & Pp2(y,tVar27)"
          proof(rule bexI[of _ "x"])
            show "x inHIDDENR3 Df0 & Pp2(y,x)"
              using A4 sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A5: "domRELAT-1K1 f =XBOOLE-0R4 SegFINSEQ-1K2 Af0"and A6: "rngFUNCT-1K2 f c=TARSKIR1 Df0"and A7: " for y be objectHIDDENM1 holds y inHIDDENR3 SegFINSEQ-1K2 Af0 implies Pp2(y,f .FUNCT-1K1 y)"
        using funct_1_sch_6 A2 sorry
      have 
        [ty]:"f be FinSequenceFINSEQ-1M1"
        using A5 finseq_1_def_2 sorry
      obtain p where 
        [ty]:"p be FinSequenceFINSEQ-1M3-of Df0" and pDef:"p = f"
        using A6 finseq_1_def_4 sorry
      show " ex tVar28 be FinSequenceFINSEQ-1M3-of Df0 st domFINSEQ-1K5 tVar28 =XBOOLE-0R4 SegFINSEQ-1K2 Af0 & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 SegFINSEQ-1K2 Af0 &  not Pp2(k,tVar28 .FUNCT-1K1 k)))"
      proof(rule bexI[of _ "p"])
        show "domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 Af0 & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 SegFINSEQ-1K2 Af0 &  not Pp2(k,p .FUNCT-1K1 k)))"
          using A5 A7 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

reserve D for "setHIDDENM2"
reserve p for "FinSequenceFINSEQ-1M3-of D"
reserve m for "NatNAT-1M1"
mdef finseq_1_def_15 (" _  |FINSEQ-1K17  _ " [200,200]200 ) where
  mlet "m be NatNAT-1M1", "p be FinSequenceFINSEQ-1M1"
"func p  |FINSEQ-1K17 m \<rightarrow> FinSequenceFINSEQ-1M1 equals
  p  |RELAT-1K8 SegFINSEQ-1K2 m"
proof-
  (*coherence*)
    show "p  |RELAT-1K8 SegFINSEQ-1K2 m be FinSequenceFINSEQ-1M1"
      using finseq_1_th_15 sorry
qed "sorry"

syntax FINSEQ_1K18 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _  |FINSEQ-1K18\<^bsub>'( _ ')\<^esub>  _ " [200,0,200]200)
translations "p  |FINSEQ-1K18\<^bsub>(D)\<^esub> m" \<rightharpoonup> "p  |FINSEQ-1K17 m"

mtheorem finseq_1_add_8:
  mlet "D be setHIDDENM2", "m be NatNAT-1M1", "p be FinSequenceFINSEQ-1M3-of D"
"cluster p  |FINSEQ-1K17 m as-term-is FinSequenceFINSEQ-1M3-of D"
proof
(*coherence*)
  show "p  |FINSEQ-1K17 m be FinSequenceFINSEQ-1M3-of D"
    using finseq_1_th_18 sorry
qed "sorry"

mtheorem finseq_1_cl_32:
  mlet "f be FinSequenceFINSEQ-1M1"
"cluster f  |FINSEQ-1K17 (0NUMBERSK6) as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "f  |FINSEQ-1K17 (0NUMBERSK6) be emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem finseq_1_th_58:
" for i be NatNAT-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 q <=XXREAL-0R1 i implies q  |FINSEQ-1K17 i =FUNCT-1R1 q"
proof-
  have " for i be NatNAT-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 q <=XXREAL-0R1 i implies q  |FINSEQ-1K17 i =FUNCT-1R1 q"
  proof(rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    assume "lenFINSEQ-1K4 q <=XXREAL-0R1 i"
    then have "SegFINSEQ-1K2 (lenFINSEQ-1K4 q) c=TARSKIR1 SegFINSEQ-1K2 i"
      using finseq_1_th_5 sorry
    then have "domFINSEQ-1K5 q c=TARSKIR1 SegFINSEQ-1K2 i"
      using finseq_1_def_3 sorry
    thus "q  |FINSEQ-1K17 i =FUNCT-1R1 q"
      using relat_1_th_68 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_59:
" for i be NatNAT-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds i <=XXREAL-0R1 lenFINSEQ-1K4 q implies lenFINSEQ-1K4 (q  |FINSEQ-1K17 i) =XBOOLE-0R4 i"
proof-
  have " for i be NatNAT-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds i <=XXREAL-0R1 lenFINSEQ-1K4 q implies lenFINSEQ-1K4 (q  |FINSEQ-1K17 i) =XBOOLE-0R4 i"
  proof(rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    assume "i <=XXREAL-0R1 lenFINSEQ-1K4 q"
    then have "SegFINSEQ-1K2 i c=TARSKIR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
      using finseq_1_th_5 sorry
    then have "SegFINSEQ-1K2 i c=TARSKIR1 domFINSEQ-1K5 q"
      using finseq_1_def_3 sorry
    then have "i inTARSKIR2 NATNUMBERSK1 & SegFINSEQ-1K2 i =XBOOLE-0R4 domFINSEQ-1K5 (q  |FINSEQ-1K17 i)"
      using ordinal1_def_12 relat_1_th_62 sorry
    thus "lenFINSEQ-1K4 (q  |FINSEQ-1K17 i) =XBOOLE-0R4 i"
      using finseq_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_60:
" for n be NatNAT-1M1 holds  for i be NatNAT-1M1 holds  for m be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies i +XCMPLX-0K2 m inTARSKIR2 SegFINSEQ-1K2 (n +XCMPLX-0K2 m)"
proof-
  have " for n be NatNAT-1M1 holds  for i be NatNAT-1M1 holds  for m be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies i +XCMPLX-0K2 m inTARSKIR2 SegFINSEQ-1K2 (n +XCMPLX-0K2 m)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix i assume [ty]: "i be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    assume A1: "i inTARSKIR2 SegFINSEQ-1K2 n"
    then have A2: "\<one>\<^sub>M <=XXREAL-0R1 i"
      using finseq_1_th_1 sorry
    have A3: "i <=XXREAL-0R1 n"
      using A1 finseq_1_th_1 sorry
    have "i <=XXREAL-0R1 i +XCMPLX-0K2 m"
      using nat_1_th_11 sorry
    then have "\<one>\<^sub>M <=XXREAL-0R1 i +XCMPLX-0K2 m"
      using A2 xxreal_0_th_2 sorry
    thus "i +XCMPLX-0K2 m inTARSKIR2 SegFINSEQ-1K2 (n +XCMPLX-0K2 m)"
      using A3 finseq_1_th_1 xreal_1_th_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_61:
" for n be NatNAT-1M1 holds  for i be NatNAT-1M1 holds  for m be NatNAT-1M1 holds i >XXREAL-0R4 0NUMBERSK6 & i +XCMPLX-0K2 m inTARSKIR2 SegFINSEQ-1K2 (n +XCMPLX-0K2 m) implies i inTARSKIR2 SegFINSEQ-1K2 n & i inTARSKIR2 SegFINSEQ-1K2 (n +XCMPLX-0K2 m)"
proof-
  have " for n be NatNAT-1M1 holds  for i be NatNAT-1M1 holds  for m be NatNAT-1M1 holds i >XXREAL-0R4 0NUMBERSK6 & i +XCMPLX-0K2 m inTARSKIR2 SegFINSEQ-1K2 (n +XCMPLX-0K2 m) implies i inTARSKIR2 SegFINSEQ-1K2 n & i inTARSKIR2 SegFINSEQ-1K2 (n +XCMPLX-0K2 m)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix i assume [ty]: "i be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    assume A1: "i >XXREAL-0R4 0NUMBERSK6"
      and A2: "i +XCMPLX-0K2 m inTARSKIR2 SegFINSEQ-1K2 (n +XCMPLX-0K2 m)"
    have "\<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
       sorry
    then have A3: "\<one>\<^sub>M <=XXREAL-0R1 i"
      using A1 nat_1_th_13 sorry
    have A4: "i +XCMPLX-0K2 m <=XXREAL-0R1 n +XCMPLX-0K2 m"
      using A2 finseq_1_th_1 sorry
    have "i <=XXREAL-0R1 n"
      using A2 finseq_1_th_1 xreal_1_th_6 sorry
    thus "i inTARSKIR2 SegFINSEQ-1K2 n"
      using A3 sorry
    have "i <=XXREAL-0R1 i +XCMPLX-0K2 m"
      using nat_1_th_11 sorry
    then have "i <=XXREAL-0R1 n +XCMPLX-0K2 m"
      using A4 xxreal_0_th_2 sorry
    thus "i inTARSKIR2 SegFINSEQ-1K2 (n +XCMPLX-0K2 m)"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef finseq_1_def_16 (" _ [*]FINSEQ-1K19" [164]164 ) where
  mlet "R be RelationRELAT-1M1"
"func R [*]FINSEQ-1K19 \<rightarrow> RelationRELAT-1M1 means
  \<lambda>it.  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 it iff (x inHIDDENR3 fieldRELAT-1K3 R & y inHIDDENR3 fieldRELAT-1K3 R) & ( ex p be FinSequenceFINSEQ-1M1 st ((lenFINSEQ-1K4 p >=XXREAL-0R2 \<one>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x) & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 y) & ( for i be NatNAT-1M1 holds i >=XXREAL-0R2 \<one>\<^sub>M & i <XXREAL-0R3 lenFINSEQ-1K4 p implies [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R))"
proof-
  (*existence*)
    show " ex it be RelationRELAT-1M1 st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 it iff (x inHIDDENR3 fieldRELAT-1K3 R & y inHIDDENR3 fieldRELAT-1K3 R) & ( ex p be FinSequenceFINSEQ-1M1 st ((lenFINSEQ-1K4 p >=XXREAL-0R2 \<one>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x) & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 y) & ( for i be NatNAT-1M1 holds i >=XXREAL-0R2 \<one>\<^sub>M & i <XXREAL-0R3 lenFINSEQ-1K4 p implies [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R))"
    proof-
      have " ex S be RelationRELAT-1M1 st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 S iff (x inHIDDENR3 fieldRELAT-1K3 R & y inHIDDENR3 fieldRELAT-1K3 R) & ( ex p be FinSequenceFINSEQ-1M1 st ((lenFINSEQ-1K4 p >=XXREAL-0R2 \<one>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x) & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 y) & ( for i be NatNAT-1M1 holds i >=XXREAL-0R2 \<one>\<^sub>M & i <XXREAL-0R3 lenFINSEQ-1K4 p implies [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R))"
      proof-
        let ?X = "\<lambda>Lamb1. \<lambda>Lamb2.  ex p be FinSequenceFINSEQ-1M1 st ((lenFINSEQ-1K4 p >=XXREAL-0R2 \<one>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 Lamb1) & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 Lamb2) & ( for i be NatNAT-1M1 holds i >=XXREAL-0R2 \<one>\<^sub>M & i <XXREAL-0R3 lenFINSEQ-1K4 p implies [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R)"
        show " ex S be RelationRELAT-1M1 st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 S iff (x inHIDDENR3 fieldRELAT-1K3 R & y inHIDDENR3 fieldRELAT-1K3 R) & ( ex p be FinSequenceFINSEQ-1M1 st ((lenFINSEQ-1K4 p >=XXREAL-0R2 \<one>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x) & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 y) & ( for i be NatNAT-1M1 holds i >=XXREAL-0R2 \<one>\<^sub>M & i <XXREAL-0R3 lenFINSEQ-1K4 p implies [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R))"
          using relat_1_sch_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be RelationRELAT-1M1 holds  for it2 be RelationRELAT-1M1 holds ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 it1 iff (x inHIDDENR3 fieldRELAT-1K3 R & y inHIDDENR3 fieldRELAT-1K3 R) & ( ex p be FinSequenceFINSEQ-1M1 st ((lenFINSEQ-1K4 p >=XXREAL-0R2 \<one>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x) & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 y) & ( for i be NatNAT-1M1 holds i >=XXREAL-0R2 \<one>\<^sub>M & i <XXREAL-0R3 lenFINSEQ-1K4 p implies [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R))) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 it2 iff (x inHIDDENR3 fieldRELAT-1K3 R & y inHIDDENR3 fieldRELAT-1K3 R) & ( ex p be FinSequenceFINSEQ-1M1 st ((lenFINSEQ-1K4 p >=XXREAL-0R2 \<one>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x) & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 y) & ( for i be NatNAT-1M1 holds i >=XXREAL-0R2 \<one>\<^sub>M & i <XXREAL-0R3 lenFINSEQ-1K4 p implies [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R))) implies it1 =HIDDENR1 it2"
    proof-
      have " for R1 be RelationRELAT-1M1 holds  for R2 be RelationRELAT-1M1 holds ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R1 iff (x inHIDDENR3 fieldRELAT-1K3 R & y inHIDDENR3 fieldRELAT-1K3 R) & ( ex p be FinSequenceFINSEQ-1M1 st ((lenFINSEQ-1K4 p >=XXREAL-0R2 \<one>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x) & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 y) & ( for i be NatNAT-1M1 holds i >=XXREAL-0R2 \<one>\<^sub>M & i <XXREAL-0R3 lenFINSEQ-1K4 p implies [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R))) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R2 iff (x inHIDDENR3 fieldRELAT-1K3 R & y inHIDDENR3 fieldRELAT-1K3 R) & ( ex p be FinSequenceFINSEQ-1M1 st ((lenFINSEQ-1K4 p >=XXREAL-0R2 \<one>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x) & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 y) & ( for i be NatNAT-1M1 holds i >=XXREAL-0R2 \<one>\<^sub>M & i <XXREAL-0R3 lenFINSEQ-1K4 p implies [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R))) implies R1 =HIDDENR1 R2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix R1 assume [ty]: "R1 be RelationRELAT-1M1"
        fix R2 assume [ty]: "R2 be RelationRELAT-1M1"
        assume A1: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R1 iff (x inHIDDENR3 fieldRELAT-1K3 R & y inHIDDENR3 fieldRELAT-1K3 R) & ( ex p be FinSequenceFINSEQ-1M1 st ((lenFINSEQ-1K4 p >=XXREAL-0R2 \<one>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x) & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 y) & ( for i be NatNAT-1M1 holds i >=XXREAL-0R2 \<one>\<^sub>M & i <XXREAL-0R3 lenFINSEQ-1K4 p implies [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R))"
          and A2: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R2 iff (x inHIDDENR3 fieldRELAT-1K3 R & y inHIDDENR3 fieldRELAT-1K3 R) & ( ex p be FinSequenceFINSEQ-1M1 st ((lenFINSEQ-1K4 p >=XXREAL-0R2 \<one>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x) & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 y) & ( for i be NatNAT-1M1 holds i >=XXREAL-0R2 \<one>\<^sub>M & i <XXREAL-0R3 lenFINSEQ-1K4 p implies [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R))"
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 R1 implies [TARSKIK4 x,y ] inHIDDENR3 R2) & ([TARSKIK4 x,y ] inHIDDENR3 R2 implies [TARSKIK4 x,y ] inHIDDENR3 R1)"
        proof(rule ballI,rule ballI,rule conjMI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          show "[TARSKIK4 x,y ] inHIDDENR3 R1 implies [TARSKIK4 x,y ] inHIDDENR3 R2"
          proof(rule impI)
            assume A3: "[TARSKIK4 x,y ] inHIDDENR3 R1"
            then have A4: "x inHIDDENR3 fieldRELAT-1K3 R & y inHIDDENR3 fieldRELAT-1K3 R"
              using A1 sorry
            have " ex p be FinSequenceFINSEQ-1M1 st ((lenFINSEQ-1K4 p >=XXREAL-0R2 \<one>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x) & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 y) & ( for i be NatNAT-1M1 holds i >=XXREAL-0R2 \<one>\<^sub>M & i <XXREAL-0R3 lenFINSEQ-1K4 p implies [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R)"
              using A1 A3 sorry
            thus "[TARSKIK4 x,y ] inHIDDENR3 R2"
              using A2 A4 sorry
          qed
          assume A5: "[TARSKIK4 x,y ] inHIDDENR3 R2"
          then have A6: "x inHIDDENR3 fieldRELAT-1K3 R & y inHIDDENR3 fieldRELAT-1K3 R"
            using A2 sorry
          have " ex p be FinSequenceFINSEQ-1M1 st ((lenFINSEQ-1K4 p >=XXREAL-0R2 \<one>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x) & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 y) & ( for i be NatNAT-1M1 holds i >=XXREAL-0R2 \<one>\<^sub>M & i <XXREAL-0R3 lenFINSEQ-1K4 p implies [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R)"
            using A2 A5 sorry
          thus "[TARSKIK4 x,y ] inHIDDENR3 R1"
            using A1 A6 sorry
        qed "sorry"
        thus "R1 =HIDDENR1 R2"
          using relat_1_def_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem finseq_1_th_62:
" for D1 be setHIDDENM2 holds  for D2 be setHIDDENM2 holds D1 c=TARSKIR1 D2 implies D1 * FINSEQ-1K14 c=TARSKIR1 D2 * FINSEQ-1K14"
proof(rule ballI,rule ballI,rule impI)
  fix D1 assume [ty]: "D1 be setHIDDENM2"
  fix D2 assume [ty]: "D2 be setHIDDENM2"
  assume A1: "D1 c=TARSKIR1 D2"
  have " for x be objectHIDDENM1 holds x inHIDDENR3 D1 * FINSEQ-1K14 implies x inHIDDENR3 D2 * FINSEQ-1K14"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    assume "x inHIDDENR3 D1 * FINSEQ-1K14"
    then obtain p where 
      [ty]:"p be FinSequenceFINSEQ-1M3-of D1" and pDef:"p = x"
      using finseq_1_def_11 sorry
    have "rngFUNCT-1K2 p c=TARSKIR1 D1"
      using finseq_1_def_4 sorry
    then have "x be FinSequenceFINSEQ-1M3-of D2"
      using finseq_1_def_4 A1 xboole_1_th_1 sorry
    thus "x inHIDDENR3 D2 * FINSEQ-1K14"
      using finseq_1_def_11 sorry
  qed "sorry"
  thus "D1 * FINSEQ-1K14 c=TARSKIR1 D2 * FINSEQ-1K14"
    using tarski_def_3 sorry
qed "sorry"

mtheorem finseq_1_cl_33:
  mlet "D be setHIDDENM2"
"cluster D * FINSEQ-1K14 as-term-is functionalFUNCT-1V6"
proof
(*coherence*)
  show "D * FINSEQ-1K14 be functionalFUNCT-1V6"
    using finseq_1_def_11 sorry
qed "sorry"

mtheorem finseq_1_th_63:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds p c=RELAT-1R2 q implies lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 q"
proof(rule ballI,rule ballI,rule impI)
  fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
  fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
  assume "p c=RELAT-1R2 q"
  then have "SegmCARD-1K5 cardCARD-1K4 p c=ORDINAL1R1 SegmCARD-1K5 cardCARD-1K4 q"
    using card_1_th_11 sorry
  thus "lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 q"
    using nat_1_th_39 sorry
qed "sorry"

mtheorem finseq_1_th_64:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 p implies (p ^FINSEQ-1K8 q).FUNCT-1K1 i =XBOOLE-0R4 p .FUNCT-1K1 i"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
  fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
  fix i assume [ty]: "i be NatNAT-1M1"
  assume A1: "\<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 p"
  have "i inTARSKIR2 NATNUMBERSK1 & SegFINSEQ-1K2 (lenFINSEQ-1K4 p) =XBOOLE-0R4 domFINSEQ-1K5 p"
    using finseq_1_def_3 ordinal1_def_12 sorry
  then have "i inTARSKIR2 domFINSEQ-1K5 p"
    using A1 sorry
  thus "(p ^FINSEQ-1K8 q).FUNCT-1K1 i =XBOOLE-0R4 p .FUNCT-1K1 i"
    using finseq_1_def_7 sorry
qed "sorry"

mtheorem finseq_1_th_65:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q implies (p ^FINSEQ-1K8 q).FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 i) =XBOOLE-0R4 q .FUNCT-1K1 i"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q implies (p ^FINSEQ-1K8 q).FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 i) =HIDDENR1 q .FUNCT-1K1 i"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    fix i assume [ty]: "i be NatNAT-1M1"
    assume "\<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q"
    then have "lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p +XCMPLX-0K2 i & lenFINSEQ-1K4 p +XCMPLX-0K2 i <=XXREAL-0R1 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q"
      using xreal_1_th_6 sorry
    then have "(p ^FINSEQ-1K8 q).FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 i) =HIDDENR1 q .FUNCT-1K1 ((lenFINSEQ-1K4 p +XCMPLX-0K2 i)-XCMPLX-0K6 lenFINSEQ-1K4 p)"
      using finseq_1_th_23 sorry
    also have "... = q .FUNCT-1K1 i"
       sorry
    finally show "(p ^FINSEQ-1K8 q).FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 i) =HIDDENR1 q .FUNCT-1K1 i"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem finseq_1_sch_6:
  fixes nf0 Ff1 Pp1 
  assumes
[ty]: "nf0 be NatNAT-1M1" and
  [ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Ff1(x1) be setHIDDENM2"
  shows "{Ff1(i) where i be NatNAT-1M1 : i <=XXREAL-0R1 nf0 & Pp1(i) } be finiteFINSET-1V1"
  proof-
    let ?F = "{Ff1(i) where i be NatNAT-1M1 : i <=XXREAL-0R1 nf0 & Pp1(i) }"
    let ?G = "\<lambda>Lamb1. Ff1(Lamb1 -XCMPLX-0K6 \<one>\<^sub>M)"
    obtain f where
      [ty]:"f be FinSequenceFINSEQ-1M1" and 
      A1: "lenFINSEQ-1K4 f =XBOOLE-0R4 nf0 +NAT-1K1 \<one>\<^sub>M"and A2: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 f implies f .FUNCT-1K1 k =XBOOLE-0R4 ?G(k)"
      using finseq_1_sch_2 sorry
    have "?F c=TARSKIR1 rngFUNCT-1K2 f"
    proof-
      have "{Ff1(i) where i be NatNAT-1M1 : i <=XXREAL-0R1 nf0 & Pp1(i) } c=TARSKIR1 rngFUNCT-1K2 f"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 {Ff1(i) where i be NatNAT-1M1 : i <=XXREAL-0R1 nf0 & Pp1(i) } implies x inHIDDENR3 rngFUNCT-1K2 f"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 ?F"
          then obtain j where
            [ty]:"j be NatNAT-1M1" and 
            A3: "x =HIDDENR1 Ff1(j)"and A4: "j <=XXREAL-0R1 nf0"and "Pp1(j)"
             sorry
          have "\<one>\<^sub>M <=XXREAL-0R1 j +NAT-1K1 \<one>\<^sub>M & j +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 nf0 +NAT-1K1 \<one>\<^sub>M"
            using A4 nat_1_th_11 xreal_1_th_6 sorry
          then have "j +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (nf0 +NAT-1K1 \<one>\<^sub>M)"
             sorry
          then have A5: "j +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
            using A1 finseq_1_def_3 sorry
          then have "f .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Ff1((j +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M)"
            using A2 sorry
          also have "... = Ff1(j)"
             sorry
          finally have "f .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Ff1(j)"
             sorry
          thus "x inHIDDENR3 rngFUNCT-1K2 f"
            using A3 A5 funct_1_def_3 sorry
        qed "sorry"
        thus "{Ff1(i) where i be NatNAT-1M1 : i <=XXREAL-0R1 nf0 & Pp1(i) } c=TARSKIR1 rngFUNCT-1K2 f"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus "{Ff1(i) where i be NatNAT-1M1 : i <=XXREAL-0R1 nf0 & Pp1(i) } be finiteFINSET-1V1"
       sorry
  qed

mlemma finseq_1_lm_5:
" for n be NatNAT-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 SegFINSEQ-1K2 n implies ( ex VarFor3 be setHIDDENM2 st (\<one>\<^sub>M <=XXREAL-0R1 VarFor3 & VarFor3 <=XXREAL-0R1 n) & x =HIDDENR1 VarFor3)"
proof-
  have " for n be NatNAT-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 SegFINSEQ-1K2 n implies  not ( for VarFor1 be setHIDDENM2 holds \<one>\<^sub>M <=XXREAL-0R1 VarFor1 & VarFor1 <=XXREAL-0R1 n implies x =HIDDENR1 VarFor1)"
  proof(rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "x inHIDDENR3 SegFINSEQ-1K2 n"
    then obtain k where 
      [ty]:"k be NatNAT-1M1" and kDef:"k = x"
       sorry
    have "\<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 n"
      using A1 finseq_1_th_1 sorry
    thus " not ( for VarFor1 be setHIDDENM2 holds \<one>\<^sub>M <=XXREAL-0R1 VarFor1 & VarFor1 <=XXREAL-0R1 n implies x =HIDDENR1 VarFor1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_66:
" for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M1 holds p =FUNCT-1R1 (((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>) implies (((lenFINSEQ-1K4 p =XBOOLE-0R4 \<four>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x1) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x4"
proof-
  have " for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M1 holds p =FUNCT-1R1 (((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>) implies lenFINSEQ-1K4 p =HIDDENR1 \<four>\<^sub>M & (((p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x1 & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<four>\<^sub>M =HIDDENR1 x4)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI)
    fix x1 assume [ty]: "x1 be setHIDDENM2"
    fix x2 assume [ty]: "x2 be setHIDDENM2"
    fix x3 assume [ty]: "x3 be setHIDDENM2"
    fix x4 assume [ty]: "x4 be setHIDDENM2"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    assume A1: "p =FUNCT-1R1 (((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>)"
    let ?p13 = "((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>)"
    have A2: "?p13 =FUNCT-1R1 <*FINSEQ-1K12 x1,x2,x3 *>"
       sorry
    then have A3: "lenFINSEQ-1K4 ?p13 =XBOOLE-0R4 \<three>\<^sub>M"
      using finseq_1_th_45 sorry
    have A4: "?p13 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x1 & ?p13 .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x2"
      using A2 finseq_1_th_45 sorry
    have A5: "?p13 .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x3"
      using A2 finseq_1_th_45 sorry
    have "lenFINSEQ-1K4 p =HIDDENR1 lenFINSEQ-1K4 (((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>)) +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x4*>)"
      using A1 finseq_1_th_22 sorry
    also have "... = \<three>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
      using A3 finseq_1_th_40 sorry
    also have "... = \<four>\<^sub>M"
       sorry
    finally show "lenFINSEQ-1K4 p =HIDDENR1 \<four>\<^sub>M"
       sorry
    have A6: "domFINSEQ-1K5 ?p13 =XBOOLE-0R4 SegFINSEQ-1K2 \<three>\<^sub>M"
      using A3 finseq_1_def_3 sorry
    have " for VarFor1 be setHIDDENM2 holds \<one>\<^sub>M <=XXREAL-0R1 VarFor1 & VarFor1 <=XXREAL-0R1 \<three>\<^sub>M implies  not VarFor1 inTARSKIR2 SegFINSEQ-1K2 \<three>\<^sub>M"
       sorry
    thus "(p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x1 & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x3"
      using A1 A4 A5 finseq_1_def_7 A6 sorry
    have "p .FUNCT-1K1 \<four>\<^sub>M =HIDDENR1 p .FUNCT-1K1 (lenFINSEQ-1K4 (((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>)) +NAT-1K1 \<one>\<^sub>M)"
      using A3 sorry
    also have "... = x4"
      using A1 finseq_1_th_42 sorry
    finally show "p .FUNCT-1K1 \<four>\<^sub>M =HIDDENR1 x4"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_67:
" for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds  for x5 be setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M1 holds p =FUNCT-1R1 ((((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>) implies ((((lenFINSEQ-1K4 p =XBOOLE-0R4 \<five>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x1) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x5"
proof-
  have " for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds  for x5 be setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M1 holds p =FUNCT-1R1 ((((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>) implies lenFINSEQ-1K4 p =HIDDENR1 \<five>\<^sub>M & ((((p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x1 & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<five>\<^sub>M =HIDDENR1 x5)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI)
    fix x1 assume [ty]: "x1 be setHIDDENM2"
    fix x2 assume [ty]: "x2 be setHIDDENM2"
    fix x3 assume [ty]: "x3 be setHIDDENM2"
    fix x4 assume [ty]: "x4 be setHIDDENM2"
    fix x5 assume [ty]: "x5 be setHIDDENM2"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    assume A1: "p =FUNCT-1R1 ((((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>)"
    let ?p14 = "(((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>)"
    have A2: "lenFINSEQ-1K4 ?p14 =XBOOLE-0R4 \<four>\<^sub>M"
      using finseq_1_th_66 sorry
    have A3: "?p14 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x1 & ?p14 .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x2"
      using finseq_1_th_66 sorry
    have A4: "?p14 .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x3 & ?p14 .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x4"
      using finseq_1_th_66 sorry
    have "lenFINSEQ-1K4 p =HIDDENR1 lenFINSEQ-1K4 ((((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>)) +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x5*>)"
      using A1 finseq_1_th_22 sorry
    also have "... = \<four>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
      using A2 finseq_1_th_40 sorry
    also have "... = \<five>\<^sub>M"
       sorry
    finally show "lenFINSEQ-1K4 p =HIDDENR1 \<five>\<^sub>M"
       sorry
    have A5: "domFINSEQ-1K5 ?p14 =XBOOLE-0R4 SegFINSEQ-1K2 \<four>\<^sub>M"
      using A2 finseq_1_def_3 sorry
    have " for VarFor1 be setHIDDENM2 holds \<one>\<^sub>M <=XXREAL-0R1 VarFor1 & VarFor1 <=XXREAL-0R1 \<four>\<^sub>M implies  not VarFor1 inTARSKIR2 SegFINSEQ-1K2 \<four>\<^sub>M"
       sorry
    thus "((p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x1 & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x4"
      using A1 A3 A4 finseq_1_def_7 A5 sorry
    have "p .FUNCT-1K1 \<five>\<^sub>M =HIDDENR1 p .FUNCT-1K1 (lenFINSEQ-1K4 ((((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>)) +NAT-1K1 \<one>\<^sub>M)"
      using A2 sorry
    also have "... = x5"
      using A1 finseq_1_th_42 sorry
    finally show "p .FUNCT-1K1 \<five>\<^sub>M =HIDDENR1 x5"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_68:
" for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds  for x5 be setHIDDENM2 holds  for x6 be setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M1 holds p =FUNCT-1R1 (((((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x6*>) implies (((((lenFINSEQ-1K4 p =XBOOLE-0R4 \<six>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x1) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x5) & p .FUNCT-1K1 \<six>\<^sub>M =XBOOLE-0R4 x6"
proof-
  have " for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds  for x5 be setHIDDENM2 holds  for x6 be setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M1 holds p =FUNCT-1R1 (((((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x6*>) implies lenFINSEQ-1K4 p =HIDDENR1 \<six>\<^sub>M & (((((p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x1 & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x5) & p .FUNCT-1K1 \<six>\<^sub>M =HIDDENR1 x6)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI)
    fix x1 assume [ty]: "x1 be setHIDDENM2"
    fix x2 assume [ty]: "x2 be setHIDDENM2"
    fix x3 assume [ty]: "x3 be setHIDDENM2"
    fix x4 assume [ty]: "x4 be setHIDDENM2"
    fix x5 assume [ty]: "x5 be setHIDDENM2"
    fix x6 assume [ty]: "x6 be setHIDDENM2"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    assume A1: "p =FUNCT-1R1 (((((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x6*>)"
    let ?p15 = "((((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>)"
    have A2: "lenFINSEQ-1K4 ?p15 =XBOOLE-0R4 \<five>\<^sub>M"
      using finseq_1_th_67 sorry
    have A3: "?p15 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x1 & ?p15 .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x2"
      using finseq_1_th_67 sorry
    have A4: "?p15 .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x3 & ?p15 .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x4"
      using finseq_1_th_67 sorry
    have A5: "?p15 .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x5"
      using finseq_1_th_67 sorry
    have "lenFINSEQ-1K4 p =HIDDENR1 lenFINSEQ-1K4 (((((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>)) +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x6*>)"
      using A1 finseq_1_th_22 sorry
    also have "... = \<five>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
      using A2 finseq_1_th_40 sorry
    also have "... = \<six>\<^sub>M"
       sorry
    finally show "lenFINSEQ-1K4 p =HIDDENR1 \<six>\<^sub>M"
       sorry
    have A6: "domFINSEQ-1K5 ?p15 =XBOOLE-0R4 SegFINSEQ-1K2 \<five>\<^sub>M"
      using A2 finseq_1_def_3 sorry
    have " for VarFor1 be setHIDDENM2 holds \<one>\<^sub>M <=XXREAL-0R1 VarFor1 & VarFor1 <=XXREAL-0R1 \<five>\<^sub>M implies  not VarFor1 inTARSKIR2 SegFINSEQ-1K2 \<five>\<^sub>M"
       sorry
    thus "(((p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x1 & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x5"
      using A1 A3 A4 A5 finseq_1_def_7 A6 sorry
    have "p .FUNCT-1K1 \<six>\<^sub>M =HIDDENR1 p .FUNCT-1K1 (lenFINSEQ-1K4 (((((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>)) +NAT-1K1 \<one>\<^sub>M)"
      using A2 sorry
    also have "... = x6"
      using A1 finseq_1_th_42 sorry
    finally show "p .FUNCT-1K1 \<six>\<^sub>M =HIDDENR1 x6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_69:
" for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds  for x5 be setHIDDENM2 holds  for x6 be setHIDDENM2 holds  for x7 be setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M1 holds p =FUNCT-1R1 ((((((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x6*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x7*>) implies ((((((lenFINSEQ-1K4 p =XBOOLE-0R4 \<seven>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x1) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x5) & p .FUNCT-1K1 \<six>\<^sub>M =XBOOLE-0R4 x6) & p .FUNCT-1K1 \<seven>\<^sub>M =XBOOLE-0R4 x7"
proof-
  have " for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds  for x5 be setHIDDENM2 holds  for x6 be setHIDDENM2 holds  for x7 be setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M1 holds p =FUNCT-1R1 ((((((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x6*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x7*>) implies lenFINSEQ-1K4 p =HIDDENR1 \<seven>\<^sub>M & ((((((p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x1 & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x5) & p .FUNCT-1K1 \<six>\<^sub>M =XBOOLE-0R4 x6) & p .FUNCT-1K1 \<seven>\<^sub>M =HIDDENR1 x7)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI)
    fix x1 assume [ty]: "x1 be setHIDDENM2"
    fix x2 assume [ty]: "x2 be setHIDDENM2"
    fix x3 assume [ty]: "x3 be setHIDDENM2"
    fix x4 assume [ty]: "x4 be setHIDDENM2"
    fix x5 assume [ty]: "x5 be setHIDDENM2"
    fix x6 assume [ty]: "x6 be setHIDDENM2"
    fix x7 assume [ty]: "x7 be setHIDDENM2"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    assume A1: "p =FUNCT-1R1 ((((((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x6*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x7*>)"
    let ?p16 = "(((((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x6*>)"
    have A2: "lenFINSEQ-1K4 ?p16 =XBOOLE-0R4 \<six>\<^sub>M"
      using finseq_1_th_68 sorry
    have A3: "?p16 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x1 & ?p16 .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x2"
      using finseq_1_th_68 sorry
    have A4: "?p16 .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x3 & ?p16 .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x4"
      using finseq_1_th_68 sorry
    have A5: "?p16 .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x5 & ?p16 .FUNCT-1K1 \<six>\<^sub>M =XBOOLE-0R4 x6"
      using finseq_1_th_68 sorry
    have "lenFINSEQ-1K4 p =HIDDENR1 lenFINSEQ-1K4 ((((((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x6*>)) +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x7*>)"
      using A1 finseq_1_th_22 sorry
    also have "... = \<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
      using A2 finseq_1_th_40 sorry
    also have "... = \<seven>\<^sub>M"
       sorry
    finally show "lenFINSEQ-1K4 p =HIDDENR1 \<seven>\<^sub>M"
       sorry
    have A6: "domFINSEQ-1K5 ?p16 =XBOOLE-0R4 SegFINSEQ-1K2 \<six>\<^sub>M"
      using A2 finseq_1_def_3 sorry
    have " for VarFor1 be setHIDDENM2 holds \<one>\<^sub>M <=XXREAL-0R1 VarFor1 & VarFor1 <=XXREAL-0R1 \<six>\<^sub>M implies  not VarFor1 inTARSKIR2 SegFINSEQ-1K2 \<six>\<^sub>M"
       sorry
    thus "((((p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x1 & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x5) & p .FUNCT-1K1 \<six>\<^sub>M =XBOOLE-0R4 x6"
      using A1 A3 A4 A5 finseq_1_def_7 A6 sorry
    have "p .FUNCT-1K1 \<seven>\<^sub>M =HIDDENR1 p .FUNCT-1K1 (lenFINSEQ-1K4 ((((((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x6*>)) +NAT-1K1 \<one>\<^sub>M)"
      using A2 sorry
    also have "... = x7"
      using A1 finseq_1_th_42 sorry
    finally show "p .FUNCT-1K1 \<seven>\<^sub>M =HIDDENR1 x7"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_70:
" for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds  for x5 be setHIDDENM2 holds  for x6 be setHIDDENM2 holds  for x7 be setHIDDENM2 holds  for x8 be setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M1 holds p =FUNCT-1R1 (((((((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x6*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x7*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x8*>) implies (((((((lenFINSEQ-1K4 p =XBOOLE-0R4 \<eight>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x1) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x5) & p .FUNCT-1K1 \<six>\<^sub>M =XBOOLE-0R4 x6) & p .FUNCT-1K1 \<seven>\<^sub>M =XBOOLE-0R4 x7) & p .FUNCT-1K1 \<eight>\<^sub>M =XBOOLE-0R4 x8"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
  fix x1 assume [ty]: "x1 be setHIDDENM2"
  fix x2 assume [ty]: "x2 be setHIDDENM2"
  fix x3 assume [ty]: "x3 be setHIDDENM2"
  fix x4 assume [ty]: "x4 be setHIDDENM2"
  fix x5 assume [ty]: "x5 be setHIDDENM2"
  fix x6 assume [ty]: "x6 be setHIDDENM2"
  fix x7 assume [ty]: "x7 be setHIDDENM2"
  fix x8 assume [ty]: "x8 be setHIDDENM2"
  fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
  show "p =FUNCT-1R1 (((((((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x6*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x7*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x8*>) implies (((((((lenFINSEQ-1K4 p =XBOOLE-0R4 \<eight>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x1) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x5) & p .FUNCT-1K1 \<six>\<^sub>M =XBOOLE-0R4 x6) & p .FUNCT-1K1 \<seven>\<^sub>M =XBOOLE-0R4 x7) & p .FUNCT-1K1 \<eight>\<^sub>M =XBOOLE-0R4 x8"
  proof-
    have "p =FUNCT-1R1 (((((((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x6*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x7*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x8*>) implies lenFINSEQ-1K4 p =HIDDENR1 \<eight>\<^sub>M & (((((((p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x1 & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x5) & p .FUNCT-1K1 \<six>\<^sub>M =XBOOLE-0R4 x6) & p .FUNCT-1K1 \<seven>\<^sub>M =XBOOLE-0R4 x7) & p .FUNCT-1K1 \<eight>\<^sub>M =HIDDENR1 x8)"
    proof(rule impI,rule conjMI,rule conjMI)
      assume A1: "p =FUNCT-1R1 (((((((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x6*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x7*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x8*>)"
      let ?p17 = "((((((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x6*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x7*>)"
      have A2: "lenFINSEQ-1K4 ?p17 =XBOOLE-0R4 \<seven>\<^sub>M"
        using finseq_1_th_69 sorry
      have A3: "?p17 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x1 & ?p17 .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x2"
        using finseq_1_th_69 sorry
      have A4: "?p17 .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x3 & ?p17 .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x4"
        using finseq_1_th_69 sorry
      have A5: "?p17 .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x5 & ?p17 .FUNCT-1K1 \<six>\<^sub>M =XBOOLE-0R4 x6"
        using finseq_1_th_69 sorry
      have A6: "?p17 .FUNCT-1K1 \<seven>\<^sub>M =XBOOLE-0R4 x7"
        using finseq_1_th_69 sorry
      have "lenFINSEQ-1K4 p =HIDDENR1 lenFINSEQ-1K4 (((((((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x6*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x7*>)) +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x8*>)"
        using A1 finseq_1_th_22 sorry
      also have "... = \<seven>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
        using A2 finseq_1_th_40 sorry
      also have "... = \<eight>\<^sub>M"
         sorry
      finally show "lenFINSEQ-1K4 p =HIDDENR1 \<eight>\<^sub>M"
         sorry
      have A7: "domFINSEQ-1K5 ?p17 =XBOOLE-0R4 SegFINSEQ-1K2 \<seven>\<^sub>M"
        using A2 finseq_1_def_3 sorry
      have " for VarFor1 be setHIDDENM2 holds \<one>\<^sub>M <=XXREAL-0R1 VarFor1 & VarFor1 <=XXREAL-0R1 \<seven>\<^sub>M implies  not VarFor1 inTARSKIR2 SegFINSEQ-1K2 \<seven>\<^sub>M"
         sorry
      thus "(((((p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x1 & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x5) & p .FUNCT-1K1 \<six>\<^sub>M =XBOOLE-0R4 x6) & p .FUNCT-1K1 \<seven>\<^sub>M =XBOOLE-0R4 x7"
        using A1 A3 A4 A5 A6 finseq_1_def_7 A7 sorry
      have "p .FUNCT-1K1 \<eight>\<^sub>M =HIDDENR1 p .FUNCT-1K1 (lenFINSEQ-1K4 (((((((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x6*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x7*>)) +NAT-1K1 \<one>\<^sub>M)"
        using A2 sorry
      also have "... = x8"
        using A1 finseq_1_th_42 sorry
      finally show "p .FUNCT-1K1 \<eight>\<^sub>M =HIDDENR1 x8"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finseq_1_th_71:
" for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds  for x5 be setHIDDENM2 holds  for x6 be setHIDDENM2 holds  for x7 be setHIDDENM2 holds  for x8 be setHIDDENM2 holds  for x9 be setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M1 holds p =FUNCT-1R1 ((((((((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x6*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x7*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x8*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x9*>) implies ((((((((lenFINSEQ-1K4 p =XBOOLE-0R4 \<nine>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x1) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x5) & p .FUNCT-1K1 \<six>\<^sub>M =XBOOLE-0R4 x6) & p .FUNCT-1K1 \<seven>\<^sub>M =XBOOLE-0R4 x7) & p .FUNCT-1K1 \<eight>\<^sub>M =XBOOLE-0R4 x8) & p .FUNCT-1K1 \<nine>\<^sub>M =XBOOLE-0R4 x9"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
  fix x1 assume [ty]: "x1 be setHIDDENM2"
  fix x2 assume [ty]: "x2 be setHIDDENM2"
  fix x3 assume [ty]: "x3 be setHIDDENM2"
  fix x4 assume [ty]: "x4 be setHIDDENM2"
  fix x5 assume [ty]: "x5 be setHIDDENM2"
  fix x6 assume [ty]: "x6 be setHIDDENM2"
  fix x7 assume [ty]: "x7 be setHIDDENM2"
  fix x8 assume [ty]: "x8 be setHIDDENM2"
  fix x9 assume [ty]: "x9 be setHIDDENM2"
  fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
  show "p =FUNCT-1R1 ((((((((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x6*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x7*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x8*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x9*>) implies ((((((((lenFINSEQ-1K4 p =XBOOLE-0R4 \<nine>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x1) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x5) & p .FUNCT-1K1 \<six>\<^sub>M =XBOOLE-0R4 x6) & p .FUNCT-1K1 \<seven>\<^sub>M =XBOOLE-0R4 x7) & p .FUNCT-1K1 \<eight>\<^sub>M =XBOOLE-0R4 x8) & p .FUNCT-1K1 \<nine>\<^sub>M =XBOOLE-0R4 x9"
  proof-
    have "p =FUNCT-1R1 ((((((((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x6*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x7*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x8*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x9*>) implies lenFINSEQ-1K4 p =HIDDENR1 \<nine>\<^sub>M & ((((((((p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x1 & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x5) & p .FUNCT-1K1 \<six>\<^sub>M =XBOOLE-0R4 x6) & p .FUNCT-1K1 \<seven>\<^sub>M =XBOOLE-0R4 x7) & p .FUNCT-1K1 \<eight>\<^sub>M =XBOOLE-0R4 x8) & p .FUNCT-1K1 \<nine>\<^sub>M =HIDDENR1 x9)"
    proof(rule impI,rule conjMI,rule conjMI)
      assume A1: "p =FUNCT-1R1 ((((((((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x6*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x7*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x8*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x9*>)"
      let ?p17 = "(((((((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x6*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x7*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x8*>)"
      have A2: "lenFINSEQ-1K4 ?p17 =XBOOLE-0R4 \<eight>\<^sub>M"
        using finseq_1_th_70 sorry
      have A3: "?p17 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x1 & ?p17 .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x2"
        using finseq_1_th_70 sorry
      have A4: "?p17 .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x3 & ?p17 .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x4"
        using finseq_1_th_70 sorry
      have A5: "?p17 .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x5 & ?p17 .FUNCT-1K1 \<six>\<^sub>M =XBOOLE-0R4 x6"
        using finseq_1_th_70 sorry
      have A6: "?p17 .FUNCT-1K1 \<seven>\<^sub>M =XBOOLE-0R4 x7 & ?p17 .FUNCT-1K1 \<eight>\<^sub>M =XBOOLE-0R4 x8"
        using finseq_1_th_70 sorry
      have "lenFINSEQ-1K4 p =HIDDENR1 lenFINSEQ-1K4 ((((((((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x6*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x7*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x8*>)) +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x9*>)"
        using A1 finseq_1_th_22 sorry
      also have "... = \<eight>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
        using A2 finseq_1_th_40 sorry
      also have "... = \<nine>\<^sub>M"
         sorry
      finally show "lenFINSEQ-1K4 p =HIDDENR1 \<nine>\<^sub>M"
         sorry
      have A7: "domFINSEQ-1K5 ?p17 =XBOOLE-0R4 SegFINSEQ-1K2 \<eight>\<^sub>M"
        using A2 finseq_1_def_3 sorry
      have " for VarFor1 be setHIDDENM2 holds \<one>\<^sub>M <=XXREAL-0R1 VarFor1 & VarFor1 <=XXREAL-0R1 \<eight>\<^sub>M implies  not VarFor1 inTARSKIR2 SegFINSEQ-1K2 \<eight>\<^sub>M"
         sorry
      thus "((((((p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x1 & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x5) & p .FUNCT-1K1 \<six>\<^sub>M =XBOOLE-0R4 x6) & p .FUNCT-1K1 \<seven>\<^sub>M =XBOOLE-0R4 x7) & p .FUNCT-1K1 \<eight>\<^sub>M =XBOOLE-0R4 x8"
        using A1 A3 A4 A5 A6 finseq_1_def_7 A7 sorry
      have "p .FUNCT-1K1 \<nine>\<^sub>M =HIDDENR1 p .FUNCT-1K1 (lenFINSEQ-1K4 ((((((((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x6*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x7*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x8*>)) +NAT-1K1 \<one>\<^sub>M)"
        using A2 sorry
      also have "... = x9"
        using A1 finseq_1_th_42 sorry
      finally show "p .FUNCT-1K1 \<nine>\<^sub>M =HIDDENR1 x9"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finseq_1_th_72:
" for p be FinSequenceFINSEQ-1M1 holds p  |FINSEQ-1K17 SegFINSEQ-1K2 (0NUMBERSK6) =FUNCT-1R1 {}XBOOLE-0K1"
   sorry

mtheorem finseq_1_th_73:
" for f be FinSequenceFINSEQ-1M1 holds  for g be FinSequenceFINSEQ-1M1 holds f  |FINSEQ-1K17 SegFINSEQ-1K2 (0NUMBERSK6) =FUNCT-1R1 g  |FINSEQ-1K17 SegFINSEQ-1K2 (0NUMBERSK6)"
   sorry

mtheorem finseq_1_th_74:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of D holds <*FINSEQ-1K13\<^bsub>(D)\<^esub> x*> be FinSequenceFINSEQ-1M3-of D"
   sorry

mtheorem finseq_1_th_75:
" for D be setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M3-of D holds  for q be FinSequenceFINSEQ-1M3-of D holds p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q be FinSequenceFINSEQ-1M3-of D"
   sorry

reserve a, b, c, d, e, f for "objectHIDDENM1"
mtheorem finseq_1_th_76:
" for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds <*FINSEQ-1K10 a*> =FUNCT-1R1 <*FINSEQ-1K10 b*> implies a =HIDDENR1 b"
proof-
  have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds <*FINSEQ-1K10 a*> =FUNCT-1R1 <*FINSEQ-1K10 b*> implies a =HIDDENR1 b"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be objectHIDDENM1"
    fix b assume [ty]: "b be objectHIDDENM1"
    assume A1: "<*FINSEQ-1K10 a*> =FUNCT-1R1 <*FINSEQ-1K10 b*>"
    have "a =HIDDENR1 (<*FINSEQ-1K10 a*>).FUNCT-1K1 \<one>\<^sub>M"
      using finseq_1_def_8 sorry
    also have "... = b"
      using A1 finseq_1_def_8 sorry
    finally show "a =HIDDENR1 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_77:
" for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds  for d be objectHIDDENM1 holds <*FINSEQ-1K11 a,b *> =FUNCT-1R1 <*FINSEQ-1K11 c,d *> implies a =HIDDENR1 c & b =HIDDENR1 d"
proof-
  have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds  for d be objectHIDDENM1 holds <*FINSEQ-1K11 a,b *> =FUNCT-1R1 <*FINSEQ-1K11 c,d *> implies a =HIDDENR1 c & b =HIDDENR1 d"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix a assume [ty]: "a be objectHIDDENM1"
    fix b assume [ty]: "b be objectHIDDENM1"
    fix c assume [ty]: "c be objectHIDDENM1"
    fix d assume [ty]: "d be objectHIDDENM1"
    assume A1: "<*FINSEQ-1K11 a,b *> =FUNCT-1R1 <*FINSEQ-1K11 c,d *>"
    have "a =HIDDENR1 (<*FINSEQ-1K11 a,b *>).FUNCT-1K1 \<one>\<^sub>M"
      using finseq_1_th_44 sorry
    also have "... = c"
      using A1 finseq_1_th_44 sorry
    finally show "a =HIDDENR1 c"
       sorry
    have "b =HIDDENR1 (<*FINSEQ-1K11 a,b *>).FUNCT-1K1 \<two>\<^sub>M"
      using finseq_1_th_44 sorry
    also have "... = d"
      using A1 finseq_1_th_44 sorry
    finally show "b =HIDDENR1 d"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_78:
" for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds  for d be objectHIDDENM1 holds  for e be objectHIDDENM1 holds  for f be objectHIDDENM1 holds <*FINSEQ-1K12 a,b,c *> =FUNCT-1R1 <*FINSEQ-1K12 d,e,f *> implies (a =HIDDENR1 d & b =HIDDENR1 e) & c =HIDDENR1 f"
proof-
  have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds  for d be objectHIDDENM1 holds  for e be objectHIDDENM1 holds  for f be objectHIDDENM1 holds <*FINSEQ-1K12 a,b,c *> =FUNCT-1R1 <*FINSEQ-1K12 d,e,f *> implies a =HIDDENR1 d & (b =HIDDENR1 e & c =HIDDENR1 f)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI)
    fix a assume [ty]: "a be objectHIDDENM1"
    fix b assume [ty]: "b be objectHIDDENM1"
    fix c assume [ty]: "c be objectHIDDENM1"
    fix d assume [ty]: "d be objectHIDDENM1"
    fix e assume [ty]: "e be objectHIDDENM1"
    fix f assume [ty]: "f be objectHIDDENM1"
    assume A1: "<*FINSEQ-1K12 a,b,c *> =FUNCT-1R1 <*FINSEQ-1K12 d,e,f *>"
    have "a =HIDDENR1 (<*FINSEQ-1K12 a,b,c *>).FUNCT-1K1 \<one>\<^sub>M"
      using finseq_1_th_45 sorry
    also have "... = d"
      using A1 finseq_1_th_45 sorry
    finally show "a =HIDDENR1 d"
       sorry
    have "b =HIDDENR1 (<*FINSEQ-1K12 a,b,c *>).FUNCT-1K1 \<two>\<^sub>M"
      using finseq_1_th_45 sorry
    also have "... = e"
      using A1 finseq_1_th_45 sorry
    finally show "b =HIDDENR1 e"
       sorry
    have "c =HIDDENR1 (<*FINSEQ-1K12 a,b,c *>).FUNCT-1K1 \<three>\<^sub>M"
      using finseq_1_th_45 sorry
    also have "... = f"
      using A1 finseq_1_th_45 sorry
    finally show "c =HIDDENR1 f"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_cl_34:
"cluster  non emptyXBOOLE-0V1\<bar>non-emptyFUNCT-1V4 for FinSequenceFINSEQ-1M1"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M1 st it be  non emptyXBOOLE-0V1\<bar>non-emptyFUNCT-1V4"
  proof-
    have " ex tVar29 be FinSequenceFINSEQ-1M1 st tVar29 be  non emptyXBOOLE-0V1 & tVar29 be non-emptyFUNCT-1V4"
    proof-
      show " ex tVar29 be FinSequenceFINSEQ-1M1 st tVar29 be  non emptyXBOOLE-0V1 & tVar29 be non-emptyFUNCT-1V4"
      proof(rule bexI[of _ "<*FINSEQ-1K10 {TARSKIK1 {}XBOOLE-0K1 }*>"],rule conjMI)
        show "<*FINSEQ-1K10 {TARSKIK1 {}XBOOLE-0K1 }*> be  non emptyXBOOLE-0V1"
           sorry
        have "{}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K10 {TARSKIK1 {}XBOOLE-0K1 }*>) implies  False "
        proof(rule impI)
          assume "{}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K10 {TARSKIK1 {}XBOOLE-0K1 }*>)"
          then have "{}XBOOLE-0K1 inTARSKIR2 {TARSKIK1 {TARSKIK1 {}XBOOLE-0K1 } }"
            using finseq_1_th_38 sorry
          thus " False "
            using tarski_def_1 sorry
        qed
        thus "<*FINSEQ-1K10 {TARSKIK1 {}XBOOLE-0K1 }*> be non-emptyFUNCT-1V4"
          using relat_1_def_9 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finseq_1_th_79:
" for n be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds q =FUNCT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 n implies lenFINSEQ-1K4 q <=XXREAL-0R1 lenFINSEQ-1K4 p"
proof-
  have " for n be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds q =FUNCT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 n implies lenFINSEQ-1K4 q <=XXREAL-0R1 lenFINSEQ-1K4 p"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    assume "q =FUNCT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 n"
    then have A1: "domFINSEQ-1K5 q =XBOOLE-0R4 domFINSEQ-1K5 p /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 n"
      using relat_1_th_61 sorry
    have "SegFINSEQ-1K2 (lenFINSEQ-1K4 q) =XBOOLE-0R4 domFINSEQ-1K5 q & SegFINSEQ-1K2 (lenFINSEQ-1K4 p) =XBOOLE-0R4 domFINSEQ-1K5 p"
      using finseq_1_def_3 sorry
    thus "lenFINSEQ-1K4 q <=XXREAL-0R1 lenFINSEQ-1K4 p"
      using finseq_1_th_5 A1 xboole_1_th_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_80:
" for n be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds  for r be FinSequenceFINSEQ-1M1 holds r =FUNCT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 n implies ( ex q be FinSequenceFINSEQ-1M1 st p =FUNCT-1R1 r ^FINSEQ-1K8 q)"
proof-
  have " for n be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds  for r be FinSequenceFINSEQ-1M1 holds r =FUNCT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 n implies ( ex tVar30 be FinSequenceFINSEQ-1M1 st p =FUNCT-1R1 r ^FINSEQ-1K8 tVar30)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix r assume [ty]: "r be FinSequenceFINSEQ-1M1"
    assume A1: "r =FUNCT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 n"
    then obtain m where
      [ty]:"m be NatNAT-1M1" and 
      A2: "lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 r +XCMPLX-0K2 m"
      using finseq_1_th_79 nat_1_th_10 sorry
    let ?U = "\<lambda>Lamb1. p .FUNCT-1K1 (lenFINSEQ-1K4 r +XCMPLX-0K2 Lamb1)"
    obtain q where
      [ty]:"q be FinSequenceFINSEQ-1M1" and 
      A3: "lenFINSEQ-1K4 q =XBOOLE-0R4 m & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 q implies q .FUNCT-1K1 k =XBOOLE-0R4 ?U(k))"
      using finseq_1_sch_2 sorry
    show " ex tVar30 be FinSequenceFINSEQ-1M1 st p =FUNCT-1R1 r ^FINSEQ-1K8 tVar30"
    proof(rule bexI[of _ "q"])
      have A4: "lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 (r ^FINSEQ-1K8 q)"
        using A2 A3 finseq_1_th_22 sorry
      have " for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 p implies p .FUNCT-1K1 k =XBOOLE-0R4 (r ^FINSEQ-1K8 q).FUNCT-1K1 k"
      proof(rule ballI,rule impMI ,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A5: "\<one>\<^sub>M <=XXREAL-0R1 k"
          and A6: "k <=XXREAL-0R1 lenFINSEQ-1K4 p"
        have A7: "k <=XXREAL-0R1 lenFINSEQ-1K4 r implies p .FUNCT-1K1 k =XBOOLE-0R4 (r ^FINSEQ-1K8 q).FUNCT-1K1 k"
        proof(rule impI)
          assume "k <=XXREAL-0R1 lenFINSEQ-1K4 r"
          then have A8: "k inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 r)"
            using A5 sorry
          have A9: "domFINSEQ-1K5 r =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 r)"
            using finseq_1_def_3 sorry
          then have "(r ^FINSEQ-1K8 q).FUNCT-1K1 k =XBOOLE-0R4 r .FUNCT-1K1 k"
            using A8 finseq_1_def_7 sorry
          thus "p .FUNCT-1K1 k =XBOOLE-0R4 (r ^FINSEQ-1K8 q).FUNCT-1K1 k"
            using A1 A8 A9 funct_1_th_47 sorry
        qed
        have " not k <=XXREAL-0R1 lenFINSEQ-1K4 r implies p .FUNCT-1K1 k =XBOOLE-0R4 (r ^FINSEQ-1K8 q).FUNCT-1K1 k"
        proof(rule impI)
          assume A10: " not k <=XXREAL-0R1 lenFINSEQ-1K4 r"
          then obtain j where
            [ty]:"j be NatNAT-1M1" and 
            A11: "k =XBOOLE-0R4 lenFINSEQ-1K4 r +XCMPLX-0K2 j"
            using nat_1_th_10 sorry
          have "k -XCMPLX-0K6 lenFINSEQ-1K4 r =XBOOLE-0R4 j"
            using A11 sorry
          then have A12: "(r ^FINSEQ-1K8 q).FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 j"
            using A4 A6 A10 finseq_1_th_24 sorry
          have "j <>HIDDENR2 0NUMBERSK6"
            using A10 A11 sorry
          then have A13: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 j"
            using nat_1_th_13 sorry
          have "j <=XXREAL-0R1 lenFINSEQ-1K4 q"
            using A2 A3 A6 A11 xreal_1_th_6 sorry
          then have "j inTARSKIR2 SegFINSEQ-1K2 m"
            using A3 A13 sorry
          then have "j inTARSKIR2 domFINSEQ-1K5 q"
            using A3 finseq_1_def_3 sorry
          thus "p .FUNCT-1K1 k =XBOOLE-0R4 (r ^FINSEQ-1K8 q).FUNCT-1K1 k"
            using A3 A11 A12 sorry
        qed
        thus "p .FUNCT-1K1 k =XBOOLE-0R4 (r ^FINSEQ-1K8 q).FUNCT-1K1 k"
          using A7 sorry
      qed "sorry"
      thus "p =FUNCT-1R1 r ^FINSEQ-1K8 q"
        using A4 finseq_1_th_14 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_cl_35:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster  non emptyXBOOLE-0V1 for FinSequenceFINSEQ-1M3-of D"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M3-of D st it be  non emptyXBOOLE-0V1"
  proof-
    have " ex tVar31 be FinSequenceFINSEQ-1M3-of D st  not tVar31 be emptyXBOOLE-0V1"
    proof-
      let ?x = "the ElementSUBSET-1M1-of D"
      show " ex tVar31 be FinSequenceFINSEQ-1M3-of D st  not tVar31 be emptyXBOOLE-0V1"
      proof(rule bexI[of _ "<*FINSEQ-1K13\<^bsub>(D)\<^esub> ?x*>"])
        show " not <*FINSEQ-1K13\<^bsub>(D)\<^esub> the ElementSUBSET-1M1-of D *> be emptyXBOOLE-0V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

abbreviation(input) FINSEQ_1R1(" _ =FINSEQ-1R1  _ " [50,50]50) where
  "p =FINSEQ-1R1 q \<equiv> p =HIDDENR1 q"

mtheorem finseq_1_def_17:
  mlet "p be FinSequenceFINSEQ-1M1", "q be FinSequenceFINSEQ-1M1"
"redefine pred p =FINSEQ-1R1 q means
  lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 p implies p .FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 k)"
proof
(*compatibility*)
  show "p =FINSEQ-1R1 q iff lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 p implies p .FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 k)"
    using finseq_1_th_14 sorry
qed "sorry"

mtheorem finseq_1_th_81:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds (\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K12 x,y,z *>) & \<two>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K12 x,y,z *>)) & \<three>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K12 x,y,z *>)"
proof(rule ballI,rule ballI,rule ballI)
  fix x assume [ty]: "x be objectHIDDENM1"
  fix y assume [ty]: "y be objectHIDDENM1"
  fix z assume [ty]: "z be objectHIDDENM1"
  have "lenFINSEQ-1K4 (<*FINSEQ-1K12 x,y,z *>) =XBOOLE-0R4 \<three>\<^sub>M"
    using finseq_1_th_45 sorry
  then have "domFINSEQ-1K5 (<*FINSEQ-1K12 x,y,z *>) =XBOOLE-0R4 SegFINSEQ-1K2 \<three>\<^sub>M"
    using finseq_1_def_3 sorry
  thus "(\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K12 x,y,z *>) & \<two>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K12 x,y,z *>)) & \<three>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K12 x,y,z *>)"
     sorry
qed "sorry"

mtheorem finseq_1_th_82:
" for p be FinSequenceFINSEQ-1M1 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m <=XXREAL-0R1 n implies (p  |FINSEQ-1K17 n) |FINSEQ-1K17 m =FINSEQ-1R1 p  |FINSEQ-1K17 m"
  using finseq_1_th_5 relat_1_th_74 sorry

reserve m for "NatNAT-1M1"
mtheorem finseq_1_th_83:
" for n be NatNAT-1M1 holds SegFINSEQ-1K2 n =XBOOLE-0R4 (n +NAT-1K1 \<one>\<^sub>M)\\SUBSET-1K6 {TARSKIK1 0NUMBERSK6 }"
proof-
  have " for n be NatNAT-1M1 holds SegFINSEQ-1K2 n =XBOOLE-0R4 (n +NAT-1K1 \<one>\<^sub>M)\\SUBSET-1K6 {TARSKIK1 0NUMBERSK6 }"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have A1: "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 {m where m be NatNAT-1M1 : m <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M }"
      using axioms_th_4 sorry
    have "SegFINSEQ-1K2 n c=TARSKIR1 (n +NAT-1K1 \<one>\<^sub>M)\\SUBSET-1K6 {TARSKIK1 0NUMBERSK6 } & (n +NAT-1K1 \<one>\<^sub>M)\\SUBSET-1K6 {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 SegFINSEQ-1K2 n"
    proof(rule conjMI)
      show "SegFINSEQ-1K2 n c=TARSKIR1 (n +NAT-1K1 \<one>\<^sub>M)\\SUBSET-1K6 {TARSKIK1 0NUMBERSK6 }"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 SegFINSEQ-1K2 n implies x inHIDDENR3 (n +NAT-1K1 \<one>\<^sub>M)\\SUBSET-1K6 {TARSKIK1 0NUMBERSK6 }"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 SegFINSEQ-1K2 n"
          then obtain k where
            [ty]:"k be NatNAT-1M1" and 
            A2: "x =HIDDENR1 k"and A3: "\<one>\<^sub>M <=XXREAL-0R1 k"and A4: "k <=XXREAL-0R1 n"
             sorry
          have "k <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
            using A4 nat_1_th_13 sorry
          then have A5: "x inHIDDENR3 n +NAT-1K1 \<one>\<^sub>M"
            using A1 A2 sorry
          have " not x inHIDDENR3 {TARSKIK1 0NUMBERSK6 }"
            using A2 A3 tarski_def_1 sorry
          thus "x inHIDDENR3 (n +NAT-1K1 \<one>\<^sub>M)\\SUBSET-1K6 {TARSKIK1 0NUMBERSK6 }"
            using A5 xboole_0_def_5 sorry
        qed "sorry"
        thus "SegFINSEQ-1K2 n c=TARSKIR1 (n +NAT-1K1 \<one>\<^sub>M)\\SUBSET-1K6 {TARSKIK1 0NUMBERSK6 }"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 (n +NAT-1K1 \<one>\<^sub>M)\\SUBSET-1K6 {TARSKIK1 0NUMBERSK6 } implies x inHIDDENR3 SegFINSEQ-1K2 n"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A6: "x inHIDDENR3 (n +NAT-1K1 \<one>\<^sub>M)\\SUBSET-1K6 {TARSKIK1 0NUMBERSK6 }"
        then have A7: "x inHIDDENR3 n +NAT-1K1 \<one>\<^sub>M"
           sorry
        have A8: " not x inHIDDENR3 {TARSKIK1 0NUMBERSK6 }"
          using A6 xboole_0_def_5 sorry
        obtain m where
          [ty]:"m be NatNAT-1M1" and 
          A9: "x =HIDDENR1 m"and A10: "m <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
          using A1 A7 sorry
        have A11: "x <>HIDDENR2 0NUMBERSK6"
          using A8 tarski_def_1 sorry
        have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
           sorry
        then have A12: "\<one>\<^sub>M <=XXREAL-0R1 m"
          using A9 A11 nat_1_th_13 sorry
        have "m <=XXREAL-0R1 n"
          using A10 nat_1_th_13 sorry
        thus "x inHIDDENR3 SegFINSEQ-1K2 n"
          using A9 A12 sorry
      qed "sorry"
      thus "(n +NAT-1K1 \<one>\<^sub>M)\\SUBSET-1K6 {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 SegFINSEQ-1K2 n"
        using tarski_def_3 sorry
    qed
    thus "SegFINSEQ-1K2 n =XBOOLE-0R4 (n +NAT-1K1 \<one>\<^sub>M)\\SUBSET-1K6 {TARSKIK1 0NUMBERSK6 }"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_cl_36:
  mlet "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster n -elementCARD-1V3 for FinSequenceFINSEQ-1M1"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M1 st it be n -elementCARD-1V3"
  proof-
    have " ex tVar32 be FinSequenceFINSEQ-1M1 st tVar32 be n -elementCARD-1V3"
    proof-
      have A1: "n be NatNAT-1M1"
        using tarski_th_1 sorry
      let ?p = "SegFINSEQ-1K1 n -->FUNCOP-1K7 {}XBOOLE-0K1"
      have "domRELAT-1K1 ?p =XBOOLE-0R4 SegFINSEQ-1K1 n"
        using funcop_1_th_13 sorry
      then obtain p where 
        [ty]:"p be FinSequenceFINSEQ-1M1" and pDef:"p = ?p"
        using A1 finseq_1_def_2 sorry
      show " ex tVar32 be FinSequenceFINSEQ-1M1 st tVar32 be n -elementCARD-1V3"
      proof(rule bexI[of _ "p"])
        have Cut3365: "SegFINSEQ-1K2 (lenFINSEQ-1K4 p) =XBOOLE-0R4 domFINSEQ-1K5 p"
          using finseq_1_def_3 sorry
        have "lenFINSEQ-1K4 p =HIDDENR1 n"
        proof-
          show "lenFINSEQ-1K4 p =HIDDENR1 n"
            using finseq_1_th_6 funcop_1_th_13 Cut3365 sorry
        qed
        thus "p be n -elementCARD-1V3"
          using card_1_def_0 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finseq_1_cl_37:
  mlet "x be objectHIDDENM1"
"cluster <*FINSEQ-1K10 x*> as-term-is \<one>\<^sub>M -elementCARD-1V3"
proof
(*coherence*)
  show "<*FINSEQ-1K10 x*> be \<one>\<^sub>M -elementCARD-1V3"
     sorry
qed "sorry"

mtheorem finseq_1_cl_38:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1"
"cluster <*FINSEQ-1K11 x,y *> as-term-is \<two>\<^sub>M -elementCARD-1V3"
proof
(*coherence*)
  show "<*FINSEQ-1K11 x,y *> be \<two>\<^sub>M -elementCARD-1V3"
    using finseq_1_th_44 sorry
qed "sorry"

mtheorem finseq_1_cl_39:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1", "z be objectHIDDENM1"
"cluster <*FINSEQ-1K12 x,y,z *> as-term-is \<three>\<^sub>M -elementCARD-1V3"
proof
(*coherence*)
  show "<*FINSEQ-1K12 x,y,z *> be \<three>\<^sub>M -elementCARD-1V3"
    using finseq_1_th_45 sorry
qed "sorry"

mdef finseq_1_def_18 ("FinSequence-memberedFINSEQ-1V3" 70 ) where
"attr FinSequence-memberedFINSEQ-1V3 for setHIDDENM2 means
  (\<lambda>X.  for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be FinSequenceFINSEQ-1M1)"..

mtheorem finseq_1_cl_40:
"cluster emptyXBOOLE-0V1 also-is FinSequence-memberedFINSEQ-1V3 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be emptyXBOOLE-0V1 implies it be FinSequence-memberedFINSEQ-1V3"
     sorry
qed "sorry"

mtheorem finseq_1_cl_41:
"cluster  non emptyXBOOLE-0V1\<bar>FinSequence-memberedFINSEQ-1V3 for setHIDDENM2"
proof
(*existence*)
  show " ex it be setHIDDENM2 st it be  non emptyXBOOLE-0V1\<bar>FinSequence-memberedFINSEQ-1V3"
  proof-
    have " ex X be setHIDDENM2 st X be  non emptyXBOOLE-0V1 & X be FinSequence-memberedFINSEQ-1V3"
    proof-
      obtain X where 
        [ty]:"X be setHIDDENM2" and XDef:"X = {TARSKIK1 the FinSequenceFINSEQ-1M1 }"
         sorry
      show " ex X be setHIDDENM2 st X be  non emptyXBOOLE-0V1 & X be FinSequence-memberedFINSEQ-1V3"
      proof(rule bexI[of _ "X"],rule conjMI)
        show "X be  non emptyXBOOLE-0V1"
           sorry
        have " for x be objectHIDDENM1 holds  not (x inHIDDENR3 X &  not x be FinSequenceFINSEQ-1M1)"
        proof(rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          show " not (x inHIDDENR3 X &  not x be FinSequenceFINSEQ-1M1)"
            using tarski_def_1 sorry
        qed "sorry"
        thus "X be FinSequence-memberedFINSEQ-1V3"
          using finseq_1_def_18 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finseq_1_cl_42:
  mlet "X be setHIDDENM2"
"cluster X * FINSEQ-1K14 as-term-is FinSequence-memberedFINSEQ-1V3"
proof
(*coherence*)
  show "X * FINSEQ-1K14 be FinSequence-memberedFINSEQ-1V3"
    using finseq_1_def_11 sorry
qed "sorry"

mtheorem finseq_1_th_84:
" for x be objectHIDDENM1 holds  for D be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f inTARSKIR2 D * FINSEQ-1K14 & x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x inTARSKIR2 D"
proof-
  have " for x be objectHIDDENM1 holds  for D be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f inTARSKIR2 D * FINSEQ-1K14 & x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x inTARSKIR2 D"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix D assume [ty]: "D be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "f inTARSKIR2 D * FINSEQ-1K14"
      and A2: "x inHIDDENR3 domRELAT-1K1 f"
    have "f be FinSequenceFINSEQ-1M3-of D"
      using A1 finseq_1_def_11 sorry
    then have A3: "rngFUNCT-1K2 f c=TARSKIR1 D"
      using finseq_1_def_4 sorry
    have "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f"
      using A2 funct_1_th_3 sorry
    thus "f .FUNCT-1K1 x inTARSKIR2 D"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_cl_43:
"cluster FinSequence-memberedFINSEQ-1V3 also-is functionalFUNCT-1V6 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be FinSequence-memberedFINSEQ-1V3 implies it be functionalFUNCT-1V6"
     sorry
qed "sorry"

mtheorem finseq_1_th_85:
" for X be FinSequence-memberedFINSEQ-1V3\<bar>setHIDDENM2 holds  ex Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 st X c=TARSKIR1 Y * FINSEQ-1K14"
proof-
  have " for X be FinSequence-memberedFINSEQ-1V3\<bar>setHIDDENM2 holds  ex Y be setHIDDENM2 st X c=TARSKIR1 Y * FINSEQ-1K14"
  proof(rule ballI)
    fix X assume [ty]: "X be FinSequence-memberedFINSEQ-1V3\<bar>setHIDDENM2"
    let ?Z = "{rngFUNCT-1K2 f where f be ElementSUBSET-1M1-of X : f inTARSKIR2 X }"
    obtain Y where 
      [ty]:"Y be setHIDDENM2" and YDef:"Y = succORDINAL1K1 (unionTARSKIK3 ?Z)"
       sorry
    show " ex Y be setHIDDENM2 st X c=TARSKIR1 Y * FINSEQ-1K14"
    proof(rule bexI[of _ "Y"])
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 Y * FINSEQ-1K14"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A1: "x inHIDDENR3 X"
        then have 
          [ty]:"x be FinSequenceFINSEQ-1M1"
          using finseq_1_def_18 sorry
        have "rngFUNCT-1K2 x inTARSKIR2 {rngFUNCT-1K2 f where f be ElementSUBSET-1M1-of X : f inTARSKIR2 X }"
          using A1 sorry
        then have "rngFUNCT-1K2 x c=TARSKIR1 Y"
          using ordinal3_th_1 setfam_1_th_41 sorry
        then have "x be FinSequenceFINSEQ-1M3-of Y"
          using finseq_1_def_4 sorry
        thus "x inHIDDENR3 Y * FINSEQ-1K14"
          using finseq_1_def_11 sorry
      qed "sorry"
      thus "X c=TARSKIR1 Y * FINSEQ-1K14"
        using tarski_def_3 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_cl_44:
  mlet "X be FinSequence-memberedFINSEQ-1V3\<bar>setHIDDENM2"
"cluster note-that FinSequence-likeFINSEQ-1V1 for ElementSUBSET-1M1-of X"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of X holds it be FinSequence-likeFINSEQ-1V1"
  proof-
    have " for e be ElementSUBSET-1M1-of X holds e be FinSequence-likeFINSEQ-1V1"
    proof(rule ballI)
      fix e assume [ty]: "e be ElementSUBSET-1M1-of X"
      have "X be emptyXBOOLE-0V1 or X be  non emptyXBOOLE-0V1"
         sorry
      thus "e be FinSequence-likeFINSEQ-1V1"
        using finseq_1_def_18 subset_1_def_1 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finseq_1_cl_45:
  mlet "X be FinSequence-memberedFINSEQ-1V3\<bar>setHIDDENM2"
"cluster note-that FinSequence-memberedFINSEQ-1V3 for SubsetSUBSET-1M2-of X"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of X holds it be FinSequence-memberedFINSEQ-1V3"
     sorry
qed "sorry"

mtheorem finseq_1_th_86:
" for n be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds q =FUNCT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 n implies lenFINSEQ-1K4 q <=XXREAL-0R1 n"
proof-
  have " for n be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds q =FUNCT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 n implies lenFINSEQ-1K4 q <=XXREAL-0R1 n"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    assume "q =FUNCT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 n"
    then have A1: "domFINSEQ-1K5 q =XBOOLE-0R4 domFINSEQ-1K5 p /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 n"
      using relat_1_th_61 sorry
    have "SegFINSEQ-1K2 (lenFINSEQ-1K4 q) =XBOOLE-0R4 domFINSEQ-1K5 q"
      using finseq_1_def_3 sorry
    thus "lenFINSEQ-1K4 q <=XXREAL-0R1 n"
      using finseq_1_th_5 A1 xboole_1_th_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_87:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds p =FINSEQ-1R1 p ^FINSEQ-1K8 q or p =FINSEQ-1R1 q ^FINSEQ-1K8 p implies q =FINSEQ-1R1 {}XBOOLE-0K1"
proof(rule ballI,rule ballI,rule impI)
  fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
  fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
  assume A1: "p =FINSEQ-1R1 p ^FINSEQ-1K8 q or p =FINSEQ-1R1 q ^FINSEQ-1K8 p"
  have "lenFINSEQ-1K4 (p ^FINSEQ-1K8 q) =XBOOLE-0R4 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q & lenFINSEQ-1K4 (q ^FINSEQ-1K8 p) =XBOOLE-0R4 lenFINSEQ-1K4 q +NAT-1K1 lenFINSEQ-1K4 p"
    using finseq_1_th_22 sorry
  thus "q =FINSEQ-1R1 {}XBOOLE-0K1"
    using A1 sorry
qed "sorry"

mtheorem finseq_1_th_88:
" for x be objectHIDDENM1 holds  for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds p ^FINSEQ-1K8 q =FINSEQ-1R1 <*FINSEQ-1K10 x*> implies p =FINSEQ-1R1 <*FINSEQ-1K10 x*> & q =FINSEQ-1R1 {}XBOOLE-0K1 or p =FINSEQ-1R1 {}XBOOLE-0K1 & q =FINSEQ-1R1 <*FINSEQ-1K10 x*>"
proof-
  have " for x be objectHIDDENM1 holds  for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds p ^FINSEQ-1K8 q =FINSEQ-1R1 <*FINSEQ-1K10 x*> implies  not ( not (p =FINSEQ-1R1 <*FINSEQ-1K10 x*> & q =FINSEQ-1R1 {}XBOOLE-0K1) &  not (p =FINSEQ-1R1 {}XBOOLE-0K1 & q =FINSEQ-1R1 <*FINSEQ-1K10 x*>))"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    assume A1: "p ^FINSEQ-1K8 q =FINSEQ-1R1 <*FINSEQ-1K10 x*>"
    then have A2: "\<one>\<^sub>M =HIDDENR1 lenFINSEQ-1K4 (p ^FINSEQ-1K8 q)"
      using finseq_1_th_40 sorry
    also have "... = lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q"
      using finseq_1_th_22 sorry
    finally have "\<one>\<^sub>M =HIDDENR1 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q"
       sorry
    have A3: "lenFINSEQ-1K4 p =XBOOLE-0R4 0NUMBERSK6 implies p =FINSEQ-1R1 {}XBOOLE-0K1 & q =FINSEQ-1R1 <*FINSEQ-1K10 x*>"
    proof(rule impI,rule conjMI)
      assume "lenFINSEQ-1K4 p =XBOOLE-0R4 0NUMBERSK6"
      thus "p =FINSEQ-1R1 {}XBOOLE-0K1"
         sorry
      thus "q =FINSEQ-1R1 <*FINSEQ-1K10 x*>"
        using A1 finseq_1_th_34 sorry
    qed
    have "lenFINSEQ-1K4 p <>HIDDENR2 0NUMBERSK6 implies q =FINSEQ-1R1 {}XBOOLE-0K1 & p =FINSEQ-1R1 <*FINSEQ-1K10 x*>"
    proof(rule impI,rule conjMI)
      assume "lenFINSEQ-1K4 p <>HIDDENR2 0NUMBERSK6"
      then have A4: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p"
        using nat_1_th_13 sorry
      have "lenFINSEQ-1K4 p <=XXREAL-0R1 \<one>\<^sub>M"
        using A2 nat_1_th_11 sorry
      then have "lenFINSEQ-1K4 p =XBOOLE-0R4 \<one>\<^sub>M"
        using A4 xxreal_0_th_1 sorry
      thus "q =FINSEQ-1R1 {}XBOOLE-0K1"
        using A2 sorry
      thus "p =FINSEQ-1R1 <*FINSEQ-1K10 x*>"
        using A1 finseq_1_th_34 sorry
    qed
    thus " not ( not (p =FINSEQ-1R1 <*FINSEQ-1K10 x*> & q =FINSEQ-1R1 {}XBOOLE-0K1) &  not (p =FINSEQ-1R1 {}XBOOLE-0K1 & q =FINSEQ-1R1 <*FINSEQ-1K10 x*>))"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_89:
" for n be NatNAT-1M1 holds  for f be n -elementCARD-1V3\<bar>FinSequenceFINSEQ-1M1 holds domFINSEQ-1K5 f =XBOOLE-0R4 SegFINSEQ-1K2 n"
proof-
  have " for n be NatNAT-1M1 holds  for f be n -elementCARD-1V3\<bar>FinSequenceFINSEQ-1M1 holds domFINSEQ-1K5 f =XBOOLE-0R4 SegFINSEQ-1K2 n"
  proof(rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix f assume [ty]: "f be n -elementCARD-1V3\<bar>FinSequenceFINSEQ-1M1"
    have "lenFINSEQ-1K4 f =XBOOLE-0R4 n"
      using card_1_def_7 sorry
    thus "domFINSEQ-1K5 f =XBOOLE-0R4 SegFINSEQ-1K2 n"
      using finseq_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_cl_46:
  mlet "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "m be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "f be n -elementCARD-1V3\<bar>FinSequenceFINSEQ-1M1", "g be m -elementCARD-1V3\<bar>FinSequenceFINSEQ-1M1"
"cluster f ^FINSEQ-1K8 g as-term-is n +XCMPLX-0K2 m -elementCARD-1V3"
proof
(*coherence*)
  show "f ^FINSEQ-1K8 g be n +XCMPLX-0K2 m -elementCARD-1V3"
  proof-
    have Cut3523: "lenFINSEQ-1K4 f =HIDDENR1 n & lenFINSEQ-1K4 g =HIDDENR1 m"
      using card_1_def_7 sorry
    have "lenFINSEQ-1K4 (f ^FINSEQ-1K8 g) =XBOOLE-0R4 n +XCMPLX-0K2 m"
    proof-
      show "lenFINSEQ-1K4 (f ^FINSEQ-1K8 g) =XBOOLE-0R4 n +XCMPLX-0K2 m"
        using finseq_1_th_22 Cut3523 sorry
    qed
    thus "f ^FINSEQ-1K8 g be n +XCMPLX-0K2 m -elementCARD-1V3"
      using card_1_def_0 sorry
  qed
qed "sorry"

mtheorem finseq_1_cl_47:
"cluster increasingVALUED-0V9 also-is one-to-oneFUNCT-1V2 for real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
proof
(*coherence*)
  show " for it be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds it be increasingVALUED-0V9 implies it be one-to-oneFUNCT-1V2"
  proof-
    have " for f be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds f be increasingVALUED-0V9 implies f be one-to-oneFUNCT-1V2"
    proof(rule ballI,rule impI)
      fix f assume [ty]: "f be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
      assume A1: "f be increasingVALUED-0V9"
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 domFINSEQ-1K5 f & y inHIDDENR3 domFINSEQ-1K5 f) & f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y implies x =HIDDENR1 y"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A2: "x inHIDDENR3 domFINSEQ-1K5 f & y inHIDDENR3 domFINSEQ-1K5 f"
          and A3: "f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y"
        obtain nx ny where 
          [ty]:"nx be ElementSUBSET-1M1-of NATNUMBERSK1" and nxDef:"nx = x" and
          [ty]:"ny be ElementSUBSET-1M1-of NATNUMBERSK1" and nyDef:"ny = y"
          using A2 sorry
        have "nx <=XXREAL-0R1 ny & nx >=XXREAL-0R2 ny"
          using A1 A2 A3 valued_0_def_13 sorry
        thus "x =HIDDENR1 y"
          using xxreal_0_th_1 sorry
      qed "sorry"
      thus "f be one-to-oneFUNCT-1V2"
        using funct_1_def_4 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finseq_1_th_90:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domFINSEQ-1K5 (<*FINSEQ-1K10 y*>) implies x =HIDDENR1 \<one>\<^sub>M"
proof(rule ballI,rule ballI,rule impI)
  fix x assume [ty]: "x be objectHIDDENM1"
  fix y assume [ty]: "y be objectHIDDENM1"
  assume "x inHIDDENR3 domFINSEQ-1K5 (<*FINSEQ-1K10 y*>)"
  then have "x inHIDDENR3 SegFINSEQ-1K2 \<one>\<^sub>M"
    using finseq_1_th_38 sorry
  thus "x =HIDDENR1 \<one>\<^sub>M"
    using finseq_1_th_2 tarski_def_1 sorry
qed "sorry"

mtheorem finseq_1_cl_48:
  mlet "X be setHIDDENM2"
"cluster X -valuedRELAT-1V5 for FinSequenceFINSEQ-1M1"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M1 st it be X -valuedRELAT-1V5"
  proof-
    have " ex tVar35 be FinSequenceFINSEQ-1M1 st tVar35 be X -valuedRELAT-1V5"
    proof-
      show " ex tVar35 be FinSequenceFINSEQ-1M1 st tVar35 be X -valuedRELAT-1V5"
      proof(rule bexI[of _ "<*>FINSEQ-1K7 X"])
        show "<*>FINSEQ-1K7 X be X -valuedRELAT-1V5"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finseq_1_cl_49:
  mlet "D be FinSequence-memberedFINSEQ-1V3\<bar>setHIDDENM2", "f be D -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1", "x be objectHIDDENM1"
"cluster f .FUNCT-1K1 x as-term-is FinSequence-likeFINSEQ-1V1"
proof
(*coherence*)
  show "f .FUNCT-1K1 x be FinSequence-likeFINSEQ-1V1"
  proof-
    show "f .FUNCT-1K1 x be FinSequence-likeFINSEQ-1V1"
    proof-
      have cases: "x inHIDDENR3 domRELAT-1K1 f or  not x inHIDDENR3 domRELAT-1K1 f"
         sorry
      have case1: "x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be FinSequence-likeFINSEQ-1V1"
      proof(rule impI)
        assume "x inHIDDENR3 domRELAT-1K1 f"
        then have A1: "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f"
          using funct_1_def_3 sorry
        have "rngFUNCT-1K2 f c=TARSKIR1 D"
          using relat_1_def_19 sorry
        thus "f .FUNCT-1K1 x be FinSequence-likeFINSEQ-1V1"
          using A1 sorry
      qed
      have case2: " not x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be FinSequence-likeFINSEQ-1V1"
      proof(rule impI)
        assume " not x inHIDDENR3 domRELAT-1K1 f"
        thus "f .FUNCT-1K1 x be FinSequence-likeFINSEQ-1V1"
          using funct_1_def_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
qed "sorry"

mtheorem finseq_1_th_91:
" for n be NatNAT-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 SegFINSEQ-1K2 n implies ( ex VarFor3 be setHIDDENM2 st (\<one>\<^sub>M <=XXREAL-0R1 VarFor3 & VarFor3 <=XXREAL-0R1 n) & x =HIDDENR1 VarFor3)"
  using finseq_1_lm_5 sorry

mtheorem finseq_1_th_92:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds domFINSEQ-1K5 (<*FINSEQ-1K11 x,y *>) =XBOOLE-0R4 {TARSKIK2 \<one>\<^sub>M,\<two>\<^sub>M }"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds domFINSEQ-1K5 (<*FINSEQ-1K11 x,y *>) =HIDDENR1 {TARSKIK2 \<one>\<^sub>M,\<two>\<^sub>M }"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    have "domFINSEQ-1K5 (<*FINSEQ-1K11 x,y *>) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 (<*FINSEQ-1K11 x,y *>))"
      using finseq_1_def_3 sorry
    also have "... = {TARSKIK2 \<one>\<^sub>M,\<two>\<^sub>M }"
      using finseq_1_th_2 finseq_1_th_44 sorry
    finally show "domFINSEQ-1K5 (<*FINSEQ-1K11 x,y *>) =HIDDENR1 {TARSKIK2 \<one>\<^sub>M,\<two>\<^sub>M }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem finseq_1_cl_50:
  mlet "A be finiteFINSET-1V1\<bar>setHIDDENM2"
"cluster ontoFUNCT-2V2\<^bsub>(A)\<^esub>\<bar>one-to-oneFUNCT-1V2 for FinSequenceFINSEQ-1M3-of A"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M3-of A st it be ontoFUNCT-2V2\<^bsub>(A)\<^esub>\<bar>one-to-oneFUNCT-1V2"
  proof-
    have " ex tVar36 be FinSequenceFINSEQ-1M3-of A st tVar36 be ontoFUNCT-2V2\<^bsub>(A)\<^esub> & tVar36 be one-to-oneFUNCT-1V2"
    proof-
      obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A1: "(A,SegFINSEQ-1K2 n)are-equipotentWELLORD2R2"
        using finseq_1_th_56 sorry
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A2: "f be one-to-oneFUNCT-1V2"and A3: "domRELAT-1K1 f =XBOOLE-0R4 SegFINSEQ-1K2 n"and A4: "rngFUNCT-1K2 f =XBOOLE-0R4 A"
        using A1 wellord2_def_4 sorry
      have "f be FinSequenceFINSEQ-1M1"
        using A3 finseq_1_def_2 sorry
      then have 
        [ty]:"f be FinSequenceFINSEQ-1M3-of A"
        using A4 finseq_1_def_4 sorry
      show " ex tVar36 be FinSequenceFINSEQ-1M3-of A st tVar36 be ontoFUNCT-2V2\<^bsub>(A)\<^esub> & tVar36 be one-to-oneFUNCT-1V2"
      proof(rule bexI[of _ "f"])
        show "f be ontoFUNCT-2V2\<^bsub>(A)\<^esub> & f be one-to-oneFUNCT-1V2"
          using A2 A4 funct_2_def_3 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef finseq_1_def_19 ("canFSFINSEQ-1K20  _ " [164]164 ) where
  mlet "A be finiteFINSET-1V1\<bar>setHIDDENM2"
"func canFSFINSEQ-1K20 A \<rightarrow> FinSequenceFINSEQ-1M1 equals
  the one-to-oneFUNCT-1V2\<bar>ontoFUNCT-2V2\<^bsub>(A)\<^esub>\<bar>FinSequenceFINSEQ-1M3-of A"
proof-
  (*coherence*)
    show "the one-to-oneFUNCT-1V2\<bar>ontoFUNCT-2V2\<^bsub>(A)\<^esub>\<bar>FinSequenceFINSEQ-1M3-of A be FinSequenceFINSEQ-1M1"
       sorry
qed "sorry"

abbreviation(input) FINSEQ_1K21("canFSFINSEQ-1K21  _ " [164]164) where
  "canFSFINSEQ-1K21 A \<equiv> canFSFINSEQ-1K20 A"

mtheorem finseq_1_add_9:
  mlet "A be finiteFINSET-1V1\<bar>setHIDDENM2"
"cluster canFSFINSEQ-1K20 A as-term-is FinSequenceFINSEQ-1M3-of A"
proof
(*coherence*)
  show "canFSFINSEQ-1K20 A be FinSequenceFINSEQ-1M3-of A"
     sorry
qed "sorry"

mtheorem finseq_1_cl_51:
  mlet "A be finiteFINSET-1V1\<bar>setHIDDENM2"
"cluster canFSFINSEQ-1K21 A as-term-is one-to-oneFUNCT-1V2\<bar>ontoFUNCT-2V2\<^bsub>(A)\<^esub> for FinSequenceFINSEQ-1M3-of A"
proof
(*coherence*)
  show " for it be FinSequenceFINSEQ-1M3-of A holds it =HIDDENR1 canFSFINSEQ-1K21 A implies it be one-to-oneFUNCT-1V2\<bar>ontoFUNCT-2V2\<^bsub>(A)\<^esub>"
     sorry
qed "sorry"

mtheorem finseq_1_th_93:
" for A be finiteFINSET-1V1\<bar>setHIDDENM2 holds lenFINSEQ-1K4 (canFSFINSEQ-1K21 A) =XBOOLE-0R4 cardCARD-1K4 A"
proof-
  have " for A be finiteFINSET-1V1\<bar>setHIDDENM2 holds cardCARD-1K4 (canFSFINSEQ-1K21 A) =HIDDENR1 cardCARD-1K4 A"
  proof(rule ballI)
    fix A assume [ty]: "A be finiteFINSET-1V1\<bar>setHIDDENM2"
    have "cardCARD-1K4 (canFSFINSEQ-1K21 A) =HIDDENR1 cardCARD-1K4 (domFINSEQ-1K5 (canFSFINSEQ-1K21 A))"
      using card_1_th_62 sorry
    also have "... = cardCARD-1K4 (rngFUNCT-1K2 (canFSFINSEQ-1K21 A))"
      using card_1_th_70 sorry
    also have "... = cardCARD-1K4 A"
      using funct_2_def_3 sorry
    finally show "cardCARD-1K4 (canFSFINSEQ-1K21 A) =HIDDENR1 cardCARD-1K4 A"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_cl_52:
  mlet "A be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster canFSFINSEQ-1K21 A as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "canFSFINSEQ-1K21 A be  non emptyXBOOLE-0V1"
  proof-
    have " not canFSFINSEQ-1K21 A be emptyXBOOLE-0V1"
    proof-
      have "lenFINSEQ-1K4 (canFSFINSEQ-1K21 A) =XBOOLE-0R4 cardCARD-1K4 A"
        using finseq_1_th_93 sorry
      thus " not canFSFINSEQ-1K21 A be emptyXBOOLE-0V1"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finseq_1_th_94:
" for a be objectHIDDENM1 holds canFSFINSEQ-1K21 {TARSKIK1 a} =FINSEQ-1R1 <*FINSEQ-1K10 a*>"
proof(rule ballI)
  fix a assume [ty]: "a be objectHIDDENM1"
  have A1: "rngFUNCT-1K2 (canFSFINSEQ-1K21 {TARSKIK1 a}) =XBOOLE-0R4 {TARSKIK1 a}"
    using funct_2_def_3 sorry
  have "lenFINSEQ-1K4 (canFSFINSEQ-1K21 {TARSKIK1 a}) =HIDDENR1 cardCARD-1K4 {TARSKIK1 a}"
    using finseq_1_th_93 sorry
  also have "... = \<one>\<^sub>M"
    using card_1_th_30 sorry
  finally have "lenFINSEQ-1K4 (canFSFINSEQ-1K21 {TARSKIK1 a}) =HIDDENR1 \<one>\<^sub>M"
     sorry
  thus "canFSFINSEQ-1K21 {TARSKIK1 a} =FINSEQ-1R1 <*FINSEQ-1K10 a*>"
    using A1 finseq_1_th_39 sorry
qed "sorry"

mtheorem finseq_1_th_95:
" for A be finiteFINSET-1V1\<bar>setHIDDENM2 holds (canFSFINSEQ-1K21 A)\<inverse>FUNCT-1K4 be FunctionFUNCT-2M1-of(A,SegFINSEQ-1K2 (cardCARD-1K4 A))"
proof(rule ballI)
  fix A assume [ty]: "A be finiteFINSET-1V1\<bar>setHIDDENM2"
  have "lenFINSEQ-1K4 (canFSFINSEQ-1K21 A) =XBOOLE-0R4 cardCARD-1K4 A"
    using finseq_1_th_93 sorry
  then have "domFINSEQ-1K5 (canFSFINSEQ-1K21 A) =XBOOLE-0R4 SegFINSEQ-1K2 (cardCARD-1K4 A)"
    using finseq_1_def_3 sorry
  then have A1: "rngFUNCT-1K2 ((canFSFINSEQ-1K21 A)\<inverse>FUNCT-1K4) =XBOOLE-0R4 SegFINSEQ-1K2 (cardCARD-1K4 A)"
    using funct_1_th_33 sorry
  have "rngFUNCT-1K2 (canFSFINSEQ-1K21 A) =XBOOLE-0R4 A"
    using funct_2_def_3 sorry
  then have "domRELAT-1K1 ((canFSFINSEQ-1K21 A)\<inverse>FUNCT-1K4) =XBOOLE-0R4 A"
    using funct_1_th_33 sorry
  thus "(canFSFINSEQ-1K21 A)\<inverse>FUNCT-1K4 be FunctionFUNCT-2M1-of(A,SegFINSEQ-1K2 (cardCARD-1K4 A))"
    using A1 funct_2_th_1 sorry
qed "sorry"

mtheorem finseq_1_th_96:
" for i be NatNAT-1M1 holds  for x be objectHIDDENM1 holds i >XXREAL-0R4 0NUMBERSK6 implies {TARSKIK1 [TARSKIK4 i,x ] } be FinSubsequenceFINSEQ-1M4"
proof-
  have " for i be NatNAT-1M1 holds  for x be objectHIDDENM1 holds i >XXREAL-0R4 0NUMBERSK6 implies {TARSKIK1 [TARSKIK4 i,x ] } be FinSubsequenceFINSEQ-1M4"
  proof(rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "i >XXREAL-0R4 0NUMBERSK6"
    have A2: "domRELAT-1K1 {TARSKIK1 [TARSKIK4 i,x ] } =XBOOLE-0R4 {TARSKIK1 i}"
      using relat_1_th_9 sorry
    have "{TARSKIK1 i} c=TARSKIR1 SegFINSEQ-1K2 i"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK1 i} implies x inHIDDENR3 SegFINSEQ-1K2 i"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 {TARSKIK1 i}"
        then have "x =HIDDENR1 i"
          using tarski_def_1 sorry
        thus "x inHIDDENR3 SegFINSEQ-1K2 i"
          using A1 finseq_1_th_3 sorry
      qed "sorry"
      thus "{TARSKIK1 i} c=TARSKIR1 SegFINSEQ-1K2 i"
        using tarski_def_3 sorry
    qed
    thus "{TARSKIK1 [TARSKIK4 i,x ] } be FinSubsequenceFINSEQ-1M4"
      using A2 finseq_1_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma finseq_1_lm_6:
" for p be FinSubsequenceFINSEQ-1M4 holds SeqFINSEQ-1K16 p =FINSEQ-1R1 {}XBOOLE-0K1 implies p =FUNCT-1R1 {}XBOOLE-0K1"
proof(rule ballI,rule impI)
  fix p assume [ty]: "p be FinSubsequenceFINSEQ-1M4"
  assume A1: "SeqFINSEQ-1K16 p =FINSEQ-1R1 {}XBOOLE-0K1"
  have "rngFUNCT-1K2 (SgmFINSEQ-1K15 (domRELAT-1K1 p)) =XBOOLE-0R4 domRELAT-1K1 p"
    using finseq_1_th_50 sorry
  then have "domFINSEQ-1K5 ({}XBOOLE-0K1) =XBOOLE-0R4 domFINSEQ-1K5 (SgmFINSEQ-1K15 (domRELAT-1K1 p))"
    using A1 relat_1_th_27 sorry
  then have "SgmFINSEQ-1K15 (domRELAT-1K1 p) =FINSEQ-1R1 {}XBOOLE-0K1"
     sorry
  then have "domRELAT-1K1 p =XBOOLE-0R4 rngFUNCT-1K2 ({}XBOOLE-0K1)"
    using finseq_1_th_50 sorry
  thus "p =FUNCT-1R1 {}XBOOLE-0K1"
     sorry
qed "sorry"

mtheorem finseq_1_th_97:
" for q be FinSubsequenceFINSEQ-1M4 holds q =FUNCT-1R1 {}XBOOLE-0K1 iff SeqFINSEQ-1K16 q =FINSEQ-1R1 {}XBOOLE-0K1"
  using finseq_1_lm_6 sorry

mtheorem finseq_1_cl_53:
"cluster note-that finiteFINSET-1V1 for FinSubsequenceFINSEQ-1M4"
proof
(*coherence*)
  show " for it be FinSubsequenceFINSEQ-1M4 holds it be finiteFINSET-1V1"
  proof-
    have " for q be FinSubsequenceFINSEQ-1M4 holds q be finiteFINSET-1V1"
    proof(rule ballI)
      fix q assume [ty]: "q be FinSubsequenceFINSEQ-1M4"
      have " ex n be NatNAT-1M1 st domRELAT-1K1 q c=TARSKIR1 SegFINSEQ-1K2 n"
        using finseq_1_def_12 sorry
      thus "q be finiteFINSET-1V1"
        using finset_1_th_10 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

reserve x1, x2, y1, y2 for "setHIDDENM2"
mtheorem finseq_1_th_98:
" for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for y1 be setHIDDENM2 holds  for y2 be setHIDDENM2 holds {TARSKIK2 [TARSKIK4 x1,y1 ],[TARSKIK4 x2,y2 ] } be FinSequenceFINSEQ-1M1 implies ((x1 =XBOOLE-0R4 \<one>\<^sub>M & x2 =XBOOLE-0R4 \<one>\<^sub>M) & y1 =XBOOLE-0R4 y2 or x1 =XBOOLE-0R4 \<one>\<^sub>M & x2 =XBOOLE-0R4 \<two>\<^sub>M) or x1 =XBOOLE-0R4 \<two>\<^sub>M & x2 =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for y1 be setHIDDENM2 holds  for y2 be setHIDDENM2 holds {TARSKIK2 [TARSKIK4 x1,y1 ],[TARSKIK4 x2,y2 ] } be FinSequenceFINSEQ-1M1 implies  not (( not ((x1 =XBOOLE-0R4 \<one>\<^sub>M & x2 =XBOOLE-0R4 \<one>\<^sub>M) & y1 =XBOOLE-0R4 y2) &  not (x1 =XBOOLE-0R4 \<one>\<^sub>M & x2 =XBOOLE-0R4 \<two>\<^sub>M)) &  not (x1 =XBOOLE-0R4 \<two>\<^sub>M & x2 =XBOOLE-0R4 \<one>\<^sub>M))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x1 assume [ty]: "x1 be setHIDDENM2"
    fix x2 assume [ty]: "x2 be setHIDDENM2"
    fix y1 assume [ty]: "y1 be setHIDDENM2"
    fix y2 assume [ty]: "y2 be setHIDDENM2"
    assume "{TARSKIK2 [TARSKIK4 x1,y1 ],[TARSKIK4 x2,y2 ] } be FinSequenceFINSEQ-1M1"
    then obtain p where 
      [ty]:"p be FinSequenceFINSEQ-1M1" and pDef:"p = {TARSKIK2 [TARSKIK4 x1,y1 ],[TARSKIK4 x2,y2 ] }"
       sorry
    have A1: "domFINSEQ-1K5 p =XBOOLE-0R4 {TARSKIK2 x1,x2 }"
      using relat_1_th_10 sorry
    then have A2: "x1 inTARSKIR2 domFINSEQ-1K5 p"
      using tarski_def_2 sorry
    have A3: "x2 inTARSKIR2 domFINSEQ-1K5 p"
      using A1 tarski_def_2 sorry
    have A4: "[TARSKIK4 x1,y1 ] inHIDDENR3 p"
      using tarski_def_2 sorry
    have A5: "[TARSKIK4 x2,y2 ] inHIDDENR3 p"
      using tarski_def_2 sorry
    have A6: "p .FUNCT-1K1 x1 =XBOOLE-0R4 y1"
      using A4 funct_1_th_1 sorry
    have A7: "p .FUNCT-1K1 x2 =XBOOLE-0R4 y2"
      using A5 funct_1_th_1 sorry
    have A8: "domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
      using finseq_1_def_3 sorry
    have A9: "lenFINSEQ-1K4 p <=XXREAL-0R1 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
      using card_2_th_50 sorry
    have A10: "lenFINSEQ-1K4 p >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_13 sorry
    have A11: "lenFINSEQ-1K4 p =XBOOLE-0R4 \<one>\<^sub>M implies (x1 =XBOOLE-0R4 \<one>\<^sub>M & x2 =XBOOLE-0R4 \<one>\<^sub>M) & y1 =XBOOLE-0R4 y2"
    proof(rule impI,rule conjMI)
      assume "lenFINSEQ-1K4 p =XBOOLE-0R4 \<one>\<^sub>M"
      thus "x1 =XBOOLE-0R4 \<one>\<^sub>M & x2 =XBOOLE-0R4 \<one>\<^sub>M"
        using A2 A3 A8 finseq_1_th_2 tarski_def_1 sorry
      thus "y1 =XBOOLE-0R4 y2"
        using A5 A6 funct_1_th_1 sorry
    qed
    have "lenFINSEQ-1K4 p =XBOOLE-0R4 \<two>\<^sub>M implies x1 =XBOOLE-0R4 \<one>\<^sub>M & x2 =XBOOLE-0R4 \<two>\<^sub>M or x1 =XBOOLE-0R4 \<two>\<^sub>M & x2 =XBOOLE-0R4 \<one>\<^sub>M"
    proof(rule impI)
      assume A12: "lenFINSEQ-1K4 p =XBOOLE-0R4 \<two>\<^sub>M"
      have A13: "x1 =XBOOLE-0R4 x2 implies p =FUNCT-1R1 {TARSKIK1 [TARSKIK4 x1,y1 ] }"
        using A6 A7 enumset1_th_29 sorry
      have "((x1 =XBOOLE-0R4 \<one>\<^sub>M & x2 =XBOOLE-0R4 \<two>\<^sub>M or x1 =XBOOLE-0R4 \<two>\<^sub>M & x2 =XBOOLE-0R4 \<one>\<^sub>M) or x1 =XBOOLE-0R4 \<one>\<^sub>M & x2 =XBOOLE-0R4 \<one>\<^sub>M) or x1 =XBOOLE-0R4 \<two>\<^sub>M & x2 =XBOOLE-0R4 \<two>\<^sub>M"
        using A2 A3 A8 A12 finseq_1_th_2 tarski_def_2 sorry
      thus "x1 =XBOOLE-0R4 \<one>\<^sub>M & x2 =XBOOLE-0R4 \<two>\<^sub>M or x1 =XBOOLE-0R4 \<two>\<^sub>M & x2 =XBOOLE-0R4 \<one>\<^sub>M"
        using A12 A13 card_1_th_30 sorry
    qed
    thus " not (( not ((x1 =XBOOLE-0R4 \<one>\<^sub>M & x2 =XBOOLE-0R4 \<one>\<^sub>M) & y1 =XBOOLE-0R4 y2) &  not (x1 =XBOOLE-0R4 \<one>\<^sub>M & x2 =XBOOLE-0R4 \<two>\<^sub>M)) &  not (x1 =XBOOLE-0R4 \<two>\<^sub>M & x2 =XBOOLE-0R4 \<one>\<^sub>M))"
      using A9 A10 A11 nat_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_99:
" for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds <*FINSEQ-1K11 x1,x2 *> =RELAT-1R1 {TARSKIK2 [TARSKIK4 \<one>\<^sub>M,x1 ],[TARSKIK4 \<two>\<^sub>M,x2 ] }"
proof-
  have " for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds <*FINSEQ-1K11 x1,x2 *> =RELAT-1R1 {TARSKIK2 [TARSKIK4 \<one>\<^sub>M,x1 ],[TARSKIK4 \<two>\<^sub>M,x2 ] }"
  proof(rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be setHIDDENM2"
    fix x2 assume [ty]: "x2 be setHIDDENM2"
    obtain f where 
      [ty]:"f be FunctionFUNCT-1M1" and fDef:"f = {TARSKIK2 [TARSKIK4 \<one>\<^sub>M,x1 ],[TARSKIK4 \<two>\<^sub>M,x2 ] }"
      using grfunc_1_th_8 sorry
    have A1: "domRELAT-1K1 f =XBOOLE-0R4 {TARSKIK2 \<one>\<^sub>M,\<two>\<^sub>M }"
      using relat_1_th_10 sorry
    then have A2: "domFINSEQ-1K5 (<*FINSEQ-1K11 x1,x2 *>) =XBOOLE-0R4 domRELAT-1K1 f"
      using finseq_1_th_2 finseq_1_th_89 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK2 \<one>\<^sub>M,\<two>\<^sub>M } implies f .FUNCT-1K1 x =XBOOLE-0R4 (<*FINSEQ-1K11 x1,x2 *>).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A3: "x inHIDDENR3 {TARSKIK2 \<one>\<^sub>M,\<two>\<^sub>M }"
      show "f .FUNCT-1K1 x =XBOOLE-0R4 (<*FINSEQ-1K11 x1,x2 *>).FUNCT-1K1 x"
      proof-
        have cases: "x =HIDDENR1 \<one>\<^sub>M or x =HIDDENR1 \<two>\<^sub>M"
          using A3 tarski_def_2 sorry
        have case1: "x =HIDDENR1 \<one>\<^sub>M implies f .FUNCT-1K1 x =XBOOLE-0R4 (<*FINSEQ-1K11 x1,x2 *>).FUNCT-1K1 x"
        proof(rule impI)
          assume A4: "x =HIDDENR1 \<one>\<^sub>M"
          then have A5: "(<*FINSEQ-1K11 x1,x2 *>).FUNCT-1K1 x =XBOOLE-0R4 x1"
            using finseq_1_th_44 sorry
          have "[TARSKIK4 x,x1 ] inHIDDENR3 f"
            using A4 tarski_def_2 sorry
          thus "f .FUNCT-1K1 x =XBOOLE-0R4 (<*FINSEQ-1K11 x1,x2 *>).FUNCT-1K1 x"
            using A5 funct_1_th_1 sorry
        qed
        have case2: "x =HIDDENR1 \<two>\<^sub>M implies f .FUNCT-1K1 x =XBOOLE-0R4 (<*FINSEQ-1K11 x1,x2 *>).FUNCT-1K1 x"
        proof(rule impI)
          assume A6: "x =HIDDENR1 \<two>\<^sub>M"
          then have A7: "(<*FINSEQ-1K11 x1,x2 *>).FUNCT-1K1 x =XBOOLE-0R4 x2"
            using finseq_1_th_44 sorry
          have "[TARSKIK4 x,x2 ] inHIDDENR3 f"
            using A6 tarski_def_2 sorry
          thus "f .FUNCT-1K1 x =XBOOLE-0R4 (<*FINSEQ-1K11 x1,x2 *>).FUNCT-1K1 x"
            using A7 funct_1_th_1 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus "<*FINSEQ-1K11 x1,x2 *> =RELAT-1R1 {TARSKIK2 [TARSKIK4 \<one>\<^sub>M,x1 ],[TARSKIK4 \<two>\<^sub>M,x2 ] }"
      using A1 A2 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_1_th_100:
" for q be FinSubsequenceFINSEQ-1M4 holds domFINSEQ-1K5 (SeqFINSEQ-1K16 q) =XBOOLE-0R4 domFINSEQ-1K5 (SgmFINSEQ-1K15 (domRELAT-1K1 q))"
proof(rule ballI)
  fix q assume [ty]: "q be FinSubsequenceFINSEQ-1M4"
  have "rngFUNCT-1K2 (SgmFINSEQ-1K15 (domRELAT-1K1 q)) =XBOOLE-0R4 domRELAT-1K1 q"
    using finseq_1_th_50 sorry
  thus "domFINSEQ-1K5 (SeqFINSEQ-1K16 q) =XBOOLE-0R4 domFINSEQ-1K5 (SgmFINSEQ-1K15 (domRELAT-1K1 q))"
    using relat_1_th_27 sorry
qed "sorry"

mtheorem finseq_1_th_101:
" for q be FinSubsequenceFINSEQ-1M4 holds rngFUNCT-1K2 q =XBOOLE-0R4 rngFUNCT-1K2 (SeqFINSEQ-1K16 q)"
proof(rule ballI)
  fix q assume [ty]: "q be FinSubsequenceFINSEQ-1M4"
  have "domRELAT-1K1 q =XBOOLE-0R4 rngFUNCT-1K2 (SgmFINSEQ-1K15 (domRELAT-1K1 q))"
    using finseq_1_th_50 sorry
  thus "rngFUNCT-1K2 q =XBOOLE-0R4 rngFUNCT-1K2 (SeqFINSEQ-1K16 q)"
    using relat_1_th_28 sorry
qed "sorry"

mtheorem finseq_1_cl_54:
"cluster one-to-oneFUNCT-1V2 for FinSequenceFINSEQ-1M1"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M1 st it be one-to-oneFUNCT-1V2"
  proof-
    have " ex tVar37 be FinSequenceFINSEQ-1M1 st tVar37 be one-to-oneFUNCT-1V2"
    proof-
      show " ex tVar37 be FinSequenceFINSEQ-1M1 st tVar37 be one-to-oneFUNCT-1V2"
      proof(rule bexI[of _ "{}XBOOLE-0K1"])
        show "{}XBOOLE-0K1 be one-to-oneFUNCT-1V2"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finseq_1_cl_55:
  mlet "D be setHIDDENM2"
"cluster one-to-oneFUNCT-1V2 for FinSequenceFINSEQ-1M3-of D"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M3-of D st it be one-to-oneFUNCT-1V2"
  proof-
    have " ex tVar38 be FinSequenceFINSEQ-1M3-of D st tVar38 be one-to-oneFUNCT-1V2"
    proof-
      show " ex tVar38 be FinSequenceFINSEQ-1M3-of D st tVar38 be one-to-oneFUNCT-1V2"
      proof(rule bexI[of _ "<*>FINSEQ-1K7 D"])
        show "<*>FINSEQ-1K7 D be one-to-oneFUNCT-1V2"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

end
