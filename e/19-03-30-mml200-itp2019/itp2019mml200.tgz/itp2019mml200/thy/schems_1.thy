theory schems_1
  imports "../mizar_extension/E_fraenkel"
begin
(*begin*)
reserve a, b, d for "setHIDDENM2"
theorem schems_1_sch_1:
  fixes Pp1 
  assumes
    A1: " for a be setHIDDENM2 holds Pp1(a)"
  shows " ex a be setHIDDENM2 st Pp1(a)"
  proof-
    have " not ( for a be setHIDDENM2 holds  not Pp1(a))"
    proof-
      let ?a = "the setHIDDENM2"
      have "Pp1(?a)"
        using A1 sorry
      thus " not ( for a be setHIDDENM2 holds  not Pp1(a))"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem schems_1_sch_2:
  fixes Sp2 
  assumes
    A1: " ex a be setHIDDENM2 st  for b be setHIDDENM2 holds Sp2(a,b)"
  shows " for b be setHIDDENM2 holds  ex a be setHIDDENM2 st Sp2(a,b)"
  proof-
    have " for b be setHIDDENM2 holds  not ( for a be setHIDDENM2 holds  not Sp2(a,b))"
    proof-
      show " for b be setHIDDENM2 holds  not ( for a be setHIDDENM2 holds  not Sp2(a,b))"
        using A1 sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem schems_1_sch_3:
  fixes Pp1 Qp1 
  assumes
    A1: " for a be setHIDDENM2 holds Pp1(a) implies Qp1(a)"
  shows "( for a be setHIDDENM2 holds Pp1(a)) implies ( for a be setHIDDENM2 holds Qp1(a))"
  proof-
    have " not (( for a be setHIDDENM2 holds Pp1(a)) &  not ( for a be setHIDDENM2 holds Qp1(a)))"
    proof-
      show " not (( for a be setHIDDENM2 holds Pp1(a)) &  not ( for a be setHIDDENM2 holds Qp1(a)))"
        using A1 sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem schems_1_sch_4:
  fixes Pp1 Qp1 
  assumes
    A1: " for a be setHIDDENM2 holds Pp1(a) iff Qp1(a)"
  shows "( for a be setHIDDENM2 holds Pp1(a)) iff ( for a be setHIDDENM2 holds Qp1(a))"
  proof-
    have "(( for a be setHIDDENM2 holds Pp1(a)) implies ( for a be setHIDDENM2 holds Qp1(a))) & (( for a be setHIDDENM2 holds Qp1(a)) implies ( for a be setHIDDENM2 holds Pp1(a)))"
    proof(rule conjMI,rule impI)
      show "( for a be setHIDDENM2 holds Pp1(a)) implies ( for a be setHIDDENM2 holds Qp1(a))"
        using A1 sorry
      assume A2: " for a be setHIDDENM2 holds Qp1(a)"
      have " for a be setHIDDENM2 holds Pp1(a)"
        using A1 A2 sorry
      thus " for a be setHIDDENM2 holds Pp1(a)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem schems_1_sch_5:
  fixes Pp1 Tp0 
  assumes
    A1: " for a be setHIDDENM2 holds Pp1(a) implies Tp0"
  shows "( for a be setHIDDENM2 holds Pp1(a)) implies Tp0"
  proof(rule impI)
    assume A2: " for a be setHIDDENM2 holds Pp1(a)"
    have " for a be setHIDDENM2 holds Tp0"
    proof(rule ballI)
      fix a assume [ty]: "a be setHIDDENM2"
      have "Pp1(a)"
        using A2 sorry
      thus "Tp0"
        using A1 sorry
    qed "sorry"
    thus "Tp0"
       sorry
  qed

theorem schems_1_sch_6:
  fixes Pp1 Qp1 
  assumes
    A1: "( ex a be setHIDDENM2 st Pp1(a)) or ( for b be setHIDDENM2 holds Qp1(b))"
  shows " ex a be setHIDDENM2 st  for b be setHIDDENM2 holds Pp1(a) or Qp1(b)"
  proof-
    have " not ( for a be setHIDDENM2 holds  not ( for b be setHIDDENM2 holds  not ( not Pp1(a) &  not Qp1(b))))"
    proof-
      have " not ( for a be setHIDDENM2 holds  not ( for b be setHIDDENM2 holds  not ( not Pp1(a) &  not Qp1(b))))"
      proof-
        have A2: "( for b be setHIDDENM2 holds Qp1(b)) implies  not ( for a be setHIDDENM2 holds  not ( for b be setHIDDENM2 holds  not ( not Pp1(a) &  not Qp1(b))))"
        proof(rule impI)
          let ?a = "the setHIDDENM2"
          assume " for b be setHIDDENM2 holds Qp1(b)"
          then have " for b be setHIDDENM2 holds Pp1(?a) or Qp1(b)"
             sorry
          thus " not ( for a be setHIDDENM2 holds  not ( for b be setHIDDENM2 holds  not ( not Pp1(a) &  not Qp1(b))))"
             sorry
        qed
        have "( ex a be setHIDDENM2 st Pp1(a)) implies  not ( for a be setHIDDENM2 holds  not ( for b be setHIDDENM2 holds  not ( not Pp1(a) &  not Qp1(b))))"
        proof(rule impI)
          assume Given: " ex a be setHIDDENM2 st Pp1(a)"
          then obtain a where
            [ty]:"a be setHIDDENM2" and 
            A3: "Pp1(a)"
             sorry
          have " for b be setHIDDENM2 holds Pp1(a) or Qp1(b)"
            using A3 sorry
          thus " not ( for a be setHIDDENM2 holds  not ( for b be setHIDDENM2 holds  not ( not Pp1(a) &  not Qp1(b))))"
             sorry
        qed
        thus " not ( for a be setHIDDENM2 holds  not ( for b be setHIDDENM2 holds  not ( not Pp1(a) &  not Qp1(b))))"
          using A1 A2 sorry
      qed
      thus " not ( for a be setHIDDENM2 holds  not ( for b be setHIDDENM2 holds  not ( not Pp1(a) &  not Qp1(b))))"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem schems_1_sch_7:
  fixes Pp1 Qp1 
  assumes
    A1: " ex a be setHIDDENM2 st  for b be setHIDDENM2 holds Pp1(a) or Qp1(b)"
  shows "( ex a be setHIDDENM2 st Pp1(a)) or ( for b be setHIDDENM2 holds Qp1(b))"
  proof-
    have " not (( for a be setHIDDENM2 holds  not Pp1(a)) &  not ( for b be setHIDDENM2 holds Qp1(b)))"
    proof-
      show " not (( for a be setHIDDENM2 holds  not Pp1(a)) &  not ( for b be setHIDDENM2 holds Qp1(b)))"
        using A1 sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem schems_1_sch_8:
  fixes Pp1 Qp1 
  assumes
    A1: " for b be setHIDDENM2 holds  ex a be setHIDDENM2 st Pp1(a) or Qp1(b)"
  shows " ex a be setHIDDENM2 st  for b be setHIDDENM2 holds Pp1(a) or Qp1(b)"
  proof-
    have " not ( for a be setHIDDENM2 holds  not ( for b be setHIDDENM2 holds  not ( not Pp1(a) &  not Qp1(b))))"
    proof-
      have A2: "( ex a be setHIDDENM2 st Pp1(a)) or ( for b be setHIDDENM2 holds Qp1(b))"
        using A1 sorry
      have " ex a be setHIDDENM2 st  for b be setHIDDENM2 holds Pp1(a) or Qp1(b)"
        using schems_1_sch_6 A2 sorry
      thus " not ( for a be setHIDDENM2 holds  not ( for b be setHIDDENM2 holds  not ( not Pp1(a) &  not Qp1(b))))"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem schems_1_sch_9:
  fixes Pp1 Qp1 
  assumes
    A1: "( ex a be setHIDDENM2 st Pp1(a)) & ( for b be setHIDDENM2 holds Qp1(b))"
  shows " for b be setHIDDENM2 holds  ex a be setHIDDENM2 st Pp1(a) & Qp1(b)"
  proof-
    have " for b be setHIDDENM2 holds  not ( for a be setHIDDENM2 holds  not (Pp1(a) & Qp1(b)))"
    proof-
      show " for b be setHIDDENM2 holds  not ( for a be setHIDDENM2 holds  not (Pp1(a) & Qp1(b)))"
        using A1 sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem schems_1_sch_10:
  fixes Pp1 Qp1 
  assumes
    A1: " for b be setHIDDENM2 holds  ex a be setHIDDENM2 st Pp1(a) & Qp1(b)"
  shows "( ex a be setHIDDENM2 st Pp1(a)) & ( for b be setHIDDENM2 holds Qp1(b))"
  proof-
    have "( for a be setHIDDENM2 holds  not Pp1(a)) or ( ex b be setHIDDENM2 st  not Qp1(b)) implies  not  True "
    proof(rule impI)
      assume A2: "( for a be setHIDDENM2 holds  not Pp1(a)) or ( ex b be setHIDDENM2 st  not Qp1(b))"
      show " not  True "
      proof-
        have cases: "( ex b be setHIDDENM2 st  not Qp1(b)) or ( for a be setHIDDENM2 holds  not Pp1(a))"
          using A2 sorry
        have case1: "( ex b be setHIDDENM2 st  not Qp1(b)) implies  not  True "
        proof(rule impI)
          assume " ex b be setHIDDENM2 st  not Qp1(b)"
          then obtain b where
            [ty]:"b be setHIDDENM2" and 
            A3: " not Qp1(b)"
             sorry
          have " for d be setHIDDENM2 holds d =HIDDENR1 b implies  False "
          proof(rule ballI,rule impI)
            fix d assume [ty]: "d be setHIDDENM2"
            assume "d =HIDDENR1 b"
            have " ex a be setHIDDENM2 st Pp1(a) & Qp1(b)"
              using A1 sorry
            thus " False "
              using A3 sorry
          qed "sorry"
          thus " not  True "
             sorry
        qed
        have case2: "( for a be setHIDDENM2 holds  not Pp1(a)) implies  not  True "
        proof(rule impI)
          assume A4: " for a be setHIDDENM2 holds  not Pp1(a)"
          have " for b be setHIDDENM2 holds  not  True "
          proof(rule ballI)
            fix b assume [ty]: "b be setHIDDENM2"
            have " ex a be setHIDDENM2 st Pp1(a) & Qp1(b)"
              using A1 sorry
            thus " not  True "
              using A4 sorry
          qed "sorry"
          thus " not  True "
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed

theorem schems_1_sch_11:
  fixes Pp1 Qp1 
  assumes
    A1: " for b be setHIDDENM2 holds  ex a be setHIDDENM2 st Pp1(a) & Qp1(b)"
  shows " ex a be setHIDDENM2 st  for b be setHIDDENM2 holds Pp1(a) & Qp1(b)"
  proof-
    have " not ( for a be setHIDDENM2 holds  not ( for b be setHIDDENM2 holds Pp1(a) & Qp1(b)))"
    proof-
      have A2: " for b be setHIDDENM2 holds  ex a be setHIDDENM2 st Pp1(a) & Qp1(b)"
        using A1 sorry
      have "( ex a be setHIDDENM2 st Pp1(a)) & ( for b be setHIDDENM2 holds Qp1(b))"
        using schems_1_sch_10 A2 sorry
      thus " not ( for a be setHIDDENM2 holds  not ( for b be setHIDDENM2 holds Pp1(a) & Qp1(b)))"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem schems_1_sch_12:
  fixes Sp2 
  assumes
    A1: " for a be setHIDDENM2 holds  for b be setHIDDENM2 holds Sp2(a,b)"
  shows " ex b be setHIDDENM2 st  for a be setHIDDENM2 holds Sp2(a,b)"
  proof-
    have " not ( for b be setHIDDENM2 holds  not ( for a be setHIDDENM2 holds Sp2(a,b)))"
    proof-
      have " for b be setHIDDENM2 holds  not ( for b be setHIDDENM2 holds  not ( for a be setHIDDENM2 holds Sp2(a,b)))"
      proof(rule ballI)
        fix b assume [ty]: "b be setHIDDENM2"
        have " for a be setHIDDENM2 holds Sp2(a,b)"
          using A1 sorry
        thus " not ( for b be setHIDDENM2 holds  not ( for a be setHIDDENM2 holds Sp2(a,b)))"
           sorry
      qed "sorry"
      thus " not ( for b be setHIDDENM2 holds  not ( for a be setHIDDENM2 holds Sp2(a,b)))"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem schems_1_sch_13:
  fixes Sp2 
  assumes
    A1: " ex a be setHIDDENM2 st  for b be setHIDDENM2 holds Sp2(a,b)"
  shows " ex a be setHIDDENM2 st Sp2(a,a)"
  proof-
    have " not ( for a be setHIDDENM2 holds  not Sp2(a,a))"
    proof-
      show " not ( for a be setHIDDENM2 holds  not Sp2(a,a))"
        using A1 sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem schems_1_sch_14:
  fixes Sp2 
  assumes
    A1: " for a be setHIDDENM2 holds Sp2(a,a)"
  shows " for a be setHIDDENM2 holds  ex b be setHIDDENM2 st Sp2(b,a)"
  proof-
    have " for a be setHIDDENM2 holds  not ( for b be setHIDDENM2 holds  not Sp2(b,a))"
    proof-
      show " for a be setHIDDENM2 holds  not ( for b be setHIDDENM2 holds  not Sp2(b,a))"
        using A1 sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem schems_1_sch_15:
  fixes Sp2 
  assumes
    A1: " for a be setHIDDENM2 holds Sp2(a,a)"
  shows " for a be setHIDDENM2 holds  ex b be setHIDDENM2 st Sp2(a,b)"
  proof-
    have " for a be setHIDDENM2 holds  not ( for b be setHIDDENM2 holds  not Sp2(a,b))"
    proof-
      show " for a be setHIDDENM2 holds  not ( for b be setHIDDENM2 holds  not Sp2(a,b))"
        using A1 sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem schems_1_sch_16:
  fixes Sp2 
  assumes
    A1: " for b be setHIDDENM2 holds  ex a be setHIDDENM2 st Sp2(a,b)"
  shows " ex a be setHIDDENM2 st  ex b be setHIDDENM2 st Sp2(a,b)"
  proof-
    have " not ( for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  not Sp2(a,b))"
    proof-
      let ?b = "the setHIDDENM2"
      have " ex a be setHIDDENM2 st Sp2(a,?b)"
        using A1 sorry
      thus " not ( for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  not Sp2(a,b))"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed

end
