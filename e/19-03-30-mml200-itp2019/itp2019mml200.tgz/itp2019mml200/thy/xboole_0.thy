theory xboole_0
  imports "../mizar_extension/E_fraenkel"
begin
(*begin*)
reserve X, Y, Z for "setHIDDENM2"
reserve x, y, z for "objectHIDDENM1"
theorem xboole_0_sch_1:
  fixes Af0 Pp1 
  assumes
[ty]: "Af0 be setHIDDENM2"
  shows " ex X be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 X iff x inHIDDENR3 Af0 & Pp1(x)"
  proof-
    have " ex tVar1 be setHIDDENM2 st  for x be objectHIDDENM1 holds (x inHIDDENR3 tVar1 implies x inHIDDENR3 Af0 & Pp1(x)) & (x inHIDDENR3 Af0 & Pp1(x) implies x inHIDDENR3 tVar1)"
    proof-
      let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb1 =HIDDENR1 Lamb2 & Pp1(Lamb2)"
      have A1: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds ?Q(x,y) & ?Q(x,z) implies y =HIDDENR1 z"
         sorry
      obtain X where
        [ty]:"X be setHIDDENM2" and 
        A2: " for x be objectHIDDENM1 holds x inHIDDENR3 X iff ( ex y be objectHIDDENM1 st y inHIDDENR3 Af0 & ?Q(y,x))"
        using tarski_sch_1 A1 sorry
      show " ex tVar1 be setHIDDENM2 st  for x be objectHIDDENM1 holds (x inHIDDENR3 tVar1 implies x inHIDDENR3 Af0 & Pp1(x)) & (x inHIDDENR3 Af0 & Pp1(x) implies x inHIDDENR3 tVar1)"
      proof(rule bexI[of _ "X"],rule ballI,rule conjMI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        show "x inHIDDENR3 X implies x inHIDDENR3 Af0 & Pp1(x)"
        proof(rule impI)
          assume "x inHIDDENR3 X"
          then have " ex y be objectHIDDENM1 st y inHIDDENR3 Af0 & ?Q(y,x)"
            using A2 sorry
          thus "x inHIDDENR3 Af0 & Pp1(x)"
             sorry
        qed
        assume "x inHIDDENR3 Af0 & Pp1(x)"
        then have " ex y be objectHIDDENM1 st y inHIDDENR3 Af0 & ?Q(y,x)"
           sorry
        thus "x inHIDDENR3 X"
          using A2 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mdef xboole_0_def_1 ("emptyXBOOLE-0V1" 70 ) where
"attr emptyXBOOLE-0V1 for setHIDDENM2 means
  (\<lambda>X.  not ( ex x be objectHIDDENM1 st x inHIDDENR3 X))"..

mtheorem xboole_0_cl_1:
"cluster emptyXBOOLE-0V1 for setHIDDENM2"
proof
(*existence*)
  show " ex it be setHIDDENM2 st it be emptyXBOOLE-0V1"
  proof-
    have " ex tVar2 be setHIDDENM2 st tVar2 be emptyXBOOLE-0V1"
    proof-
      let ?P = "\<lambda>Lamb1.  False "
      obtain Y where
        [ty]:"Y be setHIDDENM2" and 
        A1: " for x be objectHIDDENM1 holds x inHIDDENR3 Y iff x inHIDDENR3 the setHIDDENM2 & ?P(x)"
        using xboole_0_sch_1 sorry
      show " ex tVar2 be setHIDDENM2 st tVar2 be emptyXBOOLE-0V1"
      proof(rule bexI[of _ "Y"])
        have " not ( ex x be objectHIDDENM1 st x inHIDDENR3 Y)"
        proof-
          show " not ( ex x be objectHIDDENM1 st x inHIDDENR3 Y)"
            using A1 sorry
        qed
        thus "Y be emptyXBOOLE-0V1"
          using xboole_0_def_1 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef xboole_0_def_2 ("{}XBOOLE-0K1" 228 ) where
"func {}XBOOLE-0K1 \<rightarrow> setHIDDENM2 equals
  the emptyXBOOLE-0V1\<bar>setHIDDENM2"
proof-
  (*coherence*)
    show "the emptyXBOOLE-0V1\<bar>setHIDDENM2 be setHIDDENM2"
       sorry
qed "sorry"

mdef xboole_0_def_3 (" _ '\\'/XBOOLE-0K2  _ " [132,132]132 ) where
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"func X \\/XBOOLE-0K2 Y \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff x inHIDDENR3 X or x inHIDDENR3 Y"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff x inHIDDENR3 X or x inHIDDENR3 Y"
    proof-
      have " ex tVar3 be setHIDDENM2 st  for x be objectHIDDENM1 holds (x inHIDDENR3 tVar3 implies x inHIDDENR3 X or x inHIDDENR3 Y) &  not ( not ( not x inHIDDENR3 X &  not x inHIDDENR3 Y) &  not x inHIDDENR3 tVar3)"
      proof-
        show " ex tVar3 be setHIDDENM2 st  for x be objectHIDDENM1 holds (x inHIDDENR3 tVar3 implies x inHIDDENR3 X or x inHIDDENR3 Y) &  not ( not ( not x inHIDDENR3 X &  not x inHIDDENR3 Y) &  not x inHIDDENR3 tVar3)"
        proof(rule bexI[of _ "unionTARSKIK3 {TARSKIK2 X,Y }"],rule ballI,rule conjMI)
          fix x assume [ty]: "x be objectHIDDENM1"
          show "x inHIDDENR3 unionTARSKIK3 {TARSKIK2 X,Y } implies x inHIDDENR3 X or x inHIDDENR3 Y"
          proof-
            have "x inHIDDENR3 unionTARSKIK3 {TARSKIK2 X,Y } implies  not ( not x inHIDDENR3 X &  not x inHIDDENR3 Y)"
            proof(rule impI)
              assume "x inHIDDENR3 unionTARSKIK3 {TARSKIK2 X,Y }"
              then have " ex Z be setHIDDENM2 st x inHIDDENR3 Z & Z inTARSKIR2 {TARSKIK2 X,Y }"
                using tarski_def_4 sorry
              thus " not ( not x inHIDDENR3 X &  not x inHIDDENR3 Y)"
                using tarski_def_2 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          have "X inTARSKIR2 {TARSKIK2 X,Y } & Y inTARSKIR2 {TARSKIK2 X,Y }"
            using tarski_def_2 sorry
          thus " not ( not ( not x inHIDDENR3 X &  not x inHIDDENR3 Y) &  not x inHIDDENR3 unionTARSKIK3 {TARSKIK2 X,Y })"
            using tarski_def_4 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff x inHIDDENR3 X or x inHIDDENR3 Y) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff x inHIDDENR3 X or x inHIDDENR3 Y) implies it1 =HIDDENR1 it2"
    proof-
      have " for A1 be setHIDDENM2 holds  for A2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 A1 iff x inHIDDENR3 X or x inHIDDENR3 Y) & ( for x be objectHIDDENM1 holds x inHIDDENR3 A2 iff x inHIDDENR3 X or x inHIDDENR3 Y) implies A1 =HIDDENR1 A2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix A1 assume [ty]: "A1 be setHIDDENM2"
        fix A2 assume [ty]: "A2 be setHIDDENM2"
        assume A1: " for x be objectHIDDENM1 holds x inHIDDENR3 A1 iff x inHIDDENR3 X or x inHIDDENR3 Y"
          and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 A2 iff x inHIDDENR3 X or x inHIDDENR3 Y"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 A1 iff x inHIDDENR3 A2"
        proof(rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          have "x inHIDDENR3 A1 iff x inHIDDENR3 X or x inHIDDENR3 Y"
            using A1 sorry
          thus "x inHIDDENR3 A1 iff x inHIDDENR3 A2"
            using A2 sorry
        qed "sorry"
        thus "A1 =HIDDENR1 A2"
          using tarski_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem XBOOLE_0K2_commutativity:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\/XBOOLE-0K2 Y =HIDDENR1 Y \\/XBOOLE-0K2 X"
proof-
  have " for it be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds it =HIDDENR1 X \\/XBOOLE-0K2 Y implies it =HIDDENR1 Y \\/XBOOLE-0K2 X"
  proof-
    have " for it be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it iff x inHIDDENR3 X or x inHIDDENR3 Y) implies ( for x be objectHIDDENM1 holds x inHIDDENR3 it iff x inHIDDENR3 Y or x inHIDDENR3 X)"
       sorry
    thus " ?thesis "
      using xboole_0_def_3 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem XBOOLE_0K2_idempotence:
" for Y be setHIDDENM2 holds Y =HIDDENR1 Y \\/XBOOLE-0K2 Y"
proof-
  have " for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds x inHIDDENR3 Y iff x inHIDDENR3 Y or x inHIDDENR3 Y"
     sorry
  thus " ?thesis "
    using xboole_0_def_3 sorry
qed

mdef xboole_0_def_4 (" _ '/'\\XBOOLE-0K3  _ " [164,164]164 ) where
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"func X /\\XBOOLE-0K3 Y \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff x inHIDDENR3 X & x inHIDDENR3 Y"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff x inHIDDENR3 X & x inHIDDENR3 Y"
    proof-
      have " ex Z be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 Z iff x inHIDDENR3 X & x inHIDDENR3 Y"
      proof-
        let ?P = "\<lambda>Lamb1. Lamb1 inHIDDENR3 Y"
        show " ex Z be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 Z iff x inHIDDENR3 X & x inHIDDENR3 Y"
          using xboole_0_sch_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff x inHIDDENR3 X & x inHIDDENR3 Y) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff x inHIDDENR3 X & x inHIDDENR3 Y) implies it1 =HIDDENR1 it2"
    proof-
      have " for A1 be setHIDDENM2 holds  for A2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 A1 iff x inHIDDENR3 X & x inHIDDENR3 Y) & ( for x be objectHIDDENM1 holds x inHIDDENR3 A2 iff x inHIDDENR3 X & x inHIDDENR3 Y) implies A1 =HIDDENR1 A2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix A1 assume [ty]: "A1 be setHIDDENM2"
        fix A2 assume [ty]: "A2 be setHIDDENM2"
        assume A3: " for x be objectHIDDENM1 holds x inHIDDENR3 A1 iff x inHIDDENR3 X & x inHIDDENR3 Y"
          and A4: " for x be objectHIDDENM1 holds x inHIDDENR3 A2 iff x inHIDDENR3 X & x inHIDDENR3 Y"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 A1 iff x inHIDDENR3 A2"
        proof(rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          have "x inHIDDENR3 A1 iff x inHIDDENR3 X & x inHIDDENR3 Y"
            using A3 sorry
          thus "x inHIDDENR3 A1 iff x inHIDDENR3 A2"
            using A4 sorry
        qed "sorry"
        thus "A1 =HIDDENR1 A2"
          using tarski_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem XBOOLE_0K3_commutativity:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X /\\XBOOLE-0K3 Y =HIDDENR1 Y /\\XBOOLE-0K3 X"
proof-
  have " for it be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds it =HIDDENR1 X /\\XBOOLE-0K3 Y implies it =HIDDENR1 Y /\\XBOOLE-0K3 X"
  proof-
    have " for it be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it iff x inHIDDENR3 X & x inHIDDENR3 Y) implies ( for x be objectHIDDENM1 holds x inHIDDENR3 it iff x inHIDDENR3 Y & x inHIDDENR3 X)"
       sorry
    thus " ?thesis "
      using xboole_0_def_4 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem XBOOLE_0K3_idempotence:
" for Y be setHIDDENM2 holds Y =HIDDENR1 Y /\\XBOOLE-0K3 Y"
proof-
  have " for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds x inHIDDENR3 Y iff x inHIDDENR3 Y & x inHIDDENR3 Y"
     sorry
  thus " ?thesis "
    using xboole_0_def_4 sorry
qed

mdef xboole_0_def_5 (" _ '\\XBOOLE-0K4  _ " [132,132]132 ) where
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"func X \\XBOOLE-0K4 Y \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff x inHIDDENR3 X &  not x inHIDDENR3 Y"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff x inHIDDENR3 X &  not x inHIDDENR3 Y"
    proof-
      have " ex Z be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 Z iff x inHIDDENR3 X &  not x inHIDDENR3 Y"
      proof-
        let ?P = "\<lambda>Lamb1.  not Lamb1 inHIDDENR3 Y"
        show " ex Z be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 Z iff x inHIDDENR3 X &  not x inHIDDENR3 Y"
          using xboole_0_sch_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff x inHIDDENR3 X &  not x inHIDDENR3 Y) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff x inHIDDENR3 X &  not x inHIDDENR3 Y) implies it1 =HIDDENR1 it2"
    proof-
      have " for A1 be setHIDDENM2 holds  for A2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 A1 iff x inHIDDENR3 X &  not x inHIDDENR3 Y) & ( for x be objectHIDDENM1 holds x inHIDDENR3 A2 iff x inHIDDENR3 X &  not x inHIDDENR3 Y) implies A1 =HIDDENR1 A2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix A1 assume [ty]: "A1 be setHIDDENM2"
        fix A2 assume [ty]: "A2 be setHIDDENM2"
        assume A5: " for x be objectHIDDENM1 holds x inHIDDENR3 A1 iff x inHIDDENR3 X &  not x inHIDDENR3 Y"
          and A6: " for x be objectHIDDENM1 holds x inHIDDENR3 A2 iff x inHIDDENR3 X &  not x inHIDDENR3 Y"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 A1 iff x inHIDDENR3 A2"
        proof(rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          have "x inHIDDENR3 A1 iff x inHIDDENR3 X &  not x inHIDDENR3 Y"
            using A5 sorry
          thus "x inHIDDENR3 A1 iff x inHIDDENR3 A2"
            using A6 sorry
        qed "sorry"
        thus "A1 =HIDDENR1 A2"
          using tarski_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef xboole_0_def_6 (" _ '\\+'\\XBOOLE-0K5  _ " [130,130]130 ) where
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"func X \\+\\XBOOLE-0K5 Y \<rightarrow> setHIDDENM2 equals
  (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X)"
proof-
  (*coherence*)
    show "(X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X) be setHIDDENM2"
       sorry
qed "sorry"

mtheorem XBOOLE_0K5_commutativity:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\+\\XBOOLE-0K5 Y =HIDDENR1 Y \\+\\XBOOLE-0K5 X"
proof-
  have " for it be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds it =HIDDENR1 X \\+\\XBOOLE-0K5 Y implies it =HIDDENR1 Y \\+\\XBOOLE-0K5 X"
  proof-
    have " for it be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds it =HIDDENR1 (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X) implies it =HIDDENR1 (Y \\XBOOLE-0K4 X)\\/XBOOLE-0K2 (X \\XBOOLE-0K4 Y)"
       sorry
    thus " ?thesis "
      using xboole_0_def_6 sorry
  qed
  thus " ?thesis "
     sorry
qed

mdef xboole_0_def_7 (" _ missesXBOOLE-0R1  _ " [50,50]50 ) where
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"pred X missesXBOOLE-0R1 Y means
  X /\\XBOOLE-0K3 Y =HIDDENR1 {}XBOOLE-0K1"..

mtheorem XBOOLE_0R1_symmetry:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X missesXBOOLE-0R1 Y implies Y missesXBOOLE-0R1 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X /\\XBOOLE-0K3 Y =HIDDENR1 {}XBOOLE-0K1 implies Y /\\XBOOLE-0K3 X =HIDDENR1 {}XBOOLE-0K1"
     sorry
  thus " ?thesis "
    using xboole_0_def_7 sorry
qed

mdef xboole_0_def_8 (" _ c<XBOOLE-0R2  _ " [50,50]50 ) where
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"pred X c<XBOOLE-0R2 Y means
  X c=TARSKIR1 Y & X <>HIDDENR2 Y"..

mtheorem XBOOLE_0R2_irreflexivity:
" for Y be setHIDDENM2 holds  not Y c<XBOOLE-0R2 Y"
proof-
  have " for Y be setHIDDENM2 holds  not (Y c=TARSKIR1 Y & Y <>HIDDENR2 Y)"
     sorry
  thus " ?thesis "
    using xboole_0_def_8 sorry
qed

mtheorem XBOOLE_0R2_asymmetry:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c<XBOOLE-0R2 Y implies  not Y c<XBOOLE-0R2 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y & X <>HIDDENR2 Y implies  not (Y c=TARSKIR1 X & Y <>HIDDENR2 X)"
    using tarski_th_2 sorry
  thus " ?thesis "
    using xboole_0_def_8 sorry
qed

mdef xboole_0_def_9 ("'( _ , _ ')are-c=-comparableXBOOLE-0R3" [0,0]50 ) where
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"pred (X,Y)are-c=-comparableXBOOLE-0R3 means
  X c=TARSKIR1 Y or Y c=TARSKIR1 X"..

mtheorem XBOOLE_0R3_reflexivity:
" for Y be setHIDDENM2 holds (Y,Y)are-c=-comparableXBOOLE-0R3"
proof-
  have " for Y be setHIDDENM2 holds Y c=TARSKIR1 Y or Y c=TARSKIR1 Y"
     sorry
  thus " ?thesis "
    using xboole_0_def_9 sorry
qed

mtheorem XBOOLE_0R3_symmetry:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (X,Y)are-c=-comparableXBOOLE-0R3 implies (Y,X)are-c=-comparableXBOOLE-0R3"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y or Y c=TARSKIR1 X implies Y c=TARSKIR1 X or X c=TARSKIR1 Y"
     sorry
  thus " ?thesis "
    using xboole_0_def_9 sorry
qed

abbreviation(input) XBOOLE_0R4(" _ =XBOOLE-0R4  _ " [50,50]50) where
  "X =XBOOLE-0R4 Y \<equiv> X =HIDDENR1 Y"

mtheorem xboole_0_def_10:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"redefine pred X =XBOOLE-0R4 Y means
  X c=TARSKIR1 Y & Y c=TARSKIR1 X"
proof
(*compatibility*)
  show "X =XBOOLE-0R4 Y iff X c=TARSKIR1 Y & Y c=TARSKIR1 X"
    using tarski_th_2 sorry
qed "sorry"

syntax XBOOLE_0R5 :: " Set \<Rightarrow>  Set \<Rightarrow> o" (" _ meetsXBOOLE-0R5  _ " [50,50]50)
translations "X meetsXBOOLE-0R5 Y" \<rightharpoonup> " not X missesXBOOLE-0R1 Y"

mtheorem xboole_0_th_1:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds x inHIDDENR3 X \\+\\XBOOLE-0K5 Y iff  not (x inHIDDENR3 X iff x inHIDDENR3 Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  not ((x inHIDDENR3 X \\+\\XBOOLE-0K5 Y &  not (x inHIDDENR3 X &  not x inHIDDENR3 Y)) &  not (x inHIDDENR3 Y &  not x inHIDDENR3 X)) &  not ( not ( not (x inHIDDENR3 X &  not x inHIDDENR3 Y) &  not (x inHIDDENR3 Y &  not x inHIDDENR3 X)) &  not x inHIDDENR3 X \\+\\XBOOLE-0K5 Y)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    have "x inHIDDENR3 X \\+\\XBOOLE-0K5 Y iff x inHIDDENR3 X \\XBOOLE-0K4 Y or x inHIDDENR3 Y \\XBOOLE-0K4 X"
      using xboole_0_def_3 sorry
    thus " not ((x inHIDDENR3 X \\+\\XBOOLE-0K5 Y &  not (x inHIDDENR3 X &  not x inHIDDENR3 Y)) &  not (x inHIDDENR3 Y &  not x inHIDDENR3 X)) &  not ( not ( not (x inHIDDENR3 X &  not x inHIDDENR3 Y) &  not (x inHIDDENR3 Y &  not x inHIDDENR3 X)) &  not x inHIDDENR3 X \\+\\XBOOLE-0K5 Y)"
      using xboole_0_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_0_th_2:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds ( for x be objectHIDDENM1 holds  not x inHIDDENR3 X iff (x inHIDDENR3 Y iff x inHIDDENR3 Z)) implies X =XBOOLE-0R4 Y \\+\\XBOOLE-0K5 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds ( for x be objectHIDDENM1 holds  not x inHIDDENR3 X iff (x inHIDDENR3 Y iff x inHIDDENR3 Z)) implies X =XBOOLE-0R4 Y \\+\\XBOOLE-0K5 Z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume A1: " for x be objectHIDDENM1 holds  not x inHIDDENR3 X iff (x inHIDDENR3 Y iff x inHIDDENR3 Z)"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X iff x inHIDDENR3 Y \\+\\XBOOLE-0K5 Z"
    proof(rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have "x inHIDDENR3 X iff x inHIDDENR3 Y &  not x inHIDDENR3 Z or x inHIDDENR3 Z &  not x inHIDDENR3 Y"
        using A1 sorry
      then have "x inHIDDENR3 X iff x inHIDDENR3 Y \\XBOOLE-0K4 Z or x inHIDDENR3 Z \\XBOOLE-0K4 Y"
        using xboole_0_def_5 sorry
      thus "x inHIDDENR3 X iff x inHIDDENR3 Y \\+\\XBOOLE-0K5 Z"
        using xboole_0_def_3 sorry
    qed "sorry"
    thus "X =XBOOLE-0R4 Y \\+\\XBOOLE-0K5 Z"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_0_cl_2:
"cluster {}XBOOLE-0K1 as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "{}XBOOLE-0K1 be emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem xboole_0_cl_3:
  mlet "x be objectHIDDENM1"
"cluster {TARSKIK1 x} as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "{TARSKIK1 x} be  non emptyXBOOLE-0V1"
  proof-
    have " not {TARSKIK1 x} be emptyXBOOLE-0V1"
    proof-
      have Cut210: "x inHIDDENR3 {TARSKIK1 x}"
        using tarski_def_1 sorry
      have " ex z be objectHIDDENM1 st z inHIDDENR3 {TARSKIK1 x}"
      proof-
        show " ex z be objectHIDDENM1 st z inHIDDENR3 {TARSKIK1 x}"
          using Cut210 sorry
      qed
      thus " not {TARSKIK1 x} be emptyXBOOLE-0V1"
        using xboole_0_def_1 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xboole_0_cl_4:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1"
"cluster {TARSKIK2 x,y } as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "{TARSKIK2 x,y } be  non emptyXBOOLE-0V1"
  proof-
    have " not {TARSKIK2 x,y } be emptyXBOOLE-0V1"
    proof-
      have Cut217: "x inHIDDENR3 {TARSKIK2 x,y }"
        using tarski_def_2 sorry
      have " ex z be objectHIDDENM1 st z inHIDDENR3 {TARSKIK2 x,y }"
      proof-
        show " ex z be objectHIDDENM1 st z inHIDDENR3 {TARSKIK2 x,y }"
          using Cut217 sorry
      qed
      thus " not {TARSKIK2 x,y } be emptyXBOOLE-0V1"
        using xboole_0_def_1 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xboole_0_cl_5:
"cluster  non emptyXBOOLE-0V1 for setHIDDENM2"
proof
(*existence*)
  show " ex it be setHIDDENM2 st it be  non emptyXBOOLE-0V1"
  proof-
    have " ex tVar4 be setHIDDENM2 st  not tVar4 be emptyXBOOLE-0V1"
    proof-
      show " ex tVar4 be setHIDDENM2 st  not tVar4 be emptyXBOOLE-0V1"
      proof(rule bexI[of _ "{TARSKIK1 the setHIDDENM2 }"])
        show " not {TARSKIK1 the setHIDDENM2 } be emptyXBOOLE-0V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xboole_0_cl_6:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X be setHIDDENM2"
"cluster D \\/XBOOLE-0K2 X as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "D \\/XBOOLE-0K2 X be  non emptyXBOOLE-0V1"
  proof-
    have " not D \\/XBOOLE-0K2 X be emptyXBOOLE-0V1"
    proof-
      obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A1: "x inHIDDENR3 D"
        using xboole_0_def_1 sorry
      have Cut238: "x inHIDDENR3 D \\/XBOOLE-0K2 X"
        using A1 xboole_0_def_3 sorry
      have " ex x be objectHIDDENM1 st x inHIDDENR3 D \\/XBOOLE-0K2 X"
      proof-
        show " ex x be objectHIDDENM1 st x inHIDDENR3 D \\/XBOOLE-0K2 X"
          using Cut238 sorry
      qed
      thus " not D \\/XBOOLE-0K2 X be emptyXBOOLE-0V1"
        using xboole_0_def_1 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xboole_0_cl_7:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X be setHIDDENM2"
"cluster X \\/XBOOLE-0K2 D as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "X \\/XBOOLE-0K2 D be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

mlemma xboole_0_lm_1:
" for X be setHIDDENM2 holds X be emptyXBOOLE-0V1 implies X =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for X be setHIDDENM2 holds  not (X be emptyXBOOLE-0V1 &  not X =XBOOLE-0R4 {}XBOOLE-0K1)"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have " not ( ex x be objectHIDDENM1 st x inHIDDENR3 X) implies X =XBOOLE-0R4 {}XBOOLE-0K1"
    proof(rule impI)
      assume " not ( ex x be objectHIDDENM1 st x inHIDDENR3 X)"
      then have " for x be objectHIDDENM1 holds x inHIDDENR3 {}XBOOLE-0K1 iff x inHIDDENR3 X"
        using xboole_0_def_1 sorry
      thus "X =XBOOLE-0R4 {}XBOOLE-0K1"
        using tarski_th_2 sorry
    qed
    thus " not (X be emptyXBOOLE-0V1 &  not X =XBOOLE-0R4 {}XBOOLE-0K1)"
      using xboole_0_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_0_th_3:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X meetsXBOOLE-0R5 Y iff ( ex x be objectHIDDENM1 st x inHIDDENR3 X & x inHIDDENR3 Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (X meetsXBOOLE-0R5 Y implies ( ex x be objectHIDDENM1 st x inHIDDENR3 X & x inHIDDENR3 Y)) & (( ex x be objectHIDDENM1 st x inHIDDENR3 X & x inHIDDENR3 Y) implies  not X meetsXBOOLE-0R5 Y)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    show "X meetsXBOOLE-0R5 Y implies ( ex x be objectHIDDENM1 st x inHIDDENR3 X & x inHIDDENR3 Y)"
    proof(rule impI)
      assume "X meetsXBOOLE-0R5 Y"
      then have "X /\\XBOOLE-0K3 Y <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      then have " not X /\\XBOOLE-0K3 Y be emptyXBOOLE-0V1"
        using xboole_0_lm_1 sorry
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A1: "x inHIDDENR3 X /\\XBOOLE-0K3 Y"
         sorry
      show " ex x be objectHIDDENM1 st x inHIDDENR3 X & x inHIDDENR3 Y"
      proof(rule bexI[of _ "x"])
        show "x inHIDDENR3 X & x inHIDDENR3 Y"
          using A1 xboole_0_def_4 sorry
      qed "sorry"
    qed
    assume Given: " ex x be objectHIDDENM1 st x inHIDDENR3 X & x inHIDDENR3 Y"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A2: "x inHIDDENR3 X & x inHIDDENR3 Y"
       sorry
    have "x inHIDDENR3 X /\\XBOOLE-0K3 Y"
      using A2 xboole_0_def_4 sorry
    then have "X /\\XBOOLE-0K3 Y <>HIDDENR2 {}XBOOLE-0K1"
      using xboole_0_def_1 sorry
    thus " not X meetsXBOOLE-0R5 Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_0_th_4:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X meetsXBOOLE-0R5 Y iff ( ex x be objectHIDDENM1 st x inHIDDENR3 X /\\XBOOLE-0K3 Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (X meetsXBOOLE-0R5 Y implies ( ex x be objectHIDDENM1 st x inHIDDENR3 X /\\XBOOLE-0K3 Y)) & (( ex x be objectHIDDENM1 st x inHIDDENR3 X /\\XBOOLE-0K3 Y) implies  not X meetsXBOOLE-0R5 Y)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    show "X meetsXBOOLE-0R5 Y implies ( ex x be objectHIDDENM1 st x inHIDDENR3 X /\\XBOOLE-0K3 Y)"
    proof(rule impI)
      assume "X meetsXBOOLE-0R5 Y"
      then have "X /\\XBOOLE-0K3 Y <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      then have " not X /\\XBOOLE-0K3 Y be emptyXBOOLE-0V1"
        using xboole_0_lm_1 sorry
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A1: "x inHIDDENR3 X /\\XBOOLE-0K3 Y"
         sorry
      show " ex x be objectHIDDENM1 st x inHIDDENR3 X /\\XBOOLE-0K3 Y"
      proof(rule bexI[of _ "x"])
        show "x inHIDDENR3 X /\\XBOOLE-0K3 Y"
          using A1 sorry
      qed "sorry"
    qed
    assume " ex x be objectHIDDENM1 st x inHIDDENR3 X /\\XBOOLE-0K3 Y"
    then have "X /\\XBOOLE-0K3 Y <>HIDDENR2 {}XBOOLE-0K1"
      using xboole_0_def_1 sorry
    thus " not X meetsXBOOLE-0R5 Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_0_th_5:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds X missesXBOOLE-0R1 Y & x inHIDDENR3 X \\/XBOOLE-0K2 Y implies x inHIDDENR3 X &  not x inHIDDENR3 Y or x inHIDDENR3 Y &  not x inHIDDENR3 X"
  using xboole_0_def_3 xboole_0_th_3 sorry

theorem xboole_0_sch_2:
  fixes Xf0 Yf0 Pp1 
  assumes
[ty]: "Xf0 be setHIDDENM2" and
  [ty]: "Yf0 be setHIDDENM2" and
   A1: " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 iff Pp1(x)" and
   A2: " for x be objectHIDDENM1 holds x inHIDDENR3 Yf0 iff Pp1(x)"
  shows "Xf0 =XBOOLE-0R4 Yf0"
  proof-
    have A3: " for x be objectHIDDENM1 holds x inHIDDENR3 Yf0 implies x inHIDDENR3 Xf0"
      using A1 A2 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies x inHIDDENR3 Yf0"
      using A1 A2 sorry
    thus "Xf0 =XBOOLE-0R4 Yf0"
      using A3 tarski_th_2 sorry
  qed

theorem xboole_0_sch_3:
  fixes Pp1 
  shows " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 X1 iff Pp1(x)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 X2 iff Pp1(x)) implies X1 =XBOOLE-0R4 X2"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    assume A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X1 iff Pp1(x)"
      and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 X2 iff Pp1(x)"
    show "X1 =XBOOLE-0R4 X2"
      using xboole_0_sch_2 A1 A2 sorry
  qed "sorry"

(*begin*)
mtheorem xboole_0_th_6:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c<XBOOLE-0R2 Y implies ( ex x be objectHIDDENM1 st x inHIDDENR3 Y &  not x inHIDDENR3 X)"
  using xboole_0_def_8 tarski_def_3 sorry

mtheorem xboole_0_th_7:
" for X be setHIDDENM2 holds X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex x be objectHIDDENM1 st x inHIDDENR3 X)"
  using xboole_0_def_1 xboole_0_lm_1 sorry

mtheorem xboole_0_th_8:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c<XBOOLE-0R2 Y implies ( ex x be objectHIDDENM1 st x inHIDDENR3 Y & X c=TARSKIR1 Y \\XBOOLE-0K4 {TARSKIK1 x})"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c<XBOOLE-0R2 Y implies ( ex tVar7 be objectHIDDENM1 st tVar7 inHIDDENR3 Y & X c=TARSKIR1 Y \\XBOOLE-0K4 {TARSKIK1 tVar7})"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "X c<XBOOLE-0R2 Y"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A2: "x inHIDDENR3 Y"and A3: " not x inHIDDENR3 X"
      using xboole_0_th_6 sorry
    show " ex tVar7 be objectHIDDENM1 st tVar7 inHIDDENR3 Y & X c=TARSKIR1 Y \\XBOOLE-0K4 {TARSKIK1 tVar7}"
    proof(rule bexI[of _ "x"],rule conjMI)
      show "x inHIDDENR3 Y"
        using A2 sorry
      have " for y be objectHIDDENM1 holds y inHIDDENR3 X implies y inHIDDENR3 Y \\XBOOLE-0K4 {TARSKIK1 x}"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A4: "y inHIDDENR3 X"
        then have "y <>HIDDENR2 x"
          using A3 sorry
        then have A5: " not y inHIDDENR3 {TARSKIK1 x}"
          using tarski_def_1 sorry
        have "X c=TARSKIR1 Y"
          using A1 sorry
        then have "y inHIDDENR3 Y"
          using A4 sorry
        thus "y inHIDDENR3 Y \\XBOOLE-0K4 {TARSKIK1 x}"
          using xboole_0_def_5 A5 sorry
      qed "sorry"
      thus "X c=TARSKIR1 Y \\XBOOLE-0K4 {TARSKIK1 x}"
        using tarski_def_3 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax XBOOLE_0R6 :: " Set \<Rightarrow>  Set \<Rightarrow> o" (" _ c'/=XBOOLE-0R6  _ " [50,50]50)
translations "x c/=XBOOLE-0R6 y" \<rightharpoonup> " not x c=TARSKIR1 y"

syntax XBOOLE_0R7 :: " Set \<Rightarrow>  Set \<Rightarrow> o" (" _ ninXBOOLE-0R7  _ " [50,50]50)
translations "x ninXBOOLE-0R7 y" \<rightharpoonup> " not x inHIDDENR3 y"

end
