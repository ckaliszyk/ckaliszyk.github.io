theory trees_a
  imports trees_2 membered
   "../mizar_extension/E_number"
begin
(*begin*)
reserve T, T1 for "TreeTREES-1M1"
reserve P for "AntiChain-of-PrefixesTREES-1M6-of T"
reserve p1 for "FinSequenceFINSEQ-1M1"
reserve p, q, r, s, p9 for "FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
reserve x, Z for "setHIDDENM2"
reserve t for "ElementTREES-1M2-of T"
reserve k, n for "NatNAT-1M1"
mtheorem trees_a_th_1:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for r be FinSequenceFINSEQ-1M1 holds  for s be FinSequenceFINSEQ-1M1 holds p ^FINSEQ-1K8 q =FINSEQ-1R1 s ^FINSEQ-1K8 r implies (p,s)are-c=-comparableXBOOLE-0R3"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
  fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
  fix r assume [ty]: "r be FinSequenceFINSEQ-1M1"
  fix s assume [ty]: "s be FinSequenceFINSEQ-1M1"
  assume A1: "p ^FINSEQ-1K8 q =FINSEQ-1R1 s ^FINSEQ-1K8 r"
  then have "p is-a-prefix-ofTREES-1R2 s ^FINSEQ-1K8 r & s is-a-prefix-ofTREES-1R2 p ^FINSEQ-1K8 q"
    using trees_1_th_1 sorry
  thus "(p,s)are-c=-comparableXBOOLE-0R3"
    using A1 trees_2_th_1 sorry
qed "sorry"

mdef trees_a_def_1 ("treeTREES-AK1'( _ , _ , _ ')" [0,0,0]164 ) where
  mlet "T be TreeTREES-1M1", "T1 be TreeTREES-1M1", "P be AntiChain-of-PrefixesTREES-1M6-of T"
"assume P <>HIDDENR2 {}XBOOLE-0K1 func treeTREES-AK1(T,P,T1) \<rightarrow> TreeTREES-1M1 means
  \<lambda>it.  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 it iff q inTARSKIR2 T & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
proof-
  (*existence*)
    show "P <>HIDDENR2 {}XBOOLE-0K1 implies ( ex it be TreeTREES-1M1 st  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 it iff q inTARSKIR2 T & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r))"
    proof(rule impI)
      assume Assume: "P <>HIDDENR2 {}XBOOLE-0K1"
      have A1: "P <>HIDDENR2 {}XBOOLE-0K1"
        using Assume sorry
      show " ex it be TreeTREES-1M1 st  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 it iff q inTARSKIR2 T & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
      proof-
        have " ex tVar1 be TreeTREES-1M1 st  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (q inTARSKIR2 tVar1 implies q inTARSKIR2 T & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)) & (q inTARSKIR2 T & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) implies q inTARSKIR2 tVar1)"
        proof-
          obtain P9 where 
            [ty]:"P9 be SubsetSUBSET-1M2-of T" and P9Def:"P9 = P"
            using trees_1_def_11 sorry
          have " for x be objectHIDDENM1 holds x inHIDDENR3 P9 implies x inHIDDENR3 {t where t be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t }"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A2: "x inHIDDENR3 P9"
            then obtain x9 where 
              [ty]:"x9 be FinSequenceFINSEQ-1M1" and x9Def:"x9 = x"
              using trees_1_def_10 sorry
            have 
              [ty]:"x9 be ElementTREES-1M2-of T"
              using A2 sorry
            have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 x9"
            proof(rule ballI,rule impI)
              fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
              assume A3: "p inTARSKIR2 P"
              show " not p is-a-proper-prefix-ofTREES-1R3 x9"
              proof-
                have cases: "p <>HIDDENR2 x9 or p =FINSEQ-1R1 x9"
                   sorry
                have case1: "p <>HIDDENR2 x9 implies  not p is-a-proper-prefix-ofTREES-1R3 x9"
                proof(rule impI)
                  assume "p <>HIDDENR2 x9"
                  then have " not (p,x9)are-c=-comparableXBOOLE-0R3"
                    using A2 A3 trees_1_def_10 sorry
                  thus " not p is-a-proper-prefix-ofTREES-1R3 x9"
                     sorry
                qed
                have case2: "p =FINSEQ-1R1 x9 implies  not p is-a-proper-prefix-ofTREES-1R3 x9"
                proof(rule impI)
                  assume "p =FINSEQ-1R1 x9"
                  thus " not p is-a-proper-prefix-ofTREES-1R3 x9"
                     sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed "sorry"
            thus "x inHIDDENR3 {t where t be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t }"
               sorry
          qed "sorry"
          then have "P c=TARSKIR1 {t where t be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t }"
             sorry
          then obtain Y where 
            [ty]:"Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and YDef:"Y = {t where t be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t }"
            using A1 xboole_1_th_3 sorry
          obtain Z where
            [ty]:"Z be setHIDDENM2" and 
            A4: "Z =XBOOLE-0R4 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P }"
             sorry
          obtain X where 
            [ty]:"X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and XDef:"X = Y \\/XBOOLE-0K2 Z"
             sorry
          have A5: " for x be setHIDDENM2 holds x inTARSKIR2 {t where t be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t } implies (x be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 & x inTARSKIR2 NATNUMBERSK1 * FINSEQ-1K14) & x inTARSKIR2 T"
          proof-
            have " for x be setHIDDENM2 holds x inTARSKIR2 {t where t be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t } implies x be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 & (x inTARSKIR2 NATNUMBERSK1 * FINSEQ-1K14 & x inTARSKIR2 T)"
            proof(rule ballI,rule impI,rule conjMI)
              fix x assume [ty]: "x be setHIDDENM2"
              assume "x inTARSKIR2 {t where t be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t }"
              then have A6: " ex t be ElementTREES-1M2-of T st x =XBOOLE-0R4 t & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t)"
                 sorry
              thus "x be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                 sorry
              show "x inTARSKIR2 NATNUMBERSK1 * FINSEQ-1K14 & x inTARSKIR2 T"
                using A6 finseq_1_def_11 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have "X be Tree-likeTREES-1V1"
          proof-
            have "X c=TARSKIR1 NATNUMBERSK1 * FINSEQ-1K14 & (( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 X implies ProperPrefixesTREES-1K1 q c=TARSKIR1 X) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds q ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 X & n <=XXREAL-0R1 k implies q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 X))"
            proof(rule conjMI,rule conjMI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
              show "X c=TARSKIR1 NATNUMBERSK1 * FINSEQ-1K14"
              proof-
                have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 NATNUMBERSK1 * FINSEQ-1K14"
                proof(rule ballI,rule impI)
                  fix x assume [ty]: "x be objectHIDDENM1"
                  assume "x inHIDDENR3 X"
                  then have A7: "x inHIDDENR3 {t where t be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t } or x inHIDDENR3 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P }"
                    using A4 xboole_0_def_3 sorry
                  have "x inHIDDENR3 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P } implies x be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                  proof(rule impI)
                    assume "x inHIDDENR3 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P }"
                    then have " ex p be ElementTREES-1M2-of T st  ex s be ElementTREES-1M2-of T1 st x =HIDDENR1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s & p inTARSKIR2 P"
                       sorry
                    thus "x be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                       sorry
                  qed
                  thus "x inHIDDENR3 NATNUMBERSK1 * FINSEQ-1K14"
                    using A5 A7 finseq_1_def_11 sorry
                qed "sorry"
                thus "X c=TARSKIR1 NATNUMBERSK1 * FINSEQ-1K14"
                  using tarski_def_3 sorry
              qed
              show " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 X implies ProperPrefixesTREES-1K1 q c=TARSKIR1 X"
              proof(rule ballI,rule impI)
                fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                assume A8: "q inTARSKIR2 X"
                have A9: "q inTARSKIR2 {t where t be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t } implies ProperPrefixesTREES-1K1 q c=TARSKIR1 X"
                proof(rule impI)
                  assume A10: "q inTARSKIR2 {t where t be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t }"
                  then have " ex t be ElementTREES-1M2-of T st q =FINSEQ-1R1 t & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t)"
                     sorry
                  then have A11: "ProperPrefixesTREES-1K1 q c=TARSKIR1 T"
                    using trees_1_def_3 sorry
                  show "ProperPrefixesTREES-1K1 q c=TARSKIR1 X"
                  proof-
                    have " for x be objectHIDDENM1 holds x inHIDDENR3 ProperPrefixesTREES-1K1 q implies x inHIDDENR3 X"
                    proof(rule ballI,rule impI)
                      fix x assume [ty]: "x be objectHIDDENM1"
                      assume A12: "x inHIDDENR3 ProperPrefixesTREES-1K1 q"
                      then obtain p1 where
                        [ty]:"p1 be FinSequenceFINSEQ-1M1" and 
                        A13: "x =HIDDENR1 p1"and A14: "p1 is-a-proper-prefix-ofTREES-1R3 q"
                        using trees_1_def_2 sorry
                      have 
                        [ty]:"p1 be ElementTREES-1M2-of T"
                        using A11 A12 A13 sorry
                      have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 p1"
                      proof(rule ballI,rule impI)
                        fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                        assume A15: "p inTARSKIR2 P"
                        have " ex t be ElementTREES-1M2-of T st q =FINSEQ-1R1 t & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t)"
                          using A10 sorry
                        thus " not p is-a-proper-prefix-ofTREES-1R3 p1"
                          using A14 A15 xboole_1_th_56 sorry
                      qed "sorry"
                      then have "x inHIDDENR3 {s1 where s1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 s1 }"
                        using A13 sorry
                      thus "x inHIDDENR3 X"
                        using xboole_0_def_3 sorry
                    qed "sorry"
                    thus "ProperPrefixesTREES-1K1 q c=TARSKIR1 X"
                      using tarski_def_3 sorry
                  qed
                qed
                have "q inTARSKIR2 Z implies ProperPrefixesTREES-1K1 q c=TARSKIR1 X"
                proof(rule impI)
                  assume "q inTARSKIR2 Z"
                  then obtain p s where
                    [ty]:"p be ElementTREES-1M2-of T" "s be ElementTREES-1M2-of T1" and 
                    A16: "q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s"and A17: "p inTARSKIR2 P"
                    using A4 sorry
                  show "ProperPrefixesTREES-1K1 q c=TARSKIR1 X"
                  proof-
                    have " for x be objectHIDDENM1 holds x inHIDDENR3 ProperPrefixesTREES-1K1 q implies x inHIDDENR3 X"
                    proof(rule ballI,rule impI)
                      fix x assume [ty]: "x be objectHIDDENM1"
                      assume A18: "x inHIDDENR3 ProperPrefixesTREES-1K1 q"
                      then obtain r where 
                        [ty]:"r be FinSequenceFINSEQ-1M1" and rDef:"r = x"
                        using trees_1_th_11 sorry
                      have "r is-a-proper-prefix-ofTREES-1R3 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s"
                        using A16 A18 trees_1_th_12 sorry
                      then have "r is-a-prefix-ofTREES-1R2 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s"
                         sorry
                      then obtain r1 where
                        [ty]:"r1 be FinSequenceFINSEQ-1M1" and 
                        A19: "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s =FINSEQ-1R1 r ^FINSEQ-1K8 r1"
                        using trees_1_th_1 sorry
                      have A20: "lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 r implies r inTARSKIR2 X"
                      proof(rule impI)
                        assume "lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 r"
                        then obtain r2 where
                          [ty]:"r2 be FinSequenceFINSEQ-1M1" and 
                          A21: "p ^FINSEQ-1K8 r2 =FINSEQ-1R1 r"
                          using A19 finseq_1_th_47 sorry
                        have "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s =FINSEQ-1R1 p ^FINSEQ-1K8 (r2 ^FINSEQ-1K8 r1)"
                          using A19 A21 finseq_1_th_32 sorry
                        then have "s =FINSEQ-1R1 r2 ^FINSEQ-1K8 r1"
                          using finseq_1_th_33 sorry
                        then have "s  |RELAT-1K8 domFINSEQ-1K5 r2 =RELAT-1R1 r2"
                          using finseq_1_th_21 sorry
                        then have A22: "s  |RELAT-1K8 SegFINSEQ-1K2 (lenFINSEQ-1K4 r2) =RELAT-1R1 r2"
                          using finseq_1_def_3 sorry
                        then have 
                          [ty]:"r2 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                          using finseq_1_th_18 sorry
                        have "r2 is-a-prefix-ofTREES-1R2 s"
                          using A22 sorry
                        then have 
                          [ty]:"r2 be ElementTREES-1M2-of T1"
                          using trees_1_th_20 sorry
                        have "r =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r2"
                          using A21 sorry
                        then have "r inTARSKIR2 {w ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> v where w be ElementTREES-1M2-of T, v be ElementTREES-1M2-of T1 : w inTARSKIR2 P }"
                          using A17 sorry
                        thus "r inTARSKIR2 X"
                          using A4 xboole_0_def_3 sorry
                      qed
                      have "lenFINSEQ-1K4 r <=XXREAL-0R1 lenFINSEQ-1K4 p implies r inTARSKIR2 X"
                      proof(rule impI)
                        assume "lenFINSEQ-1K4 r <=XXREAL-0R1 lenFINSEQ-1K4 p"
                        then have " ex r2 be FinSequenceFINSEQ-1M1 st r ^FINSEQ-1K8 r2 =FINSEQ-1R1 p"
                          using A19 finseq_1_th_47 sorry
                        then have "p  |RELAT-1K8 domFINSEQ-1K5 r =RELAT-1R1 r"
                          using finseq_1_th_21 sorry
                        then have A23: "p  |RELAT-1K8 SegFINSEQ-1K2 (lenFINSEQ-1K4 r) =RELAT-1R1 r"
                          using finseq_1_def_3 sorry
                        then obtain r3 where 
                          [ty]:"r3 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and r3Def:"r3 = r"
                          using finseq_1_th_18 sorry
                        have A24: "r3 is-a-prefix-ofTREES-1R2 p"
                          using A23 sorry
                        then have 
                          [ty]:"r3 be ElementTREES-1M2-of T"
                          using trees_1_th_20 sorry
                        have " for p9 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p9 inTARSKIR2 P implies  not p9 is-a-proper-prefix-ofTREES-1R3 r3"
                        proof-
                          have " for p9 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p9 inTARSKIR2 P implies (p9 is-a-proper-prefix-ofTREES-1R3 r3 implies  False )"
                          proof(rule ballI,rule impI,rule impI)
                            fix p9 assume [ty]: "p9 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                            assume A25: "p9 inTARSKIR2 P"
                            assume A26: "p9 is-a-proper-prefix-ofTREES-1R3 r3"
                            then have "p9 is-a-prefix-ofTREES-1R2 r3"
                               sorry
                            then have "p9 is-a-prefix-ofTREES-1R2 p"
                              using A24 sorry
                            then have A27: "(p,p9)are-c=-comparableXBOOLE-0R3"
                               sorry
                            show " False "
                            proof-
                              have cases: "p <>HIDDENR2 p9 or p =FINSEQ-1R1 p9"
                                 sorry
                              have case1: "p <>HIDDENR2 p9 implies  False "
                              proof(rule impI)
                                assume "p <>HIDDENR2 p9"
                                thus " False "
                                  using A17 A25 A27 trees_1_def_10 sorry
                              qed
                              have case2: "p =FINSEQ-1R1 p9 implies  False "
                              proof(rule impI)
                                assume "p =FINSEQ-1R1 p9"
                                thus " False "
                                  using A24 A26 xboole_0_def_8 sorry
                              qed
                              show " ?thesis "
                                using cases case1 case2 sorry
                            qed
                          qed "sorry"
                          thus " ?thesis "
                             sorry
                        qed
                        then have "r3 inTARSKIR2 {t where t be ElementTREES-1M2-of T :  for p9 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p9 inTARSKIR2 P implies  not p9 is-a-proper-prefix-ofTREES-1R3 t }"
                           sorry
                        thus "r inTARSKIR2 X"
                          using xboole_0_def_3 sorry
                      qed
                      thus "x inHIDDENR3 X"
                        using A20 sorry
                    qed "sorry"
                    thus "ProperPrefixesTREES-1K1 q c=TARSKIR1 X"
                      using tarski_def_3 sorry
                  qed
                qed
                thus "ProperPrefixesTREES-1K1 q c=TARSKIR1 X"
                  using A8 A9 xboole_0_def_3 sorry
              qed "sorry"
              fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
              fix k assume [ty]: "k be NatNAT-1M1"
              fix n assume [ty]: "n be NatNAT-1M1"
              assume A28: "q ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 X"
                and A29: "n <=XXREAL-0R1 k"
              have A30: "q ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 {t where t be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t } implies q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 X"
              proof(rule impI)
                assume A31: "q ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 {t where t be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t }"
                then have " ex s be ElementTREES-1M2-of T st q ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) =FINSEQ-1R1 s & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 s)"
                   sorry
                then obtain u where 
                  [ty]:"u be ElementTREES-1M2-of T" and uDef:"u = q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)"
                  using A29 trees_1_def_3 sorry
                have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies (p is-a-proper-prefix-ofTREES-1R3 u implies  False )"
                proof(rule ballI,rule impI,rule impI)
                  fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                  assume A32: "p inTARSKIR2 P"
                  assume "p is-a-proper-prefix-ofTREES-1R3 u"
                  then have A33: "p is-a-prefix-ofTREES-1R2 q"
                    using trees_1_th_9 sorry
                  have " ex s be ElementTREES-1M2-of T st q ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) =FINSEQ-1R1 s & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 s)"
                    using A31 sorry
                  thus " False "
                    using A32 A33 trees_1_th_8 sorry
                qed "sorry"
                then have "q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 {t where t be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t }"
                   sorry
                thus "q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 X"
                  using xboole_0_def_3 sorry
              qed
              have "q ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 Z implies q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 X"
              proof(rule impI)
                assume "q ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 Z"
                then obtain p s where
                  [ty]:"p be ElementTREES-1M2-of T" "s be ElementTREES-1M2-of T1" and 
                  A34: "q ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s"and A35: "p inTARSKIR2 P"
                  using A4 sorry
                have A36: "lenFINSEQ-1K4 q <=XXREAL-0R1 lenFINSEQ-1K4 p implies q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 X"
                proof(rule impI)
                  assume "lenFINSEQ-1K4 q <=XXREAL-0R1 lenFINSEQ-1K4 p"
                  then obtain r where
                    [ty]:"r be FinSequenceFINSEQ-1M1" and 
                    A37: "q ^FINSEQ-1K8 r =FINSEQ-1R1 p"
                    using A34 finseq_1_th_47 sorry
                  have "q ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) =FINSEQ-1R1 q ^FINSEQ-1K8 (r ^FINSEQ-1K8 s)"
                    using A34 A37 finseq_1_th_32 sorry
                  then have A38: "<*FINSEQ-1K10 k*> =FINSEQ-1R1 r ^FINSEQ-1K8 s"
                    using finseq_1_th_33 sorry
                  have A39: "r =FINSEQ-1R1 <*FINSEQ-1K10 k*> implies q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 {t where t be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t }"
                  proof(rule impI)
                    assume A40: "r =FINSEQ-1R1 <*FINSEQ-1K10 k*>"
                    then obtain s9 where 
                      [ty]:"s9 be ElementTREES-1M2-of T" and s9Def:"s9 = q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)"
                      using A29 A37 trees_1_def_3 sorry
                    have " for p9 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p9 inTARSKIR2 P implies (p9 is-a-proper-prefix-ofTREES-1R3 s9 implies  False )"
                    proof(rule ballI,rule impI,rule impI)
                      fix p9 assume [ty]: "p9 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                      assume A41: "p9 inTARSKIR2 P"
                      assume A42: "p9 is-a-proper-prefix-ofTREES-1R3 s9"
                      have A43: "lenFINSEQ-1K4 p =HIDDENR1 lenFINSEQ-1K4 q +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 k*>)"
                        using A37 A40 finseq_1_th_22 sorry
                      also have "... = lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M"
                        using finseq_1_th_40 sorry
                      also have "... = lenFINSEQ-1K4 q +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 n*>)"
                        using finseq_1_th_40 sorry
                      also have "... = lenFINSEQ-1K4 s9"
                        using finseq_1_th_22 sorry
                      finally have "lenFINSEQ-1K4 p =HIDDENR1 lenFINSEQ-1K4 s9"
                         sorry
                      show " False "
                      proof-
                        have cases: "p9 =FINSEQ-1R1 p or p9 <>HIDDENR2 p"
                           sorry
                        have case1: "p9 =FINSEQ-1R1 p implies  False "
                        proof(rule impI)
                          assume "p9 =FINSEQ-1R1 p"
                          thus " False "
                            using A42 A43 card_2_th_102 sorry
                        qed
                        have case2: "p9 <>HIDDENR2 p implies  False "
                        proof(rule impI)
                          assume A44: "p9 <>HIDDENR2 p"
                          have "q is-a-prefix-ofTREES-1R2 p & p9 is-a-prefix-ofTREES-1R2 q"
                            using A37 A42 trees_1_th_1 trees_1_th_9 sorry
                          then have "p9 is-a-prefix-ofTREES-1R2 p"
                             sorry
                          then have "(p,p9)are-c=-comparableXBOOLE-0R3"
                             sorry
                          thus " False "
                            using A35 A41 A44 trees_1_def_10 sorry
                        qed
                        show " ?thesis "
                          using cases case1 case2 sorry
                      qed
                    qed "sorry"
                    thus "q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 {t where t be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t }"
                       sorry
                  qed
                  have "s =FINSEQ-1R1 <*FINSEQ-1K10 k*> & r =XBOOLE-0R4 {}XBOOLE-0K1 implies q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 Z"
                  proof(rule impMI ,rule impI)
                    assume A45: "s =FINSEQ-1R1 <*FINSEQ-1K10 k*>"
                      and A46: "r =XBOOLE-0R4 {}XBOOLE-0K1"
                    have "s =FINSEQ-1R1 <*>FINSEQ-1K7 NATNUMBERSK1 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s"
                      using finseq_1_th_34 sorry
                    then have "<*>FINSEQ-1K7 NATNUMBERSK1 ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T1"
                      using A29 A45 trees_1_def_3 sorry
                    then obtain t where 
                      [ty]:"t be ElementTREES-1M2-of T1" and tDef:"t = <*FINSEQ-1K10 n*>"
                      using finseq_1_th_34 sorry
                    have "q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t"
                      using A37 A46 finseq_1_th_34 sorry
                    thus "q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 Z"
                      using A4 A35 sorry
                  qed
                  thus "q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 X"
                    using A38 A39 finseq_1_th_88 xboole_0_def_3 sorry
                qed
                have "lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 q implies q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 X"
                proof(rule impI)
                  assume "lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 q"
                  then obtain r where
                    [ty]:"r be FinSequenceFINSEQ-1M1" and 
                    A47: "p ^FINSEQ-1K8 r =FINSEQ-1R1 q"
                    using A34 finseq_1_th_47 sorry
                  have "p ^FINSEQ-1K8 (r ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>)) =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s"
                    using A34 A47 finseq_1_th_32 sorry
                  then have A48: "r ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) =FINSEQ-1R1 s"
                    using finseq_1_th_33 sorry
                  then have "s  |RELAT-1K8 domFINSEQ-1K5 r =RELAT-1R1 r"
                    using finseq_1_th_21 sorry
                  then have "s  |RELAT-1K8 SegFINSEQ-1K2 (lenFINSEQ-1K4 r) =RELAT-1R1 r"
                    using finseq_1_def_3 sorry
                  then have 
                    [ty]:"r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                    using finseq_1_th_18 sorry
                  obtain t where 
                    [ty]:"t be ElementTREES-1M2-of T1" and tDef:"t = r ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)"
                    using A29 A48 trees_1_def_3 sorry
                  have "q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t"
                    using A47 finseq_1_th_32 sorry
                  then have "q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 {p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> v where p9 be ElementTREES-1M2-of T, v be ElementTREES-1M2-of T1 : p9 inTARSKIR2 P }"
                    using A35 sorry
                  thus "q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 X"
                    using A4 xboole_0_def_3 sorry
                qed
                thus "q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 X"
                  using A36 sorry
              qed
              thus "q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 X"
                using A28 A30 xboole_0_def_3 sorry
            qed "sorry"
            thus "X be Tree-likeTREES-1V1"
              using trees_1_def_3 sorry
          qed
          then have 
            [ty]:"X be TreeTREES-1M1"
             sorry
          show " ex tVar1 be TreeTREES-1M1 st  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (q inTARSKIR2 tVar1 implies q inTARSKIR2 T & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)) & (q inTARSKIR2 T & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) implies q inTARSKIR2 tVar1)"
          proof(rule bexI[of _ "X"],rule ballI,rule conjMI,rule impI)
            fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
            show "q inTARSKIR2 X implies q inTARSKIR2 T & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
            proof-
              have "q inTARSKIR2 X implies  not ( not (q inTARSKIR2 T & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-proper-prefix-ofTREES-1R3 q))) & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not ((p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)))"
              proof(rule impI)
                assume A49: "q inTARSKIR2 X"
                have A50: "q inTARSKIR2 Y implies  not ( not (q inTARSKIR2 T & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-proper-prefix-ofTREES-1R3 q))) & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not ((p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)))"
                proof(rule impI)
                  assume "q inTARSKIR2 Y"
                  then have " ex s be ElementTREES-1M2-of T st q =FINSEQ-1R1 s & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 s)"
                     sorry
                  thus " not ( not (q inTARSKIR2 T & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-proper-prefix-ofTREES-1R3 q))) & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not ((p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)))"
                     sorry
                qed
                have "q inTARSKIR2 Z implies ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
                proof(rule impI)
                  assume "q inTARSKIR2 Z"
                  then have " ex p be ElementTREES-1M2-of T st  ex s be ElementTREES-1M2-of T1 st q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s & p inTARSKIR2 P"
                    using A4 sorry
                  thus " ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
                     sorry
                qed
                thus " not ( not (q inTARSKIR2 T & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-proper-prefix-ofTREES-1R3 q))) & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not ((p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)))"
                  using A49 A50 xboole_0_def_3 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            assume A51: "q inTARSKIR2 T & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
            have A52: "q inTARSKIR2 T & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 q) implies q inTARSKIR2 {t where t be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t }"
               sorry
            have "( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) implies q inTARSKIR2 Z"
            proof(rule impI)
              assume Given: " ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
              then obtain p r where
                [ty]:"p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" "r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
                A53: "(p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
                 sorry
              have "P c=TARSKIR1 T"
                using trees_1_def_11 sorry
              thus "q inTARSKIR2 Z"
                using A4 A53 sorry
            qed
            thus "q inTARSKIR2 X"
              using A51 A52 xboole_0_def_3 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show "P <>HIDDENR2 {}XBOOLE-0K1 implies ( for it1 be TreeTREES-1M1 holds  for it2 be TreeTREES-1M1 holds ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 it1 iff q inTARSKIR2 T & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 it2 iff q inTARSKIR2 T & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "P <>HIDDENR2 {}XBOOLE-0K1"
      have A1: "P <>HIDDENR2 {}XBOOLE-0K1"
        using Assume sorry
      show " for it1 be TreeTREES-1M1 holds  for it2 be TreeTREES-1M1 holds ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 it1 iff q inTARSKIR2 T & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 it2 iff q inTARSKIR2 T & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)) implies it1 =HIDDENR1 it2"
      proof-
        have " for S1 be TreeTREES-1M1 holds  for S2 be TreeTREES-1M1 holds ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 S1 iff q inTARSKIR2 T & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 S2 iff q inTARSKIR2 T & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)) implies S1 =HIDDENR1 S2"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix S1 assume [ty]: "S1 be TreeTREES-1M1"
          fix S2 assume [ty]: "S2 be TreeTREES-1M1"
          assume A54: " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 S1 iff q inTARSKIR2 T & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
            and A55: " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 S2 iff q inTARSKIR2 T & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
          have " for x be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (x inTARSKIR2 S1 implies x inTARSKIR2 S2) & (x inTARSKIR2 S2 implies x inTARSKIR2 S1)"
          proof(rule ballI,rule conjMI,rule impI)
            fix x assume [ty]: "x be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
            show "x inTARSKIR2 S1 implies x inTARSKIR2 S2"
            proof(rule impI)
              assume A56: "x inTARSKIR2 S1"
              obtain q where 
                [ty]:"q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and qDef:"q = x"
                 sorry
              have "q inTARSKIR2 T & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
                using A54 A56 sorry
              thus "x inTARSKIR2 S2"
                using A55 sorry
            qed
            assume A57: "x inTARSKIR2 S2"
            obtain q where 
              [ty]:"q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and qDef:"q = x"
               sorry
            have "q inTARSKIR2 T & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
              using A55 A57 sorry
            thus "x inTARSKIR2 S1"
              using A54 sorry
          qed "sorry"
          thus "S1 =HIDDENR1 S2"
            using trees_2_def_1 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem trees_a_th_2:
" for T be TreeTREES-1M1 holds  for T1 be TreeTREES-1M1 holds  for P be AntiChain-of-PrefixesTREES-1M6-of T holds P <>HIDDENR2 {}XBOOLE-0K1 implies treeTREES-AK1(T,P,T1) =XBOOLE-0R4 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t1 })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P })"
proof-
  have " for T be TreeTREES-1M1 holds  for T1 be TreeTREES-1M1 holds  for P be AntiChain-of-PrefixesTREES-1M6-of T holds P <>HIDDENR2 {}XBOOLE-0K1 implies treeTREES-AK1(T,P,T1) =XBOOLE-0R4 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-proper-prefix-ofTREES-1R3 t1) })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P })"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix T assume [ty]: "T be TreeTREES-1M1"
    fix T1 assume [ty]: "T1 be TreeTREES-1M1"
    fix P assume [ty]: "P be AntiChain-of-PrefixesTREES-1M6-of T"
    assume A1: "P <>HIDDENR2 {}XBOOLE-0K1"
    have "treeTREES-AK1(T,P,T1) c=TARSKIR1 ({t where t be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P }) & ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-proper-prefix-ofTREES-1R3 t1) })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P }) c=TARSKIR1 treeTREES-AK1(T,P,T1)"
    proof(rule conjMI)
      show "treeTREES-AK1(T,P,T1) c=TARSKIR1 ({t where t be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P })"
      proof-
        have "treeTREES-AK1(T,P,T1) c=TARSKIR1 ({t where t be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-proper-prefix-ofTREES-1R3 t) })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P })"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 treeTREES-AK1(T,P,T1) implies x inHIDDENR3 ({t where t be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-proper-prefix-ofTREES-1R3 t) })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P })"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A2: "x inHIDDENR3 treeTREES-AK1(T,P,T1)"
            then obtain q where 
              [ty]:"q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and qDef:"q = x"
              using trees_1_th_19 sorry
            have A3: "( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) implies x inHIDDENR3 {p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p9 be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p9 inTARSKIR2 P }"
            proof(rule impI)
              assume Given: " ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
              then obtain p r where
                [ty]:"p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" "r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
                A4: "(p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
                 sorry
              have "P c=TARSKIR1 T"
                using trees_1_def_11 sorry
              thus "x inHIDDENR3 {p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p9 be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p9 inTARSKIR2 P }"
                using A4 sorry
            qed
            have "q inTARSKIR2 T & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 q) implies x inHIDDENR3 {t where t be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t }"
               sorry
            thus "x inHIDDENR3 ({t where t be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-proper-prefix-ofTREES-1R3 t) })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P })"
              using A1 A2 A3 trees_a_def_1 xboole_0_def_3 sorry
          qed "sorry"
          thus "treeTREES-AK1(T,P,T1) c=TARSKIR1 ({t where t be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-proper-prefix-ofTREES-1R3 t) })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P })"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 ({t where t be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P }) implies x inHIDDENR3 treeTREES-AK1(T,P,T1)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A5: "x inHIDDENR3 ({t where t be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P })"
        have A6: "x inHIDDENR3 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P } implies x inHIDDENR3 treeTREES-AK1(T,P,T1)"
        proof(rule impI)
          assume "x inHIDDENR3 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P }"
          then have " ex p be ElementTREES-1M2-of T st  ex s be ElementTREES-1M2-of T1 st x =HIDDENR1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s & p inTARSKIR2 P"
             sorry
          thus "x inHIDDENR3 treeTREES-AK1(T,P,T1)"
            using trees_a_def_1 sorry
        qed
        have "x inHIDDENR3 {t where t be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t } implies x inHIDDENR3 treeTREES-AK1(T,P,T1)"
        proof(rule impI)
          assume "x inHIDDENR3 {t where t be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t }"
          then have " ex t be ElementTREES-1M2-of T st x =HIDDENR1 t & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t)"
             sorry
          thus "x inHIDDENR3 treeTREES-AK1(T,P,T1)"
            using A1 trees_a_def_1 sorry
        qed
        thus "x inHIDDENR3 treeTREES-AK1(T,P,T1)"
          using A5 A6 xboole_0_def_3 sorry
      qed "sorry"
      thus "({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-proper-prefix-ofTREES-1R3 t1) })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P }) c=TARSKIR1 treeTREES-AK1(T,P,T1)"
        using tarski_def_3 sorry
    qed
    thus "treeTREES-AK1(T,P,T1) =XBOOLE-0R4 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-proper-prefix-ofTREES-1R3 t1) })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P })"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_a_th_3:
" for T be TreeTREES-1M1 holds  for P be AntiChain-of-PrefixesTREES-1M6-of T holds {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 } c=TARSKIR1 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t1 }"
proof-
  have " for T be TreeTREES-1M1 holds  for P be AntiChain-of-PrefixesTREES-1M6-of T holds {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-prefix-ofTREES-1R2 t1) } c=TARSKIR1 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-proper-prefix-ofTREES-1R3 t1) }"
  proof(rule ballI,rule ballI)
    fix T assume [ty]: "T be TreeTREES-1M1"
    fix P assume [ty]: "P be AntiChain-of-PrefixesTREES-1M6-of T"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 } implies x inHIDDENR3 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-proper-prefix-ofTREES-1R3 t1) }"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 }"
      then obtain t9 where
        [ty]:"t9 be ElementTREES-1M2-of T" and 
        A1: "x =HIDDENR1 t9"and A2: " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t9"
         sorry
      have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t9"
        using A2 sorry
      thus "x inHIDDENR3 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-proper-prefix-ofTREES-1R3 t1) }"
        using A1 sorry
    qed "sorry"
    thus "{t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-prefix-ofTREES-1R2 t1) } c=TARSKIR1 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-proper-prefix-ofTREES-1R3 t1) }"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_a_th_4:
" for T be TreeTREES-1M1 holds  for P be AntiChain-of-PrefixesTREES-1M6-of T holds P c=TARSKIR1 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t1 }"
proof-
  have " for T be TreeTREES-1M1 holds  for P be AntiChain-of-PrefixesTREES-1M6-of T holds P c=TARSKIR1 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-proper-prefix-ofTREES-1R3 t1) }"
  proof(rule ballI,rule ballI)
    fix T assume [ty]: "T be TreeTREES-1M1"
    fix P assume [ty]: "P be AntiChain-of-PrefixesTREES-1M6-of T"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 P implies x inHIDDENR3 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-proper-prefix-ofTREES-1R3 t1) }"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A1: "x inHIDDENR3 P"
      have " ex t1 be ElementTREES-1M2-of T st x =HIDDENR1 t1 & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t1)"
      proof-
        have " not ( for t1 be ElementTREES-1M2-of T holds  not (x =HIDDENR1 t1 & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-proper-prefix-ofTREES-1R3 t1))))"
        proof-
          have "P c=TARSKIR1 T"
            using trees_1_def_11 sorry
          then obtain t9 where
            [ty]:"t9 be ElementTREES-1M2-of T" and 
            A2: "t9 =HIDDENR1 x"
            using A1 sorry
          have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t9"
          proof(rule ballI,rule impI)
            fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
            assume A3: "p inTARSKIR2 P"
            show " not p is-a-proper-prefix-ofTREES-1R3 t9"
            proof-
              have cases: "t9 =FINSEQ-1R1 p or t9 <>HIDDENR2 p"
                 sorry
              have case1: "t9 =FINSEQ-1R1 p implies  not p is-a-proper-prefix-ofTREES-1R3 t9"
              proof(rule impI)
                assume "t9 =FINSEQ-1R1 p"
                thus " not p is-a-proper-prefix-ofTREES-1R3 t9"
                   sorry
              qed
              have case2: "t9 <>HIDDENR2 p implies  not p is-a-proper-prefix-ofTREES-1R3 t9"
              proof(rule impI)
                assume "t9 <>HIDDENR2 p"
                then have " not (t9,p)are-c=-comparableXBOOLE-0R3"
                  using A1 A2 A3 trees_1_def_10 sorry
                thus " not p is-a-proper-prefix-ofTREES-1R3 t9"
                   sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed "sorry"
          thus " not ( for t1 be ElementTREES-1M2-of T holds  not (x =HIDDENR1 t1 & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-proper-prefix-ofTREES-1R3 t1))))"
            using A2 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      thus "x inHIDDENR3 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-proper-prefix-ofTREES-1R3 t1) }"
         sorry
    qed "sorry"
    thus "P c=TARSKIR1 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-proper-prefix-ofTREES-1R3 t1) }"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_a_th_5:
" for T be TreeTREES-1M1 holds  for P be AntiChain-of-PrefixesTREES-1M6-of T holds ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t1 })\\SUBSET-1K6 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 }) =XBOOLE-0R4 P"
proof-
  have " for T be TreeTREES-1M1 holds  for P be AntiChain-of-PrefixesTREES-1M6-of T holds ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-proper-prefix-ofTREES-1R3 t1) })\\SUBSET-1K6 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-prefix-ofTREES-1R2 t1) }) =XBOOLE-0R4 P"
  proof(rule ballI,rule ballI)
    fix T assume [ty]: "T be TreeTREES-1M1"
    fix P assume [ty]: "P be AntiChain-of-PrefixesTREES-1M6-of T"
    have Cut468: " for x be objectHIDDENM1 holds x inHIDDENR3 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t1 })\\SUBSET-1K6 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 }) implies ( not x inHIDDENR3 P implies  False )"
    proof(rule ballI,rule impI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A1: "x inHIDDENR3 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t1 })\\SUBSET-1K6 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 })"
      then have A2: "x inHIDDENR3 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t1 }"
         sorry
      have A3: " not x inHIDDENR3 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 }"
        using A1 xboole_0_def_5 sorry
      assume A4: " not x inHIDDENR3 P"
      have " ex t1 be ElementTREES-1M2-of T st x =HIDDENR1 t1 & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1)"
      proof-
        have " not ( for t1 be ElementTREES-1M2-of T holds  not (x =HIDDENR1 t1 & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-prefix-ofTREES-1R2 t1))))"
        proof-
          obtain t9 where
            [ty]:"t9 be ElementTREES-1M2-of T" and 
            A5: "x =HIDDENR1 t9"and A6: " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t9"
            using A2 sorry
          have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t9"
          proof(rule ballI,rule impI)
            fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
            assume A7: "p inTARSKIR2 P"
            then have A8: " not p is-a-proper-prefix-ofTREES-1R3 t9"
              using A6 sorry
            show " not p is-a-prefix-ofTREES-1R2 t9"
            proof-
              have cases: " not p is-a-prefix-ofTREES-1R2 t9 or p =FINSEQ-1R1 t9"
                using A8 sorry
              have case1: " not p is-a-prefix-ofTREES-1R2 t9 implies  not p is-a-prefix-ofTREES-1R2 t9"
              proof(rule impI)
                assume " not p is-a-prefix-ofTREES-1R2 t9"
                thus " not p is-a-prefix-ofTREES-1R2 t9"
                   sorry
              qed
              have case2: "p =FINSEQ-1R1 t9 implies  not p is-a-prefix-ofTREES-1R2 t9"
              proof(rule impI)
                assume "p =FINSEQ-1R1 t9"
                thus " not p is-a-prefix-ofTREES-1R2 t9"
                  using A4 A5 A7 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed "sorry"
          thus " not ( for t1 be ElementTREES-1M2-of T holds  not (x =HIDDENR1 t1 & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-prefix-ofTREES-1R2 t1))))"
            using A5 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      thus " False "
        using A3 sorry
    qed "sorry"
    have "({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t1 })\\SUBSET-1K6 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 }) c=TARSKIR1 P & P c=TARSKIR1 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-proper-prefix-ofTREES-1R3 t1) })\\SUBSET-1K6 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-prefix-ofTREES-1R2 t1) })"
    proof(rule conjMI)
      show "({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t1 })\\SUBSET-1K6 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 }) c=TARSKIR1 P"
        using Cut468 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 P implies x inHIDDENR3 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-proper-prefix-ofTREES-1R3 t1) })\\SUBSET-1K6 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-prefix-ofTREES-1R2 t1) })"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A9: "x inHIDDENR3 P"
        have A10: "P c=TARSKIR1 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t1 }"
          using trees_a_th_4 sorry
        have " not x inHIDDENR3 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 }"
        proof-
          have "x inHIDDENR3 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 } implies  False "
          proof(rule impI)
            assume "x inHIDDENR3 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 }"
            then have " ex t9 be ElementTREES-1M2-of T st x =HIDDENR1 t9 & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t9)"
               sorry
            thus " False "
              using A9 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        thus "x inHIDDENR3 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-proper-prefix-ofTREES-1R3 t1) })\\SUBSET-1K6 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-prefix-ofTREES-1R2 t1) })"
          using A9 A10 xboole_0_def_5 sorry
      qed "sorry"
      thus "P c=TARSKIR1 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-proper-prefix-ofTREES-1R3 t1) })\\SUBSET-1K6 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-prefix-ofTREES-1R2 t1) })"
        using tarski_def_3 sorry
    qed
    thus "({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-proper-prefix-ofTREES-1R3 t1) })\\SUBSET-1K6 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-prefix-ofTREES-1R2 t1) }) =XBOOLE-0R4 P"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_a_th_6:
" for T be TreeTREES-1M1 holds  for T1 be TreeTREES-1M1 holds  for P be AntiChain-of-PrefixesTREES-1M6-of T holds P c=TARSKIR1 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P }"
proof(rule ballI,rule ballI,rule ballI)
  fix T assume [ty]: "T be TreeTREES-1M1"
  fix T1 assume [ty]: "T1 be TreeTREES-1M1"
  fix P assume [ty]: "P be AntiChain-of-PrefixesTREES-1M6-of T"
  have " for x be objectHIDDENM1 holds x inHIDDENR3 P implies x inHIDDENR3 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P }"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "x inHIDDENR3 P"
    have "P c=TARSKIR1 T"
      using trees_1_def_11 sorry
    then obtain q where
      [ty]:"q be ElementTREES-1M2-of T" and 
      A2: "q =HIDDENR1 x"
      using A1 sorry
    have "<*>FINSEQ-1K7 NATNUMBERSK1 inTARSKIR2 T1"
      using trees_1_th_22 sorry
    then obtain s9 where
      [ty]:"s9 be ElementTREES-1M2-of T1" and 
      A3: "s9 =FINSEQ-1R1 <*>FINSEQ-1K7 NATNUMBERSK1"
       sorry
    have "q =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s9"
      using A3 finseq_1_th_34 sorry
    thus "x inHIDDENR3 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P }"
      using A1 A2 sorry
  qed "sorry"
  thus "P c=TARSKIR1 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P }"
     sorry
qed "sorry"

mtheorem trees_a_th_7:
" for T be TreeTREES-1M1 holds  for T1 be TreeTREES-1M1 holds  for P be AntiChain-of-PrefixesTREES-1M6-of T holds P <>HIDDENR2 {}XBOOLE-0K1 implies treeTREES-AK1(T,P,T1) =XBOOLE-0R4 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P })"
proof-
  have " for T be TreeTREES-1M1 holds  for T1 be TreeTREES-1M1 holds  for P be AntiChain-of-PrefixesTREES-1M6-of T holds P <>HIDDENR2 {}XBOOLE-0K1 implies treeTREES-AK1(T,P,T1) =XBOOLE-0R4 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-prefix-ofTREES-1R2 t1) })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P })"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix T assume [ty]: "T be TreeTREES-1M1"
    fix T1 assume [ty]: "T1 be TreeTREES-1M1"
    fix P assume [ty]: "P be AntiChain-of-PrefixesTREES-1M6-of T"
    assume A1: "P <>HIDDENR2 {}XBOOLE-0K1"
    then have A2: "treeTREES-AK1(T,P,T1) =XBOOLE-0R4 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t1 })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P })"
      using trees_a_th_2 sorry
    have "treeTREES-AK1(T,P,T1) c=TARSKIR1 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P }) & ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-prefix-ofTREES-1R2 t1) })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P }) c=TARSKIR1 treeTREES-AK1(T,P,T1)"
    proof(rule conjMI)
      show "treeTREES-AK1(T,P,T1) c=TARSKIR1 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P })"
      proof-
        have "treeTREES-AK1(T,P,T1) c=TARSKIR1 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-prefix-ofTREES-1R2 t1) })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P })"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 treeTREES-AK1(T,P,T1) implies x inHIDDENR3 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-prefix-ofTREES-1R2 t1) })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P })"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 treeTREES-AK1(T,P,T1)"
            then have A3: "x inHIDDENR3 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t1 })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P })"
              using A1 trees_a_th_2 sorry
            have "x inHIDDENR3 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 } or x inHIDDENR3 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P }"
            proof-
              show "x inHIDDENR3 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 } or x inHIDDENR3 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P }"
              proof-
                have cases: "x inHIDDENR3 P or  not x inHIDDENR3 P"
                   sorry
                have case1: "x inHIDDENR3 P implies x inHIDDENR3 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 } or x inHIDDENR3 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P }"
                proof(rule impI)
                  assume A4: "x inHIDDENR3 P"
                  have "P c=TARSKIR1 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P }"
                    using trees_a_th_6 sorry
                  thus "x inHIDDENR3 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 } or x inHIDDENR3 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P }"
                    using A4 sorry
                qed
                have case2: " not x inHIDDENR3 P implies x inHIDDENR3 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 } or x inHIDDENR3 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P }"
                proof(rule impI)
                  assume A5: " not x inHIDDENR3 P"
                  have "x inHIDDENR3 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 } or x inHIDDENR3 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P }"
                  proof-
                    show "x inHIDDENR3 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 } or x inHIDDENR3 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P }"
                    proof-
                      have cases: "x inHIDDENR3 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t1 } or x inHIDDENR3 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P }"
                        using A3 xboole_0_def_3 sorry
                      have case1: "x inHIDDENR3 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t1 } implies x inHIDDENR3 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 } or x inHIDDENR3 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P }"
                      proof(rule impI)
                        assume A6: "x inHIDDENR3 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t1 }"
                        have "x inHIDDENR3 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 }"
                        proof-
                          have " not x inHIDDENR3 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 } implies  False "
                          proof(rule impI)
                            assume A7: " not x inHIDDENR3 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 }"
                            have "({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t1 })\\SUBSET-1K6 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 }) =XBOOLE-0R4 P"
                              using trees_a_th_5 sorry
                            thus " False "
                              using A5 A6 A7 xboole_0_def_5 sorry
                          qed
                          thus " ?thesis "
                             sorry
                        qed
                        thus "x inHIDDENR3 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 } or x inHIDDENR3 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P }"
                           sorry
                      qed
                      have case2: "x inHIDDENR3 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P } implies x inHIDDENR3 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 } or x inHIDDENR3 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P }"
                      proof(rule impI)
                        assume "x inHIDDENR3 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P }"
                        thus "x inHIDDENR3 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 } or x inHIDDENR3 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P }"
                           sorry
                      qed
                      show " ?thesis "
                        using cases case1 case2 sorry
                    qed
                  qed
                  thus "x inHIDDENR3 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 } or x inHIDDENR3 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P }"
                     sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "x inHIDDENR3 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-prefix-ofTREES-1R2 t1) })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P })"
              using xboole_0_def_3 sorry
          qed "sorry"
          thus "treeTREES-AK1(T,P,T1) c=TARSKIR1 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-prefix-ofTREES-1R2 t1) })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P })"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      show "({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-prefix-ofTREES-1R2 t1) })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P }) c=TARSKIR1 treeTREES-AK1(T,P,T1)"
        using A2 trees_a_th_3 xboole_1_th_9 sorry
    qed
    thus "treeTREES-AK1(T,P,T1) =XBOOLE-0R4 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P & p is-a-prefix-ofTREES-1R2 t1) })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P })"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_a_th_8:
" for T be TreeTREES-1M1 holds  for T1 be TreeTREES-1M1 holds  for P be AntiChain-of-PrefixesTREES-1M6-of T holds  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies T1 =TREES-2R1 (treeTREES-AK1(T,P,T1)) |TREES-1K4 p"
proof-
  have " for T be TreeTREES-1M1 holds  for T1 be TreeTREES-1M1 holds  for P be AntiChain-of-PrefixesTREES-1M6-of T holds  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies T1 =TREES-2R1 (treeTREES-AK1(T,P,T1)) |TREES-1K4 p"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix T assume [ty]: "T be TreeTREES-1M1"
    fix T1 assume [ty]: "T1 be TreeTREES-1M1"
    fix P assume [ty]: "P be AntiChain-of-PrefixesTREES-1M6-of T"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    assume A1: "p inTARSKIR2 P"
    have " ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (q inTARSKIR2 P & r inTARSKIR2 T1) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
    proof-
      have " not ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not ((q inTARSKIR2 P & r inTARSKIR2 T1) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r))"
      proof-
        obtain q where
          [ty]:"q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
          A2: "q =FINSEQ-1R1 p"
           sorry
        obtain r where
          [ty]:"r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
          A3: "r =FINSEQ-1R1 <*>FINSEQ-1K7 NATNUMBERSK1"
           sorry
        have A4: "r inTARSKIR2 T1"
          using A3 trees_1_th_22 sorry
        have "p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
          using A2 A3 finseq_1_th_34 sorry
        thus " not ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not ((q inTARSKIR2 P & r inTARSKIR2 T1) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r))"
          using A1 A2 A4 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    then have A5: "p inTARSKIR2 treeTREES-AK1(T,P,T1)"
      using trees_a_def_1 sorry
    have " for x be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (x inTARSKIR2 T1 implies x inTARSKIR2 (treeTREES-AK1(T,P,T1)) |TREES-1K4 p) & (x inTARSKIR2 (treeTREES-AK1(T,P,T1)) |TREES-1K4 p implies x inTARSKIR2 T1)"
    proof(rule ballI,rule conjMI)
      fix x assume [ty]: "x be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
      show "x inTARSKIR2 T1 implies x inTARSKIR2 (treeTREES-AK1(T,P,T1)) |TREES-1K4 p"
      proof(rule impI)
        assume "x inTARSKIR2 T1"
        then have "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> x inTARSKIR2 treeTREES-AK1(T,P,T1)"
          using A1 trees_a_def_1 sorry
        thus "x inTARSKIR2 (treeTREES-AK1(T,P,T1)) |TREES-1K4 p"
          using A5 trees_1_def_6 sorry
      qed
      show "x inTARSKIR2 (treeTREES-AK1(T,P,T1)) |TREES-1K4 p implies x inTARSKIR2 T1"
      proof(rule impI)
        assume "x inTARSKIR2 (treeTREES-AK1(T,P,T1)) |TREES-1K4 p"
        then have A6: "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> x inTARSKIR2 treeTREES-AK1(T,P,T1)"
          using A5 trees_1_def_6 sorry
        have A7: "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> x inTARSKIR2 T & ( for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds r inTARSKIR2 P implies  not r is-a-proper-prefix-ofTREES-1R3 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> x) implies x inTARSKIR2 T1"
        proof(rule impMI ,rule impI)
          assume "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> x inTARSKIR2 T"
            and A8: " for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds r inTARSKIR2 P implies  not r is-a-proper-prefix-ofTREES-1R3 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> x"
          have A9: " not p is-a-proper-prefix-ofTREES-1R3 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> x"
            using A1 A8 sorry
          have "p is-a-prefix-ofTREES-1R2 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> x"
            using trees_1_th_1 sorry
          then have "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> x =HIDDENR1 p"
            using A9 sorry
          also have "... = p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> <*>FINSEQ-1K7 NATNUMBERSK1"
            using finseq_1_th_34 sorry
          finally have "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> x =HIDDENR1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> <*>FINSEQ-1K7 NATNUMBERSK1"
             sorry
          then have "x =XBOOLE-0R4 {}XBOOLE-0K1"
            using finseq_1_th_33 sorry
          thus "x inTARSKIR2 T1"
            using trees_1_th_22 sorry
        qed
        have "( ex s be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (s inTARSKIR2 P & r inTARSKIR2 T1) & p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> x =FINSEQ-1R1 s ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) implies x inTARSKIR2 T1"
        proof(rule impI)
          assume Given: " ex s be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (s inTARSKIR2 P & r inTARSKIR2 T1) & p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> x =FINSEQ-1R1 s ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
          then obtain s r where
            [ty]:"s be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" "r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
            A10: "s inTARSKIR2 P"and A11: "r inTARSKIR2 T1"and A12: "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> x =FINSEQ-1R1 s ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
             sorry
          have "s <>HIDDENR2 p implies  False "
          proof(rule impI)
            assume "s <>HIDDENR2 p"
            then have " not (s,p)are-c=-comparableXBOOLE-0R3"
              using A1 A10 trees_1_def_10 sorry
            thus " False "
              using A12 trees_a_th_1 sorry
          qed
          thus "x inTARSKIR2 T1"
            using A11 A12 finseq_1_th_33 sorry
        qed
        thus "x inTARSKIR2 T1"
          using A1 A6 A7 trees_a_def_1 sorry
      qed
    qed "sorry"
    thus "T1 =TREES-2R1 (treeTREES-AK1(T,P,T1)) |TREES-1K4 p"
      using trees_2_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_a_cl_1:
  mlet "T be TreeTREES-1M1"
"cluster  non emptyXBOOLE-0V1 for AntiChain-of-PrefixesTREES-1M6-of T"
proof
(*existence*)
  show " ex it be AntiChain-of-PrefixesTREES-1M6-of T st it be  non emptyXBOOLE-0V1"
  proof-
    have " ex tVar2 be AntiChain-of-PrefixesTREES-1M6-of T st  not tVar2 be emptyXBOOLE-0V1"
    proof-
      let ?w = "the ElementTREES-1M2-of T"
      obtain X where
        [ty]:"X be setHIDDENM2" and 
        A1: "X =XBOOLE-0R4 {TARSKIK1 ?w}"
         sorry
      have A2: "X be AntiChain-of-Prefixes-likeTREES-1V2"
        using A1 trees_1_th_36 sorry
      have "X c=TARSKIR1 T"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 T"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 X"
          then have "x =HIDDENR1 ?w"
            using A1 tarski_def_1 sorry
          thus "x inHIDDENR3 T"
             sorry
        qed "sorry"
        thus "X c=TARSKIR1 T"
          using tarski_def_3 sorry
      qed
      then have 
        [ty]:"X be AntiChain-of-PrefixesTREES-1M6-of T"
        using A2 trees_1_def_11 sorry
      show " ex tVar2 be AntiChain-of-PrefixesTREES-1M6-of T st  not tVar2 be emptyXBOOLE-0V1"
      proof(rule bexI[of _ "X"])
        show " not X be emptyXBOOLE-0V1"
          using A1 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax TREES_AK2 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("{TREES-AK2\<^bsub>'( _ ')\<^esub>  _ }" [0,0]356)
translations "{TREES-AK2\<^bsub>(T)\<^esub> t}" \<rightharpoonup> "{TARSKIK1 t}"

mtheorem trees_a_add_1:
  mlet "T be TreeTREES-1M1", "t be ElementTREES-1M2-of T"
"cluster {TARSKIK1 t} as-term-is AntiChain-of-PrefixesTREES-1M6-of T"
proof
(*coherence*)
  show "{TARSKIK1 t} be AntiChain-of-PrefixesTREES-1M6-of T"
    using trees_1_th_39 sorry
qed "sorry"

mtheorem trees_a_th_9:
" for T be TreeTREES-1M1 holds  for T1 be TreeTREES-1M1 holds  for t be ElementTREES-1M2-of T holds treeTREES-AK1(T,{TREES-AK2\<^bsub>(T)\<^esub> t},T1) =TREES-2R1 T with-replacementTREES-1K5(t,T1)"
proof-
  have " for T be TreeTREES-1M1 holds  for T1 be TreeTREES-1M1 holds  for t be ElementTREES-1M2-of T holds treeTREES-AK1(T,{TREES-AK2\<^bsub>(T)\<^esub> t},T1) =TREES-2R1 T with-replacementTREES-1K5(t,T1)"
  proof(rule ballI,rule ballI,rule ballI)
    fix T assume [ty]: "T be TreeTREES-1M1"
    fix T1 assume [ty]: "T1 be TreeTREES-1M1"
    fix t assume [ty]: "t be ElementTREES-1M2-of T"
    have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (p inTARSKIR2 treeTREES-AK1(T,{TREES-AK2\<^bsub>(T)\<^esub> t},T1) implies p inTARSKIR2 T with-replacementTREES-1K5(t,T1)) & (p inTARSKIR2 T with-replacementTREES-1K5(t,T1) implies p inTARSKIR2 treeTREES-AK1(T,{TREES-AK2\<^bsub>(T)\<^esub> t},T1))"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
      show "p inTARSKIR2 treeTREES-AK1(T,{TREES-AK2\<^bsub>(T)\<^esub> t},T1) implies p inTARSKIR2 T with-replacementTREES-1K5(t,T1)"
      proof(rule impI)
        assume A1: "p inTARSKIR2 treeTREES-AK1(T,{TREES-AK2\<^bsub>(T)\<^esub> t},T1)"
        have A2: "p inTARSKIR2 T & ( for s be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds s inTARSKIR2 {TREES-AK2\<^bsub>(T)\<^esub> t} implies  not s is-a-proper-prefix-ofTREES-1R3 p) implies p inTARSKIR2 T &  not t is-a-proper-prefix-ofTREES-1R3 p"
        proof(rule impI)
          assume A3: "p inTARSKIR2 T & ( for s be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds s inTARSKIR2 {TREES-AK2\<^bsub>(T)\<^esub> t} implies  not s is-a-proper-prefix-ofTREES-1R3 p)"
          have "t inTARSKIR2 {TREES-AK2\<^bsub>(T)\<^esub> t}"
            using tarski_def_1 sorry
          thus "p inTARSKIR2 T &  not t is-a-proper-prefix-ofTREES-1R3 p"
            using A3 sorry
        qed
        have "( ex s be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (s inTARSKIR2 {TREES-AK2\<^bsub>(T)\<^esub> t} & r inTARSKIR2 T1) & p =FINSEQ-1R1 s ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) implies ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 T1 & p =FINSEQ-1R1 t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
        proof(rule impI)
          assume Given: " ex s be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (s inTARSKIR2 {TREES-AK2\<^bsub>(T)\<^esub> t} & r inTARSKIR2 T1) & p =FINSEQ-1R1 s ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
          then obtain s where
            [ty]:"s be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
            A4: " ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (s inTARSKIR2 {TREES-AK2\<^bsub>(T)\<^esub> t} & r inTARSKIR2 T1) & p =FINSEQ-1R1 s ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
             sorry
          have "s =FINSEQ-1R1 t"
            using A4 tarski_def_1 sorry
          thus " ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 T1 & p =FINSEQ-1R1 t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
            using A4 sorry
        qed
        thus "p inTARSKIR2 T with-replacementTREES-1K5(t,T1)"
          using A1 A2 trees_a_def_1 trees_1_def_9 sorry
      qed
      assume A5: "p inTARSKIR2 T with-replacementTREES-1K5(t,T1)"
      have A6: "p inTARSKIR2 T &  not t is-a-proper-prefix-ofTREES-1R3 p implies p inTARSKIR2 T & ( for s be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds s inTARSKIR2 {TREES-AK2\<^bsub>(T)\<^esub> t} implies  not s is-a-proper-prefix-ofTREES-1R3 p)"
        using tarski_def_1 sorry
      have "( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 T1 & p =FINSEQ-1R1 t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) implies ( ex s be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (s inTARSKIR2 {TREES-AK2\<^bsub>(T)\<^esub> t} & r inTARSKIR2 T1) & p =FINSEQ-1R1 s ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
      proof(rule impI)
        assume A7: " ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 T1 & p =FINSEQ-1R1 t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
        show " ex s be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (s inTARSKIR2 {TREES-AK2\<^bsub>(T)\<^esub> t} & r inTARSKIR2 T1) & p =FINSEQ-1R1 s ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
        proof-
          have " ex tVar3 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  not ( for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not ((tVar3 inTARSKIR2 {TREES-AK2\<^bsub>(T)\<^esub> tVar3} & r inTARSKIR2 T1) & p =FINSEQ-1R1 tVar3 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r))"
          proof-
            show " ex tVar3 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  not ( for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not ((tVar3 inTARSKIR2 {TREES-AK2\<^bsub>(T)\<^esub> tVar3} & r inTARSKIR2 T1) & p =FINSEQ-1R1 tVar3 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r))"
            proof(rule bexI[of _ "t"])
              have "t inTARSKIR2 {TREES-AK2\<^bsub>(T)\<^esub> t}"
                using tarski_def_1 sorry
              thus " not ( for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not ((t inTARSKIR2 {TREES-AK2\<^bsub>(T)\<^esub> t} & r inTARSKIR2 T1) & p =FINSEQ-1R1 t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r))"
                using A7 sorry
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
      qed
      thus "p inTARSKIR2 treeTREES-AK1(T,{TREES-AK2\<^bsub>(T)\<^esub> t},T1)"
        using A5 A6 trees_a_def_1 trees_1_def_9 sorry
    qed "sorry"
    thus "treeTREES-AK1(T,{TREES-AK2\<^bsub>(T)\<^esub> t},T1) =TREES-2R1 T with-replacementTREES-1K5(t,T1)"
      using trees_2_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve T, T1 for "DecoratedTreeTREES-2M4"
reserve P for "AntiChain-of-PrefixesTREES-1M6-of domRELAT-1K1 T"
reserve t for "ElementTREES-1M2-of domRELAT-1K1 T"
reserve p1, p2, r1, r2 for "FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
mdef trees_a_def_2 ("treeTREES-AK3'( _ , _ , _ ')" [0,0,0]164 ) where
  mlet "T be DecoratedTreeTREES-2M4", "P be AntiChain-of-PrefixesTREES-1M6-of domRELAT-1K1 T", "T1 be DecoratedTreeTREES-2M4"
"assume P <>HIDDENR2 {}XBOOLE-0K1 func treeTREES-AK3(T,P,T1) \<rightarrow> DecoratedTreeTREES-2M4 means
  \<lambda>it. domRELAT-1K1 it =TREES-2R1 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1) implies ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & it .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & it .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))"
proof-
  (*existence*)
    show "P <>HIDDENR2 {}XBOOLE-0K1 implies ( ex it be DecoratedTreeTREES-2M4 st domRELAT-1K1 it =TREES-2R1 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1) implies ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & it .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & it .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r)))"
    proof(rule impI)
      assume Assume: "P <>HIDDENR2 {}XBOOLE-0K1"
      have A1: "P <>HIDDENR2 {}XBOOLE-0K1"
        using Assume sorry
      show " ex it be DecoratedTreeTREES-2M4 st domRELAT-1K1 it =TREES-2R1 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1) implies ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & it .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & it .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))"
      proof-
        have " ex T0 be DecoratedTreeTREES-2M4 st domRELAT-1K1 T0 =TREES-2R1 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1) & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1) implies ( for pc be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds pc inTARSKIR2 P implies  not pc is-a-prefix-ofTREES-1R2 p & T0 .FUNCT-1K1 p =XBOOLE-0R4 T .FUNCT-1K1 p) or ( ex pc be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((pc inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & p =FINSEQ-1R1 pc ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & T0 .FUNCT-1K1 p =XBOOLE-0R4 T1 .FUNCT-1K1 r))"
        proof-
          let ?X = "\<lambda>Lamb1. \<lambda>Lamb2. ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 Lamb1 & Lamb2 =XBOOLE-0R4 T .FUNCT-1K1 Lamb1) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & Lamb1 =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & Lamb2 =XBOOLE-0R4 T1 .FUNCT-1K1 r)"
          have A2: " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1) implies ( ex x be setHIDDENM2 st ?X(q,x))"
          proof-
            have " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1) implies  not ( for x be setHIDDENM2 holds  not (( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & x =XBOOLE-0R4 T .FUNCT-1K1 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & x =XBOOLE-0R4 T1 .FUNCT-1K1 r)))"
            proof(rule ballI,rule impI)
              fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
              assume "q inTARSKIR2 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1)"
              then have A3: "q inTARSKIR2 ({t where t be ElementTREES-1M2-of domRELAT-1K1 T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of domRELAT-1K1 T, s be ElementTREES-1M2-of domRELAT-1K1 T1 : p inTARSKIR2 P })"
                using A1 trees_a_th_7 sorry
              have A4: "q inTARSKIR2 {t where t be ElementTREES-1M2-of domRELAT-1K1 T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t } implies ( ex x be setHIDDENM2 st  not ( for x be setHIDDENM2 holds  not (( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & x =XBOOLE-0R4 T .FUNCT-1K1 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & x =XBOOLE-0R4 T1 .FUNCT-1K1 r))))"
              proof(rule impI)
                assume "q inTARSKIR2 {t where t be ElementTREES-1M2-of domRELAT-1K1 T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t }"
                then obtain t where
                  [ty]:"t be ElementTREES-1M2-of domRELAT-1K1 T" and 
                  A5: "q =FINSEQ-1R1 t & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t)"
                   sorry
                obtain x where 
                  [ty]:"x be setHIDDENM2" and xDef:"x = T .FUNCT-1K1 t"
                   sorry
                show " ex x be setHIDDENM2 st  not ( for x be setHIDDENM2 holds  not (( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & x =XBOOLE-0R4 T .FUNCT-1K1 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & x =XBOOLE-0R4 T1 .FUNCT-1K1 r)))"
                proof(rule bexI[of _ "x"])
                  have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & x =XBOOLE-0R4 T .FUNCT-1K1 q"
                    using A5 sorry
                  thus " not ( for x be setHIDDENM2 holds  not (( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & x =XBOOLE-0R4 T .FUNCT-1K1 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & x =XBOOLE-0R4 T1 .FUNCT-1K1 r)))"
                     sorry
                qed "sorry"
              qed
              have "q inTARSKIR2 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of domRELAT-1K1 T, s be ElementTREES-1M2-of domRELAT-1K1 T1 : p inTARSKIR2 P } implies ( ex x be setHIDDENM2 st  not ( for x be setHIDDENM2 holds  not (( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & x =XBOOLE-0R4 T .FUNCT-1K1 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & x =XBOOLE-0R4 T1 .FUNCT-1K1 r))))"
              proof(rule impI)
                assume "q inTARSKIR2 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of domRELAT-1K1 T, s be ElementTREES-1M2-of domRELAT-1K1 T1 : p inTARSKIR2 P }"
                then obtain p s where
                  [ty]:"p be ElementTREES-1M2-of domRELAT-1K1 T" "s be ElementTREES-1M2-of domRELAT-1K1 T1" and 
                  A6: "q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s & p inTARSKIR2 P"
                   sorry
                obtain x where 
                  [ty]:"x be setHIDDENM2" and xDef:"x = T1 .FUNCT-1K1 s"
                   sorry
                show " ex x be setHIDDENM2 st  not ( for x be setHIDDENM2 holds  not (( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & x =XBOOLE-0R4 T .FUNCT-1K1 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & x =XBOOLE-0R4 T1 .FUNCT-1K1 r)))"
                proof(rule bexI[of _ "x"])
                  have "( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & x =XBOOLE-0R4 T .FUNCT-1K1 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & x =XBOOLE-0R4 T1 .FUNCT-1K1 r)"
                    using A6 sorry
                  thus " not ( for x be setHIDDENM2 holds  not (( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & x =XBOOLE-0R4 T .FUNCT-1K1 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & x =XBOOLE-0R4 T1 .FUNCT-1K1 r)))"
                     sorry
                qed "sorry"
              qed
              thus " not ( for x be setHIDDENM2 holds  not (( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & x =XBOOLE-0R4 T .FUNCT-1K1 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & x =XBOOLE-0R4 T1 .FUNCT-1K1 r)))"
                using A3 A4 xboole_0_def_3 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          show " ex T0 be DecoratedTreeTREES-2M4 st domRELAT-1K1 T0 =TREES-2R1 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1) & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1) implies ( for pc be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds pc inTARSKIR2 P implies  not pc is-a-prefix-ofTREES-1R2 p & T0 .FUNCT-1K1 p =XBOOLE-0R4 T .FUNCT-1K1 p) or ( ex pc be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((pc inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & p =FINSEQ-1R1 pc ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & T0 .FUNCT-1K1 p =XBOOLE-0R4 T1 .FUNCT-1K1 r))"
            using trees_2_sch_6 A2 sorry
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show "P <>HIDDENR2 {}XBOOLE-0K1 implies ( for it1 be DecoratedTreeTREES-2M4 holds  for it2 be DecoratedTreeTREES-2M4 holds (domRELAT-1K1 it1 =TREES-2R1 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1) implies ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & it1 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & it1 .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))) & (domRELAT-1K1 it2 =TREES-2R1 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1) implies ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & it2 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & it2 .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "P <>HIDDENR2 {}XBOOLE-0K1"
      have A1: "P <>HIDDENR2 {}XBOOLE-0K1"
        using Assume sorry
      show " for it1 be DecoratedTreeTREES-2M4 holds  for it2 be DecoratedTreeTREES-2M4 holds (domRELAT-1K1 it1 =TREES-2R1 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1) implies ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & it1 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & it1 .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))) & (domRELAT-1K1 it2 =TREES-2R1 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1) implies ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & it2 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & it2 .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))) implies it1 =HIDDENR1 it2"
      proof-
        have " for D1 be DecoratedTreeTREES-2M4 holds  for D2 be DecoratedTreeTREES-2M4 holds domRELAT-1K1 D1 =TREES-2R1 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1) & (( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1) implies ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & D1 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & D1 .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r)) & (domRELAT-1K1 D2 =TREES-2R1 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1) implies ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & D2 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & D2 .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r)))) implies D1 =HIDDENR1 D2"
        proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
          fix D1 assume [ty]: "D1 be DecoratedTreeTREES-2M4"
          fix D2 assume [ty]: "D2 be DecoratedTreeTREES-2M4"
          assume A7: "domRELAT-1K1 D1 =TREES-2R1 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1)"
            and A8: " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1) implies ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & D1 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & D1 .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r)"
            and A9: "domRELAT-1K1 D2 =TREES-2R1 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1)"
            and A10: " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1) implies ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & D2 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & D2 .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r)"
          have " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 D1 & D1 .FUNCT-1K1 q <>HIDDENR2 D2 .FUNCT-1K1 q implies  False "
          proof(rule ballI,rule impMI ,rule impI)
            fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
            assume A11: "q inTARSKIR2 domRELAT-1K1 D1"
              and A12: "D1 .FUNCT-1K1 q <>HIDDENR2 D2 .FUNCT-1K1 q"
            show " False "
            proof-
              show " False "
              proof-
                have cases: "( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & D1 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & D1 .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r)"
                  using A7 A8 A11 sorry
                have case1: "( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & D1 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q) implies  False "
                proof(rule impI)
                  assume A13: " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & D1 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q"
                  have " False "
                  proof-
                    show " False "
                    proof-
                      have cases: "( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & D2 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & D2 .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r)"
                        using A7 A10 A11 sorry
                      have case1: "( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & D2 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q) implies  False "
                      proof(rule impI)
                        assume A14: " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & D2 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q"
                        obtain x where
                          [ty]:"x be objectHIDDENM1" and 
                          A15: "x inHIDDENR3 P"
                          using A1 xboole_0_def_1 sorry
                        have "P c=TARSKIR1 domRELAT-1K1 T"
                          using trees_1_def_11 sorry
                        then have 
                          [ty]:"x be ElementTREES-1M2-of domRELAT-1K1 T"
                          using A15 sorry
                        have A16: " ex p9 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p9 =FINSEQ-1R1 x"
                           sorry
                        then have "D1 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q"
                          using A13 A15 sorry
                        thus " False "
                          using A12 A14 A15 A16 sorry
                      qed
                      have case2: "( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & D2 .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r) implies  False "
                      proof(rule impI)
                        assume " ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & D2 .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r"
                        then obtain p2 r2 where
                          [ty]:"p2 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" "r2 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
                          A17: "p2 inTARSKIR2 P"and "r2 inTARSKIR2 domRELAT-1K1 T1"and A18: "q =FINSEQ-1R1 p2 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r2"and "D2 .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r2"
                           sorry
                        have " not p2 is-a-prefix-ofTREES-1R2 q"
                          using A13 A17 sorry
                        thus " False "
                          using A18 trees_1_th_1 sorry
                      qed
                      show " ?thesis "
                        using cases case1 case2 sorry
                    qed
                  qed
                  thus " False "
                     sorry
                qed
                have case2: "( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & D1 .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r) implies  False "
                proof(rule impI)
                  assume " ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & D1 .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r"
                  then obtain p1 r1 where
                    [ty]:"p1 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" "r1 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
                    A19: "p1 inTARSKIR2 P"and "r1 inTARSKIR2 domRELAT-1K1 T1"and A20: "q =FINSEQ-1R1 p1 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r1"and A21: "D1 .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r1"
                     sorry
                  have " False "
                  proof-
                    show " False "
                    proof-
                      have cases: "( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & D2 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & D2 .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r)"
                        using A7 A10 A11 sorry
                      have case1: "( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & D2 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q) implies  False "
                      proof(rule impI)
                        assume " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & D2 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q"
                        then have " not p1 is-a-prefix-ofTREES-1R2 q"
                          using A19 sorry
                        thus " False "
                          using A20 trees_1_th_1 sorry
                      qed
                      have case2: "( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & D2 .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r) implies  False "
                      proof(rule impI)
                        assume " ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & D2 .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r"
                        then obtain p2 r2 where
                          [ty]:"p2 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" "r2 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
                          A22: "p2 inTARSKIR2 P"and "r2 inTARSKIR2 domRELAT-1K1 T1"and A23: "q =FINSEQ-1R1 p2 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r2"and A24: "D2 .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r2"
                           sorry
                        have "p1 <>HIDDENR2 p2 implies  False "
                        proof(rule impI)
                          assume A25: "p1 <>HIDDENR2 p2"
                          have "(p1,p2)are-c=-comparableXBOOLE-0R3"
                            using A20 A23 trees_a_th_1 sorry
                          thus " False "
                            using A19 A22 A25 trees_1_def_10 sorry
                        qed
                        thus " False "
                          using A12 A20 A21 A23 A24 finseq_1_th_33 sorry
                      qed
                      show " ?thesis "
                        using cases case1 case2 sorry
                    qed
                  qed
                  thus " False "
                     sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
          qed "sorry"
          thus "D1 =HIDDENR1 D2"
            using A7 A9 trees_2_th_31 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem trees_a_th_10:
" for T be DecoratedTreeTREES-2M4 holds  for T1 be DecoratedTreeTREES-2M4 holds  for P be AntiChain-of-PrefixesTREES-1M6-of domRELAT-1K1 T holds P <>HIDDENR2 {}XBOOLE-0K1 implies ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 (treeTREES-AK3(T,P,T1)) implies ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & (treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & (treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))"
proof-
  have " for T be DecoratedTreeTREES-2M4 holds  for T1 be DecoratedTreeTREES-2M4 holds  for P be AntiChain-of-PrefixesTREES-1M6-of domRELAT-1K1 T holds P <>HIDDENR2 {}XBOOLE-0K1 implies ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 (treeTREES-AK3(T,P,T1)) implies  not ( not ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P &  not ( not p is-a-prefix-ofTREES-1R2 q & (treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q))) & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & (treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))))"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule ballI,rule impI)
    fix T assume [ty]: "T be DecoratedTreeTREES-2M4"
    fix T1 assume [ty]: "T1 be DecoratedTreeTREES-2M4"
    fix P assume [ty]: "P be AntiChain-of-PrefixesTREES-1M6-of domRELAT-1K1 T"
    assume A1: "P <>HIDDENR2 {}XBOOLE-0K1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    assume "q inTARSKIR2 domRELAT-1K1 (treeTREES-AK3(T,P,T1))"
    then have "q inTARSKIR2 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1)"
      using A1 trees_a_def_2 sorry
    thus " not ( not ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 P &  not ( not p is-a-prefix-ofTREES-1R2 q & (treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q))) & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & (treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r)))"
      using trees_a_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_a_th_11:
" for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for T be DecoratedTreeTREES-2M4 holds  for T1 be DecoratedTreeTREES-2M4 holds p inTARSKIR2 domRELAT-1K1 T implies ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 (T with-replacementTREES-2K7(p,T1)) implies  not p is-a-prefix-ofTREES-1R2 q & (T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & (T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))"
proof-
  have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for T be DecoratedTreeTREES-2M4 holds  for T1 be DecoratedTreeTREES-2M4 holds p inTARSKIR2 domRELAT-1K1 T implies ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 (T with-replacementTREES-2K7(p,T1)) implies  not ( not ( not p is-a-prefix-ofTREES-1R2 q & (T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q) & ( for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not ((r inTARSKIR2 domRELAT-1K1 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & (T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))))"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    fix T assume [ty]: "T be DecoratedTreeTREES-2M4"
    fix T1 assume [ty]: "T1 be DecoratedTreeTREES-2M4"
    assume A1: "p inTARSKIR2 domRELAT-1K1 T"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    assume "q inTARSKIR2 domRELAT-1K1 (T with-replacementTREES-2K7(p,T1))"
    then have "q inTARSKIR2 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1)"
      using A1 trees_2_def_11 sorry
    thus " not ( not ( not p is-a-prefix-ofTREES-1R2 q & (T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q) & ( for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not ((r inTARSKIR2 domRELAT-1K1 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & (T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r)))"
      using A1 trees_2_def_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_a_th_12:
" for T be DecoratedTreeTREES-2M4 holds  for T1 be DecoratedTreeTREES-2M4 holds  for P be AntiChain-of-PrefixesTREES-1M6-of domRELAT-1K1 T holds P <>HIDDENR2 {}XBOOLE-0K1 implies ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 (treeTREES-AK3(T,P,T1)) & q inTARSKIR2 {t1 where t1 be ElementTREES-1M2-of domRELAT-1K1 T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 } implies (treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q)"
proof-
  have " for T be DecoratedTreeTREES-2M4 holds  for T1 be DecoratedTreeTREES-2M4 holds  for P be AntiChain-of-PrefixesTREES-1M6-of domRELAT-1K1 T holds P <>HIDDENR2 {}XBOOLE-0K1 implies ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 (treeTREES-AK3(T,P,T1)) & q inTARSKIR2 {t1 where t1 be ElementTREES-1M2-of domRELAT-1K1 T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 } implies (treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule ballI,rule impMI ,rule impI)
    fix T assume [ty]: "T be DecoratedTreeTREES-2M4"
    fix T1 assume [ty]: "T1 be DecoratedTreeTREES-2M4"
    fix P assume [ty]: "P be AntiChain-of-PrefixesTREES-1M6-of domRELAT-1K1 T"
    assume A1: "P <>HIDDENR2 {}XBOOLE-0K1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    assume A2: "q inTARSKIR2 domRELAT-1K1 (treeTREES-AK3(T,P,T1))"
      and A3: "q inTARSKIR2 {t1 where t1 be ElementTREES-1M2-of domRELAT-1K1 T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 }"
    have A4: " ex t9 be ElementTREES-1M2-of domRELAT-1K1 T st t9 =FINSEQ-1R1 q & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t9)"
      using A3 sorry
    show "(treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q"
    proof-
      have cases: "( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & (treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & (treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r)"
        using A2 trees_a_th_10 sorry
      have case1: "( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & (treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q) implies (treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q"
      proof(rule impI)
        assume A5: " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & (treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q"
        obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A6: "x inHIDDENR3 P"
          using A1 xboole_0_def_1 sorry
        have "P c=TARSKIR1 domRELAT-1K1 T"
          using trees_1_def_11 sorry
        then have 
          [ty]:"x be ElementTREES-1M2-of domRELAT-1K1 T"
          using A6 sorry
        have " ex p9 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p9 =FINSEQ-1R1 x"
           sorry
        thus "(treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q"
          using A5 A6 sorry
      qed
      have case2: "( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & (treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r) implies (treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q"
      proof(rule impI)
        assume " ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & (treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r"
        then obtain p r where
          [ty]:"p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" "r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
          A7: "p inTARSKIR2 P"and "r inTARSKIR2 domRELAT-1K1 T1"and A8: "q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"and "(treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r"
           sorry
        have " not p is-a-prefix-ofTREES-1R2 q"
          using A4 A7 sorry
        thus "(treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q"
          using A8 trees_1_th_1 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_a_th_13:
" for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for T be DecoratedTreeTREES-2M4 holds  for T1 be DecoratedTreeTREES-2M4 holds p inTARSKIR2 domRELAT-1K1 T implies ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 (T with-replacementTREES-2K7(p,T1)) & q inTARSKIR2 {t1 where t1 be ElementTREES-1M2-of domRELAT-1K1 T :  not p is-a-prefix-ofTREES-1R2 t1 } implies (T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q)"
proof-
  have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for T be DecoratedTreeTREES-2M4 holds  for T1 be DecoratedTreeTREES-2M4 holds p inTARSKIR2 domRELAT-1K1 T implies ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 (T with-replacementTREES-2K7(p,T1)) & q inTARSKIR2 {t1 where t1 be ElementTREES-1M2-of domRELAT-1K1 T :  not p is-a-prefix-ofTREES-1R2 t1 } implies (T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    fix T assume [ty]: "T be DecoratedTreeTREES-2M4"
    fix T1 assume [ty]: "T1 be DecoratedTreeTREES-2M4"
    assume A1: "p inTARSKIR2 domRELAT-1K1 T"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    assume A2: "q inTARSKIR2 domRELAT-1K1 (T with-replacementTREES-2K7(p,T1))"
      and A3: "q inTARSKIR2 {t1 where t1 be ElementTREES-1M2-of domRELAT-1K1 T :  not p is-a-prefix-ofTREES-1R2 t1 }"
    show "(T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q"
    proof-
      have cases: " not p is-a-prefix-ofTREES-1R2 q & (T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & (T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r)"
        using A1 A2 trees_a_th_11 sorry
      have case1: " not p is-a-prefix-ofTREES-1R2 q & (T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q implies (T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q"
      proof(rule impI)
        assume " not p is-a-prefix-ofTREES-1R2 q & (T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q"
        thus "(T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q"
           sorry
      qed
      have case2: "( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & (T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r) implies (T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q"
      proof(rule impI)
        assume A4: " ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & (T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r"
        have " ex t9 be ElementTREES-1M2-of domRELAT-1K1 T st q =FINSEQ-1R1 t9 &  not p is-a-prefix-ofTREES-1R2 t9"
          using A3 sorry
        thus "(T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q"
          using A4 trees_1_th_1 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_a_th_14:
" for T be DecoratedTreeTREES-2M4 holds  for T1 be DecoratedTreeTREES-2M4 holds  for P be AntiChain-of-PrefixesTREES-1M6-of domRELAT-1K1 T holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 (treeTREES-AK3(T,P,T1)) & q inTARSKIR2 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of domRELAT-1K1 T, s be ElementTREES-1M2-of domRELAT-1K1 T1 : p inTARSKIR2 P } implies ( ex p9 be ElementTREES-1M2-of domRELAT-1K1 T st  ex r be ElementTREES-1M2-of domRELAT-1K1 T1 st (q =FINSEQ-1R1 p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r & p9 inTARSKIR2 P) & (treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r)"
proof-
  have " for T be DecoratedTreeTREES-2M4 holds  for T1 be DecoratedTreeTREES-2M4 holds  for P be AntiChain-of-PrefixesTREES-1M6-of domRELAT-1K1 T holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 (treeTREES-AK3(T,P,T1)) & q inTARSKIR2 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of domRELAT-1K1 T, s be ElementTREES-1M2-of domRELAT-1K1 T1 : p inTARSKIR2 P } implies  not ( for p9 be ElementTREES-1M2-of domRELAT-1K1 T holds  for r be ElementTREES-1M2-of domRELAT-1K1 T1 holds  not ((q =FINSEQ-1R1 p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r & p9 inTARSKIR2 P) & (treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix T assume [ty]: "T be DecoratedTreeTREES-2M4"
    fix T1 assume [ty]: "T1 be DecoratedTreeTREES-2M4"
    fix P assume [ty]: "P be AntiChain-of-PrefixesTREES-1M6-of domRELAT-1K1 T"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    assume A1: "q inTARSKIR2 domRELAT-1K1 (treeTREES-AK3(T,P,T1))"
      and A2: "q inTARSKIR2 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of domRELAT-1K1 T, s be ElementTREES-1M2-of domRELAT-1K1 T1 : p inTARSKIR2 P }"
    show " not ( for p9 be ElementTREES-1M2-of domRELAT-1K1 T holds  for r be ElementTREES-1M2-of domRELAT-1K1 T1 holds  not ((q =FINSEQ-1R1 p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r & p9 inTARSKIR2 P) & (treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))"
    proof-
      have cases: "( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & (treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & (treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r)"
        using A1 trees_a_th_10 sorry
      have case1: "( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & (treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q) implies  not ( for p9 be ElementTREES-1M2-of domRELAT-1K1 T holds  for r be ElementTREES-1M2-of domRELAT-1K1 T1 holds  not ((q =FINSEQ-1R1 p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r & p9 inTARSKIR2 P) & (treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))"
      proof(rule impI)
        assume A3: " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & (treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q"
        obtain p9 r where
          [ty]:"p9 be ElementTREES-1M2-of domRELAT-1K1 T" "r be ElementTREES-1M2-of domRELAT-1K1 T1" and 
          A4: "q =FINSEQ-1R1 p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"and A5: "p9 inTARSKIR2 P"
          using A2 sorry
        have "(treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r"
          using A4 trees_1_th_1 A3 A5 sorry
        thus " not ( for p9 be ElementTREES-1M2-of domRELAT-1K1 T holds  for r be ElementTREES-1M2-of domRELAT-1K1 T1 holds  not ((q =FINSEQ-1R1 p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r & p9 inTARSKIR2 P) & (treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))"
          using A4 A5 sorry
      qed
      have case2: "( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & (treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r) implies  not ( for p9 be ElementTREES-1M2-of domRELAT-1K1 T holds  for r be ElementTREES-1M2-of domRELAT-1K1 T1 holds  not ((q =FINSEQ-1R1 p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r & p9 inTARSKIR2 P) & (treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))"
      proof(rule impI)
        assume " ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & (treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r"
        then obtain p r where
          [ty]:"p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" "r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
          A6: "p inTARSKIR2 P"and A7: "r inTARSKIR2 domRELAT-1K1 T1"and A8: "q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"and A9: "(treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r"
           sorry
        obtain p9 r9 where
          [ty]:"p9 be ElementTREES-1M2-of domRELAT-1K1 T" "r9 be ElementTREES-1M2-of domRELAT-1K1 T1" and 
          A10: "q =FINSEQ-1R1 p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r9"and A11: "p9 inTARSKIR2 P"
          using A2 sorry
        have "p <>HIDDENR2 p9 implies  False "
        proof(rule impI)
          assume A12: "p <>HIDDENR2 p9"
          have "(p,p9)are-c=-comparableXBOOLE-0R3"
            using A8 A10 trees_a_th_1 sorry
          thus " False "
            using A6 A11 A12 trees_1_def_10 sorry
        qed
        thus " not ( for p9 be ElementTREES-1M2-of domRELAT-1K1 T holds  for r be ElementTREES-1M2-of domRELAT-1K1 T1 holds  not ((q =FINSEQ-1R1 p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r & p9 inTARSKIR2 P) & (treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))"
          using A6 A7 A8 A9 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_a_th_15:
" for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for T be DecoratedTreeTREES-2M4 holds  for T1 be DecoratedTreeTREES-2M4 holds p inTARSKIR2 domRELAT-1K1 T implies ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 (T with-replacementTREES-2K7(p,T1)) & q inTARSKIR2 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of domRELAT-1K1 T1 :  True  } implies ( ex r be ElementTREES-1M2-of domRELAT-1K1 T1 st q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r & (T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))"
proof-
  have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for T be DecoratedTreeTREES-2M4 holds  for T1 be DecoratedTreeTREES-2M4 holds p inTARSKIR2 domRELAT-1K1 T implies ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 (T with-replacementTREES-2K7(p,T1)) & q inTARSKIR2 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of domRELAT-1K1 T1 :  True  } implies  not ( for r be ElementTREES-1M2-of domRELAT-1K1 T1 holds  not (q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r & (T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r)))"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    fix T assume [ty]: "T be DecoratedTreeTREES-2M4"
    fix T1 assume [ty]: "T1 be DecoratedTreeTREES-2M4"
    assume A1: "p inTARSKIR2 domRELAT-1K1 T"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    assume A2: "q inTARSKIR2 domRELAT-1K1 (T with-replacementTREES-2K7(p,T1))"
      and A3: "q inTARSKIR2 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of domRELAT-1K1 T1 :  True  }"
    show " not ( for r be ElementTREES-1M2-of domRELAT-1K1 T1 holds  not (q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r & (T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))"
    proof-
      have cases: " not p is-a-prefix-ofTREES-1R2 q & (T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & (T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r)"
        using A1 A2 trees_a_th_11 sorry
      have case1: " not p is-a-prefix-ofTREES-1R2 q & (T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q implies  not ( for r be ElementTREES-1M2-of domRELAT-1K1 T1 holds  not (q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r & (T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))"
      proof(rule impI)
        assume A4: " not p is-a-prefix-ofTREES-1R2 q & (T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q"
        have " ex r be ElementTREES-1M2-of domRELAT-1K1 T1 st q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
          using A3 sorry
        thus " not ( for r be ElementTREES-1M2-of domRELAT-1K1 T1 holds  not (q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r & (T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))"
          using A4 trees_1_th_1 sorry
      qed
      have case2: "( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & (T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r) implies  not ( for r be ElementTREES-1M2-of domRELAT-1K1 T1 holds  not (q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r & (T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))"
      proof(rule impI)
        assume " ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & (T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r"
        thus " not ( for r be ElementTREES-1M2-of domRELAT-1K1 T1 holds  not (q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r & (T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_a_th_16:
" for T be DecoratedTreeTREES-2M4 holds  for T1 be DecoratedTreeTREES-2M4 holds  for t be ElementTREES-1M2-of domRELAT-1K1 T holds treeTREES-AK3(T,{TREES-AK2\<^bsub>(domRELAT-1K1 T)\<^esub> t},T1) =FUNCT-1R1 T with-replacementTREES-2K7(t,T1)"
proof-
  have " for T be DecoratedTreeTREES-2M4 holds  for T1 be DecoratedTreeTREES-2M4 holds  for t be ElementTREES-1M2-of domRELAT-1K1 T holds treeTREES-AK3(T,{TREES-AK2\<^bsub>(domRELAT-1K1 T)\<^esub> t},T1) =FUNCT-1R1 T with-replacementTREES-2K7(t,T1)"
  proof(rule ballI,rule ballI,rule ballI)
    fix T assume [ty]: "T be DecoratedTreeTREES-2M4"
    fix T1 assume [ty]: "T1 be DecoratedTreeTREES-2M4"
    fix t assume [ty]: "t be ElementTREES-1M2-of domRELAT-1K1 T"
    have A1: "domRELAT-1K1 (treeTREES-AK3(T,{TREES-AK2\<^bsub>(domRELAT-1K1 T)\<^esub> t},T1)) =HIDDENR1 treeTREES-AK1(domRELAT-1K1 T,{TREES-AK2\<^bsub>(domRELAT-1K1 T)\<^esub> t},domRELAT-1K1 T1)"
      using trees_a_def_2 sorry
    also have "... = domRELAT-1K1 T with-replacementTREES-1K5(t,domRELAT-1K1 T1)"
      using trees_a_th_9 sorry
    also have "... = domRELAT-1K1 (T with-replacementTREES-2K7(t,T1))"
      using trees_2_def_11 sorry
    finally have "domRELAT-1K1 (treeTREES-AK3(T,{TREES-AK2\<^bsub>(domRELAT-1K1 T)\<^esub> t},T1)) =HIDDENR1 domRELAT-1K1 (T with-replacementTREES-2K7(t,T1))"
       sorry
    have " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 (treeTREES-AK3(T,{TREES-AK2\<^bsub>(domRELAT-1K1 T)\<^esub> t},T1)) implies (treeTREES-AK3(T,{TREES-AK2\<^bsub>(domRELAT-1K1 T)\<^esub> t},T1)).FUNCT-1K1 q =XBOOLE-0R4 (T with-replacementTREES-2K7(t,T1)).FUNCT-1K1 q"
    proof(rule ballI,rule impI)
      fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
      assume A2: "q inTARSKIR2 domRELAT-1K1 (treeTREES-AK3(T,{TREES-AK2\<^bsub>(domRELAT-1K1 T)\<^esub> t},T1))"
      then have A3: "q inTARSKIR2 treeTREES-AK1(domRELAT-1K1 T,{TREES-AK2\<^bsub>(domRELAT-1K1 T)\<^esub> t},domRELAT-1K1 T1)"
        using trees_a_def_2 sorry
      have A4: "treeTREES-AK1(domRELAT-1K1 T,{TREES-AK2\<^bsub>(domRELAT-1K1 T)\<^esub> t},domRELAT-1K1 T1) =XBOOLE-0R4 ({t1 where t1 be ElementTREES-1M2-of domRELAT-1K1 T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 {TREES-AK2\<^bsub>(domRELAT-1K1 T)\<^esub> t} implies  not p is-a-prefix-ofTREES-1R2 t1 })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of domRELAT-1K1 T, s be ElementTREES-1M2-of domRELAT-1K1 T1 : p inTARSKIR2 {TREES-AK2\<^bsub>(domRELAT-1K1 T)\<^esub> t} })"
        using trees_a_th_7 sorry
      show "(treeTREES-AK3(T,{TREES-AK2\<^bsub>(domRELAT-1K1 T)\<^esub> t},T1)).FUNCT-1K1 q =XBOOLE-0R4 (T with-replacementTREES-2K7(t,T1)).FUNCT-1K1 q"
      proof-
        have cases: "q inTARSKIR2 {t1 where t1 be ElementTREES-1M2-of domRELAT-1K1 T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 {TREES-AK2\<^bsub>(domRELAT-1K1 T)\<^esub> t} implies  not p is-a-prefix-ofTREES-1R2 t1 } or q inTARSKIR2 {p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p9 be ElementTREES-1M2-of domRELAT-1K1 T, s be ElementTREES-1M2-of domRELAT-1K1 T1 : p9 inTARSKIR2 {TREES-AK2\<^bsub>(domRELAT-1K1 T)\<^esub> t} }"
          using A3 A4 xboole_0_def_3 sorry
        have case1: "q inTARSKIR2 {t1 where t1 be ElementTREES-1M2-of domRELAT-1K1 T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 {TREES-AK2\<^bsub>(domRELAT-1K1 T)\<^esub> t} implies  not p is-a-prefix-ofTREES-1R2 t1 } implies (treeTREES-AK3(T,{TREES-AK2\<^bsub>(domRELAT-1K1 T)\<^esub> t},T1)).FUNCT-1K1 q =XBOOLE-0R4 (T with-replacementTREES-2K7(t,T1)).FUNCT-1K1 q"
        proof(rule impI)
          assume A5: "q inTARSKIR2 {t1 where t1 be ElementTREES-1M2-of domRELAT-1K1 T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 {TREES-AK2\<^bsub>(domRELAT-1K1 T)\<^esub> t} implies  not p is-a-prefix-ofTREES-1R2 t1 }"
          then obtain t9 where
            [ty]:"t9 be ElementTREES-1M2-of domRELAT-1K1 T" and 
            A6: "q =FINSEQ-1R1 t9"and A7: " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 {TREES-AK2\<^bsub>(domRELAT-1K1 T)\<^esub> t} implies  not p is-a-prefix-ofTREES-1R2 t9"
             sorry
          obtain p where
            [ty]:"p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
            A8: "p =FINSEQ-1R1 t"
             sorry
          have "p inTARSKIR2 {TREES-AK2\<^bsub>(domRELAT-1K1 T)\<^esub> t}"
            using A8 tarski_def_1 sorry
          then have A9: " not p is-a-prefix-ofTREES-1R2 t9"
            using A7 sorry
          have "q inTARSKIR2 domRELAT-1K1 (T with-replacementTREES-2K7(t,T1)) & q inTARSKIR2 {t1 where t1 be ElementTREES-1M2-of domRELAT-1K1 T :  not p is-a-prefix-ofTREES-1R2 t1 } implies (T with-replacementTREES-2K7(t,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q"
            using A8 trees_a_th_13 sorry
          thus "(treeTREES-AK3(T,{TREES-AK2\<^bsub>(domRELAT-1K1 T)\<^esub> t},T1)).FUNCT-1K1 q =XBOOLE-0R4 (T with-replacementTREES-2K7(t,T1)).FUNCT-1K1 q"
            using A1 A2 A5 A6 A9 trees_a_th_12 sorry
        qed
        have case2: "q inTARSKIR2 {p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p9 be ElementTREES-1M2-of domRELAT-1K1 T, s be ElementTREES-1M2-of domRELAT-1K1 T1 : p9 inTARSKIR2 {TREES-AK2\<^bsub>(domRELAT-1K1 T)\<^esub> t} } implies (treeTREES-AK3(T,{TREES-AK2\<^bsub>(domRELAT-1K1 T)\<^esub> t},T1)).FUNCT-1K1 q =XBOOLE-0R4 (T with-replacementTREES-2K7(t,T1)).FUNCT-1K1 q"
        proof(rule impI)
          assume A10: "q inTARSKIR2 {p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p9 be ElementTREES-1M2-of domRELAT-1K1 T, s be ElementTREES-1M2-of domRELAT-1K1 T1 : p9 inTARSKIR2 {TREES-AK2\<^bsub>(domRELAT-1K1 T)\<^esub> t} }"
          then obtain p r where
            [ty]:"p be ElementTREES-1M2-of domRELAT-1K1 T" "r be ElementTREES-1M2-of domRELAT-1K1 T1" and 
            A11: "q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"and A12: "p inTARSKIR2 {TREES-AK2\<^bsub>(domRELAT-1K1 T)\<^esub> t}"
             sorry
          have A13: "q inTARSKIR2 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of domRELAT-1K1 T1 :  True  }"
            using A11 sorry
          obtain p1 r1 where
            [ty]:"p1 be ElementTREES-1M2-of domRELAT-1K1 T" "r1 be ElementTREES-1M2-of domRELAT-1K1 T1" and 
            A14: "q =FINSEQ-1R1 p1 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r1"and A15: "p1 inTARSKIR2 {TREES-AK2\<^bsub>(domRELAT-1K1 T)\<^esub> t}"and A16: "(treeTREES-AK3(T,{TREES-AK2\<^bsub>(domRELAT-1K1 T)\<^esub> t},T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r1"
            using A2 A10 trees_a_th_14 sorry
          have A17: "p1 =FINSEQ-1R1 t"
            using A15 tarski_def_1 sorry
          have A18: "p =FINSEQ-1R1 t"
            using A12 tarski_def_1 sorry
          then have " ex r2 be ElementTREES-1M2-of domRELAT-1K1 T1 st q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r2 & (T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r2"
            using A1 A2 A13 trees_a_th_15 sorry
          thus "(treeTREES-AK3(T,{TREES-AK2\<^bsub>(domRELAT-1K1 T)\<^esub> t},T1)).FUNCT-1K1 q =XBOOLE-0R4 (T with-replacementTREES-2K7(t,T1)).FUNCT-1K1 q"
            using A14 A16 A17 A18 finseq_1_th_33 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus "treeTREES-AK3(T,{TREES-AK2\<^bsub>(domRELAT-1K1 T)\<^esub> t},T1) =FUNCT-1R1 T with-replacementTREES-2K7(t,T1)"
      using A1 trees_2_th_31 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve D for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve T, T1 for "DecoratedTreeTREES-2M5-of D"
reserve P for " non emptyXBOOLE-0V1\<bar>AntiChain-of-PrefixesTREES-1M6-of domRELAT-1K1 T"
mtheorem trees_a_cl_2:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "T be DecoratedTreeTREES-2M5-of D", "P be  non emptyXBOOLE-0V1\<bar>AntiChain-of-PrefixesTREES-1M6-of domRELAT-1K1 T", "T1 be DecoratedTreeTREES-2M5-of D"
"cluster treeTREES-AK3(T,P,T1) as-term-is D -valuedRELAT-1V5"
proof
(*coherence*)
  show "treeTREES-AK3(T,P,T1) be D -valuedRELAT-1V5"
  proof-
    let ?T2 = "treeTREES-AK3(T,P,T1)"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 ?T2 implies y inHIDDENR3 D"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 rngFUNCT-1K2 ?T2"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A2: "x inHIDDENR3 domRELAT-1K1 ?T2"and A3: "y =HIDDENR1 ?T2 .FUNCT-1K1 x"
        using funct_1_def_3 sorry
      have "x be ElementTREES-1M2-of domRELAT-1K1 ?T2"
        using A2 sorry
      then obtain q where 
        [ty]:"q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and qDef:"q = x"
         sorry
      have "domRELAT-1K1 ?T2 =TREES-2R1 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1)"
        using trees_a_def_2 sorry
      then have A4: "domRELAT-1K1 ?T2 =XBOOLE-0R4 ({t1 where t1 be ElementTREES-1M2-of domRELAT-1K1 T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of domRELAT-1K1 T, s be ElementTREES-1M2-of domRELAT-1K1 T1 : p inTARSKIR2 P })"
        using trees_a_th_7 sorry
      show "y inHIDDENR3 D"
      proof-
        have cases: "q inTARSKIR2 {t1 where t1 be ElementTREES-1M2-of domRELAT-1K1 T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 } or q inTARSKIR2 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of domRELAT-1K1 T, s be ElementTREES-1M2-of domRELAT-1K1 T1 : p inTARSKIR2 P }"
          using A2 A4 xboole_0_def_3 sorry
        have case1: "q inTARSKIR2 {t1 where t1 be ElementTREES-1M2-of domRELAT-1K1 T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 } implies y inHIDDENR3 D"
        proof(rule impI)
          assume A5: "q inTARSKIR2 {t1 where t1 be ElementTREES-1M2-of domRELAT-1K1 T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 }"
          then have A6: "(treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q"
            using A2 trees_a_th_12 sorry
          have "q inTARSKIR2 domRELAT-1K1 T"
          proof-
            have " ex t9 be ElementTREES-1M2-of domRELAT-1K1 T st q =FINSEQ-1R1 t9 & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t9)"
              using A5 sorry
            thus "q inTARSKIR2 domRELAT-1K1 T"
               sorry
          qed
          then have A7: "y inHIDDENR3 rngFUNCT-1K2 T"
            using A3 A6 funct_1_def_3 sorry
          have "rngFUNCT-1K2 T c=TARSKIR1 D"
            using relat_1_def_19 sorry
          thus "y inHIDDENR3 D"
            using A7 sorry
        qed
        have case2: "q inTARSKIR2 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of domRELAT-1K1 T, s be ElementTREES-1M2-of domRELAT-1K1 T1 : p inTARSKIR2 P } implies y inHIDDENR3 D"
        proof(rule impI)
          assume "q inTARSKIR2 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of domRELAT-1K1 T, s be ElementTREES-1M2-of domRELAT-1K1 T1 : p inTARSKIR2 P }"
          then have " ex p be ElementTREES-1M2-of domRELAT-1K1 T st  ex r be ElementTREES-1M2-of domRELAT-1K1 T1 st (q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r & p inTARSKIR2 P) & (treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .TREES-2K3\<^bsub>(D)\<^esub> r"
            using A2 trees_a_th_14 sorry
          thus "y inHIDDENR3 D"
            using A3 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus "treeTREES-AK3(T,P,T1) be D -valuedRELAT-1V5"
      using tarski_def_3 relat_1_def_19 sorry
  qed
qed "sorry"

end
