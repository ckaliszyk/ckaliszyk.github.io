theory euler_1
  imports int_2 card_2 pre_ff funct_7
   "../mizar_extension/E_number"
begin
(*begin*)
reserve a, b, c, k, l, m, n for "NatNAT-1M1"
reserve i, j, x, y for "IntegerINT-1M1"
mlemma euler_1_lm_1:
" for k be NatNAT-1M1 holds  for j be IntegerINT-1M1 holds k <>HIDDENR2 0NUMBERSK6 & [\\INT-1K2 j /XCMPLX-0K7 k /] +XCMPLX-0K2 \<one>\<^sub>M >=XXREAL-0R2 j /XCMPLX-0K7 k implies k >=XXREAL-0R2 j -XCMPLX-0K6 ([\\INT-1K2 j /XCMPLX-0K7 k /])*XCMPLX-0K3 k"
proof-
  have " for k be NatNAT-1M1 holds  for j be IntegerINT-1M1 holds k <>HIDDENR2 0NUMBERSK6 & [\\INT-1K2 j /XCMPLX-0K7 k /] +XCMPLX-0K2 \<one>\<^sub>M >=XXREAL-0R2 j /XCMPLX-0K7 k implies k >=XXREAL-0R2 j -XCMPLX-0K6 ([\\INT-1K2 j /XCMPLX-0K7 k /])*XCMPLX-0K3 k"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix j assume [ty]: "j be IntegerINT-1M1"
    assume A1: "k <>HIDDENR2 0NUMBERSK6"
      and A2: "[\\INT-1K2 j /XCMPLX-0K7 k /] +XCMPLX-0K2 \<one>\<^sub>M >=XXREAL-0R2 j /XCMPLX-0K7 k"
    have "([\\INT-1K2 j /XCMPLX-0K7 k /] +XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M) >=XXREAL-0R2 j /XCMPLX-0K7 k +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)"
      using A2 xreal_1_th_6 sorry
    then have "([\\INT-1K2 j /XCMPLX-0K7 k /])*XCMPLX-0K3 k >=XXREAL-0R2 (j /XCMPLX-0K7 k -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 k"
      using xreal_1_th_64 sorry
    then have "-XCMPLX-0K4 (j /XCMPLX-0K7 k -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 k >=XXREAL-0R2 -XCMPLX-0K4 ([\\INT-1K2 j /XCMPLX-0K7 k /])*XCMPLX-0K3 k"
      using xreal_1_th_24 sorry
    then have "j +XCMPLX-0K2 (-XCMPLX-0K4 (j /XCMPLX-0K7 k -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 k) >=XXREAL-0R2 j +XCMPLX-0K2 (-XCMPLX-0K4 ([\\INT-1K2 j /XCMPLX-0K7 k /])*XCMPLX-0K3 k)"
      using xreal_1_th_6 sorry
    then have "j -XCMPLX-0K6 ((j /XCMPLX-0K7 k)*XCMPLX-0K3 k -XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 k) >=XXREAL-0R2 j -XCMPLX-0K6 ([\\INT-1K2 j /XCMPLX-0K7 k /])*XCMPLX-0K3 k"
       sorry
    then have "j -XCMPLX-0K6 (j -XCMPLX-0K6 k) >=XXREAL-0R2 j -XCMPLX-0K6 ([\\INT-1K2 j /XCMPLX-0K7 k /])*XCMPLX-0K3 k"
      using A1 xcmplx_1_th_87 sorry
    thus "k >=XXREAL-0R2 j -XCMPLX-0K6 ([\\INT-1K2 j /XCMPLX-0K7 k /])*XCMPLX-0K3 k"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma euler_1_lm_2:
" not \<one>\<^sub>M be primeINT-2V1"
  using int_2_def_4 sorry

mtheorem euler_1_th_1:
" for n be NatNAT-1M1 holds (n,n)are-coprimeINT-2R1 iff n =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for n be NatNAT-1M1 holds  not ((n,n)are-coprimeINT-2R1 &  not n =XBOOLE-0R4 \<one>\<^sub>M) &  not (n =XBOOLE-0R4 \<one>\<^sub>M &  not (n,n)are-coprimeINT-2R1)"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have "n gcdINT-2K3 n =XBOOLE-0R4 n"
      using nat_d_th_32 sorry
    thus " not ((n,n)are-coprimeINT-2R1 &  not n =XBOOLE-0R4 \<one>\<^sub>M) &  not (n =XBOOLE-0R4 \<one>\<^sub>M &  not (n,n)are-coprimeINT-2R1)"
      using int_2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem euler_1_th_2:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (k <>HIDDENR2 0NUMBERSK6 & k <XXREAL-0R3 n) & n be primeINT-2V1 implies (k,n)are-coprimeINT-2R1"
proof(rule ballI,rule ballI,rule impMI ,rule impI)
  fix k assume [ty]: "k be NatNAT-1M1"
  fix n assume [ty]: "n be NatNAT-1M1"
  assume A1: "k <>HIDDENR2 0NUMBERSK6 & k <XXREAL-0R3 n"
    and A2: "n be primeINT-2V1"
  have A3: "k gcdINT-2K3 n dividesNAT-DR1 n"
    using nat_d_def_5 sorry
  show "(k,n)are-coprimeINT-2R1"
  proof-
    have cases: "k gcdINT-2K3 n =XBOOLE-0R4 \<one>\<^sub>M or k gcdINT-2K3 n =XBOOLE-0R4 n"
      using A2 A3 int_2_def_4 sorry
    have case1: "k gcdINT-2K3 n =XBOOLE-0R4 \<one>\<^sub>M implies (k,n)are-coprimeINT-2R1"
    proof(rule impI)
      assume "k gcdINT-2K3 n =XBOOLE-0R4 \<one>\<^sub>M"
      thus "(k,n)are-coprimeINT-2R1"
        using int_2_def_3 sorry
    qed
    have case2: "k gcdINT-2K3 n =XBOOLE-0R4 n implies (k,n)are-coprimeINT-2R1"
    proof(rule impI)
      assume "k gcdINT-2K3 n =XBOOLE-0R4 n"
      then have "n dividesNAT-DR1 k"
        using nat_d_def_5 sorry
      thus "(k,n)are-coprimeINT-2R1"
        using A1 nat_d_th_7 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem euler_1_th_3:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n be primeINT-2V1 & k inTARSKIR2 {kk where kk be ElementSUBSET-1M1-of NATNUMBERSK1 : ((n,kk)are-coprimeINT-2R1 & kk >=XXREAL-0R2 \<one>\<^sub>M) & kk <=XXREAL-0R1 n } iff (n be primeINT-2V1 & k inTARSKIR2 SegmCARD-1K5 n) &  not k inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (n be primeINT-2V1 & k inTARSKIR2 {kk where kk be ElementSUBSET-1M1-of NATNUMBERSK1 : ((n,kk)are-coprimeINT-2R1 & kk >=XXREAL-0R2 \<one>\<^sub>M) & kk <=XXREAL-0R1 n } implies (n be primeINT-2V1 & k inTARSKIR2 SegmCARD-1K5 n) &  not k inTARSKIR2 {TARSKIK1 0NUMBERSK6 }) & (n be primeINT-2V1 & (k inTARSKIR2 SegmCARD-1K5 n &  not k inTARSKIR2 {TARSKIK1 0NUMBERSK6 }) implies n be primeINT-2V1 & k inTARSKIR2 {kk where kk be ElementSUBSET-1M1-of NATNUMBERSK1 : ((n,kk)are-coprimeINT-2R1 & kk >=XXREAL-0R2 \<one>\<^sub>M) & kk <=XXREAL-0R1 n })"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impMI ,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?X = "{kk where kk be ElementSUBSET-1M1-of NATNUMBERSK1 : ((n,kk)are-coprimeINT-2R1 & kk >=XXREAL-0R2 \<one>\<^sub>M) & kk <=XXREAL-0R1 n }"
    show "n be primeINT-2V1 & k inTARSKIR2 {kk where kk be ElementSUBSET-1M1-of NATNUMBERSK1 : ((n,kk)are-coprimeINT-2R1 & kk >=XXREAL-0R2 \<one>\<^sub>M) & kk <=XXREAL-0R1 n } implies (n be primeINT-2V1 & k inTARSKIR2 SegmCARD-1K5 n) &  not k inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
    proof(rule impMI ,rule impI)
      assume A1: "n be primeINT-2V1"
        and A2: "k inTARSKIR2 ?X"
      have A3: " ex kk be ElementSUBSET-1M1-of NATNUMBERSK1 st ((kk =XBOOLE-0R4 k & (n,kk)are-coprimeINT-2R1) & kk >=XXREAL-0R2 \<one>\<^sub>M) & kk <=XXREAL-0R1 n"
        using A2 sorry
      then have "k <>HIDDENR2 n"
        using A1 euler_1_lm_2 euler_1_th_1 sorry
      then have "k <XXREAL-0R3 n"
        using A3 xxreal_0_th_1 sorry
      thus "(n be primeINT-2V1 & k inTARSKIR2 SegmCARD-1K5 n) &  not k inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
        using A1 A3 nat_1_th_44 tarski_def_1 sorry
    qed
    assume A4: "n be primeINT-2V1"
      and A5: "k inTARSKIR2 SegmCARD-1K5 n"
      and A6: " not k inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
    have A7: "k <>HIDDENR2 0NUMBERSK6"
      using A6 tarski_def_1 sorry
    then have A8: "k >=XXREAL-0R2 \<one>\<^sub>M"
      using nat_1_th_14 sorry
    have A9: "k <XXREAL-0R3 n"
      using A5 nat_1_th_44 sorry
    then have "k inTARSKIR2 NATNUMBERSK1 & (k,n)are-coprimeINT-2R1"
      using A4 A7 euler_1_th_2 ordinal1_def_12 sorry
    thus "n be primeINT-2V1 & k inTARSKIR2 {kk where kk be ElementSUBSET-1M1-of NATNUMBERSK1 : ((n,kk)are-coprimeINT-2R1 & kk >=XXREAL-0R2 \<one>\<^sub>M) & kk <=XXREAL-0R1 n }"
      using A4 A9 A8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem euler_1_th_4:
" for A be finiteFINSET-1V1\<bar>setHIDDENM2 holds  for x be setHIDDENM2 holds x inTARSKIR2 A implies cardCARD-1K4 (A \\SUBSET-1K6 {TARSKIK1 x}) =XBOOLE-0R4 cardCARD-1K4 A -XCMPLX-0K6 cardCARD-1K4 {TARSKIK1 x}"
  using card_2_th_44 zfmisc_1_th_31 sorry

mtheorem euler_1_th_5:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds a gcdINT-2K3 b =XBOOLE-0R4 \<one>\<^sub>M implies ( for c be NatNAT-1M1 holds a *XCMPLX-0K3 c gcdINT-2K3 b *XCMPLX-0K3 c =XBOOLE-0R4 c)"
proof-
  have " for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds a gcdINT-2K3 b =XBOOLE-0R4 \<one>\<^sub>M implies ( for m be NatNAT-1M1 holds a *XCMPLX-0K3 m gcdINT-2K3 b *XCMPLX-0K3 m =HIDDENR1 m)"
  proof(rule ballI,rule ballI,rule impI,rule ballI)
    fix a assume [ty]: "a be NatNAT-1M1"
    fix b assume [ty]: "b be NatNAT-1M1"
    assume A1: "a gcdINT-2K3 b =XBOOLE-0R4 \<one>\<^sub>M"
    fix m assume [ty]: "m be NatNAT-1M1"
    obtain a9 b9 where 
      [ty]:"a9 be IntegerINT-1M1" and a9Def:"a9 = a" and
      [ty]:"b9 be IntegerINT-1M1" and b9Def:"b9 = b"
       sorry
    have "(a9,b9)are-coprimeINT-2R1"
      using A1 int_2_def_3 sorry
    then have "a *XCMPLX-0K3 m gcdINT-2K3 b *XCMPLX-0K3 m =HIDDENR1  |.INT-2K1  |.INT-2K1 m.| .|"
      using int_2_th_24 sorry
    also have "... = m"
      using absvalue_def_1 sorry
    finally show "a *XCMPLX-0K3 m gcdINT-2K3 b *XCMPLX-0K3 m =HIDDENR1 m"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem euler_1_th_6:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds  for c be NatNAT-1M1 holds (a <>HIDDENR2 0NUMBERSK6 & c <>HIDDENR2 0NUMBERSK6) & a *XCMPLX-0K3 c gcdINT-2K3 b *XCMPLX-0K3 c =XBOOLE-0R4 c implies (a,b)are-coprimeINT-2R1"
proof-
  have " for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds  for c be NatNAT-1M1 holds a <>HIDDENR2 0NUMBERSK6 & (c <>HIDDENR2 0NUMBERSK6 & a *XCMPLX-0K3 c gcdINT-2K3 b *XCMPLX-0K3 c =XBOOLE-0R4 c) implies (a,b)are-coprimeINT-2R1"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be NatNAT-1M1"
    fix b assume [ty]: "b be NatNAT-1M1"
    fix c assume [ty]: "c be NatNAT-1M1"
    assume A1: "a <>HIDDENR2 0NUMBERSK6"
      and A2: "c <>HIDDENR2 0NUMBERSK6"
      and A3: "a *XCMPLX-0K3 c gcdINT-2K3 b *XCMPLX-0K3 c =XBOOLE-0R4 c"
    have "a *XCMPLX-0K3 c <>HIDDENR2 (0NUMBERSK6)*XCMPLX-0K3 c"
      using A1 A2 xcmplx_1_th_5 sorry
    then obtain a1 b1 where
      [ty]:"a1 be IntegerINT-1M1" "b1 be IntegerINT-1M1" and 
      A4: "a *XCMPLX-0K3 c =XBOOLE-0R4 (a *XCMPLX-0K3 c gcdINT-2K3 b *XCMPLX-0K3 c)*XCMPLX-0K3 a1"and A5: "b *XCMPLX-0K3 c =XBOOLE-0R4 (a *XCMPLX-0K3 c gcdINT-2K3 b *XCMPLX-0K3 c)*XCMPLX-0K3 b1 & (a1,b1)are-coprimeINT-2R1"
      using int_2_th_23 sorry
    have "a =HIDDENR1 a1"
      using A2 A3 A4 xcmplx_1_th_5 sorry
    thus "(a,b)are-coprimeINT-2R1"
      using A2 A3 A5 xcmplx_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem euler_1_th_7:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds a gcdINT-2K3 b =XBOOLE-0R4 \<one>\<^sub>M implies (a +XCMPLX-0K2 b)gcdINT-2K3 b =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds a gcdINT-2K3 b =XBOOLE-0R4 \<one>\<^sub>M implies (a +XCMPLX-0K2 b)gcdINT-2K3 b =XBOOLE-0R4 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be NatNAT-1M1"
    fix b assume [ty]: "b be NatNAT-1M1"
    assume A1: "a gcdINT-2K3 b =XBOOLE-0R4 \<one>\<^sub>M"
    let ?n = "(a +XCMPLX-0K2 b)gcdINT-2K3 b"
    have A2: "?n dividesNAT-DR1 b"
      using nat_d_def_5 sorry
    have "?n dividesNAT-DR1 a +XCMPLX-0K2 b"
      using nat_d_def_5 sorry
    then have "?n dividesNAT-DR1 a"
      using A2 nat_d_th_10 sorry
    then have "?n dividesNAT-DR1 a gcdINT-2K3 b"
      using A2 newton_th_50 sorry
    then have A3: "?n <=XXREAL-0R1 \<one>\<^sub>M +NAT-1K1 0NUMBERSK6"
      using A1 nat_d_th_7 sorry
    show "(a +XCMPLX-0K2 b)gcdINT-2K3 b =XBOOLE-0R4 \<one>\<^sub>M"
    proof-
      have cases: "?n =XBOOLE-0R4 \<one>\<^sub>M or ?n =XBOOLE-0R4 0NUMBERSK6"
        using A3 nat_1_th_9 sorry
      have case1: "(a +XCMPLX-0K2 b)gcdINT-2K3 b =XBOOLE-0R4 \<one>\<^sub>M implies (a +XCMPLX-0K2 b)gcdINT-2K3 b =XBOOLE-0R4 \<one>\<^sub>M"
      proof(rule impI)
        assume "?n =XBOOLE-0R4 \<one>\<^sub>M"
        thus "(a +XCMPLX-0K2 b)gcdINT-2K3 b =XBOOLE-0R4 \<one>\<^sub>M"
           sorry
      qed
      have case2: "(a +XCMPLX-0K2 b)gcdINT-2K3 b =XBOOLE-0R4 0NUMBERSK6 implies (a +XCMPLX-0K2 b)gcdINT-2K3 b =XBOOLE-0R4 \<one>\<^sub>M"
      proof(rule impI)
        assume "?n =XBOOLE-0R4 0NUMBERSK6"
        then have "b =XBOOLE-0R4 0NUMBERSK6"
          using int_2_th_5 sorry
        thus "(a +XCMPLX-0K2 b)gcdINT-2K3 b =XBOOLE-0R4 \<one>\<^sub>M"
          using A1 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem euler_1_th_8:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds  for c be NatNAT-1M1 holds (a +XCMPLX-0K2 b *XCMPLX-0K3 c)gcdINT-2K3 b =XBOOLE-0R4 a gcdINT-2K3 b"
proof(rule ballI,rule ballI,rule ballI)
  fix a assume [ty]: "a be NatNAT-1M1"
  fix b assume [ty]: "b be NatNAT-1M1"
  fix c assume [ty]: "c be NatNAT-1M1"
  let ?P = "\<lambda>Lamb1. (a +XCMPLX-0K2 b *XCMPLX-0K3 Lamb1)gcdINT-2K3 b =XBOOLE-0R4 a gcdINT-2K3 b"
  have A1: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
  proof-
    have " for kk be NatNAT-1M1 holds (a +XCMPLX-0K2 b *XCMPLX-0K3 kk)gcdINT-2K3 b =XBOOLE-0R4 a gcdINT-2K3 b implies (a +XCMPLX-0K2 b *XCMPLX-0K3 (kk +NAT-1K1 \<one>\<^sub>M))gcdINT-2K3 b =XBOOLE-0R4 a gcdINT-2K3 b"
    proof(rule ballI,rule impI)
      fix kk assume [ty]: "kk be NatNAT-1M1"
      assume A2: "(a +XCMPLX-0K2 b *XCMPLX-0K3 kk)gcdINT-2K3 b =XBOOLE-0R4 a gcdINT-2K3 b"
      have "(a +XCMPLX-0K2 b *XCMPLX-0K3 (kk +NAT-1K1 \<one>\<^sub>M))gcdINT-2K3 b =XBOOLE-0R4 a gcdINT-2K3 b"
      proof-
        show "(a +XCMPLX-0K2 b *XCMPLX-0K3 (kk +NAT-1K1 \<one>\<^sub>M))gcdINT-2K3 b =XBOOLE-0R4 a gcdINT-2K3 b"
        proof-
          have cases: "b =XBOOLE-0R4 0NUMBERSK6 or b >XXREAL-0R4 0NUMBERSK6"
             sorry
          have case1: "b =XBOOLE-0R4 0NUMBERSK6 implies (a +XCMPLX-0K2 b *XCMPLX-0K3 (kk +NAT-1K1 \<one>\<^sub>M))gcdINT-2K3 b =XBOOLE-0R4 a gcdINT-2K3 b"
          proof(rule impI)
            assume "b =XBOOLE-0R4 0NUMBERSK6"
            thus "(a +XCMPLX-0K2 b *XCMPLX-0K3 (kk +NAT-1K1 \<one>\<^sub>M))gcdINT-2K3 b =XBOOLE-0R4 a gcdINT-2K3 b"
               sorry
          qed
          have case2: "b >XXREAL-0R4 0NUMBERSK6 implies (a +XCMPLX-0K2 b *XCMPLX-0K3 (kk +NAT-1K1 \<one>\<^sub>M))gcdINT-2K3 b =XBOOLE-0R4 a gcdINT-2K3 b"
          proof(rule impI)
            assume A3: "b >XXREAL-0R4 0NUMBERSK6"
            let ?T = "a gcdINT-2K3 b"
            have A4: "a gcdINT-2K3 b >XXREAL-0R4 0NUMBERSK6"
              using A3 newton_th_58 sorry
            have A5: "a gcdINT-2K3 b dividesNAT-DR1 a +XCMPLX-0K2 b *XCMPLX-0K3 kk"
              using A2 nat_d_def_5 sorry
            then have A6: "a +XCMPLX-0K2 b *XCMPLX-0K3 kk =XBOOLE-0R4 (a gcdINT-2K3 b)*XCMPLX-0K3 ((a +XCMPLX-0K2 b *XCMPLX-0K3 kk)divNAT-DK3 (a gcdINT-2K3 b))"
              using nat_d_th_3 sorry
            have "(a +XCMPLX-0K2 b *XCMPLX-0K3 (kk +NAT-1K1 \<one>\<^sub>M))gcdINT-2K3 b =XBOOLE-0R4 a gcdINT-2K3 b"
            proof-
              show "(a +XCMPLX-0K2 b *XCMPLX-0K3 (kk +NAT-1K1 \<one>\<^sub>M))gcdINT-2K3 b =XBOOLE-0R4 a gcdINT-2K3 b"
              proof-
                have cases: "a +XCMPLX-0K2 b *XCMPLX-0K3 kk =XBOOLE-0R4 0NUMBERSK6 or a +XCMPLX-0K2 b *XCMPLX-0K3 kk >XXREAL-0R4 0NUMBERSK6"
                   sorry
                have case1: "a +XCMPLX-0K2 b *XCMPLX-0K3 kk =XBOOLE-0R4 0NUMBERSK6 implies (a +XCMPLX-0K2 b *XCMPLX-0K3 (kk +NAT-1K1 \<one>\<^sub>M))gcdINT-2K3 b =XBOOLE-0R4 a gcdINT-2K3 b"
                proof(rule impI)
                  assume A7: "a +XCMPLX-0K2 b *XCMPLX-0K3 kk =XBOOLE-0R4 0NUMBERSK6"
                  then have "a gcdINT-2K3 b =HIDDENR1 0NUMBERSK6 gcdINT-2K3 b"
                    using nat_1_th_7 sorry
                  also have "... = b"
                    using newton_th_52 sorry
                  finally have "a gcdINT-2K3 b =HIDDENR1 b"
                     sorry
                  thus "(a +XCMPLX-0K2 b *XCMPLX-0K3 (kk +NAT-1K1 \<one>\<^sub>M))gcdINT-2K3 b =XBOOLE-0R4 a gcdINT-2K3 b"
                    using A7 nat_d_th_32 sorry
                qed
                have case2: "a +XCMPLX-0K2 b *XCMPLX-0K3 kk >XXREAL-0R4 0NUMBERSK6 implies (a +XCMPLX-0K2 b *XCMPLX-0K3 (kk +NAT-1K1 \<one>\<^sub>M))gcdINT-2K3 b =XBOOLE-0R4 a gcdINT-2K3 b"
                proof(rule impI)
                  assume A8: "a +XCMPLX-0K2 b *XCMPLX-0K3 kk >XXREAL-0R4 0NUMBERSK6"
                  let ?T2 = "b divNAT-DK3 (a gcdINT-2K3 b)"
                  let ?T1 = "(a +XCMPLX-0K2 b *XCMPLX-0K3 kk)divNAT-DK3 (a gcdINT-2K3 b)"
                  have A9: "(a +XCMPLX-0K2 b *XCMPLX-0K3 kk)divNAT-DK3 (a gcdINT-2K3 b) <>HIDDENR2 0NUMBERSK6"
                    using A6 A8 sorry
                  have "a gcdINT-2K3 b dividesNAT-DR1 b"
                    using nat_d_def_5 sorry
                  then have A10: "b =XBOOLE-0R4 (a gcdINT-2K3 b)*XCMPLX-0K3 (b divNAT-DK3 (a gcdINT-2K3 b))"
                    using nat_d_th_3 sorry
                  then have "?T1 *XCMPLX-0K3 ?T gcdINT-2K3 ?T2 *XCMPLX-0K3 ?T =XBOOLE-0R4 ?T"
                    using A2 A5 nat_d_th_3 sorry
                  then have "(?T1,?T2)are-coprimeINT-2R1"
                    using A4 A9 euler_1_th_6 sorry
                  then have "?T1 gcdINT-2K3 ?T2 =XBOOLE-0R4 \<one>\<^sub>M"
                    using int_2_def_3 sorry
                  then have A11: "(?T1 +NAT-1K1 ?T2)gcdINT-2K3 ?T2 =XBOOLE-0R4 \<one>\<^sub>M"
                    using euler_1_th_7 sorry
                  have "(a +XCMPLX-0K2 b *XCMPLX-0K3 (kk +NAT-1K1 \<one>\<^sub>M))gcdINT-2K3 b =HIDDENR1 ((a +XCMPLX-0K2 b *XCMPLX-0K3 kk)+XCMPLX-0K2 b)gcdINT-2K3 b"
                     sorry
                  also have "... = (?T *XCMPLX-0K3 ?T1 +XCMPLX-0K2 ?T *XCMPLX-0K3 ?T2)gcdINT-2K3 ?T *XCMPLX-0K3 ?T2"
                    using A5 A10 nat_d_th_3 sorry
                  also have "... = ?T *XCMPLX-0K3 (?T1 +NAT-1K1 ?T2) gcdINT-2K3 ?T *XCMPLX-0K3 ?T2"
                     sorry
                  also have "... = a gcdINT-2K3 b"
                    using A11 euler_1_th_5 sorry
                  finally have "(a +XCMPLX-0K2 b *XCMPLX-0K3 (kk +NAT-1K1 \<one>\<^sub>M))gcdINT-2K3 b =HIDDENR1 a gcdINT-2K3 b"
                     sorry
                  thus "(a +XCMPLX-0K2 b *XCMPLX-0K3 (kk +NAT-1K1 \<one>\<^sub>M))gcdINT-2K3 b =XBOOLE-0R4 a gcdINT-2K3 b"
                     sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "(a +XCMPLX-0K2 b *XCMPLX-0K3 (kk +NAT-1K1 \<one>\<^sub>M))gcdINT-2K3 b =XBOOLE-0R4 a gcdINT-2K3 b"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "(a +XCMPLX-0K2 b *XCMPLX-0K3 (kk +NAT-1K1 \<one>\<^sub>M))gcdINT-2K3 b =XBOOLE-0R4 a gcdINT-2K3 b"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have A12: "?P(0NUMBERSK6)"
     sorry
  have " for c be NatNAT-1M1 holds ?P(c)"
    using nat_1_sch_2 A12 A1 sorry
  thus "(a +XCMPLX-0K2 b *XCMPLX-0K3 c)gcdINT-2K3 b =XBOOLE-0R4 a gcdINT-2K3 b"
     sorry
qed "sorry"

mtheorem euler_1_th_9:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (m,n)are-coprimeINT-2R1 implies ( ex k be NatNAT-1M1 st ( ex i0 be IntegerINT-1M1 st  ex j0 be IntegerINT-1M1 st k =XBOOLE-0R4 i0 *XCMPLX-0K3 m +XCMPLX-0K2 j0 *XCMPLX-0K3 n & k >XXREAL-0R4 0NUMBERSK6) & ( for l be NatNAT-1M1 holds ( ex i be IntegerINT-1M1 st  ex j be IntegerINT-1M1 st l =XBOOLE-0R4 i *XCMPLX-0K3 m +XCMPLX-0K2 j *XCMPLX-0K3 n & l >XXREAL-0R4 0NUMBERSK6) implies k <=XXREAL-0R1 l))"
proof-
  have " for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (m,n)are-coprimeINT-2R1 implies ( ex tVar1 be NatNAT-1M1 st ( ex i0 be IntegerINT-1M1 st  ex j0 be IntegerINT-1M1 st tVar1 =XBOOLE-0R4 i0 *XCMPLX-0K3 m +XCMPLX-0K2 j0 *XCMPLX-0K3 n & tVar1 >XXREAL-0R4 0NUMBERSK6) & ( for l be NatNAT-1M1 holds  not ( not ( for i be IntegerINT-1M1 holds  for j be IntegerINT-1M1 holds  not (l =XBOOLE-0R4 i *XCMPLX-0K3 m +XCMPLX-0K2 j *XCMPLX-0K3 n &  not l >XXREAL-0R4 0NUMBERSK6)) &  not tVar1 <=XXREAL-0R1 l)))"
  proof(rule ballI,rule ballI,rule impI)
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?P = "\<lambda>Lamb1.  ex i0 be IntegerINT-1M1 st  ex j0 be IntegerINT-1M1 st Lamb1 =XBOOLE-0R4 i0 *XCMPLX-0K3 m +XCMPLX-0K2 j0 *XCMPLX-0K3 n & Lamb1 >XXREAL-0R4 0NUMBERSK6"
    assume A1: "(m,n)are-coprimeINT-2R1"
    have "m >XXREAL-0R4 0NUMBERSK6 or n >XXREAL-0R4 0NUMBERSK6"
    proof-
      have " not m >XXREAL-0R4 0NUMBERSK6 &  not n >XXREAL-0R4 0NUMBERSK6 implies  False "
      proof(rule impI)
        assume " not m >XXREAL-0R4 0NUMBERSK6 &  not n >XXREAL-0R4 0NUMBERSK6"
        then have "m =XBOOLE-0R4 0NUMBERSK6 & n =XBOOLE-0R4 0NUMBERSK6"
           sorry
        then have "m gcdINT-2K3 n <>HIDDENR2 \<one>\<^sub>M"
          using nat_d_th_32 sorry
        thus " False "
          using A1 int_2_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    then have "\<one>\<^sub>M *XCMPLX-0K3 m +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 n >XXREAL-0R4 0NUMBERSK6"
       sorry
    then have A2: " ex k be NatNAT-1M1 st ?P(k)"
       sorry
    obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A3: "?P(k)"and A4: " for l be NatNAT-1M1 holds ?P(l) implies k <=XXREAL-0R1 l"
      using nat_1_sch_5 A2 sorry
    show " ex tVar1 be NatNAT-1M1 st ( ex i0 be IntegerINT-1M1 st  ex j0 be IntegerINT-1M1 st tVar1 =XBOOLE-0R4 i0 *XCMPLX-0K3 m +XCMPLX-0K2 j0 *XCMPLX-0K3 n & tVar1 >XXREAL-0R4 0NUMBERSK6) & ( for l be NatNAT-1M1 holds  not ( not ( for i be IntegerINT-1M1 holds  for j be IntegerINT-1M1 holds  not (l =XBOOLE-0R4 i *XCMPLX-0K3 m +XCMPLX-0K2 j *XCMPLX-0K3 n &  not l >XXREAL-0R4 0NUMBERSK6)) &  not tVar1 <=XXREAL-0R1 l))"
    proof(rule bexI[of _ "k"],rule conjMI,rule ballI)
      show " ex i0 be IntegerINT-1M1 st  ex j0 be IntegerINT-1M1 st k =XBOOLE-0R4 i0 *XCMPLX-0K3 m +XCMPLX-0K2 j0 *XCMPLX-0K3 n & k >XXREAL-0R4 0NUMBERSK6"
        using A3 sorry
      fix l assume [ty]: "l be NatNAT-1M1"
      show " not ( not ( for i be IntegerINT-1M1 holds  for j be IntegerINT-1M1 holds  not (l =XBOOLE-0R4 i *XCMPLX-0K3 m +XCMPLX-0K2 j *XCMPLX-0K3 n &  not l >XXREAL-0R4 0NUMBERSK6)) &  not k <=XXREAL-0R1 l)"
        using A4 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem euler_1_th_10:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (m,n)are-coprimeINT-2R1 implies ( for k be NatNAT-1M1 holds  ex i be IntegerINT-1M1 st  ex j be IntegerINT-1M1 st i *XCMPLX-0K3 m +XCMPLX-0K2 j *XCMPLX-0K3 n =XBOOLE-0R4 k)"
proof-
  have " for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (m,n)are-coprimeINT-2R1 implies ( for k be NatNAT-1M1 holds  not ( for i be IntegerINT-1M1 holds  for j be IntegerINT-1M1 holds  not i *XCMPLX-0K3 m +XCMPLX-0K2 j *XCMPLX-0K3 n =XBOOLE-0R4 k))"
  proof(rule ballI,rule ballI,rule impI,rule ballI)
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    obtain a9 O9 where 
      [ty]:"a9 be IntegerINT-1M1" and a9Def:"a9 = \<one>\<^sub>M" and
      [ty]:"O9 be IntegerINT-1M1" and O9Def:"O9 = 0NUMBERSK6"
       sorry
    assume A1: "(m,n)are-coprimeINT-2R1"
    then obtain a where
      [ty]:"a be NatNAT-1M1" and 
      A2: " ex i0 be IntegerINT-1M1 st  ex j0 be IntegerINT-1M1 st a =XBOOLE-0R4 i0 *XCMPLX-0K3 m +XCMPLX-0K2 j0 *XCMPLX-0K3 n & a >XXREAL-0R4 0NUMBERSK6"and A3: " for c be NatNAT-1M1 holds ( ex i be IntegerINT-1M1 st  ex j be IntegerINT-1M1 st c =XBOOLE-0R4 i *XCMPLX-0K3 m +XCMPLX-0K2 j *XCMPLX-0K3 n & c >XXREAL-0R4 0NUMBERSK6) implies a <=XXREAL-0R1 c"
      using euler_1_th_9 sorry
    fix k assume [ty]: "k be NatNAT-1M1"
    obtain i0 j0 where
      [ty]:"i0 be IntegerINT-1M1" "j0 be IntegerINT-1M1" and 
      A4: "a =XBOOLE-0R4 i0 *XCMPLX-0K3 m +XCMPLX-0K2 j0 *XCMPLX-0K3 n"and A5: "a >XXREAL-0R4 0NUMBERSK6"
      using A2 sorry
    have A6: " for c be NatNAT-1M1 holds ( ex i be IntegerINT-1M1 st  ex j be IntegerINT-1M1 st c =XBOOLE-0R4 i *XCMPLX-0K3 m +XCMPLX-0K2 j *XCMPLX-0K3 n & c >XXREAL-0R4 0NUMBERSK6) implies c modNAT-DK4 a =XBOOLE-0R4 0NUMBERSK6"
    proof-
      have " for b be NatNAT-1M1 holds ( ex i be IntegerINT-1M1 st  ex j be IntegerINT-1M1 st b =XBOOLE-0R4 i *XCMPLX-0K3 m +XCMPLX-0K2 j *XCMPLX-0K3 n & b >XXREAL-0R4 0NUMBERSK6) implies (b modNAT-DK4 a <>HIDDENR2 0NUMBERSK6 implies  False )"
      proof(rule ballI,rule impI,rule impI)
        fix b assume [ty]: "b be NatNAT-1M1"
        assume " ex i be IntegerINT-1M1 st  ex j be IntegerINT-1M1 st b =XBOOLE-0R4 i *XCMPLX-0K3 m +XCMPLX-0K2 j *XCMPLX-0K3 n & b >XXREAL-0R4 0NUMBERSK6"
        then obtain i j where
          [ty]:"i be IntegerINT-1M1" "j be IntegerINT-1M1" and 
          A7: "b =XBOOLE-0R4 i *XCMPLX-0K3 m +XCMPLX-0K2 j *XCMPLX-0K3 n"and "b >XXREAL-0R4 0NUMBERSK6"
           sorry
        let ?t2 = "j -XCMPLX-0K6 (b divNAT-DK3 a)*XCMPLX-0K3 j0"
        let ?t1 = "i -XCMPLX-0K6 (b divNAT-DK3 a)*XCMPLX-0K3 i0"
        have A8: "((b modNAT-DK4 a)+XCMPLX-0K2 a *XCMPLX-0K3 (b divNAT-DK3 a))-XCMPLX-0K6 a *XCMPLX-0K3 (b divNAT-DK3 a) =XBOOLE-0R4 b -XCMPLX-0K6 a *XCMPLX-0K3 (b divNAT-DK3 a)"
          using A5 nat_d_th_2 sorry
        then obtain c where 
          [ty]:"c be ElementSUBSET-1M1-of NATNUMBERSK1" and cDef:"c = ?t1 *XCMPLX-0K3 m +XCMPLX-0K2 ?t2 *XCMPLX-0K3 n"
          using A4 A7 sorry
        assume A9: "b modNAT-DK4 a <>HIDDENR2 0NUMBERSK6"
        have "c <XXREAL-0R3 a"
          using A4 A5 A7 A8 nat_d_th_1 sorry
        thus " False "
          using A3 A4 A9 A7 A8 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A10: "a dividesNAT-DR1 n"
    proof-
      show "a dividesNAT-DR1 n"
      proof-
        have cases: "n =XBOOLE-0R4 0NUMBERSK6 or n >XXREAL-0R4 0NUMBERSK6"
           sorry
        have case1: "n =XBOOLE-0R4 0NUMBERSK6 implies a dividesNAT-DR1 n"
        proof(rule impI)
          assume "n =XBOOLE-0R4 0NUMBERSK6"
          thus "a dividesNAT-DR1 n"
            using nat_d_th_6 sorry
        qed
        have case2: "n >XXREAL-0R4 0NUMBERSK6 implies a dividesNAT-DR1 n"
        proof(rule impI)
          assume "n >XXREAL-0R4 0NUMBERSK6"
          then have "O9 *XCMPLX-0K3 m +XCMPLX-0K2 a9 *XCMPLX-0K3 n >XXREAL-0R4 0NUMBERSK6"
             sorry
          then have "n modNAT-DK4 a =XBOOLE-0R4 0NUMBERSK6"
            using A6 sorry
          then have "n =XBOOLE-0R4 a *XCMPLX-0K3 (n divNAT-DK3 a) +NAT-1K1 0NUMBERSK6"
            using A2 nat_d_th_2 sorry
          thus "a dividesNAT-DR1 n"
            using nat_d_th_3 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    have "a dividesNAT-DR1 m"
    proof-
      show "a dividesNAT-DR1 m"
      proof-
        have cases: "m =XBOOLE-0R4 0NUMBERSK6 or m >XXREAL-0R4 0NUMBERSK6"
           sorry
        have case1: "m =XBOOLE-0R4 0NUMBERSK6 implies a dividesNAT-DR1 m"
        proof(rule impI)
          assume "m =XBOOLE-0R4 0NUMBERSK6"
          thus "a dividesNAT-DR1 m"
            using nat_d_th_6 sorry
        qed
        have case2: "m >XXREAL-0R4 0NUMBERSK6 implies a dividesNAT-DR1 m"
        proof(rule impI)
          assume "m >XXREAL-0R4 0NUMBERSK6"
          then have "a9 *XCMPLX-0K3 m +XCMPLX-0K2 O9 *XCMPLX-0K3 n >XXREAL-0R4 0NUMBERSK6"
             sorry
          then have "m modNAT-DK4 a =XBOOLE-0R4 0NUMBERSK6"
            using A6 sorry
          then have "m =XBOOLE-0R4 a *XCMPLX-0K3 (m divNAT-DK3 a) +NAT-1K1 0NUMBERSK6"
            using A2 nat_d_th_2 sorry
          thus "a dividesNAT-DR1 m"
            using nat_d_th_3 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    then have "a dividesNAT-DR1 m gcdINT-2K3 n"
      using A10 nat_d_def_5 sorry
    then have "a dividesNAT-DR1 \<one>\<^sub>M"
      using A1 int_2_def_3 sorry
    then have " ex b be NatNAT-1M1 st \<one>\<^sub>M =XBOOLE-0R4 a *XCMPLX-0K3 b"
      using nat_d_def_3 sorry
    then have "i0 *XCMPLX-0K3 m +XCMPLX-0K2 j0 *XCMPLX-0K3 n =XBOOLE-0R4 \<one>\<^sub>M"
      using A4 nat_1_th_15 sorry
    then have "k =HIDDENR1 k *XCMPLX-0K3 (i0 *XCMPLX-0K3 m +XCMPLX-0K2 j0 *XCMPLX-0K3 n)"
       sorry
    also have "... = (k *XCMPLX-0K3 i0)*XCMPLX-0K3 m +XCMPLX-0K2 k *XCMPLX-0K3 (j0 *XCMPLX-0K3 n)"
       sorry
    finally have "k =HIDDENR1 (k *XCMPLX-0K3 i0)*XCMPLX-0K3 m +XCMPLX-0K2 k *XCMPLX-0K3 (j0 *XCMPLX-0K3 n)"
       sorry
    then have "k =XBOOLE-0R4 (k *XCMPLX-0K3 i0)*XCMPLX-0K3 m +XCMPLX-0K2 (k *XCMPLX-0K3 j0)*XCMPLX-0K3 n"
       sorry
    thus " not ( for i be IntegerINT-1M1 holds  for j be IntegerINT-1M1 holds  not i *XCMPLX-0K3 m +XCMPLX-0K2 j *XCMPLX-0K3 n =XBOOLE-0R4 k)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem euler_1_th_11:
" for A be setHIDDENM2 holds  for B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(A,B) holds f be bijectiveFUNCT-2V3\<^bsub>(A,B)\<^esub> implies cardCARD-1K1 A =XBOOLE-0R4 cardCARD-1K1 B"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix A assume [ty]: "A be setHIDDENM2"
  fix B assume [ty]: "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix f assume [ty]: "f be FunctionFUNCT-2M1-of(A,B)"
  assume "f be bijectiveFUNCT-2V3\<^bsub>(A,B)\<^esub>"
  then have A1: "f be one-to-oneFUNCT-1V2\<bar>ontoFUNCT-2V2\<^bsub>(B)\<^esub>"
     sorry
  have A2: "A =XBOOLE-0R4 domRELSET-1K1\<^bsub>(A)\<^esub> f"
    using funct_2_def_1 sorry
  have "B c=TARSKIR1 rngRELSET-1K2\<^bsub>(B)\<^esub> f"
    using A1 sorry
  then have A3: "cardCARD-1K1 B c=ORDINAL1R1 cardCARD-1K1 A"
    using A2 card_1_th_12 sorry
  have "cardCARD-1K1 A c=ORDINAL1R1 cardCARD-1K1 B"
    using A2 A1 card_1_th_10 sorry
  thus "cardCARD-1K1 A =XBOOLE-0R4 cardCARD-1K1 B"
    using A3 sorry
qed "sorry"

mtheorem euler_1_th_12:
" for i be IntegerINT-1M1 holds  for k be IntegerINT-1M1 holds  for n be IntegerINT-1M1 holds (i +XCMPLX-0K2 k *XCMPLX-0K3 n)modINT-1K6 n =HIDDENR1 i modINT-1K6 n"
proof(rule ballI,rule ballI,rule ballI)
  fix i assume [ty]: "i be IntegerINT-1M1"
  fix k assume [ty]: "k be IntegerINT-1M1"
  fix n assume [ty]: "n be IntegerINT-1M1"
  show "(i +XCMPLX-0K2 k *XCMPLX-0K3 n)modINT-1K6 n =HIDDENR1 i modINT-1K6 n"
  proof-
    have cases: "n <>HIDDENR2 0NUMBERSK6 or n =HIDDENR1 0NUMBERSK6"
       sorry
    have case1: "n <>HIDDENR2 0NUMBERSK6 implies (i +XCMPLX-0K2 k *XCMPLX-0K3 n)modINT-1K6 n =HIDDENR1 i modINT-1K6 n"
    proof(rule impI)
      assume A1: "n <>HIDDENR2 0NUMBERSK6"
      then have "(i +XCMPLX-0K2 k *XCMPLX-0K3 n)modINT-1K6 n =HIDDENR1 (i +XCMPLX-0K2 k *XCMPLX-0K3 n)-XCMPLX-0K6 ((i +XCMPLX-0K2 k *XCMPLX-0K3 n)divINT-1K5 n)*XCMPLX-0K3 n"
        using int_1_def_10 sorry
      also have "... = (i +XCMPLX-0K2 k *XCMPLX-0K3 n)-XCMPLX-0K6 ([\\INT-1K2 (i +XCMPLX-0K2 k *XCMPLX-0K3 n)/XCMPLX-0K7 n /])*XCMPLX-0K3 n"
        using int_1_def_9 sorry
      also have "... = (i +XCMPLX-0K2 k *XCMPLX-0K3 n)-XCMPLX-0K6 ([\\INT-1K2 i /XCMPLX-0K7 n +XCMPLX-0K2 (k *XCMPLX-0K3 n)/XCMPLX-0K7 n /])*XCMPLX-0K3 n"
        using xcmplx_1_th_62 sorry
      also have "... = (i +XCMPLX-0K2 k *XCMPLX-0K3 n)-XCMPLX-0K6 ([\\INT-1K2 i /XCMPLX-0K7 n +XCMPLX-0K2 k /XCMPLX-0K7 (n /XCMPLX-0K7 n) /])*XCMPLX-0K3 n"
        using xcmplx_1_th_77 sorry
      also have "... = (i +XCMPLX-0K2 k *XCMPLX-0K3 n)-XCMPLX-0K6 ([\\INT-1K2 i /XCMPLX-0K7 n +XCMPLX-0K2 k /XCMPLX-0K7 \<one>\<^sub>M /])*XCMPLX-0K3 n"
        using A1 xcmplx_1_th_60 sorry
      also have "... = (i +XCMPLX-0K2 k *XCMPLX-0K3 n)-XCMPLX-0K6 ([\\INT-1K2 i /XCMPLX-0K7 n /] +XCMPLX-0K2 k)*XCMPLX-0K3 n"
        using int_1_th_28 sorry
      also have "... = i -XCMPLX-0K6 ([\\INT-1K2 i /XCMPLX-0K7 n /])*XCMPLX-0K3 n"
         sorry
      also have "... = i -XCMPLX-0K6 (i divINT-1K5 n)*XCMPLX-0K3 n"
        using int_1_def_9 sorry
      also have "... = i modINT-1K6 n"
        using A1 int_1_def_10 sorry
      finally have "(i +XCMPLX-0K2 k *XCMPLX-0K3 n)modINT-1K6 n =HIDDENR1 i modINT-1K6 n"
         sorry
      thus "(i +XCMPLX-0K2 k *XCMPLX-0K3 n)modINT-1K6 n =HIDDENR1 i modINT-1K6 n"
         sorry
    qed
    have case2: "n =HIDDENR1 0NUMBERSK6 implies (i +XCMPLX-0K2 k *XCMPLX-0K3 n)modINT-1K6 n =HIDDENR1 i modINT-1K6 n"
    proof(rule impI)
      assume "n =HIDDENR1 0NUMBERSK6"
      thus "(i +XCMPLX-0K2 k *XCMPLX-0K3 n)modINT-1K6 n =HIDDENR1 i modINT-1K6 n"
         sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem euler_1_th_13:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds  for c be NatNAT-1M1 holds c dividesNAT-DR1 a *XCMPLX-0K3 b & (a,c)are-coprimeINT-2R1 implies c dividesNAT-DR1 b"
proof-
  have " for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds  for c be NatNAT-1M1 holds c dividesNAT-DR1 a *XCMPLX-0K3 b & (a,c)are-coprimeINT-2R1 implies c dividesNAT-DR1 b"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be NatNAT-1M1"
    fix b assume [ty]: "b be NatNAT-1M1"
    fix c assume [ty]: "c be NatNAT-1M1"
    assume A1: "c dividesNAT-DR1 a *XCMPLX-0K3 b"
      and A2: "(a,c)are-coprimeINT-2R1"
    have A3: "c dividesNAT-DR1 c *XCMPLX-0K3 b"
      using nat_d_th_9 sorry
    have "a gcdINT-2K3 c =XBOOLE-0R4 \<one>\<^sub>M"
      using A2 int_2_def_3 sorry
    then have "a *XCMPLX-0K3 b gcdINT-2K3 c *XCMPLX-0K3 b =XBOOLE-0R4 b"
      using euler_1_th_5 sorry
    thus "c dividesNAT-DR1 b"
      using A1 A3 newton_th_50 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem euler_1_th_14:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds  for c be NatNAT-1M1 holds ((a <>HIDDENR2 0NUMBERSK6 & c <>HIDDENR2 0NUMBERSK6) & (a,c)are-coprimeINT-2R1) & (b,c)are-coprimeINT-2R1 implies (a *XCMPLX-0K3 b,c)are-coprimeINT-2R1"
proof-
  have " for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds  for c be NatNAT-1M1 holds a <>HIDDENR2 0NUMBERSK6 & (c <>HIDDENR2 0NUMBERSK6 & ((a,c)are-coprimeINT-2R1 & (b,c)are-coprimeINT-2R1)) implies (a *XCMPLX-0K3 b,c)are-coprimeINT-2R1"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be NatNAT-1M1"
    fix b assume [ty]: "b be NatNAT-1M1"
    fix c assume [ty]: "c be NatNAT-1M1"
    assume A1: "a <>HIDDENR2 0NUMBERSK6"
      and A2: "c <>HIDDENR2 0NUMBERSK6"
      and A3: "(a,c)are-coprimeINT-2R1"
      and A4: "(b,c)are-coprimeINT-2R1"
    have A5: "a gcdINT-2K3 c =XBOOLE-0R4 \<one>\<^sub>M"
      using A3 int_2_def_3 sorry
    have A6: "a *XCMPLX-0K3 b gcdINT-2K3 c dividesNAT-DR1 c"
      using nat_d_def_5 sorry
    have "(a *XCMPLX-0K3 b gcdINT-2K3 c)gcdINT-2K3 a dividesNAT-DR1 a *XCMPLX-0K3 b gcdINT-2K3 c"
      using nat_d_def_5 sorry
    then have "(a *XCMPLX-0K3 b gcdINT-2K3 c)gcdINT-2K3 a dividesNAT-DR1 a & (a *XCMPLX-0K3 b gcdINT-2K3 c)gcdINT-2K3 a dividesNAT-DR1 c"
      using A6 nat_d_th_4 nat_d_def_5 sorry
    then have "(a *XCMPLX-0K3 b gcdINT-2K3 c)gcdINT-2K3 a dividesNAT-DR1 \<one>\<^sub>M"
      using A5 newton_th_50 sorry
    then have A7: "(a *XCMPLX-0K3 b gcdINT-2K3 c)gcdINT-2K3 a <=XXREAL-0R1 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
      using nat_d_th_7 sorry
    have "(a *XCMPLX-0K3 b gcdINT-2K3 c)gcdINT-2K3 a <>HIDDENR2 0NUMBERSK6"
      using A1 newton_th_58 sorry
    then have "(a *XCMPLX-0K3 b gcdINT-2K3 c)gcdINT-2K3 a =XBOOLE-0R4 \<one>\<^sub>M"
      using A7 nat_1_th_9 sorry
    then have "a *XCMPLX-0K3 b gcdINT-2K3 c dividesNAT-DR1 a *XCMPLX-0K3 b & (a,a *XCMPLX-0K3 b gcdINT-2K3 c)are-coprimeINT-2R1"
      using int_2_def_3 nat_d_def_5 sorry
    then have A8: "a *XCMPLX-0K3 b gcdINT-2K3 c dividesNAT-DR1 b"
      using euler_1_th_13 sorry
    have "b gcdINT-2K3 c =XBOOLE-0R4 \<one>\<^sub>M"
      using A4 int_2_def_3 sorry
    then have "a *XCMPLX-0K3 b gcdINT-2K3 c dividesNAT-DR1 \<one>\<^sub>M"
      using A6 A8 newton_th_50 sorry
    then have A9: "a *XCMPLX-0K3 b gcdINT-2K3 c <=XXREAL-0R1 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
      using nat_d_th_7 sorry
    have "a *XCMPLX-0K3 b gcdINT-2K3 c >XXREAL-0R4 0NUMBERSK6"
      using A2 newton_th_58 sorry
    then have "a *XCMPLX-0K3 b gcdINT-2K3 c =XBOOLE-0R4 \<one>\<^sub>M"
      using A9 nat_1_th_9 sorry
    thus "(a *XCMPLX-0K3 b,c)are-coprimeINT-2R1"
      using int_2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem euler_1_th_15:
" for i be IntegerINT-1M1 holds  for x be IntegerINT-1M1 holds  for y be IntegerINT-1M1 holds x <>HIDDENR2 0NUMBERSK6 & i >=XXREAL-0R2 0NUMBERSK6 implies i *XCMPLX-0K3 x gcdINT-2K3 i *XCMPLX-0K3 y =XBOOLE-0R4 i *XCMPLX-0K3 (x gcdINT-2K3 y)"
proof-
  have " for i be IntegerINT-1M1 holds  for x be IntegerINT-1M1 holds  for y be IntegerINT-1M1 holds x <>HIDDENR2 0NUMBERSK6 & i >=XXREAL-0R2 0NUMBERSK6 implies i *XCMPLX-0K3 x gcdINT-2K3 i *XCMPLX-0K3 y =XBOOLE-0R4 i *XCMPLX-0K3 (x gcdINT-2K3 y)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix i assume [ty]: "i be IntegerINT-1M1"
    fix x assume [ty]: "x be IntegerINT-1M1"
    fix y assume [ty]: "y be IntegerINT-1M1"
    assume A1: "x <>HIDDENR2 0NUMBERSK6"
      and A2: "i >=XXREAL-0R2 0NUMBERSK6"
    obtain a2 b2 where
      [ty]:"a2 be IntegerINT-1M1" "b2 be IntegerINT-1M1" and 
      A3: "x =HIDDENR1 (x gcdINT-2K3 y)*XCMPLX-0K3 a2 & y =HIDDENR1 (x gcdINT-2K3 y)*XCMPLX-0K3 b2"and A4: "(a2,b2)are-coprimeINT-2R1"
      using A1 int_2_th_23 sorry
    have "i *XCMPLX-0K3 x =XBOOLE-0R4 (i *XCMPLX-0K3 (x gcdINT-2K3 y))*XCMPLX-0K3 a2 & i *XCMPLX-0K3 y =XBOOLE-0R4 (i *XCMPLX-0K3 (x gcdINT-2K3 y))*XCMPLX-0K3 b2"
      using A3 sorry
    then have A5: "i *XCMPLX-0K3 x gcdINT-2K3 i *XCMPLX-0K3 y =HIDDENR1  |.INT-2K1 i *XCMPLX-0K3 (x gcdINT-2K3 y) .|"
      using A4 int_2_th_24 sorry
    also have "... = ( |.INT-2K1 i.|)*NAT-1K2 ( |.INT-2K1 x gcdINT-2K3 y .|)"
      using complex1_th_65 sorry
    finally have "i *XCMPLX-0K3 x gcdINT-2K3 i *XCMPLX-0K3 y =HIDDENR1 ( |.INT-2K1 i.|)*NAT-1K2 ( |.INT-2K1 x gcdINT-2K3 y .|)"
       sorry
    have "i =HIDDENR1  |.INT-2K1 i.|"
      using A2 absvalue_def_1 sorry
    thus "i *XCMPLX-0K3 x gcdINT-2K3 i *XCMPLX-0K3 y =XBOOLE-0R4 i *XCMPLX-0K3 (x gcdINT-2K3 y)"
      using A5 absvalue_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem euler_1_th_16:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds  for x be IntegerINT-1M1 holds a <>HIDDENR2 0NUMBERSK6 implies (a +XCMPLX-0K2 x *XCMPLX-0K3 b)gcdINT-2K3 b =XBOOLE-0R4 a gcdINT-2K3 b"
proof-
  have " for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds  for xx be IntegerINT-1M1 holds a <>HIDDENR2 0NUMBERSK6 implies (a +XCMPLX-0K2 xx *XCMPLX-0K3 b)gcdINT-2K3 b =XBOOLE-0R4 a gcdINT-2K3 b"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be NatNAT-1M1"
    fix b assume [ty]: "b be NatNAT-1M1"
    fix xx assume [ty]: "xx be IntegerINT-1M1"
    let ?i = "a gcdINT-2K3 b"
    have A1: "b =XBOOLE-0R4  |.INT-2K1 b.|"
      using absvalue_def_1 sorry
    assume A2: "a <>HIDDENR2 0NUMBERSK6"
    have A3: " for m be NatNAT-1M1 holds m dividesNAT-DR1  |.INT-2K1 a +XCMPLX-0K2 xx *XCMPLX-0K3 b .| & m dividesNAT-DR1  |.INT-2K1 b.| implies m dividesNAT-DR1 ?i"
    proof-
      have " for mm be NatNAT-1M1 holds mm dividesNAT-DR1  |.INT-2K1 a +XCMPLX-0K2 xx *XCMPLX-0K3 b .| & mm dividesNAT-DR1  |.INT-2K1 b.| implies mm dividesNAT-DR1 a gcdINT-2K3 b"
      proof(rule ballI,rule impMI ,rule impI)
        fix mm assume [ty]: "mm be NatNAT-1M1"
        assume A4: "mm dividesNAT-DR1  |.INT-2K1 a +XCMPLX-0K2 xx *XCMPLX-0K3 b .|"
          and A5: "mm dividesNAT-DR1  |.INT-2K1 b.|"
        obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A6: "b =XBOOLE-0R4 mm *XCMPLX-0K3 n"
          using A1 A5 nat_d_def_3 sorry
        have 
          [ty]:"mm be ElementSUBSET-1M1-of NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "mm dividesNAT-DR1 a"
        proof-
          show "mm dividesNAT-DR1 a"
          proof-
            have cases: "a +XCMPLX-0K2 xx *XCMPLX-0K3 b >=XXREAL-0R2 0NUMBERSK6 or a +XCMPLX-0K2 xx *XCMPLX-0K3 b <XXREAL-0R3 0NUMBERSK6"
               sorry
            have case1: "a +XCMPLX-0K2 xx *XCMPLX-0K3 b >=XXREAL-0R2 0NUMBERSK6 implies mm dividesNAT-DR1 a"
            proof(rule impI)
              assume "a +XCMPLX-0K2 xx *XCMPLX-0K3 b >=XXREAL-0R2 0NUMBERSK6"
              then have " |.INT-2K1 a +XCMPLX-0K2 xx *XCMPLX-0K3 b .| =XBOOLE-0R4 a +XCMPLX-0K2 xx *XCMPLX-0K3 b"
                using absvalue_def_1 sorry
              then obtain t where
                [ty]:"t be IntegerINT-1M1" and 
                A7: "a +XCMPLX-0K2 xx *XCMPLX-0K3 b =XBOOLE-0R4 mm *XCMPLX-0K3 t"
                using A4 int_1_def_3 sorry
              have A8: "a =HIDDENR1 mm *XCMPLX-0K3 t -XCMPLX-0K6 mm *XCMPLX-0K3 (xx *XCMPLX-0K3 n)"
                using A6 A7 xcmplx_1_th_26 sorry
              also have "... = mm *XCMPLX-0K3 (t -XCMPLX-0K6 xx *XCMPLX-0K3 n)"
                 sorry
              finally have "a =HIDDENR1 mm *XCMPLX-0K3 (t -XCMPLX-0K6 xx *XCMPLX-0K3 n)"
                 sorry
              then have "t -XCMPLX-0K6 xx *XCMPLX-0K3 n >=XXREAL-0R2 0NUMBERSK6"
                using A2 sorry
              then obtain tt where 
                [ty]:"tt be ElementSUBSET-1M1-of NATNUMBERSK1" and ttDef:"tt = t -XCMPLX-0K6 xx *XCMPLX-0K3 n"
                using int_1_th_3 sorry
              have "a =XBOOLE-0R4 mm *NAT-1K2 tt"
                using A8 sorry
              thus "mm dividesNAT-DR1 a"
                using nat_d_def_3 sorry
            qed
            have case2: "a +XCMPLX-0K2 xx *XCMPLX-0K3 b <XXREAL-0R3 0NUMBERSK6 implies mm dividesNAT-DR1 a"
            proof(rule impI)
              assume "a +XCMPLX-0K2 xx *XCMPLX-0K3 b <XXREAL-0R3 0NUMBERSK6"
              then have " |.INT-2K1 a +XCMPLX-0K2 xx *XCMPLX-0K3 b .| =HIDDENR1 -XCMPLX-0K4 (a +XCMPLX-0K2 xx *XCMPLX-0K3 b)"
                using absvalue_def_1 sorry
              then obtain t where
                [ty]:"t be IntegerINT-1M1" and 
                A9: "-XCMPLX-0K4 (a +XCMPLX-0K2 xx *XCMPLX-0K3 b) =HIDDENR1 mm *XCMPLX-0K3 t"
                using A4 int_1_def_3 sorry
              have A10: "a =HIDDENR1 (-XCMPLX-0K4 mm *XCMPLX-0K3 t)-XCMPLX-0K6 mm *XCMPLX-0K3 (xx *XCMPLX-0K3 n)"
                using A6 A9 xcmplx_1_th_26 sorry
              also have "... = mm *XCMPLX-0K3 ((-XCMPLX-0K4 t)-XCMPLX-0K6 xx *XCMPLX-0K3 n)"
                 sorry
              finally have "a =HIDDENR1 mm *XCMPLX-0K3 ((-XCMPLX-0K4 t)-XCMPLX-0K6 xx *XCMPLX-0K3 n)"
                 sorry
              then have "(-XCMPLX-0K4 t)-XCMPLX-0K6 xx *XCMPLX-0K3 n >=XXREAL-0R2 0NUMBERSK6"
                using A2 sorry
              then obtain tt where 
                [ty]:"tt be ElementSUBSET-1M1-of NATNUMBERSK1" and ttDef:"tt = (-XCMPLX-0K4 t)-XCMPLX-0K6 xx *XCMPLX-0K3 n"
                using int_1_th_3 sorry
              have "a =XBOOLE-0R4 mm *NAT-1K2 tt"
                using A10 sorry
              thus "mm dividesNAT-DR1 a"
                using nat_d_def_3 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "mm dividesNAT-DR1 a gcdINT-2K3 b"
          using A1 A5 newton_th_50 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "?i dividesNAT-DR1 a"
      using nat_d_def_5 sorry
    then have A11: "a =XBOOLE-0R4 ?i *XCMPLX-0K3 (a divNAT-DK3 ?i)"
      using nat_d_th_3 sorry
    have A12: "?i dividesNAT-DR1 b"
      using nat_d_def_5 sorry
    then have A13: "b =XBOOLE-0R4 ?i *XCMPLX-0K3 (b divNAT-DK3 ?i)"
      using nat_d_th_3 sorry
    have "?i dividesNAT-DR1  |.INT-2K1 a +XCMPLX-0K2 xx *XCMPLX-0K3 b .|"
    proof-
      have "a gcdINT-2K3 b dividesNAT-DR1  |.INT-2K1 a +XCMPLX-0K2 xx *XCMPLX-0K3 b .|"
      proof-
        show "a gcdINT-2K3 b dividesNAT-DR1  |.INT-2K1 a +XCMPLX-0K2 xx *XCMPLX-0K3 b .|"
        proof-
          have cases: "a +XCMPLX-0K2 xx *XCMPLX-0K3 b <XXREAL-0R3 0NUMBERSK6 or a +XCMPLX-0K2 xx *XCMPLX-0K3 b >=XXREAL-0R2 0NUMBERSK6"
             sorry
          have case1: "a +XCMPLX-0K2 xx *XCMPLX-0K3 b <XXREAL-0R3 0NUMBERSK6 implies a gcdINT-2K3 b dividesNAT-DR1  |.INT-2K1 a +XCMPLX-0K2 xx *XCMPLX-0K3 b .|"
          proof(rule impI)
            assume "a +XCMPLX-0K2 xx *XCMPLX-0K3 b <XXREAL-0R3 0NUMBERSK6"
            then have A14: " |.INT-2K1 a +XCMPLX-0K2 xx *XCMPLX-0K3 b .| =HIDDENR1 -XCMPLX-0K4 (a +XCMPLX-0K2 xx *XCMPLX-0K3 b)"
              using absvalue_def_1 sorry
            have "-XCMPLX-0K4 (a +XCMPLX-0K2 xx *XCMPLX-0K3 b) =HIDDENR1 ?i *XCMPLX-0K3 (-XCMPLX-0K4 ((a divNAT-DK3 ?i)+XCMPLX-0K2 xx *XCMPLX-0K3 (b divNAT-DK3 ?i)))"
              using A11 A13 sorry
            thus "a gcdINT-2K3 b dividesNAT-DR1  |.INT-2K1 a +XCMPLX-0K2 xx *XCMPLX-0K3 b .|"
              using A14 int_1_def_3 sorry
          qed
          have case2: "a +XCMPLX-0K2 xx *XCMPLX-0K3 b >=XXREAL-0R2 0NUMBERSK6 implies a gcdINT-2K3 b dividesNAT-DR1  |.INT-2K1 a +XCMPLX-0K2 xx *XCMPLX-0K3 b .|"
          proof(rule impI)
            assume "a +XCMPLX-0K2 xx *XCMPLX-0K3 b >=XXREAL-0R2 0NUMBERSK6"
            then have A15: " |.INT-2K1 a +XCMPLX-0K2 xx *XCMPLX-0K3 b .| =XBOOLE-0R4 a +XCMPLX-0K2 xx *XCMPLX-0K3 b"
              using absvalue_def_1 sorry
            have "a +XCMPLX-0K2 xx *XCMPLX-0K3 b =XBOOLE-0R4 ?i *XCMPLX-0K3 ((a divNAT-DK3 ?i)+XCMPLX-0K2 xx *XCMPLX-0K3 (b divNAT-DK3 ?i))"
              using A11 A13 sorry
            thus "a gcdINT-2K3 b dividesNAT-DR1  |.INT-2K1 a +XCMPLX-0K2 xx *XCMPLX-0K3 b .|"
              using A15 int_1_def_3 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus " ?thesis "
         sorry
    qed
    then have " |.INT-2K1 a +XCMPLX-0K2 xx *XCMPLX-0K3 b .| gcdINT-2K3  |.INT-2K1 b.| =XBOOLE-0R4 ?i"
      using A1 A12 A3 nat_d_def_5 sorry
    thus "(a +XCMPLX-0K2 xx *XCMPLX-0K3 b)gcdINT-2K3 b =XBOOLE-0R4 a gcdINT-2K3 b"
      using int_2_th_34 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mdef euler_1_def_1 ("EulerEULER-1K1  _ " [228]228 ) where
  mlet "n be NatNAT-1M1"
"func EulerEULER-1K1 n \<rightarrow> ElementSUBSET-1M1-of NATNUMBERSK1 equals
  cardCARD-1K1 ({k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((n,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 n })"
proof-
  (*coherence*)
    show "cardCARD-1K1 ({k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((n,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 n }) be ElementSUBSET-1M1-of NATNUMBERSK1"
    proof-
      let ?X = "{k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((n,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 n }"
      have "?X c=TARSKIR1 SegFINSEQ-1K2 n"
      proof-
        have "{k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((n,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 n } c=TARSKIR1 SegFINSEQ-1K2 n"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((n,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 n } implies x inHIDDENR3 SegFINSEQ-1K2 n"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 ?X"
            then have " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st ((k =HIDDENR1 x & (n,k)are-coprimeINT-2R1) & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 n"
               sorry
            thus "x inHIDDENR3 SegFINSEQ-1K2 n"
              using finseq_1_th_1 sorry
          qed "sorry"
          thus "{k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((n,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 n } c=TARSKIR1 SegFINSEQ-1K2 n"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      then obtain X where 
        [ty]:"X be finiteFINSET-1V1\<bar>setHIDDENM2" and XDef:"X = ?X"
         sorry
      have "cardCARD-1K4 X be ElementSUBSET-1M1-of NATNUMBERSK1"
         sorry
      thus "cardCARD-1K1 ({k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((n,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 n }) be ElementSUBSET-1M1-of NATNUMBERSK1"
         sorry
    qed
qed "sorry"

mlemma
" for x be objectHIDDENM1 holds x inHIDDENR3 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((\<one>\<^sub>M,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 \<one>\<^sub>M } iff x =HIDDENR1 \<one>\<^sub>M"
proof-
  have " for x be objectHIDDENM1 holds (x inHIDDENR3 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((\<one>\<^sub>M,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 \<one>\<^sub>M } implies x =HIDDENR1 \<one>\<^sub>M) &  not (x =HIDDENR1 \<one>\<^sub>M &  not x inHIDDENR3 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((\<one>\<^sub>M,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 \<one>\<^sub>M })"
  proof(rule ballI,rule conjMI)
    fix x assume [ty]: "x be objectHIDDENM1"
    show "x inHIDDENR3 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((\<one>\<^sub>M,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 \<one>\<^sub>M } implies x =HIDDENR1 \<one>\<^sub>M"
    proof(rule impI)
      assume "x inHIDDENR3 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((\<one>\<^sub>M,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 \<one>\<^sub>M }"
      then have " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st ((k =HIDDENR1 x & (\<one>\<^sub>M,k)are-coprimeINT-2R1) & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 \<one>\<^sub>M"
         sorry
      thus "x =HIDDENR1 \<one>\<^sub>M"
        using xxreal_0_th_1 sorry
    qed
    have "\<one>\<^sub>M gcdINT-2K3 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
      using nat_d_th_32 sorry
    then have "(\<one>\<^sub>M,\<one>\<^sub>M)are-coprimeINT-2R1"
      using int_2_def_3 sorry
    thus " not (x =HIDDENR1 \<one>\<^sub>M &  not x inHIDDENR3 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((\<one>\<^sub>M,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 \<one>\<^sub>M })"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma euler_1_lm_3:
"cardCARD-1K4 {TARSKIK1 \<one>\<^sub>M} =XBOOLE-0R4 EulerEULER-1K1 \<one>\<^sub>M"
  using tarski_def_1 sorry

mtheorem euler_1_th_17:
"EulerEULER-1K1 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
  using euler_1_lm_3 card_1_th_30 sorry

mlemma
" for x be objectHIDDENM1 holds x inHIDDENR3 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((\<two>\<^sub>M,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 \<two>\<^sub>M } iff x =HIDDENR1 \<one>\<^sub>M"
proof-
  have " for x be objectHIDDENM1 holds (x inHIDDENR3 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((\<two>\<^sub>M,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 \<two>\<^sub>M } implies x =HIDDENR1 \<one>\<^sub>M) &  not (x =HIDDENR1 \<one>\<^sub>M &  not x inHIDDENR3 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((\<two>\<^sub>M,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 \<two>\<^sub>M })"
  proof(rule ballI,rule conjMI)
    fix x assume [ty]: "x be objectHIDDENM1"
    show "x inHIDDENR3 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((\<two>\<^sub>M,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 \<two>\<^sub>M } implies x =HIDDENR1 \<one>\<^sub>M"
    proof(rule impI)
      assume "x inHIDDENR3 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((\<two>\<^sub>M,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 \<two>\<^sub>M }"
      then obtain k where
        [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
        A1: "k =HIDDENR1 x & (\<two>\<^sub>M,k)are-coprimeINT-2R1"and A2: "k >=XXREAL-0R2 \<one>\<^sub>M & k <=XXREAL-0R1 \<two>\<^sub>M"
         sorry
      have A3: "\<two>\<^sub>M gcdINT-2K3 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M"
        using nat_d_th_32 sorry
      have " ex VarFor1 be setHIDDENM2 st (0NUMBERSK6 <=XXREAL-0R1 VarFor1 & VarFor1 <=XXREAL-0R1 \<two>\<^sub>M) & k =XBOOLE-0R4 VarFor1"
        using A2 sorry
      thus "x =HIDDENR1 \<one>\<^sub>M"
        using A1 A2 A3 int_2_def_3 sorry
    qed
    have "\<two>\<^sub>M gcdINT-2K3 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
      using newton_th_51 sorry
    then have "(\<two>\<^sub>M,\<one>\<^sub>M)are-coprimeINT-2R1"
      using int_2_def_3 sorry
    thus " not (x =HIDDENR1 \<one>\<^sub>M &  not x inHIDDENR3 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((\<two>\<^sub>M,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 \<two>\<^sub>M })"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma euler_1_lm_4:
"cardCARD-1K4 {TARSKIK1 \<one>\<^sub>M} =XBOOLE-0R4 EulerEULER-1K1 \<two>\<^sub>M"
  using tarski_def_1 sorry

mtheorem euler_1_th_18:
"EulerEULER-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
  using euler_1_lm_4 card_1_th_30 sorry

mtheorem euler_1_th_19:
" for n be NatNAT-1M1 holds n >XXREAL-0R4 \<one>\<^sub>M implies EulerEULER-1K1 n <=XXREAL-0R1 n -XCMPLX-0K6 \<one>\<^sub>M"
proof-
  have " for n be NatNAT-1M1 holds n >XXREAL-0R4 \<one>\<^sub>M implies EulerEULER-1K1 n <=XXREAL-0R1 n -XCMPLX-0K6 \<one>\<^sub>M"
  proof(rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?X = "{kk where kk be ElementSUBSET-1M1-of NATNUMBERSK1 : ((n,kk)are-coprimeINT-2R1 & kk >=XXREAL-0R2 \<one>\<^sub>M) & kk <=XXREAL-0R1 n }"
    have "?X c=TARSKIR1 SegFINSEQ-1K2 n"
    proof-
      have "{kk where kk be ElementSUBSET-1M1-of NATNUMBERSK1 : ((n,kk)are-coprimeINT-2R1 & kk >=XXREAL-0R2 \<one>\<^sub>M) & kk <=XXREAL-0R1 n } c=TARSKIR1 SegFINSEQ-1K2 n"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 {kk where kk be ElementSUBSET-1M1-of NATNUMBERSK1 : ((n,kk)are-coprimeINT-2R1 & kk >=XXREAL-0R2 \<one>\<^sub>M) & kk <=XXREAL-0R1 n } implies x inHIDDENR3 SegFINSEQ-1K2 n"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 ?X"
          then have " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st ((k =HIDDENR1 x & (n,k)are-coprimeINT-2R1) & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 n"
             sorry
          thus "x inHIDDENR3 SegFINSEQ-1K2 n"
            using finseq_1_th_1 sorry
        qed "sorry"
        thus "{kk where kk be ElementSUBSET-1M1-of NATNUMBERSK1 : ((n,kk)are-coprimeINT-2R1 & kk >=XXREAL-0R2 \<one>\<^sub>M) & kk <=XXREAL-0R1 n } c=TARSKIR1 SegFINSEQ-1K2 n"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    then obtain X where 
      [ty]:"X be finiteFINSET-1V1\<bar>setHIDDENM2" and XDef:"X = ?X"
       sorry
    assume A1: "n >XXREAL-0R4 \<one>\<^sub>M"
    then have "0NUMBERSK6 inTARSKIR2 {l where l be NatNAT-1M1 : l <XXREAL-0R3 n }"
       sorry
    then have "0NUMBERSK6 inTARSKIR2 n"
      using axioms_th_4 sorry
    then have A2: "cardCARD-1K4 (n \\SUBSET-1K6 {TARSKIK1 0NUMBERSK6 }) =XBOOLE-0R4 cardCARD-1K4 n -XCMPLX-0K6 cardCARD-1K4 {TARSKIK1 0NUMBERSK6 }"
      using euler_1_th_4 sorry
    have A3: "X c=TARSKIR1 n \\SUBSET-1K6 {TARSKIK1 0NUMBERSK6 }"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 n \\SUBSET-1K6 {TARSKIK1 0NUMBERSK6 }"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 X"
        then obtain k where
          [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A4: "k =HIDDENR1 x"and A5: "(n,k)are-coprimeINT-2R1"and A6: "k >=XXREAL-0R2 \<one>\<^sub>M"and A7: "k <=XXREAL-0R1 n"
           sorry
        have " not (n,n)are-coprimeINT-2R1"
          using A1 euler_1_th_1 sorry
        then have "k <XXREAL-0R3 n"
          using A5 A7 xxreal_0_th_1 sorry
        then have "k inTARSKIR2 {l where l be NatNAT-1M1 : l <XXREAL-0R3 n }"
           sorry
        then have A8: "k inTARSKIR2 n"
          using axioms_th_4 sorry
        have " not k inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
          using A6 tarski_def_1 sorry
        thus "x inHIDDENR3 n \\SUBSET-1K6 {TARSKIK1 0NUMBERSK6 }"
          using A4 A8 xboole_0_def_5 sorry
      qed "sorry"
      thus "X c=TARSKIR1 n \\SUBSET-1K6 {TARSKIK1 0NUMBERSK6 }"
        using tarski_def_3 sorry
    qed
    have "cardCARD-1K4 n =XBOOLE-0R4 n & cardCARD-1K4 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 \<one>\<^sub>M"
      using card_1_th_30 sorry
    thus "EulerEULER-1K1 n <=XXREAL-0R1 n -XCMPLX-0K6 \<one>\<^sub>M"
      using A3 A2 nat_1_th_43 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem euler_1_th_20:
" for n be NatNAT-1M1 holds n be primeINT-2V1 implies EulerEULER-1K1 n =XBOOLE-0R4 n -XCMPLX-0K6 \<one>\<^sub>M"
proof-
  have " for n be NatNAT-1M1 holds n be primeINT-2V1 implies EulerEULER-1K1 n =XBOOLE-0R4 n -XCMPLX-0K6 \<one>\<^sub>M"
  proof(rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?X = "{kk where kk be ElementSUBSET-1M1-of NATNUMBERSK1 : ((n,kk)are-coprimeINT-2R1 & kk >=XXREAL-0R2 \<one>\<^sub>M) & kk <=XXREAL-0R1 n }"
    have "?X c=TARSKIR1 SegFINSEQ-1K2 n"
    proof-
      have "{kk where kk be ElementSUBSET-1M1-of NATNUMBERSK1 : ((n,kk)are-coprimeINT-2R1 & kk >=XXREAL-0R2 \<one>\<^sub>M) & kk <=XXREAL-0R1 n } c=TARSKIR1 SegFINSEQ-1K2 n"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 {kk where kk be ElementSUBSET-1M1-of NATNUMBERSK1 : ((n,kk)are-coprimeINT-2R1 & kk >=XXREAL-0R2 \<one>\<^sub>M) & kk <=XXREAL-0R1 n } implies x inHIDDENR3 SegFINSEQ-1K2 n"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 ?X"
          then have " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st ((k =HIDDENR1 x & (n,k)are-coprimeINT-2R1) & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 n"
             sorry
          thus "x inHIDDENR3 SegFINSEQ-1K2 n"
            using finseq_1_th_1 sorry
        qed "sorry"
        thus "{kk where kk be ElementSUBSET-1M1-of NATNUMBERSK1 : ((n,kk)are-coprimeINT-2R1 & kk >=XXREAL-0R2 \<one>\<^sub>M) & kk <=XXREAL-0R1 n } c=TARSKIR1 SegFINSEQ-1K2 n"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    then obtain X where 
      [ty]:"X be finiteFINSET-1V1\<bar>setHIDDENM2" and XDef:"X = ?X"
       sorry
    assume A1: "n be primeINT-2V1"
    have "n <>HIDDENR2 0NUMBERSK6"
    proof-
      have "n =XBOOLE-0R4 0NUMBERSK6 implies  False "
      proof(rule impI)
        assume "n =XBOOLE-0R4 0NUMBERSK6"
        then have "n inTARSKIR2 SetPrimenumberNEWTONK9 \<two>\<^sub>M"
          using A1 newton_def_7 sorry
        thus " False "
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    then have "0NUMBERSK6 inTARSKIR2 {l where l be NatNAT-1M1 : l <XXREAL-0R3 n }"
       sorry
    then have A2: "0NUMBERSK6 inTARSKIR2 n"
      using axioms_th_4 sorry
    have "SegmCARD-1K5 n \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 X"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 SegmCARD-1K5 n \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 0NUMBERSK6 } implies x inHIDDENR3 X"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A3: "x inHIDDENR3 SegmCARD-1K5 n \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 0NUMBERSK6 }"
        then have A4: "x inHIDDENR3 SegmCARD-1K5 n"
          using xboole_0_def_5 sorry
        have " not x inHIDDENR3 {TARSKIK1 0NUMBERSK6 }"
          using A3 xboole_0_def_5 sorry
        thus "x inHIDDENR3 X"
          using A1 euler_1_th_3 A4 sorry
      qed "sorry"
      thus "SegmCARD-1K5 n \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 X"
        using tarski_def_3 sorry
    qed
    then have A5: "cardCARD-1K4 (n \\SUBSET-1K6 {TARSKIK1 0NUMBERSK6 }) <=XXREAL-0R1 cardCARD-1K4 X"
      using nat_1_th_43 sorry
    have A6: "EulerEULER-1K1 n <=XXREAL-0R1 n -XCMPLX-0K6 \<one>\<^sub>M"
      using A1 euler_1_th_19 int_2_def_4 sorry
    have "cardCARD-1K4 n =XBOOLE-0R4 n & cardCARD-1K4 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 \<one>\<^sub>M"
      using card_1_th_30 sorry
    then have "n -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 EulerEULER-1K1 n"
      using A5 A2 euler_1_th_4 sorry
    thus "EulerEULER-1K1 n =XBOOLE-0R4 n -XCMPLX-0K6 \<one>\<^sub>M"
      using A6 xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem euler_1_th_21:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (m >XXREAL-0R4 \<one>\<^sub>M & n >XXREAL-0R4 \<one>\<^sub>M) & (m,n)are-coprimeINT-2R1 implies EulerEULER-1K1 (m *XCMPLX-0K3 n) =XBOOLE-0R4 EulerEULER-1K1 m *NAT-1K2 EulerEULER-1K1 n"
proof-
  have " for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds m >XXREAL-0R4 \<one>\<^sub>M & (n >XXREAL-0R4 \<one>\<^sub>M & (m,n)are-coprimeINT-2R1) implies EulerEULER-1K1 (m *XCMPLX-0K3 n) =XBOOLE-0R4 EulerEULER-1K1 m *NAT-1K2 EulerEULER-1K1 n"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "m >XXREAL-0R4 \<one>\<^sub>M"
      and A2: "n >XXREAL-0R4 \<one>\<^sub>M"
      and A3: "(m,n)are-coprimeINT-2R1"
    let ?X = "{i where i be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m *XCMPLX-0K3 n,i)are-coprimeINT-2R1 & i >=XXREAL-0R2 \<one>\<^sub>M) & i <=XXREAL-0R1 m *XCMPLX-0K3 n }"
    let ?C = "{i where i be ElementSUBSET-1M1-of NATNUMBERSK1 :  ex x be IntegerINT-1M1 st  ex y be IntegerINT-1M1 st (((i =HIDDENR1 (m *XCMPLX-0K3 y +XCMPLX-0K2 n *XCMPLX-0K3 x)modINT-1K6 m *XCMPLX-0K3 n & (m *XCMPLX-0K3 n,i)are-coprimeINT-2R1) & y <=XXREAL-0R1 n) & x <=XXREAL-0R1 m) & i >=XXREAL-0R2 0NUMBERSK6 }"
    have A4: "m *XCMPLX-0K3 n <>HIDDENR2 0NUMBERSK6"
      using A1 A2 xcmplx_1_th_6 sorry
    have A5: "?C c=TARSKIR1 SegFINSEQ-1K2 (m *XCMPLX-0K3 n) \\/XBOOLE-0K2 {TARSKIK1 0NUMBERSK6 }"
    proof-
      have "{i where i be ElementSUBSET-1M1-of NATNUMBERSK1 :  not ( for x be IntegerINT-1M1 holds  for y be IntegerINT-1M1 holds  not ((((i =HIDDENR1 (m *XCMPLX-0K3 y +XCMPLX-0K2 n *XCMPLX-0K3 x)modINT-1K6 m *XCMPLX-0K3 n & (m *XCMPLX-0K3 n,i)are-coprimeINT-2R1) & y <=XXREAL-0R1 n) & x <=XXREAL-0R1 m) & i >=XXREAL-0R2 0NUMBERSK6)) } c=TARSKIR1 SegFINSEQ-1K2 (m *XCMPLX-0K3 n) \\/XBOOLE-0K2 {TARSKIK1 0NUMBERSK6 }"
      proof-
        have " for z be objectHIDDENM1 holds z inHIDDENR3 ?C implies z inHIDDENR3 SegFINSEQ-1K2 (m *XCMPLX-0K3 n) \\/XBOOLE-0K2 {TARSKIK1 0NUMBERSK6 }"
        proof(rule ballI,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          assume "z inHIDDENR3 ?C"
          then obtain i where
            [ty]:"i be ElementSUBSET-1M1-of NATNUMBERSK1" and 
            A6: "i =HIDDENR1 z"and A7: " ex x be IntegerINT-1M1 st  ex y be IntegerINT-1M1 st (((i =HIDDENR1 (m *XCMPLX-0K3 y +XCMPLX-0K2 n *XCMPLX-0K3 x)modINT-1K6 m *XCMPLX-0K3 n & (m *XCMPLX-0K3 n,i)are-coprimeINT-2R1) & y <=XXREAL-0R1 n) & x <=XXREAL-0R1 m) & i >=XXREAL-0R2 0NUMBERSK6"
             sorry
          obtain x y where
            [ty]:"x be IntegerINT-1M1" "y be IntegerINT-1M1" and 
            A8: "i =HIDDENR1 (m *XCMPLX-0K3 y +XCMPLX-0K2 n *XCMPLX-0K3 x)modINT-1K6 m *XCMPLX-0K3 n"and "(m *XCMPLX-0K3 n,i)are-coprimeINT-2R1"and "y <=XXREAL-0R1 n"and "x <=XXREAL-0R1 m"and "i >=XXREAL-0R2 0NUMBERSK6"
            using A7 sorry
          show "z inHIDDENR3 SegFINSEQ-1K2 (m *XCMPLX-0K3 n) \\/XBOOLE-0K2 {TARSKIK1 0NUMBERSK6 }"
          proof-
            have cases: "i >XXREAL-0R4 0NUMBERSK6 or i =XBOOLE-0R4 0NUMBERSK6"
               sorry
            have case1: "i >XXREAL-0R4 0NUMBERSK6 implies z inHIDDENR3 SegFINSEQ-1K2 (m *XCMPLX-0K3 n) \\/XBOOLE-0K2 {TARSKIK1 0NUMBERSK6 }"
            proof(rule impI)
              assume A9: "i >XXREAL-0R4 0NUMBERSK6"
              have A10: "(m *XCMPLX-0K3 y +XCMPLX-0K2 n *XCMPLX-0K3 x)modINT-1K6 m *XCMPLX-0K3 n <=XXREAL-0R1 m *XCMPLX-0K3 n"
              proof-
                let ?i2 = "m *XCMPLX-0K3 n"
                let ?i1 = "m *XCMPLX-0K3 y +XCMPLX-0K2 n *XCMPLX-0K3 x"
                have A11: "[\\INT-1K2 ?i1 /XCMPLX-0K7 ?i2 /] +XCMPLX-0K2 \<one>\<^sub>M >=XXREAL-0R2 ?i1 /XCMPLX-0K7 ?i2"
                  using int_1_th_29 sorry
                have "(m *XCMPLX-0K3 y +XCMPLX-0K2 n *XCMPLX-0K3 x)modINT-1K6 m *XCMPLX-0K3 n =HIDDENR1 ?i1 -XCMPLX-0K6 (?i1 divINT-1K5 ?i2)*XCMPLX-0K3 ?i2"
                  using A4 int_1_def_10 sorry
                also have "... = ?i1 -XCMPLX-0K6 ([\\INT-1K2 ?i1 /XCMPLX-0K7 ?i2 /])*XCMPLX-0K3 ?i2"
                  using int_1_def_9 sorry
                finally have "(m *XCMPLX-0K3 y +XCMPLX-0K2 n *XCMPLX-0K3 x)modINT-1K6 m *XCMPLX-0K3 n =HIDDENR1 ?i1 -XCMPLX-0K6 ([\\INT-1K2 ?i1 /XCMPLX-0K7 ?i2 /])*XCMPLX-0K3 ?i2"
                   sorry
                thus "(m *XCMPLX-0K3 y +XCMPLX-0K2 n *XCMPLX-0K3 x)modINT-1K6 m *XCMPLX-0K3 n <=XXREAL-0R1 m *XCMPLX-0K3 n"
                  using A1 A2 A11 euler_1_lm_1 xcmplx_1_th_6 sorry
              qed
              have "i >=XXREAL-0R2 \<one>\<^sub>M"
                using A9 nat_1_th_14 sorry
              then have "z inHIDDENR3 SegFINSEQ-1K2 (m *XCMPLX-0K3 n)"
                using A6 A8 A10 finseq_1_th_1 sorry
              thus "z inHIDDENR3 SegFINSEQ-1K2 (m *XCMPLX-0K3 n) \\/XBOOLE-0K2 {TARSKIK1 0NUMBERSK6 }"
                using xboole_0_def_3 sorry
            qed
            have case2: "i =XBOOLE-0R4 0NUMBERSK6 implies z inHIDDENR3 SegFINSEQ-1K2 (m *XCMPLX-0K3 n) \\/XBOOLE-0K2 {TARSKIK1 0NUMBERSK6 }"
            proof(rule impI)
              assume A12: "i =XBOOLE-0R4 0NUMBERSK6"
              have "0NUMBERSK6 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
                using tarski_def_1 sorry
              thus "z inHIDDENR3 SegFINSEQ-1K2 (m *XCMPLX-0K3 n) \\/XBOOLE-0K2 {TARSKIK1 0NUMBERSK6 }"
                using A6 A12 xboole_0_def_3 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed "sorry"
        thus "{i where i be ElementSUBSET-1M1-of NATNUMBERSK1 :  not ( for x be IntegerINT-1M1 holds  for y be IntegerINT-1M1 holds  not ((((i =HIDDENR1 (m *XCMPLX-0K3 y +XCMPLX-0K2 n *XCMPLX-0K3 x)modINT-1K6 m *XCMPLX-0K3 n & (m *XCMPLX-0K3 n,i)are-coprimeINT-2R1) & y <=XXREAL-0R1 n) & x <=XXREAL-0R1 m) & i >=XXREAL-0R2 0NUMBERSK6)) } c=TARSKIR1 SegFINSEQ-1K2 (m *XCMPLX-0K3 n) \\/XBOOLE-0K2 {TARSKIK1 0NUMBERSK6 }"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    then obtain C where 
      [ty]:"C be finiteFINSET-1V1\<bar>setHIDDENM2" and CDef:"C = ?C"
       sorry
    let ?A = "{i where i be ElementSUBSET-1M1-of NATNUMBERSK1 : ((n,i)are-coprimeINT-2R1 & i >=XXREAL-0R2 \<one>\<^sub>M) & i <=XXREAL-0R1 n }"
    have A13: "?A c=TARSKIR1 SegFINSEQ-1K2 n"
    proof-
      have "{i where i be ElementSUBSET-1M1-of NATNUMBERSK1 : ((n,i)are-coprimeINT-2R1 & i >=XXREAL-0R2 \<one>\<^sub>M) & i <=XXREAL-0R1 n } c=TARSKIR1 SegFINSEQ-1K2 n"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 {i where i be ElementSUBSET-1M1-of NATNUMBERSK1 : ((n,i)are-coprimeINT-2R1 & i >=XXREAL-0R2 \<one>\<^sub>M) & i <=XXREAL-0R1 n } implies x inHIDDENR3 SegFINSEQ-1K2 n"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 ?A"
          then have " ex i be ElementSUBSET-1M1-of NATNUMBERSK1 st ((i =HIDDENR1 x & (n,i)are-coprimeINT-2R1) & i >=XXREAL-0R2 \<one>\<^sub>M) & i <=XXREAL-0R1 n"
             sorry
          thus "x inHIDDENR3 SegFINSEQ-1K2 n"
            using finseq_1_th_1 sorry
        qed "sorry"
        thus "{i where i be ElementSUBSET-1M1-of NATNUMBERSK1 : ((n,i)are-coprimeINT-2R1 & i >=XXREAL-0R2 \<one>\<^sub>M) & i <=XXREAL-0R1 n } c=TARSKIR1 SegFINSEQ-1K2 n"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have A14: " for x be IntegerINT-1M1 holds  for y be IntegerINT-1M1 holds y =HIDDENR1 \<one>\<^sub>M & x =HIDDENR1 \<one>\<^sub>M implies (m *XCMPLX-0K3 y +XCMPLX-0K2 n *XCMPLX-0K3 x)modINT-1K6 m *XCMPLX-0K3 n inHIDDENR3 C"
    proof-
      have " for x be IntegerINT-1M1 holds  for y be IntegerINT-1M1 holds y =HIDDENR1 \<one>\<^sub>M & x =HIDDENR1 \<one>\<^sub>M implies (m *XCMPLX-0K3 y +XCMPLX-0K2 n *XCMPLX-0K3 x)modINT-1K6 m *XCMPLX-0K3 n inHIDDENR3 C"
      proof(rule ballI,rule ballI,rule impI)
        fix x assume [ty]: "x be IntegerINT-1M1"
        fix y assume [ty]: "y be IntegerINT-1M1"
        have A15: "m gcdINT-2K3 n =XBOOLE-0R4 \<one>\<^sub>M"
          using A3 int_2_def_3 sorry
        then have "(m +XCMPLX-0K2 n)gcdINT-2K3 m =XBOOLE-0R4 \<one>\<^sub>M"
          using euler_1_th_7 sorry
        then have A16: "(m,m +XCMPLX-0K2 n)are-coprimeINT-2R1"
          using int_2_def_3 sorry
        have "(m +XCMPLX-0K2 n)gcdINT-2K3 n =XBOOLE-0R4 \<one>\<^sub>M"
          using A15 euler_1_th_7 sorry
        then have "(n,m +XCMPLX-0K2 n)are-coprimeINT-2R1"
          using int_2_def_3 sorry
        then have "(m *XCMPLX-0K3 n,m +XCMPLX-0K2 n)are-coprimeINT-2R1"
          using A1 A16 euler_1_th_14 sorry
        then have A17: "m *XCMPLX-0K3 n gcdINT-2K3 (m +XCMPLX-0K2 n) =XBOOLE-0R4 \<one>\<^sub>M"
          using int_2_def_3 sorry
        assume A18: "y =HIDDENR1 \<one>\<^sub>M & x =HIDDENR1 \<one>\<^sub>M"
        then obtain y9 x9 where 
          [ty]:"y9 be ElementSUBSET-1M1-of NATNUMBERSK1" and y9Def:"y9 = y" and
          [ty]:"x9 be ElementSUBSET-1M1-of NATNUMBERSK1" and x9Def:"x9 = x"
           sorry
        have "(m *XCMPLX-0K3 y9 +XCMPLX-0K2 n *XCMPLX-0K3 x9)modNAT-DK4 m *XCMPLX-0K3 n =HIDDENR1 (m *XCMPLX-0K3 y +XCMPLX-0K2 n *XCMPLX-0K3 x)modINT-1K6 m *XCMPLX-0K3 n"
           sorry
        then obtain t where
          [ty]:"t be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A19: "t =HIDDENR1 (m *XCMPLX-0K3 y +XCMPLX-0K2 n *XCMPLX-0K3 x)modINT-1K6 m *XCMPLX-0K3 n"
           sorry
        have " ex d be NatNAT-1M1 st m +XCMPLX-0K2 n =XBOOLE-0R4 (m *XCMPLX-0K3 n)*XCMPLX-0K3 d +NAT-1K1 ((m +XCMPLX-0K2 n)modNAT-DK4 m *XCMPLX-0K3 n) & (m +XCMPLX-0K2 n)modNAT-DK4 m *XCMPLX-0K3 n <XXREAL-0R3 m *XCMPLX-0K3 n"
          using A4 nat_d_def_2 sorry
        then have "((m +XCMPLX-0K2 n)modNAT-DK4 m *XCMPLX-0K3 n)gcdINT-2K3 m *XCMPLX-0K3 n =XBOOLE-0R4 \<one>\<^sub>M"
          using A17 euler_1_th_8 sorry
        then have "(m *XCMPLX-0K3 n,t)are-coprimeINT-2R1"
          using A18 A19 int_2_def_3 sorry
        thus "(m *XCMPLX-0K3 y +XCMPLX-0K2 n *XCMPLX-0K3 x)modINT-1K6 m *XCMPLX-0K3 n inHIDDENR3 C"
          using A1 A2 A18 A19 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain A where 
      [ty]:"A be finiteFINSET-1V1\<bar>setHIDDENM2" and ADef:"A = ?A"
      using A13 sorry
    have A20: " for a be NatNAT-1M1 holds a =XBOOLE-0R4 \<one>\<^sub>M implies a inTARSKIR2 A"
    proof-
      have " for a be NatNAT-1M1 holds a =XBOOLE-0R4 \<one>\<^sub>M implies a inTARSKIR2 A"
      proof(rule ballI,rule impI)
        fix a assume [ty]: "a be NatNAT-1M1"
        assume A21: "a =XBOOLE-0R4 \<one>\<^sub>M"
        then have "n gcdINT-2K3 a =XBOOLE-0R4 \<one>\<^sub>M"
          using newton_th_51 sorry
        then have "(n,a)are-coprimeINT-2R1"
          using int_2_def_3 sorry
        thus "a inTARSKIR2 A"
          using A2 A21 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    let ?B = "{i where i be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,i)are-coprimeINT-2R1 & i >=XXREAL-0R2 \<one>\<^sub>M) & i <=XXREAL-0R1 m }"
    have A22: "?B c=TARSKIR1 SegFINSEQ-1K2 m"
    proof-
      have "{i where i be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,i)are-coprimeINT-2R1 & i >=XXREAL-0R2 \<one>\<^sub>M) & i <=XXREAL-0R1 m } c=TARSKIR1 SegFINSEQ-1K2 m"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 {i where i be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,i)are-coprimeINT-2R1 & i >=XXREAL-0R2 \<one>\<^sub>M) & i <=XXREAL-0R1 m } implies x inHIDDENR3 SegFINSEQ-1K2 m"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 ?B"
          then have " ex i be ElementSUBSET-1M1-of NATNUMBERSK1 st ((i =HIDDENR1 x & (m,i)are-coprimeINT-2R1) & i >=XXREAL-0R2 \<one>\<^sub>M) & i <=XXREAL-0R1 m"
             sorry
          thus "x inHIDDENR3 SegFINSEQ-1K2 m"
            using finseq_1_th_1 sorry
        qed "sorry"
        thus "{i where i be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,i)are-coprimeINT-2R1 & i >=XXREAL-0R2 \<one>\<^sub>M) & i <=XXREAL-0R1 m } c=TARSKIR1 SegFINSEQ-1K2 m"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have A23: "m *XCMPLX-0K3 n <>HIDDENR2 \<one>\<^sub>M"
      using A1 nat_1_th_15 sorry
    have A24: "C =XBOOLE-0R4 ?X"
    proof-
      have "C =XBOOLE-0R4 {i where i be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m *XCMPLX-0K3 n,i)are-coprimeINT-2R1 & i >=XXREAL-0R2 \<one>\<^sub>M) & i <=XXREAL-0R1 m *XCMPLX-0K3 n }"
      proof-
        have "C c=TARSKIR1 {i where i be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m *XCMPLX-0K3 n,i)are-coprimeINT-2R1 & i >=XXREAL-0R2 \<one>\<^sub>M) & i <=XXREAL-0R1 m *XCMPLX-0K3 n } & {i where i be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m *XCMPLX-0K3 n,i)are-coprimeINT-2R1 & i >=XXREAL-0R2 \<one>\<^sub>M) & i <=XXREAL-0R1 m *XCMPLX-0K3 n } c=TARSKIR1 C"
        proof(rule conjMI)
          show "C c=TARSKIR1 {i where i be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m *XCMPLX-0K3 n,i)are-coprimeINT-2R1 & i >=XXREAL-0R2 \<one>\<^sub>M) & i <=XXREAL-0R1 m *XCMPLX-0K3 n }"
          proof-
            have " for z be objectHIDDENM1 holds z inHIDDENR3 C implies z inHIDDENR3 {i where i be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m *XCMPLX-0K3 n,i)are-coprimeINT-2R1 & i >=XXREAL-0R2 \<one>\<^sub>M) & i <=XXREAL-0R1 m *XCMPLX-0K3 n }"
            proof(rule ballI,rule impI)
              fix z assume [ty]: "z be objectHIDDENM1"
              assume "z inHIDDENR3 C"
              then obtain i where
                [ty]:"i be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                A25: "i =HIDDENR1 z"and A26: " ex x be IntegerINT-1M1 st  ex y be IntegerINT-1M1 st (((i =HIDDENR1 (m *XCMPLX-0K3 y +XCMPLX-0K2 n *XCMPLX-0K3 x)modINT-1K6 m *XCMPLX-0K3 n & (m *XCMPLX-0K3 n,i)are-coprimeINT-2R1) & y <=XXREAL-0R1 n) & x <=XXREAL-0R1 m) & i >=XXREAL-0R2 0NUMBERSK6"
                 sorry
              obtain x y where
                [ty]:"x be IntegerINT-1M1" "y be IntegerINT-1M1" and 
                A27: "i =HIDDENR1 (m *XCMPLX-0K3 y +XCMPLX-0K2 n *XCMPLX-0K3 x)modINT-1K6 m *XCMPLX-0K3 n"and A28: "(m *XCMPLX-0K3 n,i)are-coprimeINT-2R1"and "y <=XXREAL-0R1 n"and "x <=XXREAL-0R1 m"and "i >=XXREAL-0R2 0NUMBERSK6"
                using A26 sorry
              have A29: "(m *XCMPLX-0K3 y +XCMPLX-0K2 n *XCMPLX-0K3 x)modINT-1K6 m *XCMPLX-0K3 n <=XXREAL-0R1 m *XCMPLX-0K3 n"
              proof-
                let ?i2 = "m *XCMPLX-0K3 n"
                let ?i1 = "m *XCMPLX-0K3 y +XCMPLX-0K2 n *XCMPLX-0K3 x"
                have A30: "[\\INT-1K2 ?i1 /XCMPLX-0K7 ?i2 /] +XCMPLX-0K2 \<one>\<^sub>M >=XXREAL-0R2 ?i1 /XCMPLX-0K7 ?i2"
                  using int_1_th_29 sorry
                have "(m *XCMPLX-0K3 y +XCMPLX-0K2 n *XCMPLX-0K3 x)modINT-1K6 m *XCMPLX-0K3 n =HIDDENR1 ?i1 -XCMPLX-0K6 (?i1 divINT-1K5 ?i2)*XCMPLX-0K3 ?i2"
                  using A4 int_1_def_10 sorry
                also have "... = ?i1 -XCMPLX-0K6 ([\\INT-1K2 ?i1 /XCMPLX-0K7 ?i2 /])*XCMPLX-0K3 ?i2"
                  using int_1_def_9 sorry
                finally have "(m *XCMPLX-0K3 y +XCMPLX-0K2 n *XCMPLX-0K3 x)modINT-1K6 m *XCMPLX-0K3 n =HIDDENR1 ?i1 -XCMPLX-0K6 ([\\INT-1K2 ?i1 /XCMPLX-0K7 ?i2 /])*XCMPLX-0K3 ?i2"
                   sorry
                thus "(m *XCMPLX-0K3 y +XCMPLX-0K2 n *XCMPLX-0K3 x)modINT-1K6 m *XCMPLX-0K3 n <=XXREAL-0R1 m *XCMPLX-0K3 n"
                  using A1 A2 A30 euler_1_lm_1 xcmplx_1_th_6 sorry
              qed
              show "z inHIDDENR3 {i where i be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m *XCMPLX-0K3 n,i)are-coprimeINT-2R1 & i >=XXREAL-0R2 \<one>\<^sub>M) & i <=XXREAL-0R1 m *XCMPLX-0K3 n }"
              proof-
                have cases: "i >XXREAL-0R4 0NUMBERSK6 or i =XBOOLE-0R4 0NUMBERSK6"
                   sorry
                have case1: "i >XXREAL-0R4 0NUMBERSK6 implies z inHIDDENR3 {i where i be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m *XCMPLX-0K3 n,i)are-coprimeINT-2R1 & i >=XXREAL-0R2 \<one>\<^sub>M) & i <=XXREAL-0R1 m *XCMPLX-0K3 n }"
                proof(rule impI)
                  assume "i >XXREAL-0R4 0NUMBERSK6"
                  then have "i >=XXREAL-0R2 \<one>\<^sub>M"
                    using nat_1_th_14 sorry
                  thus "z inHIDDENR3 {i where i be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m *XCMPLX-0K3 n,i)are-coprimeINT-2R1 & i >=XXREAL-0R2 \<one>\<^sub>M) & i <=XXREAL-0R1 m *XCMPLX-0K3 n }"
                    using A25 A27 A28 A29 sorry
                qed
                have case2: "i =XBOOLE-0R4 0NUMBERSK6 implies z inHIDDENR3 {i where i be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m *XCMPLX-0K3 n,i)are-coprimeINT-2R1 & i >=XXREAL-0R2 \<one>\<^sub>M) & i <=XXREAL-0R1 m *XCMPLX-0K3 n }"
                proof(rule impI)
                  assume "i =XBOOLE-0R4 0NUMBERSK6"
                  then have "m *XCMPLX-0K3 n gcdINT-2K3 0NUMBERSK6 =XBOOLE-0R4 \<one>\<^sub>M"
                    using A28 int_2_def_3 sorry
                  thus "z inHIDDENR3 {i where i be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m *XCMPLX-0K3 n,i)are-coprimeINT-2R1 & i >=XXREAL-0R2 \<one>\<^sub>M) & i <=XXREAL-0R1 m *XCMPLX-0K3 n }"
                    using A23 newton_th_52 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed "sorry"
            thus "C c=TARSKIR1 {i where i be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m *XCMPLX-0K3 n,i)are-coprimeINT-2R1 & i >=XXREAL-0R2 \<one>\<^sub>M) & i <=XXREAL-0R1 m *XCMPLX-0K3 n }"
              using tarski_def_3 sorry
          qed
          have " for z be objectHIDDENM1 holds z inHIDDENR3 {i where i be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m *XCMPLX-0K3 n,i)are-coprimeINT-2R1 & i >=XXREAL-0R2 \<one>\<^sub>M) & i <=XXREAL-0R1 m *XCMPLX-0K3 n } implies z inHIDDENR3 C"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be objectHIDDENM1"
            assume "z inHIDDENR3 ?X"
            then obtain i where
              [ty]:"i be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A31: "i =HIDDENR1 z"and A32: "(m *XCMPLX-0K3 n,i)are-coprimeINT-2R1"and "i >=XXREAL-0R2 \<one>\<^sub>M"and A33: "i <=XXREAL-0R1 m *XCMPLX-0K3 n"
               sorry
            have "i <>HIDDENR2 m *XCMPLX-0K3 n"
            proof-
              have "i =XBOOLE-0R4 m *XCMPLX-0K3 n implies  False "
              proof(rule impI)
                assume "i =XBOOLE-0R4 m *XCMPLX-0K3 n"
                then have "m *XCMPLX-0K3 n gcdINT-2K3 m *XCMPLX-0K3 n =XBOOLE-0R4 \<one>\<^sub>M"
                  using A32 int_2_def_3 sorry
                then have "m *XCMPLX-0K3 n =XBOOLE-0R4 \<one>\<^sub>M"
                  using nat_d_th_32 sorry
                thus " False "
                  using A1 nat_1_th_15 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            then have A34: "i <XXREAL-0R3 m *XCMPLX-0K3 n"
              using A33 xxreal_0_th_1 sorry
            obtain y0 x0 where
              [ty]:"y0 be IntegerINT-1M1" "x0 be IntegerINT-1M1" and 
              A35: "y0 *XCMPLX-0K3 m +XCMPLX-0K2 x0 *XCMPLX-0K3 n =XBOOLE-0R4 i"
              using A3 euler_1_th_10 sorry
            have A36: "(m *XCMPLX-0K3 y0 +XCMPLX-0K2 n *XCMPLX-0K3 x0)modINT-1K6 m *XCMPLX-0K3 n =HIDDENR1 (m *XCMPLX-0K3 y0 +XCMPLX-0K2 n *XCMPLX-0K3 x0)-XCMPLX-0K6 ((m *XCMPLX-0K3 y0 +XCMPLX-0K2 n *XCMPLX-0K3 x0)divINT-1K5 m *XCMPLX-0K3 n)*XCMPLX-0K3 (m *XCMPLX-0K3 n)"
              using A4 int_1_def_10 sorry
            also have "... = (m *XCMPLX-0K3 y0 +XCMPLX-0K2 n *XCMPLX-0K3 x0)-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (m *XCMPLX-0K3 n)"
              using A34 A35 pre_ff_th_4 sorry
            also have "... = m *XCMPLX-0K3 y0 +XCMPLX-0K2 n *XCMPLX-0K3 x0"
               sorry
            finally have "(m *XCMPLX-0K3 y0 +XCMPLX-0K2 n *XCMPLX-0K3 x0)modINT-1K6 m *XCMPLX-0K3 n =HIDDENR1 m *XCMPLX-0K3 y0 +XCMPLX-0K2 n *XCMPLX-0K3 x0"
               sorry
            let ?k = "y0 divINT-1K5 n"
            let ?j = "x0 divINT-1K5 m"
            obtain x1 y1 where
              [ty]:"x1 be IntegerINT-1M1" "y1 be IntegerINT-1M1" and 
              A37: "x1 =HIDDENR1 x0 modINT-1K6 m"and A38: "y1 =HIDDENR1 y0 modINT-1K6 n"
               sorry
            have "x0 modINT-1K6 m =HIDDENR1 x0 -XCMPLX-0K6 (x0 divINT-1K5 m)*XCMPLX-0K3 m & y0 modINT-1K6 n =HIDDENR1 y0 -XCMPLX-0K6 (y0 divINT-1K5 n)*XCMPLX-0K3 n"
              using A1 A2 int_1_def_10 sorry
            then have "m *XCMPLX-0K3 y0 +XCMPLX-0K2 n *XCMPLX-0K3 x0 =XBOOLE-0R4 (m *XCMPLX-0K3 y1 +XCMPLX-0K2 n *XCMPLX-0K3 x1)+XCMPLX-0K2 (m *XCMPLX-0K3 n)*XCMPLX-0K3 (?k +XCMPLX-0K2 ?j)"
              using A37 A38 sorry
            then have A39: "m *XCMPLX-0K3 y0 +XCMPLX-0K2 n *XCMPLX-0K3 x0 =HIDDENR1 (m *XCMPLX-0K3 y1 +XCMPLX-0K2 n *XCMPLX-0K3 x1)modINT-1K6 m *XCMPLX-0K3 n"
              using A36 euler_1_th_12 sorry
            have A40: "[\\INT-1K2 y0 /XCMPLX-0K7 n /] +XCMPLX-0K2 \<one>\<^sub>M >=XXREAL-0R2 y0 /XCMPLX-0K7 n"
              using int_1_th_29 sorry
            have A41: "[\\INT-1K2 x0 /XCMPLX-0K7 m /] +XCMPLX-0K2 \<one>\<^sub>M >=XXREAL-0R2 x0 /XCMPLX-0K7 m"
              using int_1_th_29 sorry
            have "y1 =HIDDENR1 y0 -XCMPLX-0K6 (y0 divINT-1K5 n)*XCMPLX-0K3 n"
              using A2 A38 int_1_def_10 sorry
            also have "... = y0 -XCMPLX-0K6 ([\\INT-1K2 y0 /XCMPLX-0K7 n /])*XCMPLX-0K3 n"
              using int_1_def_9 sorry
            finally have "y1 =HIDDENR1 y0 -XCMPLX-0K6 ([\\INT-1K2 y0 /XCMPLX-0K7 n /])*XCMPLX-0K3 n"
               sorry
            then have A42: "y1 <=XXREAL-0R1 n"
              using A2 A40 euler_1_lm_1 sorry
            have "x1 =HIDDENR1 x0 -XCMPLX-0K6 (x0 divINT-1K5 m)*XCMPLX-0K3 m"
              using A1 A37 int_1_def_10 sorry
            also have "... = x0 -XCMPLX-0K6 ([\\INT-1K2 x0 /XCMPLX-0K7 m /])*XCMPLX-0K3 m"
              using int_1_def_9 sorry
            finally have "x1 =HIDDENR1 x0 -XCMPLX-0K6 ([\\INT-1K2 x0 /XCMPLX-0K7 m /])*XCMPLX-0K3 m"
               sorry
            then have "x1 <=XXREAL-0R1 m"
              using A1 A41 euler_1_lm_1 sorry
            thus "z inHIDDENR3 C"
              using A31 A32 A35 A42 A39 sorry
          qed "sorry"
          thus "{i where i be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m *XCMPLX-0K3 n,i)are-coprimeINT-2R1 & i >=XXREAL-0R2 \<one>\<^sub>M) & i <=XXREAL-0R1 m *XCMPLX-0K3 n } c=TARSKIR1 C"
            using tarski_def_3 sorry
        qed
        thus "C =XBOOLE-0R4 {i where i be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m *XCMPLX-0K3 n,i)are-coprimeINT-2R1 & i >=XXREAL-0R2 \<one>\<^sub>M) & i <=XXREAL-0R1 m *XCMPLX-0K3 n }"
          using xboole_0_def_10 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    obtain B where 
      [ty]:"B be finiteFINSET-1V1\<bar>setHIDDENM2" and BDef:"B = ?B"
      using A22 sorry
    have A43: " for b be NatNAT-1M1 holds b =XBOOLE-0R4 \<one>\<^sub>M implies b inTARSKIR2 B"
    proof-
      have " for b be NatNAT-1M1 holds b =XBOOLE-0R4 \<one>\<^sub>M implies b inTARSKIR2 B"
      proof(rule ballI,rule impI)
        fix b assume [ty]: "b be NatNAT-1M1"
        assume A44: "b =XBOOLE-0R4 \<one>\<^sub>M"
        then have "m gcdINT-2K3 b =XBOOLE-0R4 \<one>\<^sub>M"
          using newton_th_51 sorry
        then have "(m,b)are-coprimeINT-2R1"
          using int_2_def_3 sorry
        thus "b inTARSKIR2 B"
          using A1 A44 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "{TARSKIK1 0NUMBERSK6 } c=TARSKIR1 NATNUMBERSK1"
      using zfmisc_1_th_31 sorry
    then have "SegFINSEQ-1K2 (m *XCMPLX-0K3 n) \\/XBOOLE-0K2 {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 NATNUMBERSK1"
      using xboole_1_th_8 sorry
    then have 
      [ty]:"A be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>SubsetSUBSET-1M2-of NATNUMBERSK1" and
      [ty]:"B be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>SubsetSUBSET-1M2-of NATNUMBERSK1" and
      [ty]:"C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>SubsetSUBSET-1M2-of NATNUMBERSK1"
      using A13 A22 A5 A20 A43 A14 xboole_1_th_1 sorry
    let ?F = "\<lambda>Lamb1. \<lambda>Lamb2. (m *XCMPLX-0K3 Lamb1 +XCMPLX-0K2 n *XCMPLX-0K3 Lamb2)modNAT-DK4 m *XCMPLX-0K3 n"
    have A45: " for y be ElementSUBSET-1M3\<^bsub>(NATNUMBERSK1)\<^esub>-of A holds  for x be ElementSUBSET-1M3\<^bsub>(NATNUMBERSK1)\<^esub>-of B holds ?F(y,x) inTARSKIR2 C"
    proof-
      have " for y be ElementSUBSET-1M3\<^bsub>(NATNUMBERSK1)\<^esub>-of A holds  for x be ElementSUBSET-1M3\<^bsub>(NATNUMBERSK1)\<^esub>-of B holds (m *XCMPLX-0K3 y +XCMPLX-0K2 n *XCMPLX-0K3 x)modNAT-DK4 m *XCMPLX-0K3 n inTARSKIR2 C"
      proof(rule ballI,rule ballI)
        let ?l = "n *XCMPLX-0K3 m"
        fix y assume [ty]: "y be ElementSUBSET-1M3\<^bsub>(NATNUMBERSK1)\<^esub>-of A"
        fix x assume [ty]: "x be ElementSUBSET-1M3\<^bsub>(NATNUMBERSK1)\<^esub>-of B"
        have "y inTARSKIR2 A"
           sorry
        then obtain i where
          [ty]:"i be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A46: "i =XBOOLE-0R4 y"and A47: "(n,i)are-coprimeINT-2R1"and A48: "i >=XXREAL-0R2 \<one>\<^sub>M"and A49: "i <=XXREAL-0R1 n"
           sorry
        have "x inTARSKIR2 B"
           sorry
        then obtain j where
          [ty]:"j be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A50: "j =XBOOLE-0R4 x"and A51: "(m,j)are-coprimeINT-2R1"and "j >=XXREAL-0R2 \<one>\<^sub>M"and A52: "j <=XXREAL-0R1 m"
           sorry
        have "(i *XCMPLX-0K3 m,n)are-coprimeINT-2R1"
          using A1 A2 A3 A47 euler_1_th_14 sorry
        then have "i *XCMPLX-0K3 m gcdINT-2K3 n =XBOOLE-0R4 \<one>\<^sub>M"
          using int_2_def_3 sorry
        then have "(m *XCMPLX-0K3 i +XCMPLX-0K2 n *XCMPLX-0K3 j)gcdINT-2K3 n =XBOOLE-0R4 \<one>\<^sub>M"
          using euler_1_th_8 sorry
        then have A53: "(n,m *XCMPLX-0K3 i +XCMPLX-0K2 n *XCMPLX-0K3 j)are-coprimeINT-2R1"
          using int_2_def_3 sorry
        have "(j *XCMPLX-0K3 n,m)are-coprimeINT-2R1"
          using A1 A2 A3 A51 euler_1_th_14 sorry
        then have "j *XCMPLX-0K3 n gcdINT-2K3 m =XBOOLE-0R4 \<one>\<^sub>M"
          using int_2_def_3 sorry
        then have "(m *XCMPLX-0K3 i +XCMPLX-0K2 n *XCMPLX-0K3 j)gcdINT-2K3 m =XBOOLE-0R4 \<one>\<^sub>M"
          using euler_1_th_8 sorry
        then have A54: "(m,m *XCMPLX-0K3 i +XCMPLX-0K2 n *XCMPLX-0K3 j)are-coprimeINT-2R1"
          using int_2_def_3 sorry
        have "i *XCMPLX-0K3 m <>HIDDENR2 (0NUMBERSK6)*XCMPLX-0K3 m"
          using A1 A48 xcmplx_1_th_5 sorry
        then have "(n *XCMPLX-0K3 m,m *XCMPLX-0K3 i +XCMPLX-0K2 n *XCMPLX-0K3 j)are-coprimeINT-2R1"
          using A1 A53 A54 euler_1_th_14 sorry
        then have A55: "n *XCMPLX-0K3 m gcdINT-2K3 (m *XCMPLX-0K3 i +XCMPLX-0K2 n *XCMPLX-0K3 j) =XBOOLE-0R4 \<one>\<^sub>M"
          using int_2_def_3 sorry
        obtain ii jj where 
          [ty]:"ii be IntegerINT-1M1" and iiDef:"ii = i" and
          [ty]:"jj be IntegerINT-1M1" and jjDef:"jj = j"
           sorry
        have "(m *XCMPLX-0K3 ii +XCMPLX-0K2 n *XCMPLX-0K3 jj)modINT-1K6 m *XCMPLX-0K3 n =HIDDENR1 (m *XCMPLX-0K3 i +XCMPLX-0K2 n *XCMPLX-0K3 j)modNAT-DK4 m *XCMPLX-0K3 n"
           sorry
        then obtain q where
          [ty]:"q be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A56: "q =HIDDENR1 (m *XCMPLX-0K3 ii +XCMPLX-0K2 n *XCMPLX-0K3 jj)modINT-1K6 m *XCMPLX-0K3 n"
           sorry
        have " ex t be NatNAT-1M1 st m *XCMPLX-0K3 i +XCMPLX-0K2 n *XCMPLX-0K3 j =XBOOLE-0R4 (n *XCMPLX-0K3 m)*XCMPLX-0K3 t +NAT-1K1 ((m *XCMPLX-0K3 i +XCMPLX-0K2 n *XCMPLX-0K3 j)modNAT-DK4 n *XCMPLX-0K3 m) & (m *XCMPLX-0K3 i +XCMPLX-0K2 n *XCMPLX-0K3 j)modNAT-DK4 n *XCMPLX-0K3 m <XXREAL-0R3 n *XCMPLX-0K3 m"
          using A4 nat_d_def_2 sorry
        then have "((m *XCMPLX-0K3 i +XCMPLX-0K2 n *XCMPLX-0K3 j)modNAT-DK4 ?l)gcdINT-2K3 ?l =XBOOLE-0R4 \<one>\<^sub>M"
          using A55 euler_1_th_8 sorry
        then have "(?l,q)are-coprimeINT-2R1"
          using A56 int_2_def_3 sorry
        thus "(m *XCMPLX-0K3 y +XCMPLX-0K2 n *XCMPLX-0K3 x)modNAT-DK4 m *XCMPLX-0K3 n inTARSKIR2 C"
          using A46 A49 A50 A52 A56 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain f where
      [ty]:"f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 A,B :],C)" and 
      A57: " for y be ElementSUBSET-1M3\<^bsub>(NATNUMBERSK1)\<^esub>-of A holds  for x be ElementSUBSET-1M3\<^bsub>(NATNUMBERSK1)\<^esub>-of B holds f .BINOP-1K2\<^bsub>(A,B,C)\<^esub>(y,x) =XBOOLE-0R4 ?F(y,x)"
      using funct_7_sch_1 A45 sorry
    have A58: "f be ontoFUNCT-2V2\<^bsub>(C)\<^esub>"
    proof-
      have "rngRELSET-1K2\<^bsub>(C)\<^esub> f c=TARSKIR1 C & C c=TARSKIR1 rngRELSET-1K2\<^bsub>(C)\<^esub> f"
      proof(rule conjMI)
        show "rngRELSET-1K2\<^bsub>(C)\<^esub> f c=TARSKIR1 C"
          using relat_1_def_19 sorry
        have " for z be objectHIDDENM1 holds z inHIDDENR3 C implies z inHIDDENR3 rngRELSET-1K2\<^bsub>(C)\<^esub> f"
        proof(rule ballI,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          assume "z inHIDDENR3 C"
          then obtain i where
            [ty]:"i be ElementSUBSET-1M1-of NATNUMBERSK1" and 
            A59: "i =HIDDENR1 z"and A60: " ex x0 be IntegerINT-1M1 st  ex y0 be IntegerINT-1M1 st (((i =HIDDENR1 (m *XCMPLX-0K3 y0 +XCMPLX-0K2 n *XCMPLX-0K3 x0)modINT-1K6 m *XCMPLX-0K3 n & (m *XCMPLX-0K3 n,i)are-coprimeINT-2R1) & y0 <=XXREAL-0R1 n) & x0 <=XXREAL-0R1 m) & i >=XXREAL-0R2 0NUMBERSK6"
             sorry
          obtain x0 y0 where
            [ty]:"x0 be IntegerINT-1M1" "y0 be IntegerINT-1M1" and 
            A61: "i =HIDDENR1 (m *XCMPLX-0K3 y0 +XCMPLX-0K2 n *XCMPLX-0K3 x0)modINT-1K6 m *XCMPLX-0K3 n"and A62: "(m *XCMPLX-0K3 n,i)are-coprimeINT-2R1"and "y0 <=XXREAL-0R1 n"and "x0 <=XXREAL-0R1 m"and "i >=XXREAL-0R2 0NUMBERSK6"
            using A60 sorry
          obtain x y where
            [ty]:"x be IntegerINT-1M1" "y be IntegerINT-1M1" and 
            A63: "x =HIDDENR1 x0 modINT-1K6 m"and A64: "y =HIDDENR1 y0 modINT-1K6 n"
             sorry
          have A65: "x <=XXREAL-0R1 m"
            using A1 A63 newton_th_65 sorry
          have A66: "(m *XCMPLX-0K3 y +XCMPLX-0K2 n *XCMPLX-0K3 x)modINT-1K6 m *XCMPLX-0K3 n =HIDDENR1 (m *XCMPLX-0K3 y0 +XCMPLX-0K2 n *XCMPLX-0K3 x0)modINT-1K6 m *XCMPLX-0K3 n"
          proof-
            let ?k = "y0 divINT-1K5 n"
            let ?j = "x0 divINT-1K5 m"
            have "x0 modINT-1K6 m =HIDDENR1 x0 -XCMPLX-0K6 (x0 divINT-1K5 m)*XCMPLX-0K3 m & y0 modINT-1K6 n =HIDDENR1 y0 -XCMPLX-0K6 (y0 divINT-1K5 n)*XCMPLX-0K3 n"
              using A1 A2 int_1_def_10 sorry
            then have "m *XCMPLX-0K3 y0 +XCMPLX-0K2 n *XCMPLX-0K3 x0 =XBOOLE-0R4 (m *XCMPLX-0K3 y +XCMPLX-0K2 n *XCMPLX-0K3 x)+XCMPLX-0K2 (m *XCMPLX-0K3 n)*XCMPLX-0K3 (?k +XCMPLX-0K2 ?j)"
              using A63 A64 sorry
            thus "(m *XCMPLX-0K3 y +XCMPLX-0K2 n *XCMPLX-0K3 x)modINT-1K6 m *XCMPLX-0K3 n =HIDDENR1 (m *XCMPLX-0K3 y0 +XCMPLX-0K2 n *XCMPLX-0K3 x0)modINT-1K6 m *XCMPLX-0K3 n"
              using euler_1_th_12 sorry
          qed
          have A67: "y <=XXREAL-0R1 n"
            using A2 A64 newton_th_65 sorry
          have 
            [ty]:"x be ElementSUBSET-1M1-of NATNUMBERSK1" and
            [ty]:"y be ElementSUBSET-1M1-of NATNUMBERSK1"
            using A63 A64 int_1_th_3 newton_th_64 sorry
          have A68: "x <>HIDDENR2 0NUMBERSK6"
          proof-
            have "x =XBOOLE-0R4 0NUMBERSK6 implies  False "
            proof(rule impI)
              let ?j = "x0 divINT-1K5 m"
              let ?jj = "(y0 +XCMPLX-0K2 n *XCMPLX-0K3 ?j)-XCMPLX-0K6 n *XCMPLX-0K3 (m *XCMPLX-0K3 (y0 +XCMPLX-0K2 n *XCMPLX-0K3 ?j) divINT-1K5 m *XCMPLX-0K3 n)"
              assume "x =XBOOLE-0R4 0NUMBERSK6"
              then have "x0 -XCMPLX-0K6 (x0 divINT-1K5 m)*XCMPLX-0K3 m =XBOOLE-0R4 0NUMBERSK6"
                using A1 A63 int_1_def_10 sorry
              then have A69: "(m *XCMPLX-0K3 y0 +XCMPLX-0K2 n *XCMPLX-0K3 x0)modINT-1K6 m *XCMPLX-0K3 n =HIDDENR1 m *XCMPLX-0K3 (y0 +XCMPLX-0K2 n *XCMPLX-0K3 ?j) -XCMPLX-0K6 (m *XCMPLX-0K3 (y0 +XCMPLX-0K2 n *XCMPLX-0K3 ?j) divINT-1K5 m *XCMPLX-0K3 n)*XCMPLX-0K3 (m *XCMPLX-0K3 n)"
                using A4 int_1_def_10 sorry
              also have "... = m *XCMPLX-0K3 ((y0 +XCMPLX-0K2 n *XCMPLX-0K3 ?j)-XCMPLX-0K6 n *XCMPLX-0K3 (m *XCMPLX-0K3 (y0 +XCMPLX-0K2 n *XCMPLX-0K3 ?j) divINT-1K5 m *XCMPLX-0K3 n))"
                 sorry
              finally have "(m *XCMPLX-0K3 y0 +XCMPLX-0K2 n *XCMPLX-0K3 x0)modINT-1K6 m *XCMPLX-0K3 n =HIDDENR1 m *XCMPLX-0K3 ((y0 +XCMPLX-0K2 n *XCMPLX-0K3 ?j)-XCMPLX-0K6 n *XCMPLX-0K3 (m *XCMPLX-0K3 (y0 +XCMPLX-0K2 n *XCMPLX-0K3 ?j) divINT-1K5 m *XCMPLX-0K3 n))"
                 sorry
              then obtain g where 
                [ty]:"g be ElementSUBSET-1M1-of NATNUMBERSK1" and gDef:"g = m *XCMPLX-0K3 ?jj"
                using A61 sorry
              have A70: "m *XCMPLX-0K3 n gcdINT-2K3 m *XCMPLX-0K3 ?jj =XBOOLE-0R4 \<one>\<^sub>M"
                using A61 A62 A69 int_2_def_3 sorry
              have A71: "g >XXREAL-0R4 0NUMBERSK6 or g =XBOOLE-0R4 0NUMBERSK6"
                 sorry
              have " not ?jj <XXREAL-0R3 0NUMBERSK6"
              proof-
                have "(y0 +XCMPLX-0K2 n *XCMPLX-0K3 (x0 divINT-1K5 m))-XCMPLX-0K6 n *XCMPLX-0K3 (m *XCMPLX-0K3 (y0 +XCMPLX-0K2 n *XCMPLX-0K3 (x0 divINT-1K5 m)) divINT-1K5 m *XCMPLX-0K3 n) <XXREAL-0R3 0NUMBERSK6 implies  False "
                proof(rule impI)
                  assume "?jj <XXREAL-0R3 0NUMBERSK6"
                  then have "m *XCMPLX-0K3 ?jj <XXREAL-0R3 (0NUMBERSK6)*XCMPLX-0K3 ?jj"
                    using A1 xreal_1_th_69 sorry
                  thus " False "
                    using A71 sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              then obtain jj where 
                [ty]:"jj be ElementSUBSET-1M1-of NATNUMBERSK1" and jjDef:"jj = ?jj"
                using int_1_th_3 sorry
              have "m *XCMPLX-0K3 (n gcdINT-2K3 jj) =XBOOLE-0R4 \<one>\<^sub>M"
                using A2 A70 euler_1_th_15 sorry
              then have "jj =XBOOLE-0R4 0NUMBERSK6"
                using A1 nat_1_th_15 sorry
              then have "m *XCMPLX-0K3 n gcdINT-2K3 0NUMBERSK6 =XBOOLE-0R4 \<one>\<^sub>M"
                using A61 A62 A69 int_2_def_3 sorry
              thus " False "
                using A23 newton_th_52 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          have A72: "y <>HIDDENR2 0NUMBERSK6"
          proof-
            have "y =XBOOLE-0R4 0NUMBERSK6 implies  False "
            proof(rule impI)
              let ?j = "y0 divINT-1K5 n"
              let ?jj = "(m *XCMPLX-0K3 ?j +XCMPLX-0K2 x0)-XCMPLX-0K6 m *XCMPLX-0K3 (n *XCMPLX-0K3 (m *XCMPLX-0K3 ?j +XCMPLX-0K2 x0) divINT-1K5 m *XCMPLX-0K3 n)"
              assume "y =XBOOLE-0R4 0NUMBERSK6"
              then have "y0 -XCMPLX-0K6 (y0 divINT-1K5 n)*XCMPLX-0K3 n =XBOOLE-0R4 0NUMBERSK6"
                using A2 A64 int_1_def_10 sorry
              then have A73: "(m *XCMPLX-0K3 y0 +XCMPLX-0K2 n *XCMPLX-0K3 x0)modINT-1K6 m *XCMPLX-0K3 n =HIDDENR1 n *XCMPLX-0K3 (m *XCMPLX-0K3 ?j +XCMPLX-0K2 x0) -XCMPLX-0K6 (n *XCMPLX-0K3 (m *XCMPLX-0K3 ?j +XCMPLX-0K2 x0) divINT-1K5 m *XCMPLX-0K3 n)*XCMPLX-0K3 (m *XCMPLX-0K3 n)"
                using A4 int_1_def_10 sorry
              also have "... = n *XCMPLX-0K3 ((m *XCMPLX-0K3 ?j +XCMPLX-0K2 x0)-XCMPLX-0K6 m *XCMPLX-0K3 (n *XCMPLX-0K3 (m *XCMPLX-0K3 ?j +XCMPLX-0K2 x0) divINT-1K5 m *XCMPLX-0K3 n))"
                 sorry
              finally have "(m *XCMPLX-0K3 y0 +XCMPLX-0K2 n *XCMPLX-0K3 x0)modINT-1K6 m *XCMPLX-0K3 n =HIDDENR1 n *XCMPLX-0K3 ((m *XCMPLX-0K3 ?j +XCMPLX-0K2 x0)-XCMPLX-0K6 m *XCMPLX-0K3 (n *XCMPLX-0K3 (m *XCMPLX-0K3 ?j +XCMPLX-0K2 x0) divINT-1K5 m *XCMPLX-0K3 n))"
                 sorry
              then obtain g where 
                [ty]:"g be ElementSUBSET-1M1-of NATNUMBERSK1" and gDef:"g = n *XCMPLX-0K3 ?jj"
                using A61 sorry
              have A74: "m *XCMPLX-0K3 n gcdINT-2K3 n *XCMPLX-0K3 ?jj =XBOOLE-0R4 \<one>\<^sub>M"
                using A61 A62 A73 int_2_def_3 sorry
              have A75: "g >XXREAL-0R4 0NUMBERSK6 or g =XBOOLE-0R4 0NUMBERSK6"
                 sorry
              have " not ?jj <XXREAL-0R3 0NUMBERSK6"
              proof-
                have "(m *XCMPLX-0K3 (y0 divINT-1K5 n) +XCMPLX-0K2 x0)-XCMPLX-0K6 m *XCMPLX-0K3 (n *XCMPLX-0K3 (m *XCMPLX-0K3 (y0 divINT-1K5 n) +XCMPLX-0K2 x0) divINT-1K5 m *XCMPLX-0K3 n) <XXREAL-0R3 0NUMBERSK6 implies  False "
                proof(rule impI)
                  assume "?jj <XXREAL-0R3 0NUMBERSK6"
                  then have "n *XCMPLX-0K3 ?jj <XXREAL-0R3 (0NUMBERSK6)*XCMPLX-0K3 ?jj"
                    using A2 xreal_1_th_69 sorry
                  thus " False "
                    using A75 sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              then obtain jj where 
                [ty]:"jj be ElementSUBSET-1M1-of NATNUMBERSK1" and jjDef:"jj = ?jj"
                using int_1_th_3 sorry
              have "n *XCMPLX-0K3 (m gcdINT-2K3 jj) =XBOOLE-0R4 \<one>\<^sub>M"
                using A1 A74 euler_1_th_15 sorry
              then have "jj =XBOOLE-0R4 0NUMBERSK6"
                using A2 nat_1_th_15 sorry
              then have "m *XCMPLX-0K3 n gcdINT-2K3 0NUMBERSK6 =XBOOLE-0R4 \<one>\<^sub>M"
                using A61 A62 A73 int_2_def_3 sorry
              thus " False "
                using A23 newton_th_52 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          have A76: "(m,x0)are-coprimeINT-2R1"
          proof-
            let ?p = "m gcdINT-2K3 x0"
            have "?p dividesNAT-DR1 m"
              using int_2_th_21 sorry
            then obtain i1 where
              [ty]:"i1 be IntegerINT-1M1" and 
              A77: "m =XBOOLE-0R4 ?p *XCMPLX-0K3 i1"
              using int_1_def_3 sorry
            have "?p dividesINT-1R1 x0"
              using int_2_th_21 sorry
            then obtain i2 where
              [ty]:"i2 be IntegerINT-1M1" and 
              A78: "x0 =HIDDENR1 ?p *XCMPLX-0K3 i2"
              using int_1_def_3 sorry
            let ?jj = "i1 *XCMPLX-0K3 n"
            let ?k = "((?p *XCMPLX-0K3 i1)*XCMPLX-0K3 y0 +XCMPLX-0K2 n *XCMPLX-0K3 (?p *XCMPLX-0K3 i2))divINT-1K5 (?p *XCMPLX-0K3 i1)*XCMPLX-0K3 n"
            let ?j = "(i1 *XCMPLX-0K3 y0 +XCMPLX-0K2 n *XCMPLX-0K3 i2)-XCMPLX-0K6 (i1 *XCMPLX-0K3 ?k)*XCMPLX-0K3 n"
            have A79: "?p <>HIDDENR2 0NUMBERSK6"
              using A1 A77 sorry
            have A80: "(m *XCMPLX-0K3 y0 +XCMPLX-0K2 n *XCMPLX-0K3 x0)modINT-1K6 m *XCMPLX-0K3 n =HIDDENR1 ((?p *XCMPLX-0K3 i1)*XCMPLX-0K3 y0 +XCMPLX-0K2 n *XCMPLX-0K3 (?p *XCMPLX-0K3 i2))-XCMPLX-0K6 (((?p *XCMPLX-0K3 i1)*XCMPLX-0K3 y0 +XCMPLX-0K2 n *XCMPLX-0K3 (?p *XCMPLX-0K3 i2))divINT-1K5 (?p *XCMPLX-0K3 i1)*XCMPLX-0K3 n)*XCMPLX-0K3 ((?p *XCMPLX-0K3 i1)*XCMPLX-0K3 n)"
              using A4 A77 A78 int_1_def_10 sorry
            have A81: "((?p *XCMPLX-0K3 i1)*XCMPLX-0K3 y0 +XCMPLX-0K2 n *XCMPLX-0K3 (?p *XCMPLX-0K3 i2))-XCMPLX-0K6 ?k *XCMPLX-0K3 ((?p *XCMPLX-0K3 i1)*XCMPLX-0K3 n) =XBOOLE-0R4 ?p *XCMPLX-0K3 ((i1 *XCMPLX-0K3 y0 +XCMPLX-0K2 n *XCMPLX-0K3 i2)-XCMPLX-0K6 (i1 *XCMPLX-0K3 ?k)*XCMPLX-0K3 n)"
               sorry
            have " not ?j <XXREAL-0R3 0NUMBERSK6"
            proof-
              have "(i1 *XCMPLX-0K3 y0 +XCMPLX-0K2 n *XCMPLX-0K3 i2)-XCMPLX-0K6 (i1 *XCMPLX-0K3 ((((m gcdINT-2K3 x0)*XCMPLX-0K3 i1)*XCMPLX-0K3 y0 +XCMPLX-0K2 n *XCMPLX-0K3 ((m gcdINT-2K3 x0)*XCMPLX-0K3 i2))divINT-1K5 ((m gcdINT-2K3 x0)*XCMPLX-0K3 i1)*XCMPLX-0K3 n))*XCMPLX-0K3 n <XXREAL-0R3 0NUMBERSK6 implies  False "
              proof(rule impI)
                assume "?j <XXREAL-0R3 0NUMBERSK6"
                then have "?p *XCMPLX-0K3 ?j <XXREAL-0R3 (0NUMBERSK6)*XCMPLX-0K3 ?j"
                  using A79 xreal_1_th_69 sorry
                thus " False "
                  using A4 A61 A77 A78 A81 int_1_def_10 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            then obtain p j where 
              [ty]:"p be ElementSUBSET-1M1-of NATNUMBERSK1" and pDef:"p = ?p" and
              [ty]:"j be ElementSUBSET-1M1-of NATNUMBERSK1" and jDef:"j = ?j"
              using int_1_th_3 sorry
            have " not ?jj <XXREAL-0R3 0NUMBERSK6"
            proof-
              have "i1 *XCMPLX-0K3 n <XXREAL-0R3 0NUMBERSK6 implies  False "
              proof(rule impI)
                assume "?jj <XXREAL-0R3 0NUMBERSK6"
                then have "p *XCMPLX-0K3 ?jj <XXREAL-0R3 (0NUMBERSK6)*XCMPLX-0K3 ?jj"
                  using A79 xreal_1_th_69 sorry
                thus " False "
                  using A4 A77 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            then obtain jj where 
              [ty]:"jj be ElementSUBSET-1M1-of NATNUMBERSK1" and jjDef:"jj = ?jj"
              using int_1_th_3 sorry
            have A82: "m *XCMPLX-0K3 n =XBOOLE-0R4 p *XCMPLX-0K3 (i1 *XCMPLX-0K3 n)"
              using A77 sorry
            have "p =XBOOLE-0R4 \<one>\<^sub>M"
            proof-
              show "p =XBOOLE-0R4 \<one>\<^sub>M"
              proof-
                have cases: "(p <>HIDDENR2 0NUMBERSK6 & jj <>HIDDENR2 0NUMBERSK6) & j <>HIDDENR2 0NUMBERSK6 or (p <>HIDDENR2 0NUMBERSK6 & jj <>HIDDENR2 0NUMBERSK6) & j =XBOOLE-0R4 0NUMBERSK6"
                  using A1 A2 A82 xcmplx_1_th_6 sorry
                have case1: "(p <>HIDDENR2 0NUMBERSK6 & jj <>HIDDENR2 0NUMBERSK6) & j <>HIDDENR2 0NUMBERSK6 implies p =XBOOLE-0R4 \<one>\<^sub>M"
                proof(rule impI)
                  assume A83: "(p <>HIDDENR2 0NUMBERSK6 & jj <>HIDDENR2 0NUMBERSK6) & j <>HIDDENR2 0NUMBERSK6"
                  have "p *NAT-1K2 jj gcdINT-2K3 p *NAT-1K2 j =XBOOLE-0R4 \<one>\<^sub>M"
                    using A61 A62 A77 A80 int_2_def_3 sorry
                  then have "p *XCMPLX-0K3 (jj gcdINT-2K3 j) =XBOOLE-0R4 \<one>\<^sub>M"
                    using A83 euler_1_th_15 sorry
                  thus "p =XBOOLE-0R4 \<one>\<^sub>M"
                    using nat_1_th_15 sorry
                qed
                have case2: "(p <>HIDDENR2 0NUMBERSK6 & jj <>HIDDENR2 0NUMBERSK6) & j =XBOOLE-0R4 0NUMBERSK6 implies p =XBOOLE-0R4 \<one>\<^sub>M"
                proof(rule impI)
                  assume "(p <>HIDDENR2 0NUMBERSK6 & jj <>HIDDENR2 0NUMBERSK6) & j =XBOOLE-0R4 0NUMBERSK6"
                  then have "p *NAT-1K2 jj gcdINT-2K3 0NUMBERSK6 =XBOOLE-0R4 \<one>\<^sub>M"
                    using A61 A62 A77 A80 A81 int_2_def_3 sorry
                  then have "p *NAT-1K2 jj =XBOOLE-0R4 \<one>\<^sub>M"
                    using newton_th_52 sorry
                  thus "p =XBOOLE-0R4 \<one>\<^sub>M"
                    using nat_1_th_15 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "(m,x0)are-coprimeINT-2R1"
              using int_2_def_3 sorry
          qed
          have "(n,y0)are-coprimeINT-2R1"
          proof-
            let ?p = "n gcdINT-2K3 y0"
            have "?p dividesNAT-DR1 n"
              using int_2_th_21 sorry
            then obtain i1 where
              [ty]:"i1 be IntegerINT-1M1" and 
              A84: "n =XBOOLE-0R4 ?p *XCMPLX-0K3 i1"
              using int_1_def_3 sorry
            have "?p dividesINT-1R1 y0"
              using int_2_th_21 sorry
            then obtain i2 where
              [ty]:"i2 be IntegerINT-1M1" and 
              A85: "y0 =HIDDENR1 ?p *XCMPLX-0K3 i2"
              using int_1_def_3 sorry
            let ?jj = "i1 *XCMPLX-0K3 m"
            let ?k = "(m *XCMPLX-0K3 (?p *XCMPLX-0K3 i2) +XCMPLX-0K2 (?p *XCMPLX-0K3 i1)*XCMPLX-0K3 x0)divINT-1K5 m *XCMPLX-0K3 (?p *XCMPLX-0K3 i1)"
            let ?j = "(m *XCMPLX-0K3 i2 +XCMPLX-0K2 i1 *XCMPLX-0K3 x0)-XCMPLX-0K6 (i1 *XCMPLX-0K3 ?k)*XCMPLX-0K3 m"
            have A86: "?p <>HIDDENR2 0NUMBERSK6"
              using A2 A84 sorry
            have A87: "(m *XCMPLX-0K3 y0 +XCMPLX-0K2 n *XCMPLX-0K3 x0)modINT-1K6 m *XCMPLX-0K3 n =HIDDENR1 (m *XCMPLX-0K3 (?p *XCMPLX-0K3 i2) +XCMPLX-0K2 (?p *XCMPLX-0K3 i1)*XCMPLX-0K3 x0)-XCMPLX-0K6 ((m *XCMPLX-0K3 (?p *XCMPLX-0K3 i2) +XCMPLX-0K2 (?p *XCMPLX-0K3 i1)*XCMPLX-0K3 x0)divINT-1K5 m *XCMPLX-0K3 (?p *XCMPLX-0K3 i1))*XCMPLX-0K3 (m *XCMPLX-0K3 (?p *XCMPLX-0K3 i1))"
              using A4 A84 A85 int_1_def_10 sorry
            have A88: "(m *XCMPLX-0K3 (?p *XCMPLX-0K3 i2) +XCMPLX-0K2 (?p *XCMPLX-0K3 i1)*XCMPLX-0K3 x0)-XCMPLX-0K6 ?k *XCMPLX-0K3 (m *XCMPLX-0K3 (?p *XCMPLX-0K3 i1)) =XBOOLE-0R4 ?p *XCMPLX-0K3 ((m *XCMPLX-0K3 i2 +XCMPLX-0K2 i1 *XCMPLX-0K3 x0)-XCMPLX-0K6 (i1 *XCMPLX-0K3 ?k)*XCMPLX-0K3 m)"
               sorry
            have "?j >=XXREAL-0R2 0NUMBERSK6"
            proof-
              have "(m *XCMPLX-0K3 i2 +XCMPLX-0K2 i1 *XCMPLX-0K3 x0)-XCMPLX-0K6 (i1 *XCMPLX-0K3 ((m *XCMPLX-0K3 ((n gcdINT-2K3 y0)*XCMPLX-0K3 i2) +XCMPLX-0K2 ((n gcdINT-2K3 y0)*XCMPLX-0K3 i1)*XCMPLX-0K3 x0)divINT-1K5 m *XCMPLX-0K3 ((n gcdINT-2K3 y0)*XCMPLX-0K3 i1)))*XCMPLX-0K3 m <XXREAL-0R3 0NUMBERSK6 implies  False "
              proof(rule impI)
                assume "?j <XXREAL-0R3 0NUMBERSK6"
                then have "?p *XCMPLX-0K3 ?j <XXREAL-0R3 (0NUMBERSK6)*XCMPLX-0K3 ?j"
                  using A86 xreal_1_th_69 sorry
                thus " False "
                  using A4 A61 A84 A85 A88 int_1_def_10 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            then obtain p j where 
              [ty]:"p be ElementSUBSET-1M1-of NATNUMBERSK1" and pDef:"p = ?p" and
              [ty]:"j be ElementSUBSET-1M1-of NATNUMBERSK1" and jDef:"j = ?j"
              using int_1_th_3 sorry
            have " not ?jj <XXREAL-0R3 0NUMBERSK6"
            proof-
              have "i1 *XCMPLX-0K3 m <XXREAL-0R3 0NUMBERSK6 implies  False "
              proof(rule impI)
                assume "?jj <XXREAL-0R3 0NUMBERSK6"
                then have "p *XCMPLX-0K3 ?jj <XXREAL-0R3 (0NUMBERSK6)*XCMPLX-0K3 ?jj"
                  using A86 xreal_1_th_69 sorry
                thus " False "
                  using A4 A84 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            then obtain jj where 
              [ty]:"jj be ElementSUBSET-1M1-of NATNUMBERSK1" and jjDef:"jj = ?jj"
              using int_1_th_3 sorry
            have A89: "m *XCMPLX-0K3 n =XBOOLE-0R4 p *XCMPLX-0K3 (i1 *XCMPLX-0K3 m)"
              using A84 sorry
            have "p =XBOOLE-0R4 \<one>\<^sub>M"
            proof-
              show "p =XBOOLE-0R4 \<one>\<^sub>M"
              proof-
                have cases: "(p <>HIDDENR2 0NUMBERSK6 & jj <>HIDDENR2 0NUMBERSK6) & j <>HIDDENR2 0NUMBERSK6 or (p <>HIDDENR2 0NUMBERSK6 & jj <>HIDDENR2 0NUMBERSK6) & j =XBOOLE-0R4 0NUMBERSK6"
                  using A1 A2 A89 xcmplx_1_th_6 sorry
                have case1: "(p <>HIDDENR2 0NUMBERSK6 & jj <>HIDDENR2 0NUMBERSK6) & j <>HIDDENR2 0NUMBERSK6 implies p =XBOOLE-0R4 \<one>\<^sub>M"
                proof(rule impI)
                  assume A90: "(p <>HIDDENR2 0NUMBERSK6 & jj <>HIDDENR2 0NUMBERSK6) & j <>HIDDENR2 0NUMBERSK6"
                  have "p *NAT-1K2 jj gcdINT-2K3 p *NAT-1K2 j =XBOOLE-0R4 \<one>\<^sub>M"
                    using A61 A62 A84 A87 int_2_def_3 sorry
                  then have "p *XCMPLX-0K3 (jj gcdINT-2K3 j) =XBOOLE-0R4 \<one>\<^sub>M"
                    using A90 euler_1_th_15 sorry
                  thus "p =XBOOLE-0R4 \<one>\<^sub>M"
                    using nat_1_th_15 sorry
                qed
                have case2: "(p <>HIDDENR2 0NUMBERSK6 & jj <>HIDDENR2 0NUMBERSK6) & j =XBOOLE-0R4 0NUMBERSK6 implies p =XBOOLE-0R4 \<one>\<^sub>M"
                proof(rule impI)
                  assume "(p <>HIDDENR2 0NUMBERSK6 & jj <>HIDDENR2 0NUMBERSK6) & j =XBOOLE-0R4 0NUMBERSK6"
                  then have "p *NAT-1K2 jj gcdINT-2K3 0NUMBERSK6 =XBOOLE-0R4 \<one>\<^sub>M"
                    using A61 A62 A84 A87 A88 int_2_def_3 sorry
                  then have "p *NAT-1K2 jj =XBOOLE-0R4 \<one>\<^sub>M"
                    using newton_th_52 sorry
                  thus "p =XBOOLE-0R4 \<one>\<^sub>M"
                    using nat_1_th_15 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "(n,y0)are-coprimeINT-2R1"
              using int_2_def_3 sorry
          qed
          then have A91: "y0 gcdINT-2K3 n =XBOOLE-0R4 \<one>\<^sub>M"
            using int_2_def_3 sorry
          have "x =XBOOLE-0R4 x0 -XCMPLX-0K6 (x0 divINT-1K5 m)*XCMPLX-0K3 m"
            using A1 A63 int_1_def_10 sorry
          then have "x0 gcdINT-2K3 m =XBOOLE-0R4 (x +XCMPLX-0K2 (x0 divINT-1K5 m)*XCMPLX-0K3 m)gcdINT-2K3 m"
             sorry
          then have "x0 gcdINT-2K3 m =XBOOLE-0R4 x gcdINT-2K3 m"
            using A68 euler_1_th_16 sorry
          then have "m gcdINT-2K3 x =XBOOLE-0R4 \<one>\<^sub>M"
            using A76 int_2_def_3 sorry
          then have A92: "(m,x)are-coprimeINT-2R1"
            using int_2_def_3 sorry
          have "x >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
            using A68 int_1_th_7 sorry
          then have A93: "x inTARSKIR2 B"
            using A65 A92 sorry
          have "y =XBOOLE-0R4 y0 -XCMPLX-0K6 (y0 divINT-1K5 n)*XCMPLX-0K3 n"
            using A2 A64 int_1_def_10 sorry
          then have "y0 gcdINT-2K3 n =XBOOLE-0R4 (y +XCMPLX-0K2 (y0 divINT-1K5 n)*XCMPLX-0K3 n)gcdINT-2K3 n"
             sorry
          then have "y0 gcdINT-2K3 n =XBOOLE-0R4 y gcdINT-2K3 n"
            using A72 euler_1_th_16 sorry
          then have A94: "(n,y)are-coprimeINT-2R1"
            using A91 int_2_def_3 sorry
          have "y >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
            using A72 int_1_th_7 sorry
          then have "y inTARSKIR2 A"
            using A67 A94 sorry
          then have 
            [ty]:"y be ElementSUBSET-1M3\<^bsub>(NATNUMBERSK1)\<^esub>-of A"
             sorry
          have 
            [ty]:"x be ElementSUBSET-1M3\<^bsub>(NATNUMBERSK1)\<^esub>-of B"
            using A93 sorry
          have A95: "i =XBOOLE-0R4 f .BINOP-1K2\<^bsub>(A,B,C)\<^esub>(y,x)"
            using A57 A61 A66 sorry
          obtain w where
            [ty]:"w be setHIDDENM2" and 
            A96: "w =HIDDENR1 [TARSKIK4 y,x ]"
             sorry
          have "domRELSET-1K1\<^bsub>([:ZFMISC-1K2 A,B :])\<^esub> f =XBOOLE-0R4 [:ZFMISC-1K2 A,B :]"
            using funct_2_def_1 sorry
          then have "w inTARSKIR2 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 A,B :])\<^esub> f"
            using A96 zfmisc_1_th_87 sorry
          thus "z inHIDDENR3 rngRELSET-1K2\<^bsub>(C)\<^esub> f"
            using A59 A96 A95 funct_1_def_3 sorry
        qed "sorry"
        thus "C c=TARSKIR1 rngRELSET-1K2\<^bsub>(C)\<^esub> f"
          using tarski_def_3 sorry
      qed
      thus "f be ontoFUNCT-2V2\<^bsub>(C)\<^esub>"
        using funct_2_def_3 xboole_0_def_10 sorry
    qed
    have A97: "m *XCMPLX-0K3 n >=XXREAL-0R2 \<one>\<^sub>M"
      using A1 A2 nat_1_th_14 xcmplx_1_th_6 sorry
    have "f be one-to-oneFUNCT-1V2"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 A,B :])\<^esub> f implies (y inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 A,B :])\<^esub> f implies (f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y implies x =HIDDENR1 y))"
      proof(rule ballI,rule ballI,rule impI,rule impI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        have A98: "domRELSET-1K1\<^bsub>([:ZFMISC-1K2 A,B :])\<^esub> f =XBOOLE-0R4 [:ZFMISC-1K2 A,B :]"
          using funct_2_def_1 sorry
        assume "x inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 A,B :])\<^esub> f"
        then obtain xx1 xx2 where
          [ty]:"xx1 be ElementSUBSET-1M3\<^bsub>(NATNUMBERSK1)\<^esub>-of A" "xx2 be ElementSUBSET-1M3\<^bsub>(NATNUMBERSK1)\<^esub>-of B" and 
          A99: "x =HIDDENR1 [TARSKIK4 xx1,xx2 ]"
          using A98 domain_1_th_1 sorry
        assume "y inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 A,B :])\<^esub> f"
        then obtain yy1 yy2 where
          [ty]:"yy1 be ElementSUBSET-1M3\<^bsub>(NATNUMBERSK1)\<^esub>-of A" "yy2 be ElementSUBSET-1M3\<^bsub>(NATNUMBERSK1)\<^esub>-of B" and 
          A100: "y =HIDDENR1 [TARSKIK4 yy1,yy2 ]"
          using A98 domain_1_th_1 sorry
        have "xx1 inTARSKIR2 A"
           sorry
        then obtain x1 where
          [ty]:"x1 be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A101: "xx1 =XBOOLE-0R4 x1"and "(n,x1)are-coprimeINT-2R1"and A102: "x1 >=XXREAL-0R2 \<one>\<^sub>M"and A103: "x1 <=XXREAL-0R1 n"
           sorry
        have "xx2 inTARSKIR2 B"
           sorry
        then obtain x2 where
          [ty]:"x2 be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A104: "xx2 =XBOOLE-0R4 x2"and "(m,x2)are-coprimeINT-2R1"and A105: "x2 >=XXREAL-0R2 \<one>\<^sub>M"and A106: "x2 <=XXREAL-0R1 m"
           sorry
        obtain p where
          [ty]:"p be IntegerINT-1M1" and 
          A107: "p =HIDDENR1 m"
           sorry
        assume A108: "f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y"
        have "yy2 inTARSKIR2 B"
           sorry
        then obtain y2 where
          [ty]:"y2 be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A109: "yy2 =XBOOLE-0R4 y2"and "(m,y2)are-coprimeINT-2R1"and A110: "y2 >=XXREAL-0R2 \<one>\<^sub>M"and A111: "y2 <=XXREAL-0R1 m"
           sorry
        have "yy1 inTARSKIR2 A"
           sorry
        then obtain y1 where
          [ty]:"y1 be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A112: "yy1 =XBOOLE-0R4 y1"and "(n,y1)are-coprimeINT-2R1"and A113: "y1 >=XXREAL-0R2 \<one>\<^sub>M"and A114: "y1 <=XXREAL-0R1 n"
           sorry
        have A115: "(x1 *XCMPLX-0K3 m +XCMPLX-0K2 x2 *XCMPLX-0K3 n)modNAT-DK4 m *XCMPLX-0K3 n =HIDDENR1 f .BINOP-1K2\<^bsub>(A,B,C)\<^esub>(xx1,xx2)"
          using A57 A101 A104 sorry
        also have "... = f .BINOP-1K2\<^bsub>(A,B,C)\<^esub>(yy1,yy2)"
          using A99 A100 A108 sorry
        also have "... = (y1 *XCMPLX-0K3 m +XCMPLX-0K2 y2 *XCMPLX-0K3 n)modNAT-DK4 m *XCMPLX-0K3 n"
          using A57 A112 A109 sorry
        finally have "(x1 *XCMPLX-0K3 m +XCMPLX-0K2 x2 *XCMPLX-0K3 n)modNAT-DK4 m *XCMPLX-0K3 n =HIDDENR1 (y1 *XCMPLX-0K3 m +XCMPLX-0K2 y2 *XCMPLX-0K3 n)modNAT-DK4 m *XCMPLX-0K3 n"
           sorry
        have 
          [ty]:"y1 be ElementSUBSET-1M1-of NATNUMBERSK1" and
          [ty]:"y2 be ElementSUBSET-1M1-of NATNUMBERSK1" and
          [ty]:"x1 be ElementSUBSET-1M1-of NATNUMBERSK1" and
          [ty]:"x2 be ElementSUBSET-1M1-of NATNUMBERSK1"
           sorry
        let ?k = "(x1 *XCMPLX-0K3 m +XCMPLX-0K2 x2 *XCMPLX-0K3 n)modNAT-DK4 m *XCMPLX-0K3 n"
        have A116: "(x1 *XCMPLX-0K3 m +XCMPLX-0K2 x2 *XCMPLX-0K3 n)-XCMPLX-0K6 (y1 *XCMPLX-0K3 m +XCMPLX-0K2 y2 *XCMPLX-0K3 n) =XBOOLE-0R4 m *XCMPLX-0K3 (x1 -XCMPLX-0K6 y1) +XCMPLX-0K2 n *XCMPLX-0K3 (x2 -XCMPLX-0K6 y2) & (?k +XCMPLX-0K2 ((x1 *XCMPLX-0K3 m +XCMPLX-0K2 x2 *XCMPLX-0K3 n)divNAT-DK3 m *XCMPLX-0K3 n)*XCMPLX-0K3 (m *XCMPLX-0K3 n))-XCMPLX-0K6 (?k +XCMPLX-0K2 ((y1 *XCMPLX-0K3 m +XCMPLX-0K2 y2 *XCMPLX-0K3 n)divNAT-DK3 m *XCMPLX-0K3 n)*XCMPLX-0K3 (m *XCMPLX-0K3 n)) =XBOOLE-0R4 (m *XCMPLX-0K3 n)*XCMPLX-0K3 (((x1 *XCMPLX-0K3 m +XCMPLX-0K2 x2 *XCMPLX-0K3 n)divNAT-DK3 m *XCMPLX-0K3 n)-XCMPLX-0K6 ((y1 *XCMPLX-0K3 m +XCMPLX-0K2 y2 *XCMPLX-0K3 n)divNAT-DK3 m *XCMPLX-0K3 n))"
           sorry
        let ?w = "((x1 *XCMPLX-0K3 m +XCMPLX-0K2 x2 *XCMPLX-0K3 n)divNAT-DK3 m *XCMPLX-0K3 n)-XCMPLX-0K6 ((y1 *XCMPLX-0K3 m +XCMPLX-0K2 y2 *XCMPLX-0K3 n)divNAT-DK3 m *XCMPLX-0K3 n)"
        have "y1 *XCMPLX-0K3 m +XCMPLX-0K2 y2 *XCMPLX-0K3 n =XBOOLE-0R4 ?k +XCMPLX-0K2 ((y1 *XCMPLX-0K3 m +XCMPLX-0K2 y2 *XCMPLX-0K3 n)divNAT-DK3 m *XCMPLX-0K3 n)*XCMPLX-0K3 (m *XCMPLX-0K3 n)"
          using A97 A115 nat_d_th_2 sorry
        then have A117: "m *XCMPLX-0K3 (x1 -XCMPLX-0K6 y1) +XCMPLX-0K2 n *XCMPLX-0K3 (x2 -XCMPLX-0K6 y2) =XBOOLE-0R4 (m *XCMPLX-0K3 n)*XCMPLX-0K3 ?w"
          using A97 A116 nat_d_th_2 sorry
        then have "n *XCMPLX-0K3 (x2 -XCMPLX-0K6 y2) =XBOOLE-0R4 m *XCMPLX-0K3 (n *XCMPLX-0K3 ?w -XCMPLX-0K6 (x1 -XCMPLX-0K6 y1))"
           sorry
        then have A118: "p dividesINT-1R1 n *XCMPLX-0K3 (x2 -XCMPLX-0K6 y2)"
          using A107 int_1_def_3 sorry
        obtain p where
          [ty]:"p be IntegerINT-1M1" and 
          A119: "p =HIDDENR1 n"
           sorry
        have "m *XCMPLX-0K3 (x1 -XCMPLX-0K6 y1) =XBOOLE-0R4 n *XCMPLX-0K3 (m *XCMPLX-0K3 ?w -XCMPLX-0K6 (x2 -XCMPLX-0K6 y2))"
          using A117 sorry
        then have A120: "p dividesINT-1R1 m *XCMPLX-0K3 (x1 -XCMPLX-0K6 y1)"
          using A119 int_1_def_3 sorry
        then have A121: "n dividesINT-1R1 x1 -XCMPLX-0K6 y1"
          using A3 A119 int_2_th_25 sorry
        have A122: "x1 -XCMPLX-0K6 y1 =XBOOLE-0R4 0NUMBERSK6"
        proof-
          show "x1 -XCMPLX-0K6 y1 =XBOOLE-0R4 0NUMBERSK6"
          proof-
            have cases: "0NUMBERSK6 <=XXREAL-0R1 x1 -XCMPLX-0K6 y1 or x1 -XCMPLX-0K6 y1 <=XXREAL-0R1 0NUMBERSK6"
               sorry
            have case1: "0NUMBERSK6 <=XXREAL-0R1 x1 -XCMPLX-0K6 y1 implies x1 -XCMPLX-0K6 y1 =XBOOLE-0R4 0NUMBERSK6"
            proof(rule impI)
              assume A123: "0NUMBERSK6 <=XXREAL-0R1 x1 -XCMPLX-0K6 y1"
              obtain k where
                [ty]:"k be IntegerINT-1M1" and 
                A124: "k =HIDDENR1 x1 -XCMPLX-0K6 y1"
                 sorry
              have 
                [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1"
                using A123 A124 int_1_th_3 sorry
              have "k =XBOOLE-0R4 0NUMBERSK6"
              proof-
                have "k <>HIDDENR2 0NUMBERSK6 implies  False "
                proof(rule impI)
                  let ?b = "n +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)"
                  have "-XCMPLX-0K4 y1 <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
                    using A113 xreal_1_th_24 sorry
                  then have A125: "x1 +XCMPLX-0K2 (-XCMPLX-0K4 y1) <=XXREAL-0R1 n +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)"
                    using A103 xreal_1_th_7 sorry
                  have A126: "k <XXREAL-0R3 ?b +XCMPLX-0K2 \<one>\<^sub>M"
                    using A124 A125 nat_1_th_13 sorry
                  assume "k <>HIDDENR2 0NUMBERSK6"
                  thus " False "
                    using A3 A119 A120 A124 A126 int_2_th_25 nat_d_th_7 sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              thus "x1 -XCMPLX-0K6 y1 =XBOOLE-0R4 0NUMBERSK6"
                using A124 sorry
            qed
            have case2: "x1 -XCMPLX-0K6 y1 <=XXREAL-0R1 0NUMBERSK6 implies x1 -XCMPLX-0K6 y1 =XBOOLE-0R4 0NUMBERSK6"
            proof(rule impI)
              assume A127: "x1 -XCMPLX-0K6 y1 <=XXREAL-0R1 0NUMBERSK6"
              obtain k where
                [ty]:"k be IntegerINT-1M1" and 
                A128: "k =HIDDENR1 -XCMPLX-0K4 (x1 -XCMPLX-0K6 y1)"
                 sorry
              have A129: "n dividesINT-1R1 k"
                using A121 A128 int_2_th_10 sorry
              have 
                [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1"
                using A127 A128 int_1_th_3 sorry
              have "k =XBOOLE-0R4 0NUMBERSK6"
              proof-
                have "k <>HIDDENR2 0NUMBERSK6 implies  False "
                proof(rule impI)
                  let ?b = "n +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)"
                  have "-XCMPLX-0K4 x1 <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
                    using A102 xreal_1_th_24 sorry
                  then have A130: "(-XCMPLX-0K4 x1)+XCMPLX-0K2 y1 <=XXREAL-0R1 n +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)"
                    using A114 xreal_1_th_7 sorry
                  have A131: "k <XXREAL-0R3 ?b +XCMPLX-0K2 \<one>\<^sub>M"
                    using A128 A130 nat_1_th_13 sorry
                  assume "k <>HIDDENR2 0NUMBERSK6"
                  thus " False "
                    using A129 A131 nat_d_th_7 sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              thus "x1 -XCMPLX-0K6 y1 =XBOOLE-0R4 0NUMBERSK6"
                using A128 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        have A132: "m dividesINT-1R1 x2 -XCMPLX-0K6 y2"
          using A3 A107 A118 int_2_th_25 sorry
        have "x2 -XCMPLX-0K6 y2 =XBOOLE-0R4 0NUMBERSK6"
        proof-
          show "x2 -XCMPLX-0K6 y2 =XBOOLE-0R4 0NUMBERSK6"
          proof-
            have cases: "0NUMBERSK6 <=XXREAL-0R1 x2 -XCMPLX-0K6 y2 or x2 -XCMPLX-0K6 y2 <=XXREAL-0R1 0NUMBERSK6"
               sorry
            have case1: "0NUMBERSK6 <=XXREAL-0R1 x2 -XCMPLX-0K6 y2 implies x2 -XCMPLX-0K6 y2 =XBOOLE-0R4 0NUMBERSK6"
            proof(rule impI)
              assume A133: "0NUMBERSK6 <=XXREAL-0R1 x2 -XCMPLX-0K6 y2"
              obtain k where
                [ty]:"k be IntegerINT-1M1" and 
                A134: "k =HIDDENR1 x2 -XCMPLX-0K6 y2"
                 sorry
              have 
                [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1"
                using A133 A134 int_1_th_3 sorry
              have "k =XBOOLE-0R4 0NUMBERSK6"
              proof-
                have "k <>HIDDENR2 0NUMBERSK6 implies  False "
                proof(rule impI)
                  let ?b = "m +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)"
                  have "-XCMPLX-0K4 y2 <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
                    using A110 xreal_1_th_24 sorry
                  then have A135: "x2 +XCMPLX-0K2 (-XCMPLX-0K4 y2) <=XXREAL-0R1 m +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)"
                    using A106 xreal_1_th_7 sorry
                  have A136: "k <XXREAL-0R3 ?b +XCMPLX-0K2 \<one>\<^sub>M"
                    using A134 A135 nat_1_th_13 sorry
                  assume "k <>HIDDENR2 0NUMBERSK6"
                  thus " False "
                    using A3 A107 A118 A134 A136 int_2_th_25 nat_d_th_7 sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              thus "x2 -XCMPLX-0K6 y2 =XBOOLE-0R4 0NUMBERSK6"
                using A134 sorry
            qed
            have case2: "x2 -XCMPLX-0K6 y2 <=XXREAL-0R1 0NUMBERSK6 implies x2 -XCMPLX-0K6 y2 =XBOOLE-0R4 0NUMBERSK6"
            proof(rule impI)
              assume A137: "x2 -XCMPLX-0K6 y2 <=XXREAL-0R1 0NUMBERSK6"
              obtain k where
                [ty]:"k be IntegerINT-1M1" and 
                A138: "k =HIDDENR1 -XCMPLX-0K4 (x2 -XCMPLX-0K6 y2)"
                 sorry
              have A139: "m dividesINT-1R1 k"
                using A132 A138 int_2_th_10 sorry
              have 
                [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1"
                using A137 A138 int_1_th_3 sorry
              have "k =XBOOLE-0R4 0NUMBERSK6"
              proof-
                have "k <>HIDDENR2 0NUMBERSK6 implies  False "
                proof(rule impI)
                  let ?b = "m +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)"
                  have "-XCMPLX-0K4 x2 <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
                    using A105 xreal_1_th_24 sorry
                  then have A140: "(-XCMPLX-0K4 x2)+XCMPLX-0K2 y2 <=XXREAL-0R1 m +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)"
                    using A111 xreal_1_th_7 sorry
                  have A141: "k <XXREAL-0R3 ?b +XCMPLX-0K2 \<one>\<^sub>M"
                    using A138 A140 nat_1_th_13 sorry
                  assume "k <>HIDDENR2 0NUMBERSK6"
                  thus " False "
                    using A139 A141 nat_d_th_7 sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              thus "x2 -XCMPLX-0K6 y2 =XBOOLE-0R4 0NUMBERSK6"
                using A138 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "x =HIDDENR1 y"
          using A99 A101 A104 A100 A112 A109 A122 sorry
      qed "sorry"
      thus "f be one-to-oneFUNCT-1V2"
        using funct_1_def_4 sorry
    qed
    then have "f be bijectiveFUNCT-2V3\<^bsub>([:ZFMISC-1K2 A,B :],C)\<^esub>"
      using A58 sorry
    then have "cardCARD-1K4 ([:ZFMISC-1K2 A,B :]) =XBOOLE-0R4 cardCARD-1K4 C"
      using euler_1_th_11 sorry
    thus "EulerEULER-1K1 (m *XCMPLX-0K3 n) =XBOOLE-0R4 EulerEULER-1K1 m *NAT-1K2 EulerEULER-1K1 n"
      using A24 card_2_th_46 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
