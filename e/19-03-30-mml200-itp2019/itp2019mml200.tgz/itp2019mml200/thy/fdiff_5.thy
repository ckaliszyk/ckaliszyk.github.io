theory fdiff_5
  imports taylor_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x, a, b for "RealXREAL-0M1"
reserve n for "ElementSUBSET-1M1-of NATNUMBERSK1"
reserve Z for "openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
reserve f, f1, f2, g for "PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
mlemma fdiff_5_lm_1:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 a)) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 x)"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & (( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 a) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 x))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 a"
      and A3: "f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M"
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f2 is-differentiable-inFDIFF-1R1 x"
      using A3 taylor_1_th_2 sorry
    have A5: "Z c=TARSKIR1 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
      using A1 valued_1_def_1 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 f1"
      using xboole_1_th_18 sorry
    have A7: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 (0NUMBERSK6)*XCMPLX-0K3 x +XCMPLX-0K2 a"
      using A2 sorry
    then have A8: "f1 is-differentiable-onFDIFF-1R2 Z"
      using A6 fdiff_1_th_23 sorry
    have "Z c=TARSKIR1 domRELAT-1K1 f2"
      using A5 xboole_1_th_18 sorry
    then have A9: "f2 is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_9 sorry
    have A10: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f2 `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 x #ZPREPOWERK3 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A11: "x inHIDDENR3 Z"
      have "diffFDIFF-1K1(f2,x) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 x #ZPREPOWERK3 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)"
        using A3 taylor_1_th_2 sorry
      thus "(f2 `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 x #ZPREPOWERK3 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)"
        using A9 A11 fdiff_1_def_7 sorry
    qed "sorry"
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 x"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A12: "x inHIDDENR3 Z"
        then have "((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 diffFDIFF-1K1(f1,x) +XCMPLX-0K2 diffFDIFF-1K1(f2,x)"
          using A1 A8 A9 fdiff_1_th_18 sorry
        then have "((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (f1 `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 diffFDIFF-1K1(f2,x)"
          using A8 A12 fdiff_1_def_7 sorry
        also have "... = (f1 `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 (f2 `|FDIFF-1K2 Z).FUNCT-1K1 x"
          using A9 A12 fdiff_1_def_7 sorry
        also have "... = 0NUMBERSK6 +XCMPLX-0K2 (f2 `|FDIFF-1K2 Z).FUNCT-1K1 x"
          using A6 A7 A12 fdiff_1_th_23 sorry
        also have "... = \<two>\<^sub>M *XCMPLX-0K3 x #ZPREPOWERK3 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)"
          using A10 A12 sorry
        also have "... = \<two>\<^sub>M *XCMPLX-0K3 x  |^NEWTONK1 \<one>\<^sub>M"
          using prepower_th_36 sorry
        also have "... = \<two>\<^sub>M *XCMPLX-0K3 x"
           sorry
        finally show "((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 x"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 x))"
      using A1 A8 A9 fdiff_1_th_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma fdiff_5_lm_2:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 a)) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M implies f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 x)"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & (( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 a) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M) implies f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 x))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 a"
      and A3: "f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M"
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f2 is-differentiable-inFDIFF-1R1 x"
      using A3 taylor_1_th_2 sorry
    have A5: "Z c=TARSKIR1 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
      using A1 valued_1_th_12 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 f1"
      using xboole_1_th_18 sorry
    have A7: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 (0NUMBERSK6)*XCMPLX-0K3 x +XCMPLX-0K2 a"
      using A2 sorry
    then have A8: "f1 is-differentiable-onFDIFF-1R2 Z"
      using A6 fdiff_1_th_23 sorry
    have "Z c=TARSKIR1 domRELAT-1K1 f2"
      using A5 xboole_1_th_18 sorry
    then have A9: "f2 is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_9 sorry
    have A10: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f2 `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 x #ZPREPOWERK3 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A11: "x inHIDDENR3 Z"
      have "diffFDIFF-1K1(f2,x) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 x #ZPREPOWERK3 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)"
        using A3 taylor_1_th_2 sorry
      thus "(f2 `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 x #ZPREPOWERK3 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)"
        using A9 A11 fdiff_1_def_7 sorry
    qed "sorry"
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A12: "x inHIDDENR3 Z"
      then have "((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 diffFDIFF-1K1(f1,x) -XCMPLX-0K6 diffFDIFF-1K1(f2,x)"
        using A1 A8 A9 fdiff_1_th_19 sorry
      then have "((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (f1 `|FDIFF-1K2 Z).FUNCT-1K1 x -XCMPLX-0K6 diffFDIFF-1K1(f2,x)"
        using A8 A12 fdiff_1_def_7 sorry
      also have "... = (f1 `|FDIFF-1K2 Z).FUNCT-1K1 x -XCMPLX-0K6 (f2 `|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A9 A12 fdiff_1_def_7 sorry
      also have "... = 0NUMBERSK6 -XCMPLX-0K6 (f2 `|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A6 A7 A12 fdiff_1_th_23 sorry
      also have "... = 0NUMBERSK6 -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 x #ZPREPOWERK3 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)"
        using A10 A12 sorry
      also have "... = 0NUMBERSK6 -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 x  |^NEWTONK1 \<one>\<^sub>M"
        using prepower_th_36 sorry
      also have "... = -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 x  |^NEWTONK1 \<one>\<^sub>M"
         sorry
      also have "... = -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 x"
         sorry
      finally show "((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 x"
         sorry
    qed "sorry"
    thus "f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 x))"
      using A1 A8 A9 fdiff_1_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma fdiff_5_lm_3:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)) implies #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 x #RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)) implies #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 x #RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
    have A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "x inHIDDENR3 domRELAT-1K1 (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
        using A1 sorry
      then have "x inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
        using taylor_1_def_4 sorry
      then have "x >XXREAL-0R4 0NUMBERSK6"
        using xxreal_1_th_4 sorry
      thus "#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_21 sorry
    qed "sorry"
    then have A3: "#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 x #RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A4: "x inHIDDENR3 Z"
      then have "x inHIDDENR3 domRELAT-1K1 (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
        using A1 sorry
      then have "x inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
        using taylor_1_def_4 sorry
      then have "x >XXREAL-0R4 0NUMBERSK6"
        using xxreal_1_th_4 sorry
      then have "diffFDIFF-1K1(#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M),x) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 x #RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)"
        using taylor_1_th_21 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 x #RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      finally have "diffFDIFF-1K1(#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M),x) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 x #RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      thus "(#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 x #RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
        using A3 A4 fdiff_1_def_7 sorry
    qed "sorry"
    thus "#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 x #RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
      using A1 A2 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_5_th_1:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f2 .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 x) & f2 .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6) implies f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (a -XCMPLX-0K6 x)^2SQUARE-1K1)"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f2 .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 x) & f2 .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6) implies f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (a -XCMPLX-0K6 x)^2SQUARE-1K1))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f2 .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 x) & f2 .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
    have A3: "Z c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      using A1 rfunct_1_def_1 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 f1"
      using xboole_1_th_18 sorry
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 a"
      using A2 sorry
    then have A6: "f1 is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_23 sorry
    have A7: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f2 .FUNCT-1K1 x =XBOOLE-0R4 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 a"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f2 .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 x"
        using A2 sorry
      thus "f2 .FUNCT-1K1 x =XBOOLE-0R4 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 a"
         sorry
    qed "sorry"
    have A8: "Z c=TARSKIR1 domRELAT-1K1 f2"
      using A3 xboole_1_th_1 sorry
    then have A9: "f2 is-differentiable-onFDIFF-1R2 Z"
      using A7 fdiff_1_th_23 sorry
    have A10: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f2 .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
      using A2 sorry
    then have A11: "f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z"
      using A6 A9 fdiff_2_th_21 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (a -XCMPLX-0K6 x)^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A12: "x inHIDDENR3 Z"
      then have A13: "f2 .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A2 sorry
      have A14: "f1 .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f2 .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 x"
        using A2 A12 sorry
      have "f1 is-differentiable-inFDIFF-1R1 x & f2 is-differentiable-inFDIFF-1R1 x"
        using A6 A9 A12 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x) =HIDDENR1 ((diffFDIFF-1K1(f1,x))*XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(f2,x))*XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A13 fdiff_2_th_14 sorry
      also have "... = ((f1 `|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(f2,x))*XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A6 A12 fdiff_1_def_7 sorry
      also have "... = ((f1 `|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 (f2 `|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A9 A12 fdiff_1_def_7 sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 (f2 `|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A4 A5 A12 fdiff_1_th_23 sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A8 A7 A12 fdiff_1_th_23 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (a -XCMPLX-0K6 x)^2SQUARE-1K1"
        using A14 sorry
      finally have "diffFDIFF-1K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x) =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (a -XCMPLX-0K6 x)^2SQUARE-1K1"
         sorry
      thus "((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (a -XCMPLX-0K6 x)^2SQUARE-1K1"
        using A11 A12 fdiff_1_def_7 sorry
    qed "sorry"
    thus "f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (a -XCMPLX-0K6 x)^2SQUARE-1K1))"
      using A6 A9 A10 fdiff_2_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_5_th_2:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 a & f2 .FUNCT-1K1 x =XBOOLE-0R4 x +XCMPLX-0K2 a) & f2 .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6) implies f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x +XCMPLX-0K2 a)^2SQUARE-1K1)"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 a & f2 .FUNCT-1K1 x =XBOOLE-0R4 x +XCMPLX-0K2 a) & f2 .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6) implies f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x +XCMPLX-0K2 a)^2SQUARE-1K1))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 a & f2 .FUNCT-1K1 x =XBOOLE-0R4 x +XCMPLX-0K2 a) & f2 .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f2 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 a"
      using A2 sorry
    have A4: "Z c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      using A1 rfunct_1_def_1 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 f1"
      using xboole_1_th_18 sorry
    have A6: "Z c=TARSKIR1 domRELAT-1K1 f2"
      using A4 xboole_1_th_1 sorry
    then have A7: "f2 is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_23 sorry
    have A8: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 a)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A9: "\<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 a) =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x -XCMPLX-0K6 a"
         sorry
      assume "x inHIDDENR3 Z"
      thus "f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 a)"
        using A2 A9 sorry
    qed "sorry"
    then have A10: "f1 is-differentiable-onFDIFF-1R2 Z"
      using A5 fdiff_1_th_23 sorry
    have A11: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f2 .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
      using A2 sorry
    then have A12: "f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z"
      using A10 A7 fdiff_2_th_21 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x +XCMPLX-0K2 a)^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A13: "x inHIDDENR3 Z"
      then have A14: "f2 .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A2 sorry
      have A15: "f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 a & f2 .FUNCT-1K1 x =XBOOLE-0R4 x +XCMPLX-0K2 a"
        using A2 A13 sorry
      have "f1 is-differentiable-inFDIFF-1R1 x & f2 is-differentiable-inFDIFF-1R1 x"
        using A10 A7 A13 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x) =HIDDENR1 ((diffFDIFF-1K1(f1,x))*XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(f2,x))*XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A14 fdiff_2_th_14 sorry
      also have "... = ((f1 `|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(f2,x))*XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A10 A13 fdiff_1_def_7 sorry
      also have "... = ((f1 `|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 (f2 `|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A7 A13 fdiff_1_def_7 sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 (f2 `|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A5 A8 A13 fdiff_1_th_23 sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A6 A3 A13 fdiff_1_th_23 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x +XCMPLX-0K2 a)^2SQUARE-1K1"
        using A15 sorry
      finally have "diffFDIFF-1K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x) =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x +XCMPLX-0K2 a)^2SQUARE-1K1"
         sorry
      thus "((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x +XCMPLX-0K2 a)^2SQUARE-1K1"
        using A12 A13 fdiff_1_def_7 sorry
    qed "sorry"
    thus "f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x +XCMPLX-0K2 a)^2SQUARE-1K1))"
      using A10 A7 A11 fdiff_2_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_5_th_3:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 a & f2 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 b) & f2 .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6) implies f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (a -XCMPLX-0K6 b)/XCMPLX-0K7 (x -XCMPLX-0K6 b)^2SQUARE-1K1)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 a & f2 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 b) & f2 .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6) implies f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (a -XCMPLX-0K6 b)/XCMPLX-0K7 (x -XCMPLX-0K6 b)^2SQUARE-1K1))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 a & f2 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 b) & f2 .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 a) & f2 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 b)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A4: "\<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 a) =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x -XCMPLX-0K6 a & \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 b) =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x -XCMPLX-0K6 b"
         sorry
      assume "x inHIDDENR3 Z"
      thus "f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 a) & f2 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 b)"
        using A2 A4 sorry
    qed "sorry"
    then have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 a)"
       sorry
    have A6: "Z c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      using A1 rfunct_1_def_1 sorry
    then have A7: "Z c=TARSKIR1 domRELAT-1K1 f1"
      using xboole_1_th_18 sorry
    then have A8: "f1 is-differentiable-onFDIFF-1R2 Z"
      using A5 fdiff_1_th_23 sorry
    have A9: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f2 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 b)"
      using A3 sorry
    have A10: "Z c=TARSKIR1 domRELAT-1K1 f2"
      using A6 xboole_1_th_1 sorry
    then have A11: "f2 is-differentiable-onFDIFF-1R2 Z"
      using A9 fdiff_1_th_23 sorry
    have A12: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f2 .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
      using A2 sorry
    then have A13: "f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z"
      using A8 A11 fdiff_2_th_21 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (a -XCMPLX-0K6 b)/XCMPLX-0K7 (x -XCMPLX-0K6 b)^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A14: "x inHIDDENR3 Z"
      then have A15: "f2 .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A2 sorry
      have A16: "f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 a & f2 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 b"
        using A2 A14 sorry
      have "f1 is-differentiable-inFDIFF-1R1 x & f2 is-differentiable-inFDIFF-1R1 x"
        using A8 A11 A14 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x) =HIDDENR1 ((diffFDIFF-1K1(f1,x))*XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(f2,x))*XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A15 fdiff_2_th_14 sorry
      also have "... = ((f1 `|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(f2,x))*XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A8 A14 fdiff_1_def_7 sorry
      also have "... = ((f1 `|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 (f2 `|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A11 A14 fdiff_1_def_7 sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 (f2 `|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A7 A5 A14 fdiff_1_th_23 sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A10 A9 A14 fdiff_1_th_23 sorry
      also have "... = (a -XCMPLX-0K6 b)/XCMPLX-0K7 (x -XCMPLX-0K6 b)^2SQUARE-1K1"
        using A16 sorry
      finally have "diffFDIFF-1K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x) =HIDDENR1 (a -XCMPLX-0K6 b)/XCMPLX-0K7 (x -XCMPLX-0K6 b)^2SQUARE-1K1"
         sorry
      thus "((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (a -XCMPLX-0K6 b)/XCMPLX-0K7 (x -XCMPLX-0K6 b)^2SQUARE-1K1"
        using A13 A14 fdiff_1_def_7 sorry
    qed "sorry"
    thus "f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (a -XCMPLX-0K6 b)/XCMPLX-0K7 (x -XCMPLX-0K6 b)^2SQUARE-1K1))"
      using A8 A11 A12 fdiff_2_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_5_th_4:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  not 0NUMBERSK6 inTARSKIR2 Z implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  not 0NUMBERSK6 inTARSKIR2 Z implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    let ?f = "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z"
    have A1: "Z c=TARSKIR1 domRELAT-1K1 ?f & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ?f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6)"
      using funct_1_th_17 sorry
    then have A2: "?f is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_23 sorry
    assume A3: " not 0NUMBERSK6 inTARSKIR2 Z"
    then have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ?f .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
      using funct_1_th_18 sorry
    then have A5: "?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z"
      using A2 fdiff_2_th_22 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A6: "x inHIDDENR3 Z"
      then have A7: "?f .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6 & ?f is-differentiable-inFDIFF-1R1 x"
        using A3 A2 fdiff_1_th_9 funct_1_th_18 sorry
      have "((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x)"
        using A5 A6 fdiff_1_def_7 sorry
      also have "... = -XCMPLX-0K4 (diffFDIFF-1K1(?f,x))/XCMPLX-0K7 (?f .FUNCT-1K1 x)^2SQUARE-1K1"
        using A7 fdiff_2_th_15 sorry
      also have "... = -XCMPLX-0K4 (?f `|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 (?f .FUNCT-1K1 x)^2SQUARE-1K1"
        using A2 A6 fdiff_1_def_7 sorry
      also have "... = -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (?f .FUNCT-1K1 x)^2SQUARE-1K1"
        using A1 A6 fdiff_1_th_23 sorry
      also have "... = -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1"
        using A6 funct_1_th_18 sorry
      finally have "((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1"
         sorry
      thus "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1"
         sorry
    qed "sorry"
    thus "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1))"
      using A2 A4 fdiff_2_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma fdiff_5_lm_4:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  not 0NUMBERSK6 inTARSKIR2 Z implies domRELAT-1K1 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) =XBOOLE-0R4 Z"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  not 0NUMBERSK6 inTARSKIR2 Z implies domRELAT-1K1 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) =XBOOLE-0R4 Z"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    have A1: "rngFUNCT-1K2 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) c=TARSKIR1 REALNUMBERSK2"
      using relat_1_def_19 sorry
    assume A2: " not 0NUMBERSK6 inTARSKIR2 Z"
    have "(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 {}XBOOLE-0K1"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } implies x inHIDDENR3 {}XBOOLE-0K1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A3: "x inHIDDENR3 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
        then have "x inHIDDENR3 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)"
          using funct_1_def_7 sorry
        then have A4: "x inHIDDENR3 Z"
          using funct_1_th_17 sorry
        have "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
          using A3 funct_1_def_7 sorry
        then have "x inHIDDENR3 {TARSKIK1 0NUMBERSK6 }"
          using A4 funct_1_th_18 sorry
        thus "x inHIDDENR3 {}XBOOLE-0K1"
          using A2 A4 tarski_def_1 sorry
      qed "sorry"
      thus "(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 {}XBOOLE-0K1"
        using tarski_def_3 sorry
    qed
    then have A5: "(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1"
      using xboole_1_th_3 sorry
    have "domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =HIDDENR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z) \\SUBSET-1K6 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      using rfunct_1_def_2 sorry
    also have "... = Z"
      using A5 funct_1_th_17 sorry
    finally have "domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =HIDDENR1 Z"
       sorry
    thus "domRELAT-1K1 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) =XBOOLE-0R4 Z"
      using A1 relat_1_th_27 sin_cos_th_24 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_5_th_5:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  not 0NUMBERSK6 inTARSKIR2 Z implies (sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  not 0NUMBERSK6 inTARSKIR2 Z implies (sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    let ?f = "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z"
    assume A1: " not 0NUMBERSK6 inTARSKIR2 Z"
    then have A2: "Z c=TARSKIR1 domRELAT-1K1 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
      using fdiff_5_lm_4 sorry
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using funct_1_th_11 sorry
    then have A3: "Z c=TARSKIR1 domRELAT-1K1 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
       sorry
    have A4: "?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_5_th_4 sorry
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-inFDIFF-1R1 x"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-inFDIFF-1R1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume "x inHIDDENR3 Z"
        then have A6: "?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 x"
          using A4 fdiff_1_th_9 sorry
        have "sinSIN-COSK17 is-differentiable-inFDIFF-1R1 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x"
          using sin_cos_th_64 sorry
        thus "(sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-inFDIFF-1R1 x"
          using A6 fdiff_2_th_13 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have A7: "(sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-onFDIFF-1R2 Z"
      using A2 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        have A8: "sinSIN-COSK17 is-differentiable-inFDIFF-1R1 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x"
          using sin_cos_th_64 sorry
        assume A9: "x inHIDDENR3 Z"
        then have "?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 x"
          using A4 fdiff_1_th_9 sorry
        then have "diffFDIFF-1K1((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x) =HIDDENR1 (diffFDIFF-1K1(sinSIN-COSK17,(?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x))"
          using A8 fdiff_2_th_13 sorry
        also have "... = (cosSIN-COSK19).FUNCT-1K1 ((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x) *XCMPLX-0K3 (diffFDIFF-1K1(?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x))"
          using sin_cos_th_64 sorry
        also have "... = (cosSIN-COSK19).FUNCT-1K1 (?f .FUNCT-1K1 x)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (diffFDIFF-1K1(?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x))"
          using A3 A9 rfunct_1_def_2 sorry
        also have "... = (cosSIN-COSK19).FUNCT-1K1 (?f .FUNCT-1K1 x)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 ((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x"
          using A4 A9 fdiff_1_def_7 sorry
        also have "... = (cosSIN-COSK19).FUNCT-1K1 (?f .FUNCT-1K1 x)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)"
          using A1 A9 fdiff_5_th_4 sorry
        also have "... = (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M *XCMPLX-0K3 x \<inverse>XCMPLX-0K5) *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)"
          using A9 funct_1_th_18 sorry
        also have "... = (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)"
          using xcmplx_0_def_9 sorry
        finally have "diffFDIFF-1K1((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)"
           sorry
        thus "(((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
          using A7 A9 fdiff_1_def_7 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "(sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)))"
      using A2 A5 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_5_th_6:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  not 0NUMBERSK6 inTARSKIR2 Z & Z c=TARSKIR1 domRELAT-1K1 ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) implies (cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  not 0NUMBERSK6 inTARSKIR2 Z & Z c=TARSKIR1 domRELAT-1K1 ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) implies (cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)))"
  proof(rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    let ?f = "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z"
    assume A1: " not 0NUMBERSK6 inTARSKIR2 Z"
      and A2: "Z c=TARSKIR1 domRELAT-1K1 ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using A2 funct_1_th_11 sorry
    then have A3: "Z c=TARSKIR1 domRELAT-1K1 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
       sorry
    have A4: "?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_5_th_4 sorry
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-inFDIFF-1R1 x"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-inFDIFF-1R1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume "x inHIDDENR3 Z"
        then have A6: "?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 x"
          using A4 fdiff_1_th_9 sorry
        have "cosSIN-COSK19 is-differentiable-inFDIFF-1R1 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x"
          using sin_cos_th_63 sorry
        thus "(cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-inFDIFF-1R1 x"
          using A6 fdiff_2_th_13 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have A7: "(cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-onFDIFF-1R2 Z"
      using A2 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        have A8: "diffFDIFF-1K1(cosSIN-COSK19,(?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x) =HIDDENR1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 ((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x)"
          using sin_cos_th_63 sorry
        have A9: "cosSIN-COSK19 is-differentiable-inFDIFF-1R1 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x"
          using sin_cos_th_63 sorry
        assume A10: "x inHIDDENR3 Z"
        then have "?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 x"
          using A4 fdiff_1_th_9 sorry
        then have "diffFDIFF-1K1((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x) =HIDDENR1 (diffFDIFF-1K1(cosSIN-COSK19,(?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x))"
          using A9 fdiff_2_th_13 sorry
        also have "... = -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 ((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x) *XCMPLX-0K3 (diffFDIFF-1K1(?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x))"
          using A8 sorry
        also have "... = -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (?f .FUNCT-1K1 x)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (diffFDIFF-1K1(?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x))"
          using A3 A10 rfunct_1_def_2 sorry
        also have "... = -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (?f .FUNCT-1K1 x)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 ((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x"
          using A4 A10 fdiff_1_def_7 sorry
        also have "... = -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (?f .FUNCT-1K1 x)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)"
          using A1 A10 fdiff_5_th_4 sorry
        also have "... = -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M *XCMPLX-0K3 x \<inverse>XCMPLX-0K5) *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)"
          using A10 funct_1_th_18 sorry
        also have "... = -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)"
          using xcmplx_0_def_9 sorry
        also have "... = (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)"
           sorry
        finally have "diffFDIFF-1K1((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x) =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)"
           sorry
        thus "(((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
          using A7 A10 fdiff_1_def_7 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "(cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)))"
      using A2 A5 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_5_th_7:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))) &  not 0NUMBERSK6 inTARSKIR2 Z implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))) &  not 0NUMBERSK6 inTARSKIR2 Z implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)))"
  proof(rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    let ?f = "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))"
      and A2: " not 0NUMBERSK6 inTARSKIR2 Z"
    have A3: "(sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-onFDIFF-1R2 Z"
      using A2 fdiff_5_th_5 sorry
    have A4: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z) /\\XBOOLE-0K3 domRELAT-1K1 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
      using A1 valued_1_def_4 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)"
      using xboole_1_th_18 sorry
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
      using funct_1_th_18 sorry
    then have A7: "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z"
      using A5 fdiff_1_th_23 sorry
    have A8: "Z c=TARSKIR1 domRELAT-1K1 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
      using A4 xboole_1_th_18 sorry
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using funct_1_th_11 sorry
    then have A9: "Z c=TARSKIR1 domRELAT-1K1 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
       sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A10: "x inHIDDENR3 Z"
      then have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z,x)) +XCMPLX-0K2 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x))"
        using A1 A3 A7 fdiff_1_th_21 sorry
      also have "... = ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x))"
        using A7 A10 fdiff_1_def_7 sorry
      also have "... = ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x))"
        using A5 A6 A10 fdiff_1_th_23 sorry
      also have "... = ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x +XCMPLX-0K2 x *XCMPLX-0K3 (diffFDIFF-1K1((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x))"
        using A10 funct_1_th_18 sorry
      also have "... = ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x +XCMPLX-0K2 x *XCMPLX-0K3 (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A3 A10 fdiff_1_def_7 sorry
      also have "... = ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x +XCMPLX-0K2 x *XCMPLX-0K3 (-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))"
        using A2 A10 fdiff_5_th_5 sorry
      also have "... = ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x -XCMPLX-0K6 (x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (x *XCMPLX-0K3 x)))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
         sorry
      also have "... = ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x -XCMPLX-0K6 (x *XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x)))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
        using xcmplx_1_th_102 sorry
      also have "... = ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x -XCMPLX-0K6 ((x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
         sorry
      also have "... = ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x -XCMPLX-0K6 (\<one>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
        using A2 A10 xcmplx_1_th_106 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 ((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x) -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
        using A8 A10 funct_1_th_12 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 (?f .FUNCT-1K1 x)\<inverse>XCMPLX-0K5 -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
        using A9 A10 rfunct_1_def_2 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M *XCMPLX-0K3 x \<inverse>XCMPLX-0K5) -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
        using A10 funct_1_th_18 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
        using xcmplx_0_def_9 sorry
      finally have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
         sorry
      thus "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
         sorry
    qed "sorry"
    thus "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)))"
      using A1 A3 A7 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_5_th_8:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))) &  not 0NUMBERSK6 inTARSKIR2 Z implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))) &  not 0NUMBERSK6 inTARSKIR2 Z implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)))"
  proof(rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    let ?f = "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))"
      and A2: " not 0NUMBERSK6 inTARSKIR2 Z"
    have A3: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z) /\\XBOOLE-0K3 domRELAT-1K1 ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
      using A1 valued_1_def_4 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
      using xboole_1_th_18 sorry
    then have A5: "(cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-onFDIFF-1R2 Z"
      using A2 fdiff_5_th_6 sorry
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
      using funct_1_th_18 sorry
    have A7: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)"
      using A3 xboole_1_th_18 sorry
    then have A8: "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z"
      using A6 fdiff_1_th_23 sorry
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using A4 funct_1_th_11 sorry
    then have A9: "Z c=TARSKIR1 domRELAT-1K1 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
       sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A10: "x inHIDDENR3 Z"
      then have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z,x)) +XCMPLX-0K2 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x))"
        using A1 A5 A8 fdiff_1_th_21 sorry
      also have "... = ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x))"
        using A8 A10 fdiff_1_def_7 sorry
      also have "... = ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x))"
        using A7 A6 A10 fdiff_1_th_23 sorry
      also have "... = ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x +XCMPLX-0K2 x *XCMPLX-0K3 (diffFDIFF-1K1((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x))"
        using A10 funct_1_th_18 sorry
      also have "... = ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x +XCMPLX-0K2 x *XCMPLX-0K3 (((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A5 A10 fdiff_1_def_7 sorry
      also have "... = ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x +XCMPLX-0K2 x *XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))"
        using A2 A4 A10 fdiff_5_th_6 sorry
      also have "... = ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x +XCMPLX-0K2 (x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (x *XCMPLX-0K3 x)))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
         sorry
      also have "... = ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x +XCMPLX-0K2 (x *XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x)))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
        using xcmplx_1_th_102 sorry
      also have "... = ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x +XCMPLX-0K2 ((x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
         sorry
      also have "... = ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
        using A2 A10 xcmplx_1_th_106 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 ((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
        using A4 A10 funct_1_th_12 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 (?f .FUNCT-1K1 x)\<inverse>XCMPLX-0K5 +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
        using A9 A10 rfunct_1_def_2 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M *XCMPLX-0K3 x \<inverse>XCMPLX-0K5) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
        using A10 funct_1_th_18 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
        using xcmplx_0_def_9 sorry
      finally have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
         sorry
      thus "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
         sorry
    qed "sorry"
    thus "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)))"
      using A1 A5 A8 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_5_th_9:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))) &  not 0NUMBERSK6 inTARSKIR2 Z implies ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (((sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))^2SQUARE-1K1 -XCMPLX-0K6 ((cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))^2SQUARE-1K1))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))) &  not 0NUMBERSK6 inTARSKIR2 Z implies ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (((sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))^2SQUARE-1K1 -XCMPLX-0K6 ((cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))^2SQUARE-1K1)))"
  proof(rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    let ?f = "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))"
      and A2: " not 0NUMBERSK6 inTARSKIR2 Z"
    have A3: "(sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-onFDIFF-1R2 Z"
      using A2 fdiff_5_th_5 sorry
    have A4: "Z c=TARSKIR1 domRELAT-1K1 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) /\\XBOOLE-0K3 domRELAT-1K1 ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
      using A1 valued_1_def_4 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
      using xboole_1_th_18 sorry
    then have A6: "(cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-onFDIFF-1R2 Z"
      using A2 fdiff_5_th_6 sorry
    have A7: "Z c=TARSKIR1 domRELAT-1K1 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
      using A4 xboole_1_th_18 sorry
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using funct_1_th_11 sorry
    then have A8: "Z c=TARSKIR1 domRELAT-1K1 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
       sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (((sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))^2SQUARE-1K1 -XCMPLX-0K6 ((cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))^2SQUARE-1K1)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A9: "x inHIDDENR3 Z"
      then have "((((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x)) +XCMPLX-0K2 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x))"
        using A1 A6 A3 fdiff_1_th_21 sorry
      also have "... = ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x))"
        using A3 A9 fdiff_1_def_7 sorry
      also have "... = ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)) +XCMPLX-0K2 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x))"
        using A2 A9 fdiff_5_th_5 sorry
      also have "... = ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)) +XCMPLX-0K2 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A6 A9 fdiff_1_def_7 sorry
      also have "... = ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)) +XCMPLX-0K2 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))"
        using A2 A5 A9 fdiff_5_th_6 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 ((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x) *XCMPLX-0K3 (-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)) +XCMPLX-0K2 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))"
        using A5 A9 funct_1_th_12 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 (?f .FUNCT-1K1 x)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)) +XCMPLX-0K2 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))"
        using A8 A9 rfunct_1_def_2 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M *XCMPLX-0K3 x \<inverse>XCMPLX-0K5) *XCMPLX-0K3 (-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)) +XCMPLX-0K2 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))"
        using A9 funct_1_th_18 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) *XCMPLX-0K3 (-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)) +XCMPLX-0K2 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))"
        using xcmplx_0_def_9 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) *XCMPLX-0K3 (-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 ((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x) *XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))"
        using A7 A9 funct_1_th_12 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) *XCMPLX-0K3 (-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (?f .FUNCT-1K1 x)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))"
        using A8 A9 rfunct_1_def_2 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) *XCMPLX-0K3 (-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M *XCMPLX-0K3 x \<inverse>XCMPLX-0K5) *XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))"
        using A9 funct_1_th_18 sorry
      also have "... = (-XCMPLX-0K4 ((cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))+XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) *XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))"
        using xcmplx_0_def_9 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (((sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))^2SQUARE-1K1 -XCMPLX-0K6 ((cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))^2SQUARE-1K1)"
         sorry
      finally have "((((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (((sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))^2SQUARE-1K1 -XCMPLX-0K6 ((cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))^2SQUARE-1K1)"
         sorry
      thus "((((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (((sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))^2SQUARE-1K1 -XCMPLX-0K6 ((cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))^2SQUARE-1K1)"
         sorry
    qed "sorry"
    thus "((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (((sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))^2SQUARE-1K1 -XCMPLX-0K6 ((cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))^2SQUARE-1K1)))"
      using A1 A6 A3 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_5_th_10:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))) & n >=XXREAL-0R2 \<one>\<^sub>M) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 n *XCMPLX-0K3 x) implies ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 ((n +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x))"
proof-
  have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))) & (n >=XXREAL-0R2 \<one>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 n *XCMPLX-0K3 x)) implies ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 ((n +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))"
      and A2: "n >=XXREAL-0R2 \<one>\<^sub>M"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 n *XCMPLX-0K3 x"
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 n *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
      using A3 sorry
    have A5: "Z c=TARSKIR1 domRELAT-1K1 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) /\\XBOOLE-0K3 domRELAT-1K1 (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))"
      using A1 valued_1_def_4 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using xboole_1_th_18 sorry
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 f"
      using funct_1_th_11 sorry
    then have A7: "Z c=TARSKIR1 domRELAT-1K1 f"
       sorry
    then have A8: "f is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_23 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have A9: "f is-differentiable-inFDIFF-1R1 x"
        using A8 fdiff_1_th_9 sorry
      have "sinSIN-COSK17 is-differentiable-inFDIFF-1R1 f .FUNCT-1K1 x"
        using sin_cos_th_64 sorry
      thus "(sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using A9 fdiff_2_th_13 sorry
    qed "sorry"
    then have A10: "(sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A6 fdiff_1_th_9 sorry
    have A11: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 n *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A12: "sinSIN-COSK17 is-differentiable-inFDIFF-1R1 f .FUNCT-1K1 x"
        using sin_cos_th_64 sorry
      assume A13: "x inHIDDENR3 Z"
      then have "f is-differentiable-inFDIFF-1R1 x"
        using A8 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 (diffFDIFF-1K1(sinSIN-COSK17,f .FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using A12 fdiff_2_th_13 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 (f .FUNCT-1K1 x) *XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using sin_cos_th_64 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x) *XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using A3 A13 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x) *XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A8 A13 fdiff_1_def_7 sorry
      also have "... = n *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x)"
        using A7 A4 A13 fdiff_1_th_23 sorry
      finally have "diffFDIFF-1K1((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 n *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x)"
         sorry
      thus "(((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 n *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x)"
        using A10 A13 fdiff_1_def_7 sorry
    qed "sorry"
    have A14: "Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))"
      using A5 xboole_1_th_18 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      have "sinSIN-COSK17 is-differentiable-inFDIFF-1R1 x"
        using sin_cos_th_64 sorry
      thus "#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_3 sorry
    qed "sorry"
    then have A15: "#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-onFDIFF-1R2 Z"
      using A14 fdiff_1_th_9 sorry
    have A16: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have "sinSIN-COSK17 is-differentiable-inFDIFF-1R1 x"
        using sin_cos_th_64 sorry
      then have A17: "diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),x) =HIDDENR1 (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(sinSIN-COSK17,x))"
        using taylor_1_th_3 sorry
      also have "... = (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
        using sin_cos_th_64 sorry
      finally have "diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),x) =HIDDENR1 (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
         sorry
      assume "x inHIDDENR3 Z"
      thus "((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
        using A15 A17 fdiff_1_def_7 sorry
    qed "sorry"
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 ((n +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A18: "n -XCMPLX-0K6 \<one>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1"
        using A2 nat_1_th_21 sorry
      assume A19: "x inHIDDENR3 Z"
      then have "((((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)) +XCMPLX-0K2 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),x))"
        using A1 A10 A15 fdiff_1_th_21 sorry
      also have "... = #ZTAYLOR-1K1 n .FUNCT-1K1 ((sinSIN-COSK17).FUNCT-1K1 x) *XCMPLX-0K3 (diffFDIFF-1K1((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)) +XCMPLX-0K2 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),x))"
        using A14 A19 funct_1_th_12 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 n *XCMPLX-0K3 (diffFDIFF-1K1((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)) +XCMPLX-0K2 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),x))"
        using taylor_1_def_1 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 n *XCMPLX-0K3 (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),x))"
        using A10 A19 fdiff_1_def_7 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 n *XCMPLX-0K3 (n *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x)) +XCMPLX-0K2 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),x))"
        using A11 A19 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 n *XCMPLX-0K3 (n *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x)) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (f .FUNCT-1K1 x) *XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),x))"
        using A6 A19 funct_1_th_12 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 n *XCMPLX-0K3 (n *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x)) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x) *XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),x))"
        using A3 A19 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 n *XCMPLX-0K3 (n *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x)) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x) *XCMPLX-0K3 ((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A15 A19 fdiff_1_def_7 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 n *XCMPLX-0K3 (n *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x)) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x) *XCMPLX-0K3 ((n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)"
        using A16 A19 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 ((n -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M) *XCMPLX-0K3 (n *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x)) +XCMPLX-0K2 (((sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x) *XCMPLX-0K3 n)*XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
         sorry
      also have "... = (((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M) *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 \<one>\<^sub>M)*XCMPLX-0K3 (n *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x)) +XCMPLX-0K2 (((sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x) *XCMPLX-0K3 n)*XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
        using A18 taylor_1_th_1 sorry
      also have "... = (((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)*XCMPLX-0K3 (n *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x)) +XCMPLX-0K2 (((sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x) *XCMPLX-0K3 n)*XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
        using prepower_th_35 sorry
      also have "... = (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x) +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x))"
         sorry
      also have "... = (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (x +XCMPLX-0K2 n *XCMPLX-0K3 x)"
        using sin_cos_th_74 sorry
      also have "... = (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 ((n +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x)"
         sorry
      finally have "((((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 ((n +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x)"
         sorry
      thus "((((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 ((n +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x)"
         sorry
    qed "sorry"
    thus "((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 ((n +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x)))"
      using A1 A10 A15 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_5_th_11:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 (((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))) & n >=XXREAL-0R2 \<one>\<^sub>M) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 n *XCMPLX-0K3 x) implies ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 ((n +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x))"
proof-
  have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))) & (n >=XXREAL-0R2 \<one>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 n *XCMPLX-0K3 x)) implies ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 ((n +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))"
      and A2: "n >=XXREAL-0R2 \<one>\<^sub>M"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 n *XCMPLX-0K3 x"
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 n *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
      using A3 sorry
    have A5: "Z c=TARSKIR1 domRELAT-1K1 ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) /\\XBOOLE-0K3 domRELAT-1K1 (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))"
      using A1 valued_1_def_4 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using xboole_1_th_18 sorry
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 f"
      using funct_1_th_11 sorry
    then have A7: "Z c=TARSKIR1 domRELAT-1K1 f"
       sorry
    then have A8: "f is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_23 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have A9: "f is-differentiable-inFDIFF-1R1 x"
        using A8 fdiff_1_th_9 sorry
      have "cosSIN-COSK19 is-differentiable-inFDIFF-1R1 f .FUNCT-1K1 x"
        using sin_cos_th_63 sorry
      thus "(cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using A9 fdiff_2_th_13 sorry
    qed "sorry"
    then have A10: "(cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A6 fdiff_1_th_9 sorry
    have A11: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 n *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A12: "cosSIN-COSK19 is-differentiable-inFDIFF-1R1 f .FUNCT-1K1 x"
        using sin_cos_th_63 sorry
      assume A13: "x inHIDDENR3 Z"
      then have "f is-differentiable-inFDIFF-1R1 x"
        using A8 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 (diffFDIFF-1K1(cosSIN-COSK19,f .FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using A12 fdiff_2_th_13 sorry
      also have "... = (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (f .FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using sin_cos_th_63 sorry
      also have "... = (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x))*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using A3 A13 sorry
      also have "... = (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x))*XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A8 A13 fdiff_1_def_7 sorry
      also have "... = (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x))*XCMPLX-0K3 n"
        using A7 A4 A13 fdiff_1_th_23 sorry
      also have "... = -XCMPLX-0K4 n *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x)"
         sorry
      finally have "diffFDIFF-1K1((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 -XCMPLX-0K4 n *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x)"
         sorry
      thus "(((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 n *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x)"
        using A10 A13 fdiff_1_def_7 sorry
    qed "sorry"
    have A14: "Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))"
      using A5 xboole_1_th_18 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      have "sinSIN-COSK17 is-differentiable-inFDIFF-1R1 x"
        using sin_cos_th_64 sorry
      thus "#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_3 sorry
    qed "sorry"
    then have A15: "#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-onFDIFF-1R2 Z"
      using A14 fdiff_1_th_9 sorry
    have A16: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have "sinSIN-COSK17 is-differentiable-inFDIFF-1R1 x"
        using sin_cos_th_64 sorry
      then have A17: "diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),x) =HIDDENR1 (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(sinSIN-COSK17,x))"
        using taylor_1_th_3 sorry
      also have "... = (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
        using sin_cos_th_64 sorry
      finally have "diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),x) =HIDDENR1 (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
         sorry
      assume "x inHIDDENR3 Z"
      thus "((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
        using A15 A17 fdiff_1_def_7 sorry
    qed "sorry"
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 ((n +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A18: "n -XCMPLX-0K6 \<one>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1"
        using A2 nat_1_th_21 sorry
      assume A19: "x inHIDDENR3 Z"
      then have "((((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)) +XCMPLX-0K2 ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),x))"
        using A1 A10 A15 fdiff_1_th_21 sorry
      also have "... = #ZTAYLOR-1K1 n .FUNCT-1K1 ((sinSIN-COSK17).FUNCT-1K1 x) *XCMPLX-0K3 (diffFDIFF-1K1((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)) +XCMPLX-0K2 ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),x))"
        using A14 A19 funct_1_th_12 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 n *XCMPLX-0K3 (diffFDIFF-1K1((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)) +XCMPLX-0K2 ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),x))"
        using taylor_1_def_1 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 n *XCMPLX-0K3 (((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),x))"
        using A10 A19 fdiff_1_def_7 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 n *XCMPLX-0K3 (-XCMPLX-0K4 n *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x)) +XCMPLX-0K2 ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),x))"
        using A11 A19 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 n *XCMPLX-0K3 (-XCMPLX-0K4 n *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x)) +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 (f .FUNCT-1K1 x) *XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),x))"
        using A6 A19 funct_1_th_12 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 n *XCMPLX-0K3 (-XCMPLX-0K4 n *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x)) +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x) *XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),x))"
        using A3 A19 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 n *XCMPLX-0K3 (-XCMPLX-0K4 n *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x)) +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x) *XCMPLX-0K3 ((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A15 A19 fdiff_1_def_7 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 n *XCMPLX-0K3 (-XCMPLX-0K4 n *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x)) +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x) *XCMPLX-0K3 ((n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)"
        using A16 A19 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 ((n -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M) *XCMPLX-0K3 (-XCMPLX-0K4 n *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x)) +XCMPLX-0K2 (((cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x) *XCMPLX-0K3 n)*XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
         sorry
      also have "... = (((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M) *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 \<one>\<^sub>M)*XCMPLX-0K3 (-XCMPLX-0K4 n *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x)) +XCMPLX-0K2 (((cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x) *XCMPLX-0K3 n)*XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
        using A18 taylor_1_th_1 sorry
      also have "... = (((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)*XCMPLX-0K3 (-XCMPLX-0K4 n *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x)) +XCMPLX-0K2 (((cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x) *XCMPLX-0K3 n)*XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
        using prepower_th_35 sorry
      also have "... = (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x))"
         sorry
      also have "... = (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (x +XCMPLX-0K2 n *XCMPLX-0K3 x)"
        using sin_cos_th_74 sorry
      also have "... = (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 ((n +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x)"
         sorry
      finally have "((((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 ((n +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x)"
         sorry
      thus "((((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 ((n +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x)"
         sorry
    qed "sorry"
    thus "((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 ((n +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x)))"
      using A1 A10 A15 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_5_th_12:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 (((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))) & n >=XXREAL-0R2 \<one>\<^sub>M) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 n *XCMPLX-0K3 x) implies ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 ((n +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x))"
proof-
  have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))) & (n >=XXREAL-0R2 \<one>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 n *XCMPLX-0K3 x)) implies ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 ((n +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)))"
      and A2: "n >=XXREAL-0R2 \<one>\<^sub>M"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 n *XCMPLX-0K3 x"
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 n *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
      using A3 sorry
    have A5: "Z c=TARSKIR1 domRELAT-1K1 ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) /\\XBOOLE-0K3 domRELAT-1K1 (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))"
      using A1 valued_1_def_4 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using xboole_1_th_18 sorry
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 f"
      using funct_1_th_11 sorry
    then have A7: "Z c=TARSKIR1 domRELAT-1K1 f"
       sorry
    then have A8: "f is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_23 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have A9: "f is-differentiable-inFDIFF-1R1 x"
        using A8 fdiff_1_th_9 sorry
      have "cosSIN-COSK19 is-differentiable-inFDIFF-1R1 f .FUNCT-1K1 x"
        using sin_cos_th_63 sorry
      thus "(cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using A9 fdiff_2_th_13 sorry
    qed "sorry"
    then have A10: "(cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A6 fdiff_1_th_9 sorry
    have A11: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 n *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A12: "cosSIN-COSK19 is-differentiable-inFDIFF-1R1 f .FUNCT-1K1 x"
        using sin_cos_th_63 sorry
      assume A13: "x inHIDDENR3 Z"
      then have "f is-differentiable-inFDIFF-1R1 x"
        using A8 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 (diffFDIFF-1K1(cosSIN-COSK19,f .FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using A12 fdiff_2_th_13 sorry
      also have "... = (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (f .FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using sin_cos_th_63 sorry
      also have "... = -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (f .FUNCT-1K1 x) *XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
         sorry
      also have "... = -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x) *XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using A3 A13 sorry
      also have "... = -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x) *XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A8 A13 fdiff_1_def_7 sorry
      also have "... = -XCMPLX-0K4 n *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x)"
        using A7 A4 A13 fdiff_1_th_23 sorry
      finally have "diffFDIFF-1K1((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 -XCMPLX-0K4 n *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x)"
         sorry
      thus "(((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 n *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x)"
        using A10 A13 fdiff_1_def_7 sorry
    qed "sorry"
    have A14: "Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))"
      using A5 xboole_1_th_18 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      have "cosSIN-COSK19 is-differentiable-inFDIFF-1R1 x"
        using sin_cos_th_63 sorry
      thus "#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_3 sorry
    qed "sorry"
    then have A15: "#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z"
      using A14 fdiff_1_th_9 sorry
    have A16: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have "cosSIN-COSK19 is-differentiable-inFDIFF-1R1 x"
        using sin_cos_th_63 sorry
      then have A17: "diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19),x) =HIDDENR1 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(cosSIN-COSK19,x))"
        using taylor_1_th_3 sorry
      also have "... = (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x)"
        using sin_cos_th_63 sorry
      also have "... = -XCMPLX-0K4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
         sorry
      finally have "diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19),x) =HIDDENR1 -XCMPLX-0K4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
         sorry
      assume "x inHIDDENR3 Z"
      thus "((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
        using A15 A17 fdiff_1_def_7 sorry
    qed "sorry"
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 ((n +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A18: "n -XCMPLX-0K6 \<one>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1"
        using A2 nat_1_th_21 sorry
      assume A19: "x inHIDDENR3 Z"
      then have "((((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)) +XCMPLX-0K2 ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19),x))"
        using A1 A10 A15 fdiff_1_th_21 sorry
      also have "... = #ZTAYLOR-1K1 n .FUNCT-1K1 ((cosSIN-COSK19).FUNCT-1K1 x) *XCMPLX-0K3 (diffFDIFF-1K1((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)) +XCMPLX-0K2 ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19),x))"
        using A14 A19 funct_1_th_12 sorry
      also have "... = ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 n *XCMPLX-0K3 (diffFDIFF-1K1((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)) +XCMPLX-0K2 ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19),x))"
        using taylor_1_def_1 sorry
      also have "... = ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 n *XCMPLX-0K3 (((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19),x))"
        using A10 A19 fdiff_1_def_7 sorry
      also have "... = ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 n *XCMPLX-0K3 (-XCMPLX-0K4 n *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x)) +XCMPLX-0K2 ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19),x))"
        using A11 A19 sorry
      also have "... = ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 n *XCMPLX-0K3 (-XCMPLX-0K4 n *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x)) +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 (f .FUNCT-1K1 x) *XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19),x))"
        using A6 A19 funct_1_th_12 sorry
      also have "... = ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 n *XCMPLX-0K3 (-XCMPLX-0K4 n *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x)) +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x) *XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19),x))"
        using A3 A19 sorry
      also have "... = ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 n *XCMPLX-0K3 (-XCMPLX-0K4 n *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x)) +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x) *XCMPLX-0K3 ((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A15 A19 fdiff_1_def_7 sorry
      also have "... = ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 ((n -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M) *XCMPLX-0K3 (-XCMPLX-0K4 n *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x)) +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x) *XCMPLX-0K3 (-XCMPLX-0K4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)"
        using A16 A19 sorry
      also have "... = (((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 \<one>\<^sub>M)*XCMPLX-0K3 (-XCMPLX-0K4 n *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x)) +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x) *XCMPLX-0K3 (-XCMPLX-0K4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)"
        using A18 taylor_1_th_1 sorry
      also have "... = (((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)*XCMPLX-0K3 (-XCMPLX-0K4 n *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x)) +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x) *XCMPLX-0K3 (-XCMPLX-0K4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)"
        using prepower_th_35 sorry
      also have "... = -XCMPLX-0K4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)"
         sorry
      also have "... = -XCMPLX-0K4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (x +XCMPLX-0K2 n *XCMPLX-0K3 x)"
        using sin_cos_th_74 sorry
      also have "... = -XCMPLX-0K4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 ((n +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x)"
         sorry
      finally have "((((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 ((n +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x)"
         sorry
      thus "((((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 ((n +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x)"
         sorry
    qed "sorry"
    thus "((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 ((n +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x)))"
      using A1 A10 A15 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_5_th_13:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))) & n >=XXREAL-0R2 \<one>\<^sub>M) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 n *XCMPLX-0K3 x) implies ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 ((n +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x))"
proof-
  have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))) & (n >=XXREAL-0R2 \<one>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 n *XCMPLX-0K3 x)) implies ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 ((n +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)))"
      and A2: "n >=XXREAL-0R2 \<one>\<^sub>M"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 n *XCMPLX-0K3 x"
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 n *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
      using A3 sorry
    have A5: "Z c=TARSKIR1 domRELAT-1K1 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) /\\XBOOLE-0K3 domRELAT-1K1 (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))"
      using A1 valued_1_def_4 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using xboole_1_th_18 sorry
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 f"
      using funct_1_th_11 sorry
    then have A7: "Z c=TARSKIR1 domRELAT-1K1 f"
       sorry
    then have A8: "f is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_23 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have A9: "f is-differentiable-inFDIFF-1R1 x"
        using A8 fdiff_1_th_9 sorry
      have "sinSIN-COSK17 is-differentiable-inFDIFF-1R1 f .FUNCT-1K1 x"
        using sin_cos_th_64 sorry
      thus "(sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using A9 fdiff_2_th_13 sorry
    qed "sorry"
    then have A10: "(sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A6 fdiff_1_th_9 sorry
    have A11: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 n *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A12: "sinSIN-COSK17 is-differentiable-inFDIFF-1R1 f .FUNCT-1K1 x"
        using sin_cos_th_64 sorry
      assume A13: "x inHIDDENR3 Z"
      then have "f is-differentiable-inFDIFF-1R1 x"
        using A8 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 (diffFDIFF-1K1(sinSIN-COSK17,f .FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using A12 fdiff_2_th_13 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 (f .FUNCT-1K1 x) *XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using sin_cos_th_64 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x) *XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using A3 A13 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x) *XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A8 A13 fdiff_1_def_7 sorry
      also have "... = n *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x)"
        using A7 A4 A13 fdiff_1_th_23 sorry
      finally have "diffFDIFF-1K1((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 n *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x)"
         sorry
      thus "(((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 n *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x)"
        using A10 A13 fdiff_1_def_7 sorry
    qed "sorry"
    have A14: "Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))"
      using A5 xboole_1_th_18 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      have "cosSIN-COSK19 is-differentiable-inFDIFF-1R1 x"
        using sin_cos_th_63 sorry
      thus "#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_3 sorry
    qed "sorry"
    then have A15: "#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z"
      using A14 fdiff_1_th_9 sorry
    have A16: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have "cosSIN-COSK19 is-differentiable-inFDIFF-1R1 x"
        using sin_cos_th_63 sorry
      then have A17: "diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19),x) =HIDDENR1 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(cosSIN-COSK19,x))"
        using taylor_1_th_3 sorry
      also have "... = (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x)"
        using sin_cos_th_63 sorry
      also have "... = -XCMPLX-0K4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
         sorry
      finally have "diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19),x) =HIDDENR1 -XCMPLX-0K4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
         sorry
      assume "x inHIDDENR3 Z"
      thus "((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
        using A15 A17 fdiff_1_def_7 sorry
    qed "sorry"
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 ((n +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A18: "n -XCMPLX-0K6 \<one>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1"
        using A2 nat_1_th_21 sorry
      assume A19: "x inHIDDENR3 Z"
      then have "((((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)) +XCMPLX-0K2 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19),x))"
        using A1 A10 A15 fdiff_1_th_21 sorry
      also have "... = #ZTAYLOR-1K1 n .FUNCT-1K1 ((cosSIN-COSK19).FUNCT-1K1 x) *XCMPLX-0K3 (diffFDIFF-1K1((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)) +XCMPLX-0K2 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19),x))"
        using A14 A19 funct_1_th_12 sorry
      also have "... = ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 n *XCMPLX-0K3 (diffFDIFF-1K1((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)) +XCMPLX-0K2 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19),x))"
        using taylor_1_def_1 sorry
      also have "... = ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 n *XCMPLX-0K3 (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19),x))"
        using A10 A19 fdiff_1_def_7 sorry
      also have "... = ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 n *XCMPLX-0K3 (n *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x)) +XCMPLX-0K2 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19),x))"
        using A11 A19 sorry
      also have "... = ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 n *XCMPLX-0K3 (n *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x)) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (f .FUNCT-1K1 x) *XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19),x))"
        using A6 A19 funct_1_th_12 sorry
      also have "... = ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 n *XCMPLX-0K3 (n *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x)) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x) *XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19),x))"
        using A3 A19 sorry
      also have "... = ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 n *XCMPLX-0K3 (n *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x)) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x) *XCMPLX-0K3 ((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A15 A19 fdiff_1_def_7 sorry
      also have "... = ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 ((n -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M) *XCMPLX-0K3 (n *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x)) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x) *XCMPLX-0K3 (-XCMPLX-0K4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)"
        using A16 A19 sorry
      also have "... = (((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 \<one>\<^sub>M)*XCMPLX-0K3 (n *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x)) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x) *XCMPLX-0K3 (-XCMPLX-0K4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)"
        using A18 taylor_1_th_1 sorry
      also have "... = (((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 \<one>\<^sub>M)*XCMPLX-0K3 (n *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x)) -XCMPLX-0K6 (((sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x) *XCMPLX-0K3 n)*XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
         sorry
      also have "... = (((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)*XCMPLX-0K3 (n *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x)) -XCMPLX-0K6 (((sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x) *XCMPLX-0K3 n)*XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
        using prepower_th_35 sorry
      also have "... = (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 (n *XCMPLX-0K3 x) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (n *XCMPLX-0K3 x))"
         sorry
      also have "... = (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (x +XCMPLX-0K2 n *XCMPLX-0K3 x)"
        using sin_cos_th_74 sorry
      also have "... = (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 ((n +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x)"
         sorry
      finally have "((((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 ((n +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x)"
         sorry
      thus "((((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 ((n +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x)"
         sorry
    qed "sorry"
    thus "((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 ((n +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x)))"
      using A1 A10 A15 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_5_th_14:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  not 0NUMBERSK6 inTARSKIR2 Z & Z c=TARSKIR1 domRELAT-1K1 ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) implies (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  not 0NUMBERSK6 inTARSKIR2 Z & Z c=TARSKIR1 domRELAT-1K1 ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) implies (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x))"
  proof(rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    let ?f = "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z"
    assume A1: " not 0NUMBERSK6 inTARSKIR2 Z"
      and A2: "Z c=TARSKIR1 domRELAT-1K1 ((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))"
    have A3: "?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_5_th_4 sorry
    have A4: "sinSIN-COSK17 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 sin_cos_th_68 sorry
    have "Z c=TARSKIR1 domRELAT-1K1 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) /\\XBOOLE-0K3 domRELAT-1K1 (sinSIN-COSK17)"
      using A2 valued_1_def_4 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using xboole_1_th_18 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A6: "x inHIDDENR3 Z"
      then have "(((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x)) +XCMPLX-0K2 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(sinSIN-COSK17,x))"
        using A2 A3 A4 fdiff_1_th_21 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(sinSIN-COSK17,x))"
        using A3 A6 fdiff_1_def_7 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1) +XCMPLX-0K2 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(sinSIN-COSK17,x))"
        using A1 A6 fdiff_5_th_4 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1) +XCMPLX-0K2 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
        using sin_cos_th_64 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1) +XCMPLX-0K2 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
        using A5 A6 rfunct_1_def_2 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1) +XCMPLX-0K2 (\<one>\<^sub>M *XCMPLX-0K3 x \<inverse>XCMPLX-0K5)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
        using A6 funct_1_th_18 sorry
      also have "... = (-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
        using xcmplx_0_def_9 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
         sorry
      finally show "(((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
         sorry
    qed "sorry"
    thus "(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x))"
      using A2 A3 A4 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_5_th_15:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  not 0NUMBERSK6 inTARSKIR2 Z & Z c=TARSKIR1 domRELAT-1K1 ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) implies (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  not 0NUMBERSK6 inTARSKIR2 Z & Z c=TARSKIR1 domRELAT-1K1 ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) implies (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x))"
  proof(rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    let ?f = "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z"
    assume A1: " not 0NUMBERSK6 inTARSKIR2 Z"
      and A2: "Z c=TARSKIR1 domRELAT-1K1 ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))"
    have A3: "?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_5_th_4 sorry
    have A4: "cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 sin_cos_th_67 sorry
    have "Z c=TARSKIR1 domRELAT-1K1 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) /\\XBOOLE-0K3 domRELAT-1K1 (cosSIN-COSK19)"
      using A2 valued_1_def_4 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using xboole_1_th_18 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A6: "x inHIDDENR3 Z"
      then have "(((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x)) +XCMPLX-0K2 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(cosSIN-COSK19,x))"
        using A2 A3 A4 fdiff_1_th_21 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(cosSIN-COSK19,x))"
        using A3 A6 fdiff_1_def_7 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1) +XCMPLX-0K2 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(cosSIN-COSK19,x))"
        using A1 A6 fdiff_5_th_4 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1) +XCMPLX-0K2 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x)"
        using sin_cos_th_63 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1) +XCMPLX-0K2 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x)"
        using A5 A6 rfunct_1_def_2 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1) +XCMPLX-0K2 (\<one>\<^sub>M *XCMPLX-0K3 x \<inverse>XCMPLX-0K5)*XCMPLX-0K3 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x)"
        using A6 funct_1_th_18 sorry
      also have "... = (-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x)"
        using xcmplx_0_def_9 sorry
      also have "... = (-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
         sorry
      finally show "(((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
         sorry
    qed "sorry"
    thus "(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x))"
      using A2 A3 A4 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_5_th_16:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 (sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)) implies sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 x #RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 (sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)) implies sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 x #RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
    then have "Z c=TARSKIR1 domRELAT-1K1 (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)) /\\XBOOLE-0K3 domRELAT-1K1 (sinSIN-COSK17)"
      using valued_1_def_1 sorry
    then have A2: "Z c=TARSKIR1 domRELAT-1K1 (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
      using xboole_1_th_18 sorry
    then have A3: "#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) is-differentiable-onFDIFF-1R2 Z"
      using fdiff_5_lm_3 sorry
    have A4: "sinSIN-COSK17 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 sin_cos_th_68 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 x #RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A5: "x inHIDDENR3 Z"
      then have "((sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(sinSIN-COSK17,x) +XCMPLX-0K2 diffFDIFF-1K1(#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M),x)"
        using A1 A3 A4 fdiff_1_th_18 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 diffFDIFF-1K1(#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M),x)"
        using sin_cos_th_64 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) `|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A3 A5 fdiff_1_def_7 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 x #RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
        using A2 A5 fdiff_5_lm_3 sorry
      finally have "((sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 x #RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      thus "((sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 x #RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
    qed "sorry"
    thus "sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 x #RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
      using A1 A3 A4 fdiff_1_th_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_5_th_17:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( not 0NUMBERSK6 inTARSKIR2 Z & Z c=TARSKIR1 domRELAT-1K1 (g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))) & g =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M implies g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not 0NUMBERSK6 inTARSKIR2 Z & (Z c=TARSKIR1 domRELAT-1K1 (g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))) & g =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M) implies g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)))"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    let ?f = "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z"
    assume A1: " not 0NUMBERSK6 inTARSKIR2 Z"
      and A2: "Z c=TARSKIR1 domRELAT-1K1 (g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))"
      and A3: "g =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M"
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies g is-differentiable-inFDIFF-1R1 x"
      using A3 taylor_1_th_2 sorry
    have A5: "Z c=TARSKIR1 domRELAT-1K1 g /\\XBOOLE-0K3 domRELAT-1K1 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
      using A2 valued_1_def_4 sorry
    then have "Z c=TARSKIR1 domRELAT-1K1 g"
      using xboole_1_th_18 sorry
    then have A6: "g is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_9 sorry
    have A7: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (g `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A8: "x inHIDDENR3 Z"
      have "diffFDIFF-1K1(g,x) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 x #ZPREPOWERK3 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)"
        using A3 taylor_1_th_2 sorry
      also have "... = \<two>\<^sub>M *XCMPLX-0K3 x"
        using prepower_th_35 sorry
      finally have "diffFDIFF-1K1(g,x) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 x"
         sorry
      thus "(g `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 x"
        using A6 A8 fdiff_1_def_7 sorry
    qed "sorry"
    have A9: "(sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_5_th_5 sorry
    have A10: "Z c=TARSKIR1 domRELAT-1K1 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
      using A5 xboole_1_th_18 sorry
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using funct_1_th_11 sorry
    then have A11: "Z c=TARSKIR1 domRELAT-1K1 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
       sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A12: "x inHIDDENR3 Z"
      then have "((g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(g,x)) +XCMPLX-0K2 g .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x))"
        using A2 A9 A6 fdiff_1_th_21 sorry
      also have "... = ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (g `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 g .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x))"
        using A6 A12 fdiff_1_def_7 sorry
      also have "... = ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 x) +XCMPLX-0K2 g .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x))"
        using A7 A12 sorry
      also have "... = ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 x) +XCMPLX-0K2 x #ZPREPOWERK3 \<two>\<^sub>M *XCMPLX-0K3 (diffFDIFF-1K1((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x))"
        using A3 taylor_1_def_1 sorry
      also have "... = ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 x) +XCMPLX-0K2 x #ZPREPOWERK3 \<two>\<^sub>M *XCMPLX-0K3 (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A9 A12 fdiff_1_def_7 sorry
      also have "... = ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 x) +XCMPLX-0K2 x #ZPREPOWERK3 \<two>\<^sub>M *XCMPLX-0K3 (-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))"
        using A1 A12 fdiff_5_th_5 sorry
      also have "... = ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 x) -XCMPLX-0K6 x #ZPREPOWERK3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M) *XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))"
         sorry
      also have "... = ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 x) -XCMPLX-0K6 (x #ZPREPOWERK3 \<one>\<^sub>M *XCMPLX-0K3 x #ZPREPOWERK3 \<one>\<^sub>M)*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))"
        using taylor_1_th_1 sorry
      also have "... = ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 x) -XCMPLX-0K6 (x *XCMPLX-0K3 x #ZPREPOWERK3 \<one>\<^sub>M)*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))"
        using prepower_th_35 sorry
      also have "... = ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 x) -XCMPLX-0K6 (x *XCMPLX-0K3 x)*XCMPLX-0K3 (((\<one>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 (x *XCMPLX-0K3 x))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))"
        using prepower_th_35 sorry
      also have "... = ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 x) -XCMPLX-0K6 (x *XCMPLX-0K3 x)*XCMPLX-0K3 (((\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))"
        using xcmplx_1_th_102 sorry
      also have "... = ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 x) -XCMPLX-0K6 ((x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x))*XCMPLX-0K3 (x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x)))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
         sorry
      also have "... = ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 x) -XCMPLX-0K6 ((x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x))*XCMPLX-0K3 \<one>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
        using A1 A12 xcmplx_1_th_106 sorry
      also have "... = ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 x) -XCMPLX-0K6 (\<one>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
        using A1 A12 xcmplx_1_th_106 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 ((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x) *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 x) -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
        using A10 A12 funct_1_th_12 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 (?f .FUNCT-1K1 x)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 x) -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
        using A11 A12 rfunct_1_def_2 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M *XCMPLX-0K3 x \<inverse>XCMPLX-0K5) *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 x) -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
        using A12 funct_1_th_18 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
        using xcmplx_0_def_9 sorry
      finally have "((g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
         sorry
      thus "((g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
         sorry
    qed "sorry"
    thus "g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)))"
      using A2 A9 A6 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_5_th_18:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( not 0NUMBERSK6 inTARSKIR2 Z & Z c=TARSKIR1 domRELAT-1K1 (g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))) & g =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M implies g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not 0NUMBERSK6 inTARSKIR2 Z & (Z c=TARSKIR1 domRELAT-1K1 (g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))) & g =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M) implies g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)))"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    let ?f = "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z"
    assume A1: " not 0NUMBERSK6 inTARSKIR2 Z"
      and A2: "Z c=TARSKIR1 domRELAT-1K1 (g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))"
      and A3: "g =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M"
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies g is-differentiable-inFDIFF-1R1 x"
      using A3 taylor_1_th_2 sorry
    have A5: "Z c=TARSKIR1 domRELAT-1K1 g /\\XBOOLE-0K3 domRELAT-1K1 ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
      using A2 valued_1_def_4 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
      using xboole_1_th_18 sorry
    then have A7: "(cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_5_th_6 sorry
    have "Z c=TARSKIR1 domRELAT-1K1 g"
      using A5 xboole_1_th_18 sorry
    then have A8: "g is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_9 sorry
    have A9: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (g `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A10: "x inHIDDENR3 Z"
      have "diffFDIFF-1K1(g,x) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 x #ZPREPOWERK3 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)"
        using A3 taylor_1_th_2 sorry
      also have "... = \<two>\<^sub>M *XCMPLX-0K3 x"
        using prepower_th_35 sorry
      finally have "diffFDIFF-1K1(g,x) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 x"
         sorry
      thus "(g `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 x"
        using A8 A10 fdiff_1_def_7 sorry
    qed "sorry"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using A6 funct_1_th_11 sorry
    then have A11: "Z c=TARSKIR1 domRELAT-1K1 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
       sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A12: "x inHIDDENR3 Z"
      then have "((g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(g,x)) +XCMPLX-0K2 g .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x))"
        using A2 A7 A8 fdiff_1_th_21 sorry
      also have "... = ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (g `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 g .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x))"
        using A8 A12 fdiff_1_def_7 sorry
      also have "... = ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 x) +XCMPLX-0K2 g .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x))"
        using A9 A12 sorry
      also have "... = ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 x) +XCMPLX-0K2 x #ZPREPOWERK3 \<two>\<^sub>M *XCMPLX-0K3 (diffFDIFF-1K1((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x))"
        using A3 taylor_1_def_1 sorry
      also have "... = ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 x) +XCMPLX-0K2 x #ZPREPOWERK3 \<two>\<^sub>M *XCMPLX-0K3 (((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A7 A12 fdiff_1_def_7 sorry
      also have "... = ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 x) +XCMPLX-0K2 x #ZPREPOWERK3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M) *XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))"
        using A1 A6 A12 fdiff_5_th_6 sorry
      also have "... = ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 x) +XCMPLX-0K2 (x #ZPREPOWERK3 \<one>\<^sub>M *XCMPLX-0K3 x #ZPREPOWERK3 \<one>\<^sub>M)*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))"
        using taylor_1_th_1 sorry
      also have "... = ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 x) +XCMPLX-0K2 (x *XCMPLX-0K3 x #ZPREPOWERK3 \<one>\<^sub>M)*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))"
        using prepower_th_35 sorry
      also have "... = ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 x) +XCMPLX-0K2 (x *XCMPLX-0K3 x)*XCMPLX-0K3 (((\<one>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 (x *XCMPLX-0K3 x))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))"
        using prepower_th_35 sorry
      also have "... = ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 x) +XCMPLX-0K2 (x *XCMPLX-0K3 x)*XCMPLX-0K3 (((\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))"
        using xcmplx_1_th_102 sorry
      also have "... = ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 x) +XCMPLX-0K2 ((x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x))*XCMPLX-0K3 (x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x)))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
         sorry
      also have "... = ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 x) +XCMPLX-0K2 ((x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x))*XCMPLX-0K3 \<one>\<^sub>M)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
        using A1 A12 xcmplx_1_th_106 sorry
      also have "... = ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)).FUNCT-1K1 x *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 x) +XCMPLX-0K2 (\<one>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
        using A1 A12 xcmplx_1_th_106 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 ((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x) *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 x) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
        using A6 A12 funct_1_th_12 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 (?f .FUNCT-1K1 x)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 x) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
        using A11 A12 rfunct_1_def_2 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M *XCMPLX-0K3 x \<inverse>XCMPLX-0K5) *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 x) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
        using A12 funct_1_th_18 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
        using xcmplx_0_def_9 sorry
      finally have "((g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
         sorry
      thus "((g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
         sorry
    qed "sorry"
    thus "g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x)))"
      using A2 A7 A8 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma fdiff_5_lm_5:
" for x be RealXREAL-0M1 holds x inHIDDENR3 domRELAT-1K1 (lnTAYLOR-1K3) implies x >XXREAL-0R4 0NUMBERSK6"
  using taylor_1_th_18 xxreal_1_th_4 sorry

mtheorem fdiff_5_th_19:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 (lnTAYLOR-1K3) implies lnTAYLOR-1K3 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((lnTAYLOR-1K3)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 x)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 (lnTAYLOR-1K3) implies lnTAYLOR-1K3 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((lnTAYLOR-1K3)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 x))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (lnTAYLOR-1K3)"
    then have A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies lnTAYLOR-1K3 is-differentiable-inFDIFF-1R1 x"
      using fdiff_5_lm_5 taylor_1_th_18 sorry
    then have A3: "lnTAYLOR-1K3 is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((lnTAYLOR-1K3)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A4: "x inHIDDENR3 Z"
      then have "diffFDIFF-1K1(lnTAYLOR-1K3,x) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 x"
        using A1 taylor_1_th_18 sorry
      thus "((lnTAYLOR-1K3)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 x"
        using A3 A4 fdiff_1_def_7 sorry
    qed "sorry"
    thus "lnTAYLOR-1K3 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((lnTAYLOR-1K3)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 x))"
      using A1 A2 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_5_th_20:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)) implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M +XCMPLX-0K2 (lnTAYLOR-1K3).FUNCT-1K1 x)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)) implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M +XCMPLX-0K2 (lnTAYLOR-1K3).FUNCT-1K1 x))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    let ?f = "lnTAYLOR-1K3"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))"
    then have A2: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z) /\\XBOOLE-0K3 domRELAT-1K1 ?f"
      using valued_1_def_4 sorry
    then have A3: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)"
      using xboole_1_th_18 sorry
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
      using funct_1_th_18 sorry
    then have A5: "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_23 sorry
    have A6: "Z c=TARSKIR1 domRELAT-1K1 ?f"
      using A2 xboole_1_th_18 sorry
    then have A7: "?f is-differentiable-onFDIFF-1R2 Z"
      using fdiff_5_th_19 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M +XCMPLX-0K2 (lnTAYLOR-1K3).FUNCT-1K1 x"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M +XCMPLX-0K2 (lnTAYLOR-1K3).FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A8: "x inHIDDENR3 Z"
        then have A9: "x <>HIDDENR2 0NUMBERSK6"
          using A6 taylor_1_th_18 xxreal_1_th_4 sorry
        have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(?f,x)) +XCMPLX-0K2 ?f .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z,x))"
          using A1 A5 A7 A8 fdiff_1_th_21 sorry
        also have "... = idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x *XCMPLX-0K3 (?f `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 ?f .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z,x))"
          using A7 A8 fdiff_1_def_7 sorry
        also have "... = idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x) +XCMPLX-0K2 ?f .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z,x))"
          using A6 A8 fdiff_5_th_19 sorry
        also have "... = x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x) +XCMPLX-0K2 ?f .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z,x))"
          using A8 funct_1_th_18 sorry
        also have "... = x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x) +XCMPLX-0K2 ?f .FUNCT-1K1 x *XCMPLX-0K3 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z `|FDIFF-1K2 Z).FUNCT-1K1 x"
          using A5 A8 fdiff_1_def_7 sorry
        also have "... = x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x) +XCMPLX-0K2 ?f .FUNCT-1K1 x *XCMPLX-0K3 \<one>\<^sub>M"
          using A3 A4 A8 fdiff_1_th_23 sorry
        also have "... = \<one>\<^sub>M +XCMPLX-0K2 (lnTAYLOR-1K3).FUNCT-1K1 x"
          using A9 xcmplx_1_th_106 sorry
        finally have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M +XCMPLX-0K2 (lnTAYLOR-1K3).FUNCT-1K1 x"
           sorry
        thus "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M +XCMPLX-0K2 (lnTAYLOR-1K3).FUNCT-1K1 x"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M +XCMPLX-0K2 (lnTAYLOR-1K3).FUNCT-1K1 x))"
      using A1 A5 A7 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_5_th_21:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 (g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)) & g =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies x >XXREAL-0R4 0NUMBERSK6) implies g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (lnTAYLOR-1K3).FUNCT-1K1 x)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)) & (g =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies x >XXREAL-0R4 0NUMBERSK6)) implies g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (lnTAYLOR-1K3).FUNCT-1K1 x))"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    let ?f = "lnTAYLOR-1K3"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?f)"
      and A2: "g =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies x >XXREAL-0R4 0NUMBERSK6"
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies g is-differentiable-inFDIFF-1R1 x"
      using A2 taylor_1_th_2 sorry
    have A5: "Z c=TARSKIR1 domRELAT-1K1 g /\\XBOOLE-0K3 domRELAT-1K1 ?f"
      using A1 valued_1_def_4 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 ?f"
      using xboole_1_th_18 sorry
    then have A7: "?f is-differentiable-onFDIFF-1R2 Z"
      using fdiff_5_th_19 sorry
    have "Z c=TARSKIR1 domRELAT-1K1 g"
      using A5 xboole_1_th_18 sorry
    then have A8: "g is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_9 sorry
    have A9: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (g `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A10: "x inHIDDENR3 Z"
      have "diffFDIFF-1K1(g,x) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 x #ZPREPOWERK3 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)"
        using A2 taylor_1_th_2 sorry
      also have "... = \<two>\<^sub>M *XCMPLX-0K3 x"
        using prepower_th_35 sorry
      finally have "diffFDIFF-1K1(g,x) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 x"
         sorry
      thus "(g `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 x"
        using A8 A10 fdiff_1_def_7 sorry
    qed "sorry"
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (lnTAYLOR-1K3).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A11: "x inHIDDENR3 Z"
      then have A12: "x <>HIDDENR2 0NUMBERSK6"
        using A3 sorry
      have "((g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(?f,x)) +XCMPLX-0K2 ?f .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(g,x))"
        using A1 A8 A7 A11 fdiff_1_th_21 sorry
      also have "... = g .FUNCT-1K1 x *XCMPLX-0K3 (?f `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 ?f .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(g,x))"
        using A7 A11 fdiff_1_def_7 sorry
      also have "... = g .FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x) +XCMPLX-0K2 ?f .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(g,x))"
        using A6 A11 fdiff_5_th_19 sorry
      also have "... = x #ZPREPOWERK3 \<two>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x) +XCMPLX-0K2 ?f .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(g,x))"
        using A2 taylor_1_def_1 sorry
      also have "... = x #ZPREPOWERK3 \<two>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x) +XCMPLX-0K2 ?f .FUNCT-1K1 x *XCMPLX-0K3 (g `|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A8 A11 fdiff_1_def_7 sorry
      also have "... = x #ZPREPOWERK3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M) *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (lnTAYLOR-1K3).FUNCT-1K1 x"
        using A9 A11 sorry
      also have "... = (x #ZPREPOWERK3 \<one>\<^sub>M *XCMPLX-0K3 x #ZPREPOWERK3 \<one>\<^sub>M)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (lnTAYLOR-1K3).FUNCT-1K1 x"
        using taylor_1_th_1 sorry
      also have "... = (x #ZPREPOWERK3 \<one>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (lnTAYLOR-1K3).FUNCT-1K1 x"
        using prepower_th_35 sorry
      also have "... = (x *XCMPLX-0K3 x)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (lnTAYLOR-1K3).FUNCT-1K1 x"
        using prepower_th_35 sorry
      also have "... = x *XCMPLX-0K3 (x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x)) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (lnTAYLOR-1K3).FUNCT-1K1 x"
         sorry
      also have "... = x *XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (lnTAYLOR-1K3).FUNCT-1K1 x"
        using A12 xcmplx_1_th_106 sorry
      also have "... = x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (lnTAYLOR-1K3).FUNCT-1K1 x"
         sorry
      finally have "((g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (lnTAYLOR-1K3).FUNCT-1K1 x"
         sorry
      thus "((g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (lnTAYLOR-1K3).FUNCT-1K1 x"
         sorry
    qed "sorry"
    thus "g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((g (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (lnTAYLOR-1K3).FUNCT-1K1 x))"
      using A1 A8 A7 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_5_th_22:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((Z c=TARSKIR1 domRELAT-1K1 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 a)) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 (a -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M) |^NEWTONK1 \<two>\<^sub>M)"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & (( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 a) & (f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6))) implies (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 (a -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M) |^NEWTONK1 \<two>\<^sub>M))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 a"
      and A3: "f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M"
      and A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have A5: "Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))\<^esub> (domRELAT-1K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      using A1 rfunct_1_def_1 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using xboole_1_th_18 sorry
    then have A7: "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z"
      using A2 A3 fdiff_5_lm_1 sorry
    have A8: "Z c=TARSKIR1 domRELAT-1K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using A5 xboole_1_th_1 sorry
    then have A9: "f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z"
      using A2 A3 fdiff_5_lm_2 sorry
    have A10: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
      using A4 sorry
    then have A11: "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z"
      using A7 A9 fdiff_2_th_21 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 (a -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M) |^NEWTONK1 \<two>\<^sub>M"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A12: "x inHIDDENR3 Z"
      then have A13: "f1 .FUNCT-1K1 x =HIDDENR1 a"
        using A2 sorry
      have A14: "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A4 A12 sorry
      have "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x & f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x"
        using A7 A9 A12 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2),x) =HIDDENR1 ((diffFDIFF-1K1(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x))*XCMPLX-0K3 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x))*XCMPLX-0K3 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)/XCMPLX-0K7 ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)^2SQUARE-1K1"
        using A14 fdiff_2_th_14 sorry
      also have "... = ((diffFDIFF-1K1(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x))*XCMPLX-0K3 (f1 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x) -XCMPLX-0K6 (diffFDIFF-1K1(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x))*XCMPLX-0K3 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)/XCMPLX-0K7 ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)^2SQUARE-1K1"
        using A8 A12 valued_1_th_13 sorry
      also have "... = ((diffFDIFF-1K1(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x))*XCMPLX-0K3 (f1 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x) -XCMPLX-0K6 (diffFDIFF-1K1(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x))*XCMPLX-0K3 (f1 .FUNCT-1K1 x +XCMPLX-0K2 f2 .FUNCT-1K1 x))/XCMPLX-0K7 ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)^2SQUARE-1K1"
        using A6 A12 valued_1_def_1 sorry
      also have "... = ((diffFDIFF-1K1(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x))*XCMPLX-0K3 (f1 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x) -XCMPLX-0K6 (diffFDIFF-1K1(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x))*XCMPLX-0K3 (f1 .FUNCT-1K1 x +XCMPLX-0K2 f2 .FUNCT-1K1 x))/XCMPLX-0K7 (f1 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A8 A12 valued_1_th_13 sorry
      also have "... = (((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 (f1 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x) -XCMPLX-0K6 (diffFDIFF-1K1(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x))*XCMPLX-0K3 (f1 .FUNCT-1K1 x +XCMPLX-0K2 f2 .FUNCT-1K1 x))/XCMPLX-0K7 (f1 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A7 A12 fdiff_1_def_7 sorry
      also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (f1 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x) -XCMPLX-0K6 (diffFDIFF-1K1(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x))*XCMPLX-0K3 (f1 .FUNCT-1K1 x +XCMPLX-0K2 f2 .FUNCT-1K1 x))/XCMPLX-0K7 (f1 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A2 A3 A6 A12 fdiff_5_lm_1 sorry
      also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (f1 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x) -XCMPLX-0K6 ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 (f1 .FUNCT-1K1 x +XCMPLX-0K2 f2 .FUNCT-1K1 x))/XCMPLX-0K7 (f1 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A9 A12 fdiff_1_def_7 sorry
      also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (f1 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x) -XCMPLX-0K6 (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (f1 .FUNCT-1K1 x +XCMPLX-0K2 f2 .FUNCT-1K1 x))/XCMPLX-0K7 (f1 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A2 A3 A8 A12 fdiff_5_lm_2 sorry
      also have "... = ((\<four>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 a)/XCMPLX-0K7 (a -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)^2SQUARE-1K1"
        using A3 A13 taylor_1_def_1 sorry
      also have "... = ((\<four>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 a)/XCMPLX-0K7 (a -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M)^2SQUARE-1K1"
        using prepower_th_36 sorry
      also have "... = ((\<four>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 a)/XCMPLX-0K7 ((a -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M) |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 (a -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M))"
         sorry
      also have "... = ((\<four>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 a)/XCMPLX-0K7 (a -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M) |^NEWTONK1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)"
        using newton_th_6 sorry
      also have "... = ((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 (a -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M) |^NEWTONK1 \<two>\<^sub>M"
         sorry
      finally have "diffFDIFF-1K1((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2),x) =HIDDENR1 ((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 (a -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M) |^NEWTONK1 \<two>\<^sub>M"
         sorry
      thus "(((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 (a -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M) |^NEWTONK1 \<two>\<^sub>M"
        using A11 A12 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 (a -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M) |^NEWTONK1 \<two>\<^sub>M))"
      using A7 A9 A10 fdiff_2_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_5_th_23:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (((Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 a)) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 (a  |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 x  |^NEWTONK1 \<four>\<^sub>M))"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) & (( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 a) & (f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M & (( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6)))) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 (a  |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 x  |^NEWTONK1 \<four>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 a"
      and A3: "f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M"
      and A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      and A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
      using A1 funct_1_th_11 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
       sorry
    then have A7: "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z"
      using A2 A3 A4 fdiff_5_th_22 sorry
    have A8: "Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))\<^esub> (domRELAT-1K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      using A6 rfunct_1_def_1 sorry
    then have A9: "Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using xboole_1_th_18 sorry
    have A10: "Z c=TARSKIR1 domRELAT-1K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using A8 xboole_1_th_1 sorry
    have A11: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A12: "x inHIDDENR3 Z"
        then have "x inHIDDENR3 domRELAT-1K1 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
          using A1 funct_1_th_11 sorry
        then have A13: "((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)).FUNCT-1K1 x =HIDDENR1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x *XCMPLX-0K3 ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
          using rfunct_1_def_1 sorry
        also have "... = (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x /XCMPLX-0K7 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x"
          using xcmplx_0_def_9 sorry
        finally have "((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)).FUNCT-1K1 x =HIDDENR1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x /XCMPLX-0K7 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x"
           sorry
        have "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6 & (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using A4 A5 A12 sorry
        thus " not ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using A13 xreal_1_th_139 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A14: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-inFDIFF-1R1 x & ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A7 A11 fdiff_1_th_9 sorry
      thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_20 sorry
    qed "sorry"
    then have A15: "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 (a  |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 x  |^NEWTONK1 \<four>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A16: "x inHIDDENR3 Z"
      then have A17: "x inHIDDENR3 domRELAT-1K1 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
        using A1 funct_1_th_11 sorry
      have A18: "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A4 A16 sorry
      have A19: "f1 .FUNCT-1K1 x =HIDDENR1 a"
        using A2 A16 sorry
      have "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-inFDIFF-1R1 x & ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A7 A11 A16 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)),x) =HIDDENR1 (diffFDIFF-1K1((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2),x))/XCMPLX-0K7 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)).FUNCT-1K1 x"
        using taylor_1_th_20 sorry
      also have "... = (((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)).FUNCT-1K1 x"
        using A7 A16 fdiff_1_def_7 sorry
      also have "... = (((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x *XCMPLX-0K3 ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)\<inverse>XCMPLX-0K5)"
        using A17 rfunct_1_def_1 sorry
      also have "... = (((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 (f1 .FUNCT-1K1 x -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M) |^NEWTONK1 \<two>\<^sub>M)/XCMPLX-0K7 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x *XCMPLX-0K3 ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)\<inverse>XCMPLX-0K5)"
        using A2 A3 A4 A6 A16 A19 fdiff_5_th_22 sorry
      also have "... = (((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 (f1 .FUNCT-1K1 x -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M) |^NEWTONK1 \<two>\<^sub>M)/XCMPLX-0K7 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x *XCMPLX-0K3 ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)\<inverse>XCMPLX-0K5)"
        using prepower_th_36 sorry
      also have "... = (((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 (f1 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x) |^NEWTONK1 \<two>\<^sub>M)/XCMPLX-0K7 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x *XCMPLX-0K3 ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)\<inverse>XCMPLX-0K5)"
        using A3 taylor_1_def_1 sorry
      also have "... = (((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x  |^NEWTONK1 \<two>\<^sub>M)/XCMPLX-0K7 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x *XCMPLX-0K3 ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)\<inverse>XCMPLX-0K5)"
        using A10 A16 valued_1_th_13 sorry
      also have "... = (((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x  |^NEWTONK1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M))/XCMPLX-0K7 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x /XCMPLX-0K7 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)"
        using xcmplx_0_def_9 sorry
      also have "... = (((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x  |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x))/XCMPLX-0K7 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x /XCMPLX-0K7 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)"
        using newton_th_6 sorry
      also have "... = (((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x *XCMPLX-0K3 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x))/XCMPLX-0K7 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x /XCMPLX-0K7 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)"
         sorry
      also have "... = ((((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)/XCMPLX-0K7 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)/XCMPLX-0K7 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x /XCMPLX-0K7 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)"
        using xcmplx_1_th_78 sorry
      also have "... = ((((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)/XCMPLX-0K7 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x /XCMPLX-0K7 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x))/XCMPLX-0K7 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x"
        using xcmplx_1_th_48 sorry
      also have "... = (((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)/XCMPLX-0K7 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x"
        using A18 xcmplx_1_th_55 sorry
      also have "... = ((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x *XCMPLX-0K3 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)"
        using xcmplx_1_th_78 sorry
      also have "... = ((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 ((f1 .FUNCT-1K1 x +XCMPLX-0K2 f2 .FUNCT-1K1 x)*XCMPLX-0K3 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)"
        using A9 A16 valued_1_def_1 sorry
      also have "... = ((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 ((f1 .FUNCT-1K1 x +XCMPLX-0K2 f2 .FUNCT-1K1 x)*XCMPLX-0K3 (f1 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x))"
        using A10 A16 valued_1_th_13 sorry
      also have "... = ((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 (a *XCMPLX-0K3 a -XCMPLX-0K6 f2 .FUNCT-1K1 x *XCMPLX-0K3 f2 .FUNCT-1K1 x)"
        using A19 sorry
      also have "... = ((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 (a *XCMPLX-0K3 a -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M *XCMPLX-0K3 f2 .FUNCT-1K1 x)"
        using A3 taylor_1_def_1 sorry
      also have "... = ((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 (a *XCMPLX-0K3 a -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M *XCMPLX-0K3 x #ZPREPOWERK3 \<two>\<^sub>M)"
        using A3 taylor_1_def_1 sorry
      also have "... = ((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 (a  |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M *XCMPLX-0K3 x #ZPREPOWERK3 \<two>\<^sub>M)"
         sorry
      also have "... = ((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 (a  |^NEWTONK1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M) -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M *XCMPLX-0K3 x #ZPREPOWERK3 \<two>\<^sub>M)"
        using newton_th_6 sorry
      also have "... = ((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 (a  |^NEWTONK1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M) -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 x #ZPREPOWERK3 \<two>\<^sub>M)"
        using prepower_th_36 sorry
      also have "... = ((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 (a  |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)"
        using prepower_th_36 sorry
      also have "... = ((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 (a  |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 x  |^NEWTONK1 (\<two>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M))"
        using newton_th_8 sorry
      also have "... = ((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 (a  |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 x  |^NEWTONK1 \<four>\<^sub>M)"
         sorry
      finally have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)),x) =HIDDENR1 ((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 (a  |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 x  |^NEWTONK1 \<four>\<^sub>M)"
         sorry
      thus "(((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 (a  |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 x  |^NEWTONK1 \<four>\<^sub>M)"
        using A15 A16 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)/XCMPLX-0K7 (a  |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 x  |^NEWTONK1 \<four>\<^sub>M)))"
      using A1 A14 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_5_th_24:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies x >XXREAL-0R4 0NUMBERSK6) implies (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (lnTAYLOR-1K3).FUNCT-1K1 x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies x >XXREAL-0R4 0NUMBERSK6) implies (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (lnTAYLOR-1K3).FUNCT-1K1 x)))"
  proof(rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    let ?f = "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z"
    let ?g = "lnTAYLOR-1K3"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?g)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies x >XXREAL-0R4 0NUMBERSK6"
    have A3: " not 0NUMBERSK6 inTARSKIR2 Z"
      using A2 sorry
    then have A4: "?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z"
      using fdiff_5_th_4 sorry
    have A5: "Z c=TARSKIR1 domRELAT-1K1 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) /\\XBOOLE-0K3 domRELAT-1K1 ?g"
      using A1 valued_1_def_4 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 ?g"
      using xboole_1_th_18 sorry
    then have A7: "?g is-differentiable-onFDIFF-1R2 Z"
      using fdiff_5_th_19 sorry
    have A8: "Z c=TARSKIR1 domRELAT-1K1 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using A5 xboole_1_th_18 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (lnTAYLOR-1K3).FUNCT-1K1 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A9: "x inHIDDENR3 Z"
      then have "(((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?g)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ?g .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x)) +XCMPLX-0K2 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(?g,x))"
        using A1 A4 A7 fdiff_1_th_21 sorry
      also have "... = ?g .FUNCT-1K1 x *XCMPLX-0K3 ((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(?g,x))"
        using A4 A9 fdiff_1_def_7 sorry
      also have "... = ?g .FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1) +XCMPLX-0K2 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(?g,x))"
        using A3 A9 fdiff_5_th_4 sorry
      also have "... = ?g .FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1) +XCMPLX-0K2 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x *XCMPLX-0K3 (?g `|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A7 A9 fdiff_1_def_7 sorry
      also have "... = ?g .FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1) +XCMPLX-0K2 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x)"
        using A6 A9 fdiff_5_th_19 sorry
      also have "... = ?g .FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1) +XCMPLX-0K2 (?f .FUNCT-1K1 x)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x)"
        using A8 A9 rfunct_1_def_2 sorry
      also have "... = ?g .FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1) +XCMPLX-0K2 (\<one>\<^sub>M *XCMPLX-0K3 x \<inverse>XCMPLX-0K5)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x)"
        using A9 funct_1_th_18 sorry
      also have "... = (-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 ?g .FUNCT-1K1 x)+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x)"
        using xcmplx_0_def_9 sorry
      also have "... = (-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (lnTAYLOR-1K3).FUNCT-1K1 x)+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1"
        using xcmplx_1_th_102 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (lnTAYLOR-1K3).FUNCT-1K1 x)"
         sorry
      finally have "(((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?g)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (lnTAYLOR-1K3).FUNCT-1K1 x)"
         sorry
      thus "(((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (lnTAYLOR-1K3).FUNCT-1K1 x)"
         sorry
    qed "sorry"
    thus "(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (lnTAYLOR-1K3).FUNCT-1K1 x)))"
      using A1 A4 A7 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_5_th_25:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6) implies (lnTAYLOR-1K3)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (x *XCMPLX-0K3 ((lnTAYLOR-1K3).FUNCT-1K1 x)^2SQUARE-1K1))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6) implies (lnTAYLOR-1K3)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (x *XCMPLX-0K3 ((lnTAYLOR-1K3).FUNCT-1K1 x)^2SQUARE-1K1)))"
  proof(rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    let ?f = "lnTAYLOR-1K3"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
    have "domRELAT-1K1 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) c=TARSKIR1 domRELAT-1K1 ?f"
      using rfunct_1_th_1 sorry
    then have A3: "Z c=TARSKIR1 domRELAT-1K1 ?f"
      using A1 sorry
    then have A4: "?f is-differentiable-onFDIFF-1R2 Z"
      using fdiff_5_th_19 sorry
    then have A5: "?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z"
      using A2 fdiff_2_th_22 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (x *XCMPLX-0K3 ((lnTAYLOR-1K3).FUNCT-1K1 x)^2SQUARE-1K1)"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (x *XCMPLX-0K3 ((lnTAYLOR-1K3).FUNCT-1K1 x)^2SQUARE-1K1)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A6: "x inHIDDENR3 Z"
        then have A7: "?f .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6 & ?f is-differentiable-inFDIFF-1R1 x"
          using A2 A4 fdiff_1_th_9 sorry
        have "((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x)"
          using A5 A6 fdiff_1_def_7 sorry
        also have "... = -XCMPLX-0K4 (diffFDIFF-1K1(?f,x))/XCMPLX-0K7 (?f .FUNCT-1K1 x)^2SQUARE-1K1"
          using A7 fdiff_2_th_15 sorry
        also have "... = -XCMPLX-0K4 (?f `|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 (?f .FUNCT-1K1 x)^2SQUARE-1K1"
          using A4 A6 fdiff_1_def_7 sorry
        also have "... = -XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 x)/XCMPLX-0K7 ((lnTAYLOR-1K3).FUNCT-1K1 x)^2SQUARE-1K1"
          using A3 A6 fdiff_5_th_19 sorry
        also have "... = -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (x *XCMPLX-0K3 ((lnTAYLOR-1K3).FUNCT-1K1 x)^2SQUARE-1K1)"
          using xcmplx_1_th_78 sorry
        finally have "((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (x *XCMPLX-0K3 ((lnTAYLOR-1K3).FUNCT-1K1 x)^2SQUARE-1K1)"
           sorry
        thus "(((lnTAYLOR-1K3)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (x *XCMPLX-0K3 ((lnTAYLOR-1K3).FUNCT-1K1 x)^2SQUARE-1K1)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "(lnTAYLOR-1K3)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (x *XCMPLX-0K3 ((lnTAYLOR-1K3).FUNCT-1K1 x)^2SQUARE-1K1)))"
      using A2 A4 fdiff_2_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
