theory finset_1
  imports ordinal3 funct_3 funct_4 xfamily
begin
(*begin*)
mdef finset_1_def_1 ("finiteFINSET-1V1" 70 ) where
"attr finiteFINSET-1V1 for setHIDDENM2 means
  (\<lambda>IT.  ex p be FunctionFUNCT-1M1 st rngFUNCT-1K2 p =XBOOLE-0R4 IT & domRELAT-1K1 p inTARSKIR2 omegaORDINAL1K4)"..

syntax FINSET_1V2 :: "Ty" ("infiniteFINSET-1V2" 70)
translations "infiniteFINSET-1V2" \<rightharpoonup> " non finiteFINSET-1V1"

reserve A, B, X, Y, Z, x, y for "setHIDDENM2"
reserve f for "FunctionFUNCT-1M1"
mlemma finset_1_lm_1:
" for x be objectHIDDENM1 holds {TARSKIK1 x} be finiteFINSET-1V1"
proof(rule ballI)
  fix x assume [ty]: "x be objectHIDDENM1"
  let ?p = "{TARSKIK1 {}XBOOLE-0K1 } -->FUNCOP-1K7 x"
  have A1: "domRELSET-1K1\<^bsub>({TARSKIK1 {}XBOOLE-0K1 })\<^esub> ?p =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
    using funcop_1_th_13 sorry
  have Cut58: " for y be objectHIDDENM1 holds y inHIDDENR3 {TARSKIK1 x} iff ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELSET-1K1\<^bsub>({TARSKIK1 {}XBOOLE-0K1 })\<^esub> ?p & y =HIDDENR1 ?p .FUNCT-1K1 x)"
  proof-
    have " for y be objectHIDDENM1 holds (y inHIDDENR3 {TARSKIK1 x} implies ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELSET-1K1\<^bsub>({TARSKIK1 {}XBOOLE-0K1 })\<^esub> ({TARSKIK1 {}XBOOLE-0K1 } -->FUNCOP-1K7 x) & y =HIDDENR1 ({TARSKIK1 {}XBOOLE-0K1 } -->FUNCOP-1K7 x).FUNCT-1K1 x)) & (( ex z be objectHIDDENM1 st z inHIDDENR3 domRELSET-1K1\<^bsub>({TARSKIK1 {}XBOOLE-0K1 })\<^esub> ({TARSKIK1 {}XBOOLE-0K1 } -->FUNCOP-1K7 x) & y =HIDDENR1 ({TARSKIK1 {}XBOOLE-0K1 } -->FUNCOP-1K7 x).FUNCT-1K1 z) implies y inHIDDENR3 {TARSKIK1 x})"
    proof(rule ballI,rule conjMI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      show "y inHIDDENR3 {TARSKIK1 x} implies ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELSET-1K1\<^bsub>({TARSKIK1 {}XBOOLE-0K1 })\<^esub> ({TARSKIK1 {}XBOOLE-0K1 } -->FUNCOP-1K7 x) & y =HIDDENR1 ({TARSKIK1 {}XBOOLE-0K1 } -->FUNCOP-1K7 x).FUNCT-1K1 x)"
      proof-
        have "y inHIDDENR3 {TARSKIK1 x} implies ( ex tVar2 be objectHIDDENM1 st tVar2 inTARSKIR2 domRELSET-1K1\<^bsub>({TARSKIK1 tVar2})\<^esub> ({TARSKIK1 tVar2} -->FUNCOP-1K7 x) & y =HIDDENR1 ({TARSKIK1 tVar2} -->FUNCOP-1K7 x).FUNCT-1K1 tVar2)"
        proof(rule impI)
          assume "y inHIDDENR3 {TARSKIK1 x}"
          then have A2: "y =HIDDENR1 x"
            using tarski_def_1 sorry
          show " ex tVar2 be objectHIDDENM1 st tVar2 inTARSKIR2 domRELSET-1K1\<^bsub>({TARSKIK1 tVar2})\<^esub> ({TARSKIK1 tVar2} -->FUNCOP-1K7 x) & y =HIDDENR1 ({TARSKIK1 tVar2} -->FUNCOP-1K7 x).FUNCT-1K1 tVar2"
          proof(rule bexI[of _ "{}XBOOLE-0K1"],rule conjMI)
            show "{}XBOOLE-0K1 inTARSKIR2 domRELSET-1K1\<^bsub>({TARSKIK1 {}XBOOLE-0K1 })\<^esub> ({TARSKIK1 {}XBOOLE-0K1 } -->FUNCOP-1K7 x)"
              using A1 tarski_def_1 sorry
            have "{}XBOOLE-0K1 inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 }"
              using tarski_def_1 sorry
            thus "y =HIDDENR1 ({TARSKIK1 {}XBOOLE-0K1 } -->FUNCOP-1K7 x).FUNCT-1K1 {}XBOOLE-0K1"
              using A2 funcop_1_th_7 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
      assume " ex z be objectHIDDENM1 st z inHIDDENR3 domRELSET-1K1\<^bsub>({TARSKIK1 {}XBOOLE-0K1 })\<^esub> ?p & y =HIDDENR1 ?p .FUNCT-1K1 z"
      then have "y =HIDDENR1 x"
        using funcop_1_th_7 sorry
      thus "y inHIDDENR3 {TARSKIK1 x}"
        using tarski_def_1 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have "rngRELSET-1K2\<^bsub>({TARSKIK1 x})\<^esub> ({TARSKIK1 {}XBOOLE-0K1 } -->FUNCOP-1K7 x) =XBOOLE-0R4 {TARSKIK1 x} & domRELAT-1K1 ({TARSKIK1 {}XBOOLE-0K1 } -->FUNCOP-1K7 x) inTARSKIR2 omegaORDINAL1K4"
  proof(rule conjMI)
    show "rngRELSET-1K2\<^bsub>({TARSKIK1 x})\<^esub> ({TARSKIK1 {}XBOOLE-0K1 } -->FUNCOP-1K7 x) =XBOOLE-0R4 {TARSKIK1 x}"
      using funct_1_def_3 Cut58 sorry
    show "domRELAT-1K1 ({TARSKIK1 {}XBOOLE-0K1 } -->FUNCOP-1K7 x) inTARSKIR2 omegaORDINAL1K4"
      using A1 ordinal3_th_15 sorry
  qed
  thus "{TARSKIK1 x} be finiteFINSET-1V1"
    using bexI[of _ "?p"] finset_1_def_1 sorry
qed "sorry"

mtheorem finset_1_cl_1:
"cluster  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1 for setHIDDENM2"
proof
(*existence*)
  show " ex it be setHIDDENM2 st it be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1"
  proof-
    have " not ( for VarFor1 be setHIDDENM2 holds  not ( not VarFor1 be emptyXBOOLE-0V1 & VarFor1 be finiteFINSET-1V1))"
    proof-
      have "{TARSKIK1 the setHIDDENM2 } be finiteFINSET-1V1"
        using finset_1_lm_1 sorry
      thus " not ( for VarFor1 be setHIDDENM2 holds  not ( not VarFor1 be emptyXBOOLE-0V1 & VarFor1 be finiteFINSET-1V1))"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finset_1_cl_2:
"cluster emptyXBOOLE-0V1 also-is finiteFINSET-1V1 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be emptyXBOOLE-0V1 implies it be finiteFINSET-1V1"
  proof-
    have " for A be setHIDDENM2 holds A be emptyXBOOLE-0V1 implies A be finiteFINSET-1V1"
    proof(rule ballI,rule impI)
      fix A assume [ty]: "A be setHIDDENM2"
      assume A1: "A be emptyXBOOLE-0V1"
      have "rngFUNCT-1K2 ({}XBOOLE-0K1) =XBOOLE-0R4 A & domRELAT-1K1 ({}XBOOLE-0K1) inTARSKIR2 omegaORDINAL1K4"
      proof(rule conjMI)
        show "rngFUNCT-1K2 ({}XBOOLE-0K1) =XBOOLE-0R4 A"
          using A1 sorry
        show "domRELAT-1K1 ({}XBOOLE-0K1) inTARSKIR2 omegaORDINAL1K4"
          using ordinal1_def_11 sorry
      qed
      thus "A be finiteFINSET-1V1"
        using bexI[of _ "{}XBOOLE-0K1"] finset_1_def_1 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

theorem finset_1_sch_1:
  fixes Af0 Ff1 Gf1 Cp1 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Gf1(x1) be objectHIDDENM1"
  shows " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 Af0 & ( for x be OrdinalORDINAL1M3 holds x inTARSKIR2 Af0 implies (Cp1(x) implies f .FUNCT-1K1 x =HIDDENR1 Ff1(x)) & ( not Cp1(x) implies f .FUNCT-1K1 x =HIDDENR1 Gf1(x)))"
  proof-
    have " ex tVar4 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar4 =XBOOLE-0R4 Af0 & ( for x be OrdinalORDINAL1M3 holds  not (x inTARSKIR2 Af0 &  not ( not (Cp1(x) &  not tVar4 .FUNCT-1K1 x =HIDDENR1 Ff1(x)) &  not ( not Cp1(x) &  not tVar4 .FUNCT-1K1 x =HIDDENR1 Gf1(x)))))"
    proof-
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A1: "domRELAT-1K1 f =XBOOLE-0R4 Af0 & ( for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies (Cp1(x) implies f .FUNCT-1K1 x =HIDDENR1 Ff1(x)) & ( not Cp1(x) implies f .FUNCT-1K1 x =HIDDENR1 Gf1(x)))"
        using partfun1_sch_1 sorry
      show " ex tVar4 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar4 =XBOOLE-0R4 Af0 & ( for x be OrdinalORDINAL1M3 holds  not (x inTARSKIR2 Af0 &  not ( not (Cp1(x) &  not tVar4 .FUNCT-1K1 x =HIDDENR1 Ff1(x)) &  not ( not Cp1(x) &  not tVar4 .FUNCT-1K1 x =HIDDENR1 Gf1(x)))))"
      proof(rule bexI[of _ "f"])
        show "domRELAT-1K1 f =XBOOLE-0R4 Af0 & ( for x be OrdinalORDINAL1M3 holds  not (x inTARSKIR2 Af0 &  not ( not (Cp1(x) &  not f .FUNCT-1K1 x =HIDDENR1 Ff1(x)) &  not ( not Cp1(x) &  not f .FUNCT-1K1 x =HIDDENR1 Gf1(x)))))"
          using A1 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mlemma finset_1_lm_2:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds A be finiteFINSET-1V1 & B be finiteFINSET-1V1 implies A \\/XBOOLE-0K2 B be finiteFINSET-1V1"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  not ((A be finiteFINSET-1V1 & B be finiteFINSET-1V1) &  not A \\/XBOOLE-0K2 B be finiteFINSET-1V1)"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    have "( ex p be FunctionFUNCT-1M1 st rngFUNCT-1K2 p =XBOOLE-0R4 A & domRELAT-1K1 p inTARSKIR2 omegaORDINAL1K4) implies  not (B be finiteFINSET-1V1 &  not A \\/XBOOLE-0K2 B be finiteFINSET-1V1)"
    proof(rule impI)
      assume Given: " ex p be FunctionFUNCT-1M1 st rngFUNCT-1K2 p =XBOOLE-0R4 A & domRELAT-1K1 p inTARSKIR2 omegaORDINAL1K4"
      then obtain p where
        [ty]:"p be FunctionFUNCT-1M1" and 
        A1: "rngFUNCT-1K2 p =XBOOLE-0R4 A"and A2: "domRELAT-1K1 p inTARSKIR2 omegaORDINAL1K4"
         sorry
      have "( ex q be FunctionFUNCT-1M1 st rngFUNCT-1K2 q =XBOOLE-0R4 B & domRELAT-1K1 q inTARSKIR2 omegaORDINAL1K4) implies A \\/XBOOLE-0K2 B be finiteFINSET-1V1"
      proof(rule impI)
        assume Given: " ex q be FunctionFUNCT-1M1 st rngFUNCT-1K2 q =XBOOLE-0R4 B & domRELAT-1K1 q inTARSKIR2 omegaORDINAL1K4"
        then obtain q where
          [ty]:"q be FunctionFUNCT-1M1" and 
          A3: "rngFUNCT-1K2 q =XBOOLE-0R4 B"and A4: "domRELAT-1K1 q inTARSKIR2 omegaORDINAL1K4"
           sorry
        obtain domp domq where 
          [ty]:"domp be OrdinalORDINAL1M3" and dompDef:"domp = domRELAT-1K1 p" and
          [ty]:"domq be OrdinalORDINAL1M3" and domqDef:"domq = domRELAT-1K1 q"
          using A2 A4 sorry
        let ?F = "\<lambda>Lamb1. p .FUNCT-1K1 Lamb1"
        let ?G = "\<lambda>Lamb1. q .FUNCT-1K1 (Lamb1 -^ORDINAL3K5 domp)"
        let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 domp"
        obtain f where
          [ty]:"f be FunctionFUNCT-1M1" and 
          A5: "domRELAT-1K1 f =XBOOLE-0R4 domp +^ORDINAL2K10 domq"and A6: " for x be OrdinalORDINAL1M3 holds x inTARSKIR2 domp +^ORDINAL2K10 domq implies (?P(x) implies f .FUNCT-1K1 x =XBOOLE-0R4 ?F(x)) & ( not ?P(x) implies f .FUNCT-1K1 x =XBOOLE-0R4 ?G(x))"
          using finset_1_sch_1 sorry
        have 
          [ty]:"domp be naturalORDINAL1V7\<bar>OrdinalORDINAL1M3" and
          [ty]:"domq be naturalORDINAL1V7\<bar>OrdinalORDINAL1M3"
          using A2 A4 sorry
        have "rngFUNCT-1K2 f =XBOOLE-0R4 A \\/XBOOLE-0K2 B & domRELAT-1K1 f inTARSKIR2 omegaORDINAL1K4"
        proof(rule conjMI)
          show "rngFUNCT-1K2 f =XBOOLE-0R4 A \\/XBOOLE-0K2 B"
          proof-
            have "rngFUNCT-1K2 f c=TARSKIR1 A \\/XBOOLE-0K2 B & A \\/XBOOLE-0K2 B c=TARSKIR1 rngFUNCT-1K2 f"
            proof(rule conjMI)
              show "rngFUNCT-1K2 f c=TARSKIR1 A \\/XBOOLE-0K2 B"
              proof-
                have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies y inHIDDENR3 A \\/XBOOLE-0K2 B"
                proof(rule ballI,rule impI)
                  fix y assume [ty]: "y be objectHIDDENM1"
                  assume "y inHIDDENR3 rngFUNCT-1K2 f"
                  then obtain x where
                    [ty]:"x be objectHIDDENM1" and 
                    A7: "x inHIDDENR3 domRELAT-1K1 f"and A8: "y =HIDDENR1 f .FUNCT-1K1 x"
                    using funct_1_def_3 sorry
                  have 
                    [ty]:"x be OrdinalORDINAL1M3"
                    using A5 A7 sorry
                  show "y inHIDDENR3 A \\/XBOOLE-0K2 B"
                  proof-
                    have cases: "x inTARSKIR2 domp or  not x inTARSKIR2 domp"
                       sorry
                    have case1: "x inTARSKIR2 domp implies y inHIDDENR3 A \\/XBOOLE-0K2 B"
                    proof(rule impI)
                      assume A9: "x inTARSKIR2 domp"
                      then have A10: "y =HIDDENR1 p .FUNCT-1K1 x"
                        using A5 A6 A7 A8 sorry
                      have "p .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 p"
                        using A9 funct_1_def_3 sorry
                      thus "y inHIDDENR3 A \\/XBOOLE-0K2 B"
                        using A1 A10 xboole_0_def_3 sorry
                    qed
                    have case2: " not x inTARSKIR2 domp implies y inHIDDENR3 A \\/XBOOLE-0K2 B"
                    proof(rule impI)
                      assume A11: " not x inTARSKIR2 domp"
                      then have A12: "domp c=ORDINAL1R1 x"
                        using ordinal1_th_16 sorry
                      have A13: "y =HIDDENR1 q .FUNCT-1K1 (x -^ORDINAL3K5 domp)"
                        using A5 A6 A7 A8 A11 sorry
                      have "domp +^ORDINAL2K10 (x -^ORDINAL3K5 domp) =XBOOLE-0R4 x"
                        using A12 ordinal3_def_5 sorry
                      then have "x -^ORDINAL3K5 domp inTARSKIR2 domRELAT-1K1 q"
                        using A5 A7 ordinal3_th_22 sorry
                      then have "y inHIDDENR3 B"
                        using A3 A13 funct_1_def_3 sorry
                      thus "y inHIDDENR3 A \\/XBOOLE-0K2 B"
                        using xboole_0_def_3 sorry
                    qed
                    show " ?thesis "
                      using cases case1 case2 sorry
                  qed
                qed "sorry"
                thus "rngFUNCT-1K2 f c=TARSKIR1 A \\/XBOOLE-0K2 B"
                  using tarski_def_3 sorry
              qed
              have " for x be objectHIDDENM1 holds x inHIDDENR3 A \\/XBOOLE-0K2 B implies x inHIDDENR3 rngFUNCT-1K2 f"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume A14: "x inHIDDENR3 A \\/XBOOLE-0K2 B"
                show "x inHIDDENR3 rngFUNCT-1K2 f"
                proof-
                  have cases: "x inHIDDENR3 rngFUNCT-1K2 p or x inHIDDENR3 rngFUNCT-1K2 q"
                    using A1 A3 A14 xboole_0_def_3 sorry
                  have case1: "x inHIDDENR3 rngFUNCT-1K2 p implies x inHIDDENR3 rngFUNCT-1K2 f"
                  proof(rule impI)
                    assume "x inHIDDENR3 rngFUNCT-1K2 p"
                    then obtain y where
                      [ty]:"y be objectHIDDENM1" and 
                      A15: "y inHIDDENR3 domRELAT-1K1 p"and A16: "x =HIDDENR1 p .FUNCT-1K1 y"
                      using funct_1_def_3 sorry
                    have A17: "domRELAT-1K1 p c=TARSKIR1 domRELAT-1K1 f"
                      using A5 ordinal3_th_24 sorry
                    then have "x =HIDDENR1 f .FUNCT-1K1 y"
                      using A5 A6 A15 A16 sorry
                    thus "x inHIDDENR3 rngFUNCT-1K2 f"
                      using A15 A17 funct_1_def_3 sorry
                  qed
                  have case2: "x inHIDDENR3 rngFUNCT-1K2 q implies x inHIDDENR3 rngFUNCT-1K2 f"
                  proof(rule impI)
                    assume "x inHIDDENR3 rngFUNCT-1K2 q"
                    then obtain y where
                      [ty]:"y be objectHIDDENM1" and 
                      A18: "y inHIDDENR3 domq"and A19: "x =HIDDENR1 q .FUNCT-1K1 y"
                      using funct_1_def_3 sorry
                    have 
                      [ty]:"y be OrdinalORDINAL1M3"
                      using A18 sorry
                    let ?z = "domp +^ORDINAL2K10 y"
                    have "domp c=ORDINAL1R1 ?z"
                      using ordinal3_th_24 sorry
                    then have A20: " not ?z inTARSKIR2 domp"
                      using ordinal1_th_5 sorry
                    have A21: "?z inTARSKIR2 domRELAT-1K1 f"
                      using A5 A18 ordinal3_th_17 sorry
                    have "x =HIDDENR1 q .FUNCT-1K1 (?z -^ORDINAL3K5 domp)"
                      using A19 ordinal3_th_52 sorry
                    also have "... = f .FUNCT-1K1 ?z"
                      using A5 A6 A20 A21 sorry
                    finally have "x =HIDDENR1 f .FUNCT-1K1 ?z"
                       sorry
                    thus "x inHIDDENR3 rngFUNCT-1K2 f"
                      using A21 funct_1_def_3 sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed "sorry"
              thus "A \\/XBOOLE-0K2 B c=TARSKIR1 rngFUNCT-1K2 f"
                using tarski_def_3 sorry
            qed
            thus "rngFUNCT-1K2 f =XBOOLE-0R4 A \\/XBOOLE-0K2 B"
              using xboole_0_def_10 sorry
          qed
          have "domp +^ORDINAL3K8 domq be naturalORDINAL1V7"
             sorry
          thus "domRELAT-1K1 f inTARSKIR2 omegaORDINAL1K4"
            using A5 sorry
        qed
        thus "A \\/XBOOLE-0K2 B be finiteFINSET-1V1"
          using bexI[of _ "f"] finset_1_def_1 sorry
      qed
      thus " not (B be finiteFINSET-1V1 &  not A \\/XBOOLE-0K2 B be finiteFINSET-1V1)"
        using finset_1_def_1 sorry
    qed
    thus " not ((A be finiteFINSET-1V1 & B be finiteFINSET-1V1) &  not A \\/XBOOLE-0K2 B be finiteFINSET-1V1)"
      using finset_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finset_1_cl_3:
  mlet "x be objectHIDDENM1"
"cluster {TARSKIK1 x} as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "{TARSKIK1 x} be finiteFINSET-1V1"
    using finset_1_lm_1 sorry
qed "sorry"

mtheorem finset_1_cl_4:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1"
"cluster {TARSKIK2 x,y } as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "{TARSKIK2 x,y } be finiteFINSET-1V1"
  proof-
    have "{TARSKIK2 x,y } =XBOOLE-0R4 {TARSKIK1 x} \\/XBOOLE-0K2 {TARSKIK1 y}"
      using enumset1_th_1 sorry
    thus "{TARSKIK2 x,y } be finiteFINSET-1V1"
      using finset_1_lm_2 sorry
  qed
qed "sorry"

mtheorem finset_1_cl_5:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1", "z be objectHIDDENM1"
"cluster {ENUMSET1K1 x,y,z } as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "{ENUMSET1K1 x,y,z } be finiteFINSET-1V1"
  proof-
    have "{ENUMSET1K1 x,y,z } =XBOOLE-0R4 {TARSKIK1 x} \\/XBOOLE-0K2 {TARSKIK2 y,z }"
      using enumset1_th_2 sorry
    thus "{ENUMSET1K1 x,y,z } be finiteFINSET-1V1"
      using finset_1_lm_2 sorry
  qed
qed "sorry"

mtheorem finset_1_cl_6:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1"
"cluster {ENUMSET1K2 x1,x2,x3,x4 } as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "{ENUMSET1K2 x1,x2,x3,x4 } be finiteFINSET-1V1"
  proof-
    have "{ENUMSET1K2 x1,x2,x3,x4 } =XBOOLE-0R4 {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K1 x2,x3,x4 }"
      using enumset1_th_4 sorry
    thus "{ENUMSET1K2 x1,x2,x3,x4 } be finiteFINSET-1V1"
      using finset_1_lm_2 sorry
  qed
qed "sorry"

mtheorem finset_1_cl_7:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1", "x5 be objectHIDDENM1"
"cluster {ENUMSET1K3 x1,x2,x3,x4,x5 } as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "{ENUMSET1K3 x1,x2,x3,x4,x5 } be finiteFINSET-1V1"
  proof-
    have "{ENUMSET1K3 x1,x2,x3,x4,x5 } =XBOOLE-0R4 {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K2 x2,x3,x4,x5 }"
      using enumset1_th_7 sorry
    thus "{ENUMSET1K3 x1,x2,x3,x4,x5 } be finiteFINSET-1V1"
      using finset_1_lm_2 sorry
  qed
qed "sorry"

mtheorem finset_1_cl_8:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1", "x5 be objectHIDDENM1", "x6 be objectHIDDENM1"
"cluster {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "{ENUMSET1K4 x1,x2,x3,x4,x5,x6 } be finiteFINSET-1V1"
  proof-
    have "{ENUMSET1K4 x1,x2,x3,x4,x5,x6 } =XBOOLE-0R4 {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K3 x2,x3,x4,x5,x6 }"
      using enumset1_th_11 sorry
    thus "{ENUMSET1K4 x1,x2,x3,x4,x5,x6 } be finiteFINSET-1V1"
      using finset_1_lm_2 sorry
  qed
qed "sorry"

mtheorem finset_1_cl_9:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1", "x5 be objectHIDDENM1", "x6 be objectHIDDENM1", "x7 be objectHIDDENM1"
"cluster {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "{ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } be finiteFINSET-1V1"
  proof-
    have "{ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } =XBOOLE-0R4 {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K4 x2,x3,x4,x5,x6,x7 }"
      using enumset1_th_16 sorry
    thus "{ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } be finiteFINSET-1V1"
      using finset_1_lm_2 sorry
  qed
qed "sorry"

mtheorem finset_1_cl_10:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1", "x5 be objectHIDDENM1", "x6 be objectHIDDENM1", "x7 be objectHIDDENM1", "x8 be objectHIDDENM1"
"cluster {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "{ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } be finiteFINSET-1V1"
  proof-
    have "{ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } =XBOOLE-0R4 {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K5 x2,x3,x4,x5,x6,x7,x8 }"
      using enumset1_th_22 sorry
    thus "{ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } be finiteFINSET-1V1"
      using finset_1_lm_2 sorry
  qed
qed "sorry"

mtheorem finset_1_cl_11:
  mlet "B be finiteFINSET-1V1\<bar>setHIDDENM2"
"cluster note-that finiteFINSET-1V1 for SubsetSUBSET-1M2-of B"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of B holds it be finiteFINSET-1V1"
  proof-
    have " for A be SubsetSUBSET-1M2-of B holds A be finiteFINSET-1V1"
    proof(rule ballI)
      fix A assume [ty]: "A be SubsetSUBSET-1M2-of B"
      show "A be finiteFINSET-1V1"
      proof-
        have cases: "A be emptyXBOOLE-0V1 or A be  non emptyXBOOLE-0V1"
           sorry
        have case1: "A be emptyXBOOLE-0V1 implies A be finiteFINSET-1V1"
        proof(rule impI)
          assume "A be emptyXBOOLE-0V1"
          thus "A be finiteFINSET-1V1"
             sorry
        qed
        have case2: "A be  non emptyXBOOLE-0V1 implies A be finiteFINSET-1V1"
        proof(rule impI)
          assume "A be  non emptyXBOOLE-0V1"
          then obtain x1 where
            [ty]:"x1 be objectHIDDENM1" and 
            A1: "x1 inHIDDENR3 A"
             sorry
          obtain p where
            [ty]:"p be FunctionFUNCT-1M1" and 
            A2: "rngFUNCT-1K2 p =XBOOLE-0R4 B"and A3: "domRELAT-1K1 p inTARSKIR2 omegaORDINAL1K4"
            using finset_1_def_1 sorry
          let ?F = "\<lambda>Lamb1. p .FUNCT-1K1 Lamb1"
          let ?G = "\<lambda>Lamb1. x1"
          let ?P = "\<lambda>Lamb1. p .FUNCT-1K1 Lamb1 inTARSKIR2 A"
          obtain q where
            [ty]:"q be FunctionFUNCT-1M1" and 
            A4: "domRELAT-1K1 q =XBOOLE-0R4 domRELAT-1K1 p"and A5: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 p implies (?P(x) implies q .FUNCT-1K1 x =XBOOLE-0R4 ?F(x)) & ( not ?P(x) implies q .FUNCT-1K1 x =HIDDENR1 ?G(x))"
            using partfun1_sch_1 sorry
          have " for y be objectHIDDENM1 holds (y inHIDDENR3 A implies ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 q & y =HIDDENR1 q .FUNCT-1K1 x)) & (( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 q & y =HIDDENR1 q .FUNCT-1K1 x) implies y inHIDDENR3 A)"
          proof(rule ballI,rule conjMI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            show "y inHIDDENR3 A implies ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 q & y =HIDDENR1 q .FUNCT-1K1 x)"
            proof-
              have "y inHIDDENR3 A implies ( ex tVar6 be objectHIDDENM1 st tVar6 inHIDDENR3 domRELAT-1K1 q & y =HIDDENR1 q .FUNCT-1K1 tVar6)"
              proof(rule impI)
                assume A6: "y inHIDDENR3 A"
                then obtain x where
                  [ty]:"x be objectHIDDENM1" and 
                  A7: "x inHIDDENR3 domRELAT-1K1 p"and A8: "p .FUNCT-1K1 x =HIDDENR1 y"
                  using A2 funct_1_def_3 sorry
                show " ex tVar6 be objectHIDDENM1 st tVar6 inHIDDENR3 domRELAT-1K1 q & y =HIDDENR1 q .FUNCT-1K1 tVar6"
                proof(rule bexI[of _ "x"],rule conjMI)
                  show "x inHIDDENR3 domRELAT-1K1 q"
                    using A4 A7 sorry
                  show "y =HIDDENR1 q .FUNCT-1K1 x"
                    using A5 A6 A7 A8 sorry
                qed "sorry"
              qed
              thus " ?thesis "
                 sorry
            qed
            assume Given: " ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 q & y =HIDDENR1 q .FUNCT-1K1 x"
            then obtain x where
              [ty]:"x be objectHIDDENM1" and 
              A9: "x inHIDDENR3 domRELAT-1K1 q"and A10: "y =HIDDENR1 q .FUNCT-1K1 x"
               sorry
            show "y inHIDDENR3 A"
            proof-
              have cases: "p .FUNCT-1K1 x inTARSKIR2 A or  not p .FUNCT-1K1 x inTARSKIR2 A"
                 sorry
              have case1: "p .FUNCT-1K1 x inTARSKIR2 A implies y inHIDDENR3 A"
              proof(rule impI)
                assume "p .FUNCT-1K1 x inTARSKIR2 A"
                thus "y inHIDDENR3 A"
                  using A4 A5 A9 A10 sorry
              qed
              have case2: " not p .FUNCT-1K1 x inTARSKIR2 A implies y inHIDDENR3 A"
              proof(rule impI)
                assume " not p .FUNCT-1K1 x inTARSKIR2 A"
                thus "y inHIDDENR3 A"
                  using A1 A4 A5 A9 A10 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed "sorry"
          then have "rngFUNCT-1K2 q =XBOOLE-0R4 A"
            using funct_1_def_3 sorry
          thus "A be finiteFINSET-1V1"
            using A3 A4 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finset_1_cl_12:
  mlet "X be finiteFINSET-1V1\<bar>setHIDDENM2", "Y be finiteFINSET-1V1\<bar>setHIDDENM2"
"cluster X \\/XBOOLE-0K2 Y as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "X \\/XBOOLE-0K2 Y be finiteFINSET-1V1"
    using finset_1_lm_2 sorry
qed "sorry"

mtheorem finset_1_th_1:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds A c=TARSKIR1 B & B be finiteFINSET-1V1 implies A be finiteFINSET-1V1"
   sorry

mtheorem finset_1_th_2:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds A be finiteFINSET-1V1 & B be finiteFINSET-1V1 implies A \\/XBOOLE-0K2 B be finiteFINSET-1V1"
   sorry

mtheorem finset_1_cl_13:
  mlet "A be setHIDDENM2", "B be finiteFINSET-1V1\<bar>setHIDDENM2"
"cluster A /\\XBOOLE-0K3 B as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "A /\\XBOOLE-0K3 B be finiteFINSET-1V1"
  proof-
    have "A /\\XBOOLE-0K3 B c=TARSKIR1 B"
      using xboole_1_th_17 sorry
    thus "A /\\XBOOLE-0K3 B be finiteFINSET-1V1"
       sorry
  qed
qed "sorry"

mtheorem finset_1_cl_14:
  mlet "A be finiteFINSET-1V1\<bar>setHIDDENM2", "B be setHIDDENM2"
"cluster A /\\XBOOLE-0K3 B as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "A /\\XBOOLE-0K3 B be finiteFINSET-1V1"
     sorry
qed "sorry"

mtheorem finset_1_cl_15:
  mlet "A be finiteFINSET-1V1\<bar>setHIDDENM2", "B be setHIDDENM2"
"cluster A \\SUBSET-1K6 B as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "A \\SUBSET-1K6 B be finiteFINSET-1V1"
     sorry
qed "sorry"

mtheorem finset_1_th_3:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds A be finiteFINSET-1V1 implies A /\\XBOOLE-0K3 B be finiteFINSET-1V1"
   sorry

mtheorem finset_1_th_4:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds A be finiteFINSET-1V1 implies A \\SUBSET-1K6 B be finiteFINSET-1V1"
   sorry

mtheorem finset_1_cl_16:
  mlet "f be FunctionFUNCT-1M1", "A be finiteFINSET-1V1\<bar>setHIDDENM2"
"cluster f .:FUNCT-1K5 A as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "f .:FUNCT-1K5 A be finiteFINSET-1V1"
  proof-
    let ?B = "domRELAT-1K1 f /\\XBOOLE-0K3 A"
    obtain p where
      [ty]:"p be FunctionFUNCT-1M1" and 
      A1: "rngFUNCT-1K2 p =XBOOLE-0R4 ?B"and A2: "domRELAT-1K1 p inTARSKIR2 omegaORDINAL1K4"
      using finset_1_def_1 sorry
    have Cut367: "rngFUNCT-1K2 (f *FUNCT-1K3 p) =XBOOLE-0R4 f .:FUNCT-1K5 ?B"
      using A1 relat_1_th_127 sorry
    have "rngFUNCT-1K2 (f *FUNCT-1K3 p) =XBOOLE-0R4 f .:FUNCT-1K5 A & domRELAT-1K1 (f *FUNCT-1K3 p) inTARSKIR2 omegaORDINAL1K4"
    proof(rule conjMI)
      show "rngFUNCT-1K2 (f *FUNCT-1K3 p) =XBOOLE-0R4 f .:FUNCT-1K5 A"
        using relat_1_th_112 Cut367 sorry
      show "domRELAT-1K1 (f *FUNCT-1K3 p) inTARSKIR2 omegaORDINAL1K4"
        using A1 A2 relat_1_th_27 xboole_1_th_17 sorry
    qed
    thus "f .:FUNCT-1K5 A be finiteFINSET-1V1"
      using bexI[of _ "f *FUNCT-1K3 p"] finset_1_def_1 sorry
  qed
qed "sorry"

mtheorem finset_1_th_5:
" for A be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds A be finiteFINSET-1V1 implies f .:FUNCT-1K5 A be finiteFINSET-1V1"
   sorry

reserve O for "OrdinalORDINAL1M3"
mtheorem finset_1_th_6:
" for A be setHIDDENM2 holds A be finiteFINSET-1V1 implies ( for X be Subset-FamilySETFAM-1M1-of A holds X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex x be setHIDDENM2 st x inTARSKIR2 X & ( for B be setHIDDENM2 holds B inTARSKIR2 X implies (x c=TARSKIR1 B implies B =XBOOLE-0R4 x))))"
proof-
  have " for A be setHIDDENM2 holds A be finiteFINSET-1V1 implies ( for X be Subset-FamilySETFAM-1M1-of A holds X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex tVar11 be setHIDDENM2 st tVar11 inTARSKIR2 X & ( for B be setHIDDENM2 holds  not ((B inTARSKIR2 X & tVar11 c=TARSKIR1 B) &  not B =XBOOLE-0R4 tVar11))))"
  proof(rule ballI,rule impI,rule ballI,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    assume A1: "A be finiteFINSET-1V1"
    fix X assume [ty]: "X be Subset-FamilySETFAM-1M1-of A"
    assume A2: "X <>HIDDENR2 {}XBOOLE-0K1"
    obtain p where
      [ty]:"p be FunctionFUNCT-1M1" and 
      A3: "rngFUNCT-1K2 p =XBOOLE-0R4 A"and A4: "domRELAT-1K1 p inTARSKIR2 omegaORDINAL1K4"
      using A1 sorry
    let ?P = "\<lambda>Lamb1. p .:FUNCT-1K5 Lamb1 inTARSKIR2 X"
    obtain G where
      [ty]:"G be setHIDDENM2" and 
      A5: " for x be setHIDDENM2 holds x inTARSKIR2 G iff x inTARSKIR2 boolSETFAM-1K9 (domRELAT-1K1 p) & ?P(x)"
      using xfamily_sch_1 sorry
    have "G c=TARSKIR1 boolSETFAM-1K9 (domRELAT-1K1 p)"
      using A5 sorry
    then obtain GX where 
      [ty]:"GX be Subset-FamilySETFAM-1M1-of domRELAT-1K1 p" and GXDef:"GX = G"
       sorry
    let ?x = "the ElementSUBSET-1M1-of X"
    have "?x be SubsetSUBSET-1M2-of A"
      using A2 tarski_def_3 sorry
    then have A6: "p .:FUNCT-1K5 p \<inverse>FUNCT-1K6 ?x =XBOOLE-0R4 ?x"
      using A3 funct_1_th_77 sorry
    have "p \<inverse>FUNCT-1K6 ?x c=TARSKIR1 domRELAT-1K1 p"
      using relat_1_th_132 sorry
    then have A7: "GX <>HIDDENR2 {}XBOOLE-0K1"
      using A2 A5 A6 sorry
    let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 omegaORDINAL1K4 implies ( for X be Subset-FamilySETFAM-1M1-of Lamb1 holds X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex x be setHIDDENM2 st x inTARSKIR2 X & ( for B be setHIDDENM2 holds B inTARSKIR2 X implies (x c=TARSKIR1 B implies B =XBOOLE-0R4 x))))"
    have A8: "?P(0ORDINAL1K5)"
    proof-
      have "0ORDINAL1K5 inTARSKIR2 omegaORDINAL1K4 implies ( for X be Subset-FamilySETFAM-1M1-of 0ORDINAL1K5 holds X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex tVar8 be setHIDDENM2 st tVar8 inTARSKIR2 X & ( for B be setHIDDENM2 holds  not ((B inTARSKIR2 X & tVar8 c=TARSKIR1 B) &  not B =XBOOLE-0R4 tVar8))))"
      proof(rule impI,rule ballI,rule impI)
        assume "0ORDINAL1K5 inTARSKIR2 omegaORDINAL1K4"
        fix X assume [ty]: "X be Subset-FamilySETFAM-1M1-of 0ORDINAL1K5"
        assume "X <>HIDDENR2 {}XBOOLE-0K1"
        then have A9: "X =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
          using zfmisc_1_th_1 zfmisc_1_th_33 sorry
        show " ex tVar8 be setHIDDENM2 st tVar8 inTARSKIR2 X & ( for B be setHIDDENM2 holds  not ((B inTARSKIR2 X & tVar8 c=TARSKIR1 B) &  not B =XBOOLE-0R4 tVar8))"
        proof(rule bexI[of _ "{}XBOOLE-0K1"])
          show "{}XBOOLE-0K1 inTARSKIR2 X & ( for B be setHIDDENM2 holds  not ((B inTARSKIR2 X & {}XBOOLE-0K1 c=TARSKIR1 B) &  not B =XBOOLE-0R4 {}XBOOLE-0K1))"
            using A9 tarski_def_1 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A10: " for O be OrdinalORDINAL1M3 holds ?P(O) implies ?P(succORDINAL1K1 O)"
    proof-
      have " for O be OrdinalORDINAL1M3 holds (O inTARSKIR2 omegaORDINAL1K4 implies ( for X be Subset-FamilySETFAM-1M1-of O holds X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex x be setHIDDENM2 st x inTARSKIR2 X & ( for B be setHIDDENM2 holds B inTARSKIR2 X implies (x c=TARSKIR1 B implies B =XBOOLE-0R4 x))))) implies (succORDINAL1K1 O inTARSKIR2 omegaORDINAL1K4 implies ( for X be Subset-FamilySETFAM-1M1-of succORDINAL1K1 O holds X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex x be setHIDDENM2 st x inTARSKIR2 X & ( for B be setHIDDENM2 holds B inTARSKIR2 X implies (x c=TARSKIR1 B implies B =XBOOLE-0R4 x)))))"
      proof(rule ballI,rule impI)
        fix O assume [ty]: "O be OrdinalORDINAL1M3"
        assume A11: "O inTARSKIR2 omegaORDINAL1K4 implies ( for X be Subset-FamilySETFAM-1M1-of O holds X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex x be setHIDDENM2 st x inTARSKIR2 X & ( for B be setHIDDENM2 holds B inTARSKIR2 X implies (x c=TARSKIR1 B implies B =XBOOLE-0R4 x))))"
        show "succORDINAL1K1 O inTARSKIR2 omegaORDINAL1K4 implies ( for X be Subset-FamilySETFAM-1M1-of succORDINAL1K1 O holds X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex x be setHIDDENM2 st x inTARSKIR2 X & ( for B be setHIDDENM2 holds B inTARSKIR2 X implies (x c=TARSKIR1 B implies B =XBOOLE-0R4 x))))"
        proof-
          have "succORDINAL1K1 O inTARSKIR2 omegaORDINAL1K4 implies ( for X be Subset-FamilySETFAM-1M1-of succORDINAL1K1 O holds X <>HIDDENR2 {}XBOOLE-0K1 implies  not ( for x be setHIDDENM2 holds  not (x inTARSKIR2 X & ( for B be setHIDDENM2 holds  not ((B inTARSKIR2 X & x c=TARSKIR1 B) &  not B =XBOOLE-0R4 x)))))"
          proof(rule impI,rule ballI,rule impI)
            assume "succORDINAL1K1 O inTARSKIR2 omegaORDINAL1K4"
            then have A12: "succORDINAL1K1 O c=ORDINAL1R1 omegaORDINAL1K4"
              using ordinal1_def_2 sorry
            fix X assume [ty]: "X be Subset-FamilySETFAM-1M1-of succORDINAL1K1 O"
            assume A13: "X <>HIDDENR2 {}XBOOLE-0K1"
            let ?P = "\<lambda>Lamb1.  ex A be setHIDDENM2 st A inTARSKIR2 X & Lamb1 =XBOOLE-0R4 A \\SUBSET-1K6 {TARSKIK1 O}"
            obtain X1 where
              [ty]:"X1 be setHIDDENM2" and 
              A14: " for x be setHIDDENM2 holds x inTARSKIR2 X1 iff x inTARSKIR2 boolSETFAM-1K9 O & ?P(x)"
              using xfamily_sch_1 sorry
            have "X1 c=TARSKIR1 boolSETFAM-1K9 O"
              using A14 sorry
            then obtain X2 where 
              [ty]:"X2 be Subset-FamilySETFAM-1M1-of O" and X2Def:"X2 = X1"
               sorry
            let ?y = "the ElementSUBSET-1M1-of X"
            have "?y be SubsetSUBSET-1M2-of succORDINAL1K1 O"
              using A13 tarski_def_3 sorry
            then have "?y \\SUBSET-1K6 {TARSKIK1 O} c=TARSKIR1 (O \\/XBOOLE-0K2 {TARSKIK1 O})\\SUBSET-1K6 {TARSKIK1 O}"
              using xboole_1_th_33 sorry
            then have A15: "?y \\SUBSET-1K6 {TARSKIK1 O} c=TARSKIR1 O \\SUBSET-1K6 {TARSKIK1 O}"
              using xboole_1_th_40 sorry
            have A16: "O inTARSKIR2 succORDINAL1K1 O"
              using ordinal1_th_6 sorry
            have A17: " not O inTARSKIR2 O"
               sorry
            then have "?y \\SUBSET-1K6 {TARSKIK1 O} c=TARSKIR1 O"
              using A15 zfmisc_1_th_57 sorry
            then have "X2 <>HIDDENR2 {}XBOOLE-0K1"
              using A13 A14 sorry
            then obtain Z where
              [ty]:"Z be setHIDDENM2" and 
              A18: "Z inTARSKIR2 X2"and A19: " for B be setHIDDENM2 holds B inTARSKIR2 X2 implies (Z c=TARSKIR1 B implies B =XBOOLE-0R4 Z)"
              using A11 A12 A16 sorry
            obtain X1 where
              [ty]:"X1 be setHIDDENM2" and 
              A20: "X1 inTARSKIR2 X"and A21: "Z =XBOOLE-0R4 X1 \\SUBSET-1K6 {TARSKIK1 O}"
              using A14 A18 sorry
            have A22: "O inTARSKIR2 {TARSKIK1 O}"
              using tarski_def_1 sorry
            then have A23: " not O inTARSKIR2 Z"
              using A21 xboole_0_def_5 sorry
            have A24: "Z \\/XBOOLE-0K2 {TARSKIK1 O} inTARSKIR2 X implies ( ex A be setHIDDENM2 st  not ( for x be setHIDDENM2 holds  not (x inTARSKIR2 X & ( for B be setHIDDENM2 holds  not ((B inTARSKIR2 X & x c=TARSKIR1 B) &  not B =XBOOLE-0R4 x)))))"
            proof(rule impI)
              assume A25: "Z \\/XBOOLE-0K2 {TARSKIK1 O} inTARSKIR2 X"
              obtain A where 
                [ty]:"A be setHIDDENM2" and ADef:"A = Z \\/XBOOLE-0K2 {TARSKIK1 O}"
                 sorry
              show " ex A be setHIDDENM2 st  not ( for x be setHIDDENM2 holds  not (x inTARSKIR2 X & ( for B be setHIDDENM2 holds  not ((B inTARSKIR2 X & x c=TARSKIR1 B) &  not B =XBOOLE-0R4 x))))"
              proof(rule bexI[of _ "A"])
                have " for B be setHIDDENM2 holds B inTARSKIR2 X implies (A c=TARSKIR1 B implies B =XBOOLE-0R4 A)"
                proof-
                  have " for B be setHIDDENM2 holds B inTARSKIR2 X implies (A c=TARSKIR1 B implies B =XBOOLE-0R4 A)"
                  proof(rule ballI,rule impI,rule impI)
                    fix B assume [ty]: "B be setHIDDENM2"
                    assume A26: "B inTARSKIR2 X"
                    assume A27: "A c=TARSKIR1 B"
                    have A28: "O inTARSKIR2 B implies B =XBOOLE-0R4 A"
                    proof(rule impI)
                      assume A29: "O inTARSKIR2 B"
                      let ?Y = "B \\SUBSET-1K6 {TARSKIK1 O}"
                      have "{TARSKIK1 O} c=TARSKIR1 B"
                        using A29 zfmisc_1_th_31 sorry
                      then have A30: "B =XBOOLE-0R4 ?Y \\/XBOOLE-0K2 {TARSKIK1 O}"
                        using xboole_1_th_45 sorry
                      have "A \\SUBSET-1K6 {TARSKIK1 O} c=TARSKIR1 ?Y"
                        using A27 xboole_1_th_33 sorry
                      then have A31: "Z \\SUBSET-1K6 {TARSKIK1 O} c=TARSKIR1 ?Y"
                        using xboole_1_th_40 sorry
                      have " not O inTARSKIR2 Z"
                        using A21 A22 xboole_0_def_5 sorry
                      then have A32: "Z c=TARSKIR1 ?Y"
                        using A31 zfmisc_1_th_57 sorry
                      have "?Y c=TARSKIR1 (O \\/XBOOLE-0K2 {TARSKIK1 O})\\SUBSET-1K6 {TARSKIK1 O}"
                        using A26 xboole_1_th_33 sorry
                      then have "?Y c=TARSKIR1 O \\SUBSET-1K6 {TARSKIK1 O}"
                        using xboole_1_th_40 sorry
                      then have "?Y c=TARSKIR1 O"
                        using A17 zfmisc_1_th_57 sorry
                      then have "?Y inTARSKIR2 X2"
                        using A14 A26 sorry
                      thus "B =XBOOLE-0R4 A"
                        using A19 A30 A32 sorry
                    qed
                    have " not O inTARSKIR2 B implies  False "
                    proof(rule impI)
                      assume A33: " not O inTARSKIR2 B"
                      have "O inTARSKIR2 {TARSKIK1 O}"
                        using tarski_def_1 sorry
                      then have "O inTARSKIR2 A"
                        using xboole_0_def_3 sorry
                      thus " False "
                        using A27 A33 sorry
                    qed
                    thus "B =XBOOLE-0R4 A"
                      using A28 sorry
                  qed "sorry"
                  thus " ?thesis "
                     sorry
                qed
                thus " not ( for x be setHIDDENM2 holds  not (x inTARSKIR2 X & ( for B be setHIDDENM2 holds  not ((B inTARSKIR2 X & x c=TARSKIR1 B) &  not B =XBOOLE-0R4 x))))"
                  using A25 sorry
              qed "sorry"
            qed
            have " not Z \\/XBOOLE-0K2 {TARSKIK1 O} inTARSKIR2 X implies ( ex A be setHIDDENM2 st  not ( for x be setHIDDENM2 holds  not (x inTARSKIR2 X & ( for B be setHIDDENM2 holds  not ((B inTARSKIR2 X & x c=TARSKIR1 B) &  not B =XBOOLE-0R4 x)))))"
            proof(rule impI)
              assume A34: " not Z \\/XBOOLE-0K2 {TARSKIK1 O} inTARSKIR2 X"
              obtain A where 
                [ty]:"A be setHIDDENM2" and ADef:"A = Z"
                 sorry
              show " ex A be setHIDDENM2 st  not ( for x be setHIDDENM2 holds  not (x inTARSKIR2 X & ( for B be setHIDDENM2 holds  not ((B inTARSKIR2 X & x c=TARSKIR1 B) &  not B =XBOOLE-0R4 x))))"
              proof(rule bexI[of _ "A"])
                have "O inTARSKIR2 X1 implies  False "
                proof(rule impI)
                  assume "O inTARSKIR2 X1"
                  then have "X1 =HIDDENR1 X1 \\/XBOOLE-0K2 {TARSKIK1 O}"
                    using zfmisc_1_th_40 sorry
                  also have "... = Z \\/XBOOLE-0K2 {TARSKIK1 O}"
                    using A21 xboole_1_th_39 sorry
                  finally have "X1 =HIDDENR1 Z \\/XBOOLE-0K2 {TARSKIK1 O}"
                     sorry
                  thus " False "
                    using A20 A34 sorry
                qed
                then have A35: "A inTARSKIR2 X"
                  using A20 A21 zfmisc_1_th_57 sorry
                have " for B be setHIDDENM2 holds B inTARSKIR2 X implies (A c=TARSKIR1 B implies B =XBOOLE-0R4 A)"
                proof-
                  have " for B be setHIDDENM2 holds B inTARSKIR2 X implies (A c=TARSKIR1 B implies B =XBOOLE-0R4 A)"
                  proof(rule ballI,rule impI,rule impI)
                    fix B assume [ty]: "B be setHIDDENM2"
                    assume A36: "B inTARSKIR2 X"
                    then have "B \\SUBSET-1K6 {TARSKIK1 O} c=TARSKIR1 (O \\/XBOOLE-0K2 {TARSKIK1 O})\\SUBSET-1K6 {TARSKIK1 O}"
                      using xboole_1_th_33 sorry
                    then have "B \\SUBSET-1K6 {TARSKIK1 O} c=TARSKIR1 O \\SUBSET-1K6 {TARSKIK1 O}"
                      using xboole_1_th_40 sorry
                    then have "B \\SUBSET-1K6 {TARSKIK1 O} c=TARSKIR1 O"
                      using A17 zfmisc_1_th_57 sorry
                    then have A37: "B \\SUBSET-1K6 {TARSKIK1 O} inTARSKIR2 X2"
                      using A14 A36 sorry
                    assume A38: "A c=TARSKIR1 B"
                    then have "A \\SUBSET-1K6 {TARSKIK1 O} c=TARSKIR1 B \\SUBSET-1K6 {TARSKIK1 O}"
                      using xboole_1_th_33 sorry
                    then have A39: "A c=TARSKIR1 B \\SUBSET-1K6 {TARSKIK1 O}"
                      using A23 zfmisc_1_th_57 sorry
                    have A40: "O inTARSKIR2 B implies  False "
                    proof(rule impI)
                      assume A41: "O inTARSKIR2 B"
                      have "A \\/XBOOLE-0K2 {TARSKIK1 O} =HIDDENR1 (B \\SUBSET-1K6 {TARSKIK1 O})\\/XBOOLE-0K2 {TARSKIK1 O}"
                        using A19 A37 A39 sorry
                      also have "... = B \\/XBOOLE-0K2 {TARSKIK1 O}"
                        using xboole_1_th_39 sorry
                      also have "... = B"
                        using A41 zfmisc_1_th_40 sorry
                      finally have "A \\/XBOOLE-0K2 {TARSKIK1 O} =HIDDENR1 B"
                         sorry
                      thus " False "
                        using A34 A36 sorry
                    qed
                    have A42: "B c=TARSKIR1 O"
                    proof-
                      have " for x be objectHIDDENM1 holds x inHIDDENR3 B implies x inHIDDENR3 O"
                      proof(rule ballI,rule impI)
                        fix x assume [ty]: "x be objectHIDDENM1"
                        assume A43: "x inHIDDENR3 B"
                        have "x inHIDDENR3 O or x inHIDDENR3 {TARSKIK1 O}"
                          using A36 A43 xboole_0_def_3 sorry
                        thus "x inHIDDENR3 O"
                          using A40 A43 tarski_def_1 sorry
                      qed "sorry"
                      thus "B c=TARSKIR1 O"
                        using tarski_def_3 sorry
                    qed
                    have "B \\SUBSET-1K6 {TARSKIK1 O} =XBOOLE-0R4 B"
                      using A40 zfmisc_1_th_57 sorry
                    then have "B inTARSKIR2 X2"
                      using A14 A36 A42 sorry
                    thus "B =XBOOLE-0R4 A"
                      using A19 A38 sorry
                  qed "sorry"
                  thus " ?thesis "
                     sorry
                qed
                thus " not ( for x be setHIDDENM2 holds  not (x inTARSKIR2 X & ( for B be setHIDDENM2 holds  not ((B inTARSKIR2 X & x c=TARSKIR1 B) &  not B =XBOOLE-0R4 x))))"
                  using A35 sorry
              qed "sorry"
            qed
            thus " not ( for x be setHIDDENM2 holds  not (x inTARSKIR2 X & ( for B be setHIDDENM2 holds  not ((B inTARSKIR2 X & x c=TARSKIR1 B) &  not B =XBOOLE-0R4 x))))"
              using A24 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A44: " for O be OrdinalORDINAL1M3 holds (O <>HIDDENR2 0ORDINAL1K5 & O be limit-ordinalORDINAL1V4) & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 O implies ?P(B)) implies ?P(O)"
    proof-
      have " for O be OrdinalORDINAL1M3 holds O <>HIDDENR2 0ORDINAL1K5 & (O be limit-ordinalORDINAL1V4 & (( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 O implies (B inTARSKIR2 omegaORDINAL1K4 implies ( for X be Subset-FamilySETFAM-1M1-of B holds X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex x be setHIDDENM2 st x inTARSKIR2 X & ( for Bc be setHIDDENM2 holds Bc inTARSKIR2 X implies (x c=TARSKIR1 Bc implies Bc =XBOOLE-0R4 x)))))) & O inTARSKIR2 omegaORDINAL1K4)) implies ( for X be Subset-FamilySETFAM-1M1-of O holds  not ( not X <>HIDDENR2 {}XBOOLE-0K1 & ( for x be setHIDDENM2 holds  not (x inTARSKIR2 X & ( for B be setHIDDENM2 holds  not ((B inTARSKIR2 X & x c=TARSKIR1 B) &  not B =XBOOLE-0R4 x))))))"
      proof(rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix O assume [ty]: "O be OrdinalORDINAL1M3"
        assume A45: "O <>HIDDENR2 0ORDINAL1K5"
          and A46: "O be limit-ordinalORDINAL1V4"
          and " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 O implies ?P(B)"
          and A47: "O inTARSKIR2 omegaORDINAL1K4"
        have "{}XBOOLE-0K1 inTARSKIR2 O"
          using A45 ordinal1_th_14 sorry
        then have "omegaORDINAL1K4 c=ORDINAL1R1 O"
          using A46 ordinal1_def_11 sorry
        then have "O inTARSKIR2 O"
          using A47 sorry
        thus " for X be Subset-FamilySETFAM-1M1-of O holds  not ( not X <>HIDDENR2 {}XBOOLE-0K1 & ( for x be setHIDDENM2 holds  not (x inTARSKIR2 X & ( for B be setHIDDENM2 holds  not ((B inTARSKIR2 X & x c=TARSKIR1 B) &  not B =XBOOLE-0R4 x)))))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for O be OrdinalORDINAL1M3 holds ?P(O)"
      using ordinal2_sch_1 A8 A10 A44 sorry
    then obtain g where
      [ty]:"g be setHIDDENM2" and 
      A48: "g inTARSKIR2 GX"and A49: " for B be setHIDDENM2 holds B inTARSKIR2 GX implies (g c=TARSKIR1 B implies B =XBOOLE-0R4 g)"
      using A4 A7 sorry
    show " ex tVar11 be setHIDDENM2 st tVar11 inTARSKIR2 X & ( for B be setHIDDENM2 holds  not ((B inTARSKIR2 X & tVar11 c=TARSKIR1 B) &  not B =XBOOLE-0R4 tVar11))"
    proof(rule bexI[of _ "p .:FUNCT-1K5 g"])
      have " for B be setHIDDENM2 holds B inTARSKIR2 X implies (p .:FUNCT-1K5 g c=TARSKIR1 B implies B =XBOOLE-0R4 p .:FUNCT-1K5 g)"
      proof(rule ballI,rule impI,rule impI)
        fix B assume [ty]: "B be setHIDDENM2"
        assume A50: "B inTARSKIR2 X"
        assume "p .:FUNCT-1K5 g c=TARSKIR1 B"
        then have A51: "p \<inverse>FUNCT-1K6 (p .:FUNCT-1K5 g) c=TARSKIR1 p \<inverse>FUNCT-1K6 B"
          using relat_1_th_143 sorry
        have A52: "g c=TARSKIR1 p \<inverse>FUNCT-1K6 (p .:FUNCT-1K5 g)"
          using A48 funct_1_th_76 sorry
        have A53: "p .:FUNCT-1K5 p \<inverse>FUNCT-1K6 B =XBOOLE-0R4 B"
          using A3 A50 funct_1_th_77 sorry
        have "p \<inverse>FUNCT-1K6 B c=TARSKIR1 domRELAT-1K1 p"
          using relat_1_th_132 sorry
        then have "p \<inverse>FUNCT-1K6 B inTARSKIR2 GX"
          using A5 A50 A53 sorry
        thus "B =XBOOLE-0R4 p .:FUNCT-1K5 g"
          using A49 A51 A52 A53 xboole_1_th_1 sorry
      qed "sorry"
      thus "p .:FUNCT-1K5 g inTARSKIR2 X & ( for B be setHIDDENM2 holds  not ((B inTARSKIR2 X & p .:FUNCT-1K5 g c=TARSKIR1 B) &  not B =XBOOLE-0R4 p .:FUNCT-1K5 g))"
        using A5 A48 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem finset_1_sch_2:
  fixes Af0 Pp1 
  assumes
[ty]: "Af0 be setHIDDENM2" and
   A1: "Af0 be finiteFINSET-1V1" and
   A2: "Pp1({}XBOOLE-0K1)" and
   A3: " for x be setHIDDENM2 holds  for B be setHIDDENM2 holds (x inTARSKIR2 Af0 & B c=TARSKIR1 Af0) & Pp1(B) implies Pp1(B \\/XBOOLE-0K2 {TARSKIK1 x})"
  shows "Pp1(Af0)"
  proof-
    have "Af0 <>HIDDENR2 {}XBOOLE-0K1 implies Pp1(Af0)"
    proof(rule impI)
      assume "Af0 <>HIDDENR2 {}XBOOLE-0K1"
      let ?R = "\<lambda>Lamb1.  ex B be setHIDDENM2 st B =XBOOLE-0R4 Lamb1 & Pp1(B)"
      obtain G where
        [ty]:"G be setHIDDENM2" and 
        A4: " for x be setHIDDENM2 holds x inTARSKIR2 G iff x inTARSKIR2 boolSETFAM-1K9 Af0 & ?R(x)"
        using xfamily_sch_1 sorry
      have "G c=TARSKIR1 boolSETFAM-1K9 Af0"
        using A4 sorry
      then obtain GA where 
        [ty]:"GA be Subset-FamilySETFAM-1M1-of Af0" and GADef:"GA = G"
         sorry
      have "{}XBOOLE-0K1 c=RELAT-1R2 Af0"
         sorry
      then have "GA <>HIDDENR2 {}XBOOLE-0K1"
        using A2 A4 sorry
      then obtain B where
        [ty]:"B be setHIDDENM2" and 
        A5: "B inTARSKIR2 GA"and A6: " for X be setHIDDENM2 holds X inTARSKIR2 GA implies (B c=TARSKIR1 X implies B =XBOOLE-0R4 X)"
        using A1 finset_1_th_6 sorry
      have A7: " ex A be setHIDDENM2 st A =XBOOLE-0R4 B & Pp1(A)"
        using A4 A5 sorry
      have "B <>HIDDENR2 Af0 implies  False "
      proof(rule impI)
        let ?x = "the ElementSUBSET-1M1-of Af0 \\SUBSET-1K6 B"
        assume "B <>HIDDENR2 Af0"
        then have " not Af0 c=TARSKIR1 B"
          using A5 sorry
        then have A8: "Af0 \\SUBSET-1K6 B <>HIDDENR2 {}XBOOLE-0K1"
          using xboole_1_th_37 sorry
        then have A9: "?x inTARSKIR2 Af0"
          using xboole_0_def_5 sorry
        then have A10: "Pp1(B \\/XBOOLE-0K2 {TARSKIK1 ?x})"
          using A3 A5 A7 sorry
        have "{TARSKIK1 ?x} c=TARSKIR1 Af0"
          using A9 zfmisc_1_th_31 sorry
        then have "B \\/XBOOLE-0K2 {TARSKIK1 ?x} c=TARSKIR1 Af0"
          using A5 xboole_1_th_8 sorry
        then have A11: "B \\/XBOOLE-0K2 {TARSKIK1 ?x} inTARSKIR2 GA"
          using A4 A10 sorry
        have " not ?x inTARSKIR2 B"
          using A8 xboole_0_def_5 sorry
        then have " not {TARSKIK1 ?x} c=TARSKIR1 B"
          using zfmisc_1_th_31 sorry
        then have "B \\/XBOOLE-0K2 {TARSKIK1 ?x} <>HIDDENR2 B"
          using xboole_1_th_7 sorry
        thus " False "
          using A6 A11 xboole_1_th_7 sorry
      qed
      thus "Pp1(Af0)"
        using A7 sorry
    qed
    thus "Pp1(Af0)"
      using A2 sorry
  qed

mlemma finset_1_lm_3:
" for A be setHIDDENM2 holds A be finiteFINSET-1V1 & ( for X be setHIDDENM2 holds X inTARSKIR2 A implies X be finiteFINSET-1V1) implies unionTARSKIK3 A be finiteFINSET-1V1"
proof-
  have " for A be setHIDDENM2 holds A be finiteFINSET-1V1 & ( for X be setHIDDENM2 holds X inTARSKIR2 A implies X be finiteFINSET-1V1) implies unionTARSKIK3 A be finiteFINSET-1V1"
  proof(rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    assume A1: "A be finiteFINSET-1V1"
      and A2: " for X be setHIDDENM2 holds X inTARSKIR2 A implies X be finiteFINSET-1V1"
    let ?P = "\<lambda>Lamb1.  ex B be setHIDDENM2 st B =XBOOLE-0R4 Lamb1 & unionTARSKIK3 B be finiteFINSET-1V1"
    obtain G where
      [ty]:"G be setHIDDENM2" and 
      A3: " for x be setHIDDENM2 holds x inTARSKIR2 G iff x inTARSKIR2 boolSETFAM-1K9 A & ?P(x)"
      using xfamily_sch_1 sorry
    let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 G"
    have "{}XBOOLE-0K1 c=RELAT-1R2 A"
       sorry
    then have A4: "?P({}XBOOLE-0K1)"
      using A3 zfmisc_1_th_2 sorry
    have A5: " for x be setHIDDENM2 holds  for B be setHIDDENM2 holds (x inTARSKIR2 A & B c=TARSKIR1 A) & ?P(B) implies ?P(B \\/XBOOLE-0K2 {TARSKIK1 x})"
    proof-
      have " for x be setHIDDENM2 holds  for B be setHIDDENM2 holds x inTARSKIR2 A & (B c=TARSKIR1 A & B inTARSKIR2 G) implies B \\/XBOOLE-0K2 {TARSKIK1 x} inTARSKIR2 G"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        fix x assume [ty]: "x be setHIDDENM2"
        fix B assume [ty]: "B be setHIDDENM2"
        assume A6: "x inTARSKIR2 A"
          and "B c=TARSKIR1 A"
          and A7: "B inTARSKIR2 G"
        have A8: " ex X be setHIDDENM2 st X =XBOOLE-0R4 B & unionTARSKIK3 X be finiteFINSET-1V1"
          using A3 A7 sorry
        have A9: "x be finiteFINSET-1V1"
          using A2 A6 sorry
        have A10: "unionTARSKIK3 (B \\/XBOOLE-0K2 {TARSKIK1 x}) =HIDDENR1 unionTARSKIK3 B \\/XBOOLE-0K2 unionTARSKIK3 {TARSKIK1 x}"
          using zfmisc_1_th_78 sorry
        also have "... = unionTARSKIK3 B \\/XBOOLE-0K2 x"
          using zfmisc_1_th_25 sorry
        finally have "unionTARSKIK3 (B \\/XBOOLE-0K2 {TARSKIK1 x}) =HIDDENR1 unionTARSKIK3 B \\/XBOOLE-0K2 x"
           sorry
        have A11: "{TARSKIK1 x} c=TARSKIR1 A"
          using A6 zfmisc_1_th_31 sorry
        have "B inTARSKIR2 boolSETFAM-1K9 A"
          using A3 A7 sorry
        then have "B \\/XBOOLE-0K2 {TARSKIK1 x} c=TARSKIR1 A"
          using A11 xboole_1_th_8 sorry
        thus "B \\/XBOOLE-0K2 {TARSKIK1 x} inTARSKIR2 G"
          using A3 A8 A9 A10 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "?P(A)"
      using finset_1_sch_2 A1 A4 A5 sorry
    then have " ex X be setHIDDENM2 st X =XBOOLE-0R4 A & unionTARSKIK3 X be finiteFINSET-1V1"
      using A3 sorry
    thus "unionTARSKIK3 A be finiteFINSET-1V1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finset_1_cl_17:
  mlet "A be finiteFINSET-1V1\<bar>setHIDDENM2", "B be finiteFINSET-1V1\<bar>setHIDDENM2"
"cluster [:ZFMISC-1K2 A,B :] as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "[:ZFMISC-1K2 A,B :] be finiteFINSET-1V1"
  proof-
    have A1: " for y be setHIDDENM2 holds [:ZFMISC-1K2 A,{TARSKIK1 y} :] be finiteFINSET-1V1"
    proof(rule ballI)
      fix y assume [ty]: "y be setHIDDENM2"
      let ?F = "\<lambda>Lamb1. [TARSKIK4 Lamb1,y ]"
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A2: "domRELAT-1K1 f =XBOOLE-0R4 A & ( for x be objectHIDDENM1 holds x inHIDDENR3 A implies f .FUNCT-1K1 x =HIDDENR1 ?F(x))"
        using funct_1_sch_3 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f iff x inHIDDENR3 [:ZFMISC-1K2 A,{TARSKIK1 y} :]"
      proof-
        have " for x be objectHIDDENM1 holds (x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 [:ZFMISC-1K2 A,{TARSKIK1 y} :]) & (x inHIDDENR3 [:ZFMISC-1K2 A,{TARSKIK1 y} :] implies x inHIDDENR3 rngFUNCT-1K2 f)"
        proof(rule ballI,rule conjMI)
          fix x assume [ty]: "x be objectHIDDENM1"
          show "x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 [:ZFMISC-1K2 A,{TARSKIK1 y} :]"
          proof(rule impI)
            assume "x inHIDDENR3 rngFUNCT-1K2 f"
            then obtain z where
              [ty]:"z be objectHIDDENM1" and 
              A3: "z inHIDDENR3 domRELAT-1K1 f"and A4: "f .FUNCT-1K1 z =HIDDENR1 x"
              using funct_1_def_3 sorry
            have "x =HIDDENR1 [TARSKIK4 z,y ]"
              using A2 A3 A4 sorry
            thus "x inHIDDENR3 [:ZFMISC-1K2 A,{TARSKIK1 y} :]"
              using A2 A3 zfmisc_1_th_106 sorry
          qed
          show "x inHIDDENR3 [:ZFMISC-1K2 A,{TARSKIK1 y} :] implies x inHIDDENR3 rngFUNCT-1K2 f"
          proof(rule impI)
            assume "x inHIDDENR3 [:ZFMISC-1K2 A,{TARSKIK1 y} :]"
            then obtain x1 x2 where
              [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" and 
              A5: "x1 inHIDDENR3 A"and A6: "x2 inHIDDENR3 {TARSKIK1 y}"and A7: "x =HIDDENR1 [TARSKIK4 x1,x2 ]"
              using zfmisc_1_def_2 sorry
            have "x2 =HIDDENR1 y"
              using A6 tarski_def_1 sorry
            then have "x =HIDDENR1 f .FUNCT-1K1 x1"
              using A2 A5 A7 sorry
            thus "x inHIDDENR3 rngFUNCT-1K2 f"
              using A2 A5 funct_1_def_3 sorry
          qed
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      then have "rngFUNCT-1K2 f =XBOOLE-0R4 [:ZFMISC-1K2 A,{TARSKIK1 y} :]"
        using tarski_th_2 sorry
      then have "f .:FUNCT-1K5 A =XBOOLE-0R4 [:ZFMISC-1K2 A,{TARSKIK1 y} :]"
        using A2 relat_1_th_113 sorry
      thus "[:ZFMISC-1K2 A,{TARSKIK1 y} :] be finiteFINSET-1V1"
         sorry
    qed "sorry"
    let ?P = "\<lambda>Lamb1.  ex y be setHIDDENM2 st y inTARSKIR2 B & Lamb1 =XBOOLE-0R4 [:ZFMISC-1K2 A,{TARSKIK1 y} :]"
    obtain G where
      [ty]:"G be setHIDDENM2" and 
      A8: " for x be setHIDDENM2 holds x inTARSKIR2 G iff x inTARSKIR2 boolSETFAM-1K9 ([:ZFMISC-1K2 A,B :]) & ?P(x)"
      using xfamily_sch_1 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 G iff x inHIDDENR3 [:ZFMISC-1K2 A,B :]"
    proof-
      have " for x be objectHIDDENM1 holds (x inHIDDENR3 unionTARSKIK3 G implies x inHIDDENR3 [:ZFMISC-1K2 A,B :]) & (x inHIDDENR3 [:ZFMISC-1K2 A,B :] implies x inHIDDENR3 unionTARSKIK3 G)"
      proof(rule ballI,rule conjMI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        show "x inHIDDENR3 unionTARSKIK3 G implies x inHIDDENR3 [:ZFMISC-1K2 A,B :]"
        proof(rule impI)
          assume "x inHIDDENR3 unionTARSKIK3 G"
          then obtain X where
            [ty]:"X be setHIDDENM2" and 
            A9: "x inHIDDENR3 X"and A10: "X inTARSKIR2 G"
            using tarski_def_4 sorry
          have "X inTARSKIR2 boolSETFAM-1K9 ([:ZFMISC-1K2 A,B :])"
            using A8 A10 sorry
          thus "x inHIDDENR3 [:ZFMISC-1K2 A,B :]"
            using A9 sorry
        qed
        assume "x inHIDDENR3 [:ZFMISC-1K2 A,B :]"
        then obtain y z where
          [ty]:"y be objectHIDDENM1" "z be objectHIDDENM1" and 
          A11: "y inHIDDENR3 A"and A12: "z inHIDDENR3 B"and A13: "x =HIDDENR1 [TARSKIK4 y,z ]"
          using zfmisc_1_def_2 sorry
        have A14: "[TARSKIK4 y,z ] inHIDDENR3 [:ZFMISC-1K2 A,{TARSKIK1 z} :]"
          using A11 zfmisc_1_th_106 sorry
        have "{TARSKIK1 z} c=TARSKIR1 B"
          using A12 zfmisc_1_th_31 sorry
        then have "[:ZFMISC-1K2 A,{TARSKIK1 z} :] c=RELAT-1R2 [:ZFMISC-1K2 A,B :]"
          using zfmisc_1_th_95 sorry
        then have "[:ZFMISC-1K2 A,{TARSKIK1 z} :] inTARSKIR2 G"
          using A8 A12 sorry
        thus "x inHIDDENR3 unionTARSKIK3 G"
          using A13 A14 tarski_def_4 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have A15: "unionTARSKIK3 G =XBOOLE-0R4 [:ZFMISC-1K2 A,B :]"
      using tarski_th_2 sorry
    let ?F = "\<lambda>Lamb1. [:ZFMISC-1K2 A,{TARSKIK1 Lamb1} :]"
    obtain g where
      [ty]:"g be FunctionFUNCT-1M1" and 
      A16: "domRELAT-1K1 g =XBOOLE-0R4 B & ( for x be objectHIDDENM1 holds x inHIDDENR3 B implies g .FUNCT-1K1 x =XBOOLE-0R4 ?F(x))"
      using funct_1_sch_3 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 g iff x inHIDDENR3 G"
    proof-
      have " for x be objectHIDDENM1 holds (x inHIDDENR3 rngFUNCT-1K2 g implies x inHIDDENR3 G) & (x inHIDDENR3 G implies x inHIDDENR3 rngFUNCT-1K2 g)"
      proof(rule ballI,rule conjMI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        obtain xx where 
          [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
          using tarski_th_1 sorry
        show "x inHIDDENR3 rngFUNCT-1K2 g implies x inHIDDENR3 G"
        proof(rule impI)
          assume "x inHIDDENR3 rngFUNCT-1K2 g"
          then obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A17: "y inHIDDENR3 domRELAT-1K1 g"and A18: "g .FUNCT-1K1 y =HIDDENR1 x"
            using funct_1_def_3 sorry
          have A19: "x =HIDDENR1 [:ZFMISC-1K2 A,{TARSKIK1 y} :]"
            using A16 A17 A18 sorry
          have "{TARSKIK1 y} c=TARSKIR1 B"
            using A16 A17 zfmisc_1_th_31 sorry
          then have "xx c=TARSKIR1 [:ZFMISC-1K2 A,B :]"
            using A19 zfmisc_1_th_95 sorry
          thus "x inHIDDENR3 G"
            using A8 A16 A17 A19 sorry
        qed
        assume "x inHIDDENR3 G"
        then obtain y where
          [ty]:"y be setHIDDENM2" and 
          A20: "y inTARSKIR2 B"and A21: "x =HIDDENR1 [:ZFMISC-1K2 A,{TARSKIK1 y} :]"
          using A8 sorry
        have "x =HIDDENR1 g .FUNCT-1K1 y"
          using A16 A20 A21 sorry
        thus "x inHIDDENR3 rngFUNCT-1K2 g"
          using A16 A20 funct_1_def_3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have "rngFUNCT-1K2 g =XBOOLE-0R4 G"
      using tarski_th_2 sorry
    then have A22: "g .:FUNCT-1K5 B =XBOOLE-0R4 G"
      using A16 relat_1_th_113 sorry
    have " for X be setHIDDENM2 holds X inTARSKIR2 G implies X be finiteFINSET-1V1"
    proof(rule ballI,rule impI)
      fix X assume [ty]: "X be setHIDDENM2"
      assume "X inTARSKIR2 G"
      then have " ex y be setHIDDENM2 st y inTARSKIR2 B & X =XBOOLE-0R4 [:ZFMISC-1K2 A,{TARSKIK1 y} :]"
        using A8 sorry
      thus "X be finiteFINSET-1V1"
        using A1 sorry
    qed "sorry"
    thus "[:ZFMISC-1K2 A,B :] be finiteFINSET-1V1"
      using A15 A22 finset_1_lm_3 sorry
  qed
qed "sorry"

mtheorem finset_1_cl_18:
  mlet "A be finiteFINSET-1V1\<bar>setHIDDENM2", "B be finiteFINSET-1V1\<bar>setHIDDENM2", "C be finiteFINSET-1V1\<bar>setHIDDENM2"
"cluster [:ZFMISC-1K3 A,B,C :] as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "[:ZFMISC-1K3 A,B,C :] be finiteFINSET-1V1"
  proof-
    have "[:ZFMISC-1K2 [:ZFMISC-1K2 A,B :],C :] be finiteFINSET-1V1"
       sorry
    thus "[:ZFMISC-1K3 A,B,C :] be finiteFINSET-1V1"
      using zfmisc_1_def_3 sorry
  qed
qed "sorry"

mtheorem finset_1_cl_19:
  mlet "A be finiteFINSET-1V1\<bar>setHIDDENM2", "B be finiteFINSET-1V1\<bar>setHIDDENM2", "C be finiteFINSET-1V1\<bar>setHIDDENM2", "D be finiteFINSET-1V1\<bar>setHIDDENM2"
"cluster [:ZFMISC-1K4 A,B,C,D :] as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "[:ZFMISC-1K4 A,B,C,D :] be finiteFINSET-1V1"
  proof-
    have "[:ZFMISC-1K2 [:ZFMISC-1K3 A,B,C :],D :] be finiteFINSET-1V1"
       sorry
    thus "[:ZFMISC-1K4 A,B,C,D :] be finiteFINSET-1V1"
      using zfmisc_1_def_4 sorry
  qed
qed "sorry"

mtheorem finset_1_cl_20:
  mlet "A be finiteFINSET-1V1\<bar>setHIDDENM2"
"cluster boolSETFAM-1K9 A as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "boolSETFAM-1K9 A be finiteFINSET-1V1"
  proof-
    have A1: "A be finiteFINSET-1V1"
       sorry
    let ?P = "\<lambda>Lamb1. boolSETFAM-1K9 Lamb1 be finiteFINSET-1V1"
    obtain G where
      [ty]:"G be setHIDDENM2" and 
      A2: " for x be setHIDDENM2 holds x inTARSKIR2 G iff x inTARSKIR2 boolSETFAM-1K9 A & ?P(x)"
      using xfamily_sch_1 sorry
    let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 G"
    have A3: "boolSETFAM-1K9 ({}XBOOLE-0K1) be finiteFINSET-1V1"
      using zfmisc_1_th_1 sorry
    have "{}XBOOLE-0K1 c=RELAT-1R2 A"
       sorry
    then have A4: "?P({}XBOOLE-0K1)"
      using A3 A2 sorry
    have A5: " for x be setHIDDENM2 holds  for B be setHIDDENM2 holds (x inTARSKIR2 A & B c=TARSKIR1 A) & ?P(B) implies ?P(B \\/XBOOLE-0K2 {TARSKIK1 x})"
    proof-
      have " for x be setHIDDENM2 holds  for B be setHIDDENM2 holds x inTARSKIR2 A & (B c=TARSKIR1 A & B inTARSKIR2 G) implies B \\/XBOOLE-0K2 {TARSKIK1 x} inTARSKIR2 G"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        fix x assume [ty]: "x be setHIDDENM2"
        fix B assume [ty]: "B be setHIDDENM2"
        assume A6: "x inTARSKIR2 A"
          and "B c=TARSKIR1 A"
          and A7: "B inTARSKIR2 G"
        have A8: "x inTARSKIR2 B implies ?P(B \\/XBOOLE-0K2 {TARSKIK1 x})"
          using A7 xboole_1_th_12 zfmisc_1_th_31 sorry
        have " not x inTARSKIR2 B implies B \\/XBOOLE-0K2 {TARSKIK1 x} inTARSKIR2 G"
        proof(rule impI)
          assume A9: " not x inTARSKIR2 B"
          let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex Y be setHIDDENM2 st Y =HIDDENR1 Lamb1 & Lamb2 =HIDDENR1 Y \\/XBOOLE-0K2 {TARSKIK1 x}"
          have A10: " for y be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds (y inHIDDENR3 boolSETFAM-1K9 B & ?P(y,y1)) & ?P(y,y2) implies y1 =HIDDENR1 y2"
             sorry
          have A11: " for y be objectHIDDENM1 holds y inHIDDENR3 boolSETFAM-1K9 B implies ( ex z be objectHIDDENM1 st ?P(y,z))"
          proof-
            have " for y be objectHIDDENM1 holds y inHIDDENR3 boolSETFAM-1K9 B implies  not ( for z be objectHIDDENM1 holds  not ( ex Y be setHIDDENM2 st Y =HIDDENR1 y & z =HIDDENR1 Y \\/XBOOLE-0K2 {TARSKIK1 x}))"
            proof(rule ballI,rule impI)
              fix y assume [ty]: "y be objectHIDDENM1"
              assume "y inHIDDENR3 boolSETFAM-1K9 B"
              have 
                [ty]:"y be setHIDDENM2"
                using tarski_th_1 sorry
              have " ex Y be setHIDDENM2 st Y =XBOOLE-0R4 y & y \\/XBOOLE-0K2 {TARSKIK1 x} =XBOOLE-0R4 Y \\/XBOOLE-0K2 {TARSKIK1 x}"
                 sorry
              thus " not ( for z be objectHIDDENM1 holds  not ( ex Y be setHIDDENM2 st Y =HIDDENR1 y & z =HIDDENR1 Y \\/XBOOLE-0K2 {TARSKIK1 x}))"
                 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          obtain f where
            [ty]:"f be FunctionFUNCT-1M1" and 
            A12: "domRELAT-1K1 f =XBOOLE-0R4 boolSETFAM-1K9 B"and A13: " for y be objectHIDDENM1 holds y inHIDDENR3 boolSETFAM-1K9 B implies ?P(y,f .FUNCT-1K1 y)"
            using funct_1_sch_2 A10 A11 sorry
          have A14: "boolSETFAM-1K9 B be finiteFINSET-1V1"
            using A2 A7 sorry
          have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f iff y inHIDDENR3 boolSETFAM-1K9 (B \\/XBOOLE-0K2 {TARSKIK1 x}) \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 (B \\/XBOOLE-0K2 {TARSKIK1 x}))\<^esub> boolSETFAM-1K9 B"
          proof-
            have " for y be objectHIDDENM1 holds (y inHIDDENR3 rngFUNCT-1K2 f implies y inHIDDENR3 boolSETFAM-1K9 (B \\/XBOOLE-0K2 {TARSKIK1 x}) \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 (B \\/XBOOLE-0K2 {TARSKIK1 x}))\<^esub> boolSETFAM-1K9 B) & (y inHIDDENR3 boolSETFAM-1K9 (B \\/XBOOLE-0K2 {TARSKIK1 x}) \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 (B \\/XBOOLE-0K2 {TARSKIK1 x}))\<^esub> boolSETFAM-1K9 B implies y inHIDDENR3 rngFUNCT-1K2 f)"
            proof(rule ballI,rule conjMI,rule impI)
              fix y assume [ty]: "y be objectHIDDENM1"
              obtain yy where 
                [ty]:"yy be setHIDDENM2" and yyDef:"yy = y"
                using tarski_th_1 sorry
              show "y inHIDDENR3 rngFUNCT-1K2 f implies y inHIDDENR3 boolSETFAM-1K9 (B \\/XBOOLE-0K2 {TARSKIK1 x}) \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 (B \\/XBOOLE-0K2 {TARSKIK1 x}))\<^esub> boolSETFAM-1K9 B"
              proof(rule impI)
                assume "y inHIDDENR3 rngFUNCT-1K2 f"
                then obtain x1 where
                  [ty]:"x1 be objectHIDDENM1" and 
                  A15: "x1 inHIDDENR3 domRELAT-1K1 f"and A16: "f .FUNCT-1K1 x1 =HIDDENR1 y"
                  using funct_1_def_3 sorry
                obtain X1 where
                  [ty]:"X1 be setHIDDENM2" and 
                  A17: "X1 =HIDDENR1 x1"and A18: "f .FUNCT-1K1 x1 =XBOOLE-0R4 X1 \\/XBOOLE-0K2 {TARSKIK1 x}"
                  using A12 A13 A15 sorry
                have A19: "X1 \\/XBOOLE-0K2 {TARSKIK1 x} c=TARSKIR1 B \\/XBOOLE-0K2 {TARSKIK1 x}"
                  using A12 A15 A17 xboole_1_th_13 sorry
                have "x inTARSKIR2 {TARSKIK1 x}"
                  using tarski_def_1 sorry
                then have "x inTARSKIR2 yy"
                  using A16 A18 xboole_0_def_3 sorry
                then have " not y inHIDDENR3 boolSETFAM-1K9 B"
                  using A9 sorry
                thus "y inHIDDENR3 boolSETFAM-1K9 (B \\/XBOOLE-0K2 {TARSKIK1 x}) \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 (B \\/XBOOLE-0K2 {TARSKIK1 x}))\<^esub> boolSETFAM-1K9 B"
                  using A16 A18 A19 xboole_0_def_5 sorry
              qed
              assume A20: "y inHIDDENR3 boolSETFAM-1K9 (B \\/XBOOLE-0K2 {TARSKIK1 x}) \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 (B \\/XBOOLE-0K2 {TARSKIK1 x}))\<^esub> boolSETFAM-1K9 B"
              let ?Z = "yy \\SUBSET-1K6 {TARSKIK1 x}"
              have A21: " not x inTARSKIR2 yy implies  False "
              proof(rule impI)
                assume A22: " not x inTARSKIR2 yy"
                have "yy c=TARSKIR1 B"
                proof-
                  have " for z be objectHIDDENM1 holds z inHIDDENR3 yy implies z inHIDDENR3 B"
                  proof(rule ballI,rule impI)
                    fix z assume [ty]: "z be objectHIDDENM1"
                    assume A23: "z inHIDDENR3 yy"
                    then have " not z inHIDDENR3 {TARSKIK1 x}"
                      using A22 tarski_def_1 sorry
                    thus "z inHIDDENR3 B"
                      using A20 A23 xboole_0_def_3 sorry
                  qed "sorry"
                  thus "yy c=TARSKIR1 B"
                    using tarski_def_3 sorry
                qed
                thus " False "
                  using A20 xboole_0_def_5 sorry
              qed
              have A24: "?Z c=TARSKIR1 B"
                using A20 xboole_1_th_43 sorry
              then obtain X where
                [ty]:"X be setHIDDENM2" and 
                A25: "X =XBOOLE-0R4 ?Z"and A26: "f .FUNCT-1K1 ?Z =XBOOLE-0R4 X \\/XBOOLE-0K2 {TARSKIK1 x}"
                using A13 sorry
              have "X \\/XBOOLE-0K2 {TARSKIK1 x} =HIDDENR1 yy \\/XBOOLE-0K2 {TARSKIK1 x}"
                using A25 xboole_1_th_39 sorry
              also have "... = y"
                using A21 zfmisc_1_th_40 sorry
              finally have "X \\/XBOOLE-0K2 {TARSKIK1 x} =HIDDENR1 y"
                 sorry
              thus "y inHIDDENR3 rngFUNCT-1K2 f"
                using A12 A24 A26 funct_1_def_3 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          then have "rngFUNCT-1K2 f =XBOOLE-0R4 boolSETFAM-1K9 (B \\/XBOOLE-0K2 {TARSKIK1 x}) \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 (B \\/XBOOLE-0K2 {TARSKIK1 x}))\<^esub> boolSETFAM-1K9 B"
            using tarski_th_2 sorry
          then have A27: "f .:FUNCT-1K5 boolSETFAM-1K9 B =XBOOLE-0R4 boolSETFAM-1K9 (B \\/XBOOLE-0K2 {TARSKIK1 x}) \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 (B \\/XBOOLE-0K2 {TARSKIK1 x}))\<^esub> boolSETFAM-1K9 B"
            using A12 relat_1_th_113 sorry
          have A28: "boolSETFAM-1K9 B c=TARSKIR1 boolSETFAM-1K9 (B \\/XBOOLE-0K2 {TARSKIK1 x})"
            using xboole_1_th_7 zfmisc_1_th_67 sorry
          have A29: "(boolSETFAM-1K9 (B \\/XBOOLE-0K2 {TARSKIK1 x}) \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 (B \\/XBOOLE-0K2 {TARSKIK1 x}))\<^esub> boolSETFAM-1K9 B)\\/XBOOLE-0K2 boolSETFAM-1K9 B =HIDDENR1 boolSETFAM-1K9 (B \\/XBOOLE-0K2 {TARSKIK1 x}) \\/XBOOLE-0K2 boolSETFAM-1K9 B"
            using xboole_1_th_39 sorry
          also have "... = boolSETFAM-1K9 (B \\/XBOOLE-0K2 {TARSKIK1 x})"
            using A28 xboole_1_th_12 sorry
          finally have "(boolSETFAM-1K9 (B \\/XBOOLE-0K2 {TARSKIK1 x}) \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 (B \\/XBOOLE-0K2 {TARSKIK1 x}))\<^esub> boolSETFAM-1K9 B)\\/XBOOLE-0K2 boolSETFAM-1K9 B =HIDDENR1 boolSETFAM-1K9 (B \\/XBOOLE-0K2 {TARSKIK1 x})"
             sorry
          have A30: "{TARSKIK1 x} c=TARSKIR1 A"
            using A6 zfmisc_1_th_31 sorry
          have "B inTARSKIR2 boolSETFAM-1K9 A"
            using A2 A7 sorry
          then have "B \\/XBOOLE-0K2 {TARSKIK1 x} c=TARSKIR1 A"
            using A30 xboole_1_th_8 sorry
          thus "B \\/XBOOLE-0K2 {TARSKIK1 x} inTARSKIR2 G"
            using A2 A14 A27 A29 sorry
        qed
        thus "B \\/XBOOLE-0K2 {TARSKIK1 x} inTARSKIR2 G"
          using A8 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "?P(A)"
      using finset_1_sch_2 A1 A4 A5 sorry
    thus "boolSETFAM-1K9 A be finiteFINSET-1V1"
      using A2 sorry
  qed
qed "sorry"

mtheorem finset_1_th_7:
" for A be setHIDDENM2 holds A be finiteFINSET-1V1 & ( for X be setHIDDENM2 holds X inTARSKIR2 A implies X be finiteFINSET-1V1) iff unionTARSKIK3 A be finiteFINSET-1V1"
proof-
  have " for A be setHIDDENM2 holds (A be finiteFINSET-1V1 & ( for X be setHIDDENM2 holds X inTARSKIR2 A implies X be finiteFINSET-1V1) implies unionTARSKIK3 A be finiteFINSET-1V1) & (unionTARSKIK3 A be finiteFINSET-1V1 implies A be finiteFINSET-1V1 & ( for X be setHIDDENM2 holds X inTARSKIR2 A implies X be finiteFINSET-1V1))"
  proof(rule ballI,rule conjMI)
    fix A assume [ty]: "A be setHIDDENM2"
    show "A be finiteFINSET-1V1 & ( for X be setHIDDENM2 holds X inTARSKIR2 A implies X be finiteFINSET-1V1) implies unionTARSKIK3 A be finiteFINSET-1V1"
      using finset_1_lm_3 sorry
    show "unionTARSKIK3 A be finiteFINSET-1V1 implies A be finiteFINSET-1V1 & ( for X be setHIDDENM2 holds X inTARSKIR2 A implies X be finiteFINSET-1V1)"
    proof(rule impI,rule conjMI,rule ballI,rule impI)
      assume A1: "unionTARSKIK3 A be finiteFINSET-1V1"
      have "A c=TARSKIR1 boolSETFAM-1K9 (unionTARSKIK3 A)"
        using zfmisc_1_th_82 sorry
      thus "A be finiteFINSET-1V1"
        using A1 sorry
      fix X assume [ty]: "X be setHIDDENM2"
      assume "X inTARSKIR2 A"
      then have "X c=TARSKIR1 unionTARSKIK3 A"
        using zfmisc_1_th_74 sorry
      thus "X be finiteFINSET-1V1"
        using A1 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finset_1_th_8:
" for f be FunctionFUNCT-1M1 holds domRELAT-1K1 f be finiteFINSET-1V1 implies rngFUNCT-1K2 f be finiteFINSET-1V1"
proof-
  have " for f be FunctionFUNCT-1M1 holds domRELAT-1K1 f be finiteFINSET-1V1 implies rngFUNCT-1K2 f be finiteFINSET-1V1"
  proof(rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume "domRELAT-1K1 f be finiteFINSET-1V1"
    then have "f .:FUNCT-1K5 domRELAT-1K1 f be finiteFINSET-1V1"
       sorry
    thus "rngFUNCT-1K2 f be finiteFINSET-1V1"
      using relat_1_th_113 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finset_1_th_9:
" for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds Y c=TARSKIR1 rngFUNCT-1K2 f & f \<inverse>FUNCT-1K6 Y be finiteFINSET-1V1 implies Y be finiteFINSET-1V1"
proof-
  have " for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds Y c=TARSKIR1 rngFUNCT-1K2 f implies  not (f \<inverse>FUNCT-1K6 Y be finiteFINSET-1V1 &  not Y be finiteFINSET-1V1)"
  proof(rule ballI,rule ballI,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume "Y c=TARSKIR1 rngFUNCT-1K2 f"
    then have "f .:FUNCT-1K5 f \<inverse>FUNCT-1K6 Y =XBOOLE-0R4 Y"
      using funct_1_th_77 sorry
    thus " not (f \<inverse>FUNCT-1K6 Y be finiteFINSET-1V1 &  not Y be finiteFINSET-1V1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finset_1_cl_21:
  mlet "X be finiteFINSET-1V1\<bar>setHIDDENM2", "Y be finiteFINSET-1V1\<bar>setHIDDENM2"
"cluster X \\+\\XBOOLE-0K5 Y as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "X \\+\\XBOOLE-0K5 Y be finiteFINSET-1V1"
     sorry
qed "sorry"

mtheorem finset_1_cl_22:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1 for SubsetSUBSET-1M2-of X"
proof
(*existence*)
  show " ex it be SubsetSUBSET-1M2-of X st it be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1"
  proof-
    have " ex tVar12 be SubsetSUBSET-1M2-of X st tVar12 be finiteFINSET-1V1 &  not tVar12 be emptyXBOOLE-0V1"
    proof-
      show " ex tVar12 be SubsetSUBSET-1M2-of X st tVar12 be finiteFINSET-1V1 &  not tVar12 be emptyXBOOLE-0V1"
      proof(rule bexI[of _ "{DOMAIN-1K6\<^bsub>(X)\<^esub> the ElementSUBSET-1M1-of X }"])
        show "{DOMAIN-1K6\<^bsub>(X)\<^esub> the ElementSUBSET-1M1-of X } be finiteFINSET-1V1 &  not {DOMAIN-1K6\<^bsub>(X)\<^esub> the ElementSUBSET-1M1-of X } be emptyXBOOLE-0V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

(*begin*)
mtheorem finset_1_th_10:
" for f be FunctionFUNCT-1M1 holds domRELAT-1K1 f be finiteFINSET-1V1 iff f be finiteFINSET-1V1"
proof-
  have " for f be FunctionFUNCT-1M1 holds (domRELAT-1K1 f be finiteFINSET-1V1 implies f be finiteFINSET-1V1) &  not (f be finiteFINSET-1V1 &  not domRELAT-1K1 f be finiteFINSET-1V1)"
  proof(rule ballI,rule conjMI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    show "domRELAT-1K1 f be finiteFINSET-1V1 implies f be finiteFINSET-1V1"
    proof(rule impI)
      assume A1: "domRELAT-1K1 f be finiteFINSET-1V1"
      then have A2: "rngFUNCT-1K2 f be finiteFINSET-1V1"
        using finset_1_th_8 sorry
      have "f c=RELAT-1R2 [:ZFMISC-1K2 domRELAT-1K1 f,rngFUNCT-1K2 f :]"
        using relat_1_th_7 sorry
      thus "f be finiteFINSET-1V1"
        using A1 A2 sorry
    qed
    have "pr1FUNCT-3K10(domRELAT-1K1 f,rngFUNCT-1K2 f) .:RELSET-1K7\<^bsub>([:ZFMISC-1K2 domRELAT-1K1 f,rngFUNCT-1K2 f :],domRELAT-1K1 f)\<^esub> f =XBOOLE-0R4 domRELAT-1K1 f"
      using funct_3_th_79 sorry
    thus " not (f be finiteFINSET-1V1 &  not domRELAT-1K1 f be finiteFINSET-1V1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finset_1_th_11:
" for F be setHIDDENM2 holds (F be finiteFINSET-1V1 & F <>HIDDENR2 {}XBOOLE-0K1) & F be c=-linearORDINAL1V6 implies ( ex m be setHIDDENM2 st m inTARSKIR2 F & ( for C be setHIDDENM2 holds C inTARSKIR2 F implies m c=TARSKIR1 C))"
proof-
  have " for F be setHIDDENM2 holds F be finiteFINSET-1V1 & (F <>HIDDENR2 {}XBOOLE-0K1 & F be c=-linearORDINAL1V6) implies  not ( for m be setHIDDENM2 holds  not (m inTARSKIR2 F & ( for C be setHIDDENM2 holds  not (C inTARSKIR2 F &  not m c=TARSKIR1 C))))"
  proof(rule ballI,rule impMI ,rule impMI ,rule impI)
    let ?P = "\<lambda>Lamb1. Lamb1 <>HIDDENR2 {}XBOOLE-0K1 implies ( ex m be setHIDDENM2 st m inTARSKIR2 Lamb1 & ( for C be setHIDDENM2 holds C inTARSKIR2 Lamb1 implies m c=TARSKIR1 C))"
    fix F assume [ty]: "F be setHIDDENM2"
    assume A1: "F be finiteFINSET-1V1"
      and A2: "F <>HIDDENR2 {}XBOOLE-0K1"
      and A3: "F be c=-linearORDINAL1V6"
    have A4: "?P({}XBOOLE-0K1)"
       sorry
    have A5: " for x be setHIDDENM2 holds  for B be setHIDDENM2 holds x inTARSKIR2 F & (B c=TARSKIR1 F & (B <>HIDDENR2 {}XBOOLE-0K1 implies ( ex m be setHIDDENM2 st m inTARSKIR2 B & ( for C be setHIDDENM2 holds C inTARSKIR2 B implies m c=TARSKIR1 C)))) implies (B \\/XBOOLE-0K2 {TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1 implies ( ex m be setHIDDENM2 st m inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x} & ( for C be setHIDDENM2 holds C inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x} implies m c=TARSKIR1 C)))"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix x assume [ty]: "x be setHIDDENM2"
      fix B assume [ty]: "B be setHIDDENM2"
      assume A6: "x inTARSKIR2 F"
        and A7: "B c=TARSKIR1 F"
        and A8: "?P(B)"
      have "B \\/XBOOLE-0K2 {TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1 implies ( ex m be setHIDDENM2 st m inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x} & ( for C be setHIDDENM2 holds C inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x} implies m c=TARSKIR1 C))"
      proof-
        show "B \\/XBOOLE-0K2 {TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1 implies ( ex m be setHIDDENM2 st m inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x} & ( for C be setHIDDENM2 holds C inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x} implies m c=TARSKIR1 C))"
        proof-
          have cases: " not ( ex y be setHIDDENM2 st y inTARSKIR2 B & y c=TARSKIR1 x) or ( ex y be setHIDDENM2 st y inTARSKIR2 B & y c=TARSKIR1 x)"
             sorry
          have case1: " not ( ex y be setHIDDENM2 st y inTARSKIR2 B & y c=TARSKIR1 x) implies (B \\/XBOOLE-0K2 {TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1 implies ( ex m be setHIDDENM2 st m inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x} & ( for C be setHIDDENM2 holds C inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x} implies m c=TARSKIR1 C)))"
          proof(rule impI,rule impI)
            assume A9: " not ( ex y be setHIDDENM2 st y inTARSKIR2 B & y c=TARSKIR1 x)"
            assume "B \\/XBOOLE-0K2 {TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1"
            obtain m where 
              [ty]:"m be setHIDDENM2" and mDef:"m = x"
               sorry
            show " ex m be setHIDDENM2 st m inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x} & ( for C be setHIDDENM2 holds C inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x} implies m c=TARSKIR1 C)"
            proof(rule bexI[of _ "m"],rule conjMI,rule ballI,rule impI)
              have "x inTARSKIR2 {TARSKIK1 x}"
                using tarski_def_1 sorry
              thus "m inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x}"
                using xboole_0_def_3 sorry
              fix C assume [ty]: "C be setHIDDENM2"
              assume "C inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x}"
              then have A10: "C inTARSKIR2 B or C inTARSKIR2 {TARSKIK1 x}"
                using xboole_0_def_3 sorry
              then have "(C,x)are-c=-comparableXBOOLE-0R3"
                using A3 A6 A7 tarski_def_1 sorry
              then have "C c=TARSKIR1 x or x c=TARSKIR1 C"
                 sorry
              thus "m c=TARSKIR1 C"
                using A9 A10 tarski_def_1 sorry
            qed "sorry"
          qed
          have case2: "( ex y be setHIDDENM2 st y inTARSKIR2 B & y c=TARSKIR1 x) implies (B \\/XBOOLE-0K2 {TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1 implies ( ex m be setHIDDENM2 st m inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x} & ( for C be setHIDDENM2 holds C inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x} implies m c=TARSKIR1 C)))"
          proof(rule impI,rule impI)
            assume " ex y be setHIDDENM2 st y inTARSKIR2 B & y c=TARSKIR1 x"
            then obtain y where
              [ty]:"y be setHIDDENM2" and 
              A11: "y inTARSKIR2 B"and A12: "y c=TARSKIR1 x"
               sorry
            assume "B \\/XBOOLE-0K2 {TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1"
            obtain m where
              [ty]:"m be setHIDDENM2" and 
              A13: "m inTARSKIR2 B"and A14: " for C be setHIDDENM2 holds C inTARSKIR2 B implies m c=TARSKIR1 C"
              using A8 A11 sorry
            have "m c=TARSKIR1 y"
              using A11 A14 sorry
            then have A15: "m c=TARSKIR1 x"
              using A12 sorry
            show " ex m be setHIDDENM2 st m inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x} & ( for C be setHIDDENM2 holds C inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x} implies m c=TARSKIR1 C)"
            proof(rule bexI[of _ "m"],rule conjMI,rule ballI,rule impI)
              show "m inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x}"
                using A13 xboole_0_def_3 sorry
              fix C assume [ty]: "C be setHIDDENM2"
              assume "C inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x}"
              then have "C inTARSKIR2 B or C inTARSKIR2 {TARSKIK1 x}"
                using xboole_0_def_3 sorry
              thus "m c=TARSKIR1 C"
                using A14 A15 tarski_def_1 sorry
            qed "sorry"
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "B \\/XBOOLE-0K2 {TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1 implies ( ex m be setHIDDENM2 st m inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x} & ( for C be setHIDDENM2 holds C inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x} implies m c=TARSKIR1 C))"
         sorry
    qed "sorry"
    have "?P(F)"
      using finset_1_sch_2 A1 A4 A5 sorry
    thus " not ( for m be setHIDDENM2 holds  not (m inTARSKIR2 F & ( for C be setHIDDENM2 holds  not (C inTARSKIR2 F &  not m c=TARSKIR1 C))))"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finset_1_th_12:
" for F be setHIDDENM2 holds (F be finiteFINSET-1V1 & F <>HIDDENR2 {}XBOOLE-0K1) & F be c=-linearORDINAL1V6 implies ( ex m be setHIDDENM2 st m inTARSKIR2 F & ( for C be setHIDDENM2 holds C inTARSKIR2 F implies C c=TARSKIR1 m))"
proof-
  have " for F be setHIDDENM2 holds F be finiteFINSET-1V1 & (F <>HIDDENR2 {}XBOOLE-0K1 & F be c=-linearORDINAL1V6) implies  not ( for m be setHIDDENM2 holds  not (m inTARSKIR2 F & ( for C be setHIDDENM2 holds  not (C inTARSKIR2 F &  not C c=TARSKIR1 m))))"
  proof(rule ballI,rule impMI ,rule impMI ,rule impI)
    let ?P = "\<lambda>Lamb1. Lamb1 <>HIDDENR2 {}XBOOLE-0K1 implies ( ex m be setHIDDENM2 st m inTARSKIR2 Lamb1 & ( for C be setHIDDENM2 holds C inTARSKIR2 Lamb1 implies C c=TARSKIR1 m))"
    fix F assume [ty]: "F be setHIDDENM2"
    assume A1: "F be finiteFINSET-1V1"
      and A2: "F <>HIDDENR2 {}XBOOLE-0K1"
      and A3: "F be c=-linearORDINAL1V6"
    have A4: "?P({}XBOOLE-0K1)"
       sorry
    have A5: " for x be setHIDDENM2 holds  for B be setHIDDENM2 holds x inTARSKIR2 F & (B c=TARSKIR1 F & (B <>HIDDENR2 {}XBOOLE-0K1 implies ( ex m be setHIDDENM2 st m inTARSKIR2 B & ( for C be setHIDDENM2 holds C inTARSKIR2 B implies C c=TARSKIR1 m)))) implies (B \\/XBOOLE-0K2 {TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1 implies ( ex m be setHIDDENM2 st m inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x} & ( for C be setHIDDENM2 holds C inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x} implies C c=TARSKIR1 m)))"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix x assume [ty]: "x be setHIDDENM2"
      fix B assume [ty]: "B be setHIDDENM2"
      assume A6: "x inTARSKIR2 F"
        and A7: "B c=TARSKIR1 F"
        and A8: "?P(B)"
      have "B \\/XBOOLE-0K2 {TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1 implies ( ex m be setHIDDENM2 st m inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x} & ( for C be setHIDDENM2 holds C inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x} implies C c=TARSKIR1 m))"
      proof-
        show "B \\/XBOOLE-0K2 {TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1 implies ( ex m be setHIDDENM2 st m inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x} & ( for C be setHIDDENM2 holds C inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x} implies C c=TARSKIR1 m))"
        proof-
          have cases: " not ( ex y be setHIDDENM2 st y inTARSKIR2 B & x c=TARSKIR1 y) or ( ex y be setHIDDENM2 st y inTARSKIR2 B & x c=TARSKIR1 y)"
             sorry
          have case1: " not ( ex y be setHIDDENM2 st y inTARSKIR2 B & x c=TARSKIR1 y) implies (B \\/XBOOLE-0K2 {TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1 implies ( ex m be setHIDDENM2 st m inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x} & ( for C be setHIDDENM2 holds C inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x} implies C c=TARSKIR1 m)))"
          proof(rule impI,rule impI)
            assume A9: " not ( ex y be setHIDDENM2 st y inTARSKIR2 B & x c=TARSKIR1 y)"
            assume "B \\/XBOOLE-0K2 {TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1"
            obtain m where 
              [ty]:"m be setHIDDENM2" and mDef:"m = x"
               sorry
            show " ex m be setHIDDENM2 st m inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x} & ( for C be setHIDDENM2 holds C inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x} implies C c=TARSKIR1 m)"
            proof(rule bexI[of _ "m"],rule conjMI,rule ballI,rule impI)
              have "x inTARSKIR2 {TARSKIK1 x}"
                using tarski_def_1 sorry
              thus "m inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x}"
                using xboole_0_def_3 sorry
              fix C assume [ty]: "C be setHIDDENM2"
              assume "C inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x}"
              then have A10: "C inTARSKIR2 B or C inTARSKIR2 {TARSKIK1 x}"
                using xboole_0_def_3 sorry
              then have "(C,x)are-c=-comparableXBOOLE-0R3"
                using A3 A6 A7 tarski_def_1 sorry
              then have "C c=TARSKIR1 x or x c=TARSKIR1 C"
                 sorry
              thus "C c=TARSKIR1 m"
                using A9 A10 tarski_def_1 sorry
            qed "sorry"
          qed
          have case2: "( ex y be setHIDDENM2 st y inTARSKIR2 B & x c=TARSKIR1 y) implies (B \\/XBOOLE-0K2 {TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1 implies ( ex m be setHIDDENM2 st m inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x} & ( for C be setHIDDENM2 holds C inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x} implies C c=TARSKIR1 m)))"
          proof(rule impI,rule impI)
            assume " ex y be setHIDDENM2 st y inTARSKIR2 B & x c=TARSKIR1 y"
            then obtain y where
              [ty]:"y be setHIDDENM2" and 
              A11: "y inTARSKIR2 B"and A12: "x c=TARSKIR1 y"
               sorry
            assume "B \\/XBOOLE-0K2 {TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1"
            obtain m where
              [ty]:"m be setHIDDENM2" and 
              A13: "m inTARSKIR2 B"and A14: " for C be setHIDDENM2 holds C inTARSKIR2 B implies C c=TARSKIR1 m"
              using A8 A11 sorry
            have "y c=TARSKIR1 m"
              using A11 A14 sorry
            then have A15: "x c=TARSKIR1 m"
              using A12 sorry
            show " ex m be setHIDDENM2 st m inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x} & ( for C be setHIDDENM2 holds C inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x} implies C c=TARSKIR1 m)"
            proof(rule bexI[of _ "m"],rule conjMI,rule ballI,rule impI)
              show "m inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x}"
                using A13 xboole_0_def_3 sorry
              fix C assume [ty]: "C be setHIDDENM2"
              assume "C inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x}"
              then have "C inTARSKIR2 B or C inTARSKIR2 {TARSKIK1 x}"
                using xboole_0_def_3 sorry
              thus "C c=TARSKIR1 m"
                using A14 A15 tarski_def_1 sorry
            qed "sorry"
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "B \\/XBOOLE-0K2 {TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1 implies ( ex m be setHIDDENM2 st m inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x} & ( for C be setHIDDENM2 holds C inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x} implies C c=TARSKIR1 m))"
         sorry
    qed "sorry"
    have "?P(F)"
      using finset_1_sch_2 A1 A4 A5 sorry
    thus " not ( for m be setHIDDENM2 holds  not (m inTARSKIR2 F & ( for C be setHIDDENM2 holds  not (C inTARSKIR2 F &  not C c=TARSKIR1 m))))"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef finset_1_def_2 ("finite-yieldingFINSET-1V3" 70 ) where
"attr finite-yieldingFINSET-1V3 for RelationRELAT-1M1 means
  (\<lambda>R.  for x be setHIDDENM2 holds x inTARSKIR2 rngRELAT-1K2 R implies x be finiteFINSET-1V1)"..

mtheorem finset_1_th_13:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X be finiteFINSET-1V1 & X c=TARSKIR1 [:ZFMISC-1K2 Y,Z :] implies ( ex A be setHIDDENM2 st  ex B be setHIDDENM2 st (((A be finiteFINSET-1V1 & A c=TARSKIR1 Y) & B be finiteFINSET-1V1) & B c=TARSKIR1 Z) & X c=TARSKIR1 [:ZFMISC-1K2 A,B :])"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X be finiteFINSET-1V1 & X c=TARSKIR1 [:ZFMISC-1K2 Y,Z :] implies ( ex A be setHIDDENM2 st  ex B be setHIDDENM2 st A be finiteFINSET-1V1 & (A c=TARSKIR1 Y & (B be finiteFINSET-1V1 & (B c=TARSKIR1 Z & X c=TARSKIR1 [:ZFMISC-1K2 A,B :]))))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    let ?G = "\<lambda>Lamb1. Lamb1 `2XTUPLE-0K2"
    assume A1: "X be finiteFINSET-1V1"
      and A2: "X c=TARSKIR1 [:ZFMISC-1K2 Y,Z :]"
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A3: "domRELAT-1K1 f =XBOOLE-0R4 X"and A4: " for a be objectHIDDENM1 holds a inHIDDENR3 X implies f .FUNCT-1K1 a =HIDDENR1 a `1XTUPLE-0K1"
      using funct_1_sch_3 sorry
    obtain g where
      [ty]:"g be FunctionFUNCT-1M1" and 
      A5: "domRELAT-1K1 g =XBOOLE-0R4 X"and A6: " for a be objectHIDDENM1 holds a inHIDDENR3 X implies g .FUNCT-1K1 a =HIDDENR1 ?G(a)"
      using funct_1_sch_3 sorry
    obtain A where 
      [ty]:"A be setHIDDENM2" and ADef:"A = rngFUNCT-1K2 f"
       sorry
    show " ex A be setHIDDENM2 st  ex B be setHIDDENM2 st A be finiteFINSET-1V1 & (A c=TARSKIR1 Y & (B be finiteFINSET-1V1 & (B c=TARSKIR1 Z & X c=TARSKIR1 [:ZFMISC-1K2 A,B :])))"
    proof(rule bexI[of _ "A"])
      obtain B where 
        [ty]:"B be setHIDDENM2" and BDef:"B = rngFUNCT-1K2 g"
         sorry
      show " ex B be setHIDDENM2 st A be finiteFINSET-1V1 & (A c=TARSKIR1 Y & (B be finiteFINSET-1V1 & (B c=TARSKIR1 Z & X c=TARSKIR1 [:ZFMISC-1K2 A,B :])))"
      proof(rule bexI[of _ "B"],rule conjMI,rule conjMI,rule conjMI,rule conjMI)
        show "A be finiteFINSET-1V1"
          using A1 A3 finset_1_th_8 sorry
        show "A c=TARSKIR1 Y"
        proof-
          have " for a be objectHIDDENM1 holds a inHIDDENR3 A implies a inHIDDENR3 Y"
          proof(rule ballI,rule impI)
            fix a assume [ty]: "a be objectHIDDENM1"
            assume "a inHIDDENR3 A"
            then obtain x where
              [ty]:"x be objectHIDDENM1" and 
              A7: "x inHIDDENR3 domRELAT-1K1 f"and A8: "f .FUNCT-1K1 x =HIDDENR1 a"
              using funct_1_def_3 sorry
            obtain y z where
              [ty]:"y be objectHIDDENM1" "z be objectHIDDENM1" and 
              A9: "y inHIDDENR3 Y"and "z inHIDDENR3 Z"and A10: "x =HIDDENR1 [TARSKIK4 y,z ]"
              using A2 A3 A7 zfmisc_1_def_2 sorry
            have "f .FUNCT-1K1 x =HIDDENR1 x `1XTUPLE-0K1"
              using A3 A4 A7 sorry
            also have "... = y"
              using A10 sorry
            finally have "f .FUNCT-1K1 x =HIDDENR1 y"
               sorry
            thus "a inHIDDENR3 Y"
              using A8 A9 sorry
          qed "sorry"
          thus "A c=TARSKIR1 Y"
            using tarski_def_3 sorry
        qed
        show "B be finiteFINSET-1V1"
          using A1 A5 finset_1_th_8 sorry
        show "B c=TARSKIR1 Z"
        proof-
          have " for a be objectHIDDENM1 holds a inHIDDENR3 B implies a inHIDDENR3 Z"
          proof(rule ballI,rule impI)
            fix a assume [ty]: "a be objectHIDDENM1"
            assume "a inHIDDENR3 B"
            then obtain x where
              [ty]:"x be objectHIDDENM1" and 
              A11: "x inHIDDENR3 domRELAT-1K1 g"and A12: "g .FUNCT-1K1 x =HIDDENR1 a"
              using funct_1_def_3 sorry
            obtain y z where
              [ty]:"y be objectHIDDENM1" "z be objectHIDDENM1" and 
              "y inHIDDENR3 Y"and A13: "z inHIDDENR3 Z"and A14: "x =HIDDENR1 [TARSKIK4 y,z ]"
              using A2 A5 A11 zfmisc_1_def_2 sorry
            have "g .FUNCT-1K1 x =HIDDENR1 x `2XTUPLE-0K2"
              using A5 A6 A11 sorry
            also have "... = z"
              using A14 sorry
            finally have "g .FUNCT-1K1 x =HIDDENR1 z"
               sorry
            thus "a inHIDDENR3 Z"
              using A12 A13 sorry
          qed "sorry"
          thus "B c=TARSKIR1 Z"
            using tarski_def_3 sorry
        qed
        show "X c=TARSKIR1 [:ZFMISC-1K2 A,B :]"
        proof-
          have " for a be objectHIDDENM1 holds a inHIDDENR3 X implies a inHIDDENR3 [:ZFMISC-1K2 A,B :]"
          proof(rule ballI,rule impI)
            fix a assume [ty]: "a be objectHIDDENM1"
            assume A15: "a inHIDDENR3 X"
            then obtain x y where
              [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
              "x inHIDDENR3 Y"and "y inHIDDENR3 Z"and A16: "a =HIDDENR1 [TARSKIK4 x,y ]"
              using A2 zfmisc_1_def_2 sorry
            have A17: "g .FUNCT-1K1 a =HIDDENR1 a `2XTUPLE-0K2"
              using A6 A15 sorry
            also have "... = y"
              using A16 sorry
            finally have "g .FUNCT-1K1 a =HIDDENR1 y"
               sorry
            have "f .FUNCT-1K1 a =HIDDENR1 a `1XTUPLE-0K1"
              using A4 A15 sorry
            also have "... = x"
              using A16 sorry
            finally have "f .FUNCT-1K1 a =HIDDENR1 x"
               sorry
            then have A18: "x inHIDDENR3 A"
              using A3 A15 funct_1_def_3 sorry
            have "y inHIDDENR3 B"
              using A5 A15 A17 funct_1_def_3 sorry
            thus "a inHIDDENR3 [:ZFMISC-1K2 A,B :]"
              using A16 A18 zfmisc_1_th_87 sorry
          qed "sorry"
          thus "X c=TARSKIR1 [:ZFMISC-1K2 A,B :]"
            using tarski_def_3 sorry
        qed
      qed "sorry"
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finset_1_th_14:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X be finiteFINSET-1V1 & X c=TARSKIR1 [:ZFMISC-1K2 Y,Z :] implies ( ex A be setHIDDENM2 st (A be finiteFINSET-1V1 & A c=TARSKIR1 Y) & X c=TARSKIR1 [:ZFMISC-1K2 A,Z :])"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X be finiteFINSET-1V1 & X c=TARSKIR1 [:ZFMISC-1K2 Y,Z :] implies ( ex A be setHIDDENM2 st A be finiteFINSET-1V1 & (A c=TARSKIR1 Y & X c=TARSKIR1 [:ZFMISC-1K2 A,Z :]))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume A1: "X be finiteFINSET-1V1"
      and A2: "X c=TARSKIR1 [:ZFMISC-1K2 Y,Z :]"
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A3: "domRELAT-1K1 f =XBOOLE-0R4 X"and A4: " for a be objectHIDDENM1 holds a inHIDDENR3 X implies f .FUNCT-1K1 a =HIDDENR1 a `1XTUPLE-0K1"
      using funct_1_sch_3 sorry
    obtain A where 
      [ty]:"A be setHIDDENM2" and ADef:"A = rngFUNCT-1K2 f"
       sorry
    show " ex A be setHIDDENM2 st A be finiteFINSET-1V1 & (A c=TARSKIR1 Y & X c=TARSKIR1 [:ZFMISC-1K2 A,Z :])"
    proof(rule bexI[of _ "A"],rule conjMI,rule conjMI)
      show "A be finiteFINSET-1V1"
        using A1 A3 finset_1_th_8 sorry
      show "A c=TARSKIR1 Y"
      proof-
        have " for a be objectHIDDENM1 holds a inHIDDENR3 A implies a inHIDDENR3 Y"
        proof(rule ballI,rule impI)
          fix a assume [ty]: "a be objectHIDDENM1"
          assume "a inHIDDENR3 A"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A5: "x inHIDDENR3 domRELAT-1K1 f"and A6: "f .FUNCT-1K1 x =HIDDENR1 a"
            using funct_1_def_3 sorry
          obtain y z where
            [ty]:"y be objectHIDDENM1" "z be objectHIDDENM1" and 
            A7: "y inHIDDENR3 Y"and "z inHIDDENR3 Z"and A8: "x =HIDDENR1 [TARSKIK4 y,z ]"
            using A2 A3 A5 zfmisc_1_def_2 sorry
          have "f .FUNCT-1K1 x =HIDDENR1 x `1XTUPLE-0K1"
            using A3 A4 A5 sorry
          also have "... = y"
            using A8 sorry
          finally have "f .FUNCT-1K1 x =HIDDENR1 y"
             sorry
          thus "a inHIDDENR3 Y"
            using A6 A7 sorry
        qed "sorry"
        thus "A c=TARSKIR1 Y"
          using tarski_def_3 sorry
      qed
      show "X c=TARSKIR1 [:ZFMISC-1K2 A,Z :]"
      proof-
        have " for a be objectHIDDENM1 holds a inHIDDENR3 X implies a inHIDDENR3 [:ZFMISC-1K2 A,Z :]"
        proof(rule ballI,rule impI)
          fix a assume [ty]: "a be objectHIDDENM1"
          assume A9: "a inHIDDENR3 X"
          then obtain x y where
            [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
            "x inHIDDENR3 Y"and A10: "y inHIDDENR3 Z"and A11: "a =HIDDENR1 [TARSKIK4 x,y ]"
            using A2 zfmisc_1_def_2 sorry
          have "f .FUNCT-1K1 a =HIDDENR1 a `1XTUPLE-0K1"
            using A4 A9 sorry
          also have "... = x"
            using A11 sorry
          finally have "f .FUNCT-1K1 a =HIDDENR1 x"
             sorry
          then have "x inHIDDENR3 A"
            using A3 A9 funct_1_def_3 sorry
          thus "a inHIDDENR3 [:ZFMISC-1K2 A,Z :]"
            using A10 A11 zfmisc_1_th_87 sorry
        qed "sorry"
        thus "X c=TARSKIR1 [:ZFMISC-1K2 A,Z :]"
          using tarski_def_3 sorry
      qed
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finset_1_cl_23:
"cluster finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1"
  proof-
    have " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (VarFor1 be finiteFINSET-1V1 &  not VarFor1 be emptyXBOOLE-0V1))"
    proof-
      have "{TARSKIK1 [TARSKIK4 {}XBOOLE-0K1,{}XBOOLE-0K1 ] } be FunctionFUNCT-1M1"
         sorry
      thus " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (VarFor1 be finiteFINSET-1V1 &  not VarFor1 be emptyXBOOLE-0V1))"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finset_1_cl_24:
  mlet "R be finiteFINSET-1V1\<bar>RelationRELAT-1M1"
"cluster domRELAT-1K1 R as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "domRELAT-1K1 R be finiteFINSET-1V1"
  proof-
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A1: "domRELAT-1K1 f =XBOOLE-0R4 R"and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 R implies f .FUNCT-1K1 x =HIDDENR1 x `1XTUPLE-0K1"
      using funct_1_sch_3 sorry
    have " for x be objectHIDDENM1 holds (x inHIDDENR3 rngFUNCT-1K2 f implies ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R)) & (( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R) implies x inHIDDENR3 rngFUNCT-1K2 f)"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      show "x inHIDDENR3 rngFUNCT-1K2 f implies ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R)"
      proof-
        have "x inHIDDENR3 rngFUNCT-1K2 f implies ( ex tVar20 be objectHIDDENM1 st [TARSKIK4 x,tVar20 ] inHIDDENR3 R)"
        proof(rule impI)
          assume "x inHIDDENR3 rngFUNCT-1K2 f"
          then obtain a where
            [ty]:"a be objectHIDDENM1" and 
            A3: "a inHIDDENR3 domRELAT-1K1 f"and A4: "f .FUNCT-1K1 a =HIDDENR1 x"
            using funct_1_def_3 sorry
          show " ex tVar20 be objectHIDDENM1 st [TARSKIK4 x,tVar20 ] inHIDDENR3 R"
          proof(rule bexI[of _ "a `2XTUPLE-0K2"])
            have A5: " ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st a =HIDDENR1 [TARSKIK4 x,y ]"
              using A1 A3 relat_1_def_1 sorry
            have "x =HIDDENR1 a `1XTUPLE-0K1"
              using A1 A2 A3 A4 sorry
            thus "[TARSKIK4 x,a `2XTUPLE-0K2 ] inHIDDENR3 R"
              using A1 A3 A5 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
      assume Given: " ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R"
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A6: "[TARSKIK4 x,y ] inHIDDENR3 R"
         sorry
      have "f .FUNCT-1K1 [TARSKIK4 x,y ] =HIDDENR1 [TARSKIK4 x,y ] `1XTUPLE-0K1"
        using A2 A6 sorry
      also have "... = x"
         sorry
      finally have "f .FUNCT-1K1 [TARSKIK4 x,y ] =HIDDENR1 x"
         sorry
      thus "x inHIDDENR3 rngFUNCT-1K2 f"
        using A1 A6 funct_1_th_3 sorry
    qed "sorry"
    then have "rngFUNCT-1K2 f =XBOOLE-0R4 domRELAT-1K1 R"
      using xtuple_0_def_12 sorry
    thus "domRELAT-1K1 R be finiteFINSET-1V1"
      using A1 finset_1_th_8 sorry
  qed
qed "sorry"

mtheorem finset_1_cl_25:
  mlet "f be FunctionFUNCT-1M1", "g be finiteFINSET-1V1\<bar>FunctionFUNCT-1M1"
"cluster f *FUNCT-1K3 g as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "f *FUNCT-1K3 g be finiteFINSET-1V1"
  proof-
    have "domRELAT-1K1 (f *FUNCT-1K3 g) c=TARSKIR1 domRELAT-1K1 g"
      using relat_1_th_25 sorry
    thus "f *FUNCT-1K3 g be finiteFINSET-1V1"
      using finset_1_th_10 sorry
  qed
qed "sorry"

mtheorem finset_1_cl_26:
  mlet "A be finiteFINSET-1V1\<bar>setHIDDENM2", "B be setHIDDENM2"
"cluster note-that finiteFINSET-1V1 for FunctionFUNCT-2M1-of(A,B)"
proof
(*coherence*)
  show " for it be FunctionFUNCT-2M1-of(A,B) holds it be finiteFINSET-1V1"
  proof-
    have " for f be FunctionFUNCT-2M1-of(A,B) holds f be finiteFINSET-1V1"
    proof(rule ballI)
      fix f assume [ty]: "f be FunctionFUNCT-2M1-of(A,B)"
      have "domRELSET-1K1\<^bsub>(A)\<^esub> f be finiteFINSET-1V1"
         sorry
      thus "f be finiteFINSET-1V1"
        using finset_1_th_10 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finset_1_cl_27:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1"
"cluster x .-->FUNCOP-1K17 y as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "x .-->FUNCOP-1K17 y be finiteFINSET-1V1"
     sorry
qed "sorry"

mtheorem finset_1_cl_28:
  mlet "R be finiteFINSET-1V1\<bar>RelationRELAT-1M1"
"cluster rngRELAT-1K2 R as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "rngRELAT-1K2 R be finiteFINSET-1V1"
  proof-
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A1: "domRELAT-1K1 f =XBOOLE-0R4 R"and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 R implies f .FUNCT-1K1 x =HIDDENR1 x `2XTUPLE-0K2"
      using funct_1_sch_3 sorry
    have " for y be objectHIDDENM1 holds (y inHIDDENR3 rngFUNCT-1K2 f implies ( ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R)) & (( ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R) implies y inHIDDENR3 rngFUNCT-1K2 f)"
    proof(rule ballI,rule conjMI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      show "y inHIDDENR3 rngFUNCT-1K2 f implies ( ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R)"
      proof-
        have "y inHIDDENR3 rngFUNCT-1K2 f implies ( ex tVar21 be objectHIDDENM1 st [TARSKIK4 tVar21,y ] inHIDDENR3 R)"
        proof(rule impI)
          assume "y inHIDDENR3 rngFUNCT-1K2 f"
          then obtain a where
            [ty]:"a be objectHIDDENM1" and 
            A3: "a inHIDDENR3 domRELAT-1K1 f"and A4: "f .FUNCT-1K1 a =HIDDENR1 y"
            using funct_1_def_3 sorry
          show " ex tVar21 be objectHIDDENM1 st [TARSKIK4 tVar21,y ] inHIDDENR3 R"
          proof(rule bexI[of _ "a `1XTUPLE-0K1"])
            have A5: " ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st a =HIDDENR1 [TARSKIK4 x,y ]"
              using A1 A3 relat_1_def_1 sorry
            have "y =HIDDENR1 a `2XTUPLE-0K2"
              using A1 A2 A3 A4 sorry
            thus "[TARSKIK4 a `1XTUPLE-0K1,y ] inHIDDENR3 R"
              using A1 A3 A5 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
      assume Given: " ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A6: "[TARSKIK4 x,y ] inHIDDENR3 R"
         sorry
      have "f .FUNCT-1K1 [TARSKIK4 x,y ] =HIDDENR1 [TARSKIK4 x,y ] `2XTUPLE-0K2"
        using A2 A6 sorry
      also have "... = y"
         sorry
      finally have "f .FUNCT-1K1 [TARSKIK4 x,y ] =HIDDENR1 y"
         sorry
      thus "y inHIDDENR3 rngFUNCT-1K2 f"
        using A1 A6 funct_1_th_3 sorry
    qed "sorry"
    then have "rngFUNCT-1K2 f =XBOOLE-0R4 rngRELAT-1K2 R"
      using xtuple_0_def_13 sorry
    thus "rngRELAT-1K2 R be finiteFINSET-1V1"
      using A1 finset_1_th_8 sorry
  qed
qed "sorry"

mtheorem finset_1_cl_29:
  mlet "f be finiteFINSET-1V1\<bar>FunctionFUNCT-1M1", "x be setHIDDENM2"
"cluster f \<inverse>FUNCT-1K6 x as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "f \<inverse>FUNCT-1K6 x be finiteFINSET-1V1"
  proof-
    have "f \<inverse>FUNCT-1K6 x c=TARSKIR1 domRELAT-1K1 f"
      using relat_1_th_132 sorry
    thus "f \<inverse>FUNCT-1K6 x be finiteFINSET-1V1"
       sorry
  qed
qed "sorry"

mtheorem finset_1_cl_30:
  mlet "f be finiteFINSET-1V1\<bar>FunctionFUNCT-1M1", "g be finiteFINSET-1V1\<bar>FunctionFUNCT-1M1"
"cluster f +*FUNCT-4K1 g as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "f +*FUNCT-4K1 g be finiteFINSET-1V1"
  proof-
    have "domRELAT-1K1 (f +*FUNCT-4K1 g) =XBOOLE-0R4 domRELAT-1K1 f \\/XBOOLE-0K2 domRELAT-1K1 g"
      using funct_4_def_1 sorry
    thus "f +*FUNCT-4K1 g be finiteFINSET-1V1"
      using finset_1_th_10 sorry
  qed
qed "sorry"

mdef finset_1_def_3 ("centeredFINSET-1V4" 70 ) where
"attr centeredFINSET-1V4 for setHIDDENM2 means
  (\<lambda>F. F <>HIDDENR2 {}XBOOLE-0K1 & ( for G be setHIDDENM2 holds (G <>HIDDENR2 {}XBOOLE-0K1 & G c=TARSKIR1 F) & G be finiteFINSET-1V1 implies meetSETFAM-1K1 G <>HIDDENR2 {}XBOOLE-0K1))"..

abbreviation(input) FINSET_1V5("finite-yieldingFINSET-1V5" 70) where
  "finite-yieldingFINSET-1V5 \<equiv> finite-yieldingFINSET-1V3"

mtheorem finset_1_def_4:
  mlet "f be FunctionFUNCT-1M1"
"redefine attr finite-yieldingFINSET-1V5 for FunctionFUNCT-1M1 means
  (\<lambda>f.  for i be objectHIDDENM1 holds i inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 i be finiteFINSET-1V1)"
proof
(*compatibility*)
  show " for f be FunctionFUNCT-1M1 holds f be finite-yieldingFINSET-1V5 iff ( for i be objectHIDDENM1 holds i inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 i be finiteFINSET-1V1)"
  proof(rule ballI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    show "f be finite-yieldingFINSET-1V5 iff ( for i be objectHIDDENM1 holds i inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 i be finiteFINSET-1V1)"
    proof-
      have "(f be finite-yieldingFINSET-1V3 implies ( for i be objectHIDDENM1 holds i inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 i be finiteFINSET-1V1)) & (( for i be objectHIDDENM1 holds i inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 i be finiteFINSET-1V1) implies f be finite-yieldingFINSET-1V3)"
      proof(rule conjMI,rule impI)
        show "f be finite-yieldingFINSET-1V3 implies ( for i be objectHIDDENM1 holds i inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 i be finiteFINSET-1V1)"
        proof(rule impI,rule ballI,rule impI)
          assume A1: "f be finite-yieldingFINSET-1V3"
          fix i assume [ty]: "i be objectHIDDENM1"
          assume "i inHIDDENR3 domRELAT-1K1 f"
          show "f .FUNCT-1K1 i be finiteFINSET-1V1"
          proof-
            have cases: "i inHIDDENR3 domRELAT-1K1 f or  not i inHIDDENR3 domRELAT-1K1 f"
               sorry
            have case1: "i inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 i be finiteFINSET-1V1"
            proof(rule impI)
              assume "i inHIDDENR3 domRELAT-1K1 f"
              then have "f .FUNCT-1K1 i inTARSKIR2 rngFUNCT-1K2 f"
                using funct_1_th_3 sorry
              thus "f .FUNCT-1K1 i be finiteFINSET-1V1"
                using A1 sorry
            qed
            have case2: " not i inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 i be finiteFINSET-1V1"
            proof(rule impI)
              assume " not i inHIDDENR3 domRELAT-1K1 f"
              thus "f .FUNCT-1K1 i be finiteFINSET-1V1"
                using funct_1_def_2 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed "sorry"
        assume A2: " for i be objectHIDDENM1 holds i inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 i be finiteFINSET-1V1"
        have " for i be setHIDDENM2 holds i inTARSKIR2 rngFUNCT-1K2 f implies i be finiteFINSET-1V1"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be setHIDDENM2"
          assume "i inTARSKIR2 rngFUNCT-1K2 f"
          then have " ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & i =XBOOLE-0R4 f .FUNCT-1K1 x"
            using funct_1_def_3 sorry
          thus "i be finiteFINSET-1V1"
            using A2 sorry
        qed "sorry"
        thus "f be finite-yieldingFINSET-1V3"
          using finset_1_def_2 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

syntax FINSET_1V6 :: " Set \<Rightarrow> Ty" ("finite-yieldingFINSET-1V6\<^bsub>'( _ ')\<^esub>" [0]70)
translations "finite-yieldingFINSET-1V6\<^bsub>(I)\<^esub>" \<rightharpoonup> "finite-yieldingFINSET-1V3"

mtheorem finset_1_def_5:
  mlet "I be setHIDDENM2", "IT be I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1"
"redefine attr finite-yieldingFINSET-1V6\<^bsub>(I)\<^esub> for I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 means
  (\<lambda>IT.  for i be objectHIDDENM1 holds i inHIDDENR3 I implies IT .FUNCT-1K1 i be finiteFINSET-1V1)"
proof
(*compatibility*)
  show " for IT be I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds IT be finite-yieldingFINSET-1V6\<^bsub>(I)\<^esub> iff ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies IT .FUNCT-1K1 i be finiteFINSET-1V1)"
  proof(rule ballI)
    fix IT assume [ty]: "IT be I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1"
    show "IT be finite-yieldingFINSET-1V6\<^bsub>(I)\<^esub> iff ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies IT .FUNCT-1K1 i be finiteFINSET-1V1)"
    proof-
      have "(IT be finite-yieldingFINSET-1V5 implies ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies IT .FUNCT-1K1 i be finiteFINSET-1V1)) & (( for i be objectHIDDENM1 holds i inHIDDENR3 I implies IT .FUNCT-1K1 i be finiteFINSET-1V1) implies IT be finite-yieldingFINSET-1V3)"
      proof(rule conjMI,rule impI)
        show "IT be finite-yieldingFINSET-1V5 implies ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies IT .FUNCT-1K1 i be finiteFINSET-1V1)"
        proof(rule impI,rule ballI,rule impI)
          assume A1: "IT be finite-yieldingFINSET-1V5"
          fix i assume [ty]: "i be objectHIDDENM1"
          assume "i inHIDDENR3 I"
          show "IT .FUNCT-1K1 i be finiteFINSET-1V1"
          proof-
            have cases: "i inHIDDENR3 domRELSET-1K1\<^bsub>(I)\<^esub> IT or  not i inHIDDENR3 domRELSET-1K1\<^bsub>(I)\<^esub> IT"
               sorry
            have case1: "i inHIDDENR3 domRELSET-1K1\<^bsub>(I)\<^esub> IT implies IT .FUNCT-1K1 i be finiteFINSET-1V1"
            proof(rule impI)
              assume "i inHIDDENR3 domRELSET-1K1\<^bsub>(I)\<^esub> IT"
              thus "IT .FUNCT-1K1 i be finiteFINSET-1V1"
                using A1 sorry
            qed
            have case2: " not i inHIDDENR3 domRELSET-1K1\<^bsub>(I)\<^esub> IT implies IT .FUNCT-1K1 i be finiteFINSET-1V1"
            proof(rule impI)
              assume " not i inHIDDENR3 domRELSET-1K1\<^bsub>(I)\<^esub> IT"
              thus "IT .FUNCT-1K1 i be finiteFINSET-1V1"
                using funct_1_def_2 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed "sorry"
        assume A2: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies IT .FUNCT-1K1 i be finiteFINSET-1V1"
        have " for i be objectHIDDENM1 holds  not (i inHIDDENR3 domRELAT-1K1 IT &  not IT .FUNCT-1K1 i be finiteFINSET-1V1)"
        proof(rule ballI)
          fix i assume [ty]: "i be objectHIDDENM1"
          have "domRELSET-1K1\<^bsub>(I)\<^esub> IT c=TARSKIR1 I"
             sorry
          thus " not (i inHIDDENR3 domRELAT-1K1 IT &  not IT .FUNCT-1K1 i be finiteFINSET-1V1)"
            using A2 sorry
        qed "sorry"
        thus "IT be finite-yieldingFINSET-1V3"
          using finset_1_def_4 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

mtheorem finset_1_th_15:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds B be infiniteFINSET-1V2 implies  not B inTARSKIR2 [:ZFMISC-1K2 A,B :]"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds B be infiniteFINSET-1V2 & B inTARSKIR2 [:ZFMISC-1K2 A,B :] implies  not  True "
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    assume A1: "B be infiniteFINSET-1V2"
      and A2: "B inTARSKIR2 [:ZFMISC-1K2 A,B :]"
    have " ex x be objectHIDDENM1 st x inHIDDENR3 A & B =HIDDENR1 [TARSKIK4 x,{TARSKIK1 x} ]"
      using A2 zfmisc_1_th_129 sorry
    thus " not  True "
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finset_1_cl_31:
  mlet "I be setHIDDENM2", "f be I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1"
"cluster finiteFINSET-1V1\<bar>I -definedRELAT-1V4\<bar>f -compatibleFUNCT-1V7 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be finiteFINSET-1V1\<bar>I -definedRELAT-1V4\<bar>f -compatibleFUNCT-1V7"
  proof-
    have " ex tVar22 be FunctionFUNCT-1M1 st (tVar22 be finiteFINSET-1V1 & tVar22 be I -definedRELAT-1V4) & tVar22 be f -compatibleFUNCT-1V7"
    proof-
      show " ex tVar22 be FunctionFUNCT-1M1 st (tVar22 be finiteFINSET-1V1 & tVar22 be I -definedRELAT-1V4) & tVar22 be f -compatibleFUNCT-1V7"
      proof(rule bexI[of _ "{}XBOOLE-0K1"])
        show "({}XBOOLE-0K1 be finiteFINSET-1V1 & {}XBOOLE-0K1 be I -definedRELAT-1V4) & {}XBOOLE-0K1 be f -compatibleFUNCT-1V7"
          using funct_1_th_104 relat_1_th_171 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finset_1_cl_32:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"cluster finiteFINSET-1V1\<bar>X -definedRELAT-1V4\<bar>Y -valuedRELAT-1V5 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be finiteFINSET-1V1\<bar>X -definedRELAT-1V4\<bar>Y -valuedRELAT-1V5"
  proof-
    have " ex tVar23 be FunctionFUNCT-1M1 st (tVar23 be finiteFINSET-1V1 & tVar23 be X -definedRELAT-1V4) & tVar23 be Y -valuedRELAT-1V5"
    proof-
      show " ex tVar23 be FunctionFUNCT-1M1 st (tVar23 be finiteFINSET-1V1 & tVar23 be X -definedRELAT-1V4) & tVar23 be Y -valuedRELAT-1V5"
      proof(rule bexI[of _ "{}XBOOLE-0K1"])
        show "({}XBOOLE-0K1 be finiteFINSET-1V1 & {}XBOOLE-0K1 be X -definedRELAT-1V4) & {}XBOOLE-0K1 be Y -valuedRELAT-1V5"
          using relat_1_th_171 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finset_1_cl_33:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster X -definedRELAT-1V4\<bar>Y -valuedRELAT-1V5\<bar> non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be X -definedRELAT-1V4\<bar>Y -valuedRELAT-1V5\<bar> non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1"
  proof-
    have " ex F be setHIDDENM2 st F be X -definedRELAT-1V4 & (F be Y -valuedRELAT-1V5 & ( not F be emptyXBOOLE-0V1 & F be finiteFINSET-1V1))"
    proof-
      let ?x = "the ElementSUBSET-1M1-of X"
      let ?y = "the ElementSUBSET-1M1-of Y"
      obtain F where 
        [ty]:"F be setHIDDENM2" and FDef:"F = ?x .-->FUNCOP-1K17 ?y"
         sorry
      show " ex F be setHIDDENM2 st F be X -definedRELAT-1V4 & (F be Y -valuedRELAT-1V5 & ( not F be emptyXBOOLE-0V1 & F be finiteFINSET-1V1))"
      proof(rule bexI[of _ "F"],rule conjMI,rule conjMI)
        show "F be X -definedRELAT-1V4"
           sorry
        show "F be Y -valuedRELAT-1V5"
           sorry
        show " not F be emptyXBOOLE-0V1 & F be finiteFINSET-1V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finset_1_cl_34:
  mlet "A be setHIDDENM2", "F be finiteFINSET-1V1\<bar>RelationRELAT-1M1"
"cluster A  |`RELAT-1K9 F as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "A  |`RELAT-1K9 F be finiteFINSET-1V1"
  proof-
    have "A  |`RELAT-1K9 F c=RELAT-1R2 F"
      using relat_1_th_86 sorry
    thus "A  |`RELAT-1K9 F be finiteFINSET-1V1"
       sorry
  qed
qed "sorry"

mtheorem finset_1_cl_35:
  mlet "A be setHIDDENM2", "F be finiteFINSET-1V1\<bar>RelationRELAT-1M1"
"cluster F  |RELAT-1K8 A as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "F  |RELAT-1K8 A be finiteFINSET-1V1"
  proof-
    have "F  |RELAT-1K8 A c=RELAT-1R2 F"
      using relat_1_th_59 sorry
    thus "F  |RELAT-1K8 A be finiteFINSET-1V1"
       sorry
  qed
qed "sorry"

mtheorem finset_1_cl_36:
  mlet "A be finiteFINSET-1V1\<bar>setHIDDENM2", "F be FunctionFUNCT-1M1"
"cluster F  |RELAT-1K8 A as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "F  |RELAT-1K8 A be finiteFINSET-1V1"
  proof-
    have "domRELAT-1K1 (F  |RELAT-1K8 A) c=TARSKIR1 A"
      using relat_1_th_58 sorry
    thus "F  |RELAT-1K8 A be finiteFINSET-1V1"
      using finset_1_th_10 sorry
  qed
qed "sorry"

mtheorem finset_1_cl_37:
  mlet "R be finiteFINSET-1V1\<bar>RelationRELAT-1M1"
"cluster fieldRELAT-1K3 R as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "fieldRELAT-1K3 R be finiteFINSET-1V1"
     sorry
qed "sorry"

mtheorem finset_1_cl_38:
"cluster trivialSUBSET-1V2 also-is finiteFINSET-1V1 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be trivialSUBSET-1V2 implies it be finiteFINSET-1V1"
  proof-
    have " for S be setHIDDENM2 holds S be trivialSUBSET-1V2 implies S be finiteFINSET-1V1"
    proof(rule ballI,rule impI)
      fix S assume [ty]: "S be setHIDDENM2"
      assume A1: "S be trivialSUBSET-1V2"
      show "S be finiteFINSET-1V1"
      proof-
        have cases: "S be emptyXBOOLE-0V1 or ( ex x be objectHIDDENM1 st S =XBOOLE-0R4 {TARSKIK1 x})"
          using A1 zfmisc_1_th_131 sorry
        have case1: "S be emptyXBOOLE-0V1 implies S be finiteFINSET-1V1"
        proof(rule impI)
          assume "S be emptyXBOOLE-0V1"
          thus "S be finiteFINSET-1V1"
             sorry
        qed
        have case2: "( ex x be objectHIDDENM1 st S =XBOOLE-0R4 {TARSKIK1 x}) implies S be finiteFINSET-1V1"
        proof(rule impI)
          assume " ex x be objectHIDDENM1 st S =XBOOLE-0R4 {TARSKIK1 x}"
          thus "S be finiteFINSET-1V1"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finset_1_cl_39:
"cluster infiniteFINSET-1V2 also-is  non trivialSUBSET-1V2 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be infiniteFINSET-1V2 implies it be  non trivialSUBSET-1V2"
     sorry
qed "sorry"

mtheorem finset_1_cl_40:
  mlet "X be  non trivialSUBSET-1V2\<bar>setHIDDENM2"
"cluster finiteFINSET-1V1\<bar> non trivialSUBSET-1V2 for SubsetSUBSET-1M2-of X"
proof
(*existence*)
  show " ex it be SubsetSUBSET-1M2-of X st it be finiteFINSET-1V1\<bar> non trivialSUBSET-1V2"
  proof-
    have " ex tVar25 be SubsetSUBSET-1M2-of X st tVar25 be finiteFINSET-1V1 &  not tVar25 be trivialSUBSET-1V2"
    proof-
      obtain a1 a2 where
        [ty]:"a1 be objectHIDDENM1" "a2 be objectHIDDENM1" and 
        A1: "(a1 inHIDDENR3 X & a2 inHIDDENR3 X) & a1 <>HIDDENR2 a2"
        using zfmisc_1_def_10 sorry
      obtain A where 
        [ty]:"A be SubsetSUBSET-1M2-of X" and ADef:"A = {TARSKIK2 a1,a2 }"
        using A1 zfmisc_1_th_32 sorry
      show " ex tVar25 be SubsetSUBSET-1M2-of X st tVar25 be finiteFINSET-1V1 &  not tVar25 be trivialSUBSET-1V2"
      proof(rule bexI[of _ "A"],rule conjMI)
        show "A be finiteFINSET-1V1"
           sorry
        have "a1 inHIDDENR3 A & a2 inHIDDENR3 A"
          using tarski_def_2 sorry
        thus " not A be trivialSUBSET-1V2"
          using A1 zfmisc_1_def_10 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finset_1_cl_41:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1", "a be objectHIDDENM1", "b be objectHIDDENM1"
"cluster (x,y)-->FUNCT-4K6(a,b) as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "(x,y)-->FUNCT-4K6(a,b) be finiteFINSET-1V1"
     sorry
qed "sorry"

mdef finset_1_def_6 ("finite-memberedFINSET-1V7" 70 ) where
"attr finite-memberedFINSET-1V7 for setHIDDENM2 means
  (\<lambda>A.  for B be setHIDDENM2 holds B inTARSKIR2 A implies B be finiteFINSET-1V1)"..

mtheorem finset_1_cl_42:
"cluster emptyXBOOLE-0V1 also-is finite-memberedFINSET-1V7 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be emptyXBOOLE-0V1 implies it be finite-memberedFINSET-1V7"
     sorry
qed "sorry"

mtheorem finset_1_cl_43:
  mlet "A be finite-memberedFINSET-1V7\<bar>setHIDDENM2"
"cluster note-that finiteFINSET-1V1 for ElementSUBSET-1M1-of A"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of A holds it be finiteFINSET-1V1"
  proof-
    have " for B be ElementSUBSET-1M1-of A holds B be finiteFINSET-1V1"
    proof(rule ballI)
      fix B assume [ty]: "B be ElementSUBSET-1M1-of A"
      show "B be finiteFINSET-1V1"
      proof-
        have cases: "A be emptyXBOOLE-0V1 or  not A be emptyXBOOLE-0V1"
           sorry
        have case1: "A be emptyXBOOLE-0V1 implies B be finiteFINSET-1V1"
        proof(rule impI)
          assume "A be emptyXBOOLE-0V1"
          thus "B be finiteFINSET-1V1"
            using subset_1_def_1 sorry
        qed
        have case2: " not A be emptyXBOOLE-0V1 implies B be finiteFINSET-1V1"
        proof(rule impI)
          assume " not A be emptyXBOOLE-0V1"
          thus "B be finiteFINSET-1V1"
            using finset_1_def_6 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finset_1_cl_44:
"cluster  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>finite-memberedFINSET-1V7 for setHIDDENM2"
proof
(*existence*)
  show " ex it be setHIDDENM2 st it be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>finite-memberedFINSET-1V7"
  proof-
    have " ex x be setHIDDENM2 st x be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1 & x be finite-memberedFINSET-1V7"
    proof-
      obtain x where 
        [ty]:"x be setHIDDENM2" and xDef:"x = {TARSKIK1 {TARSKIK1 {}XBOOLE-0K1 } }"
         sorry
      show " ex x be setHIDDENM2 st x be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1 & x be finite-memberedFINSET-1V7"
      proof(rule bexI[of _ "x"],rule conjMI)
        show "x be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1"
           sorry
        have " for y be setHIDDENM2 holds  not (y inTARSKIR2 x &  not y be finiteFINSET-1V1)"
        proof(rule ballI)
          fix y assume [ty]: "y be setHIDDENM2"
          show " not (y inTARSKIR2 x &  not y be finiteFINSET-1V1)"
            using tarski_def_1 sorry
        qed "sorry"
        thus "x be finite-memberedFINSET-1V7"
          using finset_1_def_6 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finset_1_cl_45:
  mlet "X be finiteFINSET-1V1\<bar>setHIDDENM2"
"cluster {TARSKIK1 X} as-term-is finite-memberedFINSET-1V7"
proof
(*coherence*)
  show "{TARSKIK1 X} be finite-memberedFINSET-1V7"
    using tarski_def_1 sorry
qed "sorry"

mtheorem finset_1_cl_46:
  mlet "X be finiteFINSET-1V1\<bar>setHIDDENM2"
"cluster boolSETFAM-1K9 X as-term-is finite-memberedFINSET-1V7"
proof
(*coherence*)
  show "boolSETFAM-1K9 X be finite-memberedFINSET-1V7"
     sorry
qed "sorry"

mtheorem finset_1_cl_47:
  mlet "X be finiteFINSET-1V1\<bar>setHIDDENM2", "Y be finiteFINSET-1V1\<bar>setHIDDENM2"
"cluster {TARSKIK2 X,Y } as-term-is finite-memberedFINSET-1V7"
proof
(*coherence*)
  show "{TARSKIK2 X,Y } be finite-memberedFINSET-1V7"
    using tarski_def_2 sorry
qed "sorry"

mtheorem finset_1_cl_48:
  mlet "X be finite-memberedFINSET-1V7\<bar>setHIDDENM2"
"cluster note-that finite-memberedFINSET-1V7 for SubsetSUBSET-1M2-of X"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of X holds it be finite-memberedFINSET-1V7"
     sorry
qed "sorry"

mtheorem finset_1_cl_49:
  mlet "X be finite-memberedFINSET-1V7\<bar>setHIDDENM2", "Y be finite-memberedFINSET-1V7\<bar>setHIDDENM2"
"cluster X \\/XBOOLE-0K2 Y as-term-is finite-memberedFINSET-1V7"
proof
(*coherence*)
  show "X \\/XBOOLE-0K2 Y be finite-memberedFINSET-1V7"
  proof-
    have " for x be setHIDDENM2 holds x inTARSKIR2 X \\/XBOOLE-0K2 Y implies x be finiteFINSET-1V1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be setHIDDENM2"
      assume "x inTARSKIR2 X \\/XBOOLE-0K2 Y"
      then have "x inTARSKIR2 X or x inTARSKIR2 Y"
        using xboole_0_def_3 sorry
      thus "x be finiteFINSET-1V1"
         sorry
    qed "sorry"
    thus "X \\/XBOOLE-0K2 Y be finite-memberedFINSET-1V7"
      using finset_1_def_6 sorry
  qed
qed "sorry"

mtheorem finset_1_cl_50:
  mlet "X be finiteFINSET-1V1\<bar>finite-memberedFINSET-1V7\<bar>setHIDDENM2"
"cluster unionTARSKIK3 X as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "unionTARSKIK3 X be finiteFINSET-1V1"
  proof-
    have " for x be setHIDDENM2 holds x inTARSKIR2 X implies x be finiteFINSET-1V1"
       sorry
    thus "unionTARSKIK3 X be finiteFINSET-1V1"
      using finset_1_th_7 sorry
  qed
qed "sorry"

mtheorem finset_1_cl_51:
"cluster  non emptyXBOOLE-0V1\<bar>finite-yieldingFINSET-1V5 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be  non emptyXBOOLE-0V1\<bar>finite-yieldingFINSET-1V5"
  proof-
    have " ex F be setHIDDENM2 st F be  non emptyXBOOLE-0V1 & F be finite-yieldingFINSET-1V5"
    proof-
      obtain F where 
        [ty]:"F be setHIDDENM2" and FDef:"F = {TARSKIK1 {}XBOOLE-0K1 } .-->FUNCOP-1K17 {TARSKIK1 {}XBOOLE-0K1 }"
         sorry
      show " ex F be setHIDDENM2 st F be  non emptyXBOOLE-0V1 & F be finite-yieldingFINSET-1V5"
      proof(rule bexI[of _ "F"],rule conjMI)
        show "F be  non emptyXBOOLE-0V1"
           sorry
        have " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK1 {TARSKIK1 {}XBOOLE-0K1 } } implies F .FUNCT-1K1 x be finiteFINSET-1V1"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 {TARSKIK1 {TARSKIK1 {}XBOOLE-0K1 } }"
          then have "x =HIDDENR1 {TARSKIK1 {}XBOOLE-0K1 }"
            using tarski_def_1 sorry
          thus "F .FUNCT-1K1 x be finiteFINSET-1V1"
            using funcop_1_th_72 sorry
        qed "sorry"
        thus "F be finite-yieldingFINSET-1V5"
          using finset_1_def_5 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finset_1_cl_52:
"cluster emptyXBOOLE-0V1 also-is finite-yieldingFINSET-1V3 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be emptyXBOOLE-0V1 implies it be finite-yieldingFINSET-1V3"
     sorry
qed "sorry"

mtheorem finset_1_cl_53:
  mlet "F be finite-yieldingFINSET-1V5\<bar>FunctionFUNCT-1M1", "x be objectHIDDENM1"
"cluster F .FUNCT-1K1 x as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "F .FUNCT-1K1 x be finiteFINSET-1V1"
  proof-
    show "F .FUNCT-1K1 x be finiteFINSET-1V1"
    proof-
      have cases: "x inHIDDENR3 domRELAT-1K1 F or  not x inHIDDENR3 domRELAT-1K1 F"
         sorry
      have case1: "x inHIDDENR3 domRELAT-1K1 F implies F .FUNCT-1K1 x be finiteFINSET-1V1"
      proof(rule impI)
        assume "x inHIDDENR3 domRELAT-1K1 F"
        thus "F .FUNCT-1K1 x be finiteFINSET-1V1"
          using finset_1_def_4 sorry
      qed
      have case2: " not x inHIDDENR3 domRELAT-1K1 F implies F .FUNCT-1K1 x be finiteFINSET-1V1"
      proof(rule impI)
        assume " not x inHIDDENR3 domRELAT-1K1 F"
        thus "F .FUNCT-1K1 x be finiteFINSET-1V1"
          using funct_1_def_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
qed "sorry"

mtheorem finset_1_cl_54:
  mlet "F be finite-yieldingFINSET-1V3\<bar>RelationRELAT-1M1"
"cluster rngRELAT-1K2 F as-term-is finite-memberedFINSET-1V7"
proof
(*coherence*)
  show "rngRELAT-1K2 F be finite-memberedFINSET-1V7"
    using finset_1_def_2 sorry
qed "sorry"

end
