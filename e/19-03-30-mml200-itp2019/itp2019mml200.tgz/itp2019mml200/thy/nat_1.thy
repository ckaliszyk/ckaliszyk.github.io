theory nat_1
  imports card_1 pboole axioms xreal_1
   "../mizar_extension/E_number"
begin
(*begin*)
mtheorem nat_1_cl_1:
"cluster naturalORDINAL1V7 for objectHIDDENM1"
proof
(*existence*)
  show " ex it be objectHIDDENM1 st it be naturalORDINAL1V7"
  proof-
    have " ex tVar1 be objectHIDDENM1 st tVar1 be naturalORDINAL1V7"
    proof-
      show " ex tVar1 be objectHIDDENM1 st tVar1 be naturalORDINAL1V7"
      proof(rule bexI[of _ "0NUMBERSK6"])
        show "0NUMBERSK6 be naturalORDINAL1V7"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax NAT_1M1 :: "Ty" ("NatNAT-1M1" 70)
translations "NatNAT-1M1" \<rightharpoonup> "naturalORDINAL1V7\<bar>numberORDINAL1M2"

reserve x for "RealXREAL-0M1"
reserve p, k, l, m, n, s, h, i, j, k1, t, t1 for "NatNAT-1M1"
reserve X for "SubsetSUBSET-1M2-of REALNUMBERSK2"
mtheorem nat_1_th_1:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds 0NUMBERSK6 inTARSKIR2 X & ( for x be RealXREAL-0M1 holds x inHIDDENR3 X implies x +XCMPLX-0K2 \<one>\<^sub>M inTARSKIR2 X) implies ( for n be NatNAT-1M1 holds n inTARSKIR2 X)"
proof-
  have " for A be SubsetSUBSET-1M2-of REALNUMBERSK2 holds 0NUMBERSK6 inTARSKIR2 A implies (( for x be RealXREAL-0M1 holds x inHIDDENR3 A implies x +XCMPLX-0K2 \<one>\<^sub>M inTARSKIR2 A) implies ( for n be NatNAT-1M1 holds n inTARSKIR2 A))"
  proof(rule ballI,rule impI,rule impI)
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "0NUMBERSK6 inTARSKIR2 A"
    assume " for x be RealXREAL-0M1 holds x inHIDDENR3 A implies x +XCMPLX-0K2 \<one>\<^sub>M inTARSKIR2 A"
    then have "NATNUMBERSK1 c=TARSKIR1 A"
      using A1 axioms_th_3 sorry
    thus " for n be NatNAT-1M1 holds n inTARSKIR2 A"
      using ordinal1_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_1_cl_2:
  mlet "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster n +XCMPLX-0K2 k as-term-is naturalORDINAL1V7"
proof
(*coherence*)
  show "n +XCMPLX-0K2 k be naturalORDINAL1V7"
  proof-
    have "n inHIDDENR3 NATNUMBERSK1 & k inHIDDENR3 NATNUMBERSK1"
      using ordinal1_def_12 sorry
    thus "n +XCMPLX-0K2 k be naturalORDINAL1V7"
      using axioms_th_2 sorry
  qed
qed "sorry"

abbreviation(input) NAT_1K1(" _ +NAT-1K1  _ " [132,132]132) where
  "n +NAT-1K1 k \<equiv> n +XCMPLX-0K2 k"

mtheorem nat_1_add_1:
  mlet "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "k be ElementSUBSET-1M1-of NATNUMBERSK1"
"cluster n +XCMPLX-0K2 k as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "n +XCMPLX-0K2 k be ElementSUBSET-1M1-of NATNUMBERSK1"
    using ordinal1_def_12 sorry
qed "sorry"

(*\$CS*)
(*\$N The Principle of Mathematical Induction*)
theorem nat_1_sch_2:
  fixes Pp1 
  assumes
    A1: "Pp1(0NUMBERSK6)" and
   A2: " for k be NatNAT-1M1 holds Pp1(k) implies Pp1(k +NAT-1K1 \<one>\<^sub>M)"
  shows " for k be NatNAT-1M1 holds Pp1(k)"
  proof(rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    obtain X where
      [ty]:"X be SubsetSUBSET-1M2-of NATNUMBERSK1" and 
      A3: " for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds x inTARSKIR2 X iff Pp1(x)"
      using subset_1_sch_3 sorry
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 X implies x +XCMPLX-0K2 \<one>\<^sub>M inTARSKIR2 X"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 X"
      then obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A5: "Pp1(k)"and A6: "k =HIDDENR1 x"
        using A3 sorry
      have "Pp1(k +NAT-1K1 \<one>\<^sub>M)"
        using A2 A5 sorry
      thus "x +XCMPLX-0K2 \<one>\<^sub>M inTARSKIR2 X"
        using A3 A6 sorry
    qed "sorry"
    have "X c=TARSKIR1 NATNUMBERSK1 & NATNUMBERSK1 c=TARSKIR1 REALNUMBERSK2"
      using numbers_th_19 sorry
    then have "X be SubsetSUBSET-1M2-of REALNUMBERSK2"
      using xboole_1_th_1 sorry
    then have "k inTARSKIR2 X"
      using A1 A3 A4 nat_1_th_1 sorry
    thus "Pp1(k)"
      using A3 sorry
  qed "sorry"

mtheorem nat_1_cl_3:
  mlet "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster n *XCMPLX-0K3 k as-term-is naturalORDINAL1V7"
proof
(*coherence*)
  show "n *XCMPLX-0K3 k be naturalORDINAL1V7"
  proof-
    have A0: "k be NatNAT-1M1"
      using tarski_th_1 sorry
    let ?P = "\<lambda>Lamb1. n *XCMPLX-0K3 Lamb1 be naturalORDINAL1V7"
    have A1: " for m be NatNAT-1M1 holds ?P(m) implies ?P(m +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for m be NatNAT-1M1 holds n *XCMPLX-0K3 m be naturalORDINAL1V7 implies n *XCMPLX-0K3 (m +NAT-1K1 \<one>\<^sub>M) be naturalORDINAL1V7"
      proof(rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "?P(m)"
        then obtain k where 
          [ty]:"k be NatNAT-1M1" and kDef:"k = n *XCMPLX-0K3 m"
           sorry
        have "k +XCMPLX-0K2 n be NatNAT-1M1"
           sorry
        thus "n *XCMPLX-0K3 (m +NAT-1K1 \<one>\<^sub>M) be naturalORDINAL1V7"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A2: "?P(0NUMBERSK6)"
       sorry
    have " for m be NatNAT-1M1 holds ?P(m)"
      using nat_1_sch_2 A2 A1 sorry
    thus "n *XCMPLX-0K3 k be naturalORDINAL1V7"
      using A0 sorry
  qed
qed "sorry"

abbreviation(input) NAT_1K2(" _ *NAT-1K2  _ " [164,164]164) where
  "n *NAT-1K2 k \<equiv> n *XCMPLX-0K3 k"

mtheorem nat_1_add_2:
  mlet "n be ElementSUBSET-1M1-of NATNUMBERSK1", "k be ElementSUBSET-1M1-of NATNUMBERSK1"
"cluster n *XCMPLX-0K3 k as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "n *XCMPLX-0K3 k be ElementSUBSET-1M1-of NATNUMBERSK1"
    using ordinal1_def_12 sorry
qed "sorry"

mtheorem nat_1_th_2:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds 0NUMBERSK6 <=XXREAL-0R1 i"
proof(rule ballI)
  fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
  have A0: "i be NatNAT-1M1"
    using tarski_th_1 sorry
  let ?P = "\<lambda>Lamb1. 0NUMBERSK6 <=XXREAL-0R1 Lamb1"
  have A1: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
     sorry
  have A2: "?P(0NUMBERSK6)"
     sorry
  have " for k be NatNAT-1M1 holds ?P(k)"
    using nat_1_sch_2 A2 A1 sorry
  thus "0NUMBERSK6 <=XXREAL-0R1 i"
    using A0 sorry
qed "sorry"

mtheorem nat_1_th_3:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds 0NUMBERSK6 <>HIDDENR2 i implies 0NUMBERSK6 <XXREAL-0R3 i"
  using nat_1_th_2 sorry

mtheorem nat_1_th_4:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for h be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i <=XXREAL-0R1 j implies i *XCMPLX-0K3 h <=XXREAL-0R1 j *XCMPLX-0K3 h"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for h be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  not (i <=XXREAL-0R1 j &  not i *XCMPLX-0K3 h <=XXREAL-0R1 j *XCMPLX-0K3 h)"
  proof(rule ballI,rule ballI,rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix j assume [ty]: "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix h assume [ty]: "h be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have "0NUMBERSK6 <=XXREAL-0R1 h"
      using nat_1_th_2 sorry
    thus " not (i <=XXREAL-0R1 j &  not i *XCMPLX-0K3 h <=XXREAL-0R1 j *XCMPLX-0K3 h)"
      using xreal_1_th_64 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_1_th_5:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds 0NUMBERSK6 <XXREAL-0R3 i +NAT-1K1 \<one>\<^sub>M"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  not 0NUMBERSK6 <XXREAL-0R3 i +NAT-1K1 \<one>\<^sub>M"
  proof(rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have "0NUMBERSK6 <=XXREAL-0R1 i"
      using nat_1_th_2 sorry
    thus " not 0NUMBERSK6 <XXREAL-0R3 i +NAT-1K1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_1_th_6:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i =HIDDENR1 0NUMBERSK6 or ( ex k be NatNAT-1M1 st i =HIDDENR1 k +NAT-1K1 \<one>\<^sub>M)"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  not ( not i =HIDDENR1 0NUMBERSK6 & ( for k be NatNAT-1M1 holds  not i =HIDDENR1 k +NAT-1K1 \<one>\<^sub>M))"
  proof(rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have A0: "i be NatNAT-1M1"
      using tarski_th_1 sorry
    let ?P = "\<lambda>Lamb1. Lamb1 =HIDDENR1 0NUMBERSK6 or ( ex k be NatNAT-1M1 st Lamb1 =HIDDENR1 k +NAT-1K1 \<one>\<^sub>M)"
    have A1: " for h be NatNAT-1M1 holds ?P(h) implies ?P(h +NAT-1K1 \<one>\<^sub>M)"
       sorry
    have A2: "?P(0NUMBERSK6)"
       sorry
    have " for i be NatNAT-1M1 holds ?P(i)"
      using nat_1_sch_2 A2 A1 sorry
    thus " not ( not i =HIDDENR1 0NUMBERSK6 & ( for k be NatNAT-1M1 holds  not i =HIDDENR1 k +NAT-1K1 \<one>\<^sub>M))"
      using A0 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_1_th_7:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i +XCMPLX-0K2 j =XBOOLE-0R4 0NUMBERSK6 implies i =HIDDENR1 0NUMBERSK6 & j =HIDDENR1 0NUMBERSK6"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  not (i +XCMPLX-0K2 j =XBOOLE-0R4 0NUMBERSK6 &  not (i =HIDDENR1 0NUMBERSK6 & j =HIDDENR1 0NUMBERSK6))"
  proof(rule ballI,rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix j assume [ty]: "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have "0NUMBERSK6 <=XXREAL-0R1 i & 0NUMBERSK6 <=XXREAL-0R1 j"
      using nat_1_th_2 sorry
    thus " not (i +XCMPLX-0K2 j =XBOOLE-0R4 0NUMBERSK6 &  not (i =HIDDENR1 0NUMBERSK6 & j =HIDDENR1 0NUMBERSK6))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_1_cl_4:
"cluster zeroORDINAL1V8\<bar>naturalORDINAL1V7 for objectHIDDENM1"
proof
(*existence*)
  show " ex it be objectHIDDENM1 st it be zeroORDINAL1V8\<bar>naturalORDINAL1V7"
  proof-
    have " ex tVar2 be objectHIDDENM1 st tVar2 be zeroORDINAL1V8 & tVar2 be naturalORDINAL1V7"
    proof-
      show " ex tVar2 be objectHIDDENM1 st tVar2 be zeroORDINAL1V8 & tVar2 be naturalORDINAL1V7"
      proof(rule bexI[of _ "0NUMBERSK6"])
        show "0NUMBERSK6 be zeroORDINAL1V8 & 0NUMBERSK6 be naturalORDINAL1V7"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem nat_1_cl_5:
"cluster  non zeroORDINAL1V8\<bar>naturalORDINAL1V7 for objectHIDDENM1"
proof
(*existence*)
  show " ex it be objectHIDDENM1 st it be  non zeroORDINAL1V8\<bar>naturalORDINAL1V7"
  proof-
    have " ex tVar3 be objectHIDDENM1 st  not tVar3 be zeroORDINAL1V8 & tVar3 be naturalORDINAL1V7"
    proof-
      show " ex tVar3 be objectHIDDENM1 st  not tVar3 be zeroORDINAL1V8 & tVar3 be naturalORDINAL1V7"
      proof(rule bexI[of _ "\<one>\<^sub>M"])
        show " not \<one>\<^sub>M be zeroORDINAL1V8 & \<one>\<^sub>M be naturalORDINAL1V7"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem nat_1_cl_6:
  mlet "m be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "n be  non zeroORDINAL1V8\<bar>naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster m +XCMPLX-0K2 n as-term-is  non zeroORDINAL1V8"
proof
(*coherence*)
  show "m +XCMPLX-0K2 n be  non zeroORDINAL1V8"
    using nat_1_th_7 sorry
qed "sorry"

mtheorem nat_1_cl_7:
  mlet "m be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "n be  non zeroORDINAL1V8\<bar>naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster n +XCMPLX-0K2 m as-term-is  non zeroORDINAL1V8"
proof
(*coherence*)
  show "n +XCMPLX-0K2 m be  non zeroORDINAL1V8"
     sorry
qed "sorry"

theorem nat_1_sch_3:
  fixes Nf0 Ff2 Pp2 
  assumes
[ty]: "Nf0 be NatNAT-1M1" and
  [ty_func]: "\<And> x1 x2. x1 be NatNAT-1M1 \<Longrightarrow> x2 be NatNAT-1M1 \<Longrightarrow> Ff2(x1,x2) be NatNAT-1M1" and
   A1: " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds Pp2(k,n) iff k =XBOOLE-0R4 0NUMBERSK6 & n =XBOOLE-0R4 Nf0 or ( ex m be NatNAT-1M1 st  ex l be NatNAT-1M1 st (k =XBOOLE-0R4 m +NAT-1K1 \<one>\<^sub>M & Pp2(m,l)) & n =XBOOLE-0R4 Ff2(k,l))"
  shows "( for k be NatNAT-1M1 holds  ex n be NatNAT-1M1 st Pp2(k,n)) & ( for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds Pp2(k,n) & Pp2(k,m) implies n =XBOOLE-0R4 m)"
  proof(rule conjMI)
    obtain N where 
      [ty]:"N be ElementSUBSET-1M1-of NATNUMBERSK1" and NDef:"N = Nf0"
      using ordinal1_def_12 sorry
    let ?P = "\<lambda>Lamb1.  ex n be NatNAT-1M1 st Pp2(Lamb1,n)"
    have A2: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds ( ex n be NatNAT-1M1 st Pp2(k,n)) implies ( ex tVar4 be NatNAT-1M1 st Pp2(k +NAT-1K1 \<one>\<^sub>M,tVar4))"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume Given: " ex n be NatNAT-1M1 st Pp2(k,n)"
        then obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A3: "Pp2(k,n)"
           sorry
        obtain F where 
          [ty]:"F be ElementSUBSET-1M1-of NATNUMBERSK1" and FDef:"F = Ff2(k +NAT-1K1 \<one>\<^sub>M,n)"
          using ordinal1_def_12 sorry
        show " ex tVar4 be NatNAT-1M1 st Pp2(k +NAT-1K1 \<one>\<^sub>M,tVar4)"
        proof(rule bexI[of _ "F"])
          show "Pp2(k +NAT-1K1 \<one>\<^sub>M,F)"
            using A1 A3 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "Pp2(0NUMBERSK6,N)"
      using A1 sorry
    then have A4: "?P(0NUMBERSK6)"
       sorry
    show " for k be NatNAT-1M1 holds  ex n be NatNAT-1M1 st Pp2(k,n)"
      using nat_1_sch_2 A4 A2 sorry
    let ?P = "\<lambda>Lamb1.  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds Pp2(Lamb1,n) & Pp2(Lamb1,m) implies n =XBOOLE-0R4 m"
    have A5: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds Pp2(k,n) & Pp2(k,m) implies n =XBOOLE-0R4 m) implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds Pp2(k +NAT-1K1 \<one>\<^sub>M,n) & Pp2(k +NAT-1K1 \<one>\<^sub>M,m) implies n =XBOOLE-0R4 m)"
      proof(rule ballI,rule impI,rule ballI,rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A6: " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds Pp2(k,n) & Pp2(k,m) implies n =XBOOLE-0R4 m"
        fix n assume [ty]: "n be NatNAT-1M1"
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "Pp2(k +NAT-1K1 \<one>\<^sub>M,n) & Pp2(k +NAT-1K1 \<one>\<^sub>M,m)"
        then have "( ex l be NatNAT-1M1 st  ex u be NatNAT-1M1 st (k +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 l +NAT-1K1 \<one>\<^sub>M & Pp2(l,u)) & n =XBOOLE-0R4 Ff2(k +NAT-1K1 \<one>\<^sub>M,u)) & ( ex v be NatNAT-1M1 st  ex w be NatNAT-1M1 st (k +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 v +NAT-1K1 \<one>\<^sub>M & Pp2(v,w)) & m =XBOOLE-0R4 Ff2(k +NAT-1K1 \<one>\<^sub>M,w))"
          using A1 sorry
        thus "n =XBOOLE-0R4 m"
          using A6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A7: "?P(0NUMBERSK6)"
    proof-
      have " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds Pp2(0NUMBERSK6,n) & Pp2(0NUMBERSK6,m) implies n =XBOOLE-0R4 m"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        fix m assume [ty]: "m be NatNAT-1M1"
        assume A8: "Pp2(0NUMBERSK6,n)"
          and A9: "Pp2(0NUMBERSK6,m)"
        have " not ( ex m be NatNAT-1M1 st  ex l be NatNAT-1M1 st (0NUMBERSK6 =XBOOLE-0R4 m +NAT-1K1 \<one>\<^sub>M & Pp2(m,l)) & n =XBOOLE-0R4 Ff2(0NUMBERSK6,l))"
           sorry
        then have " not ( ex n be NatNAT-1M1 st  ex l be NatNAT-1M1 st (0NUMBERSK6 =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & Pp2(n,l)) & m =XBOOLE-0R4 Ff2(0NUMBERSK6,l)) & n =XBOOLE-0R4 Nf0"
          using A1 A8 sorry
        thus "n =XBOOLE-0R4 m"
          using A1 A9 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    show " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds Pp2(k,n) & Pp2(k,m) implies n =XBOOLE-0R4 m"
      using nat_1_sch_2 A7 A5 sorry
  qed

mtheorem nat_1_th_8:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i <=XXREAL-0R1 j +NAT-1K1 \<one>\<^sub>M implies i <=XXREAL-0R1 j or i =HIDDENR1 j +NAT-1K1 \<one>\<^sub>M"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  not ((i <=XXREAL-0R1 j +NAT-1K1 \<one>\<^sub>M &  not i <=XXREAL-0R1 j) &  not i =HIDDENR1 j +NAT-1K1 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix j assume [ty]: "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have A0: "i be NatNAT-1M1 & j be NatNAT-1M1"
      using tarski_th_1 sorry
    let ?P = "\<lambda>Lamb1.  for j be NatNAT-1M1 holds Lamb1 <=XXREAL-0R1 j +NAT-1K1 \<one>\<^sub>M implies Lamb1 <=XXREAL-0R1 j or Lamb1 =HIDDENR1 j +NAT-1K1 \<one>\<^sub>M"
    have A1: " for i be NatNAT-1M1 holds ?P(i) implies ?P(i +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for i be NatNAT-1M1 holds ( for j be NatNAT-1M1 holds i <=XXREAL-0R1 j +NAT-1K1 \<one>\<^sub>M implies i <=XXREAL-0R1 j or i =XBOOLE-0R4 j +NAT-1K1 \<one>\<^sub>M) implies ( for j be NatNAT-1M1 holds i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 j +NAT-1K1 \<one>\<^sub>M implies  not ( not i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 j &  not i +NAT-1K1 \<one>\<^sub>M =HIDDENR1 j +NAT-1K1 \<one>\<^sub>M))"
      proof(rule ballI,rule impI,rule ballI,rule impI)
        fix i assume [ty]: "i be NatNAT-1M1"
        assume A2: " for j be NatNAT-1M1 holds i <=XXREAL-0R1 j +NAT-1K1 \<one>\<^sub>M implies i <=XXREAL-0R1 j or i =XBOOLE-0R4 j +NAT-1K1 \<one>\<^sub>M"
        fix j assume [ty]: "j be NatNAT-1M1"
        assume A3: "i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 j +NAT-1K1 \<one>\<^sub>M"
        have A4: "( ex k be NatNAT-1M1 st j =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M) implies  not ( not i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 j &  not i +NAT-1K1 \<one>\<^sub>M =HIDDENR1 j +NAT-1K1 \<one>\<^sub>M)"
        proof(rule impI)
          assume Given: " ex k be NatNAT-1M1 st j =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
          then obtain k where
            [ty]:"k be NatNAT-1M1" and 
            A5: "j =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
             sorry
          have "i <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
            using A3 A5 xreal_1_th_6 sorry
          thus " not ( not i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 j &  not i +NAT-1K1 \<one>\<^sub>M =HIDDENR1 j +NAT-1K1 \<one>\<^sub>M)"
            using A2 A5 xreal_1_th_6 sorry
        qed
        have "j =XBOOLE-0R4 0NUMBERSK6 implies  not ( not i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 j &  not i +NAT-1K1 \<one>\<^sub>M =HIDDENR1 j +NAT-1K1 \<one>\<^sub>M)"
        proof(rule impI)
          have A6: "0NUMBERSK6 <=XXREAL-0R1 i"
            using nat_1_th_2 sorry
          assume A7: "j =XBOOLE-0R4 0NUMBERSK6"
          then have "i <=XXREAL-0R1 0NUMBERSK6"
            using A3 xreal_1_th_6 sorry
          thus " not ( not i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 j &  not i +NAT-1K1 \<one>\<^sub>M =HIDDENR1 j +NAT-1K1 \<one>\<^sub>M)"
            using A7 A6 sorry
        qed
        thus " not ( not i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 j &  not i +NAT-1K1 \<one>\<^sub>M =HIDDENR1 j +NAT-1K1 \<one>\<^sub>M)"
          using A4 nat_1_th_6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A8: "?P(0NUMBERSK6)"
      using nat_1_th_2 sorry
    have " for i be NatNAT-1M1 holds ?P(i)"
      using nat_1_sch_2 A8 A1 sorry
    thus " not ((i <=XXREAL-0R1 j +NAT-1K1 \<one>\<^sub>M &  not i <=XXREAL-0R1 j) &  not i =HIDDENR1 j +NAT-1K1 \<one>\<^sub>M)"
      using A0 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_1_th_9:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i <=XXREAL-0R1 j & j <=XXREAL-0R1 i +NAT-1K1 \<one>\<^sub>M implies i =HIDDENR1 j or j =HIDDENR1 i +NAT-1K1 \<one>\<^sub>M"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i <=XXREAL-0R1 j & j <=XXREAL-0R1 i +NAT-1K1 \<one>\<^sub>M implies  not ( not i =HIDDENR1 j &  not j =HIDDENR1 i +NAT-1K1 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix j assume [ty]: "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "i <=XXREAL-0R1 j"
      and A2: "j <=XXREAL-0R1 i +NAT-1K1 \<one>\<^sub>M"
    have "j <=XXREAL-0R1 i or j =HIDDENR1 i +NAT-1K1 \<one>\<^sub>M"
      using A2 nat_1_th_8 sorry
    thus " not ( not i =HIDDENR1 j &  not j =HIDDENR1 i +NAT-1K1 \<one>\<^sub>M)"
      using A1 xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_1_th_10:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i <=XXREAL-0R1 j implies ( ex k be NatNAT-1M1 st j =HIDDENR1 i +XCMPLX-0K2 k)"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  not (i <=XXREAL-0R1 j & ( for k be NatNAT-1M1 holds  not j =HIDDENR1 i +XCMPLX-0K2 k))"
  proof(rule ballI,rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix j assume [ty]: "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have A0: "j be NatNAT-1M1"
      using tarski_th_1 sorry
    let ?P = "\<lambda>Lamb1. i <=XXREAL-0R1 Lamb1 implies ( ex k be NatNAT-1M1 st Lamb1 =XBOOLE-0R4 i +XCMPLX-0K2 k)"
    have A1: " for j be NatNAT-1M1 holds ?P(j) implies ?P(j +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for j be NatNAT-1M1 holds (i <=XXREAL-0R1 j implies ( ex k be NatNAT-1M1 st j =XBOOLE-0R4 i +XCMPLX-0K2 k)) implies (i <=XXREAL-0R1 j +NAT-1K1 \<one>\<^sub>M implies  not ( for k be NatNAT-1M1 holds  not j +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 i +XCMPLX-0K2 k))"
      proof(rule ballI,rule impI,rule impI)
        fix j assume [ty]: "j be NatNAT-1M1"
        assume A2: "i <=XXREAL-0R1 j implies ( ex k be NatNAT-1M1 st j =XBOOLE-0R4 i +XCMPLX-0K2 k)"
        have A3: "i <=XXREAL-0R1 j implies (i <=XXREAL-0R1 j +NAT-1K1 \<one>\<^sub>M implies ( ex k be NatNAT-1M1 st j +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 i +XCMPLX-0K2 k))"
        proof(rule impI)
          assume "i <=XXREAL-0R1 j"
          then obtain k where
            [ty]:"k be NatNAT-1M1" and 
            A4: "j =XBOOLE-0R4 i +XCMPLX-0K2 k"
            using A2 sorry
          have "(i +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 i +NAT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
             sorry
          thus "i <=XXREAL-0R1 j +NAT-1K1 \<one>\<^sub>M implies ( ex k be NatNAT-1M1 st j +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 i +XCMPLX-0K2 k)"
            using A4 sorry
        qed
        have A5: "i =HIDDENR1 j +NAT-1K1 \<one>\<^sub>M implies (i <=XXREAL-0R1 j +NAT-1K1 \<one>\<^sub>M implies ( ex k be NatNAT-1M1 st j +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 i +XCMPLX-0K2 k))"
        proof(rule impI)
          assume "i =HIDDENR1 j +NAT-1K1 \<one>\<^sub>M"
          then have "j +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 i +NAT-1K1 0NUMBERSK6"
             sorry
          thus "i <=XXREAL-0R1 j +NAT-1K1 \<one>\<^sub>M implies ( ex k be NatNAT-1M1 st j +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 i +XCMPLX-0K2 k)"
             sorry
        qed
        assume "i <=XXREAL-0R1 j +NAT-1K1 \<one>\<^sub>M"
        thus " not ( for k be NatNAT-1M1 holds  not j +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 i +XCMPLX-0K2 k)"
          using A3 A5 nat_1_th_8 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A6: "?P(0NUMBERSK6)"
    proof-
      have "i <=XXREAL-0R1 0NUMBERSK6 implies ( ex tVar5 be NatNAT-1M1 st tVar5 =XBOOLE-0R4 i +XCMPLX-0K2 tVar5)"
      proof(rule impI)
        assume A7: "i <=XXREAL-0R1 0NUMBERSK6"
        show " ex tVar5 be NatNAT-1M1 st tVar5 =XBOOLE-0R4 i +XCMPLX-0K2 tVar5"
        proof(rule bexI[of _ "0NUMBERSK6"])
          show "0NUMBERSK6 =XBOOLE-0R4 i +XCMPLX-0K2 0NUMBERSK6"
            using A7 nat_1_th_2 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    have " for j be NatNAT-1M1 holds ?P(j)"
      using nat_1_sch_2 A6 A1 sorry
    thus " not (i <=XXREAL-0R1 j & ( for k be NatNAT-1M1 holds  not j =HIDDENR1 i +XCMPLX-0K2 k))"
      using A0 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_1_th_11:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i <=XXREAL-0R1 i +XCMPLX-0K2 j"
proof(rule ballI,rule ballI)
  fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
  fix j assume [ty]: "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
  have "0NUMBERSK6 +XCMPLX-0K2 i =HIDDENR1 i & 0NUMBERSK6 <=XXREAL-0R1 j"
    using nat_1_th_2 sorry
  thus "i <=XXREAL-0R1 i +XCMPLX-0K2 j"
    using xreal_1_th_7 sorry
qed "sorry"

theorem nat_1_sch_4:
  fixes Pp1 
  assumes
    A1: " for k be NatNAT-1M1 holds ( for n be NatNAT-1M1 holds n <XXREAL-0R3 k implies Pp1(n)) implies Pp1(k)"
  shows " for k be NatNAT-1M1 holds Pp1(k)"
  proof(rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    let ?P1 = "\<lambda>Lamb1.  for n be NatNAT-1M1 holds n <XXREAL-0R3 Lamb1 implies Pp1(n)"
    have A2: " for k be NatNAT-1M1 holds ?P1(k) implies ?P1(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds ( for n be NatNAT-1M1 holds n <XXREAL-0R3 k implies Pp1(n)) implies ( for n be NatNAT-1M1 holds n <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M implies Pp1(n))"
      proof(rule ballI,rule impI,rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A3: " for n be NatNAT-1M1 holds n <XXREAL-0R3 k implies Pp1(n)"
        fix n assume [ty]: "n be NatNAT-1M1"
        assume "n <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M"
        then have "n <=XXREAL-0R1 k"
          using nat_1_th_8 sorry
        then have "n <XXREAL-0R3 k or n =XBOOLE-0R4 k & n <=XXREAL-0R1 k"
          using xxreal_0_th_1 sorry
        thus "Pp1(n)"
          using A1 A3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A4: "?P1(0NUMBERSK6)"
      using nat_1_th_2 sorry
    have " for k be NatNAT-1M1 holds ?P1(k)"
      using nat_1_sch_2 A4 A2 sorry
    then have " for n be NatNAT-1M1 holds n <XXREAL-0R3 k implies Pp1(n)"
       sorry
    thus "Pp1(k)"
      using A1 sorry
  qed "sorry"

theorem nat_1_sch_5:
  fixes Pp1 
  assumes
    A1: " ex k be NatNAT-1M1 st Pp1(k)"
  shows " ex k be NatNAT-1M1 st Pp1(k) & ( for n be NatNAT-1M1 holds Pp1(n) implies k <=XXREAL-0R1 n)"
  proof-
    have " not ( not ( for k be NatNAT-1M1 holds  not (Pp1(k) & ( for n be NatNAT-1M1 holds  not (Pp1(n) &  not k <=XXREAL-0R1 n))))) implies  False "
    proof(rule impI)
      let ?P1 = "\<lambda>Lamb1.  not Pp1(Lamb1)"
      assume A2: " not ( not ( for k be NatNAT-1M1 holds  not (Pp1(k) & ( for n be NatNAT-1M1 holds  not (Pp1(n) &  not k <=XXREAL-0R1 n)))))"
      have A3: " for k be NatNAT-1M1 holds ( for n be NatNAT-1M1 holds n <XXREAL-0R3 k implies ?P1(n)) implies ?P1(k)"
      proof-
        have " for k be NatNAT-1M1 holds ( for n be NatNAT-1M1 holds n <XXREAL-0R3 k implies  not Pp1(n)) implies  not Pp1(k)"
        proof(rule ballI,rule impI)
          fix k assume [ty]: "k be NatNAT-1M1"
          assume A4: " for n be NatNAT-1M1 holds n <XXREAL-0R3 k implies  not Pp1(n)"
          have " not ( ex n be NatNAT-1M1 st Pp1(n) &  not k <=XXREAL-0R1 n) implies  not Pp1(k)"
            using A2 sorry
          thus " not Pp1(k)"
            using A4 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have " for k be NatNAT-1M1 holds ?P1(k)"
        using nat_1_sch_4 A3 sorry
      thus " False "
        using A1 sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem nat_1_sch_6:
  fixes Nf0 Pp1 
  assumes
[ty]: "Nf0 be NatNAT-1M1" and
   A1: " for k be NatNAT-1M1 holds Pp1(k) implies k <=XXREAL-0R1 Nf0" and
   A2: " ex k be NatNAT-1M1 st Pp1(k)"
  shows " ex k be NatNAT-1M1 st Pp1(k) & ( for n be NatNAT-1M1 holds Pp1(n) implies n <=XXREAL-0R1 k)"
  proof-
    have " ex tVar6 be NatNAT-1M1 st Pp1(tVar6) & ( for n be NatNAT-1M1 holds  not (Pp1(n) &  not n <=XXREAL-0R1 tVar6))"
    proof-
      let ?P1 = "\<lambda>Lamb1.  for n be NatNAT-1M1 holds Pp1(n) implies n <=XXREAL-0R1 Lamb1"
      have A3: " ex k be NatNAT-1M1 st ?P1(k)"
        using A1 sorry
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A4: "?P1(k)"and A5: " for m be NatNAT-1M1 holds ?P1(m) implies k <=XXREAL-0R1 m"
        using nat_1_sch_5 A3 sorry
      show " ex tVar6 be NatNAT-1M1 st Pp1(tVar6) & ( for n be NatNAT-1M1 holds  not (Pp1(n) &  not n <=XXREAL-0R1 tVar6))"
      proof(rule bexI[of _ "k"],rule conjMI)
        show "Pp1(k)"
        proof-
          have " not Pp1(k) implies  False "
          proof(rule impI)
            obtain n where
              [ty]:"n be NatNAT-1M1" and 
              A6: "Pp1(n)"
              using A2 sorry
            have A7: "n <=XXREAL-0R1 k"
              using A4 A6 sorry
            assume A8: " not Pp1(k)"
            then have "n <>HIDDENR2 k"
              using A6 sorry
            then have "k <>HIDDENR2 0NUMBERSK6"
              using A7 nat_1_th_2 sorry
            then obtain m where
              [ty]:"m be NatNAT-1M1" and 
              A9: "k =XBOOLE-0R4 m +NAT-1K1 \<one>\<^sub>M"
              using nat_1_th_6 sorry
            have A10: " for n be NatNAT-1M1 holds Pp1(n) implies n <=XXREAL-0R1 m"
              using A4 A8 A9 nat_1_th_8 sorry
            have "((-XCMPLX-0K4 m)+XCMPLX-0K2 m)+XCMPLX-0K2 \<one>\<^sub>M =XBOOLE-0R4 (-XCMPLX-0K4 m)+XCMPLX-0K2 (m +NAT-1K1 \<one>\<^sub>M)"
               sorry
            thus " False "
              using A5 A9 A10 xreal_1_th_6 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        show " for n be NatNAT-1M1 holds  not (Pp1(n) &  not n <=XXREAL-0R1 k)"
          using A4 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem nat_1_th_12:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for h be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i <=XXREAL-0R1 j implies i <=XXREAL-0R1 j +XCMPLX-0K2 h"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
  fix j assume [ty]: "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
  fix h assume [ty]: "h be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
  assume "i <=XXREAL-0R1 j"
  then have A1: "i +XCMPLX-0K2 h <=XXREAL-0R1 j +XCMPLX-0K2 h"
    using xreal_1_th_7 sorry
  have "0NUMBERSK6 <=XXREAL-0R1 h"
    using nat_1_th_2 sorry
  then have "i +NAT-1K1 0NUMBERSK6 <=XXREAL-0R1 i +XCMPLX-0K2 h"
    using xreal_1_th_7 sorry
  thus "i <=XXREAL-0R1 j +XCMPLX-0K2 h"
    using A1 xxreal_0_th_2 sorry
qed "sorry"

mtheorem nat_1_th_13:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i <XXREAL-0R3 j +NAT-1K1 \<one>\<^sub>M iff i <=XXREAL-0R1 j"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (i <XXREAL-0R3 j +NAT-1K1 \<one>\<^sub>M implies i <=XXREAL-0R1 j) & (i <=XXREAL-0R1 j implies  not i <XXREAL-0R3 j +NAT-1K1 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix j assume [ty]: "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    show "i <XXREAL-0R3 j +NAT-1K1 \<one>\<^sub>M implies i <=XXREAL-0R1 j"
      using nat_1_th_8 sorry
    assume A1: "i <=XXREAL-0R1 j"
    have A2: "i =HIDDENR1 j +NAT-1K1 \<one>\<^sub>M implies  False "
    proof(rule impI)
      have A3: "j +XCMPLX-0K2 (-XCMPLX-0K4 j) =XBOOLE-0R4 0NUMBERSK6 & (j +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (-XCMPLX-0K4 j) =XBOOLE-0R4 \<one>\<^sub>M"
         sorry
      assume "i =HIDDENR1 j +NAT-1K1 \<one>\<^sub>M"
      thus " False "
        using A1 A3 xreal_1_th_6 sorry
    qed
    have "i <=XXREAL-0R1 j +NAT-1K1 \<one>\<^sub>M"
      using A1 nat_1_th_12 sorry
    thus " not i <XXREAL-0R3 j +NAT-1K1 \<one>\<^sub>M"
      using A2 xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_1_th_14:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i <XXREAL-0R3 \<one>\<^sub>M implies i =HIDDENR1 0NUMBERSK6"
proof(rule ballI,rule impI)
  fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
  assume "i <XXREAL-0R3 \<one>\<^sub>M"
  then have "i <XXREAL-0R3 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
     sorry
  then have "i <=XXREAL-0R1 0NUMBERSK6"
    using nat_1_th_13 sorry
  thus "i =HIDDENR1 0NUMBERSK6"
    using nat_1_th_2 sorry
qed "sorry"

mtheorem nat_1_th_15:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i *XCMPLX-0K3 j =XBOOLE-0R4 \<one>\<^sub>M implies i =HIDDENR1 \<one>\<^sub>M"
proof(rule ballI,rule ballI,rule impI)
  fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
  fix j assume [ty]: "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
  assume A1: "i *XCMPLX-0K3 j =XBOOLE-0R4 \<one>\<^sub>M"
  then have "i <>HIDDENR2 0NUMBERSK6"
     sorry
  then obtain m where
    [ty]:"m be NatNAT-1M1" and 
    A2: "i =HIDDENR1 m +NAT-1K1 \<one>\<^sub>M"
    using nat_1_th_6 sorry
  have "j <>HIDDENR2 0NUMBERSK6"
    using A1 sorry
  then obtain l where
    [ty]:"l be NatNAT-1M1" and 
    A3: "j =HIDDENR1 l +NAT-1K1 \<one>\<^sub>M"
    using nat_1_th_6 sorry
  have A4: "((m *XCMPLX-0K3 l +XCMPLX-0K2 m)+XCMPLX-0K2 l)+NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
    using A1 A2 A3 sorry
  then have "m *XCMPLX-0K3 l +XCMPLX-0K2 m =XBOOLE-0R4 0NUMBERSK6"
     sorry
  thus "i =HIDDENR1 \<one>\<^sub>M"
    using A2 A4 sorry
qed "sorry"

mtheorem nat_1_th_16:
" for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds k <>HIDDENR2 0NUMBERSK6 implies n <XXREAL-0R3 n +XCMPLX-0K2 k"
proof-
  have " for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds k <>HIDDENR2 0NUMBERSK6 implies  not n <XXREAL-0R3 n +XCMPLX-0K2 k"
  proof(rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix k assume [ty]: "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume "k <>HIDDENR2 0NUMBERSK6"
    then have A1: "n <>HIDDENR2 n +XCMPLX-0K2 k"
       sorry
    have "n <=XXREAL-0R1 n +XCMPLX-0K2 k"
      using nat_1_th_12 sorry
    thus " not n <XXREAL-0R3 n +XCMPLX-0K2 k"
      using A1 xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem nat_1_sch_7:
  fixes Pp1 
  assumes
    A1: " ex k be NatNAT-1M1 st Pp1(k)" and
   A2: " for k be NatNAT-1M1 holds k <>HIDDENR2 0NUMBERSK6 & Pp1(k) implies ( ex n be NatNAT-1M1 st n <XXREAL-0R3 k & Pp1(n))"
  shows "Pp1(0NUMBERSK6)"
  proof-
    obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A3: "Pp1(k) & ( for n be NatNAT-1M1 holds Pp1(n) implies k <=XXREAL-0R1 n)"
      using nat_1_sch_5 A1 sorry
    have "k <>HIDDENR2 0NUMBERSK6 implies  False "
    proof(rule impI)
      assume "k <>HIDDENR2 0NUMBERSK6"
      then have " ex n be NatNAT-1M1 st n <XXREAL-0R3 k & Pp1(n)"
        using A2 A3 sorry
      thus " False "
        using A3 sorry
    qed
    thus "Pp1(0NUMBERSK6)"
      using A3 sorry
  qed

mtheorem nat_1_th_17:
" for m be NatNAT-1M1 holds 0NUMBERSK6 <XXREAL-0R3 m implies ( for n be NatNAT-1M1 holds  ex k be NatNAT-1M1 st  ex t be NatNAT-1M1 st n =XBOOLE-0R4 m *XCMPLX-0K3 k +XCMPLX-0K2 t & t <XXREAL-0R3 m)"
proof-
  have " for m be NatNAT-1M1 holds 0NUMBERSK6 <XXREAL-0R3 m implies ( for n be NatNAT-1M1 holds  ex k be NatNAT-1M1 st  ex t be NatNAT-1M1 st n =XBOOLE-0R4 m *XCMPLX-0K3 k +XCMPLX-0K2 t & t <XXREAL-0R3 m)"
  proof(rule ballI,rule impI)
    fix m assume [ty]: "m be NatNAT-1M1"
    let ?P = "\<lambda>Lamb1.  ex k be NatNAT-1M1 st  ex t be NatNAT-1M1 st Lamb1 =XBOOLE-0R4 m *XCMPLX-0K3 k +XCMPLX-0K2 t & t <XXREAL-0R3 m"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 m"
    have A2: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds ( ex k1 be NatNAT-1M1 st  ex t1 be NatNAT-1M1 st n =XBOOLE-0R4 m *XCMPLX-0K3 k1 +XCMPLX-0K2 t1 & t1 <XXREAL-0R3 m) implies ( ex k be NatNAT-1M1 st  ex t be NatNAT-1M1 st n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 m *XCMPLX-0K3 k +XCMPLX-0K2 t & t <XXREAL-0R3 m)"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume Given: " ex k1 be NatNAT-1M1 st  ex t1 be NatNAT-1M1 st n =XBOOLE-0R4 m *XCMPLX-0K3 k1 +XCMPLX-0K2 t1 & t1 <XXREAL-0R3 m"
        then obtain k1 t1 where
          [ty]:"k1 be NatNAT-1M1" "t1 be NatNAT-1M1" and 
          A3: "n =XBOOLE-0R4 m *XCMPLX-0K3 k1 +XCMPLX-0K2 t1"and A4: "t1 <XXREAL-0R3 m"
           sorry
        have A5: "t1 +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 m implies ( ex k be NatNAT-1M1 st  ex t be NatNAT-1M1 st n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 m *XCMPLX-0K3 k +XCMPLX-0K2 t & t <XXREAL-0R3 m)"
        proof-
          have "t1 +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 m implies ( ex k be NatNAT-1M1 st  ex t be ElementSUBSET-1M1-of NATNUMBERSK1 st n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 m *XCMPLX-0K3 k +NAT-1K1 t &  not t <XXREAL-0R3 m)"
          proof(rule impI)
            assume A6: "t1 +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 m"
            obtain k where 
              [ty]:"k be NatNAT-1M1" and kDef:"k = k1"
               sorry
            show " ex k be NatNAT-1M1 st  ex t be ElementSUBSET-1M1-of NATNUMBERSK1 st n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 m *XCMPLX-0K3 k +NAT-1K1 t &  not t <XXREAL-0R3 m"
            proof(rule bexI[of _ "k"])
              obtain t where 
                [ty]:"t be ElementSUBSET-1M1-of NATNUMBERSK1" and tDef:"t = t1 +NAT-1K1 \<one>\<^sub>M"
                 sorry
              show " ex t be ElementSUBSET-1M1-of NATNUMBERSK1 st n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 m *XCMPLX-0K3 k +NAT-1K1 t &  not t <XXREAL-0R3 m"
              proof(rule bexI[of _ "t"],rule conjMI)
                show "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 m *XCMPLX-0K3 k +NAT-1K1 t"
                  using A3 sorry
                show " not t <XXREAL-0R3 m"
                  using A6 sorry
              qed "sorry"
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
        have A7: "t1 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 m implies ( ex k be NatNAT-1M1 st  ex t be NatNAT-1M1 st n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 m *XCMPLX-0K3 k +XCMPLX-0K2 t & t <XXREAL-0R3 m)"
        proof-
          have "t1 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 m implies ( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st  ex t be ElementSUBSET-1M1-of omegaORDINAL1K4 st n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 m *XCMPLX-0K3 k +NAT-1K1 t &  not t <XXREAL-0R3 m)"
          proof(rule impI)
            assume A8: "t1 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 m"
            obtain k where 
              [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = k1 +NAT-1K1 \<one>\<^sub>M"
               sorry
            show " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st  ex t be ElementSUBSET-1M1-of omegaORDINAL1K4 st n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 m *XCMPLX-0K3 k +NAT-1K1 t &  not t <XXREAL-0R3 m"
            proof(rule bexI[of _ "k"])
              obtain t where 
                [ty]:"t be ElementSUBSET-1M1-of omegaORDINAL1K4" and tDef:"t = 0NUMBERSK6"
                 sorry
              show " ex t be ElementSUBSET-1M1-of omegaORDINAL1K4 st n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 m *XCMPLX-0K3 k +NAT-1K1 t &  not t <XXREAL-0R3 m"
              proof(rule bexI[of _ "t"],rule conjMI)
                show "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 m *XCMPLX-0K3 k +NAT-1K1 t"
                  using A3 A8 sorry
                show " not t <XXREAL-0R3 m"
                  using A1 sorry
              qed "sorry"
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
        have "t1 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m"
          using A4 nat_1_th_13 sorry
        thus " ex k be NatNAT-1M1 st  ex t be NatNAT-1M1 st n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 m *XCMPLX-0K3 k +XCMPLX-0K2 t & t <XXREAL-0R3 m"
          using A5 A7 xxreal_0_th_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "0NUMBERSK6 =XBOOLE-0R4 m *XCMPLX-0K3 (0NUMBERSK6) +NAT-1K1 0NUMBERSK6"
       sorry
    then have A9: "?P(0NUMBERSK6)"
      using A1 sorry
    show " for n be NatNAT-1M1 holds  ex k be NatNAT-1M1 st  ex t be NatNAT-1M1 st n =XBOOLE-0R4 m *XCMPLX-0K3 k +XCMPLX-0K2 t & t <XXREAL-0R3 m"
      using nat_1_sch_2 A9 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_1_th_18:
" for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for m be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for t be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for k1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for t1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds ((n =HIDDENR1 m *XCMPLX-0K3 k +XCMPLX-0K2 t & t <XXREAL-0R3 m) & n =HIDDENR1 m *XCMPLX-0K3 k1 +XCMPLX-0K2 t1) & t1 <XXREAL-0R3 m implies k =HIDDENR1 k1 & t =HIDDENR1 t1"
proof-
  have " for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for m be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for t be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for k1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for t1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds n =HIDDENR1 m *XCMPLX-0K3 k +XCMPLX-0K2 t & (t <XXREAL-0R3 m & (n =HIDDENR1 m *XCMPLX-0K3 k1 +XCMPLX-0K2 t1 & t1 <XXREAL-0R3 m)) implies k =HIDDENR1 k1 & t =HIDDENR1 t1"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix m assume [ty]: "m be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix k assume [ty]: "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix t assume [ty]: "t be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix k1 assume [ty]: "k1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix t1 assume [ty]: "t1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "n =HIDDENR1 m *XCMPLX-0K3 k +XCMPLX-0K2 t"
      and A2: "t <XXREAL-0R3 m"
      and A3: "n =HIDDENR1 m *XCMPLX-0K3 k1 +XCMPLX-0K2 t1"
      and A4: "t1 <XXREAL-0R3 m"
    have A5: "k1 <=XXREAL-0R1 k implies k =HIDDENR1 k1 & t =HIDDENR1 t1"
    proof(rule impI,rule conjMI)
      assume "k1 <=XXREAL-0R1 k"
      then obtain u where
        [ty]:"u be NatNAT-1M1" and 
        A6: "k =HIDDENR1 k1 +XCMPLX-0K2 u"
        using nat_1_th_10 sorry
      have "m *XCMPLX-0K3 (k1 +XCMPLX-0K2 u) +XCMPLX-0K2 t =XBOOLE-0R4 m *XCMPLX-0K3 k1 +XCMPLX-0K2 (m *XCMPLX-0K3 u +XCMPLX-0K2 t)"
         sorry
      then have A7: "m *XCMPLX-0K3 u +XCMPLX-0K2 t =HIDDENR1 t1"
        using A1 A3 A6 xcmplx_1_th_2 sorry
      have "( ex w be NatNAT-1M1 st u =XBOOLE-0R4 w +NAT-1K1 \<one>\<^sub>M) implies  False "
      proof(rule impI)
        assume Given: " ex w be NatNAT-1M1 st u =XBOOLE-0R4 w +NAT-1K1 \<one>\<^sub>M"
        then obtain w where
          [ty]:"w be NatNAT-1M1" and 
          A8: "u =XBOOLE-0R4 w +NAT-1K1 \<one>\<^sub>M"
           sorry
        have "m *XCMPLX-0K3 u +XCMPLX-0K2 t =XBOOLE-0R4 m +XCMPLX-0K2 (m *XCMPLX-0K3 w +XCMPLX-0K2 t)"
          using A8 sorry
        thus " False "
          using A4 A7 nat_1_th_11 sorry
      qed
      then have A9: "u =XBOOLE-0R4 0NUMBERSK6"
        using nat_1_th_6 sorry
      thus "k =HIDDENR1 k1"
        using A6 sorry
      show "t =HIDDENR1 t1"
        using A1 A3 A6 A9 xcmplx_1_th_2 sorry
    qed
    have "k <=XXREAL-0R1 k1 implies k =HIDDENR1 k1 & t =HIDDENR1 t1"
    proof(rule impI,rule conjMI)
      assume "k <=XXREAL-0R1 k1"
      then obtain u where
        [ty]:"u be NatNAT-1M1" and 
        A10: "k1 =HIDDENR1 k +XCMPLX-0K2 u"
        using nat_1_th_10 sorry
      have "m *XCMPLX-0K3 (k +XCMPLX-0K2 u) +XCMPLX-0K2 t1 =XBOOLE-0R4 m *XCMPLX-0K3 k +XCMPLX-0K2 (m *XCMPLX-0K3 u +XCMPLX-0K2 t1)"
         sorry
      then have A11: "m *XCMPLX-0K3 u +XCMPLX-0K2 t1 =HIDDENR1 t"
        using A1 A3 A10 xcmplx_1_th_2 sorry
      have "( ex w be NatNAT-1M1 st u =XBOOLE-0R4 w +NAT-1K1 \<one>\<^sub>M) implies  False "
      proof(rule impI)
        assume Given: " ex w be NatNAT-1M1 st u =XBOOLE-0R4 w +NAT-1K1 \<one>\<^sub>M"
        then obtain w where
          [ty]:"w be NatNAT-1M1" and 
          A12: "u =XBOOLE-0R4 w +NAT-1K1 \<one>\<^sub>M"
           sorry
        have "m *XCMPLX-0K3 u +XCMPLX-0K2 t1 =XBOOLE-0R4 m +XCMPLX-0K2 (m *XCMPLX-0K3 w +XCMPLX-0K2 t1)"
          using A12 sorry
        thus " False "
          using A2 A11 nat_1_th_11 sorry
      qed
      then have A13: "u =XBOOLE-0R4 0NUMBERSK6"
        using nat_1_th_6 sorry
      thus "k =HIDDENR1 k1"
        using A10 sorry
      show "t =HIDDENR1 t1"
        using A1 A3 A10 A13 xcmplx_1_th_2 sorry
    qed
    thus "k =HIDDENR1 k1 & t =HIDDENR1 t1"
      using A5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_1_cl_8:
"cluster note-that ordinalORDINAL1V3 for naturalORDINAL1V7\<bar>NumberORDINAL1M1"
proof
(*coherence*)
  show " for it be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds it be ordinalORDINAL1V3"
  proof-
    have " for o be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds o be ordinalORDINAL1V3"
    proof(rule ballI)
      fix o assume [ty]: "o be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
      have "o inHIDDENR3 omegaORDINAL1K4"
        using ordinal1_def_12 sorry
      thus "o be ordinalORDINAL1V3"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem nat_1_cl_9:
"cluster  non emptyXBOOLE-0V1\<bar>ordinalORDINAL1V3 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*existence*)
  show " ex it be SubsetSUBSET-1M2-of REALNUMBERSK2 st it be  non emptyXBOOLE-0V1\<bar>ordinalORDINAL1V3"
  proof-
    have " ex tVar11 be SubsetSUBSET-1M2-of REALNUMBERSK2 st  not tVar11 be emptyXBOOLE-0V1 & tVar11 be ordinalORDINAL1V3"
    proof-
      obtain N where 
        [ty]:"N be SubsetSUBSET-1M2-of REALNUMBERSK2" and NDef:"N = NATNUMBERSK1"
        using numbers_th_19 sorry
      show " ex tVar11 be SubsetSUBSET-1M2-of REALNUMBERSK2 st  not tVar11 be emptyXBOOLE-0V1 & tVar11 be ordinalORDINAL1V3"
      proof(rule bexI[of _ "N"])
        show " not N be emptyXBOOLE-0V1 & N be ordinalORDINAL1V3"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem nat_1_th_19:
" for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds k <XXREAL-0R3 k +XCMPLX-0K2 n iff \<one>\<^sub>M <=XXREAL-0R1 n"
proof-
  have " for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (k <XXREAL-0R3 k +XCMPLX-0K2 n implies \<one>\<^sub>M <=XXREAL-0R1 n) & (\<one>\<^sub>M <=XXREAL-0R1 n implies  not k <XXREAL-0R3 k +XCMPLX-0K2 n)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix k assume [ty]: "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    show "k <XXREAL-0R3 k +XCMPLX-0K2 n implies \<one>\<^sub>M <=XXREAL-0R1 n"
    proof-
      have "k <XXREAL-0R3 k +XCMPLX-0K2 n implies ( not \<one>\<^sub>M <=XXREAL-0R1 n implies  not  True )"
      proof(rule impI,rule impI)
        assume A1: "k <XXREAL-0R3 k +XCMPLX-0K2 n"
        assume " not \<one>\<^sub>M <=XXREAL-0R1 n"
        then have "n =HIDDENR1 0NUMBERSK6"
          using nat_1_th_14 sorry
        thus " not  True "
          using A1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume "\<one>\<^sub>M <=XXREAL-0R1 n"
    thus " not k <XXREAL-0R3 k +XCMPLX-0K2 n"
      using nat_1_th_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_1_th_20:
" for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds k <XXREAL-0R3 n implies n -XCMPLX-0K6 \<one>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1"
proof(rule ballI,rule ballI,rule impI)
  fix k assume [ty]: "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
  fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
  assume "k <XXREAL-0R3 n"
  then have "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
    using nat_1_th_13 sorry
  then obtain j where
    [ty]:"j be NatNAT-1M1" and 
    A1: "n =HIDDENR1 (k +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 j"
    using nat_1_th_10 sorry
  have "n -XCMPLX-0K6 \<one>\<^sub>M =XBOOLE-0R4 k +XCMPLX-0K2 j"
    using A1 sorry
  thus "n -XCMPLX-0K6 \<one>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1"
    using ordinal1_def_12 sorry
qed "sorry"

mtheorem nat_1_th_21:
" for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds k <=XXREAL-0R1 n implies n -XCMPLX-0K6 k be ElementSUBSET-1M1-of NATNUMBERSK1"
proof(rule ballI,rule ballI,rule impI)
  fix k assume [ty]: "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
  fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
  assume A1: "k <=XXREAL-0R1 n"
  show "n -XCMPLX-0K6 k be ElementSUBSET-1M1-of NATNUMBERSK1"
  proof-
    have cases: "k <XXREAL-0R3 n or k =HIDDENR1 n"
      using A1 xxreal_0_th_1 sorry
    have case1: "k <XXREAL-0R3 n implies n -XCMPLX-0K6 k be ElementSUBSET-1M1-of NATNUMBERSK1"
    proof(rule impI)
      assume "k <XXREAL-0R3 n"
      then have "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
        using nat_1_th_13 sorry
      then obtain j where
        [ty]:"j be NatNAT-1M1" and 
        A2: "n =HIDDENR1 (k +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 j"
        using nat_1_th_10 sorry
      have 
        [ty]:"j be ElementSUBSET-1M1-of NATNUMBERSK1"
        using ordinal1_def_12 sorry
      have "n -XCMPLX-0K6 k =XBOOLE-0R4 \<one>\<^sub>M +NAT-1K1 j"
        using A2 sorry
      thus "n -XCMPLX-0K6 k be ElementSUBSET-1M1-of NATNUMBERSK1"
         sorry
    qed
    have case2: "k =HIDDENR1 n implies n -XCMPLX-0K6 k be ElementSUBSET-1M1-of NATNUMBERSK1"
    proof(rule impI)
      assume "k =HIDDENR1 n"
      then have "n -XCMPLX-0K6 k =XBOOLE-0R4 0NUMBERSK6"
         sorry
      thus "n -XCMPLX-0K6 k be ElementSUBSET-1M1-of NATNUMBERSK1"
         sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

(*begin*)
mtheorem nat_1_th_22:
" for m be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds m <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M implies m <XXREAL-0R3 n or m =HIDDENR1 n"
proof-
  have " for m be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds m <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M implies  not (m <XXREAL-0R3 n &  not m =HIDDENR1 n)"
  proof(rule ballI,rule ballI,rule impI)
    fix m assume [ty]: "m be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume "m <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
    then have "m <=XXREAL-0R1 n"
      using nat_1_th_13 sorry
    thus " not (m <XXREAL-0R3 n &  not m =HIDDENR1 n)"
      using xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_1_th_23:
" for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds k <XXREAL-0R3 \<two>\<^sub>M implies k =HIDDENR1 0NUMBERSK6 or k =HIDDENR1 \<one>\<^sub>M"
proof-
  have " for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds k <XXREAL-0R3 \<two>\<^sub>M implies  not ( not k =HIDDENR1 0NUMBERSK6 &  not k =HIDDENR1 \<one>\<^sub>M)"
  proof(rule ballI,rule impI)
    fix k assume [ty]: "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume "k <XXREAL-0R3 \<two>\<^sub>M"
    then have "k <XXREAL-0R3 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
       sorry
    thus " not ( not k =HIDDENR1 0NUMBERSK6 &  not k =HIDDENR1 \<one>\<^sub>M)"
      using nat_1_th_14 nat_1_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_1_cl_10:
"cluster  non zeroORDINAL1V8 for ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*existence*)
  show " ex it be ElementSUBSET-1M1-of NATNUMBERSK1 st it be  non zeroORDINAL1V8"
  proof-
    have " ex tVar12 be ElementSUBSET-1M1-of NATNUMBERSK1 st  not tVar12 be zeroORDINAL1V8"
    proof-
      show " ex tVar12 be ElementSUBSET-1M1-of NATNUMBERSK1 st  not tVar12 be zeroORDINAL1V8"
      proof(rule bexI[of _ "\<one>\<^sub>M"])
        show " not \<one>\<^sub>M be zeroORDINAL1V8"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem nat_1_cl_11:
"cluster note-that  non negativeXXREAL-0V3 for ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of NATNUMBERSK1 holds it be  non negativeXXREAL-0V3"
    using nat_1_th_2 sorry
qed "sorry"

mtheorem nat_1_cl_12:
"cluster note-that  non negativeXXREAL-0V3 for naturalORDINAL1V7\<bar>NumberORDINAL1M1"
proof
(*coherence*)
  show " for it be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds it be  non negativeXXREAL-0V3"
    using nat_1_th_2 sorry
qed "sorry"

mtheorem nat_1_th_24:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for h be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i <>HIDDENR2 0NUMBERSK6 & h =HIDDENR1 j *XCMPLX-0K3 i implies j <=XXREAL-0R1 h"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for h be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i <>HIDDENR2 0NUMBERSK6 implies (h =HIDDENR1 j *XCMPLX-0K3 i implies j <=XXREAL-0R1 h)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix j assume [ty]: "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix h assume [ty]: "h be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume "i <>HIDDENR2 0NUMBERSK6"
    then obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A1: "i =HIDDENR1 k +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_6 sorry
    assume "h =HIDDENR1 j *XCMPLX-0K3 i"
    then have "h =HIDDENR1 j *XCMPLX-0K3 k +XCMPLX-0K2 j *XCMPLX-0K3 \<one>\<^sub>M"
      using A1 sorry
    thus "j <=XXREAL-0R1 h"
      using nat_1_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem nat_1_sch_8:
  fixes Mf0 Pp1 
  assumes
[ty]: "Mf0 be NatNAT-1M1" and
   A1: "Pp1(Mf0)" and
   A2: " for j be NatNAT-1M1 holds Mf0 <=XXREAL-0R1 j implies (Pp1(j) implies Pp1(j +NAT-1K1 \<one>\<^sub>M))"
  shows " for i be NatNAT-1M1 holds Mf0 <=XXREAL-0R1 i implies Pp1(i)"
  proof-
    have " for i be NatNAT-1M1 holds Mf0 <=XXREAL-0R1 i implies Pp1(i)"
    proof(rule ballI,rule impI)
      let ?Q = "\<lambda>Lamb1. Pp1(Mf0 +XCMPLX-0K2 Lamb1)"
      have A3: " for m be NatNAT-1M1 holds Pp1(Mf0 +XCMPLX-0K2 m) implies Pp1(Mf0 +XCMPLX-0K2 (m +NAT-1K1 \<one>\<^sub>M))"
      proof(rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "?Q(m)"
        then have "Pp1((Mf0 +XCMPLX-0K2 m)+NAT-1K1 \<one>\<^sub>M)"
          using A2 nat_1_th_11 sorry
        thus "Pp1(Mf0 +XCMPLX-0K2 (m +NAT-1K1 \<one>\<^sub>M))"
           sorry
      qed "sorry"
      fix i assume [ty]: "i be NatNAT-1M1"
      assume "Mf0 <=XXREAL-0R1 i"
      then obtain m where
        [ty]:"m be NatNAT-1M1" and 
        A4: "i =XBOOLE-0R4 Mf0 +XCMPLX-0K2 m"
        using nat_1_th_10 sorry
      have A5: "?Q(0NUMBERSK6)"
        using A1 sorry
      have " for m be NatNAT-1M1 holds ?Q(m)"
        using nat_1_sch_2 A5 A3 sorry
      thus "Pp1(i)"
        using A4 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed

theorem nat_1_sch_9:
  fixes af0 Pp1 
  assumes
[ty]: "af0 be NatNAT-1M1" and
   A1: " for k be NatNAT-1M1 holds k >=XXREAL-0R2 af0 & ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 af0 & n <XXREAL-0R3 k implies Pp1(n)) implies Pp1(k)"
  shows " for k be NatNAT-1M1 holds k >=XXREAL-0R2 af0 implies Pp1(k)"
  proof(rule ballI,rule impI)
    let ?P1 = "\<lambda>Lamb1.  for n be NatNAT-1M1 holds n >=XXREAL-0R2 af0 & n <XXREAL-0R3 Lamb1 implies Pp1(n)"
    have A2: " for k be NatNAT-1M1 holds k >=XXREAL-0R2 af0 implies (?P1(k) implies ?P1(k +NAT-1K1 \<one>\<^sub>M))"
    proof-
      have " for k be NatNAT-1M1 holds k >=XXREAL-0R2 af0 implies (( for n be NatNAT-1M1 holds n >=XXREAL-0R2 af0 & n <XXREAL-0R3 k implies Pp1(n)) implies ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 af0 & n <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M implies Pp1(n)))"
      proof(rule ballI,rule impI,rule impI,rule ballI,rule impMI ,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume "k >=XXREAL-0R2 af0"
        assume A3: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 af0 & n <XXREAL-0R3 k implies Pp1(n)"
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A4: "n >=XXREAL-0R2 af0"
          and A5: "n <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M"
        have "n <=XXREAL-0R1 k"
          using A5 nat_1_th_13 sorry
        then have "n <XXREAL-0R3 k or n =XBOOLE-0R4 k"
          using xxreal_0_th_1 sorry
        thus "Pp1(n)"
          using A1 A3 A4 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    fix k assume [ty]: "k be NatNAT-1M1"
    assume A6: "k >=XXREAL-0R2 af0"
    have A7: "?P1(af0)"
       sorry
    have " for k be NatNAT-1M1 holds k >=XXREAL-0R2 af0 implies ?P1(k)"
      using nat_1_sch_8 A7 A2 sorry
    then have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 af0 & n <XXREAL-0R3 k implies Pp1(n)"
      using A6 sorry
    thus "Pp1(k)"
      using A1 A6 sorry
  qed "sorry"

mtheorem nat_1_th_25:
" for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds n <=XXREAL-0R1 \<one>\<^sub>M implies n =HIDDENR1 0NUMBERSK6 or n =HIDDENR1 \<one>\<^sub>M"
proof-
  have " for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds n <=XXREAL-0R1 \<one>\<^sub>M implies ( not n =HIDDENR1 0NUMBERSK6 &  not n =HIDDENR1 \<one>\<^sub>M implies  False )"
  proof(rule ballI,rule impI,rule impMI ,rule impI)
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "n <=XXREAL-0R1 \<one>\<^sub>M"
    assume A2: " not n =HIDDENR1 0NUMBERSK6"
      and A3: " not n =HIDDENR1 \<one>\<^sub>M"
    have "n <XXREAL-0R3 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
      using A1 A3 xxreal_0_th_1 sorry
    thus " False "
      using A2 nat_1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem nat_1_sch_10:
  fixes Pp1 
  assumes
    A1: "Pp1(\<one>\<^sub>M)" and
   A2: " for k be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds Pp1(k) implies Pp1(k +NAT-1K1 \<one>\<^sub>M)"
  shows " for k be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds Pp1(k)"
  proof-
    let ?P = "\<lambda>Lamb1. Lamb1 be  non zeroORDINAL1V8 implies Pp1(Lamb1)"
    have A3: " for k be NatNAT-1M1 holds (k be  non zeroORDINAL1V8 implies Pp1(k)) implies (k +NAT-1K1 \<one>\<^sub>M be  non zeroORDINAL1V8 implies Pp1(k +NAT-1K1 \<one>\<^sub>M))"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume A4: "?P(k)"
      have "k +NAT-1K1 \<one>\<^sub>M be  non zeroORDINAL1V8 implies (k +NAT-1K1 \<one>\<^sub>M be  non zeroORDINAL1V8 implies Pp1(k +NAT-1K1 \<one>\<^sub>M))"
      proof(rule impI)
        assume "k +NAT-1K1 \<one>\<^sub>M be  non zeroORDINAL1V8"
        have "k =XBOOLE-0R4 0NUMBERSK6 or k be  non zeroORDINAL1V8"
           sorry
        thus "k +NAT-1K1 \<one>\<^sub>M be  non zeroORDINAL1V8 implies Pp1(k +NAT-1K1 \<one>\<^sub>M)"
          using A1 A2 A4 sorry
      qed
      thus "k +NAT-1K1 \<one>\<^sub>M be  non zeroORDINAL1V8 implies Pp1(k +NAT-1K1 \<one>\<^sub>M)"
         sorry
    qed "sorry"
    have A5: "?P(0NUMBERSK6)"
       sorry
    have " for k be NatNAT-1M1 holds ?P(k)"
      using nat_1_sch_2 A5 A3 sorry
    thus " for k be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds Pp1(k)"
       sorry
  qed

mdef nat_1_def_1 ("min*NAT-1K3  _ " [164]164 ) where
  mlet "A be setHIDDENM2"
"func min*NAT-1K3 A \<rightarrow> ElementSUBSET-1M1-of NATNUMBERSK1 means
  \<lambda>it. it inTARSKIR2 A & ( for k be NatNAT-1M1 holds k inTARSKIR2 A implies it <=XXREAL-0R1 k) if A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of NATNUMBERSK1 otherwise \<lambda>it. it =XBOOLE-0R4 0NUMBERSK6"
proof-
  (*existence*)
    show "(A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of NATNUMBERSK1 implies ( ex it be ElementSUBSET-1M1-of NATNUMBERSK1 st it inTARSKIR2 A & ( for k be NatNAT-1M1 holds k inTARSKIR2 A implies it <=XXREAL-0R1 k))) & ( not A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of NATNUMBERSK1 implies ( ex it be ElementSUBSET-1M1-of NATNUMBERSK1 st it =XBOOLE-0R4 0NUMBERSK6))"
    proof-
      have " not (A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of NATNUMBERSK1 & ( for VarFor1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (VarFor1 inTARSKIR2 A & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 A &  not VarFor1 <=XXREAL-0R1 k))))) &  not ( not A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of NATNUMBERSK1 & ( for VarFor1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not VarFor1 =XBOOLE-0R4 0NUMBERSK6))"
      proof-
        have "A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of NATNUMBERSK1 implies ( ex i be NatNAT-1M1 st i inTARSKIR2 A & ( for k be NatNAT-1M1 holds k inTARSKIR2 A implies i <=XXREAL-0R1 k))"
        proof-
          have "A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of NATNUMBERSK1 implies  not ( for i be NatNAT-1M1 holds  not (i inTARSKIR2 A & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 A &  not i <=XXREAL-0R1 k))))"
          proof(rule impI)
            let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 A"
            let ?x = "the ElementSUBSET-1M1-of A"
            assume A1: "A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of NATNUMBERSK1"
            then have "?x be ElementSUBSET-1M1-of NATNUMBERSK1"
              using tarski_def_3 sorry
            then have A2: " ex k be NatNAT-1M1 st ?P(k)"
              using A1 sorry
            have " ex k be NatNAT-1M1 st ?P(k) & ( for i be NatNAT-1M1 holds ?P(i) implies k <=XXREAL-0R1 i)"
              using nat_1_sch_5 A2 sorry
            thus " not ( for i be NatNAT-1M1 holds  not (i inTARSKIR2 A & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 A &  not i <=XXREAL-0R1 k))))"
               sorry
          qed
          thus " ?thesis "
             sorry
        qed
        thus " not (A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of NATNUMBERSK1 & ( for VarFor1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (VarFor1 inTARSKIR2 A & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 A &  not VarFor1 <=XXREAL-0R1 k))))) &  not ( not A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of NATNUMBERSK1 & ( for VarFor1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not VarFor1 =XBOOLE-0R4 0NUMBERSK6))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for it2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds (A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of NATNUMBERSK1 implies ((it1 inTARSKIR2 A & ( for k be NatNAT-1M1 holds k inTARSKIR2 A implies it1 <=XXREAL-0R1 k)) & (it2 inTARSKIR2 A & ( for k be NatNAT-1M1 holds k inTARSKIR2 A implies it2 <=XXREAL-0R1 k)) implies it1 =HIDDENR1 it2)) & ( not A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of NATNUMBERSK1 implies (it1 =XBOOLE-0R4 0NUMBERSK6 & it2 =XBOOLE-0R4 0NUMBERSK6 implies it1 =HIDDENR1 it2))"
    proof-
      have " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (((((A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of NATNUMBERSK1 & i inTARSKIR2 A) & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 A &  not i <=XXREAL-0R1 k))) & n inTARSKIR2 A) & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 A &  not n <=XXREAL-0R1 k))) &  not i =HIDDENR1 n) &  not ((( not A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of NATNUMBERSK1 & i =XBOOLE-0R4 0NUMBERSK6) & n =XBOOLE-0R4 0NUMBERSK6) &  not i =HIDDENR1 n)"
      proof(rule ballI,rule ballI)
        fix i assume [ty]: "i be ElementSUBSET-1M1-of NATNUMBERSK1"
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have "(A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of NATNUMBERSK1 & (i inTARSKIR2 A & ( for k be NatNAT-1M1 holds k inTARSKIR2 A implies i <=XXREAL-0R1 k))) & (n inTARSKIR2 A & ( for k be NatNAT-1M1 holds k inTARSKIR2 A implies n <=XXREAL-0R1 k)) implies i =XBOOLE-0R4 n"
        proof-
          have "A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of NATNUMBERSK1 & (((i inTARSKIR2 A & ( for k be NatNAT-1M1 holds k inTARSKIR2 A implies i <=XXREAL-0R1 k)) & n inTARSKIR2 A) & ( for k be NatNAT-1M1 holds k inTARSKIR2 A implies n <=XXREAL-0R1 k)) implies i =XBOOLE-0R4 n"
          proof(rule impMI ,rule impI)
            assume "A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of NATNUMBERSK1"
              and A3: "((i inTARSKIR2 A & ( for k be NatNAT-1M1 holds k inTARSKIR2 A implies i <=XXREAL-0R1 k)) & n inTARSKIR2 A) & ( for k be NatNAT-1M1 holds k inTARSKIR2 A implies n <=XXREAL-0R1 k)"
            have "i <=XXREAL-0R1 n & n <=XXREAL-0R1 i"
              using A3 sorry
            thus "i =XBOOLE-0R4 n"
              using xxreal_0_th_1 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        thus " not (((((A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of NATNUMBERSK1 & i inTARSKIR2 A) & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 A &  not i <=XXREAL-0R1 k))) & n inTARSKIR2 A) & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 A &  not n <=XXREAL-0R1 k))) &  not i =HIDDENR1 n) &  not ((( not A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of NATNUMBERSK1 & i =XBOOLE-0R4 0NUMBERSK6) & n =XBOOLE-0R4 0NUMBERSK6) &  not i =HIDDENR1 n)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
  (*consistency*)
    show " for it be ElementSUBSET-1M1-of NATNUMBERSK1 holds  True "
       sorry
qed "sorry"

reserve x for "objectHIDDENM1"
reserve X, Y, Z for "setHIDDENM2"
(*\$CT 12*)
mtheorem nat_1_th_38:
" for n be NatNAT-1M1 holds succORDINAL1K1 (SegmCARD-1K5 n) =XBOOLE-0R4 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
proof(rule ballI)
  fix n assume [ty]: "n be NatNAT-1M1"
  have A1: "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 {L where L be NatNAT-1M1 : L <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M }"
    using axioms_th_4 sorry
  have A2: "n =XBOOLE-0R4 {K where K be NatNAT-1M1 : K <XXREAL-0R3 n }"
    using axioms_th_4 sorry
  have "succORDINAL1K1 (SegmCARD-1K5 n) c=ORDINAL1R1 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M) & SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M) c=TARSKIR1 succORDINAL1K1 (SegmCARD-1K5 n)"
  proof(rule conjMI)
    show "succORDINAL1K1 (SegmCARD-1K5 n) c=ORDINAL1R1 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 succORDINAL1K1 (SegmCARD-1K5 n) implies x inHIDDENR3 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A3: "x inHIDDENR3 succORDINAL1K1 (SegmCARD-1K5 n)"
        show "x inHIDDENR3 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
        proof-
          have cases: "x inHIDDENR3 SegmCARD-1K5 n or x =HIDDENR1 n"
            using A3 ordinal1_th_8 sorry
          have case1: "x inHIDDENR3 SegmCARD-1K5 n implies x inHIDDENR3 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
          proof(rule impI)
            assume "x inHIDDENR3 SegmCARD-1K5 n"
            then obtain K where
              [ty]:"K be NatNAT-1M1" and 
              A4: "x =HIDDENR1 K"and A5: "K <XXREAL-0R3 n"
              using A2 sorry
            have "K <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
              using A5 nat_1_th_13 sorry
            thus "x inHIDDENR3 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
              using A1 A4 sorry
          qed
          have case2: "x =HIDDENR1 n implies x inHIDDENR3 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
          proof(rule impI)
            assume A6: "x =HIDDENR1 n"
            have 
              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "n <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
              using nat_1_th_13 sorry
            thus "x inHIDDENR3 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
              using A1 A6 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus "succORDINAL1K1 (SegmCARD-1K5 n) c=ORDINAL1R1 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
        using tarski_def_3 sorry
    qed
    have " for x be objectHIDDENM1 holds x inHIDDENR3 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M) implies x inHIDDENR3 succORDINAL1K1 (SegmCARD-1K5 n)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
      then obtain K where
        [ty]:"K be NatNAT-1M1" and 
        A7: "x =HIDDENR1 K"and A8: "K <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
        using A1 sorry
      have "K <=XXREAL-0R1 n"
        using A8 nat_1_th_13 sorry
      then have "K =XBOOLE-0R4 n or K <XXREAL-0R3 n"
        using xxreal_0_th_1 sorry
      then have "x =HIDDENR1 n or x inHIDDENR3 SegmCARD-1K5 n"
        using A2 A7 sorry
      thus "x inHIDDENR3 succORDINAL1K1 (SegmCARD-1K5 n)"
        using ordinal1_th_8 sorry
    qed "sorry"
    thus "SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M) c=TARSKIR1 succORDINAL1K1 (SegmCARD-1K5 n)"
      using tarski_def_3 sorry
  qed
  thus "succORDINAL1K1 (SegmCARD-1K5 n) =XBOOLE-0R4 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
    using xboole_0_def_10 sorry
qed "sorry"

mtheorem nat_1_th_39:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n <=XXREAL-0R1 m iff SegmCARD-1K5 n c=ORDINAL1R1 SegmCARD-1K5 m"
proof-
  have " for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  not (n <=XXREAL-0R1 m &  not SegmCARD-1K5 n c=ORDINAL1R1 SegmCARD-1K5 m) &  not (SegmCARD-1K5 n c=ORDINAL1R1 SegmCARD-1K5 m &  not n <=XXREAL-0R1 m)"
  proof(rule ballI,rule ballI)
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?P = "\<lambda>Lamb1.  for m be NatNAT-1M1 holds Lamb1 <=XXREAL-0R1 m iff SegmCARD-1K5 Lamb1 c=ORDINAL1R1 SegmCARD-1K5 m"
    have A1: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds ( for m be NatNAT-1M1 holds n <=XXREAL-0R1 m iff SegmCARD-1K5 n c=ORDINAL1R1 SegmCARD-1K5 m) implies ( for m be NatNAT-1M1 holds (n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m implies SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M) c=ORDINAL1R1 SegmCARD-1K5 m) & (SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M) c=ORDINAL1R1 SegmCARD-1K5 m implies n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m))"
      proof(rule ballI,rule impI,rule ballI,rule conjMI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A2: "?P(n)"
        fix m assume [ty]: "m be NatNAT-1M1"
        show "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m implies SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M) c=ORDINAL1R1 SegmCARD-1K5 m"
        proof(rule impI)
          assume "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m"
          then obtain k where
            [ty]:"k be NatNAT-1M1" and 
            A3: "m =XBOOLE-0R4 (n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k"
            using nat_1_th_10 sorry
          have 
            [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1"
            using ordinal1_def_12 sorry
          have "SegmCARD-1K5 n c=ORDINAL1R1 SegmCARD-1K5 (n +NAT-1K1 k)"
            using A2 nat_1_th_11 sorry
          then have A4: "succORDINAL1K1 (SegmCARD-1K5 n) c=ORDINAL1R1 succORDINAL1K1 (SegmCARD-1K5 (n +NAT-1K1 k))"
            using ordinal2_th_1 sorry
          have "SegmCARD-1K5 ((n +NAT-1K1 k)+NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 succORDINAL1K1 (SegmCARD-1K5 (n +NAT-1K1 k))"
            using nat_1_th_38 sorry
          thus "SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M) c=ORDINAL1R1 SegmCARD-1K5 m"
            using A3 A4 nat_1_th_38 sorry
        qed
        assume A5: "SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M) c=ORDINAL1R1 SegmCARD-1K5 m"
        have "SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 succORDINAL1K1 (SegmCARD-1K5 n)"
          using nat_1_th_38 sorry
        then have A6: "n inTARSKIR2 SegmCARD-1K5 m"
          using A5 ordinal1_th_21 sorry
        then have A7: "n <=XXREAL-0R1 m"
          using A2 ordinal1_def_2 sorry
        obtain nn where 
          [ty]:"nn be setHIDDENM2" and nnDef:"nn = n"
           sorry
        have "n <>HIDDENR2 m"
          using A6 sorry
        then have "n <XXREAL-0R3 m"
          using A7 xxreal_0_th_1 sorry
        thus "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m"
          using nat_1_th_13 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A8: "?P(0NUMBERSK6)"
       sorry
    have " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A8 A1 sorry
    thus " not (n <=XXREAL-0R1 m &  not SegmCARD-1K5 n c=ORDINAL1R1 SegmCARD-1K5 m) &  not (SegmCARD-1K5 n c=ORDINAL1R1 SegmCARD-1K5 m &  not n <=XXREAL-0R1 m)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_1_th_40:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds cardCARD-1K4 (SegmCARD-1K5 n) c=ORDINAL1R1 cardCARD-1K4 (SegmCARD-1K5 m) iff n <=XXREAL-0R1 m"
  using nat_1_th_39 sorry

mtheorem nat_1_th_41:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds cardCARD-1K4 (SegmCARD-1K5 n) inTARSKIR2 cardCARD-1K4 (SegmCARD-1K5 m) iff n <XXREAL-0R3 m"
proof-
  have " for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  not (cardCARD-1K4 (SegmCARD-1K5 n) inTARSKIR2 cardCARD-1K4 (SegmCARD-1K5 m) & n <XXREAL-0R3 m) &  not ( not n <XXREAL-0R3 m &  not cardCARD-1K4 (SegmCARD-1K5 n) inTARSKIR2 cardCARD-1K4 (SegmCARD-1K5 m))"
  proof(rule ballI,rule ballI)
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    have "cardCARD-1K4 (SegmCARD-1K5 n) c<XBOOLE-0R2 cardCARD-1K4 (SegmCARD-1K5 m) iff cardCARD-1K4 (SegmCARD-1K5 n) c=ORDINAL1R1 cardCARD-1K4 (SegmCARD-1K5 m) & cardCARD-1K4 (SegmCARD-1K5 n) <>HIDDENR2 cardCARD-1K4 (SegmCARD-1K5 m)"
       sorry
    thus " not (cardCARD-1K4 (SegmCARD-1K5 n) inTARSKIR2 cardCARD-1K4 (SegmCARD-1K5 m) & n <XXREAL-0R3 m) &  not ( not n <XXREAL-0R3 m &  not cardCARD-1K4 (SegmCARD-1K5 n) inTARSKIR2 cardCARD-1K4 (SegmCARD-1K5 m))"
      using nat_1_th_39 ordinal1_th_11 ordinal1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve M, N for "CardinalCARD-1M1"
mtheorem nat_1_th_42:
" for n be NatNAT-1M1 holds nextcardCARD-1K2 (cardCARD-1K4 (SegmCARD-1K5 n)) =XBOOLE-0R4 cardCARD-1K4 (SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M))"
proof-
  have " for n be NatNAT-1M1 holds nextcardCARD-1K2 (cardCARD-1K4 (SegmCARD-1K5 n)) =XBOOLE-0R4 cardCARD-1K4 (SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M))"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have 
      [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    have A1: " for M be CardinalCARD-1M1 holds cardCARD-1K4 (cardCARD-1K4 n) inTARSKIR2 M implies cardCARD-1K4 (n +NAT-1K1 \<one>\<^sub>M) c=ORDINAL1R1 M"
    proof(rule ballI,rule impI)
      fix M assume [ty]: "M be CardinalCARD-1M1"
      assume A2: "cardCARD-1K4 (cardCARD-1K4 n) inTARSKIR2 M"
      have "SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 succORDINAL1K1 (SegmCARD-1K5 n)"
        using nat_1_th_38 sorry
      thus "cardCARD-1K4 (n +NAT-1K1 \<one>\<^sub>M) c=ORDINAL1R1 M"
        using A2 ordinal1_th_21 sorry
    qed "sorry"
    have "n <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_13 sorry
    thus "nextcardCARD-1K2 (cardCARD-1K4 (SegmCARD-1K5 n)) =XBOOLE-0R4 cardCARD-1K4 (SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M))"
      using A1 nat_1_th_41 card_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CD*)
mtheorem nat_1_th_43:
" for X be finiteFINSET-1V1\<bar>setHIDDENM2 holds  for Y be finiteFINSET-1V1\<bar>setHIDDENM2 holds X c=TARSKIR1 Y implies cardCARD-1K4 X <=XXREAL-0R1 cardCARD-1K4 Y"
proof(rule ballI,rule ballI,rule impI)
  fix X assume [ty]: "X be finiteFINSET-1V1\<bar>setHIDDENM2"
  fix Y assume [ty]: "Y be finiteFINSET-1V1\<bar>setHIDDENM2"
  assume "X c=TARSKIR1 Y"
  then have "SegmCARD-1K5 cardCARD-1K4 X c=ORDINAL1R1 SegmCARD-1K5 cardCARD-1K4 Y"
    using card_1_th_11 sorry
  thus "cardCARD-1K4 X <=XXREAL-0R1 cardCARD-1K4 Y"
    using nat_1_th_39 sorry
qed "sorry"

mtheorem nat_1_th_44:
" for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds k inHIDDENR3 SegmCARD-1K5 n iff k <XXREAL-0R3 n"
proof-
  have " for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (k inHIDDENR3 SegmCARD-1K5 n implies k <XXREAL-0R3 n) & (k <XXREAL-0R3 n implies k inHIDDENR3 SegmCARD-1K5 n)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix k assume [ty]: "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    show "k inHIDDENR3 SegmCARD-1K5 n implies k <XXREAL-0R3 n"
    proof(rule impI)
      assume "k inHIDDENR3 SegmCARD-1K5 n"
      then have "k inHIDDENR3 {l where l be NatNAT-1M1 : l <XXREAL-0R3 n }"
        using axioms_th_4 sorry
      then have " ex l be NatNAT-1M1 st k =HIDDENR1 l & l <XXREAL-0R3 n"
         sorry
      thus "k <XXREAL-0R3 n"
         sorry
    qed
    assume A1: "k <XXREAL-0R3 n"
    have 
      [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    have "k inTARSKIR2 {l where l be NatNAT-1M1 : l <XXREAL-0R3 n }"
      using A1 sorry
    thus "k inHIDDENR3 SegmCARD-1K5 n"
      using axioms_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_1_th_45:
" for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds n inHIDDENR3 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
proof(rule ballI)
  fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
  have A1: "n be NatNAT-1M1"
    using tarski_th_1 sorry
  have "n <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
    using xreal_1_th_29 sorry
  then have "n inHIDDENR3 {l where l be NatNAT-1M1 : l <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M }"
    using A1 sorry
  thus "n inHIDDENR3 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
    using axioms_th_4 sorry
qed "sorry"

(*\$CT*)
syntax NAT_1M2 :: " Set \<Rightarrow> Ty" ("sequenceNAT-1M2-of  _ " [70]70)
translations "sequenceNAT-1M2-of X" \<rightharpoonup> "FunctionFUNCT-2M1-of(NATNUMBERSK1,X)"

theorem nat_1_sch_11:
  fixes Af0 Gf2 
  assumes
[ty]: "Af0 be objectHIDDENM1" and
  [ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> Gf2(x1,x2) be objectHIDDENM1"
  shows " ex f be FunctionFUNCT-1M1 st (domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0) & ( for n be NatNAT-1M1 holds f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Gf2(n,f .FUNCT-1K1 n))"
  proof-
    have " ex tVar13 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar13 =XBOOLE-0R4 NATNUMBERSK1 & (tVar13 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0 & ( for n be NatNAT-1M1 holds tVar13 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Gf2(n,tVar13 .FUNCT-1K1 n)))"
    proof-
      let ?D = "\<lambda>Lamb1. \<lambda>Lamb2. {}XBOOLE-0K1"
      obtain L where
        [ty]:"L be SequenceORDINAL1M4" and 
        A1: "domRELAT-1K1 L =XBOOLE-0R4 NATNUMBERSK1"and A2: "0NUMBERSK6 inTARSKIR2 NATNUMBERSK1 implies L .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0"and A3: " for A be OrdinalORDINAL1M3 holds succORDINAL1K1 A inTARSKIR2 NATNUMBERSK1 implies L .FUNCT-1K1 succORDINAL1K1 A =HIDDENR1 Gf2(A,L .FUNCT-1K1 A)"and " for A be OrdinalORDINAL1M3 holds (A inTARSKIR2 NATNUMBERSK1 & A <>HIDDENR2 0NUMBERSK6) & A be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 A =XBOOLE-0R4 ?D(A,L  |RELAT-1K8 A)"
        using ordinal2_sch_5 sorry
      show " ex tVar13 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar13 =XBOOLE-0R4 NATNUMBERSK1 & (tVar13 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0 & ( for n be NatNAT-1M1 holds tVar13 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Gf2(n,tVar13 .FUNCT-1K1 n)))"
      proof(rule bexI[of _ "L"],rule conjMI,rule conjMI,rule ballI)
        show "domRELAT-1K1 L =XBOOLE-0R4 NATNUMBERSK1"
          using A1 sorry
        show "L .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0"
          using A2 sorry
        fix n assume [ty]: "n be NatNAT-1M1"
        have "L .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 L .FUNCT-1K1 (SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M))"
           sorry
        also have "... = L .FUNCT-1K1 succORDINAL1K1 (SegmCARD-1K5 n)"
          using nat_1_th_38 sorry
        also have "... = Gf2(n,L .FUNCT-1K1 n)"
          using A3 ordinal1_def_12 sorry
        finally show "L .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Gf2(n,L .FUNCT-1K1 n)"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem nat_1_sch_12:
  fixes Df0 Af0 Gf2 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Af0 be ElementSUBSET-1M1-of Df0" and
  [ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> Gf2(x1,x2) be ElementSUBSET-1M1-of Df0"
  shows " ex f be sequenceNAT-1M2-of Df0 st f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & ( for n be NatNAT-1M1 holds f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Gf2(n,f .FUNCT-1K1 n))"
  proof-
    have " ex tVar14 be sequenceNAT-1M2-of Df0 st tVar14 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & ( for n be NatNAT-1M1 holds tVar14 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Gf2(n,tVar14 .FUNCT-1K1 n))"
    proof-
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A1: "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1"and A2: "f .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 Af0"and A3: " for n be NatNAT-1M1 holds f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Gf2(n,f .FUNCT-1K1 n)"
        using nat_1_sch_11 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies f .FUNCT-1K1 x inTARSKIR2 Df0"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 NATNUMBERSK1"
        then obtain n where 
          [ty]:"n be NatNAT-1M1" and nDef:"n = x"
           sorry
        show "f .FUNCT-1K1 x inTARSKIR2 Df0"
        proof-
          have cases: "n =XBOOLE-0R4 0NUMBERSK6 or ( ex k be NatNAT-1M1 st n =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M)"
            using nat_1_th_6 sorry
          have case1: "n =XBOOLE-0R4 0NUMBERSK6 implies f .FUNCT-1K1 x inTARSKIR2 Df0"
          proof(rule impI)
            assume "n =XBOOLE-0R4 0NUMBERSK6"
            thus "f .FUNCT-1K1 x inTARSKIR2 Df0"
              using A2 sorry
          qed
          have case2: "( ex k be NatNAT-1M1 st n =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M) implies f .FUNCT-1K1 x inTARSKIR2 Df0"
          proof(rule impI)
            assume " ex k be NatNAT-1M1 st n =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
            then obtain k where
              [ty]:"k be NatNAT-1M1" and 
              A4: "n =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
               sorry
            have "f .FUNCT-1K1 n =XBOOLE-0R4 Gf2(k,f .FUNCT-1K1 k)"
              using A3 A4 sorry
            thus "f .FUNCT-1K1 x inTARSKIR2 Df0"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      then have 
        [ty]:"f be sequenceNAT-1M2-of Df0"
        using A1 funct_2_th_3 sorry
      show " ex tVar14 be sequenceNAT-1M2-of Df0 st tVar14 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & ( for n be NatNAT-1M1 holds tVar14 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Gf2(n,tVar14 .FUNCT-1K1 n))"
      proof(rule bexI[of _ "f"])
        show "f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & ( for n be NatNAT-1M1 holds f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Gf2(n,f .FUNCT-1K1 n))"
          using A2 A3 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem nat_1_sch_13:
  fixes Af0 Ff0 Gf0 Pp3 
  assumes
[ty]: "Af0 be objectHIDDENM1" and
  [ty]: "Ff0 be FunctionFUNCT-1M1" and
  [ty]: "Gf0 be FunctionFUNCT-1M1" and
   A1: "domRELAT-1K1 Ff0 =XBOOLE-0R4 NATNUMBERSK1" and
   A2: "Ff0 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0" and
   A3: " for n be NatNAT-1M1 holds Pp3(n,Ff0 .FUNCT-1K1 n,Ff0 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))" and
   A4: "domRELAT-1K1 Gf0 =XBOOLE-0R4 NATNUMBERSK1" and
   A5: "Gf0 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0" and
   A6: " for n be NatNAT-1M1 holds Pp3(n,Gf0 .FUNCT-1K1 n,Gf0 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))" and
   A7: " for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  for y1 be setHIDDENM2 holds  for y2 be setHIDDENM2 holds Pp3(n,x,y1) & Pp3(n,x,y2) implies y1 =XBOOLE-0R4 y2"
  shows "Ff0 =FUNCT-1R1 Gf0"
  proof-
    let ?P = "\<lambda>Lamb1. Ff0 .FUNCT-1K1 Lamb1 =XBOOLE-0R4 Gf0 .FUNCT-1K1 Lamb1"
    have A8: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds Ff0 .FUNCT-1K1 n =XBOOLE-0R4 Gf0 .FUNCT-1K1 n implies Ff0 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Gf0 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume "Ff0 .FUNCT-1K1 n =XBOOLE-0R4 Gf0 .FUNCT-1K1 n"
        then have A9: "Pp3(n,Ff0 .FUNCT-1K1 n,Gf0 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
          using A6 sorry
        have "Pp3(n,Ff0 .FUNCT-1K1 n,Ff0 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
          using A3 sorry
        thus "Ff0 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Gf0 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
          using A7 A9 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A10: "?P(0NUMBERSK6)"
      using A2 A5 sorry
    have " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A10 A8 sorry
    then have " for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies Ff0 .FUNCT-1K1 x =XBOOLE-0R4 Gf0 .FUNCT-1K1 x"
       sorry
    thus "Ff0 =FUNCT-1R1 Gf0"
      using A1 A4 funct_1_th_2 sorry
  qed

theorem nat_1_sch_14:
  fixes Df0 Af0 Ff0 Gf0 Pp3 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Af0 be ElementSUBSET-1M1-of Df0" and
  [ty]: "Ff0 be sequenceNAT-1M2-of Df0" and
  [ty]: "Gf0 be sequenceNAT-1M2-of Df0" and
   A1: "Ff0 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0" and
   A2: " for n be NatNAT-1M1 holds Pp3(n,Ff0 .FUNCT-1K1 n,Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))" and
   A3: "Gf0 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0" and
   A4: " for n be NatNAT-1M1 holds Pp3(n,Gf0 .FUNCT-1K1 n,Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))" and
   A5: " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of Df0 holds  for y1 be ElementSUBSET-1M1-of Df0 holds  for y2 be ElementSUBSET-1M1-of Df0 holds Pp3(n,x,y1) & Pp3(n,x,y2) implies y1 =XBOOLE-0R4 y2"
  shows "Ff0 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,Df0)\<^esub> Gf0"
  proof-
    have "Ff0 <>HIDDENR2 Gf0 implies  False "
    proof(rule impI)
      let ?Q = "\<lambda>Lamb1. Ff0 .FUNCT-1K1 Lamb1 <>HIDDENR2 Gf0 .FUNCT-1K1 Lamb1"
      have A6: "domRELAT-1K1 Ff0 =XBOOLE-0R4 NATNUMBERSK1 & domRELAT-1K1 Gf0 =XBOOLE-0R4 NATNUMBERSK1"
        using funct_2_def_1 sorry
      assume "Ff0 <>HIDDENR2 Gf0"
      then have " ex x be objectHIDDENM1 st x inHIDDENR3 NATNUMBERSK1 & Ff0 .FUNCT-1K1 x <>HIDDENR2 Gf0 .FUNCT-1K1 x"
        using A6 funct_1_th_2 sorry
      then have A7: " ex k be NatNAT-1M1 st ?Q(k)"
         sorry
      obtain m where
        [ty]:"m be NatNAT-1M1" and 
        A8: "?Q(m) & ( for n be NatNAT-1M1 holds ?Q(n) implies m <=XXREAL-0R1 n)"
        using nat_1_sch_5 A7 sorry
      have "m <>HIDDENR2 0NUMBERSK6 implies  False "
      proof(rule impI)
        assume "m <>HIDDENR2 0NUMBERSK6"
        then obtain k where
          [ty]:"k be NatNAT-1M1" and 
          A9: "m =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_6 sorry
        have 
          [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "k <XXREAL-0R3 m"
          using A9 nat_1_th_13 sorry
        then have A10: "Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Df0)\<^esub> k =XBOOLE-0R4 Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Df0)\<^esub> k"
          using A8 sorry
        have "Pp3(k,Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Df0)\<^esub> k,Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Df0)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)) & Pp3(k,Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Df0)\<^esub> k,Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Df0)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
          using A2 A4 sorry
        thus " False "
          using A5 A8 A9 A10 sorry
      qed
      thus " False "
        using A1 A3 A8 sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem nat_1_sch_15:
  fixes Af0 RecFunf2 Ff0 Gf0 
  assumes
[ty]: "Af0 be objectHIDDENM1" and
  [ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> RecFunf2(x1,x2) be objectHIDDENM1" and
  [ty]: "Ff0 be FunctionFUNCT-1M1" and
  [ty]: "Gf0 be FunctionFUNCT-1M1" and
   A1: "domRELAT-1K1 Ff0 =XBOOLE-0R4 NATNUMBERSK1" and
   A2: "Ff0 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0" and
   A3: " for n be NatNAT-1M1 holds Ff0 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 RecFunf2(n,Ff0 .FUNCT-1K1 n)" and
   A4: "domRELAT-1K1 Gf0 =XBOOLE-0R4 NATNUMBERSK1" and
   A5: "Gf0 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0" and
   A6: " for n be NatNAT-1M1 holds Gf0 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 RecFunf2(n,Gf0 .FUNCT-1K1 n)"
  shows "Ff0 =FUNCT-1R1 Gf0"
  proof-
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3. Lamb3 =HIDDENR1 RecFunf2(Lamb1,Lamb2)"
    have A7: " for n be NatNAT-1M1 holds ?P(n,Gf0 .FUNCT-1K1 n,Gf0 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
      using A6 sorry
    have A8: " for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  for y1 be setHIDDENM2 holds  for y2 be setHIDDENM2 holds ?P(n,x,y1) & ?P(n,x,y2) implies y1 =XBOOLE-0R4 y2"
       sorry
    have A9: " for n be NatNAT-1M1 holds ?P(n,Ff0 .FUNCT-1K1 n,Ff0 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
      using A3 sorry
    show "Ff0 =FUNCT-1R1 Gf0"
      using nat_1_sch_13 A1 A2 A9 A4 A5 A7 A8 sorry
  qed

theorem nat_1_sch_16:
  fixes Df0 Af0 RecFunf2 Ff0 Gf0 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Af0 be ElementSUBSET-1M1-of Df0" and
  [ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> RecFunf2(x1,x2) be ElementSUBSET-1M1-of Df0" and
  [ty]: "Ff0 be sequenceNAT-1M2-of Df0" and
  [ty]: "Gf0 be sequenceNAT-1M2-of Df0" and
   A1: "Ff0 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0" and
   A2: " for n be NatNAT-1M1 holds Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 RecFunf2(n,Ff0 .FUNCT-1K1 n)" and
   A3: "Gf0 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0" and
   A4: " for n be NatNAT-1M1 holds Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 RecFunf2(n,Gf0 .FUNCT-1K1 n)"
  shows "Ff0 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,Df0)\<^esub> Gf0"
  proof-
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3. Lamb3 =XBOOLE-0R4 RecFunf2(Lamb1,Lamb2)"
    have A5: " for n be NatNAT-1M1 holds ?P(n,Gf0 .FUNCT-1K1 n,Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
      using A4 sorry
    have A6: " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of Df0 holds  for y1 be ElementSUBSET-1M1-of Df0 holds  for y2 be ElementSUBSET-1M1-of Df0 holds ?P(n,x,y1) & ?P(n,x,y2) implies y1 =XBOOLE-0R4 y2"
       sorry
    have A7: " for n be NatNAT-1M1 holds ?P(n,Ff0 .FUNCT-1K1 n,Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
      using A2 sorry
    show "Ff0 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,Df0)\<^esub> Gf0"
      using nat_1_sch_14 A1 A7 A3 A5 A6 sorry
  qed

mtheorem nat_1_cl_13:
  mlet "x be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "y be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster minXXREAL-0K4(x,y) as-term-is naturalORDINAL1V7"
proof
(*coherence*)
  show "minXXREAL-0K4(x,y) be naturalORDINAL1V7"
    using xxreal_0_th_15 sorry
qed "sorry"

mtheorem nat_1_cl_14:
  mlet "x be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "y be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster maxXXREAL-0K5(x,y) as-term-is naturalORDINAL1V7"
proof
(*coherence*)
  show "maxXXREAL-0K5(x,y) be naturalORDINAL1V7"
    using xxreal_0_th_16 sorry
qed "sorry"

abbreviation(input) NAT_1K4("minNAT-1K4'( _ , _ ')" [0,0]228) where
  "minNAT-1K4(x,y) \<equiv> minXXREAL-0K4(x,y)"

mtheorem nat_1_add_3:
  mlet "x be ElementSUBSET-1M1-of NATNUMBERSK1", "y be ElementSUBSET-1M1-of NATNUMBERSK1"
"cluster minXXREAL-0K4(x,y) as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "minXXREAL-0K4(x,y) be ElementSUBSET-1M1-of NATNUMBERSK1"
    using xxreal_0_th_15 sorry
qed "sorry"

abbreviation(input) NAT_1K5("maxNAT-1K5'( _ , _ ')" [0,0]228) where
  "maxNAT-1K5(x,y) \<equiv> maxXXREAL-0K5(x,y)"

mtheorem nat_1_add_4:
  mlet "x be ElementSUBSET-1M1-of NATNUMBERSK1", "y be ElementSUBSET-1M1-of NATNUMBERSK1"
"cluster maxXXREAL-0K5(x,y) as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "maxXXREAL-0K5(x,y) be ElementSUBSET-1M1-of NATNUMBERSK1"
    using xxreal_0_th_16 sorry
qed "sorry"

theorem nat_1_sch_17:
  fixes Ff1 
  assumes
[ty_func]: "\<And> x1. x1 be NatNAT-1M1 \<Longrightarrow> Ff1(x1) be NatNAT-1M1" and
   A1: " for k be NatNAT-1M1 holds Ff1(k +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 Ff1(k) or Ff1(k) =XBOOLE-0R4 0NUMBERSK6"
  shows " ex k be NatNAT-1M1 st Ff1(k) =XBOOLE-0R4 0NUMBERSK6 & ( for n be NatNAT-1M1 holds Ff1(n) =XBOOLE-0R4 0NUMBERSK6 implies k <=XXREAL-0R1 n)"
  proof-
    have " ex tVar16 be NatNAT-1M1 st Ff1(tVar16) =XBOOLE-0R4 0NUMBERSK6 & ( for n be NatNAT-1M1 holds  not (Ff1(n) =XBOOLE-0R4 0NUMBERSK6 &  not tVar16 <=XXREAL-0R1 n))"
    proof-
      let ?X = "\<lambda>Lamb1. Ff1(Lamb1) =XBOOLE-0R4 0NUMBERSK6"
      let ?P = "\<lambda>Lamb1.  ex n be NatNAT-1M1 st Lamb1 =XBOOLE-0R4 Ff1(n)"
      have A2: " for k be NatNAT-1M1 holds k <>HIDDENR2 0NUMBERSK6 & ?P(k) implies ( ex m be NatNAT-1M1 st m <XXREAL-0R3 k & ?P(m))"
      proof-
        have " for k be NatNAT-1M1 holds k <>HIDDENR2 0NUMBERSK6 & ( ex n be NatNAT-1M1 st k =XBOOLE-0R4 Ff1(n)) implies ( ex IT be NatNAT-1M1 st  not IT <XXREAL-0R3 k & ( ex n be NatNAT-1M1 st IT =XBOOLE-0R4 Ff1(n)))"
        proof(rule ballI,rule impMI ,rule impI)
          fix k assume [ty]: "k be NatNAT-1M1"
          assume A3: "k <>HIDDENR2 0NUMBERSK6"
            and A4: "?P(k)"
          obtain n where
            [ty]:"n be NatNAT-1M1" and 
            A5: "k =XBOOLE-0R4 Ff1(n)"
            using A4 sorry
          obtain IT where 
            [ty]:"IT be NatNAT-1M1" and ITDef:"IT = Ff1(n +NAT-1K1 \<one>\<^sub>M)"
             sorry
          show " ex IT be NatNAT-1M1 st  not IT <XXREAL-0R3 k & ( ex n be NatNAT-1M1 st IT =XBOOLE-0R4 Ff1(n))"
          proof(rule bexI[of _ "IT"])
            show " not IT <XXREAL-0R3 k & ( ex n be NatNAT-1M1 st IT =XBOOLE-0R4 Ff1(n))"
              using A1 A3 A5 sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have "Ff1(0NUMBERSK6) be NatNAT-1M1"
         sorry
      then have A6: " ex k be NatNAT-1M1 st ?P(k)"
         sorry
      have "?P(0NUMBERSK6)"
        using nat_1_sch_7 A6 A2 sorry
      then have A7: " ex k be NatNAT-1M1 st ?X(k)"
         sorry
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A8: "?X(k) & ( for n be NatNAT-1M1 holds ?X(n) implies k <=XXREAL-0R1 n)"
        using nat_1_sch_5 A7 sorry
      show " ex tVar16 be NatNAT-1M1 st Ff1(tVar16) =XBOOLE-0R4 0NUMBERSK6 & ( for n be NatNAT-1M1 holds  not (Ff1(n) =XBOOLE-0R4 0NUMBERSK6 &  not tVar16 <=XXREAL-0R1 n))"
      proof(rule bexI[of _ "k"])
        show "Ff1(k) =XBOOLE-0R4 0NUMBERSK6 & ( for n be NatNAT-1M1 holds  not (Ff1(n) =XBOOLE-0R4 0NUMBERSK6 &  not k <=XXREAL-0R1 n))"
          using A8 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mdef nat_1_def_3 (" _ ^'\\NAT-1K6  _ " [164,164]164 ) where
  mlet "s be ManySortedSetPBOOLEM1-of NATNUMBERSK1", "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"func s ^\\NAT-1K6 k \<rightarrow> ManySortedSetPBOOLEM1-of NATNUMBERSK1 means
  \<lambda>it.  for n be NatNAT-1M1 holds it .FUNCT-1K1 n =XBOOLE-0R4 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
proof-
  (*existence*)
    show " ex it be ManySortedSetPBOOLEM1-of NATNUMBERSK1 st  for n be NatNAT-1M1 holds it .FUNCT-1K1 n =XBOOLE-0R4 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
    proof-
      have " ex tVar18 be ManySortedSetPBOOLEM1-of NATNUMBERSK1 st  for n be NatNAT-1M1 holds tVar18 .FUNCT-1K1 n =XBOOLE-0R4 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
      proof-
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st n =HIDDENR1 Lamb1 & Lamb2 =HIDDENR1 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
        have A1: " for i be objectHIDDENM1 holds i inHIDDENR3 NATNUMBERSK1 implies ( ex j be objectHIDDENM1 st ?P(i,j))"
        proof-
          have " for i be objectHIDDENM1 holds i inHIDDENR3 NATNUMBERSK1 implies ( ex j be setHIDDENM2 st  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st n =HIDDENR1 i & j =HIDDENR1 s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
          proof(rule ballI,rule impI)
            fix i assume [ty]: "i be objectHIDDENM1"
            assume "i inHIDDENR3 NATNUMBERSK1"
            then obtain n where 
              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = i"
               sorry
            obtain j where 
              [ty]:"j be setHIDDENM2" and jDef:"j = s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
               sorry
            show " ex j be setHIDDENM2 st  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st n =HIDDENR1 i & j =HIDDENR1 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
            proof(rule bexI[of _ "j"])
              show " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st n =HIDDENR1 i & j =HIDDENR1 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
                 sorry
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain f where
          [ty]:"f be ManySortedSetPBOOLEM1-of NATNUMBERSK1" and 
          A2: " for i be objectHIDDENM1 holds i inHIDDENR3 NATNUMBERSK1 implies ?P(i,f .FUNCT-1K1 i)"
          using pboole_sch_3 A1 sorry
        show " ex tVar18 be ManySortedSetPBOOLEM1-of NATNUMBERSK1 st  for n be NatNAT-1M1 holds tVar18 .FUNCT-1K1 n =XBOOLE-0R4 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
        proof(rule bexI[of _ "f"],rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have "?P(n,f .FUNCT-1K1 n)"
            using A2 ordinal1_def_12 sorry
          thus "f .FUNCT-1K1 n =XBOOLE-0R4 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be ManySortedSetPBOOLEM1-of NATNUMBERSK1 holds  for it2 be ManySortedSetPBOOLEM1-of NATNUMBERSK1 holds ( for n be NatNAT-1M1 holds it1 .FUNCT-1K1 n =XBOOLE-0R4 s .FUNCT-1K1 (n +XCMPLX-0K2 k)) & ( for n be NatNAT-1M1 holds it2 .FUNCT-1K1 n =XBOOLE-0R4 s .FUNCT-1K1 (n +XCMPLX-0K2 k)) implies it1 =HIDDENR1 it2"
    proof-
      have " for s1 be ManySortedSetPBOOLEM1-of NATNUMBERSK1 holds  for s2 be ManySortedSetPBOOLEM1-of NATNUMBERSK1 holds ( for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n =XBOOLE-0R4 s .FUNCT-1K1 (n +XCMPLX-0K2 k)) & ( for n be NatNAT-1M1 holds s2 .FUNCT-1K1 n =XBOOLE-0R4 s .FUNCT-1K1 (n +XCMPLX-0K2 k)) implies s1 =FUNCT-1R1 s2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix s1 assume [ty]: "s1 be ManySortedSetPBOOLEM1-of NATNUMBERSK1"
        fix s2 assume [ty]: "s2 be ManySortedSetPBOOLEM1-of NATNUMBERSK1"
        assume A3: " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n =XBOOLE-0R4 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          and A4: " for n be NatNAT-1M1 holds s2 .FUNCT-1K1 n =XBOOLE-0R4 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
        have " for n be objectHIDDENM1 holds n inHIDDENR3 NATNUMBERSK1 implies s1 .FUNCT-1K1 n =HIDDENR1 s2 .FUNCT-1K1 n"
        proof(rule ballI,rule impI)
          fix n assume [ty]: "n be objectHIDDENM1"
          assume "n inHIDDENR3 NATNUMBERSK1"
          then obtain nn where 
            [ty]:"nn be ElementSUBSET-1M1-of NATNUMBERSK1" and nnDef:"nn = n"
             sorry
          have "s1 .FUNCT-1K1 n =HIDDENR1 s .FUNCT-1K1 (nn +XCMPLX-0K2 k)"
            using A3 sorry
          also have "... = s2 .FUNCT-1K1 n"
            using A4 sorry
          finally show "s1 .FUNCT-1K1 n =HIDDENR1 s2 .FUNCT-1K1 n"
             sorry
        qed "sorry"
        thus "s1 =FUNCT-1R1 s2"
          using pboole_th_3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mlemma nat_1_lm_1:
" for s be ManySortedSetPBOOLEM1-of NATNUMBERSK1 holds  for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds rngFUNCT-1K2 (s ^\\NAT-1K6 k) c=TARSKIR1 rngFUNCT-1K2 s"
proof(rule ballI,rule ballI)
  fix s assume [ty]: "s be ManySortedSetPBOOLEM1-of NATNUMBERSK1"
  fix k assume [ty]: "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
  have " for i be objectHIDDENM1 holds i inHIDDENR3 rngFUNCT-1K2 (s ^\\NAT-1K6 k) implies i inHIDDENR3 rngFUNCT-1K2 s"
  proof(rule ballI,rule impI)
    fix i assume [ty]: "i be objectHIDDENM1"
    assume "i inHIDDENR3 rngFUNCT-1K2 (s ^\\NAT-1K6 k)"
    then obtain u where
      [ty]:"u be objectHIDDENM1" and 
      A1: "u inHIDDENR3 domRELAT-1K1 (s ^\\NAT-1K6 k)"and A2: "i =HIDDENR1 (s ^\\NAT-1K6 k).FUNCT-1K1 u"
      using funct_1_def_3 sorry
    obtain n where 
      [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = u"
      using A1 partfun1_def_2 sorry
    have A3: "domRELAT-1K1 s =XBOOLE-0R4 NATNUMBERSK1"
      using partfun1_def_2 sorry
    have "i =HIDDENR1 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
      using A2 nat_1_def_3 sorry
    thus "i inHIDDENR3 rngFUNCT-1K2 s"
      using A3 funct_1_th_3 ordinal1_def_12 sorry
  qed "sorry"
  thus "rngFUNCT-1K2 (s ^\\NAT-1K6 k) c=TARSKIR1 rngFUNCT-1K2 s"
    using tarski_def_3 sorry
qed "sorry"

mtheorem nat_1_cl_15:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "s be X -valuedRELAT-1V5\<bar>ManySortedSetPBOOLEM1-of NATNUMBERSK1", "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster s ^\\NAT-1K6 k as-term-is X -valuedRELAT-1V5"
proof
(*coherence*)
  show "s ^\\NAT-1K6 k be X -valuedRELAT-1V5"
  proof-
    have A1: "rngFUNCT-1K2 (s ^\\NAT-1K6 k) c=TARSKIR1 rngFUNCT-1K2 s"
      using nat_1_lm_1 sorry
    have Cut1300: "rngFUNCT-1K2 s c=TARSKIR1 X"
      using relat_1_def_19 sorry
    have "rngFUNCT-1K2 (s ^\\NAT-1K6 k) c=TARSKIR1 X"
    proof-
      show "rngFUNCT-1K2 (s ^\\NAT-1K6 k) c=TARSKIR1 X"
        using A1 Cut1300 sorry
    qed
    thus "s ^\\NAT-1K6 k be X -valuedRELAT-1V5"
      using relat_1_def_19 sorry
  qed
qed "sorry"

syntax NAT_1K7 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ ^'\\NAT-1K7\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164)
translations "s ^\\NAT-1K7\<^bsub>(X)\<^esub> k" \<rightharpoonup> "s ^\\NAT-1K6 k"

mtheorem nat_1_add_5:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "s be sequenceNAT-1M2-of X", "k be NatNAT-1M1"
"cluster s ^\\NAT-1K6 k as-term-is sequenceNAT-1M2-of X"
proof
(*coherence*)
  show "s ^\\NAT-1K6 k be sequenceNAT-1M2-of X"
  proof-
    have "rngFUNCT-1K2 (s ^\\NAT-1K6 k) c=TARSKIR1 X & domRELAT-1K1 (s ^\\NAT-1K6 k) =XBOOLE-0R4 NATNUMBERSK1"
      using partfun1_def_2 relat_1_def_19 sorry
    thus "s ^\\NAT-1K6 k be sequenceNAT-1M2-of X"
      using relset_1_th_4 sorry
  qed
qed "sorry"

reserve X for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve s for "sequenceNAT-1M2-of X"
mtheorem nat_1_th_47:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for s be sequenceNAT-1M2-of X holds s ^\\NAT-1K7\<^bsub>(X)\<^esub> (0NUMBERSK6) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,X)\<^esub> s"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for s be sequenceNAT-1M2-of X holds s ^\\NAT-1K7\<^bsub>(X)\<^esub> (0NUMBERSK6) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,X)\<^esub> s"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix s assume [ty]: "s be sequenceNAT-1M2-of X"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (s ^\\NAT-1K7\<^bsub>(X)\<^esub> (0NUMBERSK6)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,X)\<^esub> n =HIDDENR1 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,X)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(s ^\\NAT-1K7\<^bsub>(X)\<^esub> (0NUMBERSK6)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,X)\<^esub> n =HIDDENR1 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,X)\<^esub> (n +NAT-1K1 0NUMBERSK6)"
        using nat_1_def_3 sorry
      also have "... = s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,X)\<^esub> n"
         sorry
      finally show "(s ^\\NAT-1K7\<^bsub>(X)\<^esub> (0NUMBERSK6)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,X)\<^esub> n =HIDDENR1 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,X)\<^esub> n"
         sorry
    qed "sorry"
    thus "s ^\\NAT-1K7\<^bsub>(X)\<^esub> (0NUMBERSK6) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,X)\<^esub> s"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_1_th_48:
" for k be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for s be sequenceNAT-1M2-of X holds (s ^\\NAT-1K7\<^bsub>(X)\<^esub> k)^\\NAT-1K7\<^bsub>(X)\<^esub> m =FUNCT-2R2\<^bsub>(NATNUMBERSK1,X)\<^esub> s ^\\NAT-1K7\<^bsub>(X)\<^esub> (k +XCMPLX-0K2 m)"
proof-
  have " for k be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for s be sequenceNAT-1M2-of X holds (s ^\\NAT-1K7\<^bsub>(X)\<^esub> k)^\\NAT-1K7\<^bsub>(X)\<^esub> m =FUNCT-2R2\<^bsub>(NATNUMBERSK1,X)\<^esub> s ^\\NAT-1K7\<^bsub>(X)\<^esub> (k +XCMPLX-0K2 m)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix s assume [ty]: "s be sequenceNAT-1M2-of X"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((s ^\\NAT-1K7\<^bsub>(X)\<^esub> k)^\\NAT-1K7\<^bsub>(X)\<^esub> m).FUNCT-2K3\<^bsub>(NATNUMBERSK1,X)\<^esub> n =HIDDENR1 (s ^\\NAT-1K7\<^bsub>(X)\<^esub> (k +XCMPLX-0K2 m)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,X)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((s ^\\NAT-1K7\<^bsub>(X)\<^esub> k)^\\NAT-1K7\<^bsub>(X)\<^esub> m).FUNCT-2K3\<^bsub>(NATNUMBERSK1,X)\<^esub> n =HIDDENR1 (s ^\\NAT-1K7\<^bsub>(X)\<^esub> k).FUNCT-1K1 (n +XCMPLX-0K2 m)"
        using nat_1_def_3 sorry
      also have "... = s .FUNCT-1K1 ((n +XCMPLX-0K2 m)+XCMPLX-0K2 k)"
        using nat_1_def_3 sorry
      also have "... = s .FUNCT-1K1 (n +XCMPLX-0K2 (k +XCMPLX-0K2 m))"
         sorry
      also have "... = (s ^\\NAT-1K7\<^bsub>(X)\<^esub> (k +XCMPLX-0K2 m)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,X)\<^esub> n"
        using nat_1_def_3 sorry
      finally show "((s ^\\NAT-1K7\<^bsub>(X)\<^esub> k)^\\NAT-1K7\<^bsub>(X)\<^esub> m).FUNCT-2K3\<^bsub>(NATNUMBERSK1,X)\<^esub> n =HIDDENR1 (s ^\\NAT-1K7\<^bsub>(X)\<^esub> (k +XCMPLX-0K2 m)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,X)\<^esub> n"
         sorry
    qed "sorry"
    thus "(s ^\\NAT-1K7\<^bsub>(X)\<^esub> k)^\\NAT-1K7\<^bsub>(X)\<^esub> m =FUNCT-2R2\<^bsub>(NATNUMBERSK1,X)\<^esub> s ^\\NAT-1K7\<^bsub>(X)\<^esub> (k +XCMPLX-0K2 m)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_1_th_49:
" for k be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for s be sequenceNAT-1M2-of X holds (s ^\\NAT-1K7\<^bsub>(X)\<^esub> k)^\\NAT-1K7\<^bsub>(X)\<^esub> m =FUNCT-2R2\<^bsub>(NATNUMBERSK1,X)\<^esub> (s ^\\NAT-1K7\<^bsub>(X)\<^esub> m)^\\NAT-1K7\<^bsub>(X)\<^esub> k"
proof-
  have " for k be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for s be sequenceNAT-1M2-of X holds (s ^\\NAT-1K7\<^bsub>(X)\<^esub> k)^\\NAT-1K7\<^bsub>(X)\<^esub> m =HIDDENR1 (s ^\\NAT-1K7\<^bsub>(X)\<^esub> m)^\\NAT-1K7\<^bsub>(X)\<^esub> k"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix s assume [ty]: "s be sequenceNAT-1M2-of X"
    have "(s ^\\NAT-1K7\<^bsub>(X)\<^esub> k)^\\NAT-1K7\<^bsub>(X)\<^esub> m =HIDDENR1 s ^\\NAT-1K7\<^bsub>(X)\<^esub> (k +XCMPLX-0K2 m)"
      using nat_1_th_48 sorry
    also have "... = (s ^\\NAT-1K7\<^bsub>(X)\<^esub> m)^\\NAT-1K7\<^bsub>(X)\<^esub> k"
      using nat_1_th_48 sorry
    finally show "(s ^\\NAT-1K7\<^bsub>(X)\<^esub> k)^\\NAT-1K7\<^bsub>(X)\<^esub> m =HIDDENR1 (s ^\\NAT-1K7\<^bsub>(X)\<^esub> m)^\\NAT-1K7\<^bsub>(X)\<^esub> k"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_1_cl_16:
  mlet "N be sequenceNAT-1M2-of NATNUMBERSK1", "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "s be sequenceNAT-1M2-of X"
"cluster s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,X)\<^esub> N as-term-is Function-likeFUNCT-1V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>X -valuedRELAT-1V5"
proof
(*coherence*)
  show "s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,X)\<^esub> N be Function-likeFUNCT-1V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>X -valuedRELAT-1V5"
     sorry
qed "sorry"

mtheorem nat_1_cl_17:
  mlet "N be sequenceNAT-1M2-of NATNUMBERSK1", "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "s be sequenceNAT-1M2-of X"
"cluster s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,X)\<^esub> N as-term-is totalPARTFUN1V1\<^bsub>(NATNUMBERSK1)\<^esub>"
proof
(*coherence*)
  show "s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,X)\<^esub> N be totalPARTFUN1V1\<^bsub>(NATNUMBERSK1)\<^esub>"
     sorry
qed "sorry"

mtheorem nat_1_th_50:
" for k be NatNAT-1M1 holds  for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for s be sequenceNAT-1M2-of X holds  for N be sequenceNAT-1M2-of NATNUMBERSK1 holds (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,X)\<^esub> N)^\\NAT-1K7\<^bsub>(X)\<^esub> k =FUNCT-2R2\<^bsub>(NATNUMBERSK1,X)\<^esub> s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,X)\<^esub> (N ^\\NAT-1K7\<^bsub>(NATNUMBERSK1)\<^esub> k)"
proof-
  have " for k be NatNAT-1M1 holds  for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for s be sequenceNAT-1M2-of X holds  for N be sequenceNAT-1M2-of NATNUMBERSK1 holds (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,X)\<^esub> N)^\\NAT-1K7\<^bsub>(X)\<^esub> k =FUNCT-2R2\<^bsub>(NATNUMBERSK1,X)\<^esub> s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,X)\<^esub> (N ^\\NAT-1K7\<^bsub>(NATNUMBERSK1)\<^esub> k)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix s assume [ty]: "s be sequenceNAT-1M2-of X"
    fix N assume [ty]: "N be sequenceNAT-1M2-of NATNUMBERSK1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,X)\<^esub> N)^\\NAT-1K7\<^bsub>(X)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,X)\<^esub> n =HIDDENR1 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,X)\<^esub> (N ^\\NAT-1K7\<^bsub>(NATNUMBERSK1)\<^esub> k)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,X)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,X)\<^esub> N)^\\NAT-1K7\<^bsub>(X)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,X)\<^esub> n =HIDDENR1 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,X)\<^esub> N).FUNCT-1K1 (n +XCMPLX-0K2 k)"
        using nat_1_def_3 sorry
      also have "... = s .FUNCT-1K1 (N .FUNCT-1K1 (n +XCMPLX-0K2 k))"
        using funct_2_th_15 ordinal1_def_12 sorry
      also have "... = s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,X)\<^esub> ((N ^\\NAT-1K7\<^bsub>(NATNUMBERSK1)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> n)"
        using nat_1_def_3 sorry
      also have "... = (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,X)\<^esub> (N ^\\NAT-1K7\<^bsub>(NATNUMBERSK1)\<^esub> k)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,X)\<^esub> n"
        using funct_2_th_15 sorry
      finally show "((s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,X)\<^esub> N)^\\NAT-1K7\<^bsub>(X)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,X)\<^esub> n =HIDDENR1 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,X)\<^esub> (N ^\\NAT-1K7\<^bsub>(NATNUMBERSK1)\<^esub> k)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,X)\<^esub> n"
         sorry
    qed "sorry"
    thus "(s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,X)\<^esub> N)^\\NAT-1K7\<^bsub>(X)\<^esub> k =FUNCT-2R2\<^bsub>(NATNUMBERSK1,X)\<^esub> s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,X)\<^esub> (N ^\\NAT-1K7\<^bsub>(NATNUMBERSK1)\<^esub> k)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_1_th_51:
" for n be NatNAT-1M1 holds  for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for s be sequenceNAT-1M2-of X holds s .FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 s"
proof-
  have " for n be NatNAT-1M1 holds  for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for s be sequenceNAT-1M2-of X holds s .FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 s"
  proof(rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix s assume [ty]: "s be sequenceNAT-1M2-of X"
    have "n inTARSKIR2 NATNUMBERSK1"
      using ordinal1_def_12 sorry
    then have "n inTARSKIR2 domRELAT-1K1 s"
      using funct_2_def_1 sorry
    thus "s .FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 s"
      using funct_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_1_th_52:
" for Y be setHIDDENM2 holds  for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for s be sequenceNAT-1M2-of X holds ( for n be NatNAT-1M1 holds s .FUNCT-1K1 n inTARSKIR2 Y) implies rngFUNCT-1K2 s c=TARSKIR1 Y"
proof-
  have " for Y be setHIDDENM2 holds  for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for s be sequenceNAT-1M2-of X holds ( for n be NatNAT-1M1 holds s .FUNCT-1K1 n inTARSKIR2 Y) implies rngFUNCT-1K2 s c=TARSKIR1 Y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix s assume [ty]: "s be sequenceNAT-1M2-of X"
    assume A1: " for n be NatNAT-1M1 holds s .FUNCT-1K1 n inTARSKIR2 Y"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 s implies y inHIDDENR3 Y"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 rngFUNCT-1K2 s"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A2: "x inHIDDENR3 domRELAT-1K1 s"and A3: "y =HIDDENR1 s .FUNCT-1K1 x"
        using funct_1_def_3 sorry
      have "x inHIDDENR3 NATNUMBERSK1"
        using A2 funct_2_def_1 sorry
      thus "y inHIDDENR3 Y"
        using A1 A3 sorry
    qed "sorry"
    thus "rngFUNCT-1K2 s c=TARSKIR1 Y"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_1_th_53:
" for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds n be  non zeroORDINAL1V8 implies n =HIDDENR1 \<one>\<^sub>M or n >XXREAL-0R4 \<one>\<^sub>M"
proof(rule ballI,rule impI)
  fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
  assume "n be  non zeroORDINAL1V8"
  then have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
    using nat_1_th_13 sorry
  thus "n =HIDDENR1 \<one>\<^sub>M or n >XXREAL-0R4 \<one>\<^sub>M"
    using xxreal_0_th_1 sorry
qed "sorry"

mtheorem nat_1_th_54:
" for n be NatNAT-1M1 holds succORDINAL1K1 (SegmCARD-1K5 n) =XBOOLE-0R4 {l where l be NatNAT-1M1 : l <=XXREAL-0R1 n }"
proof-
  have " for n be NatNAT-1M1 holds succORDINAL1K1 (SegmCARD-1K5 n) =XBOOLE-0R4 {l where l be NatNAT-1M1 : l <=XXREAL-0R1 n }"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have "succORDINAL1K1 (SegmCARD-1K5 n) c=TARSKIR1 {k where k be NatNAT-1M1 : k <=XXREAL-0R1 n } & {l where l be NatNAT-1M1 : l <=XXREAL-0R1 n } c=TARSKIR1 succORDINAL1K1 (SegmCARD-1K5 n)"
    proof(rule conjMI)
      show "succORDINAL1K1 (SegmCARD-1K5 n) c=TARSKIR1 {k where k be NatNAT-1M1 : k <=XXREAL-0R1 n }"
      proof-
        have "succORDINAL1K1 (SegmCARD-1K5 n) c=TARSKIR1 {k where k be NatNAT-1M1 : k <=XXREAL-0R1 n }"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 succORDINAL1K1 (SegmCARD-1K5 n) implies x inHIDDENR3 {k where k be NatNAT-1M1 : k <=XXREAL-0R1 n }"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A1: "x inHIDDENR3 succORDINAL1K1 (SegmCARD-1K5 n)"
            then have "x inHIDDENR3 SegmCARD-1K5 succORDINAL1K1 (SegmCARD-1K5 n)"
               sorry
            then obtain k where 
              [ty]:"k be NatNAT-1M1" and kDef:"k = x"
               sorry
            have "x inHIDDENR3 SegmCARD-1K5 n or x inHIDDENR3 {TARSKIK1 n}"
              using A1 xboole_0_def_3 sorry
            then have "k <XXREAL-0R3 n or k =XBOOLE-0R4 n"
              using nat_1_th_44 tarski_def_1 sorry
            thus "x inHIDDENR3 {k where k be NatNAT-1M1 : k <=XXREAL-0R1 n }"
               sorry
          qed "sorry"
          thus "succORDINAL1K1 (SegmCARD-1K5 n) c=TARSKIR1 {k where k be NatNAT-1M1 : k <=XXREAL-0R1 n }"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 {k where k be NatNAT-1M1 : k <=XXREAL-0R1 n } implies x inHIDDENR3 succORDINAL1K1 (SegmCARD-1K5 n)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 {k where k be NatNAT-1M1 : k <=XXREAL-0R1 n }"
        then obtain k where
          [ty]:"k be NatNAT-1M1" and 
          A2: "x =HIDDENR1 k"and A3: "k <=XXREAL-0R1 n"
           sorry
        have "k <XXREAL-0R3 n or k =XBOOLE-0R4 n"
          using A3 xxreal_0_th_1 sorry
        then have "k inTARSKIR2 SegmCARD-1K5 n or k inTARSKIR2 {TARSKIK1 n}"
          using nat_1_th_44 tarski_def_1 sorry
        thus "x inHIDDENR3 succORDINAL1K1 (SegmCARD-1K5 n)"
          using A2 xboole_0_def_3 sorry
      qed "sorry"
      thus "{l where l be NatNAT-1M1 : l <=XXREAL-0R1 n } c=TARSKIR1 succORDINAL1K1 (SegmCARD-1K5 n)"
        using tarski_def_3 sorry
    qed
    thus "succORDINAL1K1 (SegmCARD-1K5 n) =XBOOLE-0R4 {l where l be NatNAT-1M1 : l <=XXREAL-0R1 n }"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_1_reduce_1:
  mlet "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"reduce InSUBSET-1K10(n,NATNUMBERSK1) to n"
proof
(*reducibility*)
  show "InSUBSET-1K10(n,NATNUMBERSK1) =HIDDENR1 n"
    using ordinal1_def_12 subset_1_def_8 sorry
qed "sorry"

theorem nat_1_sch_18:
  fixes Ff1 Pp1 
  assumes
[ty_func]: "\<And> x1. x1 be NatNAT-1M1 \<Longrightarrow> Ff1(x1) be NatNAT-1M1" and
   A1: " for k be NatNAT-1M1 holds Ff1(k +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 Ff1(k) or Pp1(k)"
  shows " ex k be NatNAT-1M1 st Pp1(k) & ( for n be NatNAT-1M1 holds Pp1(n) implies k <=XXREAL-0R1 n)"
  proof-
    have " ex tVar19 be NatNAT-1M1 st Pp1(tVar19) & ( for n be NatNAT-1M1 holds  not (Pp1(n) &  not tVar19 <=XXREAL-0R1 n))"
    proof-
      have "( for k be NatNAT-1M1 holds  not Pp1(k)) implies  False "
      proof(rule impI)
        let ?G = "\<lambda>Lamb1. InSUBSET-1K10(Ff1(Lamb1),NATNUMBERSK1)"
        obtain f where
          [ty]:"f be sequenceNAT-1M2-of NATNUMBERSK1" and 
          A2: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> k =XBOOLE-0R4 ?G(k)"
          using funct_2_sch_4 sorry
        have A3: "f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> (0NUMBERSK6) inTARSKIR2 rngFUNCT-1K2 f"
          using funct_2_th_4 sorry
        have "rngFUNCT-1K2 f c=TARSKIR1 NATNUMBERSK1"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 NATNUMBERSK1"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 f"
            then obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A4: "y inHIDDENR3 domRELAT-1K1 f & x =HIDDENR1 f .FUNCT-1K1 y"
              using funct_1_def_3 sorry
            obtain y1 where 
              [ty]:"y1 be ElementSUBSET-1M1-of NATNUMBERSK1" and y1Def:"y1 = y"
              using A4 funct_2_def_1 sorry
            have "x =HIDDENR1 ?G(y1)"
              using A4 A2 sorry
            thus "x inHIDDENR3 NATNUMBERSK1"
               sorry
          qed "sorry"
          thus "rngFUNCT-1K2 f c=TARSKIR1 NATNUMBERSK1"
            using tarski_def_3 sorry
        qed
        then obtain rf where 
          [ty]:"rf be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of NATNUMBERSK1" and rfDef:"rf = rngFUNCT-1K2 f"
          using A3 sorry
        let ?m = "min*NAT-1K3 rf"
        have "?m inTARSKIR2 rf"
          using nat_1_def_1 sorry
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A5: "x inHIDDENR3 domRELAT-1K1 f"and A6: "?m =XBOOLE-0R4 f .FUNCT-1K1 x"
          using funct_1_def_3 sorry
        have 
          [ty]:"x be ElementSUBSET-1M1-of NATNUMBERSK1"
          using A5 funct_2_def_1 sorry
        have "f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> x =XBOOLE-0R4 ?G(x) & f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (x +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 ?G(x +NAT-1K1 \<one>\<^sub>M)"
          using A2 sorry
        then have A7: "f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (x +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> x or Pp1(x)"
          using A1 sorry
        assume A8: " for k be NatNAT-1M1 holds  not Pp1(k)"
        have "f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (x +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rf"
          using funct_2_th_4 sorry
        thus " False "
          using nat_1_def_1 A8 A6 A7 sorry
      qed
      then have A9: " ex k be NatNAT-1M1 st Pp1(k)"
         sorry
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A10: "Pp1(k) & ( for n be NatNAT-1M1 holds Pp1(n) implies k <=XXREAL-0R1 n)"
        using nat_1_sch_5 A9 sorry
      show " ex tVar19 be NatNAT-1M1 st Pp1(tVar19) & ( for n be NatNAT-1M1 holds  not (Pp1(n) &  not tVar19 <=XXREAL-0R1 n))"
      proof(rule bexI[of _ "k"])
        show "Pp1(k) & ( for n be NatNAT-1M1 holds  not (Pp1(n) &  not k <=XXREAL-0R1 n))"
          using A10 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem nat_1_cl_18:
  mlet "k be OrdinalORDINAL1M3", "x be objectHIDDENM1"
"cluster k -->FUNCOP-1K7 x as-term-is Sequence-likeORDINAL1V5"
proof
(*coherence*)
  show "k -->FUNCOP-1K7 x be Sequence-likeORDINAL1V5"
    using funcop_1_th_13 sorry
qed "sorry"

mtheorem nat_1_th_55:
" for s be ManySortedSetPBOOLEM1-of NATNUMBERSK1 holds  for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds rngFUNCT-1K2 (s ^\\NAT-1K6 k) c=TARSKIR1 rngFUNCT-1K2 s"
  using nat_1_lm_1 sorry

(*\$CT 3*)
mtheorem nat_1_th_59:
" for X be finiteFINSET-1V1\<bar>setHIDDENM2 holds \<one>\<^sub>M <XXREAL-0R3 cardCARD-1K4 X implies ( ex x1 be setHIDDENM2 st  ex x2 be setHIDDENM2 st (x1 inTARSKIR2 X & x2 inTARSKIR2 X) & x1 <>HIDDENR2 x2)"
proof-
  have " for X be finiteFINSET-1V1\<bar>setHIDDENM2 holds \<one>\<^sub>M <XXREAL-0R3 cardCARD-1K4 X implies  not ( for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  not ((x1 inTARSKIR2 X & x2 inTARSKIR2 X) &  not x1 <>HIDDENR2 x2))"
  proof(rule ballI,rule impI)
    fix X assume [ty]: "X be finiteFINSET-1V1\<bar>setHIDDENM2"
    let ?x1 = "the ElementSUBSET-1M1-of X"
    assume A1: "\<one>\<^sub>M <XXREAL-0R3 cardCARD-1K4 X"
    then have "X <>HIDDENR2 {}XBOOLE-0K1"
       sorry
    then have A2: "?x1 inTARSKIR2 X"
       sorry
    have "( for x2 be setHIDDENM2 holds x2 inTARSKIR2 X implies x2 =XBOOLE-0R4 the ElementSUBSET-1M1-of X) implies  False "
    proof(rule impI)
      assume A3: " for x2 be setHIDDENM2 holds x2 inTARSKIR2 X implies x2 =XBOOLE-0R4 ?x1"
      have " for x be objectHIDDENM1 holds (x inHIDDENR3 X implies x inHIDDENR3 {TARSKIK1 the ElementSUBSET-1M1-of X }) & (x inHIDDENR3 {TARSKIK1 the ElementSUBSET-1M1-of X } implies x inHIDDENR3 X)"
      proof(rule ballI,rule conjMI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        show "x inHIDDENR3 X implies x inHIDDENR3 {TARSKIK1 the ElementSUBSET-1M1-of X }"
        proof(rule impI)
          assume "x inHIDDENR3 X"
          then have "x =HIDDENR1 ?x1"
            using A3 sorry
          thus "x inHIDDENR3 {TARSKIK1 the ElementSUBSET-1M1-of X }"
            using tarski_def_1 sorry
        qed
        assume "x inHIDDENR3 {TARSKIK1 ?x1}"
        thus "x inHIDDENR3 X"
          using A2 tarski_def_1 sorry
      qed "sorry"
      then have "X =XBOOLE-0R4 {TARSKIK1 ?x1}"
        using tarski_th_2 sorry
      thus " False "
        using A1 card_1_th_30 sorry
    qed
    thus " not ( for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  not ((x1 inTARSKIR2 X & x2 inTARSKIR2 X) &  not x1 <>HIDDENR2 x2))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_1_th_60:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies ( ex VarFor3 be setHIDDENM2 st (0NUMBERSK6 <=XXREAL-0R1 VarFor3 & VarFor3 <=XXREAL-0R1 n) & k =XBOOLE-0R4 VarFor3)"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  not (k <=XXREAL-0R1 n & ( for VarFor1 be setHIDDENM2 holds 0NUMBERSK6 <=XXREAL-0R1 VarFor1 & VarFor1 <=XXREAL-0R1 n implies k =XBOOLE-0R4 VarFor1))"
  proof(rule ballI,rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    show " not (k <=XXREAL-0R1 n & ( for VarFor1 be setHIDDENM2 holds 0NUMBERSK6 <=XXREAL-0R1 VarFor1 & VarFor1 <=XXREAL-0R1 n implies k =XBOOLE-0R4 VarFor1))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_1_th_61:
" for n be NatNAT-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M) implies ( ex VarFor3 be setHIDDENM2 st (0NUMBERSK6 <=XXREAL-0R1 VarFor3 & VarFor3 <=XXREAL-0R1 n) & x =HIDDENR1 VarFor3)"
proof-
  have " for n be NatNAT-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M) implies  not ( for VarFor1 be setHIDDENM2 holds 0NUMBERSK6 <=XXREAL-0R1 VarFor1 & VarFor1 <=XXREAL-0R1 n implies x =HIDDENR1 VarFor1)"
  proof(rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "x inHIDDENR3 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
    then obtain k where 
      [ty]:"k be NatNAT-1M1" and kDef:"k = x"
       sorry
    have "k <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
      using A1 nat_1_th_44 sorry
    then have "k <=XXREAL-0R1 n"
      using nat_1_th_13 sorry
    thus " not ( for VarFor1 be setHIDDENM2 holds 0NUMBERSK6 <=XXREAL-0R1 VarFor1 & VarFor1 <=XXREAL-0R1 n implies x =HIDDENR1 VarFor1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_1_th_62:
" for k be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for i be NatNAT-1M1 holds m <=XXREAL-0R1 i & i <=XXREAL-0R1 m +XCMPLX-0K2 k implies ( ex VarFor4 be setHIDDENM2 st (m +NAT-1K1 0NUMBERSK6 <=XXREAL-0R1 VarFor4 & VarFor4 <=XXREAL-0R1 m +XCMPLX-0K2 k) & i =XBOOLE-0R4 VarFor4)"
proof-
  have " for k be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for i be NatNAT-1M1 holds m <=XXREAL-0R1 i & i <=XXREAL-0R1 m +XCMPLX-0K2 k implies ( ex j be NatNAT-1M1 st (m +NAT-1K1 0NUMBERSK6 <=XXREAL-0R1 j & j <=XXREAL-0R1 m +XCMPLX-0K2 k) & i =XBOOLE-0R4 j)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix i assume [ty]: "i be NatNAT-1M1"
    assume A1: "m <=XXREAL-0R1 i"
      and A2: "i <=XXREAL-0R1 m +XCMPLX-0K2 k"
    obtain j where 
      [ty]:"j be NatNAT-1M1" and jDef:"j = i"
       sorry
    show " ex j be NatNAT-1M1 st (m +NAT-1K1 0NUMBERSK6 <=XXREAL-0R1 j & j <=XXREAL-0R1 m +XCMPLX-0K2 k) & i =XBOOLE-0R4 j"
    proof(rule bexI[of _ "j"])
      show "(m +NAT-1K1 0NUMBERSK6 <=XXREAL-0R1 j & j <=XXREAL-0R1 m +XCMPLX-0K2 k) & i =XBOOLE-0R4 j"
        using A1 A2 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax NAT_1K8 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ .NAT-1K8\<^bsub>'( _ ')\<^esub>  _ " [200,0,200]200)
translations "s .NAT-1K8\<^bsub>(D)\<^esub> n" \<rightharpoonup> "s .FUNCT-1K1 n"

mtheorem nat_1_add_6:
  mlet "D be setHIDDENM2", "s be sequenceNAT-1M2-of D", "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster s .FUNCT-1K1 n as-term-is ElementSUBSET-1M1-of D"
proof
(*coherence*)
  show "s .FUNCT-1K1 n be ElementSUBSET-1M1-of D"
  proof-
    have 
      [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> n be ElementSUBSET-1M1-of D"
       sorry
    thus "s .FUNCT-1K1 n be ElementSUBSET-1M1-of D"
       sorry
  qed
qed "sorry"

mtheorem nat_1_cl_19:
"cluster zeroORDINAL1V8 also-is  non positiveXXREAL-0V2 for naturalORDINAL1V7\<bar>NumberORDINAL1M1"
proof
(*coherence*)
  show " for it be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds it be zeroORDINAL1V8 implies it be  non positiveXXREAL-0V2"
     sorry
qed "sorry"

mtheorem nat_1_cl_20:
  mlet "A be  non zeroORDINAL1V8\<bar>objectHIDDENM1"
"cluster {TARSKIK1 A} as-term-is with-non-empty-elementsSETFAM-1V1"
proof
(*coherence*)
  show "{TARSKIK1 A} be with-non-empty-elementsSETFAM-1V1"
    using tarski_def_1 sorry
qed "sorry"

mtheorem nat_1_cl_21:
  mlet "A be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "B be  non zeroORDINAL1V8\<bar>objectHIDDENM1"
"cluster {TARSKIK2 A,B } as-term-is with-non-empty-elementsSETFAM-1V1"
proof
(*coherence*)
  show "{TARSKIK2 A,B } be with-non-empty-elementsSETFAM-1V1"
    using tarski_def_2 sorry
qed "sorry"

mtheorem nat_1_cl_22:
  mlet "A be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "B be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "C be  non zeroORDINAL1V8\<bar>objectHIDDENM1"
"cluster {ENUMSET1K1 A,B,C } as-term-is with-non-empty-elementsSETFAM-1V1"
proof
(*coherence*)
  show "{ENUMSET1K1 A,B,C } be with-non-empty-elementsSETFAM-1V1"
    using enumset1_def_1 sorry
qed "sorry"

mtheorem nat_1_cl_23:
  mlet "A be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "B be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "C be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "D be  non zeroORDINAL1V8\<bar>objectHIDDENM1"
"cluster {ENUMSET1K2 A,B,C,D } as-term-is with-non-empty-elementsSETFAM-1V1"
proof
(*coherence*)
  show "{ENUMSET1K2 A,B,C,D } be with-non-empty-elementsSETFAM-1V1"
    using enumset1_def_2 sorry
qed "sorry"

mtheorem nat_1_cl_24:
  mlet "A be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "B be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "C be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "D be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "E be  non zeroORDINAL1V8\<bar>objectHIDDENM1"
"cluster {ENUMSET1K3 A,B,C,D,E } as-term-is with-non-empty-elementsSETFAM-1V1"
proof
(*coherence*)
  show "{ENUMSET1K3 A,B,C,D,E } be with-non-empty-elementsSETFAM-1V1"
    using enumset1_def_3 sorry
qed "sorry"

mtheorem nat_1_cl_25:
  mlet "A be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "B be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "C be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "D be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "E be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "F be  non zeroORDINAL1V8\<bar>objectHIDDENM1"
"cluster {ENUMSET1K4 A,B,C,D,E,F } as-term-is with-non-empty-elementsSETFAM-1V1"
proof
(*coherence*)
  show "{ENUMSET1K4 A,B,C,D,E,F } be with-non-empty-elementsSETFAM-1V1"
    using enumset1_def_4 sorry
qed "sorry"

mtheorem nat_1_cl_26:
  mlet "A be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "B be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "C be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "D be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "E be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "F be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "G be  non zeroORDINAL1V8\<bar>objectHIDDENM1"
"cluster {ENUMSET1K5 A,B,C,D,E,F,G } as-term-is with-non-empty-elementsSETFAM-1V1"
proof
(*coherence*)
  show "{ENUMSET1K5 A,B,C,D,E,F,G } be with-non-empty-elementsSETFAM-1V1"
    using enumset1_def_5 sorry
qed "sorry"

mtheorem nat_1_cl_27:
  mlet "A be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "B be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "C be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "D be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "E be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "F be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "G be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "H be  non zeroORDINAL1V8\<bar>objectHIDDENM1"
"cluster {ENUMSET1K6 A,B,C,D,E,F,G,H } as-term-is with-non-empty-elementsSETFAM-1V1"
proof
(*coherence*)
  show "{ENUMSET1K6 A,B,C,D,E,F,G,H } be with-non-empty-elementsSETFAM-1V1"
    using enumset1_def_6 sorry
qed "sorry"

mtheorem nat_1_cl_28:
  mlet "A be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "B be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "C be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "D be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "E be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "F be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "G be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "H be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "I be  non zeroORDINAL1V8\<bar>objectHIDDENM1"
"cluster {ENUMSET1K7 A,B,C,D,E,F,G,H,I } as-term-is with-non-empty-elementsSETFAM-1V1"
proof
(*coherence*)
  show "{ENUMSET1K7 A,B,C,D,E,F,G,H,I } be with-non-empty-elementsSETFAM-1V1"
    using enumset1_def_7 sorry
qed "sorry"

mtheorem nat_1_cl_29:
  mlet "A be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "B be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "C be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "D be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "E be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "F be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "G be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "H be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "I be  non zeroORDINAL1V8\<bar>objectHIDDENM1", "J be  non zeroORDINAL1V8\<bar>objectHIDDENM1"
"cluster {ENUMSET1K8 A,B,C,D,E,F,G,H,I,J } as-term-is with-non-empty-elementsSETFAM-1V1"
proof
(*coherence*)
  show "{ENUMSET1K8 A,B,C,D,E,F,G,H,I,J } be with-non-empty-elementsSETFAM-1V1"
    using enumset1_def_8 sorry
qed "sorry"

mtheorem nat_1_cl_30:
"cluster emptyXBOOLE-0V1 also-is zeroORDINAL1V8 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be emptyXBOOLE-0V1 implies it be zeroORDINAL1V8"
     sorry
qed "sorry"

mtheorem nat_1_cl_31:
"cluster  non zeroORDINAL1V8 also-is  non emptyXBOOLE-0V1 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be  non zeroORDINAL1V8 implies it be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

syntax NAT_1K9 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ .NAT-1K9\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [200,0,0,0]200)
translations "B .NAT-1K9\<^bsub>(G)\<^esub>(g,i)" \<rightharpoonup> "B .BINOP-1K1(g,i)"

mtheorem nat_1_add_7:
  mlet "G be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "B be FunctionFUNCT-2M1-of([:ZFMISC-1K2 G,NATNUMBERSK1 :],G)", "g be ElementSUBSET-1M1-of G", "i be NatNAT-1M1"
"cluster B .BINOP-1K1(g,i) as-term-is ElementSUBSET-1M1-of G"
proof
(*coherence*)
  show "B .BINOP-1K1(g,i) be ElementSUBSET-1M1-of G"
  proof-
    have 
      [ty]:"i be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    have "B .BINOP-1K2\<^bsub>(G,NATNUMBERSK1,G)\<^esub>(g,i) be ElementSUBSET-1M1-of G"
       sorry
    thus "B .BINOP-1K1(g,i) be ElementSUBSET-1M1-of G"
       sorry
  qed
qed "sorry"

syntax NAT_1K10 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ .NAT-1K10\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [200,0,0,0]200)
translations "B .NAT-1K10\<^bsub>(G)\<^esub>(i,g)" \<rightharpoonup> "B .BINOP-1K1(i,g)"

mtheorem nat_1_add_8:
  mlet "G be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "B be FunctionFUNCT-2M1-of([:ZFMISC-1K2 NATNUMBERSK1,G :],G)", "i be NatNAT-1M1", "g be ElementSUBSET-1M1-of G"
"cluster B .BINOP-1K1(i,g) as-term-is ElementSUBSET-1M1-of G"
proof
(*coherence*)
  show "B .BINOP-1K1(i,g) be ElementSUBSET-1M1-of G"
  proof-
    have 
      [ty]:"i be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    have "B .BINOP-1K2\<^bsub>(NATNUMBERSK1,G,G)\<^esub>(i,g) be ElementSUBSET-1M1-of G"
       sorry
    thus "B .BINOP-1K1(i,g) be ElementSUBSET-1M1-of G"
       sorry
  qed
qed "sorry"

theorem nat_1_sch_19:
  fixes Xf0 Zf0 Pp3 
  assumes
[ty]: "Xf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Zf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
   A1: " for x be ElementSUBSET-1M1-of Xf0 holds  for y be NatNAT-1M1 holds  ex z be ElementSUBSET-1M1-of Zf0 st Pp3(x,y,z)"
  shows " ex f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 Xf0,NATNUMBERSK1 :],Zf0) st  for x be ElementSUBSET-1M1-of Xf0 holds  for y be NatNAT-1M1 holds Pp3(x,y,f .BINOP-1K1(x,y))"
  proof-
    have " ex tVar21 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 Xf0,NATNUMBERSK1 :],Zf0) st  for x be ElementSUBSET-1M1-of Xf0 holds  for y be NatNAT-1M1 holds Pp3(x,y,tVar21 .BINOP-1K1(x,y))"
    proof-
      have A2: " for x be ElementSUBSET-1M1-of Xf0 holds  for y be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex z be ElementSUBSET-1M1-of Zf0 st Pp3(x,y,z)"
        using A1 sorry
      obtain f where
        [ty]:"f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 Xf0,NATNUMBERSK1 :],Zf0)" and 
        A3: " for x be ElementSUBSET-1M1-of Xf0 holds  for y be ElementSUBSET-1M1-of NATNUMBERSK1 holds Pp3(x,y,f .BINOP-1K2\<^bsub>(Xf0,NATNUMBERSK1,Zf0)\<^esub>(x,y))"
        using binop_1_sch_3 A2 sorry
      show " ex tVar21 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 Xf0,NATNUMBERSK1 :],Zf0) st  for x be ElementSUBSET-1M1-of Xf0 holds  for y be NatNAT-1M1 holds Pp3(x,y,tVar21 .BINOP-1K1(x,y))"
      proof(rule bexI[of _ "f"],rule ballI,rule ballI)
        fix x assume [ty]: "x be ElementSUBSET-1M1-of Xf0"
        fix y assume [ty]: "y be NatNAT-1M1"
        have "y inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        thus "Pp3(x,y,f .BINOP-1K1(x,y))"
          using A3 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem nat_1_th_63:
" for n be NatNAT-1M1 holds SegmCARD-1K5 n c=ORDINAL1R1 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
  using nat_1_th_11 nat_1_th_39 sorry

end
