theory funct_5
  imports funct_3 card_1
begin
(*begin*)
reserve X, Y, Z, X1, X2, Y1, Y2 for "setHIDDENM2"
reserve x, y, z, t, x1, x2 for "objectHIDDENM1"
reserve f, g, h, f1, f2, g1, g2 for "FunctionFUNCT-1M1"
theorem funct_5_sch_1:
  fixes FSf0 ff1 
  assumes
[ty]: "FSf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> ff1(x1) be objectHIDDENM1"
  shows " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 FSf0 & ( for g be FunctionFUNCT-1M1 holds g inTARSKIR2 FSf0 implies f .FUNCT-1K1 g =HIDDENR1 ff1(g))"
  proof-
    have " ex tVar1 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar1 =XBOOLE-0R4 FSf0 & ( for g be FunctionFUNCT-1M1 holds  not (g inTARSKIR2 FSf0 &  not tVar1 .FUNCT-1K1 g =HIDDENR1 ff1(g)))"
    proof-
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A1: "domRELAT-1K1 f =XBOOLE-0R4 FSf0 & ( for x be objectHIDDENM1 holds x inHIDDENR3 FSf0 implies f .FUNCT-1K1 x =HIDDENR1 ff1(x))"
        using funct_1_sch_3 sorry
      show " ex tVar1 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar1 =XBOOLE-0R4 FSf0 & ( for g be FunctionFUNCT-1M1 holds  not (g inTARSKIR2 FSf0 &  not tVar1 .FUNCT-1K1 g =HIDDENR1 ff1(g)))"
      proof(rule bexI[of _ "f"])
        show "domRELAT-1K1 f =XBOOLE-0R4 FSf0 & ( for g be FunctionFUNCT-1M1 holds  not (g inTARSKIR2 FSf0 &  not f .FUNCT-1K1 g =HIDDENR1 ff1(g)))"
          using A1 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem funct_5_th_1:
"~FUNCT-4K2 ({}XBOOLE-0K1) =FUNCT-1R1 {}XBOOLE-0K1"
proof-
  have "[:ZFMISC-1K2 {}XBOOLE-0K1,{}XBOOLE-0K1 :] =RELAT-1R1 {}XBOOLE-0K1 & domRELAT-1K1 ({}XBOOLE-0K1) =FUNCT-1R1 {}XBOOLE-0K1"
    using zfmisc_1_th_90 sorry
  then have "domRELAT-1K1 (~FUNCT-4K2 ({}XBOOLE-0K1)) =XBOOLE-0R4 {}XBOOLE-0K1"
    using funct_4_th_46 sorry
  thus "~FUNCT-4K2 ({}XBOOLE-0K1) =FUNCT-1R1 {}XBOOLE-0K1"
     sorry
qed

(*\$CT 6*)
mtheorem funct_5_th_8:
"proj1XTUPLE-0K12 ({}XBOOLE-0K1) =FUNCT-1R1 {}XBOOLE-0K1 & proj2XTUPLE-0K13 ({}XBOOLE-0K1) =FUNCT-1R1 {}XBOOLE-0K1"
   sorry

mtheorem funct_5_th_9:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (Y <>HIDDENR2 {}XBOOLE-0K1 or [:ZFMISC-1K2 X,Y :] <>HIDDENR2 {}XBOOLE-0K1) or [:ZFMISC-1K2 Y,X :] <>HIDDENR2 {}XBOOLE-0K1 implies proj1XTUPLE-0K12 ([:ZFMISC-1K2 X,Y :]) =XBOOLE-0R4 X & proj2XTUPLE-0K13 ([:ZFMISC-1K2 Y,X :]) =XBOOLE-0R4 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (Y <>HIDDENR2 {}XBOOLE-0K1 or [:ZFMISC-1K2 X,Y :] <>HIDDENR2 {}XBOOLE-0K1) or [:ZFMISC-1K2 Y,X :] <>HIDDENR2 {}XBOOLE-0K1 implies proj1XTUPLE-0K12 ([:ZFMISC-1K2 X,Y :]) =XBOOLE-0R4 X & proj2XTUPLE-0K13 ([:ZFMISC-1K2 Y,X :]) =XBOOLE-0R4 X"
  proof(rule ballI,rule ballI,rule impI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    let ?y = "the ElementSUBSET-1M1-of Y"
    assume "(Y <>HIDDENR2 {}XBOOLE-0K1 or [:ZFMISC-1K2 X,Y :] <>HIDDENR2 {}XBOOLE-0K1) or [:ZFMISC-1K2 Y,X :] <>HIDDENR2 {}XBOOLE-0K1"
    then have A1: "Y <>HIDDENR2 {}XBOOLE-0K1"
      using zfmisc_1_th_90 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X iff ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :])"
    proof(rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have "x inHIDDENR3 X implies [TARSKIK4 x,?y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
        using A1 zfmisc_1_th_87 sorry
      thus "x inHIDDENR3 X iff ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :])"
        using zfmisc_1_th_87 sorry
    qed "sorry"
    thus "proj1XTUPLE-0K12 ([:ZFMISC-1K2 X,Y :]) =XBOOLE-0R4 X"
      using xtuple_0_def_12 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X iff ( ex y be objectHIDDENM1 st [TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Y,X :])"
    proof(rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have "x inHIDDENR3 X implies [TARSKIK4 ?y,x ] inHIDDENR3 [:ZFMISC-1K2 Y,X :]"
        using A1 zfmisc_1_th_87 sorry
      thus "x inHIDDENR3 X iff ( ex y be objectHIDDENM1 st [TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Y,X :])"
        using zfmisc_1_th_87 sorry
    qed "sorry"
    thus "proj2XTUPLE-0K13 ([:ZFMISC-1K2 Y,X :]) =XBOOLE-0R4 X"
      using xtuple_0_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_10:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj1XTUPLE-0K12 ([:ZFMISC-1K2 X,Y :]) c=TARSKIR1 X & proj2XTUPLE-0K13 ([:ZFMISC-1K2 X,Y :]) c=TARSKIR1 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj1XTUPLE-0K12 ([:ZFMISC-1K2 X,Y :]) c=TARSKIR1 X & proj2XTUPLE-0K13 ([:ZFMISC-1K2 X,Y :]) c=TARSKIR1 Y"
  proof(rule ballI,rule ballI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    show "proj1XTUPLE-0K12 ([:ZFMISC-1K2 X,Y :]) c=TARSKIR1 X"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 proj1XTUPLE-0K12 ([:ZFMISC-1K2 X,Y :]) implies x inHIDDENR3 X"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 proj1XTUPLE-0K12 ([:ZFMISC-1K2 X,Y :])"
        then have " ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
          using xtuple_0_def_12 sorry
        thus "x inHIDDENR3 X"
          using zfmisc_1_th_87 sorry
      qed "sorry"
      thus "proj1XTUPLE-0K12 ([:ZFMISC-1K2 X,Y :]) c=TARSKIR1 X"
        using tarski_def_3 sorry
    qed
    have " for y be objectHIDDENM1 holds y inHIDDENR3 proj2XTUPLE-0K13 ([:ZFMISC-1K2 X,Y :]) implies y inHIDDENR3 Y"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 proj2XTUPLE-0K13 ([:ZFMISC-1K2 X,Y :])"
      then have " ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
        using xtuple_0_def_13 sorry
      thus "y inHIDDENR3 Y"
        using zfmisc_1_th_87 sorry
    qed "sorry"
    thus "proj2XTUPLE-0K13 ([:ZFMISC-1K2 X,Y :]) c=TARSKIR1 Y"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_11:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds Z c=TARSKIR1 [:ZFMISC-1K2 X,Y :] implies proj1XTUPLE-0K12 Z c=TARSKIR1 X & proj2XTUPLE-0K13 Z c=TARSKIR1 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds Z c=TARSKIR1 [:ZFMISC-1K2 X,Y :] implies proj1XTUPLE-0K12 Z c=TARSKIR1 X & proj2XTUPLE-0K13 Z c=TARSKIR1 Y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume "Z c=TARSKIR1 [:ZFMISC-1K2 X,Y :]"
    then have A1: "proj1XTUPLE-0K12 Z c=TARSKIR1 proj1XTUPLE-0K12 ([:ZFMISC-1K2 X,Y :]) & proj2XTUPLE-0K13 Z c=TARSKIR1 proj2XTUPLE-0K13 ([:ZFMISC-1K2 X,Y :])"
      using xtuple_0_th_8 xtuple_0_th_9 sorry
    have "proj1XTUPLE-0K12 ([:ZFMISC-1K2 X,Y :]) c=TARSKIR1 X & proj2XTUPLE-0K13 ([:ZFMISC-1K2 X,Y :]) c=TARSKIR1 Y"
      using funct_5_th_10 sorry
    thus "proj1XTUPLE-0K12 Z c=TARSKIR1 X & proj2XTUPLE-0K13 Z c=TARSKIR1 Y"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_12:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds proj1XTUPLE-0K12 {TARSKIK1 [TARSKIK4 x,y ] } =XBOOLE-0R4 {TARSKIK1 x} & proj2XTUPLE-0K13 {TARSKIK1 [TARSKIK4 x,y ] } =XBOOLE-0R4 {TARSKIK1 y}"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds proj1XTUPLE-0K12 {TARSKIK1 [TARSKIK4 x,y ] } =XBOOLE-0R4 {TARSKIK1 x} & proj2XTUPLE-0K13 {TARSKIK1 [TARSKIK4 x,y ] } =XBOOLE-0R4 {TARSKIK1 y}"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    have "proj1XTUPLE-0K12 {TARSKIK1 [TARSKIK4 x,y ] } c=TARSKIR1 {TARSKIK1 x} & ({TARSKIK1 x} c=TARSKIR1 proj1XTUPLE-0K12 {TARSKIK1 [TARSKIK4 x,y ] } & proj2XTUPLE-0K13 {TARSKIK1 [TARSKIK4 x,y ] } =XBOOLE-0R4 {TARSKIK1 y})"
    proof(rule conjMI,rule conjMI)
      show "proj1XTUPLE-0K12 {TARSKIK1 [TARSKIK4 x,y ] } c=TARSKIR1 {TARSKIK1 x}"
      proof-
        have " for z be objectHIDDENM1 holds z inHIDDENR3 proj1XTUPLE-0K12 {TARSKIK1 [TARSKIK4 x,y ] } implies z inHIDDENR3 {TARSKIK1 x}"
        proof(rule ballI,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          assume "z inHIDDENR3 proj1XTUPLE-0K12 {TARSKIK1 [TARSKIK4 x,y ] }"
          then obtain t where
            [ty]:"t be objectHIDDENM1" and 
            A1: "[TARSKIK4 z,t ] inHIDDENR3 {TARSKIK1 [TARSKIK4 x,y ] }"
            using xtuple_0_def_12 sorry
          have "[TARSKIK4 z,t ] =HIDDENR1 [TARSKIK4 x,y ]"
            using A1 tarski_def_1 sorry
          then have "z =HIDDENR1 x"
            using xtuple_0_th_1 sorry
          thus "z inHIDDENR3 {TARSKIK1 x}"
            using tarski_def_1 sorry
        qed "sorry"
        thus "proj1XTUPLE-0K12 {TARSKIK1 [TARSKIK4 x,y ] } c=TARSKIR1 {TARSKIK1 x}"
          using tarski_def_3 sorry
      qed
      show "{TARSKIK1 x} c=TARSKIR1 proj1XTUPLE-0K12 {TARSKIK1 [TARSKIK4 x,y ] }"
      proof-
        have " for z be objectHIDDENM1 holds z inHIDDENR3 {TARSKIK1 x} implies z inHIDDENR3 proj1XTUPLE-0K12 {TARSKIK1 [TARSKIK4 x,y ] }"
        proof(rule ballI,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          assume "z inHIDDENR3 {TARSKIK1 x}"
          then have "z =HIDDENR1 x"
            using tarski_def_1 sorry
          then have "[TARSKIK4 z,y ] inHIDDENR3 {TARSKIK1 [TARSKIK4 x,y ] }"
            using tarski_def_1 sorry
          thus "z inHIDDENR3 proj1XTUPLE-0K12 {TARSKIK1 [TARSKIK4 x,y ] }"
            using xtuple_0_def_12 sorry
        qed "sorry"
        thus "{TARSKIK1 x} c=TARSKIR1 proj1XTUPLE-0K12 {TARSKIK1 [TARSKIK4 x,y ] }"
          using tarski_def_3 sorry
      qed
      have "proj2XTUPLE-0K13 {TARSKIK1 [TARSKIK4 x,y ] } c=TARSKIR1 {TARSKIK1 y} & {TARSKIK1 y} c=TARSKIR1 proj2XTUPLE-0K13 {TARSKIK1 [TARSKIK4 x,y ] }"
      proof(rule conjMI)
        show "proj2XTUPLE-0K13 {TARSKIK1 [TARSKIK4 x,y ] } c=TARSKIR1 {TARSKIK1 y}"
        proof-
          have " for z be objectHIDDENM1 holds z inHIDDENR3 proj2XTUPLE-0K13 {TARSKIK1 [TARSKIK4 x,y ] } implies z inHIDDENR3 {TARSKIK1 y}"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be objectHIDDENM1"
            assume "z inHIDDENR3 proj2XTUPLE-0K13 {TARSKIK1 [TARSKIK4 x,y ] }"
            then obtain t where
              [ty]:"t be objectHIDDENM1" and 
              A2: "[TARSKIK4 t,z ] inHIDDENR3 {TARSKIK1 [TARSKIK4 x,y ] }"
              using xtuple_0_def_13 sorry
            have "[TARSKIK4 t,z ] =HIDDENR1 [TARSKIK4 x,y ]"
              using A2 tarski_def_1 sorry
            then have "z =HIDDENR1 y"
              using xtuple_0_th_1 sorry
            thus "z inHIDDENR3 {TARSKIK1 y}"
              using tarski_def_1 sorry
          qed "sorry"
          thus "proj2XTUPLE-0K13 {TARSKIK1 [TARSKIK4 x,y ] } c=TARSKIR1 {TARSKIK1 y}"
            using tarski_def_3 sorry
        qed
        show "{TARSKIK1 y} c=TARSKIR1 proj2XTUPLE-0K13 {TARSKIK1 [TARSKIK4 x,y ] }"
        proof-
          have " for z be objectHIDDENM1 holds z inHIDDENR3 {TARSKIK1 y} implies z inHIDDENR3 proj2XTUPLE-0K13 {TARSKIK1 [TARSKIK4 x,y ] }"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be objectHIDDENM1"
            assume "z inHIDDENR3 {TARSKIK1 y}"
            then have "z =HIDDENR1 y"
              using tarski_def_1 sorry
            then have "[TARSKIK4 x,z ] inHIDDENR3 {TARSKIK1 [TARSKIK4 x,y ] }"
              using tarski_def_1 sorry
            thus "z inHIDDENR3 proj2XTUPLE-0K13 {TARSKIK1 [TARSKIK4 x,y ] }"
              using xtuple_0_def_13 sorry
          qed "sorry"
          thus "{TARSKIK1 y} c=TARSKIR1 proj2XTUPLE-0K13 {TARSKIK1 [TARSKIK4 x,y ] }"
            using tarski_def_3 sorry
        qed
      qed
      thus "proj2XTUPLE-0K13 {TARSKIK1 [TARSKIK4 x,y ] } =XBOOLE-0R4 {TARSKIK1 y}"
        using xboole_0_def_10 sorry
    qed
    thus "proj1XTUPLE-0K12 {TARSKIK1 [TARSKIK4 x,y ] } =XBOOLE-0R4 {TARSKIK1 x} & proj2XTUPLE-0K13 {TARSKIK1 [TARSKIK4 x,y ] } =XBOOLE-0R4 {TARSKIK1 y}"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_13:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  for t be objectHIDDENM1 holds proj1XTUPLE-0K12 {TARSKIK2 [TARSKIK4 x,y ],[TARSKIK4 z,t ] } =XBOOLE-0R4 {TARSKIK2 x,z } & proj2XTUPLE-0K13 {TARSKIK2 [TARSKIK4 x,y ],[TARSKIK4 z,t ] } =XBOOLE-0R4 {TARSKIK2 y,t }"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  for t be objectHIDDENM1 holds proj1XTUPLE-0K12 {TARSKIK2 [TARSKIK4 x,y ],[TARSKIK4 z,t ] } =XBOOLE-0R4 {TARSKIK2 x,z } & proj2XTUPLE-0K13 {TARSKIK2 [TARSKIK4 x,y ],[TARSKIK4 z,t ] } =XBOOLE-0R4 {TARSKIK2 y,t }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix z assume [ty]: "z be objectHIDDENM1"
    fix t assume [ty]: "t be objectHIDDENM1"
    have A1: "proj2XTUPLE-0K13 {TARSKIK1 [TARSKIK4 x,y ] } =XBOOLE-0R4 {TARSKIK1 y} & proj2XTUPLE-0K13 {TARSKIK1 [TARSKIK4 z,t ] } =XBOOLE-0R4 {TARSKIK1 t}"
      using funct_5_th_12 sorry
    have "{TARSKIK2 [TARSKIK4 x,y ],[TARSKIK4 z,t ] } =RELAT-1R1 {TARSKIK1 [TARSKIK4 x,y ] } \\/XBOOLE-0K2 {TARSKIK1 [TARSKIK4 z,t ] }"
      using enumset1_th_1 sorry
    then have A2: "proj1XTUPLE-0K12 {TARSKIK2 [TARSKIK4 x,y ],[TARSKIK4 z,t ] } =XBOOLE-0R4 proj1XTUPLE-0K12 {TARSKIK1 [TARSKIK4 x,y ] } \\/XBOOLE-0K2 proj1XTUPLE-0K12 {TARSKIK1 [TARSKIK4 z,t ] } & proj2XTUPLE-0K13 {TARSKIK2 [TARSKIK4 x,y ],[TARSKIK4 z,t ] } =XBOOLE-0R4 proj2XTUPLE-0K13 {TARSKIK1 [TARSKIK4 x,y ] } \\/XBOOLE-0K2 proj2XTUPLE-0K13 {TARSKIK1 [TARSKIK4 z,t ] }"
      using xtuple_0_th_23 xtuple_0_th_27 sorry
    have "proj1XTUPLE-0K12 {TARSKIK1 [TARSKIK4 x,y ] } =XBOOLE-0R4 {TARSKIK1 x} & proj1XTUPLE-0K12 {TARSKIK1 [TARSKIK4 z,t ] } =XBOOLE-0R4 {TARSKIK1 z}"
      using funct_5_th_12 sorry
    thus "proj1XTUPLE-0K12 {TARSKIK2 [TARSKIK4 x,y ],[TARSKIK4 z,t ] } =XBOOLE-0R4 {TARSKIK2 x,z } & proj2XTUPLE-0K13 {TARSKIK2 [TARSKIK4 x,y ],[TARSKIK4 z,t ] } =XBOOLE-0R4 {TARSKIK2 y,t }"
      using A2 A1 enumset1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_14:
" for X be setHIDDENM2 holds  not ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 X) implies proj1XTUPLE-0K12 X =XBOOLE-0R4 {}XBOOLE-0K1 & proj2XTUPLE-0K13 X =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for X be setHIDDENM2 holds  not ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 X) implies (proj1XTUPLE-0K12 X <>HIDDENR2 {}XBOOLE-0K1 implies  False ) & (proj2XTUPLE-0K13 X <>HIDDENR2 {}XBOOLE-0K1 implies  not  True )"
  proof(rule ballI,rule impI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    let ?x = "the ElementSUBSET-1M1-of proj2XTUPLE-0K13 X"
    assume A1: " not ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 X)"
    show "proj1XTUPLE-0K12 X <>HIDDENR2 {}XBOOLE-0K1 implies  False "
    proof(rule impI)
      let ?x = "the ElementSUBSET-1M1-of proj1XTUPLE-0K12 X"
      assume "proj1XTUPLE-0K12 X <>HIDDENR2 {}XBOOLE-0K1"
      then have " ex y be objectHIDDENM1 st [TARSKIK4 ?x,y ] inHIDDENR3 X"
        using xtuple_0_def_12 sorry
      thus " False "
        using A1 sorry
    qed
    assume "proj2XTUPLE-0K13 X <>HIDDENR2 {}XBOOLE-0K1"
    then have " ex y be objectHIDDENM1 st [TARSKIK4 y,?x ] inHIDDENR3 X"
      using xtuple_0_def_13 sorry
    thus " not  True "
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_15:
" for X be setHIDDENM2 holds proj1XTUPLE-0K12 X =XBOOLE-0R4 {}XBOOLE-0K1 or proj2XTUPLE-0K13 X =XBOOLE-0R4 {}XBOOLE-0K1 implies  not ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 X)"
  using xtuple_0_def_12 xtuple_0_def_13 sorry

mtheorem funct_5_th_16:
" for X be setHIDDENM2 holds proj1XTUPLE-0K12 X =XBOOLE-0R4 {}XBOOLE-0K1 iff proj2XTUPLE-0K13 X =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for X be setHIDDENM2 holds  not (proj1XTUPLE-0K12 X =XBOOLE-0R4 {}XBOOLE-0K1 &  not proj2XTUPLE-0K13 X =XBOOLE-0R4 {}XBOOLE-0K1) &  not (proj2XTUPLE-0K13 X =XBOOLE-0R4 {}XBOOLE-0K1 &  not proj1XTUPLE-0K12 X =XBOOLE-0R4 {}XBOOLE-0K1)"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have "proj1XTUPLE-0K12 X =XBOOLE-0R4 {}XBOOLE-0K1 or proj2XTUPLE-0K13 X =XBOOLE-0R4 {}XBOOLE-0K1 implies  not ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 X)"
      using xtuple_0_def_12 xtuple_0_def_13 sorry
    thus " not (proj1XTUPLE-0K12 X =XBOOLE-0R4 {}XBOOLE-0K1 &  not proj2XTUPLE-0K13 X =XBOOLE-0R4 {}XBOOLE-0K1) &  not (proj2XTUPLE-0K13 X =XBOOLE-0R4 {}XBOOLE-0K1 &  not proj1XTUPLE-0K12 X =XBOOLE-0R4 {}XBOOLE-0K1)"
      using funct_5_th_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_17:
" for f be FunctionFUNCT-1M1 holds proj1XTUPLE-0K12 (domRELAT-1K1 f) =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 (~FUNCT-4K2 f)) & proj2XTUPLE-0K13 (domRELAT-1K1 f) =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 (~FUNCT-4K2 f))"
proof-
  have " for f be FunctionFUNCT-1M1 holds proj1XTUPLE-0K12 (domRELAT-1K1 f) =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 (~FUNCT-4K2 f)) & proj2XTUPLE-0K13 (domRELAT-1K1 f) =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 (~FUNCT-4K2 f))"
  proof(rule ballI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have "proj1XTUPLE-0K12 (domRELAT-1K1 f) c=TARSKIR1 proj2XTUPLE-0K13 (domRELAT-1K1 (~FUNCT-4K2 f)) & (proj2XTUPLE-0K13 (domRELAT-1K1 (~FUNCT-4K2 f)) c=TARSKIR1 proj1XTUPLE-0K12 (domRELAT-1K1 f) & proj2XTUPLE-0K13 (domRELAT-1K1 f) =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 (~FUNCT-4K2 f)))"
    proof(rule conjMI,rule conjMI)
      show "proj1XTUPLE-0K12 (domRELAT-1K1 f) c=TARSKIR1 proj2XTUPLE-0K13 (domRELAT-1K1 (~FUNCT-4K2 f))"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 f) implies x inHIDDENR3 proj2XTUPLE-0K13 (domRELAT-1K1 (~FUNCT-4K2 f))"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 f)"
          then obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A1: "[TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 f"
            using xtuple_0_def_12 sorry
          have "[TARSKIK4 y,x ] inHIDDENR3 domRELAT-1K1 (~FUNCT-4K2 f)"
            using A1 funct_4_th_42 sorry
          thus "x inHIDDENR3 proj2XTUPLE-0K13 (domRELAT-1K1 (~FUNCT-4K2 f))"
            using xtuple_0_def_13 sorry
        qed "sorry"
        thus "proj1XTUPLE-0K12 (domRELAT-1K1 f) c=TARSKIR1 proj2XTUPLE-0K13 (domRELAT-1K1 (~FUNCT-4K2 f))"
          using tarski_def_3 sorry
      qed
      show "proj2XTUPLE-0K13 (domRELAT-1K1 (~FUNCT-4K2 f)) c=TARSKIR1 proj1XTUPLE-0K12 (domRELAT-1K1 f)"
      proof-
        have " for y be objectHIDDENM1 holds y inHIDDENR3 proj2XTUPLE-0K13 (domRELAT-1K1 (~FUNCT-4K2 f)) implies y inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 f)"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "y inHIDDENR3 proj2XTUPLE-0K13 (domRELAT-1K1 (~FUNCT-4K2 f))"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A2: "[TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 (~FUNCT-4K2 f)"
            using xtuple_0_def_13 sorry
          have "[TARSKIK4 y,x ] inHIDDENR3 domRELAT-1K1 f"
            using A2 funct_4_th_42 sorry
          thus "y inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 f)"
            using xtuple_0_def_12 sorry
        qed "sorry"
        thus "proj2XTUPLE-0K13 (domRELAT-1K1 (~FUNCT-4K2 f)) c=TARSKIR1 proj1XTUPLE-0K12 (domRELAT-1K1 f)"
          using tarski_def_3 sorry
      qed
      have "proj2XTUPLE-0K13 (domRELAT-1K1 f) c=TARSKIR1 proj1XTUPLE-0K12 (domRELAT-1K1 (~FUNCT-4K2 f)) & proj1XTUPLE-0K12 (domRELAT-1K1 (~FUNCT-4K2 f)) c=TARSKIR1 proj2XTUPLE-0K13 (domRELAT-1K1 f)"
      proof(rule conjMI)
        show "proj2XTUPLE-0K13 (domRELAT-1K1 f) c=TARSKIR1 proj1XTUPLE-0K12 (domRELAT-1K1 (~FUNCT-4K2 f))"
        proof-
          have " for y be objectHIDDENM1 holds y inHIDDENR3 proj2XTUPLE-0K13 (domRELAT-1K1 f) implies y inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 (~FUNCT-4K2 f))"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            assume "y inHIDDENR3 proj2XTUPLE-0K13 (domRELAT-1K1 f)"
            then obtain x where
              [ty]:"x be objectHIDDENM1" and 
              A3: "[TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 f"
              using xtuple_0_def_13 sorry
            have "[TARSKIK4 y,x ] inHIDDENR3 domRELAT-1K1 (~FUNCT-4K2 f)"
              using A3 funct_4_th_42 sorry
            thus "y inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 (~FUNCT-4K2 f))"
              using xtuple_0_def_12 sorry
          qed "sorry"
          thus "proj2XTUPLE-0K13 (domRELAT-1K1 f) c=TARSKIR1 proj1XTUPLE-0K12 (domRELAT-1K1 (~FUNCT-4K2 f))"
            using tarski_def_3 sorry
        qed
        show "proj1XTUPLE-0K12 (domRELAT-1K1 (~FUNCT-4K2 f)) c=TARSKIR1 proj2XTUPLE-0K13 (domRELAT-1K1 f)"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 (~FUNCT-4K2 f)) implies x inHIDDENR3 proj2XTUPLE-0K13 (domRELAT-1K1 f)"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 (~FUNCT-4K2 f))"
            then obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A4: "[TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 (~FUNCT-4K2 f)"
              using xtuple_0_def_12 sorry
            have "[TARSKIK4 y,x ] inHIDDENR3 domRELAT-1K1 f"
              using A4 funct_4_th_42 sorry
            thus "x inHIDDENR3 proj2XTUPLE-0K13 (domRELAT-1K1 f)"
              using xtuple_0_def_13 sorry
          qed "sorry"
          thus "proj1XTUPLE-0K12 (domRELAT-1K1 (~FUNCT-4K2 f)) c=TARSKIR1 proj2XTUPLE-0K13 (domRELAT-1K1 f)"
            using tarski_def_3 sorry
        qed
      qed
      thus "proj2XTUPLE-0K13 (domRELAT-1K1 f) =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 (~FUNCT-4K2 f))"
        using xboole_0_def_10 sorry
    qed
    thus "proj1XTUPLE-0K12 (domRELAT-1K1 f) =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 (~FUNCT-4K2 f)) & proj2XTUPLE-0K13 (domRELAT-1K1 f) =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 (~FUNCT-4K2 f))"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef funct_5_def_1 ("curryFUNCT-5K1  _ " [228]228 ) where
  mlet "f be FunctionFUNCT-1M1"
"func curryFUNCT-5K1 f \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 f) implies ( ex g be FunctionFUNCT-1M1 st (it .FUNCT-1K1 x =XBOOLE-0R4 g & domRELAT-1K1 g =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :]))) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y))))"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 f) implies ( ex g be FunctionFUNCT-1M1 st (it .FUNCT-1K1 x =XBOOLE-0R4 g & domRELAT-1K1 g =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :]))) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y))))"
    proof-
      have " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 f) & ( for g be FunctionFUNCT-1M1 holds  not ((VarFor1 .FUNCT-1K1 x =XBOOLE-0R4 g & domRELAT-1K1 g =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :]))) & ( for y be objectHIDDENM1 holds  not (y inHIDDENR3 domRELAT-1K1 g &  not g .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y)))))))))"
      proof-
        let ?F = "\<lambda>Lamb1. \<lambda>Lamb2. domRELAT-1K1 Lamb2 =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 Lamb1},proj2XTUPLE-0K13 (domRELAT-1K1 f) :])) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 Lamb2 implies Lamb2 .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(Lamb1,y))"
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex g be FunctionFUNCT-1M1 st Lamb2 =HIDDENR1 g & ?F(Lamb1,g)"
        have A1: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds (x inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 f) & ?P(x,y)) & ?P(x,z) implies y =HIDDENR1 z"
        proof-
          have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds x inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 f) implies (( ex g1 be FunctionFUNCT-1M1 st y =HIDDENR1 g1 & (domRELAT-1K1 g1 =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :])) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 g1 implies g1 .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y)))) implies (( ex g2 be FunctionFUNCT-1M1 st z =HIDDENR1 g2 & (domRELAT-1K1 g2 =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :])) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 g2 implies g2 .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y)))) implies y =HIDDENR1 z))"
          proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            fix y assume [ty]: "y be objectHIDDENM1"
            fix z assume [ty]: "z be objectHIDDENM1"
            assume "x inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 f)"
            assume Given: " ex g1 be FunctionFUNCT-1M1 st y =HIDDENR1 g1 & ?F(x,g1)"
            then obtain g1 where
              [ty]:"g1 be FunctionFUNCT-1M1" and 
              A2: "y =HIDDENR1 g1"and A3: "?F(x,g1)"
               sorry
            assume Given: " ex g2 be FunctionFUNCT-1M1 st z =HIDDENR1 g2 & ?F(x,g2)"
            then obtain g2 where
              [ty]:"g2 be FunctionFUNCT-1M1" and 
              A4: "z =HIDDENR1 g2"and A5: "?F(x,g2)"
               sorry
            have " for t be objectHIDDENM1 holds t inHIDDENR3 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :])) implies g1 .FUNCT-1K1 t =XBOOLE-0R4 g2 .FUNCT-1K1 t"
            proof(rule ballI,rule impI)
              fix t assume [ty]: "t be objectHIDDENM1"
              assume A6: "t inHIDDENR3 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :]))"
              then have "g1 .FUNCT-1K1 t =XBOOLE-0R4 f .BINOP-1K1(x,t)"
                using A3 sorry
              thus "g1 .FUNCT-1K1 t =XBOOLE-0R4 g2 .FUNCT-1K1 t"
                using A5 A6 sorry
            qed "sorry"
            thus "y =HIDDENR1 z"
              using A2 A3 A4 A5 funct_1_th_2 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have A7: " for x be objectHIDDENM1 holds x inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 f) implies ( ex y be objectHIDDENM1 st ?P(x,y))"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 f) implies ( ex A be setHIDDENM2 st  ex B be FunctionFUNCT-1M1 st A =HIDDENR1 B & (domRELAT-1K1 B =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :])) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 B implies B .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y))))"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 f)"
            let ?F = "\<lambda>Lamb1. f .FUNCT-1K1 [TARSKIK4 x,Lamb1 ]"
            obtain g where
              [ty]:"g be FunctionFUNCT-1M1" and 
              A8: "domRELAT-1K1 g =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :])) & ( for y be objectHIDDENM1 holds y inHIDDENR3 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :])) implies g .FUNCT-1K1 y =XBOOLE-0R4 ?F(y))"
              using funct_1_sch_3 sorry
            obtain y where 
              [ty]:"y be setHIDDENM2" and yDef:"y = g"
               sorry
            obtain A where 
              [ty]:"A be setHIDDENM2" and ADef:"A = y"
               sorry
            show " ex A be setHIDDENM2 st  ex B be FunctionFUNCT-1M1 st A =HIDDENR1 B & (domRELAT-1K1 B =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :])) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 B implies B .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y)))"
            proof(rule bexI[of _ "A"])
              obtain B where 
                [ty]:"B be FunctionFUNCT-1M1" and BDef:"B = g"
                 sorry
              show " ex B be FunctionFUNCT-1M1 st A =HIDDENR1 B & (domRELAT-1K1 B =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :])) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 B implies B .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y)))"
              proof(rule bexI[of _ "B"])
                show "A =HIDDENR1 B & (domRELAT-1K1 B =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :])) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 B implies B .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y)))"
                  using A8 sorry
              qed "sorry"
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have " ex g be FunctionFUNCT-1M1 st domRELAT-1K1 g =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 f) implies ?P(x,g .FUNCT-1K1 x))"
          using funct_1_sch_2 A1 A7 sorry
        thus " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 f) & ( for g be FunctionFUNCT-1M1 holds  not ((VarFor1 .FUNCT-1K1 x =XBOOLE-0R4 g & domRELAT-1K1 g =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :]))) & ( for y be objectHIDDENM1 holds  not (y inHIDDENR3 domRELAT-1K1 g &  not g .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y)))))))))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 f) implies ( ex g be FunctionFUNCT-1M1 st (it1 .FUNCT-1K1 x =XBOOLE-0R4 g & domRELAT-1K1 g =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :]))) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y))))) & (domRELAT-1K1 it2 =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 f) implies ( ex g be FunctionFUNCT-1M1 st (it2 .FUNCT-1K1 x =XBOOLE-0R4 g & domRELAT-1K1 g =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :]))) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y))))) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be FunctionFUNCT-1M1 holds  for f2 be FunctionFUNCT-1M1 holds domRELAT-1K1 f1 =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 f) & (( for x be objectHIDDENM1 holds x inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 f) implies ( ex g be FunctionFUNCT-1M1 st (f1 .FUNCT-1K1 x =XBOOLE-0R4 g & domRELAT-1K1 g =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :]))) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y)))) & (domRELAT-1K1 f2 =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 f) implies ( ex g be FunctionFUNCT-1M1 st (f2 .FUNCT-1K1 x =XBOOLE-0R4 g & domRELAT-1K1 g =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :]))) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y)))))) implies f1 =HIDDENR1 f2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix f1 assume [ty]: "f1 be FunctionFUNCT-1M1"
        fix f2 assume [ty]: "f2 be FunctionFUNCT-1M1"
        assume A9: "domRELAT-1K1 f1 =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 f)"
          and A10: " for x be objectHIDDENM1 holds x inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 f) implies ( ex g be FunctionFUNCT-1M1 st (f1 .FUNCT-1K1 x =XBOOLE-0R4 g & domRELAT-1K1 g =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :]))) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y)))"
          and A11: "domRELAT-1K1 f2 =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 f)"
          and A12: " for x be objectHIDDENM1 holds x inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 f) implies ( ex g be FunctionFUNCT-1M1 st (f2 .FUNCT-1K1 x =XBOOLE-0R4 g & domRELAT-1K1 g =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :]))) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y)))"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 f) implies f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A13: "x inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 f)"
          then obtain g1 where
            [ty]:"g1 be FunctionFUNCT-1M1" and 
            A14: "f1 .FUNCT-1K1 x =XBOOLE-0R4 g1"and A15: "domRELAT-1K1 g1 =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :]))"and A16: " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 g1 implies g1 .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y)"
            using A10 sorry
          obtain g2 where
            [ty]:"g2 be FunctionFUNCT-1M1" and 
            A17: "f2 .FUNCT-1K1 x =XBOOLE-0R4 g2"and A18: "domRELAT-1K1 g2 =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :]))"and A19: " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 g2 implies g2 .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y)"
            using A12 A13 sorry
          have " for y be objectHIDDENM1 holds y inHIDDENR3 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :])) implies g1 .FUNCT-1K1 y =XBOOLE-0R4 g2 .FUNCT-1K1 y"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            assume A20: "y inHIDDENR3 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :]))"
            then have "g1 .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y)"
              using A15 A16 sorry
            thus "g1 .FUNCT-1K1 y =XBOOLE-0R4 g2 .FUNCT-1K1 y"
              using A18 A19 A20 sorry
          qed "sorry"
          thus "f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x"
            using A14 A15 A17 A18 funct_1_th_2 sorry
        qed "sorry"
        thus "f1 =HIDDENR1 f2"
          using A9 A11 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef funct_5_def_2 ("uncurryFUNCT-5K2  _ " [228]228 ) where
  mlet "f be FunctionFUNCT-1M1"
"func uncurryFUNCT-5K2 f \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. ( for t be objectHIDDENM1 holds t inHIDDENR3 domRELAT-1K1 it iff ( ex x be objectHIDDENM1 st  ex g be FunctionFUNCT-1M1 st  ex y be objectHIDDENM1 st ((t =HIDDENR1 [TARSKIK4 x,y ] & x inHIDDENR3 domRELAT-1K1 f) & g =XBOOLE-0R4 f .FUNCT-1K1 x) & y inHIDDENR3 domRELAT-1K1 g)) & ( for x be objectHIDDENM1 holds  for g be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 it & g =XBOOLE-0R4 f .FUNCT-1K1 x `1XTUPLE-0K1 implies it .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x `2XTUPLE-0K2)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st ( for t be objectHIDDENM1 holds t inHIDDENR3 domRELAT-1K1 it iff ( ex x be objectHIDDENM1 st  ex g be FunctionFUNCT-1M1 st  ex y be objectHIDDENM1 st ((t =HIDDENR1 [TARSKIK4 x,y ] & x inHIDDENR3 domRELAT-1K1 f) & g =XBOOLE-0R4 f .FUNCT-1K1 x) & y inHIDDENR3 domRELAT-1K1 g)) & ( for x be objectHIDDENM1 holds  for g be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 it & g =XBOOLE-0R4 f .FUNCT-1K1 x `1XTUPLE-0K1 implies it .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x `2XTUPLE-0K2)"
    proof-
      have " ex tVar6 be FunctionFUNCT-1M1 st ( for t be objectHIDDENM1 holds t inHIDDENR3 domRELAT-1K1 tVar6 iff ( ex x be objectHIDDENM1 st  ex g be FunctionFUNCT-1M1 st  ex y be objectHIDDENM1 st ((t =HIDDENR1 [TARSKIK4 x,y ] & x inHIDDENR3 domRELAT-1K1 f) & g =XBOOLE-0R4 f .FUNCT-1K1 x) & y inHIDDENR3 domRELAT-1K1 g)) & ( for x be objectHIDDENM1 holds  for h be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 tVar6 & h =XBOOLE-0R4 f .FUNCT-1K1 x `1XTUPLE-0K1 implies tVar6 .FUNCT-1K1 x =XBOOLE-0R4 h .FUNCT-1K1 x `2XTUPLE-0K2)"
      proof-
        let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2.  ex g be FunctionFUNCT-1M1 st g =XBOOLE-0R4 f .FUNCT-1K1 Lamb1 `1XTUPLE-0K1 & Lamb2 =HIDDENR1 g .FUNCT-1K1 Lamb1 `2XTUPLE-0K2"
        let ?F = "\<lambda>Lamb1. domRELAT-1K1 Lamb1"
        let ?P = "\<lambda>Lamb1. f .FUNCT-1K1 Lamb1 be FunctionFUNCT-1M1"
        obtain X where
          [ty]:"X be setHIDDENM2" and 
          A21: " for x be objectHIDDENM1 holds x inHIDDENR3 X iff x inHIDDENR3 domRELAT-1K1 f & ?P(x)"
          using xboole_0_sch_1 sorry
        let ?P = "\<lambda>Lamb1.  for g1 be FunctionFUNCT-1M1 holds g1 =XBOOLE-0R4 f .FUNCT-1K1 Lamb1 `1XTUPLE-0K1 implies Lamb1 `2XTUPLE-0K2 inHIDDENR3 domRELAT-1K1 g1"
        obtain g where
          [ty]:"g be FunctionFUNCT-1M1" and 
          A22: "domRELAT-1K1 g =XBOOLE-0R4 f .:FUNCT-1K5 X & ( for g1 be FunctionFUNCT-1M1 holds g1 inTARSKIR2 f .:FUNCT-1K5 X implies g .FUNCT-1K1 g1 =XBOOLE-0R4 ?F(g1))"
          using funct_5_sch_1 sorry
        obtain Y where
          [ty]:"Y be setHIDDENM2" and 
          A23: " for x be objectHIDDENM1 holds x inHIDDENR3 Y iff x inHIDDENR3 [:ZFMISC-1K2 X,unionTARSKIK3 (rngFUNCT-1K2 g) :] & ?P(x)"
          using xboole_0_sch_1 sorry
        have A24: " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies ( ex y be objectHIDDENM1 st ?Q(x,y))"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies ( ex tVar4 be objectHIDDENM1 st  ex tVar5 be FunctionFUNCT-1M1 st tVar5 =XBOOLE-0R4 f .FUNCT-1K1 x `1XTUPLE-0K1 & tVar5 .FUNCT-1K1 x `2XTUPLE-0K2 =HIDDENR1 tVar5 .FUNCT-1K1 x `2XTUPLE-0K2)"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 Y"
            then have "x inHIDDENR3 [:ZFMISC-1K2 X,unionTARSKIK3 (rngFUNCT-1K2 g) :]"
              using A23 sorry
            then have "x `1XTUPLE-0K1 inHIDDENR3 X"
              using mcart_1_th_10 sorry
            then obtain h where 
              [ty]:"h be FunctionFUNCT-1M1" and hDef:"h = f .FUNCT-1K1 x `1XTUPLE-0K1"
              using A21 sorry
            show " ex tVar4 be objectHIDDENM1 st  ex tVar5 be FunctionFUNCT-1M1 st tVar5 =XBOOLE-0R4 f .FUNCT-1K1 x `1XTUPLE-0K1 & tVar5 .FUNCT-1K1 x `2XTUPLE-0K2 =HIDDENR1 tVar5 .FUNCT-1K1 x `2XTUPLE-0K2"
            proof(rule bexI[of _ "h .FUNCT-1K1 x `2XTUPLE-0K2"])
              show " ex tVar5 be FunctionFUNCT-1M1 st tVar5 =XBOOLE-0R4 f .FUNCT-1K1 x `1XTUPLE-0K1 & tVar5 .FUNCT-1K1 x `2XTUPLE-0K2 =HIDDENR1 tVar5 .FUNCT-1K1 x `2XTUPLE-0K2"
              proof(rule bexI[of _ "h"])
                show "h =XBOOLE-0R4 f .FUNCT-1K1 x `1XTUPLE-0K1 & h .FUNCT-1K1 x `2XTUPLE-0K2 =HIDDENR1 h .FUNCT-1K1 x `2XTUPLE-0K2"
                   sorry
              qed "sorry"
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have A25: " for x be objectHIDDENM1 holds  for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds (x inHIDDENR3 Y & ?Q(x,x1)) & ?Q(x,x2) implies x1 =HIDDENR1 x2"
           sorry
        obtain F where
          [ty]:"F be FunctionFUNCT-1M1" and 
          A26: "domRELAT-1K1 F =XBOOLE-0R4 Y & ( for x be objectHIDDENM1 holds x inHIDDENR3 Y implies ?Q(x,F .FUNCT-1K1 x))"
          using funct_1_sch_2 A25 A24 sorry
        show " ex tVar6 be FunctionFUNCT-1M1 st ( for t be objectHIDDENM1 holds t inHIDDENR3 domRELAT-1K1 tVar6 iff ( ex x be objectHIDDENM1 st  ex g be FunctionFUNCT-1M1 st  ex y be objectHIDDENM1 st ((t =HIDDENR1 [TARSKIK4 x,y ] & x inHIDDENR3 domRELAT-1K1 f) & g =XBOOLE-0R4 f .FUNCT-1K1 x) & y inHIDDENR3 domRELAT-1K1 g)) & ( for x be objectHIDDENM1 holds  for h be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 tVar6 & h =XBOOLE-0R4 f .FUNCT-1K1 x `1XTUPLE-0K1 implies tVar6 .FUNCT-1K1 x =XBOOLE-0R4 h .FUNCT-1K1 x `2XTUPLE-0K2)"
        proof(rule bexI[of _ "F"],rule conjMI,rule ballI,rule ballI,rule impMI ,rule impI)
          show " for t be objectHIDDENM1 holds t inHIDDENR3 domRELAT-1K1 F iff ( ex x be objectHIDDENM1 st  ex g be FunctionFUNCT-1M1 st  ex y be objectHIDDENM1 st ((t =HIDDENR1 [TARSKIK4 x,y ] & x inHIDDENR3 domRELAT-1K1 f) & g =XBOOLE-0R4 f .FUNCT-1K1 x) & y inHIDDENR3 domRELAT-1K1 g)"
          proof-
            have " for t be objectHIDDENM1 holds (t inHIDDENR3 domRELAT-1K1 F implies ( ex x be objectHIDDENM1 st  ex g be FunctionFUNCT-1M1 st  ex y be objectHIDDENM1 st ((t =HIDDENR1 [TARSKIK4 x,y ] & x inHIDDENR3 domRELAT-1K1 f) & g =XBOOLE-0R4 f .FUNCT-1K1 x) & y inHIDDENR3 domRELAT-1K1 g)) & (( ex x be objectHIDDENM1 st  ex h be FunctionFUNCT-1M1 st  ex y be objectHIDDENM1 st ((t =HIDDENR1 [TARSKIK4 x,y ] & x inHIDDENR3 domRELAT-1K1 f) & h =XBOOLE-0R4 f .FUNCT-1K1 x) & y inHIDDENR3 domRELAT-1K1 h) implies t inHIDDENR3 domRELAT-1K1 F)"
            proof(rule ballI,rule conjMI,rule impI)
              fix t assume [ty]: "t be objectHIDDENM1"
              show "t inHIDDENR3 domRELAT-1K1 F implies ( ex x be objectHIDDENM1 st  ex g be FunctionFUNCT-1M1 st  ex y be objectHIDDENM1 st ((t =HIDDENR1 [TARSKIK4 x,y ] & x inHIDDENR3 domRELAT-1K1 f) & g =XBOOLE-0R4 f .FUNCT-1K1 x) & y inHIDDENR3 domRELAT-1K1 g)"
              proof-
                have "t inHIDDENR3 domRELAT-1K1 F implies ( ex x be objectHIDDENM1 st  ex tVar8 be FunctionFUNCT-1M1 st  ex tVar9 be objectHIDDENM1 st ((t =HIDDENR1 [TARSKIK4 x,tVar9 ] & x inHIDDENR3 domRELAT-1K1 f) & tVar8 =XBOOLE-0R4 f .FUNCT-1K1 x) & tVar9 inHIDDENR3 domRELAT-1K1 tVar8)"
                proof(rule impI)
                  assume A27: "t inHIDDENR3 domRELAT-1K1 F"
                  obtain x where 
                    [ty]:"x be objectHIDDENM1" and xDef:"x = t `1XTUPLE-0K1"
                     sorry
                  show " ex x be objectHIDDENM1 st  ex tVar8 be FunctionFUNCT-1M1 st  ex tVar9 be objectHIDDENM1 st ((t =HIDDENR1 [TARSKIK4 x,tVar9 ] & x inHIDDENR3 domRELAT-1K1 f) & tVar8 =XBOOLE-0R4 f .FUNCT-1K1 x) & tVar9 inHIDDENR3 domRELAT-1K1 tVar8"
                  proof(rule bexI[of _ "x"])
                    have "t inHIDDENR3 [:ZFMISC-1K2 X,unionTARSKIK3 (rngFUNCT-1K2 g) :]"
                      using A23 A26 A27 sorry
                    then have A28: "x inHIDDENR3 X"
                      using mcart_1_th_10 sorry
                    then obtain h where 
                      [ty]:"h be FunctionFUNCT-1M1" and hDef:"h = f .FUNCT-1K1 x"
                      using A21 sorry
                    show " ex tVar8 be FunctionFUNCT-1M1 st  ex tVar9 be objectHIDDENM1 st ((t =HIDDENR1 [TARSKIK4 x,tVar9 ] & x inHIDDENR3 domRELAT-1K1 f) & tVar8 =XBOOLE-0R4 f .FUNCT-1K1 x) & tVar9 inHIDDENR3 domRELAT-1K1 tVar8"
                    proof(rule bexI[of _ "h"])
                      show " ex tVar9 be objectHIDDENM1 st ((t =HIDDENR1 [TARSKIK4 x,tVar9 ] & x inHIDDENR3 domRELAT-1K1 f) & h =XBOOLE-0R4 f .FUNCT-1K1 x) & tVar9 inHIDDENR3 domRELAT-1K1 h"
                      proof(rule bexI[of _ "t `2XTUPLE-0K2"])
                        show "((t =HIDDENR1 [TARSKIK4 x,t `2XTUPLE-0K2 ] & x inHIDDENR3 domRELAT-1K1 f) & h =XBOOLE-0R4 f .FUNCT-1K1 x) & t `2XTUPLE-0K2 inHIDDENR3 domRELAT-1K1 h"
                          using A21 A23 A26 A27 A28 mcart_1_th_21 sorry
                      qed "sorry"
                    qed "sorry"
                  qed "sorry"
                qed
                thus " ?thesis "
                   sorry
              qed
              assume Given: " ex x be objectHIDDENM1 st  ex h be FunctionFUNCT-1M1 st  ex y be objectHIDDENM1 st ((t =HIDDENR1 [TARSKIK4 x,y ] & x inHIDDENR3 domRELAT-1K1 f) & h =XBOOLE-0R4 f .FUNCT-1K1 x) & y inHIDDENR3 domRELAT-1K1 h"
              then obtain x h y where
                [ty]:"x be objectHIDDENM1" "h be FunctionFUNCT-1M1" "y be objectHIDDENM1" and 
                A29: "t =HIDDENR1 [TARSKIK4 x,y ]"and A30: "x inHIDDENR3 domRELAT-1K1 f"and A31: "h =XBOOLE-0R4 f .FUNCT-1K1 x"and A32: "y inHIDDENR3 domRELAT-1K1 h"
                 sorry
              have A33: "x inHIDDENR3 X"
                using A21 A30 A31 sorry
              then have "h inTARSKIR2 f .:FUNCT-1K5 X"
                using A30 A31 funct_1_def_6 sorry
              then have "g .FUNCT-1K1 h =XBOOLE-0R4 domRELAT-1K1 h & g .FUNCT-1K1 h inTARSKIR2 rngFUNCT-1K2 g"
                using A22 funct_1_def_3 sorry
              then have "domRELAT-1K1 h c=TARSKIR1 unionTARSKIK3 (rngFUNCT-1K2 g)"
                using zfmisc_1_th_74 sorry
              then have A34: "t inHIDDENR3 [:ZFMISC-1K2 X,unionTARSKIK3 (rngFUNCT-1K2 g) :]"
                using A29 A32 A33 zfmisc_1_th_87 sorry
              have " for g1 be FunctionFUNCT-1M1 holds g1 =XBOOLE-0R4 f .FUNCT-1K1 t `1XTUPLE-0K1 implies t `2XTUPLE-0K2 inHIDDENR3 domRELAT-1K1 g1"
                using A29 A31 A32 sorry
              thus "t inHIDDENR3 domRELAT-1K1 F"
                using A23 A26 A34 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          fix x assume [ty]: "x be objectHIDDENM1"
          fix h assume [ty]: "h be FunctionFUNCT-1M1"
          assume A35: "x inHIDDENR3 domRELAT-1K1 F"
            and A36: "h =XBOOLE-0R4 f .FUNCT-1K1 x `1XTUPLE-0K1"
          have " ex g be FunctionFUNCT-1M1 st g =XBOOLE-0R4 f .FUNCT-1K1 x `1XTUPLE-0K1 & F .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x `2XTUPLE-0K2"
            using A26 A35 sorry
          thus "F .FUNCT-1K1 x =XBOOLE-0R4 h .FUNCT-1K1 x `2XTUPLE-0K2"
            using A36 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (( for t be objectHIDDENM1 holds t inHIDDENR3 domRELAT-1K1 it1 iff ( ex x be objectHIDDENM1 st  ex g be FunctionFUNCT-1M1 st  ex y be objectHIDDENM1 st ((t =HIDDENR1 [TARSKIK4 x,y ] & x inHIDDENR3 domRELAT-1K1 f) & g =XBOOLE-0R4 f .FUNCT-1K1 x) & y inHIDDENR3 domRELAT-1K1 g)) & ( for x be objectHIDDENM1 holds  for g be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 it1 & g =XBOOLE-0R4 f .FUNCT-1K1 x `1XTUPLE-0K1 implies it1 .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x `2XTUPLE-0K2)) & (( for t be objectHIDDENM1 holds t inHIDDENR3 domRELAT-1K1 it2 iff ( ex x be objectHIDDENM1 st  ex g be FunctionFUNCT-1M1 st  ex y be objectHIDDENM1 st ((t =HIDDENR1 [TARSKIK4 x,y ] & x inHIDDENR3 domRELAT-1K1 f) & g =XBOOLE-0R4 f .FUNCT-1K1 x) & y inHIDDENR3 domRELAT-1K1 g)) & ( for x be objectHIDDENM1 holds  for g be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 it2 & g =XBOOLE-0R4 f .FUNCT-1K1 x `1XTUPLE-0K1 implies it2 .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x `2XTUPLE-0K2)) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be FunctionFUNCT-1M1 holds  for f2 be FunctionFUNCT-1M1 holds ( for t be objectHIDDENM1 holds t inHIDDENR3 domRELAT-1K1 f1 iff ( ex x be objectHIDDENM1 st  ex g be FunctionFUNCT-1M1 st  ex y be objectHIDDENM1 st ((t =HIDDENR1 [TARSKIK4 x,y ] & x inHIDDENR3 domRELAT-1K1 f) & g =XBOOLE-0R4 f .FUNCT-1K1 x) & y inHIDDENR3 domRELAT-1K1 g)) & (( for x be objectHIDDENM1 holds  for g be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f1 & g =XBOOLE-0R4 f .FUNCT-1K1 x `1XTUPLE-0K1 implies f1 .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x `2XTUPLE-0K2) & (( for t be objectHIDDENM1 holds t inHIDDENR3 domRELAT-1K1 f2 iff ( ex x be objectHIDDENM1 st  ex g be FunctionFUNCT-1M1 st  ex y be objectHIDDENM1 st ((t =HIDDENR1 [TARSKIK4 x,y ] & x inHIDDENR3 domRELAT-1K1 f) & g =XBOOLE-0R4 f .FUNCT-1K1 x) & y inHIDDENR3 domRELAT-1K1 g)) & ( for x be objectHIDDENM1 holds  for g be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f2 & g =XBOOLE-0R4 f .FUNCT-1K1 x `1XTUPLE-0K1 implies f2 .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x `2XTUPLE-0K2))) implies f1 =HIDDENR1 f2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        let ?P = "\<lambda>Lamb1.  ex x be objectHIDDENM1 st  ex g be FunctionFUNCT-1M1 st  ex y be objectHIDDENM1 st ((Lamb1 =HIDDENR1 [TARSKIK4 x,y ] & x inHIDDENR3 domRELAT-1K1 f) & g =XBOOLE-0R4 f .FUNCT-1K1 x) & y inHIDDENR3 domRELAT-1K1 g"
        fix f1 assume [ty]: "f1 be FunctionFUNCT-1M1"
        fix f2 assume [ty]: "f2 be FunctionFUNCT-1M1"
        assume A37: " for t be objectHIDDENM1 holds t inHIDDENR3 domRELAT-1K1 f1 iff ?P(t)"
          and A38: " for x be objectHIDDENM1 holds  for g be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f1 & g =XBOOLE-0R4 f .FUNCT-1K1 x `1XTUPLE-0K1 implies f1 .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x `2XTUPLE-0K2"
          and A39: " for t be objectHIDDENM1 holds t inHIDDENR3 domRELAT-1K1 f2 iff ?P(t)"
          and A40: " for x be objectHIDDENM1 holds  for g be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f2 & g =XBOOLE-0R4 f .FUNCT-1K1 x `1XTUPLE-0K1 implies f2 .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x `2XTUPLE-0K2"
        have A41: "domRELAT-1K1 f1 =XBOOLE-0R4 domRELAT-1K1 f2"
          using xboole_0_sch_2 A37 A39 sorry
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f1 implies f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A42: "x inHIDDENR3 domRELAT-1K1 f1"
          then obtain z g y where
            [ty]:"z be objectHIDDENM1" "g be FunctionFUNCT-1M1" "y be objectHIDDENM1" and 
            A43: "x =HIDDENR1 [TARSKIK4 z,y ]"and "z inHIDDENR3 domRELAT-1K1 f"and A44: "g =XBOOLE-0R4 f .FUNCT-1K1 z"and "y inHIDDENR3 domRELAT-1K1 g"
            using A37 sorry
          have A45: "z =HIDDENR1 x `1XTUPLE-0K1 & y =HIDDENR1 x `2XTUPLE-0K2"
            using A43 sorry
          then have "f1 .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 y"
            using A38 A42 A44 sorry
          thus "f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x"
            using A40 A41 A42 A44 A45 sorry
        qed "sorry"
        thus "f1 =HIDDENR1 f2"
          using A41 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef funct_5_def_3 ("curry''FUNCT-5K3  _ " [228]228 ) where
  mlet "f be FunctionFUNCT-1M1"
"func curry'FUNCT-5K3 f \<rightarrow> FunctionFUNCT-1M1 equals
  curryFUNCT-5K1 (~FUNCT-4K2 f)"
proof-
  (*coherence*)
    show "curryFUNCT-5K1 (~FUNCT-4K2 f) be FunctionFUNCT-1M1"
       sorry
qed "sorry"

mdef funct_5_def_4 ("uncurry''FUNCT-5K4  _ " [228]228 ) where
  mlet "f be FunctionFUNCT-1M1"
"func uncurry'FUNCT-5K4 f \<rightarrow> FunctionFUNCT-1M1 equals
  ~FUNCT-4K2 (uncurryFUNCT-5K2 f)"
proof-
  (*coherence*)
    show "~FUNCT-4K2 (uncurryFUNCT-5K2 f) be FunctionFUNCT-1M1"
       sorry
qed "sorry"

(*\$CT*)
mtheorem funct_5_cl_1:
  mlet "f be FunctionFUNCT-1M1"
"cluster curryFUNCT-5K1 f as-term-is Function-yieldingFUNCOP-1V1"
proof
(*coherence*)
  show "curryFUNCT-5K1 f be Function-yieldingFUNCOP-1V1"
  proof-
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (curryFUNCT-5K1 f) implies curryFUNCT-5K1 f .FUNCT-1K1 x be setHIDDENM2"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 domRELAT-1K1 (curryFUNCT-5K1 f)"
      then have A1: "x inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 f)"
        using funct_5_def_1 sorry
      have " ex g be FunctionFUNCT-1M1 st (curryFUNCT-5K1 f .FUNCT-1K1 x =XBOOLE-0R4 g & domRELAT-1K1 g =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :]))) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y))"
        using A1 funct_5_def_1 sorry
      thus "curryFUNCT-5K1 f .FUNCT-1K1 x be setHIDDENM2"
         sorry
    qed "sorry"
    thus "curryFUNCT-5K1 f be Function-yieldingFUNCOP-1V1"
      using funcop_1_def_6 sorry
  qed
qed "sorry"

mtheorem funct_5_th_19:
" for f be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 f implies x inHIDDENR3 domRELAT-1K1 (curryFUNCT-5K1 f)"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 f implies x inHIDDENR3 domRELAT-1K1 (curryFUNCT-5K1 f)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    assume "[TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 f"
    then have "x inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 f)"
      using xtuple_0_def_12 sorry
    thus "x inHIDDENR3 domRELAT-1K1 (curryFUNCT-5K1 f)"
      using funct_5_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_20:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 f & g =XBOOLE-0R4 curryFUNCT-5K1 f .FUNCT-1K1 x implies y inHIDDENR3 domRELAT-1K1 g & g .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y)"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 f & g =XBOOLE-0R4 curryFUNCT-5K1 f .FUNCT-1K1 x implies y inHIDDENR3 domRELAT-1K1 g & g .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    assume A1: "[TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 f"
      and A2: "g =XBOOLE-0R4 curryFUNCT-5K1 f .FUNCT-1K1 x"
    have "x inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 f)"
      using A1 xtuple_0_def_12 sorry
    then have A3: " ex h be FunctionFUNCT-1M1 st (curryFUNCT-5K1 f .FUNCT-1K1 x =XBOOLE-0R4 h & domRELAT-1K1 h =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :]))) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y))"
      using funct_5_def_1 sorry
    have "y inHIDDENR3 proj2XTUPLE-0K13 (domRELAT-1K1 f)"
      using A1 xtuple_0_def_13 sorry
    then have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :]"
      using zfmisc_1_th_105 sorry
    then have "[TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :])"
      using A1 xboole_0_def_4 sorry
    thus "y inHIDDENR3 domRELAT-1K1 g"
      using A2 A3 xtuple_0_def_13 sorry
    thus "g .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y)"
      using A2 A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_cl_2:
  mlet "f be FunctionFUNCT-1M1"
"cluster curry'FUNCT-5K3 f as-term-is Function-yieldingFUNCOP-1V1"
proof
(*coherence*)
  show "curry'FUNCT-5K3 f be Function-yieldingFUNCOP-1V1"
     sorry
qed "sorry"

mtheorem funct_5_th_21:
" for f be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 f implies y inHIDDENR3 domRELAT-1K1 (curry'FUNCT-5K3 f)"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 f implies y inHIDDENR3 domRELAT-1K1 (curry'FUNCT-5K3 f)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    assume "[TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 f"
    then have "[TARSKIK4 y,x ] inHIDDENR3 domRELAT-1K1 (~FUNCT-4K2 f)"
      using funct_4_th_42 sorry
    then have "y inHIDDENR3 domRELAT-1K1 (curry'FUNCT-5K3 f)"
      using funct_5_th_19 sorry
    thus "y inHIDDENR3 domRELAT-1K1 (curry'FUNCT-5K3 f)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_22:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 f & g =XBOOLE-0R4 curry'FUNCT-5K3 f .FUNCT-1K1 y implies x inHIDDENR3 domRELAT-1K1 g & g .FUNCT-1K1 x =XBOOLE-0R4 f .BINOP-1K1(x,y)"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 f implies (g =XBOOLE-0R4 curry'FUNCT-5K3 f .FUNCT-1K1 y implies x inHIDDENR3 domRELAT-1K1 g & g .FUNCT-1K1 x =XBOOLE-0R4 f .BINOP-1K1(x,y))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    assume "[TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 f"
    then have A1: "[TARSKIK4 y,x ] inHIDDENR3 domRELAT-1K1 (~FUNCT-4K2 f)"
      using funct_4_th_42 sorry
    assume A2: "g =XBOOLE-0R4 curry'FUNCT-5K3 f .FUNCT-1K1 y"
    then have "g .FUNCT-1K1 x =XBOOLE-0R4 ~FUNCT-4K2 f .BINOP-1K1(y,x)"
      using A1 funct_5_th_20 sorry
    thus "x inHIDDENR3 domRELAT-1K1 g & g .FUNCT-1K1 x =XBOOLE-0R4 f .BINOP-1K1(x,y)"
      using A1 A2 funct_5_th_20 funct_4_th_43 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_23:
" for f be FunctionFUNCT-1M1 holds domRELAT-1K1 (curry'FUNCT-5K3 f) =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 f)"
proof-
  have " for f be FunctionFUNCT-1M1 holds domRELAT-1K1 (curry'FUNCT-5K3 f) =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 f)"
  proof(rule ballI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have "domRELAT-1K1 (curryFUNCT-5K1 (~FUNCT-4K2 f)) =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 (~FUNCT-4K2 f))"
      using funct_5_def_1 sorry
    thus "domRELAT-1K1 (curry'FUNCT-5K3 f) =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 f)"
      using funct_5_th_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_24:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds [:ZFMISC-1K2 X,Y :] <>HIDDENR2 {}XBOOLE-0K1 & domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] implies domRELAT-1K1 (curryFUNCT-5K1 f) =XBOOLE-0R4 X & domRELAT-1K1 (curry'FUNCT-5K3 f) =XBOOLE-0R4 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds [:ZFMISC-1K2 X,Y :] <>HIDDENR2 {}XBOOLE-0K1 & domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] implies domRELAT-1K1 (curryFUNCT-5K1 f) =XBOOLE-0R4 X & domRELAT-1K1 (curry'FUNCT-5K3 f) =HIDDENR1 Y"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "[:ZFMISC-1K2 X,Y :] <>HIDDENR2 {}XBOOLE-0K1"
      and A2: "domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]"
    have "domRELAT-1K1 (curryFUNCT-5K1 f) =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 f)"
      using funct_5_def_1 sorry
    thus "domRELAT-1K1 (curryFUNCT-5K1 f) =XBOOLE-0R4 X"
      using A1 A2 funct_5_th_9 sorry
    have "domRELAT-1K1 (curry'FUNCT-5K3 f) =HIDDENR1 proj1XTUPLE-0K12 (domRELAT-1K1 (~FUNCT-4K2 f))"
      using funct_5_def_1 sorry
    also have "... = proj1XTUPLE-0K12 ([:ZFMISC-1K2 Y,X :])"
      using A2 funct_4_th_46 sorry
    also have "... = Y"
      using A1 funct_5_th_9 sorry
    finally show "domRELAT-1K1 (curry'FUNCT-5K3 f) =HIDDENR1 Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_25:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds domRELAT-1K1 f c=TARSKIR1 [:ZFMISC-1K2 X,Y :] implies domRELAT-1K1 (curryFUNCT-5K1 f) c=TARSKIR1 X & domRELAT-1K1 (curry'FUNCT-5K3 f) c=TARSKIR1 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds domRELAT-1K1 f c=TARSKIR1 [:ZFMISC-1K2 X,Y :] implies domRELAT-1K1 (curryFUNCT-5K1 f) c=TARSKIR1 X & domRELAT-1K1 (curry'FUNCT-5K3 f) c=TARSKIR1 Y"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "domRELAT-1K1 f c=TARSKIR1 [:ZFMISC-1K2 X,Y :]"
    have "domRELAT-1K1 (curryFUNCT-5K1 f) =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 f)"
      using funct_5_def_1 sorry
    thus "domRELAT-1K1 (curryFUNCT-5K1 f) c=TARSKIR1 X"
      using A1 funct_5_th_11 sorry
    have A2: "domRELAT-1K1 (curry'FUNCT-5K3 f) =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 (~FUNCT-4K2 f))"
      using funct_5_def_1 sorry
    have "domRELAT-1K1 (~FUNCT-4K2 f) c=TARSKIR1 [:ZFMISC-1K2 Y,X :]"
      using A1 funct_4_th_45 sorry
    thus "domRELAT-1K1 (curry'FUNCT-5K3 f) c=TARSKIR1 Y"
      using A2 funct_5_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_26:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds rngFUNCT-1K2 f c=TARSKIR1 FuncsFUNCT-2K1(X,Y) implies domRELAT-1K1 (uncurryFUNCT-5K2 f) =XBOOLE-0R4 [:ZFMISC-1K2 domRELAT-1K1 f,X :] & domRELAT-1K1 (uncurry'FUNCT-5K4 f) =XBOOLE-0R4 [:ZFMISC-1K2 X,domRELAT-1K1 f :]"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds rngFUNCT-1K2 f c=TARSKIR1 FuncsFUNCT-2K1(X,Y) implies domRELAT-1K1 (uncurryFUNCT-5K2 f) =XBOOLE-0R4 [:ZFMISC-1K2 domRELAT-1K1 f,X :] & domRELAT-1K1 (uncurry'FUNCT-5K4 f) =XBOOLE-0R4 [:ZFMISC-1K2 X,domRELAT-1K1 f :]"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    let ?P = "\<lambda>Lamb1.  ex x be objectHIDDENM1 st  ex g be FunctionFUNCT-1M1 st  ex y be objectHIDDENM1 st ((Lamb1 =HIDDENR1 [TARSKIK4 x,y ] & x inHIDDENR3 domRELAT-1K1 f) & g =XBOOLE-0R4 f .FUNCT-1K1 x) & y inHIDDENR3 domRELAT-1K1 g"
    assume A1: "rngFUNCT-1K2 f c=TARSKIR1 FuncsFUNCT-2K1(X,Y)"
    have A2: " for t be objectHIDDENM1 holds t inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 f,X :] iff ?P(t)"
    proof-
      have " for t be objectHIDDENM1 holds (t inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 f,X :] implies ( ex x be objectHIDDENM1 st  ex g be FunctionFUNCT-1M1 st  ex y be objectHIDDENM1 st ((t =HIDDENR1 [TARSKIK4 x,y ] & x inHIDDENR3 domRELAT-1K1 f) & g =XBOOLE-0R4 f .FUNCT-1K1 x) & y inHIDDENR3 domRELAT-1K1 g)) & (( ex x be objectHIDDENM1 st  ex g be FunctionFUNCT-1M1 st  ex y be objectHIDDENM1 st ((t =HIDDENR1 [TARSKIK4 x,y ] & x inHIDDENR3 domRELAT-1K1 f) & g =XBOOLE-0R4 f .FUNCT-1K1 x) & y inHIDDENR3 domRELAT-1K1 g) implies t inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 f,X :])"
      proof(rule ballI,rule conjMI,rule impI)
        fix t assume [ty]: "t be objectHIDDENM1"
        show "t inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 f,X :] implies ( ex x be objectHIDDENM1 st  ex g be FunctionFUNCT-1M1 st  ex y be objectHIDDENM1 st ((t =HIDDENR1 [TARSKIK4 x,y ] & x inHIDDENR3 domRELAT-1K1 f) & g =XBOOLE-0R4 f .FUNCT-1K1 x) & y inHIDDENR3 domRELAT-1K1 g)"
        proof-
          have "t inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 f,X :] implies ( ex tVar10 be objectHIDDENM1 st  ex tVar11 be FunctionFUNCT-1M1 st  ex tVar12 be objectHIDDENM1 st ((t =HIDDENR1 [TARSKIK4 tVar10,tVar12 ] & tVar10 inHIDDENR3 domRELAT-1K1 f) & tVar11 =XBOOLE-0R4 f .FUNCT-1K1 tVar10) & tVar12 inHIDDENR3 domRELAT-1K1 tVar11)"
          proof(rule impI)
            assume A3: "t inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 f,X :]"
            then have "t `1XTUPLE-0K1 inHIDDENR3 domRELAT-1K1 f"
              using mcart_1_th_10 sorry
            then have "f .FUNCT-1K1 t `1XTUPLE-0K1 inTARSKIR2 rngFUNCT-1K2 f"
              using funct_1_def_3 sorry
            then obtain g where
              [ty]:"g be FunctionFUNCT-1M1" and 
              A4: "f .FUNCT-1K1 t `1XTUPLE-0K1 =XBOOLE-0R4 g & domRELAT-1K1 g =XBOOLE-0R4 X"and "rngFUNCT-1K2 g c=TARSKIR1 Y"
              using A1 funct_2_def_2 sorry
            show " ex tVar10 be objectHIDDENM1 st  ex tVar11 be FunctionFUNCT-1M1 st  ex tVar12 be objectHIDDENM1 st ((t =HIDDENR1 [TARSKIK4 tVar10,tVar12 ] & tVar10 inHIDDENR3 domRELAT-1K1 f) & tVar11 =XBOOLE-0R4 f .FUNCT-1K1 tVar10) & tVar12 inHIDDENR3 domRELAT-1K1 tVar11"
            proof(rule bexI[of _ "t `1XTUPLE-0K1"])
              show " ex tVar11 be FunctionFUNCT-1M1 st  ex tVar12 be objectHIDDENM1 st ((t =HIDDENR1 [TARSKIK4 t `1XTUPLE-0K1,tVar12 ] & t `1XTUPLE-0K1 inHIDDENR3 domRELAT-1K1 f) & tVar11 =XBOOLE-0R4 f .FUNCT-1K1 t `1XTUPLE-0K1) & tVar12 inHIDDENR3 domRELAT-1K1 tVar11"
              proof(rule bexI[of _ "g"])
                show " ex tVar12 be objectHIDDENM1 st ((t =HIDDENR1 [TARSKIK4 t `1XTUPLE-0K1,tVar12 ] & t `1XTUPLE-0K1 inHIDDENR3 domRELAT-1K1 f) & g =XBOOLE-0R4 f .FUNCT-1K1 t `1XTUPLE-0K1) & tVar12 inHIDDENR3 domRELAT-1K1 g"
                proof(rule bexI[of _ "t `2XTUPLE-0K2"])
                  show "((t =HIDDENR1 [TARSKIK4 t `1XTUPLE-0K1,t `2XTUPLE-0K2 ] & t `1XTUPLE-0K1 inHIDDENR3 domRELAT-1K1 f) & g =XBOOLE-0R4 f .FUNCT-1K1 t `1XTUPLE-0K1) & t `2XTUPLE-0K2 inHIDDENR3 domRELAT-1K1 g"
                    using A3 A4 mcart_1_th_10 mcart_1_th_21 sorry
                qed "sorry"
              qed "sorry"
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
        assume Given: " ex x be objectHIDDENM1 st  ex g be FunctionFUNCT-1M1 st  ex y be objectHIDDENM1 st ((t =HIDDENR1 [TARSKIK4 x,y ] & x inHIDDENR3 domRELAT-1K1 f) & g =XBOOLE-0R4 f .FUNCT-1K1 x) & y inHIDDENR3 domRELAT-1K1 g"
        then obtain x g y where
          [ty]:"x be objectHIDDENM1" "g be FunctionFUNCT-1M1" "y be objectHIDDENM1" and 
          A5: "t =HIDDENR1 [TARSKIK4 x,y ]"and A6: "x inHIDDENR3 domRELAT-1K1 f"and A7: "g =XBOOLE-0R4 f .FUNCT-1K1 x"and A8: "y inHIDDENR3 domRELAT-1K1 g"
           sorry
        have "g inTARSKIR2 rngFUNCT-1K2 f"
          using A6 A7 funct_1_def_3 sorry
        then have " ex g1 be FunctionFUNCT-1M1 st (g =FUNCT-1R1 g1 & domRELAT-1K1 g1 =XBOOLE-0R4 X) & rngFUNCT-1K2 g1 c=TARSKIR1 Y"
          using A1 funct_2_def_2 sorry
        thus "t inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 f,X :]"
          using A5 A6 A8 zfmisc_1_th_87 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A9: " for t be objectHIDDENM1 holds t inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 f) iff ?P(t)"
      using funct_5_def_2 sorry
    show "domRELAT-1K1 (uncurryFUNCT-5K2 f) =XBOOLE-0R4 [:ZFMISC-1K2 domRELAT-1K1 f,X :]"
      using xboole_0_sch_2 A9 A2 sorry
    thus "domRELAT-1K1 (uncurry'FUNCT-5K4 f) =XBOOLE-0R4 [:ZFMISC-1K2 X,domRELAT-1K1 f :]"
      using funct_4_th_46 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_27:
" for f be FunctionFUNCT-1M1 holds  not ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 f) implies curryFUNCT-5K1 f =FUNCT-1R1 {}XBOOLE-0K1 & curry'FUNCT-5K3 f =FUNCT-1R1 {}XBOOLE-0K1"
proof-
  have " for f be FunctionFUNCT-1M1 holds  not ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 f) implies curryFUNCT-5K1 f =FUNCT-1R1 {}XBOOLE-0K1 & curry'FUNCT-5K3 f =FUNCT-1R1 {}XBOOLE-0K1"
  proof(rule ballI,rule impI,rule conjMI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: " not ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 f)"
    then have "proj1XTUPLE-0K12 (domRELAT-1K1 f) =XBOOLE-0R4 {}XBOOLE-0K1"
      using funct_5_th_14 sorry
    then have "domRELAT-1K1 (curryFUNCT-5K1 f) =XBOOLE-0R4 {}XBOOLE-0K1"
      using funct_5_def_1 sorry
    thus "curryFUNCT-5K1 f =FUNCT-1R1 {}XBOOLE-0K1"
       sorry
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 (~FUNCT-4K2 f) implies  False "
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "[TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 (~FUNCT-4K2 f)"
      then have "[TARSKIK4 y,x ] inHIDDENR3 domRELAT-1K1 f"
        using funct_4_th_42 sorry
      thus " False "
        using A1 sorry
    qed "sorry"
    then have "proj1XTUPLE-0K12 (domRELAT-1K1 (~FUNCT-4K2 f)) =XBOOLE-0R4 {}XBOOLE-0K1"
      using funct_5_th_14 sorry
    then have "domRELAT-1K1 (curryFUNCT-5K1 (~FUNCT-4K2 f)) =XBOOLE-0R4 {}XBOOLE-0K1"
      using funct_5_def_1 sorry
    thus "curry'FUNCT-5K3 f =FUNCT-1R1 {}XBOOLE-0K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_28:
" for f be FunctionFUNCT-1M1 holds  not ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x be FunctionFUNCT-1M1) implies uncurryFUNCT-5K2 f =FUNCT-1R1 {}XBOOLE-0K1 & uncurry'FUNCT-5K4 f =FUNCT-1R1 {}XBOOLE-0K1"
proof-
  have " for f be FunctionFUNCT-1M1 holds  not ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x be FunctionFUNCT-1M1) implies uncurryFUNCT-5K2 f =FUNCT-1R1 {}XBOOLE-0K1 & uncurry'FUNCT-5K4 f =FUNCT-1R1 {}XBOOLE-0K1"
  proof(rule ballI,rule impI,rule conjMI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: " not ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x be FunctionFUNCT-1M1)"
    have A2: "domRELAT-1K1 (uncurryFUNCT-5K2 f) <>HIDDENR2 {}XBOOLE-0K1 implies  False "
    proof(rule impI)
      let ?t = "the ElementSUBSET-1M1-of domRELAT-1K1 (uncurryFUNCT-5K2 f)"
      assume "domRELAT-1K1 (uncurryFUNCT-5K2 f) <>HIDDENR2 {}XBOOLE-0K1"
      then have " ex x be objectHIDDENM1 st  ex g be FunctionFUNCT-1M1 st  ex y be objectHIDDENM1 st ((?t =HIDDENR1 [TARSKIK4 x,y ] & x inHIDDENR3 domRELAT-1K1 f) & g =XBOOLE-0R4 f .FUNCT-1K1 x) & y inHIDDENR3 domRELAT-1K1 g"
        using funct_5_def_2 sorry
      thus " False "
        using A1 sorry
    qed
    thus "uncurryFUNCT-5K2 f =FUNCT-1R1 {}XBOOLE-0K1"
       sorry
    show "uncurry'FUNCT-5K4 f =FUNCT-1R1 {}XBOOLE-0K1"
      using A2 funct_5_th_1 relat_1_th_41 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_29:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds ([:ZFMISC-1K2 X,Y :] <>HIDDENR2 {}XBOOLE-0K1 & domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]) & x inHIDDENR3 X implies ( ex g be FunctionFUNCT-1M1 st ((curryFUNCT-5K1 f .FUNCT-1K1 x =XBOOLE-0R4 g & domRELAT-1K1 g =XBOOLE-0R4 Y) & rngFUNCT-1K2 g c=TARSKIR1 rngFUNCT-1K2 f) & ( for y be objectHIDDENM1 holds y inHIDDENR3 Y implies g .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y)))"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds [:ZFMISC-1K2 X,Y :] <>HIDDENR2 {}XBOOLE-0K1 & (domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & x inHIDDENR3 X) implies ( ex tVar13 be FunctionFUNCT-1M1 st ((curryFUNCT-5K1 f .FUNCT-1K1 x =XBOOLE-0R4 tVar13 & domRELAT-1K1 tVar13 =XBOOLE-0R4 Y) & rngFUNCT-1K2 tVar13 c=TARSKIR1 rngFUNCT-1K2 f) & ( for y be objectHIDDENM1 holds  not (y inHIDDENR3 Y &  not tVar13 .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y))))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "[:ZFMISC-1K2 X,Y :] <>HIDDENR2 {}XBOOLE-0K1"
      and A2: "domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]"
      and A3: "x inHIDDENR3 X"
    have "{TARSKIK1 x} c=TARSKIR1 X"
      using A3 zfmisc_1_th_31 sorry
    then have A4: "([:ZFMISC-1K2 {TARSKIK1 x},Y :])/\\XBOOLE-0K3 domRELAT-1K1 f =RELAT-1R1 [:ZFMISC-1K2 {TARSKIK1 x},Y :]"
      using A2 zfmisc_1_th_101 sorry
    have "x inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 f)"
      using A1 A2 A3 funct_5_th_9 sorry
    then obtain g where
      [ty]:"g be FunctionFUNCT-1M1" and 
      A5: "curryFUNCT-5K1 f .FUNCT-1K1 x =XBOOLE-0R4 g"and A6: "domRELAT-1K1 g =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :])) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y))"
      using funct_5_def_1 sorry
    show " ex tVar13 be FunctionFUNCT-1M1 st ((curryFUNCT-5K1 f .FUNCT-1K1 x =XBOOLE-0R4 tVar13 & domRELAT-1K1 tVar13 =XBOOLE-0R4 Y) & rngFUNCT-1K2 tVar13 c=TARSKIR1 rngFUNCT-1K2 f) & ( for y be objectHIDDENM1 holds  not (y inHIDDENR3 Y &  not tVar13 .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y)))"
    proof(rule bexI[of _ "g"])
      have A7: "proj2XTUPLE-0K13 ([:ZFMISC-1K2 {TARSKIK1 x},Y :]) =XBOOLE-0R4 Y"
        using funct_5_th_9 sorry
      have A8: "proj2XTUPLE-0K13 (domRELAT-1K1 f) =XBOOLE-0R4 Y"
        using A2 A3 funct_5_th_9 sorry
      have "rngFUNCT-1K2 g c=TARSKIR1 rngFUNCT-1K2 f"
      proof-
        have " for z be objectHIDDENM1 holds z inHIDDENR3 rngFUNCT-1K2 g implies z inHIDDENR3 rngFUNCT-1K2 f"
        proof(rule ballI,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          assume "z inHIDDENR3 rngFUNCT-1K2 g"
          then obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A9: "y inHIDDENR3 domRELAT-1K1 g & z =HIDDENR1 g .FUNCT-1K1 y"
            using funct_1_def_3 sorry
          have "[TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 f & z =HIDDENR1 f .BINOP-1K1(x,y)"
            using A2 A3 A6 A8 A4 A7 A9 zfmisc_1_th_87 sorry
          thus "z inHIDDENR3 rngFUNCT-1K2 f"
            using funct_1_def_3 sorry
        qed "sorry"
        thus "rngFUNCT-1K2 g c=TARSKIR1 rngFUNCT-1K2 f"
          using tarski_def_3 sorry
      qed
      thus "((curryFUNCT-5K1 f .FUNCT-1K1 x =XBOOLE-0R4 g & domRELAT-1K1 g =XBOOLE-0R4 Y) & rngFUNCT-1K2 g c=TARSKIR1 rngFUNCT-1K2 f) & ( for y be objectHIDDENM1 holds  not (y inHIDDENR3 Y &  not g .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y)))"
        using A5 A6 A8 A4 A7 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_30:
" for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 (curryFUNCT-5K1 f) implies curryFUNCT-5K1 f .FUNCT-1K1 x be FunctionFUNCT-1M1"
proof-
  have " for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 (curryFUNCT-5K1 f) implies curryFUNCT-5K1 f .FUNCT-1K1 x be FunctionFUNCT-1M1"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "x inHIDDENR3 domRELAT-1K1 (curryFUNCT-5K1 f)"
    have "domRELAT-1K1 (curryFUNCT-5K1 f) =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 f)"
      using funct_5_def_1 sorry
    then have " ex g be FunctionFUNCT-1M1 st (curryFUNCT-5K1 f .FUNCT-1K1 x =XBOOLE-0R4 g & domRELAT-1K1 g =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :]))) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y))"
      using A1 funct_5_def_1 sorry
    thus "curryFUNCT-5K1 f .FUNCT-1K1 x be FunctionFUNCT-1M1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_31:
" for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 (curryFUNCT-5K1 f) & g =XBOOLE-0R4 curryFUNCT-5K1 f .FUNCT-1K1 x implies ((domRELAT-1K1 g =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :])) & domRELAT-1K1 g c=TARSKIR1 proj2XTUPLE-0K13 (domRELAT-1K1 f)) & rngFUNCT-1K2 g c=TARSKIR1 rngFUNCT-1K2 f) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y) & [TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 f)"
proof-
  have " for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 (curryFUNCT-5K1 f) & g =XBOOLE-0R4 curryFUNCT-5K1 f .FUNCT-1K1 x implies domRELAT-1K1 g =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :])) & (domRELAT-1K1 g c=TARSKIR1 proj2XTUPLE-0K13 (domRELAT-1K1 f) & (rngFUNCT-1K2 g c=TARSKIR1 rngFUNCT-1K2 f & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y) & [TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 f)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule conjMI,rule conjMI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "x inHIDDENR3 domRELAT-1K1 (curryFUNCT-5K1 f)"
      and A2: "g =XBOOLE-0R4 curryFUNCT-5K1 f .FUNCT-1K1 x"
    have "domRELAT-1K1 (curryFUNCT-5K1 f) =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 f)"
      using funct_5_def_1 sorry
    then obtain h where
      [ty]:"h be FunctionFUNCT-1M1" and 
      A3: "curryFUNCT-5K1 f .FUNCT-1K1 x =XBOOLE-0R4 h"and A4: "domRELAT-1K1 h =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :]))"and A5: " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y)"
      using A1 funct_5_def_1 sorry
    show "domRELAT-1K1 g =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :]))"
      using A2 A3 A4 sorry
    have "domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :]) c=RELAT-1R2 domRELAT-1K1 f"
      using xboole_1_th_17 sorry
    thus "domRELAT-1K1 g c=TARSKIR1 proj2XTUPLE-0K13 (domRELAT-1K1 f)"
      using A2 A3 A4 xtuple_0_th_9 sorry
    show "rngFUNCT-1K2 g c=TARSKIR1 rngFUNCT-1K2 f"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 g implies y inHIDDENR3 rngFUNCT-1K2 f"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 rngFUNCT-1K2 g"
        then obtain z where
          [ty]:"z be objectHIDDENM1" and 
          A6: "z inHIDDENR3 domRELAT-1K1 g"and A7: "y =HIDDENR1 g .FUNCT-1K1 z"
          using funct_1_def_3 sorry
        obtain t where
          [ty]:"t be objectHIDDENM1" and 
          A8: "[TARSKIK4 t,z ] inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :])"
          using A2 A3 A4 A6 xtuple_0_def_13 sorry
        have "[TARSKIK4 t,z ] inHIDDENR3 domRELAT-1K1 f & [TARSKIK4 t,z ] inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :]"
          using A8 xboole_0_def_4 sorry
        then have A9: "[TARSKIK4 x,z ] inHIDDENR3 domRELAT-1K1 f"
          using zfmisc_1_th_105 sorry
        have "h .FUNCT-1K1 z =XBOOLE-0R4 f .BINOP-1K1(x,z)"
          using A2 A3 A5 A6 sorry
        thus "y inHIDDENR3 rngFUNCT-1K2 f"
          using A2 A3 A7 A9 funct_1_def_3 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 g c=TARSKIR1 rngFUNCT-1K2 f"
        using tarski_def_3 sorry
    qed
    fix y assume [ty]: "y be objectHIDDENM1"
    assume A10: "y inHIDDENR3 domRELAT-1K1 g"
    then obtain t where
      [ty]:"t be objectHIDDENM1" and 
      A11: "[TARSKIK4 t,y ] inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :])"
      using A2 A3 A4 xtuple_0_def_13 sorry
    have "[TARSKIK4 t,y ] inHIDDENR3 domRELAT-1K1 f & [TARSKIK4 t,y ] inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :]"
      using A11 xboole_0_def_4 sorry
    thus "g .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y) & [TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 f"
      using A2 A3 A5 A10 zfmisc_1_th_105 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_32:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for y be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds ([:ZFMISC-1K2 X,Y :] <>HIDDENR2 {}XBOOLE-0K1 & domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]) & y inHIDDENR3 Y implies ( ex g be FunctionFUNCT-1M1 st ((curry'FUNCT-5K3 f .FUNCT-1K1 y =XBOOLE-0R4 g & domRELAT-1K1 g =XBOOLE-0R4 X) & rngFUNCT-1K2 g c=TARSKIR1 rngFUNCT-1K2 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies g .FUNCT-1K1 x =XBOOLE-0R4 f .BINOP-1K1(x,y)))"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for y be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds [:ZFMISC-1K2 X,Y :] <>HIDDENR2 {}XBOOLE-0K1 & (domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & y inHIDDENR3 Y) implies ( ex tVar14 be FunctionFUNCT-1M1 st ((curry'FUNCT-5K3 f .FUNCT-1K1 y =XBOOLE-0R4 tVar14 & domRELAT-1K1 tVar14 =XBOOLE-0R4 X) & rngFUNCT-1K2 tVar14 c=TARSKIR1 rngFUNCT-1K2 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies tVar14 .FUNCT-1K1 x =XBOOLE-0R4 f .BINOP-1K1(x,y)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "[:ZFMISC-1K2 X,Y :] <>HIDDENR2 {}XBOOLE-0K1"
      and A2: "domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]"
      and A3: "y inHIDDENR3 Y"
    have A4: "domRELAT-1K1 (~FUNCT-4K2 f) =XBOOLE-0R4 [:ZFMISC-1K2 Y,X :]"
      using A2 funct_4_th_46 sorry
    have "X <>HIDDENR2 {}XBOOLE-0K1"
      using A1 zfmisc_1_th_90 sorry
    then obtain g where
      [ty]:"g be FunctionFUNCT-1M1" and 
      A5: "(curryFUNCT-5K1 (~FUNCT-4K2 f) .FUNCT-1K1 y =XBOOLE-0R4 g & domRELAT-1K1 g =XBOOLE-0R4 X) & rngFUNCT-1K2 g c=TARSKIR1 rngFUNCT-1K2 (~FUNCT-4K2 f)"and A6: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies g .FUNCT-1K1 x =XBOOLE-0R4 ~FUNCT-4K2 f .BINOP-1K1(y,x)"
      using A3 A4 funct_5_th_29 sorry
    show " ex tVar14 be FunctionFUNCT-1M1 st ((curry'FUNCT-5K3 f .FUNCT-1K1 y =XBOOLE-0R4 tVar14 & domRELAT-1K1 tVar14 =XBOOLE-0R4 X) & rngFUNCT-1K2 tVar14 c=TARSKIR1 rngFUNCT-1K2 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies tVar14 .FUNCT-1K1 x =XBOOLE-0R4 f .BINOP-1K1(x,y))"
    proof(rule bexI[of _ "g"],rule conjMI,rule ballI,rule impI)
      have "rngFUNCT-1K2 (~FUNCT-4K2 f) c=TARSKIR1 rngFUNCT-1K2 f"
        using funct_4_th_41 sorry
      thus "(curry'FUNCT-5K3 f .FUNCT-1K1 y =XBOOLE-0R4 g & domRELAT-1K1 g =XBOOLE-0R4 X) & rngFUNCT-1K2 g c=TARSKIR1 rngFUNCT-1K2 f"
        using A5 sorry
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A7: "x inHIDDENR3 X"
      then have A8: "g .FUNCT-1K1 x =XBOOLE-0R4 ~FUNCT-4K2 f .BINOP-1K1(y,x)"
        using A6 sorry
      have "[TARSKIK4 y,x ] inHIDDENR3 domRELAT-1K1 (~FUNCT-4K2 f)"
        using A3 A4 A7 zfmisc_1_th_87 sorry
      thus "g .FUNCT-1K1 x =XBOOLE-0R4 f .BINOP-1K1(x,y)"
        using A8 funct_4_th_43 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_33:
" for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 (curry'FUNCT-5K3 f) implies curry'FUNCT-5K3 f .FUNCT-1K1 x be FunctionFUNCT-1M1"
  using funct_5_th_30 sorry

mtheorem funct_5_th_34:
" for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 (curry'FUNCT-5K3 f) & g =XBOOLE-0R4 curry'FUNCT-5K3 f .FUNCT-1K1 x implies ((domRELAT-1K1 g =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 proj1XTUPLE-0K12 (domRELAT-1K1 f),{TARSKIK1 x} :])) & domRELAT-1K1 g c=TARSKIR1 proj1XTUPLE-0K12 (domRELAT-1K1 f)) & rngFUNCT-1K2 g c=TARSKIR1 rngFUNCT-1K2 f) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(y,x) & [TARSKIK4 y,x ] inHIDDENR3 domRELAT-1K1 f)"
proof-
  have " for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 (curry'FUNCT-5K3 f) & g =XBOOLE-0R4 curry'FUNCT-5K3 f .FUNCT-1K1 x implies ((domRELAT-1K1 g =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 proj1XTUPLE-0K12 (domRELAT-1K1 f),{TARSKIK1 x} :])) & domRELAT-1K1 g c=TARSKIR1 proj1XTUPLE-0K12 (domRELAT-1K1 f)) & rngFUNCT-1K2 g c=TARSKIR1 rngFUNCT-1K2 f) & ( for y be objectHIDDENM1 holds  not (y inHIDDENR3 domRELAT-1K1 g &  not (g .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(y,x) & [TARSKIK4 y,x ] inHIDDENR3 domRELAT-1K1 f)))"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    have A1: "rngFUNCT-1K2 (~FUNCT-4K2 f) c=TARSKIR1 rngFUNCT-1K2 f"
      using funct_4_th_41 sorry
    assume A2: "x inHIDDENR3 domRELAT-1K1 (curry'FUNCT-5K3 f) & g =XBOOLE-0R4 curry'FUNCT-5K3 f .FUNCT-1K1 x"
    then have "domRELAT-1K1 g =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 (~FUNCT-4K2 f) /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 (~FUNCT-4K2 f)) :]))"
      using funct_5_th_31 sorry
    then have A3: "domRELAT-1K1 g =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 (~FUNCT-4K2 f) /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj1XTUPLE-0K12 (domRELAT-1K1 f) :]))"
      using funct_5_th_17 sorry
    have "domRELAT-1K1 g c=TARSKIR1 proj1XTUPLE-0K12 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 proj1XTUPLE-0K12 (domRELAT-1K1 f),{TARSKIK1 x} :])) & (proj1XTUPLE-0K12 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 proj1XTUPLE-0K12 (domRELAT-1K1 f),{TARSKIK1 x} :])) c=TARSKIR1 domRELAT-1K1 g & ((domRELAT-1K1 g c=TARSKIR1 proj1XTUPLE-0K12 (domRELAT-1K1 f) & rngFUNCT-1K2 g c=TARSKIR1 rngFUNCT-1K2 f) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(y,x) & [TARSKIK4 y,x ] inHIDDENR3 domRELAT-1K1 f)))"
    proof(rule conjMI,rule conjMI,rule conjMI,rule ballI,rule impI)
      show A4: "domRELAT-1K1 g c=TARSKIR1 proj1XTUPLE-0K12 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 proj1XTUPLE-0K12 (domRELAT-1K1 f),{TARSKIK1 x} :]))"
      proof-
        have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 g implies z inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 proj1XTUPLE-0K12 (domRELAT-1K1 f),{TARSKIK1 x} :]))"
        proof(rule ballI,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          assume "z inHIDDENR3 domRELAT-1K1 g"
          then obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A5: "[TARSKIK4 y,z ] inHIDDENR3 domRELAT-1K1 (~FUNCT-4K2 f) /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj1XTUPLE-0K12 (domRELAT-1K1 f) :])"
            using A3 xtuple_0_def_13 sorry
          have "[TARSKIK4 y,z ] inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 x},proj1XTUPLE-0K12 (domRELAT-1K1 f) :]"
            using A5 xboole_0_def_4 sorry
          then have A6: "[TARSKIK4 z,y ] inHIDDENR3 [:ZFMISC-1K2 proj1XTUPLE-0K12 (domRELAT-1K1 f),{TARSKIK1 x} :]"
            using zfmisc_1_th_88 sorry
          have "[TARSKIK4 y,z ] inHIDDENR3 domRELAT-1K1 (~FUNCT-4K2 f)"
            using A5 xboole_0_def_4 sorry
          then have "[TARSKIK4 z,y ] inHIDDENR3 domRELAT-1K1 f"
            using funct_4_th_42 sorry
          then have "[TARSKIK4 z,y ] inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 proj1XTUPLE-0K12 (domRELAT-1K1 f),{TARSKIK1 x} :])"
            using A6 xboole_0_def_4 sorry
          thus "z inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 proj1XTUPLE-0K12 (domRELAT-1K1 f),{TARSKIK1 x} :]))"
            using xtuple_0_def_12 sorry
        qed "sorry"
        thus "domRELAT-1K1 g c=TARSKIR1 proj1XTUPLE-0K12 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 proj1XTUPLE-0K12 (domRELAT-1K1 f),{TARSKIK1 x} :]))"
          using tarski_def_3 sorry
      qed
      show "proj1XTUPLE-0K12 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 proj1XTUPLE-0K12 (domRELAT-1K1 f),{TARSKIK1 x} :])) c=TARSKIR1 domRELAT-1K1 g"
      proof-
        have " for z be objectHIDDENM1 holds z inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 proj1XTUPLE-0K12 (domRELAT-1K1 f),{TARSKIK1 x} :])) implies z inHIDDENR3 domRELAT-1K1 g"
        proof(rule ballI,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          assume "z inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 proj1XTUPLE-0K12 (domRELAT-1K1 f),{TARSKIK1 x} :]))"
          then obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A7: "[TARSKIK4 z,y ] inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 proj1XTUPLE-0K12 (domRELAT-1K1 f),{TARSKIK1 x} :])"
            using xtuple_0_def_12 sorry
          have "[TARSKIK4 z,y ] inHIDDENR3 [:ZFMISC-1K2 proj1XTUPLE-0K12 (domRELAT-1K1 f),{TARSKIK1 x} :]"
            using A7 xboole_0_def_4 sorry
          then have A8: "[TARSKIK4 y,z ] inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 x},proj1XTUPLE-0K12 (domRELAT-1K1 f) :]"
            using zfmisc_1_th_88 sorry
          have "[TARSKIK4 z,y ] inHIDDENR3 domRELAT-1K1 f"
            using A7 xboole_0_def_4 sorry
          then have "[TARSKIK4 y,z ] inHIDDENR3 domRELAT-1K1 (~FUNCT-4K2 f)"
            using funct_4_th_42 sorry
          then have "[TARSKIK4 y,z ] inHIDDENR3 domRELAT-1K1 (~FUNCT-4K2 f) /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj1XTUPLE-0K12 (domRELAT-1K1 f) :])"
            using A8 xboole_0_def_4 sorry
          thus "z inHIDDENR3 domRELAT-1K1 g"
            using A3 xtuple_0_def_13 sorry
        qed "sorry"
        thus "proj1XTUPLE-0K12 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 proj1XTUPLE-0K12 (domRELAT-1K1 f),{TARSKIK1 x} :])) c=TARSKIR1 domRELAT-1K1 g"
          using tarski_def_3 sorry
      qed
      have "domRELAT-1K1 g c=TARSKIR1 proj2XTUPLE-0K13 (domRELAT-1K1 (~FUNCT-4K2 f)) & rngFUNCT-1K2 g c=TARSKIR1 rngFUNCT-1K2 (~FUNCT-4K2 f)"
        using A2 funct_5_th_31 sorry
      thus "domRELAT-1K1 g c=TARSKIR1 proj1XTUPLE-0K12 (domRELAT-1K1 f) & rngFUNCT-1K2 g c=TARSKIR1 rngFUNCT-1K2 f"
        using A1 funct_5_th_17 sorry
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A9: "y inHIDDENR3 domRELAT-1K1 g"
      then obtain z where
        [ty]:"z be objectHIDDENM1" and 
        A10: "[TARSKIK4 y,z ] inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 proj1XTUPLE-0K12 (domRELAT-1K1 f),{TARSKIK1 x} :])"
        using A4 xtuple_0_def_12 sorry
      have "[TARSKIK4 y,z ] inHIDDENR3 [:ZFMISC-1K2 proj1XTUPLE-0K12 (domRELAT-1K1 f),{TARSKIK1 x} :]"
        using A10 xboole_0_def_4 sorry
      then have A11: "z =HIDDENR1 x"
        using zfmisc_1_th_106 sorry
      have "[TARSKIK4 y,z ] inHIDDENR3 domRELAT-1K1 f"
        using A10 xboole_0_def_4 sorry
      then have "[TARSKIK4 z,y ] inHIDDENR3 domRELAT-1K1 (~FUNCT-4K2 f)"
        using funct_4_th_42 sorry
      then have "~FUNCT-4K2 f .BINOP-1K1(x,y) =XBOOLE-0R4 f .BINOP-1K1(y,x)"
        using A11 funct_4_th_43 sorry
      thus "g .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(y,x) & [TARSKIK4 y,x ] inHIDDENR3 domRELAT-1K1 f"
        using A2 A9 A10 A11 funct_5_th_31 xboole_0_def_4 sorry
    qed "sorry"
    thus "((domRELAT-1K1 g =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 proj1XTUPLE-0K12 (domRELAT-1K1 f),{TARSKIK1 x} :])) & domRELAT-1K1 g c=TARSKIR1 proj1XTUPLE-0K12 (domRELAT-1K1 f)) & rngFUNCT-1K2 g c=TARSKIR1 rngFUNCT-1K2 f) & ( for y be objectHIDDENM1 holds  not (y inHIDDENR3 domRELAT-1K1 g &  not (g .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(y,x) & [TARSKIK4 y,x ] inHIDDENR3 domRELAT-1K1 f)))"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_35:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] implies rngFUNCT-1K2 (curryFUNCT-5K1 f) c=TARSKIR1 FuncsFUNCT-2K1(Y,rngFUNCT-1K2 f) & rngFUNCT-1K2 (curry'FUNCT-5K3 f) c=TARSKIR1 FuncsFUNCT-2K1(X,rngFUNCT-1K2 f)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] implies rngFUNCT-1K2 (curryFUNCT-5K1 f) c=TARSKIR1 FuncsFUNCT-2K1(Y,rngFUNCT-1K2 f) & rngFUNCT-1K2 (curry'FUNCT-5K3 f) c=TARSKIR1 FuncsFUNCT-2K1(X,rngFUNCT-1K2 f)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]"
    have A2: "[:ZFMISC-1K2 X,Y :] <>HIDDENR2 {}XBOOLE-0K1 implies rngFUNCT-1K2 (curryFUNCT-5K1 f) c=TARSKIR1 FuncsFUNCT-2K1(Y,rngFUNCT-1K2 f) & rngFUNCT-1K2 (curry'FUNCT-5K3 f) c=TARSKIR1 FuncsFUNCT-2K1(X,rngFUNCT-1K2 f)"
    proof(rule impI,rule conjMI)
      assume A3: "[:ZFMISC-1K2 X,Y :] <>HIDDENR2 {}XBOOLE-0K1"
      then have A4: "domRELAT-1K1 (curryFUNCT-5K1 f) =XBOOLE-0R4 X"
        using A1 funct_5_th_24 sorry
      show "rngFUNCT-1K2 (curryFUNCT-5K1 f) c=TARSKIR1 FuncsFUNCT-2K1(Y,rngFUNCT-1K2 f)"
      proof-
        have " for z be objectHIDDENM1 holds z inHIDDENR3 rngFUNCT-1K2 (curryFUNCT-5K1 f) implies z inHIDDENR3 FuncsFUNCT-2K1(Y,rngFUNCT-1K2 f)"
        proof(rule ballI,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          assume "z inHIDDENR3 rngFUNCT-1K2 (curryFUNCT-5K1 f)"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A5: "x inHIDDENR3 domRELAT-1K1 (curryFUNCT-5K1 f)"and A6: "z =HIDDENR1 curryFUNCT-5K1 f .FUNCT-1K1 x"
            using funct_1_def_3 sorry
          have " ex g be FunctionFUNCT-1M1 st ((curryFUNCT-5K1 f .FUNCT-1K1 x =XBOOLE-0R4 g & domRELAT-1K1 g =XBOOLE-0R4 Y) & rngFUNCT-1K2 g c=TARSKIR1 rngFUNCT-1K2 f) & ( for y be objectHIDDENM1 holds y inHIDDENR3 Y implies g .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y))"
            using A1 A3 A4 A5 funct_5_th_29 sorry
          thus "z inHIDDENR3 FuncsFUNCT-2K1(Y,rngFUNCT-1K2 f)"
            using A6 funct_2_def_2 sorry
        qed "sorry"
        thus "rngFUNCT-1K2 (curryFUNCT-5K1 f) c=TARSKIR1 FuncsFUNCT-2K1(Y,rngFUNCT-1K2 f)"
          using tarski_def_3 sorry
      qed
      have A7: "domRELAT-1K1 (curry'FUNCT-5K3 f) =XBOOLE-0R4 Y"
        using A1 A3 funct_5_th_24 sorry
      show "rngFUNCT-1K2 (curry'FUNCT-5K3 f) c=TARSKIR1 FuncsFUNCT-2K1(X,rngFUNCT-1K2 f)"
      proof-
        have " for z be objectHIDDENM1 holds z inHIDDENR3 rngFUNCT-1K2 (curry'FUNCT-5K3 f) implies z inHIDDENR3 FuncsFUNCT-2K1(X,rngFUNCT-1K2 f)"
        proof(rule ballI,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          assume "z inHIDDENR3 rngFUNCT-1K2 (curry'FUNCT-5K3 f)"
          then obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A8: "y inHIDDENR3 domRELAT-1K1 (curry'FUNCT-5K3 f)"and A9: "z =HIDDENR1 curry'FUNCT-5K3 f .FUNCT-1K1 y"
            using funct_1_def_3 sorry
          have " ex g be FunctionFUNCT-1M1 st ((curry'FUNCT-5K3 f .FUNCT-1K1 y =XBOOLE-0R4 g & domRELAT-1K1 g =XBOOLE-0R4 X) & rngFUNCT-1K2 g c=TARSKIR1 rngFUNCT-1K2 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies g .FUNCT-1K1 x =XBOOLE-0R4 f .BINOP-1K1(x,y))"
            using A1 A3 A7 A8 funct_5_th_32 sorry
          thus "z inHIDDENR3 FuncsFUNCT-2K1(X,rngFUNCT-1K2 f)"
            using A9 funct_2_def_2 sorry
        qed "sorry"
        thus "rngFUNCT-1K2 (curry'FUNCT-5K3 f) c=TARSKIR1 FuncsFUNCT-2K1(X,rngFUNCT-1K2 f)"
          using tarski_def_3 sorry
      qed
    qed
    have "domRELAT-1K1 f =XBOOLE-0R4 {}XBOOLE-0K1 implies rngFUNCT-1K2 (curryFUNCT-5K1 f) c=TARSKIR1 FuncsFUNCT-2K1(Y,rngFUNCT-1K2 f) & rngFUNCT-1K2 (curry'FUNCT-5K3 f) c=TARSKIR1 FuncsFUNCT-2K1(X,rngFUNCT-1K2 f)"
    proof(rule impI)
      assume A10: "domRELAT-1K1 f =XBOOLE-0R4 {}XBOOLE-0K1"
      then have "X =XBOOLE-0R4 {}XBOOLE-0K1 or Y =XBOOLE-0R4 {}XBOOLE-0K1"
        using A1 sorry
      then have A11: "[:ZFMISC-1K2 Y,X :] =RELAT-1R1 {}XBOOLE-0K1"
        using zfmisc_1_th_90 sorry
      have "{}XBOOLE-0K1 =XBOOLE-0R4 domRELAT-1K1 (curryFUNCT-5K1 f)"
        using A10 funct_5_def_1 funct_5_th_8 sorry
      then have A12: "rngFUNCT-1K2 (curryFUNCT-5K1 f) =XBOOLE-0R4 {}XBOOLE-0K1"
        using relat_1_th_42 sorry
      have "domRELAT-1K1 (~FUNCT-4K2 f) =XBOOLE-0R4 [:ZFMISC-1K2 Y,X :] & domRELAT-1K1 (curryFUNCT-5K1 (~FUNCT-4K2 f)) =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 (~FUNCT-4K2 f))"
        using A1 funct_5_def_1 funct_4_th_46 sorry
      then have "rngFUNCT-1K2 (curry'FUNCT-5K3 f) =XBOOLE-0R4 {}XBOOLE-0K1"
        using A11 funct_5_th_8 relat_1_th_42 sorry
      thus "rngFUNCT-1K2 (curryFUNCT-5K1 f) c=TARSKIR1 FuncsFUNCT-2K1(Y,rngFUNCT-1K2 f) & rngFUNCT-1K2 (curry'FUNCT-5K3 f) c=TARSKIR1 FuncsFUNCT-2K1(X,rngFUNCT-1K2 f)"
        using A12 sorry
    qed
    thus "rngFUNCT-1K2 (curryFUNCT-5K1 f) c=TARSKIR1 FuncsFUNCT-2K1(Y,rngFUNCT-1K2 f) & rngFUNCT-1K2 (curry'FUNCT-5K3 f) c=TARSKIR1 FuncsFUNCT-2K1(X,rngFUNCT-1K2 f)"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_36:
" for f be FunctionFUNCT-1M1 holds rngFUNCT-1K2 (curryFUNCT-5K1 f) c=TARSKIR1 PFuncsPARTFUN1K4(proj2XTUPLE-0K13 (domRELAT-1K1 f),rngFUNCT-1K2 f) & rngFUNCT-1K2 (curry'FUNCT-5K3 f) c=TARSKIR1 PFuncsPARTFUN1K4(proj1XTUPLE-0K12 (domRELAT-1K1 f),rngFUNCT-1K2 f)"
proof-
  have " for f be FunctionFUNCT-1M1 holds rngFUNCT-1K2 (curryFUNCT-5K1 f) c=TARSKIR1 PFuncsPARTFUN1K4(proj2XTUPLE-0K13 (domRELAT-1K1 f),rngFUNCT-1K2 f) & rngFUNCT-1K2 (curry'FUNCT-5K3 f) c=TARSKIR1 PFuncsPARTFUN1K4(proj1XTUPLE-0K12 (domRELAT-1K1 f),rngFUNCT-1K2 f)"
  proof(rule ballI,rule conjMI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have A1: "rngFUNCT-1K2 (~FUNCT-4K2 f) c=TARSKIR1 rngFUNCT-1K2 f"
      using funct_4_th_41 sorry
    show "rngFUNCT-1K2 (curryFUNCT-5K1 f) c=TARSKIR1 PFuncsPARTFUN1K4(proj2XTUPLE-0K13 (domRELAT-1K1 f),rngFUNCT-1K2 f)"
    proof-
      have " for t be objectHIDDENM1 holds t inHIDDENR3 rngFUNCT-1K2 (curryFUNCT-5K1 f) implies t inHIDDENR3 PFuncsPARTFUN1K4(proj2XTUPLE-0K13 (domRELAT-1K1 f),rngFUNCT-1K2 f)"
      proof(rule ballI,rule impI)
        fix t assume [ty]: "t be objectHIDDENM1"
        assume "t inHIDDENR3 rngFUNCT-1K2 (curryFUNCT-5K1 f)"
        then obtain z where
          [ty]:"z be objectHIDDENM1" and 
          A2: "z inHIDDENR3 domRELAT-1K1 (curryFUNCT-5K1 f)"and A3: "t =HIDDENR1 curryFUNCT-5K1 f .FUNCT-1K1 z"
          using funct_1_def_3 sorry
        have "domRELAT-1K1 (curryFUNCT-5K1 f) =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 f)"
          using funct_5_def_1 sorry
        then obtain g where
          [ty]:"g be FunctionFUNCT-1M1" and 
          A4: "curryFUNCT-5K1 f .FUNCT-1K1 z =XBOOLE-0R4 g"and "domRELAT-1K1 g =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 z},proj2XTUPLE-0K13 (domRELAT-1K1 f) :]))"and " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(z,y)"
          using A2 funct_5_def_1 sorry
        have "domRELAT-1K1 g c=TARSKIR1 proj2XTUPLE-0K13 (domRELAT-1K1 f) & rngFUNCT-1K2 g c=TARSKIR1 rngFUNCT-1K2 f"
          using A2 A4 funct_5_th_31 sorry
        thus "t inHIDDENR3 PFuncsPARTFUN1K4(proj2XTUPLE-0K13 (domRELAT-1K1 f),rngFUNCT-1K2 f)"
          using A3 A4 partfun1_def_3 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 (curryFUNCT-5K1 f) c=TARSKIR1 PFuncsPARTFUN1K4(proj2XTUPLE-0K13 (domRELAT-1K1 f),rngFUNCT-1K2 f)"
        using tarski_def_3 sorry
    qed
    have " for t be objectHIDDENM1 holds t inHIDDENR3 rngFUNCT-1K2 (curry'FUNCT-5K3 f) implies t inHIDDENR3 PFuncsPARTFUN1K4(proj1XTUPLE-0K12 (domRELAT-1K1 f),rngFUNCT-1K2 f)"
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be objectHIDDENM1"
      assume "t inHIDDENR3 rngFUNCT-1K2 (curry'FUNCT-5K3 f)"
      then obtain z where
        [ty]:"z be objectHIDDENM1" and 
        A5: "z inHIDDENR3 domRELAT-1K1 (curry'FUNCT-5K3 f)"and A6: "t =HIDDENR1 curry'FUNCT-5K3 f .FUNCT-1K1 z"
        using funct_1_def_3 sorry
      have "domRELAT-1K1 (curryFUNCT-5K1 (~FUNCT-4K2 f)) =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 (~FUNCT-4K2 f))"
        using funct_5_def_1 sorry
      then obtain g where
        [ty]:"g be FunctionFUNCT-1M1" and 
        A7: "curryFUNCT-5K1 (~FUNCT-4K2 f) .FUNCT-1K1 z =XBOOLE-0R4 g"and "domRELAT-1K1 g =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 (~FUNCT-4K2 f) /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 z},proj2XTUPLE-0K13 (domRELAT-1K1 (~FUNCT-4K2 f)) :]))"and " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 y =XBOOLE-0R4 ~FUNCT-4K2 f .BINOP-1K1(z,y)"
        using A5 funct_5_def_1 sorry
      have "rngFUNCT-1K2 g c=TARSKIR1 rngFUNCT-1K2 (~FUNCT-4K2 f)"
        using A5 A7 funct_5_th_31 sorry
      then have A8: "rngFUNCT-1K2 g c=TARSKIR1 rngFUNCT-1K2 f"
        using A1 sorry
      have "domRELAT-1K1 g c=TARSKIR1 proj2XTUPLE-0K13 (domRELAT-1K1 (~FUNCT-4K2 f))"
        using A5 A7 funct_5_th_31 sorry
      then have "domRELAT-1K1 g c=TARSKIR1 proj1XTUPLE-0K12 (domRELAT-1K1 f)"
        using funct_5_th_17 sorry
      thus "t inHIDDENR3 PFuncsPARTFUN1K4(proj1XTUPLE-0K12 (domRELAT-1K1 f),rngFUNCT-1K2 f)"
        using A6 A7 A8 partfun1_def_3 sorry
    qed "sorry"
    thus "rngFUNCT-1K2 (curry'FUNCT-5K3 f) c=TARSKIR1 PFuncsPARTFUN1K4(proj1XTUPLE-0K12 (domRELAT-1K1 f),rngFUNCT-1K2 f)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_37:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds rngFUNCT-1K2 f c=TARSKIR1 PFuncsPARTFUN1K4(X,Y) implies domRELAT-1K1 (uncurryFUNCT-5K2 f) c=TARSKIR1 [:ZFMISC-1K2 domRELAT-1K1 f,X :] & domRELAT-1K1 (uncurry'FUNCT-5K4 f) c=TARSKIR1 [:ZFMISC-1K2 X,domRELAT-1K1 f :]"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds rngFUNCT-1K2 f c=TARSKIR1 PFuncsPARTFUN1K4(X,Y) implies domRELAT-1K1 (uncurryFUNCT-5K2 f) c=TARSKIR1 [:ZFMISC-1K2 domRELAT-1K1 f,X :] & domRELAT-1K1 (uncurry'FUNCT-5K4 f) c=TARSKIR1 [:ZFMISC-1K2 X,domRELAT-1K1 f :]"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "rngFUNCT-1K2 f c=TARSKIR1 PFuncsPARTFUN1K4(X,Y)"
    show A2: "domRELAT-1K1 (uncurryFUNCT-5K2 f) c=TARSKIR1 [:ZFMISC-1K2 domRELAT-1K1 f,X :]"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 f) implies x inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 f,X :]"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 f)"
        then obtain y g z where
          [ty]:"y be objectHIDDENM1" "g be FunctionFUNCT-1M1" "z be objectHIDDENM1" and 
          A3: "x =HIDDENR1 [TARSKIK4 y,z ]"and A4: "y inHIDDENR3 domRELAT-1K1 f"and A5: "g =XBOOLE-0R4 f .FUNCT-1K1 y"and A6: "z inHIDDENR3 domRELAT-1K1 g"
          using funct_5_def_2 sorry
        have "g inTARSKIR2 rngFUNCT-1K2 f"
          using A4 A5 funct_1_def_3 sorry
        then have "g be PartFuncPARTFUN1M1-of(X,Y)"
          using A1 partfun1_th_46 sorry
        then have "domRELAT-1K1 g c=TARSKIR1 X"
          using relat_1_def_18 sorry
        thus "x inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 f,X :]"
          using A3 A4 A6 zfmisc_1_th_87 sorry
      qed "sorry"
      thus "domRELAT-1K1 (uncurryFUNCT-5K2 f) c=TARSKIR1 [:ZFMISC-1K2 domRELAT-1K1 f,X :]"
        using tarski_def_3 sorry
    qed
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (uncurry'FUNCT-5K4 f) implies x inHIDDENR3 [:ZFMISC-1K2 X,domRELAT-1K1 f :]"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 domRELAT-1K1 (uncurry'FUNCT-5K4 f)"
      then have " ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st x =HIDDENR1 [TARSKIK4 z,y ] & [TARSKIK4 y,z ] inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 f)"
        using funct_4_def_2 sorry
      thus "x inHIDDENR3 [:ZFMISC-1K2 X,domRELAT-1K1 f :]"
        using A2 zfmisc_1_th_88 sorry
    qed "sorry"
    thus "domRELAT-1K1 (uncurry'FUNCT-5K4 f) c=TARSKIR1 [:ZFMISC-1K2 X,domRELAT-1K1 f :]"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_38:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds (x inHIDDENR3 domRELAT-1K1 f & g =XBOOLE-0R4 f .FUNCT-1K1 x) & y inHIDDENR3 domRELAT-1K1 g implies ([TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 f) & uncurryFUNCT-5K2 f .BINOP-1K1(x,y) =XBOOLE-0R4 g .FUNCT-1K1 y) & g .FUNCT-1K1 y inTARSKIR2 rngFUNCT-1K2 (uncurryFUNCT-5K2 f)"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f & (g =XBOOLE-0R4 f .FUNCT-1K1 x & y inHIDDENR3 domRELAT-1K1 g) implies [TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 f) & (uncurryFUNCT-5K2 f .BINOP-1K1(x,y) =XBOOLE-0R4 g .FUNCT-1K1 y & g .FUNCT-1K1 y inTARSKIR2 rngFUNCT-1K2 (uncurryFUNCT-5K2 f))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI,rule conjMI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "x inHIDDENR3 domRELAT-1K1 f"
      and A2: "g =XBOOLE-0R4 f .FUNCT-1K1 x"
      and A3: "y inHIDDENR3 domRELAT-1K1 g"
    show A4: "[TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 f)"
      using A1 A2 A3 funct_5_def_2 sorry
    have "[TARSKIK4 x,y ] `1XTUPLE-0K1 =HIDDENR1 x & [TARSKIK4 x,y ] `2XTUPLE-0K2 =HIDDENR1 y"
       sorry
    thus "uncurryFUNCT-5K2 f .BINOP-1K1(x,y) =XBOOLE-0R4 g .FUNCT-1K1 y"
      using A2 A4 funct_5_def_2 sorry
    thus "g .FUNCT-1K1 y inTARSKIR2 rngFUNCT-1K2 (uncurryFUNCT-5K2 f)"
      using A4 funct_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_39:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds (x inHIDDENR3 domRELAT-1K1 f & g =XBOOLE-0R4 f .FUNCT-1K1 x) & y inHIDDENR3 domRELAT-1K1 g implies ([TARSKIK4 y,x ] inHIDDENR3 domRELAT-1K1 (uncurry'FUNCT-5K4 f) & uncurry'FUNCT-5K4 f .BINOP-1K1(y,x) =XBOOLE-0R4 g .FUNCT-1K1 y) & g .FUNCT-1K1 y inTARSKIR2 rngFUNCT-1K2 (uncurry'FUNCT-5K4 f)"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds (x inHIDDENR3 domRELAT-1K1 f & g =XBOOLE-0R4 f .FUNCT-1K1 x) & y inHIDDENR3 domRELAT-1K1 g implies [TARSKIK4 y,x ] inHIDDENR3 domRELAT-1K1 (uncurry'FUNCT-5K4 f) & (uncurry'FUNCT-5K4 f .BINOP-1K1(y,x) =XBOOLE-0R4 g .FUNCT-1K1 y & g .FUNCT-1K1 y inTARSKIR2 rngFUNCT-1K2 (uncurry'FUNCT-5K4 f))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "(x inHIDDENR3 domRELAT-1K1 f & g =XBOOLE-0R4 f .FUNCT-1K1 x) & y inHIDDENR3 domRELAT-1K1 g"
    then have "[TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 f)"
      using funct_5_th_38 sorry
    thus A2: "[TARSKIK4 y,x ] inHIDDENR3 domRELAT-1K1 (uncurry'FUNCT-5K4 f)"
      using funct_4_th_42 sorry
    have "uncurryFUNCT-5K2 f .BINOP-1K1(x,y) =XBOOLE-0R4 g .FUNCT-1K1 y"
      using A1 funct_5_th_38 sorry
    thus "uncurry'FUNCT-5K4 f .BINOP-1K1(y,x) =XBOOLE-0R4 g .FUNCT-1K1 y"
      using A2 funct_4_th_43 sorry
    thus "g .FUNCT-1K1 y inTARSKIR2 rngFUNCT-1K2 (uncurry'FUNCT-5K4 f)"
      using A2 funct_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_40:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds rngFUNCT-1K2 f c=TARSKIR1 PFuncsPARTFUN1K4(X,Y) implies rngFUNCT-1K2 (uncurryFUNCT-5K2 f) c=TARSKIR1 Y & rngFUNCT-1K2 (uncurry'FUNCT-5K4 f) c=TARSKIR1 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds rngFUNCT-1K2 f c=TARSKIR1 PFuncsPARTFUN1K4(X,Y) implies rngFUNCT-1K2 (uncurryFUNCT-5K2 f) c=TARSKIR1 Y & rngFUNCT-1K2 (uncurry'FUNCT-5K4 f) c=TARSKIR1 Y"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "rngFUNCT-1K2 f c=TARSKIR1 PFuncsPARTFUN1K4(X,Y)"
    show A2: "rngFUNCT-1K2 (uncurryFUNCT-5K2 f) c=TARSKIR1 Y"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (uncurryFUNCT-5K2 f) implies x inHIDDENR3 Y"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 (uncurryFUNCT-5K2 f)"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A3: "y inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 f)"and A4: "x =HIDDENR1 uncurryFUNCT-5K2 f .FUNCT-1K1 y"
          using funct_1_def_3 sorry
        obtain z g t where
          [ty]:"z be objectHIDDENM1" "g be FunctionFUNCT-1M1" "t be objectHIDDENM1" and 
          A5: "y =HIDDENR1 [TARSKIK4 z,t ]"and A6: "z inHIDDENR3 domRELAT-1K1 f & g =XBOOLE-0R4 f .FUNCT-1K1 z"and A7: "t inHIDDENR3 domRELAT-1K1 g"
          using A3 funct_5_def_2 sorry
        have "g inTARSKIR2 rngFUNCT-1K2 f"
          using A6 funct_1_def_3 sorry
        then have A8: " ex g1 be FunctionFUNCT-1M1 st (g =FUNCT-1R1 g1 & domRELAT-1K1 g1 c=TARSKIR1 X) & rngFUNCT-1K2 g1 c=TARSKIR1 Y"
          using A1 partfun1_def_3 sorry
        have "uncurryFUNCT-5K2 f .BINOP-1K1(z,t) =XBOOLE-0R4 g .FUNCT-1K1 t & g .FUNCT-1K1 t inTARSKIR2 rngFUNCT-1K2 g"
          using A6 A7 funct_5_th_38 funct_1_def_3 sorry
        thus "x inHIDDENR3 Y"
          using A4 A5 A8 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 (uncurryFUNCT-5K2 f) c=TARSKIR1 Y"
        using tarski_def_3 sorry
    qed
    have "rngFUNCT-1K2 (uncurry'FUNCT-5K4 f) c=TARSKIR1 rngFUNCT-1K2 (uncurryFUNCT-5K2 f)"
      using funct_4_th_41 sorry
    thus "rngFUNCT-1K2 (uncurry'FUNCT-5K4 f) c=TARSKIR1 Y"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_41:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds rngFUNCT-1K2 f c=TARSKIR1 FuncsFUNCT-2K1(X,Y) implies rngFUNCT-1K2 (uncurryFUNCT-5K2 f) c=TARSKIR1 Y & rngFUNCT-1K2 (uncurry'FUNCT-5K4 f) c=TARSKIR1 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds rngFUNCT-1K2 f c=TARSKIR1 FuncsFUNCT-2K1(X,Y) implies rngFUNCT-1K2 (uncurryFUNCT-5K2 f) c=TARSKIR1 Y & rngFUNCT-1K2 (uncurry'FUNCT-5K4 f) c=TARSKIR1 Y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have A1: "FuncsFUNCT-2K1(X,Y) c=TARSKIR1 PFuncsPARTFUN1K4(X,Y)"
      using funct_2_th_72 sorry
    assume "rngFUNCT-1K2 f c=TARSKIR1 FuncsFUNCT-2K1(X,Y)"
    then have "rngFUNCT-1K2 f c=TARSKIR1 PFuncsPARTFUN1K4(X,Y)"
      using A1 sorry
    thus "rngFUNCT-1K2 (uncurryFUNCT-5K2 f) c=TARSKIR1 Y & rngFUNCT-1K2 (uncurry'FUNCT-5K4 f) c=TARSKIR1 Y"
      using funct_5_th_40 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_42:
"curryFUNCT-5K1 ({}XBOOLE-0K1) =FUNCT-1R1 {}XBOOLE-0K1 & curry'FUNCT-5K3 ({}XBOOLE-0K1) =FUNCT-1R1 {}XBOOLE-0K1"
  using funct_5_def_1 funct_5_th_1 sorry

mtheorem funct_5_th_43:
"uncurryFUNCT-5K2 ({}XBOOLE-0K1) =FUNCT-1R1 {}XBOOLE-0K1 & uncurry'FUNCT-5K4 ({}XBOOLE-0K1) =FUNCT-1R1 {}XBOOLE-0K1"
proof(rule conjMI)
  have A1: "domRELAT-1K1 (uncurryFUNCT-5K2 ({}XBOOLE-0K1)) <>HIDDENR2 {}XBOOLE-0K1 implies  False "
  proof(rule impI)
    let ?t = "the ElementSUBSET-1M1-of domRELAT-1K1 (uncurryFUNCT-5K2 ({}XBOOLE-0K1))"
    assume "domRELAT-1K1 (uncurryFUNCT-5K2 ({}XBOOLE-0K1)) <>HIDDENR2 {}XBOOLE-0K1"
    then have " ex x be objectHIDDENM1 st  ex g be FunctionFUNCT-1M1 st  ex y be objectHIDDENM1 st ((?t =HIDDENR1 [TARSKIK4 x,y ] & x inHIDDENR3 domRELAT-1K1 ({}XBOOLE-0K1)) & g =FUNCT-1R1 {}XBOOLE-0K1 .FUNCT-1K1 x) & y inHIDDENR3 domRELAT-1K1 g"
      using funct_5_def_2 sorry
    thus " False "
       sorry
  qed
  thus "uncurryFUNCT-5K2 ({}XBOOLE-0K1) =FUNCT-1R1 {}XBOOLE-0K1"
     sorry
  show "uncurry'FUNCT-5K4 ({}XBOOLE-0K1) =FUNCT-1R1 {}XBOOLE-0K1"
    using A1 funct_5_th_1 relat_1_th_41 sorry
qed

mtheorem funct_5_th_44:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f1 be FunctionFUNCT-1M1 holds  for f2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 f1 =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & domRELAT-1K1 f2 =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]) & curryFUNCT-5K1 f1 =FUNCT-1R1 curryFUNCT-5K1 f2 implies f1 =FUNCT-1R1 f2"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f1 be FunctionFUNCT-1M1 holds  for f2 be FunctionFUNCT-1M1 holds domRELAT-1K1 f1 =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & (domRELAT-1K1 f2 =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & curryFUNCT-5K1 f1 =FUNCT-1R1 curryFUNCT-5K1 f2) implies f1 =FUNCT-1R1 f2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f1 assume [ty]: "f1 be FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be FunctionFUNCT-1M1"
    assume A1: "domRELAT-1K1 f1 =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]"
      and A2: "domRELAT-1K1 f2 =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]"
      and A3: "curryFUNCT-5K1 f1 =FUNCT-1R1 curryFUNCT-5K1 f2"
    have A4: "[:ZFMISC-1K2 X,Y :] <>HIDDENR2 {}XBOOLE-0K1 implies f1 =FUNCT-1R1 f2"
    proof(rule impI)
      assume "[:ZFMISC-1K2 X,Y :] <>HIDDENR2 {}XBOOLE-0K1"
      have " for z be objectHIDDENM1 holds z inHIDDENR3 [:ZFMISC-1K2 X,Y :] implies f1 .FUNCT-1K1 z =XBOOLE-0R4 f2 .FUNCT-1K1 z"
      proof(rule ballI,rule impI)
        fix z assume [ty]: "z be objectHIDDENM1"
        assume A5: "z inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
        then obtain g1 where
          [ty]:"g1 be FunctionFUNCT-1M1" and 
          A6: "curryFUNCT-5K1 f1 .FUNCT-1K1 z `1XTUPLE-0K1 =XBOOLE-0R4 g1"and "domRELAT-1K1 g1 =XBOOLE-0R4 Y"and "rngFUNCT-1K2 g1 c=TARSKIR1 rngFUNCT-1K2 f1"and A7: " for y be objectHIDDENM1 holds y inHIDDENR3 Y implies g1 .FUNCT-1K1 y =XBOOLE-0R4 f1 .BINOP-1K1(z `1XTUPLE-0K1,y)"
          using A1 funct_5_th_29 mcart_1_th_10 sorry
        have A8: "z =HIDDENR1 [TARSKIK4 z `1XTUPLE-0K1,z `2XTUPLE-0K2 ]"
          using A5 mcart_1_th_21 sorry
        have A9: "z `2XTUPLE-0K2 inHIDDENR3 Y"
          using A5 mcart_1_th_10 sorry
        then have A10: "f1 .BINOP-1K1(z `1XTUPLE-0K1,z `2XTUPLE-0K2) =XBOOLE-0R4 g1 .FUNCT-1K1 z `2XTUPLE-0K2"
          using A7 sorry
        have " ex g2 be FunctionFUNCT-1M1 st ((curryFUNCT-5K1 f2 .FUNCT-1K1 z `1XTUPLE-0K1 =XBOOLE-0R4 g2 & domRELAT-1K1 g2 =XBOOLE-0R4 Y) & rngFUNCT-1K2 g2 c=TARSKIR1 rngFUNCT-1K2 f2) & ( for y be objectHIDDENM1 holds y inHIDDENR3 Y implies g2 .FUNCT-1K1 y =XBOOLE-0R4 f2 .BINOP-1K1(z `1XTUPLE-0K1,y))"
          using A2 A5 funct_5_th_29 mcart_1_th_10 sorry
        then have "f2 .BINOP-1K1(z `1XTUPLE-0K1,z `2XTUPLE-0K2) =XBOOLE-0R4 g1 .FUNCT-1K1 z `2XTUPLE-0K2"
          using A3 A9 A6 sorry
        thus "f1 .FUNCT-1K1 z =XBOOLE-0R4 f2 .FUNCT-1K1 z"
          using A8 A10 sorry
      qed "sorry"
      thus "f1 =FUNCT-1R1 f2"
        using A1 A2 sorry
    qed
    have "[:ZFMISC-1K2 X,Y :] =RELAT-1R1 {}XBOOLE-0K1 implies f1 =FUNCT-1R1 {}XBOOLE-0K1 & f2 =FUNCT-1R1 {}XBOOLE-0K1"
      using A1 A2 sorry
    thus "f1 =FUNCT-1R1 f2"
      using A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_45:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f1 be FunctionFUNCT-1M1 holds  for f2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 f1 =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & domRELAT-1K1 f2 =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]) & curry'FUNCT-5K3 f1 =FUNCT-1R1 curry'FUNCT-5K3 f2 implies f1 =FUNCT-1R1 f2"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f1 be FunctionFUNCT-1M1 holds  for f2 be FunctionFUNCT-1M1 holds domRELAT-1K1 f1 =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & (domRELAT-1K1 f2 =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & curry'FUNCT-5K3 f1 =FUNCT-1R1 curry'FUNCT-5K3 f2) implies f1 =FUNCT-1R1 f2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f1 assume [ty]: "f1 be FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be FunctionFUNCT-1M1"
    assume A1: "domRELAT-1K1 f1 =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]"
      and A2: "domRELAT-1K1 f2 =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]"
      and A3: "curry'FUNCT-5K3 f1 =FUNCT-1R1 curry'FUNCT-5K3 f2"
    have "domRELAT-1K1 (~FUNCT-4K2 f1) =XBOOLE-0R4 [:ZFMISC-1K2 Y,X :] & domRELAT-1K1 (~FUNCT-4K2 f2) =XBOOLE-0R4 [:ZFMISC-1K2 Y,X :]"
      using A1 A2 funct_4_th_46 sorry
    then have A4: "~FUNCT-4K2 f1 =FUNCT-1R1 ~FUNCT-4K2 f2"
      using A3 funct_5_th_44 sorry
    have "~FUNCT-4K2 (~FUNCT-4K2 f1) =FUNCT-1R1 f1"
      using A1 funct_4_th_52 sorry
    thus "f1 =FUNCT-1R1 f2"
      using A2 A4 funct_4_th_52 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_46:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f1 be FunctionFUNCT-1M1 holds  for f2 be FunctionFUNCT-1M1 holds ((rngFUNCT-1K2 f1 c=TARSKIR1 FuncsFUNCT-2K1(X,Y) & rngFUNCT-1K2 f2 c=TARSKIR1 FuncsFUNCT-2K1(X,Y)) & X <>HIDDENR2 {}XBOOLE-0K1) & uncurryFUNCT-5K2 f1 =FUNCT-1R1 uncurryFUNCT-5K2 f2 implies f1 =FUNCT-1R1 f2"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f1 be FunctionFUNCT-1M1 holds  for f2 be FunctionFUNCT-1M1 holds rngFUNCT-1K2 f1 c=TARSKIR1 FuncsFUNCT-2K1(X,Y) & (rngFUNCT-1K2 f2 c=TARSKIR1 FuncsFUNCT-2K1(X,Y) & (X <>HIDDENR2 {}XBOOLE-0K1 & uncurryFUNCT-5K2 f1 =FUNCT-1R1 uncurryFUNCT-5K2 f2)) implies f1 =FUNCT-1R1 f2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f1 assume [ty]: "f1 be FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be FunctionFUNCT-1M1"
    assume A1: "rngFUNCT-1K2 f1 c=TARSKIR1 FuncsFUNCT-2K1(X,Y)"
      and A2: "rngFUNCT-1K2 f2 c=TARSKIR1 FuncsFUNCT-2K1(X,Y)"
      and A3: "X <>HIDDENR2 {}XBOOLE-0K1"
      and A4: "uncurryFUNCT-5K2 f1 =FUNCT-1R1 uncurryFUNCT-5K2 f2"
    have A5: "domRELAT-1K1 (uncurryFUNCT-5K2 f1) =XBOOLE-0R4 [:ZFMISC-1K2 domRELAT-1K1 f1,X :] & domRELAT-1K1 (uncurryFUNCT-5K2 f2) =XBOOLE-0R4 [:ZFMISC-1K2 domRELAT-1K1 f2,X :]"
      using A1 A2 funct_5_th_26 sorry
    then have "domRELAT-1K1 f1 =XBOOLE-0R4 {}XBOOLE-0K1 implies domRELAT-1K1 f1 =XBOOLE-0R4 domRELAT-1K1 f2"
      using A3 A4 sorry
    then have A6: "domRELAT-1K1 f1 =XBOOLE-0R4 domRELAT-1K1 f2"
      using A3 A4 A5 zfmisc_1_th_110 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f1 implies f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A7: "x inHIDDENR3 domRELAT-1K1 f1"
      then have "f1 .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f1"
        using funct_1_def_3 sorry
      then obtain g1 where
        [ty]:"g1 be FunctionFUNCT-1M1" and 
        A8: "f1 .FUNCT-1K1 x =XBOOLE-0R4 g1"and A9: "domRELAT-1K1 g1 =XBOOLE-0R4 X"and "rngFUNCT-1K2 g1 c=TARSKIR1 Y"
        using A1 funct_2_def_2 sorry
      have "f2 .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f2"
        using A6 A7 funct_1_def_3 sorry
      then obtain g2 where
        [ty]:"g2 be FunctionFUNCT-1M1" and 
        A10: "f2 .FUNCT-1K1 x =XBOOLE-0R4 g2"and A11: "domRELAT-1K1 g2 =XBOOLE-0R4 X"and "rngFUNCT-1K2 g2 c=TARSKIR1 Y"
        using A2 funct_2_def_2 sorry
      have " for y be objectHIDDENM1 holds y inHIDDENR3 X implies g1 .FUNCT-1K1 y =XBOOLE-0R4 g2 .FUNCT-1K1 y"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        have A12: "[TARSKIK4 x,y ] `1XTUPLE-0K1 =HIDDENR1 x & [TARSKIK4 x,y ] `2XTUPLE-0K2 =HIDDENR1 y"
           sorry
        assume A13: "y inHIDDENR3 X"
        then have A14: "[TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 f2)"
          using A4 A7 A8 A9 funct_5_def_2 sorry
        have "[TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 f1)"
          using A7 A8 A9 A13 funct_5_def_2 sorry
        then have "uncurryFUNCT-5K2 f1 .FUNCT-1K1 [TARSKIK4 x,y ] =XBOOLE-0R4 g1 .FUNCT-1K1 y"
          using A8 A12 funct_5_def_2 sorry
        thus "g1 .FUNCT-1K1 y =XBOOLE-0R4 g2 .FUNCT-1K1 y"
          using A4 A10 A14 A12 funct_5_def_2 sorry
      qed "sorry"
      thus "f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x"
        using A8 A9 A10 A11 funct_1_th_2 sorry
    qed "sorry"
    thus "f1 =FUNCT-1R1 f2"
      using A6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_47:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f1 be FunctionFUNCT-1M1 holds  for f2 be FunctionFUNCT-1M1 holds ((rngFUNCT-1K2 f1 c=TARSKIR1 FuncsFUNCT-2K1(X,Y) & rngFUNCT-1K2 f2 c=TARSKIR1 FuncsFUNCT-2K1(X,Y)) & X <>HIDDENR2 {}XBOOLE-0K1) & uncurry'FUNCT-5K4 f1 =FUNCT-1R1 uncurry'FUNCT-5K4 f2 implies f1 =FUNCT-1R1 f2"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f1 be FunctionFUNCT-1M1 holds  for f2 be FunctionFUNCT-1M1 holds rngFUNCT-1K2 f1 c=TARSKIR1 FuncsFUNCT-2K1(X,Y) & (rngFUNCT-1K2 f2 c=TARSKIR1 FuncsFUNCT-2K1(X,Y) & (X <>HIDDENR2 {}XBOOLE-0K1 & uncurry'FUNCT-5K4 f1 =FUNCT-1R1 uncurry'FUNCT-5K4 f2)) implies f1 =FUNCT-1R1 f2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f1 assume [ty]: "f1 be FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be FunctionFUNCT-1M1"
    assume A1: "rngFUNCT-1K2 f1 c=TARSKIR1 FuncsFUNCT-2K1(X,Y)"
      and A2: "rngFUNCT-1K2 f2 c=TARSKIR1 FuncsFUNCT-2K1(X,Y)"
      and A3: "X <>HIDDENR2 {}XBOOLE-0K1 & uncurry'FUNCT-5K4 f1 =FUNCT-1R1 uncurry'FUNCT-5K4 f2"
    have "domRELAT-1K1 (uncurryFUNCT-5K2 f1) =XBOOLE-0R4 [:ZFMISC-1K2 domRELAT-1K1 f1,X :]"
      using A1 funct_5_th_26 sorry
    then have A4: "uncurryFUNCT-5K2 f1 =FUNCT-1R1 ~FUNCT-4K2 (~FUNCT-4K2 (uncurryFUNCT-5K2 f1))"
      using funct_4_th_52 sorry
    have "domRELAT-1K1 (uncurryFUNCT-5K2 f2) =XBOOLE-0R4 [:ZFMISC-1K2 domRELAT-1K1 f2,X :]"
      using A2 funct_5_th_26 sorry
    thus "f1 =FUNCT-1R1 f2"
      using A1 A2 A3 A4 funct_5_th_46 funct_4_th_52 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_48:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds rngFUNCT-1K2 f c=TARSKIR1 FuncsFUNCT-2K1(X,Y) & X <>HIDDENR2 {}XBOOLE-0K1 implies curryFUNCT-5K1 (uncurryFUNCT-5K2 f) =FUNCT-1R1 f & curry'FUNCT-5K3 (uncurry'FUNCT-5K4 f) =FUNCT-1R1 f"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds rngFUNCT-1K2 f c=TARSKIR1 FuncsFUNCT-2K1(X,Y) & X <>HIDDENR2 {}XBOOLE-0K1 implies curryFUNCT-5K1 (uncurryFUNCT-5K2 f) =FUNCT-1R1 f & curry'FUNCT-5K3 (uncurry'FUNCT-5K4 f) =FUNCT-1R1 f"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "rngFUNCT-1K2 f c=TARSKIR1 FuncsFUNCT-2K1(X,Y)"
      and A2: "X <>HIDDENR2 {}XBOOLE-0K1"
    have A3: "domRELAT-1K1 (uncurryFUNCT-5K2 f) =XBOOLE-0R4 [:ZFMISC-1K2 domRELAT-1K1 f,X :]"
      using A1 funct_5_th_26 sorry
    have A4: "domRELAT-1K1 f <>HIDDENR2 {}XBOOLE-0K1 implies curryFUNCT-5K1 (uncurryFUNCT-5K2 f) =FUNCT-1R1 f"
    proof(rule impI)
      have A5: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =XBOOLE-0R4 curryFUNCT-5K1 (uncurryFUNCT-5K2 f) .FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A6: "x inHIDDENR3 domRELAT-1K1 f"
        then obtain h where
          [ty]:"h be FunctionFUNCT-1M1" and 
          A7: "(curryFUNCT-5K1 (uncurryFUNCT-5K2 f) .FUNCT-1K1 x =XBOOLE-0R4 h & domRELAT-1K1 h =XBOOLE-0R4 X) & rngFUNCT-1K2 h c=TARSKIR1 rngFUNCT-1K2 (uncurryFUNCT-5K2 f)"and A8: " for y be objectHIDDENM1 holds y inHIDDENR3 X implies h .FUNCT-1K1 y =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(x,y)"
          using A2 A3 funct_5_th_29 sorry
        have "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f"
          using A6 funct_1_def_3 sorry
        then obtain g where
          [ty]:"g be FunctionFUNCT-1M1" and 
          A9: "f .FUNCT-1K1 x =XBOOLE-0R4 g & domRELAT-1K1 g =XBOOLE-0R4 X"and "rngFUNCT-1K2 g c=TARSKIR1 Y"
          using A1 funct_2_def_2 sorry
        have " for y be objectHIDDENM1 holds y inHIDDENR3 X implies g .FUNCT-1K1 y =XBOOLE-0R4 h .FUNCT-1K1 y"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume A10: "y inHIDDENR3 X"
          then have "uncurryFUNCT-5K2 f .BINOP-1K1(x,y) =XBOOLE-0R4 g .FUNCT-1K1 y"
            using A6 A9 funct_5_th_38 sorry
          thus "g .FUNCT-1K1 y =XBOOLE-0R4 h .FUNCT-1K1 y"
            using A8 A10 sorry
        qed "sorry"
        thus "f .FUNCT-1K1 x =XBOOLE-0R4 curryFUNCT-5K1 (uncurryFUNCT-5K2 f) .FUNCT-1K1 x"
          using A9 A7 funct_1_th_2 sorry
      qed "sorry"
      assume "domRELAT-1K1 f <>HIDDENR2 {}XBOOLE-0K1"
      then have "domRELAT-1K1 (curryFUNCT-5K1 (uncurryFUNCT-5K2 f)) =XBOOLE-0R4 domRELAT-1K1 f"
        using A2 A3 funct_5_th_24 sorry
      thus "curryFUNCT-5K1 (uncurryFUNCT-5K2 f) =FUNCT-1R1 f"
        using A5 sorry
    qed
    have A11: "domRELAT-1K1 f =XBOOLE-0R4 {}XBOOLE-0K1 implies curryFUNCT-5K1 (uncurryFUNCT-5K2 f) =FUNCT-1R1 f"
    proof(rule impI)
      assume "domRELAT-1K1 f =XBOOLE-0R4 {}XBOOLE-0K1"
      then have "domRELAT-1K1 (uncurryFUNCT-5K2 f) =XBOOLE-0R4 {}XBOOLE-0K1 & f =FUNCT-1R1 {}XBOOLE-0K1"
        using A3 sorry
      thus "curryFUNCT-5K1 (uncurryFUNCT-5K2 f) =FUNCT-1R1 f"
        using funct_5_th_42 relat_1_th_41 sorry
    qed
    thus "curryFUNCT-5K1 (uncurryFUNCT-5K2 f) =FUNCT-1R1 f"
      using A4 sorry
    show "curry'FUNCT-5K3 (uncurry'FUNCT-5K4 f) =FUNCT-1R1 f"
      using A3 A11 A4 funct_4_th_52 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_49:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] implies uncurryFUNCT-5K2 (curryFUNCT-5K1 f) =FUNCT-1R1 f & uncurry'FUNCT-5K4 (curry'FUNCT-5K3 f) =FUNCT-1R1 f"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] implies uncurryFUNCT-5K2 (curryFUNCT-5K1 f) =FUNCT-1R1 f & uncurry'FUNCT-5K4 (curry'FUNCT-5K3 f) =FUNCT-1R1 f"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]"
    have A2: "domRELAT-1K1 f <>HIDDENR2 {}XBOOLE-0K1 implies uncurryFUNCT-5K2 (curryFUNCT-5K1 f) =FUNCT-1R1 f & uncurry'FUNCT-5K4 (curry'FUNCT-5K3 f) =FUNCT-1R1 f"
    proof(rule impI)
      have A3: "rngFUNCT-1K2 (curry'FUNCT-5K3 f) c=TARSKIR1 FuncsFUNCT-2K1(X,rngFUNCT-1K2 f)"
        using A1 funct_5_th_35 sorry
      assume A4: "domRELAT-1K1 f <>HIDDENR2 {}XBOOLE-0K1"
      then have "X <>HIDDENR2 {}XBOOLE-0K1"
        using A1 sorry
      then have A5: "curry'FUNCT-5K3 (uncurry'FUNCT-5K4 (curry'FUNCT-5K3 f)) =FUNCT-1R1 curry'FUNCT-5K3 f"
        using A3 funct_5_th_48 sorry
      have "domRELAT-1K1 (curry'FUNCT-5K3 f) =XBOOLE-0R4 Y"
        using A1 A4 funct_5_th_24 sorry
      then have A6: "domRELAT-1K1 (uncurry'FUNCT-5K4 (curry'FUNCT-5K3 f)) =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]"
        using A3 funct_5_th_26 sorry
      have A7: "rngFUNCT-1K2 (curryFUNCT-5K1 f) c=TARSKIR1 FuncsFUNCT-2K1(Y,rngFUNCT-1K2 f)"
        using A1 funct_5_th_35 sorry
      have "Y <>HIDDENR2 {}XBOOLE-0K1"
        using A1 A4 sorry
      then have A8: "curryFUNCT-5K1 (uncurryFUNCT-5K2 (curryFUNCT-5K1 f)) =FUNCT-1R1 curryFUNCT-5K1 f"
        using A7 funct_5_th_48 sorry
      have "domRELAT-1K1 (curryFUNCT-5K1 f) =XBOOLE-0R4 X"
        using A1 A4 funct_5_th_24 sorry
      then have "domRELAT-1K1 (uncurryFUNCT-5K2 (curryFUNCT-5K1 f)) =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]"
        using A7 funct_5_th_26 sorry
      thus "uncurryFUNCT-5K2 (curryFUNCT-5K1 f) =FUNCT-1R1 f & uncurry'FUNCT-5K4 (curry'FUNCT-5K3 f) =FUNCT-1R1 f"
        using A1 A8 A5 A6 funct_5_th_44 funct_5_th_45 sorry
    qed
    have "domRELAT-1K1 f =XBOOLE-0R4 {}XBOOLE-0K1 implies uncurryFUNCT-5K2 (curryFUNCT-5K1 f) =FUNCT-1R1 f & uncurry'FUNCT-5K4 (curry'FUNCT-5K3 f) =FUNCT-1R1 f"
    proof(rule impI)
      assume "domRELAT-1K1 f =XBOOLE-0R4 {}XBOOLE-0K1"
      then have "f =FUNCT-1R1 {}XBOOLE-0K1"
         sorry
      thus "uncurryFUNCT-5K2 (curryFUNCT-5K1 f) =FUNCT-1R1 f & uncurry'FUNCT-5K4 (curry'FUNCT-5K3 f) =FUNCT-1R1 f"
        using funct_5_th_42 funct_5_th_43 sorry
    qed
    thus "uncurryFUNCT-5K2 (curryFUNCT-5K1 f) =FUNCT-1R1 f & uncurry'FUNCT-5K4 (curry'FUNCT-5K3 f) =FUNCT-1R1 f"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_50:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds domRELAT-1K1 f c=TARSKIR1 [:ZFMISC-1K2 X,Y :] implies uncurryFUNCT-5K2 (curryFUNCT-5K1 f) =FUNCT-1R1 f & uncurry'FUNCT-5K4 (curry'FUNCT-5K3 f) =FUNCT-1R1 f"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds domRELAT-1K1 f c=TARSKIR1 [:ZFMISC-1K2 X,Y :] implies uncurryFUNCT-5K2 (curryFUNCT-5K1 f) =FUNCT-1R1 f & uncurry'FUNCT-5K4 (curry'FUNCT-5K3 f) =FUNCT-1R1 f"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "domRELAT-1K1 f c=TARSKIR1 [:ZFMISC-1K2 X,Y :]"
    have A2: " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds domRELAT-1K1 f c=TARSKIR1 [:ZFMISC-1K2 X,Y :] implies uncurryFUNCT-5K2 (curryFUNCT-5K1 f) =FUNCT-1R1 f"
    proof(rule ballI,rule ballI,rule ballI,rule impI)
      fix X assume [ty]: "X be setHIDDENM2"
      fix Y assume [ty]: "Y be setHIDDENM2"
      fix f assume [ty]: "f be FunctionFUNCT-1M1"
      assume A3: "domRELAT-1K1 f c=TARSKIR1 [:ZFMISC-1K2 X,Y :]"
      have A4: "domRELAT-1K1 (uncurryFUNCT-5K2 (curryFUNCT-5K1 f)) =XBOOLE-0R4 domRELAT-1K1 f"
      proof-
        have "domRELAT-1K1 (uncurryFUNCT-5K2 (curryFUNCT-5K1 f)) c=TARSKIR1 domRELAT-1K1 f & domRELAT-1K1 f c=TARSKIR1 domRELAT-1K1 (uncurryFUNCT-5K2 (curryFUNCT-5K1 f))"
        proof(rule conjMI)
          show "domRELAT-1K1 (uncurryFUNCT-5K2 (curryFUNCT-5K1 f)) c=TARSKIR1 domRELAT-1K1 f"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 (curryFUNCT-5K1 f)) implies x inHIDDENR3 domRELAT-1K1 f"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 (curryFUNCT-5K1 f))"
              then have " ex y be objectHIDDENM1 st  ex g be FunctionFUNCT-1M1 st  ex z be objectHIDDENM1 st ((x =HIDDENR1 [TARSKIK4 y,z ] & y inHIDDENR3 domRELAT-1K1 (curryFUNCT-5K1 f)) & g =XBOOLE-0R4 curryFUNCT-5K1 f .FUNCT-1K1 y) & z inHIDDENR3 domRELAT-1K1 g"
                using funct_5_def_2 sorry
              thus "x inHIDDENR3 domRELAT-1K1 f"
                using funct_5_th_31 sorry
            qed "sorry"
            thus "domRELAT-1K1 (uncurryFUNCT-5K2 (curryFUNCT-5K1 f)) c=TARSKIR1 domRELAT-1K1 f"
              using tarski_def_3 sorry
          qed
          have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies x inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 (curryFUNCT-5K1 f))"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A5: "x inHIDDENR3 domRELAT-1K1 f"
            then have A6: "x =HIDDENR1 [TARSKIK4 x `1XTUPLE-0K1,x `2XTUPLE-0K2 ]"
              using A3 mcart_1_th_21 sorry
            then have "x `1XTUPLE-0K1 inHIDDENR3 domRELAT-1K1 (curryFUNCT-5K1 f)"
              using A5 funct_5_th_19 sorry
            then obtain g where 
              [ty]:"g be FunctionFUNCT-1M1" and gDef:"g = curryFUNCT-5K1 f .FUNCT-1K1 x `1XTUPLE-0K1"
              using funcop_1_def_6 sorry
            have "x `2XTUPLE-0K2 inHIDDENR3 domRELAT-1K1 g & x `1XTUPLE-0K1 inHIDDENR3 domRELAT-1K1 (curryFUNCT-5K1 f)"
              using A5 A6 funct_5_th_19 funct_5_th_20 sorry
            thus "x inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 (curryFUNCT-5K1 f))"
              using A6 funct_5_th_38 sorry
          qed "sorry"
          thus "domRELAT-1K1 f c=TARSKIR1 domRELAT-1K1 (uncurryFUNCT-5K2 (curryFUNCT-5K1 f))"
            using tarski_def_3 sorry
        qed
        thus "domRELAT-1K1 (uncurryFUNCT-5K2 (curryFUNCT-5K1 f)) =XBOOLE-0R4 domRELAT-1K1 f"
          using xboole_0_def_10 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =XBOOLE-0R4 uncurryFUNCT-5K2 (curryFUNCT-5K1 f) .FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A7: "x inHIDDENR3 domRELAT-1K1 f"
        then have A8: "x =HIDDENR1 [TARSKIK4 x `1XTUPLE-0K1,x `2XTUPLE-0K2 ]"
          using A3 mcart_1_th_21 sorry
        then have "x `1XTUPLE-0K1 inHIDDENR3 domRELAT-1K1 (curryFUNCT-5K1 f)"
          using A7 funct_5_th_19 sorry
        then obtain g where 
          [ty]:"g be FunctionFUNCT-1M1" and gDef:"g = curryFUNCT-5K1 f .FUNCT-1K1 x `1XTUPLE-0K1"
          using funcop_1_def_6 sorry
        have "uncurryFUNCT-5K2 (curryFUNCT-5K1 f) .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x `2XTUPLE-0K2"
          using A4 A7 funct_5_def_2 sorry
        then have "f .BINOP-1K1(x `1XTUPLE-0K1,x `2XTUPLE-0K2) =XBOOLE-0R4 uncurryFUNCT-5K2 (curryFUNCT-5K1 f) .BINOP-1K1(x `1XTUPLE-0K1,x `2XTUPLE-0K2)"
          using A7 A8 funct_5_th_20 sorry
        thus "f .FUNCT-1K1 x =XBOOLE-0R4 uncurryFUNCT-5K2 (curryFUNCT-5K1 f) .FUNCT-1K1 x"
          using A8 sorry
      qed "sorry"
      thus "uncurryFUNCT-5K2 (curryFUNCT-5K1 f) =FUNCT-1R1 f"
        using A4 sorry
    qed "sorry"
    thus "uncurryFUNCT-5K2 (curryFUNCT-5K1 f) =FUNCT-1R1 f"
      using A1 sorry
    have "domRELAT-1K1 (~FUNCT-4K2 f) c=TARSKIR1 [:ZFMISC-1K2 Y,X :]"
      using A1 funct_4_th_45 sorry
    then have "uncurryFUNCT-5K2 (curryFUNCT-5K1 (~FUNCT-4K2 f)) =FUNCT-1R1 ~FUNCT-4K2 f"
      using A2 sorry
    thus "uncurry'FUNCT-5K4 (curry'FUNCT-5K3 f) =FUNCT-1R1 f"
      using A1 funct_4_th_52 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_51:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds rngFUNCT-1K2 f c=TARSKIR1 PFuncsPARTFUN1K4(X,Y) &  not {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f implies curryFUNCT-5K1 (uncurryFUNCT-5K2 f) =FUNCT-1R1 f & curry'FUNCT-5K3 (uncurry'FUNCT-5K4 f) =FUNCT-1R1 f"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds rngFUNCT-1K2 f c=TARSKIR1 PFuncsPARTFUN1K4(X,Y) &  not {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f implies curryFUNCT-5K1 (uncurryFUNCT-5K2 f) =FUNCT-1R1 f & curry'FUNCT-5K3 (uncurry'FUNCT-5K4 f) =FUNCT-1R1 f"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "rngFUNCT-1K2 f c=TARSKIR1 PFuncsPARTFUN1K4(X,Y)"
      and A2: " not {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f"
    have A3: "domRELAT-1K1 (curryFUNCT-5K1 (uncurryFUNCT-5K2 f)) =XBOOLE-0R4 domRELAT-1K1 f"
    proof-
      have Cut1215: "domRELAT-1K1 (uncurryFUNCT-5K2 f) c=TARSKIR1 [:ZFMISC-1K2 domRELAT-1K1 f,X :]"
        using A1 funct_5_th_37 sorry
      have "domRELAT-1K1 (curryFUNCT-5K1 (uncurryFUNCT-5K2 f)) c=TARSKIR1 domRELAT-1K1 f & domRELAT-1K1 f c=TARSKIR1 domRELAT-1K1 (curryFUNCT-5K1 (uncurryFUNCT-5K2 f))"
      proof(rule conjMI)
        show "domRELAT-1K1 (curryFUNCT-5K1 (uncurryFUNCT-5K2 f)) c=TARSKIR1 domRELAT-1K1 f"
          using funct_5_th_25 Cut1215 sorry
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies x inHIDDENR3 domRELAT-1K1 (curryFUNCT-5K1 (uncurryFUNCT-5K2 f))"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A4: "x inHIDDENR3 domRELAT-1K1 f"
          then have "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f"
            using funct_1_def_3 sorry
          then obtain g where
            [ty]:"g be FunctionFUNCT-1M1" and 
            A5: "f .FUNCT-1K1 x =XBOOLE-0R4 g"and "domRELAT-1K1 g c=TARSKIR1 X"and "rngFUNCT-1K2 g c=TARSKIR1 Y"
            using A1 partfun1_def_3 sorry
          let ?y = "the ElementSUBSET-1M1-of domRELAT-1K1 g"
          have "g <>HIDDENR2 {}XBOOLE-0K1"
            using A2 A4 A5 funct_1_def_3 sorry
          then have A6: "[TARSKIK4 x,?y ] inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 f)"
            using A4 A5 funct_5_th_38 sorry
          have "domRELAT-1K1 (curryFUNCT-5K1 (uncurryFUNCT-5K2 f)) =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 (uncurryFUNCT-5K2 f))"
            using funct_5_def_1 sorry
          thus "x inHIDDENR3 domRELAT-1K1 (curryFUNCT-5K1 (uncurryFUNCT-5K2 f))"
            using A6 xtuple_0_def_12 sorry
        qed "sorry"
        thus "domRELAT-1K1 f c=TARSKIR1 domRELAT-1K1 (curryFUNCT-5K1 (uncurryFUNCT-5K2 f))"
          using tarski_def_3 sorry
      qed
      thus "domRELAT-1K1 (curryFUNCT-5K1 (uncurryFUNCT-5K2 f)) =XBOOLE-0R4 domRELAT-1K1 f"
        using xboole_0_def_10 sorry
    qed
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =XBOOLE-0R4 curryFUNCT-5K1 (uncurryFUNCT-5K2 f) .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A7: "x inHIDDENR3 domRELAT-1K1 f"
      then obtain h where 
        [ty]:"h be FunctionFUNCT-1M1" and hDef:"h = curryFUNCT-5K1 (uncurryFUNCT-5K2 f) .FUNCT-1K1 x"
        using A3 funct_5_th_30 sorry
      have "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f"
        using A7 funct_1_def_3 sorry
      then obtain g where
        [ty]:"g be FunctionFUNCT-1M1" and 
        A8: "f .FUNCT-1K1 x =XBOOLE-0R4 g"and "domRELAT-1K1 g c=TARSKIR1 X"and "rngFUNCT-1K2 g c=TARSKIR1 Y"
        using A1 partfun1_def_3 sorry
      have A9: "domRELAT-1K1 h =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 (uncurryFUNCT-5K2 f) /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 (uncurryFUNCT-5K2 f)) :]))"
        using A3 A7 funct_5_th_31 sorry
      have A10: "domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 g"
      proof-
        have "domRELAT-1K1 h c=TARSKIR1 domRELAT-1K1 g & domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 h"
        proof(rule conjMI)
          show "domRELAT-1K1 h c=TARSKIR1 domRELAT-1K1 g"
          proof-
            have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 h implies z inHIDDENR3 domRELAT-1K1 g"
            proof(rule ballI,rule impI)
              fix z assume [ty]: "z be objectHIDDENM1"
              assume "z inHIDDENR3 domRELAT-1K1 h"
              then obtain t where
                [ty]:"t be objectHIDDENM1" and 
                A11: "[TARSKIK4 t,z ] inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 f) /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 (uncurryFUNCT-5K2 f)) :])"
                using A9 xtuple_0_def_13 sorry
              have "[TARSKIK4 t,z ] inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 (uncurryFUNCT-5K2 f)) :]"
                using A11 xboole_0_def_4 sorry
              then have A12: "t =HIDDENR1 x"
                using zfmisc_1_th_105 sorry
              have "[TARSKIK4 t,z ] inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 f)"
                using A11 xboole_0_def_4 sorry
              then obtain x1 g1 x2 where
                [ty]:"x1 be objectHIDDENM1" "g1 be FunctionFUNCT-1M1" "x2 be objectHIDDENM1" and 
                A13: "[TARSKIK4 t,z ] =HIDDENR1 [TARSKIK4 x1,x2 ]"and "x1 inHIDDENR3 domRELAT-1K1 f"and A14: "g1 =XBOOLE-0R4 f .FUNCT-1K1 x1 & x2 inHIDDENR3 domRELAT-1K1 g1"
                using funct_5_def_2 sorry
              have "t =HIDDENR1 x1"
                using A13 xtuple_0_th_1 sorry
              thus "z inHIDDENR3 domRELAT-1K1 g"
                using A8 A13 A14 A12 xtuple_0_th_1 sorry
            qed "sorry"
            thus "domRELAT-1K1 h c=TARSKIR1 domRELAT-1K1 g"
              using tarski_def_3 sorry
          qed
          have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 g implies y inHIDDENR3 domRELAT-1K1 h"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            assume "y inHIDDENR3 domRELAT-1K1 g"
            then have "[TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 f)"
              using A7 A8 funct_5_th_38 sorry
            thus "y inHIDDENR3 domRELAT-1K1 h"
              using funct_5_th_20 sorry
          qed "sorry"
          thus "domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 h"
            using tarski_def_3 sorry
        qed
        thus "domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 g"
          using xboole_0_def_10 sorry
      qed
      have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 y =HIDDENR1 g .FUNCT-1K1 y"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A15: "y inHIDDENR3 domRELAT-1K1 h"
        then have "h .FUNCT-1K1 y =HIDDENR1 uncurryFUNCT-5K2 f .BINOP-1K1(x,y)"
          using A3 A7 funct_5_th_31 sorry
        also have "... = g .FUNCT-1K1 y"
          using A7 A8 A10 A15 funct_5_th_38 sorry
        finally show "h .FUNCT-1K1 y =HIDDENR1 g .FUNCT-1K1 y"
           sorry
      qed "sorry"
      thus "f .FUNCT-1K1 x =XBOOLE-0R4 curryFUNCT-5K1 (uncurryFUNCT-5K2 f) .FUNCT-1K1 x"
        using A8 A10 funct_1_th_2 sorry
    qed "sorry"
    thus A16: "curryFUNCT-5K1 (uncurryFUNCT-5K2 f) =FUNCT-1R1 f"
      using A3 sorry
    have "domRELAT-1K1 (uncurryFUNCT-5K2 f) c=TARSKIR1 [:ZFMISC-1K2 domRELAT-1K1 f,X :]"
      using A1 funct_5_th_37 sorry
    thus "curry'FUNCT-5K3 (uncurry'FUNCT-5K4 f) =FUNCT-1R1 f"
      using A16 funct_4_th_52 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_52:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f1 be FunctionFUNCT-1M1 holds  for f2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 f1 c=TARSKIR1 [:ZFMISC-1K2 X,Y :] & domRELAT-1K1 f2 c=TARSKIR1 [:ZFMISC-1K2 X,Y :]) & curryFUNCT-5K1 f1 =FUNCT-1R1 curryFUNCT-5K1 f2 implies f1 =FUNCT-1R1 f2"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f1 be FunctionFUNCT-1M1 holds  for f2 be FunctionFUNCT-1M1 holds domRELAT-1K1 f1 c=TARSKIR1 [:ZFMISC-1K2 X,Y :] & domRELAT-1K1 f2 c=TARSKIR1 [:ZFMISC-1K2 X,Y :] implies  not (curryFUNCT-5K1 f1 =FUNCT-1R1 curryFUNCT-5K1 f2 &  not f1 =FUNCT-1R1 f2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f1 assume [ty]: "f1 be FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be FunctionFUNCT-1M1"
    assume A1: "domRELAT-1K1 f1 c=TARSKIR1 [:ZFMISC-1K2 X,Y :]"
      and A2: "domRELAT-1K1 f2 c=TARSKIR1 [:ZFMISC-1K2 X,Y :]"
    have "uncurryFUNCT-5K2 (curryFUNCT-5K1 f1) =FUNCT-1R1 f1"
      using A1 funct_5_th_50 sorry
    thus " not (curryFUNCT-5K1 f1 =FUNCT-1R1 curryFUNCT-5K1 f2 &  not f1 =FUNCT-1R1 f2)"
      using A2 funct_5_th_50 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_53:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f1 be FunctionFUNCT-1M1 holds  for f2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 f1 c=TARSKIR1 [:ZFMISC-1K2 X,Y :] & domRELAT-1K1 f2 c=TARSKIR1 [:ZFMISC-1K2 X,Y :]) & curry'FUNCT-5K3 f1 =FUNCT-1R1 curry'FUNCT-5K3 f2 implies f1 =FUNCT-1R1 f2"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f1 be FunctionFUNCT-1M1 holds  for f2 be FunctionFUNCT-1M1 holds domRELAT-1K1 f1 c=TARSKIR1 [:ZFMISC-1K2 X,Y :] & domRELAT-1K1 f2 c=TARSKIR1 [:ZFMISC-1K2 X,Y :] implies  not (curry'FUNCT-5K3 f1 =FUNCT-1R1 curry'FUNCT-5K3 f2 &  not f1 =FUNCT-1R1 f2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f1 assume [ty]: "f1 be FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be FunctionFUNCT-1M1"
    assume A1: "domRELAT-1K1 f1 c=TARSKIR1 [:ZFMISC-1K2 X,Y :]"
      and A2: "domRELAT-1K1 f2 c=TARSKIR1 [:ZFMISC-1K2 X,Y :]"
    have "uncurry'FUNCT-5K4 (curry'FUNCT-5K3 f1) =FUNCT-1R1 f1"
      using A1 funct_5_th_50 sorry
    thus " not (curry'FUNCT-5K3 f1 =FUNCT-1R1 curry'FUNCT-5K3 f2 &  not f1 =FUNCT-1R1 f2)"
      using A2 funct_5_th_50 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_54:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f1 be FunctionFUNCT-1M1 holds  for f2 be FunctionFUNCT-1M1 holds (((rngFUNCT-1K2 f1 c=TARSKIR1 PFuncsPARTFUN1K4(X,Y) & rngFUNCT-1K2 f2 c=TARSKIR1 PFuncsPARTFUN1K4(X,Y)) &  not {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f1) &  not {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f2) & uncurryFUNCT-5K2 f1 =FUNCT-1R1 uncurryFUNCT-5K2 f2 implies f1 =FUNCT-1R1 f2"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f1 be FunctionFUNCT-1M1 holds  for f2 be FunctionFUNCT-1M1 holds rngFUNCT-1K2 f1 c=TARSKIR1 PFuncsPARTFUN1K4(X,Y) & (rngFUNCT-1K2 f2 c=TARSKIR1 PFuncsPARTFUN1K4(X,Y) & ( not {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f1 &  not {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f2)) implies  not (uncurryFUNCT-5K2 f1 =FUNCT-1R1 uncurryFUNCT-5K2 f2 &  not f1 =FUNCT-1R1 f2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f1 assume [ty]: "f1 be FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be FunctionFUNCT-1M1"
    assume A1: "rngFUNCT-1K2 f1 c=TARSKIR1 PFuncsPARTFUN1K4(X,Y)"
      and A2: "rngFUNCT-1K2 f2 c=TARSKIR1 PFuncsPARTFUN1K4(X,Y)"
      and A3: " not {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f1"
      and A4: " not {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f2"
    have "curryFUNCT-5K1 (uncurryFUNCT-5K2 f1) =FUNCT-1R1 f1"
      using A1 A3 funct_5_th_51 sorry
    thus " not (uncurryFUNCT-5K2 f1 =FUNCT-1R1 uncurryFUNCT-5K2 f2 &  not f1 =FUNCT-1R1 f2)"
      using A2 A4 funct_5_th_51 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_55:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f1 be FunctionFUNCT-1M1 holds  for f2 be FunctionFUNCT-1M1 holds (((rngFUNCT-1K2 f1 c=TARSKIR1 PFuncsPARTFUN1K4(X,Y) & rngFUNCT-1K2 f2 c=TARSKIR1 PFuncsPARTFUN1K4(X,Y)) &  not {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f1) &  not {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f2) & uncurry'FUNCT-5K4 f1 =FUNCT-1R1 uncurry'FUNCT-5K4 f2 implies f1 =FUNCT-1R1 f2"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f1 be FunctionFUNCT-1M1 holds  for f2 be FunctionFUNCT-1M1 holds rngFUNCT-1K2 f1 c=TARSKIR1 PFuncsPARTFUN1K4(X,Y) & (rngFUNCT-1K2 f2 c=TARSKIR1 PFuncsPARTFUN1K4(X,Y) & ( not {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f1 &  not {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f2)) implies  not (uncurry'FUNCT-5K4 f1 =FUNCT-1R1 uncurry'FUNCT-5K4 f2 &  not f1 =FUNCT-1R1 f2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f1 assume [ty]: "f1 be FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be FunctionFUNCT-1M1"
    assume A1: "rngFUNCT-1K2 f1 c=TARSKIR1 PFuncsPARTFUN1K4(X,Y)"
      and A2: "rngFUNCT-1K2 f2 c=TARSKIR1 PFuncsPARTFUN1K4(X,Y)"
      and A3: " not {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f1"
      and A4: " not {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f2"
    have "curry'FUNCT-5K3 (uncurry'FUNCT-5K4 f1) =FUNCT-1R1 f1"
      using A1 A3 funct_5_th_51 sorry
    thus " not (uncurry'FUNCT-5K4 f1 =FUNCT-1R1 uncurry'FUNCT-5K4 f2 &  not f1 =FUNCT-1R1 f2)"
      using A2 A4 funct_5_th_51 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_56:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X c=TARSKIR1 Y implies FuncsFUNCT-2K1(Z,X) c=TARSKIR1 FuncsFUNCT-2K1(Z,Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X c=TARSKIR1 Y implies FuncsFUNCT-2K1(Z,X) c=TARSKIR1 FuncsFUNCT-2K1(Z,Y)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume A1: "X c=TARSKIR1 Y"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 FuncsFUNCT-2K1(Z,X) implies x inHIDDENR3 FuncsFUNCT-2K1(Z,Y)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 FuncsFUNCT-2K1(Z,X)"
      then obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A2: "x =HIDDENR1 f & domRELAT-1K1 f =XBOOLE-0R4 Z"and A3: "rngFUNCT-1K2 f c=TARSKIR1 X"
        using funct_2_def_2 sorry
      have "rngFUNCT-1K2 f c=TARSKIR1 Y"
        using A1 A3 sorry
      thus "x inHIDDENR3 FuncsFUNCT-2K1(Z,Y)"
        using A2 funct_2_def_2 sorry
    qed "sorry"
    thus "FuncsFUNCT-2K1(Z,X) c=TARSKIR1 FuncsFUNCT-2K1(Z,Y)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_57:
" for X be setHIDDENM2 holds FuncsFUNCT-2K1({}XBOOLE-0K1,X) =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
proof-
  have " for X be setHIDDENM2 holds FuncsFUNCT-2K1({}XBOOLE-0K1,X) =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have "FuncsFUNCT-2K1({}XBOOLE-0K1,X) c=TARSKIR1 {TARSKIK1 {}XBOOLE-0K1 } & {TARSKIK1 {}XBOOLE-0K1 } c=TARSKIR1 FuncsFUNCT-2K1({}XBOOLE-0K1,X)"
    proof(rule conjMI)
      show "FuncsFUNCT-2K1({}XBOOLE-0K1,X) c=TARSKIR1 {TARSKIK1 {}XBOOLE-0K1 }"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 FuncsFUNCT-2K1({}XBOOLE-0K1,X) implies x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 FuncsFUNCT-2K1({}XBOOLE-0K1,X)"
          then have " ex f be FunctionFUNCT-1M1 st (x =HIDDENR1 f & domRELAT-1K1 f =XBOOLE-0R4 {}XBOOLE-0K1) & rngFUNCT-1K2 f c=TARSKIR1 X"
            using funct_2_def_2 sorry
          then have "x =HIDDENR1 {}XBOOLE-0K1"
             sorry
          thus "x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
            using tarski_def_1 sorry
        qed "sorry"
        thus "FuncsFUNCT-2K1({}XBOOLE-0K1,X) c=TARSKIR1 {TARSKIK1 {}XBOOLE-0K1 }"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 } implies x inHIDDENR3 FuncsFUNCT-2K1({}XBOOLE-0K1,X)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        have A1: "{}XBOOLE-0K1 c=RELAT-1R2 X"
           sorry
        assume "x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
        then have A2: "x =HIDDENR1 {}XBOOLE-0K1"
          using tarski_def_1 sorry
        have "domRELAT-1K1 ({}XBOOLE-0K1) =FUNCT-1R1 {}XBOOLE-0K1 & rngFUNCT-1K2 ({}XBOOLE-0K1) =FUNCT-1R1 {}XBOOLE-0K1"
           sorry
        thus "x inHIDDENR3 FuncsFUNCT-2K1({}XBOOLE-0K1,X)"
          using A2 A1 funct_2_def_2 sorry
      qed "sorry"
      thus "{TARSKIK1 {}XBOOLE-0K1 } c=TARSKIR1 FuncsFUNCT-2K1({}XBOOLE-0K1,X)"
        using tarski_def_3 sorry
    qed
    thus "FuncsFUNCT-2K1({}XBOOLE-0K1,X) =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_58:
" for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds (X,FuncsFUNCT-2K1({TARSKIK1 x},X))are-equipotentWELLORD2R2 & cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 (FuncsFUNCT-2K1({TARSKIK1 x},X))"
proof-
  have " for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds (X,FuncsFUNCT-2K1({TARSKIK1 x},X))are-equipotentWELLORD2R2 & cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 (FuncsFUNCT-2K1({TARSKIK1 x},X))"
  proof(rule ballI,rule ballI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    let ?F = "\<lambda>Lamb1. {TARSKIK1 x} -->FUNCOP-1K7 Lamb1"
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A1: "domRELAT-1K1 f =XBOOLE-0R4 X & ( for y be objectHIDDENM1 holds y inHIDDENR3 X implies f .FUNCT-1K1 y =XBOOLE-0R4 ?F(y))"
      using funct_1_sch_3 sorry
    have A2: "x inHIDDENR3 {TARSKIK1 x}"
      using tarski_def_1 sorry
    show "(X,FuncsFUNCT-2K1({TARSKIK1 x},X))are-equipotentWELLORD2R2"
    proof-
      have "f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 X & proj2XTUPLE-0K13 f =HIDDENR1 FuncsFUNCT-2K1({TARSKIK1 x},X))"
      proof(rule conjMI,rule conjMI)
        show "f be one-to-oneFUNCT-1V2"
        proof-
          have " for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f & z inHIDDENR3 domRELAT-1K1 f implies  not (f .FUNCT-1K1 y =HIDDENR1 f .FUNCT-1K1 z &  not y =HIDDENR1 z)"
          proof(rule ballI,rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            fix z assume [ty]: "z be objectHIDDENM1"
            assume "y inHIDDENR3 domRELAT-1K1 f & z inHIDDENR3 domRELAT-1K1 f"
            then have A3: "f .FUNCT-1K1 y =XBOOLE-0R4 {TARSKIK1 x} -->FUNCOP-1K7 y & f .FUNCT-1K1 z =XBOOLE-0R4 {TARSKIK1 x} -->FUNCOP-1K7 z"
              using A1 sorry
            have "({TARSKIK1 x} -->FUNCOP-1K7 y).FUNCT-1K1 x =HIDDENR1 y"
              using A2 funcop_1_th_7 sorry
            thus " not (f .FUNCT-1K1 y =HIDDENR1 f .FUNCT-1K1 z &  not y =HIDDENR1 z)"
              using A2 A3 funcop_1_th_7 sorry
          qed "sorry"
          thus "f be one-to-oneFUNCT-1V2"
            using funct_1_def_4 sorry
        qed
        show "domRELAT-1K1 f =XBOOLE-0R4 X"
          using A1 sorry
        have "rngFUNCT-1K2 f c=TARSKIR1 FuncsFUNCT-2K1({TARSKIK1 x},X) & FuncsFUNCT-2K1({TARSKIK1 x},X) c=TARSKIR1 proj2XTUPLE-0K13 f"
        proof(rule conjMI)
          show "rngFUNCT-1K2 f c=TARSKIR1 FuncsFUNCT-2K1({TARSKIK1 x},X)"
          proof-
            have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies y inHIDDENR3 FuncsFUNCT-2K1({TARSKIK1 x},X)"
            proof(rule ballI,rule impI)
              fix y assume [ty]: "y be objectHIDDENM1"
              assume "y inHIDDENR3 rngFUNCT-1K2 f"
              then obtain z where
                [ty]:"z be objectHIDDENM1" and 
                A4: "z inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 z"
                using funct_1_def_3 sorry
              have A5: "domRELSET-1K1\<^bsub>({TARSKIK1 x})\<^esub> ({TARSKIK1 x} -->FUNCOP-1K7 z) =XBOOLE-0R4 {TARSKIK1 x} & rngRELSET-1K2\<^bsub>({TARSKIK1 z})\<^esub> ({TARSKIK1 x} -->FUNCOP-1K7 z) =XBOOLE-0R4 {TARSKIK1 z}"
                using funcop_1_th_8 funcop_1_th_13 sorry
              have "y =HIDDENR1 {TARSKIK1 x} -->FUNCOP-1K7 z & {TARSKIK1 z} c=TARSKIR1 X"
                using A1 A4 zfmisc_1_th_31 sorry
              thus "y inHIDDENR3 FuncsFUNCT-2K1({TARSKIK1 x},X)"
                using A5 funct_2_def_2 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 f c=TARSKIR1 FuncsFUNCT-2K1({TARSKIK1 x},X)"
              using tarski_def_3 sorry
          qed
          have " for y be objectHIDDENM1 holds y inHIDDENR3 FuncsFUNCT-2K1({TARSKIK1 x},X) implies y inHIDDENR3 proj2XTUPLE-0K13 f"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            assume "y inHIDDENR3 FuncsFUNCT-2K1({TARSKIK1 x},X)"
            then obtain g where
              [ty]:"g be FunctionFUNCT-1M1" and 
              A6: "y =HIDDENR1 g"and A7: "domRELAT-1K1 g =XBOOLE-0R4 {TARSKIK1 x}"and A8: "rngFUNCT-1K2 g c=TARSKIR1 X"
              using funct_2_def_2 sorry
            have A9: "g .FUNCT-1K1 x inTARSKIR2 {TARSKIK1 g .FUNCT-1K1 x }"
              using tarski_def_1 sorry
            have A10: "rngFUNCT-1K2 g =XBOOLE-0R4 {TARSKIK1 g .FUNCT-1K1 x }"
              using A7 funct_1_th_4 sorry
            then have "g =FUNCT-1R1 {TARSKIK1 x} -->FUNCOP-1K7 g .FUNCT-1K1 x"
              using A7 funcop_1_th_9 sorry
            then have "f .FUNCT-1K1 (g .FUNCT-1K1 x) =XBOOLE-0R4 g"
              using A1 A8 A10 A9 sorry
            thus "y inHIDDENR3 proj2XTUPLE-0K13 f"
              using A1 A6 A8 A10 A9 funct_1_def_3 sorry
          qed "sorry"
          thus "FuncsFUNCT-2K1({TARSKIK1 x},X) c=TARSKIR1 proj2XTUPLE-0K13 f"
            using tarski_def_3 sorry
        qed
        thus "proj2XTUPLE-0K13 f =HIDDENR1 FuncsFUNCT-2K1({TARSKIK1 x},X)"
          using xboole_0_def_10 sorry
      qed
      thus "(X,FuncsFUNCT-2K1({TARSKIK1 x},X))are-equipotentWELLORD2R2"
        using bexI[of _ "f"] wellord2_def_4 sorry
    qed
    thus "cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 (FuncsFUNCT-2K1({TARSKIK1 x},X))"
      using card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_59:
" for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds FuncsFUNCT-2K9(X,{TARSKIK1 x}) =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(boolZFMISC-1K1 ([:ZFMISC-1K2 X,{TARSKIK1 x} :]))\<^esub> X -->FUNCOP-1K7 x }"
proof-
  have " for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds FuncsFUNCT-2K9(X,{TARSKIK1 x}) =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(boolZFMISC-1K1 ([:ZFMISC-1K2 X,{TARSKIK1 x} :]))\<^esub> X -->FUNCOP-1K7 x }"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    have "FuncsFUNCT-2K9(X,{TARSKIK1 x}) c=TARSKIR1 {DOMAIN-1K6\<^bsub>(boolZFMISC-1K1 ([:ZFMISC-1K2 X,{TARSKIK1 x} :]))\<^esub> X -->FUNCOP-1K7 x } & {DOMAIN-1K6\<^bsub>(boolZFMISC-1K1 ([:ZFMISC-1K2 X,{TARSKIK1 x} :]))\<^esub> X -->FUNCOP-1K7 x } c=TARSKIR1 FuncsFUNCT-2K9(X,{TARSKIK1 x})"
    proof(rule conjMI)
      show "FuncsFUNCT-2K9(X,{TARSKIK1 x}) c=TARSKIR1 {DOMAIN-1K6\<^bsub>(boolZFMISC-1K1 ([:ZFMISC-1K2 X,{TARSKIK1 x} :]))\<^esub> X -->FUNCOP-1K7 x }"
      proof-
        have " for y be objectHIDDENM1 holds y inHIDDENR3 FuncsFUNCT-2K9(X,{TARSKIK1 x}) implies y inHIDDENR3 {DOMAIN-1K6\<^bsub>(boolZFMISC-1K1 ([:ZFMISC-1K2 X,{TARSKIK1 x} :]))\<^esub> X -->FUNCOP-1K7 x }"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "y inHIDDENR3 FuncsFUNCT-2K9(X,{TARSKIK1 x})"
          then obtain f where
            [ty]:"f be FunctionFUNCT-1M1" and 
            A1: "y =HIDDENR1 f"and A2: "domRELAT-1K1 f =XBOOLE-0R4 X"and A3: "rngFUNCT-1K2 f c=TARSKIR1 {TARSKIK1 x}"
            using funct_2_def_2 sorry
          have A4: "( for z be objectHIDDENM1 holds  not z inHIDDENR3 X) implies f =FUNCT-1R1 X -->FUNCOP-1K7 x"
          proof(rule impI)
            let ?z = "the ElementSUBSET-1M1-of X"
            have A5: "X <>HIDDENR2 {}XBOOLE-0K1 implies ?z inTARSKIR2 X"
               sorry
            assume " for z be objectHIDDENM1 holds  not z inHIDDENR3 X"
            thus "f =FUNCT-1R1 X -->FUNCOP-1K7 x"
              using A2 A5 sorry
          qed
          have "( ex z be objectHIDDENM1 st z inHIDDENR3 X) implies f =FUNCT-1R1 X -->FUNCOP-1K7 x"
          proof(rule impI)
            assume Given: " ex z be objectHIDDENM1 st z inHIDDENR3 X"
            then obtain z where
              [ty]:"z be objectHIDDENM1" and 
              A6: "z inHIDDENR3 X"
               sorry
            have "f .FUNCT-1K1 z inTARSKIR2 rngFUNCT-1K2 f"
              using A2 A6 funct_1_def_3 sorry
            then have "f .FUNCT-1K1 z =HIDDENR1 x & {TARSKIK1 f .FUNCT-1K1 z } c=TARSKIR1 rngFUNCT-1K2 f"
              using A3 tarski_def_1 sorry
            then have "rngFUNCT-1K2 f =XBOOLE-0R4 {TARSKIK1 x}"
              using A3 sorry
            thus "f =FUNCT-1R1 X -->FUNCOP-1K7 x"
              using A2 funcop_1_th_9 sorry
          qed
          thus "y inHIDDENR3 {DOMAIN-1K6\<^bsub>(boolZFMISC-1K1 ([:ZFMISC-1K2 X,{TARSKIK1 x} :]))\<^esub> X -->FUNCOP-1K7 x }"
            using A1 A4 tarski_def_1 sorry
        qed "sorry"
        thus "FuncsFUNCT-2K9(X,{TARSKIK1 x}) c=TARSKIR1 {DOMAIN-1K6\<^bsub>(boolZFMISC-1K1 ([:ZFMISC-1K2 X,{TARSKIK1 x} :]))\<^esub> X -->FUNCOP-1K7 x }"
          using tarski_def_3 sorry
      qed
      have " for y be objectHIDDENM1 holds y inHIDDENR3 {DOMAIN-1K6\<^bsub>(boolZFMISC-1K1 ([:ZFMISC-1K2 X,{TARSKIK1 x} :]))\<^esub> X -->FUNCOP-1K7 x } implies y inHIDDENR3 FuncsFUNCT-2K9(X,{TARSKIK1 x})"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 {DOMAIN-1K6\<^bsub>(boolZFMISC-1K1 ([:ZFMISC-1K2 X,{TARSKIK1 x} :]))\<^esub> X -->FUNCOP-1K7 x }"
        then have A7: "y =HIDDENR1 X -->FUNCOP-1K7 x"
          using tarski_def_1 sorry
        have "domRELSET-1K1\<^bsub>(X)\<^esub> (X -->FUNCOP-1K7 x) =XBOOLE-0R4 X & rngRELSET-1K2\<^bsub>({TARSKIK1 x})\<^esub> (X -->FUNCOP-1K7 x) c=TARSKIR1 {TARSKIK1 x}"
          using funcop_1_th_13 sorry
        thus "y inHIDDENR3 FuncsFUNCT-2K9(X,{TARSKIK1 x})"
          using A7 funct_2_def_2 sorry
      qed "sorry"
      thus "{DOMAIN-1K6\<^bsub>(boolZFMISC-1K1 ([:ZFMISC-1K2 X,{TARSKIK1 x} :]))\<^esub> X -->FUNCOP-1K7 x } c=TARSKIR1 FuncsFUNCT-2K9(X,{TARSKIK1 x})"
        using tarski_def_3 sorry
    qed
    thus "FuncsFUNCT-2K9(X,{TARSKIK1 x}) =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(boolZFMISC-1K1 ([:ZFMISC-1K2 X,{TARSKIK1 x} :]))\<^esub> X -->FUNCOP-1K7 x }"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_60:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds (X1,Y1)are-equipotentWELLORD2R2 & (X2,Y2)are-equipotentWELLORD2R2 implies (FuncsFUNCT-2K1(X1,X2),FuncsFUNCT-2K1(Y1,Y2))are-equipotentWELLORD2R2 & cardCARD-1K1 (FuncsFUNCT-2K1(X1,X2)) =XBOOLE-0R4 cardCARD-1K1 (FuncsFUNCT-2K1(Y1,Y2))"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds (X1,Y1)are-equipotentWELLORD2R2 & (X2,Y2)are-equipotentWELLORD2R2 implies (FuncsFUNCT-2K1(X1,X2),FuncsFUNCT-2K1(Y1,Y2))are-equipotentWELLORD2R2 & cardCARD-1K1 (FuncsFUNCT-2K1(X1,X2)) =XBOOLE-0R4 cardCARD-1K1 (FuncsFUNCT-2K1(Y1,Y2))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix Y2 assume [ty]: "Y2 be setHIDDENM2"
    assume A1: "(X1,Y1)are-equipotentWELLORD2R2"
      and A2: "(X2,Y2)are-equipotentWELLORD2R2"
    obtain f1 where
      [ty]:"f1 be FunctionFUNCT-1M1" and 
      A3: "f1 be one-to-oneFUNCT-1V2"and A4: "domRELAT-1K1 f1 =XBOOLE-0R4 Y1"and A5: "rngFUNCT-1K2 f1 =XBOOLE-0R4 X1"
      using A1 wellord2_def_4 sorry
    obtain f2 where
      [ty]:"f2 be FunctionFUNCT-1M1" and 
      A6: "f2 be one-to-oneFUNCT-1V2"and A7: "domRELAT-1K1 f2 =XBOOLE-0R4 X2"and A8: "rngFUNCT-1K2 f2 =XBOOLE-0R4 Y2"
      using A2 sorry
    have "(FuncsFUNCT-2K1(X1,X2),FuncsFUNCT-2K1(Y1,Y2))are-equipotentWELLORD2R2"
    proof-
      have A9: "rngFUNCT-1K2 (f1 \<inverse>FUNCT-1K4) =XBOOLE-0R4 Y1"
        using A3 A4 funct_1_th_33 sorry
      let ?F = "\<lambda>Lamb1. f2 *FUNCT-1K3 (Lamb1 *FUNCT-1K3 f1)"
      obtain F where
        [ty]:"F be FunctionFUNCT-1M1" and 
        A10: "domRELAT-1K1 F =XBOOLE-0R4 FuncsFUNCT-2K1(X1,X2) & ( for g be FunctionFUNCT-1M1 holds g inTARSKIR2 FuncsFUNCT-2K1(X1,X2) implies F .FUNCT-1K1 g =XBOOLE-0R4 ?F(g))"
        using funct_5_sch_1 sorry
      have "F be one-to-oneFUNCT-1V2 & (domRELAT-1K1 F =XBOOLE-0R4 FuncsFUNCT-2K1(X1,X2) & proj2XTUPLE-0K13 F =HIDDENR1 FuncsFUNCT-2K1(Y1,Y2))"
      proof(rule conjMI,rule conjMI)
        show "F be one-to-oneFUNCT-1V2"
        proof-
          have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 F & (y inHIDDENR3 domRELAT-1K1 F & F .FUNCT-1K1 x =XBOOLE-0R4 F .FUNCT-1K1 y) implies x =HIDDENR1 y"
          proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            fix y assume [ty]: "y be objectHIDDENM1"
            assume A11: "x inHIDDENR3 domRELAT-1K1 F"
              and A12: "y inHIDDENR3 domRELAT-1K1 F"
              and A13: "F .FUNCT-1K1 x =XBOOLE-0R4 F .FUNCT-1K1 y"
            obtain g1 where
              [ty]:"g1 be FunctionFUNCT-1M1" and 
              A14: "x =HIDDENR1 g1"and A15: "domRELAT-1K1 g1 =XBOOLE-0R4 X1"and A16: "rngFUNCT-1K2 g1 c=TARSKIR1 X2"
              using A10 A11 funct_2_def_2 sorry
            have A17: "F .FUNCT-1K1 x =XBOOLE-0R4 f2 *FUNCT-1K3 (g1 *FUNCT-1K3 f1)"
              using A10 A11 A14 sorry
            have A18: "rngFUNCT-1K2 (g1 *FUNCT-1K3 f1) c=TARSKIR1 X2 & domRELAT-1K1 (g1 *FUNCT-1K3 f1) =XBOOLE-0R4 Y1"
              using A4 A5 A15 A16 relat_1_th_27 relat_1_th_28 sorry
            obtain g2 where
              [ty]:"g2 be FunctionFUNCT-1M1" and 
              A19: "y =HIDDENR1 g2"and A20: "domRELAT-1K1 g2 =XBOOLE-0R4 X1"and A21: "rngFUNCT-1K2 g2 c=TARSKIR1 X2"
              using A10 A12 funct_2_def_2 sorry
            have A22: "rngFUNCT-1K2 (g2 *FUNCT-1K3 f1) c=TARSKIR1 X2 & domRELAT-1K1 (g2 *FUNCT-1K3 f1) =XBOOLE-0R4 Y1"
              using A4 A5 A20 A21 relat_1_th_27 relat_1_th_28 sorry
            have "F .FUNCT-1K1 x =XBOOLE-0R4 f2 *FUNCT-1K3 (g2 *FUNCT-1K3 f1)"
              using A10 A12 A13 A19 sorry
            then have A23: "g1 *FUNCT-1K3 f1 =FUNCT-1R1 g2 *FUNCT-1K3 f1"
              using A6 A7 A17 A18 A22 funct_1_th_27 sorry
            have " for z be objectHIDDENM1 holds z inHIDDENR3 X1 implies g1 .FUNCT-1K1 z =HIDDENR1 g2 .FUNCT-1K1 z"
            proof(rule ballI,rule impI)
              fix z assume [ty]: "z be objectHIDDENM1"
              assume "z inHIDDENR3 X1"
              then obtain z9 where
                [ty]:"z9 be objectHIDDENM1" and 
                A24: "z9 inHIDDENR3 Y1 & f1 .FUNCT-1K1 z9 =HIDDENR1 z"
                using A4 A5 funct_1_def_3 sorry
              have "g1 .FUNCT-1K1 z =HIDDENR1 (g1 *FUNCT-1K3 f1).FUNCT-1K1 z9"
                using A4 A24 funct_1_th_13 sorry
              also have "... = g2 .FUNCT-1K1 z"
                using A4 A23 A24 funct_1_th_13 sorry
              finally show "g1 .FUNCT-1K1 z =HIDDENR1 g2 .FUNCT-1K1 z"
                 sorry
            qed "sorry"
            thus "x =HIDDENR1 y"
              using A14 A15 A19 A20 funct_1_th_2 sorry
          qed "sorry"
          thus "F be one-to-oneFUNCT-1V2"
            using funct_1_def_4 sorry
        qed
        show "domRELAT-1K1 F =XBOOLE-0R4 FuncsFUNCT-2K1(X1,X2)"
          using A10 sorry
        have "rngFUNCT-1K2 F c=TARSKIR1 FuncsFUNCT-2K1(Y1,Y2) & FuncsFUNCT-2K1(Y1,Y2) c=TARSKIR1 proj2XTUPLE-0K13 F"
        proof(rule conjMI)
          show "rngFUNCT-1K2 F c=TARSKIR1 FuncsFUNCT-2K1(Y1,Y2)"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 F implies x inHIDDENR3 FuncsFUNCT-2K1(Y1,Y2)"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 rngFUNCT-1K2 F"
              then obtain y where
                [ty]:"y be objectHIDDENM1" and 
                A25: "y inHIDDENR3 domRELAT-1K1 F"and A26: "x =HIDDENR1 F .FUNCT-1K1 y"
                using funct_1_def_3 sorry
              obtain g where
                [ty]:"g be FunctionFUNCT-1M1" and 
                A27: "y =HIDDENR1 g"and A28: "domRELAT-1K1 g =XBOOLE-0R4 X1 & rngFUNCT-1K2 g c=TARSKIR1 X2"
                using A10 A25 funct_2_def_2 sorry
              have "domRELAT-1K1 (g *FUNCT-1K3 f1) =XBOOLE-0R4 Y1 & rngFUNCT-1K2 (g *FUNCT-1K3 f1) c=TARSKIR1 X2"
                using A4 A5 A28 relat_1_th_27 relat_1_th_28 sorry
              then have A29: "domRELAT-1K1 (f2 *FUNCT-1K3 (g *FUNCT-1K3 f1)) =XBOOLE-0R4 Y1"
                using A7 relat_1_th_27 sorry
              have A30: "rngFUNCT-1K2 (f2 *FUNCT-1K3 (g *FUNCT-1K3 f1)) c=TARSKIR1 Y2"
                using A8 relat_1_th_26 sorry
              have "x =HIDDENR1 f2 *FUNCT-1K3 (g *FUNCT-1K3 f1)"
                using A10 A25 A26 A27 sorry
              thus "x inHIDDENR3 FuncsFUNCT-2K1(Y1,Y2)"
                using A29 A30 funct_2_def_2 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 F c=TARSKIR1 FuncsFUNCT-2K1(Y1,Y2)"
              using tarski_def_3 sorry
          qed
          have " for x be objectHIDDENM1 holds x inHIDDENR3 FuncsFUNCT-2K1(Y1,Y2) implies x inHIDDENR3 proj2XTUPLE-0K13 F"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 FuncsFUNCT-2K1(Y1,Y2)"
            then obtain g where
              [ty]:"g be FunctionFUNCT-1M1" and 
              A31: "x =HIDDENR1 g"and A32: "domRELAT-1K1 g =XBOOLE-0R4 Y1"and A33: "rngFUNCT-1K2 g c=TARSKIR1 Y2"
              using funct_2_def_2 sorry
            have A34: "f2 *FUNCT-1K3 (((f2 \<inverse>FUNCT-1K4 *FUNCT-1K3 g)*FUNCT-1K3 f1 \<inverse>FUNCT-1K4)*FUNCT-1K3 f1) =HIDDENR1 f2 *FUNCT-1K3 ((f2 \<inverse>FUNCT-1K4 *FUNCT-1K3 g)*FUNCT-1K3 (f1 \<inverse>FUNCT-1K4 *FUNCT-1K3 f1))"
              using relat_1_th_36 sorry
            also have "... = (f2 *FUNCT-1K3 (f2 \<inverse>FUNCT-1K4 *FUNCT-1K3 g))*FUNCT-1K3 (f1 \<inverse>FUNCT-1K4 *FUNCT-1K3 f1)"
              using relat_1_th_36 sorry
            also have "... = ((f2 *FUNCT-1K3 f2 \<inverse>FUNCT-1K4)*FUNCT-1K3 g)*FUNCT-1K3 (f1 \<inverse>FUNCT-1K4 *FUNCT-1K3 f1)"
              using relat_1_th_36 sorry
            also have "... = (idPARTFUN1K6 Y2 *FUNCT-1K3 g)*FUNCT-1K3 (f1 \<inverse>FUNCT-1K4 *FUNCT-1K3 f1)"
              using A6 A8 funct_1_th_39 sorry
            also have "... = (idPARTFUN1K6 Y2 *FUNCT-1K3 g)*FUNCT-1K3 idPARTFUN1K6 Y1"
              using A3 A4 funct_1_th_39 sorry
            also have "... = g *FUNCT-1K3 idPARTFUN1K6 Y1"
              using A33 relat_1_th_53 sorry
            also have "... = x"
              using A31 A32 relat_1_th_52 sorry
            finally have "f2 *FUNCT-1K3 (((f2 \<inverse>FUNCT-1K4 *FUNCT-1K3 g)*FUNCT-1K3 f1 \<inverse>FUNCT-1K4)*FUNCT-1K3 f1) =HIDDENR1 x"
               sorry
            have "domRELAT-1K1 (f2 \<inverse>FUNCT-1K4) =XBOOLE-0R4 Y2"
              using A6 A8 funct_1_th_33 sorry
            then have A35: "domRELAT-1K1 (f2 \<inverse>FUNCT-1K4 *FUNCT-1K3 g) =XBOOLE-0R4 Y1"
              using A32 A33 relat_1_th_27 sorry
            have "rngFUNCT-1K2 (f2 \<inverse>FUNCT-1K4) =XBOOLE-0R4 X2"
              using A6 A7 funct_1_th_33 sorry
            then have "rngFUNCT-1K2 (f2 \<inverse>FUNCT-1K4 *FUNCT-1K3 g) c=TARSKIR1 X2"
              using relat_1_th_26 sorry
            then have A36: "rngFUNCT-1K2 ((f2 \<inverse>FUNCT-1K4 *FUNCT-1K3 g)*FUNCT-1K3 f1 \<inverse>FUNCT-1K4) c=TARSKIR1 X2"
              using A9 A35 relat_1_th_28 sorry
            have "domRELAT-1K1 (f1 \<inverse>FUNCT-1K4) =XBOOLE-0R4 X1"
              using A3 A5 funct_1_th_33 sorry
            then have "domRELAT-1K1 ((f2 \<inverse>FUNCT-1K4 *FUNCT-1K3 g)*FUNCT-1K3 f1 \<inverse>FUNCT-1K4) =XBOOLE-0R4 X1"
              using A9 A35 relat_1_th_27 sorry
            then have A37: "(f2 \<inverse>FUNCT-1K4 *FUNCT-1K3 g)*FUNCT-1K3 f1 \<inverse>FUNCT-1K4 inTARSKIR2 domRELAT-1K1 F"
              using A10 A36 funct_2_def_2 sorry
            then have "F .FUNCT-1K1 ((f2 \<inverse>FUNCT-1K4 *FUNCT-1K3 g)*FUNCT-1K3 f1 \<inverse>FUNCT-1K4) =XBOOLE-0R4 f2 *FUNCT-1K3 (((f2 \<inverse>FUNCT-1K4 *FUNCT-1K3 g)*FUNCT-1K3 f1 \<inverse>FUNCT-1K4)*FUNCT-1K3 f1)"
              using A10 sorry
            thus "x inHIDDENR3 proj2XTUPLE-0K13 F"
              using A37 A34 funct_1_def_3 sorry
          qed "sorry"
          thus "FuncsFUNCT-2K1(Y1,Y2) c=TARSKIR1 proj2XTUPLE-0K13 F"
            using tarski_def_3 sorry
        qed
        thus "proj2XTUPLE-0K13 F =HIDDENR1 FuncsFUNCT-2K1(Y1,Y2)"
          using xboole_0_def_10 sorry
      qed
      thus "(FuncsFUNCT-2K1(X1,X2),FuncsFUNCT-2K1(Y1,Y2))are-equipotentWELLORD2R2"
        using bexI[of _ "F"] wellord2_def_4 sorry
    qed
    thus "(FuncsFUNCT-2K1(X1,X2),FuncsFUNCT-2K1(Y1,Y2))are-equipotentWELLORD2R2 & cardCARD-1K1 (FuncsFUNCT-2K1(X1,X2)) =XBOOLE-0R4 cardCARD-1K1 (FuncsFUNCT-2K1(Y1,Y2))"
      using card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_61:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds cardCARD-1K1 X1 =XBOOLE-0R4 cardCARD-1K1 Y1 & cardCARD-1K1 X2 =XBOOLE-0R4 cardCARD-1K1 Y2 implies cardCARD-1K1 (FuncsFUNCT-2K1(X1,X2)) =XBOOLE-0R4 cardCARD-1K1 (FuncsFUNCT-2K1(Y1,Y2))"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds cardCARD-1K1 X1 =XBOOLE-0R4 cardCARD-1K1 Y1 & cardCARD-1K1 X2 =XBOOLE-0R4 cardCARD-1K1 Y2 implies cardCARD-1K1 (FuncsFUNCT-2K1(X1,X2)) =XBOOLE-0R4 cardCARD-1K1 (FuncsFUNCT-2K1(Y1,Y2))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix Y2 assume [ty]: "Y2 be setHIDDENM2"
    assume "cardCARD-1K1 X1 =XBOOLE-0R4 cardCARD-1K1 Y1 & cardCARD-1K1 X2 =XBOOLE-0R4 cardCARD-1K1 Y2"
    then have "(X1,Y1)are-equipotentWELLORD2R2 & (X2,Y2)are-equipotentWELLORD2R2"
      using card_1_th_5 sorry
    thus "cardCARD-1K1 (FuncsFUNCT-2K1(X1,X2)) =XBOOLE-0R4 cardCARD-1K1 (FuncsFUNCT-2K1(Y1,Y2))"
      using funct_5_th_60 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_62:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds X1 missesXBOOLE-0R1 X2 implies (FuncsFUNCT-2K1(X1 \\/XBOOLE-0K2 X2,X),[:ZFMISC-1K2 FuncsFUNCT-2K1(X1,X),FuncsFUNCT-2K1(X2,X) :])are-equipotentWELLORD2R2 & cardCARD-1K1 (FuncsFUNCT-2K1(X1 \\/XBOOLE-0K2 X2,X)) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 FuncsFUNCT-2K1(X1,X),FuncsFUNCT-2K1(X2,X) :])"
proof-
  have " for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds X1 missesXBOOLE-0R1 X2 implies (FuncsFUNCT-2K1(X1 \\/XBOOLE-0K2 X2,X),[:ZFMISC-1K2 FuncsFUNCT-2K1(X1,X),FuncsFUNCT-2K1(X2,X) :])are-equipotentWELLORD2R2 & cardCARD-1K1 (FuncsFUNCT-2K1(X1 \\/XBOOLE-0K2 X2,X)) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 FuncsFUNCT-2K1(X1,X),FuncsFUNCT-2K1(X2,X) :])"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    let ?F = "\<lambda>Lamb1. [TARSKIK4 Lamb1  |RELAT-1K8 X1,Lamb1  |RELAT-1K8 X2 ]"
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A1: "domRELAT-1K1 f =XBOOLE-0R4 FuncsFUNCT-2K1(X1 \\/XBOOLE-0K2 X2,X) & ( for g be FunctionFUNCT-1M1 holds g inTARSKIR2 FuncsFUNCT-2K1(X1 \\/XBOOLE-0K2 X2,X) implies f .FUNCT-1K1 g =HIDDENR1 ?F(g))"
      using funct_5_sch_1 sorry
    assume A2: "X1 missesXBOOLE-0R1 X2"
    show "(FuncsFUNCT-2K1(X1 \\/XBOOLE-0K2 X2,X),[:ZFMISC-1K2 FuncsFUNCT-2K1(X1,X),FuncsFUNCT-2K1(X2,X) :])are-equipotentWELLORD2R2"
    proof-
      have "f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 FuncsFUNCT-2K1(X1 \\/XBOOLE-0K2 X2,X) & proj2XTUPLE-0K13 f =HIDDENR1 [:ZFMISC-1K2 FuncsFUNCT-2K1(X1,X),FuncsFUNCT-2K1(X2,X) :])"
      proof(rule conjMI,rule conjMI)
        show "f be one-to-oneFUNCT-1V2"
        proof-
          have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f implies (f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y implies x =HIDDENR1 y)"
          proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            fix y assume [ty]: "y be objectHIDDENM1"
            assume A3: "x inHIDDENR3 domRELAT-1K1 f"
              and A4: "y inHIDDENR3 domRELAT-1K1 f"
            obtain g2 where
              [ty]:"g2 be FunctionFUNCT-1M1" and 
              A5: "y =HIDDENR1 g2"and A6: "domRELAT-1K1 g2 =XBOOLE-0R4 X1 \\/XBOOLE-0K2 X2"and "rngFUNCT-1K2 g2 c=TARSKIR1 X"
              using A1 A4 funct_2_def_2 sorry
            have A7: "f .FUNCT-1K1 y =HIDDENR1 [TARSKIK4 g2  |RELAT-1K8 X1,g2  |RELAT-1K8 X2 ]"
              using A1 A4 A5 sorry
            assume A8: "f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y"
            obtain g1 where
              [ty]:"g1 be FunctionFUNCT-1M1" and 
              A9: "x =HIDDENR1 g1"and A10: "domRELAT-1K1 g1 =XBOOLE-0R4 X1 \\/XBOOLE-0K2 X2"and "rngFUNCT-1K2 g1 c=TARSKIR1 X"
              using A1 A3 funct_2_def_2 sorry
            have A11: "f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 g1  |RELAT-1K8 X1,g1  |RELAT-1K8 X2 ]"
              using A1 A3 A9 sorry
            have " for x be objectHIDDENM1 holds x inHIDDENR3 X1 \\/XBOOLE-0K2 X2 implies g1 .FUNCT-1K1 x =XBOOLE-0R4 g2 .FUNCT-1K1 x"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 X1 \\/XBOOLE-0K2 X2"
              then have "x inHIDDENR3 X1 or x inHIDDENR3 X2"
                using xboole_0_def_3 sorry
              then have "g1 .FUNCT-1K1 x =XBOOLE-0R4 (g1  |RELAT-1K8 X1).FUNCT-1K1 x & g2 .FUNCT-1K1 x =XBOOLE-0R4 (g2  |RELAT-1K8 X1).FUNCT-1K1 x or g1 .FUNCT-1K1 x =XBOOLE-0R4 (g1  |RELAT-1K8 X2).FUNCT-1K1 x & g2 .FUNCT-1K1 x =XBOOLE-0R4 (g2  |RELAT-1K8 X2).FUNCT-1K1 x"
                using funct_1_th_49 sorry
              thus "g1 .FUNCT-1K1 x =XBOOLE-0R4 g2 .FUNCT-1K1 x"
                using A11 A7 A8 xtuple_0_th_1 sorry
            qed "sorry"
            thus "x =HIDDENR1 y"
              using A9 A10 A5 A6 funct_1_th_2 sorry
          qed "sorry"
          thus "f be one-to-oneFUNCT-1V2"
            using funct_1_def_4 sorry
        qed
        show "domRELAT-1K1 f =XBOOLE-0R4 FuncsFUNCT-2K1(X1 \\/XBOOLE-0K2 X2,X)"
          using A1 sorry
        have "rngFUNCT-1K2 f c=TARSKIR1 [:ZFMISC-1K2 FuncsFUNCT-2K1(X1,X),FuncsFUNCT-2K1(X2,X) :] & [:ZFMISC-1K2 FuncsFUNCT-2K1(X1,X),FuncsFUNCT-2K1(X2,X) :] c=TARSKIR1 proj2XTUPLE-0K13 f"
        proof(rule conjMI)
          show "rngFUNCT-1K2 f c=TARSKIR1 [:ZFMISC-1K2 FuncsFUNCT-2K1(X1,X),FuncsFUNCT-2K1(X2,X) :]"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 [:ZFMISC-1K2 FuncsFUNCT-2K1(X1,X),FuncsFUNCT-2K1(X2,X) :]"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 rngFUNCT-1K2 f"
              then obtain y where
                [ty]:"y be objectHIDDENM1" and 
                A12: "y inHIDDENR3 domRELAT-1K1 f"and A13: "x =HIDDENR1 f .FUNCT-1K1 y"
                using funct_1_def_3 sorry
              obtain g where
                [ty]:"g be FunctionFUNCT-1M1" and 
                A14: "y =HIDDENR1 g"and A15: "domRELAT-1K1 g =XBOOLE-0R4 X1 \\/XBOOLE-0K2 X2"and A16: "rngFUNCT-1K2 g c=TARSKIR1 X"
                using A1 A12 funct_2_def_2 sorry
              have "rngFUNCT-1K2 (g  |RELAT-1K8 X2) c=TARSKIR1 rngFUNCT-1K2 g"
                using relat_1_th_70 sorry
              then have A17: "rngFUNCT-1K2 (g  |RELAT-1K8 X2) c=TARSKIR1 X"
                using A16 sorry
              have "rngFUNCT-1K2 (g  |RELAT-1K8 X1) c=TARSKIR1 rngFUNCT-1K2 g"
                using relat_1_th_70 sorry
              then have A18: "rngFUNCT-1K2 (g  |RELAT-1K8 X1) c=TARSKIR1 X"
                using A16 sorry
              have "domRELAT-1K1 (g  |RELAT-1K8 X2) =XBOOLE-0R4 X2"
                using A15 relat_1_th_62 xboole_1_th_7 sorry
              then have A19: "g  |RELAT-1K8 X2 inTARSKIR2 FuncsFUNCT-2K1(X2,X)"
                using A17 funct_2_def_2 sorry
              have "domRELAT-1K1 (g  |RELAT-1K8 X1) =XBOOLE-0R4 X1"
                using A15 relat_1_th_62 xboole_1_th_7 sorry
              then have "g  |RELAT-1K8 X1 inTARSKIR2 FuncsFUNCT-2K1(X1,X)"
                using A18 funct_2_def_2 sorry
              then have "[TARSKIK4 g  |RELAT-1K8 X1,g  |RELAT-1K8 X2 ] inHIDDENR3 [:ZFMISC-1K2 FuncsFUNCT-2K1(X1,X),FuncsFUNCT-2K1(X2,X) :]"
                using A19 zfmisc_1_th_87 sorry
              thus "x inHIDDENR3 [:ZFMISC-1K2 FuncsFUNCT-2K1(X1,X),FuncsFUNCT-2K1(X2,X) :]"
                using A1 A12 A13 A14 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 f c=TARSKIR1 [:ZFMISC-1K2 FuncsFUNCT-2K1(X1,X),FuncsFUNCT-2K1(X2,X) :]"
              using tarski_def_3 sorry
          qed
          have " for x be objectHIDDENM1 holds x inHIDDENR3 [:ZFMISC-1K2 FuncsFUNCT-2K1(X1,X),FuncsFUNCT-2K1(X2,X) :] implies x inHIDDENR3 proj2XTUPLE-0K13 f"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A20: "x inHIDDENR3 [:ZFMISC-1K2 FuncsFUNCT-2K1(X1,X),FuncsFUNCT-2K1(X2,X) :]"
            then have A21: "x =HIDDENR1 [TARSKIK4 x `1XTUPLE-0K1,x `2XTUPLE-0K2 ]"
              using mcart_1_th_21 sorry
            have "x `1XTUPLE-0K1 inHIDDENR3 FuncsFUNCT-2K1(X1,X)"
              using A20 mcart_1_th_10 sorry
            then obtain g1 where
              [ty]:"g1 be FunctionFUNCT-1M1" and 
              A22: "x `1XTUPLE-0K1 =HIDDENR1 g1"and A23: "domRELAT-1K1 g1 =XBOOLE-0R4 X1"and A24: "rngFUNCT-1K2 g1 c=TARSKIR1 X"
              using funct_2_def_2 sorry
            have "x `2XTUPLE-0K2 inHIDDENR3 FuncsFUNCT-2K1(X2,X)"
              using A20 mcart_1_th_10 sorry
            then obtain g2 where
              [ty]:"g2 be FunctionFUNCT-1M1" and 
              A25: "x `2XTUPLE-0K2 =HIDDENR1 g2"and A26: "domRELAT-1K1 g2 =XBOOLE-0R4 X2"and A27: "rngFUNCT-1K2 g2 c=TARSKIR1 X"
              using funct_2_def_2 sorry
            have "rngFUNCT-1K2 (g1 +*FUNCT-4K1 g2) c=TARSKIR1 rngFUNCT-1K2 g1 \\/XBOOLE-0K2 rngFUNCT-1K2 g2 & rngFUNCT-1K2 g1 \\/XBOOLE-0K2 rngFUNCT-1K2 g2 c=TARSKIR1 X \\/XBOOLE-0K2 X"
              using A24 A27 funct_4_th_17 xboole_1_th_13 sorry
            then have A28: "rngFUNCT-1K2 (g1 +*FUNCT-4K1 g2) c=TARSKIR1 X"
               sorry
            have "domRELAT-1K1 (g1 +*FUNCT-4K1 g2) =XBOOLE-0R4 X1 \\/XBOOLE-0K2 X2"
              using A23 A26 funct_4_def_1 sorry
            then have A29: "g1 +*FUNCT-4K1 g2 inTARSKIR2 domRELAT-1K1 f"
              using A1 A28 funct_2_def_2 sorry
            then have "f .FUNCT-1K1 (g1 +*FUNCT-4K1 g2) =HIDDENR1 [TARSKIK4 (g1 +*FUNCT-4K1 g2) |RELAT-1K8 X1,(g1 +*FUNCT-4K1 g2) |RELAT-1K8 X2 ]"
              using A1 sorry
            also have "... = [TARSKIK4 (g1 +*FUNCT-4K1 g2) |RELAT-1K8 X1,g2 ]"
              using A26 funct_4_th_23 sorry
            also have "... = x"
              using A2 A21 A22 A23 A25 A26 funct_4_th_33 sorry
            finally have "f .FUNCT-1K1 (g1 +*FUNCT-4K1 g2) =HIDDENR1 x"
               sorry
            thus "x inHIDDENR3 proj2XTUPLE-0K13 f"
              using A29 funct_1_def_3 sorry
          qed "sorry"
          thus "[:ZFMISC-1K2 FuncsFUNCT-2K1(X1,X),FuncsFUNCT-2K1(X2,X) :] c=TARSKIR1 proj2XTUPLE-0K13 f"
            using tarski_def_3 sorry
        qed
        thus "proj2XTUPLE-0K13 f =HIDDENR1 [:ZFMISC-1K2 FuncsFUNCT-2K1(X1,X),FuncsFUNCT-2K1(X2,X) :]"
          using xboole_0_def_10 sorry
      qed
      thus "(FuncsFUNCT-2K1(X1 \\/XBOOLE-0K2 X2,X),[:ZFMISC-1K2 FuncsFUNCT-2K1(X1,X),FuncsFUNCT-2K1(X2,X) :])are-equipotentWELLORD2R2"
        using bexI[of _ "f"] wellord2_def_4 sorry
    qed
    thus "cardCARD-1K1 (FuncsFUNCT-2K1(X1 \\/XBOOLE-0K2 X2,X)) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 FuncsFUNCT-2K1(X1,X),FuncsFUNCT-2K1(X2,X) :])"
      using card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_63:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds (FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z),FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z)))are-equipotentWELLORD2R2 & cardCARD-1K1 (FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z)) =XBOOLE-0R4 cardCARD-1K1 (FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z)))"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds (FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z),FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z)))are-equipotentWELLORD2R2 & cardCARD-1K1 (FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z)) =XBOOLE-0R4 cardCARD-1K1 (FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z)))"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    let ?F = "\<lambda>Lamb1. curryFUNCT-5K1 Lamb1"
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A1: "domRELAT-1K1 f =XBOOLE-0R4 FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z) & ( for g be FunctionFUNCT-1M1 holds g inTARSKIR2 FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z) implies f .FUNCT-1K1 g =XBOOLE-0R4 ?F(g))"
      using funct_5_sch_1 sorry
    have A2: "[:ZFMISC-1K2 X,Y :] <>HIDDENR2 {}XBOOLE-0K1 implies (FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z),FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z)))are-equipotentWELLORD2R2 & cardCARD-1K1 (FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z)) =XBOOLE-0R4 cardCARD-1K1 (FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z)))"
    proof(rule impI,rule conjMI)
      assume A3: "[:ZFMISC-1K2 X,Y :] <>HIDDENR2 {}XBOOLE-0K1"
      show "(FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z),FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z)))are-equipotentWELLORD2R2"
      proof-
        have "f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z) & proj2XTUPLE-0K13 f =HIDDENR1 FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z)))"
        proof(rule conjMI,rule conjMI)
          show "f be one-to-oneFUNCT-1V2"
          proof-
            have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds x1 inHIDDENR3 domRELAT-1K1 f & (x2 inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2) implies x1 =HIDDENR1 x2"
            proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
              fix x1 assume [ty]: "x1 be objectHIDDENM1"
              fix x2 assume [ty]: "x2 be objectHIDDENM1"
              assume A4: "x1 inHIDDENR3 domRELAT-1K1 f"
                and A5: "x2 inHIDDENR3 domRELAT-1K1 f"
                and A6: "f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2"
              obtain g2 where
                [ty]:"g2 be FunctionFUNCT-1M1" and 
                A7: "x2 =HIDDENR1 g2"and A8: "domRELAT-1K1 g2 =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]"and "rngFUNCT-1K2 g2 c=TARSKIR1 Z"
                using A1 A5 funct_2_def_2 sorry
              have A9: "f .FUNCT-1K1 x2 =XBOOLE-0R4 curryFUNCT-5K1 g2"
                using A1 A5 A7 sorry
              obtain g1 where
                [ty]:"g1 be FunctionFUNCT-1M1" and 
                A10: "x1 =HIDDENR1 g1"and A11: "domRELAT-1K1 g1 =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]"and "rngFUNCT-1K2 g1 c=TARSKIR1 Z"
                using A1 A4 funct_2_def_2 sorry
              have "f .FUNCT-1K1 x1 =XBOOLE-0R4 curryFUNCT-5K1 g1"
                using A1 A4 A10 sorry
              thus "x1 =HIDDENR1 x2"
                using A6 A10 A11 A7 A8 A9 funct_5_th_44 sorry
            qed "sorry"
            thus "f be one-to-oneFUNCT-1V2"
              using funct_1_def_4 sorry
          qed
          show "domRELAT-1K1 f =XBOOLE-0R4 FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z)"
            using A1 sorry
          have "rngFUNCT-1K2 f c=TARSKIR1 FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z)) & FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z)) c=TARSKIR1 proj2XTUPLE-0K13 f"
          proof(rule conjMI)
            show "rngFUNCT-1K2 f c=TARSKIR1 FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z))"
            proof-
              have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies y inHIDDENR3 FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z))"
              proof(rule ballI,rule impI)
                fix y assume [ty]: "y be objectHIDDENM1"
                assume "y inHIDDENR3 rngFUNCT-1K2 f"
                then obtain x where
                  [ty]:"x be objectHIDDENM1" and 
                  A12: "x inHIDDENR3 domRELAT-1K1 f"and A13: "y =HIDDENR1 f .FUNCT-1K1 x"
                  using funct_1_def_3 sorry
                obtain g where
                  [ty]:"g be FunctionFUNCT-1M1" and 
                  A14: "x =HIDDENR1 g"and A15: "domRELAT-1K1 g =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]"and A16: "rngFUNCT-1K2 g c=TARSKIR1 Z"
                  using A1 A12 funct_2_def_2 sorry
                have A17: "domRELAT-1K1 (curryFUNCT-5K1 g) =XBOOLE-0R4 X"
                  using A3 A15 funct_5_th_24 sorry
                have "rngFUNCT-1K2 (curryFUNCT-5K1 g) c=TARSKIR1 FuncsFUNCT-2K1(Y,rngFUNCT-1K2 g) & FuncsFUNCT-2K1(Y,rngFUNCT-1K2 g) c=TARSKIR1 FuncsFUNCT-2K1(Y,Z)"
                  using A15 A16 funct_5_th_35 funct_5_th_56 sorry
                then have A18: "rngFUNCT-1K2 (curryFUNCT-5K1 g) c=TARSKIR1 FuncsFUNCT-2K1(Y,Z)"
                   sorry
                have "y =HIDDENR1 curryFUNCT-5K1 g"
                  using A1 A12 A13 A14 sorry
                thus "y inHIDDENR3 FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z))"
                  using A17 A18 funct_2_def_2 sorry
              qed "sorry"
              thus "rngFUNCT-1K2 f c=TARSKIR1 FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z))"
                using tarski_def_3 sorry
            qed
            have " for y be objectHIDDENM1 holds y inHIDDENR3 FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z)) implies y inHIDDENR3 proj2XTUPLE-0K13 f"
            proof(rule ballI,rule impI)
              fix y assume [ty]: "y be objectHIDDENM1"
              assume "y inHIDDENR3 FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z))"
              then obtain g where
                [ty]:"g be FunctionFUNCT-1M1" and 
                A19: "y =HIDDENR1 g"and A20: "domRELAT-1K1 g =XBOOLE-0R4 X"and A21: "rngFUNCT-1K2 g c=TARSKIR1 FuncsFUNCT-2K1(Y,Z)"
                using funct_2_def_2 sorry
              have "domRELAT-1K1 (uncurryFUNCT-5K2 g) =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & rngFUNCT-1K2 (uncurryFUNCT-5K2 g) c=TARSKIR1 Z"
                using A20 A21 funct_5_th_26 funct_5_th_41 sorry
              then have A22: "uncurryFUNCT-5K2 g inTARSKIR2 FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z)"
                using funct_2_def_2 sorry
              have "Y <>HIDDENR2 {}XBOOLE-0K1"
                using A3 zfmisc_1_th_90 sorry
              then have "curryFUNCT-5K1 (uncurryFUNCT-5K2 g) =FUNCT-1R1 g"
                using A21 funct_5_th_48 sorry
              then have "f .FUNCT-1K1 uncurryFUNCT-5K2 g =HIDDENR1 y"
                using A1 A19 A22 sorry
              thus "y inHIDDENR3 proj2XTUPLE-0K13 f"
                using A1 A22 funct_1_def_3 sorry
            qed "sorry"
            thus "FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z)) c=TARSKIR1 proj2XTUPLE-0K13 f"
              using tarski_def_3 sorry
          qed
          thus "proj2XTUPLE-0K13 f =HIDDENR1 FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z))"
            using xboole_0_def_10 sorry
        qed
        thus "(FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z),FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z)))are-equipotentWELLORD2R2"
          using bexI[of _ "f"] wellord2_def_4 sorry
      qed
      thus "cardCARD-1K1 (FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z)) =XBOOLE-0R4 cardCARD-1K1 (FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z)))"
        using card_1_th_5 sorry
    qed
    have "[:ZFMISC-1K2 X,Y :] =RELAT-1R1 {}XBOOLE-0K1 implies (FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z),FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z)))are-equipotentWELLORD2R2 & cardCARD-1K1 (FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z)) =XBOOLE-0R4 cardCARD-1K1 (FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z)))"
    proof(rule impI,rule conjMI)
      assume A23: "[:ZFMISC-1K2 X,Y :] =RELAT-1R1 {}XBOOLE-0K1"
      then have A24: "FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z) =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
        using funct_5_th_57 sorry
      have A25: "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies (FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z),FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z)))are-equipotentWELLORD2R2"
      proof(rule impI)
        assume "Y =XBOOLE-0R4 {}XBOOLE-0K1"
        then have "FuncsFUNCT-2K1(Y,Z) =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
          using funct_5_th_57 sorry
        then have "FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z)) =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(boolZFMISC-1K1 ([:ZFMISC-1K2 X,{TARSKIK1 {}XBOOLE-0K1 } :]))\<^esub> X -->FUNCOP-1K7 {}XBOOLE-0K1 }"
          using funct_5_th_59 sorry
        thus "(FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z),FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z)))are-equipotentWELLORD2R2"
          using A24 card_1_th_28 sorry
      qed
      have "X =XBOOLE-0R4 {}XBOOLE-0K1 or Y =XBOOLE-0R4 {}XBOOLE-0K1"
        using A23 sorry
      thus "(FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z),FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z)))are-equipotentWELLORD2R2"
        using A24 A25 funct_5_th_57 sorry
      have "X =XBOOLE-0R4 {}XBOOLE-0K1 implies FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z)) =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
        using funct_5_th_57 sorry
      thus "cardCARD-1K1 (FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z)) =XBOOLE-0R4 cardCARD-1K1 (FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z)))"
        using A23 A25 funct_5_th_57 card_1_th_5 sorry
    qed
    thus "(FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z),FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z)))are-equipotentWELLORD2R2 & cardCARD-1K1 (FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z)) =XBOOLE-0R4 cardCARD-1K1 (FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z)))"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_64:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds (FuncsFUNCT-2K1(Z,[:ZFMISC-1K2 X,Y :]),[:ZFMISC-1K2 FuncsFUNCT-2K1(Z,X),FuncsFUNCT-2K1(Z,Y) :])are-equipotentWELLORD2R2 & cardCARD-1K1 (FuncsFUNCT-2K1(Z,[:ZFMISC-1K2 X,Y :])) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 FuncsFUNCT-2K1(Z,X),FuncsFUNCT-2K1(Z,Y) :])"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds (FuncsFUNCT-2K1(Z,[:ZFMISC-1K2 X,Y :]),[:ZFMISC-1K2 FuncsFUNCT-2K1(Z,X),FuncsFUNCT-2K1(Z,Y) :])are-equipotentWELLORD2R2 & cardCARD-1K1 (FuncsFUNCT-2K1(Z,[:ZFMISC-1K2 X,Y :])) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 FuncsFUNCT-2K1(Z,X),FuncsFUNCT-2K1(Z,Y) :])"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    let ?F = "\<lambda>Lamb1. [TARSKIK4 pr1FUNCT-3K10(X,Y) *FUNCT-1K3 Lamb1,pr2FUNCT-3K11(X,Y) *FUNCT-1K3 Lamb1 ]"
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A1: "domRELAT-1K1 f =XBOOLE-0R4 FuncsFUNCT-2K1(Z,[:ZFMISC-1K2 X,Y :]) & ( for g be FunctionFUNCT-1M1 holds g inTARSKIR2 FuncsFUNCT-2K1(Z,[:ZFMISC-1K2 X,Y :]) implies f .FUNCT-1K1 g =HIDDENR1 ?F(g))"
      using funct_5_sch_1 sorry
    show "(FuncsFUNCT-2K1(Z,[:ZFMISC-1K2 X,Y :]),[:ZFMISC-1K2 FuncsFUNCT-2K1(Z,X),FuncsFUNCT-2K1(Z,Y) :])are-equipotentWELLORD2R2"
    proof-
      have "f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 FuncsFUNCT-2K1(Z,[:ZFMISC-1K2 X,Y :]) & proj2XTUPLE-0K13 f =HIDDENR1 [:ZFMISC-1K2 FuncsFUNCT-2K1(Z,X),FuncsFUNCT-2K1(Z,Y) :])"
      proof(rule conjMI,rule conjMI)
        show "f be one-to-oneFUNCT-1V2"
        proof-
          have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds x1 inHIDDENR3 domRELAT-1K1 f & (x2 inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2) implies x1 =HIDDENR1 x2"
          proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
            fix x1 assume [ty]: "x1 be objectHIDDENM1"
            fix x2 assume [ty]: "x2 be objectHIDDENM1"
            assume A2: "x1 inHIDDENR3 domRELAT-1K1 f"
              and A3: "x2 inHIDDENR3 domRELAT-1K1 f"
              and A4: "f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2"
            obtain g1 where
              [ty]:"g1 be FunctionFUNCT-1M1" and 
              A5: "x1 =HIDDENR1 g1"and A6: "domRELAT-1K1 g1 =XBOOLE-0R4 Z"and A7: "rngFUNCT-1K2 g1 c=TARSKIR1 [:ZFMISC-1K2 X,Y :]"
              using A1 A2 funct_2_def_2 sorry
            obtain g2 where
              [ty]:"g2 be FunctionFUNCT-1M1" and 
              A8: "x2 =HIDDENR1 g2"and A9: "domRELAT-1K1 g2 =XBOOLE-0R4 Z"and A10: "rngFUNCT-1K2 g2 c=TARSKIR1 [:ZFMISC-1K2 X,Y :]"
              using A1 A3 funct_2_def_2 sorry
            have "[TARSKIK4 pr1FUNCT-3K10(X,Y) *FUNCT-1K3 g1,pr2FUNCT-3K11(X,Y) *FUNCT-1K3 g1 ] =HIDDENR1 f .FUNCT-1K1 x1"
              using A1 A2 A5 sorry
            also have "... = [TARSKIK4 pr1FUNCT-3K10(X,Y) *FUNCT-1K3 g2,pr2FUNCT-3K11(X,Y) *FUNCT-1K3 g2 ]"
              using A1 A3 A4 A8 sorry
            finally have "[TARSKIK4 pr1FUNCT-3K10(X,Y) *FUNCT-1K3 g1,pr2FUNCT-3K11(X,Y) *FUNCT-1K3 g1 ] =HIDDENR1 [TARSKIK4 pr1FUNCT-3K10(X,Y) *FUNCT-1K3 g2,pr2FUNCT-3K11(X,Y) *FUNCT-1K3 g2 ]"
               sorry
            then have A11: "pr1FUNCT-3K10(X,Y) *FUNCT-1K3 g1 =FUNCT-1R1 pr1FUNCT-3K10(X,Y) *FUNCT-1K3 g2 & pr2FUNCT-3K11(X,Y) *FUNCT-1K3 g1 =FUNCT-1R1 pr2FUNCT-3K11(X,Y) *FUNCT-1K3 g2"
              using xtuple_0_th_1 sorry
            have " for x be objectHIDDENM1 holds x inHIDDENR3 Z implies g1 .FUNCT-1K1 x =XBOOLE-0R4 g2 .FUNCT-1K1 x"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume A12: "x inHIDDENR3 Z"
              then have A13: "(pr2FUNCT-3K11(X,Y) *FUNCT-1K3 g1).FUNCT-1K1 x =XBOOLE-0R4 pr2FUNCT-3K11(X,Y) .FUNCT-1K1 (g1 .FUNCT-1K1 x)"
                using A6 funct_1_th_13 sorry
              have A14: "g2 .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 g2"
                using A9 A12 funct_1_def_3 sorry
              then have A15: "g2 .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 (g2 .FUNCT-1K1 x)`1XTUPLE-0K1,(g2 .FUNCT-1K1 x)`2XTUPLE-0K2 ]"
                using A10 mcart_1_th_21 sorry
              have A16: "g1 .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 g1"
                using A6 A12 funct_1_def_3 sorry
              then have A17: "g1 .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 (g1 .FUNCT-1K1 x)`1XTUPLE-0K1,(g1 .FUNCT-1K1 x)`2XTUPLE-0K2 ]"
                using A7 mcart_1_th_21 sorry
              have "(g2 .FUNCT-1K1 x)`1XTUPLE-0K1 inHIDDENR3 X & (g2 .FUNCT-1K1 x)`2XTUPLE-0K2 inHIDDENR3 Y"
                using A10 A14 mcart_1_th_10 sorry
              then have A18: "pr1FUNCT-3K10(X,Y) .BINOP-1K1((g2 .FUNCT-1K1 x)`1XTUPLE-0K1,(g2 .FUNCT-1K1 x)`2XTUPLE-0K2) =HIDDENR1 (g2 .FUNCT-1K1 x)`1XTUPLE-0K1 & pr2FUNCT-3K11(X,Y) .BINOP-1K1((g2 .FUNCT-1K1 x)`1XTUPLE-0K1,(g2 .FUNCT-1K1 x)`2XTUPLE-0K2) =HIDDENR1 (g2 .FUNCT-1K1 x)`2XTUPLE-0K2"
                using funct_3_def_4 funct_3_def_5 sorry
              have "(g1 .FUNCT-1K1 x)`1XTUPLE-0K1 inHIDDENR3 X & (g1 .FUNCT-1K1 x)`2XTUPLE-0K2 inHIDDENR3 Y"
                using A7 A16 mcart_1_th_10 sorry
              then have A19: "pr1FUNCT-3K10(X,Y) .BINOP-1K1((g1 .FUNCT-1K1 x)`1XTUPLE-0K1,(g1 .FUNCT-1K1 x)`2XTUPLE-0K2) =HIDDENR1 (g1 .FUNCT-1K1 x)`1XTUPLE-0K1 & pr2FUNCT-3K11(X,Y) .BINOP-1K1((g1 .FUNCT-1K1 x)`1XTUPLE-0K1,(g1 .FUNCT-1K1 x)`2XTUPLE-0K2) =HIDDENR1 (g1 .FUNCT-1K1 x)`2XTUPLE-0K2"
                using funct_3_def_4 funct_3_def_5 sorry
              have "(pr1FUNCT-3K10(X,Y) *FUNCT-1K3 g1).FUNCT-1K1 x =XBOOLE-0R4 pr1FUNCT-3K10(X,Y) .FUNCT-1K1 (g1 .FUNCT-1K1 x) & (pr1FUNCT-3K10(X,Y) *FUNCT-1K3 g2).FUNCT-1K1 x =XBOOLE-0R4 pr1FUNCT-3K10(X,Y) .FUNCT-1K1 (g2 .FUNCT-1K1 x)"
                using A6 A9 A12 funct_1_th_13 sorry
              thus "g1 .FUNCT-1K1 x =XBOOLE-0R4 g2 .FUNCT-1K1 x"
                using A9 A11 A12 A13 A17 A15 A19 A18 funct_1_th_13 sorry
            qed "sorry"
            thus "x1 =HIDDENR1 x2"
              using A5 A6 A8 A9 funct_1_th_2 sorry
          qed "sorry"
          thus "f be one-to-oneFUNCT-1V2"
            using funct_1_def_4 sorry
        qed
        show "domRELAT-1K1 f =XBOOLE-0R4 FuncsFUNCT-2K1(Z,[:ZFMISC-1K2 X,Y :])"
          using A1 sorry
        have "rngFUNCT-1K2 f c=TARSKIR1 [:ZFMISC-1K2 FuncsFUNCT-2K1(Z,X),FuncsFUNCT-2K1(Z,Y) :] & [:ZFMISC-1K2 FuncsFUNCT-2K1(Z,X),FuncsFUNCT-2K1(Z,Y) :] c=TARSKIR1 proj2XTUPLE-0K13 f"
        proof(rule conjMI)
          show "rngFUNCT-1K2 f c=TARSKIR1 [:ZFMISC-1K2 FuncsFUNCT-2K1(Z,X),FuncsFUNCT-2K1(Z,Y) :]"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 [:ZFMISC-1K2 FuncsFUNCT-2K1(Z,X),FuncsFUNCT-2K1(Z,Y) :]"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 rngFUNCT-1K2 f"
              then obtain y where
                [ty]:"y be objectHIDDENM1" and 
                A20: "y inHIDDENR3 domRELAT-1K1 f"and A21: "x =HIDDENR1 f .FUNCT-1K1 y"
                using funct_1_def_3 sorry
              obtain g where
                [ty]:"g be FunctionFUNCT-1M1" and 
                A22: "y =HIDDENR1 g"and A23: "domRELAT-1K1 g =XBOOLE-0R4 Z & rngFUNCT-1K2 g c=TARSKIR1 [:ZFMISC-1K2 X,Y :]"
                using A1 A20 funct_2_def_2 sorry
              have A24: "rngRELSET-1K2\<^bsub>(X)\<^esub> (pr1FUNCT-3K10(X,Y) *FUNCT-1K3 g) c=TARSKIR1 X"
                 sorry
              have A25: "rngRELSET-1K2\<^bsub>(Y)\<^esub> (pr2FUNCT-3K11(X,Y) *FUNCT-1K3 g) c=TARSKIR1 Y"
                 sorry
              have "domRELSET-1K1\<^bsub>([:ZFMISC-1K2 X,Y :])\<^esub> (pr2FUNCT-3K11(X,Y)) =RELAT-1R1 [:ZFMISC-1K2 X,Y :]"
                using funct_3_def_5 sorry
              then have "domRELAT-1K1 (pr2FUNCT-3K11(X,Y) *FUNCT-1K3 g) =XBOOLE-0R4 Z"
                using A23 relat_1_th_27 sorry
              then have A26: "pr2FUNCT-3K11(X,Y) *FUNCT-1K3 g inTARSKIR2 FuncsFUNCT-2K1(Z,Y)"
                using A25 funct_2_def_2 sorry
              have "domRELSET-1K1\<^bsub>([:ZFMISC-1K2 X,Y :])\<^esub> (pr1FUNCT-3K10(X,Y)) =RELAT-1R1 [:ZFMISC-1K2 X,Y :]"
                using funct_3_def_4 sorry
              then have "domRELAT-1K1 (pr1FUNCT-3K10(X,Y) *FUNCT-1K3 g) =XBOOLE-0R4 Z"
                using A23 relat_1_th_27 sorry
              then have A27: "pr1FUNCT-3K10(X,Y) *FUNCT-1K3 g inTARSKIR2 FuncsFUNCT-2K1(Z,X)"
                using A24 funct_2_def_2 sorry
              have "x =HIDDENR1 [TARSKIK4 pr1FUNCT-3K10(X,Y) *FUNCT-1K3 g,pr2FUNCT-3K11(X,Y) *FUNCT-1K3 g ]"
                using A1 A20 A21 A22 sorry
              thus "x inHIDDENR3 [:ZFMISC-1K2 FuncsFUNCT-2K1(Z,X),FuncsFUNCT-2K1(Z,Y) :]"
                using A27 A26 zfmisc_1_th_87 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 f c=TARSKIR1 [:ZFMISC-1K2 FuncsFUNCT-2K1(Z,X),FuncsFUNCT-2K1(Z,Y) :]"
              using tarski_def_3 sorry
          qed
          have " for x be objectHIDDENM1 holds x inHIDDENR3 [:ZFMISC-1K2 FuncsFUNCT-2K1(Z,X),FuncsFUNCT-2K1(Z,Y) :] implies x inHIDDENR3 proj2XTUPLE-0K13 f"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A28: "x inHIDDENR3 [:ZFMISC-1K2 FuncsFUNCT-2K1(Z,X),FuncsFUNCT-2K1(Z,Y) :]"
            then have A29: "x =HIDDENR1 [TARSKIK4 x `1XTUPLE-0K1,x `2XTUPLE-0K2 ]"
              using mcart_1_th_21 sorry
            have "x `2XTUPLE-0K2 inHIDDENR3 FuncsFUNCT-2K1(Z,Y)"
              using A28 mcart_1_th_10 sorry
            then obtain g2 where
              [ty]:"g2 be FunctionFUNCT-1M1" and 
              A30: "x `2XTUPLE-0K2 =HIDDENR1 g2"and A31: "domRELAT-1K1 g2 =XBOOLE-0R4 Z"and A32: "rngFUNCT-1K2 g2 c=TARSKIR1 Y"
              using funct_2_def_2 sorry
            have "x `1XTUPLE-0K1 inHIDDENR3 FuncsFUNCT-2K1(Z,X)"
              using A28 mcart_1_th_10 sorry
            then obtain g1 where
              [ty]:"g1 be FunctionFUNCT-1M1" and 
              A33: "x `1XTUPLE-0K1 =HIDDENR1 g1"and A34: "domRELAT-1K1 g1 =XBOOLE-0R4 Z"and A35: "rngFUNCT-1K2 g1 c=TARSKIR1 X"
              using funct_2_def_2 sorry
            have "rngFUNCT-1K2 (<:FUNCT-3K14 g1,g2 :>) c=TARSKIR1 [:ZFMISC-1K2 rngFUNCT-1K2 g1,rngFUNCT-1K2 g2 :] & [:ZFMISC-1K2 rngFUNCT-1K2 g1,rngFUNCT-1K2 g2 :] c=RELAT-1R2 [:ZFMISC-1K2 X,Y :]"
              using A35 A32 funct_3_th_51 zfmisc_1_th_96 sorry
            then have A36: "rngFUNCT-1K2 (<:FUNCT-3K14 g1,g2 :>) c=TARSKIR1 [:ZFMISC-1K2 X,Y :]"
               sorry
            have "domRELAT-1K1 (<:FUNCT-3K14 g1,g2 :>) =XBOOLE-0R4 Z /\\XBOOLE-0K3 Z"
              using A34 A31 funct_3_def_7 sorry
            then have A37: "<:FUNCT-3K14 g1,g2 :> inTARSKIR2 FuncsFUNCT-2K1(Z,[:ZFMISC-1K2 X,Y :])"
              using A36 funct_2_def_2 sorry
            have "pr1FUNCT-3K10(X,Y) *FUNCT-1K3 (<:FUNCT-3K14 g1,g2 :>) =FUNCT-1R1 g1 & pr2FUNCT-3K11(X,Y) *FUNCT-1K3 (<:FUNCT-3K14 g1,g2 :>) =FUNCT-1R1 g2"
              using A34 A35 A31 A32 funct_3_th_52 sorry
            then have "f .FUNCT-1K1 (<:FUNCT-3K14 g1,g2 :>) =HIDDENR1 [TARSKIK4 g1,g2 ]"
              using A1 A37 sorry
            thus "x inHIDDENR3 proj2XTUPLE-0K13 f"
              using A1 A29 A33 A30 A37 funct_1_def_3 sorry
          qed "sorry"
          thus "[:ZFMISC-1K2 FuncsFUNCT-2K1(Z,X),FuncsFUNCT-2K1(Z,Y) :] c=TARSKIR1 proj2XTUPLE-0K13 f"
            using tarski_def_3 sorry
        qed
        thus "proj2XTUPLE-0K13 f =HIDDENR1 [:ZFMISC-1K2 FuncsFUNCT-2K1(Z,X),FuncsFUNCT-2K1(Z,Y) :]"
          using xboole_0_def_10 sorry
      qed
      thus "(FuncsFUNCT-2K1(Z,[:ZFMISC-1K2 X,Y :]),[:ZFMISC-1K2 FuncsFUNCT-2K1(Z,X),FuncsFUNCT-2K1(Z,Y) :])are-equipotentWELLORD2R2"
        using bexI[of _ "f"] wellord2_def_4 sorry
    qed
    thus "cardCARD-1K1 (FuncsFUNCT-2K1(Z,[:ZFMISC-1K2 X,Y :])) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 FuncsFUNCT-2K1(Z,X),FuncsFUNCT-2K1(Z,Y) :])"
      using card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_65:
" for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x <>HIDDENR2 y implies (FuncsFUNCT-2K9(X,{TARSKIK2 x,y }),boolZFMISC-1K1 X)are-equipotentWELLORD2R2 & cardCARD-1K1 (FuncsFUNCT-2K9(X,{TARSKIK2 x,y })) =XBOOLE-0R4 cardCARD-1K1 (boolZFMISC-1K1 X)"
proof-
  have " for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x <>HIDDENR2 y implies (FuncsFUNCT-2K9(X,{TARSKIK2 x,y }),boolZFMISC-1K1 X)are-equipotentWELLORD2R2 & cardCARD-1K1 (FuncsFUNCT-2K9(X,{TARSKIK2 x,y })) =XBOOLE-0R4 cardCARD-1K1 (boolZFMISC-1K1 X)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    let ?F = "\<lambda>Lamb1. Lamb1 \<inverse>FUNCT-1K6 {TARSKIK1 x}"
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A1: "domRELAT-1K1 f =XBOOLE-0R4 FuncsFUNCT-2K9(X,{TARSKIK2 x,y }) & ( for g be FunctionFUNCT-1M1 holds g inTARSKIR2 FuncsFUNCT-2K9(X,{TARSKIK2 x,y }) implies f .FUNCT-1K1 g =XBOOLE-0R4 ?F(g))"
      using funct_5_sch_1 sorry
    assume A2: "x <>HIDDENR2 y"
    show "(FuncsFUNCT-2K9(X,{TARSKIK2 x,y }),boolZFMISC-1K1 X)are-equipotentWELLORD2R2"
    proof-
      let ?F = "\<lambda>Lamb1. x"
      have "f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 FuncsFUNCT-2K9(X,{TARSKIK2 x,y }) & proj2XTUPLE-0K13 f =HIDDENR1 boolZFMISC-1K1 X)"
      proof(rule conjMI,rule conjMI)
        show "f be one-to-oneFUNCT-1V2"
        proof-
          have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds x1 inHIDDENR3 domRELAT-1K1 f & (x2 inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2) implies x1 =HIDDENR1 x2"
          proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
            fix x1 assume [ty]: "x1 be objectHIDDENM1"
            fix x2 assume [ty]: "x2 be objectHIDDENM1"
            assume A3: "x1 inHIDDENR3 domRELAT-1K1 f"
              and A4: "x2 inHIDDENR3 domRELAT-1K1 f"
              and A5: "f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2"
            obtain g2 where
              [ty]:"g2 be FunctionFUNCT-1M1" and 
              A6: "x2 =HIDDENR1 g2"and A7: "domRELAT-1K1 g2 =XBOOLE-0R4 X"and A8: "rngFUNCT-1K2 g2 c=TARSKIR1 {TARSKIK2 x,y }"
              using A1 A4 funct_2_def_2 sorry
            have A9: "f .FUNCT-1K1 x2 =XBOOLE-0R4 g2 \<inverse>FUNCT-1K6 {TARSKIK1 x}"
              using A1 A4 A6 sorry
            obtain g1 where
              [ty]:"g1 be FunctionFUNCT-1M1" and 
              A10: "x1 =HIDDENR1 g1"and A11: "domRELAT-1K1 g1 =XBOOLE-0R4 X"and A12: "rngFUNCT-1K2 g1 c=TARSKIR1 {TARSKIK2 x,y }"
              using A1 A3 funct_2_def_2 sorry
            have A13: "f .FUNCT-1K1 x1 =XBOOLE-0R4 g1 \<inverse>FUNCT-1K6 {TARSKIK1 x}"
              using A1 A3 A10 sorry
            have " for z be objectHIDDENM1 holds z inHIDDENR3 X implies g1 .FUNCT-1K1 z =XBOOLE-0R4 g2 .FUNCT-1K1 z"
            proof(rule ballI,rule impI)
              fix z assume [ty]: "z be objectHIDDENM1"
              assume A14: "z inHIDDENR3 X"
              have A15: " not g1 .FUNCT-1K1 z inTARSKIR2 {TARSKIK1 x} implies g1 .FUNCT-1K1 z =XBOOLE-0R4 g2 .FUNCT-1K1 z"
              proof(rule impI)
                assume A16: " not g1 .FUNCT-1K1 z inTARSKIR2 {TARSKIK1 x}"
                then have A17: "g1 .FUNCT-1K1 z <>HIDDENR2 x"
                  using tarski_def_1 sorry
                have " not z inHIDDENR3 g2 \<inverse>FUNCT-1K6 {TARSKIK1 x}"
                  using A5 A13 A9 A16 funct_1_def_7 sorry
                then have " not g2 .FUNCT-1K1 z inTARSKIR2 {TARSKIK1 x}"
                  using A7 A14 funct_1_def_7 sorry
                then have A18: "g2 .FUNCT-1K1 z <>HIDDENR2 x"
                  using tarski_def_1 sorry
                have "g1 .FUNCT-1K1 z inTARSKIR2 rngFUNCT-1K2 g1"
                  using A11 A14 funct_1_def_3 sorry
                then have A19: "g1 .FUNCT-1K1 z =HIDDENR1 y"
                  using A12 A17 tarski_def_2 sorry
                have "g2 .FUNCT-1K1 z inTARSKIR2 rngFUNCT-1K2 g2"
                  using A7 A14 funct_1_def_3 sorry
                thus "g1 .FUNCT-1K1 z =XBOOLE-0R4 g2 .FUNCT-1K1 z"
                  using A8 A18 A19 tarski_def_2 sorry
              qed
              have "g1 .FUNCT-1K1 z inTARSKIR2 {TARSKIK1 x} implies g1 .FUNCT-1K1 z =XBOOLE-0R4 g2 .FUNCT-1K1 z"
              proof(rule impI)
                assume A20: "g1 .FUNCT-1K1 z inTARSKIR2 {TARSKIK1 x}"
                then have "z inHIDDENR3 g2 \<inverse>FUNCT-1K6 {TARSKIK1 x}"
                  using A5 A11 A13 A9 A14 funct_1_def_7 sorry
                then have "g2 .FUNCT-1K1 z inTARSKIR2 {TARSKIK1 x}"
                  using funct_1_def_7 sorry
                then have "g2 .FUNCT-1K1 z =HIDDENR1 x"
                  using tarski_def_1 sorry
                thus "g1 .FUNCT-1K1 z =XBOOLE-0R4 g2 .FUNCT-1K1 z"
                  using A20 tarski_def_1 sorry
              qed
              thus "g1 .FUNCT-1K1 z =XBOOLE-0R4 g2 .FUNCT-1K1 z"
                using A15 sorry
            qed "sorry"
            thus "x1 =HIDDENR1 x2"
              using A10 A11 A6 A7 funct_1_th_2 sorry
          qed "sorry"
          thus "f be one-to-oneFUNCT-1V2"
            using funct_1_def_4 sorry
        qed
        show "domRELAT-1K1 f =XBOOLE-0R4 FuncsFUNCT-2K9(X,{TARSKIK2 x,y })"
          using A1 sorry
        have "rngFUNCT-1K2 f c=TARSKIR1 boolZFMISC-1K1 X & boolZFMISC-1K1 X c=TARSKIR1 proj2XTUPLE-0K13 f"
        proof(rule conjMI)
          show "rngFUNCT-1K2 f c=TARSKIR1 boolZFMISC-1K1 X"
          proof-
            have " for z be objectHIDDENM1 holds z inHIDDENR3 rngFUNCT-1K2 f implies z inHIDDENR3 boolZFMISC-1K1 X"
            proof(rule ballI,rule impI)
              fix z assume [ty]: "z be objectHIDDENM1"
              assume "z inHIDDENR3 rngFUNCT-1K2 f"
              then obtain t where
                [ty]:"t be objectHIDDENM1" and 
                A21: "t inHIDDENR3 domRELAT-1K1 f"and A22: "z =HIDDENR1 f .FUNCT-1K1 t"
                using funct_1_def_3 sorry
              obtain g where
                [ty]:"g be FunctionFUNCT-1M1" and 
                A23: "t =HIDDENR1 g"and A24: "domRELAT-1K1 g =XBOOLE-0R4 X"and "rngFUNCT-1K2 g c=TARSKIR1 {TARSKIK2 x,y }"
                using A1 A21 funct_2_def_2 sorry
              have A25: "g \<inverse>FUNCT-1K6 {TARSKIK1 x} c=TARSKIR1 X"
                using A24 relat_1_th_132 sorry
              have "z =HIDDENR1 g \<inverse>FUNCT-1K6 {TARSKIK1 x}"
                using A1 A21 A22 A23 sorry
              thus "z inHIDDENR3 boolZFMISC-1K1 X"
                using A25 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 f c=TARSKIR1 boolZFMISC-1K1 X"
              using tarski_def_3 sorry
          qed
          let ?G = "\<lambda>Lamb1. y"
          have " for z be objectHIDDENM1 holds z inHIDDENR3 boolZFMISC-1K1 X implies z inHIDDENR3 proj2XTUPLE-0K13 f"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be objectHIDDENM1"
            obtain zz where 
              [ty]:"zz be setHIDDENM2" and zzDef:"zz = z"
              using tarski_th_1 sorry
            let ?P = "\<lambda>Lamb1. Lamb1 inHIDDENR3 zz"
            obtain g where
              [ty]:"g be FunctionFUNCT-1M1" and 
              A26: "domRELAT-1K1 g =XBOOLE-0R4 X & ( for t be objectHIDDENM1 holds t inHIDDENR3 X implies (?P(t) implies g .FUNCT-1K1 t =HIDDENR1 ?F(t)) & ( not ?P(t) implies g .FUNCT-1K1 t =HIDDENR1 ?G(t)))"
              using partfun1_sch_1 sorry
            assume A27: "z inHIDDENR3 boolZFMISC-1K1 X"
            have A28: "g \<inverse>FUNCT-1K6 {TARSKIK1 x} =XBOOLE-0R4 zz"
            proof-
              have "g \<inverse>FUNCT-1K6 {TARSKIK1 x} c=TARSKIR1 zz & zz c=TARSKIR1 g \<inverse>FUNCT-1K6 {TARSKIK1 x}"
              proof(rule conjMI)
                show "g \<inverse>FUNCT-1K6 {TARSKIK1 x} c=TARSKIR1 zz"
                proof-
                  have " for t be objectHIDDENM1 holds t inHIDDENR3 g \<inverse>FUNCT-1K6 {TARSKIK1 x} implies t inHIDDENR3 zz"
                  proof(rule ballI,rule impI)
                    fix t assume [ty]: "t be objectHIDDENM1"
                    assume A29: "t inHIDDENR3 g \<inverse>FUNCT-1K6 {TARSKIK1 x}"
                    then have "g .FUNCT-1K1 t inTARSKIR2 {TARSKIK1 x}"
                      using funct_1_def_7 sorry
                    then have A30: "g .FUNCT-1K1 t =HIDDENR1 x"
                      using tarski_def_1 sorry
                    have "t inHIDDENR3 domRELAT-1K1 g"
                      using A29 funct_1_def_7 sorry
                    thus "t inHIDDENR3 zz"
                      using A2 A26 A30 sorry
                  qed "sorry"
                  thus "g \<inverse>FUNCT-1K6 {TARSKIK1 x} c=TARSKIR1 zz"
                    using tarski_def_3 sorry
                qed
                have " for t be objectHIDDENM1 holds t inHIDDENR3 zz implies t inHIDDENR3 g \<inverse>FUNCT-1K6 {TARSKIK1 x}"
                proof(rule ballI,rule impI)
                  fix t assume [ty]: "t be objectHIDDENM1"
                  assume A31: "t inHIDDENR3 zz"
                  then have "g .FUNCT-1K1 t =HIDDENR1 x"
                    using A27 A26 sorry
                  then have "g .FUNCT-1K1 t inTARSKIR2 {TARSKIK1 x}"
                    using tarski_def_1 sorry
                  thus "t inHIDDENR3 g \<inverse>FUNCT-1K6 {TARSKIK1 x}"
                    using A27 A26 A31 funct_1_def_7 sorry
                qed "sorry"
                thus "zz c=TARSKIR1 g \<inverse>FUNCT-1K6 {TARSKIK1 x}"
                  using tarski_def_3 sorry
              qed
              thus "g \<inverse>FUNCT-1K6 {TARSKIK1 x} =XBOOLE-0R4 zz"
                using xboole_0_def_10 sorry
            qed
            have "rngFUNCT-1K2 g c=TARSKIR1 {TARSKIK2 x,y }"
            proof-
              have " for t be objectHIDDENM1 holds t inHIDDENR3 rngFUNCT-1K2 g implies t inHIDDENR3 {TARSKIK2 x,y }"
              proof(rule ballI,rule impI)
                fix t assume [ty]: "t be objectHIDDENM1"
                assume "t inHIDDENR3 rngFUNCT-1K2 g"
                then have " ex v be objectHIDDENM1 st v inHIDDENR3 domRELAT-1K1 g & t =HIDDENR1 g .FUNCT-1K1 v"
                  using funct_1_def_3 sorry
                then have "t =HIDDENR1 x or t =HIDDENR1 y"
                  using A26 sorry
                thus "t inHIDDENR3 {TARSKIK2 x,y }"
                  using tarski_def_2 sorry
              qed "sorry"
              thus "rngFUNCT-1K2 g c=TARSKIR1 {TARSKIK2 x,y }"
                using tarski_def_3 sorry
            qed
            then have A32: "g inTARSKIR2 FuncsFUNCT-2K9(X,{TARSKIK2 x,y })"
              using A26 funct_2_def_2 sorry
            then have "f .FUNCT-1K1 g =XBOOLE-0R4 g \<inverse>FUNCT-1K6 {TARSKIK1 x}"
              using A1 sorry
            thus "z inHIDDENR3 proj2XTUPLE-0K13 f"
              using A1 A32 A28 funct_1_def_3 sorry
          qed "sorry"
          thus "boolZFMISC-1K1 X c=TARSKIR1 proj2XTUPLE-0K13 f"
            using tarski_def_3 sorry
        qed
        thus "proj2XTUPLE-0K13 f =HIDDENR1 boolZFMISC-1K1 X"
          using xboole_0_def_10 sorry
      qed
      thus "(FuncsFUNCT-2K9(X,{TARSKIK2 x,y }),boolZFMISC-1K1 X)are-equipotentWELLORD2R2"
        using bexI[of _ "f"] wellord2_def_4 sorry
    qed
    thus "cardCARD-1K1 (FuncsFUNCT-2K9(X,{TARSKIK2 x,y })) =XBOOLE-0R4 cardCARD-1K1 (boolZFMISC-1K1 X)"
      using card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_66:
" for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x <>HIDDENR2 y implies (FuncsFUNCT-2K1({TARSKIK2 x,y },X),[:ZFMISC-1K2 X,X :])are-equipotentWELLORD2R2 & cardCARD-1K1 (FuncsFUNCT-2K1({TARSKIK2 x,y },X)) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 X,X :])"
proof-
  have " for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x <>HIDDENR2 y implies (FuncsFUNCT-2K1({TARSKIK2 x,y },X),[:ZFMISC-1K2 X,X :])are-equipotentWELLORD2R2 & cardCARD-1K1 (FuncsFUNCT-2K1({TARSKIK2 x,y },X)) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 X,X :])"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    let ?F = "\<lambda>Lamb1. [TARSKIK4 Lamb1 .FUNCT-1K1 x,Lamb1 .FUNCT-1K1 y ]"
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A1: "domRELAT-1K1 f =XBOOLE-0R4 FuncsFUNCT-2K1({TARSKIK2 x,y },X) & ( for g be FunctionFUNCT-1M1 holds g inTARSKIR2 FuncsFUNCT-2K1({TARSKIK2 x,y },X) implies f .FUNCT-1K1 g =HIDDENR1 ?F(g))"
      using funct_5_sch_1 sorry
    assume A2: "x <>HIDDENR2 y"
    show "(FuncsFUNCT-2K1({TARSKIK2 x,y },X),[:ZFMISC-1K2 X,X :])are-equipotentWELLORD2R2"
    proof-
      let ?P = "\<lambda>Lamb1. Lamb1 =HIDDENR1 x"
      have "f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 FuncsFUNCT-2K1({TARSKIK2 x,y },X) & proj2XTUPLE-0K13 f =HIDDENR1 [:ZFMISC-1K2 X,X :])"
      proof(rule conjMI,rule conjMI)
        show "f be one-to-oneFUNCT-1V2"
        proof-
          have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds x1 inHIDDENR3 domRELAT-1K1 f & (x2 inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2) implies x1 =HIDDENR1 x2"
          proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
            fix x1 assume [ty]: "x1 be objectHIDDENM1"
            fix x2 assume [ty]: "x2 be objectHIDDENM1"
            assume A3: "x1 inHIDDENR3 domRELAT-1K1 f"
              and A4: "x2 inHIDDENR3 domRELAT-1K1 f"
              and A5: "f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2"
            obtain g2 where
              [ty]:"g2 be FunctionFUNCT-1M1" and 
              A6: "x2 =HIDDENR1 g2"and A7: "domRELAT-1K1 g2 =XBOOLE-0R4 {TARSKIK2 x,y }"and "rngFUNCT-1K2 g2 c=TARSKIR1 X"
              using A1 A4 funct_2_def_2 sorry
            obtain g1 where
              [ty]:"g1 be FunctionFUNCT-1M1" and 
              A8: "x1 =HIDDENR1 g1"and A9: "domRELAT-1K1 g1 =XBOOLE-0R4 {TARSKIK2 x,y }"and "rngFUNCT-1K2 g1 c=TARSKIR1 X"
              using A1 A3 funct_2_def_2 sorry
            have A10: "[TARSKIK4 g1 .FUNCT-1K1 x,g1 .FUNCT-1K1 y ] =HIDDENR1 f .FUNCT-1K1 x1"
              using A1 A3 A8 sorry
            also have "... = [TARSKIK4 g2 .FUNCT-1K1 x,g2 .FUNCT-1K1 y ]"
              using A1 A4 A5 A6 sorry
            finally have "[TARSKIK4 g1 .FUNCT-1K1 x,g1 .FUNCT-1K1 y ] =HIDDENR1 [TARSKIK4 g2 .FUNCT-1K1 x,g2 .FUNCT-1K1 y ]"
               sorry
            have " for z be objectHIDDENM1 holds z inHIDDENR3 {TARSKIK2 x,y } implies g1 .FUNCT-1K1 z =XBOOLE-0R4 g2 .FUNCT-1K1 z"
            proof(rule ballI,rule impI)
              fix z assume [ty]: "z be objectHIDDENM1"
              assume "z inHIDDENR3 {TARSKIK2 x,y }"
              then have "z =HIDDENR1 x or z =HIDDENR1 y"
                using tarski_def_2 sorry
              thus "g1 .FUNCT-1K1 z =XBOOLE-0R4 g2 .FUNCT-1K1 z"
                using A10 xtuple_0_th_1 sorry
            qed "sorry"
            thus "x1 =HIDDENR1 x2"
              using A8 A9 A6 A7 funct_1_th_2 sorry
          qed "sorry"
          thus "f be one-to-oneFUNCT-1V2"
            using funct_1_def_4 sorry
        qed
        show "domRELAT-1K1 f =XBOOLE-0R4 FuncsFUNCT-2K1({TARSKIK2 x,y },X)"
          using A1 sorry
        have "rngFUNCT-1K2 f c=TARSKIR1 [:ZFMISC-1K2 X,X :] & [:ZFMISC-1K2 X,X :] c=TARSKIR1 proj2XTUPLE-0K13 f"
        proof(rule conjMI)
          show "rngFUNCT-1K2 f c=TARSKIR1 [:ZFMISC-1K2 X,X :]"
          proof-
            have " for z be objectHIDDENM1 holds z inHIDDENR3 rngFUNCT-1K2 f implies z inHIDDENR3 [:ZFMISC-1K2 X,X :]"
            proof(rule ballI,rule impI)
              fix z assume [ty]: "z be objectHIDDENM1"
              assume "z inHIDDENR3 rngFUNCT-1K2 f"
              then obtain t where
                [ty]:"t be objectHIDDENM1" and 
                A11: "t inHIDDENR3 domRELAT-1K1 f"and A12: "z =HIDDENR1 f .FUNCT-1K1 t"
                using funct_1_def_3 sorry
              obtain g where
                [ty]:"g be FunctionFUNCT-1M1" and 
                A13: "t =HIDDENR1 g"and A14: "domRELAT-1K1 g =XBOOLE-0R4 {TARSKIK2 x,y }"and A15: "rngFUNCT-1K2 g c=TARSKIR1 X"
                using A1 A11 funct_2_def_2 sorry
              have "x inHIDDENR3 {TARSKIK2 x,y }"
                using tarski_def_2 sorry
              then have A16: "g .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 g"
                using A14 funct_1_def_3 sorry
              have "y inHIDDENR3 {TARSKIK2 x,y }"
                using tarski_def_2 sorry
              then have A17: "g .FUNCT-1K1 y inTARSKIR2 rngFUNCT-1K2 g"
                using A14 funct_1_def_3 sorry
              have "z =HIDDENR1 [TARSKIK4 g .FUNCT-1K1 x,g .FUNCT-1K1 y ]"
                using A1 A11 A12 A13 sorry
              thus "z inHIDDENR3 [:ZFMISC-1K2 X,X :]"
                using A15 A16 A17 zfmisc_1_th_87 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 f c=TARSKIR1 [:ZFMISC-1K2 X,X :]"
              using tarski_def_3 sorry
          qed
          have " for z be objectHIDDENM1 holds z inHIDDENR3 [:ZFMISC-1K2 X,X :] implies z inHIDDENR3 proj2XTUPLE-0K13 f"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be objectHIDDENM1"
            let ?F = "\<lambda>Lamb1. z `1XTUPLE-0K1"
            let ?G = "\<lambda>Lamb1. z `2XTUPLE-0K2"
            obtain g where
              [ty]:"g be FunctionFUNCT-1M1" and 
              A18: "domRELAT-1K1 g =XBOOLE-0R4 {TARSKIK2 x,y } & ( for t be objectHIDDENM1 holds t inHIDDENR3 {TARSKIK2 x,y } implies (?P(t) implies g .FUNCT-1K1 t =HIDDENR1 ?F(t)) & ( not ?P(t) implies g .FUNCT-1K1 t =HIDDENR1 ?G(t)))"
              using partfun1_sch_1 sorry
            have "x inHIDDENR3 {TARSKIK2 x,y }"
              using tarski_def_2 sorry
            then have A19: "g .FUNCT-1K1 x =HIDDENR1 z `1XTUPLE-0K1"
              using A18 sorry
            have "y inHIDDENR3 {TARSKIK2 x,y }"
              using tarski_def_2 sorry
            then have A20: "g .FUNCT-1K1 y =HIDDENR1 z `2XTUPLE-0K2"
              using A2 A18 sorry
            assume A21: "z inHIDDENR3 [:ZFMISC-1K2 X,X :]"
            then have A22: "z =HIDDENR1 [TARSKIK4 z `1XTUPLE-0K1,z `2XTUPLE-0K2 ]"
              using mcart_1_th_21 sorry
            have A23: "z `1XTUPLE-0K1 inHIDDENR3 X & z `2XTUPLE-0K2 inHIDDENR3 X"
              using A21 mcart_1_th_10 sorry
            have "rngFUNCT-1K2 g c=TARSKIR1 X"
            proof-
              have " for t be objectHIDDENM1 holds t inHIDDENR3 rngFUNCT-1K2 g implies t inHIDDENR3 X"
              proof(rule ballI,rule impI)
                fix t assume [ty]: "t be objectHIDDENM1"
                assume "t inHIDDENR3 rngFUNCT-1K2 g"
                then have " ex a be objectHIDDENM1 st a inHIDDENR3 domRELAT-1K1 g & t =HIDDENR1 g .FUNCT-1K1 a"
                  using funct_1_def_3 sorry
                thus "t inHIDDENR3 X"
                  using A23 A18 sorry
              qed "sorry"
              thus "rngFUNCT-1K2 g c=TARSKIR1 X"
                using tarski_def_3 sorry
            qed
            then have A24: "g inTARSKIR2 FuncsFUNCT-2K1({TARSKIK2 x,y },X)"
              using A18 funct_2_def_2 sorry
            then have "f .FUNCT-1K1 g =HIDDENR1 [TARSKIK4 g .FUNCT-1K1 x,g .FUNCT-1K1 y ]"
              using A1 sorry
            thus "z inHIDDENR3 proj2XTUPLE-0K13 f"
              using A1 A22 A24 A19 A20 funct_1_def_3 sorry
          qed "sorry"
          thus "[:ZFMISC-1K2 X,X :] c=TARSKIR1 proj2XTUPLE-0K13 f"
            using tarski_def_3 sorry
        qed
        thus "proj2XTUPLE-0K13 f =HIDDENR1 [:ZFMISC-1K2 X,X :]"
          using xboole_0_def_10 sorry
      qed
      thus "(FuncsFUNCT-2K1({TARSKIK2 x,y },X),[:ZFMISC-1K2 X,X :])are-equipotentWELLORD2R2"
        using bexI[of _ "f"] wellord2_def_4 sorry
    qed
    thus "cardCARD-1K1 (FuncsFUNCT-2K1({TARSKIK2 x,y },X)) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 X,X :])"
      using card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
abbreviation(input) FUNCT_5K5("op0FUNCT-5K5" 210) where
  "op0FUNCT-5K5 \<equiv> 0ORDINAL1K5"

abbreviation(input) FUNCT_5K6("op0FUNCT-5K6" 210) where
  "op0FUNCT-5K6 \<equiv> 0ORDINAL1K5"

mtheorem funct_5_add_1:
"cluster 0ORDINAL1K5 as-term-is ElementSUBSET-1M1-of {TARSKIK1 0ORDINAL1K5 }"
proof
(*coherence*)
  show "0ORDINAL1K5 be ElementSUBSET-1M1-of {TARSKIK1 0ORDINAL1K5 }"
    using tarski_def_1 sorry
qed "sorry"

mdef funct_5_def_5 ("op1FUNCT-5K7" 210 ) where
"func op1FUNCT-5K7 \<rightarrow> setHIDDENM2 equals
  (0ORDINAL1K5).-->FUNCOP-1K17 (0ORDINAL1K5)"
proof-
  (*coherence*)
    show "(0ORDINAL1K5).-->FUNCOP-1K17 (0ORDINAL1K5) be setHIDDENM2"
       sorry
qed "sorry"

mdef funct_5_def_6 ("op2FUNCT-5K8" 210 ) where
"func op2FUNCT-5K8 \<rightarrow> setHIDDENM2 equals
  (0ORDINAL1K5,0ORDINAL1K5):->FUNCOP-1K19 (0ORDINAL1K5)"
proof-
  (*coherence*)
    show "(0ORDINAL1K5,0ORDINAL1K5):->FUNCOP-1K19 (0ORDINAL1K5) be setHIDDENM2"
       sorry
qed "sorry"

abbreviation(input) FUNCT_5K9("op1FUNCT-5K9" 210) where
  "op1FUNCT-5K9 \<equiv> op1FUNCT-5K7"

mtheorem funct_5_add_2:
"cluster op1FUNCT-5K7 as-term-is UnOpBINOP-1M1-of {TARSKIK1 0ORDINAL1K5 }"
proof
(*coherence*)
  show "op1FUNCT-5K7 be UnOpBINOP-1M1-of {TARSKIK1 0ORDINAL1K5 }"
     sorry
qed "sorry"

abbreviation(input) FUNCT_5K10("op2FUNCT-5K10" 210) where
  "op2FUNCT-5K10 \<equiv> op2FUNCT-5K8"

mtheorem funct_5_add_3:
"cluster op2FUNCT-5K8 as-term-is BinOpBINOP-1M2-of {TARSKIK1 0ORDINAL1K5 }"
proof
(*coherence*)
  show "op2FUNCT-5K8 be BinOpBINOP-1M2-of {TARSKIK1 0ORDINAL1K5 }"
     sorry
qed "sorry"

reserve C, D, E for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve c for "ElementSUBSET-1M1-of C"
reserve d for "ElementSUBSET-1M1-of D"
syntax FUNCT_5K11 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ .FUNCT-5K11\<^bsub>'( _ , _ , _ , _ ')\<^esub>  _ " [200,0,0,0,0,200]200)
translations "f .FUNCT-5K11\<^bsub>(D,X,E,F)\<^esub> d" \<rightharpoonup> "f .FUNCT-1K1 d"

mtheorem funct_5_add_4:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X be setHIDDENM2", "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be FUNCTION-DOMAINFUNCT-2M3-of(X,E)", "f be FunctionFUNCT-2M1-of(D,F)", "d be ElementSUBSET-1M1-of D"
"cluster f .FUNCT-1K1 d as-term-is ElementFUNCT-2M4\<^bsub>(X,E)\<^esub>-of F"
proof
(*coherence*)
  show "f .FUNCT-1K1 d be ElementFUNCT-2M4\<^bsub>(X,E)\<^esub>-of F"
  proof-
    have "f .FUNCT-2K3\<^bsub>(D,F)\<^esub> d be ElementFUNCT-2M4\<^bsub>(X,E)\<^esub>-of F"
    proof-
      show "f .FUNCT-2K3\<^bsub>(D,F)\<^esub> d be ElementFUNCT-2M4\<^bsub>(X,E)\<^esub>-of F"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

reserve f for "FunctionFUNCT-2M1-of([:ZFMISC-1K2 C,D :],E)"
mtheorem funct_5_th_67:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 C,D :],E) holds curryFUNCT-5K1 f be FunctionFUNCT-2M1-of(C,FuncsFUNCT-2K9(D,E))"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 C,D :],E) holds curryFUNCT-5K1 f be FunctionFUNCT-2M1-of(C,FuncsFUNCT-2K9(D,E))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 C,D :],E)"
    have A1: "domRELSET-1K1\<^bsub>([:ZFMISC-1K2 C,D :])\<^esub> f =RELAT-1R1 [:ZFMISC-1K2 C,D :]"
      using funct_2_def_1 sorry
    have A2: "rngFUNCT-1K2 (curryFUNCT-5K1 f) c=TARSKIR1 FuncsFUNCT-2K9(D,E)"
    proof-
      have A3: "rngFUNCT-1K2 (curryFUNCT-5K1 f) c=TARSKIR1 FuncsFUNCT-2K1(D,rngRELSET-1K2\<^bsub>(E)\<^esub> f)"
        using A1 funct_5_th_35 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (curryFUNCT-5K1 f) implies x inHIDDENR3 FuncsFUNCT-2K9(D,E)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 (curryFUNCT-5K1 f)"
        then obtain g where
          [ty]:"g be FunctionFUNCT-1M1" and 
          A4: "x =HIDDENR1 g"and A5: "domRELAT-1K1 g =XBOOLE-0R4 D"and A6: "rngFUNCT-1K2 g c=TARSKIR1 rngRELSET-1K2\<^bsub>(E)\<^esub> f"
          using A3 funct_2_def_2 sorry
        have "rngFUNCT-1K2 g c=TARSKIR1 E"
          using A6 xboole_1_th_1 sorry
        then have "g be FunctionFUNCT-2M1-of(D,E)"
          using A5 funct_2_def_1 relset_1_th_4 sorry
        thus "x inHIDDENR3 FuncsFUNCT-2K9(D,E)"
          using A4 funct_2_th_8 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 (curryFUNCT-5K1 f) c=TARSKIR1 FuncsFUNCT-2K9(D,E)"
        using tarski_def_3 sorry
    qed
    have "domRELAT-1K1 (curryFUNCT-5K1 f) =XBOOLE-0R4 C"
      using A1 funct_5_th_24 sorry
    thus "curryFUNCT-5K1 f be FunctionFUNCT-2M1-of(C,FuncsFUNCT-2K9(D,E))"
      using A2 funct_2_def_1 relset_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_68:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 C,D :],E) holds curry'FUNCT-5K3 f be FunctionFUNCT-2M1-of(D,FuncsFUNCT-2K9(C,E))"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 C,D :],E) holds curry'FUNCT-5K3 f be FunctionFUNCT-2M1-of(D,FuncsFUNCT-2K9(C,E))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 C,D :],E)"
    have A1: "domRELSET-1K1\<^bsub>([:ZFMISC-1K2 C,D :])\<^esub> f =RELAT-1R1 [:ZFMISC-1K2 C,D :]"
      using funct_2_def_1 sorry
    have A2: "rngFUNCT-1K2 (curry'FUNCT-5K3 f) c=TARSKIR1 FuncsFUNCT-2K9(C,E)"
    proof-
      have A3: "rngFUNCT-1K2 (curry'FUNCT-5K3 f) c=TARSKIR1 FuncsFUNCT-2K1(C,rngRELSET-1K2\<^bsub>(E)\<^esub> f)"
        using A1 funct_5_th_35 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (curry'FUNCT-5K3 f) implies x inHIDDENR3 FuncsFUNCT-2K9(C,E)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 (curry'FUNCT-5K3 f)"
        then obtain g where
          [ty]:"g be FunctionFUNCT-1M1" and 
          A4: "x =HIDDENR1 g"and A5: "domRELAT-1K1 g =XBOOLE-0R4 C"and A6: "rngFUNCT-1K2 g c=TARSKIR1 rngRELSET-1K2\<^bsub>(E)\<^esub> f"
          using A3 funct_2_def_2 sorry
        have "rngFUNCT-1K2 g c=TARSKIR1 E"
          using A6 xboole_1_th_1 sorry
        then have "g be FunctionFUNCT-2M1-of(C,E)"
          using A5 funct_2_def_1 relset_1_th_4 sorry
        thus "x inHIDDENR3 FuncsFUNCT-2K9(C,E)"
          using A4 funct_2_th_8 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 (curry'FUNCT-5K3 f) c=TARSKIR1 FuncsFUNCT-2K9(C,E)"
        using tarski_def_3 sorry
    qed
    have "domRELAT-1K1 (curry'FUNCT-5K3 f) =XBOOLE-0R4 D"
      using A1 funct_5_th_24 sorry
    thus "curry'FUNCT-5K3 f be FunctionFUNCT-2M1-of(D,FuncsFUNCT-2K9(C,E))"
      using A2 funct_2_def_1 relset_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax FUNCT_5K12 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("curryFUNCT-5K12\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [0,0,0,228]228)
translations "curryFUNCT-5K12\<^bsub>(C,D,E)\<^esub> f" \<rightharpoonup> "curryFUNCT-5K1 f"

mtheorem funct_5_add_5:
  mlet "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 C,D :],E)"
"cluster curryFUNCT-5K1 f as-term-is FunctionFUNCT-2M1-of(C,FuncsFUNCT-2K9(D,E))"
proof
(*coherence*)
  show "curryFUNCT-5K1 f be FunctionFUNCT-2M1-of(C,FuncsFUNCT-2K9(D,E))"
    using funct_5_th_67 sorry
qed "sorry"

syntax FUNCT_5K13 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("curry''FUNCT-5K13\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [0,0,0,228]228)
translations "curry'FUNCT-5K13\<^bsub>(C,D,E)\<^esub> f" \<rightharpoonup> "curry'FUNCT-5K3 f"

mtheorem funct_5_add_6:
  mlet "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 C,D :],E)"
"cluster curry'FUNCT-5K3 f as-term-is FunctionFUNCT-2M1-of(D,FuncsFUNCT-2K9(C,E))"
proof
(*coherence*)
  show "curry'FUNCT-5K3 f be FunctionFUNCT-2M1-of(D,FuncsFUNCT-2K9(C,E))"
    using funct_5_th_68 sorry
qed "sorry"

mtheorem funct_5_th_69:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for d be ElementSUBSET-1M1-of D holds  for f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 C,D :],E) holds f .BINOP-1K2\<^bsub>(C,D,E)\<^esub>(c,d) =XBOOLE-0R4 (curryFUNCT-5K12\<^bsub>(C,D,E)\<^esub> f .FUNCT-5K11\<^bsub>(C,D,E,FuncsFUNCT-2K9(D,E))\<^esub> c).FUNCT-2K3\<^bsub>(D,E)\<^esub> d"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for d be ElementSUBSET-1M1-of D holds  for f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 C,D :],E) holds f .BINOP-1K2\<^bsub>(C,D,E)\<^esub>(c,d) =XBOOLE-0R4 (curryFUNCT-5K12\<^bsub>(C,D,E)\<^esub> f .FUNCT-5K11\<^bsub>(C,D,E,FuncsFUNCT-2K9(D,E))\<^esub> c).FUNCT-2K3\<^bsub>(D,E)\<^esub> d"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 C,D :],E)"
    have "[DOMAIN-1K1\<^bsub>(C,D)\<^esub> c,d ] inTARSKIR2 [:ZFMISC-1K2 C,D :]"
       sorry
    then have "[DOMAIN-1K1\<^bsub>(C,D)\<^esub> c,d ] inTARSKIR2 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 C,D :])\<^esub> f"
      using funct_2_def_1 sorry
    thus "f .BINOP-1K2\<^bsub>(C,D,E)\<^esub>(c,d) =XBOOLE-0R4 (curryFUNCT-5K12\<^bsub>(C,D,E)\<^esub> f .FUNCT-5K11\<^bsub>(C,D,E,FuncsFUNCT-2K9(D,E))\<^esub> c).FUNCT-2K3\<^bsub>(D,E)\<^esub> d"
      using funct_5_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_5_th_70:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for d be ElementSUBSET-1M1-of D holds  for f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 C,D :],E) holds f .BINOP-1K2\<^bsub>(C,D,E)\<^esub>(c,d) =XBOOLE-0R4 (curry'FUNCT-5K13\<^bsub>(C,D,E)\<^esub> f .FUNCT-5K11\<^bsub>(D,C,E,FuncsFUNCT-2K9(C,E))\<^esub> d).FUNCT-2K3\<^bsub>(C,E)\<^esub> c"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for d be ElementSUBSET-1M1-of D holds  for f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 C,D :],E) holds f .BINOP-1K2\<^bsub>(C,D,E)\<^esub>(c,d) =XBOOLE-0R4 (curry'FUNCT-5K13\<^bsub>(C,D,E)\<^esub> f .FUNCT-5K11\<^bsub>(D,C,E,FuncsFUNCT-2K9(C,E))\<^esub> d).FUNCT-2K3\<^bsub>(C,E)\<^esub> c"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 C,D :],E)"
    have "[DOMAIN-1K1\<^bsub>(C,D)\<^esub> c,d ] inTARSKIR2 [:ZFMISC-1K2 C,D :]"
       sorry
    then have "[DOMAIN-1K1\<^bsub>(C,D)\<^esub> c,d ] inTARSKIR2 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 C,D :])\<^esub> f"
      using funct_2_def_1 sorry
    thus "f .BINOP-1K2\<^bsub>(C,D,E)\<^esub>(c,d) =XBOOLE-0R4 (curry'FUNCT-5K13\<^bsub>(C,D,E)\<^esub> f .FUNCT-5K11\<^bsub>(D,C,E,FuncsFUNCT-2K9(C,E))\<^esub> d).FUNCT-2K3\<^bsub>(C,E)\<^esub> c"
      using funct_5_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax FUNCT_5K14 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("uncurryFUNCT-5K14\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [0,0,0,228]228)
translations "uncurryFUNCT-5K14\<^bsub>(A,B,C)\<^esub> f" \<rightharpoonup> "uncurryFUNCT-5K2 f"

mtheorem funct_5_add_7:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(A,FuncsFUNCT-2K9(B,C))"
"cluster uncurryFUNCT-5K2 f as-term-is FunctionFUNCT-2M1-of([:ZFMISC-1K2 A,B :],C)"
proof
(*coherence*)
  show "uncurryFUNCT-5K2 f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 A,B :],C)"
  proof-
    have A1: "rngRELSET-1K2\<^bsub>(FuncsFUNCT-2K9(B,C))\<^esub> f c=TARSKIR1 FuncsFUNCT-2K9(B,C)"
       sorry
    then have A2: "rngFUNCT-1K2 (uncurryFUNCT-5K2 f) c=TARSKIR1 C"
      using funct_5_th_41 sorry
    have "domRELAT-1K1 (uncurryFUNCT-5K2 f) =HIDDENR1 [:ZFMISC-1K2 domRELSET-1K1\<^bsub>(A)\<^esub> f,B :]"
      using A1 funct_5_th_26 sorry
    also have "... = [:ZFMISC-1K2 A,B :]"
      using funct_2_def_1 sorry
    finally have "domRELAT-1K1 (uncurryFUNCT-5K2 f) =HIDDENR1 [:ZFMISC-1K2 A,B :]"
       sorry
    thus "uncurryFUNCT-5K2 f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 A,B :],C)"
      using A2 funct_2_def_1 relset_1_th_4 sorry
  qed
qed "sorry"

mtheorem funct_5_th_71:
" for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(A,FuncsFUNCT-2K9(B,C)) holds curryFUNCT-5K12\<^bsub>(A,B,C)\<^esub> (uncurryFUNCT-5K14\<^bsub>(A,B,C)\<^esub> f) =FUNCT-2R2\<^bsub>(A,FuncsFUNCT-2K9(B,C))\<^esub> f"
proof(rule ballI,rule ballI,rule ballI,rule ballI)
  fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix B assume [ty]: "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix f assume [ty]: "f be FunctionFUNCT-2M1-of(A,FuncsFUNCT-2K9(B,C))"
  have "rngRELSET-1K2\<^bsub>(FuncsFUNCT-2K9(B,C))\<^esub> f c=TARSKIR1 FuncsFUNCT-2K9(B,C)"
     sorry
  thus "curryFUNCT-5K12\<^bsub>(A,B,C)\<^esub> (uncurryFUNCT-5K14\<^bsub>(A,B,C)\<^esub> f) =FUNCT-2R2\<^bsub>(A,FuncsFUNCT-2K9(B,C))\<^esub> f"
    using funct_5_th_48 sorry
qed "sorry"

mtheorem funct_5_th_72:
" for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(A,FuncsFUNCT-2K9(B,C)) holds  for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of B holds uncurryFUNCT-5K14\<^bsub>(A,B,C)\<^esub> f .BINOP-1K2\<^bsub>(A,B,C)\<^esub>(a,b) =XBOOLE-0R4 (f .FUNCT-5K11\<^bsub>(A,B,C,FuncsFUNCT-2K9(B,C))\<^esub> a).FUNCT-2K3\<^bsub>(B,C)\<^esub> b"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
  fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix B assume [ty]: "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix f assume [ty]: "f be FunctionFUNCT-2M1-of(A,FuncsFUNCT-2K9(B,C))"
  fix a assume [ty]: "a be ElementSUBSET-1M1-of A"
  fix b assume [ty]: "b be ElementSUBSET-1M1-of B"
  have "domRELSET-1K1\<^bsub>(A)\<^esub> f =XBOOLE-0R4 A & domRELSET-1K1\<^bsub>(B)\<^esub> (f .FUNCT-5K11\<^bsub>(A,B,C,FuncsFUNCT-2K9(B,C))\<^esub> a) =XBOOLE-0R4 B"
    using funct_2_def_1 sorry
  thus "uncurryFUNCT-5K14\<^bsub>(A,B,C)\<^esub> f .BINOP-1K2\<^bsub>(A,B,C)\<^esub>(a,b) =XBOOLE-0R4 (f .FUNCT-5K11\<^bsub>(A,B,C,FuncsFUNCT-2K9(B,C))\<^esub> a).FUNCT-2K3\<^bsub>(B,C)\<^esub> b"
    using funct_5_th_38 sorry
qed "sorry"

end
