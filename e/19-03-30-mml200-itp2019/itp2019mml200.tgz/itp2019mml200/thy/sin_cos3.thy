theory sin_cos3
  imports comseq_3 sin_cos2 cfunct_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x, y for "RealXREAL-0M1"
reserve z, z1, z2 for "ComplexXCMPLX-0M1"
reserve n for "ElementSUBSET-1M1-of NATNUMBERSK1"
mdef sin_cos3_def_1 ("sin-CSIN-COS3K1" 164 ) where
"func sin-CSIN-COS3K1 \<rightarrow> FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) means
  \<lambda>it.  for z be ComplexXCMPLX-0M1 holds it .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) st  for z be ComplexXCMPLX-0M1 holds it .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))"
    proof-
      have " ex tVar1 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) st  for z be ComplexXCMPLX-0M1 holds tVar1 .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))"
      proof-
        let ?U = "\<lambda>Lamb1. InSUBSET-1K10((expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 Lamb1) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 Lamb1))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8)),COMPLEXNUMBERSK3)"
        obtain f where
          [ty]:"f be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)" and 
          A1: " for z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds f .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 ?U(z)"
          using funct_2_sch_4 sorry
        show " ex tVar1 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) st  for z be ComplexXCMPLX-0M1 holds tVar1 .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))"
        proof(rule bexI[of _ "f"],rule ballI)
          fix z assume [ty]: "z be ComplexXCMPLX-0M1"
          have 
            [ty]:"z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
            using xcmplx_0_def_2 sorry
          have "f .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 ?U(z)"
            using A1 sorry
          thus "f .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for it2 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds ( for z be ComplexXCMPLX-0M1 holds it1 .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))) & ( for z be ComplexXCMPLX-0M1 holds it2 .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds ( for z be ComplexXCMPLX-0M1 holds f1 .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))) & ( for z be ComplexXCMPLX-0M1 holds f2 .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))) implies f1 =HIDDENR1 f2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix f1 assume [ty]: "f1 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
        fix f2 assume [ty]: "f2 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
        assume A2: " for z be ComplexXCMPLX-0M1 holds f1 .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))"
          and A3: " for z be ComplexXCMPLX-0M1 holds f2 .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))"
        have " for z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds f1 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 f2 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
        proof(rule ballI)
          fix z assume [ty]: "z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
          have "f1 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))"
            using A2 sorry
          also have "... = f2 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
            using A3 sorry
          finally show "f1 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 f2 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
             sorry
        qed "sorry"
        thus "f1 =HIDDENR1 f2"
          using funct_2_def_8 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef sin_cos3_def_2 ("cos-CSIN-COS3K2" 164 ) where
"func cos-CSIN-COS3K2 \<rightarrow> FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) means
  \<lambda>it.  for z be ComplexXCMPLX-0M1 holds it .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 \<two>\<^sub>M"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) st  for z be ComplexXCMPLX-0M1 holds it .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 \<two>\<^sub>M"
    proof-
      have " ex tVar2 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) st  for z be ComplexXCMPLX-0M1 holds tVar2 .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 \<two>\<^sub>M"
      proof-
        let ?U = "\<lambda>Lamb1. InSUBSET-1K10((expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 Lamb1) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 Lamb1))/XCMPLX-0K7 \<two>\<^sub>M,COMPLEXNUMBERSK3)"
        obtain f where
          [ty]:"f be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)" and 
          A1: " for z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds f .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 ?U(z)"
          using funct_2_sch_4 sorry
        show " ex tVar2 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) st  for z be ComplexXCMPLX-0M1 holds tVar2 .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 \<two>\<^sub>M"
        proof(rule bexI[of _ "f"],rule ballI)
          fix z assume [ty]: "z be ComplexXCMPLX-0M1"
          have 
            [ty]:"z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
            using xcmplx_0_def_2 sorry
          have "f .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 ?U(z)"
            using A1 sorry
          thus "f .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 \<two>\<^sub>M"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for it2 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds ( for z be ComplexXCMPLX-0M1 holds it1 .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 \<two>\<^sub>M) & ( for z be ComplexXCMPLX-0M1 holds it2 .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 \<two>\<^sub>M) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds ( for z be ComplexXCMPLX-0M1 holds f1 .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 \<two>\<^sub>M) & ( for z be ComplexXCMPLX-0M1 holds f2 .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 \<two>\<^sub>M) implies f1 =HIDDENR1 f2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix f1 assume [ty]: "f1 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
        fix f2 assume [ty]: "f2 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
        assume A2: " for z be ComplexXCMPLX-0M1 holds f1 .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 \<two>\<^sub>M"
          and A3: " for z be ComplexXCMPLX-0M1 holds f2 .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 \<two>\<^sub>M"
        have " for z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds f1 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 f2 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
        proof(rule ballI)
          fix z assume [ty]: "z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
          have "f1 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 \<two>\<^sub>M"
            using A2 sorry
          also have "... = f2 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
            using A3 sorry
          finally show "f1 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 f2 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
             sorry
        qed "sorry"
        thus "f1 =HIDDENR1 f2"
          using funct_2_def_8 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef sin_cos3_def_3 ("sinh-CSIN-COS3K3" 164 ) where
"func sinh-CSIN-COS3K3 \<rightarrow> FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) means
  \<lambda>it.  for z be ComplexXCMPLX-0M1 holds it .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 z -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) st  for z be ComplexXCMPLX-0M1 holds it .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 z -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M"
    proof-
      have " ex tVar3 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) st  for z be ComplexXCMPLX-0M1 holds tVar3 .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 z -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M"
      proof-
        let ?U = "\<lambda>Lamb1. InSUBSET-1K10((expSIN-COSK16 Lamb1 -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 Lamb1))/XCMPLX-0K7 \<two>\<^sub>M,COMPLEXNUMBERSK3)"
        obtain f where
          [ty]:"f be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)" and 
          A1: " for z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds f .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 ?U(z)"
          using funct_2_sch_4 sorry
        show " ex tVar3 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) st  for z be ComplexXCMPLX-0M1 holds tVar3 .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 z -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M"
        proof(rule bexI[of _ "f"],rule ballI)
          fix z assume [ty]: "z be ComplexXCMPLX-0M1"
          have 
            [ty]:"z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
            using xcmplx_0_def_2 sorry
          have "f .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 ?U(z)"
            using A1 sorry
          thus "f .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 z -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for it2 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds ( for z be ComplexXCMPLX-0M1 holds it1 .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 z -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M) & ( for z be ComplexXCMPLX-0M1 holds it2 .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 z -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds ( for z be ComplexXCMPLX-0M1 holds f1 .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 z -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M) & ( for z be ComplexXCMPLX-0M1 holds f2 .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 z -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M) implies f1 =HIDDENR1 f2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix f1 assume [ty]: "f1 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
        fix f2 assume [ty]: "f2 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
        assume A2: " for z be ComplexXCMPLX-0M1 holds f1 .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 z -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M"
          and A3: " for z be ComplexXCMPLX-0M1 holds f2 .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 z -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M"
        have " for z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds f1 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 f2 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
        proof(rule ballI)
          fix z assume [ty]: "z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
          have "f1 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 (expSIN-COSK16 z -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M"
            using A2 sorry
          also have "... = f2 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
            using A3 sorry
          finally show "f1 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 f2 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
             sorry
        qed "sorry"
        thus "f1 =HIDDENR1 f2"
          using funct_2_def_8 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef sin_cos3_def_4 ("cosh-CSIN-COS3K4" 164 ) where
"func cosh-CSIN-COS3K4 \<rightarrow> FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) means
  \<lambda>it.  for z be ComplexXCMPLX-0M1 holds it .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 z +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) st  for z be ComplexXCMPLX-0M1 holds it .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 z +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M"
    proof-
      have " ex tVar4 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) st  for z be ComplexXCMPLX-0M1 holds tVar4 .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 z +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M"
      proof-
        let ?U = "\<lambda>Lamb1. InSUBSET-1K10((expSIN-COSK16 Lamb1 +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 Lamb1))/XCMPLX-0K7 \<two>\<^sub>M,COMPLEXNUMBERSK3)"
        obtain f where
          [ty]:"f be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)" and 
          A1: " for z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds f .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 ?U(z)"
          using funct_2_sch_4 sorry
        show " ex tVar4 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) st  for z be ComplexXCMPLX-0M1 holds tVar4 .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 z +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M"
        proof(rule bexI[of _ "f"],rule ballI)
          fix z assume [ty]: "z be ComplexXCMPLX-0M1"
          have 
            [ty]:"z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
            using xcmplx_0_def_2 sorry
          have "f .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 ?U(z)"
            using A1 sorry
          thus "f .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 z +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for it2 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds ( for z be ComplexXCMPLX-0M1 holds it1 .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 z +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M) & ( for z be ComplexXCMPLX-0M1 holds it2 .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 z +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds ( for z be ComplexXCMPLX-0M1 holds f1 .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 z +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M) & ( for z be ComplexXCMPLX-0M1 holds f2 .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 z +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M) implies f1 =HIDDENR1 f2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix f1 assume [ty]: "f1 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
        fix f2 assume [ty]: "f2 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
        assume A2: " for z be ComplexXCMPLX-0M1 holds f1 .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 z +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M"
          and A3: " for z be ComplexXCMPLX-0M1 holds f2 .FUNCT-1K1 z =COMPLEX1R1 (expSIN-COSK16 z +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M"
        have " for z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds f1 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 f2 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
        proof(rule ballI)
          fix z assume [ty]: "z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
          have "f1 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 (expSIN-COSK16 z +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M"
            using A2 sorry
          also have "... = f2 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
            using A3 sorry
          finally show "f1 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 f2 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
             sorry
        qed "sorry"
        thus "f1 =HIDDENR1 f2"
          using funct_2_def_8 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mlemma sin_cos3_lm_1:
" for z be ComplexXCMPLX-0M1 holds (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 (expSIN-COSK16 z -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M"
  using sin_cos3_def_3 sorry

mlemma sin_cos3_lm_2:
" for z be ComplexXCMPLX-0M1 holds (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 (expSIN-COSK16 z +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M"
  using sin_cos3_def_4 sorry

mlemma sin_cos3_lm_3:
" for z be ComplexXCMPLX-0M1 holds (expSIN-COSK16 z)*XCMPLX-0K3 (expSIN-COSK16 (-XCMPLX-0K4 z)) =COMPLEX1R1 \<one>\<^sub>M"
proof-
  have " for z be ComplexXCMPLX-0M1 holds (expSIN-COSK16 z)*XCMPLX-0K3 (expSIN-COSK16 (-XCMPLX-0K4 z)) =HIDDENR1 \<one>\<^sub>M"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "(expSIN-COSK16 z)*XCMPLX-0K3 (expSIN-COSK16 (-XCMPLX-0K4 z)) =HIDDENR1 expSIN-COSK16 (z +XCMPLX-0K2 (-XCMPLX-0K4 z))"
      using sin_cos_th_23 sorry
    also have "... = \<one>\<^sub>M"
      using sin_cos_th_49 sin_cos_th_51 sorry
    finally show "(expSIN-COSK16 z)*XCMPLX-0K3 (expSIN-COSK16 (-XCMPLX-0K4 z)) =HIDDENR1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem sin_cos3_th_1:
" for z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 \<one>\<^sub>M"
proof(rule ballI)
  fix z assume [ty]: "z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
  let ?z1 = "expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z)"
  let ?z2 = "expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z)"
  have "(sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 ((expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 \<two>\<^sub>M)"
    using sin_cos3_def_2 sorry
  also have "... = (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 ((?z1 +XCMPLX-0K2 ?z2)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((?z1 +XCMPLX-0K2 ?z2)/XCMPLX-0K7 \<two>\<^sub>M)"
    using sin_cos3_def_2 sorry
  also have "... = ((?z1 -XCMPLX-0K6 ?z2)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8)))*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 ((?z1 +XCMPLX-0K2 ?z2)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((?z1 +XCMPLX-0K2 ?z2)/XCMPLX-0K7 \<two>\<^sub>M)"
    using sin_cos3_def_1 sorry
  also have "... = ((?z1 -XCMPLX-0K6 ?z2)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8)))*XCMPLX-0K3 ((?z1 -XCMPLX-0K6 ?z2)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))) +XCMPLX-0K2 ((?z1 +XCMPLX-0K2 ?z2)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((?z1 +XCMPLX-0K2 ?z2)/XCMPLX-0K7 \<two>\<^sub>M)"
    using sin_cos3_def_1 sorry
  also have "... = ((?z1 *XCMPLX-0K3 ?z2 +XCMPLX-0K2 ?z1 *XCMPLX-0K3 ?z2)+XCMPLX-0K2 (?z1 *XCMPLX-0K3 ?z2 +XCMPLX-0K2 ?z1 *XCMPLX-0K3 ?z2))/XCMPLX-0K7 \<four>\<^sub>M"
     sorry
  also have "... = ((\<one>\<^sub>M +XCMPLX-0K2 ?z1 *XCMPLX-0K3 (expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z)))+XCMPLX-0K2 (?z1 *XCMPLX-0K3 (expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z)) +XCMPLX-0K2 ?z1 *XCMPLX-0K3 (expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))))/XCMPLX-0K7 \<four>\<^sub>M"
    using sin_cos3_lm_3 sorry
  also have "... = ((\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (?z1 *XCMPLX-0K3 (expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z)) +XCMPLX-0K2 ?z1 *XCMPLX-0K3 (expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))))/XCMPLX-0K7 \<four>\<^sub>M"
    using sin_cos3_lm_3 sorry
  also have "... = ((\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (?z1 *XCMPLX-0K3 (expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z)) +XCMPLX-0K2 \<one>\<^sub>M))/XCMPLX-0K7 \<four>\<^sub>M"
    using sin_cos3_lm_3 sorry
  also have "... = (\<two>\<^sub>M +NAT-1K1 \<two>\<^sub>M)/XCMPLX-0K7 \<four>\<^sub>M"
    using sin_cos3_lm_3 sorry
  finally have "(sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 (\<two>\<^sub>M +NAT-1K1 \<two>\<^sub>M)/XCMPLX-0K7 \<four>\<^sub>M"
     sorry
  thus "(sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 \<one>\<^sub>M"
     sorry
qed "sorry"

mtheorem sin_cos3_th_2:
" for z be ComplexXCMPLX-0M1 holds -XCMPLX-0K4 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z)"
proof(rule ballI)
  fix z assume [ty]: "z be ComplexXCMPLX-0M1"
  have "(sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z) =HIDDENR1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 (-XCMPLX-0K4 z)) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 (-XCMPLX-0K4 z)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))"
    using sin_cos3_def_1 sorry
  also have "... = -XCMPLX-0K4 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))"
     sorry
  finally have "(sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z) =HIDDENR1 -XCMPLX-0K4 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))"
     sorry
  then have "-XCMPLX-0K4 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z)"
    using sin_cos3_def_1 sorry
  thus "-XCMPLX-0K4 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z)"
     sorry
qed "sorry"

mtheorem sin_cos3_th_3:
" for z be ComplexXCMPLX-0M1 holds (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z)"
proof(rule ballI)
  fix z assume [ty]: "z be ComplexXCMPLX-0M1"
  have 
    [ty]:"z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    using xcmplx_0_def_2 sorry
  have "(cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z) =HIDDENR1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 (-XCMPLX-0K4 z)) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 (-XCMPLX-0K4 z)))/XCMPLX-0K7 \<two>\<^sub>M"
    using sin_cos3_def_2 sorry
  also have "... = (expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z) +XCMPLX-0K2 expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 \<two>\<^sub>M"
     sorry
  finally have "(cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z) =HIDDENR1 (expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z) +XCMPLX-0K2 expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 \<two>\<^sub>M"
     sorry
  then have "(cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z)"
    using sin_cos3_def_2 sorry
  thus "(cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z)"
     sorry
qed "sorry"

mtheorem sin_cos3_th_4:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) =COMPLEX1R1 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 +XCMPLX-0K2 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
proof(rule ballI,rule ballI)
  fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
  fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
  have 
    [ty]:"z1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and
    [ty]:"z2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    using xcmplx_0_def_2 sorry
  obtain e1 e2 e3 e4 where 
    [ty]:"e1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and e1Def:"e1 = expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z1)" and
    [ty]:"e2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and e2Def:"e2 = expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z1)" and
    [ty]:"e3 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and e3Def:"e3 = expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z2)" and
    [ty]:"e4 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and e4Def:"e4 = expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z2)"
     sorry
  have "(sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z2 +XCMPLX-0K2 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z2 =HIDDENR1 ((expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z1) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z1))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8)))*XCMPLX-0K3 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z2 +XCMPLX-0K2 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z2"
    using sin_cos3_def_1 sorry
  also have "... = ((expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z1) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z1))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8)))*XCMPLX-0K3 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z2 +XCMPLX-0K2 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 ((expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z2) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z2))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8)))"
    using sin_cos3_def_1 sorry
  also have "... = ((expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z1) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z1))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8)))*XCMPLX-0K3 ((expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z2) +XCMPLX-0K2 expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z2))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 ((expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z2) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z2))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8)))"
    using sin_cos3_def_2 sorry
  also have "... = ((expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z1) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z1))*XCMPLX-0K3 (expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z2) +XCMPLX-0K2 expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z2)))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 \<two>\<^sub>M) +XCMPLX-0K2 ((expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z1) +XCMPLX-0K2 expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z1))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z2) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z2))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8)))"
    using sin_cos3_def_2 sorry
  also have "... = ((e1 *XCMPLX-0K3 e3 +XCMPLX-0K2 e1 *XCMPLX-0K3 e3)-XCMPLX-0K6 ((e1 *XCMPLX-0K3 e4 +XCMPLX-0K2 e2 *XCMPLX-0K3 e4)-XCMPLX-0K6 (e1 *XCMPLX-0K3 e4 -XCMPLX-0K6 e2 *XCMPLX-0K3 e4)))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 \<two>\<^sub>M)"
     sorry
  also have "... = (((ReCOMPLEX1K3 (e1 *XCMPLX-0K3 e3) +REAL-1K3 ReCOMPLEX1K3 (e1 *XCMPLX-0K3 e3))+XCMPLX-0K2 (ImCOMPLEX1K4 (e1 *XCMPLX-0K3 e3) +REAL-1K3 ImCOMPLEX1K4 (e1 *XCMPLX-0K3 e3))*XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 (e2 *XCMPLX-0K3 e4 +XCMPLX-0K2 e2 *XCMPLX-0K3 e4))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 \<two>\<^sub>M)"
    using complex1_th_81 sorry
  also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 ReCOMPLEX1K3 (e1 *XCMPLX-0K3 e3) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ImCOMPLEX1K4 (e1 *XCMPLX-0K3 e3))*XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 (e2 *XCMPLX-0K3 e4 +XCMPLX-0K2 e2 *XCMPLX-0K3 e4))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 \<two>\<^sub>M)"
     sorry
  also have "... = ((ReCOMPLEX1K3 (\<two>\<^sub>M *XCMPLX-0K3 (e1 *XCMPLX-0K3 e3)) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ImCOMPLEX1K4 (e1 *XCMPLX-0K3 e3))*XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 (e2 *XCMPLX-0K3 e4 +XCMPLX-0K2 e2 *XCMPLX-0K3 e4))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 \<two>\<^sub>M)"
    using comseq_3_th_17 sorry
  also have "... = ((ReCOMPLEX1K3 (\<two>\<^sub>M *XCMPLX-0K3 (e1 *XCMPLX-0K3 e3)) +XCMPLX-0K2 ImCOMPLEX1K4 (\<two>\<^sub>M *XCMPLX-0K3 (e1 *XCMPLX-0K3 e3)) *XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 (e2 *XCMPLX-0K3 e4 +XCMPLX-0K2 e2 *XCMPLX-0K3 e4))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 \<two>\<^sub>M)"
    using comseq_3_th_17 sorry
  also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (e1 *XCMPLX-0K3 e3) -XCMPLX-0K6 (e2 *XCMPLX-0K3 e4 +XCMPLX-0K2 e2 *XCMPLX-0K3 e4))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 \<two>\<^sub>M)"
    using complex1_th_13 sorry
  also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (e1 *XCMPLX-0K3 e3) -XCMPLX-0K6 ((ReCOMPLEX1K3 (e2 *XCMPLX-0K3 e4) +REAL-1K3 ReCOMPLEX1K3 (e2 *XCMPLX-0K3 e4))+XCMPLX-0K2 (ImCOMPLEX1K4 (e2 *XCMPLX-0K3 e4) +REAL-1K3 ImCOMPLEX1K4 (e2 *XCMPLX-0K3 e4))*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 \<two>\<^sub>M)"
    using complex1_th_81 sorry
  also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (e1 *XCMPLX-0K3 e3) -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 ReCOMPLEX1K3 (e2 *XCMPLX-0K3 e4) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ImCOMPLEX1K4 (e2 *XCMPLX-0K3 e4))*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 \<two>\<^sub>M)"
     sorry
  also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (e1 *XCMPLX-0K3 e3) -XCMPLX-0K6 (ReCOMPLEX1K3 (\<two>\<^sub>M *XCMPLX-0K3 (e2 *XCMPLX-0K3 e4)) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ImCOMPLEX1K4 (e2 *XCMPLX-0K3 e4))*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 \<two>\<^sub>M)"
    using comseq_3_th_17 sorry
  also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (e1 *XCMPLX-0K3 e3) -XCMPLX-0K6 (ReCOMPLEX1K3 (\<two>\<^sub>M *XCMPLX-0K3 (e2 *XCMPLX-0K3 e4)) +XCMPLX-0K2 ImCOMPLEX1K4 (\<two>\<^sub>M *XCMPLX-0K3 (e2 *XCMPLX-0K3 e4)) *XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 \<two>\<^sub>M)"
    using comseq_3_th_17 sorry
  also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (e1 *XCMPLX-0K3 e3) -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (e2 *XCMPLX-0K3 e4))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 \<two>\<^sub>M)"
    using complex1_th_13 sorry
  also have "... = (e1 *XCMPLX-0K3 e3)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8)) -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (e2 *XCMPLX-0K3 e4))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 \<two>\<^sub>M)"
     sorry
  also have "... = (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z1 +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 z2))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8)) -XCMPLX-0K6 (e2 *XCMPLX-0K3 e4)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))"
    using sin_cos_th_23 sorry
  also have "... = (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 (z1 +XCMPLX-0K2 z2)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8)) -XCMPLX-0K6 (expSIN-COSK16 ((-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z1)+XCMPLX-0K2 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z2)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))"
    using sin_cos_th_23 sorry
  also have "... = (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 (z1 +XCMPLX-0K2 z2)) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 (z1 +XCMPLX-0K2 z2)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))"
     sorry
  finally have "(sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z2 +XCMPLX-0K2 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z2 =HIDDENR1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 (z1 +XCMPLX-0K2 z2)) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 (z1 +XCMPLX-0K2 z2)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))"
     sorry
  then have "(sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) =COMPLEX1R1 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z2 +XCMPLX-0K2 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z2"
    using sin_cos3_def_1 sorry
  thus "(sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) =COMPLEX1R1 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 +XCMPLX-0K2 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
     sorry
qed "sorry"

mtheorem sin_cos3_th_5:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =COMPLEX1R1 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 -XCMPLX-0K6 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =COMPLEX1R1 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 -XCMPLX-0K6 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    have "(sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =HIDDENR1 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 (-XCMPLX-0K4 z2))"
       sorry
    also have "... = (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z2) +XCMPLX-0K2 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z2)"
      using sin_cos3_th_4 sorry
    also have "... = (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 +XCMPLX-0K2 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z2)"
      using sin_cos3_th_3 sorry
    also have "... = (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 +XCMPLX-0K2 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (-XCMPLX-0K4 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2)"
      using sin_cos3_th_2 sorry
    also have "... = (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 +XCMPLX-0K2 (-XCMPLX-0K4 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2)"
       sorry
    finally have "(sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =HIDDENR1 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 +XCMPLX-0K2 (-XCMPLX-0K4 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2)"
       sorry
    thus "(sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =COMPLEX1R1 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 -XCMPLX-0K6 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos3_th_6:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) =COMPLEX1R1 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 -XCMPLX-0K6 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
proof(rule ballI,rule ballI)
  fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
  fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
  have 
    [ty]:"z1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and
    [ty]:"z2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    using xcmplx_0_def_2 sorry
  let ?e1 = "expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z1)"
  let ?e2 = "expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z1)"
  let ?e3 = "expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z2)"
  let ?e4 = "expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z2)"
  have "(cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z2 -XCMPLX-0K6 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z2 =HIDDENR1 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z2 -XCMPLX-0K6 ((expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z1) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z1))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8)))*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z2"
    using sin_cos3_def_1 sorry
  also have "... = (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z2 -XCMPLX-0K6 ((expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z1) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z1))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8)))*XCMPLX-0K3 ((expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z2) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z2))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8)))"
    using sin_cos3_def_1 sorry
  also have "... = (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 ((expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z2) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z2))/XCMPLX-0K7 \<two>\<^sub>M) -XCMPLX-0K6 ((expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z1) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z1))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8)))*XCMPLX-0K3 ((expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z2) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z2))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8)))"
    using sin_cos3_def_2 sorry
  also have "... = ((?e1 +XCMPLX-0K2 ?e2)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((?e3 +XCMPLX-0K2 ?e4)/XCMPLX-0K7 \<two>\<^sub>M) -XCMPLX-0K6 ((?e1 -XCMPLX-0K6 ?e2)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8)))*XCMPLX-0K3 ((?e3 -XCMPLX-0K6 ?e4)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8)))"
    using sin_cos3_def_2 sorry
  also have "... = ((?e1 *XCMPLX-0K3 ?e3 +XCMPLX-0K2 ?e1 *XCMPLX-0K3 ?e3)+XCMPLX-0K2 (?e2 *XCMPLX-0K3 ?e4 +XCMPLX-0K2 ?e2 *XCMPLX-0K3 ?e4))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
     sorry
  also have "... = (((ReCOMPLEX1K3 (?e1 *XCMPLX-0K3 ?e3) +REAL-1K3 ReCOMPLEX1K3 (?e1 *XCMPLX-0K3 ?e3))+XCMPLX-0K2 (ImCOMPLEX1K4 (?e1 *XCMPLX-0K3 ?e3) +REAL-1K3 ImCOMPLEX1K4 (?e1 *XCMPLX-0K3 ?e3))*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 (?e2 *XCMPLX-0K3 ?e4 +XCMPLX-0K2 ?e2 *XCMPLX-0K3 ?e4))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
    using complex1_th_81 sorry
  also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 ReCOMPLEX1K3 (?e1 *XCMPLX-0K3 ?e3) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ImCOMPLEX1K4 (?e1 *XCMPLX-0K3 ?e3))*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 (?e2 *XCMPLX-0K3 ?e4 +XCMPLX-0K2 ?e2 *XCMPLX-0K3 ?e4))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
     sorry
  also have "... = ((ReCOMPLEX1K3 (\<two>\<^sub>M *XCMPLX-0K3 (?e1 *XCMPLX-0K3 ?e3)) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ImCOMPLEX1K4 (?e1 *XCMPLX-0K3 ?e3))*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 (?e2 *XCMPLX-0K3 ?e4 +XCMPLX-0K2 ?e2 *XCMPLX-0K3 ?e4))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
    using comseq_3_th_17 sorry
  also have "... = ((ReCOMPLEX1K3 (\<two>\<^sub>M *XCMPLX-0K3 (?e1 *XCMPLX-0K3 ?e3)) +XCMPLX-0K2 ImCOMPLEX1K4 (\<two>\<^sub>M *XCMPLX-0K3 (?e1 *XCMPLX-0K3 ?e3)) *XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 (?e2 *XCMPLX-0K3 ?e4 +XCMPLX-0K2 ?e2 *XCMPLX-0K3 ?e4))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
    using comseq_3_th_17 sorry
  also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (?e1 *XCMPLX-0K3 ?e3) +XCMPLX-0K2 (?e2 *XCMPLX-0K3 ?e4 +XCMPLX-0K2 ?e2 *XCMPLX-0K3 ?e4))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
    using complex1_th_13 sorry
  also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (?e1 *XCMPLX-0K3 ?e3) +XCMPLX-0K2 ((ReCOMPLEX1K3 (?e2 *XCMPLX-0K3 ?e4) +REAL-1K3 ReCOMPLEX1K3 (?e2 *XCMPLX-0K3 ?e4))+XCMPLX-0K2 (ImCOMPLEX1K4 (?e2 *XCMPLX-0K3 ?e4) +REAL-1K3 ImCOMPLEX1K4 (?e2 *XCMPLX-0K3 ?e4))*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
    using complex1_th_81 sorry
  also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (?e1 *XCMPLX-0K3 ?e3) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ReCOMPLEX1K3 (?e2 *XCMPLX-0K3 ?e4) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ImCOMPLEX1K4 (?e2 *XCMPLX-0K3 ?e4))*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
     sorry
  also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (?e1 *XCMPLX-0K3 ?e3) +XCMPLX-0K2 (ReCOMPLEX1K3 (\<two>\<^sub>M *XCMPLX-0K3 (?e2 *XCMPLX-0K3 ?e4)) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ImCOMPLEX1K4 (?e2 *XCMPLX-0K3 ?e4))*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
    using comseq_3_th_17 sorry
  also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (?e1 *XCMPLX-0K3 ?e3) +XCMPLX-0K2 (ReCOMPLEX1K3 (\<two>\<^sub>M *XCMPLX-0K3 (?e2 *XCMPLX-0K3 ?e4)) +XCMPLX-0K2 ImCOMPLEX1K4 (\<two>\<^sub>M *XCMPLX-0K3 (?e2 *XCMPLX-0K3 ?e4)) *XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
    using comseq_3_th_17 sorry
  also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (?e1 *XCMPLX-0K3 ?e3) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (?e2 *XCMPLX-0K3 ?e4))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
    using complex1_th_13 sorry
  also have "... = (?e1 *XCMPLX-0K3 ?e3)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (?e2 *XCMPLX-0K3 ?e4))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
     sorry
  also have "... = (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z1 +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 z2))/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (?e2 *XCMPLX-0K3 ?e4)/XCMPLX-0K7 \<two>\<^sub>M"
    using sin_cos_th_23 sorry
  also have "... = (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 (z1 +XCMPLX-0K2 z2)))/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (expSIN-COSK16 ((-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z1)+XCMPLX-0K2 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z2)))/XCMPLX-0K7 \<two>\<^sub>M"
    using sin_cos_th_23 sorry
  also have "... = (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 (z1 +XCMPLX-0K2 z2)) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 (z1 +XCMPLX-0K2 z2)))/XCMPLX-0K7 \<two>\<^sub>M"
     sorry
  finally have "(cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z2 -XCMPLX-0K6 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z2 =HIDDENR1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 (z1 +XCMPLX-0K2 z2)) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 (z1 +XCMPLX-0K2 z2)))/XCMPLX-0K7 \<two>\<^sub>M"
     sorry
  then have "(cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) =COMPLEX1R1 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z2 -XCMPLX-0K6 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z2"
    using sin_cos3_def_2 sorry
  thus "(cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) =COMPLEX1R1 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 -XCMPLX-0K6 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
     sorry
qed "sorry"

mtheorem sin_cos3_th_7:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =COMPLEX1R1 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 +XCMPLX-0K2 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =COMPLEX1R1 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 +XCMPLX-0K2 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    have "(cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =HIDDENR1 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 (-XCMPLX-0K4 z2))"
       sorry
    also have "... = (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z2) -XCMPLX-0K6 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z2)"
      using sin_cos3_th_6 sorry
    also have "... = (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 -XCMPLX-0K6 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z2)"
      using sin_cos3_th_3 sorry
    also have "... = (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 -XCMPLX-0K6 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (-XCMPLX-0K4 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2)"
      using sin_cos3_th_2 sorry
    also have "... = (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 -XCMPLX-0K6 (-XCMPLX-0K4 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2)"
       sorry
    finally have "(cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =HIDDENR1 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 -XCMPLX-0K6 (-XCMPLX-0K4 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2)"
       sorry
    thus "(cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =COMPLEX1R1 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 +XCMPLX-0K2 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos3_ident_1:
  mlet "p be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)", "i be ComplexXCMPLX-0M1"
"identify p /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> i with p .FUNCT-1K1 i"
proof
(*compatibility*)
  show "p /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> i =HIDDENR1 p .FUNCT-1K1 i"
     sorry
qed "sorry"

mtheorem sin_cos3_th_8:
" for z be ComplexXCMPLX-0M1 holds (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 \<one>\<^sub>M"
proof-
  have " for z be ComplexXCMPLX-0M1 holds (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 \<one>\<^sub>M"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    let ?e1 = "expSIN-COSK16 z"
    let ?e2 = "expSIN-COSK16 (-XCMPLX-0K4 z)"
    have "(cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 ((?e1 -XCMPLX-0K6 ?e2)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
      using sin_cos3_def_3 sorry
    also have "... = (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 ((?e1 -XCMPLX-0K6 ?e2)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((?e1 -XCMPLX-0K6 ?e2)/XCMPLX-0K7 \<two>\<^sub>M)"
      using sin_cos3_def_3 sorry
    also have "... = ((?e1 +XCMPLX-0K2 ?e2)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 ((?e1 -XCMPLX-0K6 ?e2)*XCMPLX-0K3 (?e1 -XCMPLX-0K6 ?e2))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
      using sin_cos3_def_4 sorry
    also have "... = ((?e1 +XCMPLX-0K2 ?e2)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((?e1 +XCMPLX-0K2 ?e2)/XCMPLX-0K7 \<two>\<^sub>M) -XCMPLX-0K6 ((?e1 -XCMPLX-0K6 ?e2)*XCMPLX-0K3 (?e1 -XCMPLX-0K6 ?e2))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
      using sin_cos3_def_4 sorry
    also have "... = ((?e1 *XCMPLX-0K3 ?e2 +XCMPLX-0K2 ?e1 *XCMPLX-0K3 ?e2)+XCMPLX-0K2 (?e1 *XCMPLX-0K3 ?e2 +XCMPLX-0K2 ?e1 *XCMPLX-0K3 ?e2))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
       sorry
    also have "... = ((\<one>\<^sub>M +XCMPLX-0K2 ?e1 *XCMPLX-0K3 ?e2)+XCMPLX-0K2 (?e1 *XCMPLX-0K3 ?e2 +XCMPLX-0K2 ?e1 *XCMPLX-0K3 ?e2))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
      using sin_cos3_lm_3 sorry
    also have "... = ((\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (?e1 *XCMPLX-0K3 ?e2 +XCMPLX-0K2 ?e1 *XCMPLX-0K3 ?e2))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
      using sin_cos3_lm_3 sorry
    also have "... = ((\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (\<one>\<^sub>M +XCMPLX-0K2 ?e1 *XCMPLX-0K3 ?e2))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
      using sin_cos3_lm_3 sorry
    also have "... = (\<two>\<^sub>M +NAT-1K1 \<two>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
      using sin_cos3_lm_3 sorry
    also have "... = \<one>\<^sub>M"
       sorry
    finally have "(cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 \<one>\<^sub>M"
       sorry
    thus "(cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos3_th_9:
" for z be ComplexXCMPLX-0M1 holds -XCMPLX-0K4 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z)"
proof-
  have " for z be ComplexXCMPLX-0M1 holds -XCMPLX-0K4 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z)"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "(sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z) =HIDDENR1 (expSIN-COSK16 (-XCMPLX-0K4 z) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (-XCMPLX-0K4 z)))/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos3_def_3 sorry
    also have "... = -XCMPLX-0K4 (expSIN-COSK16 z -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    finally have "(sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z) =HIDDENR1 -XCMPLX-0K4 (expSIN-COSK16 z -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    thus "-XCMPLX-0K4 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z)"
      using sin_cos3_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos3_th_10:
" for z be ComplexXCMPLX-0M1 holds (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z)"
proof-
  have " for z be ComplexXCMPLX-0M1 holds (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z)"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "(cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z) =HIDDENR1 (expSIN-COSK16 (-XCMPLX-0K4 z) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (-XCMPLX-0K4 z)))/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos3_def_4 sorry
    also have "... = (expSIN-COSK16 (-XCMPLX-0K4 z) +XCMPLX-0K2 expSIN-COSK16 z)/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    finally have "(cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z) =HIDDENR1 (expSIN-COSK16 (-XCMPLX-0K4 z) +XCMPLX-0K2 expSIN-COSK16 z)/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    thus "(cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z)"
      using sin_cos3_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos3_th_11:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) =COMPLEX1R1 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 +XCMPLX-0K2 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) =COMPLEX1R1 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 +XCMPLX-0K2 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    let ?e1 = "expSIN-COSK16 z1"
    let ?e2 = "expSIN-COSK16 (-XCMPLX-0K4 z1)"
    let ?e3 = "expSIN-COSK16 z2"
    let ?e4 = "expSIN-COSK16 (-XCMPLX-0K4 z2)"
    have "(sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 +XCMPLX-0K2 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 =HIDDENR1 ((?e1 -XCMPLX-0K6 ?e2)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 +XCMPLX-0K2 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
      using sin_cos3_def_3 sorry
    also have "... = ((?e1 -XCMPLX-0K6 ?e2)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 +XCMPLX-0K2 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 ((?e3 -XCMPLX-0K6 ?e4)/XCMPLX-0K7 \<two>\<^sub>M)"
      using sin_cos3_def_3 sorry
    also have "... = ((?e1 -XCMPLX-0K6 ?e2)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 +XCMPLX-0K2 ((?e1 +XCMPLX-0K2 ?e2)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((?e3 -XCMPLX-0K6 ?e4)/XCMPLX-0K7 \<two>\<^sub>M)"
      using sin_cos3_def_4 sorry
    also have "... = ((?e1 -XCMPLX-0K6 ?e2)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((?e3 +XCMPLX-0K2 ?e4)/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 ((?e1 +XCMPLX-0K2 ?e2)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((?e3 -XCMPLX-0K6 ?e4)/XCMPLX-0K7 \<two>\<^sub>M)"
      using sin_cos3_def_4 sorry
    also have "... = ((?e1 *XCMPLX-0K3 ?e3 +XCMPLX-0K2 ?e1 *XCMPLX-0K3 ?e3)-XCMPLX-0K6 (?e2 *XCMPLX-0K3 ?e4 +XCMPLX-0K2 ?e2 *XCMPLX-0K3 ?e4))/XCMPLX-0K7 \<four>\<^sub>M"
       sorry
    also have "... = (((ReCOMPLEX1K3 (?e1 *XCMPLX-0K3 ?e3) +REAL-1K3 ReCOMPLEX1K3 (?e1 *XCMPLX-0K3 ?e3))+XCMPLX-0K2 (ImCOMPLEX1K4 (?e1 *XCMPLX-0K3 ?e3) +REAL-1K3 ImCOMPLEX1K4 (?e1 *XCMPLX-0K3 ?e3))*XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 (?e2 *XCMPLX-0K3 ?e4 +XCMPLX-0K2 ?e2 *XCMPLX-0K3 ?e4))/XCMPLX-0K7 \<four>\<^sub>M"
      using complex1_th_81 sorry
    also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 ReCOMPLEX1K3 (?e1 *XCMPLX-0K3 ?e3) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ImCOMPLEX1K4 (?e1 *XCMPLX-0K3 ?e3))*XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 (?e2 *XCMPLX-0K3 ?e4 +XCMPLX-0K2 ?e2 *XCMPLX-0K3 ?e4))/XCMPLX-0K7 \<four>\<^sub>M"
       sorry
    also have "... = ((ReCOMPLEX1K3 (\<two>\<^sub>M *XCMPLX-0K3 (?e1 *XCMPLX-0K3 ?e3)) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ImCOMPLEX1K4 (?e1 *XCMPLX-0K3 ?e3))*XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 (?e2 *XCMPLX-0K3 ?e4 +XCMPLX-0K2 ?e2 *XCMPLX-0K3 ?e4))/XCMPLX-0K7 \<four>\<^sub>M"
      using comseq_3_th_17 sorry
    also have "... = ((ReCOMPLEX1K3 (\<two>\<^sub>M *XCMPLX-0K3 (?e1 *XCMPLX-0K3 ?e3)) +XCMPLX-0K2 ImCOMPLEX1K4 (\<two>\<^sub>M *XCMPLX-0K3 (?e1 *XCMPLX-0K3 ?e3)) *XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 (?e2 *XCMPLX-0K3 ?e4 +XCMPLX-0K2 ?e2 *XCMPLX-0K3 ?e4))/XCMPLX-0K7 \<four>\<^sub>M"
      using comseq_3_th_17 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (?e1 *XCMPLX-0K3 ?e3) -XCMPLX-0K6 (?e2 *XCMPLX-0K3 ?e4 +XCMPLX-0K2 ?e2 *XCMPLX-0K3 ?e4))/XCMPLX-0K7 \<four>\<^sub>M"
      using complex1_th_13 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (?e1 *XCMPLX-0K3 ?e3) -XCMPLX-0K6 ((ReCOMPLEX1K3 (?e2 *XCMPLX-0K3 ?e4) +REAL-1K3 ReCOMPLEX1K3 (?e2 *XCMPLX-0K3 ?e4))+XCMPLX-0K2 (ImCOMPLEX1K4 (?e2 *XCMPLX-0K3 ?e4) +REAL-1K3 ImCOMPLEX1K4 (?e2 *XCMPLX-0K3 ?e4))*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 \<four>\<^sub>M"
      using complex1_th_81 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (?e1 *XCMPLX-0K3 ?e3) -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 ReCOMPLEX1K3 (?e2 *XCMPLX-0K3 ?e4) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ImCOMPLEX1K4 (?e2 *XCMPLX-0K3 ?e4))*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 \<four>\<^sub>M"
       sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (?e1 *XCMPLX-0K3 ?e3) -XCMPLX-0K6 (ReCOMPLEX1K3 (\<two>\<^sub>M *XCMPLX-0K3 (?e2 *XCMPLX-0K3 ?e4)) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ImCOMPLEX1K4 (?e2 *XCMPLX-0K3 ?e4))*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 \<four>\<^sub>M"
      using comseq_3_th_17 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (?e1 *XCMPLX-0K3 ?e3) -XCMPLX-0K6 (ReCOMPLEX1K3 (\<two>\<^sub>M *XCMPLX-0K3 (?e2 *XCMPLX-0K3 ?e4)) +XCMPLX-0K2 ImCOMPLEX1K4 (\<two>\<^sub>M *XCMPLX-0K3 (?e2 *XCMPLX-0K3 ?e4)) *XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 \<four>\<^sub>M"
      using comseq_3_th_17 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (?e1 *XCMPLX-0K3 ?e3) -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (?e2 *XCMPLX-0K3 ?e4))/XCMPLX-0K7 \<four>\<^sub>M"
      using complex1_th_13 sorry
    also have "... = (?e1 *XCMPLX-0K3 ?e3)/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (?e2 *XCMPLX-0K3 ?e4))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
       sorry
    also have "... = (expSIN-COSK16 (z1 +XCMPLX-0K2 z2))/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 (?e2 *XCMPLX-0K3 ?e4)/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos_th_23 sorry
    also have "... = (expSIN-COSK16 (z1 +XCMPLX-0K2 z2))/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 (expSIN-COSK16 ((-XCMPLX-0K4 z1)+XCMPLX-0K2 (-XCMPLX-0K4 z2)))/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos_th_23 sorry
    also have "... = (expSIN-COSK16 (z1 +XCMPLX-0K2 z2) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (z1 +XCMPLX-0K2 z2)))/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    finally have "(sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 +XCMPLX-0K2 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 =HIDDENR1 (expSIN-COSK16 (z1 +XCMPLX-0K2 z2) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (z1 +XCMPLX-0K2 z2)))/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    thus "(sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) =COMPLEX1R1 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 +XCMPLX-0K2 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
      using sin_cos3_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos3_th_12:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =COMPLEX1R1 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 -XCMPLX-0K6 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =COMPLEX1R1 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 -XCMPLX-0K6 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    have "(sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =HIDDENR1 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 (-XCMPLX-0K4 z2))"
       sorry
    also have "... = (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z2) +XCMPLX-0K2 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z2)"
      using sin_cos3_th_11 sorry
    also have "... = (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 +XCMPLX-0K2 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z2)"
      using sin_cos3_th_10 sorry
    also have "... = (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 +XCMPLX-0K2 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (-XCMPLX-0K4 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2)"
      using sin_cos3_th_9 sorry
    also have "... = (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 +XCMPLX-0K2 (-XCMPLX-0K4 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2)"
       sorry
    finally have "(sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =HIDDENR1 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 +XCMPLX-0K2 (-XCMPLX-0K4 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2)"
       sorry
    thus "(sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =COMPLEX1R1 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 -XCMPLX-0K6 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos3_th_13:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =COMPLEX1R1 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 -XCMPLX-0K6 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =COMPLEX1R1 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 -XCMPLX-0K6 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    let ?e1 = "expSIN-COSK16 z1"
    let ?e2 = "expSIN-COSK16 (-XCMPLX-0K4 z1)"
    let ?e3 = "expSIN-COSK16 z2"
    let ?e4 = "expSIN-COSK16 (-XCMPLX-0K4 z2)"
    have "(cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 -XCMPLX-0K6 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 =HIDDENR1 ((?e1 +XCMPLX-0K2 ?e2)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 -XCMPLX-0K6 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
      using sin_cos3_def_4 sorry
    also have "... = ((?e1 +XCMPLX-0K2 ?e2)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((?e3 +XCMPLX-0K2 ?e4)/XCMPLX-0K7 \<two>\<^sub>M) -XCMPLX-0K6 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
      using sin_cos3_def_4 sorry
    also have "... = ((?e1 +XCMPLX-0K2 ?e2)*XCMPLX-0K3 (?e3 +XCMPLX-0K2 ?e4))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M) -XCMPLX-0K6 ((?e1 -XCMPLX-0K6 ?e2)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
      using sin_cos3_def_3 sorry
    also have "... = ((?e1 +XCMPLX-0K2 ?e2)*XCMPLX-0K3 (?e3 +XCMPLX-0K2 ?e4))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M) -XCMPLX-0K6 ((?e1 -XCMPLX-0K6 ?e2)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((?e3 -XCMPLX-0K6 ?e4)/XCMPLX-0K7 \<two>\<^sub>M)"
      using sin_cos3_def_3 sorry
    also have "... = ((?e2 *XCMPLX-0K3 ?e3 +XCMPLX-0K2 ?e2 *XCMPLX-0K3 ?e3)+XCMPLX-0K2 ((?e1 *XCMPLX-0K3 ?e4 +XCMPLX-0K2 ?e2 *XCMPLX-0K3 ?e4)+XCMPLX-0K2 (?e1 *XCMPLX-0K3 ?e4 -XCMPLX-0K6 ?e2 *XCMPLX-0K3 ?e4)))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
       sorry
    also have "... = (((ReCOMPLEX1K3 (?e2 *XCMPLX-0K3 ?e3) +REAL-1K3 ReCOMPLEX1K3 (?e2 *XCMPLX-0K3 ?e3))+XCMPLX-0K2 (ImCOMPLEX1K4 (?e2 *XCMPLX-0K3 ?e3) +REAL-1K3 ImCOMPLEX1K4 (?e2 *XCMPLX-0K3 ?e3))*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 (?e1 *XCMPLX-0K3 ?e4 +XCMPLX-0K2 ?e1 *XCMPLX-0K3 ?e4))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
      using complex1_th_81 sorry
    also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 ReCOMPLEX1K3 (?e2 *XCMPLX-0K3 ?e3) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ImCOMPLEX1K4 (?e2 *XCMPLX-0K3 ?e3))*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 (?e1 *XCMPLX-0K3 ?e4 +XCMPLX-0K2 ?e1 *XCMPLX-0K3 ?e4))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
       sorry
    also have "... = ((ReCOMPLEX1K3 (\<two>\<^sub>M *XCMPLX-0K3 (?e2 *XCMPLX-0K3 ?e3)) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ImCOMPLEX1K4 (?e2 *XCMPLX-0K3 ?e3))*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 (?e1 *XCMPLX-0K3 ?e4 +XCMPLX-0K2 ?e1 *XCMPLX-0K3 ?e4))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
      using comseq_3_th_17 sorry
    also have "... = ((ReCOMPLEX1K3 (\<two>\<^sub>M *XCMPLX-0K3 (?e2 *XCMPLX-0K3 ?e3)) +XCMPLX-0K2 ImCOMPLEX1K4 (\<two>\<^sub>M *XCMPLX-0K3 (?e2 *XCMPLX-0K3 ?e3)) *XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 (?e1 *XCMPLX-0K3 ?e4 +XCMPLX-0K2 ?e1 *XCMPLX-0K3 ?e4))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
      using comseq_3_th_17 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (?e2 *XCMPLX-0K3 ?e3) +XCMPLX-0K2 (?e1 *XCMPLX-0K3 ?e4 +XCMPLX-0K2 ?e1 *XCMPLX-0K3 ?e4))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
      using complex1_th_13 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (?e2 *XCMPLX-0K3 ?e3) +XCMPLX-0K2 ((ReCOMPLEX1K3 (?e1 *XCMPLX-0K3 ?e4) +REAL-1K3 ReCOMPLEX1K3 (?e1 *XCMPLX-0K3 ?e4))+XCMPLX-0K2 (ImCOMPLEX1K4 (?e1 *XCMPLX-0K3 ?e4) +REAL-1K3 ImCOMPLEX1K4 (?e1 *XCMPLX-0K3 ?e4))*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
      using complex1_th_81 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (?e2 *XCMPLX-0K3 ?e3) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ReCOMPLEX1K3 (?e1 *XCMPLX-0K3 ?e4) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ImCOMPLEX1K4 (?e1 *XCMPLX-0K3 ?e4))*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
       sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (?e2 *XCMPLX-0K3 ?e3) +XCMPLX-0K2 (ReCOMPLEX1K3 (\<two>\<^sub>M *XCMPLX-0K3 (?e1 *XCMPLX-0K3 ?e4)) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ImCOMPLEX1K4 (?e1 *XCMPLX-0K3 ?e4))*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
      using comseq_3_th_17 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (?e2 *XCMPLX-0K3 ?e3) +XCMPLX-0K2 (ReCOMPLEX1K3 (\<two>\<^sub>M *XCMPLX-0K3 (?e1 *XCMPLX-0K3 ?e4)) +XCMPLX-0K2 ImCOMPLEX1K4 (\<two>\<^sub>M *XCMPLX-0K3 (?e1 *XCMPLX-0K3 ?e4)) *XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
      using comseq_3_th_17 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (?e2 *XCMPLX-0K3 ?e3) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (?e1 *XCMPLX-0K3 ?e4))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
      using complex1_th_13 sorry
    also have "... = (?e1 *XCMPLX-0K3 ?e4)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (?e2 *XCMPLX-0K3 ?e3))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
       sorry
    also have "... = (expSIN-COSK16 (z1 +XCMPLX-0K2 (-XCMPLX-0K4 z2)))/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (?e2 *XCMPLX-0K3 ?e3)/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos_th_23 sorry
    also have "... = (expSIN-COSK16 (z1 -XCMPLX-0K6 z2))/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (expSIN-COSK16 ((-XCMPLX-0K4 z1)+XCMPLX-0K2 z2))/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos_th_23 sorry
    also have "... = (expSIN-COSK16 (z1 -XCMPLX-0K6 z2) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (z1 -XCMPLX-0K6 z2)))/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    finally have "(cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 -XCMPLX-0K6 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 =HIDDENR1 (expSIN-COSK16 (z1 -XCMPLX-0K6 z2) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (z1 -XCMPLX-0K6 z2)))/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    thus "(cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =COMPLEX1R1 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 -XCMPLX-0K6 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
      using sin_cos3_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos3_th_14:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) =COMPLEX1R1 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 +XCMPLX-0K2 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) =COMPLEX1R1 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 +XCMPLX-0K2 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    have "(cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) =HIDDENR1 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 (-XCMPLX-0K4 z2))"
       sorry
    also have "... = (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z2) -XCMPLX-0K6 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z2)"
      using sin_cos3_th_13 sorry
    also have "... = (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 -XCMPLX-0K6 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z2)"
      using sin_cos3_th_10 sorry
    also have "... = (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 -XCMPLX-0K6 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (-XCMPLX-0K4 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2)"
      using sin_cos3_th_9 sorry
    also have "... = (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 -XCMPLX-0K6 (-XCMPLX-0K4 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2)"
       sorry
    finally have "(cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) =HIDDENR1 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 -XCMPLX-0K6 (-XCMPLX-0K4 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2)"
       sorry
    thus "(cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) =COMPLEX1R1 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 +XCMPLX-0K2 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos3_th_15:
" for z be ComplexXCMPLX-0M1 holds (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((<i>COMPLEX1K8)*XCMPLX-0K3 z) =COMPLEX1R1 (<i>COMPLEX1K8)*XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
proof(rule ballI)
  fix z assume [ty]: "z be ComplexXCMPLX-0M1"
  have 
    [ty]:"z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    using xcmplx_0_def_2 sorry
  have "(sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((<i>COMPLEX1K8)*XCMPLX-0K3 z) =HIDDENR1 (expSIN-COSK16 (((<i>COMPLEX1K8)*XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 z) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 ((<i>COMPLEX1K8)*XCMPLX-0K3 z)))/XCMPLX-0K7 ((<i>COMPLEX1K8)*XCMPLX-0K3 \<two>\<^sub>M)"
    using sin_cos3_def_1 sorry
  also have "... = (<i>COMPLEX1K8)*XCMPLX-0K3 ((expSIN-COSK16 z -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M)"
     sorry
  finally have "(sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((<i>COMPLEX1K8)*XCMPLX-0K3 z) =HIDDENR1 (<i>COMPLEX1K8)*XCMPLX-0K3 ((expSIN-COSK16 z -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M)"
     sorry
  then have "(sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((<i>COMPLEX1K8)*XCMPLX-0K3 z) =COMPLEX1R1 (<i>COMPLEX1K8)*XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
    using sin_cos3_def_3 sorry
  thus "(sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((<i>COMPLEX1K8)*XCMPLX-0K3 z) =COMPLEX1R1 (<i>COMPLEX1K8)*XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
     sorry
qed "sorry"

mtheorem sin_cos3_th_16:
" for z be ComplexXCMPLX-0M1 holds (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((<i>COMPLEX1K8)*XCMPLX-0K3 z) =COMPLEX1R1 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
proof(rule ballI)
  fix z assume [ty]: "z be ComplexXCMPLX-0M1"
  have 
    [ty]:"z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    using xcmplx_0_def_2 sorry
  have "(cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((<i>COMPLEX1K8)*XCMPLX-0K3 z) =HIDDENR1 (expSIN-COSK16 (((<i>COMPLEX1K8)*XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 z) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 ((<i>COMPLEX1K8)*XCMPLX-0K3 z)))/XCMPLX-0K7 \<two>\<^sub>M"
    using sin_cos3_def_2 sorry
  also have "... = (expSIN-COSK16 (-XCMPLX-0K4 z) +XCMPLX-0K2 expSIN-COSK16 z)/XCMPLX-0K7 \<two>\<^sub>M"
     sorry
  finally have "(cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((<i>COMPLEX1K8)*XCMPLX-0K3 z) =HIDDENR1 (expSIN-COSK16 (-XCMPLX-0K4 z) +XCMPLX-0K2 expSIN-COSK16 z)/XCMPLX-0K7 \<two>\<^sub>M"
     sorry
  then have "(cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((<i>COMPLEX1K8)*XCMPLX-0K3 z) =COMPLEX1R1 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
    using sin_cos3_def_4 sorry
  thus "(cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((<i>COMPLEX1K8)*XCMPLX-0K3 z) =COMPLEX1R1 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
     sorry
qed "sorry"

mtheorem sin_cos3_th_17:
" for z be ComplexXCMPLX-0M1 holds (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((<i>COMPLEX1K8)*XCMPLX-0K3 z) =COMPLEX1R1 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
proof(rule ballI)
  fix z assume [ty]: "z be ComplexXCMPLX-0M1"
  have 
    [ty]:"z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    using xcmplx_0_def_2 sorry
  have "(sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((<i>COMPLEX1K8)*XCMPLX-0K3 z) =HIDDENR1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 \<two>\<^sub>M"
    using sin_cos3_def_3 sorry
  also have "... = (<i>COMPLEX1K8)*XCMPLX-0K3 ((expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 ((<i>COMPLEX1K8)*XCMPLX-0K3 \<two>\<^sub>M))"
     sorry
  finally have "(sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((<i>COMPLEX1K8)*XCMPLX-0K3 z) =HIDDENR1 (<i>COMPLEX1K8)*XCMPLX-0K3 ((expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 ((<i>COMPLEX1K8)*XCMPLX-0K3 \<two>\<^sub>M))"
     sorry
  then have "(sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((<i>COMPLEX1K8)*XCMPLX-0K3 z) =COMPLEX1R1 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
    using sin_cos3_def_1 sorry
  thus "(sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((<i>COMPLEX1K8)*XCMPLX-0K3 z) =COMPLEX1R1 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
     sorry
qed "sorry"

mtheorem sin_cos3_th_18:
" for z be ComplexXCMPLX-0M1 holds (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((<i>COMPLEX1K8)*XCMPLX-0K3 z) =COMPLEX1R1 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
proof(rule ballI)
  fix z assume [ty]: "z be ComplexXCMPLX-0M1"
  have 
    [ty]:"z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    using xcmplx_0_def_2 sorry
  have "(cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((<i>COMPLEX1K8)*XCMPLX-0K3 z) =COMPLEX1R1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 \<two>\<^sub>M"
    using sin_cos3_def_4 sorry
  then have "(cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((<i>COMPLEX1K8)*XCMPLX-0K3 z) =COMPLEX1R1 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
    using sin_cos3_def_2 sorry
  thus "(cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((<i>COMPLEX1K8)*XCMPLX-0K3 z) =COMPLEX1R1 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
     sorry
qed "sorry"

mlemma sin_cos3_lm_4:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds expSIN-COSK16 (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (exp-RSIN-COSK24 x)*XCMPLX-0K3 (cosSIN-COSK20 y +XCMPLX-0K2 (sinSIN-COSK18 y)*XCMPLX-0K3 (<i>COMPLEX1K8))"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds expSIN-COSK16 (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (exp-RSIN-COSK24 x)*XCMPLX-0K3 (cosSIN-COSK20 y +XCMPLX-0K2 (sinSIN-COSK18 y)*XCMPLX-0K3 (<i>COMPLEX1K8))"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    have "expSIN-COSK16 (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 (expSIN-COSK16 x)*XCMPLX-0K3 (expSIN-COSK16 (y *XCMPLX-0K3 (<i>COMPLEX1K8)))"
      using sin_cos_th_23 sorry
    also have "... = (exp-RSIN-COSK24 x)*XCMPLX-0K3 (expSIN-COSK16 (y *XCMPLX-0K3 (<i>COMPLEX1K8)))"
      using sin_cos_th_49 sorry
    also have "... = (exp-RSIN-COSK24 x)*XCMPLX-0K3 (cosSIN-COSK20 y +XCMPLX-0K2 (sinSIN-COSK18 y)*XCMPLX-0K3 (<i>COMPLEX1K8))"
      using sin_cos_th_25 sorry
    finally have "expSIN-COSK16 (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 (exp-RSIN-COSK24 x)*XCMPLX-0K3 (cosSIN-COSK20 y +XCMPLX-0K2 (sinSIN-COSK18 y)*XCMPLX-0K3 (<i>COMPLEX1K8))"
       sorry
    thus "expSIN-COSK16 (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (exp-RSIN-COSK24 x)*XCMPLX-0K3 (cosSIN-COSK20 y +XCMPLX-0K2 (sinSIN-COSK18 y)*XCMPLX-0K3 (<i>COMPLEX1K8))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos3_th_19:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds expSIN-COSK16 (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 y +XCMPLX-0K2 ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
proof(rule ballI,rule ballI)
  fix x assume [ty]: "x be RealXREAL-0M1"
  fix y assume [ty]: "y be RealXREAL-0M1"
  have "expSIN-COSK16 (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 (exp-RSIN-COSK24 x)*XCMPLX-0K3 (cosSIN-COSK20 y +XCMPLX-0K2 (sinSIN-COSK18 y)*XCMPLX-0K3 (<i>COMPLEX1K8))"
    using sin_cos3_lm_4 sorry
  also have "... = ((exp-RSIN-COSK24 x)*XCMPLX-0K3 (cosSIN-COSK20 y) -XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (sinSIN-COSK18 y))+XCMPLX-0K2 ((exp-RSIN-COSK24 x)*XCMPLX-0K3 (sinSIN-COSK18 y) +XCMPLX-0K2 (cosSIN-COSK20 y)*XCMPLX-0K3 (0NUMBERSK6))*XCMPLX-0K3 (<i>COMPLEX1K8)"
     sorry
  also have "... = (exp-RSIN-COSK24 x)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 y +XCMPLX-0K2 ((exp-RSIN-COSK24 x)*XCMPLX-0K3 (sinSIN-COSK18 y))*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using sin_cos_def_19 sorry
  also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 y +XCMPLX-0K2 ((exp-RSIN-COSK24 x)*XCMPLX-0K3 (sinSIN-COSK18 y))*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using sin_cos_def_23 sorry
  also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 y +XCMPLX-0K2 ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK18 y))*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using sin_cos_def_23 sorry
  finally have "expSIN-COSK16 (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 y +XCMPLX-0K2 ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK18 y))*XCMPLX-0K3 (<i>COMPLEX1K8)"
     sorry
  thus "expSIN-COSK16 (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 y +XCMPLX-0K2 ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using sin_cos_def_17 sorry
qed "sorry"

mtheorem sin_cos3_th_20:
"expSIN-COSK16 0cCOMPLEX1K6 =COMPLEX1R1 \<one>\<^sub>M"
  using sin_cos_th_49 sin_cos_th_51 sorry

mtheorem sin_cos3_th_21:
"(sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 =COMPLEX1R1 0NUMBERSK6"
proof-
  have "(sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 =HIDDENR1 (expSIN-COSK16 0cCOMPLEX1K6 -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 0cCOMPLEX1K6))/XCMPLX-0K7 ((<i>COMPLEX1K8)*XCMPLX-0K3 \<two>\<^sub>M)"
    using sin_cos3_def_1 sorry
  also have "... = 0cCOMPLEX1K6 /XCMPLX-0K7 ((<i>COMPLEX1K8)*XCMPLX-0K3 \<two>\<^sub>M)"
     sorry
  finally have "(sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 =HIDDENR1 0cCOMPLEX1K6 /XCMPLX-0K7 ((<i>COMPLEX1K8)*XCMPLX-0K3 \<two>\<^sub>M)"
     sorry
  thus "(sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 =COMPLEX1R1 0NUMBERSK6"
     sorry
qed

mtheorem sin_cos3_th_22:
"(sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 =COMPLEX1R1 0NUMBERSK6"
proof-
  have "(sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 =HIDDENR1 (expSIN-COSK16 0cCOMPLEX1K6 -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 0cCOMPLEX1K6))/XCMPLX-0K7 \<two>\<^sub>M"
    using sin_cos3_def_3 sorry
  also have "... = 0cCOMPLEX1K6 /XCMPLX-0K7 \<two>\<^sub>M"
     sorry
  finally have "(sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 =HIDDENR1 0cCOMPLEX1K6 /XCMPLX-0K7 \<two>\<^sub>M"
     sorry
  thus "(sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 =COMPLEX1R1 0NUMBERSK6"
     sorry
qed

mtheorem sin_cos3_th_23:
"(cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 =COMPLEX1R1 \<one>\<^sub>M"
proof-
  have "(cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 =HIDDENR1 (expSIN-COSK16 0cCOMPLEX1K6 +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 0cCOMPLEX1K6))/XCMPLX-0K7 \<two>\<^sub>M"
    using sin_cos3_def_2 sorry
  also have "... = \<one>\<^sub>M"
    using sin_cos_th_49 sin_cos_th_51 sorry
  finally have "(cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 =HIDDENR1 \<one>\<^sub>M"
     sorry
  thus "(cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 =COMPLEX1R1 \<one>\<^sub>M"
     sorry
qed

mtheorem sin_cos3_th_24:
"(cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 =COMPLEX1R1 \<one>\<^sub>M"
proof-
  have "(cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 =HIDDENR1 (expSIN-COSK16 0cCOMPLEX1K6 +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 0cCOMPLEX1K6))/XCMPLX-0K7 \<two>\<^sub>M"
    using sin_cos3_def_4 sorry
  also have "... = \<one>\<^sub>M"
    using sin_cos_th_49 sin_cos_th_51 sorry
  finally have "(cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 =HIDDENR1 \<one>\<^sub>M"
     sorry
  thus "(cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 =COMPLEX1R1 \<one>\<^sub>M"
     sorry
qed

mtheorem sin_cos3_th_25:
" for z be ComplexXCMPLX-0M1 holds expSIN-COSK16 z =COMPLEX1R1 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
proof-
  have " for z be ComplexXCMPLX-0M1 holds expSIN-COSK16 z =COMPLEX1R1 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "(cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 (expSIN-COSK16 z +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
      using sin_cos3_def_4 sorry
    also have "... = (expSIN-COSK16 z +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (expSIN-COSK16 z -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos3_def_3 sorry
    also have "... = (expSIN-COSK16 z +XCMPLX-0K2 ((expSIN-COSK16 (-XCMPLX-0K4 z) +XCMPLX-0K2 expSIN-COSK16 z)-XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 z)))/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    also have "... = ((ReCOMPLEX1K3 (expSIN-COSK16 z) +REAL-1K3 ReCOMPLEX1K3 (expSIN-COSK16 z))+XCMPLX-0K2 (ImCOMPLEX1K4 (expSIN-COSK16 z) +REAL-1K3 ImCOMPLEX1K4 (expSIN-COSK16 z))*XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 \<two>\<^sub>M"
      using complex1_th_81 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ReCOMPLEX1K3 (expSIN-COSK16 z) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ImCOMPLEX1K4 (expSIN-COSK16 z))*XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    also have "... = (ReCOMPLEX1K3 (\<two>\<^sub>M *XCMPLX-0K3 (expSIN-COSK16 z)) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ImCOMPLEX1K4 (expSIN-COSK16 z))*XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 \<two>\<^sub>M"
      using comseq_3_th_17 sorry
    also have "... = (ReCOMPLEX1K3 (\<two>\<^sub>M *XCMPLX-0K3 (expSIN-COSK16 z)) +XCMPLX-0K2 ImCOMPLEX1K4 (\<two>\<^sub>M *XCMPLX-0K3 (expSIN-COSK16 z)) *XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 \<two>\<^sub>M"
      using comseq_3_th_17 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (expSIN-COSK16 z))/XCMPLX-0K7 \<two>\<^sub>M"
      using complex1_th_13 sorry
    also have "... = (expSIN-COSK16 z)*XCMPLX-0K3 \<one>\<^sub>M"
       sorry
    finally have "(cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 (expSIN-COSK16 z)*XCMPLX-0K3 \<one>\<^sub>M"
       sorry
    thus "expSIN-COSK16 z =COMPLEX1R1 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos3_th_26:
" for z be ComplexXCMPLX-0M1 holds expSIN-COSK16 (-XCMPLX-0K4 z) =COMPLEX1R1 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
proof-
  have " for z be ComplexXCMPLX-0M1 holds expSIN-COSK16 (-XCMPLX-0K4 z) =COMPLEX1R1 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "(cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 (expSIN-COSK16 z +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
      using sin_cos3_def_4 sorry
    also have "... = (expSIN-COSK16 z +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 (expSIN-COSK16 z -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos3_def_3 sorry
    also have "... = (expSIN-COSK16 (-XCMPLX-0K4 z) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    also have "... = ((ReCOMPLEX1K3 (expSIN-COSK16 (-XCMPLX-0K4 z)) +REAL-1K3 ReCOMPLEX1K3 (expSIN-COSK16 (-XCMPLX-0K4 z)))+XCMPLX-0K2 (ImCOMPLEX1K4 (expSIN-COSK16 (-XCMPLX-0K4 z)) +REAL-1K3 ImCOMPLEX1K4 (expSIN-COSK16 (-XCMPLX-0K4 z)))*XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 \<two>\<^sub>M"
      using complex1_th_81 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ReCOMPLEX1K3 (expSIN-COSK16 (-XCMPLX-0K4 z)) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ImCOMPLEX1K4 (expSIN-COSK16 (-XCMPLX-0K4 z)))*XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    also have "... = (ReCOMPLEX1K3 (\<two>\<^sub>M *XCMPLX-0K3 (expSIN-COSK16 (-XCMPLX-0K4 z))) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ImCOMPLEX1K4 (expSIN-COSK16 (-XCMPLX-0K4 z)))*XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 \<two>\<^sub>M"
      using comseq_3_th_17 sorry
    also have "... = (ReCOMPLEX1K3 (\<two>\<^sub>M *XCMPLX-0K3 (expSIN-COSK16 (-XCMPLX-0K4 z))) +XCMPLX-0K2 ImCOMPLEX1K4 (\<two>\<^sub>M *XCMPLX-0K3 (expSIN-COSK16 (-XCMPLX-0K4 z))) *XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 \<two>\<^sub>M"
      using comseq_3_th_17 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (expSIN-COSK16 (-XCMPLX-0K4 z)))/XCMPLX-0K7 \<two>\<^sub>M"
      using complex1_th_13 sorry
    also have "... = (expSIN-COSK16 (-XCMPLX-0K4 z))*XCMPLX-0K3 \<one>\<^sub>M"
       sorry
    finally have "(cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 (expSIN-COSK16 (-XCMPLX-0K4 z))*XCMPLX-0K3 \<one>\<^sub>M"
       sorry
    thus "expSIN-COSK16 (-XCMPLX-0K4 z) =COMPLEX1R1 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos3_th_27:
" for z be ComplexXCMPLX-0M1 holds expSIN-COSK16 (z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 expSIN-COSK16 z"
proof-
  have " for z be ComplexXCMPLX-0M1 holds expSIN-COSK16 (z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 expSIN-COSK16 z"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (<i>COMPLEX1K8) =HIDDENR1 (ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex1_th_13 sorry
    also have "... = (ReCOMPLEX1K3 z +XCMPLX-0K2 0NUMBERSK6)+XCMPLX-0K2 (ImCOMPLEX1K4 z +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    finally have "z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (<i>COMPLEX1K8) =HIDDENR1 (ReCOMPLEX1K3 z +XCMPLX-0K2 0NUMBERSK6)+XCMPLX-0K2 (ImCOMPLEX1K4 z +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    then have "expSIN-COSK16 (z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 (exp-RSIN-COSK23).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMPLEX1K3 z *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (ImCOMPLEX1K4 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 \<one>\<^sub>M) +XCMPLX-0K2 ((exp-RSIN-COSK23).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMPLEX1K3 z *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (ImCOMPLEX1K4 z +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos3_th_19 sorry
    also have "... = (exp-RSIN-COSK23).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMPLEX1K3 z *REAL-1K4 (cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMPLEX1K4 z +XCMPLX-0K2 ((exp-RSIN-COSK23).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMPLEX1K3 z *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (ImCOMPLEX1K4 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 \<one>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos2_th_11 sorry
    also have "... = (exp-RSIN-COSK23).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMPLEX1K3 z *REAL-1K4 (cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMPLEX1K4 z +XCMPLX-0K2 ((exp-RSIN-COSK23).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMPLEX1K3 z *REAL-1K4 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMPLEX1K4 z)*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos2_th_10 sorry
    also have "... = expSIN-COSK16 (ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8))"
      using sin_cos3_th_19 sorry
    finally have "expSIN-COSK16 (z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 expSIN-COSK16 (ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8))"
       sorry
    thus "expSIN-COSK16 (z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 expSIN-COSK16 z"
      using complex1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos3_th_28:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds expSIN-COSK16 (((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n)*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 \<one>\<^sub>M"
proof-
  have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds expSIN-COSK16 (((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n)*XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 \<one>\<^sub>M"
  proof(rule ballI)
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    have "expSIN-COSK16 (((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n)*XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 cosSIN-COSK20 (0NUMBERSK6 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n) +XCMPLX-0K2 (sinSIN-COSK18 (0NUMBERSK6 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_th_25 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 (0NUMBERSK6 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n) +XCMPLX-0K2 (sinSIN-COSK18 (0NUMBERSK6 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_def_19 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 (0NUMBERSK6 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (0NUMBERSK6 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n) *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_def_17 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 (0NUMBERSK6 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (0NUMBERSK6) *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos2_th_10 sorry
    also have "... = \<one>\<^sub>M"
      using sin_cos_th_30 sin_cos2_th_11 sorry
    finally show "expSIN-COSK16 (((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n)*XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos3_th_29:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds expSIN-COSK16 ((-XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n)*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 \<one>\<^sub>M"
proof-
  have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds expSIN-COSK16 ((-XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n)*XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 \<one>\<^sub>M"
  proof(rule ballI)
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    have "expSIN-COSK16 ((-XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n)*XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 cosSIN-COSK20 (-XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n) +XCMPLX-0K2 (sinSIN-COSK18 (-XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_th_25 sorry
    also have "... = cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n) +XCMPLX-0K2 (sinSIN-COSK18 (-XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_th_31 sorry
    also have "... = cosSIN-COSK20 (0NUMBERSK6 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n) +XCMPLX-0K2 (-XCMPLX-0K4 sinSIN-COSK18 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_th_31 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 (0NUMBERSK6 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n) +XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK18 (0NUMBERSK6 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n))*XCMPLX-0K3 (<i>COMPLEX1K8))"
      using sin_cos_def_19 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 (0NUMBERSK6 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n) +XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (0NUMBERSK6 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n) *XCMPLX-0K3 (<i>COMPLEX1K8))"
      using sin_cos_def_17 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 (0NUMBERSK6 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n) +XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (0NUMBERSK6) *XCMPLX-0K3 (<i>COMPLEX1K8))"
      using sin_cos2_th_10 sorry
    also have "... = \<one>\<^sub>M"
      using sin_cos_th_30 sin_cos2_th_11 sorry
    finally show "expSIN-COSK16 ((-XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n)*XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos3_th_30:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds expSIN-COSK16 (((\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
proof-
  have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds expSIN-COSK16 (((\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
  proof(rule ballI)
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    have "expSIN-COSK16 (((\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 cosSIN-COSK20 (((PISIN-COSK29)*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 n +XCMPLX-0K2 PISIN-COSK29) +XCMPLX-0K2 (sinSIN-COSK18 ((PISIN-COSK29)*XCMPLX-0K3 (\<two>\<^sub>M *NAT-1K2 n) +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_th_25 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 (((PISIN-COSK29)*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 n +XCMPLX-0K2 PISIN-COSK29) +XCMPLX-0K2 (sinSIN-COSK18 (((PISIN-COSK29)*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 n +XCMPLX-0K2 PISIN-COSK29))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_def_19 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 (((PISIN-COSK29)*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 n +XCMPLX-0K2 PISIN-COSK29) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (((PISIN-COSK29)*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 n +XCMPLX-0K2 PISIN-COSK29) *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_def_17 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 (PISIN-COSK29) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (((PISIN-COSK29)*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 n +XCMPLX-0K2 PISIN-COSK29) *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos2_th_11 sorry
    also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)+XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (PISIN-COSK29) *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_th_76 sin_cos2_th_10 sorry
    finally have "expSIN-COSK16 (((\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)+XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (PISIN-COSK29) *XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    thus "expSIN-COSK16 (((\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
      using sin_cos_th_76 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos3_th_31:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds expSIN-COSK16 ((-XCMPLX-0K4 (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
proof-
  have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds expSIN-COSK16 ((-XCMPLX-0K4 (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
  proof(rule ballI)
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    have "expSIN-COSK16 ((-XCMPLX-0K4 (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 cosSIN-COSK20 (-XCMPLX-0K4 (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) +XCMPLX-0K2 (sinSIN-COSK18 (-XCMPLX-0K4 (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_th_25 sorry
    also have "... = cosSIN-COSK20 ((\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) +XCMPLX-0K2 (sinSIN-COSK18 (-XCMPLX-0K4 (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_th_31 sorry
    also have "... = cosSIN-COSK20 (((PISIN-COSK29)*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 n +XCMPLX-0K2 PISIN-COSK29) +XCMPLX-0K2 (-XCMPLX-0K4 sinSIN-COSK18 ((PISIN-COSK29)*XCMPLX-0K3 (\<two>\<^sub>M *NAT-1K2 n) +XCMPLX-0K2 PISIN-COSK29))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_th_31 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 (((PISIN-COSK29)*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 n +XCMPLX-0K2 PISIN-COSK29) +XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK18 (((PISIN-COSK29)*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 n +XCMPLX-0K2 PISIN-COSK29))*XCMPLX-0K3 (<i>COMPLEX1K8))"
      using sin_cos_def_19 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 (((PISIN-COSK29)*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 n +XCMPLX-0K2 PISIN-COSK29) +XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (((PISIN-COSK29)*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 n +XCMPLX-0K2 PISIN-COSK29) *XCMPLX-0K3 (<i>COMPLEX1K8))"
      using sin_cos_def_17 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 (PISIN-COSK29) +XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (((PISIN-COSK29)*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 n +XCMPLX-0K2 PISIN-COSK29) *XCMPLX-0K3 (<i>COMPLEX1K8))"
      using sin_cos2_th_11 sorry
    also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)+XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (PISIN-COSK29) *XCMPLX-0K3 (<i>COMPLEX1K8))"
      using sin_cos_th_76 sin_cos2_th_10 sorry
    finally have "expSIN-COSK16 ((-XCMPLX-0K4 (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)+XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (PISIN-COSK29) *XCMPLX-0K3 (<i>COMPLEX1K8))"
       sorry
    thus "expSIN-COSK16 ((-XCMPLX-0K4 (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
      using sin_cos_th_76 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos3_th_32:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds expSIN-COSK16 (((\<two>\<^sub>M *NAT-1K2 n +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 <i>COMPLEX1K8"
proof-
  have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds expSIN-COSK16 (((\<two>\<^sub>M *NAT-1K2 n +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 <i>COMPLEX1K8"
  proof(rule ballI)
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    have "expSIN-COSK16 (((\<two>\<^sub>M *NAT-1K2 n +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 cosSIN-COSK20 (((PISIN-COSK29)*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 n +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) +XCMPLX-0K2 (sinSIN-COSK18 ((PISIN-COSK29)*XCMPLX-0K3 (\<two>\<^sub>M *NAT-1K2 n) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_th_25 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 (((PISIN-COSK29)*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 n +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) +XCMPLX-0K2 (sinSIN-COSK18 (((PISIN-COSK29)*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 n +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_def_19 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 (((PISIN-COSK29)*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 n +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (((PISIN-COSK29)*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 n +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_def_17 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (((PISIN-COSK29)*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 n +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos2_th_11 sorry
    also have "... = (sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_th_76 sin_cos2_th_10 sorry
    finally have "expSIN-COSK16 (((\<two>\<^sub>M *NAT-1K2 n +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    thus "expSIN-COSK16 (((\<two>\<^sub>M *NAT-1K2 n +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 <i>COMPLEX1K8"
      using sin_cos_th_76 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos3_th_33:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds expSIN-COSK16 ((-XCMPLX-0K4 (\<two>\<^sub>M *NAT-1K2 n +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8)"
proof-
  have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds expSIN-COSK16 ((-XCMPLX-0K4 (\<two>\<^sub>M *NAT-1K2 n +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8)"
  proof(rule ballI)
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    have "expSIN-COSK16 ((-XCMPLX-0K4 (\<two>\<^sub>M *NAT-1K2 n +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 cosSIN-COSK20 (-XCMPLX-0K4 (\<two>\<^sub>M *NAT-1K2 n +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) +XCMPLX-0K2 (sinSIN-COSK18 (-XCMPLX-0K4 (\<two>\<^sub>M *NAT-1K2 n +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_th_25 sorry
    also have "... = cosSIN-COSK20 ((\<two>\<^sub>M *NAT-1K2 n +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) +XCMPLX-0K2 (sinSIN-COSK18 (-XCMPLX-0K4 (\<two>\<^sub>M *NAT-1K2 n +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_th_31 sorry
    also have "... = cosSIN-COSK20 (((PISIN-COSK29)*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 n +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) +XCMPLX-0K2 (-XCMPLX-0K4 sinSIN-COSK18 ((PISIN-COSK29)*XCMPLX-0K3 (\<two>\<^sub>M *NAT-1K2 n) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_th_31 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 (((PISIN-COSK29)*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 n +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) +XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK18 (((PISIN-COSK29)*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 n +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)))*XCMPLX-0K3 (<i>COMPLEX1K8))"
      using sin_cos_def_19 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 (((PISIN-COSK29)*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 n +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) +XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (((PISIN-COSK29)*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 n +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) *XCMPLX-0K3 (<i>COMPLEX1K8))"
      using sin_cos_def_17 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) +XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (((PISIN-COSK29)*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 n +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos2_th_11 sorry
    also have "... = (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_th_76 sin_cos2_th_10 sorry
    finally have "expSIN-COSK16 ((-XCMPLX-0K4 (\<two>\<^sub>M *NAT-1K2 n +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    thus "expSIN-COSK16 ((-XCMPLX-0K4 (\<two>\<^sub>M *NAT-1K2 n +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_th_76 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos3_th_34:
" for z be ComplexXCMPLX-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z +XCMPLX-0K2 (\<two>\<^sub>M *NAT-1K2 n)*XCMPLX-0K3 (PISIN-COSK29)) =COMPLEX1R1 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
proof-
  have " for z be ComplexXCMPLX-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z +XCMPLX-0K2 (\<two>\<^sub>M *NAT-1K2 n)*XCMPLX-0K3 (PISIN-COSK29)) =COMPLEX1R1 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
  proof(rule ballI,rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    have "(sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z +XCMPLX-0K2 (\<two>\<^sub>M *NAT-1K2 n)*XCMPLX-0K3 (PISIN-COSK29)) =HIDDENR1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 ((\<two>\<^sub>M *NAT-1K2 n)*XCMPLX-0K3 (PISIN-COSK29))) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 (z +XCMPLX-0K2 (\<two>\<^sub>M *NAT-1K2 n)*XCMPLX-0K3 (PISIN-COSK29))))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))"
      using sin_cos3_def_1 sorry
    also have "... = ((expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z))*XCMPLX-0K3 (expSIN-COSK16 (((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n)*XCMPLX-0K3 (<i>COMPLEX1K8))) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 (z +XCMPLX-0K2 (\<two>\<^sub>M *NAT-1K2 n)*XCMPLX-0K3 (PISIN-COSK29))))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))"
      using sin_cos_th_23 sorry
    also have "... = ((expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z))*XCMPLX-0K3 \<one>\<^sub>M -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 (z +XCMPLX-0K2 (\<two>\<^sub>M *NAT-1K2 n)*XCMPLX-0K3 (PISIN-COSK29))))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))"
      using sin_cos3_th_28 sorry
    also have "... = (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) -XCMPLX-0K6 expSIN-COSK16 ((-XCMPLX-0K4 <i>COMPLEX1K8)*XCMPLX-0K3 z +XCMPLX-0K2 (-XCMPLX-0K4 <i>COMPLEX1K8)*XCMPLX-0K3 ((\<two>\<^sub>M *NAT-1K2 n)*XCMPLX-0K3 (PISIN-COSK29))))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))"
       sorry
    also have "... = (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) -XCMPLX-0K6 (expSIN-COSK16 ((-XCMPLX-0K4 <i>COMPLEX1K8)*XCMPLX-0K3 z))*XCMPLX-0K3 (expSIN-COSK16 ((-XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n)*XCMPLX-0K3 (<i>COMPLEX1K8))))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))"
      using sin_cos_th_23 sorry
    also have "... = (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) -XCMPLX-0K6 (expSIN-COSK16 ((-XCMPLX-0K4 <i>COMPLEX1K8)*XCMPLX-0K3 z))*XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))"
      using sin_cos3_th_29 sorry
    also have "... = (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))"
       sorry
    finally have "(sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z +XCMPLX-0K2 (\<two>\<^sub>M *NAT-1K2 n)*XCMPLX-0K3 (PISIN-COSK29)) =HIDDENR1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))"
       sorry
    thus "(sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z +XCMPLX-0K2 (\<two>\<^sub>M *NAT-1K2 n)*XCMPLX-0K3 (PISIN-COSK29)) =COMPLEX1R1 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
      using sin_cos3_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos3_th_35:
" for z be ComplexXCMPLX-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z +XCMPLX-0K2 (\<two>\<^sub>M *NAT-1K2 n)*XCMPLX-0K3 (PISIN-COSK29)) =COMPLEX1R1 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
proof-
  have " for z be ComplexXCMPLX-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z +XCMPLX-0K2 (\<two>\<^sub>M *NAT-1K2 n)*XCMPLX-0K3 (PISIN-COSK29)) =COMPLEX1R1 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
  proof(rule ballI,rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    have "(cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z +XCMPLX-0K2 (\<two>\<^sub>M *NAT-1K2 n)*XCMPLX-0K3 (PISIN-COSK29)) =HIDDENR1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 ((\<two>\<^sub>M *NAT-1K2 n)*XCMPLX-0K3 (PISIN-COSK29))) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 (z +XCMPLX-0K2 (\<two>\<^sub>M *NAT-1K2 n)*XCMPLX-0K3 (PISIN-COSK29))))/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos3_def_2 sorry
    also have "... = ((expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z))*XCMPLX-0K3 (expSIN-COSK16 (((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n)*XCMPLX-0K3 (<i>COMPLEX1K8))) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 (z +XCMPLX-0K2 (\<two>\<^sub>M *NAT-1K2 n)*XCMPLX-0K3 (PISIN-COSK29))))/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos_th_23 sorry
    also have "... = ((expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z))*XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 (z +XCMPLX-0K2 (\<two>\<^sub>M *NAT-1K2 n)*XCMPLX-0K3 (PISIN-COSK29))))/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos3_th_28 sorry
    also have "... = (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) +XCMPLX-0K2 expSIN-COSK16 ((-XCMPLX-0K4 <i>COMPLEX1K8)*XCMPLX-0K3 z +XCMPLX-0K2 (-XCMPLX-0K4 <i>COMPLEX1K8)*XCMPLX-0K3 ((\<two>\<^sub>M *NAT-1K2 n)*XCMPLX-0K3 (PISIN-COSK29))))/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    also have "... = (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) +XCMPLX-0K2 (expSIN-COSK16 ((-XCMPLX-0K4 <i>COMPLEX1K8)*XCMPLX-0K3 z))*XCMPLX-0K3 (expSIN-COSK16 ((-XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n)*XCMPLX-0K3 (<i>COMPLEX1K8))))/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos_th_23 sorry
    also have "... = ((expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z))*XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 (expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))*XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos3_th_29 sorry
    also have "... = (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    finally have "(cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z +XCMPLX-0K2 (\<two>\<^sub>M *NAT-1K2 n)*XCMPLX-0K3 (PISIN-COSK29)) =HIDDENR1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    thus "(cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z +XCMPLX-0K2 (\<two>\<^sub>M *NAT-1K2 n)*XCMPLX-0K3 (PISIN-COSK29)) =COMPLEX1R1 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
      using sin_cos3_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos3_th_36:
" for z be ComplexXCMPLX-0M1 holds expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) =COMPLEX1R1 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
proof(rule ballI)
  fix z assume [ty]: "z be ComplexXCMPLX-0M1"
  have 
    [ty]:"z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    using xcmplx_0_def_2 sorry
  have "(cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
    using sin_cos3_def_2 sorry
  also have "... = (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 ((expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8)))"
    using sin_cos3_def_1 sorry
  also have "... = (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) +XCMPLX-0K2 ((expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z) +XCMPLX-0K2 expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z))-XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z)))/XCMPLX-0K7 \<two>\<^sub>M"
     sorry
  also have "... = ((ReCOMPLEX1K3 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z)) +REAL-1K3 ReCOMPLEX1K3 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z)))+XCMPLX-0K2 (ImCOMPLEX1K4 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z)) +REAL-1K3 ImCOMPLEX1K4 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z)))*XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 \<two>\<^sub>M"
    using complex1_th_81 sorry
  also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ReCOMPLEX1K3 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z)) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ImCOMPLEX1K4 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z)))*XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 \<two>\<^sub>M"
     sorry
  also have "... = (ReCOMPLEX1K3 (\<two>\<^sub>M *XCMPLX-0K3 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z))) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ImCOMPLEX1K4 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z)))*XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 \<two>\<^sub>M"
    using comseq_3_th_17 sorry
  also have "... = (ReCOMPLEX1K3 (\<two>\<^sub>M *XCMPLX-0K3 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z))) +XCMPLX-0K2 ImCOMPLEX1K4 (\<two>\<^sub>M *XCMPLX-0K3 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z))) *XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 \<two>\<^sub>M"
    using comseq_3_th_17 sorry
  also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z)))/XCMPLX-0K7 \<two>\<^sub>M"
    using complex1_th_13 sorry
  finally have "(cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z)))/XCMPLX-0K7 \<two>\<^sub>M"
     sorry
  thus "expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) =COMPLEX1R1 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
     sorry
qed "sorry"

mtheorem sin_cos3_th_37:
" for z be ComplexXCMPLX-0M1 holds expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z) =COMPLEX1R1 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
proof(rule ballI)
  fix z assume [ty]: "z be ComplexXCMPLX-0M1"
  have 
    [ty]:"z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    using xcmplx_0_def_2 sorry
  have "(cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
    using sin_cos3_def_2 sorry
  also have "... = (expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 (<i>COMPLEX1K8)*XCMPLX-0K3 ((expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 z) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8)))"
    using sin_cos3_def_1 sorry
  also have "... = (expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))/XCMPLX-0K7 \<two>\<^sub>M"
     sorry
  also have "... = ((ReCOMPLEX1K3 (expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z)) +REAL-1K3 ReCOMPLEX1K3 (expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z)))+XCMPLX-0K2 (ImCOMPLEX1K4 (expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z)) +REAL-1K3 ImCOMPLEX1K4 (expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z)))*XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 \<two>\<^sub>M"
    using complex1_th_81 sorry
  also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ReCOMPLEX1K3 (expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z)) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ImCOMPLEX1K4 (expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z)))*XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 \<two>\<^sub>M"
     sorry
  also have "... = (ReCOMPLEX1K3 (\<two>\<^sub>M *XCMPLX-0K3 (expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ImCOMPLEX1K4 (expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z)))*XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 \<two>\<^sub>M"
    using comseq_3_th_17 sorry
  also have "... = (ReCOMPLEX1K3 (\<two>\<^sub>M *XCMPLX-0K3 (expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))) +XCMPLX-0K2 ImCOMPLEX1K4 (\<two>\<^sub>M *XCMPLX-0K3 (expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z))) *XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 \<two>\<^sub>M"
    using comseq_3_th_17 sorry
  also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z)))/XCMPLX-0K7 \<two>\<^sub>M"
    using complex1_th_13 sorry
  finally have "(cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z)))/XCMPLX-0K7 \<two>\<^sub>M"
     sorry
  thus "expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 z) =COMPLEX1R1 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
     sorry
qed "sorry"

mtheorem sin_cos3_th_38:
" for x be RealXREAL-0M1 holds (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 (sinSIN-COSK17).FUNCT-1K1 x"
proof(rule ballI)
  fix x assume [ty]: "x be RealXREAL-0M1"
  have "x inHIDDENR3 REALNUMBERSK2"
    using xreal_0_def_1 sorry
  then obtain z where 
    [ty]:"z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and zDef:"z = x"
    using numbers_th_11 sorry
  have "(sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
     sorry
  also have "... = (expSIN-COSK16 ((-XCMPLX-0K4 0NUMBERSK6)+XCMPLX-0K2 x *XCMPLX-0K3 (<i>COMPLEX1K8)) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 x))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))"
    using sin_cos3_def_1 sorry
  also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 (0NUMBERSK6) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 ((exp-RSIN-COSK23).FUNCT-1K1 (0NUMBERSK6) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)*XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 x *XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))"
    using sin_cos3_th_19 sorry
  also have "... = (((exp-RSIN-COSK24 (0NUMBERSK6))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 ((exp-RSIN-COSK23).FUNCT-1K1 (0NUMBERSK6) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)*XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 x *XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))"
    using sin_cos_def_23 sorry
  also have "... = (((exp-RSIN-COSK24 (0NUMBERSK6))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 ((exp-RSIN-COSK24 (0NUMBERSK6))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)*XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 x *XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))"
    using sin_cos_def_23 sorry
  also have "... = (((cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 expSIN-COSK16 (0NUMBERSK6 +XCMPLX-0K2 (-XCMPLX-0K4 x)*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))"
    using sin_cos_th_51 sorry
  also have "... = (((cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 ((exp-RSIN-COSK23).FUNCT-1K1 (0NUMBERSK6) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (-XCMPLX-0K4 x) +XCMPLX-0K2 ((exp-RSIN-COSK23).FUNCT-1K1 (0NUMBERSK6) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 x))*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))"
    using sin_cos3_th_19 sorry
  also have "... = (((cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 ((exp-RSIN-COSK24 (0NUMBERSK6))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (-XCMPLX-0K4 x) +XCMPLX-0K2 ((exp-RSIN-COSK23).FUNCT-1K1 (0NUMBERSK6) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 x))*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))"
    using sin_cos_def_23 sorry
  also have "... = (((cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 (\<one>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (-XCMPLX-0K4 x) +XCMPLX-0K2 (\<one>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 x))*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))"
    using sin_cos_th_51 sin_cos_def_23 sorry
  also have "... = (((cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 ((cosSIN-COSK19).FUNCT-1K1 (-XCMPLX-0K4 x) +XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x)*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))"
    using sin_cos_th_30 sorry
  also have "... = (((cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 ((cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x)*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8))"
    using sin_cos_th_30 sorry
  also have "... = (sinSIN-COSK17).FUNCT-1K1 x"
     sorry
  finally have "(sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 x"
     sorry
  thus "(sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 (sinSIN-COSK17).FUNCT-1K1 x"
     sorry
qed "sorry"

mtheorem sin_cos3_th_39:
" for x be RealXREAL-0M1 holds (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 x"
proof(rule ballI)
  fix x assume [ty]: "x be RealXREAL-0M1"
  have "x inHIDDENR3 REALNUMBERSK2"
    using xreal_0_def_1 sorry
  then obtain z where 
    [ty]:"z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and zDef:"z = x"
    using numbers_th_11 sorry
  have "(cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
     sorry
  also have "... = (expSIN-COSK16 (0NUMBERSK6 +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 x) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 x))/XCMPLX-0K7 \<two>\<^sub>M"
    using sin_cos3_def_2 sorry
  also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 (0NUMBERSK6) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 ((exp-RSIN-COSK23).FUNCT-1K1 (0NUMBERSK6) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 x))/XCMPLX-0K7 \<two>\<^sub>M"
    using sin_cos3_th_19 sorry
  also have "... = (((exp-RSIN-COSK24 (0NUMBERSK6))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 ((exp-RSIN-COSK23).FUNCT-1K1 (0NUMBERSK6) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 x))/XCMPLX-0K7 \<two>\<^sub>M"
    using sin_cos_def_23 sorry
  also have "... = ((\<one>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 x))/XCMPLX-0K7 \<two>\<^sub>M"
    using sin_cos_th_51 sin_cos_def_23 sorry
  also have "... = (((cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 expSIN-COSK16 (0NUMBERSK6 +XCMPLX-0K2 (-XCMPLX-0K4 x)*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 \<two>\<^sub>M"
     sorry
  also have "... = (((cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 ((exp-RSIN-COSK23).FUNCT-1K1 (0NUMBERSK6) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (-XCMPLX-0K4 x) +XCMPLX-0K2 ((exp-RSIN-COSK23).FUNCT-1K1 (0NUMBERSK6) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 x))*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 \<two>\<^sub>M"
    using sin_cos3_th_19 sorry
  also have "... = (((cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 ((exp-RSIN-COSK24 (0NUMBERSK6))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (-XCMPLX-0K4 x) +XCMPLX-0K2 ((exp-RSIN-COSK23).FUNCT-1K1 (0NUMBERSK6) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 x))*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 \<two>\<^sub>M"
    using sin_cos_def_23 sorry
  also have "... = (((cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 (\<one>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (-XCMPLX-0K4 x) +XCMPLX-0K2 (\<one>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 x))*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 \<two>\<^sub>M"
    using sin_cos_th_51 sin_cos_def_23 sorry
  also have "... = (((cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 (\<one>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 x))*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 \<two>\<^sub>M"
    using sin_cos_th_30 sorry
  also have "... = (((cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 ((cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x)*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 \<two>\<^sub>M"
    using sin_cos_th_30 sorry
  also have "... = (cosSIN-COSK19).FUNCT-1K1 x"
     sorry
  finally have "(cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x"
     sorry
  thus "(cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 x"
     sorry
qed "sorry"

mtheorem sin_cos3_th_40:
" for x be RealXREAL-0M1 holds (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 (sinhSIN-COS2K1).FUNCT-1K1 x"
proof(rule ballI)
  fix x assume [ty]: "x be RealXREAL-0M1"
  have A1: "(sinhSIN-COS2K1).FUNCT-1K1 x *XCMPLX-0K3 \<two>\<^sub>M =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 x))/XCMPLX-0K7 \<two>\<^sub>M)"
    using sin_cos2_def_1 sorry
  also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 x))/XCMPLX-0K7 (\<two>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
     sorry
  finally have "(sinhSIN-COS2K1).FUNCT-1K1 x *XCMPLX-0K3 \<two>\<^sub>M =HIDDENR1 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 x))/XCMPLX-0K7 (\<two>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
     sorry
  have "x inHIDDENR3 REALNUMBERSK2"
    using xreal_0_def_1 sorry
  then obtain z where 
    [ty]:"z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and zDef:"z = x"
    using numbers_th_11 sorry
  have "(sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
     sorry
  also have "... = (expSIN-COSK16 (x +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M"
    using sin_cos3_def_3 sorry
  also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (0NUMBERSK6))*XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M"
    using sin_cos3_th_19 sin_cos_th_30 sorry
  also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 expSIN-COSK16 ((-XCMPLX-0K4 x)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 \<two>\<^sub>M"
     sorry
  also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 ((exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 x) *XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 ((exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 x) *XCMPLX-0K3 (0NUMBERSK6))*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 \<two>\<^sub>M"
    using sin_cos3_th_19 sin_cos_th_30 sorry
  also have "... = ((sinhSIN-COS2K1).FUNCT-1K1 x *XCMPLX-0K3 \<two>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M"
    using A1 sorry
  finally have "(sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 ((sinhSIN-COS2K1).FUNCT-1K1 x *XCMPLX-0K3 \<two>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M"
     sorry
  thus "(sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 (sinhSIN-COS2K1).FUNCT-1K1 x"
     sorry
qed "sorry"

mtheorem sin_cos3_th_41:
" for x be RealXREAL-0M1 holds (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 (coshSIN-COS2K3).FUNCT-1K1 x"
proof(rule ballI)
  fix x assume [ty]: "x be RealXREAL-0M1"
  have A1: "(coshSIN-COS2K3).FUNCT-1K1 x *XCMPLX-0K3 \<two>\<^sub>M =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 x))/XCMPLX-0K7 \<two>\<^sub>M)"
    using sin_cos2_def_3 sorry
  also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 x))/XCMPLX-0K7 (\<two>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
     sorry
  finally have "(coshSIN-COS2K3).FUNCT-1K1 x *XCMPLX-0K3 \<two>\<^sub>M =HIDDENR1 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 x))/XCMPLX-0K7 (\<two>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
     sorry
  have "x inHIDDENR3 REALNUMBERSK2"
    using xreal_0_def_1 sorry
  then obtain z where 
    [ty]:"z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and zDef:"z = x"
    using numbers_th_11 sorry
  have "(cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
     sorry
  also have "... = (expSIN-COSK16 (x +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M"
    using sin_cos3_def_4 sorry
  also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (0NUMBERSK6))*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M"
    using sin_cos3_th_19 sin_cos_th_30 sorry
  also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 expSIN-COSK16 ((-XCMPLX-0K4 x)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 \<two>\<^sub>M"
     sorry
  also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 ((exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 x) *XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 ((exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 x) *XCMPLX-0K3 (0NUMBERSK6))*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 \<two>\<^sub>M"
    using sin_cos3_th_19 sin_cos_th_30 sorry
  also have "... = ((coshSIN-COS2K3).FUNCT-1K1 x *XCMPLX-0K3 \<two>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M"
    using A1 sorry
  finally have "(cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 ((coshSIN-COS2K3).FUNCT-1K1 x *XCMPLX-0K3 \<two>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M"
     sorry
  thus "(cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 (coshSIN-COS2K3).FUNCT-1K1 x"
     sorry
qed "sorry"

mtheorem sin_cos3_th_42:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 y +XCMPLX-0K2 ((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 y +XCMPLX-0K2 ((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    have "(sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (y *XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (y *XCMPLX-0K3 (<i>COMPLEX1K8))"
      using sin_cos3_th_4 sorry
    also have "... = (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> y +XCMPLX-0K2 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (y *XCMPLX-0K3 (<i>COMPLEX1K8))"
      using sin_cos3_th_16 sorry
    also have "... = (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> y +XCMPLX-0K2 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 ((sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> y *XCMPLX-0K3 (<i>COMPLEX1K8))"
      using sin_cos3_th_15 sorry
    also have "... = (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> y +XCMPLX-0K2 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 ((<i>COMPLEX1K8)*XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> y)"
      using sin_cos3_th_38 sorry
    also have "... = (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> y +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 ((<i>COMPLEX1K8)*XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> y)"
      using sin_cos3_th_39 sorry
    also have "... = (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> y +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 ((<i>COMPLEX1K8)*XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 y)"
      using sin_cos3_th_40 sorry
    also have "... = ((sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 y +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 (0NUMBERSK6 +XCMPLX-0K2 ((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8))"
      using sin_cos3_th_41 sorry
    finally have "(sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 ((sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 y +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 (0NUMBERSK6 +XCMPLX-0K2 ((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8))"
       sorry
    thus "(sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 y +XCMPLX-0K2 ((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos3_th_43:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 (-XCMPLX-0K4 y)*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 y +XCMPLX-0K2 (-XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 (-XCMPLX-0K4 y)*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 y +XCMPLX-0K2 (-XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    have "(sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 (-XCMPLX-0K4 y)*XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (-XCMPLX-0K4 y) +XCMPLX-0K2 ((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (-XCMPLX-0K4 y))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos3_th_42 sorry
    also have "... = (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 y +XCMPLX-0K2 ((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (-XCMPLX-0K4 y))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos2_th_19 sorry
    also have "... = (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 y +XCMPLX-0K2 ((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 (sinhSIN-COS2K1).FUNCT-1K1 y))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos2_th_19 sorry
    finally have "(sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 (-XCMPLX-0K4 y)*XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 y +XCMPLX-0K2 ((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 (sinhSIN-COS2K1).FUNCT-1K1 y))*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    thus "(sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 (-XCMPLX-0K4 y)*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 y +XCMPLX-0K2 (-XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos3_th_44:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 y +XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 y +XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    have "(cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((<i>COMPLEX1K8)*XCMPLX-0K3 y) -XCMPLX-0K6 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((<i>COMPLEX1K8)*XCMPLX-0K3 y)"
      using sin_cos3_th_6 sorry
    also have "... = (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((<i>COMPLEX1K8)*XCMPLX-0K3 y) -XCMPLX-0K6 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 ((sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> y *XCMPLX-0K3 (<i>COMPLEX1K8))"
      using sin_cos3_th_15 sorry
    also have "... = (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> y -XCMPLX-0K6 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 ((sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> y *XCMPLX-0K3 (<i>COMPLEX1K8))"
      using sin_cos3_th_16 sorry
    also have "... = (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> y -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 ((sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> y *XCMPLX-0K3 (<i>COMPLEX1K8))"
      using sin_cos3_th_38 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> y -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 ((sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> y *XCMPLX-0K3 (<i>COMPLEX1K8))"
      using sin_cos3_th_39 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> y -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 y *XCMPLX-0K3 (<i>COMPLEX1K8))"
      using sin_cos3_th_40 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 y -XCMPLX-0K6 ((sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos3_th_41 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 y +XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    finally have "(cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 y +XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    thus "(cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 y +XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos3_th_45:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 (-XCMPLX-0K4 y)*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 y +XCMPLX-0K2 ((sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 (-XCMPLX-0K4 y)*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 y +XCMPLX-0K2 ((sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    have "(cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 (-XCMPLX-0K4 y)*XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (-XCMPLX-0K4 y) +XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (-XCMPLX-0K4 y))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos3_th_44 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 y +XCMPLX-0K2 (-XCMPLX-0K4 ((sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (-XCMPLX-0K4 y))*XCMPLX-0K3 (<i>COMPLEX1K8))"
      using sin_cos2_th_19 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 y +XCMPLX-0K2 (-XCMPLX-0K4 ((sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 (sinhSIN-COS2K1).FUNCT-1K1 y))*XCMPLX-0K3 (<i>COMPLEX1K8))"
      using sin_cos2_th_19 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 y +XCMPLX-0K2 (-XCMPLX-0K4 (-XCMPLX-0K4 ((sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)))"
       sorry
    finally have "(cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 (-XCMPLX-0K4 y)*XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 y +XCMPLX-0K2 (-XCMPLX-0K4 (-XCMPLX-0K4 ((sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)))"
       sorry
    thus "(cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 (-XCMPLX-0K4 y)*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 y +XCMPLX-0K2 ((sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos3_th_46:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (sinhSIN-COS2K1).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 y +XCMPLX-0K2 ((coshSIN-COS2K3).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (sinhSIN-COS2K1).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 y +XCMPLX-0K2 ((coshSIN-COS2K3).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    have "(sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((y +XCMPLX-0K2 (-XCMPLX-0K4 x)*XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 (<i>COMPLEX1K8))"
       sorry
    also have "... = (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (y +XCMPLX-0K2 (-XCMPLX-0K4 x)*XCMPLX-0K3 (<i>COMPLEX1K8))"
      using sin_cos3_th_17 sorry
    also have "... = (<i>COMPLEX1K8)*XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 y *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 x +XCMPLX-0K2 (-XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 y *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 x)*XCMPLX-0K3 (<i>COMPLEX1K8))"
      using sin_cos3_th_43 sorry
    also have "... = (-XCMPLX-0K4 (-XCMPLX-0K4 (sinhSIN-COS2K1).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 y))+XCMPLX-0K2 ((coshSIN-COS2K3).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    finally have "(sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 (-XCMPLX-0K4 (-XCMPLX-0K4 (sinhSIN-COS2K1).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 y))+XCMPLX-0K2 ((coshSIN-COS2K3).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    thus "(sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (sinhSIN-COS2K1).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 y +XCMPLX-0K2 ((coshSIN-COS2K3).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos3_th_47:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 (-XCMPLX-0K4 y)*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (sinhSIN-COS2K1).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 y +XCMPLX-0K2 (-XCMPLX-0K4 (coshSIN-COS2K3).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 (-XCMPLX-0K4 y)*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (sinhSIN-COS2K1).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 y +XCMPLX-0K2 (-XCMPLX-0K4 (coshSIN-COS2K3).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    have "(sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 (-XCMPLX-0K4 y)*XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 (sinhSIN-COS2K1).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (-XCMPLX-0K4 y) +XCMPLX-0K2 ((coshSIN-COS2K3).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 y))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos3_th_46 sorry
    also have "... = (sinhSIN-COS2K1).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 y +XCMPLX-0K2 ((coshSIN-COS2K3).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 y))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_th_30 sorry
    also have "... = (sinhSIN-COS2K1).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 y +XCMPLX-0K2 ((coshSIN-COS2K3).FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 y))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_th_30 sorry
    finally have "(sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 (-XCMPLX-0K4 y)*XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 (sinhSIN-COS2K1).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 y +XCMPLX-0K2 ((coshSIN-COS2K3).FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 y))*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    thus "(sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 (-XCMPLX-0K4 y)*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (sinhSIN-COS2K1).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 y +XCMPLX-0K2 (-XCMPLX-0K4 (coshSIN-COS2K3).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos3_th_48:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (coshSIN-COS2K3).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 y +XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (coshSIN-COS2K3).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 y +XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    have "(cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((<i>COMPLEX1K8)*XCMPLX-0K3 (y +XCMPLX-0K2 (-XCMPLX-0K4 x)*XCMPLX-0K3 (<i>COMPLEX1K8))) =COMPLEX1R1 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (y +XCMPLX-0K2 (-XCMPLX-0K4 x)*XCMPLX-0K3 (<i>COMPLEX1K8))"
      using sin_cos3_th_18 sorry
    thus "(cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (coshSIN-COS2K3).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 y +XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos3_th_45 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos3_th_49:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 (-XCMPLX-0K4 y)*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (coshSIN-COS2K3).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 y +XCMPLX-0K2 (-XCMPLX-0K4 (sinhSIN-COS2K1).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 (-XCMPLX-0K4 y)*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (coshSIN-COS2K3).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 y +XCMPLX-0K2 (-XCMPLX-0K4 (sinhSIN-COS2K1).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    have "(cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 (-XCMPLX-0K4 y)*XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 (coshSIN-COS2K3).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (-XCMPLX-0K4 y) +XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 y))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos3_th_48 sorry
    also have "... = (coshSIN-COS2K3).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 y +XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 y))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_th_30 sorry
    also have "... = (coshSIN-COS2K3).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 y +XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 y))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_th_30 sorry
    finally have "(cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 (-XCMPLX-0K4 y)*XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 (coshSIN-COS2K3).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 y +XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 y))*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    thus "(cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 (-XCMPLX-0K4 y)*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (coshSIN-COS2K3).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 y +XCMPLX-0K2 (-XCMPLX-0K4 (sinhSIN-COS2K1).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$N De Moivre's Theorem*)
mtheorem sin_cos3_th_50:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for z be ComplexXCMPLX-0M1 holds ((cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z) |^COMSEQ-3K2 n =COMPLEX1R1 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z) +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z)"
proof-
  let ?X = "\<lambda>Lamb1.  for z be ComplexXCMPLX-0M1 holds ((cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z) |^COMSEQ-3K2 Lamb1 =COMPLEX1R1 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (Lamb1 *XCMPLX-0K3 z) +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (Lamb1 *XCMPLX-0K3 z)"
  have A1: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
  proof-
    have " for n be NatNAT-1M1 holds ( for z be ComplexXCMPLX-0M1 holds ((cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z) |^COMSEQ-3K2 n =COMPLEX1R1 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z) +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z)) implies ( for z be ComplexXCMPLX-0M1 holds ((cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z) |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 z) +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 z))"
    proof(rule ballI,rule impI)
      fix n assume [ty]: "n be NatNAT-1M1"
      assume A2: " for z be ComplexXCMPLX-0M1 holds ((cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z) |^COMSEQ-3K2 n =COMPLEX1R1 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z) +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z)"
      have " for z be ComplexXCMPLX-0M1 holds ((cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z) |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 z) +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 z)"
      proof(rule ballI)
        fix z assume [ty]: "z be ComplexXCMPLX-0M1"
        let ?cn = "(cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z)"
        let ?sn = "(sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z)"
        let ?c1 = "(cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
        let ?s1 = "(sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
        have A3: "((cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z) |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z)GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using comseq_3_def_2 sorry
        also have "... = ((cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z)GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 ((cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z)"
          using comseq_3_def_1 sorry
        also have "... = ((cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z) |^COMSEQ-3K2 n *XCMPLX-0K3 ((cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z)"
          using comseq_3_def_2 sorry
        also have "... = ((cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z) +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z))*XCMPLX-0K3 ((cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z)"
          using A2 sorry
        also have "... = (?cn *XCMPLX-0K3 ?c1 +XCMPLX-0K2 ((<i>COMPLEX1K8)*XCMPLX-0K3 ?sn)*XCMPLX-0K3 ?c1)+XCMPLX-0K2 (((<i>COMPLEX1K8)*XCMPLX-0K3 ?cn)*XCMPLX-0K3 ?s1 +XCMPLX-0K2 (-XCMPLX-0K4 ?sn *XCMPLX-0K3 ?s1))"
           sorry
        finally have "((cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z) |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (?cn *XCMPLX-0K3 ?c1 +XCMPLX-0K2 ((<i>COMPLEX1K8)*XCMPLX-0K3 ?sn)*XCMPLX-0K3 ?c1)+XCMPLX-0K2 (((<i>COMPLEX1K8)*XCMPLX-0K3 ?cn)*XCMPLX-0K3 ?s1 +XCMPLX-0K2 (-XCMPLX-0K4 ?sn *XCMPLX-0K3 ?s1))"
           sorry
        have "(cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 z) +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 z) =HIDDENR1 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 z) +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 ((sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z) *XCMPLX-0K3 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<one>\<^sub>M *XCMPLX-0K3 z) +XCMPLX-0K2 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z) *XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<one>\<^sub>M *XCMPLX-0K3 z))"
          using sin_cos3_th_4 sorry
        also have "... = ((cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z) *XCMPLX-0K3 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z) *XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z)+XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 ((sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z) *XCMPLX-0K3 (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z) *XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z)"
          using sin_cos3_th_6 sorry
        also have "... = ?cn *XCMPLX-0K3 ?c1 +XCMPLX-0K2 (((<i>COMPLEX1K8)*XCMPLX-0K3 ?sn)*XCMPLX-0K3 ?c1 +XCMPLX-0K2 (((<i>COMPLEX1K8)*XCMPLX-0K3 ?cn)*XCMPLX-0K3 ?s1 +XCMPLX-0K2 (-XCMPLX-0K4 ?sn *XCMPLX-0K3 ?s1)))"
           sorry
        finally have "(cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 z) +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 z) =HIDDENR1 ?cn *XCMPLX-0K3 ?c1 +XCMPLX-0K2 (((<i>COMPLEX1K8)*XCMPLX-0K3 ?sn)*XCMPLX-0K3 ?c1 +XCMPLX-0K2 (((<i>COMPLEX1K8)*XCMPLX-0K3 ?cn)*XCMPLX-0K3 ?s1 +XCMPLX-0K2 (-XCMPLX-0K4 ?sn *XCMPLX-0K3 ?s1)))"
           sorry
        thus "((cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z) |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 z) +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 z)"
          using A3 sorry
      qed "sorry"
      thus " for z be ComplexXCMPLX-0M1 holds ((cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z) |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 z) +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 z)"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have A4: "?X(0NUMBERSK6)"
    using sin_cos3_th_21 sin_cos3_th_23 complex1_def_4 comseq_3_th_11 sorry
  have " for n be NatNAT-1M1 holds ?X(n)"
    using nat_1_sch_2 A4 A1 sorry
  thus " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for z be ComplexXCMPLX-0M1 holds ((cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z) |^COMSEQ-3K2 n =COMPLEX1R1 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z) +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z)"
     sorry
qed

mtheorem sin_cos3_th_51:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for z be ComplexXCMPLX-0M1 holds ((cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z) |^COMSEQ-3K2 n =COMPLEX1R1 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z) -XCMPLX-0K6 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z)"
proof(rule ballI,rule ballI)
  fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
  fix z assume [ty]: "z be ComplexXCMPLX-0M1"
  have "((cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z) |^COMSEQ-3K2 n =HIDDENR1 ((cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (-XCMPLX-0K4 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z)) |^COMSEQ-3K2 n"
     sorry
  also have "... = ((cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z)) |^COMSEQ-3K2 n"
    using sin_cos3_th_2 sorry
  also have "... = ((cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z) +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 z)) |^COMSEQ-3K2 n"
    using sin_cos3_th_3 sorry
  also have "... = (cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 n *XCMPLX-0K3 z) +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 (-XCMPLX-0K4 z))"
    using sin_cos3_th_50 sorry
  also have "... = (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z) +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 n *XCMPLX-0K3 z)"
    using sin_cos3_th_3 sorry
  also have "... = (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z) +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (-XCMPLX-0K4 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z))"
    using sin_cos3_th_2 sorry
  also have "... = (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z) +XCMPLX-0K2 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z))"
     sorry
  finally have "((cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z) |^COMSEQ-3K2 n =HIDDENR1 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z) +XCMPLX-0K2 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z))"
     sorry
  thus "((cos-CSIN-COS3K2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z) |^COMSEQ-3K2 n =COMPLEX1R1 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z) -XCMPLX-0K6 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z)"
     sorry
qed "sorry"

mtheorem sin_cos3_th_52:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds expSIN-COSK16 (((<i>COMPLEX1K8)*XCMPLX-0K3 n)*XCMPLX-0K3 z) =COMPLEX1R1 ((cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z) |^COMSEQ-3K2 n"
proof(rule ballI,rule ballI)
  fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
  fix z assume [ty]: "z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
  have "expSIN-COSK16 (((<i>COMPLEX1K8)*XCMPLX-0K3 n)*XCMPLX-0K3 z) =HIDDENR1 expSIN-COSK16 ((<i>COMPLEX1K8)*XCMPLX-0K3 (n *XCMPLX-0K3 z))"
     sorry
  also have "... = (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z) +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z)"
    using sin_cos3_th_36 sorry
  finally have "expSIN-COSK16 (((<i>COMPLEX1K8)*XCMPLX-0K3 n)*XCMPLX-0K3 z) =HIDDENR1 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z) +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z)"
     sorry
  thus "expSIN-COSK16 (((<i>COMPLEX1K8)*XCMPLX-0K3 n)*XCMPLX-0K3 z) =COMPLEX1R1 ((cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z) |^COMSEQ-3K2 n"
    using sin_cos3_th_50 sorry
qed "sorry"

mtheorem sin_cos3_th_53:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds expSIN-COSK16 (-XCMPLX-0K4 ((<i>COMPLEX1K8)*XCMPLX-0K3 n)*XCMPLX-0K3 z) =COMPLEX1R1 ((cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z) |^COMSEQ-3K2 n"
proof(rule ballI,rule ballI)
  fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
  fix z assume [ty]: "z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
  have "expSIN-COSK16 (-XCMPLX-0K4 ((<i>COMPLEX1K8)*XCMPLX-0K3 n)*XCMPLX-0K3 z) =HIDDENR1 expSIN-COSK16 (-XCMPLX-0K4 (<i>COMPLEX1K8)*XCMPLX-0K3 (n *XCMPLX-0K3 z))"
     sorry
  also have "... = (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z) -XCMPLX-0K6 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z)"
    using sin_cos3_th_37 sorry
  finally have "expSIN-COSK16 (-XCMPLX-0K4 ((<i>COMPLEX1K8)*XCMPLX-0K3 n)*XCMPLX-0K3 z) =HIDDENR1 (cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z) -XCMPLX-0K6 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (n *XCMPLX-0K3 z)"
     sorry
  thus "expSIN-COSK16 (-XCMPLX-0K4 ((<i>COMPLEX1K8)*XCMPLX-0K3 n)*XCMPLX-0K3 z) =COMPLEX1R1 ((cos-CSIN-COS3K2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 (<i>COMPLEX1K8)*XCMPLX-0K3 (sin-CSIN-COS3K1)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z) |^COMSEQ-3K2 n"
    using sin_cos3_th_51 sorry
qed "sorry"

mtheorem sin_cos3_th_54:
" for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds ((\<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 ((\<one>\<^sub>M +XCMPLX-0K2 <i>COMPLEX1K8)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 (-REAL-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (sinhSIN-COS2K1).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x *REAL-1K4 (cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> y +REAL-1K3 (coshSIN-COS2K3).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x *REAL-1K4 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> y"
proof(rule ballI,rule ballI)
  fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
  fix y assume [ty]: "y be ElementSUBSET-1M1-of REALNUMBERSK2"
  let ?shx = "(sinhSIN-COS2K1).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x"
  let ?cy = "(cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> y"
  let ?chx = "(coshSIN-COS2K3).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x"
  let ?sy = "(sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> y"
  have "((\<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 ((\<one>\<^sub>M +XCMPLX-0K2 <i>COMPLEX1K8)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 (-REAL-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 ((\<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (?shx *REAL-1K4 ?cy +XCMPLX-0K2 (?chx *REAL-1K4 ?sy)*XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 ((\<one>\<^sub>M +XCMPLX-0K2 <i>COMPLEX1K8)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 (-REAL-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8))"
    using sin_cos3_th_46 sorry
  also have "... = ((\<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (?shx *REAL-1K4 ?cy +XCMPLX-0K2 (?chx *REAL-1K4 ?sy)*XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 ((\<one>\<^sub>M +XCMPLX-0K2 <i>COMPLEX1K8)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x *REAL-1K4 (cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> y +XCMPLX-0K2 (-REAL-1K1 (coshSIN-COS2K3).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x *REAL-1K4 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> y)*XCMPLX-0K3 (<i>COMPLEX1K8))"
    using sin_cos3_th_47 sorry
  also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ((?shx *REAL-1K4 ?cy +REAL-1K3 ?chx *REAL-1K4 ?sy)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 \<two>\<^sub>M"
     sorry
  finally have "((\<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 ((\<one>\<^sub>M +XCMPLX-0K2 <i>COMPLEX1K8)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 (-REAL-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 ((?shx *REAL-1K4 ?cy +REAL-1K3 ?chx *REAL-1K4 ?sy)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 \<two>\<^sub>M"
     sorry
  thus "((\<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 ((\<one>\<^sub>M +XCMPLX-0K2 <i>COMPLEX1K8)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 (-REAL-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (sinhSIN-COS2K1).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x *REAL-1K4 (cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> y +REAL-1K3 (coshSIN-COS2K3).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x *REAL-1K4 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> y"
     sorry
qed "sorry"

mtheorem sin_cos3_th_55:
" for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds ((\<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 ((\<one>\<^sub>M +XCMPLX-0K2 <i>COMPLEX1K8)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 (-REAL-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (sinhSIN-COS2K1).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x *REAL-1K4 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> y +REAL-1K3 (coshSIN-COS2K3).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x *REAL-1K4 (cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> y"
proof(rule ballI,rule ballI)
  fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
  fix y assume [ty]: "y be ElementSUBSET-1M1-of REALNUMBERSK2"
  let ?shx = "(sinhSIN-COS2K1).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x"
  let ?cy = "(cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> y"
  let ?chx = "(coshSIN-COS2K3).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x"
  let ?sy = "(sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> y"
  have "((\<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 ((\<one>\<^sub>M +XCMPLX-0K2 <i>COMPLEX1K8)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 (-REAL-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 ((\<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (?chx *REAL-1K4 ?cy +XCMPLX-0K2 (?shx *REAL-1K4 ?sy)*XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 ((\<one>\<^sub>M +XCMPLX-0K2 <i>COMPLEX1K8)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 (-REAL-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8))"
    using sin_cos3_th_48 sorry
  also have "... = ((\<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 (?chx *REAL-1K4 ?cy +XCMPLX-0K2 (?shx *REAL-1K4 ?sy)*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 ((\<one>\<^sub>M +XCMPLX-0K2 <i>COMPLEX1K8)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (?chx *REAL-1K4 ?cy +XCMPLX-0K2 (-REAL-1K1 ?shx *REAL-1K4 ?sy)*XCMPLX-0K3 (<i>COMPLEX1K8))"
    using sin_cos3_th_49 sorry
  also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ((?chx *REAL-1K4 ?cy +REAL-1K3 ?shx *REAL-1K4 ?sy)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 \<two>\<^sub>M"
     sorry
  finally have "((\<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 ((\<one>\<^sub>M +XCMPLX-0K2 <i>COMPLEX1K8)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 (-REAL-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 ((?chx *REAL-1K4 ?cy +REAL-1K3 ?shx *REAL-1K4 ?sy)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 \<two>\<^sub>M"
     sorry
  thus "((\<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 ((\<one>\<^sub>M +XCMPLX-0K2 <i>COMPLEX1K8)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x +XCMPLX-0K2 (-REAL-1K1 y)*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (sinhSIN-COS2K1).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x *REAL-1K4 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> y +REAL-1K3 (coshSIN-COS2K3).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x *REAL-1K4 (cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> y"
     sorry
qed "sorry"

mtheorem sin_cos3_th_56:
" for z be ComplexXCMPLX-0M1 holds (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 ((cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z) -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M"
proof-
  have " for z be ComplexXCMPLX-0M1 holds (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 ((cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z) -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    let ?e1 = "expSIN-COSK16 z"
    let ?e2 = "expSIN-COSK16 (-XCMPLX-0K4 z)"
    have "(sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 ((expSIN-COSK16 z -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
      using sin_cos3_def_3 sorry
    also have "... = ((?e1 -XCMPLX-0K6 ?e2)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((?e1 -XCMPLX-0K6 ?e2)/XCMPLX-0K7 \<two>\<^sub>M)"
      using sin_cos3_def_3 sorry
    also have "... = (((?e1 *XCMPLX-0K3 ?e1 +XCMPLX-0K2 ?e2 *XCMPLX-0K3 ?e2)-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (?e1 *XCMPLX-0K3 ?e2))/XCMPLX-0K7 \<two>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    also have "... = (((?e1 *XCMPLX-0K3 ?e1 +XCMPLX-0K2 ?e2 *XCMPLX-0K3 ?e2)-XCMPLX-0K6 \<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos3_lm_3 sorry
    also have "... = (((expSIN-COSK16 (z +XCMPLX-0K2 z) +XCMPLX-0K2 ?e2 *XCMPLX-0K3 ?e2)-XCMPLX-0K6 \<two>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos_th_23 sorry
    also have "... = (((expSIN-COSK16 (\<two>\<^sub>M *XCMPLX-0K3 z) +XCMPLX-0K2 expSIN-COSK16 ((-XCMPLX-0K4 z)+XCMPLX-0K2 (-XCMPLX-0K4 z)))-XCMPLX-0K6 \<two>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos_th_23 sorry
    also have "... = ((expSIN-COSK16 (\<two>\<^sub>M *XCMPLX-0K3 z) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 z))/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    finally have "(sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 ((expSIN-COSK16 (\<two>\<^sub>M *XCMPLX-0K3 z) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 z))/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    thus "(sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 ((cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z) -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos3_lm_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos3_th_57:
" for z be ComplexXCMPLX-0M1 holds (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 ((cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z) +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M"
proof-
  have " for z be ComplexXCMPLX-0M1 holds (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 ((cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z) +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    let ?e1 = "expSIN-COSK16 z"
    let ?e2 = "expSIN-COSK16 (-XCMPLX-0K4 z)"
    have "(cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 ((expSIN-COSK16 z +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 z))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
      using sin_cos3_def_4 sorry
    also have "... = ((?e1 +XCMPLX-0K2 ?e2)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((?e1 +XCMPLX-0K2 ?e2)/XCMPLX-0K7 \<two>\<^sub>M)"
      using sin_cos3_def_4 sorry
    also have "... = (((?e1 *XCMPLX-0K3 ?e1 +XCMPLX-0K2 ?e2 *XCMPLX-0K3 ?e2)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (?e1 *XCMPLX-0K3 ?e2))/XCMPLX-0K7 \<two>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    also have "... = (((?e1 *XCMPLX-0K3 ?e1 +XCMPLX-0K2 ?e2 *XCMPLX-0K3 ?e2)+XCMPLX-0K2 \<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos3_lm_3 sorry
    also have "... = (((expSIN-COSK16 (z +XCMPLX-0K2 z) +XCMPLX-0K2 ?e2 *XCMPLX-0K3 ?e2)+XCMPLX-0K2 \<two>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos_th_23 sorry
    also have "... = (((expSIN-COSK16 (\<two>\<^sub>M *XCMPLX-0K3 z) +XCMPLX-0K2 expSIN-COSK16 ((-XCMPLX-0K4 z)+XCMPLX-0K2 (-XCMPLX-0K4 z)))+XCMPLX-0K2 \<two>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos_th_23 sorry
    also have "... = ((expSIN-COSK16 (\<two>\<^sub>M *XCMPLX-0K3 z) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 z))/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    finally have "(cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 ((expSIN-COSK16 (\<two>\<^sub>M *XCMPLX-0K3 z) +XCMPLX-0K2 expSIN-COSK16 (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 z))/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    thus "(cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 ((cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z) +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos3_lm_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos3_th_58:
" for z be ComplexXCMPLX-0M1 holds (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z)*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z & (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z)*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 \<one>\<^sub>M"
proof-
  have " for z be ComplexXCMPLX-0M1 holds (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z)*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z & (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z)*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 \<one>\<^sub>M"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    let ?e1 = "expSIN-COSK16 z"
    let ?e2 = "expSIN-COSK16 (-XCMPLX-0K4 z)"
    have A1: "(\<two>\<^sub>M *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z)*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 \<one>\<^sub>M =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z) -XCMPLX-0K6 \<one>\<^sub>M"
       sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 (((cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z) +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M) -XCMPLX-0K6 \<one>\<^sub>M"
      using sin_cos3_th_57 sorry
    also have "... = ((cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z) +XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
       sorry
    finally have "(\<two>\<^sub>M *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z)*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 \<one>\<^sub>M =HIDDENR1 ((cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z) +XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
       sorry
    have "(\<two>\<^sub>M *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z)*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z)"
       sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z *XCMPLX-0K3 ((?e1 +XCMPLX-0K2 ?e2)/XCMPLX-0K7 \<two>\<^sub>M))"
      using sin_cos3_def_4 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 (((?e1 -XCMPLX-0K6 ?e2)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((?e1 +XCMPLX-0K2 ?e2)/XCMPLX-0K7 \<two>\<^sub>M))"
      using sin_cos3_def_3 sorry
    also have "... = (?e1 *XCMPLX-0K3 ?e1 -XCMPLX-0K6 ?e2 *XCMPLX-0K3 ?e2)/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    also have "... = (expSIN-COSK16 (z +XCMPLX-0K2 z) -XCMPLX-0K6 ?e2 *XCMPLX-0K3 ?e2)/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos_th_23 sorry
    also have "... = (expSIN-COSK16 (\<two>\<^sub>M *XCMPLX-0K3 z) -XCMPLX-0K6 expSIN-COSK16 ((-XCMPLX-0K4 z)+XCMPLX-0K2 (-XCMPLX-0K4 z)))/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos_th_23 sorry
    also have "... = (expSIN-COSK16 (\<two>\<^sub>M *XCMPLX-0K3 z) -XCMPLX-0K6 expSIN-COSK16 (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 z))/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    also have "... = (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z)"
      using sin_cos3_lm_1 sorry
    finally have "(\<two>\<^sub>M *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z)*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z)"
       sorry
    thus "(sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z)*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z & (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z)*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 \<one>\<^sub>M"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos3_th_59:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds ((sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 -XCMPLX-0K6 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 =COMPLEX1R1 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) & (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 -XCMPLX-0K6 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 =COMPLEX1R1 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2)) & (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 -XCMPLX-0K6 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 =COMPLEX1R1 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 -XCMPLX-0K6 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds ((sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 -XCMPLX-0K6 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 =COMPLEX1R1 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) & (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 -XCMPLX-0K6 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 =COMPLEX1R1 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2)) & (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 -XCMPLX-0K6 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 =COMPLEX1R1 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 -XCMPLX-0K6 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    let ?s1 = "(sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1"
    let ?s2 = "(sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
    let ?c1 = "(cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1"
    let ?c2 = "(cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
    have A1: "(sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =HIDDENR1 (?s1 *XCMPLX-0K3 ?c2 +XCMPLX-0K2 ?c1 *XCMPLX-0K3 ?s2)*XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2)"
      using sin_cos3_th_11 sorry
    also have "... = (?s1 *XCMPLX-0K3 ?c2 +XCMPLX-0K2 ?c1 *XCMPLX-0K3 ?s2)*XCMPLX-0K3 (?s1 *XCMPLX-0K3 ?c2 -XCMPLX-0K6 ?c1 *XCMPLX-0K3 ?s2)"
      using sin_cos3_th_12 sorry
    also have "... = (?s1 *XCMPLX-0K3 ?s1)*XCMPLX-0K3 (?c2 *XCMPLX-0K3 ?c2) -XCMPLX-0K6 (?s2 *XCMPLX-0K3 (?c1 *XCMPLX-0K3 ?c1))*XCMPLX-0K3 ?s2"
       sorry
    finally have "(sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =HIDDENR1 (?s1 *XCMPLX-0K3 ?s1)*XCMPLX-0K3 (?c2 *XCMPLX-0K3 ?c2) -XCMPLX-0K6 (?s2 *XCMPLX-0K3 (?c1 *XCMPLX-0K3 ?c1))*XCMPLX-0K3 ?s2"
       sorry
    then have A2: "(sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =HIDDENR1 ((-XCMPLX-0K4 (?c1 *XCMPLX-0K3 ?c1 -XCMPLX-0K6 ?s1 *XCMPLX-0K3 ?s1))*XCMPLX-0K3 (?c2 *XCMPLX-0K3 ?c2) +XCMPLX-0K2 (?c1 *XCMPLX-0K3 ?c1)*XCMPLX-0K3 (?c2 *XCMPLX-0K3 ?c2))-XCMPLX-0K6 (?s2 *XCMPLX-0K3 ?s2)*XCMPLX-0K3 (?c1 *XCMPLX-0K3 ?c1)"
       sorry
    also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (?c2 *XCMPLX-0K3 ?c2) +XCMPLX-0K2 (?c1 *XCMPLX-0K3 ?c1)*XCMPLX-0K3 (?c2 *XCMPLX-0K3 ?c2))-XCMPLX-0K6 (?s2 *XCMPLX-0K3 ?s2)*XCMPLX-0K3 (?c1 *XCMPLX-0K3 ?c1)"
      using sin_cos3_th_8 sorry
    also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (?c2 *XCMPLX-0K3 ?c2) +XCMPLX-0K2 (?c1 *XCMPLX-0K3 ?c1)*XCMPLX-0K3 (?c2 *XCMPLX-0K3 ?c2 -XCMPLX-0K6 ?s2 *XCMPLX-0K3 ?s2)"
       sorry
    also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (?c2 *XCMPLX-0K3 ?c2) +XCMPLX-0K2 (?c1 *XCMPLX-0K3 ?c1)*XCMPLX-0K3 \<one>\<^sub>M"
      using sin_cos3_th_8 sorry
    also have "... = (-XCMPLX-0K4 ?c2 *XCMPLX-0K3 ?c2)+XCMPLX-0K2 ?c1 *XCMPLX-0K3 ?c1"
       sorry
    finally have "(sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =HIDDENR1 (-XCMPLX-0K4 ?c2 *XCMPLX-0K3 ?c2)+XCMPLX-0K2 ?c1 *XCMPLX-0K3 ?c1"
       sorry
    have "(sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =HIDDENR1 ((?s1 *XCMPLX-0K3 ?s1)*XCMPLX-0K3 (?c2 *XCMPLX-0K3 ?c2 -XCMPLX-0K6 ?s2 *XCMPLX-0K3 ?s2) +XCMPLX-0K2 (?s1 *XCMPLX-0K3 ?s1)*XCMPLX-0K3 (?s2 *XCMPLX-0K3 ?s2))-XCMPLX-0K6 (?s2 *XCMPLX-0K3 ?s2)*XCMPLX-0K3 (?c1 *XCMPLX-0K3 ?c1)"
      using A1 sorry
    also have "... = ((?s1 *XCMPLX-0K3 ?s1)*XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 (?s1 *XCMPLX-0K3 ?s1)*XCMPLX-0K3 (?s2 *XCMPLX-0K3 ?s2))-XCMPLX-0K6 (?s2 *XCMPLX-0K3 ?s2)*XCMPLX-0K3 (?c1 *XCMPLX-0K3 ?c1)"
      using sin_cos3_th_8 sorry
    also have "... = (?s1 *XCMPLX-0K3 ?s1)*XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 (?s2 *XCMPLX-0K3 ?s2)*XCMPLX-0K3 (-XCMPLX-0K4 (?c1 *XCMPLX-0K3 ?c1 -XCMPLX-0K6 ?s1 *XCMPLX-0K3 ?s1))"
       sorry
    also have "... = (?s1 *XCMPLX-0K3 ?s1)*XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 (?s2 *XCMPLX-0K3 ?s2)*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M)"
      using sin_cos3_th_8 sorry
    also have "... = (?s1 *XCMPLX-0K3 ?s1)*XCMPLX-0K3 \<one>\<^sub>M -XCMPLX-0K6 ?s2 *XCMPLX-0K3 ?s2"
       sorry
    finally have "(sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =HIDDENR1 (?s1 *XCMPLX-0K3 ?s1)*XCMPLX-0K3 \<one>\<^sub>M -XCMPLX-0K6 ?s2 *XCMPLX-0K3 ?s2"
       sorry
    thus "((sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 -XCMPLX-0K6 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 =COMPLEX1R1 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) & (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 -XCMPLX-0K6 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 =COMPLEX1R1 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2)) & (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 -XCMPLX-0K6 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 =COMPLEX1R1 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 -XCMPLX-0K6 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos3_th_60:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds ((cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =COMPLEX1R1 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 +XCMPLX-0K2 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 & (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =COMPLEX1R1 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 +XCMPLX-0K2 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2) & (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 +XCMPLX-0K2 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 =COMPLEX1R1 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 +XCMPLX-0K2 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds ((cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =COMPLEX1R1 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 +XCMPLX-0K2 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 & (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =COMPLEX1R1 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 +XCMPLX-0K2 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2) & (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 +XCMPLX-0K2 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 =COMPLEX1R1 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 +XCMPLX-0K2 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    let ?s1 = "(sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1"
    let ?s2 = "(sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
    let ?c1 = "(cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1"
    let ?c2 = "(cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
    have A1: "(cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =HIDDENR1 (?c1 *XCMPLX-0K3 ?c2 +XCMPLX-0K2 ?s1 *XCMPLX-0K3 ?s2)*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2)"
      using sin_cos3_th_14 sorry
    also have "... = (?c1 *XCMPLX-0K3 ?c2 +XCMPLX-0K2 ?s1 *XCMPLX-0K3 ?s2)*XCMPLX-0K3 (?c1 *XCMPLX-0K3 ?c2 -XCMPLX-0K6 ?s1 *XCMPLX-0K3 ?s2)"
      using sin_cos3_th_13 sorry
    also have "... = ((?c1 *XCMPLX-0K3 ?c1)*XCMPLX-0K3 ?c2)*XCMPLX-0K3 ?c2 -XCMPLX-0K6 ((?s1 *XCMPLX-0K3 ?s1)*XCMPLX-0K3 ?s2)*XCMPLX-0K3 ?s2"
       sorry
    finally have "(cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =HIDDENR1 ((?c1 *XCMPLX-0K3 ?c1)*XCMPLX-0K3 ?c2)*XCMPLX-0K3 ?c2 -XCMPLX-0K6 ((?s1 *XCMPLX-0K3 ?s1)*XCMPLX-0K3 ?s2)*XCMPLX-0K3 ?s2"
       sorry
    then have A2: "(cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =HIDDENR1 (?c1 *XCMPLX-0K3 ?c1)*XCMPLX-0K3 (?c2 *XCMPLX-0K3 ?c2 -XCMPLX-0K6 ?s2 *XCMPLX-0K3 ?s2) +XCMPLX-0K2 (?c1 *XCMPLX-0K3 ?c1 -XCMPLX-0K6 ?s1 *XCMPLX-0K3 ?s1)*XCMPLX-0K3 (?s2 *XCMPLX-0K3 ?s2)"
       sorry
    also have "... = (?c1 *XCMPLX-0K3 ?c1)*XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 (?c1 *XCMPLX-0K3 ?c1 -XCMPLX-0K6 ?s1 *XCMPLX-0K3 ?s1)*XCMPLX-0K3 (?s2 *XCMPLX-0K3 ?s2)"
      using sin_cos3_th_8 sorry
    also have "... = ?c1 *XCMPLX-0K3 ?c1 +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 (?s2 *XCMPLX-0K3 ?s2)"
      using sin_cos3_th_8 sorry
    finally have "(cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =HIDDENR1 ?c1 *XCMPLX-0K3 ?c1 +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 (?s2 *XCMPLX-0K3 ?s2)"
       sorry
    have "(cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =HIDDENR1 (?c1 *XCMPLX-0K3 ?c1 -XCMPLX-0K6 ?s1 *XCMPLX-0K3 ?s1)*XCMPLX-0K3 (?c2 *XCMPLX-0K3 ?c2) +XCMPLX-0K2 (?s1 *XCMPLX-0K3 ?s1)*XCMPLX-0K3 (?c2 *XCMPLX-0K3 ?c2 -XCMPLX-0K6 ?s2 *XCMPLX-0K3 ?s2)"
      using A1 sorry
    also have "... = \<one>\<^sub>M *XCMPLX-0K3 (?c2 *XCMPLX-0K3 ?c2) +XCMPLX-0K2 (?s1 *XCMPLX-0K3 ?s1)*XCMPLX-0K3 (?c2 *XCMPLX-0K3 ?c2 -XCMPLX-0K6 ?s2 *XCMPLX-0K3 ?s2)"
      using sin_cos3_th_8 sorry
    also have "... = ?c2 *XCMPLX-0K3 ?c2 +XCMPLX-0K2 (?s1 *XCMPLX-0K3 ?s1)*XCMPLX-0K3 \<one>\<^sub>M"
      using sin_cos3_th_8 sorry
    finally have "(cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =HIDDENR1 ?c2 *XCMPLX-0K3 ?c2 +XCMPLX-0K2 (?s1 *XCMPLX-0K3 ?s1)*XCMPLX-0K3 \<one>\<^sub>M"
       sorry
    thus "((cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =COMPLEX1R1 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 +XCMPLX-0K2 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 & (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =COMPLEX1R1 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 +XCMPLX-0K2 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2) & (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 +XCMPLX-0K2 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 =COMPLEX1R1 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 +XCMPLX-0K2 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos3_th_61:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z1) +XCMPLX-0K2 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z2) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2))*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) & (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z1) -XCMPLX-0K6 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z2) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2))*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2)"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z1) +XCMPLX-0K2 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z2) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2))*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) & (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z1) -XCMPLX-0K6 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z2) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2))*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2)"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    let ?c1 = "(cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1"
    let ?c2 = "(cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
    let ?s1 = "(sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1"
    let ?s2 = "(sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2"
    have A1: "(\<two>\<^sub>M *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2))*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (?s1 *XCMPLX-0K3 ?c2 -XCMPLX-0K6 ?c1 *XCMPLX-0K3 ?s2))*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2)"
      using sin_cos3_th_12 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (?s1 *XCMPLX-0K3 ?c2 -XCMPLX-0K6 ?c1 *XCMPLX-0K3 ?s2))*XCMPLX-0K3 (?c1 *XCMPLX-0K3 ?c2 +XCMPLX-0K2 ?s1 *XCMPLX-0K3 ?s2)"
      using sin_cos3_th_14 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((?s1 *XCMPLX-0K3 ?c1)*XCMPLX-0K3 (?c2 *XCMPLX-0K3 ?c2 -XCMPLX-0K6 ?s2 *XCMPLX-0K3 ?s2) -XCMPLX-0K6 ((?s2 *XCMPLX-0K3 ?c2)*XCMPLX-0K3 (?c1 *XCMPLX-0K3 ?c1) -XCMPLX-0K6 (?s2 *XCMPLX-0K3 ?c2)*XCMPLX-0K3 (?s1 *XCMPLX-0K3 ?s1)))"
       sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((?s1 *XCMPLX-0K3 ?c1)*XCMPLX-0K3 \<one>\<^sub>M -XCMPLX-0K6 (?s2 *XCMPLX-0K3 ?c2)*XCMPLX-0K3 (?c1 *XCMPLX-0K3 ?c1 -XCMPLX-0K6 ?s1 *XCMPLX-0K3 ?s1))"
      using sin_cos3_th_8 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((?s1 *XCMPLX-0K3 ?c1)*XCMPLX-0K3 \<one>\<^sub>M -XCMPLX-0K6 (?s2 *XCMPLX-0K3 ?c2)*XCMPLX-0K3 \<one>\<^sub>M)"
      using sin_cos3_th_8 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ?s1)*XCMPLX-0K3 ?c1 -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (?s2 *XCMPLX-0K3 ?c2)"
       sorry
    also have "... = (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z1) -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 ?s2)*XCMPLX-0K3 ?c2"
      using sin_cos3_th_58 sorry
    finally have "(\<two>\<^sub>M *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2))*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) =HIDDENR1 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z1) -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 ?s2)*XCMPLX-0K3 ?c2"
       sorry
    have "(\<two>\<^sub>M *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2))*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (?s1 *XCMPLX-0K3 ?c2 +XCMPLX-0K2 ?c1 *XCMPLX-0K3 ?s2))*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2)"
      using sin_cos3_th_11 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (?s1 *XCMPLX-0K3 ?c2 +XCMPLX-0K2 ?c1 *XCMPLX-0K3 ?s2))*XCMPLX-0K3 (?c1 *XCMPLX-0K3 ?c2 -XCMPLX-0K6 ?s1 *XCMPLX-0K3 ?s2)"
      using sin_cos3_th_13 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((?c2 *XCMPLX-0K3 ?c2 -XCMPLX-0K6 ?s2 *XCMPLX-0K3 ?s2)*XCMPLX-0K3 (?c1 *XCMPLX-0K3 ?s1) +XCMPLX-0K2 ((?c1 *XCMPLX-0K3 ?c1)*XCMPLX-0K3 (?s2 *XCMPLX-0K3 ?c2) -XCMPLX-0K6 (?s1 *XCMPLX-0K3 ?s1)*XCMPLX-0K3 (?c2 *XCMPLX-0K3 ?s2)))"
       sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M *XCMPLX-0K3 (?c1 *XCMPLX-0K3 ?s1) +XCMPLX-0K2 (?c1 *XCMPLX-0K3 ?c1 -XCMPLX-0K6 ?s1 *XCMPLX-0K3 ?s1)*XCMPLX-0K3 (?c2 *XCMPLX-0K3 ?s2))"
      using sin_cos3_th_8 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M *XCMPLX-0K3 (?c1 *XCMPLX-0K3 ?s1) +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 (?c2 *XCMPLX-0K3 ?s2))"
      using sin_cos3_th_8 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ?s1)*XCMPLX-0K3 ?c1 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (?c2 *XCMPLX-0K3 ?s2)"
       sorry
    also have "... = (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z1) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ?s2)*XCMPLX-0K3 ?c2"
      using sin_cos3_th_58 sorry
    also have "... = (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z1) +XCMPLX-0K2 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z2)"
      using sin_cos3_th_58 sorry
    finally have "(\<two>\<^sub>M *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2))*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =HIDDENR1 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z1) +XCMPLX-0K2 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z2)"
       sorry
    thus "(sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z1) +XCMPLX-0K2 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z2) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2))*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) & (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z1) -XCMPLX-0K6 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z2) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2))*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2)"
      using A1 sin_cos3_th_58 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma sin_cos3_lm_5:
" for z1 be ComplexXCMPLX-0M1 holds (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 =COMPLEX1R1 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 -XCMPLX-0K6 \<one>\<^sub>M"
proof(rule ballI)
  fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
  have "(cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 -XCMPLX-0K6 \<one>\<^sub>M =HIDDENR1 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 -XCMPLX-0K6 ((cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 -XCMPLX-0K6 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1)"
    using sin_cos3_th_8 sorry
  also have "... = ((sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 +XCMPLX-0K2 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1)-XCMPLX-0K6 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1"
     sorry
  finally have "(cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 -XCMPLX-0K6 \<one>\<^sub>M =HIDDENR1 ((sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 +XCMPLX-0K2 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1)-XCMPLX-0K6 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1"
     sorry
  thus "(sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 =COMPLEX1R1 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 -XCMPLX-0K6 \<one>\<^sub>M"
     sorry
qed "sorry"

mtheorem sin_cos3_th_62:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z1) +XCMPLX-0K2 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z2) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2))*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) & (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z1) -XCMPLX-0K6 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z2) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2))*XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2)"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z1) +XCMPLX-0K2 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z2) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2))*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) & (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z1) -XCMPLX-0K6 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z2) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2))*XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2)"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    have A1: "(\<two>\<^sub>M *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2))*XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2))"
       sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 -XCMPLX-0K6 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2)"
      using sin_cos3_th_59 sorry
    also have "... = (((\<two>\<^sub>M *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1)*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 ((cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2)"
       sorry
    also have "... = ((cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z1) +XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 ((cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2)"
      using sin_cos3_th_58 sorry
    also have "... = (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z1) -XCMPLX-0K6 ((\<two>\<^sub>M *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2)*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 -XCMPLX-0K6 \<one>\<^sub>M)"
       sorry
    finally have "(\<two>\<^sub>M *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2))*XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =HIDDENR1 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z1) -XCMPLX-0K6 ((\<two>\<^sub>M *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2)*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 -XCMPLX-0K6 \<one>\<^sub>M)"
       sorry
    have "(\<two>\<^sub>M *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2))*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2) *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2))"
       sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 +XCMPLX-0K2 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2)"
      using sin_cos3_th_60 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 (((cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2)"
      using sin_cos3_lm_5 sorry
    also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1)*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1 -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2)*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 -XCMPLX-0K6 \<one>\<^sub>M)"
       sorry
    also have "... = (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z1) +XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2)*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 -XCMPLX-0K6 \<one>\<^sub>M)"
      using sin_cos3_th_58 sorry
    also have "... = (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z1) +XCMPLX-0K2 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z2)"
      using sin_cos3_th_58 sorry
    finally have "(\<two>\<^sub>M *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2))*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) =HIDDENR1 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z1) +XCMPLX-0K2 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z2)"
       sorry
    thus "(cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z1) +XCMPLX-0K2 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z2) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2))*XCMPLX-0K3 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2) & (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z1) -XCMPLX-0K6 (cosh-CSIN-COS3K4)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 z2) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 +XCMPLX-0K2 z2))*XCMPLX-0K3 (sinh-CSIN-COS3K3)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z1 -XCMPLX-0K6 z2)"
      using A1 sin_cos3_th_58 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
