theory cfunct_1
  imports rfunct_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x, y, X, Y for "setHIDDENM2"
reserve C for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve c for "ElementSUBSET-1M1-of C"
reserve f, f1, f2, f3, g, g1 for "PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
reserve r1, r2, p1 for "RealXREAL-0M1"
reserve r, q, cr1, cr2 for "ComplexXCMPLX-0M1"
mdef cfunct_1_def_1 (" _ '/CFUNCT-1K1\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164 ) where
  mlet "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)", "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
"func f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2 \<rightarrow> PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) means
  \<lambda>it. domRELSET-1K1\<^bsub>(C)\<^esub> it =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }) & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> it implies it /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)"
proof-
  (*existence*)
    show " ex it be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) st domRELSET-1K1\<^bsub>(C)\<^esub> it =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }) & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> it implies it /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)"
    proof-
      let ?F = "\<lambda>Lamb1. f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1 *XCMPLX-0K3 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1)\<inverse>XCMPLX-0K5"
      show " ex it be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) st domRELSET-1K1\<^bsub>(C)\<^esub> it =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }) & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> it implies it /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)"
      proof-
        have " ex tVar1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) st domRELSET-1K1\<^bsub>(C)\<^esub> tVar1 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }) & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> tVar1 implies tVar1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)"
        proof-
          let ?F = "\<lambda>Lamb1. InSUBSET-1K10(f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1 *XCMPLX-0K3 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1)\<inverse>XCMPLX-0K5,COMPLEXNUMBERSK3)"
          let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 })"
          obtain F where
            [ty]:"F be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)" and 
            A1: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> F iff ?P(c)"and A2: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> F implies F /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 ?F(c)"
            using partfun2_sch_2 sorry
          show " ex tVar1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) st domRELSET-1K1\<^bsub>(C)\<^esub> tVar1 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }) & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> tVar1 implies tVar1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)"
          proof(rule bexI[of _ "F"],rule conjMI,rule ballI,rule impI)
            show "domRELSET-1K1\<^bsub>(C)\<^esub> F =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 })"
              using A1 subset_1_th_3 sorry
            fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
            assume "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> F"
            then have "F /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 ?F(c)"
              using A2 sorry
            thus "F /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5"
               sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show " for it1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for it2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (domRELSET-1K1\<^bsub>(C)\<^esub> it1 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }) & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> it1 implies it1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)) & (domRELSET-1K1\<^bsub>(C)\<^esub> it2 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }) & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> it2 implies it2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)) implies it1 =HIDDENR1 it2"
    proof-
      let ?F = "\<lambda>Lamb1. f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1 *XCMPLX-0K3 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1)\<inverse>XCMPLX-0K5"
      show " for it1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for it2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (domRELSET-1K1\<^bsub>(C)\<^esub> it1 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }) & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> it1 implies it1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)) & (domRELSET-1K1\<^bsub>(C)\<^esub> it2 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }) & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> it2 implies it2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)) implies it1 =HIDDENR1 it2"
      proof-
        have " for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }) & (( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5) & (domRELSET-1K1\<^bsub>(C)\<^esub> g =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }) & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g implies g /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5))) implies f =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> g"
        proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
          let ?X = "domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 })"
          fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
          fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
          assume A3: "domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 ?X"
            and A4: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 ?F(c)"
            and A5: "domRELSET-1K1\<^bsub>(C)\<^esub> g =XBOOLE-0R4 ?X"
            and A6: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g implies g /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 ?F(c)"
          have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 g /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
          proof(rule ballI,rule impI)
            fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
            assume A7: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
            then have "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5"
              using A4 sorry
            also have "... = g /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
              using A7 A3 A5 A6 sorry
            finally show "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 g /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
               sorry
          qed "sorry"
          thus "f =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> g"
            using A3 A5 partfun2_th_1 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mdef cfunct_1_def_2 (" _ ^CFUNCT-1K2\<^bsub>'( _ ')\<^esub>" [164,0]164 ) where
  mlet "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
"func f ^CFUNCT-1K2\<^bsub>(C)\<^esub> \<rightarrow> PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) means
  \<lambda>it. domRELSET-1K1\<^bsub>(C)\<^esub> it =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> it implies it /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)"
proof-
  (*existence*)
    show " ex it be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) st domRELSET-1K1\<^bsub>(C)\<^esub> it =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> it implies it /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)"
    proof-
      let ?F = "\<lambda>Lamb1. (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1)\<inverse>XCMPLX-0K5"
      show " ex it be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) st domRELSET-1K1\<^bsub>(C)\<^esub> it =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> it implies it /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)"
      proof-
        have " ex tVar2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) st domRELSET-1K1\<^bsub>(C)\<^esub> tVar2 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> tVar2 implies tVar2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)"
        proof-
          let ?F = "\<lambda>Lamb1. InSUBSET-1K10((f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1)\<inverse>XCMPLX-0K5,COMPLEXNUMBERSK3)"
          let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
          obtain F where
            [ty]:"F be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)" and 
            A1: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> F iff ?P(c)"and A2: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> F implies F /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 ?F(c)"
            using partfun2_sch_2 sorry
          show " ex tVar2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) st domRELSET-1K1\<^bsub>(C)\<^esub> tVar2 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> tVar2 implies tVar2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)"
          proof(rule bexI[of _ "F"],rule conjMI,rule ballI,rule impI)
            show "domRELSET-1K1\<^bsub>(C)\<^esub> F =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }"
              using A1 subset_1_th_3 sorry
            fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
            assume "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> F"
            then have "F /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 ?F(c)"
              using A2 sorry
            thus "F /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5"
               sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show " for it1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for it2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (domRELSET-1K1\<^bsub>(C)\<^esub> it1 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> it1 implies it1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)) & (domRELSET-1K1\<^bsub>(C)\<^esub> it2 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> it2 implies it2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)) implies it1 =HIDDENR1 it2"
    proof-
      let ?F = "\<lambda>Lamb1. (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1)\<inverse>XCMPLX-0K5"
      show " for it1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for it2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (domRELSET-1K1\<^bsub>(C)\<^esub> it1 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> it1 implies it1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)) & (domRELSET-1K1\<^bsub>(C)\<^esub> it2 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> it2 implies it2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)) implies it1 =HIDDENR1 it2"
      proof-
        have " for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds domRELSET-1K1\<^bsub>(C)\<^esub> f1 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } & (( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 implies f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5) & (domRELSET-1K1\<^bsub>(C)\<^esub> g1 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g1 implies g1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5))) implies f1 =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> g1"
        proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
          let ?X = "domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }"
          fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
          fix g1 assume [ty]: "g1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
          assume A3: "domRELSET-1K1\<^bsub>(C)\<^esub> f1 =XBOOLE-0R4 ?X"
            and A4: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 implies f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 ?F(c)"
            and A5: "domRELSET-1K1\<^bsub>(C)\<^esub> g1 =XBOOLE-0R4 ?X"
            and A6: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g1 implies g1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 ?F(c)"
          have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 implies f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 g1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
          proof(rule ballI,rule impI)
            fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
            assume A7: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1"
            then have "f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5"
              using A4 sorry
            also have "... = g1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
              using A7 A3 A5 A6 sorry
            finally show "f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 g1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
               sorry
          qed "sorry"
          thus "f1 =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> g1"
            using A3 A5 partfun2_th_1 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem cfunct_1_th_1:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) implies (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 & ( for c be ElementSUBSET-1M1-of C holds  not (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) &  not (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    show A1: "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
      using valued_1_def_1 sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) implies (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1"
        using A1 xboole_0_def_4 sorry
      then have A3: "f1 .FUNCT-1K1 c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using partfun1_def_6 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using A1 A2 xboole_0_def_4 sorry
      then have A4: "f2 .FUNCT-1K1 c =COMPLEX1R1 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using partfun1_def_6 sorry
      have "(f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2).FUNCT-1K1 c"
        using A2 partfun1_def_6 sorry
      also have "... = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A2 A3 A4 valued_1_def_1 sorry
      finally show "(f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    thus " for c be ElementSUBSET-1M1-of C holds  not (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) &  not (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_2:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) implies (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 & ( for c be ElementSUBSET-1M1-of C holds  not (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) &  not (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have A1: "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2)"
      using valued_1_def_1 sorry
    thus "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
      using valued_1_th_8 sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) implies (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
      then have A3: "domRELSET-1K1\<^bsub>(C)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f2 & c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2)"
        using A1 valued_1_th_8 xboole_0_def_4 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1"
        using A1 A2 xboole_0_def_4 sorry
      then have A4: "f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 .FUNCT-1K1 c"
        using partfun1_def_6 sorry
      have "(f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2).FUNCT-1K1 c"
        using A2 partfun1_def_6 sorry
      also have "... = f1 .FUNCT-1K1 c -XCMPLX-0K6 f2 .FUNCT-1K1 c"
        using A2 valued_1_th_13 sorry
      also have "... = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A3 A4 partfun1_def_6 sorry
      finally show "(f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    thus " for c be ElementSUBSET-1M1-of C holds  not (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) &  not (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_3:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) implies (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 & ( for c be ElementSUBSET-1M1-of C holds  not (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) &  not (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    show A1: "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
      using valued_1_def_4 sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) implies (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1"
        using A1 xboole_0_def_4 sorry
      then have A3: "f1 .FUNCT-1K1 c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using partfun1_def_6 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using A1 A2 xboole_0_def_4 sorry
      then have A4: "f2 .FUNCT-1K1 c =COMPLEX1R1 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using partfun1_def_6 sorry
      have "(f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2).FUNCT-1K1 c"
        using A2 partfun1_def_6 sorry
      also have "... = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A2 A3 A4 valued_1_def_4 sorry
      finally show "(f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    thus " for c be ElementSUBSET-1M1-of C holds  not (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) &  not (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_4:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) implies (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 r *XCMPLX-0K3 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & ( for c be ElementSUBSET-1M1-of C holds  not (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) &  not (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 r *XCMPLX-0K3 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix r assume [ty]: "r be ComplexXCMPLX-0M1"
    show A1: "domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f"
      using valued_1_def_5 sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) implies (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 r *XCMPLX-0K3 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)"
      then have "(r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f).FUNCT-1K1 c"
        using partfun1_def_6 sorry
      also have "... = r *XCMPLX-0K3 f .FUNCT-1K1 c"
        using valued_1_th_6 sorry
      also have "... = r *XCMPLX-0K3 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A1 A2 partfun1_def_6 sorry
      finally show "(r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 r *XCMPLX-0K3 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    thus " for c be ElementSUBSET-1M1-of C holds  not (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) &  not (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 r *XCMPLX-0K3 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_5:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds domRELSET-1K1\<^bsub>(C)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) implies (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 -XCMPLX-0K4 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds domRELSET-1K1\<^bsub>(C)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & ( for c be ElementSUBSET-1M1-of C holds  not (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) &  not (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 -XCMPLX-0K4 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c))"
  proof(rule ballI,rule ballI,rule conjMI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    show A1: "domRELSET-1K1\<^bsub>(C)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f"
      using valued_1_th_8 sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) implies (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 -XCMPLX-0K4 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)"
      then have "(-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f).FUNCT-1K1 c"
        using partfun1_def_6 sorry
      also have "... = -XCMPLX-0K4 f .FUNCT-1K1 c"
        using valued_1_th_8 sorry
      also have "... = -XCMPLX-0K4 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A1 A2 partfun1_def_6 sorry
      finally show "(-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 -XCMPLX-0K4 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    thus " for c be ElementSUBSET-1M1-of C holds  not (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) &  not (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 -XCMPLX-0K4 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma cfunct_1_lm_1:
" for x be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds x inTARSKIR2 f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y iff x inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x inTARSKIR2 Y"
  using partfun2_th_26 sorry

mtheorem cfunct_1_th_6:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds domRELSET-1K1\<^bsub>(C)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>) c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> g & domRELSET-1K1\<^bsub>(C)\<^esub> g /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g \\SUBSET-1K7\<^bsub>(C)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> g \\SUBSET-1K7\<^bsub>(C)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds domRELSET-1K1\<^bsub>(C)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>) c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> g & domRELSET-1K1\<^bsub>(C)\<^esub> g /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g \\SUBSET-1K7\<^bsub>(C)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> g \\SUBSET-1K7\<^bsub>(C)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }"
  proof(rule ballI,rule ballI,rule conjMI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> g \\SUBSET-1K7\<^bsub>(C)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
      using cfunct_1_def_2 sorry
    thus "domRELSET-1K1\<^bsub>(C)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>) c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> g"
      using xboole_1_th_36 sorry
    show "domRELSET-1K1\<^bsub>(C)\<^esub> g /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g \\SUBSET-1K7\<^bsub>(C)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> g \\SUBSET-1K7\<^bsub>(C)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }"
      using xboole_1_th_28 xboole_1_th_36 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_7:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) \\SUBSET-1K7\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 (domRELSET-1K1\<^bsub>(C)\<^esub> f1 \\SUBSET-1K7\<^bsub>(C)\<^esub> f1 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 })"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) \\SUBSET-1K7\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 (domRELSET-1K1\<^bsub>(C)\<^esub> f1 \\SUBSET-1K7\<^bsub>(C)\<^esub> f1 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 })"
  proof(rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) \\SUBSET-1K7\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 (domRELSET-1K1\<^bsub>(C)\<^esub> f1 \\SUBSET-1K7\<^bsub>(C)\<^esub> f1 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }) & (domRELSET-1K1\<^bsub>(C)\<^esub> f1 \\SUBSET-1K7\<^bsub>(C)\<^esub> f1 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }) c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) \\SUBSET-1K7\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }"
    proof(rule conjMI)
      show "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) \\SUBSET-1K7\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 (domRELSET-1K1\<^bsub>(C)\<^esub> f1 \\SUBSET-1K7\<^bsub>(C)\<^esub> f1 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 })"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) \\SUBSET-1K7\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } implies x inHIDDENR3 (domRELSET-1K1\<^bsub>(C)\<^esub> f1 \\SUBSET-1K7\<^bsub>(C)\<^esub> f1 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 })"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A1: "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) \\SUBSET-1K7\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }"
          then have A2: "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
            using xboole_0_def_5 sorry
          obtain x1 where 
            [ty]:"x1 be ElementSUBSET-1M1-of C" and x1Def:"x1 = x"
            using A1 sorry
          have " not x inHIDDENR3 (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
            using A1 xboole_0_def_5 sorry
          then have " not (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 inTARSKIR2 {TARSKIK1 0cCOMPLEX1K6 }"
            using A2 partfun2_th_26 sorry
          then have "(f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 <>HIDDENR2 0cCOMPLEX1K6"
            using tarski_def_1 sorry
          then have A3: "f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 <>HIDDENR2 0cCOMPLEX1K6"
            using A2 cfunct_1_th_3 sorry
          then have "f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 <>HIDDENR2 0cCOMPLEX1K6"
             sorry
          then have " not f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 inTARSKIR2 {TARSKIK1 0cCOMPLEX1K6 }"
            using tarski_def_1 sorry
          then have A4: " not x1 inTARSKIR2 f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
            using partfun2_th_26 sorry
          have A5: "x1 inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
            using A2 cfunct_1_th_3 sorry
          then have "x1 inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f2"
            using xboole_0_def_4 sorry
          then have A6: "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
            using A4 xboole_0_def_5 sorry
          have "f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 <>HIDDENR2 0cCOMPLEX1K6"
            using A3 sorry
          then have " not f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 inTARSKIR2 {TARSKIK1 0cCOMPLEX1K6 }"
            using tarski_def_1 sorry
          then have A7: " not x1 inTARSKIR2 f1 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
            using partfun2_th_26 sorry
          have "x1 inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1"
            using A5 xboole_0_def_4 sorry
          then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f1 \\SUBSET-1K7\<^bsub>(C)\<^esub> f1 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
            using A7 xboole_0_def_5 sorry
          thus "x inHIDDENR3 (domRELSET-1K1\<^bsub>(C)\<^esub> f1 \\SUBSET-1K7\<^bsub>(C)\<^esub> f1 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 })"
            using A6 xboole_0_def_4 sorry
        qed "sorry"
        thus "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) \\SUBSET-1K7\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 (domRELSET-1K1\<^bsub>(C)\<^esub> f1 \\SUBSET-1K7\<^bsub>(C)\<^esub> f1 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 })"
          using tarski_def_3 sorry
      qed
      show "(domRELSET-1K1\<^bsub>(C)\<^esub> f1 \\SUBSET-1K7\<^bsub>(C)\<^esub> f1 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }) c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) \\SUBSET-1K7\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 (domRELSET-1K1\<^bsub>(C)\<^esub> f1 \\SUBSET-1K7\<^bsub>(C)\<^esub> f1 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) \\SUBSET-1K7\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A8: "x inHIDDENR3 (domRELSET-1K1\<^bsub>(C)\<^esub> f1 \\SUBSET-1K7\<^bsub>(C)\<^esub> f1 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 })"
          then obtain x1 where 
            [ty]:"x1 be ElementSUBSET-1M1-of C" and x1Def:"x1 = x"
             sorry
          have A9: "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
            using A8 xboole_0_def_4 sorry
          then have A10: "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f2"
            using xboole_0_def_5 sorry
          have " not x inHIDDENR3 f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
            using A9 xboole_0_def_5 sorry
          then have " not f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 inTARSKIR2 {TARSKIK1 0cCOMPLEX1K6 }"
            using A10 partfun2_th_26 sorry
          then have A11: "f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 <>HIDDENR2 0cCOMPLEX1K6"
            using tarski_def_1 sorry
          have A12: "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f1 \\SUBSET-1K7\<^bsub>(C)\<^esub> f1 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
            using A8 xboole_0_def_4 sorry
          then have A13: "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f1"
            using xboole_0_def_5 sorry
          then have "x1 inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
            using A10 xboole_0_def_4 sorry
          then have A14: "x1 inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
            using cfunct_1_th_3 sorry
          have " not x inHIDDENR3 f1 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
            using A12 xboole_0_def_5 sorry
          then have " not f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 inTARSKIR2 {TARSKIK1 0cCOMPLEX1K6 }"
            using A13 partfun2_th_26 sorry
          then have "f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 <>HIDDENR2 0cCOMPLEX1K6"
            using tarski_def_1 sorry
          then have "f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 <>HIDDENR2 0cCOMPLEX1K6"
            using A11 xcmplx_1_th_6 sorry
          then have "(f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 <>HIDDENR2 0cCOMPLEX1K6"
            using A14 cfunct_1_th_3 sorry
          then have " not (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 inTARSKIR2 {TARSKIK1 0cCOMPLEX1K6 }"
            using tarski_def_1 sorry
          then have " not x inHIDDENR3 (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
            using partfun2_th_26 sorry
          thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) \\SUBSET-1K7\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }"
            using A14 xboole_0_def_5 sorry
        qed "sorry"
        thus "(domRELSET-1K1\<^bsub>(C)\<^esub> f1 \\SUBSET-1K7\<^bsub>(C)\<^esub> f1 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }) c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) \\SUBSET-1K7\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }"
          using tarski_def_3 sorry
      qed
    qed
    thus "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) \\SUBSET-1K7\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 (domRELSET-1K1\<^bsub>(C)\<^esub> f1 \\SUBSET-1K7\<^bsub>(C)\<^esub> f1 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 })"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_8:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>) implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c <>HIDDENR2 0NUMBERSK6"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>) & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 0NUMBERSK6 implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    assume A1: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
      and A2: "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 0NUMBERSK6"
    have A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
      using A1 cfunct_1_def_2 sorry
    then have A4: " not c inTARSKIR2 f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
      using xboole_0_def_5 sorry
    have " False "
    proof-
      show " False "
      proof-
        have cases: " not c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f or  not f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c inTARSKIR2 {TARSKIK1 0cCOMPLEX1K6 }"
          using A4 partfun2_th_26 sorry
        have case1: " not c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies  False "
        proof(rule impI)
          assume " not c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
          thus " False "
            using A3 xboole_0_def_5 sorry
        qed
        have case2: " not f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c inTARSKIR2 {TARSKIK1 0cCOMPLEX1K6 } implies  False "
        proof(rule impI)
          assume " not f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c inTARSKIR2 {TARSKIK1 0cCOMPLEX1K6 }"
          thus " False "
            using A2 tarski_def_1 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " False "
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_9:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } <>HIDDENR2 {}XBOOLE-0K1 implies  False "
  proof(rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    let ?x = "the ElementSUBSET-1M1-of (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
    assume A1: "(f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } <>HIDDENR2 {}XBOOLE-0K1"
    then have A2: "?x inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
      using cfunct_1_lm_1 sorry
    have A3: "(f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ?x inTARSKIR2 {TARSKIK1 0cCOMPLEX1K6 }"
      using A1 cfunct_1_lm_1 sorry
    obtain x where 
      [ty]:"x be ElementSUBSET-1M1-of C" and xDef:"x = ?x"
      using A2 sorry
    have "x inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
      using A2 cfunct_1_def_2 sorry
    then have "x inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f &  not x inTARSKIR2 f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
      using xboole_0_def_5 sorry
    then have A4: " not f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x inTARSKIR2 {TARSKIK1 0cCOMPLEX1K6 }"
      using partfun2_th_26 sorry
    have "(f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 0cCOMPLEX1K6"
      using A3 tarski_def_1 sorry
    then have "(f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x)\<inverse>XCMPLX-0K5 =COMPLEX1R1 0cCOMPLEX1K6"
      using A2 cfunct_1_def_2 sorry
    thus " False "
      using A4 tarski_def_1 xcmplx_1_th_202 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_10:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)\<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } & (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)\<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } & (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }"
  proof(rule ballI,rule ballI,rule conjMI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have A1: "domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f"
      using valued_1_def_11 sorry
    have " for c be ElementSUBSET-1M1-of C holds (c inTARSKIR2 ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)\<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } implies c inTARSKIR2 f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }) & (c inTARSKIR2 f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 } implies c inTARSKIR2 ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)\<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 })"
    proof(rule ballI,rule conjMI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      show "c inTARSKIR2 ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)\<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } implies c inTARSKIR2 f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
      proof(rule impI)
        assume A2: "c inTARSKIR2 ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)\<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
        then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)"
          using funct_1_def_7 sorry
        then have A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
          using valued_1_def_11 sorry
        have "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|).FUNCT-1K1 c inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
          using A2 funct_1_def_7 sorry
        then have "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|).FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6"
          using tarski_def_1 sorry
        then have A4: " |.COMPLEX1K10 f .FUNCT-1K1 c.| =COMPLEX1R1 0NUMBERSK6"
          using valued_1_th_18 sorry
        have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)"
          using A2 funct_1_def_7 sorry
        then have "f .FUNCT-1K1 c =COMPLEX1R1 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
          using A1 partfun1_def_6 sorry
        then have "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 0cCOMPLEX1K6"
          using A4 complex1_th_45 sorry
        then have "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c inTARSKIR2 {TARSKIK1 0cCOMPLEX1K6 }"
          using tarski_def_1 sorry
        thus "c inTARSKIR2 f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
          using A3 partfun2_th_26 sorry
      qed
      assume A5: "c inTARSKIR2 f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
      then have "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c inTARSKIR2 {TARSKIK1 0cCOMPLEX1K6 }"
        using partfun2_th_26 sorry
      then have A6: " |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| =COMPLEX1R1 0NUMBERSK6"
        using complex1_th_44 tarski_def_1 sorry
      have A7: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using A5 partfun2_th_26 sorry
      then have "f .FUNCT-1K1 c =COMPLEX1R1 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using partfun1_def_6 sorry
      then have "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|).FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6"
        using A6 valued_1_th_18 sorry
      then have A8: "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|).FUNCT-1K1 c inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
        using tarski_def_1 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)"
        using A7 valued_1_def_11 sorry
      thus "c inTARSKIR2 ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)\<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
        using A8 funct_1_def_7 sorry
    qed "sorry"
    thus "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)\<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }"
      using subset_1_th_3 sorry
    have " for c be ElementSUBSET-1M1-of C holds (c inTARSKIR2 (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 } implies c inTARSKIR2 f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }) & (c inTARSKIR2 f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 } implies c inTARSKIR2 (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 })"
    proof(rule ballI,rule conjMI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      show "c inTARSKIR2 (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 } implies c inTARSKIR2 f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
      proof(rule impI)
        assume A9: "c inTARSKIR2 (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
        then have A10: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)"
          using partfun2_th_26 sorry
        have "(-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c inTARSKIR2 {TARSKIK1 0cCOMPLEX1K6 }"
          using A9 partfun2_th_26 sorry
        then have "(-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 0cCOMPLEX1K6"
          using tarski_def_1 sorry
        then have "-XCMPLX-0K4 (-XCMPLX-0K4 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c) =COMPLEX1R1 -XCMPLX-0K4 0cCOMPLEX1K6"
          using A10 cfunct_1_th_5 sorry
        then have A11: "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c inTARSKIR2 {TARSKIK1 0cCOMPLEX1K6 }"
          using tarski_def_1 sorry
        have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
          using A10 cfunct_1_th_5 sorry
        thus "c inTARSKIR2 f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
          using A11 partfun2_th_26 sorry
      qed
      assume A12: "c inTARSKIR2 f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
      then have "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c inTARSKIR2 {TARSKIK1 0cCOMPLEX1K6 }"
        using partfun2_th_26 sorry
      then have A13: "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 0cCOMPLEX1K6"
        using tarski_def_1 sorry
      have A14: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using A12 partfun2_th_26 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)"
        using cfunct_1_th_5 sorry
      then have "(-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 -XCMPLX-0K4 0cCOMPLEX1K6"
        using A13 cfunct_1_th_5 sorry
      then have A15: "(-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c inTARSKIR2 {TARSKIK1 0cCOMPLEX1K6 }"
        using tarski_def_1 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)"
        using A14 cfunct_1_th_5 sorry
      thus "c inTARSKIR2 (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
        using A15 partfun2_th_26 sorry
    qed "sorry"
    thus "(-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }"
      using subset_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_11:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds domRELSET-1K1\<^bsub>(C)\<^esub> ((f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)^CFUNCT-1K2\<^bsub>(C)\<^esub>) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>))"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds domRELSET-1K1\<^bsub>(C)\<^esub> ((f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)^CFUNCT-1K2\<^bsub>(C)\<^esub>) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>))"
  proof(rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have A1: "domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
      using cfunct_1_def_2 sorry
    have "domRELSET-1K1\<^bsub>(C)\<^esub> ((f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)^CFUNCT-1K2\<^bsub>(C)\<^esub>) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>) \\SUBSET-1K7\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
      using cfunct_1_def_2 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>) \\SUBSET-1K7\<^bsub>(C)\<^esub> {}XBOOLE-0K1"
      using cfunct_1_th_9 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
      using A1 xboole_1_th_28 xboole_1_th_36 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>))"
      using relat_1_th_61 sorry
    finally show "domRELSET-1K1\<^bsub>(C)\<^esub> ((f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)^CFUNCT-1K2\<^bsub>(C)\<^esub>) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_12:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds r <>HIDDENR2 0NUMBERSK6 implies (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds r <>HIDDENR2 0NUMBERSK6 implies (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix r assume [ty]: "r be ComplexXCMPLX-0M1"
    assume A1: "r <>HIDDENR2 0NUMBERSK6"
    have " for c be ElementSUBSET-1M1-of C holds (c inTARSKIR2 (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 } implies c inTARSKIR2 f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }) & (c inTARSKIR2 f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 } implies c inTARSKIR2 (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 })"
    proof(rule ballI,rule conjMI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      show "c inTARSKIR2 (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 } implies c inTARSKIR2 f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
      proof(rule impI)
        assume A2: "c inTARSKIR2 (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
        then have A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)"
          using partfun2_th_26 sorry
        have "(r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c inTARSKIR2 {TARSKIK1 0cCOMPLEX1K6 }"
          using A2 partfun2_th_26 sorry
        then have "(r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 0cCOMPLEX1K6"
          using tarski_def_1 sorry
        then have "r *XCMPLX-0K3 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 0cCOMPLEX1K6"
          using A3 cfunct_1_th_4 sorry
        then have "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 0cCOMPLEX1K6"
          using A1 xcmplx_1_th_6 sorry
        then have A4: "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c inTARSKIR2 {TARSKIK1 0cCOMPLEX1K6 }"
          using tarski_def_1 sorry
        have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
          using A3 cfunct_1_th_4 sorry
        thus "c inTARSKIR2 f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
          using A4 partfun2_th_26 sorry
      qed
      assume A5: "c inTARSKIR2 f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
      then have "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c inTARSKIR2 {TARSKIK1 0cCOMPLEX1K6 }"
        using partfun2_th_26 sorry
      then have "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 0cCOMPLEX1K6"
        using tarski_def_1 sorry
      then have A6: "r *XCMPLX-0K3 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 0cCOMPLEX1K6"
         sorry
      have A7: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using A5 partfun2_th_26 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)"
        using cfunct_1_th_4 sorry
      then have "(r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 0cCOMPLEX1K6"
        using A6 cfunct_1_th_4 sorry
      then have A8: "(r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c inTARSKIR2 {TARSKIK1 0cCOMPLEX1K6 }"
        using tarski_def_1 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)"
        using A7 cfunct_1_th_4 sorry
      thus "c inTARSKIR2 (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
        using A8 partfun2_th_26 sorry
    qed "sorry"
    thus "(r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }"
      using subset_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem cfunct_1_th_13:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f3 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)+VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f3 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)+VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f3 assume [ty]: "f3 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have A1: "domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)+VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3"
      using valued_1_def_1 sorry
    also have "... = (domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3"
      using valued_1_def_1 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3)"
      using xboole_1_th_16 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
      using valued_1_def_1 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3))"
      using valued_1_def_1 sorry
    finally have "domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)+VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3))"
       sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)+VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3) implies ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)+VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)+VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3"
        using valued_1_def_1 sorry
      then have A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
        using xboole_0_def_4 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
        using A1 A2 valued_1_def_1 sorry
      then have A4: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f2 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
        using xboole_0_def_4 sorry
      have "((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)+VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 f3 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A2 cfunct_1_th_1 sorry
      also have "... = (f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)+XCMPLX-0K2 f3 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A3 cfunct_1_th_1 sorry
      also have "... = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 f3 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)"
         sorry
      also have "... = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 (f2 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A4 cfunct_1_th_1 sorry
      also have "... = (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A1 A2 cfunct_1_th_1 sorry
      finally show "((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)+VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    thus "(f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)+VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
      using A1 partfun2_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_14:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f3 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f3 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f3 assume [ty]: "f3 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have A1: "domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3"
      using cfunct_1_th_3 sorry
    also have "... = (domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3"
      using cfunct_1_th_3 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3)"
      using xboole_1_th_16 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
      using cfunct_1_th_3 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3))"
      using cfunct_1_th_3 sorry
    finally have "domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3))"
       sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3) implies ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3"
        using cfunct_1_th_3 sorry
      then have A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
        using xboole_0_def_4 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
        using A1 A2 cfunct_1_th_3 sorry
      then have A4: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
        using xboole_0_def_4 sorry
      have "((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f3 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A2 cfunct_1_th_3 sorry
      also have "... = (f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)*XCMPLX-0K3 f3 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A3 cfunct_1_th_3 sorry
      also have "... = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f3 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)"
         sorry
      also have "... = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A4 cfunct_1_th_3 sorry
      also have "... = (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A1 A2 cfunct_1_th_3 sorry
      finally show "((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    thus "(f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
      using A1 partfun2_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_15:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f3 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f3 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f3 assume [ty]: "f3 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have A1: "domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3"
      using cfunct_1_th_3 sorry
    also have "... = (domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2)/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f3 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3)"
      using valued_1_def_1 sorry
    also have "... = ((domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3"
      using xboole_1_th_16 sorry
    also have "... = ((domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3"
      using xboole_1_th_16 sorry
    also have "... = (domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3)/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3)"
      using xboole_1_th_16 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3) /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3)"
      using cfunct_1_th_3 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
      using cfunct_1_th_3 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
      using valued_1_def_1 sorry
    finally have "domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
       sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3) implies ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
      then have A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
        using A1 valued_1_def_1 sorry
      then have A4: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
        using xboole_0_def_4 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3"
        using A2 cfunct_1_th_3 sorry
      then have A5: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
        using xboole_0_def_4 sorry
      have A6: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
        using A3 xboole_0_def_4 sorry
      have "((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f3 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A2 cfunct_1_th_3 sorry
      also have "... = (f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)*XCMPLX-0K3 f3 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A5 cfunct_1_th_1 sorry
      also have "... = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f3 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f3 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
      also have "... = (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f3 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A4 cfunct_1_th_3 sorry
      also have "... = (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 (f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A6 cfunct_1_th_3 sorry
      also have "... = (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A1 A2 cfunct_1_th_1 sorry
      finally show "((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    thus "(f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3"
      using A1 partfun2_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_16:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f3 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f3 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f3 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2"
  using cfunct_1_th_15 sorry

mtheorem cfunct_1_th_17:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix r assume [ty]: "r be ComplexXCMPLX-0M1"
    have A1: "domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
      using cfunct_1_th_4 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
      using cfunct_1_th_3 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
      using cfunct_1_th_4 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> ((r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
      using cfunct_1_th_3 sorry
    finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> ((r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
       sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)) implies (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 ((r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2))"
      then have A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
        using cfunct_1_th_4 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using A1 A2 cfunct_1_th_3 sorry
      then have A4: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1)"
        using xboole_0_def_4 sorry
      have "(r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 r *XCMPLX-0K3 (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A2 cfunct_1_th_4 sorry
      also have "... = r *XCMPLX-0K3 (f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)"
        using A3 cfunct_1_th_3 sorry
      also have "... = (r *XCMPLX-0K3 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)*XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
      also have "... = (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A4 cfunct_1_th_4 sorry
      also have "... = ((r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A1 A2 cfunct_1_th_3 sorry
      finally show "(r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 ((r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    thus "r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2"
      using A1 partfun2_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_18:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix r assume [ty]: "r be ComplexXCMPLX-0M1"
    have A1: "domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
      using cfunct_1_th_4 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
      using cfunct_1_th_3 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2)"
      using cfunct_1_th_4 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2))"
      using cfunct_1_th_3 sorry
    finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2))"
       sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)) implies (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2))"
      then have A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
        using cfunct_1_th_4 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2)"
        using A1 A2 cfunct_1_th_3 sorry
      then have A4: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2)"
        using xboole_0_def_4 sorry
      have "(r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 r *XCMPLX-0K3 (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A2 cfunct_1_th_4 sorry
      also have "... = r *XCMPLX-0K3 (f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)"
        using A3 cfunct_1_th_3 sorry
      also have "... = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (r *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)"
         sorry
      also have "... = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A4 cfunct_1_th_4 sorry
      also have "... = (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A1 A2 cfunct_1_th_3 sorry
      finally show "(r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    thus "r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2)"
      using A1 partfun2_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_19:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f3 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f3 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f3 assume [ty]: "f3 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have A1: "domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3"
      using cfunct_1_th_3 sorry
    also have "... = (domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2)/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f3 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3)"
      using cfunct_1_th_2 sorry
    also have "... = ((domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3"
      using xboole_1_th_16 sorry
    also have "... = ((domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3"
      using xboole_1_th_16 sorry
    also have "... = (domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3)/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3)"
      using xboole_1_th_16 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3) /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3)"
      using cfunct_1_th_3 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
      using cfunct_1_th_3 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
      using cfunct_1_th_2 sorry
    finally have "domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
       sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3) implies ((f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3"
        using cfunct_1_th_3 sorry
      then have A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
        using xboole_0_def_4 sorry
      have A4: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
        using A1 A2 cfunct_1_th_2 sorry
      then have A5: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
        using xboole_0_def_4 sorry
      have A6: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
        using A4 xboole_0_def_4 sorry
      have "((f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f3 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A2 cfunct_1_th_3 sorry
      also have "... = (f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)*XCMPLX-0K3 f3 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A3 cfunct_1_th_2 sorry
      also have "... = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f3 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f3 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
      also have "... = (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f3 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A5 cfunct_1_th_3 sorry
      also have "... = (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c -XCMPLX-0K6 (f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A6 cfunct_1_th_3 sorry
      also have "... = (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A1 A2 cfunct_1_th_2 sorry
      finally show "((f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    thus "(f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3"
      using A1 partfun2_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_20:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f3 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f3 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f3 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
  using cfunct_1_th_19 sorry

mtheorem cfunct_1_th_21:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix r assume [ty]: "r be ComplexXCMPLX-0M1"
    have A1: "domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
      using cfunct_1_th_4 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
      using valued_1_def_1 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2)"
      using cfunct_1_th_4 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2)"
      using cfunct_1_th_4 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2)"
      using valued_1_def_1 sorry
    finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2)"
       sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)) implies (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2))"
      then have A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
        using cfunct_1_th_4 sorry
      have A4: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2)"
        using A1 A2 valued_1_def_1 sorry
      then have A5: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1)"
        using xboole_0_def_4 sorry
      have A6: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2)"
        using A4 xboole_0_def_4 sorry
      have "(r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 r *XCMPLX-0K3 (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A2 cfunct_1_th_4 sorry
      also have "... = r *XCMPLX-0K3 (f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)"
        using A3 cfunct_1_th_1 sorry
      also have "... = r *XCMPLX-0K3 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 r *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
      also have "... = (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 r *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A5 cfunct_1_th_4 sorry
      also have "... = (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A6 cfunct_1_th_4 sorry
      also have "... = (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A1 A2 cfunct_1_th_1 sorry
      finally show "(r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    thus "r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2"
      using A1 partfun2_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_22:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds  for q be ComplexXCMPLX-0M1 holds (r *XCMPLX-0K3 q)(#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (q (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds  for q be ComplexXCMPLX-0M1 holds (r *XCMPLX-0K3 q)(#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (q (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix r assume [ty]: "r be ComplexXCMPLX-0M1"
    fix q assume [ty]: "q be ComplexXCMPLX-0M1"
    have A1: "domRELSET-1K1\<^bsub>(C)\<^esub> ((r *XCMPLX-0K3 q)(#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> f"
      using cfunct_1_th_4 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (q (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)"
      using cfunct_1_th_4 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (q (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f))"
      using cfunct_1_th_4 sorry
    finally have "domRELSET-1K1\<^bsub>(C)\<^esub> ((r *XCMPLX-0K3 q)(#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (q (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f))"
       sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((r *XCMPLX-0K3 q)(#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) implies ((r *XCMPLX-0K3 q)(#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (q (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((r *XCMPLX-0K3 q)(#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)"
      then have A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (q (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)"
        using A1 cfunct_1_th_4 sorry
      have "((r *XCMPLX-0K3 q)(#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (r *XCMPLX-0K3 q)*XCMPLX-0K3 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A2 cfunct_1_th_4 sorry
      also have "... = r *XCMPLX-0K3 (q *XCMPLX-0K3 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)"
         sorry
      also have "... = r *XCMPLX-0K3 (q (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A3 cfunct_1_th_4 sorry
      also have "... = (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (q (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A1 A2 cfunct_1_th_4 sorry
      finally show "((r *XCMPLX-0K3 q)(#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (q (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    thus "(r *XCMPLX-0K3 q)(#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (q (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)"
      using A1 partfun2_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_23:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix r assume [ty]: "r be ComplexXCMPLX-0M1"
    have A1: "domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
      using cfunct_1_th_4 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
      using cfunct_1_th_2 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2)"
      using cfunct_1_th_4 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2)"
      using cfunct_1_th_4 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2)"
      using cfunct_1_th_2 sorry
    finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2)"
       sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)) implies (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2))"
      then have A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
        using cfunct_1_th_4 sorry
      have A4: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2)"
        using A1 A2 cfunct_1_th_2 sorry
      then have A5: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1)"
        using xboole_0_def_4 sorry
      have A6: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2)"
        using A4 xboole_0_def_4 sorry
      have "(r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 r *XCMPLX-0K3 (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A2 cfunct_1_th_4 sorry
      also have "... = r *XCMPLX-0K3 (f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)"
        using A3 cfunct_1_th_2 sorry
      also have "... = r *XCMPLX-0K3 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c -XCMPLX-0K6 r *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
      also have "... = (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c -XCMPLX-0K6 r *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A5 cfunct_1_th_4 sorry
      also have "... = (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c -XCMPLX-0K6 (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A6 cfunct_1_th_4 sorry
      also have "... = (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A1 A2 cfunct_1_th_2 sorry
      finally show "(r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    thus "r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2"
      using A1 partfun2_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_24:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1)"
  proof(rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have A1: "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f1"
      using cfunct_1_th_2 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1)"
      using cfunct_1_th_2 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> ((-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1))"
      using cfunct_1_th_4 sorry
    finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> ((-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1))"
       sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) implies (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 ((-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      have A2: "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f1"
        using cfunct_1_th_2 sorry
      also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1)"
        using cfunct_1_th_2 sorry
      finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1)"
         sorry
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
      have "(f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A3 cfunct_1_th_2 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c -XCMPLX-0K6 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)"
         sorry
      also have "... = (-XCMPLX-0K4 1rCOMPLEX1K7)*XCMPLX-0K3 (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A3 A2 cfunct_1_th_2 complex1_def_4 sorry
      also have "... = ((-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A1 A3 cfunct_1_th_4 sorry
      finally show "(f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 ((-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    thus "f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1)"
      using A1 partfun2_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_25:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f3 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)-VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f3 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)-VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f3 assume [ty]: "f3 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have A1: "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
      using cfunct_1_th_2 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3)"
      using valued_1_def_1 sorry
    also have "... = (domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3"
      using xboole_1_th_16 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3"
      using cfunct_1_th_2 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)-VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
      using cfunct_1_th_2 sorry
    finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)-VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
       sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)) implies (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 ((f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)-VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3))"
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
        using cfunct_1_th_2 sorry
      then have A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f2 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
        using xboole_0_def_4 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3"
        using A1 A2 cfunct_1_th_2 sorry
      then have A4: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
        using xboole_0_def_4 sorry
      have "(f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c -XCMPLX-0K6 (f2 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A2 cfunct_1_th_2 sorry
      also have "... = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c -XCMPLX-0K6 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 f3 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)"
        using A3 cfunct_1_th_1 sorry
      also have "... = (f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)-XCMPLX-0K6 f3 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
      also have "... = (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c -XCMPLX-0K6 f3 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A4 cfunct_1_th_2 sorry
      also have "... = ((f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)-VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A1 A2 cfunct_1_th_2 sorry
      finally show "(f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 ((f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)-VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    thus "f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)-VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3"
      using A1 partfun2_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_26:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds 1rCOMPLEX1K7 (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds 1rCOMPLEX1K7 (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f"
  proof(rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have A1: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (1rCOMPLEX1K7 (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) implies (1rCOMPLEX1K7 (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (1rCOMPLEX1K7 (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)"
      then have "(1rCOMPLEX1K7 (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 1rCOMPLEX1K7 *XCMPLX-0K3 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using cfunct_1_th_4 sorry
      also have "... = f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using complex1_def_4 sorry
      finally show "(1rCOMPLEX1K7 (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (1rCOMPLEX1K7 (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f"
      using cfunct_1_th_4 sorry
    thus "1rCOMPLEX1K7 (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f"
      using A1 partfun2_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_27:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f3 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)+VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f3 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)+VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f3 assume [ty]: "f3 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have A1: "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
      using cfunct_1_th_2 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3)"
      using cfunct_1_th_2 sorry
    also have "... = (domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3"
      using xboole_1_th_16 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3"
      using cfunct_1_th_2 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)+VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
      using valued_1_def_1 sorry
    finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)+VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
       sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)) implies (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 ((f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)+VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3))"
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3"
        using A1 valued_1_def_1 sorry
      then have A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
        using xboole_0_def_4 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
        using A2 cfunct_1_th_2 sorry
      then have A4: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
        using xboole_0_def_4 sorry
      have "(f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c -XCMPLX-0K6 (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A2 cfunct_1_th_2 sorry
      also have "... = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c -XCMPLX-0K6 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c -XCMPLX-0K6 f3 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)"
        using A4 cfunct_1_th_2 sorry
      also have "... = (f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)+XCMPLX-0K2 f3 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
      also have "... = (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 f3 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A3 cfunct_1_th_2 sorry
      also have "... = ((f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)+VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A1 A2 cfunct_1_th_1 sorry
      finally show "(f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 ((f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)+VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    thus "f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)+VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3"
      using A1 partfun2_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_28:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f3 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)-VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f3 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)-VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f3 assume [ty]: "f3 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have A1: "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
      using valued_1_def_1 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3)"
      using cfunct_1_th_2 sorry
    also have "... = (domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3"
      using xboole_1_th_16 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3"
      using valued_1_def_1 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)-VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
      using cfunct_1_th_2 sorry
    finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)-VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
       sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)) implies (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)-VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3))"
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
        using valued_1_def_1 sorry
      then have A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
        using xboole_0_def_4 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f3"
        using A1 A2 cfunct_1_th_2 sorry
      then have A4: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
        using xboole_0_def_4 sorry
      have "(f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A2 cfunct_1_th_1 sorry
      also have "... = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c -XCMPLX-0K6 f3 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)"
        using A3 cfunct_1_th_2 sorry
      also have "... = (f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)-XCMPLX-0K6 f3 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
      also have "... = (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c -XCMPLX-0K6 f3 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A4 cfunct_1_th_1 sorry
      also have "... = ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)-VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A1 A2 cfunct_1_th_2 sorry
      finally show "(f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)-VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    thus "f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)-VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3"
      using A1 partfun2_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_29:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 .| =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1.|)(#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2.|)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 .| =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1.|)(#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2.|)"
  proof(rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have A1: "domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 .|) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
      using valued_1_def_11 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
      using cfunct_1_th_3 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2.|)"
      using valued_1_def_11 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1.|) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2.|)"
      using valued_1_def_11 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1.|)(#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2.|))"
      using valued_1_def_4 sorry
    finally have "domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 .|) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1.|)(#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2.|))"
       sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 .|) implies ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 .|).FUNCT-1K1 c =HIDDENR1 (( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1.|)(#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2.|)).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      have A2: "domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2.|) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using valued_1_def_11 sorry
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      have A3: "domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1.|) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1"
        using valued_1_def_11 sorry
      assume A4: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 .|)"
      then have A5: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
        using valued_1_def_11 sorry
      have A6: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1.|) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2.|)"
        using A1 A4 valued_1_def_4 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1.|)"
        using xboole_0_def_4 sorry
      then have A7: "f1 .FUNCT-1K1 c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A3 partfun1_def_6 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2.|)"
        using A6 xboole_0_def_4 sorry
      then have A8: "f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f2 .FUNCT-1K1 c"
        using A2 partfun1_def_6 sorry
      have "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 .|).FUNCT-1K1 c =HIDDENR1  |.COMPLEX1K10 (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2).FUNCT-1K1 c.|"
        using valued_1_th_18 sorry
      also have "... =  |.COMPLEX1K10 (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.|"
        using A5 partfun1_def_6 sorry
      also have "... =  |.COMPLEX1K10 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c .|"
        using A5 cfunct_1_th_3 sorry
      also have "... = ( |.COMPLEX1K10 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.|)*XCMPLX-0K3 ( |.COMPLEX1K10 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.|)"
        using complex1_th_65 sorry
      also have "... = ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1.|).FUNCT-1K1 c *XCMPLX-0K3 ( |.COMPLEX1K10 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.|)"
        using A7 valued_1_th_18 sorry
      also have "... = ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1.|).FUNCT-1K1 c *XCMPLX-0K3 ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2.|).FUNCT-1K1 c"
        using A8 valued_1_th_18 sorry
      also have "... = (( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1.|)(#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2.|)).FUNCT-1K1 c"
        using valued_1_th_5 sorry
      finally show "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 .|).FUNCT-1K1 c =HIDDENR1 (( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1.|)(#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2.|)).FUNCT-1K1 c"
         sorry
    qed "sorry"
    thus " |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 .| =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1.|)(#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2.|)"
      using A1 partfun1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_30:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f .| =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> ( |.COMPLEX1K10 r.|)(#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f .| =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> ( |.COMPLEX1K10 r.|)(#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)"
  proof(rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix r assume [ty]: "r be ComplexXCMPLX-0M1"
    have A1: "domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)"
      using valued_1_def_11 sorry
    have A2: "domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f .|) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)"
      using valued_1_def_11 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f"
      using cfunct_1_th_4 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (( |.COMPLEX1K10 r.|)(#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|))"
      using A1 valued_1_def_5 sorry
    finally have "domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f .|) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (( |.COMPLEX1K10 r.|)(#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|))"
       sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f .|) implies ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f .|).FUNCT-1K1 c =HIDDENR1 (( |.COMPLEX1K10 r.|)(#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f .|)"
      then have A4: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)"
        using valued_1_def_11 sorry
      have A5: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)"
        using A2 A3 valued_1_def_5 sorry
      have "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f .|).FUNCT-1K1 c =HIDDENR1  |.COMPLEX1K10 (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f).FUNCT-1K1 c.|"
        using valued_1_th_18 sorry
      also have "... =  |.COMPLEX1K10 (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.|"
        using A4 partfun1_def_6 sorry
      also have "... =  |.COMPLEX1K10 r *XCMPLX-0K3 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c .|"
        using A4 cfunct_1_th_4 sorry
      also have "... = ( |.COMPLEX1K10 r.|)*XCMPLX-0K3 ( |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.|)"
        using complex1_th_65 sorry
      also have "... = ( |.COMPLEX1K10 r.|)*XCMPLX-0K3 ( |.COMPLEX1K10 f .FUNCT-1K1 c.|)"
        using A1 A5 partfun1_def_6 sorry
      also have "... = ( |.COMPLEX1K10 r.|)*XCMPLX-0K3 ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|).FUNCT-1K1 c"
        using valued_1_th_18 sorry
      also have "... = (( |.COMPLEX1K10 r.|)(#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)).FUNCT-1K1 c"
        using A2 A3 valued_1_def_5 sorry
      finally show "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f .|).FUNCT-1K1 c =HIDDENR1 (( |.COMPLEX1K10 r.|)(#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)).FUNCT-1K1 c"
         sorry
    qed "sorry"
    thus " |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f .| =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> ( |.COMPLEX1K10 r.|)(#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)"
      using A2 partfun1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_31:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds -VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f"
  using complex1_def_4 sorry

(*\$CT*)
mtheorem cfunct_1_th_33:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2"
   sorry

mtheorem cfunct_1_th_34:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)^CFUNCT-1K2\<^bsub>(C)\<^esub> =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)^CFUNCT-1K2\<^bsub>(C)\<^esub> =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
  proof(rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have A1: "domRELSET-1K1\<^bsub>(C)\<^esub> ((f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)^CFUNCT-1K2\<^bsub>(C)\<^esub>) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>))"
      using cfunct_1_th_11 sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)^CFUNCT-1K2\<^bsub>(C)\<^esub>) implies ((f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)^CFUNCT-1K2\<^bsub>(C)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
        using A1 relat_1_th_61 sorry
      then have A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
        using xboole_0_def_4 sorry
      have "((f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)^CFUNCT-1K2\<^bsub>(C)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 ((f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5"
        using A2 cfunct_1_def_2 sorry
      also have "... = ((f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)\<inverse>XCMPLX-0K5"
        using A3 cfunct_1_def_2 sorry
      also have "... = (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A1 A2 partfun2_th_15 sorry
      finally show "((f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)^CFUNCT-1K2\<^bsub>(C)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    thus "(f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)^CFUNCT-1K2\<^bsub>(C)\<^esub> =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
      using A1 partfun2_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_35:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)^CFUNCT-1K2\<^bsub>(C)\<^esub> =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)^CFUNCT-1K2\<^bsub>(C)\<^esub> =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
  proof(rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have A1: "domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)^CFUNCT-1K2\<^bsub>(C)\<^esub>) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) \\SUBSET-1K7\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
      using cfunct_1_def_2 sorry
    also have "... = (domRELSET-1K1\<^bsub>(C)\<^esub> f1 \\SUBSET-1K7\<^bsub>(C)\<^esub> f1 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 })/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 })"
      using cfunct_1_th_7 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>) /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 })"
      using cfunct_1_def_2 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
      using cfunct_1_def_2 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>))"
      using cfunct_1_th_3 sorry
    finally have "domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)^CFUNCT-1K2\<^bsub>(C)\<^esub>) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>))"
       sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)^CFUNCT-1K2\<^bsub>(C)\<^esub>) implies ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)^CFUNCT-1K2\<^bsub>(C)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 ((f1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) \\SUBSET-1K7\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
        using cfunct_1_def_2 sorry
      then have A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
        using xboole_0_def_5 sorry
      have A4: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
        using A1 A2 cfunct_1_th_3 sorry
      then have A5: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
        using xboole_0_def_4 sorry
      have A6: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
        using A4 xboole_0_def_4 sorry
      have "((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)^CFUNCT-1K2\<^bsub>(C)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5"
        using A2 cfunct_1_def_2 sorry
      also have "... = (f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5"
        using A3 cfunct_1_th_3 sorry
      also have "... = (f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5"
        using xcmplx_1_th_204 sorry
      also have "... = (f1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5"
        using A5 cfunct_1_def_2 sorry
      also have "... = (f1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A6 cfunct_1_def_2 sorry
      also have "... = ((f1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A1 A2 cfunct_1_th_3 sorry
      finally show "((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)^CFUNCT-1K2\<^bsub>(C)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 ((f1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    thus "(f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)^CFUNCT-1K2\<^bsub>(C)\<^esub> =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
      using A1 partfun2_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_36:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds r <>HIDDENR2 0NUMBERSK6 implies (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)^CFUNCT-1K2\<^bsub>(C)\<^esub> =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r \<inverse>XCMPLX-0K5 (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds r <>HIDDENR2 0NUMBERSK6 implies (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)^CFUNCT-1K2\<^bsub>(C)\<^esub> =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r \<inverse>XCMPLX-0K5 (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix r assume [ty]: "r be ComplexXCMPLX-0M1"
    assume A1: "r <>HIDDENR2 0NUMBERSK6"
    have A2: "domRELSET-1K1\<^bsub>(C)\<^esub> ((r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)^CFUNCT-1K2\<^bsub>(C)\<^esub>) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) \\SUBSET-1K7\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
      using cfunct_1_def_2 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
      using A1 cfunct_1_th_12 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
      using cfunct_1_th_4 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
      using cfunct_1_def_2 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (r \<inverse>XCMPLX-0K5 (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>))"
      using cfunct_1_th_4 sorry
    finally have "domRELSET-1K1\<^bsub>(C)\<^esub> ((r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)^CFUNCT-1K2\<^bsub>(C)\<^esub>) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (r \<inverse>XCMPLX-0K5 (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>))"
       sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)^CFUNCT-1K2\<^bsub>(C)\<^esub>) implies ((r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)^CFUNCT-1K2\<^bsub>(C)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (r \<inverse>XCMPLX-0K5 (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
      then have A4: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
        using A2 cfunct_1_th_4 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) \\SUBSET-1K7\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
        using A3 cfunct_1_def_2 sorry
      then have A5: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)"
        using xboole_0_def_5 sorry
      have "((r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)^CFUNCT-1K2\<^bsub>(C)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 ((r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5"
        using A3 cfunct_1_def_2 sorry
      also have "... = (r *XCMPLX-0K3 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5"
        using A5 cfunct_1_th_4 sorry
      also have "... = r \<inverse>XCMPLX-0K5 *XCMPLX-0K3 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5"
        using xcmplx_1_th_204 sorry
      also have "... = r \<inverse>XCMPLX-0K5 *XCMPLX-0K3 (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A4 cfunct_1_def_2 sorry
      also have "... = (r \<inverse>XCMPLX-0K5 (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A2 A3 cfunct_1_th_4 sorry
      finally show "((r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)^CFUNCT-1K2\<^bsub>(C)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (r \<inverse>XCMPLX-0K5 (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    thus "(r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)^CFUNCT-1K2\<^bsub>(C)\<^esub> =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r \<inverse>XCMPLX-0K5 (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
      using A2 partfun2_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma cfunct_1_lm_2:
"(-XCMPLX-0K4 1rCOMPLEX1K7)\<inverse>XCMPLX-0K5 =COMPLEX1R1 -XCMPLX-0K4 1rCOMPLEX1K7"
  using complex1_def_4 sorry

mtheorem cfunct_1_th_37:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)^CFUNCT-1K2\<^bsub>(C)\<^esub> =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
  using cfunct_1_lm_2 cfunct_1_th_36 complex1_def_4 sorry

mtheorem cfunct_1_th_38:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub> =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub>  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f ^CFUNCT-1K2\<^bsub>(C)\<^esub> .|"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub> =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub>  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f ^CFUNCT-1K2\<^bsub>(C)\<^esub> .|"
  proof(rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have A1: "domRELSET-1K1\<^bsub>(C)\<^esub> (( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub>) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) \\SUBSET-1K7\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)\<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
      using rfunct_1_def_2 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)\<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
      using valued_1_def_11 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
      using cfunct_1_th_10 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
      using cfunct_1_def_2 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f ^CFUNCT-1K2\<^bsub>(C)\<^esub> .|)"
      using valued_1_def_11 sorry
    finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub>) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f ^CFUNCT-1K2\<^bsub>(C)\<^esub> .|)"
       sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub>) implies (( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub>).FUNCT-1K1 c =HIDDENR1 ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f ^CFUNCT-1K2\<^bsub>(C)\<^esub> .|).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      have A2: "domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)"
        using valued_1_def_11 sorry
      assume A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub>)"
      then have A4: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
        using A1 valued_1_def_11 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) \\SUBSET-1K7\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)\<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
        using A3 rfunct_1_def_2 sorry
      then have A5: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)"
        using xboole_0_def_5 sorry
      have "(( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub>).FUNCT-1K1 c =HIDDENR1 (( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|).FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
        using A3 rfunct_1_def_2 sorry
      also have "... = ( |.COMPLEX1K10 f .FUNCT-1K1 c.|)\<inverse>XCMPLX-0K5"
        using valued_1_th_18 sorry
      also have "... = ( |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.|)\<inverse>XCMPLX-0K5"
        using A5 A2 partfun1_def_6 sorry
      also have "... = ( |.COMPLEX1K10 1rCOMPLEX1K7.|)/XCMPLX-0K7 ( |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.|)"
        using complex1_th_48 xcmplx_1_th_215 sorry
      also have "... =  |.COMPLEX1K10 1rCOMPLEX1K7 /XCMPLX-0K7 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c .|"
        using complex1_th_67 sorry
      also have "... =  |.COMPLEX1K10 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5.|"
        using complex1_def_4 xcmplx_1_th_215 sorry
      also have "... =  |.COMPLEX1K10 (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.|"
        using A4 cfunct_1_def_2 sorry
      also have "... =  |.COMPLEX1K10 (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>).FUNCT-1K1 c.|"
        using A4 partfun1_def_6 sorry
      also have "... = ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f ^CFUNCT-1K2\<^bsub>(C)\<^esub> .|).FUNCT-1K1 c"
        using valued_1_th_18 sorry
      finally show "(( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub>).FUNCT-1K1 c =HIDDENR1 ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f ^CFUNCT-1K2\<^bsub>(C)\<^esub> .|).FUNCT-1K1 c"
         sorry
    qed "sorry"
    thus "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub> =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub>  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f ^CFUNCT-1K2\<^bsub>(C)\<^esub> .|"
      using A1 partfun1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_39:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f /CFUNCT-1K1\<^bsub>(C)\<^esub> g =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f /CFUNCT-1K1\<^bsub>(C)\<^esub> g =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
  proof(rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have A1: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f /CFUNCT-1K1\<^bsub>(C)\<^esub> g) implies (f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)"
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g \\SUBSET-1K7\<^bsub>(C)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 })"
        using cfunct_1_def_1 sorry
      then have A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
        using cfunct_1_def_2 sorry
      then have A4: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
        using xboole_0_def_4 sorry
      have A5: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>))"
        using A3 cfunct_1_th_3 sorry
      have "(f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (g /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5"
        using A2 cfunct_1_def_1 sorry
      also have "... = f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A4 cfunct_1_def_2 sorry
      also have "... = (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A5 cfunct_1_th_3 sorry
      finally show "(f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (f /CFUNCT-1K1\<^bsub>(C)\<^esub> g) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g \\SUBSET-1K7\<^bsub>(C)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 })"
      using cfunct_1_def_1 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
      using cfunct_1_def_2 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>))"
      using cfunct_1_th_3 sorry
    finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (f /CFUNCT-1K1\<^bsub>(C)\<^esub> g) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>))"
       sorry
    thus "f /CFUNCT-1K1\<^bsub>(C)\<^esub> g =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
      using A1 partfun2_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_40:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (g /CFUNCT-1K1\<^bsub>(C)\<^esub> f) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> g)/CFUNCT-1K1\<^bsub>(C)\<^esub> f"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (g /CFUNCT-1K1\<^bsub>(C)\<^esub> f) =HIDDENR1 (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> g)/CFUNCT-1K1\<^bsub>(C)\<^esub> f"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix r assume [ty]: "r be ComplexXCMPLX-0M1"
    have "r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (g /CFUNCT-1K1\<^bsub>(C)\<^esub> f) =HIDDENR1 r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>))"
      using cfunct_1_th_39 sorry
    also have "... = (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> g)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
      using cfunct_1_th_17 sorry
    also have "... = (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> g)/CFUNCT-1K1\<^bsub>(C)\<^esub> f"
      using cfunct_1_th_39 sorry
    finally show "r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (g /CFUNCT-1K1\<^bsub>(C)\<^esub> f) =HIDDENR1 (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> g)/CFUNCT-1K1\<^bsub>(C)\<^esub> f"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_41:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
  proof(rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have A1: "domRELSET-1K1\<^bsub>(C)\<^esub> ((f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f /CFUNCT-1K1\<^bsub>(C)\<^esub> g) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> g"
      using cfunct_1_th_3 sorry
    also have "... = (domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g \\SUBSET-1K7\<^bsub>(C)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }))/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> g"
      using cfunct_1_def_1 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> ((domRELSET-1K1\<^bsub>(C)\<^esub> g \\SUBSET-1K7\<^bsub>(C)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 })/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> g)"
      using xboole_1_th_16 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> g)"
      using cfunct_1_def_2 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
      using cfunct_1_th_6 xboole_1_th_28 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>))"
      using relat_1_th_61 sorry
    finally have "domRELSET-1K1\<^bsub>(C)\<^esub> ((f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>))"
       sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g) implies ((f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g)"
      then have A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
        using A1 relat_1_th_61 sorry
      then have A4: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>))"
        using cfunct_1_th_3 sorry
      have A5: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
        using A3 xboole_0_def_4 sorry
      then have A6: "g /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c <>HIDDENR2 0cCOMPLEX1K6"
        using cfunct_1_th_8 sorry
      have "((f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 g /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A2 cfunct_1_th_3 sorry
      also have "... = (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 g /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using cfunct_1_th_39 sorry
      also have "... = (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)*XCMPLX-0K3 g /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A4 cfunct_1_th_3 sorry
      also have "... = (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (g /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 g /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A5 cfunct_1_def_2 sorry
      also have "... = f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 ((g /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 g /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)"
         sorry
      also have "... = f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 1rCOMPLEX1K7"
        using A6 complex1_def_4 xcmplx_0_def_7 sorry
      also have "... = (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A1 A2 complex1_def_4 partfun2_th_15 sorry
      finally show "((f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    thus "(f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
      using A1 partfun2_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_42:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g1) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1)/CFUNCT-1K1\<^bsub>(C)\<^esub> (g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g1) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1)/CFUNCT-1K1\<^bsub>(C)\<^esub> (g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix g1 assume [ty]: "g1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have A1: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g1)) implies ((f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g1))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 ((f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1)/CFUNCT-1K1\<^bsub>(C)\<^esub> (g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g1))"
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f /CFUNCT-1K1\<^bsub>(C)\<^esub> g) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g1)"
        using cfunct_1_th_3 sorry
      then have A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>)) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g1)"
        using cfunct_1_th_39 sorry
      then have A4: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>))"
        using xboole_0_def_4 sorry
      then have A5: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
        using cfunct_1_th_3 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>)) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (g1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>))"
        using A3 cfunct_1_th_39 sorry
      then have A6: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (g1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>))"
        using xboole_0_def_4 sorry
      then have A7: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (g1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
        using cfunct_1_th_3 sorry
      then have A8: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1"
        using xboole_0_def_4 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using A5 xboole_0_def_4 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f1"
        using A8 xboole_0_def_4 sorry
      then have A9: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1)"
        using cfunct_1_th_3 sorry
      have A10: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (g1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
        using A7 xboole_0_def_4 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
        using A5 xboole_0_def_4 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (g1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
        using A10 xboole_0_def_4 sorry
      then have A11: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((g ^CFUNCT-1K2\<^bsub>(C)\<^esub>)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (g1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>))"
        using cfunct_1_th_3 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1)^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
        using cfunct_1_th_35 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> ((g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1)^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
        using A9 xboole_0_def_4 sorry
      then have A12: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1)^CFUNCT-1K2\<^bsub>(C)\<^esub>))"
        using cfunct_1_th_3 sorry
      have "((f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g1))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A2 cfunct_1_th_3 sorry
      also have "... = (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using cfunct_1_th_39 sorry
      also have "... = (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (g1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using cfunct_1_th_39 sorry
      also have "... = (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)*XCMPLX-0K3 (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (g1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A4 cfunct_1_th_3 sorry
      also have "... = (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)*XCMPLX-0K3 (f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (g1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)"
        using A6 cfunct_1_th_3 sorry
      also have "... = f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 ((g ^CFUNCT-1K2\<^bsub>(C)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (g1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c))"
         sorry
      also have "... = f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 ((g ^CFUNCT-1K2\<^bsub>(C)\<^esub>)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (g1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)"
        using A11 cfunct_1_th_3 sorry
      also have "... = (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)*XCMPLX-0K3 ((g ^CFUNCT-1K2\<^bsub>(C)\<^esub>)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (g1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
      also have "... = (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)*XCMPLX-0K3 ((g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1)^CFUNCT-1K2\<^bsub>(C)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using cfunct_1_th_35 sorry
      also have "... = (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 ((g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1)^CFUNCT-1K2\<^bsub>(C)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A9 cfunct_1_th_3 sorry
      also have "... = ((f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1)^CFUNCT-1K2\<^bsub>(C)\<^esub>))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A12 cfunct_1_th_3 sorry
      also have "... = ((f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1)/CFUNCT-1K1\<^bsub>(C)\<^esub> (g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using cfunct_1_th_39 sorry
      finally show "((f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g1))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 ((f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1)/CFUNCT-1K1\<^bsub>(C)\<^esub> (g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    have "domRELSET-1K1\<^bsub>(C)\<^esub> ((f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g1)) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f /CFUNCT-1K1\<^bsub>(C)\<^esub> g) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g1)"
      using cfunct_1_th_3 sorry
    also have "... = (domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g \\SUBSET-1K7\<^bsub>(C)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }))/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g1)"
      using cfunct_1_def_1 sorry
    also have "... = (domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g \\SUBSET-1K7\<^bsub>(C)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }))/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g1 \\SUBSET-1K7\<^bsub>(C)\<^esub> g1 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }))"
      using cfunct_1_def_1 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> ((domRELSET-1K1\<^bsub>(C)\<^esub> g \\SUBSET-1K7\<^bsub>(C)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 })/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g1 \\SUBSET-1K7\<^bsub>(C)\<^esub> g1 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 })))"
      using xboole_1_th_16 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> ((domRELSET-1K1\<^bsub>(C)\<^esub> g \\SUBSET-1K7\<^bsub>(C)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 })/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g1 \\SUBSET-1K7\<^bsub>(C)\<^esub> g1 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 })))"
      using xboole_1_th_16 sorry
    also have "... = (domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f1)/\\SUBSET-1K9\<^bsub>(C)\<^esub> ((domRELSET-1K1\<^bsub>(C)\<^esub> g \\SUBSET-1K7\<^bsub>(C)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 })/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g1 \\SUBSET-1K7\<^bsub>(C)\<^esub> g1 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }))"
      using xboole_1_th_16 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(C)\<^esub> ((domRELSET-1K1\<^bsub>(C)\<^esub> g \\SUBSET-1K7\<^bsub>(C)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 })/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g1 \\SUBSET-1K7\<^bsub>(C)\<^esub> g1 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }))"
      using cfunct_1_th_3 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> (g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1) \\SUBSET-1K7\<^bsub>(C)\<^esub> (g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 })"
      using cfunct_1_th_7 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> ((f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1)/CFUNCT-1K1\<^bsub>(C)\<^esub> (g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1))"
      using cfunct_1_def_1 sorry
    finally have "domRELSET-1K1\<^bsub>(C)\<^esub> ((f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g1)) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> ((f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1)/CFUNCT-1K1\<^bsub>(C)\<^esub> (g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1))"
       sorry
    thus "(f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g1) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1)/CFUNCT-1K1\<^bsub>(C)\<^esub> (g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1)"
      using A1 partfun2_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_43:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2)^CFUNCT-1K2\<^bsub>(C)\<^esub> =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>) /CFUNCT-1K1\<^bsub>(C)\<^esub> f1"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2)^CFUNCT-1K2\<^bsub>(C)\<^esub> =HIDDENR1 f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>) /CFUNCT-1K1\<^bsub>(C)\<^esub> f1"
  proof(rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have "(f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2)^CFUNCT-1K2\<^bsub>(C)\<^esub> =HIDDENR1 (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>))^CFUNCT-1K2\<^bsub>(C)\<^esub>"
      using cfunct_1_th_39 sorry
    also have "... = (f1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>)^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
      using cfunct_1_th_35 sorry
    also have "... = f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>) (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
      using cfunct_1_th_34 sorry
    also have "... = f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>) /CFUNCT-1K1\<^bsub>(C)\<^esub> f1"
      using cfunct_1_th_39 sorry
    finally show "(f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2)^CFUNCT-1K2\<^bsub>(C)\<^esub> =HIDDENR1 f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>) /CFUNCT-1K1\<^bsub>(C)\<^esub> f1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_44:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1)/CFUNCT-1K1\<^bsub>(C)\<^esub> f2"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2) =HIDDENR1 (g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1)/CFUNCT-1K1\<^bsub>(C)\<^esub> f2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have "g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2) =HIDDENR1 g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>))"
      using cfunct_1_th_39 sorry
    also have "... = (g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
      using cfunct_1_th_14 sorry
    also have "... = (g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1)/CFUNCT-1K1\<^bsub>(C)\<^esub> f2"
      using cfunct_1_th_39 sorry
    finally show "g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2) =HIDDENR1 (g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1)/CFUNCT-1K1\<^bsub>(C)\<^esub> f2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_45:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds g /CFUNCT-1K1\<^bsub>(C)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>))/CFUNCT-1K1\<^bsub>(C)\<^esub> f1"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds g /CFUNCT-1K1\<^bsub>(C)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2) =HIDDENR1 (g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>))/CFUNCT-1K1\<^bsub>(C)\<^esub> f1"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have "g /CFUNCT-1K1\<^bsub>(C)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2) =HIDDENR1 g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2)^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
      using cfunct_1_th_39 sorry
    also have "... = g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>) /CFUNCT-1K1\<^bsub>(C)\<^esub> f1)"
      using cfunct_1_th_43 sorry
    also have "... = (g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>))/CFUNCT-1K1\<^bsub>(C)\<^esub> f1"
      using cfunct_1_th_44 sorry
    finally show "g /CFUNCT-1K1\<^bsub>(C)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2) =HIDDENR1 (g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>))/CFUNCT-1K1\<^bsub>(C)\<^esub> f1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_46:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds -VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f /CFUNCT-1K1\<^bsub>(C)\<^esub> g =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/CFUNCT-1K1\<^bsub>(C)\<^esub> g & f /CFUNCT-1K1\<^bsub>(C)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> g) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> -VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f /CFUNCT-1K1\<^bsub>(C)\<^esub> g"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds -VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f /CFUNCT-1K1\<^bsub>(C)\<^esub> g =HIDDENR1 (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/CFUNCT-1K1\<^bsub>(C)\<^esub> g & f /CFUNCT-1K1\<^bsub>(C)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> g) =HIDDENR1 -VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f /CFUNCT-1K1\<^bsub>(C)\<^esub> g"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have "-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f /CFUNCT-1K1\<^bsub>(C)\<^esub> g =HIDDENR1 (-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)"
      using complex1_def_4 sorry
    also have "... = (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/CFUNCT-1K1\<^bsub>(C)\<^esub> g"
      using cfunct_1_th_40 complex1_def_4 sorry
    finally show "-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f /CFUNCT-1K1\<^bsub>(C)\<^esub> g =HIDDENR1 (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/CFUNCT-1K1\<^bsub>(C)\<^esub> g"
       sorry
    have "f /CFUNCT-1K1\<^bsub>(C)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> g) =HIDDENR1 f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> g)^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
      using cfunct_1_th_39 sorry
    also have "... = f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>))"
      using cfunct_1_lm_2 cfunct_1_th_36 complex1_def_4 sorry
    also have "... = -VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
      using cfunct_1_th_18 complex1_def_4 sorry
    also have "... = -VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f /CFUNCT-1K1\<^bsub>(C)\<^esub> g"
      using cfunct_1_th_39 sorry
    finally show "f /CFUNCT-1K1\<^bsub>(C)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> g) =HIDDENR1 -VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f /CFUNCT-1K1\<^bsub>(C)\<^esub> g"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_47:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 /CFUNCT-1K1\<^bsub>(C)\<^esub> f =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/CFUNCT-1K1\<^bsub>(C)\<^esub> f & f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 /CFUNCT-1K1\<^bsub>(C)\<^esub> f =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/CFUNCT-1K1\<^bsub>(C)\<^esub> f"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 /CFUNCT-1K1\<^bsub>(C)\<^esub> f =HIDDENR1 (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/CFUNCT-1K1\<^bsub>(C)\<^esub> f & f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 /CFUNCT-1K1\<^bsub>(C)\<^esub> f =HIDDENR1 (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/CFUNCT-1K1\<^bsub>(C)\<^esub> f"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have "f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 /CFUNCT-1K1\<^bsub>(C)\<^esub> f =HIDDENR1 f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>) +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 /CFUNCT-1K1\<^bsub>(C)\<^esub> f"
      using cfunct_1_th_39 sorry
    also have "... = f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>) +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
      using cfunct_1_th_39 sorry
    also have "... = (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
      using cfunct_1_th_15 sorry
    also have "... = (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/CFUNCT-1K1\<^bsub>(C)\<^esub> f"
      using cfunct_1_th_39 sorry
    finally show "f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 /CFUNCT-1K1\<^bsub>(C)\<^esub> f =HIDDENR1 (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/CFUNCT-1K1\<^bsub>(C)\<^esub> f"
       sorry
    have "f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 /CFUNCT-1K1\<^bsub>(C)\<^esub> f =HIDDENR1 f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>) -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 /CFUNCT-1K1\<^bsub>(C)\<^esub> f"
      using cfunct_1_th_39 sorry
    also have "... = f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>) -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
      using cfunct_1_th_39 sorry
    also have "... = (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
      using cfunct_1_th_19 sorry
    also have "... = (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/CFUNCT-1K1\<^bsub>(C)\<^esub> f"
      using cfunct_1_th_39 sorry
    finally show "f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 /CFUNCT-1K1\<^bsub>(C)\<^esub> f =HIDDENR1 (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/CFUNCT-1K1\<^bsub>(C)\<^esub> f"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_48:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/CFUNCT-1K1\<^bsub>(C)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/CFUNCT-1K1\<^bsub>(C)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix g1 assume [ty]: "g1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have A1: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g) implies (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/CFUNCT-1K1\<^bsub>(C)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      have A2: "domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>) c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using cfunct_1_th_6 sorry
      assume A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g)"
      then have A4: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (g1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g)"
        using valued_1_def_1 sorry
      then have A5: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f)"
        using xboole_0_def_4 sorry
      have A6: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (g1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g)"
        using A4 xboole_0_def_4 sorry
      have A7: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (g1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g)"
        using A4 cfunct_1_th_39 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>))"
        using xboole_0_def_4 sorry
      then have A8: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
        using cfunct_1_th_3 sorry
      then have A9: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
        using xboole_0_def_4 sorry
      then have A10: "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c <>HIDDENR2 0cCOMPLEX1K6"
        using cfunct_1_th_8 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (g1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>))"
        using A7 cfunct_1_th_39 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (g1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>))"
        using xboole_0_def_4 sorry
      then have A11: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
        using cfunct_1_th_3 sorry
      then have A12: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
        using xboole_0_def_4 sorry
      then have A13: "g /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c <>HIDDENR2 0cCOMPLEX1K6"
        using cfunct_1_th_8 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g1"
        using A11 xboole_0_def_4 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using A9 A2 xboole_0_def_4 sorry
      then have A14: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (g1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)"
        using cfunct_1_th_3 sorry
      have A15: "domRELSET-1K1\<^bsub>(C)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>) c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> g"
        using cfunct_1_th_6 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> g"
        using A9 A12 A2 xboole_0_def_4 sorry
      then have A16: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g)"
        using cfunct_1_th_3 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1"
        using A8 xboole_0_def_4 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> g"
        using A12 A15 xboole_0_def_4 sorry
      then have A17: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g)"
        using cfunct_1_th_3 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (g1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)"
        using A14 xboole_0_def_4 sorry
      then have A18: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)"
        using valued_1_def_1 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
        using A9 A12 xboole_0_def_4 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>))"
        using cfunct_1_th_3 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g)^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
        using cfunct_1_th_35 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> ((f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g)^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
        using A18 xboole_0_def_4 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g)^CFUNCT-1K2\<^bsub>(C)\<^esub>))"
        using cfunct_1_th_3 sorry
      then have A19: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/CFUNCT-1K1\<^bsub>(C)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g))"
        using cfunct_1_th_39 sorry
      have "(f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 (g1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A3 cfunct_1_th_1 sorry
      also have "... = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5 +XCMPLX-0K2 (g1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A5 cfunct_1_def_1 sorry
      also have "... = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (1rCOMPLEX1K7 *XCMPLX-0K3 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5) +XCMPLX-0K2 (g1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 1rCOMPLEX1K7)*XCMPLX-0K3 (g /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5"
        using A6 cfunct_1_def_1 complex1_def_4 sorry
      also have "... = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 ((g /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (g /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5) +XCMPLX-0K2 g1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (1rCOMPLEX1K7 *XCMPLX-0K3 (g /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)"
        using A13 complex1_def_4 xcmplx_0_def_7 sorry
      also have "... = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (g /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 ((g /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)) +XCMPLX-0K2 g1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 ((f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 (g /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)"
        using A10 complex1_def_4 xcmplx_0_def_7 sorry
      also have "... = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (g /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (g /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5) +XCMPLX-0K2 g1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 ((f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (g /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5))"
        using xcmplx_1_th_204 sorry
      also have "... = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (g /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 g /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5) +XCMPLX-0K2 g1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 g /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)"
        using xcmplx_1_th_204 sorry
      also have "... = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (g /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 ((f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5) +XCMPLX-0K2 g1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 g /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)"
        using A16 cfunct_1_th_3 sorry
      also have "... = (f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 g /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)*XCMPLX-0K3 ((f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5 +XCMPLX-0K2 g1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 ((f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)"
        using A16 cfunct_1_th_3 sorry
      also have "... = (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 ((f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5 +XCMPLX-0K2 (g1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)*XCMPLX-0K3 ((f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5"
        using A17 cfunct_1_th_3 sorry
      also have "... = (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 ((f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5 +XCMPLX-0K2 (g1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 ((f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5"
        using A14 cfunct_1_th_3 sorry
      also have "... = ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 (g1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)*XCMPLX-0K3 ((f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5"
         sorry
      also have "... = (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 ((f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5"
        using A18 cfunct_1_th_1 sorry
      also have "... = ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/CFUNCT-1K1\<^bsub>(C)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A19 cfunct_1_def_1 sorry
      finally show "(f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/CFUNCT-1K1\<^bsub>(C)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g))/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (g1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g)"
      using valued_1_def_1 sorry
    also have "... = (domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }))/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (g1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g)"
      using cfunct_1_def_1 sorry
    also have "... = (domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }))/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g \\SUBSET-1K7\<^bsub>(C)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }))"
      using cfunct_1_def_1 sorry
    also have "... = (domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 })))/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g \\SUBSET-1K7\<^bsub>(C)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }))"
      using cfunct_1_th_6 sorry
    also have "... = ((domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }))/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f1)/\\SUBSET-1K9\<^bsub>(C)\<^esub> ((domRELSET-1K1\<^bsub>(C)\<^esub> g /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g \\SUBSET-1K7\<^bsub>(C)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }))/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> g1)"
      using cfunct_1_th_6 sorry
    also have "... = (domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }))/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> ((domRELSET-1K1\<^bsub>(C)\<^esub> g /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g \\SUBSET-1K7\<^bsub>(C)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }))/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> g1))"
      using xboole_1_th_16 sorry
    also have "... = (domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }))/\\SUBSET-1K9\<^bsub>(C)\<^esub> ((domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g \\SUBSET-1K7\<^bsub>(C)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 })))/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> g1)"
      using xboole_1_th_16 sorry
    also have "... = (domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }))/\\SUBSET-1K9\<^bsub>(C)\<^esub> (((domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> g)/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g \\SUBSET-1K7\<^bsub>(C)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }))/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> g1)"
      using xboole_1_th_16 sorry
    also have "... = (domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }))/\\SUBSET-1K9\<^bsub>(C)\<^esub> ((domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g) /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g \\SUBSET-1K7\<^bsub>(C)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }))/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> g1)"
      using cfunct_1_th_3 sorry
    also have "... = (domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }))/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g) /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g \\SUBSET-1K7\<^bsub>(C)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 })))"
      using xboole_1_th_16 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g) /\\SUBSET-1K9\<^bsub>(C)\<^esub> (((domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 })/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f)/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g \\SUBSET-1K7\<^bsub>(C)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 })))"
      using xboole_1_th_16 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g) /\\SUBSET-1K9\<^bsub>(C)\<^esub> ((domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 })/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g \\SUBSET-1K7\<^bsub>(C)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }))))"
      using xboole_1_th_16 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g) /\\SUBSET-1K9\<^bsub>(C)\<^esub> ((domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 })/\\SUBSET-1K9\<^bsub>(C)\<^esub> ((domRELSET-1K1\<^bsub>(C)\<^esub> g1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f)/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g \\SUBSET-1K7\<^bsub>(C)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 })))"
      using xboole_1_th_16 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g) /\\SUBSET-1K9\<^bsub>(C)\<^esub> ((domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 })/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> (g1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f) /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g \\SUBSET-1K7\<^bsub>(C)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 })))"
      using cfunct_1_th_3 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g) /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> (g1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f) /\\SUBSET-1K9\<^bsub>(C)\<^esub> ((domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 })/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g \\SUBSET-1K7\<^bsub>(C)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 })))"
      using xboole_1_th_16 sorry
    also have "... = (domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (g1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f))/\\SUBSET-1K9\<^bsub>(C)\<^esub> ((domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 })/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g \\SUBSET-1K7\<^bsub>(C)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }))"
      using xboole_1_th_16 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f) /\\SUBSET-1K9\<^bsub>(C)\<^esub> ((domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 })/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g \\SUBSET-1K7\<^bsub>(C)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }))"
      using valued_1_def_1 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f) /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g) \\SUBSET-1K7\<^bsub>(C)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 })"
      using cfunct_1_th_7 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/CFUNCT-1K1\<^bsub>(C)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g))"
      using cfunct_1_def_1 sorry
    finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/CFUNCT-1K1\<^bsub>(C)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g))"
       sorry
    thus "f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/CFUNCT-1K1\<^bsub>(C)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g)"
      using A1 partfun2_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_49:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)/CFUNCT-1K1\<^bsub>(C)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g1) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (g1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>))/CFUNCT-1K1\<^bsub>(C)\<^esub> (g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)/CFUNCT-1K1\<^bsub>(C)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g1) =HIDDENR1 (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (g1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>))/CFUNCT-1K1\<^bsub>(C)\<^esub> (g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix g1 assume [ty]: "g1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have "(f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)/CFUNCT-1K1\<^bsub>(C)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g1) =HIDDENR1 (f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g1)^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
      using cfunct_1_th_39 sorry
    also have "... = (f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (g1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (g1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>) /CFUNCT-1K1\<^bsub>(C)\<^esub> f1)"
      using cfunct_1_th_43 sorry
    also have "... = (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (g1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>))/CFUNCT-1K1\<^bsub>(C)\<^esub> (g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1)"
      using cfunct_1_th_42 sorry
    finally show "(f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)/CFUNCT-1K1\<^bsub>(C)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g1) =HIDDENR1 (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (g1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>))/CFUNCT-1K1\<^bsub>(C)\<^esub> (g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_50:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/CFUNCT-1K1\<^bsub>(C)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g =HIDDENR1 (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/CFUNCT-1K1\<^bsub>(C)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix g1 assume [ty]: "g1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have "f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g =HIDDENR1 f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> g1)/CFUNCT-1K1\<^bsub>(C)\<^esub> g"
      using cfunct_1_th_40 complex1_def_4 sorry
    also have "... = (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> g1)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/CFUNCT-1K1\<^bsub>(C)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g)"
      using cfunct_1_th_48 sorry
    also have "... = (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/CFUNCT-1K1\<^bsub>(C)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g)"
      using cfunct_1_th_17 complex1_def_4 sorry
    finally show "f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g =HIDDENR1 (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/CFUNCT-1K1\<^bsub>(C)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_51:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2 .| =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1.|)/RFUNCT-1K3\<^bsub>(C,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2.|)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2 .| =HIDDENR1 ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1.|)/RFUNCT-1K3\<^bsub>(C,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2.|)"
  proof(rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have " |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2 .| =HIDDENR1  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>) .|"
      using cfunct_1_th_39 sorry
    also have "... = ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1.|)(#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub> .|)"
      using cfunct_1_th_29 sorry
    also have "... = ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1.|)(#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2.|)^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub>)"
      using cfunct_1_th_38 sorry
    also have "... = ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1.|)/RFUNCT-1K3\<^bsub>(C,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2.|)"
      using rfunct_1_th_31 sorry
    finally show " |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2 .| =HIDDENR1 ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1.|)/RFUNCT-1K3\<^bsub>(C,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2.|)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_52:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X & (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) & (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X"
proof-
  have " for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X & ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 & (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have A1: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) implies ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
      then have A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
        using relat_1_th_61 sorry
      then have A4: "c inTARSKIR2 X"
        using xboole_0_def_4 sorry
      have A5: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
        using A3 xboole_0_def_4 sorry
      then have A6: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using valued_1_def_1 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using xboole_0_def_4 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f2 /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
        using A4 xboole_0_def_4 sorry
      then have A7: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
        using relat_1_th_61 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1"
        using A6 xboole_0_def_4 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
        using A4 xboole_0_def_4 sorry
      then have A8: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
        using relat_1_th_61 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
        using A7 xboole_0_def_4 sorry
      then have A9: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
        using valued_1_def_1 sorry
      have "((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A2 partfun2_th_15 sorry
      also have "... = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A5 cfunct_1_th_1 sorry
      also have "... = (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A8 partfun2_th_15 sorry
      also have "... = (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 (f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A7 partfun2_th_15 sorry
      also have "... = (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A9 cfunct_1_th_1 sorry
      finally show "((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    have "domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
      using relat_1_th_61 sorry
    also have "... = (domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2)/\\SUBSET-1K8\<^bsub>(C)\<^esub> (X /\\XBOOLE-0K3 X)"
      using valued_1_def_1 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 /\\SUBSET-1K8\<^bsub>(C)\<^esub> (X /\\XBOOLE-0K3 X))"
      using xboole_1_th_16 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> ((domRELSET-1K1\<^bsub>(C)\<^esub> f2 /\\SUBSET-1K8\<^bsub>(C)\<^esub> X)/\\SUBSET-1K8\<^bsub>(C)\<^esub> X)"
      using xboole_1_th_16 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X))"
      using relat_1_th_61 sorry
    also have "... = (domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K8\<^bsub>(C)\<^esub> X)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
      using xboole_1_th_16 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
      using relat_1_th_61 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
      using valued_1_def_1 sorry
    finally have "domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
       sorry
    thus "(f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X"
      using A1 partfun2_th_1 sorry
    have A10: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) implies ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A11: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
      then have A12: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
        using relat_1_th_61 sorry
      then have A13: "c inTARSKIR2 X"
        using xboole_0_def_4 sorry
      have A14: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
        using A12 xboole_0_def_4 sorry
      then have A15: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using valued_1_def_1 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1"
        using xboole_0_def_4 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
        using A13 xboole_0_def_4 sorry
      then have A16: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
        using relat_1_th_61 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using A15 xboole_0_def_4 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using A16 xboole_0_def_4 sorry
      then have A17: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
        using valued_1_def_1 sorry
      have "((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A11 partfun2_th_15 sorry
      also have "... = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A14 cfunct_1_th_1 sorry
      also have "... = (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A16 partfun2_th_15 sorry
      also have "... = (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A17 cfunct_1_th_1 sorry
      finally show "((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    have "domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
      using relat_1_th_61 sorry
    also have "... = (domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2)/\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
      using valued_1_def_1 sorry
    also have "... = (domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K8\<^bsub>(C)\<^esub> X)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
      using xboole_1_th_16 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
      using relat_1_th_61 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
      using valued_1_def_1 sorry
    finally have "domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
       sorry
    thus "(f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2"
      using A10 partfun2_th_1 sorry
    have A18: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) implies ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A19: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
      then have A20: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
        using relat_1_th_61 sorry
      then have A21: "c inTARSKIR2 X"
        using xboole_0_def_4 sorry
      have A22: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
        using A20 xboole_0_def_4 sorry
      then have A23: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using valued_1_def_1 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using xboole_0_def_4 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f2 /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
        using A21 xboole_0_def_4 sorry
      then have A24: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
        using relat_1_th_61 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1"
        using A23 xboole_0_def_4 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
        using A24 xboole_0_def_4 sorry
      then have A25: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
        using valued_1_def_1 sorry
      have "((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A19 partfun2_th_15 sorry
      also have "... = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A22 cfunct_1_th_1 sorry
      also have "... = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 (f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A24 partfun2_th_15 sorry
      also have "... = (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A25 cfunct_1_th_1 sorry
      finally show "((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    have "domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
      using relat_1_th_61 sorry
    also have "... = (domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2)/\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
      using valued_1_def_1 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 /\\SUBSET-1K8\<^bsub>(C)\<^esub> X)"
      using xboole_1_th_16 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
      using relat_1_th_61 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
      using valued_1_def_1 sorry
    finally have "domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
       sorry
    thus "(f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X"
      using A18 partfun2_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_53:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X & (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) & (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X"
proof-
  have " for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X & ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 & (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have A1: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) implies ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
      then have A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
        using relat_1_th_61 sorry
      then have A4: "c inTARSKIR2 X"
        using xboole_0_def_4 sorry
      have A5: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
        using A3 xboole_0_def_4 sorry
      then have A6: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using cfunct_1_th_3 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using xboole_0_def_4 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f2 /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
        using A4 xboole_0_def_4 sorry
      then have A7: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
        using relat_1_th_61 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1"
        using A6 xboole_0_def_4 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
        using A4 xboole_0_def_4 sorry
      then have A8: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
        using relat_1_th_61 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
        using A7 xboole_0_def_4 sorry
      then have A9: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
        using cfunct_1_th_3 sorry
      have "((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A2 partfun2_th_15 sorry
      also have "... = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A5 cfunct_1_th_3 sorry
      also have "... = (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A8 partfun2_th_15 sorry
      also have "... = (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A7 partfun2_th_15 sorry
      also have "... = (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A9 cfunct_1_th_3 sorry
      finally show "((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    have "domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
      using relat_1_th_61 sorry
    also have "... = (domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2)/\\SUBSET-1K8\<^bsub>(C)\<^esub> (X /\\XBOOLE-0K3 X)"
      using cfunct_1_th_3 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 /\\SUBSET-1K8\<^bsub>(C)\<^esub> (X /\\XBOOLE-0K3 X))"
      using xboole_1_th_16 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> ((domRELSET-1K1\<^bsub>(C)\<^esub> f2 /\\SUBSET-1K8\<^bsub>(C)\<^esub> X)/\\SUBSET-1K8\<^bsub>(C)\<^esub> X)"
      using xboole_1_th_16 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X))"
      using relat_1_th_61 sorry
    also have "... = (domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K8\<^bsub>(C)\<^esub> X)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
      using xboole_1_th_16 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
      using relat_1_th_61 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
      using cfunct_1_th_3 sorry
    finally have "domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
       sorry
    thus "(f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X"
      using A1 partfun2_th_1 sorry
    have A10: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) implies ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A11: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
      then have A12: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
        using relat_1_th_61 sorry
      then have A13: "c inTARSKIR2 X"
        using xboole_0_def_4 sorry
      have A14: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
        using A12 xboole_0_def_4 sorry
      then have A15: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using cfunct_1_th_3 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1"
        using xboole_0_def_4 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
        using A13 xboole_0_def_4 sorry
      then have A16: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
        using relat_1_th_61 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using A15 xboole_0_def_4 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using A16 xboole_0_def_4 sorry
      then have A17: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
        using cfunct_1_th_3 sorry
      have "((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A11 partfun2_th_15 sorry
      also have "... = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A14 cfunct_1_th_3 sorry
      also have "... = (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A16 partfun2_th_15 sorry
      also have "... = (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A17 cfunct_1_th_3 sorry
      finally show "((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    have "domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
      using relat_1_th_61 sorry
    also have "... = (domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2)/\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
      using cfunct_1_th_3 sorry
    also have "... = (domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K8\<^bsub>(C)\<^esub> X)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
      using xboole_1_th_16 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
      using relat_1_th_61 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
      using cfunct_1_th_3 sorry
    finally have "domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
       sorry
    thus "(f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2"
      using A10 partfun2_th_1 sorry
    have A18: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) implies ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A19: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
      then have A20: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
        using relat_1_th_61 sorry
      then have A21: "c inTARSKIR2 X"
        using xboole_0_def_4 sorry
      have A22: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
        using A20 xboole_0_def_4 sorry
      then have A23: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using cfunct_1_th_3 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using xboole_0_def_4 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f2 /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
        using A21 xboole_0_def_4 sorry
      then have A24: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
        using relat_1_th_61 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1"
        using A23 xboole_0_def_4 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
        using A24 xboole_0_def_4 sorry
      then have A25: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
        using cfunct_1_th_3 sorry
      have "((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A19 partfun2_th_15 sorry
      also have "... = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A22 cfunct_1_th_3 sorry
      also have "... = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A24 partfun2_th_15 sorry
      also have "... = (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A25 cfunct_1_th_3 sorry
      finally show "((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    have "domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
      using relat_1_th_61 sorry
    also have "... = (domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2)/\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
      using cfunct_1_th_3 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 /\\SUBSET-1K8\<^bsub>(C)\<^esub> X)"
      using xboole_1_th_16 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
      using relat_1_th_61 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
      using cfunct_1_th_3 sorry
    finally have "domRELSET-1K1\<^bsub>(C)\<^esub> ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
       sorry
    thus "(f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X"
      using A18 partfun2_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_54:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds ((-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> -VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X & (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X ^CFUNCT-1K2\<^bsub>(C)\<^esub>) & ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub>  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X.|"
proof-
  have " for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> -VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X & ((f ^CFUNCT-1K2\<^bsub>(C)\<^esub>) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X ^CFUNCT-1K2\<^bsub>(C)\<^esub> & ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub>  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X.|)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have A1: "domRELSET-1K1\<^bsub>(C)\<^esub> ((f ^CFUNCT-1K2\<^bsub>(C)\<^esub>) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>) /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
      using relat_1_th_61 sorry
    also have "... = (domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 })/\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
      using cfunct_1_def_2 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K8\<^bsub>(C)\<^esub> X \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 } /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
      using xboole_1_th_50 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) \\SUBSET-1K7\<^bsub>(C)\<^esub> X /\\SUBSET-1K9\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
      using relat_1_th_61 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) \\SUBSET-1K7\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
      using funct_1_th_70 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
      using cfunct_1_def_2 sorry
    finally have "domRELSET-1K1\<^bsub>(C)\<^esub> ((f ^CFUNCT-1K2\<^bsub>(C)\<^esub>) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
       sorry
    have A2: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) implies ((-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
      then have A4: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
        using relat_1_th_61 sorry
      then have A5: "c inTARSKIR2 X"
        using xboole_0_def_4 sorry
      have A6: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)"
        using A4 xboole_0_def_4 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using cfunct_1_th_5 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
        using A5 xboole_0_def_4 sorry
      then have A7: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
        using relat_1_th_61 sorry
      then have A8: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
        using cfunct_1_th_5 sorry
      have "((-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A3 partfun2_th_15 sorry
      also have "... = -XCMPLX-0K4 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A6 cfunct_1_th_5 sorry
      also have "... = -XCMPLX-0K4 (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A7 partfun2_th_15 sorry
      also have "... = (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A8 cfunct_1_th_5 sorry
      finally show "((-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    have "domRELSET-1K1\<^bsub>(C)\<^esub> ((-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
      using relat_1_th_61 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
      using cfunct_1_th_5 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
      using relat_1_th_61 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
      using cfunct_1_th_5 sorry
    finally have "domRELSET-1K1\<^bsub>(C)\<^esub> ((-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
       sorry
    thus "(-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> -VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X"
      using A2 partfun2_th_1 sorry
    have A9: "domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X ^CFUNCT-1K2\<^bsub>(C)\<^esub>) c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
      using cfunct_1_th_6 sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f ^CFUNCT-1K2\<^bsub>(C)\<^esub>) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) implies ((f ^CFUNCT-1K2\<^bsub>(C)\<^esub>) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X ^CFUNCT-1K2\<^bsub>(C)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A10: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f ^CFUNCT-1K2\<^bsub>(C)\<^esub>) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>) /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
        using relat_1_th_61 sorry
      then have A11: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
        using xboole_0_def_4 sorry
      have "((f ^CFUNCT-1K2\<^bsub>(C)\<^esub>) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A10 partfun2_th_15 sorry
      also have "... = (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5"
        using A11 cfunct_1_def_2 sorry
      also have "... = ((f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5"
        using A9 A1 A10 partfun2_th_15 sorry
      also have "... = (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X ^CFUNCT-1K2\<^bsub>(C)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A1 A10 cfunct_1_def_2 sorry
      finally show "((f ^CFUNCT-1K2\<^bsub>(C)\<^esub>) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X ^CFUNCT-1K2\<^bsub>(C)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    thus "(f ^CFUNCT-1K2\<^bsub>(C)\<^esub>) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X ^CFUNCT-1K2\<^bsub>(C)\<^esub>"
      using A1 partfun2_th_1 sorry
    have A12: "domRELSET-1K1\<^bsub>(C)\<^esub> (( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
      using relat_1_th_61 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
      using valued_1_def_11 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
      using relat_1_th_61 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X.|)"
      using valued_1_def_11 sorry
    finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X.|)"
       sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X) implies (( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 c =HIDDENR1 ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X.|).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      have A13: "domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using valued_1_def_11 sorry
      assume A14: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X)"
      then have A15: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
        using A12 valued_1_def_11 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
        using A14 relat_1_th_61 sorry
      then have A16: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)"
        using xboole_0_def_4 sorry
      have "(( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 c =HIDDENR1 ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|).FUNCT-1K1 c"
        using A14 funct_1_th_47 sorry
      also have "... =  |.COMPLEX1K10 f .FUNCT-1K1 c.|"
        using valued_1_th_18 sorry
      also have "... =  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.|"
        using A16 A13 partfun1_def_6 sorry
      also have "... =  |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.|"
        using A15 partfun2_th_15 sorry
      also have "... =  |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X).FUNCT-1K1 c.|"
        using A15 partfun1_def_6 sorry
      also have "... = ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X.|).FUNCT-1K1 c"
        using valued_1_th_18 sorry
      finally show "(( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 c =HIDDENR1 ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X.|).FUNCT-1K1 c"
         sorry
    qed "sorry"
    thus "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub>  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X.|"
      using A12 partfun1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_55:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds ((f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X & (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) & (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X"
proof-
  have " for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =HIDDENR1 f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X & ((f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =HIDDENR1 f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 & (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =HIDDENR1 f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have "(f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =HIDDENR1 f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X"
      using cfunct_1_th_52 sorry
    also have "... = f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X"
      using cfunct_1_th_54 sorry
    finally show "(f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =HIDDENR1 f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X"
       sorry
    have "(f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =HIDDENR1 f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2)"
      using cfunct_1_th_52 sorry
    also have "... = f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2"
       sorry
    finally show "(f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =HIDDENR1 f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2"
       sorry
    have "(f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =HIDDENR1 f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X"
      using cfunct_1_th_52 sorry
    also have "... = f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X"
      using cfunct_1_th_54 sorry
    finally show "(f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =HIDDENR1 f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_56:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds ((f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X /CFUNCT-1K1\<^bsub>(C)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X & (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X /CFUNCT-1K1\<^bsub>(C)\<^esub> f2) & (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X"
proof-
  have " for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =HIDDENR1 f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X /CFUNCT-1K1\<^bsub>(C)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X & ((f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =HIDDENR1 f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X /CFUNCT-1K1\<^bsub>(C)\<^esub> f2 & (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =HIDDENR1 f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have "(f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =HIDDENR1 (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>)) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X"
      using cfunct_1_th_39 sorry
    also have "... = f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X"
      using cfunct_1_th_53 sorry
    also have "... = f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
      using cfunct_1_th_54 sorry
    also have "... = f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X /CFUNCT-1K1\<^bsub>(C)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X"
      using cfunct_1_th_39 sorry
    finally show "(f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =HIDDENR1 f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X /CFUNCT-1K1\<^bsub>(C)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X"
       sorry
    have "(f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =HIDDENR1 (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>)) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X"
      using cfunct_1_th_39 sorry
    also have "... = f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
      using cfunct_1_th_53 sorry
    also have "... = f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X /CFUNCT-1K1\<^bsub>(C)\<^esub> f2"
      using cfunct_1_th_39 sorry
    finally show "(f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =HIDDENR1 f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X /CFUNCT-1K1\<^bsub>(C)\<^esub> f2"
       sorry
    have "(f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =HIDDENR1 (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>)) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X"
      using cfunct_1_th_39 sorry
    also have "... = f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X"
      using cfunct_1_th_53 sorry
    also have "... = f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
      using cfunct_1_th_54 sorry
    also have "... = f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X"
      using cfunct_1_th_39 sorry
    finally show "(f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =HIDDENR1 f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_57:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X"
proof-
  have " for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix r assume [ty]: "r be ComplexXCMPLX-0M1"
    have A1: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) implies ((r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
      then have A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
        using relat_1_th_61 sorry
      then have A4: "c inTARSKIR2 X"
        using xboole_0_def_4 sorry
      have A5: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)"
        using A3 xboole_0_def_4 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using cfunct_1_th_4 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
        using A4 xboole_0_def_4 sorry
      then have A6: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
        using relat_1_th_61 sorry
      then have A7: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
        using cfunct_1_th_4 sorry
      have "((r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A2 partfun2_th_15 sorry
      also have "... = r *XCMPLX-0K3 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A5 cfunct_1_th_4 sorry
      also have "... = r *XCMPLX-0K3 (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A6 partfun2_th_15 sorry
      also have "... = (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A7 cfunct_1_th_4 sorry
      finally show "((r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
         sorry
    qed "sorry"
    have "domRELSET-1K1\<^bsub>(C)\<^esub> ((r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
      using relat_1_th_61 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
      using cfunct_1_th_4 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
      using relat_1_th_61 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
      using cfunct_1_th_4 sorry
    finally have "domRELSET-1K1\<^bsub>(C)\<^esub> ((r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X)"
       sorry
    thus "(r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X"
      using A1 partfun2_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem cfunct_1_th_58:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds ((f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>) & (f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)) & (f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>) & ((f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>) & ((f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>) & (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI,rule conjMI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    show "f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
    proof-
      have "(f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>) & (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
      proof(rule conjMI,rule impI)
        show "f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
        proof(rule impI)
          assume "f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
          then have Cut1663: "domRELSET-1K1\<^bsub>(C)\<^esub> f1 =XBOOLE-0R4 C & domRELSET-1K1\<^bsub>(C)\<^esub> f2 =XBOOLE-0R4 C"
             sorry
          have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =HIDDENR1 C"
          proof-
            have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =HIDDENR1 C /\\XBOOLE-0K3 C"
              using valued_1_def_1 Cut1663 sorry
            also have "... = C"
               sorry
            finally show "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =HIDDENR1 C"
               sorry
          qed
          thus "f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
            using partfun1_def_2 sorry
        qed
        assume "f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
        then have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =XBOOLE-0R4 C"
           sorry
        then have "domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 =XBOOLE-0R4 C"
          using valued_1_def_1 sorry
        then have Cut1670: "C c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> f1 & C c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> f2"
          using xboole_1_th_17 sorry
        have "domRELSET-1K1\<^bsub>(C)\<^esub> f1 =XBOOLE-0R4 C & domRELSET-1K1\<^bsub>(C)\<^esub> f2 =XBOOLE-0R4 C"
        proof-
          show "domRELSET-1K1\<^bsub>(C)\<^esub> f1 =XBOOLE-0R4 C & domRELSET-1K1\<^bsub>(C)\<^esub> f2 =XBOOLE-0R4 C"
            using Cut1670 sorry
        qed
        thus "f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
          using partfun1_def_2 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    show "f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
    proof-
      have "(f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>) & (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
      proof(rule conjMI,rule impI)
        show "f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
        proof(rule impI)
          assume "f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
          then have Cut1678: "domRELSET-1K1\<^bsub>(C)\<^esub> f1 =XBOOLE-0R4 C & domRELSET-1K1\<^bsub>(C)\<^esub> f2 =XBOOLE-0R4 C"
             sorry
          have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =HIDDENR1 C"
          proof-
            have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =HIDDENR1 C /\\XBOOLE-0K3 C"
              using cfunct_1_th_2 Cut1678 sorry
            also have "... = C"
               sorry
            finally show "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =HIDDENR1 C"
               sorry
          qed
          thus "f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
            using partfun1_def_2 sorry
        qed
        assume "f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
        then have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =XBOOLE-0R4 C"
           sorry
        then have "domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 =XBOOLE-0R4 C"
          using cfunct_1_th_2 sorry
        then have Cut1685: "C c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> f1 & C c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> f2"
          using xboole_1_th_17 sorry
        have "domRELSET-1K1\<^bsub>(C)\<^esub> f1 =XBOOLE-0R4 C & domRELSET-1K1\<^bsub>(C)\<^esub> f2 =XBOOLE-0R4 C"
        proof-
          show "domRELSET-1K1\<^bsub>(C)\<^esub> f1 =XBOOLE-0R4 C & domRELSET-1K1\<^bsub>(C)\<^esub> f2 =XBOOLE-0R4 C"
            using Cut1685 sorry
        qed
        thus "f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
          using partfun1_def_2 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    show "f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
    proof(rule impI)
      assume "f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      then have Cut1691: "domRELSET-1K1\<^bsub>(C)\<^esub> f1 =XBOOLE-0R4 C & domRELSET-1K1\<^bsub>(C)\<^esub> f2 =XBOOLE-0R4 C"
         sorry
      have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =HIDDENR1 C"
      proof-
        have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =HIDDENR1 C /\\XBOOLE-0K3 C"
          using cfunct_1_th_3 Cut1691 sorry
        also have "... = C"
           sorry
        finally show "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =HIDDENR1 C"
           sorry
      qed
      thus "f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
        using partfun1_def_2 sorry
    qed
    assume "f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
    then have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =XBOOLE-0R4 C"
       sorry
    then have "domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 =XBOOLE-0R4 C"
      using cfunct_1_th_3 sorry
    then have Cut1698: "C c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> f1 & C c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> f2"
      using xboole_1_th_17 sorry
    have "domRELSET-1K1\<^bsub>(C)\<^esub> f1 =XBOOLE-0R4 C & domRELSET-1K1\<^bsub>(C)\<^esub> f2 =XBOOLE-0R4 C"
    proof-
      show "domRELSET-1K1\<^bsub>(C)\<^esub> f1 =XBOOLE-0R4 C & domRELSET-1K1\<^bsub>(C)\<^esub> f2 =XBOOLE-0R4 C"
        using Cut1698 sorry
    qed
    thus "f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      using partfun1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_59:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds f be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  using cfunct_1_th_4 sorry

mtheorem cfunct_1_th_60:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff -VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  using cfunct_1_th_59 sorry

mtheorem cfunct_1_th_61:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.| be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  using valued_1_def_11 sorry

mtheorem cfunct_1_th_62:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f ^CFUNCT-1K2\<^bsub>(C)\<^esub> be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 & f be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f ^CFUNCT-1K2\<^bsub>(C)\<^esub> be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 & f be totalPARTFUN1V1\<^bsub>(C)\<^esub>) & (f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 & f be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies f ^CFUNCT-1K2\<^bsub>(C)\<^esub> be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    show "f ^CFUNCT-1K2\<^bsub>(C)\<^esub> be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 & f be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
    proof(rule impI,rule conjMI)
      assume "f ^CFUNCT-1K2\<^bsub>(C)\<^esub> be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      then have A1: "domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>) =XBOOLE-0R4 C"
         sorry
      have "f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 } c=TARSKIR1 C"
         sorry
      then have "f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 } c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
        using A1 cfunct_1_def_2 sorry
      thus "f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1"
        using xboole_1_th_38 sorry
      then have Cut1725: "C =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> {}XBOOLE-0K1"
        using A1 cfunct_1_def_2 sorry
      have "domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 C"
      proof-
        show "domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 C"
          using Cut1725 sorry
      qed
      thus "f be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
        using partfun1_def_2 sorry
    qed
    assume A2: "f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 & f be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>) =HIDDENR1 C"
    proof-
      have "domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
        using cfunct_1_def_2 sorry
      also have "... = C"
        using A2 sorry
      finally show "domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>) =HIDDENR1 C"
         sorry
    qed
    thus "f ^CFUNCT-1K2\<^bsub>(C)\<^esub> be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      using partfun1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_63:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1) & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds ((f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1) & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>) & (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & (f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI,rule conjMI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    show "(f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1) & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
    proof-
      have "f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & (f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>) implies f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      proof(rule impMI ,rule impI)
        assume A1: "f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
          and A2: "f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
        have "f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub> be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
          using A2 cfunct_1_th_62 sorry
        then have "f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>) be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
          using A1 cfunct_1_th_58 sorry
        thus "f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
          using cfunct_1_th_39 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume "f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
    then have A3: "f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>) be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      using cfunct_1_th_39 sorry
    thus "f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      using cfunct_1_th_58 sorry
    have "f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub> be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      using A3 cfunct_1_th_58 sorry
    thus "f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      using cfunct_1_th_62 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_64:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c & (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c) & (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c & ((f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c & (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    assume A1: "f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
    then have "f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      using cfunct_1_th_58 sorry
    then have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =XBOOLE-0R4 C"
       sorry
    thus "(f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
      using cfunct_1_th_1 sorry
    have "f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      using A1 cfunct_1_th_58 sorry
    then have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =XBOOLE-0R4 C"
       sorry
    thus "(f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
      using cfunct_1_th_2 sorry
    have "f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      using A1 cfunct_1_th_58 sorry
    then have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =XBOOLE-0R4 C"
       sorry
    thus "(f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
      using cfunct_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_65:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds f be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 r *XCMPLX-0K3 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds f be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 r *XCMPLX-0K3 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix r assume [ty]: "r be ComplexXCMPLX-0M1"
    assume "f be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
    then have "r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      using cfunct_1_th_59 sorry
    then have "domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) =XBOOLE-0R4 C"
       sorry
    thus "(r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 r *XCMPLX-0K3 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
      using cfunct_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_66:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 -XCMPLX-0K4 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c & ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|).FUNCT-1K1 c =COMPLEX1R1  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.|"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 -XCMPLX-0K4 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c & ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|).FUNCT-1K1 c =HIDDENR1  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.|"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    assume A1: "f be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
    then have " |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.| be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      using cfunct_1_th_61 sorry
    then have A2: "domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) =XBOOLE-0R4 C"
      using valued_1_def_11 sorry
    have "-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      using A1 cfunct_1_th_60 sorry
    then have "domRELSET-1K1\<^bsub>(C)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) =XBOOLE-0R4 C"
       sorry
    thus "(-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 -XCMPLX-0K4 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
      using cfunct_1_th_5 sorry
    have "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|).FUNCT-1K1 c =HIDDENR1  |.COMPLEX1K10 f .FUNCT-1K1 c.|"
      using valued_1_th_18 sorry
    also have "... =  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.|"
      using A2 partfun1_def_6 sorry
    finally show "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|).FUNCT-1K1 c =HIDDENR1  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.|"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_67:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f ^CFUNCT-1K2\<^bsub>(C)\<^esub> be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5"
  using cfunct_1_def_2 sorry

mtheorem cfunct_1_th_68:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub> be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub> be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    assume A1: "f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      and A2: "f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub> be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
    have "f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 } =XBOOLE-0R4 {}XBOOLE-0K1 & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      using A2 cfunct_1_th_62 sorry
    then have "f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      using A1 cfunct_1_th_63 sorry
    then have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2) =XBOOLE-0R4 C"
       sorry
    thus "(f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5"
      using cfunct_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mlemma cfunct_1_lm_3:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.| be boundedSEQ-2V6 iff f be boundedCOMSEQ-2V1"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.| be boundedSEQ-2V6 implies f be boundedCOMSEQ-2V1) &  not (f be boundedCOMSEQ-2V1 &  not  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.| be boundedSEQ-2V6)"
  proof(rule ballI,rule ballI,rule conjMI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have A1: "domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)"
      using valued_1_def_11 sorry
    show " |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.| be boundedSEQ-2V6 implies f be boundedCOMSEQ-2V1"
    proof(rule impI)
      assume " |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.| be boundedSEQ-2V6"
      then obtain r1 where
        [ty]:"r1 be RealXREAL-0M1" and 
        A2: " for y be setHIDDENM2 holds y inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) implies  |.COMPLEX1K10 absVALUED-1K59\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f .FUNCT-1K1 y.| <XXREAL-0R3 r1"
         sorry
      have " for y be setHIDDENM2 holds y inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies  not r1 <=XXREAL-0R1  |.COMPLEX1K10 f .FUNCT-1K1 y.|"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be setHIDDENM2"
        assume A3: "y inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        then have " |.COMPLEX1K10 absVALUED-1K59\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f .FUNCT-1K1 y.| <XXREAL-0R3 r1"
          using A1 A2 sorry
        then have " |.COMPLEX1K10  |.COMPLEX1K10 f .FUNCT-1K1 y.| .| <XXREAL-0R3 r1"
          using A1 A3 valued_1_def_11 sorry
        thus " not r1 <=XXREAL-0R1  |.COMPLEX1K10 f .FUNCT-1K1 y.|"
           sorry
      qed "sorry"
      thus "f be boundedCOMSEQ-2V1"
        using bexI[of _ "r1"] comseq_2_def_3 sorry
    qed
    have "( ex r1 be RealXREAL-0M1 st  for y be setHIDDENM2 holds y inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 y.| <XXREAL-0R3 r1) implies  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.| be boundedSEQ-2V6"
    proof(rule impI)
      assume Given: " ex r1 be RealXREAL-0M1 st  for y be setHIDDENM2 holds y inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 y.| <XXREAL-0R3 r1"
      then obtain r1 where
        [ty]:"r1 be RealXREAL-0M1" and 
        A4: " for y be setHIDDENM2 holds y inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 y.| <XXREAL-0R3 r1"
         sorry
      have " ex r1 be RealXREAL-0M1 st  for y be setHIDDENM2 holds y inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) implies  |.COMPLEX1K10 absVALUED-1K59\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f .FUNCT-1K1 y.| <XXREAL-0R3 r1"
      proof-
        show " ex r1 be RealXREAL-0M1 st  for y be setHIDDENM2 holds y inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) implies  |.COMPLEX1K10 absVALUED-1K59\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f .FUNCT-1K1 y.| <XXREAL-0R3 r1"
        proof(rule bexI[of _ "r1"],rule ballI,rule impI)
          fix y assume [ty]: "y be setHIDDENM2"
          assume A5: "y inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)"
          then have " |.COMPLEX1K10  |.COMPLEX1K10 f .FUNCT-1K1 y.| .| <XXREAL-0R3 r1"
            using A1 A4 sorry
          thus " |.COMPLEX1K10 absVALUED-1K59\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f .FUNCT-1K1 y.| <XXREAL-0R3 r1"
            using A5 valued_1_def_11 sorry
        qed "sorry"
      qed
      thus " |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.| be boundedSEQ-2V6"
         sorry
    qed
    thus " not (f be boundedCOMSEQ-2V1 &  not  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.| be boundedSEQ-2V6)"
      using comseq_2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_69:
" for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1 iff ( ex p be RealXREAL-0M1 st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| <=XXREAL-0R1 p)"
proof-
  have " for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1 implies ( ex p be RealXREAL-0M1 st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| <=XXREAL-0R1 p)) & (( ex p be RealXREAL-0M1 st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| <=XXREAL-0R1 p) implies f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have A1: "domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f"
      using valued_1_def_11 sorry
    have A2: "domRELSET-1K1\<^bsub>(C)\<^esub> (( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y) =XBOOLE-0R4 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)"
      using relat_1_th_61 sorry
    have A3: "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub>  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y.|"
      using rfunct_1_th_46 sorry
    show "f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1 implies ( ex p be RealXREAL-0M1 st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| <=XXREAL-0R1 p)"
    proof(rule impI)
      assume "f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1"
      then have "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be boundedSEQ-2V6"
        using A3 cfunct_1_lm_3 sorry
      then obtain p where
        [ty]:"p be RealXREAL-0M1" and 
        A4: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> (( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y) implies  |.COMPLEX1K10 (( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 c.| <=XXREAL-0R1 p"
        using rfunct_1_th_72 sorry
      have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| <=XXREAL-0R1 p"
      proof(rule ballI,rule impI)
        fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
        assume A5: "c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f"
        have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
          using A5 xboole_0_def_4 sorry
        then have A6: "f .FUNCT-1K1 c =COMPLEX1R1 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
          using partfun1_def_6 sorry
        have " |.COMPLEX1K10 (( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 c.| =HIDDENR1  |.COMPLEX1K10 ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|).FUNCT-1K1 c.|"
          using A1 A2 A5 funct_1_th_47 sorry
        also have "... =  |.COMPLEX1K10  |.COMPLEX1K10 f .FUNCT-1K1 c.| .|"
          using valued_1_th_18 sorry
        finally have " |.COMPLEX1K10 (( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 c.| =HIDDENR1  |.COMPLEX1K10  |.COMPLEX1K10 f .FUNCT-1K1 c.| .|"
           sorry
        thus " |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| <=XXREAL-0R1 p"
          using A1 A2 A4 A5 A6 sorry
      qed "sorry"
      thus " ex p be RealXREAL-0M1 st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| <=XXREAL-0R1 p"
         sorry
    qed
    assume Given: " ex p be RealXREAL-0M1 st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| <=XXREAL-0R1 p"
    then obtain p where
      [ty]:"p be RealXREAL-0M1" and 
      A7: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| <=XXREAL-0R1 p"
       sorry
    have A8: "domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f"
      using valued_1_def_11 sorry
    have " for c be objectHIDDENM1 holds c inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> (( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y) implies  |.COMPLEX1K10 (( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 c.| <=XXREAL-0R1 p"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume A9: "c inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> (( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y)"
      have A10: "c inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)"
        using A9 relat_1_th_57 sorry
      have " |.COMPLEX1K10 (( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 c.| =HIDDENR1  |.COMPLEX1K10 ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|).FUNCT-1K1 c.|"
        using A9 funct_1_th_47 sorry
      also have "... =  |.COMPLEX1K10  |.COMPLEX1K10 f .FUNCT-1K1 c.| .|"
        using valued_1_th_18 sorry
      also have "... =  |.COMPLEX1K10  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| .|"
        using A1 A10 partfun1_def_6 sorry
      finally have " |.COMPLEX1K10 (( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 c.| =HIDDENR1  |.COMPLEX1K10  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| .|"
         sorry
      thus " |.COMPLEX1K10 (( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 c.| <=XXREAL-0R1 p"
        using A2 A7 A8 A9 sorry
    qed "sorry"
    then have "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be boundedSEQ-2V6"
      using rfunct_1_th_72 sorry
    thus "f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1"
      using A3 cfunct_1_lm_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_70:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds Y c=TARSKIR1 X & f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X be boundedCOMSEQ-2V1 implies f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds Y c=TARSKIR1 X & f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X be boundedCOMSEQ-2V1 implies f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    assume A1: "Y c=TARSKIR1 X"
      and A2: "f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X be boundedCOMSEQ-2V1"
    have "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub>  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X.|"
      using rfunct_1_th_46 sorry
    then have "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X be boundedSEQ-2V6"
      using A2 cfunct_1_lm_3 sorry
    then have "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub>  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y.| & ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be boundedSEQ-2V6"
      using A1 rfunct_1_th_46 rfunct_1_th_74 sorry
    thus "f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1"
      using cfunct_1_lm_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_71:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds X missesXBOOLE-0R1 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X be boundedCOMSEQ-2V1"
proof-
  have " for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  not (X missesXBOOLE-0R1 domRELSET-1K1\<^bsub>(C)\<^esub> f &  not f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X be boundedCOMSEQ-2V1)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have "X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 {}XBOOLE-0K1 implies f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X be boundedCOMSEQ-2V1"
    proof(rule impI)
      assume "X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 {}XBOOLE-0K1"
      then have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| <=XXREAL-0R1 0NUMBERSK6"
         sorry
      thus "f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X be boundedCOMSEQ-2V1"
        using cfunct_1_th_69 sorry
    qed
    thus " not (X missesXBOOLE-0R1 domRELSET-1K1\<^bsub>(C)\<^esub> f &  not f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X be boundedCOMSEQ-2V1)"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_72:
" for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1 implies (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1"
proof-
  have " for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1 implies (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix r assume [ty]: "r be ComplexXCMPLX-0M1"
    assume A1: "f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1"
    have "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub>  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y.|"
      using rfunct_1_th_46 sorry
    then have "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be boundedSEQ-2V6"
      using A1 cfunct_1_lm_3 sorry
    then have "(( |.COMPLEX1K10 r.|)(#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be boundedSEQ-2V6"
      using rfunct_1_th_80 sorry
    then have "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f .|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub>  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y.| & ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f .|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be boundedSEQ-2V6"
      using cfunct_1_th_30 rfunct_1_th_46 sorry
    thus "(r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1"
      using cfunct_1_lm_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_73:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X be bounded-belowSEQ-2V2"
proof-
  have " for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X be bounded-belowSEQ-2V2"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    have " ex z be ElementSUBSET-1M1-of NATNUMBERSK1 st  for c be objectHIDDENM1 holds c inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) implies z <=XXREAL-0R1 ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|).FUNCT-1K1 c"
    proof-
      obtain z where 
        [ty]:"z be ElementSUBSET-1M1-of NATNUMBERSK1" and zDef:"z = 0NUMBERSK6"
         sorry
      show " ex z be ElementSUBSET-1M1-of NATNUMBERSK1 st  for c be objectHIDDENM1 holds c inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) implies z <=XXREAL-0R1 ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|).FUNCT-1K1 c"
      proof(rule bexI[of _ "z"],rule ballI,rule impI)
        fix c assume [ty]: "c be objectHIDDENM1"
        have A1: "z <=XXREAL-0R1  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.|"
          using complex1_th_46 sorry
        assume "c inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)"
        then have A2: "c inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)"
          using xboole_0_def_4 sorry
        have "domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f"
          using valued_1_def_11 sorry
        then have "f .FUNCT-1K1 c =COMPLEX1R1 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
          using A2 partfun1_def_6 sorry
        thus "z <=XXREAL-0R1 ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|).FUNCT-1K1 c"
          using A1 valued_1_th_18 sorry
      qed "sorry"
    qed
    thus "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X be bounded-belowSEQ-2V2"
      using rfunct_1_th_71 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_74:
" for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1 implies ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be boundedSEQ-2V6 & (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1"
proof-
  have " for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1 implies ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be boundedSEQ-2V6 & (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    assume A1: "f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1"
    have "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub>  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y.|"
      using rfunct_1_th_46 sorry
    thus "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be boundedSEQ-2V6"
      using A1 cfunct_1_lm_3 sorry
    show "(-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1"
      using A1 cfunct_1_th_72 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_75:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X be boundedCOMSEQ-2V1 & f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1 implies (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedCOMSEQ-2V1"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X be boundedCOMSEQ-2V1 & f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1 implies (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedCOMSEQ-2V1"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    assume A1: "f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X be boundedCOMSEQ-2V1"
      and A2: "f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1"
    obtain r1 where
      [ty]:"r1 be RealXREAL-0M1" and 
      A3: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f1 implies  |.COMPLEX1K10 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| <=XXREAL-0R1 r1"
      using A1 cfunct_1_th_69 sorry
    obtain r2 where
      [ty]:"r2 be RealXREAL-0M1" and 
      A4: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 implies  |.COMPLEX1K10 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| <=XXREAL-0R1 r2"
      using A2 cfunct_1_th_69 sorry
    have " ex p1 be RealXREAL-0M1 st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) implies  |.COMPLEX1K10 (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| <=XXREAL-0R1 p1"
    proof-
      have " ex r0 be setHIDDENM2 st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) implies  |.COMPLEX1K10 (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| <=XXREAL-0R1 r0"
      proof-
        obtain r0 where 
          [ty]:"r0 be setHIDDENM2" and r0Def:"r0 = r1 +XCMPLX-0K2 r2"
           sorry
        show " ex r0 be setHIDDENM2 st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) implies  |.COMPLEX1K10 (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| <=XXREAL-0R1 r0"
        proof(rule bexI[of _ "r0"],rule ballI,rule impI)
          fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
          have A5: " |.COMPLEX1K10 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c .| <=XXREAL-0R1  |.COMPLEX1K10 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| +XCMPLX-0K2  |.COMPLEX1K10 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.|"
            using complex1_th_56 sorry
          assume A6: "c inTARSKIR2 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
          then have A7: "c inTARSKIR2 X /\\XBOOLE-0K3 Y"
            using xboole_0_def_4 sorry
          then have A8: "c inTARSKIR2 X"
            using xboole_0_def_4 sorry
          have A9: "c inTARSKIR2 Y"
            using A7 xboole_0_def_4 sorry
          have A10: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
            using A6 xboole_0_def_4 sorry
          then have A11: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
            using valued_1_def_1 sorry
          then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f2"
            using xboole_0_def_4 sorry
          then have "c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
            using A9 xboole_0_def_4 sorry
          then have A12: " |.COMPLEX1K10 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| <=XXREAL-0R1 r2"
            using A4 sorry
          have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1"
            using A11 xboole_0_def_4 sorry
          then have "c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f1"
            using A8 xboole_0_def_4 sorry
          then have " |.COMPLEX1K10 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| <=XXREAL-0R1 r1"
            using A3 sorry
          then have " |.COMPLEX1K10 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| +XCMPLX-0K2  |.COMPLEX1K10 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| <=XXREAL-0R1 r0"
            using A12 xreal_1_th_7 sorry
          then have " |.COMPLEX1K10 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c .| <=XXREAL-0R1 r0"
            using A5 xxreal_0_th_2 sorry
          thus " |.COMPLEX1K10 (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| <=XXREAL-0R1 r0"
            using A10 cfunct_1_th_1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    thus "(f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedCOMSEQ-2V1"
      using cfunct_1_th_69 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_76:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X be boundedCOMSEQ-2V1 & f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1 implies (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedCOMSEQ-2V1 & (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedCOMSEQ-2V1"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X be boundedCOMSEQ-2V1 & f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1 implies (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedCOMSEQ-2V1 & (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedCOMSEQ-2V1"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    assume A1: "f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X be boundedCOMSEQ-2V1"
      and A2: "f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1"
    obtain r1 where
      [ty]:"r1 be RealXREAL-0M1" and 
      A3: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f1 implies  |.COMPLEX1K10 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| <=XXREAL-0R1 r1"
      using A1 cfunct_1_th_69 sorry
    obtain r2 where
      [ty]:"r2 be RealXREAL-0M1" and 
      A4: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 implies  |.COMPLEX1K10 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| <=XXREAL-0R1 r2"
      using A2 cfunct_1_th_69 sorry
    have " ex r be setHIDDENM2 st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) implies  |.COMPLEX1K10 (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| <=XXREAL-0R1 r"
    proof-
      obtain r where 
        [ty]:"r be setHIDDENM2" and rDef:"r = r1 *XCMPLX-0K3 r2"
         sorry
      show " ex r be setHIDDENM2 st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) implies  |.COMPLEX1K10 (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| <=XXREAL-0R1 r"
      proof(rule bexI[of _ "r"],rule ballI,rule impI)
        fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
        assume A5: "c inTARSKIR2 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
        then have A6: "c inTARSKIR2 X /\\XBOOLE-0K3 Y"
          using xboole_0_def_4 sorry
        then have A7: "c inTARSKIR2 X"
          using xboole_0_def_4 sorry
        have A8: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
          using A5 xboole_0_def_4 sorry
        then have A9: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
          using cfunct_1_th_3 sorry
        then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1"
          using xboole_0_def_4 sorry
        then have "c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f1"
          using A7 xboole_0_def_4 sorry
        then have A10: " |.COMPLEX1K10 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| <=XXREAL-0R1 r1"
          using A3 sorry
        have A11: "c inTARSKIR2 Y"
          using A6 xboole_0_def_4 sorry
        have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f2"
          using A9 xboole_0_def_4 sorry
        then have "c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
          using A11 xboole_0_def_4 sorry
        then have A12: " |.COMPLEX1K10 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| <=XXREAL-0R1 r2"
          using A4 sorry
        have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| & 0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.|"
          using complex1_th_46 sorry
        then have "( |.COMPLEX1K10 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.|)*XCMPLX-0K3 ( |.COMPLEX1K10 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.|) <=XXREAL-0R1 r"
          using A10 A12 xreal_1_th_66 sorry
        then have " |.COMPLEX1K10 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c .| <=XXREAL-0R1 r"
          using complex1_th_65 sorry
        thus " |.COMPLEX1K10 (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| <=XXREAL-0R1 r"
          using A8 cfunct_1_th_3 sorry
      qed "sorry"
    qed
    thus "(f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedCOMSEQ-2V1"
      using cfunct_1_th_69 sorry
    have "(-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1"
      using A2 cfunct_1_th_74 sorry
    thus "(f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedCOMSEQ-2V1"
      using A1 cfunct_1_th_75 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_77:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X be boundedCOMSEQ-2V1 & f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1 implies f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X \\/XBOOLE-0K2 Y) be boundedCOMSEQ-2V1"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X be boundedCOMSEQ-2V1 & f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1 implies f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X \\/XBOOLE-0K2 Y) be boundedCOMSEQ-2V1"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    assume A1: "f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X be boundedCOMSEQ-2V1"
      and A2: "f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1"
    have "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub>  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y.|"
      using rfunct_1_th_46 sorry
    then have A3: "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be boundedSEQ-2V6"
      using A2 cfunct_1_lm_3 sorry
    have "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub>  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X.|"
      using rfunct_1_th_46 sorry
    then have "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X be boundedSEQ-2V6"
      using A1 cfunct_1_lm_3 sorry
    then have "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y) =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub>  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X \\/XBOOLE-0K2 Y).| & ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y) be boundedSEQ-2V6"
      using A3 rfunct_1_th_46 rfunct_1_th_87 sorry
    thus "f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X \\/XBOOLE-0K2 Y) be boundedCOMSEQ-2V1"
      using cfunct_1_lm_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_78:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X be constantFUNCT-1V5 & f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5 implies ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be constantFUNCT-1V5 & (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be constantFUNCT-1V5) & (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be constantFUNCT-1V5"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X be constantFUNCT-1V5 & f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5 implies (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be constantFUNCT-1V5 & ((f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be constantFUNCT-1V5 & (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be constantFUNCT-1V5)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    assume A1: "f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X be constantFUNCT-1V5"
      and A2: "f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5"
    obtain cr1 where
      [ty]:"cr1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and 
      A3: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f1 implies f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 cr1"
      using A1 partfun2_th_35 sorry
    obtain cr2 where
      [ty]:"cr2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and 
      A4: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 implies f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 cr2"
      using A2 partfun2_th_35 sorry
    have A5: "cr1 +XCMPLX-0K2 cr2 inTARSKIR2 COMPLEXNUMBERSK3"
      using xcmplx_0_def_2 sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) implies (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 cr1 +XCMPLX-0K2 cr2"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A6: "c inTARSKIR2 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
      then have A7: "c inTARSKIR2 X /\\XBOOLE-0K3 Y"
        using xboole_0_def_4 sorry
      then have A8: "c inTARSKIR2 X"
        using xboole_0_def_4 sorry
      have A9: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
        using A6 xboole_0_def_4 sorry
      then have A10: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using valued_1_def_1 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1"
        using xboole_0_def_4 sorry
      then have A11: "c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f1"
        using A8 xboole_0_def_4 sorry
      have A12: "c inTARSKIR2 Y"
        using A7 xboole_0_def_4 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using A10 xboole_0_def_4 sorry
      then have A13: "c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using A12 xboole_0_def_4 sorry
      have "(f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A9 cfunct_1_th_1 sorry
      also have "... = cr1 +XCMPLX-0K2 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A3 A11 sorry
      also have "... = cr1 +XCMPLX-0K2 cr2"
        using A4 A13 sorry
      finally show "(f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 cr1 +XCMPLX-0K2 cr2"
         sorry
    qed "sorry"
    thus "(f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be constantFUNCT-1V5"
      using A5 partfun2_th_35 sorry
    have A14: "cr1 -XCMPLX-0K6 cr2 inTARSKIR2 COMPLEXNUMBERSK3"
      using xcmplx_0_def_2 sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) implies (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 cr1 -XCMPLX-0K6 cr2"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A15: "c inTARSKIR2 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
      then have A16: "c inTARSKIR2 X /\\XBOOLE-0K3 Y"
        using xboole_0_def_4 sorry
      then have A17: "c inTARSKIR2 X"
        using xboole_0_def_4 sorry
      have A18: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
        using A15 xboole_0_def_4 sorry
      then have A19: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using cfunct_1_th_2 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1"
        using xboole_0_def_4 sorry
      then have A20: "c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f1"
        using A17 xboole_0_def_4 sorry
      have A21: "c inTARSKIR2 Y"
        using A16 xboole_0_def_4 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using A19 xboole_0_def_4 sorry
      then have A22: "c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using A21 xboole_0_def_4 sorry
      have "(f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A18 cfunct_1_th_2 sorry
      also have "... = cr1 -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A3 A20 sorry
      also have "... = cr1 -XCMPLX-0K6 cr2"
        using A4 A22 sorry
      finally show "(f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 cr1 -XCMPLX-0K6 cr2"
         sorry
    qed "sorry"
    thus "(f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be constantFUNCT-1V5"
      using A14 partfun2_th_35 sorry
    have A23: "cr1 *XCMPLX-0K3 cr2 inTARSKIR2 COMPLEXNUMBERSK3"
      using xcmplx_0_def_2 sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) implies (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 cr1 *XCMPLX-0K3 cr2"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A24: "c inTARSKIR2 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
      then have A25: "c inTARSKIR2 X /\\XBOOLE-0K3 Y"
        using xboole_0_def_4 sorry
      then have A26: "c inTARSKIR2 X"
        using xboole_0_def_4 sorry
      have A27: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
        using A24 xboole_0_def_4 sorry
      then have A28: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using cfunct_1_th_3 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1"
        using xboole_0_def_4 sorry
      then have A29: "c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f1"
        using A26 xboole_0_def_4 sorry
      have A30: "c inTARSKIR2 Y"
        using A25 xboole_0_def_4 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using A28 xboole_0_def_4 sorry
      then have A31: "c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using A30 xboole_0_def_4 sorry
      have "(f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A27 cfunct_1_th_3 sorry
      also have "... = cr1 *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A3 A29 sorry
      also have "... = cr1 *XCMPLX-0K3 cr2"
        using A4 A31 sorry
      finally show "(f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 cr1 *XCMPLX-0K3 cr2"
         sorry
    qed "sorry"
    thus "(f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be constantFUNCT-1V5"
      using A23 partfun2_th_35 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_79:
" for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for q be ComplexXCMPLX-0M1 holds f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5 implies (q (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5"
proof-
  have " for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for q be ComplexXCMPLX-0M1 holds f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5 implies (q (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix q assume [ty]: "q be ComplexXCMPLX-0M1"
    assume "f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5"
    then obtain r where
      [ty]:"r be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and 
      A1: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 r"
      using partfun2_th_35 sorry
    have A2: "q *XCMPLX-0K3 r inTARSKIR2 COMPLEXNUMBERSK3"
      using xcmplx_0_def_2 sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (q (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) implies (q (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 q *XCMPLX-0K3 r"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A3: "c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (q (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)"
      then have A4: "c inTARSKIR2 Y"
        using xboole_0_def_4 sorry
      have A5: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (q (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)"
        using A3 xboole_0_def_4 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using cfunct_1_th_4 sorry
      then have A6: "c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using A4 xboole_0_def_4 sorry
      have "(q (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 q *XCMPLX-0K3 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A5 cfunct_1_th_4 sorry
      also have "... = q *XCMPLX-0K3 r"
        using A1 A6 sorry
      finally show "(q (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 q *XCMPLX-0K3 r"
         sorry
    qed "sorry"
    thus "(q (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5"
      using A2 partfun2_th_35 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_80:
" for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5 implies ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 & (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5"
proof-
  have " for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5 implies ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 & (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    assume "f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5"
    then obtain r where
      [ty]:"r be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and 
      A1: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 r"
      using partfun2_th_35 sorry
    obtain rr where 
      [ty]:"rr be ElementSUBSET-1M1-of REALNUMBERSK2" and rrDef:"rr =  |.COMPLEX1K10 r.|"
      using xreal_0_def_1 sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) implies ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|).FUNCT-1K1 c =HIDDENR1 rr"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A2: "c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)"
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)"
        using xboole_0_def_4 sorry
      then have A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using valued_1_def_11 sorry
      have "c inTARSKIR2 Y"
        using A2 xboole_0_def_4 sorry
      then have A4: "c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using A3 xboole_0_def_4 sorry
      have "f .FUNCT-1K1 c =COMPLEX1R1 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using A3 partfun1_def_6 sorry
      then have "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|).FUNCT-1K1 c =HIDDENR1  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.|"
        using valued_1_th_18 sorry
      also have "... = rr"
        using A1 A4 sorry
      finally show "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|).FUNCT-1K1 c =HIDDENR1 rr"
         sorry
    qed "sorry"
    thus "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5"
      using partfun2_th_57 sorry
    have A5: "-XCMPLX-0K4 r inHIDDENR3 COMPLEXNUMBERSK3"
      using xcmplx_0_def_2 sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) implies (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 -XCMPLX-0K4 r"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A6: "c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)"
      then have "c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using cfunct_1_th_5 sorry
      then have A7: "-XCMPLX-0K4 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 -XCMPLX-0K4 r"
        using A1 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)"
        using A6 xboole_0_def_4 sorry
      thus "(-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 -XCMPLX-0K4 r"
        using A7 cfunct_1_th_5 sorry
    qed "sorry"
    thus "(-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5"
      using A5 partfun2_th_35 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_81:
" for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5 implies f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1"
proof-
  have " for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5 implies f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    assume "f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5"
    then obtain r where
      [ty]:"r be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and 
      A1: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 r"
      using partfun2_th_35 sorry
    have " ex p be objectHIDDENM1 st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| <=XXREAL-0R1 p"
    proof-
      obtain p where 
        [ty]:"p be objectHIDDENM1" and pDef:"p =  |.COMPLEX1K10 r.|"
         sorry
      show " ex p be objectHIDDENM1 st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| <=XXREAL-0R1 p"
      proof(rule bexI[of _ "p"],rule ballI,rule impI)
        fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
        assume "c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f"
        thus " |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| <=XXREAL-0R1 p"
          using A1 sorry
      qed "sorry"
    qed
    thus "f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1"
      using cfunct_1_th_69 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_82:
" for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5 implies (( for r be ComplexXCMPLX-0M1 holds (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1) & (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1) & ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be boundedSEQ-2V6"
proof-
  have " for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5 implies ( for r be ComplexXCMPLX-0M1 holds (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1) & ((-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1 & ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be boundedSEQ-2V6)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    assume A1: "f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5"
    thus " for r be ComplexXCMPLX-0M1 holds (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1"
      using cfunct_1_th_79 cfunct_1_th_81 sorry
    show "(-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1"
      using A1 cfunct_1_th_80 cfunct_1_th_81 sorry
    have "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5"
      using A1 cfunct_1_th_80 sorry
    thus "( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be boundedSEQ-2V6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_83:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X be boundedCOMSEQ-2V1 & f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5 implies (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedCOMSEQ-2V1"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X be boundedCOMSEQ-2V1 & f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5 implies (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedCOMSEQ-2V1"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    assume A1: "f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X be boundedCOMSEQ-2V1"
      and A2: "f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5"
    have "f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1"
      using A2 cfunct_1_th_81 sorry
    thus "(f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedCOMSEQ-2V1"
      using A1 cfunct_1_th_75 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_84:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X be boundedCOMSEQ-2V1 & f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5 implies ((f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedCOMSEQ-2V1 & (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedCOMSEQ-2V1) & (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedCOMSEQ-2V1"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X be boundedCOMSEQ-2V1 & f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5 implies (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedCOMSEQ-2V1 & ((f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedCOMSEQ-2V1 & (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedCOMSEQ-2V1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
    assume A1: "f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X be boundedCOMSEQ-2V1"
      and A2: "f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5"
    have "(-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5"
      using A2 cfunct_1_th_80 sorry
    thus "(f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedCOMSEQ-2V1"
      using A1 cfunct_1_th_83 sorry
    have A3: "f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1"
      using A2 cfunct_1_th_81 sorry
    thus "(f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedCOMSEQ-2V1"
      using A1 cfunct_1_th_76 sorry
    show "(f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedCOMSEQ-2V1"
      using A1 A3 cfunct_1_th_76 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfunct_1_th_85:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.| be boundedSEQ-2V6 iff f be boundedCOMSEQ-2V1"
  using cfunct_1_lm_3 sorry

mtheorem cfunct_1_ident_1:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,D)", "c be ComplexXCMPLX-0M1"
"identify f /.PARTFUN1K7\<^bsub>(D)\<^esub> c with f .FUNCT-1K1 c"
proof
(*compatibility*)
  show "f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =HIDDENR1 f .FUNCT-1K1 c"
  proof-
    have 
      [ty]:"c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
      using xcmplx_0_def_2 sorry
    have "f /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,D)\<^esub> c =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,D)\<^esub> c"
      using funct_2_th_99 sorry
    thus "f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =HIDDENR1 f .FUNCT-1K1 c"
       sorry
  qed
qed "sorry"

end
