theory quin_1
  imports square_1 membered
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x, a, b, c for "RealXREAL-0M1"
mdef quin_1_def_1 ("deltaQUIN-1K1'( _ , _ , _ ')" [0,0,0]228 ) where
  mlet "a be ComplexXCMPLX-0M1", "b be ComplexXCMPLX-0M1", "c be ComplexXCMPLX-0M1"
"func deltaQUIN-1K1(a,b,c) \<rightarrow> numberORDINAL1M2 equals
  b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c"
proof-
  (*coherence*)
    show "b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c be numberORDINAL1M2"
       sorry
qed "sorry"

mtheorem quin_1_cl_1:
  mlet "a be ComplexXCMPLX-0M1", "b be ComplexXCMPLX-0M1", "c be ComplexXCMPLX-0M1"
"cluster deltaQUIN-1K1(a,b,c) as-term-is complexXCMPLX-0V1"
proof
(*coherence*)
  show "deltaQUIN-1K1(a,b,c) be complexXCMPLX-0V1"
     sorry
qed "sorry"

mtheorem quin_1_cl_2:
  mlet "a be RealXREAL-0M1", "b be RealXREAL-0M1", "c be RealXREAL-0M1"
"cluster deltaQUIN-1K1(a,b,c) as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "deltaQUIN-1K1(a,b,c) be realXREAL-0V1"
     sorry
qed "sorry"

mtheorem quin_1_th_1:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds  for x be ComplexXCMPLX-0M1 holds a <>HIDDENR2 0NUMBERSK6 implies (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c =HIDDENR1 a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a)"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix a assume [ty]: "a be ComplexXCMPLX-0M1"
  fix b assume [ty]: "b be ComplexXCMPLX-0M1"
  fix c assume [ty]: "c be ComplexXCMPLX-0M1"
  fix x assume [ty]: "x be ComplexXCMPLX-0M1"
  assume A1: "a <>HIDDENR2 0NUMBERSK6"
  then have A2: "\<four>\<^sub>M *XCMPLX-0K3 a <>HIDDENR2 0NUMBERSK6"
     sorry
  have "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c =HIDDENR1 (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 (b *XCMPLX-0K3 x)*XCMPLX-0K3 \<one>\<^sub>M)+XCMPLX-0K2 c"
     sorry
  also have "... = (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 (b *XCMPLX-0K3 x)*XCMPLX-0K3 (a *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a)))+XCMPLX-0K2 c"
    using A1 xcmplx_1_th_106 sorry
  also have "... = a *XCMPLX-0K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 (b *XCMPLX-0K3 x)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a)) +XCMPLX-0K2 c"
     sorry
  also have "... = a *XCMPLX-0K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 (b *XCMPLX-0K3 x)/XCMPLX-0K7 a) +XCMPLX-0K2 c"
    using xcmplx_1_th_99 sorry
  also have "... = a *XCMPLX-0K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 x *XCMPLX-0K3 (b /XCMPLX-0K7 a)) +XCMPLX-0K2 c"
    using xcmplx_1_th_74 sorry
  also have "... = a *XCMPLX-0K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 x *XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 b)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) +XCMPLX-0K2 c"
    using xcmplx_1_th_91 sorry
  also have "... = a *XCMPLX-0K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 x *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 (b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))) +XCMPLX-0K2 c"
    using xcmplx_1_th_74 sorry
  also have "... = (a *XCMPLX-0K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) +XCMPLX-0K2 b ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (c -XCMPLX-0K6 b ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))"
     sorry
  also have "... = (a *XCMPLX-0K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) +XCMPLX-0K2 a *XCMPLX-0K3 ((b ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a)))+XCMPLX-0K2 (c -XCMPLX-0K6 b ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))"
    using A1 xcmplx_1_th_109 sorry
  also have "... = (a *XCMPLX-0K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) +XCMPLX-0K2 a *XCMPLX-0K3 ((b ^2SQUARE-1K1 *XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 ((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 a)))+XCMPLX-0K2 (c -XCMPLX-0K6 b ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))"
    using xcmplx_1_th_76 sorry
  also have "... = (a *XCMPLX-0K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) +XCMPLX-0K2 a *XCMPLX-0K3 (b ^2SQUARE-1K1 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1))+XCMPLX-0K2 (c -XCMPLX-0K6 b ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))"
     sorry
  also have "... = (a *XCMPLX-0K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) +XCMPLX-0K2 a *XCMPLX-0K3 (b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1)+XCMPLX-0K2 (c -XCMPLX-0K6 b ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))"
    using xcmplx_1_th_76 sorry
  also have "... = a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 (b ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 c)"
     sorry
  also have "... = a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 (b ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 ((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)/XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))"
    using A2 xcmplx_1_th_89 sorry
  also have "... = a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)/XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a)"
    using xcmplx_1_th_120 sorry
  finally have "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c =HIDDENR1 a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)/XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a)"
     sorry
  thus "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c =HIDDENR1 a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a)"
     sorry
qed "sorry"

mtheorem quin_1_th_2:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) <=XXREAL-0R1 0NUMBERSK6 implies (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >=XXREAL-0R2 0NUMBERSK6"
proof-
  have " for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) <=XXREAL-0R1 0NUMBERSK6 implies (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >=XXREAL-0R2 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "deltaQUIN-1K1(a,b,c) <=XXREAL-0R1 0NUMBERSK6"
    have "-XCMPLX-0K4 deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 -XCMPLX-0K4 0NUMBERSK6 & \<four>\<^sub>M *XCMPLX-0K3 a >XXREAL-0R4 0NUMBERSK6"
      using A1 A2 xreal_1_th_25 xreal_1_th_129 sorry
    then have "(-XCMPLX-0K4 deltaQUIN-1K1(a,b,c))/XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a) >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_th_136 sorry
    then have "-XCMPLX-0K4 deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a) >=XXREAL-0R2 0NUMBERSK6"
      using xcmplx_1_th_187 sorry
    then have A3: "a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (-XCMPLX-0K4 deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a)) >=XXREAL-0R2 a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6"
      using xreal_1_th_7 sorry
    have "(x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_th_63 sorry
    then have "a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      using A1 xreal_1_th_127 sorry
    then have "a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a) >=XXREAL-0R2 0NUMBERSK6"
      using A3 xxreal_0_th_2 sorry
    thus "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >=XXREAL-0R2 0NUMBERSK6"
      using A1 quin_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quin_1_th_3:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) <XXREAL-0R3 0NUMBERSK6 implies (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >XXREAL-0R4 0NUMBERSK6"
proof-
  have " for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) <XXREAL-0R3 0NUMBERSK6 implies  not (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >XXREAL-0R4 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "deltaQUIN-1K1(a,b,c) <XXREAL-0R3 0NUMBERSK6"
    have "-XCMPLX-0K4 deltaQUIN-1K1(a,b,c) >XXREAL-0R4 -XCMPLX-0K4 0NUMBERSK6 & \<four>\<^sub>M *XCMPLX-0K3 a >XXREAL-0R4 0NUMBERSK6"
      using A1 A2 xreal_1_th_26 xreal_1_th_129 sorry
    then have "(-XCMPLX-0K4 deltaQUIN-1K1(a,b,c))/XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6"
      using xreal_1_th_139 sorry
    then have "-XCMPLX-0K4 deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6"
      using xcmplx_1_th_187 sorry
    then have A3: "a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (-XCMPLX-0K4 deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a)) >XXREAL-0R4 a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1"
      using xreal_1_th_29 sorry
    have "(x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_th_63 sorry
    then have "a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      using A1 xreal_1_th_127 sorry
    then have "a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6"
      using A3 xxreal_0_th_2 sorry
    thus " not (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >XXREAL-0R4 0NUMBERSK6"
      using A1 quin_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quin_1_th_4:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) <=XXREAL-0R1 0NUMBERSK6 implies (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <=XXREAL-0R1 0NUMBERSK6"
proof-
  have " for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) <=XXREAL-0R1 0NUMBERSK6 implies (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <=XXREAL-0R1 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a <XXREAL-0R3 0NUMBERSK6"
      and A2: "deltaQUIN-1K1(a,b,c) <=XXREAL-0R1 0NUMBERSK6"
    have "-XCMPLX-0K4 deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 -XCMPLX-0K4 0NUMBERSK6 & \<four>\<^sub>M *XCMPLX-0K3 a <XXREAL-0R3 0NUMBERSK6"
      using A1 A2 xreal_1_th_25 xreal_1_th_132 sorry
    then have "(-XCMPLX-0K4 deltaQUIN-1K1(a,b,c))/XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a) <=XXREAL-0R1 0NUMBERSK6"
      using xreal_1_th_137 sorry
    then have "-XCMPLX-0K4 deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a) <=XXREAL-0R1 0NUMBERSK6"
      using xcmplx_1_th_187 sorry
    then have A3: "a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (-XCMPLX-0K4 deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a)) <=XXREAL-0R1 a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6"
      using xreal_1_th_7 sorry
    have "a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 <=XXREAL-0R1 0NUMBERSK6"
      using A1 xreal_1_th_63 xreal_1_th_131 sorry
    then have "a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a) <=XXREAL-0R1 0NUMBERSK6"
      using A3 xxreal_0_th_2 sorry
    thus "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <=XXREAL-0R1 0NUMBERSK6"
      using A1 quin_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quin_1_th_5:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) <XXREAL-0R3 0NUMBERSK6 implies (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6"
proof-
  have " for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) <XXREAL-0R3 0NUMBERSK6 implies  not (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a <XXREAL-0R3 0NUMBERSK6"
      and A2: "deltaQUIN-1K1(a,b,c) <XXREAL-0R3 0NUMBERSK6"
    have "-XCMPLX-0K4 deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6 & \<four>\<^sub>M *XCMPLX-0K3 a <XXREAL-0R3 0NUMBERSK6"
      using A1 A2 xreal_1_th_58 xreal_1_th_132 sorry
    then have "(-XCMPLX-0K4 deltaQUIN-1K1(a,b,c))/XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6"
      using xreal_1_th_142 sorry
    then have "-XCMPLX-0K4 deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6"
      using xcmplx_1_th_187 sorry
    then have A3: "a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (-XCMPLX-0K4 deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a)) <XXREAL-0R3 a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6"
      using xreal_1_th_6 sorry
    have "a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 <=XXREAL-0R1 0NUMBERSK6"
      using A1 xreal_1_th_63 xreal_1_th_131 sorry
    then have "a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6"
      using A3 xxreal_0_th_2 sorry
    thus " not (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6"
      using A1 quin_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quin_1_th_6:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >=XXREAL-0R2 0NUMBERSK6 implies ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6"
proof-
  have " for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >=XXREAL-0R2 0NUMBERSK6 implies ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >=XXREAL-0R2 0NUMBERSK6"
    have A3: "\<four>\<^sub>M *XCMPLX-0K3 a <>HIDDENR2 0NUMBERSK6"
      using A1 sorry
    have "\<four>\<^sub>M *XCMPLX-0K3 a >XXREAL-0R4 0NUMBERSK6 & a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a) >=XXREAL-0R2 0NUMBERSK6"
      using A1 A2 quin_1_th_1 xreal_1_th_129 sorry
    then have "(\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a)) >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_th_127 sorry
    then have A4: "((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a)) >=XXREAL-0R2 0NUMBERSK6"
       sorry
    have "\<two>\<^sub>M *XCMPLX-0K3 a <>HIDDENR2 0NUMBERSK6"
      using A1 sorry
    then have "((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a)) >=XXREAL-0R2 0NUMBERSK6"
      using A4 xcmplx_1_th_87 sorry
    thus "((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6"
      using A3 xcmplx_1_th_87 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quin_1_th_7:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >XXREAL-0R4 0NUMBERSK6 implies ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6"
proof-
  have " for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >XXREAL-0R4 0NUMBERSK6 implies  not ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >XXREAL-0R4 0NUMBERSK6"
    have A3: "\<four>\<^sub>M *XCMPLX-0K3 a <>HIDDENR2 0NUMBERSK6"
      using A1 sorry
    have "\<four>\<^sub>M *XCMPLX-0K3 a >XXREAL-0R4 0NUMBERSK6 & a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6"
      using A1 A2 quin_1_th_1 xreal_1_th_129 sorry
    then have "(\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a)) >XXREAL-0R4 0NUMBERSK6"
      using xreal_1_th_129 sorry
    then have A4: "((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a)) >XXREAL-0R4 0NUMBERSK6"
       sorry
    have "\<two>\<^sub>M *XCMPLX-0K3 a <>HIDDENR2 0NUMBERSK6"
      using A1 sorry
    then have "((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a)) >XXREAL-0R4 0NUMBERSK6"
      using A4 xcmplx_1_th_87 sorry
    thus " not ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6"
      using A3 xcmplx_1_th_87 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quin_1_th_8:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <=XXREAL-0R1 0NUMBERSK6 implies ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6"
proof-
  have " for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <=XXREAL-0R1 0NUMBERSK6 implies ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a <XXREAL-0R3 0NUMBERSK6"
      and A2: "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <=XXREAL-0R1 0NUMBERSK6"
    have A3: "\<four>\<^sub>M *XCMPLX-0K3 a <>HIDDENR2 0NUMBERSK6"
      using A1 sorry
    have "\<four>\<^sub>M *XCMPLX-0K3 a <XXREAL-0R3 0NUMBERSK6 & a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a) <=XXREAL-0R1 0NUMBERSK6"
      using A1 A2 quin_1_th_1 xreal_1_th_132 sorry
    then have "(\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a)) >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_th_128 sorry
    then have A4: "((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a)) >=XXREAL-0R2 0NUMBERSK6"
       sorry
    have "\<two>\<^sub>M *XCMPLX-0K3 a <>HIDDENR2 0NUMBERSK6"
      using A1 sorry
    then have "((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a)) >=XXREAL-0R2 0NUMBERSK6"
      using A4 xcmplx_1_th_87 sorry
    thus "((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6"
      using A3 xcmplx_1_th_87 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quin_1_th_9:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6 implies ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6"
proof-
  have " for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6 implies  not ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a <XXREAL-0R3 0NUMBERSK6"
      and A2: "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6"
    have A3: "\<four>\<^sub>M *XCMPLX-0K3 a <>HIDDENR2 0NUMBERSK6"
      using A1 sorry
    have "\<four>\<^sub>M *XCMPLX-0K3 a <XXREAL-0R3 0NUMBERSK6 & a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6"
      using A1 A2 quin_1_th_1 xreal_1_th_132 sorry
    then have "(\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a)) >XXREAL-0R4 0NUMBERSK6"
      using xreal_1_th_130 sorry
    then have A4: "((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a)) >XXREAL-0R4 0NUMBERSK6"
       sorry
    have "\<two>\<^sub>M *XCMPLX-0K3 a <>HIDDENR2 0NUMBERSK6"
      using A1 sorry
    then have "((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a)) >XXREAL-0R4 0NUMBERSK6"
      using A4 xcmplx_1_th_87 sorry
    thus " not ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6"
      using A3 xcmplx_1_th_87 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quin_1_th_10:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ( for x be RealXREAL-0M1 holds (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >=XXREAL-0R2 0NUMBERSK6) & a >XXREAL-0R4 0NUMBERSK6 implies deltaQUIN-1K1(a,b,c) <=XXREAL-0R1 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ( for x be RealXREAL-0M1 holds (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >=XXREAL-0R2 0NUMBERSK6) & a >XXREAL-0R4 0NUMBERSK6 implies deltaQUIN-1K1(a,b,c) <=XXREAL-0R1 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: " for x be RealXREAL-0M1 holds (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >=XXREAL-0R2 0NUMBERSK6"
      and A2: "a >XXREAL-0R4 0NUMBERSK6"
    have "(a *XCMPLX-0K3 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))+XCMPLX-0K2 c >=XXREAL-0R2 0NUMBERSK6"
      using A1 sorry
    then have "((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6"
      using A2 quin_1_th_6 sorry
    then have A3: "((-XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))+XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6"
       sorry
    have "\<two>\<^sub>M *XCMPLX-0K3 a <>HIDDENR2 0NUMBERSK6"
      using A2 sorry
    then have "((-XCMPLX-0K4 b)+XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6"
      using A3 xcmplx_1_th_87 sorry
    then have "-XCMPLX-0K4 deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 -XCMPLX-0K4 0NUMBERSK6"
       sorry
    thus "deltaQUIN-1K1(a,b,c) <=XXREAL-0R1 0NUMBERSK6"
      using xreal_1_th_24 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quin_1_th_11:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ( for x be RealXREAL-0M1 holds (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <=XXREAL-0R1 0NUMBERSK6) & a <XXREAL-0R3 0NUMBERSK6 implies deltaQUIN-1K1(a,b,c) <=XXREAL-0R1 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ( for x be RealXREAL-0M1 holds (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <=XXREAL-0R1 0NUMBERSK6) & a <XXREAL-0R3 0NUMBERSK6 implies deltaQUIN-1K1(a,b,c) <=XXREAL-0R1 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: " for x be RealXREAL-0M1 holds (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <=XXREAL-0R1 0NUMBERSK6"
      and A2: "a <XXREAL-0R3 0NUMBERSK6"
    have "(a *XCMPLX-0K3 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))+XCMPLX-0K2 c <=XXREAL-0R1 0NUMBERSK6"
      using A1 sorry
    then have "((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6"
      using A2 quin_1_th_8 sorry
    then have A3: "((-XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))+XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6"
       sorry
    have "\<two>\<^sub>M *XCMPLX-0K3 a <>HIDDENR2 0NUMBERSK6"
      using A2 sorry
    then have "((-XCMPLX-0K4 b)+XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6"
      using A3 xcmplx_1_th_87 sorry
    then have "-XCMPLX-0K4 deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 -XCMPLX-0K4 0NUMBERSK6"
       sorry
    thus "deltaQUIN-1K1(a,b,c) <=XXREAL-0R1 0NUMBERSK6"
      using xreal_1_th_24 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quin_1_th_12:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ( for x be RealXREAL-0M1 holds (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >XXREAL-0R4 0NUMBERSK6) & a >XXREAL-0R4 0NUMBERSK6 implies deltaQUIN-1K1(a,b,c) <XXREAL-0R3 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ( for x be RealXREAL-0M1 holds (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >XXREAL-0R4 0NUMBERSK6) & a >XXREAL-0R4 0NUMBERSK6 implies  not deltaQUIN-1K1(a,b,c) <XXREAL-0R3 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: " for x be RealXREAL-0M1 holds (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >XXREAL-0R4 0NUMBERSK6"
      and A2: "a >XXREAL-0R4 0NUMBERSK6"
    have "(a *XCMPLX-0K3 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))+XCMPLX-0K2 c >XXREAL-0R4 0NUMBERSK6"
      using A1 sorry
    then have "((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6"
      using A2 quin_1_th_7 sorry
    then have A3: "((-XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))+XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6"
       sorry
    have "\<two>\<^sub>M *XCMPLX-0K3 a <>HIDDENR2 0NUMBERSK6"
      using A2 sorry
    then have "((-XCMPLX-0K4 b)+XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6"
      using A3 xcmplx_1_th_87 sorry
    then have "-XCMPLX-0K4 deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6"
       sorry
    thus " not deltaQUIN-1K1(a,b,c) <XXREAL-0R3 0NUMBERSK6"
      using xreal_1_th_58 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quin_1_th_13:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ( for x be RealXREAL-0M1 holds (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6) & a <XXREAL-0R3 0NUMBERSK6 implies deltaQUIN-1K1(a,b,c) <XXREAL-0R3 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ( for x be RealXREAL-0M1 holds (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6) & a <XXREAL-0R3 0NUMBERSK6 implies  not deltaQUIN-1K1(a,b,c) <XXREAL-0R3 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: " for x be RealXREAL-0M1 holds (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6"
      and A2: "a <XXREAL-0R3 0NUMBERSK6"
    have "(a *XCMPLX-0K3 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))+XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6"
      using A1 sorry
    then have "((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6"
      using A2 quin_1_th_9 sorry
    then have A3: "((-XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))+XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6"
       sorry
    have "\<two>\<^sub>M *XCMPLX-0K3 a <>HIDDENR2 0NUMBERSK6"
      using A2 sorry
    then have "((-XCMPLX-0K4 b)+XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6"
      using A3 xcmplx_1_th_87 sorry
    then have "-XCMPLX-0K4 deltaQUIN-1K1(a,b,c) >XXREAL-0R4 -XCMPLX-0K4 0NUMBERSK6"
       sorry
    thus " not deltaQUIN-1K1(a,b,c) <XXREAL-0R3 0NUMBERSK6"
      using xreal_1_th_24 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quin_1_th_14:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds  for x be ComplexXCMPLX-0M1 holds a <>HIDDENR2 0NUMBERSK6 & (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c =HIDDENR1 0NUMBERSK6 implies ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) =HIDDENR1 0NUMBERSK6"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix a assume [ty]: "a be ComplexXCMPLX-0M1"
  fix b assume [ty]: "b be ComplexXCMPLX-0M1"
  fix c assume [ty]: "c be ComplexXCMPLX-0M1"
  fix x assume [ty]: "x be ComplexXCMPLX-0M1"
  assume A1: "a <>HIDDENR2 0NUMBERSK6"
    and A2: "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c =HIDDENR1 0NUMBERSK6"
  have A3: "\<four>\<^sub>M *XCMPLX-0K3 a <>HIDDENR2 0NUMBERSK6"
    using A1 sorry
  have "a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a) =HIDDENR1 0NUMBERSK6"
    using A1 A2 quin_1_th_1 sorry
  then have A4: "((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a)) =HIDDENR1 0NUMBERSK6"
     sorry
  have "\<two>\<^sub>M *XCMPLX-0K3 a <>HIDDENR2 0NUMBERSK6"
    using A1 sorry
  then have "((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a)) =HIDDENR1 0NUMBERSK6"
    using A4 xcmplx_1_th_87 sorry
  thus "((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) =HIDDENR1 0NUMBERSK6"
    using A3 xcmplx_1_th_87 sorry
qed "sorry"

mlemma quin_1_lm_1:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds a ^2SQUARE-1K1 =HIDDENR1 b ^2SQUARE-1K1 implies a =HIDDENR1 b or a =HIDDENR1 -XCMPLX-0K4 b"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds a ^2SQUARE-1K1 =HIDDENR1 b ^2SQUARE-1K1 implies  not ( not a =HIDDENR1 b &  not a =HIDDENR1 -XCMPLX-0K4 b)"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix b assume [ty]: "b be ComplexXCMPLX-0M1"
    assume "a ^2SQUARE-1K1 =HIDDENR1 b ^2SQUARE-1K1"
    then have "(a +XCMPLX-0K2 b)*XCMPLX-0K3 (a -XCMPLX-0K6 b) =HIDDENR1 0NUMBERSK6"
       sorry
    then have "a +XCMPLX-0K2 b =HIDDENR1 0NUMBERSK6 or a -XCMPLX-0K6 b =HIDDENR1 0NUMBERSK6"
      using xcmplx_1_th_6 sorry
    thus " not ( not a =HIDDENR1 b &  not a =HIDDENR1 -XCMPLX-0K4 b)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quin_1_th_15:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6) & (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c =HIDDENR1 0NUMBERSK6 implies x =HIDDENR1 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) or x =HIDDENR1 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
proof-
  have " for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <>HIDDENR2 0NUMBERSK6 & (deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6 & (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c =HIDDENR1 0NUMBERSK6) implies  not ( not x =HIDDENR1 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) &  not x =HIDDENR1 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a <>HIDDENR2 0NUMBERSK6"
      and A2: "deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6"
      and A3: "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c =HIDDENR1 0NUMBERSK6"
    have "((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) =HIDDENR1 0NUMBERSK6"
      using A1 A3 quin_1_th_14 sorry
    then have "((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1 =HIDDENR1 (sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))^2SQUARE-1K1"
      using A2 square_1_def_2 sorry
    then have A4: "(\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b =HIDDENR1 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)) or (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b =HIDDENR1 -XCMPLX-0K4 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c))"
      using quin_1_lm_1 sorry
    have "\<two>\<^sub>M *XCMPLX-0K3 a <>HIDDENR2 0NUMBERSK6"
      using A1 sorry
    thus " not ( not x =HIDDENR1 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) &  not x =HIDDENR1 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
      using A4 xcmplx_1_th_89 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quin_1_th_16:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <>HIDDENR2 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6 implies (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c =HIDDENR1 (a *XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))*XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
proof-
  have " for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <>HIDDENR2 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6 implies (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c =HIDDENR1 (a *XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))*XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a <>HIDDENR2 0NUMBERSK6"
      and A2: "deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6"
    have "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c =HIDDENR1 a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 (deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))"
      using A1 quin_1_th_1 sorry
    also have "... = a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 (a *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a))*XCMPLX-0K3 (deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))"
      using A1 xcmplx_1_th_106 sorry
    also have "... = a *XCMPLX-0K3 ((x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a)))"
       sorry
    also have "... = a *XCMPLX-0K3 ((x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 (deltaQUIN-1K1(a,b,c) *XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 ((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 a))"
      using xcmplx_1_th_76 sorry
    also have "... = a *XCMPLX-0K3 ((x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 (sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))^2SQUARE-1K1 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1)"
      using A2 square_1_def_2 sorry
    also have "... = a *XCMPLX-0K3 ((x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 (sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1)"
      using xcmplx_1_th_76 sorry
    also have "... = (a *XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))))*XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))"
       sorry
    also have "... = (a *XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))))*XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))"
      using xcmplx_1_th_187 sorry
    also have "... = (a *XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))))*XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))"
      using xcmplx_1_th_187 sorry
    also have "... = (a *XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))*XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))"
      using xcmplx_1_th_62 sorry
    also have "... = (a *XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))*XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
      using xcmplx_1_th_120 sorry
    finally have "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c =HIDDENR1 (a *XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))*XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
       sorry
    thus "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c =HIDDENR1 (a *XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))*XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quin_1_th_17:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6 implies ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6 implies  not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a <XXREAL-0R3 0NUMBERSK6"
      and A2: "deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6"
    have "sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)) >XXREAL-0R4 0NUMBERSK6"
      using A2 square_1_th_25 sorry
    then have "\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)) >XXREAL-0R4 0NUMBERSK6"
      using xreal_1_th_129 sorry
    then have "sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)) +XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)) >XXREAL-0R4 0NUMBERSK6"
       sorry
    then have "sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)) >XXREAL-0R4 -XCMPLX-0K4 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c))"
      using xreal_1_th_59 sorry
    then have A3: "(-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)) >XXREAL-0R4 (-XCMPLX-0K4 b)+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))"
      using xreal_1_th_6 sorry
    have "\<two>\<^sub>M *XCMPLX-0K3 a <XXREAL-0R3 0NUMBERSK6"
      using A1 xreal_1_th_132 sorry
    thus " not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
      using A3 xreal_1_th_75 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quin_1_th_18:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6 implies ((a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >XXREAL-0R4 0NUMBERSK6 iff ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 x & x <XXREAL-0R3 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
proof-
  have " for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6 implies ((a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >XXREAL-0R4 0NUMBERSK6 implies ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 x & x <XXREAL-0R3 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) & (((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 x & x <XXREAL-0R3 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) implies  not (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >XXREAL-0R4 0NUMBERSK6)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a <XXREAL-0R3 0NUMBERSK6"
      and A2: "deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6"
    show "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >XXREAL-0R4 0NUMBERSK6 implies ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 x & x <XXREAL-0R3 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
    proof-
      have "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >XXREAL-0R4 0NUMBERSK6 implies  not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 x &  not x <XXREAL-0R3 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
      proof(rule impI)
        assume "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >XXREAL-0R4 0NUMBERSK6"
        then have "(a *XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))*XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) >XXREAL-0R4 0NUMBERSK6"
          using A1 A2 quin_1_th_16 sorry
        then have "a *XCMPLX-0K3 ((x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) >XXREAL-0R4 0NUMBERSK6"
           sorry
        then have "(x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) <XXREAL-0R3 (0NUMBERSK6)/XCMPLX-0K7 a"
          using A1 xreal_1_th_84 sorry
        then have "x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 & x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 or x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 & x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6"
          using xreal_1_th_133 sorry
        then have "(x >XXREAL-0R4 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) & x <XXREAL-0R3 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) & ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) or x <XXREAL-0R3 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) & x >XXREAL-0R4 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
          using A1 A2 quin_1_th_17 xreal_1_th_47 xreal_1_th_48 sorry
        thus " not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 x &  not x <XXREAL-0R3 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
          using xxreal_0_th_2 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume "((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 x & x <XXREAL-0R3 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
    then have "x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 & x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6"
      using xreal_1_th_49 xreal_1_th_50 sorry
    then have "(x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) <XXREAL-0R3 0NUMBERSK6"
      using xreal_1_th_132 sorry
    then have "a *XCMPLX-0K3 ((x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) >XXREAL-0R4 0NUMBERSK6"
      using A1 xreal_1_th_130 sorry
    then have "(a *XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))*XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) >XXREAL-0R4 0NUMBERSK6"
       sorry
    thus " not (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >XXREAL-0R4 0NUMBERSK6"
      using A1 A2 quin_1_th_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quin_1_th_19:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6 implies ((a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6 iff x <XXREAL-0R3 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) or x >XXREAL-0R4 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
proof-
  have " for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6 implies ((a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6 implies x <XXREAL-0R3 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) or x >XXREAL-0R4 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) & (x <XXREAL-0R3 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) or x >XXREAL-0R4 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) implies  not (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a <XXREAL-0R3 0NUMBERSK6"
      and A2: "deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6"
    show "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6 implies x <XXREAL-0R3 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) or x >XXREAL-0R4 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
    proof-
      have "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6 implies  not (x <XXREAL-0R3 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) & x >XXREAL-0R4 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
      proof(rule impI)
        assume "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6"
        then have "(a *XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))*XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) <XXREAL-0R3 0NUMBERSK6"
          using A1 A2 quin_1_th_16 sorry
        then have "a *XCMPLX-0K3 ((x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) <XXREAL-0R3 0NUMBERSK6"
           sorry
        then have "(x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) >XXREAL-0R4 (0NUMBERSK6)/XCMPLX-0K7 a"
          using A1 xreal_1_th_82 sorry
        then have "x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 & x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 or x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 & x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6"
          using xreal_1_th_134 sorry
        thus " not (x <XXREAL-0R3 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) & x >XXREAL-0R4 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
          using xreal_1_th_47 xreal_1_th_48 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume "x <XXREAL-0R3 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) or x >XXREAL-0R4 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
    then have A3: "x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 or x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6"
      using xreal_1_th_49 xreal_1_th_50 sorry
    have "((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
      using A1 A2 quin_1_th_17 sorry
    then have "x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
      using xreal_1_th_10 sorry
    then have "x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 & x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 or x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 & x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6"
      using A3 xxreal_0_th_2 sorry
    then have "(x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) >XXREAL-0R4 0NUMBERSK6"
      using xreal_1_th_129 xreal_1_th_130 sorry
    then have "a *XCMPLX-0K3 ((x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) <XXREAL-0R3 0NUMBERSK6"
      using A1 xreal_1_th_132 sorry
    then have "(a *XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))*XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) <XXREAL-0R3 0NUMBERSK6"
       sorry
    thus " not (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6"
      using A1 A2 quin_1_th_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quin_1_th_20:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds  for x be ComplexXCMPLX-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) =HIDDENR1 0NUMBERSK6) & (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c =HIDDENR1 0NUMBERSK6 implies x =HIDDENR1 -XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds  for x be ComplexXCMPLX-0M1 holds a <>HIDDENR2 0NUMBERSK6 & (deltaQUIN-1K1(a,b,c) =HIDDENR1 0NUMBERSK6 & (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c =HIDDENR1 0NUMBERSK6) implies x =HIDDENR1 -XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix b assume [ty]: "b be ComplexXCMPLX-0M1"
    fix c assume [ty]: "c be ComplexXCMPLX-0M1"
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    assume A1: "a <>HIDDENR2 0NUMBERSK6"
      and A2: "deltaQUIN-1K1(a,b,c) =HIDDENR1 0NUMBERSK6 & (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c =HIDDENR1 0NUMBERSK6"
    have "((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 0NUMBERSK6 =HIDDENR1 0NUMBERSK6"
      using A1 A2 quin_1_th_14 sorry
    then have A3: "(\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b =HIDDENR1 0NUMBERSK6"
      using xcmplx_1_th_6 sorry
    have "\<two>\<^sub>M *XCMPLX-0K3 a <>HIDDENR2 0NUMBERSK6"
      using A1 sorry
    then have "x =HIDDENR1 (-XCMPLX-0K4 b)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
      using A3 xcmplx_1_th_89 sorry
    thus "x =HIDDENR1 -XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
      using xcmplx_1_th_187 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quin_1_th_21:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6 implies (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >XXREAL-0R4 0NUMBERSK6"
proof-
  have " for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6 implies  not (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >XXREAL-0R4 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6"
    have "\<four>\<^sub>M *XCMPLX-0K3 a <>HIDDENR2 0NUMBERSK6"
      using A1 sorry
    then have A3: "((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a)) >XXREAL-0R4 0NUMBERSK6"
      using A2 xcmplx_1_th_87 sorry
    have "\<two>\<^sub>M *XCMPLX-0K3 a <>HIDDENR2 0NUMBERSK6"
      using A1 sorry
    then have "((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a)) >XXREAL-0R4 0NUMBERSK6"
      using A3 xcmplx_1_th_87 sorry
    then have A4: "(\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a)) >XXREAL-0R4 0NUMBERSK6"
       sorry
    have "\<four>\<^sub>M *XCMPLX-0K3 a >XXREAL-0R4 0NUMBERSK6"
      using A1 xreal_1_th_129 sorry
    then have "a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 (0NUMBERSK6)/XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a)"
      using A4 xreal_1_th_83 sorry
    thus " not (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >XXREAL-0R4 0NUMBERSK6"
      using A1 quin_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quin_1_th_22:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) =HIDDENR1 0NUMBERSK6 implies ((a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >XXREAL-0R4 0NUMBERSK6 iff x <>HIDDENR2 -XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
proof-
  have " for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) =HIDDENR1 0NUMBERSK6 implies ((a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >XXREAL-0R4 0NUMBERSK6 implies x <>HIDDENR2 -XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) & (x <>HIDDENR2 -XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) implies  not (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >XXREAL-0R4 0NUMBERSK6)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "deltaQUIN-1K1(a,b,c) =HIDDENR1 0NUMBERSK6"
    have A3: "\<two>\<^sub>M *XCMPLX-0K3 a <>HIDDENR2 0NUMBERSK6"
      using A1 sorry
    show "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >XXREAL-0R4 0NUMBERSK6 implies x <>HIDDENR2 -XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
    proof-
      have "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >XXREAL-0R4 0NUMBERSK6 implies  not x <>HIDDENR2 -XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
      proof(rule impI)
        assume "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >XXREAL-0R4 0NUMBERSK6"
        then have "((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 0NUMBERSK6 >XXREAL-0R4 0NUMBERSK6"
          using A1 A2 quin_1_th_7 sorry
        then have "(\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x <>HIDDENR2 -XCMPLX-0K4 b"
           sorry
        then have "x <>HIDDENR2 (-XCMPLX-0K4 b)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
          using A3 xcmplx_1_th_87 sorry
        thus " not x <>HIDDENR2 -XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
          using xcmplx_1_th_187 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume "x <>HIDDENR2 -XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
    then have "x <>HIDDENR2 (-XCMPLX-0K4 b)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
      using xcmplx_1_th_187 sorry
    then have "(\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b <>HIDDENR2 0NUMBERSK6"
      using A3 xcmplx_1_th_89 sorry
    then have "((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6"
      using A2 square_1_th_12 sorry
    thus " not (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >XXREAL-0R4 0NUMBERSK6"
      using A1 quin_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quin_1_th_23:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6 implies (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6"
proof-
  have " for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6 implies  not (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a <XXREAL-0R3 0NUMBERSK6"
      and A2: "((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6"
    have "\<four>\<^sub>M *XCMPLX-0K3 a <>HIDDENR2 0NUMBERSK6"
      using A1 sorry
    then have A3: "((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a)) >XXREAL-0R4 0NUMBERSK6"
      using A2 xcmplx_1_th_87 sorry
    have "\<two>\<^sub>M *XCMPLX-0K3 a <>HIDDENR2 0NUMBERSK6"
      using A1 sorry
    then have "((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a)) >XXREAL-0R4 0NUMBERSK6"
      using A3 xcmplx_1_th_87 sorry
    then have A4: "(\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a)) >XXREAL-0R4 0NUMBERSK6"
       sorry
    have "\<four>\<^sub>M *XCMPLX-0K3 a <XXREAL-0R3 0NUMBERSK6"
      using A1 xreal_1_th_132 sorry
    then have "a *XCMPLX-0K3 (x +XCMPLX-0K2 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 (0NUMBERSK6)/XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a)"
      using A4 xreal_1_th_84 sorry
    thus " not (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6"
      using A1 quin_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quin_1_th_24:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) =HIDDENR1 0NUMBERSK6 implies ((a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6 iff x <>HIDDENR2 -XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
proof-
  have " for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) =HIDDENR1 0NUMBERSK6 implies ((a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6 implies x <>HIDDENR2 -XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) & (x <>HIDDENR2 -XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) implies  not (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a <XXREAL-0R3 0NUMBERSK6"
      and A2: "deltaQUIN-1K1(a,b,c) =HIDDENR1 0NUMBERSK6"
    have A3: "\<two>\<^sub>M *XCMPLX-0K3 a <>HIDDENR2 0NUMBERSK6"
      using A1 sorry
    show "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6 implies x <>HIDDENR2 -XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
    proof-
      have "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6 implies  not x <>HIDDENR2 -XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
      proof(rule impI)
        assume "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6"
        then have "((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 0NUMBERSK6 >XXREAL-0R4 0NUMBERSK6"
          using A1 A2 quin_1_th_9 sorry
        then have "(\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x <>HIDDENR2 -XCMPLX-0K4 b"
           sorry
        then have "x <>HIDDENR2 (-XCMPLX-0K4 b)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
          using A3 xcmplx_1_th_87 sorry
        thus " not x <>HIDDENR2 -XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
          using xcmplx_1_th_187 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume "x <>HIDDENR2 -XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
    then have "x <>HIDDENR2 (-XCMPLX-0K4 b)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
      using xcmplx_1_th_187 sorry
    then have "(\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b <>HIDDENR2 0NUMBERSK6"
      using A3 xcmplx_1_th_89 sorry
    then have "((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6"
      using A2 square_1_th_12 sorry
    thus " not (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6"
      using A1 quin_1_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quin_1_th_25:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6 implies ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6 implies  not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6"
    have "sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)) >XXREAL-0R4 0NUMBERSK6"
      using A2 square_1_th_25 sorry
    then have "\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)) >XXREAL-0R4 0NUMBERSK6"
      using xreal_1_th_129 sorry
    then have "sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)) +XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)) >XXREAL-0R4 0NUMBERSK6"
       sorry
    then have "sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)) >XXREAL-0R4 -XCMPLX-0K4 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c))"
      using xreal_1_th_59 sorry
    then have A3: "(-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)) >XXREAL-0R4 (-XCMPLX-0K4 b)+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))"
      using xreal_1_th_6 sorry
    have "\<two>\<^sub>M *XCMPLX-0K3 a >XXREAL-0R4 0NUMBERSK6"
      using A1 xreal_1_th_129 sorry
    thus " not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
      using A3 xreal_1_th_74 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quin_1_th_26:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6 implies ((a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6 iff ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 x & x <XXREAL-0R3 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
proof-
  have " for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6 implies ((a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6 implies ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 x & x <XXREAL-0R3 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) & (((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 x & x <XXREAL-0R3 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) implies  not (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6"
    show "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6 implies ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 x & x <XXREAL-0R3 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
    proof-
      have "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6 implies  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 x &  not x <XXREAL-0R3 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
      proof(rule impI)
        assume "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6"
        then have "(a *XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))*XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) <XXREAL-0R3 0NUMBERSK6"
          using A1 A2 quin_1_th_16 sorry
        then have "a *XCMPLX-0K3 ((x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) <XXREAL-0R3 0NUMBERSK6"
           sorry
        then have "(x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) <XXREAL-0R3 (0NUMBERSK6)/XCMPLX-0K7 a"
          using A1 xreal_1_th_81 sorry
        then have "x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 & x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 or x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 & x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6"
          using xreal_1_th_133 sorry
        then have "x >XXREAL-0R4 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) & x <XXREAL-0R3 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) or (((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) & x <XXREAL-0R3 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) & x >XXREAL-0R4 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
          using A1 A2 quin_1_th_25 xreal_1_th_47 xreal_1_th_48 sorry
        thus " not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 x &  not x <XXREAL-0R3 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
          using xxreal_0_th_2 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume "((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 x & x <XXREAL-0R3 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
    then have "x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 & x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6"
      using xreal_1_th_49 xreal_1_th_50 sorry
    then have "(x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) <XXREAL-0R3 0NUMBERSK6"
      using xreal_1_th_132 sorry
    then have "a *XCMPLX-0K3 ((x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) <XXREAL-0R3 0NUMBERSK6"
      using A1 xreal_1_th_132 sorry
    then have "(a *XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))*XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) <XXREAL-0R3 0NUMBERSK6"
       sorry
    thus " not (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6"
      using A1 A2 quin_1_th_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quin_1_th_27:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6 implies ((a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >XXREAL-0R4 0NUMBERSK6 iff x <XXREAL-0R3 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) or x >XXREAL-0R4 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
proof-
  have " for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6 implies ((a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >XXREAL-0R4 0NUMBERSK6 implies x <XXREAL-0R3 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) or x >XXREAL-0R4 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) & (x <XXREAL-0R3 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) or x >XXREAL-0R4 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) implies  not (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >XXREAL-0R4 0NUMBERSK6)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6"
    show "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >XXREAL-0R4 0NUMBERSK6 implies x <XXREAL-0R3 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) or x >XXREAL-0R4 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
    proof-
      have "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >XXREAL-0R4 0NUMBERSK6 implies  not (x <XXREAL-0R3 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) & x >XXREAL-0R4 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
      proof(rule impI)
        assume "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >XXREAL-0R4 0NUMBERSK6"
        then have "(a *XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))*XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) >XXREAL-0R4 0NUMBERSK6"
          using A1 A2 quin_1_th_16 sorry
        then have "a *XCMPLX-0K3 ((x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) >XXREAL-0R4 0NUMBERSK6"
           sorry
        then have "(x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) >XXREAL-0R4 (0NUMBERSK6)/XCMPLX-0K7 a"
          using A1 xreal_1_th_83 sorry
        then have "x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 & x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 or x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 & x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6"
          using xreal_1_th_134 sorry
        thus " not (x <XXREAL-0R3 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) & x >XXREAL-0R4 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
          using xreal_1_th_47 xreal_1_th_48 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume "x <XXREAL-0R3 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) or x >XXREAL-0R4 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
    then have A3: "x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 or x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6"
      using xreal_1_th_49 xreal_1_th_50 sorry
    have "((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
      using A1 A2 quin_1_th_25 sorry
    then have "x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
      using xreal_1_th_10 sorry
    then have "x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 & x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 or x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 & x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6"
      using A3 xxreal_0_th_2 sorry
    then have "(x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) >XXREAL-0R4 0NUMBERSK6"
      using xreal_1_th_129 xreal_1_th_130 sorry
    then have "a *XCMPLX-0K3 ((x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) >XXREAL-0R4 0NUMBERSK6"
      using A1 xreal_1_th_129 sorry
    then have "(a *XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))*XCMPLX-0K3 (x -XCMPLX-0K6 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) >XXREAL-0R4 0NUMBERSK6"
       sorry
    thus " not (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c >XXREAL-0R4 0NUMBERSK6"
      using A1 A2 quin_1_th_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
