theory xxreal_1
  imports membered xreal_1
begin
(*begin*)
reserve x for "setHIDDENM2"
reserve p, q, r, s, t, u for "ExtRealXXREAL-0M1"
reserve g for "RealXREAL-0M1"
reserve a for "ElementSUBSET-1M1-of ExtREALXXREAL-0K3"
theorem xxreal_1_sch_1:
  fixes Pp1 Qp1 
  assumes
    A1: " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds Pp1(r) & Qp1(s) implies r <=XXREAL-0R1 s"
  shows " ex s be ExtRealXXREAL-0M1 st ( for r be ExtRealXXREAL-0M1 holds Pp1(r) implies r <=XXREAL-0R1 s) & ( for r be ExtRealXXREAL-0M1 holds Qp1(r) implies s <=XXREAL-0R1 r)"
  proof-
    have " ex tVar1 be ExtRealXXREAL-0M1 st ( for r be ExtRealXXREAL-0M1 holds Pp1(r) implies r <=XXREAL-0R1 tVar1) & ( for r be ExtRealXXREAL-0M1 holds  not (Qp1(r) &  not tVar1 <=XXREAL-0R1 r))"
    proof-
      let ?A = "{a where a be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 : Pp1(a) }"
      let ?B = "{a where a be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 : Qp1(a) }"
      obtain X Y where 
        [ty]:"X be SubsetSUBSET-1M2-of REALNUMBERSK2" and XDef:"X = ?A /\\XBOOLE-0K3 REALNUMBERSK2" and
        [ty]:"Y be SubsetSUBSET-1M2-of REALNUMBERSK2" and YDef:"Y = ?B /\\XBOOLE-0K3 REALNUMBERSK2"
        using xboole_1_th_17 sorry
      show " ex tVar1 be ExtRealXXREAL-0M1 st ( for r be ExtRealXXREAL-0M1 holds Pp1(r) implies r <=XXREAL-0R1 tVar1) & ( for r be ExtRealXXREAL-0M1 holds  not (Qp1(r) &  not tVar1 <=XXREAL-0R1 r))"
      proof-
        have cases: "(X =MEMBEREDR9 {}XBOOLE-0K1 or Y =MEMBEREDR9 {}XBOOLE-0K1) or X <>HIDDENR2 {}XBOOLE-0K1 & Y <>HIDDENR2 {}XBOOLE-0K1"
           sorry
        have case1: "X =MEMBEREDR9 {}XBOOLE-0K1 implies ( ex tVar1 be ExtRealXXREAL-0M1 st ( for r be ExtRealXXREAL-0M1 holds Pp1(r) implies r <=XXREAL-0R1 tVar1) & ( for r be ExtRealXXREAL-0M1 holds  not (Qp1(r) &  not tVar1 <=XXREAL-0R1 r)))"
        proof(rule impI)
          assume A2: "X =MEMBEREDR9 {}XBOOLE-0K1"
          show " ex tVar1 be ExtRealXXREAL-0M1 st ( for r be ExtRealXXREAL-0M1 holds Pp1(r) implies r <=XXREAL-0R1 tVar1) & ( for r be ExtRealXXREAL-0M1 holds  not (Qp1(r) &  not tVar1 <=XXREAL-0R1 r))"
          proof-
            have cases: "+inftyXXREAL-0K1 inHIDDENR3 ?A or  not +inftyXXREAL-0K1 inHIDDENR3 ?A"
               sorry
            have case1: "+inftyXXREAL-0K1 inHIDDENR3 {a where a be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 : Pp1(a) } implies ( ex tVar1 be ExtRealXXREAL-0M1 st ( for r be ExtRealXXREAL-0M1 holds Pp1(r) implies r <=XXREAL-0R1 tVar1) & ( for r be ExtRealXXREAL-0M1 holds  not (Qp1(r) &  not tVar1 <=XXREAL-0R1 r)))"
            proof(rule impI)
              assume A3: "+inftyXXREAL-0K1 inHIDDENR3 ?A"
              show " ex tVar1 be ExtRealXXREAL-0M1 st ( for r be ExtRealXXREAL-0M1 holds Pp1(r) implies r <=XXREAL-0R1 tVar1) & ( for r be ExtRealXXREAL-0M1 holds  not (Qp1(r) &  not tVar1 <=XXREAL-0R1 r))"
              proof(rule bexI[of _ "+inftyXXREAL-0K1"],rule conjMI)
                show " for r be ExtRealXXREAL-0M1 holds Pp1(r) implies r <=XXREAL-0R1 +inftyXXREAL-0K1"
                  using xxreal_0_th_3 sorry
                have " ex a be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st a =HIDDENR1 +inftyXXREAL-0K1 & Pp1(a)"
                  using A3 sorry
                thus " for r be ExtRealXXREAL-0M1 holds  not (Qp1(r) &  not +inftyXXREAL-0K1 <=XXREAL-0R1 r)"
                  using A1 sorry
              qed "sorry"
            qed
            have case2: " not +inftyXXREAL-0K1 inHIDDENR3 {a where a be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 : Pp1(a) } implies ( ex tVar2 be ExtRealXXREAL-0M1 st ( for r be ExtRealXXREAL-0M1 holds Pp1(r) implies r <=XXREAL-0R1 tVar2) & ( for r be ExtRealXXREAL-0M1 holds  not (Qp1(r) &  not tVar2 <=XXREAL-0R1 r)))"
            proof(rule impI)
              assume A4: " not +inftyXXREAL-0K1 inHIDDENR3 ?A"
              show " ex tVar2 be ExtRealXXREAL-0M1 st ( for r be ExtRealXXREAL-0M1 holds Pp1(r) implies r <=XXREAL-0R1 tVar2) & ( for r be ExtRealXXREAL-0M1 holds  not (Qp1(r) &  not tVar2 <=XXREAL-0R1 r))"
              proof(rule bexI[of _ "-inftyXXREAL-0K2"],rule conjMI)
                show " for r be ExtRealXXREAL-0M1 holds Pp1(r) implies r <=XXREAL-0R1 -inftyXXREAL-0K2"
                proof(rule ballI,rule impI)
                  fix r assume [ty]: "r be ExtRealXXREAL-0M1"
                  assume A5: "Pp1(r)"
                  have "r inHIDDENR3 ExtREALXXREAL-0K3"
                    using xxreal_0_def_1 sorry
                  then have A6: "r inHIDDENR3 ?A"
                    using A5 sorry
                  show "r <=XXREAL-0R1 -inftyXXREAL-0K2"
                  proof-
                    have cases: "r =HIDDENR1 -inftyXXREAL-0K2 or r inHIDDENR3 REALNUMBERSK2"
                      using A4 A6 xxreal_0_th_14 sorry
                    have case1: "r =HIDDENR1 -inftyXXREAL-0K2 implies r <=XXREAL-0R1 -inftyXXREAL-0K2"
                    proof(rule impI)
                      assume "r =HIDDENR1 -inftyXXREAL-0K2"
                      thus "r <=XXREAL-0R1 -inftyXXREAL-0K2"
                         sorry
                    qed
                    have case2: "r inHIDDENR3 REALNUMBERSK2 implies r <=XXREAL-0R1 -inftyXXREAL-0K2"
                    proof(rule impI)
                      assume "r inHIDDENR3 REALNUMBERSK2"
                      thus "r <=XXREAL-0R1 -inftyXXREAL-0K2"
                        using A2 A6 xboole_0_def_4 sorry
                    qed
                    show " ?thesis "
                      using cases case1 case2 sorry
                  qed
                qed "sorry"
                show " for r be ExtRealXXREAL-0M1 holds  not (Qp1(r) &  not -inftyXXREAL-0K2 <=XXREAL-0R1 r)"
                  using xxreal_0_th_5 sorry
              qed "sorry"
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        have case2: "Y =MEMBEREDR9 {}XBOOLE-0K1 implies ( ex tVar3 be ExtRealXXREAL-0M1 st ( for r be ExtRealXXREAL-0M1 holds Pp1(r) implies r <=XXREAL-0R1 tVar3) & ( for r be ExtRealXXREAL-0M1 holds  not (Qp1(r) &  not tVar3 <=XXREAL-0R1 r)))"
        proof(rule impI)
          assume A7: "Y =MEMBEREDR9 {}XBOOLE-0K1"
          show " ex tVar3 be ExtRealXXREAL-0M1 st ( for r be ExtRealXXREAL-0M1 holds Pp1(r) implies r <=XXREAL-0R1 tVar3) & ( for r be ExtRealXXREAL-0M1 holds  not (Qp1(r) &  not tVar3 <=XXREAL-0R1 r))"
          proof-
            have cases: "-inftyXXREAL-0K2 inHIDDENR3 ?B or  not -inftyXXREAL-0K2 inHIDDENR3 ?B"
               sorry
            have case1: "-inftyXXREAL-0K2 inHIDDENR3 {a where a be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 : Qp1(a) } implies ( ex tVar3 be ExtRealXXREAL-0M1 st ( for r be ExtRealXXREAL-0M1 holds Pp1(r) implies r <=XXREAL-0R1 tVar3) & ( for r be ExtRealXXREAL-0M1 holds  not (Qp1(r) &  not tVar3 <=XXREAL-0R1 r)))"
            proof(rule impI)
              assume A8: "-inftyXXREAL-0K2 inHIDDENR3 ?B"
              show " ex tVar3 be ExtRealXXREAL-0M1 st ( for r be ExtRealXXREAL-0M1 holds Pp1(r) implies r <=XXREAL-0R1 tVar3) & ( for r be ExtRealXXREAL-0M1 holds  not (Qp1(r) &  not tVar3 <=XXREAL-0R1 r))"
              proof(rule bexI[of _ "-inftyXXREAL-0K2"],rule conjMI)
                have " ex a be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st a =HIDDENR1 -inftyXXREAL-0K2 & Qp1(a)"
                  using A8 sorry
                thus " for r be ExtRealXXREAL-0M1 holds Pp1(r) implies r <=XXREAL-0R1 -inftyXXREAL-0K2"
                  using A1 sorry
                show " for r be ExtRealXXREAL-0M1 holds  not (Qp1(r) &  not -inftyXXREAL-0K2 <=XXREAL-0R1 r)"
                  using xxreal_0_th_5 sorry
              qed "sorry"
            qed
            have case2: " not -inftyXXREAL-0K2 inHIDDENR3 ?B implies ( ex tVar4 be ExtRealXXREAL-0M1 st ( for r be ExtRealXXREAL-0M1 holds Pp1(r) implies r <=XXREAL-0R1 tVar4) & ( for r be ExtRealXXREAL-0M1 holds Qp1(r) implies tVar4 <=XXREAL-0R1 r))"
            proof(rule impI)
              assume A9: " not -inftyXXREAL-0K2 inHIDDENR3 ?B"
              show " ex tVar4 be ExtRealXXREAL-0M1 st ( for r be ExtRealXXREAL-0M1 holds Pp1(r) implies r <=XXREAL-0R1 tVar4) & ( for r be ExtRealXXREAL-0M1 holds Qp1(r) implies tVar4 <=XXREAL-0R1 r)"
              proof(rule bexI[of _ "+inftyXXREAL-0K1"],rule conjMI,rule ballI,rule impI)
                show " for r be ExtRealXXREAL-0M1 holds Pp1(r) implies r <=XXREAL-0R1 +inftyXXREAL-0K1"
                  using xxreal_0_th_3 sorry
                fix r assume [ty]: "r be ExtRealXXREAL-0M1"
                assume A10: "Qp1(r)"
                have "r inHIDDENR3 ExtREALXXREAL-0K3"
                  using xxreal_0_def_1 sorry
                then have A11: "r inHIDDENR3 ?B"
                  using A10 sorry
                show "+inftyXXREAL-0K1 <=XXREAL-0R1 r"
                proof-
                  have cases: "r =HIDDENR1 +inftyXXREAL-0K1 or r inHIDDENR3 REALNUMBERSK2"
                    using A9 A11 xxreal_0_th_14 sorry
                  have case1: "r =HIDDENR1 +inftyXXREAL-0K1 implies +inftyXXREAL-0K1 <=XXREAL-0R1 r"
                  proof(rule impI)
                    assume "r =HIDDENR1 +inftyXXREAL-0K1"
                    thus "+inftyXXREAL-0K1 <=XXREAL-0R1 r"
                       sorry
                  qed
                  have case2: "r inHIDDENR3 REALNUMBERSK2 implies +inftyXXREAL-0K1 <=XXREAL-0R1 r"
                  proof(rule impI)
                    assume "r inHIDDENR3 REALNUMBERSK2"
                    thus "+inftyXXREAL-0K1 <=XXREAL-0R1 r"
                      using A7 A11 xboole_0_def_4 sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed "sorry"
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        have case3: "X <>HIDDENR2 {}XBOOLE-0K1 & Y <>HIDDENR2 {}XBOOLE-0K1 implies ( ex tVar5 be ExtRealXXREAL-0M1 st ( for r be ExtRealXXREAL-0M1 holds Pp1(r) implies r <=XXREAL-0R1 tVar5) & ( for r be ExtRealXXREAL-0M1 holds Qp1(r) implies tVar5 <=XXREAL-0R1 r))"
        proof(rule impMI ,rule impI)
          assume A12: "X <>HIDDENR2 {}XBOOLE-0K1"
            and A13: "Y <>HIDDENR2 {}XBOOLE-0K1"
          have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies x <=XXREAL-0R1 y"
          proof-
            have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x inHIDDENR3 X implies (y inHIDDENR3 Y implies x <=XXREAL-0R1 y)"
            proof(rule ballI,rule ballI,rule impI,rule impI)
              fix x assume [ty]: "x be RealXREAL-0M1"
              fix y assume [ty]: "y be RealXREAL-0M1"
              assume "x inHIDDENR3 X"
              then have "x inHIDDENR3 ?A"
                using xboole_0_def_4 sorry
              then have A14: " ex a be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st a =HIDDENR1 x & Pp1(a)"
                 sorry
              assume "y inHIDDENR3 Y"
              then have "y inHIDDENR3 ?B"
                using xboole_0_def_4 sorry
              then have " ex a be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st a =HIDDENR1 y & Qp1(a)"
                 sorry
              thus "x <=XXREAL-0R1 y"
                using A1 A14 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          then obtain s where
            [ty]:"s be RealXREAL-0M1" and 
            A15: " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies x <=XXREAL-0R1 s & s <=XXREAL-0R1 y"
            using axioms_th_1 sorry
          have 
            [ty]:"s be ExtRealXXREAL-0M1"
             sorry
          show " ex tVar5 be ExtRealXXREAL-0M1 st ( for r be ExtRealXXREAL-0M1 holds Pp1(r) implies r <=XXREAL-0R1 tVar5) & ( for r be ExtRealXXREAL-0M1 holds Qp1(r) implies tVar5 <=XXREAL-0R1 r)"
          proof(rule bexI[of _ "s"],rule conjMI,rule ballI,rule impI)
            show " for r be ExtRealXXREAL-0M1 holds Pp1(r) implies r <=XXREAL-0R1 s"
            proof(rule ballI,rule impI)
              fix r assume [ty]: "r be ExtRealXXREAL-0M1"
              obtain x where
                [ty]:"x be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                A16: "x inTARSKIR2 Y"
                using A13 sorry
              have "x inTARSKIR2 ?B"
                using A16 xboole_0_def_4 sorry
              then have A17: " ex a be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st x =XBOOLE-0R4 a & Qp1(a)"
                 sorry
              assume A18: "Pp1(r)"
              show "r <=XXREAL-0R1 s"
              proof-
                have cases: "r inHIDDENR3 REALNUMBERSK2 or r =HIDDENR1 -inftyXXREAL-0K2"
                  using A1 A17 A18 xxreal_0_th_13 sorry
                have case1: "r inHIDDENR3 REALNUMBERSK2 implies r <=XXREAL-0R1 s"
                proof(rule impI)
                  assume A19: "r inHIDDENR3 REALNUMBERSK2"
                  then have 
                    [ty]:"r be RealXREAL-0M1"
                     sorry
                  have "r be ElementSUBSET-1M1-of ExtREALXXREAL-0K3"
                    using xxreal_0_def_1 sorry
                  then have "r inHIDDENR3 ?A"
                    using A18 sorry
                  then have "r inHIDDENR3 X"
                    using A19 xboole_0_def_4 sorry
                  thus "r <=XXREAL-0R1 s"
                    using A15 A16 sorry
                qed
                have case2: "r =HIDDENR1 -inftyXXREAL-0K2 implies r <=XXREAL-0R1 s"
                proof(rule impI)
                  assume "r =HIDDENR1 -inftyXXREAL-0K2"
                  thus "r <=XXREAL-0R1 s"
                    using xxreal_0_th_5 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed "sorry"
            fix r assume [ty]: "r be ExtRealXXREAL-0M1"
            obtain x where
              [ty]:"x be ElementSUBSET-1M1-of REALNUMBERSK2" and 
              A20: "x inTARSKIR2 X"
              using A12 sorry
            have "x inTARSKIR2 ?A"
              using A20 xboole_0_def_4 sorry
            then have A21: " ex a be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st x =XBOOLE-0R4 a & Pp1(a)"
               sorry
            assume A22: "Qp1(r)"
            show "s <=XXREAL-0R1 r"
            proof-
              have cases: "r inHIDDENR3 REALNUMBERSK2 or r =HIDDENR1 +inftyXXREAL-0K1"
                using A1 A21 A22 xxreal_0_th_10 sorry
              have case1: "r inHIDDENR3 REALNUMBERSK2 implies s <=XXREAL-0R1 r"
              proof(rule impI)
                assume A23: "r inHIDDENR3 REALNUMBERSK2"
                then have 
                  [ty]:"r be RealXREAL-0M1"
                   sorry
                have "r be ElementSUBSET-1M1-of ExtREALXXREAL-0K3"
                  using xxreal_0_def_1 sorry
                then have "r inHIDDENR3 ?B"
                  using A22 sorry
                then have "r inHIDDENR3 Y"
                  using A23 xboole_0_def_4 sorry
                thus "s <=XXREAL-0R1 r"
                  using A15 A20 sorry
              qed
              have case2: "r =HIDDENR1 +inftyXXREAL-0K1 implies s <=XXREAL-0R1 r"
              proof(rule impI)
                assume "r =HIDDENR1 +inftyXXREAL-0K1"
                thus "s <=XXREAL-0R1 r"
                  using xxreal_0_th_3 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed "sorry"
        qed
        show " ?thesis "
          using cases case1 case2 case3 sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed

(*begin*)
mdef xxreal_1_def_1 ("[.XXREAL-1K1 _ , _ .]" [0,0]164 ) where
  mlet "r be ExtRealXXREAL-0M1", "s be ExtRealXXREAL-0M1"
"func [.XXREAL-1K1 r,s .] \<rightarrow> setHIDDENM2 equals
  {a where a be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 : r <=XXREAL-0R1 a & a <=XXREAL-0R1 s }"
proof-
  (*coherence*)
    show "{a where a be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 : r <=XXREAL-0R1 a & a <=XXREAL-0R1 s } be setHIDDENM2"
       sorry
qed "sorry"

mdef xxreal_1_def_2 ("[.XXREAL-1K2 _ , _ .[" [0,0]164 ) where
  mlet "r be ExtRealXXREAL-0M1", "s be ExtRealXXREAL-0M1"
"func [.XXREAL-1K2 r,s .[ \<rightarrow> setHIDDENM2 equals
  {a where a be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 : r <=XXREAL-0R1 a & a <XXREAL-0R3 s }"
proof-
  (*coherence*)
    show "{a where a be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 : r <=XXREAL-0R1 a & a <XXREAL-0R3 s } be setHIDDENM2"
       sorry
qed "sorry"

mdef xxreal_1_def_3 ("].XXREAL-1K3 _ , _ .]" [0,0]164 ) where
  mlet "r be ExtRealXXREAL-0M1", "s be ExtRealXXREAL-0M1"
"func ].XXREAL-1K3 r,s .] \<rightarrow> setHIDDENM2 equals
  {a where a be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 : r <XXREAL-0R3 a & a <=XXREAL-0R1 s }"
proof-
  (*coherence*)
    show "{a where a be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 : r <XXREAL-0R3 a & a <=XXREAL-0R1 s } be setHIDDENM2"
       sorry
qed "sorry"

mdef xxreal_1_def_4 ("].XXREAL-1K4 _ , _ .[" [0,0]164 ) where
  mlet "r be ExtRealXXREAL-0M1", "s be ExtRealXXREAL-0M1"
"func ].XXREAL-1K4 r,s .[ \<rightarrow> setHIDDENM2 equals
  {a where a be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 : r <XXREAL-0R3 a & a <XXREAL-0R3 s }"
proof-
  (*coherence*)
    show "{a where a be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 : r <XXREAL-0R3 a & a <XXREAL-0R3 s } be setHIDDENM2"
       sorry
qed "sorry"

mtheorem xxreal_1_th_1:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 [.XXREAL-1K1 r,s .] iff r <=XXREAL-0R1 t & t <=XXREAL-0R1 s"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 [.XXREAL-1K1 r,s .] implies r <=XXREAL-0R1 t & t <=XXREAL-0R1 s) &  not ((r <=XXREAL-0R1 t & t <=XXREAL-0R1 s) &  not t inHIDDENR3 [.XXREAL-1K1 r,s .])"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    show "t inHIDDENR3 [.XXREAL-1K1 r,s .] implies r <=XXREAL-0R1 t & t <=XXREAL-0R1 s"
    proof(rule impI)
      assume "t inHIDDENR3 [.XXREAL-1K1 r,s .]"
      then have " ex a be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st (a =HIDDENR1 t & r <=XXREAL-0R1 a) & a <=XXREAL-0R1 s"
         sorry
      thus "r <=XXREAL-0R1 t & t <=XXREAL-0R1 s"
         sorry
    qed
    have "t be ElementSUBSET-1M1-of ExtREALXXREAL-0K3"
      using xxreal_0_def_1 sorry
    thus " not ((r <=XXREAL-0R1 t & t <=XXREAL-0R1 s) &  not t inHIDDENR3 [.XXREAL-1K1 r,s .])"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_2:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 ].XXREAL-1K3 r,s .] iff r <XXREAL-0R3 t & t <=XXREAL-0R1 s"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 ].XXREAL-1K3 r,s .] implies r <XXREAL-0R3 t & t <=XXREAL-0R1 s) &  not (( not r <XXREAL-0R3 t & t <=XXREAL-0R1 s) &  not t inHIDDENR3 ].XXREAL-1K3 r,s .])"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    show "t inHIDDENR3 ].XXREAL-1K3 r,s .] implies r <XXREAL-0R3 t & t <=XXREAL-0R1 s"
    proof(rule impI)
      assume "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
      then have " ex a be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st (a =HIDDENR1 t & r <XXREAL-0R3 a) & a <=XXREAL-0R1 s"
         sorry
      thus "r <XXREAL-0R3 t & t <=XXREAL-0R1 s"
         sorry
    qed
    have "t be ElementSUBSET-1M1-of ExtREALXXREAL-0K3"
      using xxreal_0_def_1 sorry
    thus " not (( not r <XXREAL-0R3 t & t <=XXREAL-0R1 s) &  not t inHIDDENR3 ].XXREAL-1K3 r,s .])"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_3:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 [.XXREAL-1K2 r,s .[ iff r <=XXREAL-0R1 t & t <XXREAL-0R3 s"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 [.XXREAL-1K2 r,s .[ implies r <=XXREAL-0R1 t & t <XXREAL-0R3 s) &  not ((r <=XXREAL-0R1 t &  not t <XXREAL-0R3 s) &  not t inHIDDENR3 [.XXREAL-1K2 r,s .[)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    show "t inHIDDENR3 [.XXREAL-1K2 r,s .[ implies r <=XXREAL-0R1 t & t <XXREAL-0R3 s"
    proof(rule impI)
      assume "t inHIDDENR3 [.XXREAL-1K2 r,s .["
      then have " ex a be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st (a =HIDDENR1 t & r <=XXREAL-0R1 a) & a <XXREAL-0R3 s"
         sorry
      thus "r <=XXREAL-0R1 t & t <XXREAL-0R3 s"
         sorry
    qed
    have "t be ElementSUBSET-1M1-of ExtREALXXREAL-0K3"
      using xxreal_0_def_1 sorry
    thus " not ((r <=XXREAL-0R1 t &  not t <XXREAL-0R3 s) &  not t inHIDDENR3 [.XXREAL-1K2 r,s .[)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_4:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 ].XXREAL-1K4 r,s .[ iff r <XXREAL-0R3 t & t <XXREAL-0R3 s"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 ].XXREAL-1K4 r,s .[ implies r <XXREAL-0R3 t & t <XXREAL-0R3 s) &  not (( not r <XXREAL-0R3 t &  not t <XXREAL-0R3 s) &  not t inHIDDENR3 ].XXREAL-1K4 r,s .[)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    show "t inHIDDENR3 ].XXREAL-1K4 r,s .[ implies r <XXREAL-0R3 t & t <XXREAL-0R3 s"
    proof(rule impI)
      assume "t inHIDDENR3 ].XXREAL-1K4 r,s .["
      then have " ex a be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st (a =HIDDENR1 t & r <XXREAL-0R3 a) & a <XXREAL-0R3 s"
         sorry
      thus "r <XXREAL-0R3 t & t <XXREAL-0R3 s"
         sorry
    qed
    have "t be ElementSUBSET-1M1-of ExtREALXXREAL-0K3"
      using xxreal_0_def_1 sorry
    thus " not (( not r <XXREAL-0R3 t &  not t <XXREAL-0R3 s) &  not t inHIDDENR3 ].XXREAL-1K4 r,s .[)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_cl_1:
  mlet "r be ExtRealXXREAL-0M1", "s be ExtRealXXREAL-0M1"
"cluster [.XXREAL-1K1 r,s .] as-term-is ext-real-memberedMEMBEREDV2"
proof
(*coherence*)
  show "[.XXREAL-1K1 r,s .] be ext-real-memberedMEMBEREDV2"
  proof-
    have " for x be objectHIDDENM1 holds x inHIDDENR3 [.XXREAL-1K1 r,s .] implies x be ext-realXXREAL-0V1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 [.XXREAL-1K1 r,s .]"
      then have " ex a be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st (x =HIDDENR1 a & r <=XXREAL-0R1 a) & a <=XXREAL-0R1 s"
         sorry
      thus "x be ext-realXXREAL-0V1"
         sorry
    qed "sorry"
    thus "[.XXREAL-1K1 r,s .] be ext-real-memberedMEMBEREDV2"
      using membered_def_2 sorry
  qed
qed "sorry"

mtheorem xxreal_1_cl_2:
  mlet "r be ExtRealXXREAL-0M1", "s be ExtRealXXREAL-0M1"
"cluster [.XXREAL-1K2 r,s .[ as-term-is ext-real-memberedMEMBEREDV2"
proof
(*coherence*)
  show "[.XXREAL-1K2 r,s .[ be ext-real-memberedMEMBEREDV2"
  proof-
    have " for x be objectHIDDENM1 holds x inHIDDENR3 [.XXREAL-1K2 r,s .[ implies x be ext-realXXREAL-0V1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 [.XXREAL-1K2 r,s .["
      then have " ex a be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st (x =HIDDENR1 a & r <=XXREAL-0R1 a) & a <XXREAL-0R3 s"
         sorry
      thus "x be ext-realXXREAL-0V1"
         sorry
    qed "sorry"
    thus "[.XXREAL-1K2 r,s .[ be ext-real-memberedMEMBEREDV2"
      using membered_def_2 sorry
  qed
qed "sorry"

mtheorem xxreal_1_cl_3:
  mlet "r be ExtRealXXREAL-0M1", "s be ExtRealXXREAL-0M1"
"cluster ].XXREAL-1K3 r,s .] as-term-is ext-real-memberedMEMBEREDV2"
proof
(*coherence*)
  show "].XXREAL-1K3 r,s .] be ext-real-memberedMEMBEREDV2"
  proof-
    have " for x be objectHIDDENM1 holds x inHIDDENR3 ].XXREAL-1K3 r,s .] implies x be ext-realXXREAL-0V1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 ].XXREAL-1K3 r,s .]"
      then have " ex a be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st (x =HIDDENR1 a & r <XXREAL-0R3 a) & a <=XXREAL-0R1 s"
         sorry
      thus "x be ext-realXXREAL-0V1"
         sorry
    qed "sorry"
    thus "].XXREAL-1K3 r,s .] be ext-real-memberedMEMBEREDV2"
      using membered_def_2 sorry
  qed
qed "sorry"

mtheorem xxreal_1_cl_4:
  mlet "r be ExtRealXXREAL-0M1", "s be ExtRealXXREAL-0M1"
"cluster ].XXREAL-1K4 r,s .[ as-term-is ext-real-memberedMEMBEREDV2"
proof
(*coherence*)
  show "].XXREAL-1K4 r,s .[ be ext-real-memberedMEMBEREDV2"
  proof-
    have " for x be objectHIDDENM1 holds x inHIDDENR3 ].XXREAL-1K4 r,s .[ implies x be ext-realXXREAL-0V1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 ].XXREAL-1K4 r,s .["
      then have " ex a be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st (x =HIDDENR1 a & r <XXREAL-0R3 a) & a <XXREAL-0R3 s"
         sorry
      thus "x be ext-realXXREAL-0V1"
         sorry
    qed "sorry"
    thus "].XXREAL-1K4 r,s .[ be ext-real-memberedMEMBEREDV2"
      using membered_def_2 sorry
  qed
qed "sorry"

mtheorem xxreal_1_th_5:
" for x be setHIDDENM2 holds  for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds x inTARSKIR2 [.XXREAL-1K1 p,q .] implies (x inTARSKIR2 ].XXREAL-1K4 p,q .[ or x =HIDDENR1 p) or x =HIDDENR1 q"
proof-
  have " for x be setHIDDENM2 holds  for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds x inTARSKIR2 [.XXREAL-1K1 p,q .] implies  not (( not x inTARSKIR2 ].XXREAL-1K4 p,q .[ &  not x =HIDDENR1 p) &  not x =HIDDENR1 q)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    assume A1: "x inTARSKIR2 [.XXREAL-1K1 p,q .]"
    then obtain s where 
      [ty]:"s be ExtRealXXREAL-0M1" and sDef:"s = x"
       sorry
    have A2: "p <=XXREAL-0R1 s"
      using A1 xxreal_1_th_1 sorry
    have A3: "s <=XXREAL-0R1 q"
      using A1 xxreal_1_th_1 sorry
    have A4: "p =HIDDENR1 s or p <XXREAL-0R3 s"
      using A2 xxreal_0_th_1 sorry
    have "s =HIDDENR1 q or s <XXREAL-0R3 q"
      using A3 xxreal_0_th_1 sorry
    thus " not (( not x inTARSKIR2 ].XXREAL-1K4 p,q .[ &  not x =HIDDENR1 p) &  not x =HIDDENR1 q)"
      using A4 xxreal_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_6:
" for x be setHIDDENM2 holds  for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds x inTARSKIR2 [.XXREAL-1K1 p,q .] implies x inTARSKIR2 ].XXREAL-1K3 p,q .] or x =HIDDENR1 p"
proof-
  have " for x be setHIDDENM2 holds  for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds x inTARSKIR2 [.XXREAL-1K1 p,q .] implies  not ( not x inTARSKIR2 ].XXREAL-1K3 p,q .] &  not x =HIDDENR1 p)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    assume A1: "x inTARSKIR2 [.XXREAL-1K1 p,q .]"
    then obtain s where 
      [ty]:"s be ExtRealXXREAL-0M1" and sDef:"s = x"
       sorry
    have A2: "p <=XXREAL-0R1 s"
      using A1 xxreal_1_th_1 sorry
    have A3: "s <=XXREAL-0R1 q"
      using A1 xxreal_1_th_1 sorry
    have "p =HIDDENR1 s or p <XXREAL-0R3 s"
      using A2 xxreal_0_th_1 sorry
    thus " not ( not x inTARSKIR2 ].XXREAL-1K3 p,q .] &  not x =HIDDENR1 p)"
      using A3 xxreal_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_7:
" for x be setHIDDENM2 holds  for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds x inTARSKIR2 [.XXREAL-1K1 p,q .] implies x inTARSKIR2 [.XXREAL-1K2 p,q .[ or x =HIDDENR1 q"
proof-
  have " for x be setHIDDENM2 holds  for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds x inTARSKIR2 [.XXREAL-1K1 p,q .] implies  not ( not x inTARSKIR2 [.XXREAL-1K2 p,q .[ &  not x =HIDDENR1 q)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    assume A1: "x inTARSKIR2 [.XXREAL-1K1 p,q .]"
    then obtain s where 
      [ty]:"s be ExtRealXXREAL-0M1" and sDef:"s = x"
       sorry
    have A2: "p <=XXREAL-0R1 s"
      using A1 xxreal_1_th_1 sorry
    have "s <=XXREAL-0R1 q"
      using A1 xxreal_1_th_1 sorry
    then have "q =HIDDENR1 s or s <XXREAL-0R3 q"
      using xxreal_0_th_1 sorry
    thus " not ( not x inTARSKIR2 [.XXREAL-1K2 p,q .[ &  not x =HIDDENR1 q)"
      using A2 xxreal_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_8:
" for x be setHIDDENM2 holds  for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds x inTARSKIR2 [.XXREAL-1K2 p,q .[ implies x inTARSKIR2 ].XXREAL-1K4 p,q .[ or x =HIDDENR1 p"
proof-
  have " for x be setHIDDENM2 holds  for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds x inTARSKIR2 [.XXREAL-1K2 p,q .[ implies  not ( not x inTARSKIR2 ].XXREAL-1K4 p,q .[ &  not x =HIDDENR1 p)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    assume A1: "x inTARSKIR2 [.XXREAL-1K2 p,q .["
    then obtain s where 
      [ty]:"s be ExtRealXXREAL-0M1" and sDef:"s = x"
       sorry
    have A2: "p <=XXREAL-0R1 s"
      using A1 xxreal_1_th_3 sorry
    have A3: "s <XXREAL-0R3 q"
      using A1 xxreal_1_th_3 sorry
    have "p =HIDDENR1 s or p <XXREAL-0R3 s"
      using A2 xxreal_0_th_1 sorry
    thus " not ( not x inTARSKIR2 ].XXREAL-1K4 p,q .[ &  not x =HIDDENR1 p)"
      using A3 xxreal_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_9:
" for x be setHIDDENM2 holds  for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds x inTARSKIR2 ].XXREAL-1K3 p,q .] implies x inTARSKIR2 ].XXREAL-1K4 p,q .[ or x =HIDDENR1 q"
proof-
  have " for x be setHIDDENM2 holds  for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds x inTARSKIR2 ].XXREAL-1K3 p,q .] implies  not ( not x inTARSKIR2 ].XXREAL-1K4 p,q .[ &  not x =HIDDENR1 q)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    assume A1: "x inTARSKIR2 ].XXREAL-1K3 p,q .]"
    then obtain s where 
      [ty]:"s be ExtRealXXREAL-0M1" and sDef:"s = x"
       sorry
    have A2: "p <XXREAL-0R3 s"
      using A1 xxreal_1_th_2 sorry
    have "s <=XXREAL-0R1 q"
      using A1 xxreal_1_th_2 sorry
    then have "q =HIDDENR1 s or s <XXREAL-0R3 q"
      using xxreal_0_th_1 sorry
    thus " not ( not x inTARSKIR2 ].XXREAL-1K4 p,q .[ &  not x =HIDDENR1 q)"
      using A2 xxreal_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_10:
" for x be setHIDDENM2 holds  for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds x inTARSKIR2 [.XXREAL-1K2 p,q .[ implies x inTARSKIR2 ].XXREAL-1K3 p,q .] & x <>HIDDENR2 q or x =HIDDENR1 p"
proof-
  have " for x be setHIDDENM2 holds  for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds x inTARSKIR2 [.XXREAL-1K2 p,q .[ implies  not ( not (x inTARSKIR2 ].XXREAL-1K3 p,q .] &  not x <>HIDDENR2 q) &  not x =HIDDENR1 p)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    assume A1: "x inTARSKIR2 [.XXREAL-1K2 p,q .["
    then obtain s where 
      [ty]:"s be ExtRealXXREAL-0M1" and sDef:"s = x"
       sorry
    have A2: "p <=XXREAL-0R1 s"
      using A1 xxreal_1_th_3 sorry
    have A3: "s <XXREAL-0R3 q"
      using A1 xxreal_1_th_3 sorry
    have "p =HIDDENR1 s or p <XXREAL-0R3 s"
      using A2 xxreal_0_th_1 sorry
    thus " not ( not (x inTARSKIR2 ].XXREAL-1K3 p,q .] &  not x <>HIDDENR2 q) &  not x =HIDDENR1 p)"
      using A3 xxreal_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_11:
" for x be setHIDDENM2 holds  for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds x inTARSKIR2 ].XXREAL-1K3 p,q .] implies x inTARSKIR2 [.XXREAL-1K2 p,q .[ & x <>HIDDENR2 p or x =HIDDENR1 q"
proof-
  have " for x be setHIDDENM2 holds  for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds x inTARSKIR2 ].XXREAL-1K3 p,q .] implies  not ( not (x inTARSKIR2 [.XXREAL-1K2 p,q .[ &  not x <>HIDDENR2 p) &  not x =HIDDENR1 q)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    assume A1: "x inTARSKIR2 ].XXREAL-1K3 p,q .]"
    then obtain s where 
      [ty]:"s be ExtRealXXREAL-0M1" and sDef:"s = x"
       sorry
    have A2: "p <XXREAL-0R3 s"
      using A1 xxreal_1_th_2 sorry
    have "s <=XXREAL-0R1 q"
      using A1 xxreal_1_th_2 sorry
    then have "q =HIDDENR1 s or s <XXREAL-0R3 q"
      using xxreal_0_th_1 sorry
    thus " not ( not (x inTARSKIR2 [.XXREAL-1K2 p,q .[ &  not x <>HIDDENR2 p) &  not x =HIDDENR1 q)"
      using A2 xxreal_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_12:
" for x be setHIDDENM2 holds  for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds x inTARSKIR2 ].XXREAL-1K3 p,q .] implies x inTARSKIR2 [.XXREAL-1K1 p,q .] & x <>HIDDENR2 p"
proof-
  have " for x be setHIDDENM2 holds  for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds x inTARSKIR2 ].XXREAL-1K3 p,q .] implies x inTARSKIR2 [.XXREAL-1K1 p,q .] &  not x <>HIDDENR2 p"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    assume A1: "x inTARSKIR2 ].XXREAL-1K3 p,q .]"
    then obtain s where 
      [ty]:"s be ExtRealXXREAL-0M1" and sDef:"s = x"
       sorry
    have A2: "p <XXREAL-0R3 s"
      using A1 xxreal_1_th_2 sorry
    have "s <=XXREAL-0R1 q"
      using A1 xxreal_1_th_2 sorry
    thus "x inTARSKIR2 [.XXREAL-1K1 p,q .] &  not x <>HIDDENR2 p"
      using A2 xxreal_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_13:
" for x be setHIDDENM2 holds  for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds x inTARSKIR2 [.XXREAL-1K2 p,q .[ implies x inTARSKIR2 [.XXREAL-1K1 p,q .] & x <>HIDDENR2 q"
proof-
  have " for x be setHIDDENM2 holds  for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds x inTARSKIR2 [.XXREAL-1K2 p,q .[ implies x inTARSKIR2 [.XXREAL-1K1 p,q .] &  not x <>HIDDENR2 q"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    assume A1: "x inTARSKIR2 [.XXREAL-1K2 p,q .["
    then obtain s where 
      [ty]:"s be ExtRealXXREAL-0M1" and sDef:"s = x"
       sorry
    have A2: "p <=XXREAL-0R1 s"
      using A1 xxreal_1_th_3 sorry
    have "s <XXREAL-0R3 q"
      using A1 xxreal_1_th_3 sorry
    thus "x inTARSKIR2 [.XXREAL-1K1 p,q .] &  not x <>HIDDENR2 q"
      using A2 xxreal_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_14:
" for x be setHIDDENM2 holds  for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds x inTARSKIR2 ].XXREAL-1K4 p,q .[ implies x inTARSKIR2 [.XXREAL-1K2 p,q .[ & x <>HIDDENR2 p"
proof-
  have " for x be setHIDDENM2 holds  for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds x inTARSKIR2 ].XXREAL-1K4 p,q .[ implies x inTARSKIR2 [.XXREAL-1K2 p,q .[ &  not x <>HIDDENR2 p"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    assume A1: "x inTARSKIR2 ].XXREAL-1K4 p,q .["
    then obtain s where 
      [ty]:"s be ExtRealXXREAL-0M1" and sDef:"s = x"
       sorry
    have A2: "p <XXREAL-0R3 s"
      using A1 xxreal_1_th_4 sorry
    have "s <XXREAL-0R3 q"
      using A1 xxreal_1_th_4 sorry
    thus "x inTARSKIR2 [.XXREAL-1K2 p,q .[ &  not x <>HIDDENR2 p"
      using A2 xxreal_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_15:
" for x be setHIDDENM2 holds  for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds x inTARSKIR2 ].XXREAL-1K4 p,q .[ implies x inTARSKIR2 ].XXREAL-1K3 p,q .] & x <>HIDDENR2 q"
proof-
  have " for x be setHIDDENM2 holds  for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds x inTARSKIR2 ].XXREAL-1K4 p,q .[ implies x inTARSKIR2 ].XXREAL-1K3 p,q .] &  not x <>HIDDENR2 q"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    assume A1: "x inTARSKIR2 ].XXREAL-1K4 p,q .["
    then obtain s where 
      [ty]:"s be ExtRealXXREAL-0M1" and sDef:"s = x"
       sorry
    have A2: "p <XXREAL-0R3 s"
      using A1 xxreal_1_th_4 sorry
    have "s <XXREAL-0R3 q"
      using A1 xxreal_1_th_4 sorry
    thus "x inTARSKIR2 ].XXREAL-1K3 p,q .] &  not x <>HIDDENR2 q"
      using A2 xxreal_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_16:
" for x be setHIDDENM2 holds  for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds x inTARSKIR2 ].XXREAL-1K4 p,q .[ implies (x inTARSKIR2 [.XXREAL-1K1 p,q .] & x <>HIDDENR2 p) & x <>HIDDENR2 q"
proof-
  have " for x be setHIDDENM2 holds  for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds x inTARSKIR2 ].XXREAL-1K4 p,q .[ implies (x inTARSKIR2 [.XXREAL-1K1 p,q .] &  not x <>HIDDENR2 p) &  not x <>HIDDENR2 q"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    assume A1: "x inTARSKIR2 ].XXREAL-1K4 p,q .["
    then have "x inTARSKIR2 ].XXREAL-1K3 p,q .]"
      using xxreal_1_th_15 sorry
    thus "(x inTARSKIR2 [.XXREAL-1K1 p,q .] &  not x <>HIDDENR2 p) &  not x <>HIDDENR2 q"
      using A1 xxreal_1_th_12 xxreal_1_th_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_17:
" for r be ExtRealXXREAL-0M1 holds [.XXREAL-1K1 r,r .] =MEMBEREDR8 {TARSKIK1 r}"
proof-
  have " for r be ExtRealXXREAL-0M1 holds [.XXREAL-1K1 r,r .] =MEMBEREDR8 {TARSKIK1 r}"
  proof(rule ballI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    have " for s be ExtRealXXREAL-0M1 holds (s inHIDDENR3 [.XXREAL-1K1 r,r .] implies s inHIDDENR3 {TARSKIK1 r}) & (s inHIDDENR3 {TARSKIK1 r} implies s inHIDDENR3 [.XXREAL-1K1 r,r .])"
    proof(rule ballI,rule conjMI,rule impI)
      fix s assume [ty]: "s be ExtRealXXREAL-0M1"
      show "s inHIDDENR3 [.XXREAL-1K1 r,r .] implies s inHIDDENR3 {TARSKIK1 r}"
      proof(rule impI)
        assume "s inHIDDENR3 [.XXREAL-1K1 r,r .]"
        then have " ex a be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st (s =HIDDENR1 a & r <=XXREAL-0R1 a) & a <=XXREAL-0R1 r"
           sorry
        then have "s =HIDDENR1 r"
          using xxreal_0_th_1 sorry
        thus "s inHIDDENR3 {TARSKIK1 r}"
          using tarski_def_1 sorry
      qed
      assume "s inHIDDENR3 {TARSKIK1 r}"
      then have A1: "s =HIDDENR1 r"
        using tarski_def_1 sorry
      have 
        [ty]:"s be ElementSUBSET-1M1-of ExtREALXXREAL-0K3"
        using xxreal_0_def_1 sorry
      have "s <=XXREAL-0R1 s"
         sorry
      thus "s inHIDDENR3 [.XXREAL-1K1 r,r .]"
        using A1 sorry
    qed "sorry"
    thus "[.XXREAL-1K1 r,r .] =MEMBEREDR8 {TARSKIK1 r}"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_18:
" for r be ExtRealXXREAL-0M1 holds [.XXREAL-1K2 r,r .[ =MEMBEREDR8 {}XBOOLE-0K1"
proof-
  have " for r be ExtRealXXREAL-0M1 holds [.XXREAL-1K2 r,r .[ =MEMBEREDR8 {}XBOOLE-0K1"
  proof(rule ballI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    have " for p be ExtRealXXREAL-0M1 holds  not (p inHIDDENR3 [.XXREAL-1K2 r,r .[ &  not p inHIDDENR3 {}XBOOLE-0K1) &  not (p inHIDDENR3 {}XBOOLE-0K1 &  not p inHIDDENR3 [.XXREAL-1K2 r,r .[)"
    proof(rule ballI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      have " not ( ex p be ExtRealXXREAL-0M1 st p inHIDDENR3 [.XXREAL-1K2 r,r .[)"
      proof-
        have "( ex p be ExtRealXXREAL-0M1 st p inHIDDENR3 [.XXREAL-1K2 r,r .[) implies  not  True "
        proof(rule impI)
          assume Given: " ex p be ExtRealXXREAL-0M1 st p inHIDDENR3 [.XXREAL-1K2 r,r .["
          then obtain p where
            [ty]:"p be ExtRealXXREAL-0M1" and 
            A1: "p inHIDDENR3 [.XXREAL-1K2 r,r .["
             sorry
          have " ex a be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st (p =HIDDENR1 a & r <=XXREAL-0R1 a) & a <XXREAL-0R3 r"
            using A1 sorry
          thus " not  True "
             sorry
        qed
        thus " ?thesis "
           sorry
      qed
      thus " not (p inHIDDENR3 [.XXREAL-1K2 r,r .[ &  not p inHIDDENR3 {}XBOOLE-0K1) &  not (p inHIDDENR3 {}XBOOLE-0K1 &  not p inHIDDENR3 [.XXREAL-1K2 r,r .[)"
         sorry
    qed "sorry"
    thus "[.XXREAL-1K2 r,r .[ =MEMBEREDR8 {}XBOOLE-0K1"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_19:
" for r be ExtRealXXREAL-0M1 holds ].XXREAL-1K3 r,r .] =MEMBEREDR8 {}XBOOLE-0K1"
proof-
  have " for r be ExtRealXXREAL-0M1 holds ].XXREAL-1K3 r,r .] =MEMBEREDR8 {}XBOOLE-0K1"
  proof(rule ballI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    have " for p be ExtRealXXREAL-0M1 holds (p inHIDDENR3 ].XXREAL-1K3 r,r .] implies p inHIDDENR3 {}XBOOLE-0K1) &  not (p inHIDDENR3 {}XBOOLE-0K1 &  not p inHIDDENR3 ].XXREAL-1K3 r,r .])"
    proof(rule ballI,rule conjMI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      show "p inHIDDENR3 ].XXREAL-1K3 r,r .] implies p inHIDDENR3 {}XBOOLE-0K1"
      proof(rule impI)
        assume "p inHIDDENR3 ].XXREAL-1K3 r,r .]"
        then have " ex a be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st (p =HIDDENR1 a & r <XXREAL-0R3 a) & a <=XXREAL-0R1 r"
           sorry
        thus "p inHIDDENR3 {}XBOOLE-0K1"
           sorry
      qed
      show " not (p inHIDDENR3 {}XBOOLE-0K1 &  not p inHIDDENR3 ].XXREAL-1K3 r,r .])"
         sorry
    qed "sorry"
    thus "].XXREAL-1K3 r,r .] =MEMBEREDR8 {}XBOOLE-0K1"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_20:
" for r be ExtRealXXREAL-0M1 holds ].XXREAL-1K4 r,r .[ =MEMBEREDR8 {}XBOOLE-0K1"
proof-
  have " for r be ExtRealXXREAL-0M1 holds ].XXREAL-1K4 r,r .[ =MEMBEREDR8 {}XBOOLE-0K1"
  proof(rule ballI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    have " for p be ExtRealXXREAL-0M1 holds (p inHIDDENR3 ].XXREAL-1K4 r,r .[ implies p inHIDDENR3 {}XBOOLE-0K1) &  not (p inHIDDENR3 {}XBOOLE-0K1 &  not p inHIDDENR3 ].XXREAL-1K4 r,r .[)"
    proof(rule ballI,rule conjMI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      show "p inHIDDENR3 ].XXREAL-1K4 r,r .[ implies p inHIDDENR3 {}XBOOLE-0K1"
      proof(rule impI)
        assume "p inHIDDENR3 ].XXREAL-1K4 r,r .["
        then have " ex a be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st (p =HIDDENR1 a & r <XXREAL-0R3 a) & a <XXREAL-0R3 r"
           sorry
        thus "p inHIDDENR3 {}XBOOLE-0K1"
           sorry
      qed
      show " not (p inHIDDENR3 {}XBOOLE-0K1 &  not p inHIDDENR3 ].XXREAL-1K4 r,r .[)"
         sorry
    qed "sorry"
    thus "].XXREAL-1K4 r,r .[ =MEMBEREDR8 {}XBOOLE-0K1"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_cl_5:
  mlet "r be ExtRealXXREAL-0M1"
"cluster [.XXREAL-1K1 r,r .] as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "[.XXREAL-1K1 r,r .] be  non emptyXBOOLE-0V1"
  proof-
    have " not [.XXREAL-1K1 r,r .] be emptyXBOOLE-0V1"
    proof-
      have "[.XXREAL-1K1 r,r .] =MEMBEREDR8 {TARSKIK1 r}"
        using xxreal_1_th_17 sorry
      thus " not [.XXREAL-1K1 r,r .] be emptyXBOOLE-0V1"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_1_cl_6:
  mlet "r be ExtRealXXREAL-0M1"
"cluster [.XXREAL-1K2 r,r .[ as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "[.XXREAL-1K2 r,r .[ be emptyXBOOLE-0V1"
    using xxreal_1_th_18 sorry
qed "sorry"

mtheorem xxreal_1_cl_7:
  mlet "r be ExtRealXXREAL-0M1"
"cluster ].XXREAL-1K3 r,r .] as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "].XXREAL-1K3 r,r .] be emptyXBOOLE-0V1"
    using xxreal_1_th_19 sorry
qed "sorry"

mtheorem xxreal_1_cl_8:
  mlet "r be ExtRealXXREAL-0M1"
"cluster ].XXREAL-1K4 r,r .[ as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "].XXREAL-1K4 r,r .[ be emptyXBOOLE-0V1"
    using xxreal_1_th_20 sorry
qed "sorry"

mtheorem xxreal_1_th_21:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds ].XXREAL-1K4 p,q .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds ].XXREAL-1K4 p,q .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    have " for s be ExtRealXXREAL-0M1 holds s inHIDDENR3 ].XXREAL-1K4 p,q .[ implies s inHIDDENR3 ].XXREAL-1K3 p,q .]"
    proof(rule ballI,rule impI)
      fix s assume [ty]: "s be ExtRealXXREAL-0M1"
      assume A1: "s inHIDDENR3 ].XXREAL-1K4 p,q .["
      then have A2: "p <XXREAL-0R3 s"
        using xxreal_1_th_4 sorry
      have "s <XXREAL-0R3 q"
        using A1 xxreal_1_th_4 sorry
      thus "s inHIDDENR3 ].XXREAL-1K3 p,q .]"
        using A2 xxreal_1_th_2 sorry
    qed "sorry"
    thus "].XXREAL-1K4 p,q .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
      using membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_22:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds ].XXREAL-1K4 p,q .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds ].XXREAL-1K4 p,q .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    have " for s be ExtRealXXREAL-0M1 holds s inHIDDENR3 ].XXREAL-1K4 p,q .[ implies s inHIDDENR3 [.XXREAL-1K2 p,q .["
    proof(rule ballI,rule impI)
      fix s assume [ty]: "s be ExtRealXXREAL-0M1"
      assume A1: "s inHIDDENR3 ].XXREAL-1K4 p,q .["
      then have A2: "p <XXREAL-0R3 s"
        using xxreal_1_th_4 sorry
      have "s <XXREAL-0R3 q"
        using A1 xxreal_1_th_4 sorry
      thus "s inHIDDENR3 [.XXREAL-1K2 p,q .["
        using A2 xxreal_1_th_3 sorry
    qed "sorry"
    thus "].XXREAL-1K4 p,q .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
      using membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_23:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds ].XXREAL-1K3 p,q .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds ].XXREAL-1K3 p,q .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    have " for s be ExtRealXXREAL-0M1 holds s inHIDDENR3 ].XXREAL-1K3 p,q .] implies s inHIDDENR3 [.XXREAL-1K1 p,q .]"
    proof(rule ballI,rule impI)
      fix s assume [ty]: "s be ExtRealXXREAL-0M1"
      assume A1: "s inHIDDENR3 ].XXREAL-1K3 p,q .]"
      then have A2: "p <XXREAL-0R3 s"
        using xxreal_1_th_2 sorry
      have "s <=XXREAL-0R1 q"
        using A1 xxreal_1_th_2 sorry
      thus "s inHIDDENR3 [.XXREAL-1K1 p,q .]"
        using A2 xxreal_1_th_1 sorry
    qed "sorry"
    thus "].XXREAL-1K3 p,q .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_24:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds [.XXREAL-1K2 p,q .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds [.XXREAL-1K2 p,q .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    have " for s be ExtRealXXREAL-0M1 holds s inHIDDENR3 [.XXREAL-1K2 p,q .[ implies s inHIDDENR3 [.XXREAL-1K1 p,q .]"
    proof(rule ballI,rule impI)
      fix s assume [ty]: "s be ExtRealXXREAL-0M1"
      assume A1: "s inHIDDENR3 [.XXREAL-1K2 p,q .["
      then have A2: "p <=XXREAL-0R1 s"
        using xxreal_1_th_3 sorry
      have "s <XXREAL-0R3 q"
        using A1 xxreal_1_th_3 sorry
      thus "s inHIDDENR3 [.XXREAL-1K1 p,q .]"
        using A2 xxreal_1_th_1 sorry
    qed "sorry"
    thus "[.XXREAL-1K2 p,q .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_25:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds ].XXREAL-1K4 p,q .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds ].XXREAL-1K4 p,q .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    have A1: "].XXREAL-1K4 p,q .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
      using xxreal_1_th_22 sorry
    have "[.XXREAL-1K2 p,q .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using xxreal_1_th_24 sorry
    thus "].XXREAL-1K4 p,q .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_26:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 q implies ].XXREAL-1K3 q,p .] =MEMBEREDR8 {}XBOOLE-0K1"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 q implies (].XXREAL-1K3 q,p .] <>HIDDENR2 {}XBOOLE-0K1 implies  False )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    assume A1: "p <=XXREAL-0R1 q"
    assume "].XXREAL-1K3 q,p .] <>HIDDENR2 {}XBOOLE-0K1"
    then obtain r where
      [ty]:"r be ExtRealXXREAL-0M1" and 
      A2: "r inHIDDENR3 ].XXREAL-1K3 q,p .]"
       sorry
    have A3: "q <XXREAL-0R3 r"
      using A2 xxreal_1_th_2 sorry
    have "r <=XXREAL-0R1 p"
      using A2 xxreal_1_th_2 sorry
    thus " False "
      using A1 A3 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_27:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 q implies [.XXREAL-1K2 q,p .[ =MEMBEREDR8 {}XBOOLE-0K1"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 q implies ([.XXREAL-1K2 q,p .[ <>HIDDENR2 {}XBOOLE-0K1 implies  False )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    assume A1: "p <=XXREAL-0R1 q"
    assume "[.XXREAL-1K2 q,p .[ <>HIDDENR2 {}XBOOLE-0K1"
    then obtain r where
      [ty]:"r be ExtRealXXREAL-0M1" and 
      A2: "r inHIDDENR3 [.XXREAL-1K2 q,p .["
       sorry
    have A3: "q <=XXREAL-0R1 r"
      using A2 xxreal_1_th_3 sorry
    have "r <XXREAL-0R3 p"
      using A2 xxreal_1_th_3 sorry
    thus " False "
      using A1 A3 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_28:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 q implies ].XXREAL-1K4 q,p .[ =MEMBEREDR8 {}XBOOLE-0K1"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 q implies ].XXREAL-1K4 q,p .[ =MEMBEREDR8 {}XBOOLE-0K1"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    assume "p <=XXREAL-0R1 q"
    then have "[.XXREAL-1K2 q,p .[ =MEMBEREDR8 {}XBOOLE-0K1"
      using xxreal_1_th_27 sorry
    thus "].XXREAL-1K4 q,p .[ =MEMBEREDR8 {}XBOOLE-0K1"
      using xxreal_1_th_22 xboole_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_29:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds p <XXREAL-0R3 q implies [.XXREAL-1K1 q,p .] =MEMBEREDR8 {}XBOOLE-0K1"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds p <XXREAL-0R3 q implies ([.XXREAL-1K1 q,p .] <>HIDDENR2 {}XBOOLE-0K1 implies  False )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    assume A1: "p <XXREAL-0R3 q"
    assume "[.XXREAL-1K1 q,p .] <>HIDDENR2 {}XBOOLE-0K1"
    then obtain r where
      [ty]:"r be ExtRealXXREAL-0M1" and 
      A2: "r inHIDDENR3 [.XXREAL-1K1 q,p .]"
       sorry
    have A3: "q <=XXREAL-0R1 r"
      using A2 xxreal_1_th_1 sorry
    have "r <=XXREAL-0R1 p"
      using A2 xxreal_1_th_1 sorry
    thus " False "
      using A1 A3 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_30:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s implies [.XXREAL-1K1 r,s .] be  non emptyXBOOLE-0V1"
  using xxreal_1_th_1 sorry

mtheorem xxreal_1_th_31:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds p <XXREAL-0R3 q implies [.XXREAL-1K2 p,q .[ be  non emptyXBOOLE-0V1"
  using xxreal_1_th_3 sorry

mtheorem xxreal_1_th_32:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds p <XXREAL-0R3 q implies ].XXREAL-1K3 p,q .] be  non emptyXBOOLE-0V1"
  using xxreal_1_th_2 sorry

mtheorem xxreal_1_th_33:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds p <XXREAL-0R3 q implies ].XXREAL-1K4 p,q .[ be  non emptyXBOOLE-0V1"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds p <XXREAL-0R3 q implies  not ].XXREAL-1K4 p,q .[ be emptyXBOOLE-0V1"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    assume "p <XXREAL-0R3 q"
    then have " ex s be ExtRealXXREAL-0M1 st p <XXREAL-0R3 s & s <XXREAL-0R3 q"
      using xreal_1_th_227 sorry
    thus " not ].XXREAL-1K4 p,q .[ be emptyXBOOLE-0V1"
      using xxreal_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_34:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r & s <=XXREAL-0R1 q implies [.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r & s <=XXREAL-0R1 q implies [.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "p <=XXREAL-0R1 r"
      and A2: "s <=XXREAL-0R1 q"
    have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 [.XXREAL-1K1 r,s .] implies t inHIDDENR3 [.XXREAL-1K1 p,q .]"
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume A3: "t inHIDDENR3 [.XXREAL-1K1 r,s .]"
      then have A4: "r <=XXREAL-0R1 t"
        using xxreal_1_th_1 sorry
      have A5: "t <=XXREAL-0R1 s"
        using A3 xxreal_1_th_1 sorry
      have A6: "p <=XXREAL-0R1 t"
        using A1 A4 xxreal_0_th_2 sorry
      have "t <=XXREAL-0R1 q"
        using A2 A5 xxreal_0_th_2 sorry
      thus "t inHIDDENR3 [.XXREAL-1K1 p,q .]"
        using A6 xxreal_1_th_1 sorry
    qed "sorry"
    thus "[.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_35:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r & s <=XXREAL-0R1 q implies [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r & s <=XXREAL-0R1 q implies [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have A1: "[.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 r,s .]"
      using xxreal_1_th_24 sorry
    assume A2: "p <=XXREAL-0R1 r"
      and A3: "s <=XXREAL-0R1 q"
    have "[.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using A2 A3 xxreal_1_th_34 sorry
    thus "[.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_36:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r & s <=XXREAL-0R1 q implies ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r & s <=XXREAL-0R1 q implies ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have A1: "].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 r,s .]"
      using xxreal_1_th_23 sorry
    assume A2: "p <=XXREAL-0R1 r"
      and A3: "s <=XXREAL-0R1 q"
    have "[.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using A2 A3 xxreal_1_th_34 sorry
    thus "].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_37:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r & s <=XXREAL-0R1 q implies ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r & s <=XXREAL-0R1 q implies ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have A1: "].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 r,s .]"
      using xxreal_1_th_25 sorry
    assume A2: "p <=XXREAL-0R1 r"
      and A3: "s <=XXREAL-0R1 q"
    have "[.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using A2 A3 xxreal_1_th_34 sorry
    thus "].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_38:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r & s <=XXREAL-0R1 q implies [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r & s <=XXREAL-0R1 q implies [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "p <=XXREAL-0R1 r"
      and A2: "s <=XXREAL-0R1 q"
    have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 [.XXREAL-1K2 r,s .[ implies t inHIDDENR3 [.XXREAL-1K2 p,q .["
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume A3: "t inHIDDENR3 [.XXREAL-1K2 r,s .["
      then have A4: "r <=XXREAL-0R1 t"
        using xxreal_1_th_3 sorry
      have A5: "t <XXREAL-0R3 s"
        using A3 xxreal_1_th_3 sorry
      have A6: "p <=XXREAL-0R1 t"
        using A1 A4 xxreal_0_th_2 sorry
      have "t <XXREAL-0R3 q"
        using A2 A5 xxreal_0_th_2 sorry
      thus "t inHIDDENR3 [.XXREAL-1K2 p,q .["
        using A6 xxreal_1_th_3 sorry
    qed "sorry"
    thus "[.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
      using membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_39:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <XXREAL-0R3 r & s <=XXREAL-0R1 q implies [.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <XXREAL-0R3 r & s <=XXREAL-0R1 q implies [.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "p <XXREAL-0R3 r"
      and A2: "s <=XXREAL-0R1 q"
    have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 [.XXREAL-1K1 r,s .] implies t inHIDDENR3 ].XXREAL-1K3 p,q .]"
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume A3: "t inHIDDENR3 [.XXREAL-1K1 r,s .]"
      then have A4: "r <=XXREAL-0R1 t"
        using xxreal_1_th_1 sorry
      have A5: "t <=XXREAL-0R1 s"
        using A3 xxreal_1_th_1 sorry
      have A6: "p <XXREAL-0R3 t"
        using A1 A4 xxreal_0_th_2 sorry
      have "t <=XXREAL-0R1 q"
        using A2 A5 xxreal_0_th_2 sorry
      thus "t inHIDDENR3 ].XXREAL-1K3 p,q .]"
        using A6 xxreal_1_th_2 sorry
    qed "sorry"
    thus "[.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
      using membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_40:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <XXREAL-0R3 r & s <=XXREAL-0R1 q implies [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <XXREAL-0R3 r & s <=XXREAL-0R1 q implies [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have A1: "[.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 r,s .]"
      using xxreal_1_th_24 sorry
    assume A2: "p <XXREAL-0R3 r"
      and A3: "s <=XXREAL-0R1 q"
    have "[.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
      using A2 A3 xxreal_1_th_39 sorry
    thus "[.XXREAL-1K2 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_41:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r & s <=XXREAL-0R1 q implies ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r & s <=XXREAL-0R1 q implies ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "p <=XXREAL-0R1 r"
      and A2: "s <=XXREAL-0R1 q"
    have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 ].XXREAL-1K4 r,s .[ implies t inHIDDENR3 ].XXREAL-1K3 p,q .]"
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume A3: "t inHIDDENR3 ].XXREAL-1K4 r,s .["
      then have A4: "r <XXREAL-0R3 t"
        using xxreal_1_th_4 sorry
      have A5: "t <XXREAL-0R3 s"
        using A3 xxreal_1_th_4 sorry
      have A6: "p <XXREAL-0R3 t"
        using A1 A4 xxreal_0_th_2 sorry
      have "t <XXREAL-0R3 q"
        using A2 A5 xxreal_0_th_2 sorry
      thus "t inHIDDENR3 ].XXREAL-1K3 p,q .]"
        using A6 xxreal_1_th_2 sorry
    qed "sorry"
    thus "].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
      using membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_42:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r & s <=XXREAL-0R1 q implies ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r & s <=XXREAL-0R1 q implies ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "p <=XXREAL-0R1 r"
      and A2: "s <=XXREAL-0R1 q"
    have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 ].XXREAL-1K3 r,s .] implies t inHIDDENR3 ].XXREAL-1K3 p,q .]"
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume A3: "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
      then have A4: "r <XXREAL-0R3 t"
        using xxreal_1_th_2 sorry
      have A5: "t <=XXREAL-0R1 s"
        using A3 xxreal_1_th_2 sorry
      have A6: "p <XXREAL-0R3 t"
        using A1 A4 xxreal_0_th_2 sorry
      have "t <=XXREAL-0R1 q"
        using A2 A5 xxreal_0_th_2 sorry
      thus "t inHIDDENR3 ].XXREAL-1K3 p,q .]"
        using A6 xxreal_1_th_2 sorry
    qed "sorry"
    thus "].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
      using membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_43:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r & s <XXREAL-0R3 q implies [.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r & s <XXREAL-0R3 q implies [.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "p <=XXREAL-0R1 r"
      and A2: "s <XXREAL-0R3 q"
    have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 [.XXREAL-1K1 r,s .] implies t inHIDDENR3 [.XXREAL-1K2 p,q .["
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume A3: "t inHIDDENR3 [.XXREAL-1K1 r,s .]"
      then have A4: "r <=XXREAL-0R1 t"
        using xxreal_1_th_1 sorry
      have A5: "t <=XXREAL-0R1 s"
        using A3 xxreal_1_th_1 sorry
      have A6: "p <=XXREAL-0R1 t"
        using A1 A4 xxreal_0_th_2 sorry
      have "t <XXREAL-0R3 q"
        using A2 A5 xxreal_0_th_2 sorry
      thus "t inHIDDENR3 [.XXREAL-1K2 p,q .["
        using A6 xxreal_1_th_3 sorry
    qed "sorry"
    thus "[.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
      using membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_44:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r & s <XXREAL-0R3 q implies ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r & s <XXREAL-0R3 q implies ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have A1: "].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 r,s .]"
      using xxreal_1_th_23 sorry
    assume A2: "p <=XXREAL-0R1 r"
      and A3: "s <XXREAL-0R3 q"
    have "[.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
      using A2 A3 xxreal_1_th_43 sorry
    thus "].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_45:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r & s <=XXREAL-0R1 q implies ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r & s <=XXREAL-0R1 q implies ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "p <=XXREAL-0R1 r"
      and A2: "s <=XXREAL-0R1 q"
    have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 ].XXREAL-1K4 r,s .[ implies t inHIDDENR3 [.XXREAL-1K2 p,q .["
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume A3: "t inHIDDENR3 ].XXREAL-1K4 r,s .["
      then have A4: "r <XXREAL-0R3 t"
        using xxreal_1_th_4 sorry
      have A5: "t <XXREAL-0R3 s"
        using A3 xxreal_1_th_4 sorry
      have A6: "p <=XXREAL-0R1 t"
        using A1 A4 xxreal_0_th_2 sorry
      have "t <XXREAL-0R3 q"
        using A2 A5 xxreal_0_th_2 sorry
      thus "t inHIDDENR3 [.XXREAL-1K2 p,q .["
        using A6 xxreal_1_th_3 sorry
    qed "sorry"
    thus "].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
      using membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_46:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r & s <=XXREAL-0R1 q implies ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r & s <=XXREAL-0R1 q implies ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "p <=XXREAL-0R1 r"
      and A2: "s <=XXREAL-0R1 q"
    have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 ].XXREAL-1K4 r,s .[ implies t inHIDDENR3 ].XXREAL-1K4 p,q .["
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume A3: "t inHIDDENR3 ].XXREAL-1K4 r,s .["
      then have A4: "r <XXREAL-0R3 t"
        using xxreal_1_th_4 sorry
      have A5: "t <XXREAL-0R3 s"
        using A3 xxreal_1_th_4 sorry
      have A6: "p <XXREAL-0R3 t"
        using A1 A4 xxreal_0_th_2 sorry
      have "t <XXREAL-0R3 q"
        using A2 A5 xxreal_0_th_2 sorry
      thus "t inHIDDENR3 ].XXREAL-1K4 p,q .["
        using A6 xxreal_1_th_4 sorry
    qed "sorry"
    thus "].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
      using membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_47:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <XXREAL-0R3 r & s <XXREAL-0R3 q implies [.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <XXREAL-0R3 r & s <XXREAL-0R3 q implies [.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "p <XXREAL-0R3 r"
      and A2: "s <XXREAL-0R3 q"
    have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 [.XXREAL-1K1 r,s .] implies t inHIDDENR3 ].XXREAL-1K4 p,q .["
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume A3: "t inHIDDENR3 [.XXREAL-1K1 r,s .]"
      then have A4: "r <=XXREAL-0R1 t"
        using xxreal_1_th_1 sorry
      have A5: "t <=XXREAL-0R1 s"
        using A3 xxreal_1_th_1 sorry
      have A6: "p <XXREAL-0R3 t"
        using A1 A4 xxreal_0_th_2 sorry
      have "t <XXREAL-0R3 q"
        using A2 A5 xxreal_0_th_2 sorry
      thus "t inHIDDENR3 ].XXREAL-1K4 p,q .["
        using A6 xxreal_1_th_4 sorry
    qed "sorry"
    thus "[.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
      using membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_48:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <XXREAL-0R3 r & s <=XXREAL-0R1 q implies [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <XXREAL-0R3 r & s <=XXREAL-0R1 q implies [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "p <XXREAL-0R3 r"
      and A2: "s <=XXREAL-0R1 q"
    have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 [.XXREAL-1K2 r,s .[ implies t inHIDDENR3 ].XXREAL-1K4 p,q .["
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume A3: "t inHIDDENR3 [.XXREAL-1K2 r,s .["
      then have A4: "r <=XXREAL-0R1 t"
        using xxreal_1_th_3 sorry
      have A5: "t <XXREAL-0R3 s"
        using A3 xxreal_1_th_3 sorry
      have A6: "p <XXREAL-0R3 t"
        using A1 A4 xxreal_0_th_2 sorry
      have "t <XXREAL-0R3 q"
        using A2 A5 xxreal_0_th_2 sorry
      thus "t inHIDDENR3 ].XXREAL-1K4 p,q .["
        using A6 xxreal_1_th_4 sorry
    qed "sorry"
    thus "[.XXREAL-1K2 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
      using membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_49:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r & s <XXREAL-0R3 q implies ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r & s <XXREAL-0R3 q implies ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "p <=XXREAL-0R1 r"
      and A2: "s <XXREAL-0R3 q"
    have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 ].XXREAL-1K3 r,s .] implies t inHIDDENR3 ].XXREAL-1K4 p,q .["
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume A3: "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
      then have A4: "r <XXREAL-0R3 t"
        using xxreal_1_th_2 sorry
      have A5: "t <=XXREAL-0R1 s"
        using A3 xxreal_1_th_2 sorry
      have A6: "p <XXREAL-0R3 t"
        using A1 A4 xxreal_0_th_2 sorry
      have "t <XXREAL-0R3 q"
        using A2 A5 xxreal_0_th_2 sorry
      thus "t inHIDDENR3 ].XXREAL-1K4 p,q .["
        using A6 xxreal_1_th_4 sorry
    qed "sorry"
    thus "].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
      using membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_50:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & [.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .] implies p <=XXREAL-0R1 r & s <=XXREAL-0R1 q"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s implies  not ([.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .] &  not (p <=XXREAL-0R1 r & s <=XXREAL-0R1 q))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
    then have A2: "r inHIDDENR3 [.XXREAL-1K1 r,s .]"
      using xxreal_1_th_1 sorry
    have "s inHIDDENR3 [.XXREAL-1K1 r,s .]"
      using A1 xxreal_1_th_1 sorry
    thus " not ([.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .] &  not (p <=XXREAL-0R1 r & s <=XXREAL-0R1 q))"
      using A2 xxreal_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_51:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .] implies p <=XXREAL-0R1 r & s <=XXREAL-0R1 q"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .] implies p <=XXREAL-0R1 r & s <=XXREAL-0R1 q"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
    have " for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 t & t <XXREAL-0R3 s implies p <=XXREAL-0R1 t"
    proof(rule ballI,rule impMI ,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume A3: "r <XXREAL-0R3 t"
        and A4: "t <XXREAL-0R3 s"
      have "t inHIDDENR3 ].XXREAL-1K4 r,s .["
        using A3 A4 xxreal_1_th_4 sorry
      thus "p <=XXREAL-0R1 t"
        using A2 xxreal_1_th_1 sorry
    qed "sorry"
    thus "p <=XXREAL-0R1 r"
      using A1 xreal_1_th_228 sorry
    have " for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 t & t <XXREAL-0R3 s implies t <=XXREAL-0R1 q"
    proof(rule ballI,rule impMI ,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume A5: "r <XXREAL-0R3 t"
        and A6: "t <XXREAL-0R3 s"
      have "t inHIDDENR3 ].XXREAL-1K4 r,s .["
        using A5 A6 xxreal_1_th_4 sorry
      thus "t <=XXREAL-0R1 q"
        using A2 xxreal_1_th_1 sorry
    qed "sorry"
    thus "s <=XXREAL-0R1 q"
      using A1 xreal_1_th_229 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_52:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .] implies p <=XXREAL-0R1 r & s <=XXREAL-0R1 q"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .] implies p <=XXREAL-0R1 r & s <=XXREAL-0R1 q"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "[.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
    have "].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 r,s .["
      using xxreal_1_th_22 sorry
    then have "].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using A2 sorry
    thus "p <=XXREAL-0R1 r & s <=XXREAL-0R1 q"
      using A1 xxreal_1_th_51 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_53:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .] implies p <=XXREAL-0R1 r & s <=XXREAL-0R1 q"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .] implies p <=XXREAL-0R1 r & s <=XXREAL-0R1 q"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
    have "].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 r,s .]"
      using xxreal_1_th_21 sorry
    then have "].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using A2 sorry
    thus "p <=XXREAL-0R1 r & s <=XXREAL-0R1 q"
      using A1 xxreal_1_th_51 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_54:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & [.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K2 p,q .[ implies p <=XXREAL-0R1 r & s <XXREAL-0R3 q"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & [.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K2 p,q .[ implies p <=XXREAL-0R1 r &  not s <XXREAL-0R3 q"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
      and A2: "[.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
    have "[.XXREAL-1K2 p,q .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using xxreal_1_th_24 sorry
    then have "[.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using A2 sorry
    thus "p <=XXREAL-0R1 r"
      using A1 xxreal_1_th_50 sorry
    have "s inHIDDENR3 [.XXREAL-1K1 r,s .]"
      using A1 xxreal_1_th_1 sorry
    thus " not s <XXREAL-0R3 q"
      using A2 xxreal_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_55:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .[ implies p <=XXREAL-0R1 r & s <=XXREAL-0R1 q"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .[ implies p <=XXREAL-0R1 r & s <=XXREAL-0R1 q"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "[.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
    have "].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 r,s .["
      using xxreal_1_th_22 sorry
    then have A3: "].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
      using A2 sorry
    have "[.XXREAL-1K2 p,q .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using xxreal_1_th_24 sorry
    then have "].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using A3 sorry
    thus "p <=XXREAL-0R1 r & s <=XXREAL-0R1 q"
      using A1 xxreal_1_th_51 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_56:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .[ implies p <=XXREAL-0R1 r & s <=XXREAL-0R1 q"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .[ implies p <=XXREAL-0R1 r & s <=XXREAL-0R1 q"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
    have "[.XXREAL-1K2 p,q .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using xxreal_1_th_24 sorry
    then have "].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using A2 sorry
    thus "p <=XXREAL-0R1 r & s <=XXREAL-0R1 q"
      using A1 xxreal_1_th_51 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_57:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K2 p,q .[ implies p <=XXREAL-0R1 r & s <XXREAL-0R3 q"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K2 p,q .[ implies p <=XXREAL-0R1 r &  not s <XXREAL-0R3 q"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
    have "[.XXREAL-1K2 p,q .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using xxreal_1_th_24 sorry
    then have "].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using A2 sorry
    thus "p <=XXREAL-0R1 r"
      using A1 xxreal_1_th_53 sorry
    have "s inHIDDENR3 ].XXREAL-1K3 r,s .]"
      using A1 xxreal_1_th_2 sorry
    thus " not s <XXREAL-0R3 q"
      using A2 xxreal_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_58:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & [.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,q .] implies p <XXREAL-0R3 r & s <=XXREAL-0R1 q"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & [.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,q .] implies p <XXREAL-0R3 r & s <=XXREAL-0R1 q"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
      and A2: "[.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
    have "].XXREAL-1K3 p,q .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using xxreal_1_th_23 sorry
    then have A3: "[.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using A2 sorry
    have "r inHIDDENR3 [.XXREAL-1K1 r,s .]"
      using A1 xxreal_1_th_1 sorry
    thus "p <XXREAL-0R3 r"
      using A2 xxreal_1_th_2 sorry
    show "s <=XXREAL-0R1 q"
      using A1 A3 xxreal_1_th_50 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_59:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .] implies p <=XXREAL-0R1 r & s <=XXREAL-0R1 q"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .] implies p <=XXREAL-0R1 r & s <=XXREAL-0R1 q"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
    have "].XXREAL-1K3 p,q .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using xxreal_1_th_23 sorry
    then have "].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using A2 sorry
    thus "p <=XXREAL-0R1 r & s <=XXREAL-0R1 q"
      using A1 xxreal_1_th_51 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_60:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .] implies p <XXREAL-0R3 r & s <=XXREAL-0R1 q"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .] implies p <XXREAL-0R3 r & s <=XXREAL-0R1 q"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "[.XXREAL-1K2 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
    have "].XXREAL-1K3 p,q .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using xxreal_1_th_23 sorry
    then have A3: "[.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using A2 sorry
    have "r inHIDDENR3 [.XXREAL-1K2 r,s .["
      using A1 xxreal_1_th_3 sorry
    thus "p <XXREAL-0R3 r"
      using A2 xxreal_1_th_2 sorry
    show "s <=XXREAL-0R1 q"
      using A1 A3 xxreal_1_th_52 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_61:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,q .] implies p <=XXREAL-0R1 r & s <=XXREAL-0R1 q"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,q .] implies p <=XXREAL-0R1 r & s <=XXREAL-0R1 q"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
    have "].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 r,s .]"
      using xxreal_1_th_21 sorry
    then have A3: "].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
      using A2 sorry
    have "].XXREAL-1K3 p,q .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using xxreal_1_th_23 sorry
    then have "].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using A3 sorry
    thus "p <=XXREAL-0R1 r & s <=XXREAL-0R1 q"
      using A1 xxreal_1_th_51 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_62:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & [.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 p,q .[ implies p <XXREAL-0R3 r & s <XXREAL-0R3 q"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & [.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 p,q .[ implies p <XXREAL-0R3 r &  not s <XXREAL-0R3 q"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
      and A2: "[.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
    have "r inHIDDENR3 [.XXREAL-1K1 r,s .]"
      using A1 xxreal_1_th_1 sorry
    thus "p <XXREAL-0R3 r"
      using A2 xxreal_1_th_4 sorry
    have "s inHIDDENR3 [.XXREAL-1K1 r,s .]"
      using A1 xxreal_1_th_1 sorry
    thus " not s <XXREAL-0R3 q"
      using A2 xxreal_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_63:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .[ implies p <=XXREAL-0R1 r & s <=XXREAL-0R1 q"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .[ implies p <=XXREAL-0R1 r & s <=XXREAL-0R1 q"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
    have "].XXREAL-1K4 p,q .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using xxreal_1_th_25 sorry
    then have "].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using A2 sorry
    thus "p <=XXREAL-0R1 r & s <=XXREAL-0R1 q"
      using A1 xxreal_1_th_51 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_64:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .[ implies p <XXREAL-0R3 r & s <=XXREAL-0R1 q"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .[ implies p <XXREAL-0R3 r & s <=XXREAL-0R1 q"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "[.XXREAL-1K2 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
    have "].XXREAL-1K4 p,q .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using xxreal_1_th_25 sorry
    then have A3: "[.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using A2 sorry
    have "r inHIDDENR3 [.XXREAL-1K2 r,s .["
      using A1 xxreal_1_th_3 sorry
    thus "p <XXREAL-0R3 r"
      using A2 xxreal_1_th_4 sorry
    show "s <=XXREAL-0R1 q"
      using A1 A3 xxreal_1_th_52 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_65:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 p,q .[ implies p <=XXREAL-0R1 r & s <XXREAL-0R3 q"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 p,q .[ implies p <=XXREAL-0R1 r &  not s <XXREAL-0R3 q"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
    have "].XXREAL-1K4 p,q .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using xxreal_1_th_25 sorry
    then have "].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using A2 sorry
    thus "p <=XXREAL-0R1 r"
      using A1 xxreal_1_th_53 sorry
    have "s inHIDDENR3 ].XXREAL-1K3 r,s .]"
      using A1 xxreal_1_th_2 sorry
    thus " not s <XXREAL-0R3 q"
      using A2 xxreal_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_66:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 q & [.XXREAL-1K1 p,q .] =MEMBEREDR8 [.XXREAL-1K1 r,s .] implies p =HIDDENR1 r & q =HIDDENR1 s"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 q & [.XXREAL-1K1 p,q .] =MEMBEREDR8 [.XXREAL-1K1 r,s .] implies p =HIDDENR1 r & q =HIDDENR1 s"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "p <=XXREAL-0R1 q"
      and A2: "[.XXREAL-1K1 p,q .] =MEMBEREDR8 [.XXREAL-1K1 r,s .]"
    have A3: "r <=XXREAL-0R1 p"
      using A1 A2 xxreal_1_th_50 sorry
    have A4: "q <=XXREAL-0R1 s"
      using A1 A2 xxreal_1_th_50 sorry
    have "r <=XXREAL-0R1 q"
      using A1 A3 xxreal_0_th_2 sorry
    then have A5: "r <=XXREAL-0R1 s"
      using A4 xxreal_0_th_2 sorry
    then have A6: "p <=XXREAL-0R1 r"
      using A2 xxreal_1_th_50 sorry
    have "s <=XXREAL-0R1 q"
      using A2 A5 xxreal_1_th_50 sorry
    thus "p =HIDDENR1 r & q =HIDDENR1 s"
      using A3 A4 A6 xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_67:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <XXREAL-0R3 q & ].XXREAL-1K4 p,q .[ =MEMBEREDR8 ].XXREAL-1K4 r,s .[ implies p =HIDDENR1 r & q =HIDDENR1 s"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <XXREAL-0R3 q & ].XXREAL-1K4 p,q .[ =MEMBEREDR8 ].XXREAL-1K4 r,s .[ implies p =HIDDENR1 r & q =HIDDENR1 s"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "p <XXREAL-0R3 q"
      and A2: "].XXREAL-1K4 p,q .[ =MEMBEREDR8 ].XXREAL-1K4 r,s .["
    have A3: "r <=XXREAL-0R1 p"
      using A1 A2 xxreal_1_th_63 sorry
    have A4: "q <=XXREAL-0R1 s"
      using A1 A2 xxreal_1_th_63 sorry
    have "r <XXREAL-0R3 q"
      using A1 A3 xxreal_0_th_2 sorry
    then have A5: "r <XXREAL-0R3 s"
      using A4 xxreal_0_th_2 sorry
    then have A6: "p <=XXREAL-0R1 r"
      using A2 xxreal_1_th_63 sorry
    have "s <=XXREAL-0R1 q"
      using A2 A5 xxreal_1_th_63 sorry
    thus "p =HIDDENR1 r & q =HIDDENR1 s"
      using A3 A4 A6 xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_68:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <XXREAL-0R3 q & ].XXREAL-1K3 p,q .] =MEMBEREDR8 ].XXREAL-1K3 r,s .] implies p =HIDDENR1 r & q =HIDDENR1 s"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <XXREAL-0R3 q & ].XXREAL-1K3 p,q .] =MEMBEREDR8 ].XXREAL-1K3 r,s .] implies p =HIDDENR1 r & q =HIDDENR1 s"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "p <XXREAL-0R3 q"
      and A2: "].XXREAL-1K3 p,q .] =MEMBEREDR8 ].XXREAL-1K3 r,s .]"
    have A3: "r <=XXREAL-0R1 p"
      using A1 A2 xxreal_1_th_61 sorry
    have A4: "q <=XXREAL-0R1 s"
      using A1 A2 xxreal_1_th_61 sorry
    have "r <XXREAL-0R3 q"
      using A1 A3 xxreal_0_th_2 sorry
    then have A5: "r <XXREAL-0R3 s"
      using A4 xxreal_0_th_2 sorry
    then have A6: "p <=XXREAL-0R1 r"
      using A2 xxreal_1_th_61 sorry
    have "s <=XXREAL-0R1 q"
      using A2 A5 xxreal_1_th_61 sorry
    thus "p =HIDDENR1 r & q =HIDDENR1 s"
      using A3 A4 A6 xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_69:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <XXREAL-0R3 q & [.XXREAL-1K2 p,q .[ =MEMBEREDR8 [.XXREAL-1K2 r,s .[ implies p =HIDDENR1 r & q =HIDDENR1 s"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <XXREAL-0R3 q & [.XXREAL-1K2 p,q .[ =MEMBEREDR8 [.XXREAL-1K2 r,s .[ implies p =HIDDENR1 r & q =HIDDENR1 s"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "p <XXREAL-0R3 q"
      and A2: "[.XXREAL-1K2 p,q .[ =MEMBEREDR8 [.XXREAL-1K2 r,s .["
    have A3: "r <=XXREAL-0R1 p"
      using A1 A2 xxreal_1_th_55 sorry
    have A4: "q <=XXREAL-0R1 s"
      using A1 A2 xxreal_1_th_55 sorry
    have "r <XXREAL-0R3 q"
      using A1 A3 xxreal_0_th_2 sorry
    then have A5: "r <XXREAL-0R3 s"
      using A4 xxreal_0_th_2 sorry
    then have A6: "p <=XXREAL-0R1 r"
      using A2 xxreal_1_th_55 sorry
    have "s <=XXREAL-0R1 q"
      using A2 A5 xxreal_1_th_55 sorry
    thus "p =HIDDENR1 r & q =HIDDENR1 s"
      using A3 A4 A6 xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_70:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s implies [.XXREAL-1K1 r,s .] <>HIDDENR2 ].XXREAL-1K3 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & [.XXREAL-1K1 r,s .] =MEMBEREDR8 ].XXREAL-1K3 p,q .] implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
      and A2: "[.XXREAL-1K1 r,s .] =MEMBEREDR8 ].XXREAL-1K3 p,q .]"
    have "r inHIDDENR3 ].XXREAL-1K3 p,q .] implies  False "
    proof(rule impI)
      assume "r inHIDDENR3 ].XXREAL-1K3 p,q .]"
      then have A3: "p <XXREAL-0R3 r"
        using xxreal_1_th_2 sorry
      have "s <=XXREAL-0R1 q"
        using A1 A2 xxreal_1_th_58 sorry
      then have "r <=XXREAL-0R1 q"
        using A1 xxreal_0_th_2 sorry
      then have "p <XXREAL-0R3 q"
        using A3 xxreal_0_th_2 sorry
      thus " False "
        using A2 A3 xxreal_1_th_53 sorry
    qed
    thus " False "
      using A1 A2 xxreal_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_71:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s implies [.XXREAL-1K1 r,s .] <>HIDDENR2 [.XXREAL-1K2 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & [.XXREAL-1K1 r,s .] =MEMBEREDR8 [.XXREAL-1K2 p,q .[ implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
      and A2: "[.XXREAL-1K1 r,s .] =MEMBEREDR8 [.XXREAL-1K2 p,q .["
    have "s inHIDDENR3 [.XXREAL-1K2 p,q .[ implies  False "
    proof(rule impI)
      assume "s inHIDDENR3 [.XXREAL-1K2 p,q .["
      then have A3: "s <XXREAL-0R3 q"
        using xxreal_1_th_3 sorry
      have "p <=XXREAL-0R1 r"
        using A1 A2 xxreal_1_th_54 sorry
      then have "p <=XXREAL-0R1 s"
        using A1 xxreal_0_th_2 sorry
      then have "p <XXREAL-0R3 q"
        using A3 xxreal_0_th_2 sorry
      thus " False "
        using A2 A3 xxreal_1_th_52 sorry
    qed
    thus " False "
      using A1 A2 xxreal_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_72:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s implies [.XXREAL-1K1 r,s .] <>HIDDENR2 ].XXREAL-1K4 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & [.XXREAL-1K1 r,s .] =MEMBEREDR8 ].XXREAL-1K4 p,q .[ implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
      and A2: "[.XXREAL-1K1 r,s .] =MEMBEREDR8 ].XXREAL-1K4 p,q .["
    have "s inHIDDENR3 ].XXREAL-1K4 p,q .[ implies  False "
    proof(rule impI)
      assume "s inHIDDENR3 ].XXREAL-1K4 p,q .["
      then have A3: "s <XXREAL-0R3 q"
        using xxreal_1_th_4 sorry
      have "p <=XXREAL-0R1 r"
        using A1 A2 xxreal_1_th_62 sorry
      then have "p <=XXREAL-0R1 s"
        using A1 xxreal_0_th_2 sorry
      then have "p <XXREAL-0R3 q"
        using A3 xxreal_0_th_2 sorry
      thus " False "
        using A2 A3 xxreal_1_th_51 sorry
    qed
    thus " False "
      using A1 A2 xxreal_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_73:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies [.XXREAL-1K2 r,s .[ <>HIDDENR2 [.XXREAL-1K1 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & [.XXREAL-1K2 r,s .[ =MEMBEREDR8 [.XXREAL-1K1 p,q .] implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "[.XXREAL-1K2 r,s .[ =MEMBEREDR8 [.XXREAL-1K1 p,q .]"
    have A3: " not s inHIDDENR3 [.XXREAL-1K2 r,s .["
      using xxreal_1_th_3 sorry
    have "p <=XXREAL-0R1 r"
      using A1 A2 xxreal_1_th_52 sorry
    then have A4: "p <=XXREAL-0R1 s"
      using A1 xxreal_0_th_2 sorry
    have "s <=XXREAL-0R1 q"
      using A1 A2 xxreal_1_th_52 sorry
    thus " False "
      using A2 A3 A4 xxreal_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_74:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies [.XXREAL-1K2 r,s .[ <>HIDDENR2 ].XXREAL-1K3 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & [.XXREAL-1K2 r,s .[ =MEMBEREDR8 ].XXREAL-1K3 p,q .] implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "[.XXREAL-1K2 r,s .[ =MEMBEREDR8 ].XXREAL-1K3 p,q .]"
    have A3: " not s inHIDDENR3 [.XXREAL-1K2 r,s .["
      using xxreal_1_th_3 sorry
    have "p <=XXREAL-0R1 r"
      using A1 A2 xxreal_1_th_60 sorry
    then have A4: "p <XXREAL-0R3 s"
      using A1 xxreal_0_th_2 sorry
    have "s <=XXREAL-0R1 q"
      using A1 A2 xxreal_1_th_60 sorry
    thus " False "
      using A2 A3 A4 xxreal_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_75:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies [.XXREAL-1K2 r,s .[ <>HIDDENR2 ].XXREAL-1K4 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & [.XXREAL-1K2 r,s .[ =MEMBEREDR8 ].XXREAL-1K4 p,q .[ implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "[.XXREAL-1K2 r,s .[ =MEMBEREDR8 ].XXREAL-1K4 p,q .["
    have "r inHIDDENR3 ].XXREAL-1K4 p,q .[ implies  False "
    proof(rule impI)
      assume "r inHIDDENR3 ].XXREAL-1K4 p,q .["
      then have A3: "p <XXREAL-0R3 r"
        using xxreal_1_th_4 sorry
      have "s <=XXREAL-0R1 q"
        using A1 A2 xxreal_1_th_64 sorry
      then have "r <XXREAL-0R3 q"
        using A1 xxreal_0_th_2 sorry
      then have "p <XXREAL-0R3 q"
        using A3 xxreal_0_th_2 sorry
      thus " False "
        using A2 A3 xxreal_1_th_56 sorry
    qed
    thus " False "
      using A1 A2 xxreal_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_76:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies ].XXREAL-1K3 r,s .] <>HIDDENR2 [.XXREAL-1K1 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & ].XXREAL-1K3 r,s .] =MEMBEREDR8 [.XXREAL-1K1 p,q .] implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "].XXREAL-1K3 r,s .] =MEMBEREDR8 [.XXREAL-1K1 p,q .]"
    have A3: " not r inHIDDENR3 ].XXREAL-1K3 r,s .]"
      using xxreal_1_th_2 sorry
    have A4: "p <=XXREAL-0R1 r"
      using A1 A2 xxreal_1_th_53 sorry
    have "s <=XXREAL-0R1 q"
      using A1 A2 xxreal_1_th_53 sorry
    then have "r <=XXREAL-0R1 q"
      using A1 xxreal_0_th_2 sorry
    thus " False "
      using A2 A3 A4 xxreal_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_77:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies ].XXREAL-1K3 r,s .] <>HIDDENR2 [.XXREAL-1K2 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & ].XXREAL-1K3 r,s .] =MEMBEREDR8 [.XXREAL-1K2 p,q .[ implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "].XXREAL-1K3 r,s .] =MEMBEREDR8 [.XXREAL-1K2 p,q .["
    have A3: " not r inHIDDENR3 ].XXREAL-1K3 r,s .]"
      using xxreal_1_th_2 sorry
    have A4: "p <=XXREAL-0R1 r"
      using A1 A2 xxreal_1_th_57 sorry
    have "s <=XXREAL-0R1 q"
      using A1 A2 xxreal_1_th_57 sorry
    then have "r <XXREAL-0R3 q"
      using A1 xxreal_0_th_2 sorry
    thus " False "
      using A2 A3 A4 xxreal_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_78:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies ].XXREAL-1K3 r,s .] <>HIDDENR2 ].XXREAL-1K4 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & ].XXREAL-1K3 r,s .] =MEMBEREDR8 ].XXREAL-1K4 p,q .[ implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "].XXREAL-1K3 r,s .] =MEMBEREDR8 ].XXREAL-1K4 p,q .["
    have "s inHIDDENR3 ].XXREAL-1K4 p,q .[ implies  False "
    proof(rule impI)
      assume "s inHIDDENR3 ].XXREAL-1K4 p,q .["
      then have A3: "s <XXREAL-0R3 q"
        using xxreal_1_th_4 sorry
      have "p <=XXREAL-0R1 r"
        using A1 A2 xxreal_1_th_65 sorry
      then have "p <=XXREAL-0R1 s"
        using A1 xxreal_0_th_2 sorry
      then have "p <XXREAL-0R3 q"
        using A3 xxreal_0_th_2 sorry
      thus " False "
        using A2 A3 xxreal_1_th_59 sorry
    qed
    thus " False "
      using A1 A2 xxreal_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_79:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies ].XXREAL-1K4 r,s .[ <>HIDDENR2 [.XXREAL-1K1 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & ].XXREAL-1K4 r,s .[ =MEMBEREDR8 [.XXREAL-1K1 p,q .] implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "].XXREAL-1K4 r,s .[ =MEMBEREDR8 [.XXREAL-1K1 p,q .]"
    have A3: " not r inHIDDENR3 ].XXREAL-1K4 r,s .["
      using xxreal_1_th_4 sorry
    have A4: "p <=XXREAL-0R1 r"
      using A1 A2 xxreal_1_th_51 sorry
    have "s <=XXREAL-0R1 q"
      using A1 A2 xxreal_1_th_51 sorry
    then have "r <=XXREAL-0R1 q"
      using A1 xxreal_0_th_2 sorry
    thus " False "
      using A2 A3 A4 xxreal_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_80:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies ].XXREAL-1K4 r,s .[ <>HIDDENR2 ].XXREAL-1K3 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & ].XXREAL-1K4 r,s .[ =MEMBEREDR8 ].XXREAL-1K3 p,q .] implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "].XXREAL-1K4 r,s .[ =MEMBEREDR8 ].XXREAL-1K3 p,q .]"
    have A3: " not s inHIDDENR3 ].XXREAL-1K4 r,s .["
      using xxreal_1_th_4 sorry
    have "p <=XXREAL-0R1 r"
      using A1 A2 xxreal_1_th_59 sorry
    then have A4: "p <XXREAL-0R3 s"
      using A1 xxreal_0_th_2 sorry
    have "s <=XXREAL-0R1 q"
      using A1 A2 xxreal_1_th_59 sorry
    thus " False "
      using A2 A3 A4 xxreal_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_81:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies ].XXREAL-1K4 r,s .[ <>HIDDENR2 [.XXREAL-1K2 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & ].XXREAL-1K4 r,s .[ =MEMBEREDR8 [.XXREAL-1K2 p,q .[ implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "].XXREAL-1K4 r,s .[ =MEMBEREDR8 [.XXREAL-1K2 p,q .["
    have A3: " not r inHIDDENR3 ].XXREAL-1K4 r,s .["
      using xxreal_1_th_4 sorry
    have A4: "p <=XXREAL-0R1 r"
      using A1 A2 xxreal_1_th_56 sorry
    have "s <=XXREAL-0R1 q"
      using A1 A2 xxreal_1_th_56 sorry
    then have "r <XXREAL-0R3 q"
      using A1 xxreal_0_th_2 sorry
    thus " False "
      using A2 A3 A4 xxreal_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_82:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & [.XXREAL-1K1 r,s .] c<XBOOLE-0R2 [.XXREAL-1K1 p,q .] implies p <XXREAL-0R3 r or s <XXREAL-0R3 q"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s implies ([.XXREAL-1K1 r,s .] c<XBOOLE-0R2 [.XXREAL-1K1 p,q .] implies  not (p <XXREAL-0R3 r & s <XXREAL-0R3 q))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
    assume A2: "[.XXREAL-1K1 r,s .] c<XBOOLE-0R2 [.XXREAL-1K1 p,q .]"
    then have A3: "[.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
       sorry
    then have A4: "p <=XXREAL-0R1 r"
      using A1 xxreal_1_th_50 sorry
    have A5: "s <=XXREAL-0R1 q"
      using A1 A3 xxreal_1_th_50 sorry
    have "p <>HIDDENR2 r or s <>HIDDENR2 q"
      using A2 sorry
    thus " not (p <XXREAL-0R3 r & s <XXREAL-0R3 q)"
      using A4 A5 xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_83:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .] implies [.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .] implies [.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
    have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 [.XXREAL-1K1 r,s .] implies t inHIDDENR3 [.XXREAL-1K1 p,q .]"
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume A3: "t inHIDDENR3 [.XXREAL-1K1 r,s .]"
      show "t inHIDDENR3 [.XXREAL-1K1 p,q .]"
      proof-
        have cases: "(t inHIDDENR3 ].XXREAL-1K4 r,s .[ or t =HIDDENR1 r) or t =HIDDENR1 s"
          using A3 xxreal_1_th_5 sorry
        have case1: "t inHIDDENR3 ].XXREAL-1K4 r,s .[ implies t inHIDDENR3 [.XXREAL-1K1 p,q .]"
        proof(rule impI)
          assume "t inHIDDENR3 ].XXREAL-1K4 r,s .["
          thus "t inHIDDENR3 [.XXREAL-1K1 p,q .]"
            using A2 sorry
        qed
        have case2: "t =HIDDENR1 r implies t inHIDDENR3 [.XXREAL-1K1 p,q .]"
        proof(rule impI)
          assume A4: "t =HIDDENR1 r"
          then have A5: "p <=XXREAL-0R1 t"
            using A1 A2 xxreal_1_th_51 sorry
          have "s <=XXREAL-0R1 q"
            using A1 A2 xxreal_1_th_51 sorry
          then have "t <=XXREAL-0R1 q"
            using A1 A4 xxreal_0_th_2 sorry
          thus "t inHIDDENR3 [.XXREAL-1K1 p,q .]"
            using A5 xxreal_1_th_1 sorry
        qed
        have case3: "t =HIDDENR1 s implies t inHIDDENR3 [.XXREAL-1K1 p,q .]"
        proof(rule impI)
          assume A6: "t =HIDDENR1 s"
          have A7: "s <=XXREAL-0R1 q"
            using A1 A2 xxreal_1_th_51 sorry
          have "p <=XXREAL-0R1 r"
            using A1 A2 xxreal_1_th_51 sorry
          then have "p <=XXREAL-0R1 t"
            using A1 A6 xxreal_0_th_2 sorry
          thus "t inHIDDENR3 [.XXREAL-1K1 p,q .]"
            using A6 A7 xxreal_1_th_1 sorry
        qed
        show " ?thesis "
          using cases case1 case2 case3 sorry
      qed
    qed "sorry"
    thus "[.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_84:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies [.XXREAL-1K2 s,p .[ c=MEMBEREDR2 ].XXREAL-1K4 r,p .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies [.XXREAL-1K2 s,p .[ c=MEMBEREDR2 ].XXREAL-1K4 r,p .["
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
    have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 [.XXREAL-1K2 s,p .[ implies t inHIDDENR3 ].XXREAL-1K4 r,p .["
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume A2: "t inHIDDENR3 [.XXREAL-1K2 s,p .["
      then have "s <=XXREAL-0R1 t"
        using xxreal_1_th_3 sorry
      then have A3: "r <XXREAL-0R3 t"
        using A1 xxreal_0_th_2 sorry
      have "t <XXREAL-0R3 p"
        using A2 xxreal_1_th_3 sorry
      thus "t inHIDDENR3 ].XXREAL-1K4 r,p .["
        using A3 xxreal_1_th_4 sorry
    qed "sorry"
    thus "[.XXREAL-1K2 s,p .[ c=MEMBEREDR2 ].XXREAL-1K4 r,p .["
      using membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_85:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 r implies [.XXREAL-1K1 r,s .] c=MEMBEREDR2 {TARSKIK1 r} & [.XXREAL-1K1 r,s .] c=MEMBEREDR2 {TARSKIK1 s}"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 r implies [.XXREAL-1K1 r,s .] c=MEMBEREDR2 {TARSKIK1 r} & [.XXREAL-1K1 r,s .] c=MEMBEREDR2 {TARSKIK1 s}"
  proof(rule ballI,rule ballI,rule impI,rule conjMI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "s <=XXREAL-0R1 r"
    show "[.XXREAL-1K1 r,s .] c=MEMBEREDR2 {TARSKIK1 r}"
    proof-
      have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 [.XXREAL-1K1 r,s .] implies t inHIDDENR3 {TARSKIK1 r}"
      proof(rule ballI,rule impI)
        fix t assume [ty]: "t be ExtRealXXREAL-0M1"
        assume A2: "t inHIDDENR3 [.XXREAL-1K1 r,s .]"
        then have A3: "t <=XXREAL-0R1 s"
          using xxreal_1_th_1 sorry
        have A4: "r <=XXREAL-0R1 t"
          using A2 xxreal_1_th_1 sorry
        have "t <=XXREAL-0R1 r"
          using A1 A3 xxreal_0_th_2 sorry
        then have "r =HIDDENR1 t"
          using A4 xxreal_0_th_1 sorry
        thus "t inHIDDENR3 {TARSKIK1 r}"
          using tarski_def_1 sorry
      qed "sorry"
      thus "[.XXREAL-1K1 r,s .] c=MEMBEREDR2 {TARSKIK1 r}"
        using membered_def_8 sorry
    qed
    have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 [.XXREAL-1K1 r,s .] implies t inHIDDENR3 {TARSKIK1 s}"
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume A5: "t inHIDDENR3 [.XXREAL-1K1 r,s .]"
      then have "r <=XXREAL-0R1 t"
        using xxreal_1_th_1 sorry
      then have A6: "s <=XXREAL-0R1 t"
        using A1 xxreal_0_th_2 sorry
      have "t <=XXREAL-0R1 s"
        using A5 xxreal_1_th_1 sorry
      then have "s =HIDDENR1 t"
        using A6 xxreal_0_th_1 sorry
      thus "t inHIDDENR3 {TARSKIK1 s}"
        using tarski_def_1 sorry
    qed "sorry"
    thus "[.XXREAL-1K1 r,s .] c=MEMBEREDR2 {TARSKIK1 s}"
      using membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_86:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds ].XXREAL-1K4 r,s .[ missesMEMBEREDR14 {TARSKIK2 r,s }"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds ].XXREAL-1K4 r,s .[ missesMEMBEREDR14 {TARSKIK2 r,s }"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 ].XXREAL-1K4 r,s .[ implies  not t inHIDDENR3 {TARSKIK2 r,s }"
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume A1: "t inHIDDENR3 ].XXREAL-1K4 r,s .["
      then have A2: "r <XXREAL-0R3 t"
        using xxreal_1_th_4 sorry
      have "t <XXREAL-0R3 s"
        using A1 xxreal_1_th_4 sorry
      thus " not t inHIDDENR3 {TARSKIK2 r,s }"
        using A2 tarski_def_2 sorry
    qed "sorry"
    thus "].XXREAL-1K4 r,s .[ missesMEMBEREDR14 {TARSKIK2 r,s }"
      using membered_def_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_87:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds [.XXREAL-1K2 r,s .[ missesMEMBEREDR14 {TARSKIK1 s}"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds [.XXREAL-1K2 r,s .[ missesMEMBEREDR14 {TARSKIK1 s}"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 [.XXREAL-1K2 r,s .[ implies  not t inHIDDENR3 {TARSKIK1 s}"
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume "t inHIDDENR3 [.XXREAL-1K2 r,s .["
      then have "t <XXREAL-0R3 s"
        using xxreal_1_th_3 sorry
      thus " not t inHIDDENR3 {TARSKIK1 s}"
        using tarski_def_1 sorry
    qed "sorry"
    thus "[.XXREAL-1K2 r,s .[ missesMEMBEREDR14 {TARSKIK1 s}"
      using membered_def_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_88:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds ].XXREAL-1K3 r,s .] missesMEMBEREDR14 {TARSKIK1 r}"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds ].XXREAL-1K3 r,s .] missesMEMBEREDR14 {TARSKIK1 r}"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 ].XXREAL-1K3 r,s .] implies  not t inHIDDENR3 {TARSKIK1 r}"
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
      then have "r <XXREAL-0R3 t"
        using xxreal_1_th_2 sorry
      thus " not t inHIDDENR3 {TARSKIK1 r}"
        using tarski_def_1 sorry
    qed "sorry"
    thus "].XXREAL-1K3 r,s .] missesMEMBEREDR14 {TARSKIK1 r}"
      using membered_def_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_89:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 p implies [.XXREAL-1K1 r,s .] missesMEMBEREDR14 ].XXREAL-1K4 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 p implies [.XXREAL-1K1 r,s .] missesMEMBEREDR14 ].XXREAL-1K4 p,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "s <=XXREAL-0R1 p"
    have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 [.XXREAL-1K1 r,s .] implies  not t inHIDDENR3 ].XXREAL-1K4 p,q .["
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume "t inHIDDENR3 [.XXREAL-1K1 r,s .]"
      then have "t <=XXREAL-0R1 s"
        using xxreal_1_th_1 sorry
      then have "t <=XXREAL-0R1 p"
        using A1 xxreal_0_th_2 sorry
      thus " not t inHIDDENR3 ].XXREAL-1K4 p,q .["
        using xxreal_1_th_4 sorry
    qed "sorry"
    thus "[.XXREAL-1K1 r,s .] missesMEMBEREDR14 ].XXREAL-1K4 p,q .["
      using membered_def_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_90:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 p implies [.XXREAL-1K1 r,s .] missesMEMBEREDR14 ].XXREAL-1K3 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 p implies [.XXREAL-1K1 r,s .] missesMEMBEREDR14 ].XXREAL-1K3 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "s <=XXREAL-0R1 p"
    have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 [.XXREAL-1K1 r,s .] implies  not t inHIDDENR3 ].XXREAL-1K3 p,q .]"
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume "t inHIDDENR3 [.XXREAL-1K1 r,s .]"
      then have "t <=XXREAL-0R1 s"
        using xxreal_1_th_1 sorry
      then have "t <=XXREAL-0R1 p"
        using A1 xxreal_0_th_2 sorry
      thus " not t inHIDDENR3 ].XXREAL-1K3 p,q .]"
        using xxreal_1_th_2 sorry
    qed "sorry"
    thus "[.XXREAL-1K1 r,s .] missesMEMBEREDR14 ].XXREAL-1K3 p,q .]"
      using membered_def_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_91:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 p implies ].XXREAL-1K3 r,s .] missesMEMBEREDR14 ].XXREAL-1K4 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 p implies ].XXREAL-1K3 r,s .] missesMEMBEREDR14 ].XXREAL-1K4 p,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "s <=XXREAL-0R1 p"
    have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 ].XXREAL-1K3 r,s .] implies  not t inHIDDENR3 ].XXREAL-1K4 p,q .["
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
      then have "t <=XXREAL-0R1 s"
        using xxreal_1_th_2 sorry
      then have "t <=XXREAL-0R1 p"
        using A1 xxreal_0_th_2 sorry
      thus " not t inHIDDENR3 ].XXREAL-1K4 p,q .["
        using xxreal_1_th_4 sorry
    qed "sorry"
    thus "].XXREAL-1K3 r,s .] missesMEMBEREDR14 ].XXREAL-1K4 p,q .["
      using membered_def_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_92:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 p implies ].XXREAL-1K3 r,s .] missesMEMBEREDR14 ].XXREAL-1K3 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 p implies ].XXREAL-1K3 r,s .] missesMEMBEREDR14 ].XXREAL-1K3 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "s <=XXREAL-0R1 p"
    have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 ].XXREAL-1K3 r,s .] implies  not t inHIDDENR3 ].XXREAL-1K3 p,q .]"
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
      then have "t <=XXREAL-0R1 s"
        using xxreal_1_th_2 sorry
      then have "t <=XXREAL-0R1 p"
        using A1 xxreal_0_th_2 sorry
      thus " not t inHIDDENR3 ].XXREAL-1K3 p,q .]"
        using xxreal_1_th_2 sorry
    qed "sorry"
    thus "].XXREAL-1K3 r,s .] missesMEMBEREDR14 ].XXREAL-1K3 p,q .]"
      using membered_def_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_93:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 p implies ].XXREAL-1K4 r,s .[ missesMEMBEREDR14 [.XXREAL-1K1 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 p implies ].XXREAL-1K4 r,s .[ missesMEMBEREDR14 [.XXREAL-1K1 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "s <=XXREAL-0R1 p"
    have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 ].XXREAL-1K4 r,s .[ implies  not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume "t inHIDDENR3 ].XXREAL-1K4 r,s .["
      then have "t <XXREAL-0R3 s"
        using xxreal_1_th_4 sorry
      then have "t <XXREAL-0R3 p"
        using A1 xxreal_0_th_2 sorry
      thus " not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
        using xxreal_1_th_1 sorry
    qed "sorry"
    thus "].XXREAL-1K4 r,s .[ missesMEMBEREDR14 [.XXREAL-1K1 p,q .]"
      using membered_def_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_94:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 p implies ].XXREAL-1K4 r,s .[ missesMEMBEREDR14 [.XXREAL-1K2 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 p implies ].XXREAL-1K4 r,s .[ missesMEMBEREDR14 [.XXREAL-1K2 p,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "s <=XXREAL-0R1 p"
    have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 ].XXREAL-1K4 r,s .[ implies  not t inHIDDENR3 [.XXREAL-1K2 p,q .["
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume "t inHIDDENR3 ].XXREAL-1K4 r,s .["
      then have "t <XXREAL-0R3 s"
        using xxreal_1_th_4 sorry
      then have "t <XXREAL-0R3 p"
        using A1 xxreal_0_th_2 sorry
      thus " not t inHIDDENR3 [.XXREAL-1K2 p,q .["
        using xxreal_1_th_3 sorry
    qed "sorry"
    thus "].XXREAL-1K4 r,s .[ missesMEMBEREDR14 [.XXREAL-1K2 p,q .["
      using membered_def_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_95:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 p implies [.XXREAL-1K2 r,s .[ missesMEMBEREDR14 [.XXREAL-1K1 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 p implies [.XXREAL-1K2 r,s .[ missesMEMBEREDR14 [.XXREAL-1K1 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "s <=XXREAL-0R1 p"
    have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 [.XXREAL-1K2 r,s .[ implies  not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume "t inHIDDENR3 [.XXREAL-1K2 r,s .["
      then have "t <XXREAL-0R3 s"
        using xxreal_1_th_3 sorry
      then have "t <XXREAL-0R3 p"
        using A1 xxreal_0_th_2 sorry
      thus " not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
        using xxreal_1_th_1 sorry
    qed "sorry"
    thus "[.XXREAL-1K2 r,s .[ missesMEMBEREDR14 [.XXREAL-1K1 p,q .]"
      using membered_def_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_96:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 p implies [.XXREAL-1K2 r,s .[ missesMEMBEREDR14 [.XXREAL-1K2 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 p implies [.XXREAL-1K2 r,s .[ missesMEMBEREDR14 [.XXREAL-1K2 p,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "s <=XXREAL-0R1 p"
    have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 [.XXREAL-1K2 r,s .[ implies  not t inHIDDENR3 [.XXREAL-1K2 p,q .["
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume "t inHIDDENR3 [.XXREAL-1K2 r,s .["
      then have "t <XXREAL-0R3 s"
        using xxreal_1_th_3 sorry
      then have "t <XXREAL-0R3 p"
        using A1 xxreal_0_th_2 sorry
      thus " not t inHIDDENR3 [.XXREAL-1K2 p,q .["
        using xxreal_1_th_3 sorry
    qed "sorry"
    thus "[.XXREAL-1K2 r,s .[ missesMEMBEREDR14 [.XXREAL-1K2 p,q .["
      using membered_def_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_97:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 p & r <XXREAL-0R3 s implies  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 p & r <XXREAL-0R3 s implies  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 p"
      and A2: "r <XXREAL-0R3 s"
    show " not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
    proof-
      have cases: "s <=XXREAL-0R1 p or p <=XXREAL-0R1 s"
         sorry
      have case1: "s <=XXREAL-0R1 p implies  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      proof(rule impI)
        assume A3: "s <=XXREAL-0R1 p"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A4: "r <XXREAL-0R3 t"and A5: "t <XXREAL-0R3 s"
          using A2 xreal_1_th_227 sorry
        have "t inHIDDENR3 ].XXREAL-1K4 r,s .[ &  not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
        proof(rule conjMI)
          show "t inHIDDENR3 ].XXREAL-1K4 r,s .["
            using A4 A5 xxreal_1_th_4 sorry
          have "t <XXREAL-0R3 p"
            using A3 A5 xxreal_0_th_2 sorry
          thus " not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
            using xxreal_1_th_1 sorry
        qed
        thus " not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      have case2: "p <=XXREAL-0R1 s implies  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      proof(rule impI)
        assume A6: "p <=XXREAL-0R1 s"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A7: "r <XXREAL-0R3 t"and A8: "t <XXREAL-0R3 p"
          using A1 xreal_1_th_227 sorry
        have Cut1550: "t <XXREAL-0R3 s"
          using A6 A8 xxreal_0_th_2 sorry
        have "t inHIDDENR3 ].XXREAL-1K4 r,s .[ &  not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
        proof(rule conjMI)
          show "t inHIDDENR3 ].XXREAL-1K4 r,s .["
            using A7 xxreal_1_th_4 Cut1550 sorry
          show " not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
            using A8 xxreal_1_th_1 sorry
        qed
        thus " not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_98:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 p & r <XXREAL-0R3 s implies  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 p & r <XXREAL-0R3 s implies  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 p"
      and A2: "r <XXREAL-0R3 s"
    show " not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
    proof-
      have cases: "s <=XXREAL-0R1 p or p <=XXREAL-0R1 s"
         sorry
      have case1: "s <=XXREAL-0R1 p implies  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      proof(rule impI)
        assume A3: "s <=XXREAL-0R1 p"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A4: "r <XXREAL-0R3 t"and A5: "t <XXREAL-0R3 s"
          using A2 xreal_1_th_227 sorry
        have "t inHIDDENR3 [.XXREAL-1K2 r,s .[ &  not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
        proof(rule conjMI)
          show "t inHIDDENR3 [.XXREAL-1K2 r,s .["
            using A4 A5 xxreal_1_th_3 sorry
          have "t <XXREAL-0R3 p"
            using A3 A5 xxreal_0_th_2 sorry
          thus " not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
            using xxreal_1_th_1 sorry
        qed
        thus " not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      have case2: "p <=XXREAL-0R1 s implies  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      proof(rule impI)
        assume A6: "p <=XXREAL-0R1 s"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A7: "r <XXREAL-0R3 t"and A8: "t <XXREAL-0R3 p"
          using A1 xreal_1_th_227 sorry
        have Cut1579: "t <XXREAL-0R3 s"
          using A6 A8 xxreal_0_th_2 sorry
        have "t inHIDDENR3 [.XXREAL-1K2 r,s .[ &  not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
        proof(rule conjMI)
          show "t inHIDDENR3 [.XXREAL-1K2 r,s .["
            using A7 xxreal_1_th_3 Cut1579 sorry
          show " not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
            using A8 xxreal_1_th_1 sorry
        qed
        thus " not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_99:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 p & r <XXREAL-0R3 s implies  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 p & r <XXREAL-0R3 s implies  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 p"
      and A2: "r <XXREAL-0R3 s"
    show " not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
    proof-
      have cases: "s <=XXREAL-0R1 p or p <=XXREAL-0R1 s"
         sorry
      have case1: "s <=XXREAL-0R1 p implies  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      proof(rule impI)
        assume A3: "s <=XXREAL-0R1 p"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A4: "r <XXREAL-0R3 t"and A5: "t <XXREAL-0R3 s"
          using A2 xreal_1_th_227 sorry
        have "t inHIDDENR3 ].XXREAL-1K3 r,s .] &  not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
        proof(rule conjMI)
          show "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
            using A4 A5 xxreal_1_th_2 sorry
          have "t <XXREAL-0R3 p"
            using A3 A5 xxreal_0_th_2 sorry
          thus " not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
            using xxreal_1_th_1 sorry
        qed
        thus " not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      have case2: "p <=XXREAL-0R1 s implies  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      proof(rule impI)
        assume A6: "p <=XXREAL-0R1 s"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A7: "r <XXREAL-0R3 t"and A8: "t <XXREAL-0R3 p"
          using A1 xreal_1_th_227 sorry
        have Cut1608: "t <XXREAL-0R3 s"
          using A6 A8 xxreal_0_th_2 sorry
        have "t inHIDDENR3 ].XXREAL-1K3 r,s .] &  not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
        proof(rule conjMI)
          show "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
            using A7 xxreal_1_th_2 Cut1608 sorry
          show " not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
            using A8 xxreal_1_th_1 sorry
        qed
        thus " not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_100:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 p & r <=XXREAL-0R1 s implies  not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 p & r <=XXREAL-0R1 s implies  not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 p"
      and A2: "r <=XXREAL-0R1 s"
    obtain t where 
      [ty]:"t be ExtRealXXREAL-0M1" and tDef:"t = r"
       sorry
    have " ex t be ExtRealXXREAL-0M1 st t inHIDDENR3 [.XXREAL-1K1 r,s .] &  not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
    proof(rule bexI[of _ "t"],rule conjMI)
      show "t inHIDDENR3 [.XXREAL-1K1 r,s .]"
        using A2 xxreal_1_th_1 sorry
      show " not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
        using A1 xxreal_1_th_1 sorry
    qed "sorry"
    thus " not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_101:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 p & r <XXREAL-0R3 s implies  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 p & r <XXREAL-0R3 s implies  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 p"
      and A2: "r <XXREAL-0R3 s"
    show " not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
    proof-
      have cases: "s <=XXREAL-0R1 p or p <=XXREAL-0R1 s"
         sorry
      have case1: "s <=XXREAL-0R1 p implies  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
      proof(rule impI)
        assume A3: "s <=XXREAL-0R1 p"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A4: "r <XXREAL-0R3 t"and A5: "t <XXREAL-0R3 s"
          using A2 xreal_1_th_227 sorry
        have "t inHIDDENR3 ].XXREAL-1K4 r,s .[ &  not t inHIDDENR3 [.XXREAL-1K2 p,q .["
        proof(rule conjMI)
          show "t inHIDDENR3 ].XXREAL-1K4 r,s .["
            using A4 A5 xxreal_1_th_4 sorry
          have "t <XXREAL-0R3 p"
            using A3 A5 xxreal_0_th_2 sorry
          thus " not t inHIDDENR3 [.XXREAL-1K2 p,q .["
            using xxreal_1_th_3 sorry
        qed
        thus " not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      have case2: "p <=XXREAL-0R1 s implies  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
      proof(rule impI)
        assume A6: "p <=XXREAL-0R1 s"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A7: "r <XXREAL-0R3 t"and A8: "t <XXREAL-0R3 p"
          using A1 xreal_1_th_227 sorry
        have Cut1648: "t <XXREAL-0R3 s"
          using A6 A8 xxreal_0_th_2 sorry
        have "t inHIDDENR3 ].XXREAL-1K4 r,s .[ &  not t inHIDDENR3 [.XXREAL-1K2 p,q .["
        proof(rule conjMI)
          show "t inHIDDENR3 ].XXREAL-1K4 r,s .["
            using A7 xxreal_1_th_4 Cut1648 sorry
          show " not t inHIDDENR3 [.XXREAL-1K2 p,q .["
            using A8 xxreal_1_th_3 sorry
        qed
        thus " not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_102:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 p & r <XXREAL-0R3 s implies  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 p & r <XXREAL-0R3 s implies  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 p"
      and A2: "r <XXREAL-0R3 s"
    show " not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
    proof-
      have cases: "s <=XXREAL-0R1 p or p <=XXREAL-0R1 s"
         sorry
      have case1: "s <=XXREAL-0R1 p implies  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
      proof(rule impI)
        assume A3: "s <=XXREAL-0R1 p"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A4: "r <XXREAL-0R3 t"and A5: "t <XXREAL-0R3 s"
          using A2 xreal_1_th_227 sorry
        have "t inHIDDENR3 ].XXREAL-1K3 r,s .] &  not t inHIDDENR3 [.XXREAL-1K2 p,q .["
        proof(rule conjMI)
          show "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
            using A4 A5 xxreal_1_th_2 sorry
          have "t <XXREAL-0R3 p"
            using A3 A5 xxreal_0_th_2 sorry
          thus " not t inHIDDENR3 [.XXREAL-1K2 p,q .["
            using xxreal_1_th_3 sorry
        qed
        thus " not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      have case2: "p <=XXREAL-0R1 s implies  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
      proof(rule impI)
        assume A6: "p <=XXREAL-0R1 s"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A7: "r <XXREAL-0R3 t"and A8: "t <XXREAL-0R3 p"
          using A1 xreal_1_th_227 sorry
        have Cut1677: "t <XXREAL-0R3 s"
          using A6 A8 xxreal_0_th_2 sorry
        have "t inHIDDENR3 ].XXREAL-1K3 r,s .] &  not t inHIDDENR3 [.XXREAL-1K2 p,q .["
        proof(rule conjMI)
          show "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
            using A7 xxreal_1_th_2 Cut1677 sorry
          show " not t inHIDDENR3 [.XXREAL-1K2 p,q .["
            using A8 xxreal_1_th_3 sorry
        qed
        thus " not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_103:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 p & r <XXREAL-0R3 s implies  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 p & r <XXREAL-0R3 s implies  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 p"
      and A2: "r <XXREAL-0R3 s"
    show " not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
    proof-
      have cases: "s <=XXREAL-0R1 p or p <=XXREAL-0R1 s"
         sorry
      have case1: "s <=XXREAL-0R1 p implies  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
      proof(rule impI)
        assume A3: "s <=XXREAL-0R1 p"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A4: "r <XXREAL-0R3 t"and A5: "t <XXREAL-0R3 s"
          using A2 xreal_1_th_227 sorry
        have "t inHIDDENR3 [.XXREAL-1K2 r,s .[ &  not t inHIDDENR3 [.XXREAL-1K2 p,q .["
        proof(rule conjMI)
          show "t inHIDDENR3 [.XXREAL-1K2 r,s .["
            using A4 A5 xxreal_1_th_3 sorry
          have "t <XXREAL-0R3 p"
            using A3 A5 xxreal_0_th_2 sorry
          thus " not t inHIDDENR3 [.XXREAL-1K2 p,q .["
            using xxreal_1_th_3 sorry
        qed
        thus " not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      have case2: "p <=XXREAL-0R1 s implies  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
      proof(rule impI)
        assume A6: "p <=XXREAL-0R1 s"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A7: "r <XXREAL-0R3 t"and A8: "t <XXREAL-0R3 p"
          using A1 xreal_1_th_227 sorry
        have Cut1706: "t <XXREAL-0R3 s"
          using A6 A8 xxreal_0_th_2 sorry
        have "t inHIDDENR3 [.XXREAL-1K2 r,s .[ &  not t inHIDDENR3 [.XXREAL-1K2 p,q .["
        proof(rule conjMI)
          show "t inHIDDENR3 [.XXREAL-1K2 r,s .["
            using A7 xxreal_1_th_3 Cut1706 sorry
          show " not t inHIDDENR3 [.XXREAL-1K2 p,q .["
            using A8 xxreal_1_th_3 sorry
        qed
        thus " not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_104:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 p & r <=XXREAL-0R1 s implies  not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 p & r <=XXREAL-0R1 s implies  not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 p"
      and A2: "r <=XXREAL-0R1 s"
    obtain t where 
      [ty]:"t be ExtRealXXREAL-0M1" and tDef:"t = r"
       sorry
    have " ex t be ExtRealXXREAL-0M1 st t inHIDDENR3 [.XXREAL-1K1 r,s .] &  not t inHIDDENR3 [.XXREAL-1K2 p,q .["
    proof(rule bexI[of _ "t"],rule conjMI)
      show "t inHIDDENR3 [.XXREAL-1K1 r,s .]"
        using A2 xxreal_1_th_1 sorry
      show " not t inHIDDENR3 [.XXREAL-1K2 p,q .["
        using A1 xxreal_1_th_3 sorry
    qed "sorry"
    thus " not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
      using membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_105:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 p & r <XXREAL-0R3 s implies  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 p & r <XXREAL-0R3 s implies  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 p"
      and A2: "r <XXREAL-0R3 s"
    show " not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
    proof-
      have cases: "s <=XXREAL-0R1 p or p <=XXREAL-0R1 s"
         sorry
      have case1: "s <=XXREAL-0R1 p implies  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
      proof(rule impI)
        assume A3: "s <=XXREAL-0R1 p"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A4: "r <XXREAL-0R3 t"and A5: "t <XXREAL-0R3 s"
          using A2 xreal_1_th_227 sorry
        have "t inHIDDENR3 ].XXREAL-1K4 r,s .[ &  not t inHIDDENR3 ].XXREAL-1K3 p,q .]"
        proof(rule conjMI)
          show "t inHIDDENR3 ].XXREAL-1K4 r,s .["
            using A4 A5 xxreal_1_th_4 sorry
          have "t <XXREAL-0R3 p"
            using A3 A5 xxreal_0_th_2 sorry
          thus " not t inHIDDENR3 ].XXREAL-1K3 p,q .]"
            using xxreal_1_th_2 sorry
        qed
        thus " not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      have case2: "p <=XXREAL-0R1 s implies  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
      proof(rule impI)
        assume A6: "p <=XXREAL-0R1 s"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A7: "r <XXREAL-0R3 t"and A8: "t <XXREAL-0R3 p"
          using A1 xreal_1_th_227 sorry
        have Cut1746: "t <XXREAL-0R3 s"
          using A6 A8 xxreal_0_th_2 sorry
        have "t inHIDDENR3 ].XXREAL-1K4 r,s .[ &  not t inHIDDENR3 ].XXREAL-1K3 p,q .]"
        proof(rule conjMI)
          show "t inHIDDENR3 ].XXREAL-1K4 r,s .["
            using A7 xxreal_1_th_4 Cut1746 sorry
          show " not t inHIDDENR3 ].XXREAL-1K3 p,q .]"
            using A8 xxreal_1_th_2 sorry
        qed
        thus " not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_106:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 p & r <XXREAL-0R3 s implies  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 p & r <XXREAL-0R3 s implies  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 p"
      and A2: "r <XXREAL-0R3 s"
    obtain t where 
      [ty]:"t be ExtRealXXREAL-0M1" and tDef:"t = r"
       sorry
    have " ex t be ExtRealXXREAL-0M1 st t inHIDDENR3 [.XXREAL-1K2 r,s .[ &  not t inHIDDENR3 ].XXREAL-1K3 p,q .]"
    proof(rule bexI[of _ "t"],rule conjMI)
      show "t inHIDDENR3 [.XXREAL-1K2 r,s .["
        using A2 xxreal_1_th_3 sorry
      show " not t inHIDDENR3 ].XXREAL-1K3 p,q .]"
        using A1 xxreal_1_th_2 sorry
    qed "sorry"
    thus " not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
      using membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_107:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 p & r <XXREAL-0R3 s implies  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 p & r <XXREAL-0R3 s implies  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 p"
      and A2: "r <XXREAL-0R3 s"
    show " not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
    proof-
      have cases: "s <=XXREAL-0R1 p or p <=XXREAL-0R1 s"
         sorry
      have case1: "s <=XXREAL-0R1 p implies  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
      proof(rule impI)
        assume A3: "s <=XXREAL-0R1 p"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A4: "r <XXREAL-0R3 t"and A5: "t <XXREAL-0R3 s"
          using A2 xreal_1_th_227 sorry
        have "t inHIDDENR3 ].XXREAL-1K3 r,s .] &  not t inHIDDENR3 ].XXREAL-1K3 p,q .]"
        proof(rule conjMI)
          show "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
            using A4 A5 xxreal_1_th_2 sorry
          have "t <XXREAL-0R3 p"
            using A3 A5 xxreal_0_th_2 sorry
          thus " not t inHIDDENR3 ].XXREAL-1K3 p,q .]"
            using xxreal_1_th_2 sorry
        qed
        thus " not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      have case2: "p <=XXREAL-0R1 s implies  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
      proof(rule impI)
        assume A6: "p <=XXREAL-0R1 s"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A7: "r <XXREAL-0R3 t"and A8: "t <XXREAL-0R3 p"
          using A1 xreal_1_th_227 sorry
        have Cut1786: "t <=XXREAL-0R1 s"
          using A6 A8 xxreal_0_th_2 sorry
        have "t inHIDDENR3 ].XXREAL-1K3 r,s .] &  not t inHIDDENR3 ].XXREAL-1K3 p,q .]"
        proof(rule conjMI)
          show "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
            using A7 xxreal_1_th_2 Cut1786 sorry
          show " not t inHIDDENR3 ].XXREAL-1K3 p,q .]"
            using A8 xxreal_1_th_2 sorry
        qed
        thus " not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_108:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 p & r <=XXREAL-0R1 s implies  not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 p & r <=XXREAL-0R1 s implies  not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 p"
      and A2: "r <=XXREAL-0R1 s"
    have "r inHIDDENR3 [.XXREAL-1K1 r,s .] &  not r inHIDDENR3 ].XXREAL-1K3 p,q .]"
    proof(rule conjMI)
      show "r inHIDDENR3 [.XXREAL-1K1 r,s .]"
        using A2 xxreal_1_th_1 sorry
      show " not r inHIDDENR3 ].XXREAL-1K3 p,q .]"
        using A1 xxreal_1_th_2 sorry
    qed
    thus " not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
      using bexI[of _ "r"] membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_109:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 p & r <=XXREAL-0R1 s implies  not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 p & r <=XXREAL-0R1 s implies  not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 p"
      and A2: "r <=XXREAL-0R1 s"
    have "r inHIDDENR3 [.XXREAL-1K1 r,s .] &  not r inHIDDENR3 ].XXREAL-1K4 p,q .["
    proof(rule conjMI)
      show "r inHIDDENR3 [.XXREAL-1K1 r,s .]"
        using A2 xxreal_1_th_1 sorry
      show " not r inHIDDENR3 ].XXREAL-1K4 p,q .["
        using A1 xxreal_1_th_4 sorry
    qed
    thus " not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
      using bexI[of _ "r"] membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_110:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 p & r <XXREAL-0R3 s implies  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 p & r <XXREAL-0R3 s implies  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 p"
      and A2: "r <XXREAL-0R3 s"
    have "r inHIDDENR3 [.XXREAL-1K2 r,s .[ &  not r inHIDDENR3 ].XXREAL-1K4 p,q .["
    proof(rule conjMI)
      show "r inHIDDENR3 [.XXREAL-1K2 r,s .["
        using A2 xxreal_1_th_3 sorry
      show " not r inHIDDENR3 ].XXREAL-1K4 p,q .["
        using A1 xxreal_1_th_4 sorry
    qed
    thus " not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
      using bexI[of _ "r"] membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_111:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 p & r <XXREAL-0R3 s implies  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 p & r <XXREAL-0R3 s implies  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 p"
      and A2: "r <XXREAL-0R3 s"
    show " not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
    proof-
      have cases: "s <=XXREAL-0R1 p or p <=XXREAL-0R1 s"
         sorry
      have case1: "s <=XXREAL-0R1 p implies  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
      proof(rule impI)
        assume A3: "s <=XXREAL-0R1 p"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A4: "r <XXREAL-0R3 t"and A5: "t <XXREAL-0R3 s"
          using A2 xreal_1_th_227 sorry
        have "t inHIDDENR3 ].XXREAL-1K3 r,s .] &  not t inHIDDENR3 ].XXREAL-1K4 p,q .["
        proof(rule conjMI)
          show "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
            using A4 A5 xxreal_1_th_2 sorry
          have "t <XXREAL-0R3 p"
            using A3 A5 xxreal_0_th_2 sorry
          thus " not t inHIDDENR3 ].XXREAL-1K4 p,q .["
            using xxreal_1_th_4 sorry
        qed
        thus " not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      have case2: "p <=XXREAL-0R1 s implies  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
      proof(rule impI)
        assume A6: "p <=XXREAL-0R1 s"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A7: "r <XXREAL-0R3 t"and A8: "t <XXREAL-0R3 p"
          using A1 xreal_1_th_227 sorry
        have Cut1848: "t <=XXREAL-0R1 s"
          using A6 A8 xxreal_0_th_2 sorry
        have "t inHIDDENR3 ].XXREAL-1K3 r,s .] &  not t inHIDDENR3 ].XXREAL-1K4 p,q .["
        proof(rule conjMI)
          show "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
            using A7 xxreal_1_th_2 Cut1848 sorry
          show " not t inHIDDENR3 ].XXREAL-1K4 p,q .["
            using A8 xxreal_1_th_4 sorry
        qed
        thus " not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_112:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 p & r <XXREAL-0R3 s implies  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 p & r <XXREAL-0R3 s implies  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 p"
      and A2: "r <XXREAL-0R3 s"
    show " not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
    proof-
      have cases: "s <=XXREAL-0R1 p or p <=XXREAL-0R1 s"
         sorry
      have case1: "s <=XXREAL-0R1 p implies  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
      proof(rule impI)
        assume A3: "s <=XXREAL-0R1 p"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A4: "r <XXREAL-0R3 t"and A5: "t <XXREAL-0R3 s"
          using A2 xreal_1_th_227 sorry
        have "t inHIDDENR3 ].XXREAL-1K4 r,s .[ &  not t inHIDDENR3 ].XXREAL-1K4 p,q .["
        proof(rule conjMI)
          show "t inHIDDENR3 ].XXREAL-1K4 r,s .["
            using A4 A5 xxreal_1_th_4 sorry
          have "t <XXREAL-0R3 p"
            using A3 A5 xxreal_0_th_2 sorry
          thus " not t inHIDDENR3 ].XXREAL-1K4 p,q .["
            using xxreal_1_th_4 sorry
        qed
        thus " not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      have case2: "p <=XXREAL-0R1 s implies  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
      proof(rule impI)
        assume A6: "p <=XXREAL-0R1 s"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A7: "r <XXREAL-0R3 t"and A8: "t <XXREAL-0R3 p"
          using A1 xreal_1_th_227 sorry
        have Cut1877: "t <XXREAL-0R3 s"
          using A6 A8 xxreal_0_th_2 sorry
        have "t inHIDDENR3 ].XXREAL-1K4 r,s .[ &  not t inHIDDENR3 ].XXREAL-1K4 p,q .["
        proof(rule conjMI)
          show "t inHIDDENR3 ].XXREAL-1K4 r,s .["
            using A7 xxreal_1_th_4 Cut1877 sorry
          show " not t inHIDDENR3 ].XXREAL-1K4 p,q .["
            using A8 xxreal_1_th_4 sorry
        qed
        thus " not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_113:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds q <XXREAL-0R3 s & r <XXREAL-0R3 s implies  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds q <XXREAL-0R3 s & r <XXREAL-0R3 s implies  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "q <XXREAL-0R3 s"
      and A2: "r <XXREAL-0R3 s"
    show " not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
    proof-
      have cases: "r <=XXREAL-0R1 q or q <=XXREAL-0R1 r"
         sorry
      have case1: "r <=XXREAL-0R1 q implies  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      proof(rule impI)
        assume A3: "r <=XXREAL-0R1 q"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A4: "q <XXREAL-0R3 t"and A5: "t <XXREAL-0R3 s"
          using A1 xreal_1_th_227 sorry
        have Cut1896: "r <XXREAL-0R3 t"
          using A3 A4 xxreal_0_th_2 sorry
        have "t inHIDDENR3 ].XXREAL-1K4 r,s .[ &  not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
        proof(rule conjMI)
          show "t inHIDDENR3 ].XXREAL-1K4 r,s .["
            using A5 xxreal_1_th_4 Cut1896 sorry
          show " not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
            using A4 xxreal_1_th_1 sorry
        qed
        thus " not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      have case2: "q <=XXREAL-0R1 r implies  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      proof(rule impI)
        assume A6: "q <=XXREAL-0R1 r"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A7: "r <XXREAL-0R3 t"and A8: "t <XXREAL-0R3 s"
          using A2 xreal_1_th_227 sorry
        have "t inHIDDENR3 ].XXREAL-1K4 r,s .[ &  not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
        proof(rule conjMI)
          show "t inHIDDENR3 ].XXREAL-1K4 r,s .["
            using A7 A8 xxreal_1_th_4 sorry
          have "q <XXREAL-0R3 t"
            using A6 A7 xxreal_0_th_2 sorry
          thus " not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
            using xxreal_1_th_1 sorry
        qed
        thus " not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_114:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds q <XXREAL-0R3 s & r <XXREAL-0R3 s implies  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds q <XXREAL-0R3 s & r <XXREAL-0R3 s implies  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "q <XXREAL-0R3 s"
      and A2: "r <XXREAL-0R3 s"
    show " not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
    proof-
      have cases: "r <=XXREAL-0R1 q or q <=XXREAL-0R1 r"
         sorry
      have case1: "r <=XXREAL-0R1 q implies  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      proof(rule impI)
        assume A3: "r <=XXREAL-0R1 q"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A4: "q <XXREAL-0R3 t"and A5: "t <XXREAL-0R3 s"
          using A1 xreal_1_th_227 sorry
        have Cut1925: "r <XXREAL-0R3 t"
          using A3 A4 xxreal_0_th_2 sorry
        have "t inHIDDENR3 [.XXREAL-1K2 r,s .[ &  not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
        proof(rule conjMI)
          show "t inHIDDENR3 [.XXREAL-1K2 r,s .["
            using A5 xxreal_1_th_3 Cut1925 sorry
          show " not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
            using A4 xxreal_1_th_1 sorry
        qed
        thus " not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      have case2: "q <=XXREAL-0R1 r implies  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      proof(rule impI)
        assume A6: "q <=XXREAL-0R1 r"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A7: "r <XXREAL-0R3 t"and A8: "t <XXREAL-0R3 s"
          using A2 xreal_1_th_227 sorry
        have "t inHIDDENR3 [.XXREAL-1K2 r,s .[ &  not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
        proof(rule conjMI)
          show "t inHIDDENR3 [.XXREAL-1K2 r,s .["
            using A7 A8 xxreal_1_th_3 sorry
          have "q <XXREAL-0R3 t"
            using A6 A7 xxreal_0_th_2 sorry
          thus " not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
            using xxreal_1_th_1 sorry
        qed
        thus " not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_115:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds q <XXREAL-0R3 s & r <XXREAL-0R3 s implies  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds q <XXREAL-0R3 s & r <XXREAL-0R3 s implies  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "q <XXREAL-0R3 s"
      and A2: "r <XXREAL-0R3 s"
    show " not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
    proof-
      have cases: "r <=XXREAL-0R1 q or q <=XXREAL-0R1 r"
         sorry
      have case1: "r <=XXREAL-0R1 q implies  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      proof(rule impI)
        assume A3: "r <=XXREAL-0R1 q"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A4: "q <XXREAL-0R3 t"and A5: "t <XXREAL-0R3 s"
          using A1 xreal_1_th_227 sorry
        have Cut1954: "r <XXREAL-0R3 t"
          using A3 A4 xxreal_0_th_2 sorry
        have "t inHIDDENR3 ].XXREAL-1K3 r,s .] &  not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
        proof(rule conjMI)
          show "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
            using A5 xxreal_1_th_2 Cut1954 sorry
          show " not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
            using A4 xxreal_1_th_1 sorry
        qed
        thus " not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      have case2: "q <=XXREAL-0R1 r implies  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      proof(rule impI)
        assume A6: "q <=XXREAL-0R1 r"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A7: "r <XXREAL-0R3 t"and A8: "t <XXREAL-0R3 s"
          using A2 xreal_1_th_227 sorry
        have "t inHIDDENR3 ].XXREAL-1K3 r,s .] &  not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
        proof(rule conjMI)
          show "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
            using A7 A8 xxreal_1_th_2 sorry
          have "q <XXREAL-0R3 t"
            using A6 A7 xxreal_0_th_2 sorry
          thus " not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
            using xxreal_1_th_1 sorry
        qed
        thus " not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_116:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds q <XXREAL-0R3 s & r <=XXREAL-0R1 s implies  not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds q <XXREAL-0R3 s & r <=XXREAL-0R1 s implies  not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "q <XXREAL-0R3 s"
      and A2: "r <=XXREAL-0R1 s"
    show " not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
    proof-
      have cases: "r <=XXREAL-0R1 q or q <XXREAL-0R3 r"
         sorry
      have case1: "r <=XXREAL-0R1 q implies  not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      proof(rule impI)
        assume A3: "r <=XXREAL-0R1 q"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A4: "q <XXREAL-0R3 t"and A5: "t <XXREAL-0R3 s"
          using A1 xreal_1_th_227 sorry
        have Cut1983: "r <XXREAL-0R3 t"
          using A3 A4 xxreal_0_th_2 sorry
        have "t inHIDDENR3 [.XXREAL-1K1 r,s .] &  not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
        proof(rule conjMI)
          show "t inHIDDENR3 [.XXREAL-1K1 r,s .]"
            using A5 xxreal_1_th_1 Cut1983 sorry
          show " not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
            using A4 xxreal_1_th_1 sorry
        qed
        thus " not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      have case2: "q <XXREAL-0R3 r implies  not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      proof(rule impI)
        assume A6: "q <XXREAL-0R3 r"
        obtain t where 
          [ty]:"t be ExtRealXXREAL-0M1" and tDef:"t = r"
           sorry
        have " ex t be ExtRealXXREAL-0M1 st t inHIDDENR3 [.XXREAL-1K1 r,s .] &  not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
        proof(rule bexI[of _ "t"],rule conjMI)
          show "t inHIDDENR3 [.XXREAL-1K1 r,s .]"
            using A2 xxreal_1_th_1 sorry
          show " not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
            using A6 xxreal_1_th_1 sorry
        qed "sorry"
        thus " not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
          using membered_def_8 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_117:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds q <XXREAL-0R3 s & r <XXREAL-0R3 s implies  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds q <XXREAL-0R3 s & r <XXREAL-0R3 s implies  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "q <XXREAL-0R3 s"
      and A2: "r <XXREAL-0R3 s"
    show " not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
    proof-
      have cases: "r <=XXREAL-0R1 q or q <XXREAL-0R3 r"
         sorry
      have case1: "r <=XXREAL-0R1 q implies  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
      proof(rule impI)
        assume A3: "r <=XXREAL-0R1 q"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A4: "q <XXREAL-0R3 t"and A5: "t <XXREAL-0R3 s"
          using A1 xreal_1_th_227 sorry
        have Cut2008: "r <XXREAL-0R3 t"
          using A3 A4 xxreal_0_th_2 sorry
        have "t inHIDDENR3 ].XXREAL-1K4 r,s .[ &  not t inHIDDENR3 [.XXREAL-1K2 p,q .["
        proof(rule conjMI)
          show "t inHIDDENR3 ].XXREAL-1K4 r,s .["
            using A5 xxreal_1_th_4 Cut2008 sorry
          show " not t inHIDDENR3 [.XXREAL-1K2 p,q .["
            using A4 xxreal_1_th_3 sorry
        qed
        thus " not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      have case2: "q <XXREAL-0R3 r implies  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
      proof(rule impI)
        assume A6: "q <XXREAL-0R3 r"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A7: "r <XXREAL-0R3 t"and A8: "t <XXREAL-0R3 s"
          using A2 xreal_1_th_227 sorry
        have "t inHIDDENR3 ].XXREAL-1K4 r,s .[ &  not t inHIDDENR3 [.XXREAL-1K2 p,q .["
        proof(rule conjMI)
          show "t inHIDDENR3 ].XXREAL-1K4 r,s .["
            using A7 A8 xxreal_1_th_4 sorry
          have "q <XXREAL-0R3 t"
            using A6 A7 xxreal_0_th_2 sorry
          thus " not t inHIDDENR3 [.XXREAL-1K2 p,q .["
            using xxreal_1_th_3 sorry
        qed
        thus " not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_118:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds q <=XXREAL-0R1 s & r <XXREAL-0R3 s implies  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds q <=XXREAL-0R1 s & r <XXREAL-0R3 s implies  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "q <=XXREAL-0R1 s"
      and A2: "r <XXREAL-0R3 s"
    obtain t where 
      [ty]:"t be ExtRealXXREAL-0M1" and tDef:"t = s"
       sorry
    have " ex t be ExtRealXXREAL-0M1 st t inHIDDENR3 ].XXREAL-1K3 r,s .] &  not t inHIDDENR3 [.XXREAL-1K2 p,q .["
    proof(rule bexI[of _ "t"],rule conjMI)
      show "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
        using A2 xxreal_1_th_2 sorry
      show " not t inHIDDENR3 [.XXREAL-1K2 p,q .["
        using A1 xxreal_1_th_3 sorry
    qed "sorry"
    thus " not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
      using membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_119:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds q <XXREAL-0R3 s & r <XXREAL-0R3 s implies  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds q <XXREAL-0R3 s & r <XXREAL-0R3 s implies  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "q <XXREAL-0R3 s"
      and A2: "r <XXREAL-0R3 s"
    show " not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
    proof-
      have cases: "r <=XXREAL-0R1 q or q <XXREAL-0R3 r"
         sorry
      have case1: "r <=XXREAL-0R1 q implies  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
      proof(rule impI)
        assume A3: "r <=XXREAL-0R1 q"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A4: "q <XXREAL-0R3 t"and A5: "t <XXREAL-0R3 s"
          using A1 xreal_1_th_227 sorry
        have Cut2048: "r <XXREAL-0R3 t"
          using A3 A4 xxreal_0_th_2 sorry
        have "t inHIDDENR3 [.XXREAL-1K2 r,s .[ &  not t inHIDDENR3 [.XXREAL-1K2 p,q .["
        proof(rule conjMI)
          show "t inHIDDENR3 [.XXREAL-1K2 r,s .["
            using A5 xxreal_1_th_3 Cut2048 sorry
          show " not t inHIDDENR3 [.XXREAL-1K2 p,q .["
            using A4 xxreal_1_th_3 sorry
        qed
        thus " not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      have case2: "q <XXREAL-0R3 r implies  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
      proof(rule impI)
        assume A6: "q <XXREAL-0R3 r"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A7: "r <XXREAL-0R3 t"and A8: "t <XXREAL-0R3 s"
          using A2 xreal_1_th_227 sorry
        have "t inHIDDENR3 [.XXREAL-1K2 r,s .[ &  not t inHIDDENR3 [.XXREAL-1K2 p,q .["
        proof(rule conjMI)
          show "t inHIDDENR3 [.XXREAL-1K2 r,s .["
            using A7 A8 xxreal_1_th_3 sorry
          have "q <XXREAL-0R3 t"
            using A6 A7 xxreal_0_th_2 sorry
          thus " not t inHIDDENR3 [.XXREAL-1K2 p,q .["
            using xxreal_1_th_3 sorry
        qed
        thus " not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,q .["
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_120:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds q <XXREAL-0R3 s & r <XXREAL-0R3 s implies  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds q <XXREAL-0R3 s & r <XXREAL-0R3 s implies  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "q <XXREAL-0R3 s"
      and A2: "r <XXREAL-0R3 s"
    show " not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
    proof-
      have cases: "r <=XXREAL-0R1 q or q <XXREAL-0R3 r"
         sorry
      have case1: "r <=XXREAL-0R1 q implies  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
      proof(rule impI)
        assume A3: "r <=XXREAL-0R1 q"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A4: "q <XXREAL-0R3 t"and A5: "t <XXREAL-0R3 s"
          using A1 xreal_1_th_227 sorry
        have Cut2077: "r <XXREAL-0R3 t"
          using A3 A4 xxreal_0_th_2 sorry
        have "t inHIDDENR3 ].XXREAL-1K4 r,s .[ &  not t inHIDDENR3 ].XXREAL-1K3 p,q .]"
        proof(rule conjMI)
          show "t inHIDDENR3 ].XXREAL-1K4 r,s .["
            using A5 xxreal_1_th_4 Cut2077 sorry
          show " not t inHIDDENR3 ].XXREAL-1K3 p,q .]"
            using A4 xxreal_1_th_2 sorry
        qed
        thus " not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      have case2: "q <XXREAL-0R3 r implies  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
      proof(rule impI)
        assume A6: "q <XXREAL-0R3 r"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A7: "r <XXREAL-0R3 t"and A8: "t <XXREAL-0R3 s"
          using A2 xreal_1_th_227 sorry
        have "t inHIDDENR3 ].XXREAL-1K4 r,s .[ &  not t inHIDDENR3 ].XXREAL-1K3 p,q .]"
        proof(rule conjMI)
          show "t inHIDDENR3 ].XXREAL-1K4 r,s .["
            using A7 A8 xxreal_1_th_4 sorry
          have "q <XXREAL-0R3 t"
            using A6 A7 xxreal_0_th_2 sorry
          thus " not t inHIDDENR3 ].XXREAL-1K3 p,q .]"
            using xxreal_1_th_2 sorry
        qed
        thus " not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_121:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds q <XXREAL-0R3 s & r <=XXREAL-0R1 s implies  not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds q <XXREAL-0R3 s & r <=XXREAL-0R1 s implies  not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "q <XXREAL-0R3 s"
      and A2: "r <=XXREAL-0R1 s"
    obtain t where 
      [ty]:"t be ExtRealXXREAL-0M1" and tDef:"t = s"
       sorry
    have " ex t be ExtRealXXREAL-0M1 st t inHIDDENR3 [.XXREAL-1K1 r,s .] &  not t inHIDDENR3 ].XXREAL-1K3 p,q .]"
    proof(rule bexI[of _ "t"],rule conjMI)
      show "t inHIDDENR3 [.XXREAL-1K1 r,s .]"
        using A2 xxreal_1_th_1 sorry
      show " not t inHIDDENR3 ].XXREAL-1K3 p,q .]"
        using A1 xxreal_1_th_2 sorry
    qed "sorry"
    thus " not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
      using membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_122:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds q <XXREAL-0R3 s & r <XXREAL-0R3 s implies  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds q <XXREAL-0R3 s & r <XXREAL-0R3 s implies  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "q <XXREAL-0R3 s"
      and A2: "r <XXREAL-0R3 s"
    show " not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
    proof-
      have cases: "r <=XXREAL-0R1 q or q <XXREAL-0R3 r"
         sorry
      have case1: "r <=XXREAL-0R1 q implies  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
      proof(rule impI)
        assume A3: "r <=XXREAL-0R1 q"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A4: "q <XXREAL-0R3 t"and A5: "t <XXREAL-0R3 s"
          using A1 xreal_1_th_227 sorry
        have Cut2117: "r <XXREAL-0R3 t"
          using A3 A4 xxreal_0_th_2 sorry
        have "t inHIDDENR3 [.XXREAL-1K2 r,s .[ &  not t inHIDDENR3 ].XXREAL-1K3 p,q .]"
        proof(rule conjMI)
          show "t inHIDDENR3 [.XXREAL-1K2 r,s .["
            using A5 xxreal_1_th_3 Cut2117 sorry
          show " not t inHIDDENR3 ].XXREAL-1K3 p,q .]"
            using A4 xxreal_1_th_2 sorry
        qed
        thus " not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      have case2: "q <XXREAL-0R3 r implies  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
      proof(rule impI)
        assume A6: "q <XXREAL-0R3 r"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A7: "r <XXREAL-0R3 t"and A8: "t <XXREAL-0R3 s"
          using A2 xreal_1_th_227 sorry
        have "t inHIDDENR3 [.XXREAL-1K2 r,s .[ &  not t inHIDDENR3 ].XXREAL-1K3 p,q .]"
        proof(rule conjMI)
          show "t inHIDDENR3 [.XXREAL-1K2 r,s .["
            using A7 A8 xxreal_1_th_3 sorry
          have "q <XXREAL-0R3 t"
            using A6 A7 xxreal_0_th_2 sorry
          thus " not t inHIDDENR3 ].XXREAL-1K3 p,q .]"
            using xxreal_1_th_2 sorry
        qed
        thus " not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_123:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds q <XXREAL-0R3 s & r <XXREAL-0R3 s implies  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds q <XXREAL-0R3 s & r <XXREAL-0R3 s implies  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "q <XXREAL-0R3 s"
      and A2: "r <XXREAL-0R3 s"
    show " not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
    proof-
      have cases: "r <=XXREAL-0R1 q or q <XXREAL-0R3 r"
         sorry
      have case1: "r <=XXREAL-0R1 q implies  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
      proof(rule impI)
        assume A3: "r <=XXREAL-0R1 q"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A4: "q <XXREAL-0R3 t"and A5: "t <XXREAL-0R3 s"
          using A1 xreal_1_th_227 sorry
        have Cut2146: "r <XXREAL-0R3 t"
          using A3 A4 xxreal_0_th_2 sorry
        have "t inHIDDENR3 ].XXREAL-1K3 r,s .] &  not t inHIDDENR3 ].XXREAL-1K3 p,q .]"
        proof(rule conjMI)
          show "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
            using A5 xxreal_1_th_2 Cut2146 sorry
          show " not t inHIDDENR3 ].XXREAL-1K3 p,q .]"
            using A4 xxreal_1_th_2 sorry
        qed
        thus " not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      have case2: "q <XXREAL-0R3 r implies  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
      proof(rule impI)
        assume A6: "q <XXREAL-0R3 r"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A7: "r <XXREAL-0R3 t"and A8: "t <XXREAL-0R3 s"
          using A2 xreal_1_th_227 sorry
        have "t inHIDDENR3 ].XXREAL-1K3 r,s .] &  not t inHIDDENR3 ].XXREAL-1K3 p,q .]"
        proof(rule conjMI)
          show "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
            using A7 A8 xxreal_1_th_2 sorry
          have "q <XXREAL-0R3 t"
            using A6 A7 xxreal_0_th_2 sorry
          thus " not t inHIDDENR3 ].XXREAL-1K3 p,q .]"
            using xxreal_1_th_2 sorry
        qed
        thus " not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,q .]"
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_124:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds q <=XXREAL-0R1 s & r <=XXREAL-0R1 s implies  not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds q <=XXREAL-0R1 s & r <=XXREAL-0R1 s implies  not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "q <=XXREAL-0R1 s"
      and A2: "r <=XXREAL-0R1 s"
    obtain t where 
      [ty]:"t be ExtRealXXREAL-0M1" and tDef:"t = s"
       sorry
    have " ex t be ExtRealXXREAL-0M1 st t inHIDDENR3 [.XXREAL-1K1 r,s .] &  not t inHIDDENR3 ].XXREAL-1K4 p,q .["
    proof(rule bexI[of _ "t"],rule conjMI)
      show "t inHIDDENR3 [.XXREAL-1K1 r,s .]"
        using A2 xxreal_1_th_1 sorry
      show " not t inHIDDENR3 ].XXREAL-1K4 p,q .["
        using A1 xxreal_1_th_4 sorry
    qed "sorry"
    thus " not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
      using membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_125:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds q <XXREAL-0R3 s & r <XXREAL-0R3 s implies  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds q <XXREAL-0R3 s & r <XXREAL-0R3 s implies  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "q <XXREAL-0R3 s"
      and A2: "r <XXREAL-0R3 s"
    show " not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
    proof-
      have cases: "r <=XXREAL-0R1 q or q <XXREAL-0R3 r"
         sorry
      have case1: "r <=XXREAL-0R1 q implies  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
      proof(rule impI)
        assume A3: "r <=XXREAL-0R1 q"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A4: "q <XXREAL-0R3 t"and A5: "t <XXREAL-0R3 s"
          using A1 xreal_1_th_227 sorry
        have Cut2186: "r <XXREAL-0R3 t"
          using A3 A4 xxreal_0_th_2 sorry
        have "t inHIDDENR3 [.XXREAL-1K2 r,s .[ &  not t inHIDDENR3 ].XXREAL-1K4 p,q .["
        proof(rule conjMI)
          show "t inHIDDENR3 [.XXREAL-1K2 r,s .["
            using A5 xxreal_1_th_3 Cut2186 sorry
          show " not t inHIDDENR3 ].XXREAL-1K4 p,q .["
            using A4 xxreal_1_th_4 sorry
        qed
        thus " not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      have case2: "q <XXREAL-0R3 r implies  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
      proof(rule impI)
        assume A6: "q <XXREAL-0R3 r"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A7: "r <XXREAL-0R3 t"and A8: "t <XXREAL-0R3 s"
          using A2 xreal_1_th_227 sorry
        have "t inHIDDENR3 [.XXREAL-1K2 r,s .[ &  not t inHIDDENR3 ].XXREAL-1K4 p,q .["
        proof(rule conjMI)
          show "t inHIDDENR3 [.XXREAL-1K2 r,s .["
            using A7 A8 xxreal_1_th_3 sorry
          have "q <XXREAL-0R3 t"
            using A6 A7 xxreal_0_th_2 sorry
          thus " not t inHIDDENR3 ].XXREAL-1K4 p,q .["
            using xxreal_1_th_4 sorry
        qed
        thus " not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_126:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds q <=XXREAL-0R1 s & r <XXREAL-0R3 s implies  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds q <=XXREAL-0R1 s & r <XXREAL-0R3 s implies  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "q <=XXREAL-0R1 s"
      and A2: "r <XXREAL-0R3 s"
    obtain t where 
      [ty]:"t be ExtRealXXREAL-0M1" and tDef:"t = s"
       sorry
    have " ex t be ExtRealXXREAL-0M1 st t inHIDDENR3 ].XXREAL-1K3 r,s .] &  not t inHIDDENR3 ].XXREAL-1K4 p,q .["
    proof(rule bexI[of _ "t"],rule conjMI)
      show "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
        using A2 xxreal_1_th_2 sorry
      show " not t inHIDDENR3 ].XXREAL-1K4 p,q .["
        using A1 xxreal_1_th_4 sorry
    qed "sorry"
    thus " not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
      using membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_127:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds q <XXREAL-0R3 s & r <XXREAL-0R3 s implies  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds q <XXREAL-0R3 s & r <XXREAL-0R3 s implies  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "q <XXREAL-0R3 s"
      and A2: "r <XXREAL-0R3 s"
    show " not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
    proof-
      have cases: "r <=XXREAL-0R1 q or q <XXREAL-0R3 r"
         sorry
      have case1: "r <=XXREAL-0R1 q implies  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
      proof(rule impI)
        assume A3: "r <=XXREAL-0R1 q"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A4: "q <XXREAL-0R3 t"and A5: "t <XXREAL-0R3 s"
          using A1 xreal_1_th_227 sorry
        have Cut2226: "r <XXREAL-0R3 t"
          using A3 A4 xxreal_0_th_2 sorry
        have "t inHIDDENR3 ].XXREAL-1K4 r,s .[ &  not t inHIDDENR3 ].XXREAL-1K4 p,q .["
        proof(rule conjMI)
          show "t inHIDDENR3 ].XXREAL-1K4 r,s .["
            using A5 xxreal_1_th_4 Cut2226 sorry
          show " not t inHIDDENR3 ].XXREAL-1K4 p,q .["
            using A4 xxreal_1_th_4 sorry
        qed
        thus " not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      have case2: "q <XXREAL-0R3 r implies  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
      proof(rule impI)
        assume A6: "q <XXREAL-0R3 r"
        obtain t where
          [ty]:"t be ExtRealXXREAL-0M1" and 
          A7: "r <XXREAL-0R3 t"and A8: "t <XXREAL-0R3 s"
          using A2 xreal_1_th_227 sorry
        have "t inHIDDENR3 ].XXREAL-1K4 r,s .[ &  not t inHIDDENR3 ].XXREAL-1K4 p,q .["
        proof(rule conjMI)
          show "t inHIDDENR3 ].XXREAL-1K4 r,s .["
            using A7 A8 xxreal_1_th_4 sorry
          have "q <XXREAL-0R3 t"
            using A6 A7 xxreal_0_th_2 sorry
          thus " not t inHIDDENR3 ].XXREAL-1K4 p,q .["
            using xxreal_1_th_4 sorry
        qed
        thus " not ].XXREAL-1K4 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,q .["
          using bexI[of _ "t"] membered_def_8 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem xxreal_1_th_128:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s implies [.XXREAL-1K1 r,s .] =MEMBEREDR8 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 {TARSKIK2 r,s }"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s implies [.XXREAL-1K1 r,s .] =MEMBEREDR8 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 {TARSKIK2 r,s }"
  proof(rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 [.XXREAL-1K1 r,s .] implies t inHIDDENR3 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 {TARSKIK2 r,s }) & (t inHIDDENR3 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 {TARSKIK2 r,s } implies t inHIDDENR3 [.XXREAL-1K1 r,s .])"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 [.XXREAL-1K1 r,s .] implies t inHIDDENR3 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 {TARSKIK2 r,s }"
      proof(rule impI)
        assume "t inHIDDENR3 [.XXREAL-1K1 r,s .]"
        then have "(t inHIDDENR3 ].XXREAL-1K4 r,s .[ or t =HIDDENR1 r) or t =HIDDENR1 s"
          using xxreal_1_th_5 sorry
        then have "t inHIDDENR3 ].XXREAL-1K4 r,s .[ or t inHIDDENR3 {TARSKIK2 r,s }"
          using tarski_def_2 sorry
        thus "t inHIDDENR3 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 {TARSKIK2 r,s }"
          using xboole_0_def_3 sorry
      qed
      assume "t inHIDDENR3 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 {TARSKIK2 r,s }"
      then have "t inHIDDENR3 ].XXREAL-1K4 r,s .[ or t inHIDDENR3 {TARSKIK2 r,s }"
        using xboole_0_def_3 sorry
      then have "(t inHIDDENR3 ].XXREAL-1K4 r,s .[ or t =HIDDENR1 r) or t =HIDDENR1 s"
        using tarski_def_2 sorry
      thus "t inHIDDENR3 [.XXREAL-1K1 r,s .]"
        using A1 xxreal_1_th_1 xxreal_1_th_16 sorry
    qed "sorry"
    thus "[.XXREAL-1K1 r,s .] =MEMBEREDR8 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 {TARSKIK2 r,s }"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_129:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s implies [.XXREAL-1K1 r,s .] =MEMBEREDR8 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 {TARSKIK1 s}"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s implies [.XXREAL-1K1 r,s .] =MEMBEREDR8 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 {TARSKIK1 s}"
  proof(rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 [.XXREAL-1K1 r,s .] implies t inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 {TARSKIK1 s}) & (t inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 {TARSKIK1 s} implies t inHIDDENR3 [.XXREAL-1K1 r,s .])"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 [.XXREAL-1K1 r,s .] implies t inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 {TARSKIK1 s}"
      proof(rule impI)
        assume "t inHIDDENR3 [.XXREAL-1K1 r,s .]"
        then have "t inHIDDENR3 [.XXREAL-1K2 r,s .[ or t =HIDDENR1 s"
          using xxreal_1_th_7 sorry
        then have "t inHIDDENR3 [.XXREAL-1K2 r,s .[ or t inHIDDENR3 {TARSKIK1 s}"
          using tarski_def_1 sorry
        thus "t inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 {TARSKIK1 s}"
          using xboole_0_def_3 sorry
      qed
      assume "t inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 {TARSKIK1 s}"
      then have "t inHIDDENR3 [.XXREAL-1K2 r,s .[ or t inHIDDENR3 {TARSKIK1 s}"
        using xboole_0_def_3 sorry
      then have "t inHIDDENR3 [.XXREAL-1K2 r,s .[ or t =HIDDENR1 s"
        using tarski_def_1 sorry
      thus "t inHIDDENR3 [.XXREAL-1K1 r,s .]"
        using A1 xxreal_1_th_1 xxreal_1_th_13 sorry
    qed "sorry"
    thus "[.XXREAL-1K1 r,s .] =MEMBEREDR8 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 {TARSKIK1 s}"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_130:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s implies [.XXREAL-1K1 r,s .] =MEMBEREDR8 {TARSKIK1 r} \\/XBOOLE-0K2 ].XXREAL-1K3 r,s .]"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s implies [.XXREAL-1K1 r,s .] =MEMBEREDR8 {TARSKIK1 r} \\/XBOOLE-0K2 ].XXREAL-1K3 r,s .]"
  proof(rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 [.XXREAL-1K1 r,s .] implies t inHIDDENR3 {TARSKIK1 r} \\/XBOOLE-0K2 ].XXREAL-1K3 r,s .]) & (t inHIDDENR3 {TARSKIK1 r} \\/XBOOLE-0K2 ].XXREAL-1K3 r,s .] implies t inHIDDENR3 [.XXREAL-1K1 r,s .])"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 [.XXREAL-1K1 r,s .] implies t inHIDDENR3 {TARSKIK1 r} \\/XBOOLE-0K2 ].XXREAL-1K3 r,s .]"
      proof(rule impI)
        assume "t inHIDDENR3 [.XXREAL-1K1 r,s .]"
        then have "t inHIDDENR3 ].XXREAL-1K3 r,s .] or t =HIDDENR1 r"
          using xxreal_1_th_6 sorry
        then have "t inHIDDENR3 ].XXREAL-1K3 r,s .] or t inHIDDENR3 {TARSKIK1 r}"
          using tarski_def_1 sorry
        thus "t inHIDDENR3 {TARSKIK1 r} \\/XBOOLE-0K2 ].XXREAL-1K3 r,s .]"
          using xboole_0_def_3 sorry
      qed
      assume "t inHIDDENR3 {TARSKIK1 r} \\/XBOOLE-0K2 ].XXREAL-1K3 r,s .]"
      then have "t inHIDDENR3 ].XXREAL-1K3 r,s .] or t inHIDDENR3 {TARSKIK1 r}"
        using xboole_0_def_3 sorry
      then have "t inHIDDENR3 ].XXREAL-1K3 r,s .] or t =HIDDENR1 r"
        using tarski_def_1 sorry
      thus "t inHIDDENR3 [.XXREAL-1K1 r,s .]"
        using A1 xxreal_1_th_1 xxreal_1_th_12 sorry
    qed "sorry"
    thus "[.XXREAL-1K1 r,s .] =MEMBEREDR8 {TARSKIK1 r} \\/XBOOLE-0K2 ].XXREAL-1K3 r,s .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_131:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies [.XXREAL-1K2 r,s .[ =MEMBEREDR8 {TARSKIK1 r} \\/XBOOLE-0K2 ].XXREAL-1K4 r,s .["
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies [.XXREAL-1K2 r,s .[ =MEMBEREDR8 {TARSKIK1 r} \\/XBOOLE-0K2 ].XXREAL-1K4 r,s .["
  proof(rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 [.XXREAL-1K2 r,s .[ implies t inHIDDENR3 {TARSKIK1 r} \\/XBOOLE-0K2 ].XXREAL-1K4 r,s .[) & (t inHIDDENR3 {TARSKIK1 r} \\/XBOOLE-0K2 ].XXREAL-1K4 r,s .[ implies t inHIDDENR3 [.XXREAL-1K2 r,s .[)"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 [.XXREAL-1K2 r,s .[ implies t inHIDDENR3 {TARSKIK1 r} \\/XBOOLE-0K2 ].XXREAL-1K4 r,s .["
      proof(rule impI)
        assume "t inHIDDENR3 [.XXREAL-1K2 r,s .["
        then have "t inHIDDENR3 ].XXREAL-1K4 r,s .[ or t =HIDDENR1 r"
          using xxreal_1_th_8 sorry
        then have "t inHIDDENR3 ].XXREAL-1K4 r,s .[ or t inHIDDENR3 {TARSKIK1 r}"
          using tarski_def_1 sorry
        thus "t inHIDDENR3 {TARSKIK1 r} \\/XBOOLE-0K2 ].XXREAL-1K4 r,s .["
          using xboole_0_def_3 sorry
      qed
      assume "t inHIDDENR3 {TARSKIK1 r} \\/XBOOLE-0K2 ].XXREAL-1K4 r,s .["
      then have "t inHIDDENR3 ].XXREAL-1K4 r,s .[ or t inHIDDENR3 {TARSKIK1 r}"
        using xboole_0_def_3 sorry
      then have "t inHIDDENR3 ].XXREAL-1K4 r,s .[ or t =HIDDENR1 r"
        using tarski_def_1 sorry
      thus "t inHIDDENR3 [.XXREAL-1K2 r,s .["
        using A1 xxreal_1_th_3 xxreal_1_th_14 sorry
    qed "sorry"
    thus "[.XXREAL-1K2 r,s .[ =MEMBEREDR8 {TARSKIK1 r} \\/XBOOLE-0K2 ].XXREAL-1K4 r,s .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_132:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies ].XXREAL-1K3 r,s .] =MEMBEREDR8 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 {TARSKIK1 s}"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies ].XXREAL-1K3 r,s .] =MEMBEREDR8 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 {TARSKIK1 s}"
  proof(rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 ].XXREAL-1K3 r,s .] implies t inHIDDENR3 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 {TARSKIK1 s}) & (t inHIDDENR3 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 {TARSKIK1 s} implies t inHIDDENR3 ].XXREAL-1K3 r,s .])"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 ].XXREAL-1K3 r,s .] implies t inHIDDENR3 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 {TARSKIK1 s}"
      proof(rule impI)
        assume "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
        then have "t inHIDDENR3 ].XXREAL-1K4 r,s .[ or t =HIDDENR1 s"
          using xxreal_1_th_9 sorry
        then have "t inHIDDENR3 ].XXREAL-1K4 r,s .[ or t inHIDDENR3 {TARSKIK1 s}"
          using tarski_def_1 sorry
        thus "t inHIDDENR3 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 {TARSKIK1 s}"
          using xboole_0_def_3 sorry
      qed
      assume "t inHIDDENR3 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 {TARSKIK1 s}"
      then have "t inHIDDENR3 ].XXREAL-1K4 r,s .[ or t inHIDDENR3 {TARSKIK1 s}"
        using xboole_0_def_3 sorry
      then have "t inHIDDENR3 ].XXREAL-1K4 r,s .[ or t =HIDDENR1 s"
        using tarski_def_1 sorry
      thus "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
        using A1 xxreal_1_th_2 xxreal_1_th_15 sorry
    qed "sorry"
    thus "].XXREAL-1K3 r,s .] =MEMBEREDR8 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 {TARSKIK1 s}"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_133:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s implies [.XXREAL-1K1 r,s .] \\SUBSET-1K6 {TARSKIK2 r,s } =MEMBEREDR8 ].XXREAL-1K4 r,s .["
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s implies [.XXREAL-1K1 r,s .] \\SUBSET-1K6 {TARSKIK2 r,s } =MEMBEREDR8 ].XXREAL-1K4 r,s .["
  proof(rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume "r <=XXREAL-0R1 s"
    then have A1: "[.XXREAL-1K1 r,s .] =MEMBEREDR8 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 {TARSKIK2 r,s }"
      using xxreal_1_th_128 sorry
    have A2: " not r inHIDDENR3 ].XXREAL-1K4 r,s .["
      using xxreal_1_th_4 sorry
    have " not s inHIDDENR3 ].XXREAL-1K4 r,s .["
      using xxreal_1_th_4 sorry
    thus "[.XXREAL-1K1 r,s .] \\SUBSET-1K6 {TARSKIK2 r,s } =MEMBEREDR8 ].XXREAL-1K4 r,s .["
      using A1 A2 zfmisc_1_th_121 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_134:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s implies [.XXREAL-1K1 r,s .] \\SUBSET-1K6 {TARSKIK1 r} =MEMBEREDR8 ].XXREAL-1K3 r,s .]"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s implies [.XXREAL-1K1 r,s .] \\SUBSET-1K6 {TARSKIK1 r} =MEMBEREDR8 ].XXREAL-1K3 r,s .]"
  proof(rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume "r <=XXREAL-0R1 s"
    then have A1: "[.XXREAL-1K1 r,s .] =MEMBEREDR8 {TARSKIK1 r} \\/XBOOLE-0K2 ].XXREAL-1K3 r,s .]"
      using xxreal_1_th_130 sorry
    have " not r inHIDDENR3 ].XXREAL-1K3 r,s .]"
      using xxreal_1_th_2 sorry
    thus "[.XXREAL-1K1 r,s .] \\SUBSET-1K6 {TARSKIK1 r} =MEMBEREDR8 ].XXREAL-1K3 r,s .]"
      using A1 zfmisc_1_th_117 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_135:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s implies [.XXREAL-1K1 r,s .] \\SUBSET-1K6 {TARSKIK1 s} =MEMBEREDR8 [.XXREAL-1K2 r,s .["
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s implies [.XXREAL-1K1 r,s .] \\SUBSET-1K6 {TARSKIK1 s} =MEMBEREDR8 [.XXREAL-1K2 r,s .["
  proof(rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume "r <=XXREAL-0R1 s"
    then have A1: "[.XXREAL-1K1 r,s .] =MEMBEREDR8 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 {TARSKIK1 s}"
      using xxreal_1_th_129 sorry
    have " not s inHIDDENR3 [.XXREAL-1K2 r,s .["
      using xxreal_1_th_3 sorry
    thus "[.XXREAL-1K1 r,s .] \\SUBSET-1K6 {TARSKIK1 s} =MEMBEREDR8 [.XXREAL-1K2 r,s .["
      using A1 zfmisc_1_th_117 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_136:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies [.XXREAL-1K2 r,s .[ \\SUBSET-1K6 {TARSKIK1 r} =MEMBEREDR8 ].XXREAL-1K4 r,s .["
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies [.XXREAL-1K2 r,s .[ \\SUBSET-1K6 {TARSKIK1 r} =MEMBEREDR8 ].XXREAL-1K4 r,s .["
  proof(rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume "r <XXREAL-0R3 s"
    then have A1: "[.XXREAL-1K2 r,s .[ =MEMBEREDR8 {TARSKIK1 r} \\/XBOOLE-0K2 ].XXREAL-1K4 r,s .["
      using xxreal_1_th_131 sorry
    have " not r inHIDDENR3 ].XXREAL-1K4 r,s .["
      using xxreal_1_th_4 sorry
    thus "[.XXREAL-1K2 r,s .[ \\SUBSET-1K6 {TARSKIK1 r} =MEMBEREDR8 ].XXREAL-1K4 r,s .["
      using A1 zfmisc_1_th_117 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_137:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies ].XXREAL-1K3 r,s .] \\SUBSET-1K6 {TARSKIK1 s} =MEMBEREDR8 ].XXREAL-1K4 r,s .["
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies ].XXREAL-1K3 r,s .] \\SUBSET-1K6 {TARSKIK1 s} =MEMBEREDR8 ].XXREAL-1K4 r,s .["
  proof(rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume "r <XXREAL-0R3 s"
    then have A1: "].XXREAL-1K3 r,s .] =MEMBEREDR8 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 {TARSKIK1 s}"
      using xxreal_1_th_132 sorry
    have " not s inHIDDENR3 ].XXREAL-1K4 r,s .["
      using xxreal_1_th_4 sorry
    thus "].XXREAL-1K3 r,s .] \\SUBSET-1K6 {TARSKIK1 s} =MEMBEREDR8 ].XXREAL-1K4 r,s .["
      using A1 zfmisc_1_th_117 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_138:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & s <XXREAL-0R3 t implies (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K2 s,t .[) =MEMBEREDR8 {TARSKIK1 s}"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & s <XXREAL-0R3 t implies (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K2 s,t .[) =MEMBEREDR8 {TARSKIK1 s}"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "s <XXREAL-0R3 t"
    have " for x be objectHIDDENM1 holds (x inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K2 s,t .[) implies x =HIDDENR1 s) & (x =HIDDENR1 s implies x inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K2 s,t .[))"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      show "x inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K2 s,t .[) implies x =HIDDENR1 s"
      proof(rule impI)
        assume A3: "x inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K2 s,t .[)"
        then obtain p where 
          [ty]:"p be ExtRealXXREAL-0M1" and pDef:"p = x"
           sorry
        have A4: "p inHIDDENR3 ].XXREAL-1K3 r,s .]"
          using A3 xboole_0_def_4 sorry
        have "p inHIDDENR3 [.XXREAL-1K2 s,t .["
          using A3 xboole_0_def_4 sorry
        then have A5: "s <=XXREAL-0R1 p"
          using xxreal_1_th_3 sorry
        have "p <=XXREAL-0R1 s"
          using A4 xxreal_1_th_2 sorry
        thus "x =HIDDENR1 s"
          using A5 xxreal_0_th_1 sorry
      qed
      assume A6: "x =HIDDENR1 s"
      have A7: "s inHIDDENR3 ].XXREAL-1K3 r,s .]"
        using A1 xxreal_1_th_2 sorry
      have "s inHIDDENR3 [.XXREAL-1K2 s,t .["
        using A2 xxreal_1_th_3 sorry
      thus "x inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K2 s,t .[)"
        using A6 A7 xboole_0_def_4 sorry
    qed "sorry"
    thus "(].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K2 s,t .[) =MEMBEREDR8 {TARSKIK1 s}"
      using tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_139:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) =MEMBEREDR8 [.XXREAL-1K2 maxXXREAL-0K5(r,p),minXXREAL-0K4(s,q) .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) =MEMBEREDR8 [.XXREAL-1K2 maxXXREAL-0K5(r,p),minXXREAL-0K4(s,q) .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) implies t inHIDDENR3 [.XXREAL-1K2 maxXXREAL-0K5(r,p),minXXREAL-0K4(s,q) .[) & (t inHIDDENR3 [.XXREAL-1K2 maxXXREAL-0K5(r,p),minXXREAL-0K4(s,q) .[ implies t inHIDDENR3 ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[))"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) implies t inHIDDENR3 [.XXREAL-1K2 maxXXREAL-0K5(r,p),minXXREAL-0K4(s,q) .["
      proof(rule impI)
        assume A1: "t inHIDDENR3 ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[)"
        then have A2: "t inHIDDENR3 [.XXREAL-1K2 r,s .["
          using xboole_0_def_4 sorry
        have A3: "t inHIDDENR3 [.XXREAL-1K2 p,q .["
          using A1 xboole_0_def_4 sorry
        have A4: "r <=XXREAL-0R1 t"
          using A2 xxreal_1_th_3 sorry
        have A5: "t <XXREAL-0R3 s"
          using A2 xxreal_1_th_3 sorry
        have A6: "p <=XXREAL-0R1 t"
          using A3 xxreal_1_th_3 sorry
        have A7: "t <XXREAL-0R3 q"
          using A3 xxreal_1_th_3 sorry
        have A8: "maxXXREAL-0K5(r,p) <=XXREAL-0R1 t"
          using A4 A6 xxreal_0_th_28 sorry
        have "t <XXREAL-0R3 minXXREAL-0K4(s,q)"
          using A5 A7 xxreal_0_th_21 sorry
        thus "t inHIDDENR3 [.XXREAL-1K2 maxXXREAL-0K5(r,p),minXXREAL-0K4(s,q) .["
          using A8 xxreal_1_th_3 sorry
      qed
      assume A9: "t inHIDDENR3 [.XXREAL-1K2 maxXXREAL-0K5(r,p),minXXREAL-0K4(s,q) .["
      then have A10: "maxXXREAL-0K5(r,p) <=XXREAL-0R1 t"
        using xxreal_1_th_3 sorry
      have A11: "t <XXREAL-0R3 minXXREAL-0K4(s,q)"
        using A9 xxreal_1_th_3 sorry
      have A12: "r <=XXREAL-0R1 t"
        using A10 xxreal_0_th_30 sorry
      have A13: "p <=XXREAL-0R1 t"
        using A10 xxreal_0_th_30 sorry
      have A14: "t <XXREAL-0R3 s"
        using A11 xxreal_0_th_23 sorry
      have A15: "t <XXREAL-0R3 q"
        using A11 xxreal_0_th_23 sorry
      have A16: "t inHIDDENR3 [.XXREAL-1K2 r,s .["
        using A12 A14 xxreal_1_th_3 sorry
      have "t inHIDDENR3 [.XXREAL-1K2 p,q .["
        using A13 A15 xxreal_1_th_3 sorry
      thus "t inHIDDENR3 ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[)"
        using A16 xboole_0_def_4 sorry
    qed "sorry"
    thus "([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) =MEMBEREDR8 [.XXREAL-1K2 maxXXREAL-0K5(r,p),minXXREAL-0K4(s,q) .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_140:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds ([.XXREAL-1K1 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) =MEMBEREDR8 [.XXREAL-1K1 maxXXREAL-0K5(r,p),minXXREAL-0K4(s,q) .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds ([.XXREAL-1K1 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) =MEMBEREDR8 [.XXREAL-1K1 maxXXREAL-0K5(r,p),minXXREAL-0K4(s,q) .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 ([.XXREAL-1K1 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) implies t inHIDDENR3 [.XXREAL-1K1 maxXXREAL-0K5(r,p),minXXREAL-0K4(s,q) .]) & (t inHIDDENR3 [.XXREAL-1K1 maxXXREAL-0K5(r,p),minXXREAL-0K4(s,q) .] implies t inHIDDENR3 ([.XXREAL-1K1 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]))"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 ([.XXREAL-1K1 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) implies t inHIDDENR3 [.XXREAL-1K1 maxXXREAL-0K5(r,p),minXXREAL-0K4(s,q) .]"
      proof(rule impI)
        assume A1: "t inHIDDENR3 ([.XXREAL-1K1 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .])"
        then have A2: "t inHIDDENR3 [.XXREAL-1K1 r,s .]"
          using xboole_0_def_4 sorry
        have A3: "t inHIDDENR3 [.XXREAL-1K1 p,q .]"
          using A1 xboole_0_def_4 sorry
        have A4: "r <=XXREAL-0R1 t"
          using A2 xxreal_1_th_1 sorry
        have A5: "t <=XXREAL-0R1 s"
          using A2 xxreal_1_th_1 sorry
        have A6: "p <=XXREAL-0R1 t"
          using A3 xxreal_1_th_1 sorry
        have A7: "t <=XXREAL-0R1 q"
          using A3 xxreal_1_th_1 sorry
        have A8: "maxXXREAL-0K5(r,p) <=XXREAL-0R1 t"
          using A4 A6 xxreal_0_th_28 sorry
        have "t <=XXREAL-0R1 minXXREAL-0K4(s,q)"
          using A5 A7 xxreal_0_th_20 sorry
        thus "t inHIDDENR3 [.XXREAL-1K1 maxXXREAL-0K5(r,p),minXXREAL-0K4(s,q) .]"
          using A8 xxreal_1_th_1 sorry
      qed
      assume A9: "t inHIDDENR3 [.XXREAL-1K1 maxXXREAL-0K5(r,p),minXXREAL-0K4(s,q) .]"
      then have A10: "maxXXREAL-0K5(r,p) <=XXREAL-0R1 t"
        using xxreal_1_th_1 sorry
      have A11: "t <=XXREAL-0R1 minXXREAL-0K4(s,q)"
        using A9 xxreal_1_th_1 sorry
      have A12: "r <=XXREAL-0R1 t"
        using A10 xxreal_0_th_30 sorry
      have A13: "p <=XXREAL-0R1 t"
        using A10 xxreal_0_th_30 sorry
      have A14: "t <=XXREAL-0R1 s"
        using A11 xxreal_0_th_22 sorry
      have A15: "t <=XXREAL-0R1 q"
        using A11 xxreal_0_th_22 sorry
      have A16: "t inHIDDENR3 [.XXREAL-1K1 r,s .]"
        using A12 A14 xxreal_1_th_1 sorry
      have "t inHIDDENR3 [.XXREAL-1K1 p,q .]"
        using A13 A15 xxreal_1_th_1 sorry
      thus "t inHIDDENR3 ([.XXREAL-1K1 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .])"
        using A16 xboole_0_def_4 sorry
    qed "sorry"
    thus "([.XXREAL-1K1 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) =MEMBEREDR8 [.XXREAL-1K1 maxXXREAL-0K5(r,p),minXXREAL-0K4(s,q) .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_141:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .]) =MEMBEREDR8 ].XXREAL-1K3 maxXXREAL-0K5(r,p),minXXREAL-0K4(s,q) .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .]) =MEMBEREDR8 ].XXREAL-1K3 maxXXREAL-0K5(r,p),minXXREAL-0K4(s,q) .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .]) implies t inHIDDENR3 ].XXREAL-1K3 maxXXREAL-0K5(r,p),minXXREAL-0K4(s,q) .]) & (t inHIDDENR3 ].XXREAL-1K3 maxXXREAL-0K5(r,p),minXXREAL-0K4(s,q) .] implies t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .]))"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .]) implies t inHIDDENR3 ].XXREAL-1K3 maxXXREAL-0K5(r,p),minXXREAL-0K4(s,q) .]"
      proof(rule impI)
        assume A1: "t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .])"
        then have A2: "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
          using xboole_0_def_4 sorry
        have A3: "t inHIDDENR3 ].XXREAL-1K3 p,q .]"
          using A1 xboole_0_def_4 sorry
        have A4: "r <XXREAL-0R3 t"
          using A2 xxreal_1_th_2 sorry
        have A5: "t <=XXREAL-0R1 s"
          using A2 xxreal_1_th_2 sorry
        have A6: "p <XXREAL-0R3 t"
          using A3 xxreal_1_th_2 sorry
        have A7: "t <=XXREAL-0R1 q"
          using A3 xxreal_1_th_2 sorry
        have A8: "maxXXREAL-0K5(r,p) <XXREAL-0R3 t"
          using A4 A6 xxreal_0_th_29 sorry
        have "t <=XXREAL-0R1 minXXREAL-0K4(s,q)"
          using A5 A7 xxreal_0_th_20 sorry
        thus "t inHIDDENR3 ].XXREAL-1K3 maxXXREAL-0K5(r,p),minXXREAL-0K4(s,q) .]"
          using A8 xxreal_1_th_2 sorry
      qed
      assume A9: "t inHIDDENR3 ].XXREAL-1K3 maxXXREAL-0K5(r,p),minXXREAL-0K4(s,q) .]"
      then have A10: "maxXXREAL-0K5(r,p) <XXREAL-0R3 t"
        using xxreal_1_th_2 sorry
      have A11: "t <=XXREAL-0R1 minXXREAL-0K4(s,q)"
        using A9 xxreal_1_th_2 sorry
      have A12: "r <XXREAL-0R3 t"
        using A10 xxreal_0_th_31 sorry
      have A13: "p <XXREAL-0R3 t"
        using A10 xxreal_0_th_31 sorry
      have A14: "t <=XXREAL-0R1 s"
        using A11 xxreal_0_th_22 sorry
      have A15: "t <=XXREAL-0R1 q"
        using A11 xxreal_0_th_22 sorry
      have A16: "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
        using A12 A14 xxreal_1_th_2 sorry
      have "t inHIDDENR3 ].XXREAL-1K3 p,q .]"
        using A13 A15 xxreal_1_th_2 sorry
      thus "t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .])"
        using A16 xboole_0_def_4 sorry
    qed "sorry"
    thus "(].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .]) =MEMBEREDR8 ].XXREAL-1K3 maxXXREAL-0K5(r,p),minXXREAL-0K4(s,q) .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_142:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 (].XXREAL-1K4 p,q .[) =MEMBEREDR8 ].XXREAL-1K4 maxXXREAL-0K5(r,p),minXXREAL-0K4(s,q) .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 (].XXREAL-1K4 p,q .[) =MEMBEREDR8 ].XXREAL-1K4 maxXXREAL-0K5(r,p),minXXREAL-0K4(s,q) .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 (].XXREAL-1K4 p,q .[) implies t inHIDDENR3 ].XXREAL-1K4 maxXXREAL-0K5(r,p),minXXREAL-0K4(s,q) .[) & (t inHIDDENR3 ].XXREAL-1K4 maxXXREAL-0K5(r,p),minXXREAL-0K4(s,q) .[ implies t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 (].XXREAL-1K4 p,q .[))"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 (].XXREAL-1K4 p,q .[) implies t inHIDDENR3 ].XXREAL-1K4 maxXXREAL-0K5(r,p),minXXREAL-0K4(s,q) .["
      proof(rule impI)
        assume A1: "t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 (].XXREAL-1K4 p,q .[)"
        then have A2: "t inHIDDENR3 ].XXREAL-1K4 r,s .["
          using xboole_0_def_4 sorry
        have A3: "t inHIDDENR3 ].XXREAL-1K4 p,q .["
          using A1 xboole_0_def_4 sorry
        have A4: "r <XXREAL-0R3 t"
          using A2 xxreal_1_th_4 sorry
        have A5: "t <XXREAL-0R3 s"
          using A2 xxreal_1_th_4 sorry
        have A6: "p <XXREAL-0R3 t"
          using A3 xxreal_1_th_4 sorry
        have A7: "t <XXREAL-0R3 q"
          using A3 xxreal_1_th_4 sorry
        have A8: "maxXXREAL-0K5(r,p) <XXREAL-0R3 t"
          using A4 A6 xxreal_0_th_29 sorry
        have "t <XXREAL-0R3 minXXREAL-0K4(s,q)"
          using A5 A7 xxreal_0_th_21 sorry
        thus "t inHIDDENR3 ].XXREAL-1K4 maxXXREAL-0K5(r,p),minXXREAL-0K4(s,q) .["
          using A8 xxreal_1_th_4 sorry
      qed
      assume A9: "t inHIDDENR3 ].XXREAL-1K4 maxXXREAL-0K5(r,p),minXXREAL-0K4(s,q) .["
      then have A10: "maxXXREAL-0K5(r,p) <XXREAL-0R3 t"
        using xxreal_1_th_4 sorry
      have A11: "t <XXREAL-0R3 minXXREAL-0K4(s,q)"
        using A9 xxreal_1_th_4 sorry
      have A12: "r <XXREAL-0R3 t"
        using A10 xxreal_0_th_31 sorry
      have A13: "p <XXREAL-0R3 t"
        using A10 xxreal_0_th_31 sorry
      have A14: "t <XXREAL-0R3 s"
        using A11 xxreal_0_th_23 sorry
      have A15: "t <XXREAL-0R3 q"
        using A11 xxreal_0_th_23 sorry
      have A16: "t inHIDDENR3 ].XXREAL-1K4 r,s .["
        using A12 A14 xxreal_1_th_4 sorry
      have "t inHIDDENR3 ].XXREAL-1K4 p,q .["
        using A13 A15 xxreal_1_th_4 sorry
      thus "t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 (].XXREAL-1K4 p,q .[)"
        using A16 xboole_0_def_4 sorry
    qed "sorry"
    thus "(].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 (].XXREAL-1K4 p,q .[) =MEMBEREDR8 ].XXREAL-1K4 maxXXREAL-0K5(r,p),minXXREAL-0K4(s,q) .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_143:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 p & s <=XXREAL-0R1 q implies ([.XXREAL-1K1 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) =MEMBEREDR8 [.XXREAL-1K1 p,s .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 p & s <=XXREAL-0R1 q implies ([.XXREAL-1K1 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) =MEMBEREDR8 [.XXREAL-1K1 p,s .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 p"
      and A2: "s <=XXREAL-0R1 q"
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 ([.XXREAL-1K1 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) implies t inHIDDENR3 [.XXREAL-1K1 p,s .]) & (t inHIDDENR3 [.XXREAL-1K1 p,s .] implies t inHIDDENR3 ([.XXREAL-1K1 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]))"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 ([.XXREAL-1K1 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) implies t inHIDDENR3 [.XXREAL-1K1 p,s .]"
      proof(rule impI)
        assume A3: "t inHIDDENR3 ([.XXREAL-1K1 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .])"
        then have A4: "t inHIDDENR3 [.XXREAL-1K1 r,s .]"
          using xboole_0_def_4 sorry
        have A5: "t inHIDDENR3 [.XXREAL-1K1 p,q .]"
          using A3 xboole_0_def_4 sorry
        have A6: "t <=XXREAL-0R1 s"
          using A4 xxreal_1_th_1 sorry
        have "p <=XXREAL-0R1 t"
          using A5 xxreal_1_th_1 sorry
        thus "t inHIDDENR3 [.XXREAL-1K1 p,s .]"
          using A6 xxreal_1_th_1 sorry
      qed
      assume A7: "t inHIDDENR3 [.XXREAL-1K1 p,s .]"
      then have A8: "p <=XXREAL-0R1 t"
        using xxreal_1_th_1 sorry
      have A9: "t <=XXREAL-0R1 s"
        using A7 xxreal_1_th_1 sorry
      have A10: "r <=XXREAL-0R1 t"
        using A1 A8 xxreal_0_th_2 sorry
      have A11: "t <=XXREAL-0R1 q"
        using A2 A9 xxreal_0_th_2 sorry
      have A12: "t inHIDDENR3 [.XXREAL-1K1 r,s .]"
        using A9 A10 xxreal_1_th_1 sorry
      have "t inHIDDENR3 [.XXREAL-1K1 p,q .]"
        using A8 A11 xxreal_1_th_1 sorry
      thus "t inHIDDENR3 ([.XXREAL-1K1 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .])"
        using A12 xboole_0_def_4 sorry
    qed "sorry"
    thus "([.XXREAL-1K1 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) =MEMBEREDR8 [.XXREAL-1K1 p,s .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_144:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 p & s <=XXREAL-0R1 q implies ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) =MEMBEREDR8 [.XXREAL-1K2 p,s .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 p & s <=XXREAL-0R1 q implies ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) =MEMBEREDR8 [.XXREAL-1K2 p,s .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 p"
      and A2: "s <=XXREAL-0R1 q"
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) implies t inHIDDENR3 [.XXREAL-1K2 p,s .[) & (t inHIDDENR3 [.XXREAL-1K2 p,s .[ implies t inHIDDENR3 ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]))"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) implies t inHIDDENR3 [.XXREAL-1K2 p,s .["
      proof(rule impI)
        assume A3: "t inHIDDENR3 ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .])"
        then have A4: "t inHIDDENR3 [.XXREAL-1K2 r,s .["
          using xboole_0_def_4 sorry
        have A5: "t inHIDDENR3 [.XXREAL-1K1 p,q .]"
          using A3 xboole_0_def_4 sorry
        have A6: "t <XXREAL-0R3 s"
          using A4 xxreal_1_th_3 sorry
        have "p <=XXREAL-0R1 t"
          using A5 xxreal_1_th_1 sorry
        thus "t inHIDDENR3 [.XXREAL-1K2 p,s .["
          using A6 xxreal_1_th_3 sorry
      qed
      assume A7: "t inHIDDENR3 [.XXREAL-1K2 p,s .["
      then have A8: "p <=XXREAL-0R1 t"
        using xxreal_1_th_3 sorry
      have A9: "t <XXREAL-0R3 s"
        using A7 xxreal_1_th_3 sorry
      have A10: "r <=XXREAL-0R1 t"
        using A1 A8 xxreal_0_th_2 sorry
      have A11: "t <=XXREAL-0R1 q"
        using A2 A9 xxreal_0_th_2 sorry
      have A12: "t inHIDDENR3 [.XXREAL-1K2 r,s .["
        using A9 A10 xxreal_1_th_3 sorry
      have "t inHIDDENR3 [.XXREAL-1K1 p,q .]"
        using A8 A11 xxreal_1_th_1 sorry
      thus "t inHIDDENR3 ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .])"
        using A12 xboole_0_def_4 sorry
    qed "sorry"
    thus "([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) =MEMBEREDR8 [.XXREAL-1K2 p,s .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_145:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r >=XXREAL-0R2 p & s >XXREAL-0R4 q implies ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) =MEMBEREDR8 [.XXREAL-1K1 r,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r >=XXREAL-0R2 p & s >XXREAL-0R4 q implies ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) =MEMBEREDR8 [.XXREAL-1K1 r,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r >=XXREAL-0R2 p"
      and A2: "s >XXREAL-0R4 q"
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) implies t inHIDDENR3 [.XXREAL-1K1 r,q .]) & (t inHIDDENR3 [.XXREAL-1K1 r,q .] implies t inHIDDENR3 ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]))"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) implies t inHIDDENR3 [.XXREAL-1K1 r,q .]"
      proof(rule impI)
        assume A3: "t inHIDDENR3 ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .])"
        then have A4: "t inHIDDENR3 [.XXREAL-1K2 r,s .["
          using xboole_0_def_4 sorry
        have A5: "t inHIDDENR3 [.XXREAL-1K1 p,q .]"
          using A3 xboole_0_def_4 sorry
        have A6: "r <=XXREAL-0R1 t"
          using A4 xxreal_1_th_3 sorry
        have "t <=XXREAL-0R1 q"
          using A5 xxreal_1_th_1 sorry
        thus "t inHIDDENR3 [.XXREAL-1K1 r,q .]"
          using A6 xxreal_1_th_1 sorry
      qed
      assume A7: "t inHIDDENR3 [.XXREAL-1K1 r,q .]"
      then have A8: "r <=XXREAL-0R1 t"
        using xxreal_1_th_1 sorry
      have A9: "t <=XXREAL-0R1 q"
        using A7 xxreal_1_th_1 sorry
      then have A10: "t <XXREAL-0R3 s"
        using A2 xxreal_0_th_2 sorry
      have A11: "p <=XXREAL-0R1 t"
        using A1 A8 xxreal_0_th_2 sorry
      have A12: "t inHIDDENR3 [.XXREAL-1K2 r,s .["
        using A8 A10 xxreal_1_th_3 sorry
      have "t inHIDDENR3 [.XXREAL-1K1 p,q .]"
        using A9 A11 xxreal_1_th_1 sorry
      thus "t inHIDDENR3 ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .])"
        using A12 xboole_0_def_4 sorry
    qed "sorry"
    thus "([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) =MEMBEREDR8 [.XXREAL-1K1 r,q .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_146:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 p & s <=XXREAL-0R1 q implies (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) =MEMBEREDR8 [.XXREAL-1K1 p,s .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 p & s <=XXREAL-0R1 q implies (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) =MEMBEREDR8 [.XXREAL-1K1 p,s .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 p"
      and A2: "s <=XXREAL-0R1 q"
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) implies t inHIDDENR3 [.XXREAL-1K1 p,s .]) & (t inHIDDENR3 [.XXREAL-1K1 p,s .] implies t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]))"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) implies t inHIDDENR3 [.XXREAL-1K1 p,s .]"
      proof(rule impI)
        assume A3: "t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .])"
        then have A4: "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
          using xboole_0_def_4 sorry
        have A5: "t inHIDDENR3 [.XXREAL-1K1 p,q .]"
          using A3 xboole_0_def_4 sorry
        have A6: "t <=XXREAL-0R1 s"
          using A4 xxreal_1_th_2 sorry
        have "p <=XXREAL-0R1 t"
          using A5 xxreal_1_th_1 sorry
        thus "t inHIDDENR3 [.XXREAL-1K1 p,s .]"
          using A6 xxreal_1_th_1 sorry
      qed
      assume A7: "t inHIDDENR3 [.XXREAL-1K1 p,s .]"
      then have A8: "p <=XXREAL-0R1 t"
        using xxreal_1_th_1 sorry
      have A9: "t <=XXREAL-0R1 s"
        using A7 xxreal_1_th_1 sorry
      have A10: "r <XXREAL-0R3 t"
        using A1 A8 xxreal_0_th_2 sorry
      have A11: "t <=XXREAL-0R1 q"
        using A2 A9 xxreal_0_th_2 sorry
      have A12: "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
        using A9 A10 xxreal_1_th_2 sorry
      have "t inHIDDENR3 [.XXREAL-1K1 p,q .]"
        using A8 A11 xxreal_1_th_1 sorry
      thus "t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .])"
        using A12 xboole_0_def_4 sorry
    qed "sorry"
    thus "(].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) =MEMBEREDR8 [.XXREAL-1K1 p,s .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_147:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r >=XXREAL-0R2 p & s >=XXREAL-0R2 q implies (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) =MEMBEREDR8 ].XXREAL-1K3 r,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r >=XXREAL-0R2 p & s >=XXREAL-0R2 q implies (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) =MEMBEREDR8 ].XXREAL-1K3 r,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r >=XXREAL-0R2 p"
      and A2: "s >=XXREAL-0R2 q"
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) implies t inHIDDENR3 ].XXREAL-1K3 r,q .]) & (t inHIDDENR3 ].XXREAL-1K3 r,q .] implies t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]))"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) implies t inHIDDENR3 ].XXREAL-1K3 r,q .]"
      proof(rule impI)
        assume A3: "t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .])"
        then have A4: "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
          using xboole_0_def_4 sorry
        have A5: "t inHIDDENR3 [.XXREAL-1K1 p,q .]"
          using A3 xboole_0_def_4 sorry
        have A6: "r <XXREAL-0R3 t"
          using A4 xxreal_1_th_2 sorry
        have "t <=XXREAL-0R1 q"
          using A5 xxreal_1_th_1 sorry
        thus "t inHIDDENR3 ].XXREAL-1K3 r,q .]"
          using A6 xxreal_1_th_2 sorry
      qed
      assume A7: "t inHIDDENR3 ].XXREAL-1K3 r,q .]"
      then have A8: "r <XXREAL-0R3 t"
        using xxreal_1_th_2 sorry
      have A9: "t <=XXREAL-0R1 q"
        using A7 xxreal_1_th_2 sorry
      then have A10: "t <=XXREAL-0R1 s"
        using A2 xxreal_0_th_2 sorry
      have A11: "p <=XXREAL-0R1 t"
        using A1 A8 xxreal_0_th_2 sorry
      have A12: "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
        using A8 A10 xxreal_1_th_2 sorry
      have "t inHIDDENR3 [.XXREAL-1K1 p,q .]"
        using A9 A11 xxreal_1_th_1 sorry
      thus "t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .])"
        using A12 xboole_0_def_4 sorry
    qed "sorry"
    thus "(].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) =MEMBEREDR8 ].XXREAL-1K3 r,q .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_148:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 p & s <=XXREAL-0R1 q implies (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) =MEMBEREDR8 [.XXREAL-1K2 p,s .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 p & s <=XXREAL-0R1 q implies (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) =MEMBEREDR8 [.XXREAL-1K2 p,s .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 p"
      and A2: "s <=XXREAL-0R1 q"
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) implies t inHIDDENR3 [.XXREAL-1K2 p,s .[) & (t inHIDDENR3 [.XXREAL-1K2 p,s .[ implies t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]))"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) implies t inHIDDENR3 [.XXREAL-1K2 p,s .["
      proof(rule impI)
        assume A3: "t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .])"
        then have A4: "t inHIDDENR3 ].XXREAL-1K4 r,s .["
          using xboole_0_def_4 sorry
        have A5: "t inHIDDENR3 [.XXREAL-1K1 p,q .]"
          using A3 xboole_0_def_4 sorry
        have A6: "t <XXREAL-0R3 s"
          using A4 xxreal_1_th_4 sorry
        have "p <=XXREAL-0R1 t"
          using A5 xxreal_1_th_1 sorry
        thus "t inHIDDENR3 [.XXREAL-1K2 p,s .["
          using A6 xxreal_1_th_3 sorry
      qed
      assume A7: "t inHIDDENR3 [.XXREAL-1K2 p,s .["
      then have A8: "p <=XXREAL-0R1 t"
        using xxreal_1_th_3 sorry
      have A9: "t <XXREAL-0R3 s"
        using A7 xxreal_1_th_3 sorry
      have A10: "r <XXREAL-0R3 t"
        using A1 A8 xxreal_0_th_2 sorry
      have A11: "t <=XXREAL-0R1 q"
        using A2 A9 xxreal_0_th_2 sorry
      have A12: "t inHIDDENR3 ].XXREAL-1K4 r,s .["
        using A9 A10 xxreal_1_th_4 sorry
      have "t inHIDDENR3 [.XXREAL-1K1 p,q .]"
        using A8 A11 xxreal_1_th_1 sorry
      thus "t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .])"
        using A12 xboole_0_def_4 sorry
    qed "sorry"
    thus "(].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) =MEMBEREDR8 [.XXREAL-1K2 p,s .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_149:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r >=XXREAL-0R2 p & s >XXREAL-0R4 q implies (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) =MEMBEREDR8 ].XXREAL-1K3 r,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r >=XXREAL-0R2 p & s >XXREAL-0R4 q implies (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) =MEMBEREDR8 ].XXREAL-1K3 r,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r >=XXREAL-0R2 p"
      and A2: "s >XXREAL-0R4 q"
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) implies t inHIDDENR3 ].XXREAL-1K3 r,q .]) & (t inHIDDENR3 ].XXREAL-1K3 r,q .] implies t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]))"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) implies t inHIDDENR3 ].XXREAL-1K3 r,q .]"
      proof(rule impI)
        assume A3: "t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .])"
        then have A4: "t inHIDDENR3 ].XXREAL-1K4 r,s .["
          using xboole_0_def_4 sorry
        have A5: "t inHIDDENR3 [.XXREAL-1K1 p,q .]"
          using A3 xboole_0_def_4 sorry
        have A6: "r <XXREAL-0R3 t"
          using A4 xxreal_1_th_4 sorry
        have "t <=XXREAL-0R1 q"
          using A5 xxreal_1_th_1 sorry
        thus "t inHIDDENR3 ].XXREAL-1K3 r,q .]"
          using A6 xxreal_1_th_2 sorry
      qed
      assume A7: "t inHIDDENR3 ].XXREAL-1K3 r,q .]"
      then have A8: "r <XXREAL-0R3 t"
        using xxreal_1_th_2 sorry
      have A9: "t <=XXREAL-0R1 q"
        using A7 xxreal_1_th_2 sorry
      then have A10: "t <XXREAL-0R3 s"
        using A2 xxreal_0_th_2 sorry
      have A11: "p <=XXREAL-0R1 t"
        using A1 A8 xxreal_0_th_2 sorry
      have A12: "t inHIDDENR3 ].XXREAL-1K4 r,s .["
        using A8 A10 xxreal_1_th_4 sorry
      have "t inHIDDENR3 [.XXREAL-1K1 p,q .]"
        using A9 A11 xxreal_1_th_1 sorry
      thus "t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .])"
        using A12 xboole_0_def_4 sorry
    qed "sorry"
    thus "(].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K1 p,q .]) =MEMBEREDR8 ].XXREAL-1K3 r,q .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_150:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 p & s <=XXREAL-0R1 q implies ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) =MEMBEREDR8 [.XXREAL-1K2 p,s .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 p & s <=XXREAL-0R1 q implies ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) =MEMBEREDR8 [.XXREAL-1K2 p,s .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 p"
      and A2: "s <=XXREAL-0R1 q"
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) implies t inHIDDENR3 [.XXREAL-1K2 p,s .[) & (t inHIDDENR3 [.XXREAL-1K2 p,s .[ implies t inHIDDENR3 ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[))"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) implies t inHIDDENR3 [.XXREAL-1K2 p,s .["
      proof(rule impI)
        assume A3: "t inHIDDENR3 ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[)"
        then have A4: "t inHIDDENR3 [.XXREAL-1K2 r,s .["
          using xboole_0_def_4 sorry
        have A5: "t inHIDDENR3 [.XXREAL-1K2 p,q .["
          using A3 xboole_0_def_4 sorry
        have A6: "t <XXREAL-0R3 s"
          using A4 xxreal_1_th_3 sorry
        have "p <=XXREAL-0R1 t"
          using A5 xxreal_1_th_3 sorry
        thus "t inHIDDENR3 [.XXREAL-1K2 p,s .["
          using A6 xxreal_1_th_3 sorry
      qed
      assume A7: "t inHIDDENR3 [.XXREAL-1K2 p,s .["
      then have A8: "p <=XXREAL-0R1 t"
        using xxreal_1_th_3 sorry
      have A9: "t <XXREAL-0R3 s"
        using A7 xxreal_1_th_3 sorry
      have A10: "r <=XXREAL-0R1 t"
        using A1 A8 xxreal_0_th_2 sorry
      have A11: "t <XXREAL-0R3 q"
        using A2 A9 xxreal_0_th_2 sorry
      have A12: "t inHIDDENR3 [.XXREAL-1K2 r,s .["
        using A9 A10 xxreal_1_th_3 sorry
      have "t inHIDDENR3 [.XXREAL-1K2 p,q .["
        using A8 A11 xxreal_1_th_3 sorry
      thus "t inHIDDENR3 ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[)"
        using A12 xboole_0_def_4 sorry
    qed "sorry"
    thus "([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) =MEMBEREDR8 [.XXREAL-1K2 p,s .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_151:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r >=XXREAL-0R2 p & s >=XXREAL-0R2 q implies ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) =MEMBEREDR8 [.XXREAL-1K2 r,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r >=XXREAL-0R2 p & s >=XXREAL-0R2 q implies ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) =MEMBEREDR8 [.XXREAL-1K2 r,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r >=XXREAL-0R2 p"
      and A2: "s >=XXREAL-0R2 q"
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) implies t inHIDDENR3 [.XXREAL-1K2 r,q .[) & (t inHIDDENR3 [.XXREAL-1K2 r,q .[ implies t inHIDDENR3 ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[))"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) implies t inHIDDENR3 [.XXREAL-1K2 r,q .["
      proof(rule impI)
        assume A3: "t inHIDDENR3 ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[)"
        then have A4: "t inHIDDENR3 [.XXREAL-1K2 r,s .["
          using xboole_0_def_4 sorry
        have A5: "t inHIDDENR3 [.XXREAL-1K2 p,q .["
          using A3 xboole_0_def_4 sorry
        have A6: "r <=XXREAL-0R1 t"
          using A4 xxreal_1_th_3 sorry
        have "t <XXREAL-0R3 q"
          using A5 xxreal_1_th_3 sorry
        thus "t inHIDDENR3 [.XXREAL-1K2 r,q .["
          using A6 xxreal_1_th_3 sorry
      qed
      assume A7: "t inHIDDENR3 [.XXREAL-1K2 r,q .["
      then have A8: "r <=XXREAL-0R1 t"
        using xxreal_1_th_3 sorry
      have A9: "t <XXREAL-0R3 q"
        using A7 xxreal_1_th_3 sorry
      then have A10: "t <XXREAL-0R3 s"
        using A2 xxreal_0_th_2 sorry
      have A11: "p <=XXREAL-0R1 t"
        using A1 A8 xxreal_0_th_2 sorry
      have A12: "t inHIDDENR3 [.XXREAL-1K2 r,s .["
        using A8 A10 xxreal_1_th_3 sorry
      have "t inHIDDENR3 [.XXREAL-1K2 p,q .["
        using A9 A11 xxreal_1_th_3 sorry
      thus "t inHIDDENR3 ([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[)"
        using A12 xboole_0_def_4 sorry
    qed "sorry"
    thus "([.XXREAL-1K2 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) =MEMBEREDR8 [.XXREAL-1K2 r,q .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_152:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 p & s <XXREAL-0R3 q implies (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) =MEMBEREDR8 [.XXREAL-1K1 p,s .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 p & s <XXREAL-0R3 q implies (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) =MEMBEREDR8 [.XXREAL-1K1 p,s .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 p"
      and A2: "s <XXREAL-0R3 q"
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) implies t inHIDDENR3 [.XXREAL-1K1 p,s .]) & (t inHIDDENR3 [.XXREAL-1K1 p,s .] implies t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[))"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) implies t inHIDDENR3 [.XXREAL-1K1 p,s .]"
      proof(rule impI)
        assume A3: "t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[)"
        then have A4: "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
          using xboole_0_def_4 sorry
        have A5: "t inHIDDENR3 [.XXREAL-1K2 p,q .["
          using A3 xboole_0_def_4 sorry
        have A6: "t <=XXREAL-0R1 s"
          using A4 xxreal_1_th_2 sorry
        have "p <=XXREAL-0R1 t"
          using A5 xxreal_1_th_3 sorry
        thus "t inHIDDENR3 [.XXREAL-1K1 p,s .]"
          using A6 xxreal_1_th_1 sorry
      qed
      assume A7: "t inHIDDENR3 [.XXREAL-1K1 p,s .]"
      then have A8: "p <=XXREAL-0R1 t"
        using xxreal_1_th_1 sorry
      have A9: "t <=XXREAL-0R1 s"
        using A7 xxreal_1_th_1 sorry
      have A10: "r <XXREAL-0R3 t"
        using A1 A8 xxreal_0_th_2 sorry
      have A11: "t <XXREAL-0R3 q"
        using A2 A9 xxreal_0_th_2 sorry
      have A12: "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
        using A9 A10 xxreal_1_th_2 sorry
      have "t inHIDDENR3 [.XXREAL-1K2 p,q .["
        using A8 A11 xxreal_1_th_3 sorry
      thus "t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[)"
        using A12 xboole_0_def_4 sorry
    qed "sorry"
    thus "(].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) =MEMBEREDR8 [.XXREAL-1K1 p,s .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_153:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r >=XXREAL-0R2 p & s >=XXREAL-0R2 q implies (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) =MEMBEREDR8 ].XXREAL-1K4 r,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r >=XXREAL-0R2 p & s >=XXREAL-0R2 q implies (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) =MEMBEREDR8 ].XXREAL-1K4 r,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r >=XXREAL-0R2 p"
      and A2: "s >=XXREAL-0R2 q"
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) implies t inHIDDENR3 ].XXREAL-1K4 r,q .[) & (t inHIDDENR3 ].XXREAL-1K4 r,q .[ implies t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[))"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) implies t inHIDDENR3 ].XXREAL-1K4 r,q .["
      proof(rule impI)
        assume A3: "t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[)"
        then have A4: "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
          using xboole_0_def_4 sorry
        have A5: "t inHIDDENR3 [.XXREAL-1K2 p,q .["
          using A3 xboole_0_def_4 sorry
        have A6: "r <XXREAL-0R3 t"
          using A4 xxreal_1_th_2 sorry
        have "t <XXREAL-0R3 q"
          using A5 xxreal_1_th_3 sorry
        thus "t inHIDDENR3 ].XXREAL-1K4 r,q .["
          using A6 xxreal_1_th_4 sorry
      qed
      assume A7: "t inHIDDENR3 ].XXREAL-1K4 r,q .["
      then have A8: "r <XXREAL-0R3 t"
        using xxreal_1_th_4 sorry
      have A9: "t <XXREAL-0R3 q"
        using A7 xxreal_1_th_4 sorry
      then have A10: "t <=XXREAL-0R1 s"
        using A2 xxreal_0_th_2 sorry
      have A11: "p <=XXREAL-0R1 t"
        using A1 A8 xxreal_0_th_2 sorry
      have A12: "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
        using A8 A10 xxreal_1_th_2 sorry
      have "t inHIDDENR3 [.XXREAL-1K2 p,q .["
        using A9 A11 xxreal_1_th_3 sorry
      thus "t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[)"
        using A12 xboole_0_def_4 sorry
    qed "sorry"
    thus "(].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) =MEMBEREDR8 ].XXREAL-1K4 r,q .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_154:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 p & s <=XXREAL-0R1 q implies (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) =MEMBEREDR8 [.XXREAL-1K2 p,s .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 p & s <=XXREAL-0R1 q implies (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) =MEMBEREDR8 [.XXREAL-1K2 p,s .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 p"
      and A2: "s <=XXREAL-0R1 q"
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) implies t inHIDDENR3 [.XXREAL-1K2 p,s .[) & (t inHIDDENR3 [.XXREAL-1K2 p,s .[ implies t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[))"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) implies t inHIDDENR3 [.XXREAL-1K2 p,s .["
      proof(rule impI)
        assume A3: "t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[)"
        then have A4: "t inHIDDENR3 ].XXREAL-1K4 r,s .["
          using xboole_0_def_4 sorry
        have A5: "t inHIDDENR3 [.XXREAL-1K2 p,q .["
          using A3 xboole_0_def_4 sorry
        have A6: "t <XXREAL-0R3 s"
          using A4 xxreal_1_th_4 sorry
        have "p <=XXREAL-0R1 t"
          using A5 xxreal_1_th_3 sorry
        thus "t inHIDDENR3 [.XXREAL-1K2 p,s .["
          using A6 xxreal_1_th_3 sorry
      qed
      assume A7: "t inHIDDENR3 [.XXREAL-1K2 p,s .["
      then have A8: "p <=XXREAL-0R1 t"
        using xxreal_1_th_3 sorry
      have A9: "t <XXREAL-0R3 s"
        using A7 xxreal_1_th_3 sorry
      have A10: "r <XXREAL-0R3 t"
        using A1 A8 xxreal_0_th_2 sorry
      have A11: "t <XXREAL-0R3 q"
        using A2 A9 xxreal_0_th_2 sorry
      have A12: "t inHIDDENR3 ].XXREAL-1K4 r,s .["
        using A9 A10 xxreal_1_th_4 sorry
      have "t inHIDDENR3 [.XXREAL-1K2 p,q .["
        using A8 A11 xxreal_1_th_3 sorry
      thus "t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[)"
        using A12 xboole_0_def_4 sorry
    qed "sorry"
    thus "(].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) =MEMBEREDR8 [.XXREAL-1K2 p,s .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_155:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r >=XXREAL-0R2 p & s >=XXREAL-0R2 q implies (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) =MEMBEREDR8 ].XXREAL-1K4 r,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r >=XXREAL-0R2 p & s >=XXREAL-0R2 q implies (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) =MEMBEREDR8 ].XXREAL-1K4 r,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r >=XXREAL-0R2 p"
      and A2: "s >=XXREAL-0R2 q"
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) implies t inHIDDENR3 ].XXREAL-1K4 r,q .[) & (t inHIDDENR3 ].XXREAL-1K4 r,q .[ implies t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[))"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) implies t inHIDDENR3 ].XXREAL-1K4 r,q .["
      proof(rule impI)
        assume A3: "t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[)"
        then have A4: "t inHIDDENR3 ].XXREAL-1K4 r,s .["
          using xboole_0_def_4 sorry
        have A5: "t inHIDDENR3 [.XXREAL-1K2 p,q .["
          using A3 xboole_0_def_4 sorry
        have A6: "r <XXREAL-0R3 t"
          using A4 xxreal_1_th_4 sorry
        have "t <XXREAL-0R3 q"
          using A5 xxreal_1_th_3 sorry
        thus "t inHIDDENR3 ].XXREAL-1K4 r,q .["
          using A6 xxreal_1_th_4 sorry
      qed
      assume A7: "t inHIDDENR3 ].XXREAL-1K4 r,q .["
      then have A8: "r <XXREAL-0R3 t"
        using xxreal_1_th_4 sorry
      have A9: "t <XXREAL-0R3 q"
        using A7 xxreal_1_th_4 sorry
      then have A10: "t <XXREAL-0R3 s"
        using A2 xxreal_0_th_2 sorry
      have A11: "p <=XXREAL-0R1 t"
        using A1 A8 xxreal_0_th_2 sorry
      have A12: "t inHIDDENR3 ].XXREAL-1K4 r,s .["
        using A8 A10 xxreal_1_th_4 sorry
      have "t inHIDDENR3 [.XXREAL-1K2 p,q .["
        using A9 A11 xxreal_1_th_3 sorry
      thus "t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[)"
        using A12 xboole_0_def_4 sorry
    qed "sorry"
    thus "(].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 p,q .[) =MEMBEREDR8 ].XXREAL-1K4 r,q .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_156:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 p & s <=XXREAL-0R1 q implies (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .]) =MEMBEREDR8 ].XXREAL-1K3 p,s .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 p & s <=XXREAL-0R1 q implies (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .]) =MEMBEREDR8 ].XXREAL-1K3 p,s .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 p"
      and A2: "s <=XXREAL-0R1 q"
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .]) implies t inHIDDENR3 ].XXREAL-1K3 p,s .]) & (t inHIDDENR3 ].XXREAL-1K3 p,s .] implies t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .]))"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .]) implies t inHIDDENR3 ].XXREAL-1K3 p,s .]"
      proof(rule impI)
        assume A3: "t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .])"
        then have A4: "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
          using xboole_0_def_4 sorry
        have A5: "t inHIDDENR3 ].XXREAL-1K3 p,q .]"
          using A3 xboole_0_def_4 sorry
        have A6: "t <=XXREAL-0R1 s"
          using A4 xxreal_1_th_2 sorry
        have "p <XXREAL-0R3 t"
          using A5 xxreal_1_th_2 sorry
        thus "t inHIDDENR3 ].XXREAL-1K3 p,s .]"
          using A6 xxreal_1_th_2 sorry
      qed
      assume A7: "t inHIDDENR3 ].XXREAL-1K3 p,s .]"
      then have A8: "p <XXREAL-0R3 t"
        using xxreal_1_th_2 sorry
      have A9: "t <=XXREAL-0R1 s"
        using A7 xxreal_1_th_2 sorry
      have A10: "r <XXREAL-0R3 t"
        using A1 A8 xxreal_0_th_2 sorry
      have A11: "t <=XXREAL-0R1 q"
        using A2 A9 xxreal_0_th_2 sorry
      have A12: "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
        using A9 A10 xxreal_1_th_2 sorry
      have "t inHIDDENR3 ].XXREAL-1K3 p,q .]"
        using A8 A11 xxreal_1_th_2 sorry
      thus "t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .])"
        using A12 xboole_0_def_4 sorry
    qed "sorry"
    thus "(].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .]) =MEMBEREDR8 ].XXREAL-1K3 p,s .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_157:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r >=XXREAL-0R2 p & s >=XXREAL-0R2 q implies (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .]) =MEMBEREDR8 ].XXREAL-1K3 r,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r >=XXREAL-0R2 p & s >=XXREAL-0R2 q implies (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .]) =MEMBEREDR8 ].XXREAL-1K3 r,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r >=XXREAL-0R2 p"
      and A2: "s >=XXREAL-0R2 q"
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .]) implies t inHIDDENR3 ].XXREAL-1K3 r,q .]) & (t inHIDDENR3 ].XXREAL-1K3 r,q .] implies t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .]))"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .]) implies t inHIDDENR3 ].XXREAL-1K3 r,q .]"
      proof(rule impI)
        assume A3: "t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .])"
        then have A4: "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
          using xboole_0_def_4 sorry
        have A5: "t inHIDDENR3 ].XXREAL-1K3 p,q .]"
          using A3 xboole_0_def_4 sorry
        have A6: "r <XXREAL-0R3 t"
          using A4 xxreal_1_th_2 sorry
        have "t <=XXREAL-0R1 q"
          using A5 xxreal_1_th_2 sorry
        thus "t inHIDDENR3 ].XXREAL-1K3 r,q .]"
          using A6 xxreal_1_th_2 sorry
      qed
      assume A7: "t inHIDDENR3 ].XXREAL-1K3 r,q .]"
      then have A8: "r <XXREAL-0R3 t"
        using xxreal_1_th_2 sorry
      have A9: "t <=XXREAL-0R1 q"
        using A7 xxreal_1_th_2 sorry
      then have A10: "t <=XXREAL-0R1 s"
        using A2 xxreal_0_th_2 sorry
      have A11: "p <XXREAL-0R3 t"
        using A1 A8 xxreal_0_th_2 sorry
      have A12: "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
        using A8 A10 xxreal_1_th_2 sorry
      have "t inHIDDENR3 ].XXREAL-1K3 p,q .]"
        using A9 A11 xxreal_1_th_2 sorry
      thus "t inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .])"
        using A12 xboole_0_def_4 sorry
    qed "sorry"
    thus "(].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .]) =MEMBEREDR8 ].XXREAL-1K3 r,q .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_158:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 p & s <=XXREAL-0R1 q implies (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .]) =MEMBEREDR8 ].XXREAL-1K4 p,s .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 p & s <=XXREAL-0R1 q implies (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .]) =MEMBEREDR8 ].XXREAL-1K4 p,s .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 p"
      and A2: "s <=XXREAL-0R1 q"
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .]) implies t inHIDDENR3 ].XXREAL-1K4 p,s .[) & (t inHIDDENR3 ].XXREAL-1K4 p,s .[ implies t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .]))"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .]) implies t inHIDDENR3 ].XXREAL-1K4 p,s .["
      proof(rule impI)
        assume A3: "t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .])"
        then have A4: "t inHIDDENR3 ].XXREAL-1K4 r,s .["
          using xboole_0_def_4 sorry
        have A5: "t inHIDDENR3 ].XXREAL-1K3 p,q .]"
          using A3 xboole_0_def_4 sorry
        have A6: "t <XXREAL-0R3 s"
          using A4 xxreal_1_th_4 sorry
        have "p <XXREAL-0R3 t"
          using A5 xxreal_1_th_2 sorry
        thus "t inHIDDENR3 ].XXREAL-1K4 p,s .["
          using A6 xxreal_1_th_4 sorry
      qed
      assume A7: "t inHIDDENR3 ].XXREAL-1K4 p,s .["
      then have A8: "p <XXREAL-0R3 t"
        using xxreal_1_th_4 sorry
      have A9: "t <XXREAL-0R3 s"
        using A7 xxreal_1_th_4 sorry
      have A10: "r <XXREAL-0R3 t"
        using A1 A8 xxreal_0_th_2 sorry
      have A11: "t <=XXREAL-0R1 q"
        using A2 A9 xxreal_0_th_2 sorry
      have A12: "t inHIDDENR3 ].XXREAL-1K4 r,s .["
        using A9 A10 xxreal_1_th_4 sorry
      have "t inHIDDENR3 ].XXREAL-1K3 p,q .]"
        using A8 A11 xxreal_1_th_2 sorry
      thus "t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .])"
        using A12 xboole_0_def_4 sorry
    qed "sorry"
    thus "(].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .]) =MEMBEREDR8 ].XXREAL-1K4 p,s .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_159:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r >=XXREAL-0R2 p & s >XXREAL-0R4 q implies (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .]) =MEMBEREDR8 ].XXREAL-1K3 r,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r >=XXREAL-0R2 p & s >XXREAL-0R4 q implies (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .]) =MEMBEREDR8 ].XXREAL-1K3 r,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r >=XXREAL-0R2 p"
      and A2: "s >XXREAL-0R4 q"
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .]) implies t inHIDDENR3 ].XXREAL-1K3 r,q .]) & (t inHIDDENR3 ].XXREAL-1K3 r,q .] implies t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .]))"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .]) implies t inHIDDENR3 ].XXREAL-1K3 r,q .]"
      proof(rule impI)
        assume A3: "t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .])"
        then have A4: "t inHIDDENR3 ].XXREAL-1K4 r,s .["
          using xboole_0_def_4 sorry
        have A5: "t inHIDDENR3 ].XXREAL-1K3 p,q .]"
          using A3 xboole_0_def_4 sorry
        have A6: "r <XXREAL-0R3 t"
          using A4 xxreal_1_th_4 sorry
        have "t <=XXREAL-0R1 q"
          using A5 xxreal_1_th_2 sorry
        thus "t inHIDDENR3 ].XXREAL-1K3 r,q .]"
          using A6 xxreal_1_th_2 sorry
      qed
      assume A7: "t inHIDDENR3 ].XXREAL-1K3 r,q .]"
      then have A8: "r <XXREAL-0R3 t"
        using xxreal_1_th_2 sorry
      have A9: "t <=XXREAL-0R1 q"
        using A7 xxreal_1_th_2 sorry
      then have A10: "t <XXREAL-0R3 s"
        using A2 xxreal_0_th_2 sorry
      have A11: "p <XXREAL-0R3 t"
        using A1 A8 xxreal_0_th_2 sorry
      have A12: "t inHIDDENR3 ].XXREAL-1K4 r,s .["
        using A8 A10 xxreal_1_th_4 sorry
      have "t inHIDDENR3 ].XXREAL-1K3 p,q .]"
        using A9 A11 xxreal_1_th_2 sorry
      thus "t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .])"
        using A12 xboole_0_def_4 sorry
    qed "sorry"
    thus "(].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 (].XXREAL-1K3 p,q .]) =MEMBEREDR8 ].XXREAL-1K3 r,q .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_160:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 p & s <=XXREAL-0R1 q implies (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 (].XXREAL-1K4 p,q .[) =MEMBEREDR8 ].XXREAL-1K4 p,s .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 p & s <=XXREAL-0R1 q implies (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 (].XXREAL-1K4 p,q .[) =MEMBEREDR8 ].XXREAL-1K4 p,s .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 p"
      and A2: "s <=XXREAL-0R1 q"
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 (].XXREAL-1K4 p,q .[) implies t inHIDDENR3 ].XXREAL-1K4 p,s .[) & (t inHIDDENR3 ].XXREAL-1K4 p,s .[ implies t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 (].XXREAL-1K4 p,q .[))"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 (].XXREAL-1K4 p,q .[) implies t inHIDDENR3 ].XXREAL-1K4 p,s .["
      proof(rule impI)
        assume A3: "t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 (].XXREAL-1K4 p,q .[)"
        then have A4: "t inHIDDENR3 ].XXREAL-1K4 r,s .["
          using xboole_0_def_4 sorry
        have A5: "t inHIDDENR3 ].XXREAL-1K4 p,q .["
          using A3 xboole_0_def_4 sorry
        have A6: "t <XXREAL-0R3 s"
          using A4 xxreal_1_th_4 sorry
        have "p <XXREAL-0R3 t"
          using A5 xxreal_1_th_4 sorry
        thus "t inHIDDENR3 ].XXREAL-1K4 p,s .["
          using A6 xxreal_1_th_4 sorry
      qed
      assume A7: "t inHIDDENR3 ].XXREAL-1K4 p,s .["
      then have A8: "p <XXREAL-0R3 t"
        using xxreal_1_th_4 sorry
      have A9: "t <XXREAL-0R3 s"
        using A7 xxreal_1_th_4 sorry
      have A10: "r <XXREAL-0R3 t"
        using A1 A8 xxreal_0_th_2 sorry
      have A11: "t <XXREAL-0R3 q"
        using A2 A9 xxreal_0_th_2 sorry
      have A12: "t inHIDDENR3 ].XXREAL-1K4 r,s .["
        using A9 A10 xxreal_1_th_4 sorry
      have "t inHIDDENR3 ].XXREAL-1K4 p,q .["
        using A8 A11 xxreal_1_th_4 sorry
      thus "t inHIDDENR3 (].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 (].XXREAL-1K4 p,q .[)"
        using A12 xboole_0_def_4 sorry
    qed "sorry"
    thus "(].XXREAL-1K4 r,s .[)/\\XBOOLE-0K3 (].XXREAL-1K4 p,q .[) =MEMBEREDR8 ].XXREAL-1K4 p,s .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_161:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 p,q .[ c=MEMBEREDR2 [.XXREAL-1K2 minXXREAL-0K4(r,p),maxXXREAL-0K5(s,q) .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 p,q .[ c=MEMBEREDR2 [.XXREAL-1K2 minXXREAL-0K4(r,p),maxXXREAL-0K5(s,q) .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 p,q .[ implies t inHIDDENR3 [.XXREAL-1K2 minXXREAL-0K4(r,p),maxXXREAL-0K5(s,q) .["
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume "t inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 p,q .["
      then have "t inHIDDENR3 [.XXREAL-1K2 r,s .[ or t inHIDDENR3 [.XXREAL-1K2 p,q .["
        using xboole_0_def_3 sorry
      then have A1: "r <=XXREAL-0R1 t & t <XXREAL-0R3 s or p <=XXREAL-0R1 t & t <XXREAL-0R3 q"
        using xxreal_1_th_3 sorry
      then have A2: "minXXREAL-0K4(r,p) <=XXREAL-0R1 t"
        using xxreal_0_th_23 sorry
      have "t <XXREAL-0R3 maxXXREAL-0K5(s,q)"
        using A1 xxreal_0_th_30 sorry
      thus "t inHIDDENR3 [.XXREAL-1K2 minXXREAL-0K4(r,p),maxXXREAL-0K5(s,q) .["
        using A2 xxreal_1_th_3 sorry
    qed "sorry"
    thus "[.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 p,q .[ c=MEMBEREDR2 [.XXREAL-1K2 minXXREAL-0K4(r,p),maxXXREAL-0K5(s,q) .["
      using membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_162:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds [.XXREAL-1K2 r,s .[ meetsXBOOLE-0R5 [.XXREAL-1K2 p,q .[ implies [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 p,q .[ =MEMBEREDR8 [.XXREAL-1K2 minXXREAL-0K4(r,p),maxXXREAL-0K5(s,q) .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds [.XXREAL-1K2 r,s .[ meetsXBOOLE-0R5 [.XXREAL-1K2 p,q .[ implies [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 p,q .[ =MEMBEREDR8 [.XXREAL-1K2 minXXREAL-0K4(r,p),maxXXREAL-0K5(s,q) .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume "[.XXREAL-1K2 r,s .[ meetsXBOOLE-0R5 [.XXREAL-1K2 p,q .["
    then obtain u where
      [ty]:"u be ExtRealXXREAL-0M1" and 
      A1: "u inHIDDENR3 [.XXREAL-1K2 r,s .["and A2: "u inHIDDENR3 [.XXREAL-1K2 p,q .["
       sorry
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 p,q .[ implies t inHIDDENR3 [.XXREAL-1K2 minXXREAL-0K4(r,p),maxXXREAL-0K5(s,q) .[) & (t inHIDDENR3 [.XXREAL-1K2 minXXREAL-0K4(r,p),maxXXREAL-0K5(s,q) .[ implies t inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 p,q .[)"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 p,q .[ implies t inHIDDENR3 [.XXREAL-1K2 minXXREAL-0K4(r,p),maxXXREAL-0K5(s,q) .["
      proof(rule impI)
        assume "t inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 p,q .["
        then have "t inHIDDENR3 [.XXREAL-1K2 r,s .[ or t inHIDDENR3 [.XXREAL-1K2 p,q .["
          using xboole_0_def_3 sorry
        then have A3: "r <=XXREAL-0R1 t & t <XXREAL-0R3 s or p <=XXREAL-0R1 t & t <XXREAL-0R3 q"
          using xxreal_1_th_3 sorry
        then have A4: "minXXREAL-0K4(r,p) <=XXREAL-0R1 t"
          using xxreal_0_th_23 sorry
        have "t <XXREAL-0R3 maxXXREAL-0K5(s,q)"
          using A3 xxreal_0_th_30 sorry
        thus "t inHIDDENR3 [.XXREAL-1K2 minXXREAL-0K4(r,p),maxXXREAL-0K5(s,q) .["
          using A4 xxreal_1_th_3 sorry
      qed
      have A5: "r <=XXREAL-0R1 u"
        using A1 xxreal_1_th_3 sorry
      have A6: "u <XXREAL-0R3 s"
        using A1 xxreal_1_th_3 sorry
      have A7: "p <=XXREAL-0R1 u"
        using A2 xxreal_1_th_3 sorry
      have A8: "u <XXREAL-0R3 q"
        using A2 xxreal_1_th_3 sorry
      assume A9: "t inHIDDENR3 [.XXREAL-1K2 minXXREAL-0K4(r,p),maxXXREAL-0K5(s,q) .["
      then have A10: "minXXREAL-0K4(r,p) <=XXREAL-0R1 t"
        using xxreal_1_th_3 sorry
      have A11: "t <XXREAL-0R3 maxXXREAL-0K5(s,q)"
        using A9 xxreal_1_th_3 sorry
      show "t inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 p,q .["
      proof-
        have cases: "((r <=XXREAL-0R1 t & t <XXREAL-0R3 s or p <=XXREAL-0R1 t & t <XXREAL-0R3 q) or p <=XXREAL-0R1 t & t <XXREAL-0R3 s) or r <=XXREAL-0R1 t & t <XXREAL-0R3 q"
          using A10 A11 xxreal_0_th_21 xxreal_0_th_28 sorry
        have case1: "r <=XXREAL-0R1 t & t <XXREAL-0R3 s or p <=XXREAL-0R1 t & t <XXREAL-0R3 q implies t inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 p,q .["
        proof(rule impI)
          assume "r <=XXREAL-0R1 t & t <XXREAL-0R3 s or p <=XXREAL-0R1 t & t <XXREAL-0R3 q"
          then have "t inHIDDENR3 [.XXREAL-1K2 r,s .[ or t inHIDDENR3 [.XXREAL-1K2 p,q .["
            using xxreal_1_th_3 sorry
          thus "t inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 p,q .["
            using xboole_0_def_3 sorry
        qed
        have case2: "p <=XXREAL-0R1 t & t <XXREAL-0R3 s implies t inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 p,q .["
        proof(rule impMI ,rule impI)
          assume A12: "p <=XXREAL-0R1 t"
            and A13: "t <XXREAL-0R3 s"
          have "u <=XXREAL-0R1 t or t <=XXREAL-0R1 u"
             sorry
          then have "r <=XXREAL-0R1 t or t <XXREAL-0R3 q"
            using A5 A8 xxreal_0_th_2 sorry
          then have "t inHIDDENR3 [.XXREAL-1K2 r,s .[ or t inHIDDENR3 [.XXREAL-1K2 p,q .["
            using A12 A13 xxreal_1_th_3 sorry
          thus "t inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 p,q .["
            using xboole_0_def_3 sorry
        qed
        have case3: "r <=XXREAL-0R1 t & t <XXREAL-0R3 q implies t inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 p,q .["
        proof(rule impMI ,rule impI)
          assume A14: "r <=XXREAL-0R1 t"
            and A15: "t <XXREAL-0R3 q"
          have "u <=XXREAL-0R1 t or t <=XXREAL-0R1 u"
             sorry
          then have "t <XXREAL-0R3 s or p <=XXREAL-0R1 t"
            using A6 A7 xxreal_0_th_2 sorry
          then have "t inHIDDENR3 [.XXREAL-1K2 r,s .[ or t inHIDDENR3 [.XXREAL-1K2 p,q .["
            using A14 A15 xxreal_1_th_3 sorry
          thus "t inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 p,q .["
            using xboole_0_def_3 sorry
        qed
        show " ?thesis "
          using cases case1 case2 case3 sorry
      qed
    qed "sorry"
    thus "[.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 p,q .[ =MEMBEREDR8 [.XXREAL-1K2 minXXREAL-0K4(r,p),maxXXREAL-0K5(s,q) .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_163:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 p,q .] c=MEMBEREDR2 ].XXREAL-1K3 minXXREAL-0K4(r,p),maxXXREAL-0K5(s,q) .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 p,q .] c=MEMBEREDR2 ].XXREAL-1K3 minXXREAL-0K4(r,p),maxXXREAL-0K5(s,q) .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 p,q .] implies t inHIDDENR3 ].XXREAL-1K3 minXXREAL-0K4(r,p),maxXXREAL-0K5(s,q) .]"
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume "t inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 p,q .]"
      then have "t inHIDDENR3 ].XXREAL-1K3 r,s .] or t inHIDDENR3 ].XXREAL-1K3 p,q .]"
        using xboole_0_def_3 sorry
      then have A1: "r <XXREAL-0R3 t & t <=XXREAL-0R1 s or p <XXREAL-0R3 t & t <=XXREAL-0R1 q"
        using xxreal_1_th_2 sorry
      then have A2: "minXXREAL-0K4(r,p) <XXREAL-0R3 t"
        using xxreal_0_th_22 sorry
      have "t <=XXREAL-0R1 maxXXREAL-0K5(s,q)"
        using A1 xxreal_0_th_31 sorry
      thus "t inHIDDENR3 ].XXREAL-1K3 minXXREAL-0K4(r,p),maxXXREAL-0K5(s,q) .]"
        using A2 xxreal_1_th_2 sorry
    qed "sorry"
    thus "].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 p,q .] c=MEMBEREDR2 ].XXREAL-1K3 minXXREAL-0K4(r,p),maxXXREAL-0K5(s,q) .]"
      using membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_164:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds ].XXREAL-1K3 r,s .] meetsXBOOLE-0R5 ].XXREAL-1K3 p,q .] implies ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 p,q .] =MEMBEREDR8 ].XXREAL-1K3 minXXREAL-0K4(r,p),maxXXREAL-0K5(s,q) .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds ].XXREAL-1K3 r,s .] meetsXBOOLE-0R5 ].XXREAL-1K3 p,q .] implies ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 p,q .] =MEMBEREDR8 ].XXREAL-1K3 minXXREAL-0K4(r,p),maxXXREAL-0K5(s,q) .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume "].XXREAL-1K3 r,s .] meetsXBOOLE-0R5 ].XXREAL-1K3 p,q .]"
    then obtain u where
      [ty]:"u be ExtRealXXREAL-0M1" and 
      A1: "u inHIDDENR3 ].XXREAL-1K3 r,s .]"and A2: "u inHIDDENR3 ].XXREAL-1K3 p,q .]"
       sorry
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 p,q .] implies t inHIDDENR3 ].XXREAL-1K3 minXXREAL-0K4(r,p),maxXXREAL-0K5(s,q) .]) & (t inHIDDENR3 ].XXREAL-1K3 minXXREAL-0K4(r,p),maxXXREAL-0K5(s,q) .] implies t inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 p,q .])"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 p,q .] implies t inHIDDENR3 ].XXREAL-1K3 minXXREAL-0K4(r,p),maxXXREAL-0K5(s,q) .]"
      proof(rule impI)
        assume "t inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 p,q .]"
        then have "t inHIDDENR3 ].XXREAL-1K3 r,s .] or t inHIDDENR3 ].XXREAL-1K3 p,q .]"
          using xboole_0_def_3 sorry
        then have A3: "r <XXREAL-0R3 t & t <=XXREAL-0R1 s or p <XXREAL-0R3 t & t <=XXREAL-0R1 q"
          using xxreal_1_th_2 sorry
        then have A4: "minXXREAL-0K4(r,p) <XXREAL-0R3 t"
          using xxreal_0_th_22 sorry
        have "t <=XXREAL-0R1 maxXXREAL-0K5(s,q)"
          using A3 xxreal_0_th_31 sorry
        thus "t inHIDDENR3 ].XXREAL-1K3 minXXREAL-0K4(r,p),maxXXREAL-0K5(s,q) .]"
          using A4 xxreal_1_th_2 sorry
      qed
      have A5: "r <XXREAL-0R3 u"
        using A1 xxreal_1_th_2 sorry
      have A6: "u <=XXREAL-0R1 s"
        using A1 xxreal_1_th_2 sorry
      have A7: "p <XXREAL-0R3 u"
        using A2 xxreal_1_th_2 sorry
      have A8: "u <=XXREAL-0R1 q"
        using A2 xxreal_1_th_2 sorry
      assume A9: "t inHIDDENR3 ].XXREAL-1K3 minXXREAL-0K4(r,p),maxXXREAL-0K5(s,q) .]"
      then have A10: "minXXREAL-0K4(r,p) <XXREAL-0R3 t"
        using xxreal_1_th_2 sorry
      have A11: "t <=XXREAL-0R1 maxXXREAL-0K5(s,q)"
        using A9 xxreal_1_th_2 sorry
      show "t inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 p,q .]"
      proof-
        have cases: "((r <XXREAL-0R3 t & t <=XXREAL-0R1 s or p <XXREAL-0R3 t & t <=XXREAL-0R1 q) or p <XXREAL-0R3 t & t <=XXREAL-0R1 s) or r <XXREAL-0R3 t & t <=XXREAL-0R1 q"
          using A10 A11 xxreal_0_th_20 xxreal_0_th_29 sorry
        have case1: "r <XXREAL-0R3 t & t <=XXREAL-0R1 s or p <XXREAL-0R3 t & t <=XXREAL-0R1 q implies t inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 p,q .]"
        proof(rule impI)
          assume "r <XXREAL-0R3 t & t <=XXREAL-0R1 s or p <XXREAL-0R3 t & t <=XXREAL-0R1 q"
          then have "t inHIDDENR3 ].XXREAL-1K3 r,s .] or t inHIDDENR3 ].XXREAL-1K3 p,q .]"
            using xxreal_1_th_2 sorry
          thus "t inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 p,q .]"
            using xboole_0_def_3 sorry
        qed
        have case2: "p <XXREAL-0R3 t & t <=XXREAL-0R1 s implies t inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 p,q .]"
        proof(rule impMI ,rule impI)
          assume A12: "p <XXREAL-0R3 t"
            and A13: "t <=XXREAL-0R1 s"
          have "u <=XXREAL-0R1 t or t <=XXREAL-0R1 u"
             sorry
          then have "r <XXREAL-0R3 t or t <=XXREAL-0R1 q"
            using A5 A8 xxreal_0_th_2 sorry
          then have "t inHIDDENR3 ].XXREAL-1K3 r,s .] or t inHIDDENR3 ].XXREAL-1K3 p,q .]"
            using A12 A13 xxreal_1_th_2 sorry
          thus "t inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 p,q .]"
            using xboole_0_def_3 sorry
        qed
        have case3: "r <XXREAL-0R3 t & t <=XXREAL-0R1 q implies t inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 p,q .]"
        proof(rule impMI ,rule impI)
          assume A14: "r <XXREAL-0R3 t"
            and A15: "t <=XXREAL-0R1 q"
          have "u <=XXREAL-0R1 t or t <=XXREAL-0R1 u"
             sorry
          then have "t <=XXREAL-0R1 s or p <XXREAL-0R3 t"
            using A6 A7 xxreal_0_th_2 sorry
          then have "t inHIDDENR3 ].XXREAL-1K3 r,s .] or t inHIDDENR3 ].XXREAL-1K3 p,q .]"
            using A14 A15 xxreal_1_th_2 sorry
          thus "t inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 p,q .]"
            using xboole_0_def_3 sorry
        qed
        show " ?thesis "
          using cases case1 case2 case3 sorry
      qed
    qed "sorry"
    thus "].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 p,q .] =MEMBEREDR8 ].XXREAL-1K3 minXXREAL-0K4(r,p),maxXXREAL-0K5(s,q) .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_165:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & s <=XXREAL-0R1 t implies [.XXREAL-1K1 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,t .] =MEMBEREDR8 [.XXREAL-1K1 r,t .]"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & s <=XXREAL-0R1 t implies [.XXREAL-1K1 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,t .] =MEMBEREDR8 [.XXREAL-1K1 r,t .]"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
      and A2: "s <=XXREAL-0R1 t"
    have " for p be ExtRealXXREAL-0M1 holds (p inHIDDENR3 [.XXREAL-1K1 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,t .] implies p inHIDDENR3 [.XXREAL-1K1 r,t .]) & (p inHIDDENR3 [.XXREAL-1K1 r,t .] implies p inHIDDENR3 [.XXREAL-1K1 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,t .])"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      show "p inHIDDENR3 [.XXREAL-1K1 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,t .] implies p inHIDDENR3 [.XXREAL-1K1 r,t .]"
      proof(rule impI)
        assume "p inHIDDENR3 [.XXREAL-1K1 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,t .]"
        then have "p inHIDDENR3 [.XXREAL-1K1 r,s .] or p inHIDDENR3 [.XXREAL-1K1 s,t .]"
          using xboole_0_def_3 sorry
        then have A3: "r <=XXREAL-0R1 p & p <=XXREAL-0R1 s or s <=XXREAL-0R1 p & p <=XXREAL-0R1 t"
          using xxreal_1_th_1 sorry
        then have A4: "r <=XXREAL-0R1 p"
          using A1 xxreal_0_th_2 sorry
        have "p <=XXREAL-0R1 t"
          using A2 A3 xxreal_0_th_2 sorry
        thus "p inHIDDENR3 [.XXREAL-1K1 r,t .]"
          using A4 xxreal_1_th_1 sorry
      qed
      assume "p inHIDDENR3 [.XXREAL-1K1 r,t .]"
      then have "r <=XXREAL-0R1 p & p <=XXREAL-0R1 s or s <=XXREAL-0R1 p & p <=XXREAL-0R1 t"
        using xxreal_1_th_1 sorry
      then have "p inHIDDENR3 [.XXREAL-1K1 r,s .] or p inHIDDENR3 [.XXREAL-1K1 s,t .]"
        using xxreal_1_th_1 sorry
      thus "p inHIDDENR3 [.XXREAL-1K1 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,t .]"
        using xboole_0_def_3 sorry
    qed "sorry"
    thus "[.XXREAL-1K1 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,t .] =MEMBEREDR8 [.XXREAL-1K1 r,t .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_166:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & s <=XXREAL-0R1 t implies [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,t .] =MEMBEREDR8 [.XXREAL-1K1 r,t .]"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & s <=XXREAL-0R1 t implies [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,t .] =MEMBEREDR8 [.XXREAL-1K1 r,t .]"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
      and A2: "s <=XXREAL-0R1 t"
    have " for p be ExtRealXXREAL-0M1 holds (p inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,t .] implies p inHIDDENR3 [.XXREAL-1K1 r,t .]) & (p inHIDDENR3 [.XXREAL-1K1 r,t .] implies p inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,t .])"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      show "p inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,t .] implies p inHIDDENR3 [.XXREAL-1K1 r,t .]"
      proof(rule impI)
        assume "p inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,t .]"
        then have "p inHIDDENR3 [.XXREAL-1K2 r,s .[ or p inHIDDENR3 [.XXREAL-1K1 s,t .]"
          using xboole_0_def_3 sorry
        then have A3: "r <=XXREAL-0R1 p & p <XXREAL-0R3 s or s <=XXREAL-0R1 p & p <=XXREAL-0R1 t"
          using xxreal_1_th_1 xxreal_1_th_3 sorry
        then have A4: "r <=XXREAL-0R1 p"
          using A1 xxreal_0_th_2 sorry
        have "p <=XXREAL-0R1 t"
          using A2 A3 xxreal_0_th_2 sorry
        thus "p inHIDDENR3 [.XXREAL-1K1 r,t .]"
          using A4 xxreal_1_th_1 sorry
      qed
      assume "p inHIDDENR3 [.XXREAL-1K1 r,t .]"
      then have "r <=XXREAL-0R1 p & p <XXREAL-0R3 s or s <=XXREAL-0R1 p & p <=XXREAL-0R1 t"
        using xxreal_1_th_1 sorry
      then have "p inHIDDENR3 [.XXREAL-1K2 r,s .[ or p inHIDDENR3 [.XXREAL-1K1 s,t .]"
        using xxreal_1_th_1 xxreal_1_th_3 sorry
      thus "p inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,t .]"
        using xboole_0_def_3 sorry
    qed "sorry"
    thus "[.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,t .] =MEMBEREDR8 [.XXREAL-1K1 r,t .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_167:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & s <=XXREAL-0R1 t implies [.XXREAL-1K1 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .] =MEMBEREDR8 [.XXREAL-1K1 r,t .]"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & s <=XXREAL-0R1 t implies [.XXREAL-1K1 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .] =MEMBEREDR8 [.XXREAL-1K1 r,t .]"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
      and A2: "s <=XXREAL-0R1 t"
    have " for p be ExtRealXXREAL-0M1 holds (p inHIDDENR3 [.XXREAL-1K1 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .] implies p inHIDDENR3 [.XXREAL-1K1 r,t .]) & (p inHIDDENR3 [.XXREAL-1K1 r,t .] implies p inHIDDENR3 [.XXREAL-1K1 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .])"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      show "p inHIDDENR3 [.XXREAL-1K1 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .] implies p inHIDDENR3 [.XXREAL-1K1 r,t .]"
      proof(rule impI)
        assume "p inHIDDENR3 [.XXREAL-1K1 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .]"
        then have "p inHIDDENR3 [.XXREAL-1K1 r,s .] or p inHIDDENR3 ].XXREAL-1K3 s,t .]"
          using xboole_0_def_3 sorry
        then have A3: "r <=XXREAL-0R1 p & p <=XXREAL-0R1 s or s <XXREAL-0R3 p & p <=XXREAL-0R1 t"
          using xxreal_1_th_1 xxreal_1_th_2 sorry
        then have A4: "r <=XXREAL-0R1 p"
          using A1 xxreal_0_th_2 sorry
        have "p <=XXREAL-0R1 t"
          using A2 A3 xxreal_0_th_2 sorry
        thus "p inHIDDENR3 [.XXREAL-1K1 r,t .]"
          using A4 xxreal_1_th_1 sorry
      qed
      assume "p inHIDDENR3 [.XXREAL-1K1 r,t .]"
      then have "r <=XXREAL-0R1 p & p <=XXREAL-0R1 s or s <XXREAL-0R3 p & p <=XXREAL-0R1 t"
        using xxreal_1_th_1 sorry
      then have "p inHIDDENR3 [.XXREAL-1K1 r,s .] or p inHIDDENR3 ].XXREAL-1K3 s,t .]"
        using xxreal_1_th_1 xxreal_1_th_2 sorry
      thus "p inHIDDENR3 [.XXREAL-1K1 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .]"
        using xboole_0_def_3 sorry
    qed "sorry"
    thus "[.XXREAL-1K1 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .] =MEMBEREDR8 [.XXREAL-1K1 r,t .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_168:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & s <=XXREAL-0R1 t implies [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .[ =MEMBEREDR8 [.XXREAL-1K2 r,t .["
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & s <=XXREAL-0R1 t implies [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .[ =MEMBEREDR8 [.XXREAL-1K2 r,t .["
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
      and A2: "s <=XXREAL-0R1 t"
    have " for p be ExtRealXXREAL-0M1 holds (p inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .[ implies p inHIDDENR3 [.XXREAL-1K2 r,t .[) & (p inHIDDENR3 [.XXREAL-1K2 r,t .[ implies p inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .[)"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      show "p inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .[ implies p inHIDDENR3 [.XXREAL-1K2 r,t .["
      proof(rule impI)
        assume "p inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .["
        then have "p inHIDDENR3 [.XXREAL-1K2 r,s .[ or p inHIDDENR3 [.XXREAL-1K2 s,t .["
          using xboole_0_def_3 sorry
        then have A3: "r <=XXREAL-0R1 p & p <XXREAL-0R3 s or s <=XXREAL-0R1 p & p <XXREAL-0R3 t"
          using xxreal_1_th_3 sorry
        then have A4: "r <=XXREAL-0R1 p"
          using A1 xxreal_0_th_2 sorry
        have "p <XXREAL-0R3 t"
          using A2 A3 xxreal_0_th_2 sorry
        thus "p inHIDDENR3 [.XXREAL-1K2 r,t .["
          using A4 xxreal_1_th_3 sorry
      qed
      assume "p inHIDDENR3 [.XXREAL-1K2 r,t .["
      then have "r <=XXREAL-0R1 p & p <XXREAL-0R3 s or s <=XXREAL-0R1 p & p <XXREAL-0R3 t"
        using xxreal_1_th_3 sorry
      then have "p inHIDDENR3 [.XXREAL-1K2 r,s .[ or p inHIDDENR3 [.XXREAL-1K2 s,t .["
        using xxreal_1_th_3 sorry
      thus "p inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .["
        using xboole_0_def_3 sorry
    qed "sorry"
    thus "[.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .[ =MEMBEREDR8 [.XXREAL-1K2 r,t .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_169:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & s <XXREAL-0R3 t implies [.XXREAL-1K1 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .[ =MEMBEREDR8 [.XXREAL-1K2 r,t .["
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & s <XXREAL-0R3 t implies [.XXREAL-1K1 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .[ =MEMBEREDR8 [.XXREAL-1K2 r,t .["
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
      and A2: "s <XXREAL-0R3 t"
    have " for p be ExtRealXXREAL-0M1 holds (p inHIDDENR3 [.XXREAL-1K1 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .[ implies p inHIDDENR3 [.XXREAL-1K2 r,t .[) & (p inHIDDENR3 [.XXREAL-1K2 r,t .[ implies p inHIDDENR3 [.XXREAL-1K1 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .[)"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      show "p inHIDDENR3 [.XXREAL-1K1 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .[ implies p inHIDDENR3 [.XXREAL-1K2 r,t .["
      proof(rule impI)
        assume "p inHIDDENR3 [.XXREAL-1K1 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .["
        then have "p inHIDDENR3 [.XXREAL-1K1 r,s .] or p inHIDDENR3 ].XXREAL-1K4 s,t .["
          using xboole_0_def_3 sorry
        then have A3: "r <=XXREAL-0R1 p & p <=XXREAL-0R1 s or s <XXREAL-0R3 p & p <XXREAL-0R3 t"
          using xxreal_1_th_1 xxreal_1_th_4 sorry
        then have A4: "r <=XXREAL-0R1 p"
          using A1 xxreal_0_th_2 sorry
        have "p <XXREAL-0R3 t"
          using A2 A3 xxreal_0_th_2 sorry
        thus "p inHIDDENR3 [.XXREAL-1K2 r,t .["
          using A4 xxreal_1_th_3 sorry
      qed
      assume "p inHIDDENR3 [.XXREAL-1K2 r,t .["
      then have "r <=XXREAL-0R1 p & p <=XXREAL-0R1 s or s <XXREAL-0R3 p & p <XXREAL-0R3 t"
        using xxreal_1_th_3 sorry
      then have "p inHIDDENR3 [.XXREAL-1K1 r,s .] or p inHIDDENR3 ].XXREAL-1K4 s,t .["
        using xxreal_1_th_1 xxreal_1_th_4 sorry
      thus "p inHIDDENR3 [.XXREAL-1K1 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .["
        using xboole_0_def_3 sorry
    qed "sorry"
    thus "[.XXREAL-1K1 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .[ =MEMBEREDR8 [.XXREAL-1K2 r,t .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_170:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & s <=XXREAL-0R1 t implies ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .] =MEMBEREDR8 ].XXREAL-1K3 r,t .]"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & s <=XXREAL-0R1 t implies ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .] =MEMBEREDR8 ].XXREAL-1K3 r,t .]"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
      and A2: "s <=XXREAL-0R1 t"
    have " for p be ExtRealXXREAL-0M1 holds (p inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .] implies p inHIDDENR3 ].XXREAL-1K3 r,t .]) & (p inHIDDENR3 ].XXREAL-1K3 r,t .] implies p inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .])"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      show "p inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .] implies p inHIDDENR3 ].XXREAL-1K3 r,t .]"
      proof(rule impI)
        assume "p inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .]"
        then have "p inHIDDENR3 ].XXREAL-1K3 r,s .] or p inHIDDENR3 ].XXREAL-1K3 s,t .]"
          using xboole_0_def_3 sorry
        then have A3: "r <XXREAL-0R3 p & p <=XXREAL-0R1 s or s <XXREAL-0R3 p & p <=XXREAL-0R1 t"
          using xxreal_1_th_2 sorry
        then have A4: "r <XXREAL-0R3 p"
          using A1 xxreal_0_th_2 sorry
        have "p <=XXREAL-0R1 t"
          using A2 A3 xxreal_0_th_2 sorry
        thus "p inHIDDENR3 ].XXREAL-1K3 r,t .]"
          using A4 xxreal_1_th_2 sorry
      qed
      assume "p inHIDDENR3 ].XXREAL-1K3 r,t .]"
      then have "r <XXREAL-0R3 p & p <=XXREAL-0R1 s or s <XXREAL-0R3 p & p <=XXREAL-0R1 t"
        using xxreal_1_th_2 sorry
      then have "p inHIDDENR3 ].XXREAL-1K3 r,s .] or p inHIDDENR3 ].XXREAL-1K3 s,t .]"
        using xxreal_1_th_2 sorry
      thus "p inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .]"
        using xboole_0_def_3 sorry
    qed "sorry"
    thus "].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .] =MEMBEREDR8 ].XXREAL-1K3 r,t .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_171:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & s <XXREAL-0R3 t implies ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .[ =MEMBEREDR8 ].XXREAL-1K4 r,t .["
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & s <XXREAL-0R3 t implies ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .[ =MEMBEREDR8 ].XXREAL-1K4 r,t .["
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
      and A2: "s <XXREAL-0R3 t"
    have " for p be ExtRealXXREAL-0M1 holds (p inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .[ implies p inHIDDENR3 ].XXREAL-1K4 r,t .[) & (p inHIDDENR3 ].XXREAL-1K4 r,t .[ implies p inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .[)"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      show "p inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .[ implies p inHIDDENR3 ].XXREAL-1K4 r,t .["
      proof(rule impI)
        assume "p inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .["
        then have "p inHIDDENR3 ].XXREAL-1K3 r,s .] or p inHIDDENR3 ].XXREAL-1K4 s,t .["
          using xboole_0_def_3 sorry
        then have A3: "r <XXREAL-0R3 p & p <=XXREAL-0R1 s or s <XXREAL-0R3 p & p <XXREAL-0R3 t"
          using xxreal_1_th_2 xxreal_1_th_4 sorry
        then have A4: "r <XXREAL-0R3 p"
          using A1 xxreal_0_th_2 sorry
        have "p <XXREAL-0R3 t"
          using A2 A3 xxreal_0_th_2 sorry
        thus "p inHIDDENR3 ].XXREAL-1K4 r,t .["
          using A4 xxreal_1_th_4 sorry
      qed
      assume "p inHIDDENR3 ].XXREAL-1K4 r,t .["
      then have "r <XXREAL-0R3 p & p <=XXREAL-0R1 s or s <XXREAL-0R3 p & p <XXREAL-0R3 t"
        using xxreal_1_th_4 sorry
      then have "p inHIDDENR3 ].XXREAL-1K3 r,s .] or p inHIDDENR3 ].XXREAL-1K4 s,t .["
        using xxreal_1_th_2 xxreal_1_th_4 sorry
      thus "p inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .["
        using xboole_0_def_3 sorry
    qed "sorry"
    thus "].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .[ =MEMBEREDR8 ].XXREAL-1K4 r,t .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_172:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & s <XXREAL-0R3 t implies ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .[ =MEMBEREDR8 ].XXREAL-1K4 r,t .["
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & s <XXREAL-0R3 t implies ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .[ =MEMBEREDR8 ].XXREAL-1K4 r,t .["
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "s <XXREAL-0R3 t"
    have " for p be ExtRealXXREAL-0M1 holds (p inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .[ implies p inHIDDENR3 ].XXREAL-1K4 r,t .[) & (p inHIDDENR3 ].XXREAL-1K4 r,t .[ implies p inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .[)"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      show "p inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .[ implies p inHIDDENR3 ].XXREAL-1K4 r,t .["
      proof(rule impI)
        assume "p inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .["
        then have "p inHIDDENR3 ].XXREAL-1K3 r,s .] or p inHIDDENR3 [.XXREAL-1K2 s,t .["
          using xboole_0_def_3 sorry
        then have A3: "r <XXREAL-0R3 p & p <=XXREAL-0R1 s or s <=XXREAL-0R1 p & p <XXREAL-0R3 t"
          using xxreal_1_th_2 xxreal_1_th_3 sorry
        then have A4: "r <XXREAL-0R3 p"
          using A1 xxreal_0_th_2 sorry
        have "p <XXREAL-0R3 t"
          using A2 A3 xxreal_0_th_2 sorry
        thus "p inHIDDENR3 ].XXREAL-1K4 r,t .["
          using A4 xxreal_1_th_4 sorry
      qed
      assume "p inHIDDENR3 ].XXREAL-1K4 r,t .["
      then have "r <XXREAL-0R3 p & p <=XXREAL-0R1 s or s <XXREAL-0R3 p & p <XXREAL-0R3 t"
        using xxreal_1_th_4 sorry
      then have "p inHIDDENR3 ].XXREAL-1K3 r,s .] or p inHIDDENR3 [.XXREAL-1K2 s,t .["
        using xxreal_1_th_2 xxreal_1_th_3 sorry
      thus "p inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .["
        using xboole_0_def_3 sorry
    qed "sorry"
    thus "].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .[ =MEMBEREDR8 ].XXREAL-1K4 r,t .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_173:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & s <XXREAL-0R3 t implies ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .[ =MEMBEREDR8 ].XXREAL-1K4 r,t .["
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & s <XXREAL-0R3 t implies ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .[ =MEMBEREDR8 ].XXREAL-1K4 r,t .["
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "s <XXREAL-0R3 t"
    have " for p be ExtRealXXREAL-0M1 holds (p inHIDDENR3 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .[ implies p inHIDDENR3 ].XXREAL-1K4 r,t .[) & (p inHIDDENR3 ].XXREAL-1K4 r,t .[ implies p inHIDDENR3 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .[)"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      show "p inHIDDENR3 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .[ implies p inHIDDENR3 ].XXREAL-1K4 r,t .["
      proof(rule impI)
        assume "p inHIDDENR3 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .["
        then have "p inHIDDENR3 ].XXREAL-1K4 r,s .[ or p inHIDDENR3 [.XXREAL-1K2 s,t .["
          using xboole_0_def_3 sorry
        then have A3: "r <XXREAL-0R3 p & p <XXREAL-0R3 s or s <=XXREAL-0R1 p & p <XXREAL-0R3 t"
          using xxreal_1_th_3 xxreal_1_th_4 sorry
        then have A4: "r <XXREAL-0R3 p"
          using A1 xxreal_0_th_2 sorry
        have "p <XXREAL-0R3 t"
          using A2 A3 xxreal_0_th_2 sorry
        thus "p inHIDDENR3 ].XXREAL-1K4 r,t .["
          using A4 xxreal_1_th_4 sorry
      qed
      assume "p inHIDDENR3 ].XXREAL-1K4 r,t .["
      then have "r <XXREAL-0R3 p & p <XXREAL-0R3 s or s <=XXREAL-0R1 p & p <XXREAL-0R3 t"
        using xxreal_1_th_4 sorry
      then have "p inHIDDENR3 ].XXREAL-1K4 r,s .[ or p inHIDDENR3 [.XXREAL-1K2 s,t .["
        using xxreal_1_th_3 xxreal_1_th_4 sorry
      thus "p inHIDDENR3 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .["
        using xboole_0_def_3 sorry
    qed "sorry"
    thus "].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .[ =MEMBEREDR8 ].XXREAL-1K4 r,t .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_174:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds (p <=XXREAL-0R1 s & r <=XXREAL-0R1 q) & s <=XXREAL-0R1 r implies [.XXREAL-1K1 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .] =MEMBEREDR8 [.XXREAL-1K1 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 s & (r <=XXREAL-0R1 q & s <=XXREAL-0R1 r) implies [.XXREAL-1K1 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .] =MEMBEREDR8 [.XXREAL-1K1 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "p <=XXREAL-0R1 s"
      and A2: "r <=XXREAL-0R1 q"
      and A3: "s <=XXREAL-0R1 r"
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 [.XXREAL-1K1 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .] implies t inHIDDENR3 [.XXREAL-1K1 p,q .]) & (t inHIDDENR3 [.XXREAL-1K1 p,q .] implies t inHIDDENR3 [.XXREAL-1K1 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .])"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 [.XXREAL-1K1 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .] implies t inHIDDENR3 [.XXREAL-1K1 p,q .]"
      proof(rule impI)
        assume "t inHIDDENR3 [.XXREAL-1K1 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
        then have "t inHIDDENR3 [.XXREAL-1K1 p,r .] or t inHIDDENR3 [.XXREAL-1K1 s,q .]"
          using xboole_0_def_3 sorry
        then have A4: "p <=XXREAL-0R1 t & t <=XXREAL-0R1 r or s <=XXREAL-0R1 t & t <=XXREAL-0R1 q"
          using xxreal_1_th_1 sorry
        then have A5: "p <=XXREAL-0R1 t"
          using A1 xxreal_0_th_2 sorry
        have "t <=XXREAL-0R1 q"
          using A2 A4 xxreal_0_th_2 sorry
        thus "t inHIDDENR3 [.XXREAL-1K1 p,q .]"
          using A5 xxreal_1_th_1 sorry
      qed
      assume "t inHIDDENR3 [.XXREAL-1K1 p,q .]"
      then have "p <=XXREAL-0R1 t & t <=XXREAL-0R1 r or s <=XXREAL-0R1 t & t <=XXREAL-0R1 q"
        using A3 xxreal_1_th_1 xxreal_0_th_2 sorry
      then have "t inHIDDENR3 [.XXREAL-1K1 p,r .] or t inHIDDENR3 [.XXREAL-1K1 s,q .]"
        using xxreal_1_th_1 sorry
      thus "t inHIDDENR3 [.XXREAL-1K1 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
        using xboole_0_def_3 sorry
    qed "sorry"
    thus "[.XXREAL-1K1 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .] =MEMBEREDR8 [.XXREAL-1K1 p,q .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_175:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds (p <=XXREAL-0R1 s & r <=XXREAL-0R1 q) & s <XXREAL-0R3 r implies [.XXREAL-1K2 p,r .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .] =MEMBEREDR8 [.XXREAL-1K1 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 s & (r <=XXREAL-0R1 q & s <XXREAL-0R3 r) implies [.XXREAL-1K2 p,r .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .] =MEMBEREDR8 [.XXREAL-1K1 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "p <=XXREAL-0R1 s"
      and A2: "r <=XXREAL-0R1 q"
      and A3: "s <XXREAL-0R3 r"
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 [.XXREAL-1K2 p,r .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .] implies t inHIDDENR3 [.XXREAL-1K1 p,q .]) & (t inHIDDENR3 [.XXREAL-1K1 p,q .] implies t inHIDDENR3 [.XXREAL-1K2 p,r .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .])"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 [.XXREAL-1K2 p,r .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .] implies t inHIDDENR3 [.XXREAL-1K1 p,q .]"
      proof(rule impI)
        assume "t inHIDDENR3 [.XXREAL-1K2 p,r .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
        then have "t inHIDDENR3 [.XXREAL-1K2 p,r .[ or t inHIDDENR3 ].XXREAL-1K3 s,q .]"
          using xboole_0_def_3 sorry
        then have A4: "p <=XXREAL-0R1 t & t <=XXREAL-0R1 r or s <=XXREAL-0R1 t & t <=XXREAL-0R1 q"
          using xxreal_1_th_2 xxreal_1_th_3 sorry
        then have A5: "p <=XXREAL-0R1 t"
          using A1 xxreal_0_th_2 sorry
        have "t <=XXREAL-0R1 q"
          using A2 A4 xxreal_0_th_2 sorry
        thus "t inHIDDENR3 [.XXREAL-1K1 p,q .]"
          using A5 xxreal_1_th_1 sorry
      qed
      assume "t inHIDDENR3 [.XXREAL-1K1 p,q .]"
      then have "p <=XXREAL-0R1 t & t <XXREAL-0R3 r or s <XXREAL-0R3 t & t <=XXREAL-0R1 q"
        using A3 xxreal_1_th_1 xxreal_0_th_2 sorry
      then have "t inHIDDENR3 [.XXREAL-1K2 p,r .[ or t inHIDDENR3 ].XXREAL-1K3 s,q .]"
        using xxreal_1_th_2 xxreal_1_th_3 sorry
      thus "t inHIDDENR3 [.XXREAL-1K2 p,r .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
        using xboole_0_def_3 sorry
    qed "sorry"
    thus "[.XXREAL-1K2 p,r .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .] =MEMBEREDR8 [.XXREAL-1K1 p,q .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_176:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds (p <=XXREAL-0R1 s & s <=XXREAL-0R1 r) & r <XXREAL-0R3 q implies [.XXREAL-1K1 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[ =MEMBEREDR8 [.XXREAL-1K2 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 s & (s <=XXREAL-0R1 r & r <XXREAL-0R3 q) implies [.XXREAL-1K1 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[ =MEMBEREDR8 [.XXREAL-1K2 p,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "p <=XXREAL-0R1 s"
      and A2: "s <=XXREAL-0R1 r"
      and A3: "r <XXREAL-0R3 q"
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 [.XXREAL-1K1 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[ implies t inHIDDENR3 [.XXREAL-1K2 p,q .[) & (t inHIDDENR3 [.XXREAL-1K2 p,q .[ implies t inHIDDENR3 [.XXREAL-1K1 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[)"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 [.XXREAL-1K1 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[ implies t inHIDDENR3 [.XXREAL-1K2 p,q .["
      proof(rule impI)
        assume "t inHIDDENR3 [.XXREAL-1K1 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
        then have "t inHIDDENR3 [.XXREAL-1K1 p,r .] or t inHIDDENR3 [.XXREAL-1K2 s,q .["
          using xboole_0_def_3 sorry
        then have A4: "p <=XXREAL-0R1 t & t <=XXREAL-0R1 r or s <=XXREAL-0R1 t & t <XXREAL-0R3 q"
          using xxreal_1_th_1 xxreal_1_th_3 sorry
        then have A5: "p <=XXREAL-0R1 t"
          using A1 xxreal_0_th_2 sorry
        have "t <XXREAL-0R3 q"
          using A3 A4 xxreal_0_th_2 sorry
        thus "t inHIDDENR3 [.XXREAL-1K2 p,q .["
          using A5 xxreal_1_th_3 sorry
      qed
      assume "t inHIDDENR3 [.XXREAL-1K2 p,q .["
      then have "p <=XXREAL-0R1 t & t <=XXREAL-0R1 r or s <=XXREAL-0R1 t & t <XXREAL-0R3 q"
        using A2 xxreal_1_th_3 xxreal_0_th_2 sorry
      then have "t inHIDDENR3 [.XXREAL-1K1 p,r .] or t inHIDDENR3 [.XXREAL-1K2 s,q .["
        using xxreal_1_th_1 xxreal_1_th_3 sorry
      thus "t inHIDDENR3 [.XXREAL-1K1 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
        using xboole_0_def_3 sorry
    qed "sorry"
    thus "[.XXREAL-1K1 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[ =MEMBEREDR8 [.XXREAL-1K2 p,q .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_177:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds (p <XXREAL-0R3 s & r <=XXREAL-0R1 q) & s <=XXREAL-0R1 r implies ].XXREAL-1K3 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .] =MEMBEREDR8 ].XXREAL-1K3 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <XXREAL-0R3 s & (r <=XXREAL-0R1 q & s <=XXREAL-0R1 r) implies ].XXREAL-1K3 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .] =MEMBEREDR8 ].XXREAL-1K3 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "p <XXREAL-0R3 s"
      and A2: "r <=XXREAL-0R1 q"
      and A3: "s <=XXREAL-0R1 r"
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 ].XXREAL-1K3 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .] implies t inHIDDENR3 ].XXREAL-1K3 p,q .]) & (t inHIDDENR3 ].XXREAL-1K3 p,q .] implies t inHIDDENR3 ].XXREAL-1K3 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .])"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 ].XXREAL-1K3 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .] implies t inHIDDENR3 ].XXREAL-1K3 p,q .]"
      proof(rule impI)
        assume "t inHIDDENR3 ].XXREAL-1K3 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
        then have "t inHIDDENR3 ].XXREAL-1K3 p,r .] or t inHIDDENR3 [.XXREAL-1K1 s,q .]"
          using xboole_0_def_3 sorry
        then have A4: "p <XXREAL-0R3 t & t <=XXREAL-0R1 r or s <=XXREAL-0R1 t & t <=XXREAL-0R1 q"
          using xxreal_1_th_1 xxreal_1_th_2 sorry
        then have A5: "p <XXREAL-0R3 t"
          using A1 xxreal_0_th_2 sorry
        have "t <=XXREAL-0R1 q"
          using A2 A4 xxreal_0_th_2 sorry
        thus "t inHIDDENR3 ].XXREAL-1K3 p,q .]"
          using A5 xxreal_1_th_2 sorry
      qed
      assume "t inHIDDENR3 ].XXREAL-1K3 p,q .]"
      then have "p <XXREAL-0R3 t & t <=XXREAL-0R1 r or s <=XXREAL-0R1 t & t <=XXREAL-0R1 q"
        using A3 xxreal_1_th_2 xxreal_0_th_2 sorry
      then have "t inHIDDENR3 ].XXREAL-1K3 p,r .] or t inHIDDENR3 [.XXREAL-1K1 s,q .]"
        using xxreal_1_th_1 xxreal_1_th_2 sorry
      thus "t inHIDDENR3 ].XXREAL-1K3 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
        using xboole_0_def_3 sorry
    qed "sorry"
    thus "].XXREAL-1K3 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .] =MEMBEREDR8 ].XXREAL-1K3 p,q .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_178:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds (p <XXREAL-0R3 s & r <XXREAL-0R3 q) & s <=XXREAL-0R1 r implies ].XXREAL-1K3 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[ =MEMBEREDR8 ].XXREAL-1K4 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <XXREAL-0R3 s & (r <XXREAL-0R3 q & s <=XXREAL-0R1 r) implies ].XXREAL-1K3 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[ =MEMBEREDR8 ].XXREAL-1K4 p,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "p <XXREAL-0R3 s"
      and A2: "r <XXREAL-0R3 q"
      and A3: "s <=XXREAL-0R1 r"
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 ].XXREAL-1K3 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[ implies t inHIDDENR3 ].XXREAL-1K4 p,q .[) & (t inHIDDENR3 ].XXREAL-1K4 p,q .[ implies t inHIDDENR3 ].XXREAL-1K3 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[)"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 ].XXREAL-1K3 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[ implies t inHIDDENR3 ].XXREAL-1K4 p,q .["
      proof(rule impI)
        assume "t inHIDDENR3 ].XXREAL-1K3 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
        then have "t inHIDDENR3 ].XXREAL-1K3 p,r .] or t inHIDDENR3 [.XXREAL-1K2 s,q .["
          using xboole_0_def_3 sorry
        then have A4: "p <XXREAL-0R3 t & t <=XXREAL-0R1 r or s <=XXREAL-0R1 t & t <XXREAL-0R3 q"
          using xxreal_1_th_2 xxreal_1_th_3 sorry
        then have A5: "p <XXREAL-0R3 t"
          using A1 xxreal_0_th_2 sorry
        have "t <XXREAL-0R3 q"
          using A2 A4 xxreal_0_th_2 sorry
        thus "t inHIDDENR3 ].XXREAL-1K4 p,q .["
          using A5 xxreal_1_th_4 sorry
      qed
      assume "t inHIDDENR3 ].XXREAL-1K4 p,q .["
      then have "p <XXREAL-0R3 t & t <=XXREAL-0R1 r or s <=XXREAL-0R1 t & t <XXREAL-0R3 q"
        using A3 xxreal_1_th_4 xxreal_0_th_2 sorry
      then have "t inHIDDENR3 ].XXREAL-1K3 p,r .] or t inHIDDENR3 [.XXREAL-1K2 s,q .["
        using xxreal_1_th_2 xxreal_1_th_3 sorry
      thus "t inHIDDENR3 ].XXREAL-1K3 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
        using xboole_0_def_3 sorry
    qed "sorry"
    thus "].XXREAL-1K3 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[ =MEMBEREDR8 ].XXREAL-1K4 p,q .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_179:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds ((p <=XXREAL-0R1 r & p <=XXREAL-0R1 s) & r <=XXREAL-0R1 q) & s <=XXREAL-0R1 q implies ([.XXREAL-1K2 p,r .[ \\/XBOOLE-0K2 [.XXREAL-1K1 r,s .])\\/XBOOLE-0K2 ].XXREAL-1K3 s,q .] =MEMBEREDR8 [.XXREAL-1K1 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r & (p <=XXREAL-0R1 s & (r <=XXREAL-0R1 q & s <=XXREAL-0R1 q)) implies ([.XXREAL-1K2 p,r .[ \\/XBOOLE-0K2 [.XXREAL-1K1 r,s .])\\/XBOOLE-0K2 ].XXREAL-1K3 s,q .] =HIDDENR1 [.XXREAL-1K1 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "p <=XXREAL-0R1 r"
      and A2: "p <=XXREAL-0R1 s"
      and A3: "r <=XXREAL-0R1 q"
      and A4: "s <=XXREAL-0R1 q"
    show "([.XXREAL-1K2 p,r .[ \\/XBOOLE-0K2 [.XXREAL-1K1 r,s .])\\/XBOOLE-0K2 ].XXREAL-1K3 s,q .] =HIDDENR1 [.XXREAL-1K1 p,q .]"
    proof-
      have cases: "r <=XXREAL-0R1 s or s <XXREAL-0R3 r"
         sorry
      have case1: "r <=XXREAL-0R1 s implies ([.XXREAL-1K2 p,r .[ \\/XBOOLE-0K2 [.XXREAL-1K1 r,s .])\\/XBOOLE-0K2 ].XXREAL-1K3 s,q .] =HIDDENR1 [.XXREAL-1K1 p,q .]"
      proof(rule impI)
        assume "r <=XXREAL-0R1 s"
        then have "([.XXREAL-1K2 p,r .[ \\/XBOOLE-0K2 [.XXREAL-1K1 r,s .])\\/XBOOLE-0K2 ].XXREAL-1K3 s,q .] =HIDDENR1 [.XXREAL-1K1 p,s .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
          using A1 xxreal_1_th_166 sorry
        also have "... = [.XXREAL-1K1 p,q .]"
          using A2 A4 xxreal_1_th_167 sorry
        finally show "([.XXREAL-1K2 p,r .[ \\/XBOOLE-0K2 [.XXREAL-1K1 r,s .])\\/XBOOLE-0K2 ].XXREAL-1K3 s,q .] =HIDDENR1 [.XXREAL-1K1 p,q .]"
           sorry
      qed
      have case2: "s <XXREAL-0R3 r implies ([.XXREAL-1K2 p,r .[ \\/XBOOLE-0K2 [.XXREAL-1K1 r,s .])\\/XBOOLE-0K2 ].XXREAL-1K3 s,q .] =HIDDENR1 [.XXREAL-1K1 p,q .]"
      proof(rule impI)
        assume A5: "s <XXREAL-0R3 r"
        then have "([.XXREAL-1K2 p,r .[ \\/XBOOLE-0K2 [.XXREAL-1K1 r,s .])\\/XBOOLE-0K2 ].XXREAL-1K3 s,q .] =HIDDENR1 ([.XXREAL-1K2 p,r .[ \\/XBOOLE-0K2 {}XBOOLE-0K1)\\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
          using xxreal_1_th_29 sorry
        also have "... = [.XXREAL-1K1 p,q .]"
          using A2 A3 A5 xxreal_1_th_175 sorry
        finally show "([.XXREAL-1K2 p,r .[ \\/XBOOLE-0K2 [.XXREAL-1K1 r,s .])\\/XBOOLE-0K2 ].XXREAL-1K3 s,q .] =HIDDENR1 [.XXREAL-1K1 p,q .]"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_180:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds ((p <XXREAL-0R3 r & p <XXREAL-0R3 s) & r <XXREAL-0R3 q) & s <XXREAL-0R3 q implies (].XXREAL-1K3 p,r .] \\/XBOOLE-0K2 ].XXREAL-1K4 r,s .[)\\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[ =MEMBEREDR8 ].XXREAL-1K4 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <XXREAL-0R3 r & (p <XXREAL-0R3 s & (r <XXREAL-0R3 q & s <XXREAL-0R3 q)) implies (].XXREAL-1K3 p,r .] \\/XBOOLE-0K2 ].XXREAL-1K4 r,s .[)\\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[ =HIDDENR1 ].XXREAL-1K4 p,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "p <XXREAL-0R3 r"
      and A2: "p <XXREAL-0R3 s"
      and A3: "r <XXREAL-0R3 q"
      and A4: "s <XXREAL-0R3 q"
    show "(].XXREAL-1K3 p,r .] \\/XBOOLE-0K2 ].XXREAL-1K4 r,s .[)\\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[ =HIDDENR1 ].XXREAL-1K4 p,q .["
    proof-
      have cases: "r <XXREAL-0R3 s or s <=XXREAL-0R1 r"
         sorry
      have case1: "r <XXREAL-0R3 s implies (].XXREAL-1K3 p,r .] \\/XBOOLE-0K2 ].XXREAL-1K4 r,s .[)\\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[ =HIDDENR1 ].XXREAL-1K4 p,q .["
      proof(rule impI)
        assume "r <XXREAL-0R3 s"
        then have "(].XXREAL-1K3 p,r .] \\/XBOOLE-0K2 ].XXREAL-1K4 r,s .[)\\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[ =HIDDENR1 ].XXREAL-1K4 p,s .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
          using A1 xxreal_1_th_171 sorry
        also have "... = ].XXREAL-1K4 p,q .["
          using A2 A4 xxreal_1_th_173 sorry
        finally show "(].XXREAL-1K3 p,r .] \\/XBOOLE-0K2 ].XXREAL-1K4 r,s .[)\\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[ =HIDDENR1 ].XXREAL-1K4 p,q .["
           sorry
      qed
      have case2: "s <=XXREAL-0R1 r implies (].XXREAL-1K3 p,r .] \\/XBOOLE-0K2 ].XXREAL-1K4 r,s .[)\\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[ =HIDDENR1 ].XXREAL-1K4 p,q .["
      proof(rule impI)
        assume A5: "s <=XXREAL-0R1 r"
        then have "(].XXREAL-1K3 p,r .] \\/XBOOLE-0K2 ].XXREAL-1K4 r,s .[)\\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[ =HIDDENR1 (].XXREAL-1K3 p,r .] \\/XBOOLE-0K2 {}XBOOLE-0K1)\\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
          using xxreal_1_th_28 sorry
        also have "... = ].XXREAL-1K4 p,q .["
          using A2 A3 A5 xxreal_1_th_178 sorry
        finally show "(].XXREAL-1K3 p,r .] \\/XBOOLE-0K2 ].XXREAL-1K4 r,s .[)\\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[ =HIDDENR1 ].XXREAL-1K4 p,q .["
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_181:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds (p <=XXREAL-0R1 r & r <=XXREAL-0R1 s) & s <=XXREAL-0R1 q implies ([.XXREAL-1K1 p,r .] \\/XBOOLE-0K2 ].XXREAL-1K4 r,s .[)\\/XBOOLE-0K2 [.XXREAL-1K1 s,q .] =MEMBEREDR8 [.XXREAL-1K1 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r & (r <=XXREAL-0R1 s & s <=XXREAL-0R1 q) implies ([.XXREAL-1K1 p,r .] \\/XBOOLE-0K2 ].XXREAL-1K4 r,s .[)\\/XBOOLE-0K2 [.XXREAL-1K1 s,q .] =HIDDENR1 [.XXREAL-1K1 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "p <=XXREAL-0R1 r"
      and A2: "r <=XXREAL-0R1 s"
      and A3: "s <=XXREAL-0R1 q"
    have A4: "p <=XXREAL-0R1 s"
      using A1 A2 xxreal_0_th_2 sorry
    have A5: "r <=XXREAL-0R1 q"
      using A2 A3 xxreal_0_th_2 sorry
    show "([.XXREAL-1K1 p,r .] \\/XBOOLE-0K2 ].XXREAL-1K4 r,s .[)\\/XBOOLE-0K2 [.XXREAL-1K1 s,q .] =HIDDENR1 [.XXREAL-1K1 p,q .]"
    proof-
      have cases: "r <XXREAL-0R3 s or s <=XXREAL-0R1 r"
         sorry
      have case1: "r <XXREAL-0R3 s implies ([.XXREAL-1K1 p,r .] \\/XBOOLE-0K2 ].XXREAL-1K4 r,s .[)\\/XBOOLE-0K2 [.XXREAL-1K1 s,q .] =HIDDENR1 [.XXREAL-1K1 p,q .]"
      proof(rule impI)
        assume "r <XXREAL-0R3 s"
        then have "([.XXREAL-1K1 p,r .] \\/XBOOLE-0K2 ].XXREAL-1K4 r,s .[)\\/XBOOLE-0K2 [.XXREAL-1K1 s,q .] =HIDDENR1 [.XXREAL-1K2 p,s .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
          using A1 xxreal_1_th_169 sorry
        also have "... = [.XXREAL-1K1 p,q .]"
          using A3 A4 xxreal_1_th_166 sorry
        finally show "([.XXREAL-1K1 p,r .] \\/XBOOLE-0K2 ].XXREAL-1K4 r,s .[)\\/XBOOLE-0K2 [.XXREAL-1K1 s,q .] =HIDDENR1 [.XXREAL-1K1 p,q .]"
           sorry
      qed
      have case2: "s <=XXREAL-0R1 r implies ([.XXREAL-1K1 p,r .] \\/XBOOLE-0K2 ].XXREAL-1K4 r,s .[)\\/XBOOLE-0K2 [.XXREAL-1K1 s,q .] =HIDDENR1 [.XXREAL-1K1 p,q .]"
      proof(rule impI)
        assume A6: "s <=XXREAL-0R1 r"
        then have "([.XXREAL-1K1 p,r .] \\/XBOOLE-0K2 ].XXREAL-1K4 r,s .[)\\/XBOOLE-0K2 [.XXREAL-1K1 s,q .] =HIDDENR1 ([.XXREAL-1K1 p,r .] \\/XBOOLE-0K2 {}XBOOLE-0K1)\\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
          using xxreal_1_th_28 sorry
        also have "... = [.XXREAL-1K1 p,q .]"
          using A4 A5 A6 xxreal_1_th_174 sorry
        finally show "([.XXREAL-1K1 p,r .] \\/XBOOLE-0K2 ].XXREAL-1K4 r,s .[)\\/XBOOLE-0K2 [.XXREAL-1K1 s,q .] =HIDDENR1 [.XXREAL-1K1 p,q .]"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_182:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s implies [.XXREAL-1K1 r,t .] \\SUBSET-1K6 [.XXREAL-1K1 r,s .] =MEMBEREDR8 ].XXREAL-1K3 s,t .]"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s implies [.XXREAL-1K1 r,t .] \\SUBSET-1K6 [.XXREAL-1K1 r,s .] =MEMBEREDR8 ].XXREAL-1K3 s,t .]"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
    have " for p be ExtRealXXREAL-0M1 holds (p inHIDDENR3 [.XXREAL-1K1 r,t .] \\SUBSET-1K6 [.XXREAL-1K1 r,s .] implies p inHIDDENR3 ].XXREAL-1K3 s,t .]) & (p inHIDDENR3 ].XXREAL-1K3 s,t .] implies p inHIDDENR3 [.XXREAL-1K1 r,t .] \\SUBSET-1K6 [.XXREAL-1K1 r,s .])"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      show "p inHIDDENR3 [.XXREAL-1K1 r,t .] \\SUBSET-1K6 [.XXREAL-1K1 r,s .] implies p inHIDDENR3 ].XXREAL-1K3 s,t .]"
      proof(rule impI)
        assume A2: "p inHIDDENR3 [.XXREAL-1K1 r,t .] \\SUBSET-1K6 [.XXREAL-1K1 r,s .]"
        then have A3: " not p inHIDDENR3 [.XXREAL-1K1 r,s .]"
          using xboole_0_def_5 sorry
        have A4: "p <=XXREAL-0R1 t"
          using A2 xxreal_1_th_1 sorry
        have "p <XXREAL-0R3 r or s <XXREAL-0R3 p"
          using A3 xxreal_1_th_1 sorry
        thus "p inHIDDENR3 ].XXREAL-1K3 s,t .]"
          using A2 A4 xxreal_1_th_1 xxreal_1_th_2 sorry
      qed
      assume A5: "p inHIDDENR3 ].XXREAL-1K3 s,t .]"
      then have A6: "s <XXREAL-0R3 p"
        using xxreal_1_th_2 sorry
      then have A7: "r <=XXREAL-0R1 p"
        using A1 xxreal_0_th_2 sorry
      have "p <=XXREAL-0R1 t"
        using A5 xxreal_1_th_2 sorry
      then have A8: "p inHIDDENR3 [.XXREAL-1K1 r,t .]"
        using A7 xxreal_1_th_1 sorry
      have " not p inHIDDENR3 [.XXREAL-1K1 r,s .]"
        using A6 xxreal_1_th_1 sorry
      thus "p inHIDDENR3 [.XXREAL-1K1 r,t .] \\SUBSET-1K6 [.XXREAL-1K1 r,s .]"
        using A8 xboole_0_def_5 sorry
    qed "sorry"
    thus "[.XXREAL-1K1 r,t .] \\SUBSET-1K6 [.XXREAL-1K1 r,s .] =MEMBEREDR8 ].XXREAL-1K3 s,t .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_183:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s implies [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 [.XXREAL-1K1 r,s .] =MEMBEREDR8 ].XXREAL-1K4 s,t .["
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s implies [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 [.XXREAL-1K1 r,s .] =MEMBEREDR8 ].XXREAL-1K4 s,t .["
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
    have " for p be ExtRealXXREAL-0M1 holds (p inHIDDENR3 [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 [.XXREAL-1K1 r,s .] implies p inHIDDENR3 ].XXREAL-1K4 s,t .[) & (p inHIDDENR3 ].XXREAL-1K4 s,t .[ implies p inHIDDENR3 [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 [.XXREAL-1K1 r,s .])"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      show "p inHIDDENR3 [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 [.XXREAL-1K1 r,s .] implies p inHIDDENR3 ].XXREAL-1K4 s,t .["
      proof(rule impI)
        assume A2: "p inHIDDENR3 [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 [.XXREAL-1K1 r,s .]"
        then have A3: " not p inHIDDENR3 [.XXREAL-1K1 r,s .]"
          using xboole_0_def_5 sorry
        have A4: "p <XXREAL-0R3 t"
          using A2 xxreal_1_th_3 sorry
        have "p <XXREAL-0R3 r or s <XXREAL-0R3 p"
          using A3 xxreal_1_th_1 sorry
        thus "p inHIDDENR3 ].XXREAL-1K4 s,t .["
          using A2 A4 xxreal_1_th_3 xxreal_1_th_4 sorry
      qed
      assume A5: "p inHIDDENR3 ].XXREAL-1K4 s,t .["
      then have A6: "s <XXREAL-0R3 p"
        using xxreal_1_th_4 sorry
      then have A7: "r <=XXREAL-0R1 p"
        using A1 xxreal_0_th_2 sorry
      have "p <XXREAL-0R3 t"
        using A5 xxreal_1_th_4 sorry
      then have A8: "p inHIDDENR3 [.XXREAL-1K2 r,t .["
        using A7 xxreal_1_th_3 sorry
      have " not p inHIDDENR3 [.XXREAL-1K1 r,s .]"
        using A6 xxreal_1_th_1 sorry
      thus "p inHIDDENR3 [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 [.XXREAL-1K1 r,s .]"
        using A8 xboole_0_def_5 sorry
    qed "sorry"
    thus "[.XXREAL-1K2 r,t .[ \\SUBSET-1K6 [.XXREAL-1K1 r,s .] =MEMBEREDR8 ].XXREAL-1K4 s,t .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_184:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies [.XXREAL-1K1 r,t .] \\SUBSET-1K6 [.XXREAL-1K2 r,s .[ =MEMBEREDR8 [.XXREAL-1K1 s,t .]"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies [.XXREAL-1K1 r,t .] \\SUBSET-1K6 [.XXREAL-1K2 r,s .[ =MEMBEREDR8 [.XXREAL-1K1 s,t .]"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
    have " for p be ExtRealXXREAL-0M1 holds (p inHIDDENR3 [.XXREAL-1K1 r,t .] \\SUBSET-1K6 [.XXREAL-1K2 r,s .[ implies p inHIDDENR3 [.XXREAL-1K1 s,t .]) & (p inHIDDENR3 [.XXREAL-1K1 s,t .] implies p inHIDDENR3 [.XXREAL-1K1 r,t .] \\SUBSET-1K6 [.XXREAL-1K2 r,s .[)"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      show "p inHIDDENR3 [.XXREAL-1K1 r,t .] \\SUBSET-1K6 [.XXREAL-1K2 r,s .[ implies p inHIDDENR3 [.XXREAL-1K1 s,t .]"
      proof(rule impI)
        assume A2: "p inHIDDENR3 [.XXREAL-1K1 r,t .] \\SUBSET-1K6 [.XXREAL-1K2 r,s .["
        then have A3: " not p inHIDDENR3 [.XXREAL-1K2 r,s .["
          using xboole_0_def_5 sorry
        have A4: "p <=XXREAL-0R1 t"
          using A2 xxreal_1_th_1 sorry
        have "p <XXREAL-0R3 r or s <=XXREAL-0R1 p"
          using A3 xxreal_1_th_3 sorry
        thus "p inHIDDENR3 [.XXREAL-1K1 s,t .]"
          using A2 A4 xxreal_1_th_1 sorry
      qed
      assume A5: "p inHIDDENR3 [.XXREAL-1K1 s,t .]"
      then have A6: "s <=XXREAL-0R1 p"
        using xxreal_1_th_1 sorry
      then have A7: "r <=XXREAL-0R1 p"
        using A1 xxreal_0_th_2 sorry
      have "p <=XXREAL-0R1 t"
        using A5 xxreal_1_th_1 sorry
      then have A8: "p inHIDDENR3 [.XXREAL-1K1 r,t .]"
        using A7 xxreal_1_th_1 sorry
      have " not p inHIDDENR3 [.XXREAL-1K2 r,s .["
        using A6 xxreal_1_th_3 sorry
      thus "p inHIDDENR3 [.XXREAL-1K1 r,t .] \\SUBSET-1K6 [.XXREAL-1K2 r,s .["
        using A8 xboole_0_def_5 sorry
    qed "sorry"
    thus "[.XXREAL-1K1 r,t .] \\SUBSET-1K6 [.XXREAL-1K2 r,s .[ =MEMBEREDR8 [.XXREAL-1K1 s,t .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_185:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 [.XXREAL-1K2 r,s .[ =MEMBEREDR8 [.XXREAL-1K2 s,t .["
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 [.XXREAL-1K2 r,s .[ =MEMBEREDR8 [.XXREAL-1K2 s,t .["
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
    have " for p be ExtRealXXREAL-0M1 holds (p inHIDDENR3 [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 [.XXREAL-1K2 r,s .[ implies p inHIDDENR3 [.XXREAL-1K2 s,t .[) & (p inHIDDENR3 [.XXREAL-1K2 s,t .[ implies p inHIDDENR3 [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 [.XXREAL-1K2 r,s .[)"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      show "p inHIDDENR3 [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 [.XXREAL-1K2 r,s .[ implies p inHIDDENR3 [.XXREAL-1K2 s,t .["
      proof(rule impI)
        assume A2: "p inHIDDENR3 [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 [.XXREAL-1K2 r,s .["
        then have A3: " not p inHIDDENR3 [.XXREAL-1K2 r,s .["
          using xboole_0_def_5 sorry
        have A4: "p <XXREAL-0R3 t"
          using A2 xxreal_1_th_3 sorry
        have "p <XXREAL-0R3 r or s <=XXREAL-0R1 p"
          using A3 xxreal_1_th_3 sorry
        thus "p inHIDDENR3 [.XXREAL-1K2 s,t .["
          using A2 A4 xxreal_1_th_3 sorry
      qed
      assume A5: "p inHIDDENR3 [.XXREAL-1K2 s,t .["
      then have A6: "s <=XXREAL-0R1 p"
        using xxreal_1_th_3 sorry
      then have A7: "r <=XXREAL-0R1 p"
        using A1 xxreal_0_th_2 sorry
      have "p <XXREAL-0R3 t"
        using A5 xxreal_1_th_3 sorry
      then have A8: "p inHIDDENR3 [.XXREAL-1K2 r,t .["
        using A7 xxreal_1_th_3 sorry
      have " not p inHIDDENR3 [.XXREAL-1K2 r,s .["
        using A6 xxreal_1_th_3 sorry
      thus "p inHIDDENR3 [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 [.XXREAL-1K2 r,s .["
        using A8 xboole_0_def_5 sorry
    qed "sorry"
    thus "[.XXREAL-1K2 r,t .[ \\SUBSET-1K6 [.XXREAL-1K2 r,s .[ =MEMBEREDR8 [.XXREAL-1K2 s,t .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_186:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s implies [.XXREAL-1K1 r,t .] \\SUBSET-1K6 [.XXREAL-1K1 r,s .] =MEMBEREDR8 ].XXREAL-1K3 s,t .]"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s implies [.XXREAL-1K1 r,t .] \\SUBSET-1K6 [.XXREAL-1K1 r,s .] =MEMBEREDR8 ].XXREAL-1K3 s,t .]"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
    have " for p be ExtRealXXREAL-0M1 holds (p inHIDDENR3 [.XXREAL-1K1 r,t .] \\SUBSET-1K6 [.XXREAL-1K1 r,s .] implies p inHIDDENR3 ].XXREAL-1K3 s,t .]) & (p inHIDDENR3 ].XXREAL-1K3 s,t .] implies p inHIDDENR3 [.XXREAL-1K1 r,t .] \\SUBSET-1K6 [.XXREAL-1K1 r,s .])"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      show "p inHIDDENR3 [.XXREAL-1K1 r,t .] \\SUBSET-1K6 [.XXREAL-1K1 r,s .] implies p inHIDDENR3 ].XXREAL-1K3 s,t .]"
      proof(rule impI)
        assume A2: "p inHIDDENR3 [.XXREAL-1K1 r,t .] \\SUBSET-1K6 [.XXREAL-1K1 r,s .]"
        then have A3: " not p inHIDDENR3 [.XXREAL-1K1 r,s .]"
          using xboole_0_def_5 sorry
        have A4: "p <=XXREAL-0R1 t"
          using A2 xxreal_1_th_1 sorry
        have "p <XXREAL-0R3 r or s <XXREAL-0R3 p"
          using A3 xxreal_1_th_1 sorry
        thus "p inHIDDENR3 ].XXREAL-1K3 s,t .]"
          using A2 A4 xxreal_1_th_1 xxreal_1_th_2 sorry
      qed
      assume A5: "p inHIDDENR3 ].XXREAL-1K3 s,t .]"
      then have A6: "s <XXREAL-0R3 p"
        using xxreal_1_th_2 sorry
      then have A7: "r <=XXREAL-0R1 p"
        using A1 xxreal_0_th_2 sorry
      have "p <=XXREAL-0R1 t"
        using A5 xxreal_1_th_2 sorry
      then have A8: "p inHIDDENR3 [.XXREAL-1K1 r,t .]"
        using A7 xxreal_1_th_1 sorry
      have " not p inHIDDENR3 [.XXREAL-1K1 r,s .]"
        using A6 xxreal_1_th_1 sorry
      thus "p inHIDDENR3 [.XXREAL-1K1 r,t .] \\SUBSET-1K6 [.XXREAL-1K1 r,s .]"
        using A8 xboole_0_def_5 sorry
    qed "sorry"
    thus "[.XXREAL-1K1 r,t .] \\SUBSET-1K6 [.XXREAL-1K1 r,s .] =MEMBEREDR8 ].XXREAL-1K3 s,t .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_187:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 ].XXREAL-1K3 r,s .] =MEMBEREDR8 ].XXREAL-1K4 s,t .["
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 ].XXREAL-1K3 r,s .] =MEMBEREDR8 ].XXREAL-1K4 s,t .["
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
    have " for p be ExtRealXXREAL-0M1 holds (p inHIDDENR3 ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 ].XXREAL-1K3 r,s .] implies p inHIDDENR3 ].XXREAL-1K4 s,t .[) & (p inHIDDENR3 ].XXREAL-1K4 s,t .[ implies p inHIDDENR3 ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 ].XXREAL-1K3 r,s .])"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      show "p inHIDDENR3 ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 ].XXREAL-1K3 r,s .] implies p inHIDDENR3 ].XXREAL-1K4 s,t .["
      proof(rule impI)
        assume A2: "p inHIDDENR3 ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 ].XXREAL-1K3 r,s .]"
        then have A3: " not p inHIDDENR3 ].XXREAL-1K3 r,s .]"
          using xboole_0_def_5 sorry
        have A4: "p <XXREAL-0R3 t"
          using A2 xxreal_1_th_4 sorry
        have "p <=XXREAL-0R1 r or s <XXREAL-0R3 p"
          using A3 xxreal_1_th_2 sorry
        thus "p inHIDDENR3 ].XXREAL-1K4 s,t .["
          using A2 A4 xxreal_1_th_4 sorry
      qed
      assume A5: "p inHIDDENR3 ].XXREAL-1K4 s,t .["
      then have A6: "s <XXREAL-0R3 p"
        using xxreal_1_th_4 sorry
      then have A7: "r <XXREAL-0R3 p"
        using A1 xxreal_0_th_2 sorry
      have "p <XXREAL-0R3 t"
        using A5 xxreal_1_th_4 sorry
      then have A8: "p inHIDDENR3 ].XXREAL-1K4 r,t .["
        using A7 xxreal_1_th_4 sorry
      have " not p inHIDDENR3 ].XXREAL-1K3 r,s .]"
        using A6 xxreal_1_th_2 sorry
      thus "p inHIDDENR3 ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 ].XXREAL-1K3 r,s .]"
        using A8 xboole_0_def_5 sorry
    qed "sorry"
    thus "].XXREAL-1K4 r,t .[ \\SUBSET-1K6 ].XXREAL-1K3 r,s .] =MEMBEREDR8 ].XXREAL-1K4 s,t .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_188:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies ].XXREAL-1K3 r,t .] \\SUBSET-1K6 ].XXREAL-1K4 r,s .[ =MEMBEREDR8 [.XXREAL-1K1 s,t .]"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies ].XXREAL-1K3 r,t .] \\SUBSET-1K6 ].XXREAL-1K4 r,s .[ =MEMBEREDR8 [.XXREAL-1K1 s,t .]"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
    have " for p be ExtRealXXREAL-0M1 holds (p inHIDDENR3 ].XXREAL-1K3 r,t .] \\SUBSET-1K6 ].XXREAL-1K4 r,s .[ implies p inHIDDENR3 [.XXREAL-1K1 s,t .]) & (p inHIDDENR3 [.XXREAL-1K1 s,t .] implies p inHIDDENR3 ].XXREAL-1K3 r,t .] \\SUBSET-1K6 ].XXREAL-1K4 r,s .[)"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      show "p inHIDDENR3 ].XXREAL-1K3 r,t .] \\SUBSET-1K6 ].XXREAL-1K4 r,s .[ implies p inHIDDENR3 [.XXREAL-1K1 s,t .]"
      proof(rule impI)
        assume A2: "p inHIDDENR3 ].XXREAL-1K3 r,t .] \\SUBSET-1K6 ].XXREAL-1K4 r,s .["
        then have A3: " not p inHIDDENR3 ].XXREAL-1K4 r,s .["
          using xboole_0_def_5 sorry
        have A4: "p <=XXREAL-0R1 t"
          using A2 xxreal_1_th_2 sorry
        have "p <=XXREAL-0R1 r or s <=XXREAL-0R1 p"
          using A3 xxreal_1_th_4 sorry
        thus "p inHIDDENR3 [.XXREAL-1K1 s,t .]"
          using A2 A4 xxreal_1_th_1 xxreal_1_th_2 sorry
      qed
      assume A5: "p inHIDDENR3 [.XXREAL-1K1 s,t .]"
      then have A6: "s <=XXREAL-0R1 p"
        using xxreal_1_th_1 sorry
      then have A7: "r <XXREAL-0R3 p"
        using A1 xxreal_0_th_2 sorry
      have "p <=XXREAL-0R1 t"
        using A5 xxreal_1_th_1 sorry
      then have A8: "p inHIDDENR3 ].XXREAL-1K3 r,t .]"
        using A7 xxreal_1_th_2 sorry
      have " not p inHIDDENR3 ].XXREAL-1K4 r,s .["
        using A6 xxreal_1_th_4 sorry
      thus "p inHIDDENR3 ].XXREAL-1K3 r,t .] \\SUBSET-1K6 ].XXREAL-1K4 r,s .["
        using A8 xboole_0_def_5 sorry
    qed "sorry"
    thus "].XXREAL-1K3 r,t .] \\SUBSET-1K6 ].XXREAL-1K4 r,s .[ =MEMBEREDR8 [.XXREAL-1K1 s,t .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_189:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 ].XXREAL-1K4 r,s .[ =MEMBEREDR8 [.XXREAL-1K2 s,t .["
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 ].XXREAL-1K4 r,s .[ =MEMBEREDR8 [.XXREAL-1K2 s,t .["
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
    have " for p be ExtRealXXREAL-0M1 holds (p inHIDDENR3 ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 ].XXREAL-1K4 r,s .[ implies p inHIDDENR3 [.XXREAL-1K2 s,t .[) & (p inHIDDENR3 [.XXREAL-1K2 s,t .[ implies p inHIDDENR3 ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 ].XXREAL-1K4 r,s .[)"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      show "p inHIDDENR3 ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 ].XXREAL-1K4 r,s .[ implies p inHIDDENR3 [.XXREAL-1K2 s,t .["
      proof(rule impI)
        assume A2: "p inHIDDENR3 ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 ].XXREAL-1K4 r,s .["
        then have A3: " not p inHIDDENR3 ].XXREAL-1K4 r,s .["
          using xboole_0_def_5 sorry
        have A4: "p <XXREAL-0R3 t"
          using A2 xxreal_1_th_4 sorry
        have "p <=XXREAL-0R1 r or s <=XXREAL-0R1 p"
          using A3 xxreal_1_th_4 sorry
        thus "p inHIDDENR3 [.XXREAL-1K2 s,t .["
          using A2 A4 xxreal_1_th_3 xxreal_1_th_4 sorry
      qed
      assume A5: "p inHIDDENR3 [.XXREAL-1K2 s,t .["
      then have A6: "s <=XXREAL-0R1 p"
        using xxreal_1_th_3 sorry
      then have A7: "r <XXREAL-0R3 p"
        using A1 xxreal_0_th_2 sorry
      have "p <XXREAL-0R3 t"
        using A5 xxreal_1_th_3 sorry
      then have A8: "p inHIDDENR3 ].XXREAL-1K4 r,t .["
        using A7 xxreal_1_th_4 sorry
      have " not p inHIDDENR3 ].XXREAL-1K4 r,s .["
        using A6 xxreal_1_th_4 sorry
      thus "p inHIDDENR3 ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 ].XXREAL-1K4 r,s .["
        using A8 xboole_0_def_5 sorry
    qed "sorry"
    thus "].XXREAL-1K4 r,t .[ \\SUBSET-1K6 ].XXREAL-1K4 r,s .[ =MEMBEREDR8 [.XXREAL-1K2 s,t .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_190:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 t implies [.XXREAL-1K1 r,t .] \\SUBSET-1K6 [.XXREAL-1K1 s,t .] =MEMBEREDR8 [.XXREAL-1K2 r,s .["
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 t implies [.XXREAL-1K1 r,t .] \\SUBSET-1K6 [.XXREAL-1K1 s,t .] =MEMBEREDR8 [.XXREAL-1K2 r,s .["
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "s <=XXREAL-0R1 t"
    have " for p be ExtRealXXREAL-0M1 holds (p inHIDDENR3 [.XXREAL-1K1 r,t .] \\SUBSET-1K6 [.XXREAL-1K1 s,t .] implies p inHIDDENR3 [.XXREAL-1K2 r,s .[) & (p inHIDDENR3 [.XXREAL-1K2 r,s .[ implies p inHIDDENR3 [.XXREAL-1K1 r,t .] \\SUBSET-1K6 [.XXREAL-1K1 s,t .])"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      show "p inHIDDENR3 [.XXREAL-1K1 r,t .] \\SUBSET-1K6 [.XXREAL-1K1 s,t .] implies p inHIDDENR3 [.XXREAL-1K2 r,s .["
      proof(rule impI)
        assume A2: "p inHIDDENR3 [.XXREAL-1K1 r,t .] \\SUBSET-1K6 [.XXREAL-1K1 s,t .]"
        then have A3: " not p inHIDDENR3 [.XXREAL-1K1 s,t .]"
          using xboole_0_def_5 sorry
        have A4: "r <=XXREAL-0R1 p"
          using A2 xxreal_1_th_1 sorry
        have "p <XXREAL-0R3 s or t <XXREAL-0R3 p"
          using A3 xxreal_1_th_1 sorry
        thus "p inHIDDENR3 [.XXREAL-1K2 r,s .["
          using A2 A4 xxreal_1_th_1 xxreal_1_th_3 sorry
      qed
      assume A5: "p inHIDDENR3 [.XXREAL-1K2 r,s .["
      then have A6: "p <XXREAL-0R3 s"
        using xxreal_1_th_3 sorry
      have A7: "r <=XXREAL-0R1 p"
        using A5 xxreal_1_th_3 sorry
      have "p <=XXREAL-0R1 t"
        using A1 A6 xxreal_0_th_2 sorry
      then have A8: "p inHIDDENR3 [.XXREAL-1K1 r,t .]"
        using A7 xxreal_1_th_1 sorry
      have " not p inHIDDENR3 [.XXREAL-1K1 s,t .]"
        using A6 xxreal_1_th_1 sorry
      thus "p inHIDDENR3 [.XXREAL-1K1 r,t .] \\SUBSET-1K6 [.XXREAL-1K1 s,t .]"
        using A8 xboole_0_def_5 sorry
    qed "sorry"
    thus "[.XXREAL-1K1 r,t .] \\SUBSET-1K6 [.XXREAL-1K1 s,t .] =MEMBEREDR8 [.XXREAL-1K2 r,s .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_191:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 t implies ].XXREAL-1K3 r,t .] \\SUBSET-1K6 [.XXREAL-1K1 s,t .] =MEMBEREDR8 ].XXREAL-1K4 r,s .["
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 t implies ].XXREAL-1K3 r,t .] \\SUBSET-1K6 [.XXREAL-1K1 s,t .] =MEMBEREDR8 ].XXREAL-1K4 r,s .["
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "s <=XXREAL-0R1 t"
    have " for p be ExtRealXXREAL-0M1 holds (p inHIDDENR3 ].XXREAL-1K3 r,t .] \\SUBSET-1K6 [.XXREAL-1K1 s,t .] implies p inHIDDENR3 ].XXREAL-1K4 r,s .[) & (p inHIDDENR3 ].XXREAL-1K4 r,s .[ implies p inHIDDENR3 ].XXREAL-1K3 r,t .] \\SUBSET-1K6 [.XXREAL-1K1 s,t .])"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      show "p inHIDDENR3 ].XXREAL-1K3 r,t .] \\SUBSET-1K6 [.XXREAL-1K1 s,t .] implies p inHIDDENR3 ].XXREAL-1K4 r,s .["
      proof(rule impI)
        assume A2: "p inHIDDENR3 ].XXREAL-1K3 r,t .] \\SUBSET-1K6 [.XXREAL-1K1 s,t .]"
        then have A3: " not p inHIDDENR3 [.XXREAL-1K1 s,t .]"
          using xboole_0_def_5 sorry
        have A4: "r <XXREAL-0R3 p"
          using A2 xxreal_1_th_2 sorry
        have "p <XXREAL-0R3 s or t <XXREAL-0R3 p"
          using A3 xxreal_1_th_1 sorry
        thus "p inHIDDENR3 ].XXREAL-1K4 r,s .["
          using A2 A4 xxreal_1_th_2 xxreal_1_th_4 sorry
      qed
      assume A5: "p inHIDDENR3 ].XXREAL-1K4 r,s .["
      then have A6: "p <XXREAL-0R3 s"
        using xxreal_1_th_4 sorry
      have A7: "r <XXREAL-0R3 p"
        using A5 xxreal_1_th_4 sorry
      have "p <=XXREAL-0R1 t"
        using A1 A6 xxreal_0_th_2 sorry
      then have A8: "p inHIDDENR3 ].XXREAL-1K3 r,t .]"
        using A7 xxreal_1_th_2 sorry
      have " not p inHIDDENR3 [.XXREAL-1K1 s,t .]"
        using A6 xxreal_1_th_1 sorry
      thus "p inHIDDENR3 ].XXREAL-1K3 r,t .] \\SUBSET-1K6 [.XXREAL-1K1 s,t .]"
        using A8 xboole_0_def_5 sorry
    qed "sorry"
    thus "].XXREAL-1K3 r,t .] \\SUBSET-1K6 [.XXREAL-1K1 s,t .] =MEMBEREDR8 ].XXREAL-1K4 r,s .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_192:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds s <XXREAL-0R3 t implies [.XXREAL-1K1 r,t .] \\SUBSET-1K6 ].XXREAL-1K3 s,t .] =MEMBEREDR8 [.XXREAL-1K1 r,s .]"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds s <XXREAL-0R3 t implies [.XXREAL-1K1 r,t .] \\SUBSET-1K6 ].XXREAL-1K3 s,t .] =MEMBEREDR8 [.XXREAL-1K1 r,s .]"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "s <XXREAL-0R3 t"
    have " for p be ExtRealXXREAL-0M1 holds (p inHIDDENR3 [.XXREAL-1K1 r,t .] \\SUBSET-1K6 ].XXREAL-1K3 s,t .] implies p inHIDDENR3 [.XXREAL-1K1 r,s .]) & (p inHIDDENR3 [.XXREAL-1K1 r,s .] implies p inHIDDENR3 [.XXREAL-1K1 r,t .] \\SUBSET-1K6 ].XXREAL-1K3 s,t .])"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      show "p inHIDDENR3 [.XXREAL-1K1 r,t .] \\SUBSET-1K6 ].XXREAL-1K3 s,t .] implies p inHIDDENR3 [.XXREAL-1K1 r,s .]"
      proof(rule impI)
        assume A2: "p inHIDDENR3 [.XXREAL-1K1 r,t .] \\SUBSET-1K6 ].XXREAL-1K3 s,t .]"
        then have A3: " not p inHIDDENR3 ].XXREAL-1K3 s,t .]"
          using xboole_0_def_5 sorry
        have A4: "r <=XXREAL-0R1 p"
          using A2 xxreal_1_th_1 sorry
        have "p <=XXREAL-0R1 s or t <XXREAL-0R3 p"
          using A3 xxreal_1_th_2 sorry
        thus "p inHIDDENR3 [.XXREAL-1K1 r,s .]"
          using A2 A4 xxreal_1_th_1 sorry
      qed
      assume A5: "p inHIDDENR3 [.XXREAL-1K1 r,s .]"
      then have A6: "p <=XXREAL-0R1 s"
        using xxreal_1_th_1 sorry
      have A7: "r <=XXREAL-0R1 p"
        using A5 xxreal_1_th_1 sorry
      have "p <=XXREAL-0R1 t"
        using A1 A6 xxreal_0_th_2 sorry
      then have A8: "p inHIDDENR3 [.XXREAL-1K1 r,t .]"
        using A7 xxreal_1_th_1 sorry
      have " not p inHIDDENR3 ].XXREAL-1K3 s,t .]"
        using A6 xxreal_1_th_2 sorry
      thus "p inHIDDENR3 [.XXREAL-1K1 r,t .] \\SUBSET-1K6 ].XXREAL-1K3 s,t .]"
        using A8 xboole_0_def_5 sorry
    qed "sorry"
    thus "[.XXREAL-1K1 r,t .] \\SUBSET-1K6 ].XXREAL-1K3 s,t .] =MEMBEREDR8 [.XXREAL-1K1 r,s .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_193:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds s <XXREAL-0R3 t implies ].XXREAL-1K3 r,t .] \\SUBSET-1K6 ].XXREAL-1K3 s,t .] =MEMBEREDR8 ].XXREAL-1K3 r,s .]"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds s <XXREAL-0R3 t implies ].XXREAL-1K3 r,t .] \\SUBSET-1K6 ].XXREAL-1K3 s,t .] =MEMBEREDR8 ].XXREAL-1K3 r,s .]"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "s <XXREAL-0R3 t"
    have " for p be ExtRealXXREAL-0M1 holds (p inHIDDENR3 ].XXREAL-1K3 r,t .] \\SUBSET-1K6 ].XXREAL-1K3 s,t .] implies p inHIDDENR3 ].XXREAL-1K3 r,s .]) & (p inHIDDENR3 ].XXREAL-1K3 r,s .] implies p inHIDDENR3 ].XXREAL-1K3 r,t .] \\SUBSET-1K6 ].XXREAL-1K3 s,t .])"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      show "p inHIDDENR3 ].XXREAL-1K3 r,t .] \\SUBSET-1K6 ].XXREAL-1K3 s,t .] implies p inHIDDENR3 ].XXREAL-1K3 r,s .]"
      proof(rule impI)
        assume A2: "p inHIDDENR3 ].XXREAL-1K3 r,t .] \\SUBSET-1K6 ].XXREAL-1K3 s,t .]"
        then have A3: " not p inHIDDENR3 ].XXREAL-1K3 s,t .]"
          using xboole_0_def_5 sorry
        have A4: "r <XXREAL-0R3 p"
          using A2 xxreal_1_th_2 sorry
        have "p <=XXREAL-0R1 s or t <XXREAL-0R3 p"
          using A3 xxreal_1_th_2 sorry
        thus "p inHIDDENR3 ].XXREAL-1K3 r,s .]"
          using A2 A4 xxreal_1_th_2 sorry
      qed
      assume A5: "p inHIDDENR3 ].XXREAL-1K3 r,s .]"
      then have A6: "p <=XXREAL-0R1 s"
        using xxreal_1_th_2 sorry
      have A7: "r <XXREAL-0R3 p"
        using A5 xxreal_1_th_2 sorry
      have "p <=XXREAL-0R1 t"
        using A1 A6 xxreal_0_th_2 sorry
      then have A8: "p inHIDDENR3 ].XXREAL-1K3 r,t .]"
        using A7 xxreal_1_th_2 sorry
      have " not p inHIDDENR3 ].XXREAL-1K3 s,t .]"
        using A6 xxreal_1_th_2 sorry
      thus "p inHIDDENR3 ].XXREAL-1K3 r,t .] \\SUBSET-1K6 ].XXREAL-1K3 s,t .]"
        using A8 xboole_0_def_5 sorry
    qed "sorry"
    thus "].XXREAL-1K3 r,t .] \\SUBSET-1K6 ].XXREAL-1K3 s,t .] =MEMBEREDR8 ].XXREAL-1K3 r,s .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_194:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds s <XXREAL-0R3 t implies [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 [.XXREAL-1K2 s,t .[ =MEMBEREDR8 [.XXREAL-1K2 r,s .["
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds s <XXREAL-0R3 t implies [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 [.XXREAL-1K2 s,t .[ =MEMBEREDR8 [.XXREAL-1K2 r,s .["
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "s <XXREAL-0R3 t"
    have " for p be ExtRealXXREAL-0M1 holds (p inHIDDENR3 [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 [.XXREAL-1K2 s,t .[ implies p inHIDDENR3 [.XXREAL-1K2 r,s .[) & (p inHIDDENR3 [.XXREAL-1K2 r,s .[ implies p inHIDDENR3 [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 [.XXREAL-1K2 s,t .[)"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      show "p inHIDDENR3 [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 [.XXREAL-1K2 s,t .[ implies p inHIDDENR3 [.XXREAL-1K2 r,s .["
      proof(rule impI)
        assume A2: "p inHIDDENR3 [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 [.XXREAL-1K2 s,t .["
        then have A3: " not p inHIDDENR3 [.XXREAL-1K2 s,t .["
          using xboole_0_def_5 sorry
        have A4: "r <=XXREAL-0R1 p"
          using A2 xxreal_1_th_3 sorry
        have "p <XXREAL-0R3 s or t <=XXREAL-0R1 p"
          using A3 xxreal_1_th_3 sorry
        thus "p inHIDDENR3 [.XXREAL-1K2 r,s .["
          using A2 A4 xxreal_1_th_3 sorry
      qed
      assume A5: "p inHIDDENR3 [.XXREAL-1K2 r,s .["
      then have A6: "p <XXREAL-0R3 s"
        using xxreal_1_th_3 sorry
      have A7: "r <=XXREAL-0R1 p"
        using A5 xxreal_1_th_3 sorry
      have "p <XXREAL-0R3 t"
        using A1 A6 xxreal_0_th_2 sorry
      then have A8: "p inHIDDENR3 [.XXREAL-1K2 r,t .["
        using A7 xxreal_1_th_3 sorry
      have " not p inHIDDENR3 [.XXREAL-1K2 s,t .["
        using A6 xxreal_1_th_3 sorry
      thus "p inHIDDENR3 [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 [.XXREAL-1K2 s,t .["
        using A8 xboole_0_def_5 sorry
    qed "sorry"
    thus "[.XXREAL-1K2 r,t .[ \\SUBSET-1K6 [.XXREAL-1K2 s,t .[ =MEMBEREDR8 [.XXREAL-1K2 r,s .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_195:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds s <XXREAL-0R3 t implies ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 [.XXREAL-1K2 s,t .[ =MEMBEREDR8 ].XXREAL-1K4 r,s .["
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds s <XXREAL-0R3 t implies ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 [.XXREAL-1K2 s,t .[ =MEMBEREDR8 ].XXREAL-1K4 r,s .["
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "s <XXREAL-0R3 t"
    have " for p be ExtRealXXREAL-0M1 holds (p inHIDDENR3 ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 [.XXREAL-1K2 s,t .[ implies p inHIDDENR3 ].XXREAL-1K4 r,s .[) & (p inHIDDENR3 ].XXREAL-1K4 r,s .[ implies p inHIDDENR3 ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 [.XXREAL-1K2 s,t .[)"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      show "p inHIDDENR3 ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 [.XXREAL-1K2 s,t .[ implies p inHIDDENR3 ].XXREAL-1K4 r,s .["
      proof(rule impI)
        assume A2: "p inHIDDENR3 ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 [.XXREAL-1K2 s,t .["
        then have A3: " not p inHIDDENR3 [.XXREAL-1K2 s,t .["
          using xboole_0_def_5 sorry
        have A4: "r <XXREAL-0R3 p"
          using A2 xxreal_1_th_4 sorry
        have "p <XXREAL-0R3 s or t <=XXREAL-0R1 p"
          using A3 xxreal_1_th_3 sorry
        thus "p inHIDDENR3 ].XXREAL-1K4 r,s .["
          using A2 A4 xxreal_1_th_4 sorry
      qed
      assume A5: "p inHIDDENR3 ].XXREAL-1K4 r,s .["
      then have A6: "p <XXREAL-0R3 s"
        using xxreal_1_th_4 sorry
      have A7: "r <XXREAL-0R3 p"
        using A5 xxreal_1_th_4 sorry
      have "p <XXREAL-0R3 t"
        using A1 A6 xxreal_0_th_2 sorry
      then have A8: "p inHIDDENR3 ].XXREAL-1K4 r,t .["
        using A7 xxreal_1_th_4 sorry
      have " not p inHIDDENR3 [.XXREAL-1K2 s,t .["
        using A6 xxreal_1_th_3 sorry
      thus "p inHIDDENR3 ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 [.XXREAL-1K2 s,t .["
        using A8 xboole_0_def_5 sorry
    qed "sorry"
    thus "].XXREAL-1K4 r,t .[ \\SUBSET-1K6 [.XXREAL-1K2 s,t .[ =MEMBEREDR8 ].XXREAL-1K4 r,s .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_196:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds s <XXREAL-0R3 t implies [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 ].XXREAL-1K4 s,t .[ =MEMBEREDR8 [.XXREAL-1K1 r,s .]"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds s <XXREAL-0R3 t implies [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 ].XXREAL-1K4 s,t .[ =MEMBEREDR8 [.XXREAL-1K1 r,s .]"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "s <XXREAL-0R3 t"
    have " for p be ExtRealXXREAL-0M1 holds (p inHIDDENR3 [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 ].XXREAL-1K4 s,t .[ implies p inHIDDENR3 [.XXREAL-1K1 r,s .]) & (p inHIDDENR3 [.XXREAL-1K1 r,s .] implies p inHIDDENR3 [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 ].XXREAL-1K4 s,t .[)"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      show "p inHIDDENR3 [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 ].XXREAL-1K4 s,t .[ implies p inHIDDENR3 [.XXREAL-1K1 r,s .]"
      proof(rule impI)
        assume A2: "p inHIDDENR3 [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 ].XXREAL-1K4 s,t .["
        then have A3: " not p inHIDDENR3 ].XXREAL-1K4 s,t .["
          using xboole_0_def_5 sorry
        have A4: "r <=XXREAL-0R1 p"
          using A2 xxreal_1_th_3 sorry
        have "p <=XXREAL-0R1 s or t <=XXREAL-0R1 p"
          using A3 xxreal_1_th_4 sorry
        thus "p inHIDDENR3 [.XXREAL-1K1 r,s .]"
          using A2 A4 xxreal_1_th_1 xxreal_1_th_3 sorry
      qed
      assume A5: "p inHIDDENR3 [.XXREAL-1K1 r,s .]"
      then have A6: "p <=XXREAL-0R1 s"
        using xxreal_1_th_1 sorry
      have A7: "r <=XXREAL-0R1 p"
        using A5 xxreal_1_th_1 sorry
      have "p <XXREAL-0R3 t"
        using A1 A6 xxreal_0_th_2 sorry
      then have A8: "p inHIDDENR3 [.XXREAL-1K2 r,t .["
        using A7 xxreal_1_th_3 sorry
      have " not p inHIDDENR3 ].XXREAL-1K4 s,t .["
        using A6 xxreal_1_th_4 sorry
      thus "p inHIDDENR3 [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 ].XXREAL-1K4 s,t .["
        using A8 xboole_0_def_5 sorry
    qed "sorry"
    thus "[.XXREAL-1K2 r,t .[ \\SUBSET-1K6 ].XXREAL-1K4 s,t .[ =MEMBEREDR8 [.XXREAL-1K1 r,s .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_197:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds s <XXREAL-0R3 t implies ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 ].XXREAL-1K4 s,t .[ =MEMBEREDR8 ].XXREAL-1K3 r,s .]"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds s <XXREAL-0R3 t implies ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 ].XXREAL-1K4 s,t .[ =MEMBEREDR8 ].XXREAL-1K3 r,s .]"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "s <XXREAL-0R3 t"
    have " for p be ExtRealXXREAL-0M1 holds (p inHIDDENR3 ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 ].XXREAL-1K4 s,t .[ implies p inHIDDENR3 ].XXREAL-1K3 r,s .]) & (p inHIDDENR3 ].XXREAL-1K3 r,s .] implies p inHIDDENR3 ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 ].XXREAL-1K4 s,t .[)"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      show "p inHIDDENR3 ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 ].XXREAL-1K4 s,t .[ implies p inHIDDENR3 ].XXREAL-1K3 r,s .]"
      proof(rule impI)
        assume A2: "p inHIDDENR3 ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 ].XXREAL-1K4 s,t .["
        then have A3: " not p inHIDDENR3 ].XXREAL-1K4 s,t .["
          using xboole_0_def_5 sorry
        have A4: "r <XXREAL-0R3 p"
          using A2 xxreal_1_th_4 sorry
        have "p <=XXREAL-0R1 s or t <=XXREAL-0R1 p"
          using A3 xxreal_1_th_4 sorry
        thus "p inHIDDENR3 ].XXREAL-1K3 r,s .]"
          using A2 A4 xxreal_1_th_2 xxreal_1_th_4 sorry
      qed
      assume A5: "p inHIDDENR3 ].XXREAL-1K3 r,s .]"
      then have A6: "p <=XXREAL-0R1 s"
        using xxreal_1_th_2 sorry
      have A7: "r <XXREAL-0R3 p"
        using A5 xxreal_1_th_2 sorry
      have "p <XXREAL-0R3 t"
        using A1 A6 xxreal_0_th_2 sorry
      then have A8: "p inHIDDENR3 ].XXREAL-1K4 r,t .["
        using A7 xxreal_1_th_4 sorry
      have " not p inHIDDENR3 ].XXREAL-1K4 s,t .["
        using A6 xxreal_1_th_4 sorry
      thus "p inHIDDENR3 ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 ].XXREAL-1K4 s,t .["
        using A8 xboole_0_def_5 sorry
    qed "sorry"
    thus "].XXREAL-1K4 r,t .[ \\SUBSET-1K6 ].XXREAL-1K4 s,t .[ =MEMBEREDR8 ].XXREAL-1K3 r,s .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_198:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds [.XXREAL-1K2 p,q .[ meetsXBOOLE-0R5 [.XXREAL-1K2 r,s .[ implies [.XXREAL-1K2 p,q .[ \\SUBSET-1K6 [.XXREAL-1K2 r,s .[ =MEMBEREDR8 [.XXREAL-1K2 p,r .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds [.XXREAL-1K2 p,q .[ meetsXBOOLE-0R5 [.XXREAL-1K2 r,s .[ implies [.XXREAL-1K2 p,q .[ \\SUBSET-1K6 [.XXREAL-1K2 r,s .[ =MEMBEREDR8 [.XXREAL-1K2 p,r .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume "[.XXREAL-1K2 p,q .[ meetsXBOOLE-0R5 [.XXREAL-1K2 r,s .["
    then obtain u where
      [ty]:"u be ExtRealXXREAL-0M1" and 
      A1: "u inHIDDENR3 [.XXREAL-1K2 r,s .["and A2: "u inHIDDENR3 [.XXREAL-1K2 p,q .["
       sorry
    have A3: "r <=XXREAL-0R1 u"
      using A1 xxreal_1_th_3 sorry
    have A4: "u <=XXREAL-0R1 s"
      using A1 xxreal_1_th_3 sorry
    have A5: "p <=XXREAL-0R1 u"
      using A2 xxreal_1_th_3 sorry
    have "u <=XXREAL-0R1 q"
      using A2 xxreal_1_th_3 sorry
    then have A6: "r <=XXREAL-0R1 q"
      using A3 xxreal_0_th_2 sorry
    have A7: "p <=XXREAL-0R1 s"
      using A4 A5 xxreal_0_th_2 sorry
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 [.XXREAL-1K2 p,q .[ \\SUBSET-1K6 [.XXREAL-1K2 r,s .[ implies t inHIDDENR3 [.XXREAL-1K2 p,r .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[) & (t inHIDDENR3 [.XXREAL-1K2 p,r .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[ implies t inHIDDENR3 [.XXREAL-1K2 p,q .[ \\SUBSET-1K6 [.XXREAL-1K2 r,s .[)"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 [.XXREAL-1K2 p,q .[ \\SUBSET-1K6 [.XXREAL-1K2 r,s .[ implies t inHIDDENR3 [.XXREAL-1K2 p,r .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
      proof(rule impI)
        assume A8: "t inHIDDENR3 [.XXREAL-1K2 p,q .[ \\SUBSET-1K6 [.XXREAL-1K2 r,s .["
        then have A9: " not t inHIDDENR3 [.XXREAL-1K2 r,s .["
          using xboole_0_def_5 sorry
        have A10: "p <=XXREAL-0R1 t"
          using A8 xxreal_1_th_3 sorry
        have A11: "t <XXREAL-0R3 q"
          using A8 xxreal_1_th_3 sorry
        have "t <XXREAL-0R3 r or s <=XXREAL-0R1 t"
          using A9 xxreal_1_th_3 sorry
        then have "t inHIDDENR3 [.XXREAL-1K2 p,r .[ or t inHIDDENR3 [.XXREAL-1K2 s,q .["
          using A10 A11 xxreal_1_th_3 sorry
        thus "t inHIDDENR3 [.XXREAL-1K2 p,r .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
          using xboole_0_def_3 sorry
      qed
      assume "t inHIDDENR3 [.XXREAL-1K2 p,r .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
      then have "t inHIDDENR3 [.XXREAL-1K2 p,r .[ or t inHIDDENR3 [.XXREAL-1K2 s,q .["
        using xboole_0_def_3 sorry
      then have A12: "p <=XXREAL-0R1 t & t <XXREAL-0R3 r or s <=XXREAL-0R1 t & t <XXREAL-0R3 q"
        using xxreal_1_th_3 sorry
      then have A13: "p <=XXREAL-0R1 t"
        using A7 xxreal_0_th_2 sorry
      have "t <XXREAL-0R3 q"
        using A6 A12 xxreal_0_th_2 sorry
      then have A14: "t inHIDDENR3 [.XXREAL-1K2 p,q .["
        using A13 xxreal_1_th_3 sorry
      have " not t inHIDDENR3 [.XXREAL-1K2 r,s .["
        using A12 xxreal_1_th_3 sorry
      thus "t inHIDDENR3 [.XXREAL-1K2 p,q .[ \\SUBSET-1K6 [.XXREAL-1K2 r,s .["
        using A14 xboole_0_def_5 sorry
    qed "sorry"
    thus "[.XXREAL-1K2 p,q .[ \\SUBSET-1K6 [.XXREAL-1K2 r,s .[ =MEMBEREDR8 [.XXREAL-1K2 p,r .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_199:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds ].XXREAL-1K3 p,q .] meetsXBOOLE-0R5 ].XXREAL-1K3 r,s .] implies ].XXREAL-1K3 p,q .] \\SUBSET-1K6 ].XXREAL-1K3 r,s .] =MEMBEREDR8 ].XXREAL-1K3 p,r .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds ].XXREAL-1K3 p,q .] meetsXBOOLE-0R5 ].XXREAL-1K3 r,s .] implies ].XXREAL-1K3 p,q .] \\SUBSET-1K6 ].XXREAL-1K3 r,s .] =MEMBEREDR8 ].XXREAL-1K3 p,r .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume "].XXREAL-1K3 p,q .] meetsXBOOLE-0R5 ].XXREAL-1K3 r,s .]"
    then obtain u where
      [ty]:"u be ExtRealXXREAL-0M1" and 
      A1: "u inHIDDENR3 ].XXREAL-1K3 r,s .]"and A2: "u inHIDDENR3 ].XXREAL-1K3 p,q .]"
       sorry
    have A3: "r <XXREAL-0R3 u"
      using A1 xxreal_1_th_2 sorry
    have A4: "u <=XXREAL-0R1 s"
      using A1 xxreal_1_th_2 sorry
    have A5: "p <XXREAL-0R3 u"
      using A2 xxreal_1_th_2 sorry
    have "u <=XXREAL-0R1 q"
      using A2 xxreal_1_th_2 sorry
    then have A6: "r <=XXREAL-0R1 q"
      using A3 xxreal_0_th_2 sorry
    have A7: "p <=XXREAL-0R1 s"
      using A4 A5 xxreal_0_th_2 sorry
    have " for t be ExtRealXXREAL-0M1 holds (t inHIDDENR3 ].XXREAL-1K3 p,q .] \\SUBSET-1K6 ].XXREAL-1K3 r,s .] implies t inHIDDENR3 ].XXREAL-1K3 p,r .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]) & (t inHIDDENR3 ].XXREAL-1K3 p,r .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .] implies t inHIDDENR3 ].XXREAL-1K3 p,q .] \\SUBSET-1K6 ].XXREAL-1K3 r,s .])"
    proof(rule ballI,rule conjMI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      show "t inHIDDENR3 ].XXREAL-1K3 p,q .] \\SUBSET-1K6 ].XXREAL-1K3 r,s .] implies t inHIDDENR3 ].XXREAL-1K3 p,r .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
      proof(rule impI)
        assume A8: "t inHIDDENR3 ].XXREAL-1K3 p,q .] \\SUBSET-1K6 ].XXREAL-1K3 r,s .]"
        then have A9: " not t inHIDDENR3 ].XXREAL-1K3 r,s .]"
          using xboole_0_def_5 sorry
        have A10: "p <XXREAL-0R3 t"
          using A8 xxreal_1_th_2 sorry
        have A11: "t <=XXREAL-0R1 q"
          using A8 xxreal_1_th_2 sorry
        have "t <=XXREAL-0R1 r or s <XXREAL-0R3 t"
          using A9 xxreal_1_th_2 sorry
        then have "t inHIDDENR3 ].XXREAL-1K3 p,r .] or t inHIDDENR3 ].XXREAL-1K3 s,q .]"
          using A10 A11 xxreal_1_th_2 sorry
        thus "t inHIDDENR3 ].XXREAL-1K3 p,r .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
          using xboole_0_def_3 sorry
      qed
      assume "t inHIDDENR3 ].XXREAL-1K3 p,r .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
      then have "t inHIDDENR3 ].XXREAL-1K3 p,r .] or t inHIDDENR3 ].XXREAL-1K3 s,q .]"
        using xboole_0_def_3 sorry
      then have A12: "p <XXREAL-0R3 t & t <=XXREAL-0R1 r or s <XXREAL-0R3 t & t <=XXREAL-0R1 q"
        using xxreal_1_th_2 sorry
      then have A13: "p <XXREAL-0R3 t"
        using A7 xxreal_0_th_2 sorry
      have "t <=XXREAL-0R1 q"
        using A6 A12 xxreal_0_th_2 sorry
      then have A14: "t inHIDDENR3 ].XXREAL-1K3 p,q .]"
        using A13 xxreal_1_th_2 sorry
      have " not t inHIDDENR3 ].XXREAL-1K3 r,s .]"
        using A12 xxreal_1_th_2 sorry
      thus "t inHIDDENR3 ].XXREAL-1K3 p,q .] \\SUBSET-1K6 ].XXREAL-1K3 r,s .]"
        using A14 xboole_0_def_5 sorry
    qed "sorry"
    thus "].XXREAL-1K3 p,q .] \\SUBSET-1K6 ].XXREAL-1K3 r,s .] =MEMBEREDR8 ].XXREAL-1K3 p,r .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_200:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r & s <=XXREAL-0R1 q implies [.XXREAL-1K1 p,q .] \\SUBSET-1K6 ([.XXREAL-1K1 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]) =MEMBEREDR8 ].XXREAL-1K4 r,s .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r & s <=XXREAL-0R1 q implies [.XXREAL-1K1 p,q .] \\SUBSET-1K6 ([.XXREAL-1K1 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]) =HIDDENR1 ].XXREAL-1K4 r,s .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "p <=XXREAL-0R1 r"
      and A2: "s <=XXREAL-0R1 q"
    have "[.XXREAL-1K1 p,q .] \\SUBSET-1K6 ([.XXREAL-1K1 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]) =HIDDENR1 ([.XXREAL-1K1 p,q .] \\SUBSET-1K6 [.XXREAL-1K1 p,r .])\\SUBSET-1K7\<^bsub>([.XXREAL-1K1 p,q .])\<^esub> [.XXREAL-1K1 s,q .]"
      using xboole_1_th_41 sorry
    also have "... = ].XXREAL-1K3 r,q .] \\SUBSET-1K6 [.XXREAL-1K1 s,q .]"
      using A1 xxreal_1_th_182 sorry
    also have "... = ].XXREAL-1K4 r,s .["
      using A2 xxreal_1_th_191 sorry
    finally show "[.XXREAL-1K1 p,q .] \\SUBSET-1K6 ([.XXREAL-1K1 p,r .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]) =HIDDENR1 ].XXREAL-1K4 r,s .["
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_201:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & s <=XXREAL-0R1 t implies [.XXREAL-1K1 r,t .] \\SUBSET-1K6 {TARSKIK1 s} =MEMBEREDR8 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .]"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & s <=XXREAL-0R1 t implies [.XXREAL-1K1 r,t .] \\SUBSET-1K6 {TARSKIK1 s} =MEMBEREDR8 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .]"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
      and A2: "s <=XXREAL-0R1 t"
    have " for p be ExtRealXXREAL-0M1 holds (p inHIDDENR3 [.XXREAL-1K1 r,t .] \\SUBSET-1K6 {TARSKIK1 s} implies p inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .]) & (p inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .] implies p inHIDDENR3 [.XXREAL-1K1 r,t .] \\SUBSET-1K6 {TARSKIK1 s})"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      show "p inHIDDENR3 [.XXREAL-1K1 r,t .] \\SUBSET-1K6 {TARSKIK1 s} implies p inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .]"
      proof(rule impI)
        assume A3: "p inHIDDENR3 [.XXREAL-1K1 r,t .] \\SUBSET-1K6 {TARSKIK1 s}"
        then have " not p inHIDDENR3 {TARSKIK1 s}"
          using xboole_0_def_5 sorry
        then have "p <>HIDDENR2 s"
          using tarski_def_1 sorry
        then have "r <=XXREAL-0R1 p & p <XXREAL-0R3 s or s <XXREAL-0R3 p & p <=XXREAL-0R1 t"
          using A3 xxreal_1_th_1 xxreal_0_th_1 sorry
        then have "p inHIDDENR3 [.XXREAL-1K2 r,s .[ or p inHIDDENR3 ].XXREAL-1K3 s,t .]"
          using xxreal_1_th_2 xxreal_1_th_3 sorry
        thus "p inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .]"
          using xboole_0_def_3 sorry
      qed
      assume "p inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .]"
      then have "p inHIDDENR3 [.XXREAL-1K2 r,s .[ or p inHIDDENR3 ].XXREAL-1K3 s,t .]"
        using xboole_0_def_3 sorry
      then have A4: "r <=XXREAL-0R1 p & p <XXREAL-0R3 s or s <XXREAL-0R3 p & p <=XXREAL-0R1 t"
        using xxreal_1_th_2 xxreal_1_th_3 sorry
      then have A5: "r <=XXREAL-0R1 p"
        using A1 xxreal_0_th_2 sorry
      have "p <=XXREAL-0R1 t"
        using A2 A4 xxreal_0_th_2 sorry
      then have A6: "p inHIDDENR3 [.XXREAL-1K1 r,t .]"
        using A5 xxreal_1_th_1 sorry
      have " not p inHIDDENR3 {TARSKIK1 s}"
        using A4 tarski_def_1 sorry
      thus "p inHIDDENR3 [.XXREAL-1K1 r,t .] \\SUBSET-1K6 {TARSKIK1 s}"
        using A6 xboole_0_def_5 sorry
    qed "sorry"
    thus "[.XXREAL-1K1 r,t .] \\SUBSET-1K6 {TARSKIK1 s} =MEMBEREDR8 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_202:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & s <XXREAL-0R3 t implies [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 {TARSKIK1 s} =MEMBEREDR8 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .["
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & s <XXREAL-0R3 t implies [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 {TARSKIK1 s} =MEMBEREDR8 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .["
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
      and A2: "s <XXREAL-0R3 t"
    have " for p be ExtRealXXREAL-0M1 holds (p inHIDDENR3 [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 {TARSKIK1 s} implies p inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .[) & (p inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .[ implies p inHIDDENR3 [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 {TARSKIK1 s})"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      show "p inHIDDENR3 [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 {TARSKIK1 s} implies p inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .["
      proof(rule impI)
        assume A3: "p inHIDDENR3 [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 {TARSKIK1 s}"
        then have " not p inHIDDENR3 {TARSKIK1 s}"
          using xboole_0_def_5 sorry
        then have "p <>HIDDENR2 s"
          using tarski_def_1 sorry
        then have "r <=XXREAL-0R1 p & p <XXREAL-0R3 s or s <XXREAL-0R3 p & p <XXREAL-0R3 t"
          using A3 xxreal_1_th_3 xxreal_0_th_1 sorry
        then have "p inHIDDENR3 [.XXREAL-1K2 r,s .[ or p inHIDDENR3 ].XXREAL-1K4 s,t .["
          using xxreal_1_th_3 xxreal_1_th_4 sorry
        thus "p inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .["
          using xboole_0_def_3 sorry
      qed
      assume "p inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .["
      then have "p inHIDDENR3 [.XXREAL-1K2 r,s .[ or p inHIDDENR3 ].XXREAL-1K4 s,t .["
        using xboole_0_def_3 sorry
      then have A4: "r <=XXREAL-0R1 p & p <XXREAL-0R3 s or s <XXREAL-0R3 p & p <XXREAL-0R3 t"
        using xxreal_1_th_3 xxreal_1_th_4 sorry
      then have A5: "r <=XXREAL-0R1 p"
        using A1 xxreal_0_th_2 sorry
      have "p <XXREAL-0R3 t"
        using A2 A4 xxreal_0_th_2 sorry
      then have A6: "p inHIDDENR3 [.XXREAL-1K2 r,t .["
        using A5 xxreal_1_th_3 sorry
      have " not p inHIDDENR3 {TARSKIK1 s}"
        using A4 tarski_def_1 sorry
      thus "p inHIDDENR3 [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 {TARSKIK1 s}"
        using A6 xboole_0_def_5 sorry
    qed "sorry"
    thus "[.XXREAL-1K2 r,t .[ \\SUBSET-1K6 {TARSKIK1 s} =MEMBEREDR8 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_203:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & s <=XXREAL-0R1 t implies ].XXREAL-1K3 r,t .] \\SUBSET-1K6 {TARSKIK1 s} =MEMBEREDR8 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .]"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & s <=XXREAL-0R1 t implies ].XXREAL-1K3 r,t .] \\SUBSET-1K6 {TARSKIK1 s} =MEMBEREDR8 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .]"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "s <=XXREAL-0R1 t"
    have " for p be ExtRealXXREAL-0M1 holds (p inHIDDENR3 ].XXREAL-1K3 r,t .] \\SUBSET-1K6 {TARSKIK1 s} implies p inHIDDENR3 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .]) & (p inHIDDENR3 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .] implies p inHIDDENR3 ].XXREAL-1K3 r,t .] \\SUBSET-1K6 {TARSKIK1 s})"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      show "p inHIDDENR3 ].XXREAL-1K3 r,t .] \\SUBSET-1K6 {TARSKIK1 s} implies p inHIDDENR3 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .]"
      proof(rule impI)
        assume A3: "p inHIDDENR3 ].XXREAL-1K3 r,t .] \\SUBSET-1K6 {TARSKIK1 s}"
        then have " not p inHIDDENR3 {TARSKIK1 s}"
          using xboole_0_def_5 sorry
        then have "p <>HIDDENR2 s"
          using tarski_def_1 sorry
        then have "r <XXREAL-0R3 p & p <XXREAL-0R3 s or s <XXREAL-0R3 p & p <=XXREAL-0R1 t"
          using A3 xxreal_1_th_2 xxreal_0_th_1 sorry
        then have "p inHIDDENR3 ].XXREAL-1K4 r,s .[ or p inHIDDENR3 ].XXREAL-1K3 s,t .]"
          using xxreal_1_th_2 xxreal_1_th_4 sorry
        thus "p inHIDDENR3 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .]"
          using xboole_0_def_3 sorry
      qed
      assume "p inHIDDENR3 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .]"
      then have "p inHIDDENR3 ].XXREAL-1K4 r,s .[ or p inHIDDENR3 ].XXREAL-1K3 s,t .]"
        using xboole_0_def_3 sorry
      then have A4: "r <XXREAL-0R3 p & p <XXREAL-0R3 s or s <XXREAL-0R3 p & p <=XXREAL-0R1 t"
        using xxreal_1_th_2 xxreal_1_th_4 sorry
      then have A5: "r <XXREAL-0R3 p"
        using A1 xxreal_0_th_2 sorry
      have "p <=XXREAL-0R1 t"
        using A2 A4 xxreal_0_th_2 sorry
      then have A6: "p inHIDDENR3 ].XXREAL-1K3 r,t .]"
        using A5 xxreal_1_th_2 sorry
      have " not p inHIDDENR3 {TARSKIK1 s}"
        using A4 tarski_def_1 sorry
      thus "p inHIDDENR3 ].XXREAL-1K3 r,t .] \\SUBSET-1K6 {TARSKIK1 s}"
        using A6 xboole_0_def_5 sorry
    qed "sorry"
    thus "].XXREAL-1K3 r,t .] \\SUBSET-1K6 {TARSKIK1 s} =MEMBEREDR8 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_204:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & s <XXREAL-0R3 t implies ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 {TARSKIK1 s} =MEMBEREDR8 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .["
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & s <XXREAL-0R3 t implies ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 {TARSKIK1 s} =MEMBEREDR8 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .["
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "s <XXREAL-0R3 t"
    have " for p be ExtRealXXREAL-0M1 holds (p inHIDDENR3 ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 {TARSKIK1 s} implies p inHIDDENR3 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .[) & (p inHIDDENR3 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .[ implies p inHIDDENR3 ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 {TARSKIK1 s})"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      show "p inHIDDENR3 ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 {TARSKIK1 s} implies p inHIDDENR3 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .["
      proof(rule impI)
        assume A3: "p inHIDDENR3 ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 {TARSKIK1 s}"
        then have " not p inHIDDENR3 {TARSKIK1 s}"
          using xboole_0_def_5 sorry
        then have "p <>HIDDENR2 s"
          using tarski_def_1 sorry
        then have "r <XXREAL-0R3 p & p <XXREAL-0R3 s or s <XXREAL-0R3 p & p <XXREAL-0R3 t"
          using A3 xxreal_1_th_4 xxreal_0_th_1 sorry
        then have "p inHIDDENR3 ].XXREAL-1K4 r,s .[ or p inHIDDENR3 ].XXREAL-1K4 s,t .["
          using xxreal_1_th_4 sorry
        thus "p inHIDDENR3 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .["
          using xboole_0_def_3 sorry
      qed
      assume "p inHIDDENR3 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .["
      then have "p inHIDDENR3 ].XXREAL-1K4 r,s .[ or p inHIDDENR3 ].XXREAL-1K4 s,t .["
        using xboole_0_def_3 sorry
      then have A4: "r <XXREAL-0R3 p & p <XXREAL-0R3 s or s <XXREAL-0R3 p & p <XXREAL-0R3 t"
        using xxreal_1_th_4 sorry
      then have A5: "r <XXREAL-0R3 p"
        using A1 xxreal_0_th_2 sorry
      have "p <XXREAL-0R3 t"
        using A2 A4 xxreal_0_th_2 sorry
      then have A6: "p inHIDDENR3 ].XXREAL-1K4 r,t .["
        using A5 xxreal_1_th_4 sorry
      have " not p inHIDDENR3 {TARSKIK1 s}"
        using A4 tarski_def_1 sorry
      thus "p inHIDDENR3 ].XXREAL-1K4 r,t .[ \\SUBSET-1K6 {TARSKIK1 s}"
        using A6 xboole_0_def_5 sorry
    qed "sorry"
    thus "].XXREAL-1K4 r,t .[ \\SUBSET-1K6 {TARSKIK1 s} =MEMBEREDR8 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_205:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds  not s inHIDDENR3 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .["
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds s inHIDDENR3 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .[ implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume "s inHIDDENR3 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .["
    then have "s inHIDDENR3 ].XXREAL-1K4 r,s .[ or s inHIDDENR3 ].XXREAL-1K4 s,t .["
      using xboole_0_def_3 sorry
    thus " False "
      using xxreal_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_206:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds  not s inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .["
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds s inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .[ implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume "s inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,t .["
    then have "s inHIDDENR3 [.XXREAL-1K2 r,s .[ or s inHIDDENR3 ].XXREAL-1K4 s,t .["
      using xboole_0_def_3 sorry
    thus " False "
      using xxreal_1_th_3 xxreal_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_207:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds  not s inHIDDENR3 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .]"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds s inHIDDENR3 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .] implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume "s inHIDDENR3 ].XXREAL-1K4 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .]"
    then have "s inHIDDENR3 ].XXREAL-1K4 r,s .[ or s inHIDDENR3 ].XXREAL-1K3 s,t .]"
      using xboole_0_def_3 sorry
    thus " False "
      using xxreal_1_th_2 xxreal_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_208:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds  not s inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .]"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds s inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .] implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume "s inHIDDENR3 [.XXREAL-1K2 r,s .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,t .]"
    then have "s inHIDDENR3 [.XXREAL-1K2 r,s .[ or s inHIDDENR3 ].XXREAL-1K3 s,t .]"
      using xboole_0_def_3 sorry
    thus " False "
      using xxreal_1_th_2 xxreal_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem xxreal_1_th_209:
"[.XXREAL-1K1 -inftyXXREAL-0K2,+inftyXXREAL-0K1 .] =MEMBEREDR8 ExtREALXXREAL-0K3"
proof-
  have " for r be ExtRealXXREAL-0M1 holds (r inHIDDENR3 [.XXREAL-1K1 -inftyXXREAL-0K2,+inftyXXREAL-0K1 .] implies r inHIDDENR3 ExtREALXXREAL-0K3) & (r inHIDDENR3 ExtREALXXREAL-0K3 implies r inHIDDENR3 [.XXREAL-1K1 -inftyXXREAL-0K2,+inftyXXREAL-0K1 .])"
  proof(rule ballI,rule conjMI,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    show "r inHIDDENR3 [.XXREAL-1K1 -inftyXXREAL-0K2,+inftyXXREAL-0K1 .] implies r inHIDDENR3 ExtREALXXREAL-0K3"
      using xxreal_0_def_1 sorry
    assume "r inHIDDENR3 ExtREALXXREAL-0K3"
    have A1: "-inftyXXREAL-0K2 <=XXREAL-0R1 r"
      using xxreal_0_th_5 sorry
    have "r <=XXREAL-0R1 +inftyXXREAL-0K1"
      using xxreal_0_th_3 sorry
    thus "r inHIDDENR3 [.XXREAL-1K1 -inftyXXREAL-0K2,+inftyXXREAL-0K1 .]"
      using A1 xxreal_1_th_1 sorry
  qed "sorry"
  thus "[.XXREAL-1K1 -inftyXXREAL-0K2,+inftyXXREAL-0K1 .] =MEMBEREDR8 ExtREALXXREAL-0K3"
    using membered_def_14 sorry
qed

mtheorem xxreal_1_th_210:
" for p be ExtRealXXREAL-0M1 holds ].XXREAL-1K4 p,-inftyXXREAL-0K2 .[ =MEMBEREDR8 {}XBOOLE-0K1"
proof-
  have " for p be ExtRealXXREAL-0M1 holds ].XXREAL-1K4 p,-inftyXXREAL-0K2 .[ =MEMBEREDR8 {}XBOOLE-0K1"
  proof(rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    have " not ( ex x be objectHIDDENM1 st x inHIDDENR3 ].XXREAL-1K4 p,-inftyXXREAL-0K2 .[)"
    proof-
      have "( ex x be objectHIDDENM1 st x inHIDDENR3 ].XXREAL-1K4 p,-inftyXXREAL-0K2 .[) implies  False "
      proof(rule impI)
        assume Given: " ex x be objectHIDDENM1 st x inHIDDENR3 ].XXREAL-1K4 p,-inftyXXREAL-0K2 .["
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A1: "x inHIDDENR3 ].XXREAL-1K4 p,-inftyXXREAL-0K2 .["
           sorry
        obtain s where 
          [ty]:"s be ExtRealXXREAL-0M1" and sDef:"s = x"
          using A1 sorry
        have "s <XXREAL-0R3 -inftyXXREAL-0K2"
          using A1 xxreal_1_th_4 sorry
        thus " False "
          using xxreal_0_th_5 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus "].XXREAL-1K4 p,-inftyXXREAL-0K2 .[ =MEMBEREDR8 {}XBOOLE-0K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_211:
" for p be ExtRealXXREAL-0M1 holds [.XXREAL-1K2 p,-inftyXXREAL-0K2 .[ =MEMBEREDR8 {}XBOOLE-0K1"
proof-
  have " for p be ExtRealXXREAL-0M1 holds [.XXREAL-1K2 p,-inftyXXREAL-0K2 .[ =MEMBEREDR8 {}XBOOLE-0K1"
  proof(rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    have " not ( ex x be objectHIDDENM1 st x inHIDDENR3 [.XXREAL-1K2 p,-inftyXXREAL-0K2 .[)"
    proof-
      have "( ex x be objectHIDDENM1 st x inHIDDENR3 [.XXREAL-1K2 p,-inftyXXREAL-0K2 .[) implies  False "
      proof(rule impI)
        assume Given: " ex x be objectHIDDENM1 st x inHIDDENR3 [.XXREAL-1K2 p,-inftyXXREAL-0K2 .["
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A1: "x inHIDDENR3 [.XXREAL-1K2 p,-inftyXXREAL-0K2 .["
           sorry
        obtain s where 
          [ty]:"s be ExtRealXXREAL-0M1" and sDef:"s = x"
          using A1 sorry
        have "s <XXREAL-0R3 -inftyXXREAL-0K2"
          using A1 xxreal_1_th_3 sorry
        thus " False "
          using xxreal_0_th_5 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus "[.XXREAL-1K2 p,-inftyXXREAL-0K2 .[ =MEMBEREDR8 {}XBOOLE-0K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_212:
" for p be ExtRealXXREAL-0M1 holds ].XXREAL-1K3 p,-inftyXXREAL-0K2 .] =MEMBEREDR8 {}XBOOLE-0K1"
proof-
  have " for p be ExtRealXXREAL-0M1 holds ].XXREAL-1K3 p,-inftyXXREAL-0K2 .] =MEMBEREDR8 {}XBOOLE-0K1"
  proof(rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    have " not ( ex x be objectHIDDENM1 st x inHIDDENR3 ].XXREAL-1K3 p,-inftyXXREAL-0K2 .])"
    proof-
      have "( ex x be objectHIDDENM1 st x inHIDDENR3 ].XXREAL-1K3 p,-inftyXXREAL-0K2 .]) implies  False "
      proof(rule impI)
        assume Given: " ex x be objectHIDDENM1 st x inHIDDENR3 ].XXREAL-1K3 p,-inftyXXREAL-0K2 .]"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A1: "x inHIDDENR3 ].XXREAL-1K3 p,-inftyXXREAL-0K2 .]"
           sorry
        obtain s where 
          [ty]:"s be ExtRealXXREAL-0M1" and sDef:"s = x"
          using A1 sorry
        have A2: "p <XXREAL-0R3 s"
          using A1 xxreal_1_th_2 sorry
        have "s <=XXREAL-0R1 -inftyXXREAL-0K2"
          using A1 xxreal_1_th_2 sorry
        then have "p <XXREAL-0R3 -inftyXXREAL-0K2"
          using A2 xxreal_0_th_2 sorry
        thus " False "
          using xxreal_0_th_5 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus "].XXREAL-1K3 p,-inftyXXREAL-0K2 .] =MEMBEREDR8 {}XBOOLE-0K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_213:
" for p be ExtRealXXREAL-0M1 holds p <>HIDDENR2 -inftyXXREAL-0K2 implies [.XXREAL-1K1 p,-inftyXXREAL-0K2 .] =MEMBEREDR8 {}XBOOLE-0K1"
proof-
  have " for p be ExtRealXXREAL-0M1 holds p <>HIDDENR2 -inftyXXREAL-0K2 implies [.XXREAL-1K1 p,-inftyXXREAL-0K2 .] =MEMBEREDR8 {}XBOOLE-0K1"
  proof(rule ballI,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    assume A1: "p <>HIDDENR2 -inftyXXREAL-0K2"
    have " not ( ex x be objectHIDDENM1 st x inHIDDENR3 [.XXREAL-1K1 p,-inftyXXREAL-0K2 .])"
    proof-
      have "( ex x be objectHIDDENM1 st x inHIDDENR3 [.XXREAL-1K1 p,-inftyXXREAL-0K2 .]) implies  False "
      proof(rule impI)
        assume Given: " ex x be objectHIDDENM1 st x inHIDDENR3 [.XXREAL-1K1 p,-inftyXXREAL-0K2 .]"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A2: "x inHIDDENR3 [.XXREAL-1K1 p,-inftyXXREAL-0K2 .]"
           sorry
        obtain s where 
          [ty]:"s be ExtRealXXREAL-0M1" and sDef:"s = x"
          using A2 sorry
        have A3: "p <=XXREAL-0R1 s"
          using A2 xxreal_1_th_1 sorry
        have "s <=XXREAL-0R1 -inftyXXREAL-0K2"
          using A2 xxreal_1_th_1 sorry
        thus " False "
          using A1 A3 xxreal_0_th_2 xxreal_0_th_6 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus "[.XXREAL-1K1 p,-inftyXXREAL-0K2 .] =MEMBEREDR8 {}XBOOLE-0K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_214:
" for p be ExtRealXXREAL-0M1 holds ].XXREAL-1K4 +inftyXXREAL-0K1,p .[ =MEMBEREDR8 {}XBOOLE-0K1"
proof-
  have " for p be ExtRealXXREAL-0M1 holds ].XXREAL-1K4 +inftyXXREAL-0K1,p .[ =MEMBEREDR8 {}XBOOLE-0K1"
  proof(rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    have " not ( ex x be objectHIDDENM1 st x inHIDDENR3 ].XXREAL-1K4 +inftyXXREAL-0K1,p .[)"
    proof-
      have "( ex x be objectHIDDENM1 st x inHIDDENR3 ].XXREAL-1K4 +inftyXXREAL-0K1,p .[) implies  False "
      proof(rule impI)
        assume Given: " ex x be objectHIDDENM1 st x inHIDDENR3 ].XXREAL-1K4 +inftyXXREAL-0K1,p .["
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A1: "x inHIDDENR3 ].XXREAL-1K4 +inftyXXREAL-0K1,p .["
           sorry
        obtain s where 
          [ty]:"s be ExtRealXXREAL-0M1" and sDef:"s = x"
          using A1 sorry
        have "+inftyXXREAL-0K1 <XXREAL-0R3 s"
          using A1 xxreal_1_th_4 sorry
        thus " False "
          using xxreal_0_th_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus "].XXREAL-1K4 +inftyXXREAL-0K1,p .[ =MEMBEREDR8 {}XBOOLE-0K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_215:
" for p be ExtRealXXREAL-0M1 holds [.XXREAL-1K2 +inftyXXREAL-0K1,p .[ =MEMBEREDR8 {}XBOOLE-0K1"
proof-
  have " for p be ExtRealXXREAL-0M1 holds [.XXREAL-1K2 +inftyXXREAL-0K1,p .[ =MEMBEREDR8 {}XBOOLE-0K1"
  proof(rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    have " not ( ex x be objectHIDDENM1 st x inHIDDENR3 [.XXREAL-1K2 +inftyXXREAL-0K1,p .[)"
    proof-
      have "( ex x be objectHIDDENM1 st x inHIDDENR3 [.XXREAL-1K2 +inftyXXREAL-0K1,p .[) implies  False "
      proof(rule impI)
        assume Given: " ex x be objectHIDDENM1 st x inHIDDENR3 [.XXREAL-1K2 +inftyXXREAL-0K1,p .["
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A1: "x inHIDDENR3 [.XXREAL-1K2 +inftyXXREAL-0K1,p .["
           sorry
        obtain s where 
          [ty]:"s be ExtRealXXREAL-0M1" and sDef:"s = x"
          using A1 sorry
        have A2: "+inftyXXREAL-0K1 <=XXREAL-0R1 s"
          using A1 xxreal_1_th_3 sorry
        have "s <XXREAL-0R3 p"
          using A1 xxreal_1_th_3 sorry
        then have "p >XXREAL-0R4 +inftyXXREAL-0K1"
          using A2 xxreal_0_th_2 sorry
        thus " False "
          using xxreal_0_th_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus "[.XXREAL-1K2 +inftyXXREAL-0K1,p .[ =MEMBEREDR8 {}XBOOLE-0K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_216:
" for p be ExtRealXXREAL-0M1 holds ].XXREAL-1K3 +inftyXXREAL-0K1,p .] =MEMBEREDR8 {}XBOOLE-0K1"
proof-
  have " for p be ExtRealXXREAL-0M1 holds ].XXREAL-1K3 +inftyXXREAL-0K1,p .] =MEMBEREDR8 {}XBOOLE-0K1"
  proof(rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    have " not ( ex x be objectHIDDENM1 st x inHIDDENR3 ].XXREAL-1K3 +inftyXXREAL-0K1,p .])"
    proof-
      have "( ex x be objectHIDDENM1 st x inHIDDENR3 ].XXREAL-1K3 +inftyXXREAL-0K1,p .]) implies  False "
      proof(rule impI)
        assume Given: " ex x be objectHIDDENM1 st x inHIDDENR3 ].XXREAL-1K3 +inftyXXREAL-0K1,p .]"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A1: "x inHIDDENR3 ].XXREAL-1K3 +inftyXXREAL-0K1,p .]"
           sorry
        obtain s where 
          [ty]:"s be ExtRealXXREAL-0M1" and sDef:"s = x"
          using A1 sorry
        have "+inftyXXREAL-0K1 <XXREAL-0R3 s"
          using A1 xxreal_1_th_2 sorry
        thus " False "
          using xxreal_0_th_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus "].XXREAL-1K3 +inftyXXREAL-0K1,p .] =MEMBEREDR8 {}XBOOLE-0K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_217:
" for p be ExtRealXXREAL-0M1 holds p <>HIDDENR2 +inftyXXREAL-0K1 implies [.XXREAL-1K1 +inftyXXREAL-0K1,p .] =MEMBEREDR8 {}XBOOLE-0K1"
proof-
  have " for p be ExtRealXXREAL-0M1 holds p <>HIDDENR2 +inftyXXREAL-0K1 implies [.XXREAL-1K1 +inftyXXREAL-0K1,p .] =MEMBEREDR8 {}XBOOLE-0K1"
  proof(rule ballI,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    assume A1: "p <>HIDDENR2 +inftyXXREAL-0K1"
    have " not ( ex x be objectHIDDENM1 st x inHIDDENR3 [.XXREAL-1K1 +inftyXXREAL-0K1,p .])"
    proof-
      have "( ex x be objectHIDDENM1 st x inHIDDENR3 [.XXREAL-1K1 +inftyXXREAL-0K1,p .]) implies  False "
      proof(rule impI)
        assume Given: " ex x be objectHIDDENM1 st x inHIDDENR3 [.XXREAL-1K1 +inftyXXREAL-0K1,p .]"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A2: "x inHIDDENR3 [.XXREAL-1K1 +inftyXXREAL-0K1,p .]"
           sorry
        obtain s where 
          [ty]:"s be ExtRealXXREAL-0M1" and sDef:"s = x"
          using A2 sorry
        have A3: "+inftyXXREAL-0K1 <=XXREAL-0R1 s"
          using A2 xxreal_1_th_1 sorry
        have "s <=XXREAL-0R1 p"
          using A2 xxreal_1_th_1 sorry
        thus " False "
          using A1 A3 xxreal_0_th_2 xxreal_0_th_4 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus "[.XXREAL-1K1 +inftyXXREAL-0K1,p .] =MEMBEREDR8 {}XBOOLE-0K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_218:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds p >XXREAL-0R4 q implies p inHIDDENR3 ].XXREAL-1K3 q,+inftyXXREAL-0K1 .]"
  using xxreal_0_th_3 xxreal_1_th_2 sorry

mtheorem xxreal_1_th_219:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds q <=XXREAL-0R1 p implies p inHIDDENR3 [.XXREAL-1K1 q,+inftyXXREAL-0K1 .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  not (q <=XXREAL-0R1 p &  not p inHIDDENR3 [.XXREAL-1K1 q,+inftyXXREAL-0K1 .])"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    have "p <=XXREAL-0R1 +inftyXXREAL-0K1"
      using xxreal_0_th_3 sorry
    thus " not (q <=XXREAL-0R1 p &  not p inHIDDENR3 [.XXREAL-1K1 q,+inftyXXREAL-0K1 .])"
      using xxreal_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_220:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 q implies p inHIDDENR3 [.XXREAL-1K1 -inftyXXREAL-0K2,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  not (p <=XXREAL-0R1 q &  not p inHIDDENR3 [.XXREAL-1K1 -inftyXXREAL-0K2,q .])"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    have "p >=XXREAL-0R2 -inftyXXREAL-0K2"
      using xxreal_0_th_5 sorry
    thus " not (p <=XXREAL-0R1 q &  not p inHIDDENR3 [.XXREAL-1K1 -inftyXXREAL-0K2,q .])"
      using xxreal_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_221:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds p <XXREAL-0R3 q implies p inHIDDENR3 [.XXREAL-1K2 -inftyXXREAL-0K2,q .["
  using xxreal_0_th_5 xxreal_1_th_3 sorry

(*begin*)
mtheorem xxreal_1_th_222:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 q implies [.XXREAL-1K1 p,q .] =MEMBEREDR8 [.XXREAL-1K1 p,q .] \\/XBOOLE-0K2 [.XXREAL-1K1 q,p .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 q implies [.XXREAL-1K1 p,q .] =MEMBEREDR8 [.XXREAL-1K1 p,q .] \\/XBOOLE-0K2 [.XXREAL-1K1 q,p .]"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    assume A1: "p <=XXREAL-0R1 q"
    then have A2: "[.XXREAL-1K1 q,p .] c=MEMBEREDR2 {TARSKIK1 p}"
      using xxreal_1_th_85 sorry
    have "p inHIDDENR3 [.XXREAL-1K1 p,q .]"
      using A1 xxreal_1_th_1 sorry
    then have "{TARSKIK1 p} c=MEMBEREDR2 [.XXREAL-1K1 p,q .]"
      using zfmisc_1_th_31 sorry
    thus "[.XXREAL-1K1 p,q .] =MEMBEREDR8 [.XXREAL-1K1 p,q .] \\/XBOOLE-0K2 [.XXREAL-1K1 q,p .]"
      using A2 xboole_1_th_1 xboole_1_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_223:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & s <=XXREAL-0R1 t implies  not r inHIDDENR3 ].XXREAL-1K4 s,t .[ \\/XBOOLE-0K2 ].XXREAL-1K4 t,p .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & s <=XXREAL-0R1 t implies (r inHIDDENR3 ].XXREAL-1K4 s,t .[ \\/XBOOLE-0K2 ].XXREAL-1K4 t,p .[ implies  False )"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
      and A2: "s <=XXREAL-0R1 t"
    assume "r inHIDDENR3 ].XXREAL-1K4 s,t .[ \\/XBOOLE-0K2 ].XXREAL-1K4 t,p .["
    then have "r inHIDDENR3 ].XXREAL-1K4 s,t .[ or r inHIDDENR3 ].XXREAL-1K4 t,p .["
      using xboole_0_def_3 sorry
    then have "s <XXREAL-0R3 r & r <XXREAL-0R3 t or t <XXREAL-0R3 r & r <XXREAL-0R3 p"
      using xxreal_1_th_4 sorry
    thus " False "
      using A1 A2 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_224:
"REALNUMBERSK2 =MEMBEREDR8 ].XXREAL-1K4 -inftyXXREAL-0K2,+inftyXXREAL-0K1 .["
proof-
  have " for x be ExtRealXXREAL-0M1 holds (x inHIDDENR3 REALNUMBERSK2 implies x inHIDDENR3 ].XXREAL-1K4 -inftyXXREAL-0K2,+inftyXXREAL-0K1 .[) & (x inHIDDENR3 ].XXREAL-1K4 -inftyXXREAL-0K2,+inftyXXREAL-0K1 .[ implies x inHIDDENR3 REALNUMBERSK2)"
  proof(rule ballI,rule conjMI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    show "x inHIDDENR3 REALNUMBERSK2 implies x inHIDDENR3 ].XXREAL-1K4 -inftyXXREAL-0K2,+inftyXXREAL-0K1 .["
    proof(rule impI)
      assume A1: "x inHIDDENR3 REALNUMBERSK2"
      then have A2: "-inftyXXREAL-0K2 <XXREAL-0R3 x"
        using xxreal_0_th_12 sorry
      have "x <XXREAL-0R3 +inftyXXREAL-0K1"
        using A1 xxreal_0_th_9 sorry
      thus "x inHIDDENR3 ].XXREAL-1K4 -inftyXXREAL-0K2,+inftyXXREAL-0K1 .["
        using A2 xxreal_1_th_4 sorry
    qed
    assume A3: "x inHIDDENR3 ].XXREAL-1K4 -inftyXXREAL-0K2,+inftyXXREAL-0K1 .["
    then have A4: "-inftyXXREAL-0K2 <XXREAL-0R3 x"
      using xxreal_1_th_4 sorry
    have "x <XXREAL-0R3 +inftyXXREAL-0K1"
      using A3 xxreal_1_th_4 sorry
    thus "x inHIDDENR3 REALNUMBERSK2"
      using A4 xxreal_0_th_14 sorry
  qed "sorry"
  thus "REALNUMBERSK2 =MEMBEREDR8 ].XXREAL-1K4 -inftyXXREAL-0K2,+inftyXXREAL-0K1 .["
    using membered_def_14 sorry
qed

mtheorem xxreal_1_th_225:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds ].XXREAL-1K4 p,q .[ c=MEMBEREDR2 REALNUMBERSK2"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds ].XXREAL-1K4 p,q .[ c=MEMBEREDR2 REALNUMBERSK2"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 ].XXREAL-1K4 p,q .[ implies x inHIDDENR3 REALNUMBERSK2"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      assume A1: "x inHIDDENR3 ].XXREAL-1K4 p,q .["
      then have A2: "p <XXREAL-0R3 x"
        using xxreal_1_th_4 sorry
      have "x <XXREAL-0R3 q"
        using A1 xxreal_1_th_4 sorry
      thus "x inHIDDENR3 REALNUMBERSK2"
        using A2 xxreal_0_th_48 sorry
    qed "sorry"
    thus "].XXREAL-1K4 p,q .[ c=MEMBEREDR2 REALNUMBERSK2"
      using membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_226:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds p inHIDDENR3 REALNUMBERSK2 implies [.XXREAL-1K2 p,q .[ c=MEMBEREDR2 REALNUMBERSK2"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds p inHIDDENR3 REALNUMBERSK2 implies [.XXREAL-1K2 p,q .[ c=MEMBEREDR2 REALNUMBERSK2"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    assume A1: "p inHIDDENR3 REALNUMBERSK2"
    have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 [.XXREAL-1K2 p,q .[ implies x inHIDDENR3 REALNUMBERSK2"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      assume A2: "x inHIDDENR3 [.XXREAL-1K2 p,q .["
      then have A3: "p <=XXREAL-0R1 x"
        using xxreal_1_th_3 sorry
      have "x <XXREAL-0R3 q"
        using A2 xxreal_1_th_3 sorry
      thus "x inHIDDENR3 REALNUMBERSK2"
        using A1 A3 xxreal_0_th_46 sorry
    qed "sorry"
    thus "[.XXREAL-1K2 p,q .[ c=MEMBEREDR2 REALNUMBERSK2"
      using membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_227:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds q inHIDDENR3 REALNUMBERSK2 implies ].XXREAL-1K3 p,q .] c=MEMBEREDR2 REALNUMBERSK2"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds q inHIDDENR3 REALNUMBERSK2 implies ].XXREAL-1K3 p,q .] c=MEMBEREDR2 REALNUMBERSK2"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    assume A1: "q inHIDDENR3 REALNUMBERSK2"
    have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 ].XXREAL-1K3 p,q .] implies x inHIDDENR3 REALNUMBERSK2"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      assume A2: "x inHIDDENR3 ].XXREAL-1K3 p,q .]"
      then have A3: "p <XXREAL-0R3 x"
        using xxreal_1_th_2 sorry
      have "x <=XXREAL-0R1 q"
        using A2 xxreal_1_th_2 sorry
      thus "x inHIDDENR3 REALNUMBERSK2"
        using A1 A3 xxreal_0_th_47 sorry
    qed "sorry"
    thus "].XXREAL-1K3 p,q .] c=MEMBEREDR2 REALNUMBERSK2"
      using membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_228:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds p inHIDDENR3 REALNUMBERSK2 & q inHIDDENR3 REALNUMBERSK2 implies [.XXREAL-1K1 p,q .] c=MEMBEREDR2 REALNUMBERSK2"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds p inHIDDENR3 REALNUMBERSK2 & q inHIDDENR3 REALNUMBERSK2 implies [.XXREAL-1K1 p,q .] c=MEMBEREDR2 REALNUMBERSK2"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    assume A1: "p inHIDDENR3 REALNUMBERSK2"
      and A2: "q inHIDDENR3 REALNUMBERSK2"
    have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 [.XXREAL-1K1 p,q .] implies x inHIDDENR3 REALNUMBERSK2"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      assume A3: "x inHIDDENR3 [.XXREAL-1K1 p,q .]"
      then have A4: "p <=XXREAL-0R1 x"
        using xxreal_1_th_1 sorry
      have "x <=XXREAL-0R1 q"
        using A3 xxreal_1_th_1 sorry
      thus "x inHIDDENR3 REALNUMBERSK2"
        using A1 A2 A4 xxreal_0_th_45 sorry
    qed "sorry"
    thus "[.XXREAL-1K1 p,q .] c=MEMBEREDR2 REALNUMBERSK2"
      using membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_cl_9:
  mlet "p be ExtRealXXREAL-0M1", "q be ExtRealXXREAL-0M1"
"cluster ].XXREAL-1K4 p,q .[ as-term-is real-memberedMEMBEREDV3"
proof
(*coherence*)
  show "].XXREAL-1K4 p,q .[ be real-memberedMEMBEREDV3"
    using xxreal_1_th_225 membered_th_21 sorry
qed "sorry"

mtheorem xxreal_1_cl_10:
  mlet "p be RealXREAL-0M1", "q be ExtRealXXREAL-0M1"
"cluster [.XXREAL-1K2 p,q .[ as-term-is real-memberedMEMBEREDV3"
proof
(*coherence*)
  show "[.XXREAL-1K2 p,q .[ be real-memberedMEMBEREDV3"
  proof-
    have "p inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    then have "[.XXREAL-1K2 p,q .[ c=MEMBEREDR2 REALNUMBERSK2"
      using xxreal_1_th_226 sorry
    thus "[.XXREAL-1K2 p,q .[ be real-memberedMEMBEREDV3"
       sorry
  qed
qed "sorry"

mtheorem xxreal_1_cl_11:
  mlet "q be RealXREAL-0M1", "p be ExtRealXXREAL-0M1"
"cluster ].XXREAL-1K3 p,q .] as-term-is real-memberedMEMBEREDV3"
proof
(*coherence*)
  show "].XXREAL-1K3 p,q .] be real-memberedMEMBEREDV3"
  proof-
    have "q inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    then have "].XXREAL-1K3 p,q .] c=MEMBEREDR2 REALNUMBERSK2"
      using xxreal_1_th_227 sorry
    thus "].XXREAL-1K3 p,q .] be real-memberedMEMBEREDV3"
       sorry
  qed
qed "sorry"

mtheorem xxreal_1_cl_12:
  mlet "p be RealXREAL-0M1", "q be RealXREAL-0M1"
"cluster [.XXREAL-1K1 p,q .] as-term-is real-memberedMEMBEREDV3"
proof
(*coherence*)
  show "[.XXREAL-1K1 p,q .] be real-memberedMEMBEREDV3"
  proof-
    have A1: "p inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    have "q inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    then have "[.XXREAL-1K1 p,q .] c=MEMBEREDR2 REALNUMBERSK2"
      using A1 xxreal_1_th_228 sorry
    thus "[.XXREAL-1K1 p,q .] be real-memberedMEMBEREDV3"
       sorry
  qed
qed "sorry"

mtheorem xxreal_1_th_229:
" for s be ExtRealXXREAL-0M1 holds ].XXREAL-1K4 -inftyXXREAL-0K2,s .[ =XBOOLE-0R4 {g where g be RealXREAL-0M1 : g <XXREAL-0R3 s }"
proof-
  have " for s be ExtRealXXREAL-0M1 holds ].XXREAL-1K4 -inftyXXREAL-0K2,s .[ =XBOOLE-0R4 {g where g be RealXREAL-0M1 :  not g <XXREAL-0R3 s }"
  proof(rule ballI)
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "].XXREAL-1K4 -inftyXXREAL-0K2,s .[ c=MEMBEREDR3 {g where g be RealXREAL-0M1 : g <XXREAL-0R3 s } & {g where g be RealXREAL-0M1 :  not g <XXREAL-0R3 s } c=TARSKIR1 ].XXREAL-1K4 -inftyXXREAL-0K2,s .["
    proof(rule conjMI)
      show "].XXREAL-1K4 -inftyXXREAL-0K2,s .[ c=MEMBEREDR3 {g where g be RealXREAL-0M1 : g <XXREAL-0R3 s }"
      proof-
        have "].XXREAL-1K4 -inftyXXREAL-0K2,s .[ c=MEMBEREDR3 {g where g be RealXREAL-0M1 :  not g <XXREAL-0R3 s }"
        proof-
          have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].XXREAL-1K4 -inftyXXREAL-0K2,s .[ implies x inHIDDENR3 {g where g be RealXREAL-0M1 :  not g <XXREAL-0R3 s }"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be RealXREAL-0M1"
            assume A1: "x inHIDDENR3 ].XXREAL-1K4 -inftyXXREAL-0K2,s .["
            have A2: "x <XXREAL-0R3 s"
              using A1 xxreal_1_th_4 sorry
            show "x inHIDDENR3 {g where g be RealXREAL-0M1 :  not g <XXREAL-0R3 s }"
              using A2 sorry
          qed "sorry"
          thus "].XXREAL-1K4 -inftyXXREAL-0K2,s .[ c=MEMBEREDR3 {g where g be RealXREAL-0M1 :  not g <XXREAL-0R3 s }"
            using membered_def_9 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 {g where g be RealXREAL-0M1 : g <XXREAL-0R3 s } implies x inHIDDENR3 ].XXREAL-1K4 -inftyXXREAL-0K2,s .["
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 {g where g be RealXREAL-0M1 : g <XXREAL-0R3 s }"
        then obtain g where
          [ty]:"g be RealXREAL-0M1" and 
          A3: "x =HIDDENR1 g"and A4: "g <XXREAL-0R3 s"
           sorry
        have "g inHIDDENR3 REALNUMBERSK2"
          using xreal_0_def_1 sorry
        then have "-inftyXXREAL-0K2 <XXREAL-0R3 g"
          using xxreal_0_th_12 sorry
        thus "x inHIDDENR3 ].XXREAL-1K4 -inftyXXREAL-0K2,s .["
          using A3 A4 xxreal_1_th_4 sorry
      qed "sorry"
      thus "{g where g be RealXREAL-0M1 :  not g <XXREAL-0R3 s } c=TARSKIR1 ].XXREAL-1K4 -inftyXXREAL-0K2,s .["
        using tarski_def_3 sorry
    qed
    thus "].XXREAL-1K4 -inftyXXREAL-0K2,s .[ =XBOOLE-0R4 {g where g be RealXREAL-0M1 :  not g <XXREAL-0R3 s }"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_230:
" for s be ExtRealXXREAL-0M1 holds ].XXREAL-1K4 s,+inftyXXREAL-0K1 .[ =XBOOLE-0R4 {g where g be RealXREAL-0M1 : s <XXREAL-0R3 g }"
proof-
  have " for s be ExtRealXXREAL-0M1 holds ].XXREAL-1K4 s,+inftyXXREAL-0K1 .[ =XBOOLE-0R4 {g where g be RealXREAL-0M1 :  not s <XXREAL-0R3 g }"
  proof(rule ballI)
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "].XXREAL-1K4 s,+inftyXXREAL-0K1 .[ c=MEMBEREDR3 {g where g be RealXREAL-0M1 : s <XXREAL-0R3 g } & {g where g be RealXREAL-0M1 :  not s <XXREAL-0R3 g } c=TARSKIR1 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .["
    proof(rule conjMI)
      show "].XXREAL-1K4 s,+inftyXXREAL-0K1 .[ c=MEMBEREDR3 {g where g be RealXREAL-0M1 : s <XXREAL-0R3 g }"
      proof-
        have "].XXREAL-1K4 s,+inftyXXREAL-0K1 .[ c=MEMBEREDR3 {g where g be RealXREAL-0M1 :  not s <XXREAL-0R3 g }"
        proof-
          have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .[ implies x inHIDDENR3 {g where g be RealXREAL-0M1 :  not s <XXREAL-0R3 g }"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be RealXREAL-0M1"
            assume "x inHIDDENR3 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .["
            then have A1: "s <XXREAL-0R3 x"
              using xxreal_1_th_4 sorry
            show "x inHIDDENR3 {g where g be RealXREAL-0M1 :  not s <XXREAL-0R3 g }"
              using A1 sorry
          qed "sorry"
          thus "].XXREAL-1K4 s,+inftyXXREAL-0K1 .[ c=MEMBEREDR3 {g where g be RealXREAL-0M1 :  not s <XXREAL-0R3 g }"
            using membered_def_9 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 {g where g be RealXREAL-0M1 : s <XXREAL-0R3 g } implies x inHIDDENR3 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .["
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 {g where g be RealXREAL-0M1 : s <XXREAL-0R3 g }"
        then obtain g where
          [ty]:"g be RealXREAL-0M1" and 
          A2: "x =HIDDENR1 g"and A3: "s <XXREAL-0R3 g"
           sorry
        have "g inHIDDENR3 REALNUMBERSK2"
          using xreal_0_def_1 sorry
        then have "g <XXREAL-0R3 +inftyXXREAL-0K1"
          using xxreal_0_th_9 sorry
        thus "x inHIDDENR3 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .["
          using A2 A3 xxreal_1_th_4 sorry
      qed "sorry"
      thus "{g where g be RealXREAL-0M1 :  not s <XXREAL-0R3 g } c=TARSKIR1 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .["
        using tarski_def_3 sorry
    qed
    thus "].XXREAL-1K4 s,+inftyXXREAL-0K1 .[ =XBOOLE-0R4 {g where g be RealXREAL-0M1 :  not s <XXREAL-0R3 g }"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_231:
" for s be RealXREAL-0M1 holds ].XXREAL-1K3 -inftyXXREAL-0K2,s .] =XBOOLE-0R4 {g where g be RealXREAL-0M1 : g <=XXREAL-0R1 s }"
proof-
  have " for s be RealXREAL-0M1 holds ].XXREAL-1K3 -inftyXXREAL-0K2,s .] =XBOOLE-0R4 {g where g be RealXREAL-0M1 : g <=XXREAL-0R1 s }"
  proof(rule ballI)
    fix s assume [ty]: "s be RealXREAL-0M1"
    have "].XXREAL-1K3 -inftyXXREAL-0K2,s .] c=MEMBEREDR3 {g where g be RealXREAL-0M1 : g <=XXREAL-0R1 s } & {g where g be RealXREAL-0M1 : g <=XXREAL-0R1 s } c=TARSKIR1 ].XXREAL-1K3 -inftyXXREAL-0K2,s .]"
    proof(rule conjMI)
      show "].XXREAL-1K3 -inftyXXREAL-0K2,s .] c=MEMBEREDR3 {g where g be RealXREAL-0M1 : g <=XXREAL-0R1 s }"
      proof-
        have "].XXREAL-1K3 -inftyXXREAL-0K2,s .] c=MEMBEREDR3 {g where g be RealXREAL-0M1 : g <=XXREAL-0R1 s }"
        proof-
          have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].XXREAL-1K3 -inftyXXREAL-0K2,s .] implies x inHIDDENR3 {g where g be RealXREAL-0M1 : g <=XXREAL-0R1 s }"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be RealXREAL-0M1"
            assume "x inHIDDENR3 ].XXREAL-1K3 -inftyXXREAL-0K2,s .]"
            then have A1: "x <=XXREAL-0R1 s"
              using xxreal_1_th_2 sorry
            show "x inHIDDENR3 {g where g be RealXREAL-0M1 : g <=XXREAL-0R1 s }"
              using A1 sorry
          qed "sorry"
          thus "].XXREAL-1K3 -inftyXXREAL-0K2,s .] c=MEMBEREDR3 {g where g be RealXREAL-0M1 : g <=XXREAL-0R1 s }"
            using membered_def_9 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 {g where g be RealXREAL-0M1 : g <=XXREAL-0R1 s } implies x inHIDDENR3 ].XXREAL-1K3 -inftyXXREAL-0K2,s .]"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 {g where g be RealXREAL-0M1 : g <=XXREAL-0R1 s }"
        then obtain g where
          [ty]:"g be RealXREAL-0M1" and 
          A2: "x =HIDDENR1 g"and A3: "g <=XXREAL-0R1 s"
           sorry
        have "g inHIDDENR3 REALNUMBERSK2"
          using xreal_0_def_1 sorry
        then have "-inftyXXREAL-0K2 <XXREAL-0R3 g"
          using xxreal_0_th_12 sorry
        thus "x inHIDDENR3 ].XXREAL-1K3 -inftyXXREAL-0K2,s .]"
          using A2 A3 xxreal_1_th_2 sorry
      qed "sorry"
      thus "{g where g be RealXREAL-0M1 : g <=XXREAL-0R1 s } c=TARSKIR1 ].XXREAL-1K3 -inftyXXREAL-0K2,s .]"
        using tarski_def_3 sorry
    qed
    thus "].XXREAL-1K3 -inftyXXREAL-0K2,s .] =XBOOLE-0R4 {g where g be RealXREAL-0M1 : g <=XXREAL-0R1 s }"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_232:
" for s be RealXREAL-0M1 holds [.XXREAL-1K2 s,+inftyXXREAL-0K1 .[ =XBOOLE-0R4 {g where g be RealXREAL-0M1 : s <=XXREAL-0R1 g }"
proof-
  have " for s be RealXREAL-0M1 holds [.XXREAL-1K2 s,+inftyXXREAL-0K1 .[ =XBOOLE-0R4 {g where g be RealXREAL-0M1 : s <=XXREAL-0R1 g }"
  proof(rule ballI)
    fix s assume [ty]: "s be RealXREAL-0M1"
    have "[.XXREAL-1K2 s,+inftyXXREAL-0K1 .[ c=MEMBEREDR3 {g where g be RealXREAL-0M1 : s <=XXREAL-0R1 g } & {g where g be RealXREAL-0M1 : s <=XXREAL-0R1 g } c=TARSKIR1 [.XXREAL-1K2 s,+inftyXXREAL-0K1 .["
    proof(rule conjMI)
      show "[.XXREAL-1K2 s,+inftyXXREAL-0K1 .[ c=MEMBEREDR3 {g where g be RealXREAL-0M1 : s <=XXREAL-0R1 g }"
      proof-
        have "[.XXREAL-1K2 s,+inftyXXREAL-0K1 .[ c=MEMBEREDR3 {g where g be RealXREAL-0M1 : s <=XXREAL-0R1 g }"
        proof-
          have " for x be RealXREAL-0M1 holds x inHIDDENR3 [.XXREAL-1K2 s,+inftyXXREAL-0K1 .[ implies x inHIDDENR3 {g where g be RealXREAL-0M1 : s <=XXREAL-0R1 g }"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be RealXREAL-0M1"
            assume "x inHIDDENR3 [.XXREAL-1K2 s,+inftyXXREAL-0K1 .["
            then have A1: "s <=XXREAL-0R1 x"
              using xxreal_1_th_3 sorry
            show "x inHIDDENR3 {g where g be RealXREAL-0M1 : s <=XXREAL-0R1 g }"
              using A1 sorry
          qed "sorry"
          thus "[.XXREAL-1K2 s,+inftyXXREAL-0K1 .[ c=MEMBEREDR3 {g where g be RealXREAL-0M1 : s <=XXREAL-0R1 g }"
            using membered_def_9 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 {g where g be RealXREAL-0M1 : s <=XXREAL-0R1 g } implies x inHIDDENR3 [.XXREAL-1K2 s,+inftyXXREAL-0K1 .["
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 {g where g be RealXREAL-0M1 : s <=XXREAL-0R1 g }"
        then obtain g where
          [ty]:"g be RealXREAL-0M1" and 
          A2: "x =HIDDENR1 g"and A3: "s <=XXREAL-0R1 g"
           sorry
        have "g inHIDDENR3 REALNUMBERSK2"
          using xreal_0_def_1 sorry
        then have "g <XXREAL-0R3 +inftyXXREAL-0K1"
          using xxreal_0_th_9 sorry
        thus "x inHIDDENR3 [.XXREAL-1K2 s,+inftyXXREAL-0K1 .["
          using A2 A3 xxreal_1_th_3 sorry
      qed "sorry"
      thus "{g where g be RealXREAL-0M1 : s <=XXREAL-0R1 g } c=TARSKIR1 [.XXREAL-1K2 s,+inftyXXREAL-0K1 .["
        using tarski_def_3 sorry
    qed
    thus "[.XXREAL-1K2 s,+inftyXXREAL-0K1 .[ =XBOOLE-0R4 {g where g be RealXREAL-0M1 : s <=XXREAL-0R1 g }"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_233:
" for u be ExtRealXXREAL-0M1 holds  for x be RealXREAL-0M1 holds x inHIDDENR3 ].XXREAL-1K4 -inftyXXREAL-0K2,u .[ iff x <XXREAL-0R3 u"
proof-
  have " for u be ExtRealXXREAL-0M1 holds  for x be RealXREAL-0M1 holds  not (x inHIDDENR3 ].XXREAL-1K4 -inftyXXREAL-0K2,u .[ & x <XXREAL-0R3 u) &  not ( not x <XXREAL-0R3 u &  not x inHIDDENR3 ].XXREAL-1K4 -inftyXXREAL-0K2,u .[)"
  proof(rule ballI,rule ballI)
    fix u assume [ty]: "u be ExtRealXXREAL-0M1"
    fix x assume [ty]: "x be RealXREAL-0M1"
    have "x inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    then have "-inftyXXREAL-0K2 <XXREAL-0R3 x"
      using xxreal_0_th_12 sorry
    thus " not (x inHIDDENR3 ].XXREAL-1K4 -inftyXXREAL-0K2,u .[ & x <XXREAL-0R3 u) &  not ( not x <XXREAL-0R3 u &  not x inHIDDENR3 ].XXREAL-1K4 -inftyXXREAL-0K2,u .[)"
      using xxreal_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_234:
" for u be ExtRealXXREAL-0M1 holds  for x be RealXREAL-0M1 holds x inHIDDENR3 ].XXREAL-1K3 -inftyXXREAL-0K2,u .] iff x <=XXREAL-0R1 u"
proof-
  have " for u be ExtRealXXREAL-0M1 holds  for x be RealXREAL-0M1 holds  not (x inHIDDENR3 ].XXREAL-1K3 -inftyXXREAL-0K2,u .] &  not x <=XXREAL-0R1 u) &  not (x <=XXREAL-0R1 u &  not x inHIDDENR3 ].XXREAL-1K3 -inftyXXREAL-0K2,u .])"
  proof(rule ballI,rule ballI)
    fix u assume [ty]: "u be ExtRealXXREAL-0M1"
    fix x assume [ty]: "x be RealXREAL-0M1"
    have "x inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    then have "-inftyXXREAL-0K2 <XXREAL-0R3 x"
      using xxreal_0_th_12 sorry
    thus " not (x inHIDDENR3 ].XXREAL-1K3 -inftyXXREAL-0K2,u .] &  not x <=XXREAL-0R1 u) &  not (x <=XXREAL-0R1 u &  not x inHIDDENR3 ].XXREAL-1K3 -inftyXXREAL-0K2,u .])"
      using xxreal_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_235:
" for u be ExtRealXXREAL-0M1 holds  for x be RealXREAL-0M1 holds x inHIDDENR3 ].XXREAL-1K4 u,+inftyXXREAL-0K1 .[ iff u <XXREAL-0R3 x"
proof-
  have " for u be ExtRealXXREAL-0M1 holds  for x be RealXREAL-0M1 holds  not (x inHIDDENR3 ].XXREAL-1K4 u,+inftyXXREAL-0K1 .[ & u <XXREAL-0R3 x) &  not ( not u <XXREAL-0R3 x &  not x inHIDDENR3 ].XXREAL-1K4 u,+inftyXXREAL-0K1 .[)"
  proof(rule ballI,rule ballI)
    fix u assume [ty]: "u be ExtRealXXREAL-0M1"
    fix x assume [ty]: "x be RealXREAL-0M1"
    have "x inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    then have "x <XXREAL-0R3 +inftyXXREAL-0K1"
      using xxreal_0_th_9 sorry
    thus " not (x inHIDDENR3 ].XXREAL-1K4 u,+inftyXXREAL-0K1 .[ & u <XXREAL-0R3 x) &  not ( not u <XXREAL-0R3 x &  not x inHIDDENR3 ].XXREAL-1K4 u,+inftyXXREAL-0K1 .[)"
      using xxreal_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_236:
" for u be ExtRealXXREAL-0M1 holds  for x be RealXREAL-0M1 holds x inHIDDENR3 [.XXREAL-1K2 u,+inftyXXREAL-0K1 .[ iff u <=XXREAL-0R1 x"
proof-
  have " for u be ExtRealXXREAL-0M1 holds  for x be RealXREAL-0M1 holds  not (x inHIDDENR3 [.XXREAL-1K2 u,+inftyXXREAL-0K1 .[ &  not u <=XXREAL-0R1 x) &  not (u <=XXREAL-0R1 x &  not x inHIDDENR3 [.XXREAL-1K2 u,+inftyXXREAL-0K1 .[)"
  proof(rule ballI,rule ballI)
    fix u assume [ty]: "u be ExtRealXXREAL-0M1"
    fix x assume [ty]: "x be RealXREAL-0M1"
    have "x inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    then have "x <XXREAL-0R3 +inftyXXREAL-0K1"
      using xxreal_0_th_9 sorry
    thus " not (x inHIDDENR3 [.XXREAL-1K2 u,+inftyXXREAL-0K1 .[ &  not u <=XXREAL-0R1 x) &  not (u <=XXREAL-0R1 x &  not x inHIDDENR3 [.XXREAL-1K2 u,+inftyXXREAL-0K1 .[)"
      using xxreal_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_237:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r implies [.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,+inftyXXREAL-0K1 .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not (p <=XXREAL-0R1 r &  not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,+inftyXXREAL-0K1 .])"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "s <=XXREAL-0R1 +inftyXXREAL-0K1"
      using xxreal_0_th_3 sorry
    thus " not (p <=XXREAL-0R1 r &  not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,+inftyXXREAL-0K1 .])"
      using xxreal_1_th_34 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_238:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r implies [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,+inftyXXREAL-0K1 .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not (p <=XXREAL-0R1 r &  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,+inftyXXREAL-0K1 .])"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "s <=XXREAL-0R1 +inftyXXREAL-0K1"
      using xxreal_0_th_3 sorry
    thus " not (p <=XXREAL-0R1 r &  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 p,+inftyXXREAL-0K1 .])"
      using xxreal_1_th_35 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_239:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r implies ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,+inftyXXREAL-0K1 .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not (p <=XXREAL-0R1 r &  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,+inftyXXREAL-0K1 .])"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "s <=XXREAL-0R1 +inftyXXREAL-0K1"
      using xxreal_0_th_3 sorry
    thus " not (p <=XXREAL-0R1 r &  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 p,+inftyXXREAL-0K1 .])"
      using xxreal_1_th_36 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_240:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r implies ].XXREAL-1K4 r,s .[ c=MEMBEREDR3 [.XXREAL-1K1 p,+inftyXXREAL-0K1 .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not (p <=XXREAL-0R1 r &  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR3 [.XXREAL-1K1 p,+inftyXXREAL-0K1 .])"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "s <=XXREAL-0R1 +inftyXXREAL-0K1"
      using xxreal_0_th_3 sorry
    thus " not (p <=XXREAL-0R1 r &  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR3 [.XXREAL-1K1 p,+inftyXXREAL-0K1 .])"
      using xxreal_1_th_37 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_241:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r implies [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,+inftyXXREAL-0K1 .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not (p <=XXREAL-0R1 r &  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,+inftyXXREAL-0K1 .[)"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "s <=XXREAL-0R1 +inftyXXREAL-0K1"
      using xxreal_0_th_3 sorry
    thus " not (p <=XXREAL-0R1 r &  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 p,+inftyXXREAL-0K1 .[)"
      using xxreal_1_th_38 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_242:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <XXREAL-0R3 r implies [.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,+inftyXXREAL-0K1 .]"
  using xxreal_1_th_39 xxreal_0_th_3 sorry

mtheorem xxreal_1_th_243:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <XXREAL-0R3 r implies [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 ].XXREAL-1K3 p,+inftyXXREAL-0K1 .]"
  using xxreal_1_th_40 xxreal_0_th_3 sorry

mtheorem xxreal_1_th_244:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r implies ].XXREAL-1K4 r,s .[ c=MEMBEREDR3 ].XXREAL-1K3 p,+inftyXXREAL-0K1 .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not (p <=XXREAL-0R1 r &  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR3 ].XXREAL-1K3 p,+inftyXXREAL-0K1 .])"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "s <=XXREAL-0R1 +inftyXXREAL-0K1"
      using xxreal_0_th_3 sorry
    thus " not (p <=XXREAL-0R1 r &  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR3 ].XXREAL-1K3 p,+inftyXXREAL-0K1 .])"
      using xxreal_1_th_41 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_245:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r implies ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,+inftyXXREAL-0K1 .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not (p <=XXREAL-0R1 r &  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,+inftyXXREAL-0K1 .])"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "s <=XXREAL-0R1 +inftyXXREAL-0K1"
      using xxreal_0_th_3 sorry
    thus " not (p <=XXREAL-0R1 r &  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 p,+inftyXXREAL-0K1 .])"
      using xxreal_1_th_42 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_246:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r implies ].XXREAL-1K4 r,s .[ c=MEMBEREDR3 [.XXREAL-1K2 p,+inftyXXREAL-0K1 .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not (p <=XXREAL-0R1 r &  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR3 [.XXREAL-1K2 p,+inftyXXREAL-0K1 .[)"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "s <=XXREAL-0R1 +inftyXXREAL-0K1"
      using xxreal_0_th_3 sorry
    thus " not (p <=XXREAL-0R1 r &  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR3 [.XXREAL-1K2 p,+inftyXXREAL-0K1 .[)"
      using xxreal_1_th_45 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_247:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 r implies ].XXREAL-1K4 r,s .[ c=MEMBEREDR3 ].XXREAL-1K4 p,+inftyXXREAL-0K1 .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not (p <=XXREAL-0R1 r &  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR3 ].XXREAL-1K4 p,+inftyXXREAL-0K1 .[)"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "s <=XXREAL-0R1 +inftyXXREAL-0K1"
      using xxreal_0_th_3 sorry
    thus " not (p <=XXREAL-0R1 r &  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR3 ].XXREAL-1K4 p,+inftyXXREAL-0K1 .[)"
      using xxreal_1_th_46 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_248:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <XXREAL-0R3 r implies [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 ].XXREAL-1K4 p,+inftyXXREAL-0K1 .["
  using xxreal_1_th_48 xxreal_0_th_3 sorry

mtheorem xxreal_1_th_249:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds p <XXREAL-0R3 r implies [.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 p,+inftyXXREAL-0K1 .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not ( not p <XXREAL-0R3 r &  not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 p,+inftyXXREAL-0K1 .[)"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    have "s inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    then have "s <XXREAL-0R3 +inftyXXREAL-0K1"
      using xxreal_0_th_9 sorry
    thus " not ( not p <XXREAL-0R3 r &  not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 p,+inftyXXREAL-0K1 .[)"
      using xxreal_1_th_47 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_250:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds p <=XXREAL-0R1 r implies ].XXREAL-1K3 r,s .] c=MEMBEREDR3 ].XXREAL-1K4 p,+inftyXXREAL-0K1 .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not (p <=XXREAL-0R1 r &  not ].XXREAL-1K3 r,s .] c=MEMBEREDR3 ].XXREAL-1K4 p,+inftyXXREAL-0K1 .[)"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    have "s inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    thus " not (p <=XXREAL-0R1 r &  not ].XXREAL-1K3 r,s .] c=MEMBEREDR3 ].XXREAL-1K4 p,+inftyXXREAL-0K1 .[)"
      using xxreal_1_th_49 xxreal_0_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_251:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds p <=XXREAL-0R1 r implies [.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K2 p,+inftyXXREAL-0K1 .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not (p <=XXREAL-0R1 r &  not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K2 p,+inftyXXREAL-0K1 .[)"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    have "s inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    thus " not (p <=XXREAL-0R1 r &  not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K2 p,+inftyXXREAL-0K1 .[)"
      using xxreal_1_th_43 xxreal_0_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_252:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds p <=XXREAL-0R1 r implies ].XXREAL-1K3 r,s .] c=MEMBEREDR3 [.XXREAL-1K2 p,+inftyXXREAL-0K1 .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not (p <=XXREAL-0R1 r &  not ].XXREAL-1K3 r,s .] c=MEMBEREDR3 [.XXREAL-1K2 p,+inftyXXREAL-0K1 .[)"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    have "s inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    thus " not (p <=XXREAL-0R1 r &  not ].XXREAL-1K3 r,s .] c=MEMBEREDR3 [.XXREAL-1K2 p,+inftyXXREAL-0K1 .[)"
      using xxreal_1_th_44 xxreal_0_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_253:
" for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 q implies [.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 -inftyXXREAL-0K2,q .]"
proof-
  have " for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not (s <=XXREAL-0R1 q &  not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 -inftyXXREAL-0K2,q .])"
  proof(rule ballI,rule ballI,rule ballI)
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "-inftyXXREAL-0K2 <=XXREAL-0R1 r"
      using xxreal_0_th_5 sorry
    thus " not (s <=XXREAL-0R1 q &  not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 -inftyXXREAL-0K2,q .])"
      using xxreal_1_th_34 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_254:
" for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 q implies [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 -inftyXXREAL-0K2,q .]"
proof-
  have " for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not (s <=XXREAL-0R1 q &  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 -inftyXXREAL-0K2,q .])"
  proof(rule ballI,rule ballI,rule ballI)
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "-inftyXXREAL-0K2 <=XXREAL-0R1 r"
      using xxreal_0_th_5 sorry
    thus " not (s <=XXREAL-0R1 q &  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K1 -inftyXXREAL-0K2,q .])"
      using xxreal_1_th_35 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_255:
" for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 q implies ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 -inftyXXREAL-0K2,q .]"
proof-
  have " for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not (s <=XXREAL-0R1 q &  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 -inftyXXREAL-0K2,q .])"
  proof(rule ballI,rule ballI,rule ballI)
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "-inftyXXREAL-0K2 <=XXREAL-0R1 r"
      using xxreal_0_th_5 sorry
    thus " not (s <=XXREAL-0R1 q &  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K1 -inftyXXREAL-0K2,q .])"
      using xxreal_1_th_36 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_256:
" for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 q implies ].XXREAL-1K4 r,s .[ c=MEMBEREDR3 [.XXREAL-1K1 -inftyXXREAL-0K2,q .]"
proof-
  have " for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not (s <=XXREAL-0R1 q &  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR3 [.XXREAL-1K1 -inftyXXREAL-0K2,q .])"
  proof(rule ballI,rule ballI,rule ballI)
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "-inftyXXREAL-0K2 <=XXREAL-0R1 r"
      using xxreal_0_th_5 sorry
    thus " not (s <=XXREAL-0R1 q &  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR3 [.XXREAL-1K1 -inftyXXREAL-0K2,q .])"
      using xxreal_1_th_37 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_257:
" for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 q implies [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 -inftyXXREAL-0K2,q .["
proof-
  have " for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not (s <=XXREAL-0R1 q &  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 -inftyXXREAL-0K2,q .[)"
  proof(rule ballI,rule ballI,rule ballI)
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "-inftyXXREAL-0K2 <=XXREAL-0R1 r"
      using xxreal_0_th_5 sorry
    thus " not (s <=XXREAL-0R1 q &  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR2 [.XXREAL-1K2 -inftyXXREAL-0K2,q .[)"
      using xxreal_1_th_38 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_258:
" for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 q implies ].XXREAL-1K4 r,s .[ c=MEMBEREDR3 ].XXREAL-1K3 -inftyXXREAL-0K2,q .]"
proof-
  have " for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not (s <=XXREAL-0R1 q &  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR3 ].XXREAL-1K3 -inftyXXREAL-0K2,q .])"
  proof(rule ballI,rule ballI,rule ballI)
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "-inftyXXREAL-0K2 <=XXREAL-0R1 r"
      using xxreal_0_th_5 sorry
    thus " not (s <=XXREAL-0R1 q &  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR3 ].XXREAL-1K3 -inftyXXREAL-0K2,q .])"
      using xxreal_1_th_41 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_259:
" for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 q implies ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 -inftyXXREAL-0K2,q .]"
proof-
  have " for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not (s <=XXREAL-0R1 q &  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 -inftyXXREAL-0K2,q .])"
  proof(rule ballI,rule ballI,rule ballI)
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "-inftyXXREAL-0K2 <=XXREAL-0R1 r"
      using xxreal_0_th_5 sorry
    thus " not (s <=XXREAL-0R1 q &  not ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 -inftyXXREAL-0K2,q .])"
      using xxreal_1_th_42 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_260:
" for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <XXREAL-0R3 q implies [.XXREAL-1K1 r,s .] c=MEMBEREDR2 [.XXREAL-1K2 -inftyXXREAL-0K2,q .["
  using xxreal_1_th_43 xxreal_0_th_5 sorry

mtheorem xxreal_1_th_261:
" for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <XXREAL-0R3 q implies ].XXREAL-1K3 r,s .] c=MEMBEREDR2 [.XXREAL-1K2 -inftyXXREAL-0K2,q .["
  using xxreal_1_th_44 xxreal_0_th_5 sorry

mtheorem xxreal_1_th_262:
" for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 q implies ].XXREAL-1K4 r,s .[ c=MEMBEREDR3 [.XXREAL-1K2 -inftyXXREAL-0K2,q .["
proof-
  have " for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not (s <=XXREAL-0R1 q &  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR3 [.XXREAL-1K2 -inftyXXREAL-0K2,q .[)"
  proof(rule ballI,rule ballI,rule ballI)
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "-inftyXXREAL-0K2 <=XXREAL-0R1 r"
      using xxreal_0_th_5 sorry
    thus " not (s <=XXREAL-0R1 q &  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR3 [.XXREAL-1K2 -inftyXXREAL-0K2,q .[)"
      using xxreal_1_th_45 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_263:
" for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 q implies ].XXREAL-1K4 r,s .[ c=MEMBEREDR3 ].XXREAL-1K4 -inftyXXREAL-0K2,q .["
proof-
  have " for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not (s <=XXREAL-0R1 q &  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR3 ].XXREAL-1K4 -inftyXXREAL-0K2,q .[)"
  proof(rule ballI,rule ballI,rule ballI)
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "-inftyXXREAL-0K2 <=XXREAL-0R1 r"
      using xxreal_0_th_5 sorry
    thus " not (s <=XXREAL-0R1 q &  not ].XXREAL-1K4 r,s .[ c=MEMBEREDR3 ].XXREAL-1K4 -inftyXXREAL-0K2,q .[)"
      using xxreal_1_th_46 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_264:
" for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <XXREAL-0R3 q implies ].XXREAL-1K3 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 -inftyXXREAL-0K2,q .["
  using xxreal_1_th_49 xxreal_0_th_5 sorry

mtheorem xxreal_1_th_265:
" for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for r be RealXREAL-0M1 holds s <=XXREAL-0R1 q implies [.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 -inftyXXREAL-0K2,q .]"
proof-
  have " for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for r be RealXREAL-0M1 holds  not (s <=XXREAL-0R1 q &  not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 -inftyXXREAL-0K2,q .])"
  proof(rule ballI,rule ballI,rule ballI)
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    have "r inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    thus " not (s <=XXREAL-0R1 q &  not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K3 -inftyXXREAL-0K2,q .])"
      using xxreal_1_th_39 xxreal_0_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_266:
" for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for r be RealXREAL-0M1 holds s <=XXREAL-0R1 q implies [.XXREAL-1K2 r,s .[ c=MEMBEREDR3 ].XXREAL-1K3 -inftyXXREAL-0K2,q .]"
proof-
  have " for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for r be RealXREAL-0M1 holds  not (s <=XXREAL-0R1 q &  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR3 ].XXREAL-1K3 -inftyXXREAL-0K2,q .])"
  proof(rule ballI,rule ballI,rule ballI)
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    have "r inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    thus " not (s <=XXREAL-0R1 q &  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR3 ].XXREAL-1K3 -inftyXXREAL-0K2,q .])"
      using xxreal_1_th_40 xxreal_0_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_267:
" for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for r be RealXREAL-0M1 holds s <XXREAL-0R3 q implies [.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 -inftyXXREAL-0K2,q .["
proof-
  have " for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for r be RealXREAL-0M1 holds  not ( not s <XXREAL-0R3 q &  not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 -inftyXXREAL-0K2,q .[)"
  proof(rule ballI,rule ballI,rule ballI)
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    have "r inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    then have "-inftyXXREAL-0K2 <XXREAL-0R3 r"
      using xxreal_0_th_12 sorry
    thus " not ( not s <XXREAL-0R3 q &  not [.XXREAL-1K1 r,s .] c=MEMBEREDR2 ].XXREAL-1K4 -inftyXXREAL-0K2,q .[)"
      using xxreal_1_th_47 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_268:
" for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for r be RealXREAL-0M1 holds s <=XXREAL-0R1 q implies [.XXREAL-1K2 r,s .[ c=MEMBEREDR3 ].XXREAL-1K4 -inftyXXREAL-0K2,q .["
proof-
  have " for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for r be RealXREAL-0M1 holds  not (s <=XXREAL-0R1 q &  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR3 ].XXREAL-1K4 -inftyXXREAL-0K2,q .[)"
  proof(rule ballI,rule ballI,rule ballI)
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    have "r inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    thus " not (s <=XXREAL-0R1 q &  not [.XXREAL-1K2 r,s .[ c=MEMBEREDR3 ].XXREAL-1K4 -inftyXXREAL-0K2,q .[)"
      using xxreal_1_th_48 xxreal_0_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_269:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds (].XXREAL-1K4 -inftyXXREAL-0K2,b .[)/\\XBOOLE-0K3 (].XXREAL-1K4 a,+inftyXXREAL-0K1 .[) =MEMBEREDR9 ].XXREAL-1K4 a,b .["
proof(rule ballI,rule ballI)
  fix a assume [ty]: "a be ExtRealXXREAL-0M1"
  fix b assume [ty]: "b be ExtRealXXREAL-0M1"
  have A1: "-inftyXXREAL-0K2 <=XXREAL-0R1 a"
    using xxreal_0_th_5 sorry
  have "b <=XXREAL-0R1 +inftyXXREAL-0K1"
    using xxreal_0_th_3 sorry
  thus "(].XXREAL-1K4 -inftyXXREAL-0K2,b .[)/\\XBOOLE-0K3 (].XXREAL-1K4 a,+inftyXXREAL-0K1 .[) =MEMBEREDR9 ].XXREAL-1K4 a,b .["
    using A1 xxreal_1_th_160 sorry
qed "sorry"

mtheorem xxreal_1_th_270:
" for p be ExtRealXXREAL-0M1 holds  for b be RealXREAL-0M1 holds (].XXREAL-1K3 -inftyXXREAL-0K2,b .])/\\XBOOLE-0K3 (].XXREAL-1K4 p,+inftyXXREAL-0K1 .[) =MEMBEREDR9 ].XXREAL-1K3 p,b .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for b be RealXREAL-0M1 holds (].XXREAL-1K3 -inftyXXREAL-0K2,b .])/\\XBOOLE-0K3 (].XXREAL-1K4 p,+inftyXXREAL-0K1 .[) =MEMBEREDR9 ].XXREAL-1K3 p,b .]"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    have A1: "b inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    have "-inftyXXREAL-0K2 <=XXREAL-0R1 p"
      using xxreal_0_th_5 sorry
    thus "(].XXREAL-1K3 -inftyXXREAL-0K2,b .])/\\XBOOLE-0K3 (].XXREAL-1K4 p,+inftyXXREAL-0K1 .[) =MEMBEREDR9 ].XXREAL-1K3 p,b .]"
      using A1 xxreal_1_th_159 xxreal_0_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_271:
" for p be ExtRealXXREAL-0M1 holds  for a be RealXREAL-0M1 holds (].XXREAL-1K4 -inftyXXREAL-0K2,p .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 a,+inftyXXREAL-0K1 .[) =MEMBEREDR9 [.XXREAL-1K2 a,p .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for a be RealXREAL-0M1 holds (].XXREAL-1K4 -inftyXXREAL-0K2,p .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 a,+inftyXXREAL-0K1 .[) =MEMBEREDR9 [.XXREAL-1K2 a,p .["
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    have "a inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    then have "-inftyXXREAL-0K2 <XXREAL-0R3 a"
      using xxreal_0_th_12 sorry
    thus "(].XXREAL-1K4 -inftyXXREAL-0K2,p .[)/\\XBOOLE-0K3 ([.XXREAL-1K2 a,+inftyXXREAL-0K1 .[) =MEMBEREDR9 [.XXREAL-1K2 a,p .["
      using xxreal_1_th_154 xxreal_0_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_272:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (].XXREAL-1K3 -inftyXXREAL-0K2,a .])/\\XBOOLE-0K3 ([.XXREAL-1K2 b,+inftyXXREAL-0K1 .[) =MEMBEREDR9 [.XXREAL-1K1 b,a .]"
proof(rule ballI,rule ballI)
  fix a assume [ty]: "a be RealXREAL-0M1"
  fix b assume [ty]: "b be RealXREAL-0M1"
  have A1: "a inHIDDENR3 REALNUMBERSK2"
    using xreal_0_def_1 sorry
  have "b inHIDDENR3 REALNUMBERSK2"
    using xreal_0_def_1 sorry
  then have A2: "-inftyXXREAL-0K2 <XXREAL-0R3 b"
    using xxreal_0_th_12 sorry
  have "a <XXREAL-0R3 +inftyXXREAL-0K1"
    using A1 xxreal_0_th_9 sorry
  thus "(].XXREAL-1K3 -inftyXXREAL-0K2,a .])/\\XBOOLE-0K3 ([.XXREAL-1K2 b,+inftyXXREAL-0K1 .[) =MEMBEREDR9 [.XXREAL-1K1 b,a .]"
    using A2 xxreal_1_th_152 sorry
qed "sorry"

mtheorem xxreal_1_th_273:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 p implies [.XXREAL-1K2 r,s .[ missesMEMBEREDR14 ].XXREAL-1K4 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 p implies [.XXREAL-1K2 r,s .[ missesMEMBEREDR14 ].XXREAL-1K4 p,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "s <=XXREAL-0R1 p"
    have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 [.XXREAL-1K2 r,s .[ implies  not t inHIDDENR3 ].XXREAL-1K4 p,q .["
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume "t inHIDDENR3 [.XXREAL-1K2 r,s .["
      then have "t <=XXREAL-0R1 s"
        using xxreal_1_th_3 sorry
      then have "t <=XXREAL-0R1 p"
        using A1 xxreal_0_th_2 sorry
      thus " not t inHIDDENR3 ].XXREAL-1K4 p,q .["
        using xxreal_1_th_4 sorry
    qed "sorry"
    thus "[.XXREAL-1K2 r,s .[ missesMEMBEREDR14 ].XXREAL-1K4 p,q .["
      using membered_def_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_274:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 p implies [.XXREAL-1K2 r,s .[ missesMEMBEREDR14 ].XXREAL-1K3 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 p implies [.XXREAL-1K2 r,s .[ missesMEMBEREDR14 ].XXREAL-1K3 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "s <=XXREAL-0R1 p"
    have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 [.XXREAL-1K2 r,s .[ implies  not t inHIDDENR3 ].XXREAL-1K3 p,q .]"
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume "t inHIDDENR3 [.XXREAL-1K2 r,s .["
      then have "t <=XXREAL-0R1 s"
        using xxreal_1_th_3 sorry
      then have "t <=XXREAL-0R1 p"
        using A1 xxreal_0_th_2 sorry
      thus " not t inHIDDENR3 ].XXREAL-1K3 p,q .]"
        using xxreal_1_th_2 sorry
    qed "sorry"
    thus "[.XXREAL-1K2 r,s .[ missesMEMBEREDR14 ].XXREAL-1K3 p,q .]"
      using membered_def_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_275:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 p implies ].XXREAL-1K4 r,s .[ missesMEMBEREDR15 ].XXREAL-1K4 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 p implies ].XXREAL-1K4 r,s .[ missesMEMBEREDR15 ].XXREAL-1K4 p,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "s <=XXREAL-0R1 p"
    have " for t be RealXREAL-0M1 holds t inHIDDENR3 ].XXREAL-1K4 r,s .[ implies  not t inHIDDENR3 ].XXREAL-1K4 p,q .["
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be RealXREAL-0M1"
      assume "t inHIDDENR3 ].XXREAL-1K4 r,s .["
      then have "t <=XXREAL-0R1 s"
        using xxreal_1_th_4 sorry
      then have "t <=XXREAL-0R1 p"
        using A1 xxreal_0_th_2 sorry
      thus " not t inHIDDENR3 ].XXREAL-1K4 p,q .["
        using xxreal_1_th_4 sorry
    qed "sorry"
    thus "].XXREAL-1K4 r,s .[ missesMEMBEREDR15 ].XXREAL-1K4 p,q .["
      using membered_def_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_276:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 p implies ].XXREAL-1K4 r,s .[ missesMEMBEREDR14 ].XXREAL-1K3 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <=XXREAL-0R1 p implies ].XXREAL-1K4 r,s .[ missesMEMBEREDR14 ].XXREAL-1K3 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "s <=XXREAL-0R1 p"
    have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 ].XXREAL-1K4 r,s .[ implies  not t inHIDDENR3 ].XXREAL-1K3 p,q .]"
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume "t inHIDDENR3 ].XXREAL-1K4 r,s .["
      then have "t <=XXREAL-0R1 s"
        using xxreal_1_th_4 sorry
      then have "t <=XXREAL-0R1 p"
        using A1 xxreal_0_th_2 sorry
      thus " not t inHIDDENR3 ].XXREAL-1K3 p,q .]"
        using xxreal_1_th_2 sorry
    qed "sorry"
    thus "].XXREAL-1K4 r,s .[ missesMEMBEREDR14 ].XXREAL-1K3 p,q .]"
      using membered_def_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_277:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <XXREAL-0R3 p implies [.XXREAL-1K1 r,s .] missesMEMBEREDR14 [.XXREAL-1K2 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <XXREAL-0R3 p implies [.XXREAL-1K1 r,s .] missesMEMBEREDR14 [.XXREAL-1K2 p,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "s <XXREAL-0R3 p"
    have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 [.XXREAL-1K1 r,s .] implies  not t inHIDDENR3 [.XXREAL-1K2 p,q .["
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume "t inHIDDENR3 [.XXREAL-1K1 r,s .]"
      then have "t <=XXREAL-0R1 s"
        using xxreal_1_th_1 sorry
      then have "t <XXREAL-0R3 p"
        using A1 xxreal_0_th_2 sorry
      thus " not t inHIDDENR3 [.XXREAL-1K2 p,q .["
        using xxreal_1_th_3 sorry
    qed "sorry"
    thus "[.XXREAL-1K1 r,s .] missesMEMBEREDR14 [.XXREAL-1K2 p,q .["
      using membered_def_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_278:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <XXREAL-0R3 p implies [.XXREAL-1K1 r,s .] missesMEMBEREDR14 [.XXREAL-1K1 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <XXREAL-0R3 p implies [.XXREAL-1K1 r,s .] missesMEMBEREDR14 [.XXREAL-1K1 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "s <XXREAL-0R3 p"
    have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 [.XXREAL-1K1 r,s .] implies  not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume "t inHIDDENR3 [.XXREAL-1K1 r,s .]"
      then have "t <=XXREAL-0R1 s"
        using xxreal_1_th_1 sorry
      then have "t <XXREAL-0R3 p"
        using A1 xxreal_0_th_2 sorry
      thus " not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
        using xxreal_1_th_1 sorry
    qed "sorry"
    thus "[.XXREAL-1K1 r,s .] missesMEMBEREDR14 [.XXREAL-1K1 p,q .]"
      using membered_def_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_279:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <XXREAL-0R3 p implies ].XXREAL-1K3 r,s .] missesMEMBEREDR14 [.XXREAL-1K2 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <XXREAL-0R3 p implies ].XXREAL-1K3 r,s .] missesMEMBEREDR14 [.XXREAL-1K2 p,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "s <XXREAL-0R3 p"
    have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 ].XXREAL-1K3 r,s .] implies  not t inHIDDENR3 [.XXREAL-1K2 p,q .["
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
      then have "t <=XXREAL-0R1 s"
        using xxreal_1_th_2 sorry
      then have "t <XXREAL-0R3 p"
        using A1 xxreal_0_th_2 sorry
      thus " not t inHIDDENR3 [.XXREAL-1K2 p,q .["
        using xxreal_1_th_3 sorry
    qed "sorry"
    thus "].XXREAL-1K3 r,s .] missesMEMBEREDR14 [.XXREAL-1K2 p,q .["
      using membered_def_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_280:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <XXREAL-0R3 p implies ].XXREAL-1K3 r,s .] missesMEMBEREDR14 [.XXREAL-1K1 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds s <XXREAL-0R3 p implies ].XXREAL-1K3 r,s .] missesMEMBEREDR14 [.XXREAL-1K1 p,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "s <XXREAL-0R3 p"
    have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 ].XXREAL-1K3 r,s .] implies  not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be ExtRealXXREAL-0M1"
      assume "t inHIDDENR3 ].XXREAL-1K3 r,s .]"
      then have "t <=XXREAL-0R1 s"
        using xxreal_1_th_2 sorry
      then have "t <XXREAL-0R3 p"
        using A1 xxreal_0_th_2 sorry
      thus " not t inHIDDENR3 [.XXREAL-1K1 p,q .]"
        using xxreal_1_th_1 sorry
    qed "sorry"
    thus "].XXREAL-1K3 r,s .] missesMEMBEREDR14 [.XXREAL-1K1 p,q .]"
      using membered_def_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_281:
" for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds [.XXREAL-1K1 -inftyXXREAL-0K2,t .] \\SUBSET-1K6 [.XXREAL-1K1 -inftyXXREAL-0K2,s .] =MEMBEREDR8 ].XXREAL-1K3 s,t .]"
  using xxreal_1_th_182 xxreal_0_th_5 sorry

mtheorem xxreal_1_th_282:
" for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds [.XXREAL-1K2 -inftyXXREAL-0K2,t .[ \\SUBSET-1K6 [.XXREAL-1K1 -inftyXXREAL-0K2,s .] =MEMBEREDR8 ].XXREAL-1K4 s,t .["
  using xxreal_1_th_183 xxreal_0_th_5 sorry

mtheorem xxreal_1_th_283:
" for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds [.XXREAL-1K1 -inftyXXREAL-0K2,t .] \\SUBSET-1K6 [.XXREAL-1K1 -inftyXXREAL-0K2,s .] =MEMBEREDR8 ].XXREAL-1K3 s,t .]"
  using xxreal_1_th_186 xxreal_0_th_5 sorry

mtheorem xxreal_1_th_284:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds [.XXREAL-1K1 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 [.XXREAL-1K1 s,+inftyXXREAL-0K1 .] =MEMBEREDR8 [.XXREAL-1K2 r,s .["
  using xxreal_1_th_190 xxreal_0_th_3 sorry

mtheorem xxreal_1_th_285:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds ].XXREAL-1K3 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 [.XXREAL-1K1 s,+inftyXXREAL-0K1 .] =MEMBEREDR8 ].XXREAL-1K4 r,s .["
  using xxreal_1_th_191 xxreal_0_th_3 sorry

mtheorem xxreal_1_th_286:
" for t be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds [.XXREAL-1K1 -inftyXXREAL-0K2,t .] \\SUBSET-1K6 [.XXREAL-1K2 -inftyXXREAL-0K2,s .[ =MEMBEREDR8 [.XXREAL-1K1 s,t .]"
proof-
  have " for t be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds [.XXREAL-1K1 -inftyXXREAL-0K2,t .] \\SUBSET-1K6 [.XXREAL-1K2 -inftyXXREAL-0K2,s .[ =MEMBEREDR8 [.XXREAL-1K1 s,t .]"
  proof(rule ballI,rule ballI)
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    have "s inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    thus "[.XXREAL-1K1 -inftyXXREAL-0K2,t .] \\SUBSET-1K6 [.XXREAL-1K2 -inftyXXREAL-0K2,s .[ =MEMBEREDR8 [.XXREAL-1K1 s,t .]"
      using xxreal_1_th_184 xxreal_0_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_287:
" for t be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds [.XXREAL-1K2 -inftyXXREAL-0K2,t .[ \\SUBSET-1K6 [.XXREAL-1K2 -inftyXXREAL-0K2,s .[ =MEMBEREDR8 [.XXREAL-1K2 s,t .["
proof-
  have " for t be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds [.XXREAL-1K2 -inftyXXREAL-0K2,t .[ \\SUBSET-1K6 [.XXREAL-1K2 -inftyXXREAL-0K2,s .[ =MEMBEREDR8 [.XXREAL-1K2 s,t .["
  proof(rule ballI,rule ballI)
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    have "s inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    thus "[.XXREAL-1K2 -inftyXXREAL-0K2,t .[ \\SUBSET-1K6 [.XXREAL-1K2 -inftyXXREAL-0K2,s .[ =MEMBEREDR8 [.XXREAL-1K2 s,t .["
      using xxreal_1_th_185 xxreal_0_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_288:
" for t be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds ].XXREAL-1K4 -inftyXXREAL-0K2,t .[ \\SUBSET-1K6 ].XXREAL-1K3 -inftyXXREAL-0K2,s .] =MEMBEREDR9 ].XXREAL-1K4 s,t .["
proof-
  have " for t be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds ].XXREAL-1K4 -inftyXXREAL-0K2,t .[ \\SUBSET-1K6 ].XXREAL-1K3 -inftyXXREAL-0K2,s .] =MEMBEREDR9 ].XXREAL-1K4 s,t .["
  proof(rule ballI,rule ballI)
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    have "s inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    thus "].XXREAL-1K4 -inftyXXREAL-0K2,t .[ \\SUBSET-1K6 ].XXREAL-1K3 -inftyXXREAL-0K2,s .] =MEMBEREDR9 ].XXREAL-1K4 s,t .["
      using xxreal_1_th_187 xxreal_0_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_289:
" for t be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds ].XXREAL-1K3 -inftyXXREAL-0K2,t .] \\SUBSET-1K6 ].XXREAL-1K4 -inftyXXREAL-0K2,s .[ =MEMBEREDR8 [.XXREAL-1K1 s,t .]"
proof-
  have " for t be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds ].XXREAL-1K3 -inftyXXREAL-0K2,t .] \\SUBSET-1K6 ].XXREAL-1K4 -inftyXXREAL-0K2,s .[ =MEMBEREDR8 [.XXREAL-1K1 s,t .]"
  proof(rule ballI,rule ballI)
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    have "s inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    thus "].XXREAL-1K3 -inftyXXREAL-0K2,t .] \\SUBSET-1K6 ].XXREAL-1K4 -inftyXXREAL-0K2,s .[ =MEMBEREDR8 [.XXREAL-1K1 s,t .]"
      using xxreal_1_th_188 xxreal_0_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_290:
" for t be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds ].XXREAL-1K4 -inftyXXREAL-0K2,t .[ \\SUBSET-1K6 ].XXREAL-1K4 -inftyXXREAL-0K2,s .[ =MEMBEREDR9 [.XXREAL-1K2 s,t .["
proof-
  have " for t be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds ].XXREAL-1K4 -inftyXXREAL-0K2,t .[ \\SUBSET-1K6 ].XXREAL-1K4 -inftyXXREAL-0K2,s .[ =MEMBEREDR9 [.XXREAL-1K2 s,t .["
  proof(rule ballI,rule ballI)
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    have "s inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    thus "].XXREAL-1K4 -inftyXXREAL-0K2,t .[ \\SUBSET-1K6 ].XXREAL-1K4 -inftyXXREAL-0K2,s .[ =MEMBEREDR9 [.XXREAL-1K2 s,t .["
      using xxreal_1_th_189 xxreal_0_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_291:
" for r be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds [.XXREAL-1K1 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 ].XXREAL-1K3 s,+inftyXXREAL-0K1 .] =MEMBEREDR8 [.XXREAL-1K1 r,s .]"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds [.XXREAL-1K1 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 ].XXREAL-1K3 s,+inftyXXREAL-0K1 .] =MEMBEREDR8 [.XXREAL-1K1 r,s .]"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    have "s inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    thus "[.XXREAL-1K1 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 ].XXREAL-1K3 s,+inftyXXREAL-0K1 .] =MEMBEREDR8 [.XXREAL-1K1 r,s .]"
      using xxreal_1_th_192 xxreal_0_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_292:
" for r be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds ].XXREAL-1K3 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 ].XXREAL-1K3 s,+inftyXXREAL-0K1 .] =MEMBEREDR8 ].XXREAL-1K3 r,s .]"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds ].XXREAL-1K3 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 ].XXREAL-1K3 s,+inftyXXREAL-0K1 .] =MEMBEREDR8 ].XXREAL-1K3 r,s .]"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    have "s inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    thus "].XXREAL-1K3 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 ].XXREAL-1K3 s,+inftyXXREAL-0K1 .] =MEMBEREDR8 ].XXREAL-1K3 r,s .]"
      using xxreal_1_th_193 xxreal_0_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_293:
" for r be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds [.XXREAL-1K2 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 [.XXREAL-1K2 s,+inftyXXREAL-0K1 .[ =MEMBEREDR8 [.XXREAL-1K2 r,s .["
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds [.XXREAL-1K2 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 [.XXREAL-1K2 s,+inftyXXREAL-0K1 .[ =MEMBEREDR8 [.XXREAL-1K2 r,s .["
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    have "s inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    thus "[.XXREAL-1K2 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 [.XXREAL-1K2 s,+inftyXXREAL-0K1 .[ =MEMBEREDR8 [.XXREAL-1K2 r,s .["
      using xxreal_1_th_194 xxreal_0_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_294:
" for r be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds ].XXREAL-1K4 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 [.XXREAL-1K2 s,+inftyXXREAL-0K1 .[ =MEMBEREDR9 ].XXREAL-1K4 r,s .["
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds ].XXREAL-1K4 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 [.XXREAL-1K2 s,+inftyXXREAL-0K1 .[ =MEMBEREDR9 ].XXREAL-1K4 r,s .["
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    have "s inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    thus "].XXREAL-1K4 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 [.XXREAL-1K2 s,+inftyXXREAL-0K1 .[ =MEMBEREDR9 ].XXREAL-1K4 r,s .["
      using xxreal_1_th_195 xxreal_0_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_295:
" for r be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds [.XXREAL-1K2 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .[ =MEMBEREDR8 [.XXREAL-1K1 r,s .]"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds [.XXREAL-1K2 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .[ =MEMBEREDR8 [.XXREAL-1K1 r,s .]"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    have "s inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    thus "[.XXREAL-1K2 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .[ =MEMBEREDR8 [.XXREAL-1K1 r,s .]"
      using xxreal_1_th_196 xxreal_0_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_296:
" for r be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds ].XXREAL-1K4 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .[ =MEMBEREDR9 ].XXREAL-1K3 r,s .]"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds ].XXREAL-1K4 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .[ =MEMBEREDR9 ].XXREAL-1K3 r,s .]"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    have "s inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    thus "].XXREAL-1K4 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .[ =MEMBEREDR9 ].XXREAL-1K3 r,s .]"
      using xxreal_1_th_197 xxreal_0_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_297:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & p <XXREAL-0R3 q implies ].XXREAL-1K4 r,q .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & p <XXREAL-0R3 q implies ].XXREAL-1K4 r,q .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "p <XXREAL-0R3 q"
    have " for x be ExtRealXXREAL-0M1 holds (x inHIDDENR3 ].XXREAL-1K4 r,q .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ implies x inHIDDENR3 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[) & (x inHIDDENR3 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[ implies x inHIDDENR3 ].XXREAL-1K4 r,q .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .[)"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      show "x inHIDDENR3 ].XXREAL-1K4 r,q .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ implies x inHIDDENR3 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
      proof(rule impI)
        assume A3: "x inHIDDENR3 ].XXREAL-1K4 r,q .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .["
        then have A4: " not x inHIDDENR3 ].XXREAL-1K4 p,s .["
          using xboole_0_def_5 sorry
        have A5: "r <XXREAL-0R3 x"
          using A3 xxreal_1_th_4 sorry
        have A6: "x <XXREAL-0R3 q"
          using A3 xxreal_1_th_4 sorry
        have " not (p <XXREAL-0R3 x & x <XXREAL-0R3 s)"
          using A4 xxreal_1_th_4 sorry
        then have "x inHIDDENR3 ].XXREAL-1K3 r,p .] or x inHIDDENR3 [.XXREAL-1K2 s,q .["
          using A5 A6 xxreal_1_th_2 xxreal_1_th_3 sorry
        thus "x inHIDDENR3 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
          using xboole_0_def_3 sorry
      qed
      assume "x inHIDDENR3 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
      then have "x inHIDDENR3 ].XXREAL-1K3 r,p .] or x inHIDDENR3 [.XXREAL-1K2 s,q .["
        using xboole_0_def_3 sorry
      then have A7: "r <XXREAL-0R3 x & x <=XXREAL-0R1 p or s <=XXREAL-0R1 x & x <XXREAL-0R3 q"
        using xxreal_1_th_2 xxreal_1_th_3 sorry
      then have A8: "r <XXREAL-0R3 x"
        using A1 xxreal_0_th_2 sorry
      have "x <XXREAL-0R3 q"
        using A2 A7 xxreal_0_th_2 sorry
      then have A9: "x inHIDDENR3 ].XXREAL-1K4 r,q .["
        using A8 xxreal_1_th_4 sorry
      have " not x inHIDDENR3 ].XXREAL-1K4 p,s .["
        using A7 xxreal_1_th_4 sorry
      thus "x inHIDDENR3 ].XXREAL-1K4 r,q .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .["
        using A9 xboole_0_def_5 sorry
    qed "sorry"
    thus "].XXREAL-1K4 r,q .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_298:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & p <XXREAL-0R3 q implies [.XXREAL-1K2 r,q .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & p <XXREAL-0R3 q implies [.XXREAL-1K2 r,q .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
      and A2: "p <XXREAL-0R3 q"
    have " for x be ExtRealXXREAL-0M1 holds (x inHIDDENR3 [.XXREAL-1K2 r,q .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ implies x inHIDDENR3 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[) & (x inHIDDENR3 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[ implies x inHIDDENR3 [.XXREAL-1K2 r,q .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .[)"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      show "x inHIDDENR3 [.XXREAL-1K2 r,q .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ implies x inHIDDENR3 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
      proof(rule impI)
        assume A3: "x inHIDDENR3 [.XXREAL-1K2 r,q .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .["
        then have A4: " not x inHIDDENR3 ].XXREAL-1K4 p,s .["
          using xboole_0_def_5 sorry
        have A5: "r <=XXREAL-0R1 x"
          using A3 xxreal_1_th_3 sorry
        have A6: "x <XXREAL-0R3 q"
          using A3 xxreal_1_th_3 sorry
        have " not (p <XXREAL-0R3 x & x <XXREAL-0R3 s)"
          using A4 xxreal_1_th_4 sorry
        then have "x inHIDDENR3 [.XXREAL-1K1 r,p .] or x inHIDDENR3 [.XXREAL-1K2 s,q .["
          using A5 A6 xxreal_1_th_1 xxreal_1_th_3 sorry
        thus "x inHIDDENR3 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
          using xboole_0_def_3 sorry
      qed
      assume "x inHIDDENR3 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
      then have "x inHIDDENR3 [.XXREAL-1K1 r,p .] or x inHIDDENR3 [.XXREAL-1K2 s,q .["
        using xboole_0_def_3 sorry
      then have A7: "r <=XXREAL-0R1 x & x <=XXREAL-0R1 p or s <=XXREAL-0R1 x & x <XXREAL-0R3 q"
        using xxreal_1_th_1 xxreal_1_th_3 sorry
      then have A8: "r <=XXREAL-0R1 x"
        using A1 xxreal_0_th_2 sorry
      have "x <XXREAL-0R3 q"
        using A2 A7 xxreal_0_th_2 sorry
      then have A9: "x inHIDDENR3 [.XXREAL-1K2 r,q .["
        using A8 xxreal_1_th_3 sorry
      have " not x inHIDDENR3 ].XXREAL-1K4 p,s .["
        using A7 xxreal_1_th_4 sorry
      thus "x inHIDDENR3 [.XXREAL-1K2 r,q .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .["
        using A9 xboole_0_def_5 sorry
    qed "sorry"
    thus "[.XXREAL-1K2 r,q .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_299:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & p <=XXREAL-0R1 q implies ].XXREAL-1K3 r,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & p <=XXREAL-0R1 q implies ].XXREAL-1K3 r,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "p <=XXREAL-0R1 q"
    have " for x be ExtRealXXREAL-0M1 holds (x inHIDDENR3 ].XXREAL-1K3 r,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ implies x inHIDDENR3 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]) & (x inHIDDENR3 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .] implies x inHIDDENR3 ].XXREAL-1K3 r,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,s .[)"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      show "x inHIDDENR3 ].XXREAL-1K3 r,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ implies x inHIDDENR3 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
      proof(rule impI)
        assume A3: "x inHIDDENR3 ].XXREAL-1K3 r,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,s .["
        then have A4: " not x inHIDDENR3 ].XXREAL-1K4 p,s .["
          using xboole_0_def_5 sorry
        have A5: "r <XXREAL-0R3 x"
          using A3 xxreal_1_th_2 sorry
        have A6: "x <=XXREAL-0R1 q"
          using A3 xxreal_1_th_2 sorry
        have " not (p <XXREAL-0R3 x & x <XXREAL-0R3 s)"
          using A4 xxreal_1_th_4 sorry
        then have "x inHIDDENR3 ].XXREAL-1K3 r,p .] or x inHIDDENR3 [.XXREAL-1K1 s,q .]"
          using A5 A6 xxreal_1_th_1 xxreal_1_th_2 sorry
        thus "x inHIDDENR3 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
          using xboole_0_def_3 sorry
      qed
      assume "x inHIDDENR3 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
      then have "x inHIDDENR3 ].XXREAL-1K3 r,p .] or x inHIDDENR3 [.XXREAL-1K1 s,q .]"
        using xboole_0_def_3 sorry
      then have A7: "r <XXREAL-0R3 x & x <=XXREAL-0R1 p or s <=XXREAL-0R1 x & x <=XXREAL-0R1 q"
        using xxreal_1_th_1 xxreal_1_th_2 sorry
      then have A8: "r <XXREAL-0R3 x"
        using A1 xxreal_0_th_2 sorry
      have "x <=XXREAL-0R1 q"
        using A2 A7 xxreal_0_th_2 sorry
      then have A9: "x inHIDDENR3 ].XXREAL-1K3 r,q .]"
        using A8 xxreal_1_th_2 sorry
      have " not x inHIDDENR3 ].XXREAL-1K4 p,s .["
        using A7 xxreal_1_th_4 sorry
      thus "x inHIDDENR3 ].XXREAL-1K3 r,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,s .["
        using A9 xboole_0_def_5 sorry
    qed "sorry"
    thus "].XXREAL-1K3 r,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_300:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & p <=XXREAL-0R1 q implies [.XXREAL-1K1 r,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & p <=XXREAL-0R1 q implies [.XXREAL-1K1 r,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
      and A2: "p <=XXREAL-0R1 q"
    have " for x be ExtRealXXREAL-0M1 holds (x inHIDDENR3 [.XXREAL-1K1 r,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ implies x inHIDDENR3 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]) & (x inHIDDENR3 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .] implies x inHIDDENR3 [.XXREAL-1K1 r,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,s .[)"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      show "x inHIDDENR3 [.XXREAL-1K1 r,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ implies x inHIDDENR3 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
      proof(rule impI)
        assume A3: "x inHIDDENR3 [.XXREAL-1K1 r,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,s .["
        then have A4: " not x inHIDDENR3 ].XXREAL-1K4 p,s .["
          using xboole_0_def_5 sorry
        have A5: "r <=XXREAL-0R1 x"
          using A3 xxreal_1_th_1 sorry
        have A6: "x <=XXREAL-0R1 q"
          using A3 xxreal_1_th_1 sorry
        have " not (p <XXREAL-0R3 x & x <XXREAL-0R3 s)"
          using A4 xxreal_1_th_4 sorry
        then have "x inHIDDENR3 [.XXREAL-1K1 r,p .] or x inHIDDENR3 [.XXREAL-1K1 s,q .]"
          using A5 A6 xxreal_1_th_1 sorry
        thus "x inHIDDENR3 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
          using xboole_0_def_3 sorry
      qed
      assume "x inHIDDENR3 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
      then have "x inHIDDENR3 [.XXREAL-1K1 r,p .] or x inHIDDENR3 [.XXREAL-1K1 s,q .]"
        using xboole_0_def_3 sorry
      then have A7: "r <=XXREAL-0R1 x & x <=XXREAL-0R1 p or s <=XXREAL-0R1 x & x <=XXREAL-0R1 q"
        using xxreal_1_th_1 sorry
      then have A8: "r <=XXREAL-0R1 x"
        using A1 xxreal_0_th_2 sorry
      have "x <=XXREAL-0R1 q"
        using A2 A7 xxreal_0_th_2 sorry
      then have A9: "x inHIDDENR3 [.XXREAL-1K1 r,q .]"
        using A8 xxreal_1_th_1 sorry
      have " not x inHIDDENR3 ].XXREAL-1K4 p,s .["
        using A7 xxreal_1_th_4 sorry
      thus "x inHIDDENR3 [.XXREAL-1K1 r,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,s .["
        using A9 xboole_0_def_5 sorry
    qed "sorry"
    thus "[.XXREAL-1K1 r,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_301:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & p <=XXREAL-0R1 q implies ].XXREAL-1K4 r,q .[ \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR8 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & p <=XXREAL-0R1 q implies ].XXREAL-1K4 r,q .[ \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR8 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "p <=XXREAL-0R1 q"
    have " for x be ExtRealXXREAL-0M1 holds (x inHIDDENR3 ].XXREAL-1K4 r,q .[ \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ implies x inHIDDENR3 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[) & (x inHIDDENR3 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[ implies x inHIDDENR3 ].XXREAL-1K4 r,q .[ \\SUBSET-1K6 [.XXREAL-1K2 p,s .[)"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      show "x inHIDDENR3 ].XXREAL-1K4 r,q .[ \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ implies x inHIDDENR3 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
      proof(rule impI)
        assume A3: "x inHIDDENR3 ].XXREAL-1K4 r,q .[ \\SUBSET-1K6 [.XXREAL-1K2 p,s .["
        then have A4: " not x inHIDDENR3 [.XXREAL-1K2 p,s .["
          using xboole_0_def_5 sorry
        have A5: "r <XXREAL-0R3 x"
          using A3 xxreal_1_th_4 sorry
        have A6: "x <XXREAL-0R3 q"
          using A3 xxreal_1_th_4 sorry
        have " not (p <=XXREAL-0R1 x & x <XXREAL-0R3 s)"
          using A4 xxreal_1_th_3 sorry
        then have "x inHIDDENR3 ].XXREAL-1K4 r,p .[ or x inHIDDENR3 [.XXREAL-1K2 s,q .["
          using A5 A6 xxreal_1_th_3 xxreal_1_th_4 sorry
        thus "x inHIDDENR3 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
          using xboole_0_def_3 sorry
      qed
      assume "x inHIDDENR3 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
      then have "x inHIDDENR3 ].XXREAL-1K4 r,p .[ or x inHIDDENR3 [.XXREAL-1K2 s,q .["
        using xboole_0_def_3 sorry
      then have A7: "r <XXREAL-0R3 x & x <XXREAL-0R3 p or s <=XXREAL-0R1 x & x <XXREAL-0R3 q"
        using xxreal_1_th_3 xxreal_1_th_4 sorry
      then have A8: "r <XXREAL-0R3 x"
        using A1 xxreal_0_th_2 sorry
      have "x <XXREAL-0R3 q"
        using A2 A7 xxreal_0_th_2 sorry
      then have A9: "x inHIDDENR3 ].XXREAL-1K4 r,q .["
        using A8 xxreal_1_th_4 sorry
      have " not x inHIDDENR3 [.XXREAL-1K2 p,s .["
        using A7 xxreal_1_th_3 sorry
      thus "x inHIDDENR3 ].XXREAL-1K4 r,q .[ \\SUBSET-1K6 [.XXREAL-1K2 p,s .["
        using A9 xboole_0_def_5 sorry
    qed "sorry"
    thus "].XXREAL-1K4 r,q .[ \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR8 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_302:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & p <=XXREAL-0R1 q implies [.XXREAL-1K2 r,q .[ \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & p <=XXREAL-0R1 q implies [.XXREAL-1K2 r,q .[ \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
      and A2: "p <=XXREAL-0R1 q"
    have " for x be ExtRealXXREAL-0M1 holds (x inHIDDENR3 [.XXREAL-1K2 r,q .[ \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ implies x inHIDDENR3 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[) & (x inHIDDENR3 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[ implies x inHIDDENR3 [.XXREAL-1K2 r,q .[ \\SUBSET-1K6 [.XXREAL-1K2 p,s .[)"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      show "x inHIDDENR3 [.XXREAL-1K2 r,q .[ \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ implies x inHIDDENR3 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
      proof(rule impI)
        assume A3: "x inHIDDENR3 [.XXREAL-1K2 r,q .[ \\SUBSET-1K6 [.XXREAL-1K2 p,s .["
        then have A4: " not x inHIDDENR3 [.XXREAL-1K2 p,s .["
          using xboole_0_def_5 sorry
        have A5: "r <=XXREAL-0R1 x"
          using A3 xxreal_1_th_3 sorry
        have A6: "x <XXREAL-0R3 q"
          using A3 xxreal_1_th_3 sorry
        have " not (p <=XXREAL-0R1 x & x <XXREAL-0R3 s)"
          using A4 xxreal_1_th_3 sorry
        then have "x inHIDDENR3 [.XXREAL-1K2 r,p .[ or x inHIDDENR3 [.XXREAL-1K2 s,q .["
          using A5 A6 xxreal_1_th_3 sorry
        thus "x inHIDDENR3 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
          using xboole_0_def_3 sorry
      qed
      assume "x inHIDDENR3 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
      then have "x inHIDDENR3 [.XXREAL-1K2 r,p .[ or x inHIDDENR3 [.XXREAL-1K2 s,q .["
        using xboole_0_def_3 sorry
      then have A7: "r <=XXREAL-0R1 x & x <XXREAL-0R3 p or s <=XXREAL-0R1 x & x <XXREAL-0R3 q"
        using xxreal_1_th_3 sorry
      then have A8: "r <=XXREAL-0R1 x"
        using A1 xxreal_0_th_2 sorry
      have "x <XXREAL-0R3 q"
        using A2 A7 xxreal_0_th_2 sorry
      then have A9: "x inHIDDENR3 [.XXREAL-1K2 r,q .["
        using A8 xxreal_1_th_3 sorry
      have " not x inHIDDENR3 [.XXREAL-1K2 p,s .["
        using A7 xxreal_1_th_3 sorry
      thus "x inHIDDENR3 [.XXREAL-1K2 r,q .[ \\SUBSET-1K6 [.XXREAL-1K2 p,s .["
        using A9 xboole_0_def_5 sorry
    qed "sorry"
    thus "[.XXREAL-1K2 r,q .[ \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_303:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & p <=XXREAL-0R1 q implies ].XXREAL-1K3 r,q .] \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR8 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & p <=XXREAL-0R1 q implies ].XXREAL-1K3 r,q .] \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR8 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "p <=XXREAL-0R1 q"
    have " for x be ExtRealXXREAL-0M1 holds (x inHIDDENR3 ].XXREAL-1K3 r,q .] \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ implies x inHIDDENR3 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]) & (x inHIDDENR3 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .] implies x inHIDDENR3 ].XXREAL-1K3 r,q .] \\SUBSET-1K6 [.XXREAL-1K2 p,s .[)"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      show "x inHIDDENR3 ].XXREAL-1K3 r,q .] \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ implies x inHIDDENR3 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
      proof(rule impI)
        assume A3: "x inHIDDENR3 ].XXREAL-1K3 r,q .] \\SUBSET-1K6 [.XXREAL-1K2 p,s .["
        then have A4: " not x inHIDDENR3 [.XXREAL-1K2 p,s .["
          using xboole_0_def_5 sorry
        have A5: "r <XXREAL-0R3 x"
          using A3 xxreal_1_th_2 sorry
        have A6: "x <=XXREAL-0R1 q"
          using A3 xxreal_1_th_2 sorry
        have " not (p <=XXREAL-0R1 x & x <XXREAL-0R3 s)"
          using A4 xxreal_1_th_3 sorry
        then have "x inHIDDENR3 ].XXREAL-1K4 r,p .[ or x inHIDDENR3 [.XXREAL-1K1 s,q .]"
          using A5 A6 xxreal_1_th_1 xxreal_1_th_4 sorry
        thus "x inHIDDENR3 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
          using xboole_0_def_3 sorry
      qed
      assume "x inHIDDENR3 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
      then have "x inHIDDENR3 ].XXREAL-1K4 r,p .[ or x inHIDDENR3 [.XXREAL-1K1 s,q .]"
        using xboole_0_def_3 sorry
      then have A7: "r <XXREAL-0R3 x & x <XXREAL-0R3 p or s <=XXREAL-0R1 x & x <=XXREAL-0R1 q"
        using xxreal_1_th_1 xxreal_1_th_4 sorry
      then have A8: "r <XXREAL-0R3 x"
        using A1 xxreal_0_th_2 sorry
      have "x <=XXREAL-0R1 q"
        using A2 A7 xxreal_0_th_2 sorry
      then have A9: "x inHIDDENR3 ].XXREAL-1K3 r,q .]"
        using A8 xxreal_1_th_2 sorry
      have " not x inHIDDENR3 [.XXREAL-1K2 p,s .["
        using A7 xxreal_1_th_3 sorry
      thus "x inHIDDENR3 ].XXREAL-1K3 r,q .] \\SUBSET-1K6 [.XXREAL-1K2 p,s .["
        using A9 xboole_0_def_5 sorry
    qed "sorry"
    thus "].XXREAL-1K3 r,q .] \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR8 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_304:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & p <=XXREAL-0R1 q implies [.XXREAL-1K1 r,q .] \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & p <=XXREAL-0R1 q implies [.XXREAL-1K1 r,q .] \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
      and A2: "p <=XXREAL-0R1 q"
    have " for x be ExtRealXXREAL-0M1 holds (x inHIDDENR3 [.XXREAL-1K1 r,q .] \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ implies x inHIDDENR3 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]) & (x inHIDDENR3 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .] implies x inHIDDENR3 [.XXREAL-1K1 r,q .] \\SUBSET-1K6 [.XXREAL-1K2 p,s .[)"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      show "x inHIDDENR3 [.XXREAL-1K1 r,q .] \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ implies x inHIDDENR3 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
      proof(rule impI)
        assume A3: "x inHIDDENR3 [.XXREAL-1K1 r,q .] \\SUBSET-1K6 [.XXREAL-1K2 p,s .["
        then have A4: " not x inHIDDENR3 [.XXREAL-1K2 p,s .["
          using xboole_0_def_5 sorry
        have A5: "r <=XXREAL-0R1 x"
          using A3 xxreal_1_th_1 sorry
        have A6: "x <=XXREAL-0R1 q"
          using A3 xxreal_1_th_1 sorry
        have " not (p <=XXREAL-0R1 x & x <XXREAL-0R3 s)"
          using A4 xxreal_1_th_3 sorry
        then have "x inHIDDENR3 [.XXREAL-1K2 r,p .[ or x inHIDDENR3 [.XXREAL-1K1 s,q .]"
          using A5 A6 xxreal_1_th_1 xxreal_1_th_3 sorry
        thus "x inHIDDENR3 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
          using xboole_0_def_3 sorry
      qed
      assume "x inHIDDENR3 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
      then have "x inHIDDENR3 [.XXREAL-1K2 r,p .[ or x inHIDDENR3 [.XXREAL-1K1 s,q .]"
        using xboole_0_def_3 sorry
      then have A7: "r <=XXREAL-0R1 x & x <XXREAL-0R3 p or s <=XXREAL-0R1 x & x <=XXREAL-0R1 q"
        using xxreal_1_th_1 xxreal_1_th_3 sorry
      then have A8: "r <=XXREAL-0R1 x"
        using A1 xxreal_0_th_2 sorry
      have "x <=XXREAL-0R1 q"
        using A2 A7 xxreal_0_th_2 sorry
      then have A9: "x inHIDDENR3 [.XXREAL-1K1 r,q .]"
        using A8 xxreal_1_th_1 sorry
      have " not x inHIDDENR3 [.XXREAL-1K2 p,s .["
        using A7 xxreal_1_th_3 sorry
      thus "x inHIDDENR3 [.XXREAL-1K1 r,q .] \\SUBSET-1K6 [.XXREAL-1K2 p,s .["
        using A9 xboole_0_def_5 sorry
    qed "sorry"
    thus "[.XXREAL-1K1 r,q .] \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_305:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & p <XXREAL-0R3 q implies ].XXREAL-1K4 r,q .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & p <XXREAL-0R3 q implies ].XXREAL-1K4 r,q .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "p <XXREAL-0R3 q"
    have " for x be ExtRealXXREAL-0M1 holds (x inHIDDENR3 ].XXREAL-1K4 r,q .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .] implies x inHIDDENR3 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .[) & (x inHIDDENR3 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .[ implies x inHIDDENR3 ].XXREAL-1K4 r,q .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .])"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      show "x inHIDDENR3 ].XXREAL-1K4 r,q .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .] implies x inHIDDENR3 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .["
      proof(rule impI)
        assume A3: "x inHIDDENR3 ].XXREAL-1K4 r,q .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .]"
        then have A4: " not x inHIDDENR3 ].XXREAL-1K3 p,s .]"
          using xboole_0_def_5 sorry
        have A5: "r <XXREAL-0R3 x"
          using A3 xxreal_1_th_4 sorry
        have A6: "x <XXREAL-0R3 q"
          using A3 xxreal_1_th_4 sorry
        have " not (p <XXREAL-0R3 x & x <=XXREAL-0R1 s)"
          using A4 xxreal_1_th_2 sorry
        then have "x inHIDDENR3 ].XXREAL-1K3 r,p .] or x inHIDDENR3 ].XXREAL-1K4 s,q .["
          using A5 A6 xxreal_1_th_2 xxreal_1_th_4 sorry
        thus "x inHIDDENR3 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .["
          using xboole_0_def_3 sorry
      qed
      assume "x inHIDDENR3 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .["
      then have "x inHIDDENR3 ].XXREAL-1K3 r,p .] or x inHIDDENR3 ].XXREAL-1K4 s,q .["
        using xboole_0_def_3 sorry
      then have A7: "r <XXREAL-0R3 x & x <=XXREAL-0R1 p or s <XXREAL-0R3 x & x <XXREAL-0R3 q"
        using xxreal_1_th_2 xxreal_1_th_4 sorry
      then have A8: "r <XXREAL-0R3 x"
        using A1 xxreal_0_th_2 sorry
      have "x <XXREAL-0R3 q"
        using A2 A7 xxreal_0_th_2 sorry
      then have A9: "x inHIDDENR3 ].XXREAL-1K4 r,q .["
        using A8 xxreal_1_th_4 sorry
      have " not x inHIDDENR3 ].XXREAL-1K3 p,s .]"
        using A7 xxreal_1_th_2 sorry
      thus "x inHIDDENR3 ].XXREAL-1K4 r,q .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .]"
        using A9 xboole_0_def_5 sorry
    qed "sorry"
    thus "].XXREAL-1K4 r,q .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_306:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & p <XXREAL-0R3 q implies [.XXREAL-1K2 r,q .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & p <XXREAL-0R3 q implies [.XXREAL-1K2 r,q .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
      and A2: "p <XXREAL-0R3 q"
    have " for x be ExtRealXXREAL-0M1 holds (x inHIDDENR3 [.XXREAL-1K2 r,q .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .] implies x inHIDDENR3 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .[) & (x inHIDDENR3 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .[ implies x inHIDDENR3 [.XXREAL-1K2 r,q .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .])"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      show "x inHIDDENR3 [.XXREAL-1K2 r,q .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .] implies x inHIDDENR3 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .["
      proof(rule impI)
        assume A3: "x inHIDDENR3 [.XXREAL-1K2 r,q .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .]"
        then have A4: " not x inHIDDENR3 ].XXREAL-1K3 p,s .]"
          using xboole_0_def_5 sorry
        have A5: "r <=XXREAL-0R1 x"
          using A3 xxreal_1_th_3 sorry
        have A6: "x <XXREAL-0R3 q"
          using A3 xxreal_1_th_3 sorry
        have " not (p <XXREAL-0R3 x & x <=XXREAL-0R1 s)"
          using A4 xxreal_1_th_2 sorry
        then have "x inHIDDENR3 [.XXREAL-1K1 r,p .] or x inHIDDENR3 ].XXREAL-1K4 s,q .["
          using A5 A6 xxreal_1_th_1 xxreal_1_th_4 sorry
        thus "x inHIDDENR3 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .["
          using xboole_0_def_3 sorry
      qed
      assume "x inHIDDENR3 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .["
      then have "x inHIDDENR3 [.XXREAL-1K1 r,p .] or x inHIDDENR3 ].XXREAL-1K4 s,q .["
        using xboole_0_def_3 sorry
      then have A7: "r <=XXREAL-0R1 x & x <=XXREAL-0R1 p or s <XXREAL-0R3 x & x <XXREAL-0R3 q"
        using xxreal_1_th_1 xxreal_1_th_4 sorry
      then have A8: "r <=XXREAL-0R1 x"
        using A1 xxreal_0_th_2 sorry
      have "x <XXREAL-0R3 q"
        using A2 A7 xxreal_0_th_2 sorry
      then have A9: "x inHIDDENR3 [.XXREAL-1K2 r,q .["
        using A8 xxreal_1_th_3 sorry
      have " not x inHIDDENR3 ].XXREAL-1K3 p,s .]"
        using A7 xxreal_1_th_2 sorry
      thus "x inHIDDENR3 [.XXREAL-1K2 r,q .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .]"
        using A9 xboole_0_def_5 sorry
    qed "sorry"
    thus "[.XXREAL-1K2 r,q .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_307:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & p <=XXREAL-0R1 q implies ].XXREAL-1K3 r,q .] \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & p <=XXREAL-0R1 q implies ].XXREAL-1K3 r,q .] \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "p <=XXREAL-0R1 q"
    have " for x be ExtRealXXREAL-0M1 holds (x inHIDDENR3 ].XXREAL-1K3 r,q .] \\SUBSET-1K6 ].XXREAL-1K3 p,s .] implies x inHIDDENR3 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]) & (x inHIDDENR3 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .] implies x inHIDDENR3 ].XXREAL-1K3 r,q .] \\SUBSET-1K6 ].XXREAL-1K3 p,s .])"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      show "x inHIDDENR3 ].XXREAL-1K3 r,q .] \\SUBSET-1K6 ].XXREAL-1K3 p,s .] implies x inHIDDENR3 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
      proof(rule impI)
        assume A3: "x inHIDDENR3 ].XXREAL-1K3 r,q .] \\SUBSET-1K6 ].XXREAL-1K3 p,s .]"
        then have A4: " not x inHIDDENR3 ].XXREAL-1K3 p,s .]"
          using xboole_0_def_5 sorry
        have A5: "r <XXREAL-0R3 x"
          using A3 xxreal_1_th_2 sorry
        have A6: "x <=XXREAL-0R1 q"
          using A3 xxreal_1_th_2 sorry
        have " not (p <XXREAL-0R3 x & x <=XXREAL-0R1 s)"
          using A4 xxreal_1_th_2 sorry
        then have "x inHIDDENR3 ].XXREAL-1K3 r,p .] or x inHIDDENR3 ].XXREAL-1K3 s,q .]"
          using A5 A6 xxreal_1_th_2 sorry
        thus "x inHIDDENR3 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
          using xboole_0_def_3 sorry
      qed
      assume "x inHIDDENR3 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
      then have "x inHIDDENR3 ].XXREAL-1K3 r,p .] or x inHIDDENR3 ].XXREAL-1K3 s,q .]"
        using xboole_0_def_3 sorry
      then have A7: "r <XXREAL-0R3 x & x <=XXREAL-0R1 p or s <XXREAL-0R3 x & x <=XXREAL-0R1 q"
        using xxreal_1_th_2 sorry
      then have A8: "r <XXREAL-0R3 x"
        using A1 xxreal_0_th_2 sorry
      have "x <=XXREAL-0R1 q"
        using A2 A7 xxreal_0_th_2 sorry
      then have A9: "x inHIDDENR3 ].XXREAL-1K3 r,q .]"
        using A8 xxreal_1_th_2 sorry
      have " not x inHIDDENR3 ].XXREAL-1K3 p,s .]"
        using A7 xxreal_1_th_2 sorry
      thus "x inHIDDENR3 ].XXREAL-1K3 r,q .] \\SUBSET-1K6 ].XXREAL-1K3 p,s .]"
        using A9 xboole_0_def_5 sorry
    qed "sorry"
    thus "].XXREAL-1K3 r,q .] \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_308:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & p <=XXREAL-0R1 q implies [.XXREAL-1K1 r,q .] \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & p <=XXREAL-0R1 q implies [.XXREAL-1K1 r,q .] \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
      and A2: "p <=XXREAL-0R1 q"
    have " for x be ExtRealXXREAL-0M1 holds (x inHIDDENR3 [.XXREAL-1K1 r,q .] \\SUBSET-1K6 ].XXREAL-1K3 p,s .] implies x inHIDDENR3 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]) & (x inHIDDENR3 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .] implies x inHIDDENR3 [.XXREAL-1K1 r,q .] \\SUBSET-1K6 ].XXREAL-1K3 p,s .])"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      show "x inHIDDENR3 [.XXREAL-1K1 r,q .] \\SUBSET-1K6 ].XXREAL-1K3 p,s .] implies x inHIDDENR3 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
      proof(rule impI)
        assume A3: "x inHIDDENR3 [.XXREAL-1K1 r,q .] \\SUBSET-1K6 ].XXREAL-1K3 p,s .]"
        then have A4: " not x inHIDDENR3 ].XXREAL-1K3 p,s .]"
          using xboole_0_def_5 sorry
        have A5: "r <=XXREAL-0R1 x"
          using A3 xxreal_1_th_1 sorry
        have A6: "x <=XXREAL-0R1 q"
          using A3 xxreal_1_th_1 sorry
        have " not (p <XXREAL-0R3 x & x <=XXREAL-0R1 s)"
          using A4 xxreal_1_th_2 sorry
        then have "x inHIDDENR3 [.XXREAL-1K1 r,p .] or x inHIDDENR3 ].XXREAL-1K3 s,q .]"
          using A5 A6 xxreal_1_th_1 xxreal_1_th_2 sorry
        thus "x inHIDDENR3 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
          using xboole_0_def_3 sorry
      qed
      assume "x inHIDDENR3 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
      then have "x inHIDDENR3 [.XXREAL-1K1 r,p .] or x inHIDDENR3 ].XXREAL-1K3 s,q .]"
        using xboole_0_def_3 sorry
      then have A7: "r <=XXREAL-0R1 x & x <=XXREAL-0R1 p or s <XXREAL-0R3 x & x <=XXREAL-0R1 q"
        using xxreal_1_th_1 xxreal_1_th_2 sorry
      then have A8: "r <=XXREAL-0R1 x"
        using A1 xxreal_0_th_2 sorry
      have "x <=XXREAL-0R1 q"
        using A2 A7 xxreal_0_th_2 sorry
      then have A9: "x inHIDDENR3 [.XXREAL-1K1 r,q .]"
        using A8 xxreal_1_th_1 sorry
      have " not x inHIDDENR3 ].XXREAL-1K3 p,s .]"
        using A7 xxreal_1_th_2 sorry
      thus "x inHIDDENR3 [.XXREAL-1K1 r,q .] \\SUBSET-1K6 ].XXREAL-1K3 p,s .]"
        using A9 xboole_0_def_5 sorry
    qed "sorry"
    thus "[.XXREAL-1K1 r,q .] \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_309:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & p <=XXREAL-0R1 q implies ].XXREAL-1K4 r,q .[ \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR9 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & p <=XXREAL-0R1 q implies ].XXREAL-1K4 r,q .[ \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR9 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
      and A2: "p <=XXREAL-0R1 q"
    have " for x be RealXREAL-0M1 holds (x inHIDDENR3 ].XXREAL-1K4 r,q .[ \\SUBSET-1K6 [.XXREAL-1K1 p,s .] implies x inHIDDENR3 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .[) & (x inHIDDENR3 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .[ implies x inHIDDENR3 ].XXREAL-1K4 r,q .[ \\SUBSET-1K6 [.XXREAL-1K1 p,s .])"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      show "x inHIDDENR3 ].XXREAL-1K4 r,q .[ \\SUBSET-1K6 [.XXREAL-1K1 p,s .] implies x inHIDDENR3 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .["
      proof(rule impI)
        assume A3: "x inHIDDENR3 ].XXREAL-1K4 r,q .[ \\SUBSET-1K6 [.XXREAL-1K1 p,s .]"
        then have A4: " not x inHIDDENR3 [.XXREAL-1K1 p,s .]"
          using xboole_0_def_5 sorry
        have A5: "r <XXREAL-0R3 x"
          using A3 xxreal_1_th_4 sorry
        have A6: "x <XXREAL-0R3 q"
          using A3 xxreal_1_th_4 sorry
        have " not (p <=XXREAL-0R1 x & x <=XXREAL-0R1 s)"
          using A4 xxreal_1_th_1 sorry
        then have "x inHIDDENR3 ].XXREAL-1K4 r,p .[ or x inHIDDENR3 ].XXREAL-1K4 s,q .["
          using A5 A6 xxreal_1_th_4 sorry
        thus "x inHIDDENR3 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .["
          using xboole_0_def_3 sorry
      qed
      assume "x inHIDDENR3 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .["
      then have "x inHIDDENR3 ].XXREAL-1K4 r,p .[ or x inHIDDENR3 ].XXREAL-1K4 s,q .["
        using xboole_0_def_3 sorry
      then have A7: "r <XXREAL-0R3 x & x <XXREAL-0R3 p or s <XXREAL-0R3 x & x <XXREAL-0R3 q"
        using xxreal_1_th_4 sorry
      then have A8: "r <XXREAL-0R3 x"
        using A1 xxreal_0_th_2 sorry
      have "x <XXREAL-0R3 q"
        using A2 A7 xxreal_0_th_2 sorry
      then have A9: "x inHIDDENR3 ].XXREAL-1K4 r,q .["
        using A8 xxreal_1_th_4 sorry
      have " not x inHIDDENR3 [.XXREAL-1K1 p,s .]"
        using A7 xxreal_1_th_1 sorry
      thus "x inHIDDENR3 ].XXREAL-1K4 r,q .[ \\SUBSET-1K6 [.XXREAL-1K1 p,s .]"
        using A9 xboole_0_def_5 sorry
    qed "sorry"
    thus "].XXREAL-1K4 r,q .[ \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR9 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .["
      using membered_def_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_310:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & p <=XXREAL-0R1 q implies [.XXREAL-1K2 r,q .[ \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & p <=XXREAL-0R1 q implies [.XXREAL-1K2 r,q .[ \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
      and A2: "p <=XXREAL-0R1 q"
    have " for x be ExtRealXXREAL-0M1 holds (x inHIDDENR3 [.XXREAL-1K2 r,q .[ \\SUBSET-1K6 [.XXREAL-1K1 p,s .] implies x inHIDDENR3 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .[) & (x inHIDDENR3 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .[ implies x inHIDDENR3 [.XXREAL-1K2 r,q .[ \\SUBSET-1K6 [.XXREAL-1K1 p,s .])"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      show "x inHIDDENR3 [.XXREAL-1K2 r,q .[ \\SUBSET-1K6 [.XXREAL-1K1 p,s .] implies x inHIDDENR3 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .["
      proof(rule impI)
        assume A3: "x inHIDDENR3 [.XXREAL-1K2 r,q .[ \\SUBSET-1K6 [.XXREAL-1K1 p,s .]"
        then have A4: " not x inHIDDENR3 [.XXREAL-1K1 p,s .]"
          using xboole_0_def_5 sorry
        have A5: "r <=XXREAL-0R1 x"
          using A3 xxreal_1_th_3 sorry
        have A6: "x <XXREAL-0R3 q"
          using A3 xxreal_1_th_3 sorry
        have " not (p <=XXREAL-0R1 x & x <=XXREAL-0R1 s)"
          using A4 xxreal_1_th_1 sorry
        then have "x inHIDDENR3 [.XXREAL-1K2 r,p .[ or x inHIDDENR3 ].XXREAL-1K4 s,q .["
          using A5 A6 xxreal_1_th_3 xxreal_1_th_4 sorry
        thus "x inHIDDENR3 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .["
          using xboole_0_def_3 sorry
      qed
      assume "x inHIDDENR3 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .["
      then have "x inHIDDENR3 [.XXREAL-1K2 r,p .[ or x inHIDDENR3 ].XXREAL-1K4 s,q .["
        using xboole_0_def_3 sorry
      then have A7: "r <=XXREAL-0R1 x & x <XXREAL-0R3 p or s <XXREAL-0R3 x & x <XXREAL-0R3 q"
        using xxreal_1_th_3 xxreal_1_th_4 sorry
      then have A8: "r <=XXREAL-0R1 x"
        using A1 xxreal_0_th_2 sorry
      have "x <XXREAL-0R3 q"
        using A2 A7 xxreal_0_th_2 sorry
      then have A9: "x inHIDDENR3 [.XXREAL-1K2 r,q .["
        using A8 xxreal_1_th_3 sorry
      have " not x inHIDDENR3 [.XXREAL-1K1 p,s .]"
        using A7 xxreal_1_th_1 sorry
      thus "x inHIDDENR3 [.XXREAL-1K2 r,q .[ \\SUBSET-1K6 [.XXREAL-1K1 p,s .]"
        using A9 xboole_0_def_5 sorry
    qed "sorry"
    thus "[.XXREAL-1K2 r,q .[ \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_311:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & p <=XXREAL-0R1 q implies ].XXREAL-1K3 r,q .] \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR8 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & p <=XXREAL-0R1 q implies ].XXREAL-1K3 r,q .] \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR8 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "p <=XXREAL-0R1 q"
    have " for x be ExtRealXXREAL-0M1 holds (x inHIDDENR3 ].XXREAL-1K3 r,q .] \\SUBSET-1K6 [.XXREAL-1K1 p,s .] implies x inHIDDENR3 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]) & (x inHIDDENR3 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .] implies x inHIDDENR3 ].XXREAL-1K3 r,q .] \\SUBSET-1K6 [.XXREAL-1K1 p,s .])"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      show "x inHIDDENR3 ].XXREAL-1K3 r,q .] \\SUBSET-1K6 [.XXREAL-1K1 p,s .] implies x inHIDDENR3 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
      proof(rule impI)
        assume A3: "x inHIDDENR3 ].XXREAL-1K3 r,q .] \\SUBSET-1K6 [.XXREAL-1K1 p,s .]"
        then have A4: " not x inHIDDENR3 [.XXREAL-1K1 p,s .]"
          using xboole_0_def_5 sorry
        have A5: "r <XXREAL-0R3 x"
          using A3 xxreal_1_th_2 sorry
        have A6: "x <=XXREAL-0R1 q"
          using A3 xxreal_1_th_2 sorry
        have " not (p <=XXREAL-0R1 x & x <=XXREAL-0R1 s)"
          using A4 xxreal_1_th_1 sorry
        then have "x inHIDDENR3 ].XXREAL-1K4 r,p .[ or x inHIDDENR3 ].XXREAL-1K3 s,q .]"
          using A5 A6 xxreal_1_th_2 xxreal_1_th_4 sorry
        thus "x inHIDDENR3 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
          using xboole_0_def_3 sorry
      qed
      assume "x inHIDDENR3 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
      then have "x inHIDDENR3 ].XXREAL-1K4 r,p .[ or x inHIDDENR3 ].XXREAL-1K3 s,q .]"
        using xboole_0_def_3 sorry
      then have A7: "r <XXREAL-0R3 x & x <XXREAL-0R3 p or s <XXREAL-0R3 x & x <=XXREAL-0R1 q"
        using xxreal_1_th_2 xxreal_1_th_4 sorry
      then have A8: "r <XXREAL-0R3 x"
        using A1 xxreal_0_th_2 sorry
      have "x <=XXREAL-0R1 q"
        using A2 A7 xxreal_0_th_2 sorry
      then have A9: "x inHIDDENR3 ].XXREAL-1K3 r,q .]"
        using A8 xxreal_1_th_2 sorry
      have " not x inHIDDENR3 [.XXREAL-1K1 p,s .]"
        using A7 xxreal_1_th_1 sorry
      thus "x inHIDDENR3 ].XXREAL-1K3 r,q .] \\SUBSET-1K6 [.XXREAL-1K1 p,s .]"
        using A9 xboole_0_def_5 sorry
    qed "sorry"
    thus "].XXREAL-1K3 r,q .] \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR8 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_312:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & p <=XXREAL-0R1 q implies [.XXREAL-1K1 r,q .] \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & p <=XXREAL-0R1 q implies [.XXREAL-1K1 r,q .] \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
      and A2: "p <=XXREAL-0R1 q"
    have " for x be ExtRealXXREAL-0M1 holds (x inHIDDENR3 [.XXREAL-1K1 r,q .] \\SUBSET-1K6 [.XXREAL-1K1 p,s .] implies x inHIDDENR3 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]) & (x inHIDDENR3 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .] implies x inHIDDENR3 [.XXREAL-1K1 r,q .] \\SUBSET-1K6 [.XXREAL-1K1 p,s .])"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      show "x inHIDDENR3 [.XXREAL-1K1 r,q .] \\SUBSET-1K6 [.XXREAL-1K1 p,s .] implies x inHIDDENR3 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
      proof(rule impI)
        assume A3: "x inHIDDENR3 [.XXREAL-1K1 r,q .] \\SUBSET-1K6 [.XXREAL-1K1 p,s .]"
        then have A4: " not x inHIDDENR3 [.XXREAL-1K1 p,s .]"
          using xboole_0_def_5 sorry
        have A5: "r <=XXREAL-0R1 x"
          using A3 xxreal_1_th_1 sorry
        have A6: "x <=XXREAL-0R1 q"
          using A3 xxreal_1_th_1 sorry
        have " not (p <=XXREAL-0R1 x & x <=XXREAL-0R1 s)"
          using A4 xxreal_1_th_1 sorry
        then have "x inHIDDENR3 [.XXREAL-1K2 r,p .[ or x inHIDDENR3 ].XXREAL-1K3 s,q .]"
          using A5 A6 xxreal_1_th_2 xxreal_1_th_3 sorry
        thus "x inHIDDENR3 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
          using xboole_0_def_3 sorry
      qed
      assume "x inHIDDENR3 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
      then have "x inHIDDENR3 [.XXREAL-1K2 r,p .[ or x inHIDDENR3 ].XXREAL-1K3 s,q .]"
        using xboole_0_def_3 sorry
      then have A7: "r <=XXREAL-0R1 x & x <XXREAL-0R3 p or s <XXREAL-0R3 x & x <=XXREAL-0R1 q"
        using xxreal_1_th_2 xxreal_1_th_3 sorry
      then have A8: "r <=XXREAL-0R1 x"
        using A1 xxreal_0_th_2 sorry
      have "x <=XXREAL-0R1 q"
        using A2 A7 xxreal_0_th_2 sorry
      then have A9: "x inHIDDENR3 [.XXREAL-1K1 r,q .]"
        using A8 xxreal_1_th_1 sorry
      have " not x inHIDDENR3 [.XXREAL-1K1 p,s .]"
        using A7 xxreal_1_th_1 sorry
      thus "x inHIDDENR3 [.XXREAL-1K1 r,q .] \\SUBSET-1K6 [.XXREAL-1K1 p,s .]"
        using A9 xboole_0_def_5 sorry
    qed "sorry"
    thus "[.XXREAL-1K1 r,q .] \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_313:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 p & p <=XXREAL-0R1 q implies ].XXREAL-1K4 r,q .[ \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR9 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  not ((r <=XXREAL-0R1 p & p <=XXREAL-0R1 q) &  not ].XXREAL-1K4 r,q .[ \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR9 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 p,q .[)"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    have "[.XXREAL-1K1 p,p .] =MEMBEREDR8 {TARSKIK1 p}"
      using xxreal_1_th_17 sorry
    thus " not ((r <=XXREAL-0R1 p & p <=XXREAL-0R1 q) &  not ].XXREAL-1K4 r,q .[ \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR9 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 p,q .[)"
      using xxreal_1_th_309 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_314:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 p & p <=XXREAL-0R1 q implies [.XXREAL-1K2 r,q .[ \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  not ((r <=XXREAL-0R1 p & p <=XXREAL-0R1 q) &  not [.XXREAL-1K2 r,q .[ \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 p,q .[)"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    have "[.XXREAL-1K1 p,p .] =MEMBEREDR8 {TARSKIK1 p}"
      using xxreal_1_th_17 sorry
    thus " not ((r <=XXREAL-0R1 p & p <=XXREAL-0R1 q) &  not [.XXREAL-1K2 r,q .[ \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 p,q .[)"
      using xxreal_1_th_310 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_315:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 p & p <=XXREAL-0R1 q implies ].XXREAL-1K3 r,q .] \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR8 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  not (( not r <XXREAL-0R3 p & p <=XXREAL-0R1 q) &  not ].XXREAL-1K3 r,q .] \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR8 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 p,q .])"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    have "[.XXREAL-1K1 p,p .] =MEMBEREDR8 {TARSKIK1 p}"
      using xxreal_1_th_17 sorry
    thus " not (( not r <XXREAL-0R3 p & p <=XXREAL-0R1 q) &  not ].XXREAL-1K3 r,q .] \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR8 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 p,q .])"
      using xxreal_1_th_311 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_316:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 p & p <=XXREAL-0R1 q implies [.XXREAL-1K1 r,q .] \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  not ((r <=XXREAL-0R1 p & p <=XXREAL-0R1 q) &  not [.XXREAL-1K1 r,q .] \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 p,q .])"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    have "[.XXREAL-1K1 p,p .] =MEMBEREDR8 {TARSKIK1 p}"
      using xxreal_1_th_17 sorry
    thus " not ((r <=XXREAL-0R1 p & p <=XXREAL-0R1 q) &  not [.XXREAL-1K1 r,q .] \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 p,q .])"
      using xxreal_1_th_312 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_317:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 q & p <=XXREAL-0R1 q implies ].XXREAL-1K3 r,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,q .[ =MEMBEREDR8 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 {TARSKIK1 q}"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  not (( not r <XXREAL-0R3 q & p <=XXREAL-0R1 q) &  not ].XXREAL-1K3 r,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,q .[ =MEMBEREDR8 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 {TARSKIK1 q})"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    have "[.XXREAL-1K1 q,q .] =MEMBEREDR8 {TARSKIK1 q}"
      using xxreal_1_th_17 sorry
    thus " not (( not r <XXREAL-0R3 q & p <=XXREAL-0R1 q) &  not ].XXREAL-1K3 r,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,q .[ =MEMBEREDR8 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 {TARSKIK1 q})"
      using xxreal_1_th_299 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_318:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 q & p <=XXREAL-0R1 q implies [.XXREAL-1K1 r,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,q .[ =MEMBEREDR8 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 {TARSKIK1 q}"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  not ((r <=XXREAL-0R1 q & p <=XXREAL-0R1 q) &  not [.XXREAL-1K1 r,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,q .[ =MEMBEREDR8 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 {TARSKIK1 q})"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    have "[.XXREAL-1K1 q,q .] =MEMBEREDR8 {TARSKIK1 q}"
      using xxreal_1_th_17 sorry
    thus " not ((r <=XXREAL-0R1 q & p <=XXREAL-0R1 q) &  not [.XXREAL-1K1 r,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,q .[ =MEMBEREDR8 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 {TARSKIK1 q})"
      using xxreal_1_th_300 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_319:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 q & p <=XXREAL-0R1 q implies ].XXREAL-1K3 r,q .] \\SUBSET-1K6 [.XXREAL-1K2 p,q .[ =MEMBEREDR8 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 {TARSKIK1 q}"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  not (( not r <XXREAL-0R3 q & p <=XXREAL-0R1 q) &  not ].XXREAL-1K3 r,q .] \\SUBSET-1K6 [.XXREAL-1K2 p,q .[ =MEMBEREDR8 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 {TARSKIK1 q})"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    have "[.XXREAL-1K1 q,q .] =MEMBEREDR8 {TARSKIK1 q}"
      using xxreal_1_th_17 sorry
    thus " not (( not r <XXREAL-0R3 q & p <=XXREAL-0R1 q) &  not ].XXREAL-1K3 r,q .] \\SUBSET-1K6 [.XXREAL-1K2 p,q .[ =MEMBEREDR8 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 {TARSKIK1 q})"
      using xxreal_1_th_303 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_320:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 q & p <=XXREAL-0R1 q implies [.XXREAL-1K1 r,q .] \\SUBSET-1K6 [.XXREAL-1K2 p,q .[ =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 {TARSKIK1 q}"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  not ((r <=XXREAL-0R1 q & p <=XXREAL-0R1 q) &  not [.XXREAL-1K1 r,q .] \\SUBSET-1K6 [.XXREAL-1K2 p,q .[ =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 {TARSKIK1 q})"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    have "[.XXREAL-1K1 q,q .] =MEMBEREDR8 {TARSKIK1 q}"
      using xxreal_1_th_17 sorry
    thus " not ((r <=XXREAL-0R1 q & p <=XXREAL-0R1 q) &  not [.XXREAL-1K1 r,q .] \\SUBSET-1K6 [.XXREAL-1K2 p,q .[ =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 {TARSKIK1 q})"
      using xxreal_1_th_304 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_321:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 s & p <XXREAL-0R3 q implies [.XXREAL-1K2 p,q .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 {TARSKIK1 p} \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not ((p <=XXREAL-0R1 s &  not p <XXREAL-0R3 q) &  not [.XXREAL-1K2 p,q .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 {TARSKIK1 p} \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[)"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "[.XXREAL-1K1 p,p .] =MEMBEREDR8 {TARSKIK1 p}"
      using xxreal_1_th_17 sorry
    thus " not ((p <=XXREAL-0R1 s &  not p <XXREAL-0R3 q) &  not [.XXREAL-1K2 p,q .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 {TARSKIK1 p} \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[)"
      using xxreal_1_th_298 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_322:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 s & p <=XXREAL-0R1 q implies [.XXREAL-1K1 p,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 {TARSKIK1 p} \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not ((p <=XXREAL-0R1 s & p <=XXREAL-0R1 q) &  not [.XXREAL-1K1 p,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 {TARSKIK1 p} \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .])"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "[.XXREAL-1K1 p,p .] =MEMBEREDR8 {TARSKIK1 p}"
      using xxreal_1_th_17 sorry
    thus " not ((p <=XXREAL-0R1 s & p <=XXREAL-0R1 q) &  not [.XXREAL-1K1 p,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 {TARSKIK1 p} \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .])"
      using xxreal_1_th_300 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_323:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 s & p <XXREAL-0R3 q implies [.XXREAL-1K2 p,q .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 {TARSKIK1 p} \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not ((p <=XXREAL-0R1 s &  not p <XXREAL-0R3 q) &  not [.XXREAL-1K2 p,q .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 {TARSKIK1 p} \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .[)"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "[.XXREAL-1K1 p,p .] =MEMBEREDR8 {TARSKIK1 p}"
      using xxreal_1_th_17 sorry
    thus " not ((p <=XXREAL-0R1 s &  not p <XXREAL-0R3 q) &  not [.XXREAL-1K2 p,q .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 {TARSKIK1 p} \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .[)"
      using xxreal_1_th_306 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_324:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 s & p <=XXREAL-0R1 q implies [.XXREAL-1K1 p,q .] \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 {TARSKIK1 p} \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not ((p <=XXREAL-0R1 s & p <=XXREAL-0R1 q) &  not [.XXREAL-1K1 p,q .] \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 {TARSKIK1 p} \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .])"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "[.XXREAL-1K1 p,p .] =MEMBEREDR8 {TARSKIK1 p}"
      using xxreal_1_th_17 sorry
    thus " not ((p <=XXREAL-0R1 s & p <=XXREAL-0R1 q) &  not [.XXREAL-1K1 p,q .] \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 {TARSKIK1 p} \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .])"
      using xxreal_1_th_308 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_325:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <XXREAL-0R3 q implies [.XXREAL-1K2 -inftyXXREAL-0K2,q .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 [.XXREAL-1K1 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
  using xxreal_1_th_298 xxreal_0_th_5 sorry

mtheorem xxreal_1_th_326:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 q implies [.XXREAL-1K1 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 [.XXREAL-1K1 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not (p <=XXREAL-0R1 q &  not [.XXREAL-1K1 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 [.XXREAL-1K1 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .])"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "-inftyXXREAL-0K2 <=XXREAL-0R1 s"
      using xxreal_0_th_5 sorry
    thus " not (p <=XXREAL-0R1 q &  not [.XXREAL-1K1 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 [.XXREAL-1K1 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .])"
      using xxreal_1_th_300 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_327:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 q implies [.XXREAL-1K2 -inftyXXREAL-0K2,q .[ \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR8 [.XXREAL-1K2 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not (p <=XXREAL-0R1 q &  not [.XXREAL-1K2 -inftyXXREAL-0K2,q .[ \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR8 [.XXREAL-1K2 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[)"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "-inftyXXREAL-0K2 <=XXREAL-0R1 s"
      using xxreal_0_th_5 sorry
    thus " not (p <=XXREAL-0R1 q &  not [.XXREAL-1K2 -inftyXXREAL-0K2,q .[ \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR8 [.XXREAL-1K2 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[)"
      using xxreal_1_th_302 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_328:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 q implies [.XXREAL-1K1 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR8 [.XXREAL-1K2 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not (p <=XXREAL-0R1 q &  not [.XXREAL-1K1 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR8 [.XXREAL-1K2 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .])"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "-inftyXXREAL-0K2 <=XXREAL-0R1 s"
      using xxreal_0_th_5 sorry
    thus " not (p <=XXREAL-0R1 q &  not [.XXREAL-1K1 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR8 [.XXREAL-1K2 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .])"
      using xxreal_1_th_304 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_329:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <XXREAL-0R3 q implies [.XXREAL-1K2 -inftyXXREAL-0K2,q .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 [.XXREAL-1K1 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .["
  using xxreal_1_th_306 xxreal_0_th_5 sorry

mtheorem xxreal_1_th_330:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 q implies [.XXREAL-1K1 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 [.XXREAL-1K1 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not (p <=XXREAL-0R1 q &  not [.XXREAL-1K1 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 [.XXREAL-1K1 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .])"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "-inftyXXREAL-0K2 <=XXREAL-0R1 s"
      using xxreal_0_th_5 sorry
    thus " not (p <=XXREAL-0R1 q &  not [.XXREAL-1K1 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 [.XXREAL-1K1 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .])"
      using xxreal_1_th_308 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_331:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 q implies [.XXREAL-1K2 -inftyXXREAL-0K2,q .[ \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR8 [.XXREAL-1K2 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not (p <=XXREAL-0R1 q &  not [.XXREAL-1K2 -inftyXXREAL-0K2,q .[ \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR8 [.XXREAL-1K2 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .[)"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "-inftyXXREAL-0K2 <=XXREAL-0R1 s"
      using xxreal_0_th_5 sorry
    thus " not (p <=XXREAL-0R1 q &  not [.XXREAL-1K2 -inftyXXREAL-0K2,q .[ \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR8 [.XXREAL-1K2 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .[)"
      using xxreal_1_th_310 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_332:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 q implies [.XXREAL-1K1 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR8 [.XXREAL-1K2 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not (p <=XXREAL-0R1 q &  not [.XXREAL-1K1 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR8 [.XXREAL-1K2 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .])"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "-inftyXXREAL-0K2 <=XXREAL-0R1 s"
      using xxreal_0_th_5 sorry
    thus " not (p <=XXREAL-0R1 q &  not [.XXREAL-1K1 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR8 [.XXREAL-1K2 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .])"
      using xxreal_1_th_312 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_333:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds p <XXREAL-0R3 q implies ].XXREAL-1K4 -inftyXXREAL-0K2,q .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 ].XXREAL-1K3 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not ( not p <XXREAL-0R3 q &  not ].XXREAL-1K4 -inftyXXREAL-0K2,q .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 ].XXREAL-1K3 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[)"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    have "s inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    then have "-inftyXXREAL-0K2 <XXREAL-0R3 s"
      using xxreal_0_th_12 sorry
    thus " not ( not p <XXREAL-0R3 q &  not ].XXREAL-1K4 -inftyXXREAL-0K2,q .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 ].XXREAL-1K3 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[)"
      using xxreal_1_th_297 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_334:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds p <=XXREAL-0R1 q implies ].XXREAL-1K3 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 ].XXREAL-1K3 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not (p <=XXREAL-0R1 q &  not ].XXREAL-1K3 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 ].XXREAL-1K3 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .])"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    have "s inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    thus " not (p <=XXREAL-0R1 q &  not ].XXREAL-1K3 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 ].XXREAL-1K3 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .])"
      using xxreal_1_th_299 xxreal_0_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_335:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds p <=XXREAL-0R1 q implies ].XXREAL-1K4 -inftyXXREAL-0K2,q .[ \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR9 ].XXREAL-1K4 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not (p <=XXREAL-0R1 q &  not ].XXREAL-1K4 -inftyXXREAL-0K2,q .[ \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR9 ].XXREAL-1K4 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[)"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    have "s inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    thus " not (p <=XXREAL-0R1 q &  not ].XXREAL-1K4 -inftyXXREAL-0K2,q .[ \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR9 ].XXREAL-1K4 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .[)"
      using xxreal_1_th_301 xxreal_0_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_336:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds p <=XXREAL-0R1 q implies ].XXREAL-1K3 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR8 ].XXREAL-1K4 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not (p <=XXREAL-0R1 q &  not ].XXREAL-1K3 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR8 ].XXREAL-1K4 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .])"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    have "s inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    thus " not (p <=XXREAL-0R1 q &  not ].XXREAL-1K3 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR8 ].XXREAL-1K4 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .])"
      using xxreal_1_th_303 xxreal_0_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_337:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds p <XXREAL-0R3 q implies ].XXREAL-1K4 -inftyXXREAL-0K2,q .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 ].XXREAL-1K3 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not ( not p <XXREAL-0R3 q &  not ].XXREAL-1K4 -inftyXXREAL-0K2,q .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 ].XXREAL-1K3 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .[)"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    have "s inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    then have "-inftyXXREAL-0K2 <XXREAL-0R3 s"
      using xxreal_0_th_12 sorry
    thus " not ( not p <XXREAL-0R3 q &  not ].XXREAL-1K4 -inftyXXREAL-0K2,q .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 ].XXREAL-1K3 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .[)"
      using xxreal_1_th_305 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_338:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds p <=XXREAL-0R1 q implies ].XXREAL-1K3 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 ].XXREAL-1K3 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not (p <=XXREAL-0R1 q &  not ].XXREAL-1K3 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 ].XXREAL-1K3 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .])"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    have "s inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    thus " not (p <=XXREAL-0R1 q &  not ].XXREAL-1K3 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 ].XXREAL-1K3 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .])"
      using xxreal_1_th_307 xxreal_0_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_339:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 q implies ].XXREAL-1K4 -inftyXXREAL-0K2,q .[ \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR9 ].XXREAL-1K4 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not (p <=XXREAL-0R1 q &  not ].XXREAL-1K4 -inftyXXREAL-0K2,q .[ \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR9 ].XXREAL-1K4 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .[)"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "-inftyXXREAL-0K2 <=XXREAL-0R1 s"
      using xxreal_0_th_5 sorry
    thus " not (p <=XXREAL-0R1 q &  not ].XXREAL-1K4 -inftyXXREAL-0K2,q .[ \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR9 ].XXREAL-1K4 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .[)"
      using xxreal_1_th_309 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_340:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds p <=XXREAL-0R1 q implies ].XXREAL-1K3 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR8 ].XXREAL-1K4 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not (p <=XXREAL-0R1 q &  not ].XXREAL-1K3 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR8 ].XXREAL-1K4 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .])"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    have "s inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    thus " not (p <=XXREAL-0R1 q &  not ].XXREAL-1K3 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR8 ].XXREAL-1K4 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .])"
      using xxreal_1_th_311 xxreal_0_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_341:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 q implies [.XXREAL-1K2 -inftyXXREAL-0K2,q .[ \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR8 [.XXREAL-1K2 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  not (p <=XXREAL-0R1 q &  not [.XXREAL-1K2 -inftyXXREAL-0K2,q .[ \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR8 [.XXREAL-1K2 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 p,q .[)"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    have "-inftyXXREAL-0K2 <=XXREAL-0R1 p"
      using xxreal_0_th_5 sorry
    thus " not (p <=XXREAL-0R1 q &  not [.XXREAL-1K2 -inftyXXREAL-0K2,q .[ \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR8 [.XXREAL-1K2 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 p,q .[)"
      using xxreal_1_th_314 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_342:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 q implies [.XXREAL-1K1 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR8 [.XXREAL-1K2 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 p,q .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  not (p <=XXREAL-0R1 q &  not [.XXREAL-1K1 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR8 [.XXREAL-1K2 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 p,q .])"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    have "-inftyXXREAL-0K2 <=XXREAL-0R1 p"
      using xxreal_0_th_5 sorry
    thus " not (p <=XXREAL-0R1 q &  not [.XXREAL-1K1 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR8 [.XXREAL-1K2 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 p,q .])"
      using xxreal_1_th_316 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_343:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 q implies [.XXREAL-1K1 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,q .[ =MEMBEREDR8 [.XXREAL-1K1 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 {TARSKIK1 q}"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  not (p <=XXREAL-0R1 q &  not [.XXREAL-1K1 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,q .[ =MEMBEREDR8 [.XXREAL-1K1 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 {TARSKIK1 q})"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    have "-inftyXXREAL-0K2 <=XXREAL-0R1 q"
      using xxreal_0_th_5 sorry
    thus " not (p <=XXREAL-0R1 q &  not [.XXREAL-1K1 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,q .[ =MEMBEREDR8 [.XXREAL-1K1 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 {TARSKIK1 q})"
      using xxreal_1_th_318 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_344:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 q implies [.XXREAL-1K1 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 [.XXREAL-1K2 p,q .[ =MEMBEREDR8 [.XXREAL-1K2 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 {TARSKIK1 q}"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  not (p <=XXREAL-0R1 q &  not [.XXREAL-1K1 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 [.XXREAL-1K2 p,q .[ =MEMBEREDR8 [.XXREAL-1K2 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 {TARSKIK1 q})"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    have "-inftyXXREAL-0K2 <=XXREAL-0R1 q"
      using xxreal_0_th_5 sorry
    thus " not (p <=XXREAL-0R1 q &  not [.XXREAL-1K1 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 [.XXREAL-1K2 p,q .[ =MEMBEREDR8 [.XXREAL-1K2 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 {TARSKIK1 q})"
      using xxreal_1_th_320 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_345:
" for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds [.XXREAL-1K1 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 ].XXREAL-1K4 -inftyXXREAL-0K2,s .[ =MEMBEREDR8 {TARSKIK1 -inftyXXREAL-0K2 } \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
proof-
  have " for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds [.XXREAL-1K1 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 ].XXREAL-1K4 -inftyXXREAL-0K2,s .[ =MEMBEREDR8 {TARSKIK1 -inftyXXREAL-0K2 } \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
  proof(rule ballI,rule ballI)
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have A1: "-inftyXXREAL-0K2 <=XXREAL-0R1 s"
      using xxreal_0_th_5 sorry
    have "-inftyXXREAL-0K2 <=XXREAL-0R1 q"
      using xxreal_0_th_5 sorry
    thus "[.XXREAL-1K1 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 ].XXREAL-1K4 -inftyXXREAL-0K2,s .[ =MEMBEREDR8 {TARSKIK1 -inftyXXREAL-0K2 } \\/XBOOLE-0K2 [.XXREAL-1K1 s,q .]"
      using A1 xxreal_1_th_322 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_346:
" for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds [.XXREAL-1K1 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 ].XXREAL-1K3 -inftyXXREAL-0K2,s .] =MEMBEREDR8 {TARSKIK1 -inftyXXREAL-0K2 } \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
proof-
  have " for q be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds [.XXREAL-1K1 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 ].XXREAL-1K3 -inftyXXREAL-0K2,s .] =MEMBEREDR8 {TARSKIK1 -inftyXXREAL-0K2 } \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
  proof(rule ballI,rule ballI)
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have A1: "-inftyXXREAL-0K2 <=XXREAL-0R1 s"
      using xxreal_0_th_5 sorry
    have "-inftyXXREAL-0K2 <=XXREAL-0R1 q"
      using xxreal_0_th_5 sorry
    thus "[.XXREAL-1K1 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 ].XXREAL-1K3 -inftyXXREAL-0K2,s .] =MEMBEREDR8 {TARSKIK1 -inftyXXREAL-0K2 } \\/XBOOLE-0K2 ].XXREAL-1K3 s,q .]"
      using A1 xxreal_1_th_324 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_347:
" for s be ExtRealXXREAL-0M1 holds  for q be RealXREAL-0M1 holds [.XXREAL-1K2 -inftyXXREAL-0K2,q .[ \\SUBSET-1K6 ].XXREAL-1K4 -inftyXXREAL-0K2,s .[ =MEMBEREDR8 {TARSKIK1 -inftyXXREAL-0K2 } \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
proof-
  have " for s be ExtRealXXREAL-0M1 holds  for q be RealXREAL-0M1 holds [.XXREAL-1K2 -inftyXXREAL-0K2,q .[ \\SUBSET-1K6 ].XXREAL-1K4 -inftyXXREAL-0K2,s .[ =MEMBEREDR8 {TARSKIK1 -inftyXXREAL-0K2 } \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
  proof(rule ballI,rule ballI)
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be RealXREAL-0M1"
    have A1: "q inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    have "-inftyXXREAL-0K2 <=XXREAL-0R1 s"
      using xxreal_0_th_5 sorry
    thus "[.XXREAL-1K2 -inftyXXREAL-0K2,q .[ \\SUBSET-1K6 ].XXREAL-1K4 -inftyXXREAL-0K2,s .[ =MEMBEREDR8 {TARSKIK1 -inftyXXREAL-0K2 } \\/XBOOLE-0K2 [.XXREAL-1K2 s,q .["
      using A1 xxreal_1_th_321 xxreal_0_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_348:
" for s be ExtRealXXREAL-0M1 holds  for q be RealXREAL-0M1 holds [.XXREAL-1K2 -inftyXXREAL-0K2,q .[ \\SUBSET-1K6 ].XXREAL-1K3 -inftyXXREAL-0K2,s .] =MEMBEREDR8 {TARSKIK1 -inftyXXREAL-0K2 } \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .["
proof-
  have " for s be ExtRealXXREAL-0M1 holds  for q be RealXREAL-0M1 holds [.XXREAL-1K2 -inftyXXREAL-0K2,q .[ \\SUBSET-1K6 ].XXREAL-1K3 -inftyXXREAL-0K2,s .] =MEMBEREDR8 {TARSKIK1 -inftyXXREAL-0K2 } \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .["
  proof(rule ballI,rule ballI)
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be RealXREAL-0M1"
    have A1: "q inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    have "-inftyXXREAL-0K2 <=XXREAL-0R1 s"
      using xxreal_0_th_5 sorry
    thus "[.XXREAL-1K2 -inftyXXREAL-0K2,q .[ \\SUBSET-1K6 ].XXREAL-1K3 -inftyXXREAL-0K2,s .] =MEMBEREDR8 {TARSKIK1 -inftyXXREAL-0K2 } \\/XBOOLE-0K2 ].XXREAL-1K4 s,q .["
      using A1 xxreal_1_th_323 xxreal_0_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_349:
" for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 q implies ].XXREAL-1K4 -inftyXXREAL-0K2,q .[ \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR9 ].XXREAL-1K4 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 p,q .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be ExtRealXXREAL-0M1 holds  not (p <=XXREAL-0R1 q &  not ].XXREAL-1K4 -inftyXXREAL-0K2,q .[ \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR9 ].XXREAL-1K4 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 p,q .[)"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    have "-inftyXXREAL-0K2 <=XXREAL-0R1 p"
      using xxreal_0_th_5 sorry
    thus " not (p <=XXREAL-0R1 q &  not ].XXREAL-1K4 -inftyXXREAL-0K2,q .[ \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR9 ].XXREAL-1K4 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 p,q .[)"
      using xxreal_1_th_313 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_350:
" for q be ExtRealXXREAL-0M1 holds  for p be RealXREAL-0M1 holds p <=XXREAL-0R1 q implies ].XXREAL-1K3 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR8 ].XXREAL-1K4 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 p,q .]"
proof-
  have " for q be ExtRealXXREAL-0M1 holds  for p be RealXREAL-0M1 holds  not (p <=XXREAL-0R1 q &  not ].XXREAL-1K3 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR8 ].XXREAL-1K4 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 p,q .])"
  proof(rule ballI,rule ballI)
    fix q assume [ty]: "q be ExtRealXXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    have "p inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    thus " not (p <=XXREAL-0R1 q &  not ].XXREAL-1K3 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR8 ].XXREAL-1K4 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 p,q .])"
      using xxreal_1_th_315 xxreal_0_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_351:
" for p be ExtRealXXREAL-0M1 holds  for q be RealXREAL-0M1 holds p <=XXREAL-0R1 q implies ].XXREAL-1K3 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,q .[ =MEMBEREDR8 ].XXREAL-1K3 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 {TARSKIK1 q}"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be RealXREAL-0M1 holds  not (p <=XXREAL-0R1 q &  not ].XXREAL-1K3 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,q .[ =MEMBEREDR8 ].XXREAL-1K3 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 {TARSKIK1 q})"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be RealXREAL-0M1"
    have "q inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    thus " not (p <=XXREAL-0R1 q &  not ].XXREAL-1K3 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 ].XXREAL-1K4 p,q .[ =MEMBEREDR8 ].XXREAL-1K3 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 {TARSKIK1 q})"
      using xxreal_1_th_317 xxreal_0_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_352:
" for p be ExtRealXXREAL-0M1 holds  for q be RealXREAL-0M1 holds p <=XXREAL-0R1 q implies ].XXREAL-1K3 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 [.XXREAL-1K2 p,q .[ =MEMBEREDR9 ].XXREAL-1K4 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 {TARSKIK1 q}"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for q be RealXREAL-0M1 holds  not (p <=XXREAL-0R1 q &  not ].XXREAL-1K3 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 [.XXREAL-1K2 p,q .[ =MEMBEREDR9 ].XXREAL-1K4 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 {TARSKIK1 q})"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix q assume [ty]: "q be RealXREAL-0M1"
    have "q inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    thus " not (p <=XXREAL-0R1 q &  not ].XXREAL-1K3 -inftyXXREAL-0K2,q .] \\SUBSET-1K6 [.XXREAL-1K2 p,q .[ =MEMBEREDR9 ].XXREAL-1K4 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 {TARSKIK1 q})"
      using xxreal_1_th_319 xxreal_0_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_353:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies ].XXREAL-1K3 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,+inftyXXREAL-0K1 .]"
  using xxreal_1_th_299 xxreal_0_th_3 sorry

mtheorem xxreal_1_th_354:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s implies [.XXREAL-1K1 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,+inftyXXREAL-0K1 .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not (r <=XXREAL-0R1 s &  not [.XXREAL-1K1 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,+inftyXXREAL-0K1 .])"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "p <=XXREAL-0R1 +inftyXXREAL-0K1"
      using xxreal_0_th_3 sorry
    thus " not (r <=XXREAL-0R1 s &  not [.XXREAL-1K1 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,+inftyXXREAL-0K1 .])"
      using xxreal_1_th_300 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_355:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies ].XXREAL-1K4 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR8 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,+inftyXXREAL-0K1 .["
  using xxreal_1_th_301 xxreal_0_th_3 sorry

mtheorem xxreal_1_th_356:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s implies [.XXREAL-1K2 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,+inftyXXREAL-0K1 .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not (r <=XXREAL-0R1 s &  not [.XXREAL-1K2 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,+inftyXXREAL-0K1 .[)"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "p <=XXREAL-0R1 +inftyXXREAL-0K1"
      using xxreal_0_th_3 sorry
    thus " not (r <=XXREAL-0R1 s &  not [.XXREAL-1K2 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,+inftyXXREAL-0K1 .[)"
      using xxreal_1_th_302 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_357:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies ].XXREAL-1K3 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR8 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,+inftyXXREAL-0K1 .]"
  using xxreal_1_th_303 xxreal_0_th_3 sorry

mtheorem xxreal_1_th_358:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s implies [.XXREAL-1K1 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,+inftyXXREAL-0K1 .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not (r <=XXREAL-0R1 s &  not [.XXREAL-1K1 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,+inftyXXREAL-0K1 .])"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "p <=XXREAL-0R1 +inftyXXREAL-0K1"
      using xxreal_0_th_3 sorry
    thus " not (r <=XXREAL-0R1 s &  not [.XXREAL-1K1 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,+inftyXXREAL-0K1 .])"
      using xxreal_1_th_304 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_359:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies ].XXREAL-1K3 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,+inftyXXREAL-0K1 .]"
  using xxreal_1_th_307 xxreal_0_th_3 sorry

mtheorem xxreal_1_th_360:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s implies [.XXREAL-1K1 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,+inftyXXREAL-0K1 .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not (r <=XXREAL-0R1 s &  not [.XXREAL-1K1 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,+inftyXXREAL-0K1 .])"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "p <=XXREAL-0R1 +inftyXXREAL-0K1"
      using xxreal_0_th_3 sorry
    thus " not (r <=XXREAL-0R1 s &  not [.XXREAL-1K1 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,+inftyXXREAL-0K1 .])"
      using xxreal_1_th_308 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_361:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s implies ].XXREAL-1K4 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR9 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not (r <=XXREAL-0R1 s &  not ].XXREAL-1K4 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR9 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .[)"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "p <=XXREAL-0R1 +inftyXXREAL-0K1"
      using xxreal_0_th_3 sorry
    thus " not (r <=XXREAL-0R1 s &  not ].XXREAL-1K4 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR9 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .[)"
      using xxreal_1_th_309 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_362:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s implies [.XXREAL-1K2 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not (r <=XXREAL-0R1 s &  not [.XXREAL-1K2 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .[)"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "p <=XXREAL-0R1 +inftyXXREAL-0K1"
      using xxreal_0_th_3 sorry
    thus " not (r <=XXREAL-0R1 s &  not [.XXREAL-1K2 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .[)"
      using xxreal_1_th_310 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_363:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies ].XXREAL-1K3 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR8 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,+inftyXXREAL-0K1 .]"
  using xxreal_1_th_311 xxreal_0_th_3 sorry

mtheorem xxreal_1_th_364:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s implies [.XXREAL-1K1 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,+inftyXXREAL-0K1 .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not (r <=XXREAL-0R1 s &  not [.XXREAL-1K1 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,+inftyXXREAL-0K1 .])"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "p <=XXREAL-0R1 +inftyXXREAL-0K1"
      using xxreal_0_th_3 sorry
    thus " not (r <=XXREAL-0R1 s &  not [.XXREAL-1K1 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,+inftyXXREAL-0K1 .])"
      using xxreal_1_th_312 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_365:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 p implies ].XXREAL-1K4 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR9 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 p,+inftyXXREAL-0K1 .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  not (r <=XXREAL-0R1 p &  not ].XXREAL-1K4 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR9 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 p,+inftyXXREAL-0K1 .[)"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    have "p <=XXREAL-0R1 +inftyXXREAL-0K1"
      using xxreal_0_th_3 sorry
    thus " not (r <=XXREAL-0R1 p &  not ].XXREAL-1K4 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR9 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 p,+inftyXXREAL-0K1 .[)"
      using xxreal_1_th_313 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_366:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 p implies [.XXREAL-1K2 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 p,+inftyXXREAL-0K1 .["
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  not (r <=XXREAL-0R1 p &  not [.XXREAL-1K2 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 p,+inftyXXREAL-0K1 .[)"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    have "p <=XXREAL-0R1 +inftyXXREAL-0K1"
      using xxreal_0_th_3 sorry
    thus " not (r <=XXREAL-0R1 p &  not [.XXREAL-1K2 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 p,+inftyXXREAL-0K1 .[)"
      using xxreal_1_th_314 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_367:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 p implies ].XXREAL-1K3 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR8 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 p,+inftyXXREAL-0K1 .]"
  using xxreal_1_th_315 xxreal_0_th_3 sorry

mtheorem xxreal_1_th_368:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 p implies [.XXREAL-1K1 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 p,+inftyXXREAL-0K1 .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds  not (r <=XXREAL-0R1 p &  not [.XXREAL-1K1 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 p,+inftyXXREAL-0K1 .])"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    have "p <=XXREAL-0R1 +inftyXXREAL-0K1"
      using xxreal_0_th_3 sorry
    thus " not (r <=XXREAL-0R1 p &  not [.XXREAL-1K1 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 p,+inftyXXREAL-0K1 .])"
      using xxreal_1_th_316 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_369:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds [.XXREAL-1K1 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 ].XXREAL-1K4 p,+inftyXXREAL-0K1 .[ =MEMBEREDR8 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 {TARSKIK1 +inftyXXREAL-0K1 }"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds [.XXREAL-1K1 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 ].XXREAL-1K4 p,+inftyXXREAL-0K1 .[ =MEMBEREDR8 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 {TARSKIK1 +inftyXXREAL-0K1 }"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    have A1: "r <=XXREAL-0R1 +inftyXXREAL-0K1"
      using xxreal_0_th_3 sorry
    have "p <=XXREAL-0R1 +inftyXXREAL-0K1"
      using xxreal_0_th_3 sorry
    thus "[.XXREAL-1K1 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 ].XXREAL-1K4 p,+inftyXXREAL-0K1 .[ =MEMBEREDR8 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 {TARSKIK1 +inftyXXREAL-0K1 }"
      using A1 xxreal_1_th_318 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_370:
" for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds [.XXREAL-1K1 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 [.XXREAL-1K2 p,+inftyXXREAL-0K1 .[ =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 {TARSKIK1 +inftyXXREAL-0K1 }"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds [.XXREAL-1K1 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 [.XXREAL-1K2 p,+inftyXXREAL-0K1 .[ =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 {TARSKIK1 +inftyXXREAL-0K1 }"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    have A1: "r <=XXREAL-0R1 +inftyXXREAL-0K1"
      using xxreal_0_th_3 sorry
    have "p <=XXREAL-0R1 +inftyXXREAL-0K1"
      using xxreal_0_th_3 sorry
    thus "[.XXREAL-1K1 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 [.XXREAL-1K2 p,+inftyXXREAL-0K1 .[ =MEMBEREDR8 [.XXREAL-1K2 r,p .[ \\/XBOOLE-0K2 {TARSKIK1 +inftyXXREAL-0K1 }"
      using A1 xxreal_1_th_320 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_371:
" for p be ExtRealXXREAL-0M1 holds  for r be RealXREAL-0M1 holds ].XXREAL-1K3 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 ].XXREAL-1K4 p,+inftyXXREAL-0K1 .[ =MEMBEREDR8 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 {TARSKIK1 +inftyXXREAL-0K1 }"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for r be RealXREAL-0M1 holds ].XXREAL-1K3 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 ].XXREAL-1K4 p,+inftyXXREAL-0K1 .[ =MEMBEREDR8 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 {TARSKIK1 +inftyXXREAL-0K1 }"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    have "r inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    then have "r <XXREAL-0R3 +inftyXXREAL-0K1"
      using xxreal_0_th_9 sorry
    thus "].XXREAL-1K3 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 ].XXREAL-1K4 p,+inftyXXREAL-0K1 .[ =MEMBEREDR8 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 {TARSKIK1 +inftyXXREAL-0K1 }"
      using xxreal_1_th_317 xxreal_0_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_372:
" for p be ExtRealXXREAL-0M1 holds  for r be RealXREAL-0M1 holds ].XXREAL-1K3 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 [.XXREAL-1K2 p,+inftyXXREAL-0K1 .[ =MEMBEREDR8 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 {TARSKIK1 +inftyXXREAL-0K1 }"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for r be RealXREAL-0M1 holds ].XXREAL-1K3 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 [.XXREAL-1K2 p,+inftyXXREAL-0K1 .[ =MEMBEREDR8 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 {TARSKIK1 +inftyXXREAL-0K1 }"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    have "r inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    then have "r <XXREAL-0R3 +inftyXXREAL-0K1"
      using xxreal_0_th_9 sorry
    thus "].XXREAL-1K3 r,+inftyXXREAL-0K1 .] \\SUBSET-1K6 [.XXREAL-1K2 p,+inftyXXREAL-0K1 .[ =MEMBEREDR8 ].XXREAL-1K4 r,p .[ \\/XBOOLE-0K2 {TARSKIK1 +inftyXXREAL-0K1 }"
      using xxreal_1_th_319 xxreal_0_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_373:
" for p be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 s implies [.XXREAL-1K1 p,+inftyXXREAL-0K1 .] \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 {TARSKIK1 p} \\/XBOOLE-0K2 [.XXREAL-1K1 s,+inftyXXREAL-0K1 .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not (p <=XXREAL-0R1 s &  not [.XXREAL-1K1 p,+inftyXXREAL-0K1 .] \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 {TARSKIK1 p} \\/XBOOLE-0K2 [.XXREAL-1K1 s,+inftyXXREAL-0K1 .])"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "p <=XXREAL-0R1 +inftyXXREAL-0K1"
      using xxreal_0_th_3 sorry
    thus " not (p <=XXREAL-0R1 s &  not [.XXREAL-1K1 p,+inftyXXREAL-0K1 .] \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 {TARSKIK1 p} \\/XBOOLE-0K2 [.XXREAL-1K1 s,+inftyXXREAL-0K1 .])"
      using xxreal_1_th_322 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_374:
" for p be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds p <=XXREAL-0R1 s implies [.XXREAL-1K1 p,+inftyXXREAL-0K1 .] \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 {TARSKIK1 p} \\/XBOOLE-0K2 ].XXREAL-1K3 s,+inftyXXREAL-0K1 .]"
proof-
  have " for p be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not (p <=XXREAL-0R1 s &  not [.XXREAL-1K1 p,+inftyXXREAL-0K1 .] \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 {TARSKIK1 p} \\/XBOOLE-0K2 ].XXREAL-1K3 s,+inftyXXREAL-0K1 .])"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "p <=XXREAL-0R1 +inftyXXREAL-0K1"
      using xxreal_0_th_3 sorry
    thus " not (p <=XXREAL-0R1 s &  not [.XXREAL-1K1 p,+inftyXXREAL-0K1 .] \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 {TARSKIK1 p} \\/XBOOLE-0K2 ].XXREAL-1K3 s,+inftyXXREAL-0K1 .])"
      using xxreal_1_th_324 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_375:
" for p be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds [.XXREAL-1K1 -inftyXXREAL-0K2,+inftyXXREAL-0K1 .] \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 [.XXREAL-1K1 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,+inftyXXREAL-0K1 .]"
  using xxreal_1_th_326 xxreal_0_th_3 sorry

mtheorem xxreal_1_th_376:
" for p be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds [.XXREAL-1K2 -inftyXXREAL-0K2,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR8 [.XXREAL-1K2 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,+inftyXXREAL-0K1 .["
  using xxreal_1_th_327 xxreal_0_th_3 sorry

mtheorem xxreal_1_th_377:
" for p be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds [.XXREAL-1K1 -inftyXXREAL-0K2,+inftyXXREAL-0K1 .] \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR8 [.XXREAL-1K2 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,+inftyXXREAL-0K1 .]"
  using xxreal_1_th_328 xxreal_0_th_3 sorry

mtheorem xxreal_1_th_378:
" for p be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds [.XXREAL-1K1 -inftyXXREAL-0K2,+inftyXXREAL-0K1 .] \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 [.XXREAL-1K1 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,+inftyXXREAL-0K1 .]"
  using xxreal_1_th_330 xxreal_0_th_3 sorry

mtheorem xxreal_1_th_379:
" for p be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds [.XXREAL-1K2 -inftyXXREAL-0K2,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR8 [.XXREAL-1K2 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .["
  using xxreal_1_th_331 xxreal_0_th_3 sorry

mtheorem xxreal_1_th_380:
" for p be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds [.XXREAL-1K1 -inftyXXREAL-0K2,+inftyXXREAL-0K1 .] \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR8 [.XXREAL-1K2 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,+inftyXXREAL-0K1 .]"
  using xxreal_1_th_332 xxreal_0_th_3 sorry

mtheorem xxreal_1_th_381:
" for p be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds ].XXREAL-1K3 -inftyXXREAL-0K2,+inftyXXREAL-0K1 .] \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 ].XXREAL-1K3 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,+inftyXXREAL-0K1 .]"
  using xxreal_1_th_334 xxreal_0_th_3 sorry

mtheorem xxreal_1_th_382:
" for p be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds REALNUMBERSK2 \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR9 ].XXREAL-1K4 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 [.XXREAL-1K2 s,+inftyXXREAL-0K1 .["
  using xxreal_1_th_224 xxreal_1_th_335 xxreal_0_th_3 sorry

mtheorem xxreal_1_th_383:
" for p be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds ].XXREAL-1K3 -inftyXXREAL-0K2,+inftyXXREAL-0K1 .] \\SUBSET-1K6 [.XXREAL-1K2 p,s .[ =MEMBEREDR8 ].XXREAL-1K4 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 [.XXREAL-1K1 s,+inftyXXREAL-0K1 .]"
  using xxreal_1_th_336 xxreal_0_th_3 sorry

mtheorem xxreal_1_th_384:
" for p be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds ].XXREAL-1K3 -inftyXXREAL-0K2,+inftyXXREAL-0K1 .] \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 ].XXREAL-1K3 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 ].XXREAL-1K3 s,+inftyXXREAL-0K1 .]"
  using xxreal_1_th_338 xxreal_0_th_3 sorry

mtheorem xxreal_1_th_385:
" for p be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds REALNUMBERSK2 \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR9 ].XXREAL-1K4 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .["
  using xxreal_1_th_224 xxreal_1_th_339 xxreal_0_th_3 sorry

mtheorem xxreal_1_th_386:
" for p be ExtRealXXREAL-0M1 holds  for s be RealXREAL-0M1 holds ].XXREAL-1K3 -inftyXXREAL-0K2,+inftyXXREAL-0K1 .] \\SUBSET-1K6 [.XXREAL-1K1 p,s .] =MEMBEREDR8 ].XXREAL-1K4 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 s,+inftyXXREAL-0K1 .]"
  using xxreal_1_th_340 xxreal_0_th_3 sorry

mtheorem xxreal_1_th_387:
" for p be ExtRealXXREAL-0M1 holds [.XXREAL-1K2 -inftyXXREAL-0K2,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR8 [.XXREAL-1K2 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 p,+inftyXXREAL-0K1 .["
  using xxreal_1_th_341 xxreal_0_th_3 sorry

mtheorem xxreal_1_th_388:
" for p be ExtRealXXREAL-0M1 holds [.XXREAL-1K1 -inftyXXREAL-0K2,+inftyXXREAL-0K1 .] \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR8 [.XXREAL-1K2 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 p,+inftyXXREAL-0K1 .]"
  using xxreal_1_th_342 xxreal_0_th_3 sorry

mtheorem xxreal_1_th_389:
" for p be ExtRealXXREAL-0M1 holds REALNUMBERSK2 \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR9 ].XXREAL-1K4 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 ].XXREAL-1K4 p,+inftyXXREAL-0K1 .["
  using xxreal_1_th_224 xxreal_1_th_349 xxreal_0_th_3 sorry

mtheorem xxreal_1_th_390:
" for p be RealXREAL-0M1 holds ].XXREAL-1K3 -inftyXXREAL-0K2,+inftyXXREAL-0K1 .] \\SUBSET-1K6 {TARSKIK1 p} =MEMBEREDR8 ].XXREAL-1K4 -inftyXXREAL-0K2,p .[ \\/XBOOLE-0K2 ].XXREAL-1K3 p,+inftyXXREAL-0K1 .]"
  using xxreal_1_th_350 xxreal_0_th_3 sorry

mtheorem xxreal_1_th_391:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for p be RealXREAL-0M1 holds r <XXREAL-0R3 s implies ].XXREAL-1K4 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,+inftyXXREAL-0K1 .["
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for p be RealXREAL-0M1 holds  not ( not r <XXREAL-0R3 s &  not ].XXREAL-1K4 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,+inftyXXREAL-0K1 .[)"
  proof(rule ballI,rule ballI,rule ballI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    have "p inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    then have "p <XXREAL-0R3 +inftyXXREAL-0K1"
      using xxreal_0_th_9 sorry
    thus " not ( not r <XXREAL-0R3 s &  not ].XXREAL-1K4 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,+inftyXXREAL-0K1 .[)"
      using xxreal_1_th_297 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_392:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for p be RealXREAL-0M1 holds r <=XXREAL-0R1 s implies [.XXREAL-1K2 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,+inftyXXREAL-0K1 .["
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for p be RealXREAL-0M1 holds  not (r <=XXREAL-0R1 s &  not [.XXREAL-1K2 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,+inftyXXREAL-0K1 .[)"
  proof(rule ballI,rule ballI,rule ballI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    have "p inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    thus " not (r <=XXREAL-0R1 s &  not [.XXREAL-1K2 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,+inftyXXREAL-0K1 .[)"
      using xxreal_1_th_298 xxreal_0_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_393:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for p be RealXREAL-0M1 holds r <XXREAL-0R3 s implies ].XXREAL-1K4 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR9 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .["
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for p be RealXREAL-0M1 holds  not ( not r <XXREAL-0R3 s &  not ].XXREAL-1K4 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR9 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .[)"
  proof(rule ballI,rule ballI,rule ballI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    have "p inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    then have "p <XXREAL-0R3 +inftyXXREAL-0K1"
      using xxreal_0_th_9 sorry
    thus " not ( not r <XXREAL-0R3 s &  not ].XXREAL-1K4 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR9 ].XXREAL-1K3 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .[)"
      using xxreal_1_th_305 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_394:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for p be RealXREAL-0M1 holds r <=XXREAL-0R1 s implies [.XXREAL-1K2 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .["
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for p be RealXREAL-0M1 holds  not (r <=XXREAL-0R1 s &  not [.XXREAL-1K2 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .[)"
  proof(rule ballI,rule ballI,rule ballI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    have "p inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    thus " not (r <=XXREAL-0R1 s &  not [.XXREAL-1K2 r,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 [.XXREAL-1K1 r,p .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .[)"
      using xxreal_1_th_306 xxreal_0_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_395:
" for s be ExtRealXXREAL-0M1 holds  for p be RealXREAL-0M1 holds p <=XXREAL-0R1 s implies [.XXREAL-1K2 p,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR9 {TARSKIK1 p} \\/XBOOLE-0K2 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .["
proof-
  have " for s be ExtRealXXREAL-0M1 holds  for p be RealXREAL-0M1 holds  not (p <=XXREAL-0R1 s &  not [.XXREAL-1K2 p,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR9 {TARSKIK1 p} \\/XBOOLE-0K2 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .[)"
  proof(rule ballI,rule ballI)
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    have "p inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    thus " not (p <=XXREAL-0R1 s &  not [.XXREAL-1K2 p,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR9 {TARSKIK1 p} \\/XBOOLE-0K2 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .[)"
      using xxreal_1_th_323 xxreal_0_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_396:
" for s be ExtRealXXREAL-0M1 holds  for p be RealXREAL-0M1 holds [.XXREAL-1K2 -inftyXXREAL-0K2,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 [.XXREAL-1K1 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,+inftyXXREAL-0K1 .["
proof-
  have " for s be ExtRealXXREAL-0M1 holds  for p be RealXREAL-0M1 holds [.XXREAL-1K2 -inftyXXREAL-0K2,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 [.XXREAL-1K1 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,+inftyXXREAL-0K1 .["
  proof(rule ballI,rule ballI)
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    have "p inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    thus "[.XXREAL-1K2 -inftyXXREAL-0K2,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 [.XXREAL-1K1 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,+inftyXXREAL-0K1 .["
      using xxreal_1_th_325 xxreal_0_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_397:
" for s be ExtRealXXREAL-0M1 holds  for p be RealXREAL-0M1 holds [.XXREAL-1K2 -inftyXXREAL-0K2,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 [.XXREAL-1K1 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .["
proof-
  have " for s be ExtRealXXREAL-0M1 holds  for p be RealXREAL-0M1 holds [.XXREAL-1K2 -inftyXXREAL-0K2,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 [.XXREAL-1K1 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .["
  proof(rule ballI,rule ballI)
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    have "p inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    thus "[.XXREAL-1K2 -inftyXXREAL-0K2,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR8 [.XXREAL-1K1 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .["
      using xxreal_1_th_329 xxreal_0_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_398:
" for s be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds REALNUMBERSK2 \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR9 ].XXREAL-1K3 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,+inftyXXREAL-0K1 .["
proof(rule ballI,rule ballI)
  fix s assume [ty]: "s be RealXREAL-0M1"
  fix p assume [ty]: "p be RealXREAL-0M1"
  have "p inHIDDENR3 REALNUMBERSK2"
    using xreal_0_def_1 sorry
  thus "REALNUMBERSK2 \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR9 ].XXREAL-1K3 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,+inftyXXREAL-0K1 .["
    using xxreal_1_th_224 xxreal_1_th_333 xxreal_0_th_9 sorry
qed "sorry"

mtheorem xxreal_1_th_399:
" for s be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds REALNUMBERSK2 \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR9 ].XXREAL-1K3 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .["
proof(rule ballI,rule ballI)
  fix s assume [ty]: "s be RealXREAL-0M1"
  fix p assume [ty]: "p be RealXREAL-0M1"
  have "p inHIDDENR3 REALNUMBERSK2"
    using xreal_0_def_1 sorry
  thus "REALNUMBERSK2 \\SUBSET-1K6 ].XXREAL-1K3 p,s .] =MEMBEREDR9 ].XXREAL-1K3 -inftyXXREAL-0K2,p .] \\/XBOOLE-0K2 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .["
    using xxreal_1_th_224 xxreal_1_th_337 xxreal_0_th_9 sorry
qed "sorry"

mtheorem xxreal_1_th_400:
" for s be ExtRealXXREAL-0M1 holds  for p be RealXREAL-0M1 holds p <=XXREAL-0R1 s implies [.XXREAL-1K2 p,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 {TARSKIK1 p} \\/XBOOLE-0K2 [.XXREAL-1K2 s,+inftyXXREAL-0K1 .["
proof-
  have " for s be ExtRealXXREAL-0M1 holds  for p be RealXREAL-0M1 holds  not (p <=XXREAL-0R1 s &  not [.XXREAL-1K2 p,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 {TARSKIK1 p} \\/XBOOLE-0K2 [.XXREAL-1K2 s,+inftyXXREAL-0K1 .[)"
  proof(rule ballI,rule ballI)
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    have "p inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    thus " not (p <=XXREAL-0R1 s &  not [.XXREAL-1K2 p,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 ].XXREAL-1K4 p,s .[ =MEMBEREDR8 {TARSKIK1 p} \\/XBOOLE-0K2 [.XXREAL-1K2 s,+inftyXXREAL-0K1 .[)"
      using xxreal_1_th_321 xxreal_0_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_401:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies [.XXREAL-1K1 r,s .] \\SUBSET-1K6 [.XXREAL-1K2 r,s .[ =MEMBEREDR8 {TARSKIK1 s}"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not ( not r <XXREAL-0R3 s &  not [.XXREAL-1K1 r,s .] \\SUBSET-1K6 [.XXREAL-1K2 r,s .[ =MEMBEREDR8 {TARSKIK1 s})"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "[.XXREAL-1K1 s,s .] =MEMBEREDR8 {TARSKIK1 s}"
      using xxreal_1_th_17 sorry
    thus " not ( not r <XXREAL-0R3 s &  not [.XXREAL-1K1 r,s .] \\SUBSET-1K6 [.XXREAL-1K2 r,s .[ =MEMBEREDR8 {TARSKIK1 s})"
      using xxreal_1_th_184 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_402:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s implies ].XXREAL-1K3 r,s .] \\SUBSET-1K6 ].XXREAL-1K4 r,s .[ =MEMBEREDR8 {TARSKIK1 s}"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  not ( not r <XXREAL-0R3 s &  not ].XXREAL-1K3 r,s .] \\SUBSET-1K6 ].XXREAL-1K4 r,s .[ =MEMBEREDR8 {TARSKIK1 s})"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    have "[.XXREAL-1K1 s,s .] =MEMBEREDR8 {TARSKIK1 s}"
      using xxreal_1_th_17 sorry
    thus " not ( not r <XXREAL-0R3 s &  not ].XXREAL-1K3 r,s .] \\SUBSET-1K6 ].XXREAL-1K4 r,s .[ =MEMBEREDR8 {TARSKIK1 s})"
      using xxreal_1_th_188 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_403:
" for r be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 t implies [.XXREAL-1K1 r,t .] \\SUBSET-1K6 ].XXREAL-1K3 r,t .] =MEMBEREDR8 {TARSKIK1 r}"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds  not ( not r <XXREAL-0R3 t &  not [.XXREAL-1K1 r,t .] \\SUBSET-1K6 ].XXREAL-1K3 r,t .] =MEMBEREDR8 {TARSKIK1 r})"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    have "[.XXREAL-1K1 r,r .] =MEMBEREDR8 {TARSKIK1 r}"
      using xxreal_1_th_17 sorry
    thus " not ( not r <XXREAL-0R3 t &  not [.XXREAL-1K1 r,t .] \\SUBSET-1K6 ].XXREAL-1K3 r,t .] =MEMBEREDR8 {TARSKIK1 r})"
      using xxreal_1_th_192 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_404:
" for r be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 t implies [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 ].XXREAL-1K4 r,t .[ =MEMBEREDR8 {TARSKIK1 r}"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds  not ( not r <XXREAL-0R3 t &  not [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 ].XXREAL-1K4 r,t .[ =MEMBEREDR8 {TARSKIK1 r})"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    have "[.XXREAL-1K1 r,r .] =MEMBEREDR8 {TARSKIK1 r}"
      using xxreal_1_th_17 sorry
    thus " not ( not r <XXREAL-0R3 t &  not [.XXREAL-1K2 r,t .[ \\SUBSET-1K6 ].XXREAL-1K4 r,t .[ =MEMBEREDR8 {TARSKIK1 r})"
      using xxreal_1_th_196 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_405:
" for s be RealXREAL-0M1 holds [.XXREAL-1K1 -inftyXXREAL-0K2,s .] \\SUBSET-1K6 [.XXREAL-1K2 -inftyXXREAL-0K2,s .[ =MEMBEREDR8 {TARSKIK1 s}"
proof(rule ballI)
  fix s assume [ty]: "s be RealXREAL-0M1"
  have "s inHIDDENR3 REALNUMBERSK2"
    using xreal_0_def_1 sorry
  thus "[.XXREAL-1K1 -inftyXXREAL-0K2,s .] \\SUBSET-1K6 [.XXREAL-1K2 -inftyXXREAL-0K2,s .[ =MEMBEREDR8 {TARSKIK1 s}"
    using xxreal_1_th_401 xxreal_0_th_12 sorry
qed "sorry"

mtheorem xxreal_1_th_406:
" for s be RealXREAL-0M1 holds ].XXREAL-1K3 -inftyXXREAL-0K2,s .] \\SUBSET-1K6 ].XXREAL-1K4 -inftyXXREAL-0K2,s .[ =MEMBEREDR9 {TARSKIK1 s}"
proof(rule ballI)
  fix s assume [ty]: "s be RealXREAL-0M1"
  have "s inHIDDENR3 REALNUMBERSK2"
    using xreal_0_def_1 sorry
  thus "].XXREAL-1K3 -inftyXXREAL-0K2,s .] \\SUBSET-1K6 ].XXREAL-1K4 -inftyXXREAL-0K2,s .[ =MEMBEREDR9 {TARSKIK1 s}"
    using xxreal_1_th_402 xxreal_0_th_12 sorry
qed "sorry"

mtheorem xxreal_1_th_407:
" for s be RealXREAL-0M1 holds [.XXREAL-1K1 -inftyXXREAL-0K2,s .] \\SUBSET-1K6 ].XXREAL-1K3 -inftyXXREAL-0K2,s .] =MEMBEREDR8 {TARSKIK1 -inftyXXREAL-0K2 }"
proof(rule ballI)
  fix s assume [ty]: "s be RealXREAL-0M1"
  have "s inHIDDENR3 REALNUMBERSK2"
    using xreal_0_def_1 sorry
  thus "[.XXREAL-1K1 -inftyXXREAL-0K2,s .] \\SUBSET-1K6 ].XXREAL-1K3 -inftyXXREAL-0K2,s .] =MEMBEREDR8 {TARSKIK1 -inftyXXREAL-0K2 }"
    using xxreal_1_th_403 xxreal_0_th_12 sorry
qed "sorry"

mtheorem xxreal_1_th_408:
" for s be RealXREAL-0M1 holds [.XXREAL-1K2 -inftyXXREAL-0K2,s .[ \\SUBSET-1K6 ].XXREAL-1K4 -inftyXXREAL-0K2,s .[ =MEMBEREDR8 {TARSKIK1 -inftyXXREAL-0K2 }"
proof(rule ballI)
  fix s assume [ty]: "s be RealXREAL-0M1"
  have "s inHIDDENR3 REALNUMBERSK2"
    using xreal_0_def_1 sorry
  thus "[.XXREAL-1K2 -inftyXXREAL-0K2,s .[ \\SUBSET-1K6 ].XXREAL-1K4 -inftyXXREAL-0K2,s .[ =MEMBEREDR8 {TARSKIK1 -inftyXXREAL-0K2 }"
    using xxreal_1_th_404 xxreal_0_th_12 sorry
qed "sorry"

mtheorem xxreal_1_th_409:
" for s be RealXREAL-0M1 holds [.XXREAL-1K1 s,+inftyXXREAL-0K1 .] \\SUBSET-1K6 [.XXREAL-1K2 s,+inftyXXREAL-0K1 .[ =MEMBEREDR8 {TARSKIK1 +inftyXXREAL-0K1 }"
proof(rule ballI)
  fix s assume [ty]: "s be RealXREAL-0M1"
  have "s inHIDDENR3 REALNUMBERSK2"
    using xreal_0_def_1 sorry
  thus "[.XXREAL-1K1 s,+inftyXXREAL-0K1 .] \\SUBSET-1K6 [.XXREAL-1K2 s,+inftyXXREAL-0K1 .[ =MEMBEREDR8 {TARSKIK1 +inftyXXREAL-0K1 }"
    using xxreal_1_th_401 xxreal_0_th_9 sorry
qed "sorry"

mtheorem xxreal_1_th_410:
" for s be RealXREAL-0M1 holds ].XXREAL-1K3 s,+inftyXXREAL-0K1 .] \\SUBSET-1K6 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .[ =MEMBEREDR8 {TARSKIK1 +inftyXXREAL-0K1 }"
proof(rule ballI)
  fix s assume [ty]: "s be RealXREAL-0M1"
  have "s inHIDDENR3 REALNUMBERSK2"
    using xreal_0_def_1 sorry
  thus "].XXREAL-1K3 s,+inftyXXREAL-0K1 .] \\SUBSET-1K6 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .[ =MEMBEREDR8 {TARSKIK1 +inftyXXREAL-0K1 }"
    using xxreal_1_th_402 xxreal_0_th_9 sorry
qed "sorry"

mtheorem xxreal_1_th_411:
" for s be RealXREAL-0M1 holds [.XXREAL-1K1 s,+inftyXXREAL-0K1 .] \\SUBSET-1K6 ].XXREAL-1K3 s,+inftyXXREAL-0K1 .] =MEMBEREDR8 {TARSKIK1 s}"
proof(rule ballI)
  fix s assume [ty]: "s be RealXREAL-0M1"
  have "s inHIDDENR3 REALNUMBERSK2"
    using xreal_0_def_1 sorry
  thus "[.XXREAL-1K1 s,+inftyXXREAL-0K1 .] \\SUBSET-1K6 ].XXREAL-1K3 s,+inftyXXREAL-0K1 .] =MEMBEREDR8 {TARSKIK1 s}"
    using xxreal_1_th_403 xxreal_0_th_9 sorry
qed "sorry"

mtheorem xxreal_1_th_412:
" for s be RealXREAL-0M1 holds [.XXREAL-1K2 s,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .[ =MEMBEREDR9 {TARSKIK1 s}"
proof(rule ballI)
  fix s assume [ty]: "s be RealXREAL-0M1"
  have "s inHIDDENR3 REALNUMBERSK2"
    using xreal_0_def_1 sorry
  thus "[.XXREAL-1K2 s,+inftyXXREAL-0K1 .[ \\SUBSET-1K6 ].XXREAL-1K4 s,+inftyXXREAL-0K1 .[ =MEMBEREDR9 {TARSKIK1 s}"
    using xxreal_1_th_404 xxreal_0_th_9 sorry
qed "sorry"

mtheorem xxreal_1_th_413:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & s <XXREAL-0R3 t implies [.XXREAL-1K1 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .[ =MEMBEREDR8 [.XXREAL-1K2 r,t .["
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & s <XXREAL-0R3 t implies [.XXREAL-1K1 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .[ =MEMBEREDR8 [.XXREAL-1K2 r,t .["
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
      and A2: "s <XXREAL-0R3 t"
    have " for p be ExtRealXXREAL-0M1 holds (p inHIDDENR3 [.XXREAL-1K1 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .[ implies p inHIDDENR3 [.XXREAL-1K2 r,t .[) & (p inHIDDENR3 [.XXREAL-1K2 r,t .[ implies p inHIDDENR3 [.XXREAL-1K1 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .[)"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      show "p inHIDDENR3 [.XXREAL-1K1 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .[ implies p inHIDDENR3 [.XXREAL-1K2 r,t .["
      proof(rule impI)
        assume "p inHIDDENR3 [.XXREAL-1K1 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .["
        then have "p inHIDDENR3 [.XXREAL-1K1 r,s .] or p inHIDDENR3 [.XXREAL-1K2 s,t .["
          using xboole_0_def_3 sorry
        then have A3: "r <=XXREAL-0R1 p & p <=XXREAL-0R1 s or s <=XXREAL-0R1 p & p <XXREAL-0R3 t"
          using xxreal_1_th_1 xxreal_1_th_3 sorry
        then have A4: "r <=XXREAL-0R1 p"
          using A1 xxreal_0_th_2 sorry
        have "p <XXREAL-0R3 t"
          using A2 A3 xxreal_0_th_2 sorry
        thus "p inHIDDENR3 [.XXREAL-1K2 r,t .["
          using A4 xxreal_1_th_3 sorry
      qed
      assume "p inHIDDENR3 [.XXREAL-1K2 r,t .["
      then have "r <=XXREAL-0R1 p & p <=XXREAL-0R1 s or s <=XXREAL-0R1 p & p <XXREAL-0R3 t"
        using xxreal_1_th_3 sorry
      then have "p inHIDDENR3 [.XXREAL-1K1 r,s .] or p inHIDDENR3 [.XXREAL-1K2 s,t .["
        using xxreal_1_th_1 xxreal_1_th_3 sorry
      thus "p inHIDDENR3 [.XXREAL-1K1 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .["
        using xboole_0_def_3 sorry
    qed "sorry"
    thus "[.XXREAL-1K1 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .[ =MEMBEREDR8 [.XXREAL-1K2 r,t .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_414:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & s <=XXREAL-0R1 t implies ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,t .] =MEMBEREDR8 ].XXREAL-1K3 r,t .]"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & s <=XXREAL-0R1 t implies ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,t .] =MEMBEREDR8 ].XXREAL-1K3 r,t .]"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "s <=XXREAL-0R1 t"
    have " for p be ExtRealXXREAL-0M1 holds (p inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,t .] implies p inHIDDENR3 ].XXREAL-1K3 r,t .]) & (p inHIDDENR3 ].XXREAL-1K3 r,t .] implies p inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,t .])"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      show "p inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,t .] implies p inHIDDENR3 ].XXREAL-1K3 r,t .]"
      proof(rule impI)
        assume "p inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,t .]"
        then have "p inHIDDENR3 ].XXREAL-1K3 r,s .] or p inHIDDENR3 [.XXREAL-1K1 s,t .]"
          using xboole_0_def_3 sorry
        then have A3: "r <XXREAL-0R3 p & p <=XXREAL-0R1 s or s <=XXREAL-0R1 p & p <=XXREAL-0R1 t"
          using xxreal_1_th_1 xxreal_1_th_2 sorry
        then have A4: "r <XXREAL-0R3 p"
          using A1 xxreal_0_th_2 sorry
        have "p <=XXREAL-0R1 t"
          using A2 A3 xxreal_0_th_2 sorry
        thus "p inHIDDENR3 ].XXREAL-1K3 r,t .]"
          using A4 xxreal_1_th_2 sorry
      qed
      assume "p inHIDDENR3 ].XXREAL-1K3 r,t .]"
      then have "r <XXREAL-0R3 p & p <=XXREAL-0R1 s or s <=XXREAL-0R1 p & p <=XXREAL-0R1 t"
        using xxreal_1_th_2 sorry
      then have "p inHIDDENR3 ].XXREAL-1K3 r,s .] or p inHIDDENR3 [.XXREAL-1K1 s,t .]"
        using xxreal_1_th_1 xxreal_1_th_2 sorry
      thus "p inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,t .]"
        using xboole_0_def_3 sorry
    qed "sorry"
    thus "].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K1 s,t .] =MEMBEREDR8 ].XXREAL-1K3 r,t .]"
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_415:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & s <XXREAL-0R3 t implies ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .[ =MEMBEREDR8 ].XXREAL-1K4 r,t .["
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & s <XXREAL-0R3 t implies ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .[ =MEMBEREDR8 ].XXREAL-1K4 r,t .["
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "s <XXREAL-0R3 t"
    have " for p be ExtRealXXREAL-0M1 holds (p inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .[ implies p inHIDDENR3 ].XXREAL-1K4 r,t .[) & (p inHIDDENR3 ].XXREAL-1K4 r,t .[ implies p inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .[)"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be ExtRealXXREAL-0M1"
      show "p inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .[ implies p inHIDDENR3 ].XXREAL-1K4 r,t .["
      proof(rule impI)
        assume "p inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .["
        then have "p inHIDDENR3 ].XXREAL-1K3 r,s .] or p inHIDDENR3 [.XXREAL-1K2 s,t .["
          using xboole_0_def_3 sorry
        then have A3: "r <XXREAL-0R3 p & p <=XXREAL-0R1 s or s <=XXREAL-0R1 p & p <XXREAL-0R3 t"
          using xxreal_1_th_2 xxreal_1_th_3 sorry
        then have A4: "r <XXREAL-0R3 p"
          using A1 xxreal_0_th_2 sorry
        have "p <XXREAL-0R3 t"
          using A2 A3 xxreal_0_th_2 sorry
        thus "p inHIDDENR3 ].XXREAL-1K4 r,t .["
          using A4 xxreal_1_th_4 sorry
      qed
      assume "p inHIDDENR3 ].XXREAL-1K4 r,t .["
      then have "r <XXREAL-0R3 p & p <=XXREAL-0R1 s or s <=XXREAL-0R1 p & p <XXREAL-0R3 t"
        using xxreal_1_th_4 sorry
      then have "p inHIDDENR3 ].XXREAL-1K3 r,s .] or p inHIDDENR3 [.XXREAL-1K2 s,t .["
        using xxreal_1_th_2 xxreal_1_th_3 sorry
      thus "p inHIDDENR3 ].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .["
        using xboole_0_def_3 sorry
    qed "sorry"
    thus "].XXREAL-1K3 r,s .] \\/XBOOLE-0K2 [.XXREAL-1K2 s,t .[ =MEMBEREDR8 ].XXREAL-1K4 r,t .["
      using membered_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_416:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & s <XXREAL-0R3 t implies ([.XXREAL-1K1 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K2 s,t .[) =MEMBEREDR8 {TARSKIK1 s}"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & s <XXREAL-0R3 t implies ([.XXREAL-1K1 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K2 s,t .[) =MEMBEREDR8 {TARSKIK1 s}"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
      and A2: "s <XXREAL-0R3 t"
    have " for x be objectHIDDENM1 holds (x inHIDDENR3 ([.XXREAL-1K1 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K2 s,t .[) implies x =HIDDENR1 s) & (x =HIDDENR1 s implies x inHIDDENR3 ([.XXREAL-1K1 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K2 s,t .[))"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      show "x inHIDDENR3 ([.XXREAL-1K1 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K2 s,t .[) implies x =HIDDENR1 s"
      proof(rule impI)
        assume A3: "x inHIDDENR3 ([.XXREAL-1K1 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K2 s,t .[)"
        then obtain p where 
          [ty]:"p be ExtRealXXREAL-0M1" and pDef:"p = x"
           sorry
        have A4: "p inHIDDENR3 [.XXREAL-1K1 r,s .]"
          using A3 xboole_0_def_4 sorry
        have "p inHIDDENR3 [.XXREAL-1K2 s,t .["
          using A3 xboole_0_def_4 sorry
        then have A5: "s <=XXREAL-0R1 p"
          using xxreal_1_th_3 sorry
        have "p <=XXREAL-0R1 s"
          using A4 xxreal_1_th_1 sorry
        thus "x =HIDDENR1 s"
          using A5 xxreal_0_th_1 sorry
      qed
      assume A6: "x =HIDDENR1 s"
      have A7: "s inHIDDENR3 [.XXREAL-1K1 r,s .]"
        using A1 xxreal_1_th_1 sorry
      have "s inHIDDENR3 [.XXREAL-1K2 s,t .["
        using A2 xxreal_1_th_3 sorry
      thus "x inHIDDENR3 ([.XXREAL-1K1 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K2 s,t .[)"
        using A6 A7 xboole_0_def_4 sorry
    qed "sorry"
    thus "([.XXREAL-1K1 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K2 s,t .[) =MEMBEREDR8 {TARSKIK1 s}"
      using tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_417:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & s <=XXREAL-0R1 t implies (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 s,t .]) =MEMBEREDR8 {TARSKIK1 s}"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & s <=XXREAL-0R1 t implies (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 s,t .]) =MEMBEREDR8 {TARSKIK1 s}"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: "s <=XXREAL-0R1 t"
    have " for x be objectHIDDENM1 holds (x inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 s,t .]) implies x =HIDDENR1 s) & (x =HIDDENR1 s implies x inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 s,t .]))"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      show "x inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 s,t .]) implies x =HIDDENR1 s"
      proof(rule impI)
        assume A3: "x inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 s,t .])"
        then obtain p where 
          [ty]:"p be ExtRealXXREAL-0M1" and pDef:"p = x"
           sorry
        have A4: "p inHIDDENR3 ].XXREAL-1K3 r,s .]"
          using A3 xboole_0_def_4 sorry
        have "p inHIDDENR3 [.XXREAL-1K1 s,t .]"
          using A3 xboole_0_def_4 sorry
        then have A5: "s <=XXREAL-0R1 p"
          using xxreal_1_th_1 sorry
        have "p <=XXREAL-0R1 s"
          using A4 xxreal_1_th_2 sorry
        thus "x =HIDDENR1 s"
          using A5 xxreal_0_th_1 sorry
      qed
      assume A6: "x =HIDDENR1 s"
      have A7: "s inHIDDENR3 ].XXREAL-1K3 r,s .]"
        using A1 xxreal_1_th_2 sorry
      have "s inHIDDENR3 [.XXREAL-1K1 s,t .]"
        using A2 xxreal_1_th_1 sorry
      thus "x inHIDDENR3 (].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 s,t .])"
        using A6 A7 xboole_0_def_4 sorry
    qed "sorry"
    thus "(].XXREAL-1K3 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 s,t .]) =MEMBEREDR8 {TARSKIK1 s}"
      using tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_418:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & s <=XXREAL-0R1 t implies ([.XXREAL-1K1 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 s,t .]) =MEMBEREDR8 {TARSKIK1 s}"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <=XXREAL-0R1 s & s <=XXREAL-0R1 t implies ([.XXREAL-1K1 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 s,t .]) =MEMBEREDR8 {TARSKIK1 s}"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 s"
      and A2: "s <=XXREAL-0R1 t"
    have " for x be objectHIDDENM1 holds (x inHIDDENR3 ([.XXREAL-1K1 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 s,t .]) implies x =HIDDENR1 s) & (x =HIDDENR1 s implies x inHIDDENR3 ([.XXREAL-1K1 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 s,t .]))"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      show "x inHIDDENR3 ([.XXREAL-1K1 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 s,t .]) implies x =HIDDENR1 s"
      proof(rule impI)
        assume A3: "x inHIDDENR3 ([.XXREAL-1K1 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 s,t .])"
        then obtain p where 
          [ty]:"p be ExtRealXXREAL-0M1" and pDef:"p = x"
           sorry
        have A4: "p inHIDDENR3 [.XXREAL-1K1 r,s .]"
          using A3 xboole_0_def_4 sorry
        have "p inHIDDENR3 [.XXREAL-1K1 s,t .]"
          using A3 xboole_0_def_4 sorry
        then have A5: "s <=XXREAL-0R1 p"
          using xxreal_1_th_1 sorry
        have "p <=XXREAL-0R1 s"
          using A4 xxreal_1_th_1 sorry
        thus "x =HIDDENR1 s"
          using A5 xxreal_0_th_1 sorry
      qed
      assume A6: "x =HIDDENR1 s"
      have A7: "s inHIDDENR3 [.XXREAL-1K1 r,s .]"
        using A1 xxreal_1_th_1 sorry
      have "s inHIDDENR3 [.XXREAL-1K1 s,t .]"
        using A2 xxreal_1_th_1 sorry
      thus "x inHIDDENR3 ([.XXREAL-1K1 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 s,t .])"
        using A6 A7 xboole_0_def_4 sorry
    qed "sorry"
    thus "([.XXREAL-1K1 r,s .])/\\XBOOLE-0K3 ([.XXREAL-1K1 s,t .]) =MEMBEREDR8 {TARSKIK1 s}"
      using tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_1_th_419:
" for s be ExtRealXXREAL-0M1 holds [.XXREAL-1K1 -inftyXXREAL-0K2,s .] =MEMBEREDR8 ].XXREAL-1K4 -inftyXXREAL-0K2,s .[ \\/XBOOLE-0K2 {TARSKIK2 -inftyXXREAL-0K2,s }"
  using xxreal_1_th_128 xxreal_0_th_5 sorry

mtheorem xxreal_1_th_420:
" for s be ExtRealXXREAL-0M1 holds [.XXREAL-1K1 -inftyXXREAL-0K2,s .] =MEMBEREDR8 [.XXREAL-1K2 -inftyXXREAL-0K2,s .[ \\/XBOOLE-0K2 {TARSKIK1 s}"
  using xxreal_1_th_129 xxreal_0_th_5 sorry

mtheorem xxreal_1_th_421:
" for s be ExtRealXXREAL-0M1 holds [.XXREAL-1K1 -inftyXXREAL-0K2,s .] =MEMBEREDR8 {TARSKIK1 -inftyXXREAL-0K2 } \\/XBOOLE-0K2 ].XXREAL-1K3 -inftyXXREAL-0K2,s .]"
  using xxreal_1_th_130 xxreal_0_th_5 sorry

mtheorem xxreal_1_th_422:
" for s be RealXREAL-0M1 holds [.XXREAL-1K2 -inftyXXREAL-0K2,s .[ =MEMBEREDR8 {TARSKIK1 -inftyXXREAL-0K2 } \\/XBOOLE-0K2 ].XXREAL-1K4 -inftyXXREAL-0K2,s .["
proof(rule ballI)
  fix s assume [ty]: "s be RealXREAL-0M1"
  have "s inHIDDENR3 REALNUMBERSK2"
    using xreal_0_def_1 sorry
  thus "[.XXREAL-1K2 -inftyXXREAL-0K2,s .[ =MEMBEREDR8 {TARSKIK1 -inftyXXREAL-0K2 } \\/XBOOLE-0K2 ].XXREAL-1K4 -inftyXXREAL-0K2,s .["
    using xxreal_1_th_131 xxreal_0_th_12 sorry
qed "sorry"

mtheorem xxreal_1_th_423:
" for s be RealXREAL-0M1 holds ].XXREAL-1K3 -inftyXXREAL-0K2,s .] =MEMBEREDR9 ].XXREAL-1K4 -inftyXXREAL-0K2,s .[ \\/XBOOLE-0K2 {TARSKIK1 s}"
proof(rule ballI)
  fix s assume [ty]: "s be RealXREAL-0M1"
  have "s inHIDDENR3 REALNUMBERSK2"
    using xreal_0_def_1 sorry
  thus "].XXREAL-1K3 -inftyXXREAL-0K2,s .] =MEMBEREDR9 ].XXREAL-1K4 -inftyXXREAL-0K2,s .[ \\/XBOOLE-0K2 {TARSKIK1 s}"
    using xxreal_1_th_132 xxreal_0_th_12 sorry
qed "sorry"

mtheorem xxreal_1_th_424:
" for r be ExtRealXXREAL-0M1 holds [.XXREAL-1K1 r,+inftyXXREAL-0K1 .] =MEMBEREDR8 ].XXREAL-1K4 r,+inftyXXREAL-0K1 .[ \\/XBOOLE-0K2 {TARSKIK2 r,+inftyXXREAL-0K1 }"
  using xxreal_1_th_128 xxreal_0_th_3 sorry

mtheorem xxreal_1_th_425:
" for r be ExtRealXXREAL-0M1 holds [.XXREAL-1K1 r,+inftyXXREAL-0K1 .] =MEMBEREDR8 [.XXREAL-1K2 r,+inftyXXREAL-0K1 .[ \\/XBOOLE-0K2 {TARSKIK1 +inftyXXREAL-0K1 }"
  using xxreal_1_th_129 xxreal_0_th_3 sorry

mtheorem xxreal_1_th_426:
" for r be ExtRealXXREAL-0M1 holds [.XXREAL-1K1 r,+inftyXXREAL-0K1 .] =MEMBEREDR8 {TARSKIK1 r} \\/XBOOLE-0K2 ].XXREAL-1K3 r,+inftyXXREAL-0K1 .]"
  using xxreal_1_th_130 xxreal_0_th_3 sorry

mtheorem xxreal_1_th_427:
" for r be RealXREAL-0M1 holds [.XXREAL-1K2 r,+inftyXXREAL-0K1 .[ =MEMBEREDR9 {TARSKIK1 r} \\/XBOOLE-0K2 ].XXREAL-1K4 r,+inftyXXREAL-0K1 .["
proof(rule ballI)
  fix r assume [ty]: "r be RealXREAL-0M1"
  have "r inHIDDENR3 REALNUMBERSK2"
    using xreal_0_def_1 sorry
  thus "[.XXREAL-1K2 r,+inftyXXREAL-0K1 .[ =MEMBEREDR9 {TARSKIK1 r} \\/XBOOLE-0K2 ].XXREAL-1K4 r,+inftyXXREAL-0K1 .["
    using xxreal_1_th_131 xxreal_0_th_9 sorry
qed "sorry"

mtheorem xxreal_1_th_428:
" for r be RealXREAL-0M1 holds ].XXREAL-1K3 r,+inftyXXREAL-0K1 .] =MEMBEREDR8 ].XXREAL-1K4 r,+inftyXXREAL-0K1 .[ \\/XBOOLE-0K2 {TARSKIK1 +inftyXXREAL-0K1 }"
proof(rule ballI)
  fix r assume [ty]: "r be RealXREAL-0M1"
  have "r inHIDDENR3 REALNUMBERSK2"
    using xreal_0_def_1 sorry
  thus "].XXREAL-1K3 r,+inftyXXREAL-0K1 .] =MEMBEREDR8 ].XXREAL-1K4 r,+inftyXXREAL-0K1 .[ \\/XBOOLE-0K2 {TARSKIK1 +inftyXXREAL-0K1 }"
    using xxreal_1_th_132 xxreal_0_th_9 sorry
qed "sorry"

end
