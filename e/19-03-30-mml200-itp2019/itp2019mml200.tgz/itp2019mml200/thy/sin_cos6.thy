theory sin_cos6
  imports fdiff_2 complex2
   "../mizar_extension/E_number"
begin
(*begin*)
reserve r, r1, r2, s, x for "RealXREAL-0M1"
reserve i for "IntegerINT-1M1"
mtheorem sin_cos6_th_1:
" for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 r & r <XXREAL-0R3 s implies [\\INT-1K2 r /XCMPLX-0K7 s /] =HIDDENR1 0NUMBERSK6"
proof-
  have " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 r & r <XXREAL-0R3 s implies [\\INT-1K2 r /XCMPLX-0K7 s /] =HIDDENR1 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 r & r <XXREAL-0R3 s"
    then have "r /XCMPLX-0K7 s <XXREAL-0R3 s /XCMPLX-0K7 s"
      using xreal_1_th_74 sorry
    then have "r /XCMPLX-0K7 s -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 s /XCMPLX-0K7 s -XCMPLX-0K6 \<one>\<^sub>M"
      using xreal_1_th_9 sorry
    then have "r /XCMPLX-0K7 s -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
      using A1 xcmplx_1_th_60 sorry
    thus "[\\INT-1K2 r /XCMPLX-0K7 s /] =HIDDENR1 0NUMBERSK6"
      using A1 int_1_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_2:
" for f be FunctionFUNCT-1M1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds f  |RELAT-1K8 X be one-to-oneFUNCT-1V2 & Y c=TARSKIR1 X implies f  |RELAT-1K8 Y be one-to-oneFUNCT-1V2"
proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  fix X assume [ty]: "X be setHIDDENM2"
  fix Y assume [ty]: "Y be setHIDDENM2"
  assume A1: "f  |RELAT-1K8 X be one-to-oneFUNCT-1V2"
    and A2: "Y c=TARSKIR1 X"
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 Y) implies (y inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 Y) implies ((f  |RELAT-1K8 Y).FUNCT-1K1 x =XBOOLE-0R4 (f  |RELAT-1K8 Y).FUNCT-1K1 y implies x =HIDDENR1 y))"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    have A3: "domRELAT-1K1 (f  |RELAT-1K8 Y) =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 Y"
      using relat_1_th_61 sorry
    assume A4: "x inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 Y)"
    then have A5: "x inHIDDENR3 Y"
      using A3 xboole_0_def_4 sorry
    have "x inHIDDENR3 domRELAT-1K1 f"
      using A3 A4 xboole_0_def_4 sorry
    then have "x inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 X"
      using A2 A5 xboole_0_def_4 sorry
    then have A6: "x inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 X)"
      using relat_1_th_61 sorry
    assume A7: "y inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 Y)"
    then have A8: "y inHIDDENR3 Y"
      using A3 xboole_0_def_4 sorry
    have "y inHIDDENR3 domRELAT-1K1 f"
      using A3 A7 xboole_0_def_4 sorry
    then have "y inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 X"
      using A2 A8 xboole_0_def_4 sorry
    then have A9: "y inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 X)"
      using relat_1_th_61 sorry
    assume A10: "(f  |RELAT-1K8 Y).FUNCT-1K1 x =XBOOLE-0R4 (f  |RELAT-1K8 Y).FUNCT-1K1 y"
    have "(f  |RELAT-1K8 X).FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 x"
      using A2 A5 funct_1_th_49 sorry
    also have "... = (f  |RELAT-1K8 Y).FUNCT-1K1 x"
      using A5 funct_1_th_49 sorry
    also have "... = f .FUNCT-1K1 y"
      using A8 A10 funct_1_th_49 sorry
    also have "... = (f  |RELAT-1K8 X).FUNCT-1K1 y"
      using A2 A8 funct_1_th_49 sorry
    finally have "(f  |RELAT-1K8 X).FUNCT-1K1 x =HIDDENR1 (f  |RELAT-1K8 X).FUNCT-1K1 y"
       sorry
    thus "x =HIDDENR1 y"
      using A1 A6 A9 sorry
  qed "sorry"
  thus "f  |RELAT-1K8 Y be one-to-oneFUNCT-1V2"
    using funct_1_def_4 sorry
qed "sorry"

(*begin*)
mtheorem sin_cos6_th_3:
" for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 sinSIN-COSK18 r"
proof-
  have " for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 sinSIN-COSK18 r"
  proof(rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    have "(sinSIN-COSK17).FUNCT-1K1 r inTARSKIR2 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
      using comptrig_th_27 sorry
    then have "sinSIN-COSK18 r inTARSKIR2 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
      using sin_cos_def_17 sorry
    thus "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 sinSIN-COSK18 r"
      using xxreal_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_4:
" for r be RealXREAL-0M1 holds sinSIN-COSK18 r <=XXREAL-0R1 \<one>\<^sub>M"
proof-
  have " for r be RealXREAL-0M1 holds sinSIN-COSK18 r <=XXREAL-0R1 \<one>\<^sub>M"
  proof(rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    have "(sinSIN-COSK17).FUNCT-1K1 r inTARSKIR2 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
      using comptrig_th_27 sorry
    then have "sinSIN-COSK18 r inTARSKIR2 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
      using sin_cos_def_17 sorry
    thus "sinSIN-COSK18 r <=XXREAL-0R1 \<one>\<^sub>M"
      using xxreal_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_5:
" for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 cosSIN-COSK20 r"
proof-
  have " for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 cosSIN-COSK20 r"
  proof(rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    have "(cosSIN-COSK19).FUNCT-1K1 r inTARSKIR2 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
      using comptrig_th_27 sorry
    then have "cosSIN-COSK20 r inTARSKIR2 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
      using sin_cos_def_19 sorry
    thus "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 cosSIN-COSK20 r"
      using xxreal_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_6:
" for r be RealXREAL-0M1 holds cosSIN-COSK20 r <=XXREAL-0R1 \<one>\<^sub>M"
proof-
  have " for r be RealXREAL-0M1 holds cosSIN-COSK20 r <=XXREAL-0R1 \<one>\<^sub>M"
  proof(rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    have "(cosSIN-COSK19).FUNCT-1K1 r inTARSKIR2 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
      using comptrig_th_27 sorry
    then have "cosSIN-COSK20 r inTARSKIR2 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
      using sin_cos_def_19 sorry
    thus "cosSIN-COSK20 r <=XXREAL-0R1 \<one>\<^sub>M"
      using xxreal_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma sin_cos6_lm_1:
"[.RCOMP-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (0NUMBERSK6),(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (0NUMBERSK6) .] =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]"
   sorry

mlemma sin_cos6_lm_2:
"[.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (0NUMBERSK6),(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (0NUMBERSK6) .] =XBOOLE-0R4 [.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]"
   sorry

mlemma sin_cos6_lm_3:
"[.RCOMP-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (0NUMBERSK6),PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (0NUMBERSK6) .] =XBOOLE-0R4 [.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]"
   sorry

mlemma sin_cos6_lm_4:
"[.RCOMP-1K1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (0NUMBERSK6),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (0NUMBERSK6) .] =XBOOLE-0R4 [.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]"
   sorry

mlemma sin_cos6_lm_5:
" for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds r ^2SQUARE-1K1 +XCMPLX-0K2 s ^2SQUARE-1K1 =XBOOLE-0R4 \<one>\<^sub>M implies -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M"
proof-
  have " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not (r ^2SQUARE-1K1 +XCMPLX-0K2 s ^2SQUARE-1K1 =XBOOLE-0R4 \<one>\<^sub>M &  not (-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M))"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    have "s ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_th_63 sorry
    then have "-XCMPLX-0K4 s ^2SQUARE-1K1 <=XXREAL-0R1 -XCMPLX-0K4 0NUMBERSK6"
       sorry
    then have "r ^2SQUARE-1K1 -XCMPLX-0K6 (r ^2SQUARE-1K1 +XCMPLX-0K2 s ^2SQUARE-1K1) <=XXREAL-0R1 0NUMBERSK6"
       sorry
    thus " not (r ^2SQUARE-1K1 +XCMPLX-0K2 s ^2SQUARE-1K1 =XBOOLE-0R4 \<one>\<^sub>M &  not (-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M))"
      using square_1_th_43 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_cl_1:
"cluster PISIN-COSK29 as-term-is positiveXXREAL-0V2"
proof
(*coherence*)
  show "PISIN-COSK29 be positiveXXREAL-0V2"
  proof-
    have Cut142: "PISIN-COSK29 inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<four>\<^sub>M .["
      using sin_cos_def_28 sorry
    have "PISIN-COSK29 >XXREAL-0R4 0NUMBERSK6"
    proof-
      show "PISIN-COSK29 >XXREAL-0R4 0NUMBERSK6"
        using xxreal_1_th_4 Cut142 sorry
    qed
    thus "PISIN-COSK29 be positiveXXREAL-0V2"
      using xxreal_0_def_6 sorry
  qed
qed "sorry"

mlemma sin_cos6_lm_6:
"(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<one>\<^sub>M"
  using xreal_1_th_76 sorry

mlemma sin_cos6_lm_7:
"\<one>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
  using xreal_1_th_68 sorry

mlemma sin_cos6_lm_8:
"0NUMBERSK6 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 \<one>\<^sub>M <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 \<one>\<^sub>M"
  using xreal_1_th_6 sorry

mlemma sin_cos6_lm_9:
"(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
  using xreal_1_th_68 sorry

mlemma sin_cos6_lm_10:
"\<one>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
  using xreal_1_th_68 sorry

mtheorem sin_cos6_th_7:
"sinSIN-COSK18 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M & (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
proof-
  have "(sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 ((-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))"
    using sin_cos_th_78 sorry
  also have "... = -XCMPLX-0K4 \<one>\<^sub>M"
    using sin_cos_th_76 sorry
  finally have "(sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
     sorry
  thus "sinSIN-COSK18 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M & (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
    using sin_cos_def_17 sorry
qed

mtheorem sin_cos6_th_8:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (sinSIN-COSK17).FUNCT-1K1 r =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 (r +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)"
proof-
  have " for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (sinSIN-COSK17).FUNCT-1K1 r =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 (r +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix i assume [ty]: "i be IntegerINT-1M1"
    have "(sinSIN-COSK17).FUNCT-1K1 r =HIDDENR1 sinSIN-COSK18 r"
      using sin_cos_def_17 sorry
    also have "... = sinSIN-COSK18 (r +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)"
      using complex2_th_8 sorry
    also have "... = (sinSIN-COSK17).FUNCT-1K1 (r +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)"
      using sin_cos_def_17 sorry
    finally show "(sinSIN-COSK17).FUNCT-1K1 r =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 (r +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_9:
"cosSIN-COSK20 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6 & (cosSIN-COSK19).FUNCT-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6"
proof-
  have "(cosSIN-COSK19).FUNCT-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 ((-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))"
    using sin_cos_th_78 sorry
  also have "... = 0NUMBERSK6"
    using sin_cos_th_76 sorry
  finally have "(cosSIN-COSK19).FUNCT-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 0NUMBERSK6"
     sorry
  thus "cosSIN-COSK20 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6 & (cosSIN-COSK19).FUNCT-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6"
    using sin_cos_def_19 sorry
qed

mtheorem sin_cos6_th_10:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (cosSIN-COSK19).FUNCT-1K1 r =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 (r +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)"
proof-
  have " for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (cosSIN-COSK19).FUNCT-1K1 r =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 (r +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix i assume [ty]: "i be IntegerINT-1M1"
    have "(cosSIN-COSK19).FUNCT-1K1 r =HIDDENR1 cosSIN-COSK20 r"
      using sin_cos_def_19 sorry
    also have "... = cosSIN-COSK20 (r +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)"
      using complex2_th_9 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 (r +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)"
      using sin_cos_def_19 sorry
    finally show "(cosSIN-COSK19).FUNCT-1K1 r =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 (r +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_11:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <XXREAL-0R3 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies sinSIN-COSK18 r >XXREAL-0R4 0NUMBERSK6"
proof-
  have " for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <XXREAL-0R3 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies  not sinSIN-COSK18 r >XXREAL-0R4 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix i assume [ty]: "i be IntegerINT-1M1"
    assume "(\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <XXREAL-0R3 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
    then have "(\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i & r -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 (PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
      using xreal_1_th_9 sorry
    then have "r -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i inTARSKIR2 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
      using xxreal_1_th_4 sorry
    then have "(sinSIN-COSK17).FUNCT-1K1 (r +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (-XCMPLX-0K4 i)) >XXREAL-0R4 0NUMBERSK6"
      using comptrig_th_7 sorry
    then have "(sinSIN-COSK17).FUNCT-1K1 r >XXREAL-0R4 0NUMBERSK6"
      using sin_cos6_th_8 sorry
    thus " not sinSIN-COSK18 r >XXREAL-0R4 0NUMBERSK6"
      using sin_cos_def_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_12:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies sinSIN-COSK18 r <XXREAL-0R3 0NUMBERSK6"
proof-
  have " for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies  not sinSIN-COSK18 r <XXREAL-0R3 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix i assume [ty]: "i be IntegerINT-1M1"
    assume "PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
    then have "(PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i & r -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
      using xreal_1_th_9 sorry
    then have "r -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i inTARSKIR2 ].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .["
      using xxreal_1_th_4 sorry
    then have "(sinSIN-COSK17).FUNCT-1K1 (r +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (-XCMPLX-0K4 i)) <XXREAL-0R3 0NUMBERSK6"
      using comptrig_th_9 sorry
    then have "(sinSIN-COSK17).FUNCT-1K1 r <XXREAL-0R3 0NUMBERSK6"
      using sin_cos6_th_8 sorry
    thus " not sinSIN-COSK18 r <XXREAL-0R3 0NUMBERSK6"
      using sin_cos_def_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_13:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies cosSIN-COSK20 r >XXREAL-0R4 0NUMBERSK6"
proof-
  have " for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies  not cosSIN-COSK20 r >XXREAL-0R4 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix i assume [ty]: "i be IntegerINT-1M1"
    assume A1: "(-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r"
      and A2: "r <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
    have "r +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)+XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using A2 xreal_1_th_6 sorry
    then have A3: "r +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
       sorry
    have A4: "sinSIN-COSK18 (r +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =XBOOLE-0R4 cosSIN-COSK20 r"
      using sin_cos_th_79 sorry
    have "((-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)+XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 r +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using A1 xreal_1_th_6 sorry
    thus " not cosSIN-COSK20 r >XXREAL-0R4 0NUMBERSK6"
      using A3 A4 sin_cos6_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_14:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies cosSIN-COSK20 r <XXREAL-0R3 0NUMBERSK6"
proof-
  have " for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies  not cosSIN-COSK20 r <XXREAL-0R3 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix i assume [ty]: "i be IntegerINT-1M1"
    assume A1: "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r"
      and A2: "r <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
    have "((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)+XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 r +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using A1 xreal_1_th_6 sorry
    then have A3: "PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    have "r +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 ((\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)+XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using A2 xreal_1_th_6 sorry
    then have A4: "r +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
       sorry
    have "sinSIN-COSK18 (r +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =XBOOLE-0R4 cosSIN-COSK20 r"
      using sin_cos_th_79 sorry
    thus " not cosSIN-COSK20 r <XXREAL-0R3 0NUMBERSK6"
      using A3 A4 sin_cos6_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_15:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies cosSIN-COSK20 r >XXREAL-0R4 0NUMBERSK6"
proof-
  have " for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies  not cosSIN-COSK20 r >XXREAL-0R4 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix i assume [ty]: "i be IntegerINT-1M1"
    assume A1: "(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r"
      and A2: "r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
    have "((\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)-XCMPLX-0K6 PISIN-COSK29 <XXREAL-0R3 r -XCMPLX-0K6 PISIN-COSK29"
      using A1 xreal_1_th_9 sorry
    then have A3: "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r -XCMPLX-0K6 PISIN-COSK29"
       sorry
    have "PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i & r -XCMPLX-0K6 PISIN-COSK29 <XXREAL-0R3 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)-XCMPLX-0K6 PISIN-COSK29"
      using A2 comptrig_th_5 xreal_1_th_6 xreal_1_th_9 sorry
    then have A4: "r -XCMPLX-0K6 PISIN-COSK29 <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
      using xxreal_0_th_2 sorry
    have "cosSIN-COSK20 (r -XCMPLX-0K6 PISIN-COSK29) =HIDDENR1 cosSIN-COSK20 (-XCMPLX-0K4 (PISIN-COSK29 -XCMPLX-0K6 r))"
       sorry
    also have "... = cosSIN-COSK20 (PISIN-COSK29 +XCMPLX-0K2 (-XCMPLX-0K4 r))"
      using sin_cos_th_31 sorry
    also have "... = -XCMPLX-0K4 cosSIN-COSK20 (-XCMPLX-0K4 r)"
      using sin_cos_th_79 sorry
    also have "... = -XCMPLX-0K4 cosSIN-COSK20 r"
      using sin_cos_th_31 sorry
    finally have "cosSIN-COSK20 (r -XCMPLX-0K6 PISIN-COSK29) =HIDDENR1 -XCMPLX-0K4 cosSIN-COSK20 r"
       sorry
    thus " not cosSIN-COSK20 r >XXREAL-0R4 0NUMBERSK6"
      using A3 A4 sin_cos6_th_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_16:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <=XXREAL-0R1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies sinSIN-COSK18 r >=XXREAL-0R2 0NUMBERSK6"
proof-
  have " for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <=XXREAL-0R1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies sinSIN-COSK18 r >=XXREAL-0R2 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix i assume [ty]: "i be IntegerINT-1M1"
    assume A1: "(\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <=XXREAL-0R1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
    show "sinSIN-COSK18 r >=XXREAL-0R2 0NUMBERSK6"
    proof-
      have cases: "((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <XXREAL-0R3 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i or (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i =HIDDENR1 r) or r =HIDDENR1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
        using A1 xxreal_0_th_1 sorry
      have case1: "(\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <XXREAL-0R3 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies sinSIN-COSK18 r >=XXREAL-0R2 0NUMBERSK6"
      proof(rule impI)
        assume "(\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <XXREAL-0R3 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
        thus "sinSIN-COSK18 r >=XXREAL-0R2 0NUMBERSK6"
          using sin_cos6_th_11 sorry
      qed
      have case2: "(\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i =HIDDENR1 r implies sinSIN-COSK18 r >=XXREAL-0R2 0NUMBERSK6"
      proof(rule impI)
        assume A2: "(\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i =HIDDENR1 r"
        have "sinSIN-COSK18 (0NUMBERSK6 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i) =XBOOLE-0R4 sinSIN-COSK18 (0NUMBERSK6)"
          using complex2_th_8 sorry
        thus "sinSIN-COSK18 r >=XXREAL-0R2 0NUMBERSK6"
          using A2 sin_cos_th_31 sorry
      qed
      have case3: "r =HIDDENR1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies sinSIN-COSK18 r >=XXREAL-0R2 0NUMBERSK6"
      proof(rule impI)
        assume "r =HIDDENR1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
        thus "sinSIN-COSK18 r >=XXREAL-0R2 0NUMBERSK6"
          using complex2_th_8 sin_cos_th_77 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_17:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies sinSIN-COSK18 r <=XXREAL-0R1 0NUMBERSK6"
proof-
  have " for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies sinSIN-COSK18 r <=XXREAL-0R1 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix i assume [ty]: "i be IntegerINT-1M1"
    assume "PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
    then have "(PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i or PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i =HIDDENR1 r) or r =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
      using xxreal_0_th_1 sorry
    thus "sinSIN-COSK18 r <=XXREAL-0R1 0NUMBERSK6"
      using sin_cos6_th_12 complex2_th_8 sin_cos_th_77 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_18:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <=XXREAL-0R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies cosSIN-COSK20 r >=XXREAL-0R2 0NUMBERSK6"
proof-
  have " for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <=XXREAL-0R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies cosSIN-COSK20 r >=XXREAL-0R2 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix i assume [ty]: "i be IntegerINT-1M1"
    assume "(-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <=XXREAL-0R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
    then have "((-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i or (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i =HIDDENR1 r) or r =HIDDENR1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
      using xxreal_0_th_1 sorry
    thus "cosSIN-COSK20 r >=XXREAL-0R2 0NUMBERSK6"
      using sin_cos6_th_9 sin_cos6_th_13 complex2_th_9 sin_cos_th_77 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_19:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <=XXREAL-0R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies cosSIN-COSK20 r <=XXREAL-0R1 0NUMBERSK6"
proof-
  have " for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <=XXREAL-0R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies cosSIN-COSK20 r <=XXREAL-0R1 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix i assume [ty]: "i be IntegerINT-1M1"
    assume "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <=XXREAL-0R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
    then have "((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i or (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i =HIDDENR1 r) or r =HIDDENR1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
      using xxreal_0_th_1 sorry
    thus "cosSIN-COSK20 r <=XXREAL-0R1 0NUMBERSK6"
      using sin_cos6_th_14 complex2_th_9 sin_cos_th_77 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_20:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies cosSIN-COSK20 r >=XXREAL-0R2 0NUMBERSK6"
proof-
  have " for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies cosSIN-COSK20 r >=XXREAL-0R2 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix i assume [ty]: "i be IntegerINT-1M1"
    assume A1: "(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
    show "cosSIN-COSK20 r >=XXREAL-0R2 0NUMBERSK6"
    proof-
      have cases: "((\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i or (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i =HIDDENR1 r) or r =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
        using A1 xxreal_0_th_1 sorry
      have case1: "(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies cosSIN-COSK20 r >=XXREAL-0R2 0NUMBERSK6"
      proof(rule impI)
        assume "(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
        thus "cosSIN-COSK20 r >=XXREAL-0R2 0NUMBERSK6"
          using sin_cos6_th_15 sorry
      qed
      have case2: "(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i =HIDDENR1 r implies cosSIN-COSK20 r >=XXREAL-0R2 0NUMBERSK6"
      proof(rule impI)
        assume "(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i =HIDDENR1 r"
        thus "cosSIN-COSK20 r >=XXREAL-0R2 0NUMBERSK6"
          using complex2_th_9 sin_cos_th_77 sorry
      qed
      have case3: "r =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies cosSIN-COSK20 r >=XXREAL-0R2 0NUMBERSK6"
      proof(rule impI)
        assume "r =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
        thus "cosSIN-COSK20 r >=XXREAL-0R2 0NUMBERSK6"
          using complex2_th_9 sin_cos_th_77 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_21:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i) & sinSIN-COSK18 r =XBOOLE-0R4 0NUMBERSK6 implies r =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i or r =HIDDENR1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
proof-
  have " for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies (sinSIN-COSK18 r =XBOOLE-0R4 0NUMBERSK6 implies  not ( not r =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i &  not r =HIDDENR1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i))"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix i assume [ty]: "i be IntegerINT-1M1"
    assume A1: "(\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
    assume A2: "sinSIN-COSK18 r =XBOOLE-0R4 0NUMBERSK6"
    then have A3: "r <=XXREAL-0R1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i or \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r"
      using sin_cos6_th_12 sorry
    have "r <=XXREAL-0R1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i or r >=XXREAL-0R2 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
      using A2 sin_cos6_th_11 sorry
    thus " not ( not r =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i &  not r =HIDDENR1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)"
      using A1 A3 xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_22:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i) & cosSIN-COSK20 r =XBOOLE-0R4 0NUMBERSK6 implies r =HIDDENR1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i or r =HIDDENR1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
proof-
  have " for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies (cosSIN-COSK20 r =XBOOLE-0R4 0NUMBERSK6 implies  not ( not r =HIDDENR1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i &  not r =HIDDENR1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix i assume [ty]: "i be IntegerINT-1M1"
    assume A1: "(\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r"
      and A2: "r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
    have A3: "(-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 0NUMBERSK6 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
      using xreal_1_th_6 sorry
    assume A4: "cosSIN-COSK20 r =XBOOLE-0R4 0NUMBERSK6"
    then have A5: "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i >=XXREAL-0R2 r or r >=XXREAL-0R2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
      using sin_cos6_th_14 sorry
    have "(-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i >=XXREAL-0R2 r or r >=XXREAL-0R2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
      using A4 sin_cos6_th_13 sorry
    then have "(r =HIDDENR1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i or r =HIDDENR1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i) or r >XXREAL-0R4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
      using A1 A5 A3 xxreal_0_th_1 xxreal_0_th_2 sorry
    thus " not ( not r =HIDDENR1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i &  not r =HIDDENR1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)"
      using A2 A4 sin_cos6_th_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_23:
" for r be RealXREAL-0M1 holds sinSIN-COSK18 r =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M implies r =HIDDENR1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
proof-
  have " for r be RealXREAL-0M1 holds sinSIN-COSK18 r =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M implies r =HIDDENR1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
  proof(rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    let ?i = "[\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]"
    obtain w where
      [ty]:"w be RealXREAL-0M1" and 
      A1: "w =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (-XCMPLX-0K4 ?i) +XCMPLX-0K2 r"and A2: "0NUMBERSK6 <=XXREAL-0R1 w & w <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using complex2_th_1 sorry
    assume A3: "sinSIN-COSK18 r =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
    then have "(cosSIN-COSK20 r)*XCMPLX-0K3 (cosSIN-COSK20 r) +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M) =XBOOLE-0R4 \<one>\<^sub>M"
      using sin_cos_th_29 sorry
    then have A4: "cosSIN-COSK20 r =XBOOLE-0R4 0NUMBERSK6"
       sorry
    have "0NUMBERSK6 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]) <=XXREAL-0R1 w +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]) & w +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
      using A2 xreal_1_th_6 sorry
    then have "r =HIDDENR1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]) or r =HIDDENR1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
      using A1 A4 sin_cos6_th_22 sorry
    thus "r =HIDDENR1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
      using A3 complex2_th_8 sin_cos_th_77 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_24:
" for r be RealXREAL-0M1 holds sinSIN-COSK18 r =XBOOLE-0R4 \<one>\<^sub>M implies r =HIDDENR1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
proof-
  have " for r be RealXREAL-0M1 holds sinSIN-COSK18 r =XBOOLE-0R4 \<one>\<^sub>M implies r =HIDDENR1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
  proof(rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    let ?i = "[\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]"
    obtain w where
      [ty]:"w be RealXREAL-0M1" and 
      A1: "w =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (-XCMPLX-0K4 ?i) +XCMPLX-0K2 r"and A2: "0NUMBERSK6 <=XXREAL-0R1 w & w <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using complex2_th_1 sorry
    assume A3: "sinSIN-COSK18 r =XBOOLE-0R4 \<one>\<^sub>M"
    then have "(cosSIN-COSK20 r)*XCMPLX-0K3 (cosSIN-COSK20 r) +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
      using sin_cos_th_29 sorry
    then have A4: "cosSIN-COSK20 r =XBOOLE-0R4 0NUMBERSK6"
       sorry
    have "0NUMBERSK6 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]) <=XXREAL-0R1 w +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]) & w +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
      using A2 xreal_1_th_6 sorry
    then have "r =HIDDENR1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]) or r =HIDDENR1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
      using A1 A4 sin_cos6_th_22 sorry
    thus "r =HIDDENR1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
      using A3 complex2_th_8 sin_cos_th_77 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_25:
" for r be RealXREAL-0M1 holds cosSIN-COSK20 r =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M implies r =HIDDENR1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
proof-
  have " for r be RealXREAL-0M1 holds cosSIN-COSK20 r =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M implies r =HIDDENR1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
  proof(rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    let ?i = "[\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]"
    obtain w where
      [ty]:"w be RealXREAL-0M1" and 
      A1: "w =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (-XCMPLX-0K4 ?i) +XCMPLX-0K2 r"and A2: "0NUMBERSK6 <=XXREAL-0R1 w & w <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using complex2_th_1 sorry
    assume A3: "cosSIN-COSK20 r =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
    then have "(sinSIN-COSK18 r)*XCMPLX-0K3 (sinSIN-COSK18 r) +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M) =XBOOLE-0R4 \<one>\<^sub>M"
      using sin_cos_th_29 sorry
    then have A4: "sinSIN-COSK18 r =XBOOLE-0R4 0NUMBERSK6"
       sorry
    have "0NUMBERSK6 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]) <=XXREAL-0R1 w +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]) & w +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
      using A2 xreal_1_th_6 sorry
    then have "r =HIDDENR1 0NUMBERSK6 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]) or r =HIDDENR1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
      using A1 A4 sin_cos6_th_21 sorry
    thus "r =HIDDENR1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
      using A3 complex2_th_9 sin_cos_th_31 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_26:
" for r be RealXREAL-0M1 holds cosSIN-COSK20 r =XBOOLE-0R4 \<one>\<^sub>M implies r =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
proof-
  have " for r be RealXREAL-0M1 holds cosSIN-COSK20 r =XBOOLE-0R4 \<one>\<^sub>M implies r =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
  proof(rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    let ?i = "[\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]"
    obtain w where
      [ty]:"w be RealXREAL-0M1" and 
      A1: "w =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (-XCMPLX-0K4 ?i) +XCMPLX-0K2 r"and A2: "0NUMBERSK6 <=XXREAL-0R1 w & w <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using complex2_th_1 sorry
    assume A3: "cosSIN-COSK20 r =XBOOLE-0R4 \<one>\<^sub>M"
    then have "(sinSIN-COSK18 r)*XCMPLX-0K3 (sinSIN-COSK18 r) +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
      using sin_cos_th_29 sorry
    then have A4: "sinSIN-COSK18 r =XBOOLE-0R4 0NUMBERSK6"
       sorry
    have "0NUMBERSK6 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]) <=XXREAL-0R1 w +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]) & w +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
      using A2 xreal_1_th_6 sorry
    then have "r =HIDDENR1 0NUMBERSK6 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]) or r =HIDDENR1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
      using A1 A4 sin_cos6_th_21 sorry
    thus "r =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
      using A3 complex2_th_9 sin_cos_th_77 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_27:
" for r be RealXREAL-0M1 holds (0NUMBERSK6 <=XXREAL-0R1 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) & sinSIN-COSK18 r =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M implies r =HIDDENR1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
proof-
  have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 r & (r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) & sinSIN-COSK18 r =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M) implies r =HIDDENR1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
  proof(rule ballI,rule impMI ,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 r"
      and A2: "r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      and A3: "sinSIN-COSK18 r =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
    have A4: "r =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) or r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using A2 xxreal_0_th_1 sorry
    have "r =HIDDENR1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
      using A3 sin_cos6_th_23 sorry
    also have "... = (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (0NUMBERSK6)"
      using A1 A3 A4 sin_cos6_th_1 sin_cos_th_77 sorry
    also have "... = (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
       sorry
    finally show "r =HIDDENR1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_28:
" for r be RealXREAL-0M1 holds (0NUMBERSK6 <=XXREAL-0R1 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) & sinSIN-COSK18 r =XBOOLE-0R4 \<one>\<^sub>M implies r =HIDDENR1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
proof-
  have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 r & (r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) & sinSIN-COSK18 r =XBOOLE-0R4 \<one>\<^sub>M) implies r =HIDDENR1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
  proof(rule ballI,rule impMI ,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 r"
      and A2: "r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      and A3: "sinSIN-COSK18 r =XBOOLE-0R4 \<one>\<^sub>M"
    have A4: "r =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) or r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using A2 xxreal_0_th_1 sorry
    have "r =HIDDENR1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
      using A3 sin_cos6_th_24 sorry
    also have "... = (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (0NUMBERSK6)"
      using A1 A3 A4 sin_cos6_th_1 sin_cos_th_77 sorry
    also have "... = (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    finally show "r =HIDDENR1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_29:
" for r be RealXREAL-0M1 holds (0NUMBERSK6 <=XXREAL-0R1 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) & cosSIN-COSK20 r =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M implies r =HIDDENR1 PISIN-COSK29"
proof-
  have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 r & (r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) & cosSIN-COSK20 r =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M) implies r =HIDDENR1 PISIN-COSK29"
  proof(rule ballI,rule impMI ,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 r"
      and A2: "r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      and A3: "cosSIN-COSK20 r =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
    have A4: "r =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) or r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using A2 xxreal_0_th_1 sorry
    have "r =HIDDENR1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
      using A3 sin_cos6_th_25 sorry
    also have "... = PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (0NUMBERSK6)"
      using A1 A3 A4 sin_cos6_th_1 sin_cos_th_77 sorry
    also have "... = PISIN-COSK29"
       sorry
    finally show "r =HIDDENR1 PISIN-COSK29"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_30:
" for r be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 r & r <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M implies sinSIN-COSK18 r <XXREAL-0R3 \<one>\<^sub>M"
proof-
  have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 r & (r <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M & sinSIN-COSK18 r >=XXREAL-0R2 \<one>\<^sub>M) implies  not  True "
  proof(rule ballI,rule impMI ,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 r"
      and A2: "r <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      and A3: "sinSIN-COSK18 r >=XXREAL-0R2 \<one>\<^sub>M"
    have A4: "sinSIN-COSK18 r <=XXREAL-0R1 \<one>\<^sub>M"
      using sin_cos6_th_4 sorry
    have "(\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using xreal_1_th_64 sorry
    then have "r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using A2 xxreal_0_th_2 sorry
    thus " not  True "
      using A1 A2 A3 A4 sin_cos6_th_28 xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_31:
" for r be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 r & r <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) implies sinSIN-COSK18 r >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
proof-
  have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 r & (r <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) & sinSIN-COSK18 r <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M) implies  not  True "
  proof(rule ballI,rule impMI ,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 r"
      and A2: "r <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
      and A3: "sinSIN-COSK18 r <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
    have A4: "sinSIN-COSK18 r >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M"
      using sin_cos6_th_3 sorry
    have "r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using A2 sin_cos6_lm_9 xxreal_0_th_2 sorry
    thus " not  True "
      using A1 A2 A3 A4 sin_cos6_th_27 xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_32:
" for r be RealXREAL-0M1 holds (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) implies sinSIN-COSK18 r >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
proof-
  have " for r be RealXREAL-0M1 holds ((\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) & sinSIN-COSK18 r <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M implies  not  True "
  proof(rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "((\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) & sinSIN-COSK18 r <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
    have "sinSIN-COSK18 r >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M"
      using sin_cos6_th_3 sorry
    thus " not  True "
      using A1 sin_cos6_th_27 xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_33:
" for r be RealXREAL-0M1 holds (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) implies sinSIN-COSK18 r <XXREAL-0R3 \<one>\<^sub>M"
proof-
  have " for r be RealXREAL-0M1 holds ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) & sinSIN-COSK18 r >=XXREAL-0R2 \<one>\<^sub>M implies  not  True "
  proof(rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) & sinSIN-COSK18 r >=XXREAL-0R2 \<one>\<^sub>M"
    have "sinSIN-COSK18 r <=XXREAL-0R1 \<one>\<^sub>M"
      using sin_cos6_th_4 sorry
    thus " not  True "
      using A1 sin_cos6_th_28 xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_34:
" for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) implies cosSIN-COSK20 r <XXREAL-0R3 \<one>\<^sub>M"
proof-
  have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) implies  not cosSIN-COSK20 r <XXREAL-0R3 \<one>\<^sub>M"
  proof(rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume "0NUMBERSK6 <XXREAL-0R3 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
    then have A1: "cosSIN-COSK20 r <>HIDDENR2 \<one>\<^sub>M"
      using comptrig_th_61 sorry
    have "cosSIN-COSK20 r <=XXREAL-0R1 \<one>\<^sub>M"
      using sin_cos6_th_6 sorry
    thus " not cosSIN-COSK20 r <XXREAL-0R3 \<one>\<^sub>M"
      using A1 xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_35:
" for r be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 r & r <XXREAL-0R3 PISIN-COSK29 implies cosSIN-COSK20 r >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
proof-
  have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 r & r <XXREAL-0R3 PISIN-COSK29 implies  not cosSIN-COSK20 r >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
  proof(rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 r"
      and A2: "r <XXREAL-0R3 PISIN-COSK29"
    have A3: "cosSIN-COSK20 r >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M"
      using sin_cos6_th_5 sorry
    have "r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using A2 sin_cos6_lm_10 xxreal_0_th_2 sorry
    thus " not cosSIN-COSK20 r >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
      using A1 A2 A3 sin_cos6_th_29 xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_36:
" for r be RealXREAL-0M1 holds PISIN-COSK29 <XXREAL-0R3 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) implies cosSIN-COSK20 r >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
proof-
  have " for r be RealXREAL-0M1 holds PISIN-COSK29 <XXREAL-0R3 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) implies  not cosSIN-COSK20 r >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
  proof(rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "PISIN-COSK29 <XXREAL-0R3 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
    have "cosSIN-COSK20 r >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M"
      using sin_cos6_th_5 sorry
    thus " not cosSIN-COSK20 r >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
      using A1 sin_cos6_th_29 xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_37:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies sinSIN-COSK18 r <XXREAL-0R3 \<one>\<^sub>M"
proof-
  have " for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i) & sinSIN-COSK18 r >=XXREAL-0R2 \<one>\<^sub>M implies  not  True "
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix i assume [ty]: "i be IntegerINT-1M1"
    assume A1: "(\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
      and A2: "sinSIN-COSK18 r >=XXREAL-0R2 \<one>\<^sub>M"
    have A3: "(\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i & r -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
      using A1 xreal_1_th_9 sorry
    have A4: "sinSIN-COSK18 r <=XXREAL-0R1 \<one>\<^sub>M"
      using sin_cos6_th_4 sorry
    have "sinSIN-COSK18 (r -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i) =HIDDENR1 sinSIN-COSK18 (r +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (-XCMPLX-0K4 i))"
       sorry
    also have "... = sinSIN-COSK18 r"
      using complex2_th_8 sorry
    also have "... = \<one>\<^sub>M"
      using A2 A4 xxreal_0_th_1 sorry
    finally have "sinSIN-COSK18 (r -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i) =HIDDENR1 \<one>\<^sub>M"
       sorry
    thus " not  True "
      using A3 sin_cos6_th_30 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_38:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies sinSIN-COSK18 r >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
proof-
  have " for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i) & sinSIN-COSK18 r <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M implies  not  True "
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix i assume [ty]: "i be IntegerINT-1M1"
    assume A1: "(\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
      and A2: "sinSIN-COSK18 r <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
    have A3: "(\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i & r -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 ((\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
      using A1 xreal_1_th_9 sorry
    have A4: "sinSIN-COSK18 r >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M"
      using sin_cos6_th_3 sorry
    have "sinSIN-COSK18 (r -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i) =HIDDENR1 sinSIN-COSK18 (r +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (-XCMPLX-0K4 i))"
       sorry
    also have "... = sinSIN-COSK18 r"
      using complex2_th_8 sorry
    also have "... = -XCMPLX-0K4 \<one>\<^sub>M"
      using A2 A4 xxreal_0_th_1 sorry
    finally have "sinSIN-COSK18 (r -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
       sorry
    thus " not  True "
      using A3 sin_cos6_th_31 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_39:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies sinSIN-COSK18 r >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
proof-
  have " for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds ((\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i) & sinSIN-COSK18 r <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M implies  not  True "
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix i assume [ty]: "i be IntegerINT-1M1"
    assume A1: "(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
      and A2: "sinSIN-COSK18 r <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
    have A3: "((\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i & r -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
      using A1 xreal_1_th_9 sorry
    have A4: "sinSIN-COSK18 r >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M"
      using sin_cos6_th_3 sorry
    have "sinSIN-COSK18 (r -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i) =HIDDENR1 sinSIN-COSK18 (r +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (-XCMPLX-0K4 i))"
       sorry
    also have "... = sinSIN-COSK18 r"
      using complex2_th_8 sorry
    also have "... = -XCMPLX-0K4 \<one>\<^sub>M"
      using A2 A4 xxreal_0_th_1 sorry
    finally have "sinSIN-COSK18 (r -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
       sorry
    thus " not  True "
      using A3 sin_cos6_th_32 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_40:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies sinSIN-COSK18 r <XXREAL-0R3 \<one>\<^sub>M"
proof-
  have " for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i) & sinSIN-COSK18 r >=XXREAL-0R2 \<one>\<^sub>M implies  not  True "
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix i assume [ty]: "i be IntegerINT-1M1"
    assume A1: "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
      and A2: "sinSIN-COSK18 r >=XXREAL-0R2 \<one>\<^sub>M"
    have A3: "((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i & r -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
      using A1 xreal_1_th_9 sorry
    have A4: "sinSIN-COSK18 r <=XXREAL-0R1 \<one>\<^sub>M"
      using sin_cos6_th_4 sorry
    have "sinSIN-COSK18 (r -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i) =HIDDENR1 sinSIN-COSK18 (r +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (-XCMPLX-0K4 i))"
       sorry
    also have "... = sinSIN-COSK18 r"
      using complex2_th_8 sorry
    also have "... = \<one>\<^sub>M"
      using A2 A4 xxreal_0_th_1 sorry
    finally have "sinSIN-COSK18 (r -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i) =HIDDENR1 \<one>\<^sub>M"
       sorry
    thus " not  True "
      using A3 sin_cos6_th_33 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_41:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies cosSIN-COSK20 r <XXREAL-0R3 \<one>\<^sub>M"
proof-
  have " for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i) & cosSIN-COSK20 r >=XXREAL-0R2 \<one>\<^sub>M implies  not  True "
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix i assume [ty]: "i be IntegerINT-1M1"
    assume A1: "(\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
      and A2: "cosSIN-COSK20 r >=XXREAL-0R2 \<one>\<^sub>M"
    have A3: "(\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i & r -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
      using A1 xreal_1_th_9 sorry
    have A4: "cosSIN-COSK20 r <=XXREAL-0R1 \<one>\<^sub>M"
      using sin_cos6_th_6 sorry
    have "cosSIN-COSK20 (r -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i) =HIDDENR1 cosSIN-COSK20 (r +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (-XCMPLX-0K4 i))"
       sorry
    also have "... = cosSIN-COSK20 r"
      using complex2_th_9 sorry
    also have "... = \<one>\<^sub>M"
      using A2 A4 xxreal_0_th_1 sorry
    finally have "cosSIN-COSK20 (r -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i) =HIDDENR1 \<one>\<^sub>M"
       sorry
    thus " not  True "
      using A3 sin_cos6_th_34 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_42:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <XXREAL-0R3 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies cosSIN-COSK20 r >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
proof-
  have " for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <XXREAL-0R3 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i) & cosSIN-COSK20 r <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M implies  not  True "
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix i assume [ty]: "i be IntegerINT-1M1"
    assume A1: "(\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <XXREAL-0R3 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
      and A2: "cosSIN-COSK20 r <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
    have A3: "(\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i & r -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 (PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
      using A1 xreal_1_th_9 sorry
    have A4: "cosSIN-COSK20 r >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M"
      using sin_cos6_th_5 sorry
    have "cosSIN-COSK20 (r -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i) =HIDDENR1 cosSIN-COSK20 (r +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (-XCMPLX-0K4 i))"
       sorry
    also have "... = cosSIN-COSK20 r"
      using complex2_th_9 sorry
    also have "... = -XCMPLX-0K4 \<one>\<^sub>M"
      using A2 A4 xxreal_0_th_1 sorry
    finally have "cosSIN-COSK20 (r -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
       sorry
    thus " not  True "
      using A3 sin_cos6_th_35 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_43:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies cosSIN-COSK20 r >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
proof-
  have " for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i) & cosSIN-COSK20 r <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M implies  not  True "
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix i assume [ty]: "i be IntegerINT-1M1"
    assume A1: "PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
      and A2: "cosSIN-COSK20 r <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
    have A3: "(PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i & r -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
      using A1 xreal_1_th_9 sorry
    have A4: "cosSIN-COSK20 r >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M"
      using sin_cos6_th_5 sorry
    have "cosSIN-COSK20 (r -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i) =HIDDENR1 cosSIN-COSK20 (r +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (-XCMPLX-0K4 i))"
       sorry
    also have "... = cosSIN-COSK20 r"
      using complex2_th_9 sorry
    also have "... = -XCMPLX-0K4 \<one>\<^sub>M"
      using A2 A4 xxreal_0_th_1 sorry
    finally have "cosSIN-COSK20 (r -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
       sorry
    thus " not  True "
      using A3 sin_cos6_th_36 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_44:
" for r be RealXREAL-0M1 holds cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 r) =XBOOLE-0R4 \<one>\<^sub>M implies r inHIDDENR3 INTINT-1K1"
proof-
  have " for r be RealXREAL-0M1 holds cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 r) =XBOOLE-0R4 \<one>\<^sub>M implies ( not r inHIDDENR3 INTINT-1K1 implies  False )"
  proof(rule ballI,rule impI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    obtain d where 
      [ty]:"d be positiveXXREAL-0V2\<bar>RealXREAL-0M1" and dDef:"d = \<two>\<^sub>M"
       sorry
    assume A1: "cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 r) =XBOOLE-0R4 \<one>\<^sub>M"
    assume " not r inHIDDENR3 INTINT-1K1"
    then have " not r be integerINT-1V1"
      using int_1_def_2 sorry
    then obtain t where 
      [ty]:"t be positiveXXREAL-0V2\<bar>RealXREAL-0M1" and tDef:"t = fracINT-1K4 r"
      using int_1_th_46 sorry
    let ?s = "[\\INT-1K2 r/]"
    have A2: "r =HIDDENR1 ?s +XCMPLX-0K2 t & (d *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 t <XXREAL-0R3 (d *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 \<one>\<^sub>M"
      using int_1_th_42 int_1_th_43 xreal_1_th_68 sorry
    have "cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (?s +XCMPLX-0K2 t)) =HIDDENR1 cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ?s +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 t)"
       sorry
    also have "... = cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 t)"
      using complex2_th_9 sorry
    finally have "cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (?s +XCMPLX-0K2 t)) =HIDDENR1 cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 t)"
       sorry
    thus " False "
      using A1 A2 sin_cos6_th_34 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_45:
"(sinSIN-COSK17).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
  using comptrig_th_30 relat_1_th_115 sorry

mtheorem sin_cos6_th_46:
"(sinSIN-COSK17).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[) =XBOOLE-0R4 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
proof-
  have "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[) c=RELSET-1R1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])"
    using relat_1_th_75 xxreal_1_th_25 sorry
  then have A1: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[)) c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]))"
    using relat_1_th_11 sorry
  have A2: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[)) =XBOOLE-0R4 (sinSIN-COSK17).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[)"
    using relat_1_th_115 sorry
  have "(sinSIN-COSK17).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[) c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ & ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ c=TARSKIR1 (sinSIN-COSK17).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[)"
  proof(rule conjMI)
    show "(sinSIN-COSK17).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[) c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 (sinSIN-COSK17).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[) implies x inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A3: "x inHIDDENR3 (sinSIN-COSK17).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[)"
        then obtain a where
          [ty]:"a be objectHIDDENM1" and 
          A4: "a inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17)"and A5: "a inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["and A6: "(sinSIN-COSK17).FUNCT-1K1 a =HIDDENR1 x"
          using funct_1_def_6 sorry
        have 
          [ty]:"a be RealXREAL-0M1" and
          [ty]:"x be RealXREAL-0M1"
          using A4 A6 sorry
        let ?i = "[\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]"
        have A7: "((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 \<one>\<^sub>M) =XBOOLE-0R4 ?i /XCMPLX-0K7 \<one>\<^sub>M"
          using xcmplx_1_th_91 sorry
        have A8: "(sinSIN-COSK17).FUNCT-1K1 a =XBOOLE-0R4 sinSIN-COSK18 a"
          using sin_cos_def_17 sorry
        have A9: "x =HIDDENR1 \<one>\<^sub>M implies  False "
        proof(rule impI)
          assume "x =HIDDENR1 \<one>\<^sub>M"
          then have A10: "a =HIDDENR1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
            using A6 A8 sin_cos6_th_24 sorry
          then have "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]) <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
            using A5 xxreal_1_th_4 sorry
          then have "((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]))-XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
            using xreal_1_th_9 sorry
          then have "?i <XXREAL-0R3 0NUMBERSK6"
             sorry
          then have A11: "?i <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
            using int_1_th_8 sorry
          have "-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
            using A5 A10 xxreal_1_th_4 sorry
          then have "(-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]))-XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
            using xreal_1_th_9 sorry
          then have "((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) <XXREAL-0R3 ?i"
            using A7 xreal_1_th_74 sorry
          then have "(-XCMPLX-0K4 \<one>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 ?i"
            using xcmplx_1_th_91 sorry
          thus " False "
            using A11 xxreal_0_th_2 sorry
        qed
        have A12: "x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M implies  False "
        proof(rule impI)
          assume "x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
          then have A13: "a =HIDDENR1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
            using A6 A8 sin_cos6_th_23 sorry
          then have "-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
            using A5 xxreal_1_th_4 sorry
          then have "(-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 ((\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]))-XCMPLX-0K6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
            using xreal_1_th_9 sorry
          then have "(-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) <XXREAL-0R3 ?i"
            using A7 xreal_1_th_74 sorry
          then have "-XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) <XXREAL-0R3 ?i"
            using xcmplx_1_th_187 sorry
          then have "-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 ?i"
            using xcmplx_1_th_60 sorry
          then have A14: "(-XCMPLX-0K4 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 ?i"
            using int_1_th_7 sorry
          have "(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]) <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
            using A5 A13 xxreal_1_th_4 sorry
          then have "((\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]))-XCMPLX-0K6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
            using xreal_1_th_9 sorry
          then have "?i <XXREAL-0R3 (-XCMPLX-0K4 PISIN-COSK29)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))"
            using A7 xreal_1_th_74 sorry
          thus " False "
            using A14 xcmplx_1_th_91 sorry
        qed
        have "x <=XXREAL-0R1 \<one>\<^sub>M"
          using A1 A2 A3 comptrig_th_30 xxreal_1_th_1 sorry
        then have A15: "x <XXREAL-0R3 \<one>\<^sub>M"
          using A9 xxreal_0_th_1 sorry
        have "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 x"
          using A1 A2 A3 comptrig_th_30 xxreal_1_th_1 sorry
        then have "-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 x"
          using A12 xxreal_0_th_1 sorry
        thus "x inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
          using A15 xxreal_1_th_4 sorry
      qed "sorry"
      thus "(sinSIN-COSK17).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[) c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
        using tarski_def_3 sorry
    qed
    have " for a be objectHIDDENM1 holds a inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ implies a inHIDDENR3 (sinSIN-COSK17).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[)"
    proof(rule ballI,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      assume A16: "a inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
      then have 
        [ty]:"a be RealXREAL-0M1"
         sorry
      have "-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 a & a <XXREAL-0R3 \<one>\<^sub>M"
        using A16 xxreal_1_th_4 sorry
      then have "a inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]))"
        using comptrig_th_30 xxreal_1_th_1 sorry
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A17: "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]))"and A18: "((sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])).FUNCT-1K1 x =HIDDENR1 a"
        using funct_1_def_3 sorry
      have 
        [ty]:"x be RealXREAL-0M1"
        using A17 sorry
      have A19: "(sinSIN-COSK17).FUNCT-1K1 x =HIDDENR1 a"
        using A17 A18 funct_1_th_47 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]"
        using relat_1_th_62 sin_cos_th_24 sorry
      then have "-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <=XXREAL-0R1 x & x <=XXREAL-0R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
        using A17 xxreal_1_th_1 sorry
      then have "(-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 x & x <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M =HIDDENR1 x) or (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M =HIDDENR1 x"
        using xxreal_0_th_1 sorry
      then have "x inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
        using A16 A19 sin_cos6_th_7 sin_cos_th_76 xxreal_1_th_4 sorry
      thus "a inHIDDENR3 (sinSIN-COSK17).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[)"
        using A19 funct_1_def_6 sin_cos_th_24 sorry
    qed "sorry"
    thus "].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ c=TARSKIR1 (sinSIN-COSK17).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[)"
      using tarski_def_3 sorry
  qed
  thus "(sinSIN-COSK17).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[) =XBOOLE-0R4 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
    using xboole_0_def_10 sorry
qed

mtheorem sin_cos6_th_47:
"(sinSIN-COSK17).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
  using comptrig_th_31 relat_1_th_115 sorry

mtheorem sin_cos6_th_48:
"(sinSIN-COSK17).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[) =XBOOLE-0R4 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
proof-
  have "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[) c=RELSET-1R1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .])"
    using relat_1_th_75 xxreal_1_th_25 sorry
  then have A1: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[)) c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]))"
    using relat_1_th_11 sorry
  have A2: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[)) =XBOOLE-0R4 (sinSIN-COSK17).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[)"
    using relat_1_th_115 sorry
  have "(sinSIN-COSK17).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[) c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ & ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ c=TARSKIR1 (sinSIN-COSK17).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[)"
  proof(rule conjMI)
    show "(sinSIN-COSK17).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[) c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 (sinSIN-COSK17).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[) implies x inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A3: "x inHIDDENR3 (sinSIN-COSK17).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[)"
        then obtain a where
          [ty]:"a be objectHIDDENM1" and 
          A4: "a inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17)"and A5: "a inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .["and A6: "(sinSIN-COSK17).FUNCT-1K1 a =HIDDENR1 x"
          using funct_1_def_6 sorry
        have 
          [ty]:"a be RealXREAL-0M1" and
          [ty]:"x be RealXREAL-0M1"
          using A4 A6 sorry
        let ?i = "[\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]"
        have A7: "((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 \<one>\<^sub>M) =XBOOLE-0R4 ?i /XCMPLX-0K7 \<one>\<^sub>M"
          using xcmplx_1_th_91 sorry
        have A8: "(sinSIN-COSK17).FUNCT-1K1 a =XBOOLE-0R4 sinSIN-COSK18 a"
          using sin_cos_def_17 sorry
        have A9: "x =HIDDENR1 \<one>\<^sub>M implies  False "
        proof(rule impI)
          assume "x =HIDDENR1 \<one>\<^sub>M"
          then have A10: "a =HIDDENR1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
            using A6 A8 sin_cos6_th_24 sorry
          then have "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
            using A5 xxreal_1_th_4 sorry
          then have "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]))-XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
            using xreal_1_th_9 sorry
          then have "0NUMBERSK6 <XXREAL-0R3 ?i"
             sorry
          then have A11: "0NUMBERSK6 +XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 ?i"
            using int_1_th_7 sorry
          have "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]) <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
            using A5 A10 xxreal_1_th_4 sorry
          then have "((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]))-XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
            using xreal_1_th_9 sorry
          then have "?i <XXREAL-0R3 (\<one>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))"
            using A7 xreal_1_th_74 sorry
          then have "?i <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M"
            using xcmplx_1_th_91 sorry
          thus " False "
            using A11 xxreal_0_th_2 sorry
        qed
        have A12: "x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M implies  False "
        proof(rule impI)
          assume "x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
          then have A13: "a =HIDDENR1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
            using A6 A8 sin_cos6_th_23 sorry
          then have "(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]) <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
            using A5 xxreal_1_th_4 sorry
          then have "((\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]))-XCMPLX-0K6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
            using xreal_1_th_9 sorry
          then have "?i <XXREAL-0R3 0NUMBERSK6"
             sorry
          then have A14: "?i <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
            using int_1_th_8 sorry
          have "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
            using A5 A13 xxreal_1_th_4 sorry
          then have "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 ((\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]))-XCMPLX-0K6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
            using xreal_1_th_9 sorry
          then have "((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) <XXREAL-0R3 ?i"
            using A7 xreal_1_th_74 sorry
          then have "(-XCMPLX-0K4 \<one>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 ?i"
            using xcmplx_1_th_91 sorry
          thus " False "
            using A14 xxreal_0_th_2 sorry
        qed
        have "x <=XXREAL-0R1 \<one>\<^sub>M"
          using A1 A2 A3 comptrig_th_31 xxreal_1_th_1 sorry
        then have A15: "x <XXREAL-0R3 \<one>\<^sub>M"
          using A9 xxreal_0_th_1 sorry
        have "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 x"
          using A1 A2 A3 comptrig_th_31 xxreal_1_th_1 sorry
        then have "-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 x"
          using A12 xxreal_0_th_1 sorry
        thus "x inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
          using A15 xxreal_1_th_4 sorry
      qed "sorry"
      thus "(sinSIN-COSK17).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[) c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
        using tarski_def_3 sorry
    qed
    have " for a be objectHIDDENM1 holds a inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ implies a inHIDDENR3 (sinSIN-COSK17).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[)"
    proof(rule ballI,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      assume A16: "a inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
      then have 
        [ty]:"a be RealXREAL-0M1"
         sorry
      have "-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 a & a <XXREAL-0R3 \<one>\<^sub>M"
        using A16 xxreal_1_th_4 sorry
      then have "a inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]))"
        using comptrig_th_31 xxreal_1_th_1 sorry
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A17: "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]))"and A18: "((sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .])).FUNCT-1K1 x =HIDDENR1 a"
        using funct_1_def_3 sorry
      have 
        [ty]:"x be RealXREAL-0M1"
        using A17 sorry
      have A19: "(sinSIN-COSK17).FUNCT-1K1 x =HIDDENR1 a"
        using A17 A18 funct_1_th_47 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .])) =XBOOLE-0R4 [.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]"
        using relat_1_th_62 sin_cos_th_24 sorry
      then have "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <=XXREAL-0R1 x & x <=XXREAL-0R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
        using A17 xxreal_1_th_1 sorry
      then have "((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 x & x <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) or (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M =HIDDENR1 x) or (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) =HIDDENR1 x"
        using xxreal_0_th_1 sorry
      then have "x inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .["
        using A16 A19 sin_cos_th_76 xxreal_1_th_4 sorry
      thus "a inHIDDENR3 (sinSIN-COSK17).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[)"
        using A19 funct_1_def_6 sin_cos_th_24 sorry
    qed "sorry"
    thus "].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ c=TARSKIR1 (sinSIN-COSK17).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[)"
      using tarski_def_3 sorry
  qed
  thus "(sinSIN-COSK17).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[) =XBOOLE-0R4 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
    using xboole_0_def_10 sorry
qed

mtheorem sin_cos6_th_49:
"(cosSIN-COSK19).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
  using comptrig_th_32 relat_1_th_115 sorry

mtheorem sin_cos6_th_50:
"(cosSIN-COSK19).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[) =XBOOLE-0R4 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
proof-
  have "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[) c=RELSET-1R1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])"
    using relat_1_th_75 xxreal_1_th_25 sorry
  then have A1: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[)) c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]))"
    using relat_1_th_11 sorry
  have A2: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[)) =XBOOLE-0R4 (cosSIN-COSK19).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[)"
    using relat_1_th_115 sorry
  have "(cosSIN-COSK19).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[) c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ & ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ c=TARSKIR1 (cosSIN-COSK19).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[)"
  proof(rule conjMI)
    show "(cosSIN-COSK19).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[) c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 (cosSIN-COSK19).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[) implies x inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A3: "x inHIDDENR3 (cosSIN-COSK19).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[)"
        then obtain a where
          [ty]:"a be objectHIDDENM1" and 
          A4: "a inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19)"and A5: "a inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["and A6: "(cosSIN-COSK19).FUNCT-1K1 a =HIDDENR1 x"
          using funct_1_def_6 sorry
        have 
          [ty]:"a be RealXREAL-0M1" and
          [ty]:"x be RealXREAL-0M1"
          using A4 A6 sorry
        let ?i = "[\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]"
        have A7: "((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 \<one>\<^sub>M) =XBOOLE-0R4 ?i /XCMPLX-0K7 \<one>\<^sub>M"
          using xcmplx_1_th_91 sorry
        have A8: "(cosSIN-COSK19).FUNCT-1K1 a =XBOOLE-0R4 cosSIN-COSK20 a"
          using sin_cos_def_19 sorry
        have A9: "x =HIDDENR1 \<one>\<^sub>M implies  False "
        proof(rule impI)
          assume "x =HIDDENR1 \<one>\<^sub>M"
          then have A10: "a =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
            using A6 A8 sin_cos6_th_26 sorry
          then have "(\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]) <XXREAL-0R3 PISIN-COSK29"
            using A5 xxreal_1_th_4 sorry
          then have "?i <XXREAL-0R3 (\<one>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))"
            using A7 xreal_1_th_74 sorry
          then have A11: "?i <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M"
            using xcmplx_1_th_91 sorry
          have "0NUMBERSK6 <XXREAL-0R3 ?i"
            using A5 A10 xxreal_1_th_4 sorry
          then have "0NUMBERSK6 +XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 ?i"
            using int_1_th_7 sorry
          thus " False "
            using A11 xxreal_0_th_2 sorry
        qed
        have A12: "x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M implies  False "
        proof(rule impI)
          assume "x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
          then have A13: "a =HIDDENR1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
            using A6 A8 sin_cos6_th_25 sorry
          then have "0NUMBERSK6 <XXREAL-0R3 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
            using A5 xxreal_1_th_4 sorry
          then have "0NUMBERSK6 -XCMPLX-0K6 PISIN-COSK29 <XXREAL-0R3 (PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]))-XCMPLX-0K6 PISIN-COSK29"
            using xreal_1_th_9 sorry
          then have "(-XCMPLX-0K4 PISIN-COSK29)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) <XXREAL-0R3 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))"
            using xreal_1_th_74 sorry
          then have "-XCMPLX-0K4 (\<one>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) <XXREAL-0R3 ?i"
            using A7 xcmplx_1_th_187 sorry
          then have A14: "-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 ?i"
            using xcmplx_1_th_91 sorry
          have "PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]) <XXREAL-0R3 PISIN-COSK29"
            using A5 A13 xxreal_1_th_4 sorry
          then have "(PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]))-XCMPLX-0K6 PISIN-COSK29 <XXREAL-0R3 PISIN-COSK29 -XCMPLX-0K6 PISIN-COSK29"
            using xreal_1_th_9 sorry
          then have "?i <XXREAL-0R3 0NUMBERSK6"
             sorry
          then have "?i <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
            using int_1_th_8 sorry
          thus " False "
            using A14 xxreal_0_th_2 sorry
        qed
        have "x <=XXREAL-0R1 \<one>\<^sub>M"
          using A1 A2 A3 comptrig_th_32 xxreal_1_th_1 sorry
        then have A15: "x <XXREAL-0R3 \<one>\<^sub>M"
          using A9 xxreal_0_th_1 sorry
        have "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 x"
          using A1 A2 A3 comptrig_th_32 xxreal_1_th_1 sorry
        then have "-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 x"
          using A12 xxreal_0_th_1 sorry
        thus "x inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
          using A15 xxreal_1_th_4 sorry
      qed "sorry"
      thus "(cosSIN-COSK19).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[) c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
        using tarski_def_3 sorry
    qed
    have " for a be objectHIDDENM1 holds a inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ implies a inHIDDENR3 (cosSIN-COSK19).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[)"
    proof(rule ballI,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      assume A16: "a inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
      then have 
        [ty]:"a be RealXREAL-0M1"
         sorry
      have "-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 a & a <XXREAL-0R3 \<one>\<^sub>M"
        using A16 xxreal_1_th_4 sorry
      then have "a inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]))"
        using comptrig_th_32 xxreal_1_th_1 sorry
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A17: "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]))"and A18: "((cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])).FUNCT-1K1 x =HIDDENR1 a"
        using funct_1_def_3 sorry
      have 
        [ty]:"x be RealXREAL-0M1"
        using A17 sorry
      have A19: "(cosSIN-COSK19).FUNCT-1K1 x =HIDDENR1 a"
        using A17 A18 funct_1_th_47 sorry
      have A20: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])) =XBOOLE-0R4 [.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]"
        using relat_1_th_62 sin_cos_th_24 sorry
      then have "x <=XXREAL-0R1 PISIN-COSK29"
        using A17 xxreal_1_th_1 sorry
      then have "(0NUMBERSK6 <XXREAL-0R3 x & x <XXREAL-0R3 PISIN-COSK29 or 0NUMBERSK6 =HIDDENR1 x) or PISIN-COSK29 =HIDDENR1 x"
        using A17 A20 xxreal_0_th_1 xxreal_1_th_1 sorry
      then have "x inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
        using A16 A19 sin_cos_th_30 sin_cos_th_76 xxreal_1_th_4 sorry
      thus "a inHIDDENR3 (cosSIN-COSK19).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[)"
        using A19 funct_1_def_6 sin_cos_th_24 sorry
    qed "sorry"
    thus "].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ c=TARSKIR1 (cosSIN-COSK19).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[)"
      using tarski_def_3 sorry
  qed
  thus "(cosSIN-COSK19).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[) =XBOOLE-0R4 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
    using xboole_0_def_10 sorry
qed

mtheorem sin_cos6_th_51:
"(cosSIN-COSK19).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
  using comptrig_th_33 relat_1_th_115 sorry

mtheorem sin_cos6_th_52:
"(cosSIN-COSK19).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[) =XBOOLE-0R4 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
proof-
  have "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[) c=RELSET-1R1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .])"
    using relat_1_th_75 xxreal_1_th_25 sorry
  then have A1: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[)) c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]))"
    using relat_1_th_11 sorry
  have A2: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[)) =XBOOLE-0R4 (cosSIN-COSK19).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[)"
    using relat_1_th_115 sorry
  have "(cosSIN-COSK19).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[) c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ & ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ c=TARSKIR1 (cosSIN-COSK19).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[)"
  proof(rule conjMI)
    show "(cosSIN-COSK19).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[) c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 (cosSIN-COSK19).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[) implies x inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A3: "x inHIDDENR3 (cosSIN-COSK19).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[)"
        then obtain a where
          [ty]:"a be objectHIDDENM1" and 
          A4: "a inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19)"and A5: "a inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .["and A6: "(cosSIN-COSK19).FUNCT-1K1 a =HIDDENR1 x"
          using funct_1_def_6 sorry
        have 
          [ty]:"a be RealXREAL-0M1" and
          [ty]:"x be RealXREAL-0M1"
          using A4 A6 sorry
        let ?i = "[\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]"
        have A7: "((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 \<one>\<^sub>M) =XBOOLE-0R4 ?i /XCMPLX-0K7 \<one>\<^sub>M"
          using xcmplx_1_th_91 sorry
        have A8: "(cosSIN-COSK19).FUNCT-1K1 a =XBOOLE-0R4 cosSIN-COSK20 a"
          using sin_cos_def_19 sorry
        have A9: "x =HIDDENR1 \<one>\<^sub>M implies  False "
        proof(rule impI)
          assume "x =HIDDENR1 \<one>\<^sub>M"
          then have A10: "a =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
            using A6 A8 sin_cos6_th_26 sorry
          then have "(\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
            using A5 xxreal_1_th_4 sorry
          then have "?i <XXREAL-0R3 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))"
            using A7 xreal_1_th_74 sorry
          then have A11: "?i <XXREAL-0R3 \<one>\<^sub>M +XCMPLX-0K2 0NUMBERSK6"
            using xcmplx_1_th_60 sorry
          have "PISIN-COSK29 <XXREAL-0R3 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
            using A5 A10 xxreal_1_th_4 sorry
          thus " False "
            using A7 A11 int_1_th_7 sorry
        qed
        have A12: "x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M implies  False "
        proof(rule impI)
          assume "x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
          then have A13: "a =HIDDENR1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
            using A6 A8 sin_cos6_th_25 sorry
          then have "PISIN-COSK29 <XXREAL-0R3 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
            using A5 xxreal_1_th_4 sorry
          then have "PISIN-COSK29 -XCMPLX-0K6 PISIN-COSK29 <XXREAL-0R3 (PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]))-XCMPLX-0K6 PISIN-COSK29"
            using xreal_1_th_9 sorry
          then have "(0NUMBERSK6)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) <XXREAL-0R3 ?i"
             sorry
          then have A14: "0NUMBERSK6 +XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 ?i"
            using int_1_th_7 sorry
          have "PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
            using A5 A13 xxreal_1_th_4 sorry
          then have "(PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]))-XCMPLX-0K6 PISIN-COSK29 <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 PISIN-COSK29"
            using xreal_1_th_9 sorry
          then have "?i <XXREAL-0R3 (\<one>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))"
            using A7 xreal_1_th_74 sorry
          then have "?i <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M"
            using xcmplx_1_th_91 sorry
          thus " False "
            using A14 xxreal_0_th_2 sorry
        qed
        have "x <=XXREAL-0R1 \<one>\<^sub>M"
          using A1 A2 A3 comptrig_th_33 xxreal_1_th_1 sorry
        then have A15: "x <XXREAL-0R3 \<one>\<^sub>M"
          using A9 xxreal_0_th_1 sorry
        have "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 x"
          using A1 A2 A3 comptrig_th_33 xxreal_1_th_1 sorry
        then have "-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 x"
          using A12 xxreal_0_th_1 sorry
        thus "x inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
          using A15 xxreal_1_th_4 sorry
      qed "sorry"
      thus "(cosSIN-COSK19).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[) c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
        using tarski_def_3 sorry
    qed
    have " for a be objectHIDDENM1 holds a inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ implies a inHIDDENR3 (cosSIN-COSK19).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[)"
    proof(rule ballI,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      assume A16: "a inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
      then have 
        [ty]:"a be RealXREAL-0M1"
         sorry
      have "-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 a & a <XXREAL-0R3 \<one>\<^sub>M"
        using A16 xxreal_1_th_4 sorry
      then have "a inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]))"
        using comptrig_th_33 xxreal_1_th_1 sorry
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A17: "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]))"and A18: "((cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .])).FUNCT-1K1 x =HIDDENR1 a"
        using funct_1_def_3 sorry
      have 
        [ty]:"x be RealXREAL-0M1"
        using A17 sorry
      have A19: "(cosSIN-COSK19).FUNCT-1K1 x =HIDDENR1 a"
        using A17 A18 funct_1_th_47 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .])) =XBOOLE-0R4 [.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]"
        using relat_1_th_62 sin_cos_th_24 sorry
      then have "PISIN-COSK29 <=XXREAL-0R1 x & x <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
        using A17 xxreal_1_th_1 sorry
      then have "(PISIN-COSK29 <XXREAL-0R3 x & x <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) or PISIN-COSK29 =HIDDENR1 x) or \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) =HIDDENR1 x"
        using xxreal_0_th_1 sorry
      then have "x inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .["
        using A16 A19 sin_cos_th_76 xxreal_1_th_4 sorry
      thus "a inHIDDENR3 (cosSIN-COSK19).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[)"
        using A19 funct_1_def_6 sin_cos_th_24 sorry
    qed "sorry"
    thus "].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ c=TARSKIR1 (cosSIN-COSK19).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[)"
      using tarski_def_3 sorry
  qed
  thus "(cosSIN-COSK19).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[) =XBOOLE-0R4 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
    using xboole_0_def_10 sorry
qed

mlemma sin_cos6_lm_11:
" for i be IntegerINT-1M1 holds  for r be RealXREAL-0M1 holds  for p1 be RealXREAL-0M1 holds  for p2 be RealXREAL-0M1 holds r inHIDDENR3 [.RCOMP-1K1 p1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,p2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .] implies r +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 [.RCOMP-1K1 p1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M),p2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M) .]"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix i assume [ty]: "i be IntegerINT-1M1"
  fix r assume [ty]: "r be RealXREAL-0M1"
  fix p1 assume [ty]: "p1 be RealXREAL-0M1"
  fix p2 assume [ty]: "p2 be RealXREAL-0M1"
  assume A1: "r inHIDDENR3 [.RCOMP-1K1 p1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,p2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]"
  then have "r <=XXREAL-0R1 p2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
    using xxreal_1_th_1 sorry
  then have A2: "r +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) <=XXREAL-0R1 (p2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
    using xreal_1_th_6 sorry
  have "p1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r"
    using A1 xxreal_1_th_1 sorry
  then have "(p1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) <=XXREAL-0R1 r +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
    using xreal_1_th_6 sorry
  thus "r +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 [.RCOMP-1K1 p1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M),p2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M) .]"
    using A2 xxreal_1_th_1 sorry
qed "sorry"

mlemma sin_cos6_lm_12:
" for i be IntegerINT-1M1 holds  for r be RealXREAL-0M1 holds  for p1 be RealXREAL-0M1 holds  for p2 be RealXREAL-0M1 holds r inHIDDENR3 ([.RCOMP-1K1 p1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,p2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> REALNUMBERSK2 implies r +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 ([.RCOMP-1K1 p1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M),p2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M) .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> REALNUMBERSK2"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix i assume [ty]: "i be IntegerINT-1M1"
  fix r assume [ty]: "r be RealXREAL-0M1"
  fix p1 assume [ty]: "p1 be RealXREAL-0M1"
  fix p2 assume [ty]: "p2 be RealXREAL-0M1"
  assume "r inHIDDENR3 ([.RCOMP-1K1 p1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,p2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> REALNUMBERSK2"
  then have "r inHIDDENR3 [.RCOMP-1K1 p1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,p2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]"
    using xboole_0_def_4 sorry
  then have "r +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 [.RCOMP-1K1 p1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M),p2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M) .]"
    using sin_cos6_lm_11 sorry
  thus "r +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 ([.RCOMP-1K1 p1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M),p2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M) .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> REALNUMBERSK2"
    using xboole_0_def_4 sorry
qed "sorry"

mlemma sin_cos6_lm_13:
" for i be IntegerINT-1M1 holds  for r be RealXREAL-0M1 holds  for p1 be RealXREAL-0M1 holds  for p2 be RealXREAL-0M1 holds r inHIDDENR3 [.RCOMP-1K1 p1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,p2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .] implies r -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 [.RCOMP-1K1 p1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M),p2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M) .]"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix i assume [ty]: "i be IntegerINT-1M1"
  fix r assume [ty]: "r be RealXREAL-0M1"
  fix p1 assume [ty]: "p1 be RealXREAL-0M1"
  fix p2 assume [ty]: "p2 be RealXREAL-0M1"
  assume A1: "r inHIDDENR3 [.RCOMP-1K1 p1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,p2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]"
  then have "r <=XXREAL-0R1 p2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
    using xxreal_1_th_1 sorry
  then have A2: "r -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) <=XXREAL-0R1 (p2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
    using xreal_1_th_9 sorry
  have "p1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r"
    using A1 xxreal_1_th_1 sorry
  then have "(p1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) <=XXREAL-0R1 r -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
    using xreal_1_th_9 sorry
  thus "r -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 [.RCOMP-1K1 p1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M),p2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M) .]"
    using A2 xxreal_1_th_1 sorry
qed "sorry"

mlemma sin_cos6_lm_14:
" for i be IntegerINT-1M1 holds  for r be RealXREAL-0M1 holds  for p1 be RealXREAL-0M1 holds  for p2 be RealXREAL-0M1 holds r inHIDDENR3 ([.RCOMP-1K1 p1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,p2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> REALNUMBERSK2 implies r -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 ([.RCOMP-1K1 p1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M),p2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M) .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> REALNUMBERSK2"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix i assume [ty]: "i be IntegerINT-1M1"
  fix r assume [ty]: "r be RealXREAL-0M1"
  fix p1 assume [ty]: "p1 be RealXREAL-0M1"
  fix p2 assume [ty]: "p2 be RealXREAL-0M1"
  assume "r inHIDDENR3 ([.RCOMP-1K1 p1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,p2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> REALNUMBERSK2"
  then have "r inHIDDENR3 [.RCOMP-1K1 p1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,p2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]"
    using xboole_0_def_4 sorry
  then have "r -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 [.RCOMP-1K1 p1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M),p2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M) .]"
    using sin_cos6_lm_13 sorry
  thus "r -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 ([.RCOMP-1K1 p1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M),p2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M) .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> REALNUMBERSK2"
    using xboole_0_def_4 sorry
qed "sorry"

mtheorem sin_cos6_th_53:
" for i be IntegerINT-1M1 holds (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be increasingRFUNCT-2V1"
proof-
  have " for i be IntegerINT-1M1 holds (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be increasingRFUNCT-2V1"
  proof(rule ballI)
    fix i assume [ty]: "i be IntegerINT-1M1"
    let ?P = "\<lambda>Lamb1. (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 Lamb1,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 Lamb1 .]) be increasingRFUNCT-2V1"
    have A1: " for i be IntegerINT-1M1 holds ?P(i) implies ?P(i -XCMPLX-0K6 \<one>\<^sub>M) & ?P(i +XCMPLX-0K2 \<one>\<^sub>M)"
    proof-
      have " for i be IntegerINT-1M1 holds (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be increasingRFUNCT-2V1 implies (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M),(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M) .]) be increasingRFUNCT-2V1 & (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M),(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M) .]) be increasingRFUNCT-2V1"
      proof(rule ballI,rule impI,rule conjMI)
        fix i assume [ty]: "i be IntegerINT-1M1"
        assume A2: "?P(i)"
        let ?Z = "[.RCOMP-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ((i -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M),(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ((i -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M) .]"
        show "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M),(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M) .]) be increasingRFUNCT-2V1"
        proof-
          let ?Y = "[.RCOMP-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M),(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M) .]"
          have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 ([.RCOMP-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M),(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M) .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17) & r2 inHIDDENR3 ([.RCOMP-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M),(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M) .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17) implies (r1 <XXREAL-0R3 r2 implies (sinSIN-COSK17).FUNCT-1K1 r1 <XXREAL-0R3 (sinSIN-COSK17).FUNCT-1K1 r2)"
          proof(rule ballI,rule ballI,rule impI,rule impI)
            fix r1 assume [ty]: "r1 be RealXREAL-0M1"
            fix r2 assume [ty]: "r2 be RealXREAL-0M1"
            assume "r1 inHIDDENR3 ?Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17) & r2 inHIDDENR3 ?Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17)"
            then have A3: "r1 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 ?Z /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17) & r2 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 ?Z /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17)"
              using sin_cos6_lm_12 sin_cos_th_24 sorry
            assume "r1 <XXREAL-0R3 r2"
            then have "r1 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 r2 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
              using xreal_1_th_6 sorry
            then have "(sinSIN-COSK17).FUNCT-1K1 (r1 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) <XXREAL-0R3 (sinSIN-COSK17).FUNCT-1K1 (r2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 \<one>\<^sub>M)"
              using A2 A3 rfunct_2_th_20 sorry
            then have "(sinSIN-COSK17).FUNCT-1K1 (r1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 \<one>\<^sub>M) <XXREAL-0R3 (sinSIN-COSK17).FUNCT-1K1 r2"
              using sin_cos6_th_8 sorry
            thus "(sinSIN-COSK17).FUNCT-1K1 r1 <XXREAL-0R3 (sinSIN-COSK17).FUNCT-1K1 r2"
              using sin_cos6_th_8 sorry
          qed "sorry"
          thus "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M),(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M) .]) be increasingRFUNCT-2V1"
            using rfunct_2_th_20 sorry
        qed
        let ?Y = "[.RCOMP-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M),(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M) .]"
        have A4: "?Z =XBOOLE-0R4 [.RCOMP-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ((i +XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M),(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ((i +XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M) .]"
           sorry
        have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 ([.RCOMP-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M),(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M) .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17) & r2 inHIDDENR3 ([.RCOMP-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M),(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M) .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17) implies (r1 <XXREAL-0R3 r2 implies (sinSIN-COSK17).FUNCT-1K1 r1 <XXREAL-0R3 (sinSIN-COSK17).FUNCT-1K1 r2)"
        proof(rule ballI,rule ballI,rule impI,rule impI)
          fix r1 assume [ty]: "r1 be RealXREAL-0M1"
          fix r2 assume [ty]: "r2 be RealXREAL-0M1"
          assume "r1 inHIDDENR3 ?Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17) & r2 inHIDDENR3 ?Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17)"
          then have A5: "r1 -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 ?Z /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17) & r2 -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 ?Z /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17)"
            using A4 sin_cos6_lm_14 sin_cos_th_24 sorry
          assume "r1 <XXREAL-0R3 r2"
          then have "r1 -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 r2 -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
            using xreal_1_th_9 sorry
          then have "(sinSIN-COSK17).FUNCT-1K1 (r1 -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) <XXREAL-0R3 (sinSIN-COSK17).FUNCT-1K1 (r2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M))"
            using A2 A5 rfunct_2_th_20 sorry
          then have "(sinSIN-COSK17).FUNCT-1K1 (r1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M)) <XXREAL-0R3 (sinSIN-COSK17).FUNCT-1K1 r2"
            using sin_cos6_th_8 sorry
          thus "(sinSIN-COSK17).FUNCT-1K1 r1 <XXREAL-0R3 (sinSIN-COSK17).FUNCT-1K1 r2"
            using sin_cos6_th_8 sorry
        qed "sorry"
        thus "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M),(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M) .]) be increasingRFUNCT-2V1"
          using rfunct_2_th_20 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A6: "?P(0NUMBERSK6)"
      using comptrig_th_23 sorry
    have " for i be IntegerINT-1M1 holds ?P(i)"
      using int_1_sch_4 A6 A1 sorry
    thus "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be increasingRFUNCT-2V1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_54:
" for i be IntegerINT-1M1 holds (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be decreasingRFUNCT-2V2"
proof-
  have " for i be IntegerINT-1M1 holds (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be decreasingRFUNCT-2V2"
  proof(rule ballI)
    fix i assume [ty]: "i be IntegerINT-1M1"
    let ?P = "\<lambda>Lamb1. (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 Lamb1,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 Lamb1 .]) be decreasingRFUNCT-2V2"
    have A1: " for i be IntegerINT-1M1 holds ?P(i) implies ?P(i -XCMPLX-0K6 \<one>\<^sub>M) & ?P(i +XCMPLX-0K2 \<one>\<^sub>M)"
    proof-
      have " for i be IntegerINT-1M1 holds (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be decreasingRFUNCT-2V2 implies (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M),(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M) .]) be decreasingRFUNCT-2V2 & (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M),(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M) .]) be decreasingRFUNCT-2V2"
      proof(rule ballI,rule impI,rule conjMI)
        fix i assume [ty]: "i be IntegerINT-1M1"
        assume A2: "?P(i)"
        let ?Z = "[.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ((i -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M),(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ((i -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M) .]"
        show "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M),(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M) .]) be decreasingRFUNCT-2V2"
        proof-
          let ?Y = "[.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M),(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M) .]"
          have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M),(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M) .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17) & r2 inHIDDENR3 ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M),(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M) .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17) implies (r1 <XXREAL-0R3 r2 implies (sinSIN-COSK17).FUNCT-1K1 r1 >XXREAL-0R4 (sinSIN-COSK17).FUNCT-1K1 r2)"
          proof(rule ballI,rule ballI,rule impI,rule impI)
            fix r1 assume [ty]: "r1 be RealXREAL-0M1"
            fix r2 assume [ty]: "r2 be RealXREAL-0M1"
            assume "r1 inHIDDENR3 ?Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17) & r2 inHIDDENR3 ?Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17)"
            then have A3: "r1 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 ?Z /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17) & r2 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 ?Z /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17)"
              using sin_cos6_lm_12 sin_cos_th_24 sorry
            assume "r1 <XXREAL-0R3 r2"
            then have "r1 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 r2 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
              using xreal_1_th_6 sorry
            then have "(sinSIN-COSK17).FUNCT-1K1 (r1 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) >XXREAL-0R4 (sinSIN-COSK17).FUNCT-1K1 (r2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 \<one>\<^sub>M)"
              using A2 A3 rfunct_2_th_21 sorry
            then have "(sinSIN-COSK17).FUNCT-1K1 (r1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 \<one>\<^sub>M) >XXREAL-0R4 (sinSIN-COSK17).FUNCT-1K1 r2"
              using sin_cos6_th_8 sorry
            thus "(sinSIN-COSK17).FUNCT-1K1 r1 >XXREAL-0R4 (sinSIN-COSK17).FUNCT-1K1 r2"
              using sin_cos6_th_8 sorry
          qed "sorry"
          thus "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M),(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M) .]) be decreasingRFUNCT-2V2"
            using rfunct_2_th_21 sorry
        qed
        let ?Y = "[.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M),(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M) .]"
        have A4: "?Z =XBOOLE-0R4 [.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ((i +XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M),(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ((i +XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M) .]"
           sorry
        have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M),(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M) .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17) & r2 inHIDDENR3 ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M),(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M) .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17) implies (r1 <XXREAL-0R3 r2 implies (sinSIN-COSK17).FUNCT-1K1 r1 >XXREAL-0R4 (sinSIN-COSK17).FUNCT-1K1 r2)"
        proof(rule ballI,rule ballI,rule impI,rule impI)
          fix r1 assume [ty]: "r1 be RealXREAL-0M1"
          fix r2 assume [ty]: "r2 be RealXREAL-0M1"
          assume "r1 inHIDDENR3 ?Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17) & r2 inHIDDENR3 ?Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17)"
          then have A5: "r1 -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 ?Z /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17) & r2 -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 ?Z /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17)"
            using A4 sin_cos6_lm_14 sin_cos_th_24 sorry
          assume "r1 <XXREAL-0R3 r2"
          then have "r1 -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 r2 -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
            using xreal_1_th_9 sorry
          then have "(sinSIN-COSK17).FUNCT-1K1 (r1 -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) >XXREAL-0R4 (sinSIN-COSK17).FUNCT-1K1 (r2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M))"
            using A2 A5 rfunct_2_th_21 sorry
          then have "(sinSIN-COSK17).FUNCT-1K1 (r1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M)) >XXREAL-0R4 (sinSIN-COSK17).FUNCT-1K1 r2"
            using sin_cos6_th_8 sorry
          thus "(sinSIN-COSK17).FUNCT-1K1 r1 >XXREAL-0R4 (sinSIN-COSK17).FUNCT-1K1 r2"
            using sin_cos6_th_8 sorry
        qed "sorry"
        thus "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M),(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M) .]) be decreasingRFUNCT-2V2"
          using rfunct_2_th_21 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A6: "?P(0NUMBERSK6)"
      using comptrig_th_24 sorry
    have " for i be IntegerINT-1M1 holds ?P(i)"
      using int_1_sch_4 A6 A1 sorry
    thus "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be decreasingRFUNCT-2V2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_55:
" for i be IntegerINT-1M1 holds (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be decreasingRFUNCT-2V2"
proof-
  have " for i be IntegerINT-1M1 holds (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be decreasingRFUNCT-2V2"
  proof(rule ballI)
    fix i assume [ty]: "i be IntegerINT-1M1"
    let ?P = "\<lambda>Lamb1. (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 Lamb1,PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 Lamb1 .]) be decreasingRFUNCT-2V2"
    have A1: " for i be IntegerINT-1M1 holds ?P(i) implies ?P(i -XCMPLX-0K6 \<one>\<^sub>M) & ?P(i +XCMPLX-0K2 \<one>\<^sub>M)"
    proof-
      have " for i be IntegerINT-1M1 holds (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be decreasingRFUNCT-2V2 implies (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M),PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M) .]) be decreasingRFUNCT-2V2 & (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M),PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M) .]) be decreasingRFUNCT-2V2"
      proof(rule ballI,rule impI,rule conjMI)
        fix i assume [ty]: "i be IntegerINT-1M1"
        assume A2: "?P(i)"
        let ?Z = "[.RCOMP-1K1 0NUMBERSK6 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ((i -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M),PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ((i -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M) .]"
        show "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M),PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M) .]) be decreasingRFUNCT-2V2"
        proof-
          let ?Y = "[.RCOMP-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M),PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M) .]"
          have A3: "?Y =XBOOLE-0R4 [.RCOMP-1K1 0NUMBERSK6 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M),PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M) .]"
             sorry
          have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 ([.RCOMP-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M),PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M) .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19) & r2 inHIDDENR3 ([.RCOMP-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M),PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M) .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19) implies (r1 <XXREAL-0R3 r2 implies (cosSIN-COSK19).FUNCT-1K1 r1 >XXREAL-0R4 (cosSIN-COSK19).FUNCT-1K1 r2)"
          proof(rule ballI,rule ballI,rule impI,rule impI)
            fix r1 assume [ty]: "r1 be RealXREAL-0M1"
            fix r2 assume [ty]: "r2 be RealXREAL-0M1"
            assume "r1 inHIDDENR3 ?Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19) & r2 inHIDDENR3 ?Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19)"
            then have A4: "r1 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 ?Z /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19) & r2 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 ?Z /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19)"
              using A3 sin_cos6_lm_12 sin_cos_th_24 sorry
            assume "r1 <XXREAL-0R3 r2"
            then have "r1 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 r2 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
              using xreal_1_th_6 sorry
            then have "(cosSIN-COSK19).FUNCT-1K1 (r1 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) >XXREAL-0R4 (cosSIN-COSK19).FUNCT-1K1 (r2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 \<one>\<^sub>M)"
              using A2 A4 rfunct_2_th_21 sorry
            then have "(cosSIN-COSK19).FUNCT-1K1 (r1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 \<one>\<^sub>M) >XXREAL-0R4 (cosSIN-COSK19).FUNCT-1K1 r2"
              using sin_cos6_th_10 sorry
            thus "(cosSIN-COSK19).FUNCT-1K1 r1 >XXREAL-0R4 (cosSIN-COSK19).FUNCT-1K1 r2"
              using sin_cos6_th_10 sorry
          qed "sorry"
          thus "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M),PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M) .]) be decreasingRFUNCT-2V2"
            using rfunct_2_th_21 sorry
        qed
        let ?Y = "[.RCOMP-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M),PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M) .]"
        have A5: "?Y =XBOOLE-0R4 [.RCOMP-1K1 0NUMBERSK6 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M),PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M) .] & ?Z =XBOOLE-0R4 [.RCOMP-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ((i +XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M),PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ((i +XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M) .]"
           sorry
        have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 ([.RCOMP-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M),PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M) .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19) & r2 inHIDDENR3 ([.RCOMP-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M),PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M) .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19) implies (r1 <XXREAL-0R3 r2 implies (cosSIN-COSK19).FUNCT-1K1 r1 >XXREAL-0R4 (cosSIN-COSK19).FUNCT-1K1 r2)"
        proof(rule ballI,rule ballI,rule impI,rule impI)
          fix r1 assume [ty]: "r1 be RealXREAL-0M1"
          fix r2 assume [ty]: "r2 be RealXREAL-0M1"
          assume "r1 inHIDDENR3 ?Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19) & r2 inHIDDENR3 ?Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19)"
          then have A6: "r1 -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 ?Z /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19) & r2 -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 ?Z /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19)"
            using A5 sin_cos6_lm_14 sin_cos_th_24 sorry
          assume "r1 <XXREAL-0R3 r2"
          then have "r1 -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 r2 -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
            using xreal_1_th_9 sorry
          then have "(cosSIN-COSK19).FUNCT-1K1 (r1 -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) >XXREAL-0R4 (cosSIN-COSK19).FUNCT-1K1 (r2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M))"
            using A2 A6 rfunct_2_th_21 sorry
          then have "(cosSIN-COSK19).FUNCT-1K1 (r1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M)) >XXREAL-0R4 (cosSIN-COSK19).FUNCT-1K1 r2"
            using sin_cos6_th_10 sorry
          thus "(cosSIN-COSK19).FUNCT-1K1 r1 >XXREAL-0R4 (cosSIN-COSK19).FUNCT-1K1 r2"
            using sin_cos6_th_10 sorry
        qed "sorry"
        thus "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M),PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M) .]) be decreasingRFUNCT-2V2"
          using rfunct_2_th_21 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A7: "?P(0NUMBERSK6)"
      using comptrig_th_25 sorry
    have " for i be IntegerINT-1M1 holds ?P(i)"
      using int_1_sch_4 A7 A1 sorry
    thus "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be decreasingRFUNCT-2V2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_56:
" for i be IntegerINT-1M1 holds (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be increasingRFUNCT-2V1"
proof-
  have " for i be IntegerINT-1M1 holds (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be increasingRFUNCT-2V1"
  proof(rule ballI)
    fix i assume [ty]: "i be IntegerINT-1M1"
    let ?P = "\<lambda>Lamb1. (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 Lamb1,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 Lamb1 .]) be increasingRFUNCT-2V1"
    have A1: " for i be IntegerINT-1M1 holds ?P(i) implies ?P(i -XCMPLX-0K6 \<one>\<^sub>M) & ?P(i +XCMPLX-0K2 \<one>\<^sub>M)"
    proof-
      have " for i be IntegerINT-1M1 holds (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be increasingRFUNCT-2V1 implies (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M) .]) be increasingRFUNCT-2V1 & (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M) .]) be increasingRFUNCT-2V1"
      proof(rule ballI,rule impI,rule conjMI)
        fix i assume [ty]: "i be IntegerINT-1M1"
        assume A2: "?P(i)"
        let ?Z = "[.RCOMP-1K1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ((i -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ((i -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M) .]"
        show "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M) .]) be increasingRFUNCT-2V1"
        proof-
          let ?Y = "[.RCOMP-1K1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M) .]"
          have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 ([.RCOMP-1K1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M) .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19) & r2 inHIDDENR3 ([.RCOMP-1K1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M) .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19) implies (r1 <XXREAL-0R3 r2 implies (cosSIN-COSK19).FUNCT-1K1 r1 <XXREAL-0R3 (cosSIN-COSK19).FUNCT-1K1 r2)"
          proof(rule ballI,rule ballI,rule impI,rule impI)
            fix r1 assume [ty]: "r1 be RealXREAL-0M1"
            fix r2 assume [ty]: "r2 be RealXREAL-0M1"
            assume "r1 inHIDDENR3 ?Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19) & r2 inHIDDENR3 ?Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19)"
            then have A3: "r1 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 ?Z /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19) & r2 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 ?Z /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19)"
              using sin_cos6_lm_12 sin_cos_th_24 sorry
            assume "r1 <XXREAL-0R3 r2"
            then have "r1 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 r2 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
              using xreal_1_th_6 sorry
            then have "(cosSIN-COSK19).FUNCT-1K1 (r1 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) <XXREAL-0R3 (cosSIN-COSK19).FUNCT-1K1 (r2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 \<one>\<^sub>M)"
              using A2 A3 rfunct_2_th_20 sorry
            then have "(cosSIN-COSK19).FUNCT-1K1 (r1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 \<one>\<^sub>M) <XXREAL-0R3 (cosSIN-COSK19).FUNCT-1K1 r2"
              using sin_cos6_th_10 sorry
            thus "(cosSIN-COSK19).FUNCT-1K1 r1 <XXREAL-0R3 (cosSIN-COSK19).FUNCT-1K1 r2"
              using sin_cos6_th_10 sorry
          qed "sorry"
          thus "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M) .]) be increasingRFUNCT-2V1"
            using rfunct_2_th_20 sorry
        qed
        let ?Y = "[.RCOMP-1K1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M) .]"
        have A4: "?Z =XBOOLE-0R4 [.RCOMP-1K1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ((i +XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ((i +XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M) .]"
           sorry
        have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 ([.RCOMP-1K1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M) .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19) & r2 inHIDDENR3 ([.RCOMP-1K1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M) .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19) implies (r1 <XXREAL-0R3 r2 implies (cosSIN-COSK19).FUNCT-1K1 r1 <XXREAL-0R3 (cosSIN-COSK19).FUNCT-1K1 r2)"
        proof(rule ballI,rule ballI,rule impI,rule impI)
          fix r1 assume [ty]: "r1 be RealXREAL-0M1"
          fix r2 assume [ty]: "r2 be RealXREAL-0M1"
          assume "r1 inHIDDENR3 ?Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19) & r2 inHIDDENR3 ?Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19)"
          then have A5: "r1 -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 ?Z /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19) & r2 -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 ?Z /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19)"
            using A4 sin_cos6_lm_14 sin_cos_th_24 sorry
          assume "r1 <XXREAL-0R3 r2"
          then have "r1 -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 r2 -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
            using xreal_1_th_9 sorry
          then have "(cosSIN-COSK19).FUNCT-1K1 (r1 -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) <XXREAL-0R3 (cosSIN-COSK19).FUNCT-1K1 (r2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M))"
            using A2 A5 rfunct_2_th_20 sorry
          then have "(cosSIN-COSK19).FUNCT-1K1 (r1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M)) <XXREAL-0R3 (cosSIN-COSK19).FUNCT-1K1 r2"
            using sin_cos6_th_10 sorry
          thus "(cosSIN-COSK19).FUNCT-1K1 r1 <XXREAL-0R3 (cosSIN-COSK19).FUNCT-1K1 r2"
            using sin_cos6_th_10 sorry
        qed "sorry"
        thus "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M) .]) be increasingRFUNCT-2V1"
          using rfunct_2_th_20 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A6: "?P(0NUMBERSK6)"
      using comptrig_th_26 sorry
    have " for i be IntegerINT-1M1 holds ?P(i)"
      using int_1_sch_4 A6 A1 sorry
    thus "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be increasingRFUNCT-2V1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_57:
" for i be IntegerINT-1M1 holds (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be one-to-oneFUNCT-1V2"
proof-
  have " for i be IntegerINT-1M1 holds (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be one-to-oneFUNCT-1V2"
  proof(rule ballI)
    fix i assume [ty]: "i be IntegerINT-1M1"
    let ?Q = "[.RCOMP-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]"
    have "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?Q be increasingRFUNCT-2V1"
      using sin_cos6_th_53 sorry
    thus "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be one-to-oneFUNCT-1V2"
      using fcont_3_th_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_58:
" for i be IntegerINT-1M1 holds (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be one-to-oneFUNCT-1V2"
proof-
  have " for i be IntegerINT-1M1 holds (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be one-to-oneFUNCT-1V2"
  proof(rule ballI)
    fix i assume [ty]: "i be IntegerINT-1M1"
    let ?Q = "[.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]"
    have "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?Q be decreasingRFUNCT-2V2"
      using sin_cos6_th_54 sorry
    thus "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be one-to-oneFUNCT-1V2"
      using fcont_3_th_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_cl_2:
"cluster (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) be one-to-oneFUNCT-1V2"
    using sin_cos6_lm_1 sin_cos6_th_57 sorry
qed "sorry"

mtheorem sin_cos6_cl_3:
"cluster (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]) be one-to-oneFUNCT-1V2"
    using sin_cos6_lm_2 sin_cos6_th_58 sorry
qed "sorry"

mtheorem sin_cos6_cl_4:
"cluster (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,0NUMBERSK6 .]) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,0NUMBERSK6 .]) be one-to-oneFUNCT-1V2"
  proof-
    have "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) be one-to-oneFUNCT-1V2"
       sorry
    thus "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,0NUMBERSK6 .]) be one-to-oneFUNCT-1V2"
      using sin_cos6_th_2 xxreal_1_th_34 sorry
  qed
qed "sorry"

mtheorem sin_cos6_cl_5:
"cluster (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) be one-to-oneFUNCT-1V2"
  proof-
    have "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) be one-to-oneFUNCT-1V2"
       sorry
    thus "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) be one-to-oneFUNCT-1V2"
      using sin_cos6_th_2 xxreal_1_th_34 sorry
  qed
qed "sorry"

mtheorem sin_cos6_cl_6:
"cluster (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .]) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .]) be one-to-oneFUNCT-1V2"
  proof-
    have "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]) be one-to-oneFUNCT-1V2"
       sorry
    thus "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .]) be one-to-oneFUNCT-1V2"
      using sin_cos6_lm_7 sin_cos6_th_2 xxreal_1_th_34 sorry
  qed
qed "sorry"

mtheorem sin_cos6_cl_7:
"cluster (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]) be one-to-oneFUNCT-1V2"
  proof-
    have "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]) be one-to-oneFUNCT-1V2"
       sorry
    thus "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]) be one-to-oneFUNCT-1V2"
      using sin_cos6_lm_6 sin_cos6_th_2 xxreal_1_th_34 sorry
  qed
qed "sorry"

mtheorem sin_cos6_cl_8:
"cluster (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]) be one-to-oneFUNCT-1V2"
  proof-
    have "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 \<one>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 \<one>\<^sub>M .]) be one-to-oneFUNCT-1V2"
      using sin_cos6_th_57 sorry
    thus "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]) be one-to-oneFUNCT-1V2"
      using sin_cos6_lm_8 sin_cos6_th_2 xxreal_1_th_34 sorry
  qed
qed "sorry"

mtheorem sin_cos6_cl_9:
"cluster (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[) be one-to-oneFUNCT-1V2"
  proof-
    have "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) be one-to-oneFUNCT-1V2"
       sorry
    thus "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[) be one-to-oneFUNCT-1V2"
      using sin_cos6_th_2 xxreal_1_th_25 sorry
  qed
qed "sorry"

mtheorem sin_cos6_cl_10:
"cluster (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[) be one-to-oneFUNCT-1V2"
  proof-
    have "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]) be one-to-oneFUNCT-1V2"
       sorry
    thus "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[) be one-to-oneFUNCT-1V2"
      using sin_cos6_th_2 xxreal_1_th_25 sorry
  qed
qed "sorry"

mtheorem sin_cos6_cl_11:
"cluster (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,0NUMBERSK6 .[) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,0NUMBERSK6 .[) be one-to-oneFUNCT-1V2"
  proof-
    have "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,0NUMBERSK6 .]) be one-to-oneFUNCT-1V2"
       sorry
    thus "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,0NUMBERSK6 .[) be one-to-oneFUNCT-1V2"
      using sin_cos6_th_2 xxreal_1_th_25 sorry
  qed
qed "sorry"

mtheorem sin_cos6_cl_12:
"cluster (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[) be one-to-oneFUNCT-1V2"
  proof-
    have "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) be one-to-oneFUNCT-1V2"
       sorry
    thus "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[) be one-to-oneFUNCT-1V2"
      using sin_cos6_th_2 xxreal_1_th_25 sorry
  qed
qed "sorry"

mtheorem sin_cos6_cl_13:
"cluster (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[) be one-to-oneFUNCT-1V2"
  proof-
    have "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .]) be one-to-oneFUNCT-1V2"
       sorry
    thus "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[) be one-to-oneFUNCT-1V2"
      using sin_cos6_th_2 xxreal_1_th_25 sorry
  qed
qed "sorry"

mtheorem sin_cos6_cl_14:
"cluster (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[) be one-to-oneFUNCT-1V2"
  proof-
    have "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]) be one-to-oneFUNCT-1V2"
       sorry
    thus "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[) be one-to-oneFUNCT-1V2"
      using sin_cos6_th_2 xxreal_1_th_25 sorry
  qed
qed "sorry"

mtheorem sin_cos6_cl_15:
"cluster (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[) be one-to-oneFUNCT-1V2"
  proof-
    have "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]) be one-to-oneFUNCT-1V2"
       sorry
    thus "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[) be one-to-oneFUNCT-1V2"
      using sin_cos6_th_2 xxreal_1_th_25 sorry
  qed
qed "sorry"

mtheorem sin_cos6_th_59:
" for i be IntegerINT-1M1 holds (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be one-to-oneFUNCT-1V2"
proof-
  have " for i be IntegerINT-1M1 holds (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be one-to-oneFUNCT-1V2"
  proof(rule ballI)
    fix i assume [ty]: "i be IntegerINT-1M1"
    let ?Q1 = "[.RCOMP-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]"
    have "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?Q1 be decreasingRFUNCT-2V2"
      using sin_cos6_th_55 sorry
    thus "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be one-to-oneFUNCT-1V2"
      using fcont_3_th_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_60:
" for i be IntegerINT-1M1 holds (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be one-to-oneFUNCT-1V2"
proof-
  have " for i be IntegerINT-1M1 holds (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be one-to-oneFUNCT-1V2"
  proof(rule ballI)
    fix i assume [ty]: "i be IntegerINT-1M1"
    let ?Q1 = "[.RCOMP-1K1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]"
    have "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?Q1 be increasingRFUNCT-2V1"
      using sin_cos6_th_56 sorry
    thus "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be one-to-oneFUNCT-1V2"
      using fcont_3_th_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_cl_16:
"cluster (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]) be one-to-oneFUNCT-1V2"
    using sin_cos6_lm_3 sin_cos6_th_59 sorry
qed "sorry"

mtheorem sin_cos6_cl_17:
"cluster (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]) be one-to-oneFUNCT-1V2"
    using sin_cos6_lm_4 sin_cos6_th_60 sorry
qed "sorry"

mtheorem sin_cos6_cl_18:
"cluster (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) be one-to-oneFUNCT-1V2"
  proof-
    have "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]) be one-to-oneFUNCT-1V2"
       sorry
    thus "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) be one-to-oneFUNCT-1V2"
      using sin_cos6_lm_6 sin_cos6_th_2 xxreal_1_th_34 sorry
  qed
qed "sorry"

mtheorem sin_cos6_cl_19:
"cluster (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .]) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .]) be one-to-oneFUNCT-1V2"
  proof-
    have "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]) be one-to-oneFUNCT-1V2"
       sorry
    thus "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .]) be one-to-oneFUNCT-1V2"
      using sin_cos6_th_2 xxreal_1_th_34 sorry
  qed
qed "sorry"

mtheorem sin_cos6_cl_20:
"cluster (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]) be one-to-oneFUNCT-1V2"
  proof-
    have "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]) be one-to-oneFUNCT-1V2"
       sorry
    thus "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]) be one-to-oneFUNCT-1V2"
      using sin_cos6_lm_9 sin_cos6_th_2 xxreal_1_th_34 sorry
  qed
qed "sorry"

mtheorem sin_cos6_cl_21:
"cluster (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]) be one-to-oneFUNCT-1V2"
  proof-
    have "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]) be one-to-oneFUNCT-1V2"
       sorry
    thus "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]) be one-to-oneFUNCT-1V2"
      using sin_cos6_lm_7 sin_cos6_th_2 xxreal_1_th_34 sorry
  qed
qed "sorry"

mtheorem sin_cos6_cl_22:
"cluster (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[) be one-to-oneFUNCT-1V2"
  proof-
    have "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]) be one-to-oneFUNCT-1V2"
       sorry
    thus "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[) be one-to-oneFUNCT-1V2"
      using sin_cos6_th_2 xxreal_1_th_25 sorry
  qed
qed "sorry"

mtheorem sin_cos6_cl_23:
"cluster (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[) be one-to-oneFUNCT-1V2"
  proof-
    have "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]) be one-to-oneFUNCT-1V2"
       sorry
    thus "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[) be one-to-oneFUNCT-1V2"
      using sin_cos6_th_2 xxreal_1_th_25 sorry
  qed
qed "sorry"

mtheorem sin_cos6_cl_24:
"cluster (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[) be one-to-oneFUNCT-1V2"
  proof-
    have "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) be one-to-oneFUNCT-1V2"
       sorry
    thus "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[) be one-to-oneFUNCT-1V2"
      using sin_cos6_th_2 xxreal_1_th_25 sorry
  qed
qed "sorry"

mtheorem sin_cos6_cl_25:
"cluster (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[) be one-to-oneFUNCT-1V2"
  proof-
    have "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .]) be one-to-oneFUNCT-1V2"
       sorry
    thus "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[) be one-to-oneFUNCT-1V2"
      using sin_cos6_th_2 xxreal_1_th_25 sorry
  qed
qed "sorry"

mtheorem sin_cos6_cl_26:
"cluster (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[) be one-to-oneFUNCT-1V2"
  proof-
    have "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]) be one-to-oneFUNCT-1V2"
       sorry
    thus "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[) be one-to-oneFUNCT-1V2"
      using sin_cos6_th_2 xxreal_1_th_25 sorry
  qed
qed "sorry"

mtheorem sin_cos6_cl_27:
"cluster (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[) be one-to-oneFUNCT-1V2"
  proof-
    have "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]) be one-to-oneFUNCT-1V2"
       sorry
    thus "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[) be one-to-oneFUNCT-1V2"
      using sin_cos6_th_2 xxreal_1_th_25 sorry
  qed
qed "sorry"

mtheorem sin_cos6_th_61:
" for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (((((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i) & (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 s) & s <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i) & sinSIN-COSK18 r =XBOOLE-0R4 sinSIN-COSK18 s) & cosSIN-COSK20 r =XBOOLE-0R4 cosSIN-COSK20 s implies r =HIDDENR1 s"
proof-
  have " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & ((r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i & (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 s) & (s <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i & (sinSIN-COSK18 r =XBOOLE-0R4 sinSIN-COSK18 s & cosSIN-COSK20 r =XBOOLE-0R4 cosSIN-COSK20 s))) implies r =HIDDENR1 s"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    fix i assume [ty]: "i be IntegerINT-1M1"
    assume A1: "(\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r"
      and A2: "r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i & (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 s"
      and A3: "s <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
      and A4: "sinSIN-COSK18 r =XBOOLE-0R4 sinSIN-COSK18 s & cosSIN-COSK20 r =XBOOLE-0R4 cosSIN-COSK20 s"
    have A5: "cosSIN-COSK20 (r -XCMPLX-0K6 s) =HIDDENR1 (cosSIN-COSK20 r)*XCMPLX-0K3 (cosSIN-COSK20 s) +XCMPLX-0K2 (sinSIN-COSK18 r)*XCMPLX-0K3 (sinSIN-COSK18 s)"
      using complex2_th_3 sorry
    also have "... = \<one>\<^sub>M"
      using A4 sin_cos_th_29 sorry
    finally have "cosSIN-COSK20 (r -XCMPLX-0K6 s) =HIDDENR1 \<one>\<^sub>M"
       sorry
    have A6: "sinSIN-COSK18 (r -XCMPLX-0K6 s) =HIDDENR1 (sinSIN-COSK18 r)*XCMPLX-0K3 (cosSIN-COSK20 s) -XCMPLX-0K6 (cosSIN-COSK20 r)*XCMPLX-0K3 (sinSIN-COSK18 s)"
      using complex2_th_3 sorry
    also have "... = 0NUMBERSK6"
      using A4 sorry
    finally have "sinSIN-COSK18 (r -XCMPLX-0K6 s) =HIDDENR1 0NUMBERSK6"
       sorry
    have A7: "cosSIN-COSK20 (s -XCMPLX-0K6 r) =HIDDENR1 (cosSIN-COSK20 r)*XCMPLX-0K3 (cosSIN-COSK20 s) +XCMPLX-0K2 (sinSIN-COSK18 r)*XCMPLX-0K3 (sinSIN-COSK18 s)"
      using complex2_th_3 sorry
    also have "... = \<one>\<^sub>M"
      using A4 sin_cos_th_29 sorry
    finally have "cosSIN-COSK20 (s -XCMPLX-0K6 r) =HIDDENR1 \<one>\<^sub>M"
       sorry
    have A8: "sinSIN-COSK18 (s -XCMPLX-0K6 r) =HIDDENR1 (sinSIN-COSK18 s)*XCMPLX-0K3 (cosSIN-COSK20 r) -XCMPLX-0K6 (cosSIN-COSK20 s)*XCMPLX-0K3 (sinSIN-COSK18 r)"
      using complex2_th_3 sorry
    also have "... = 0NUMBERSK6"
      using A4 sorry
    finally have "sinSIN-COSK18 (s -XCMPLX-0K6 r) =HIDDENR1 0NUMBERSK6"
       sorry
    show "r =HIDDENR1 s"
    proof-
      have cases: "(r >XXREAL-0R4 s or r <XXREAL-0R3 s) or r =HIDDENR1 s"
        using xxreal_0_th_1 sorry
      have case1: "r >XXREAL-0R4 s implies r =HIDDENR1 s"
      proof(rule impI)
        assume A9: "r >XXREAL-0R4 s"
        have "r +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)+XCMPLX-0K2 s"
          using A2 xreal_1_th_8 sorry
        then have "(r +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)+XCMPLX-0K2 s)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
          using xreal_1_th_9 sorry
        then have "r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 s"
           sorry
        then have A10: "r -XCMPLX-0K6 s <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
          using xreal_1_th_19 sorry
        have "r >XXREAL-0R4 s +XCMPLX-0K2 0NUMBERSK6"
          using A9 sorry
        then have "0NUMBERSK6 <=XXREAL-0R1 r -XCMPLX-0K6 s"
          using xreal_1_th_20 sorry
        then have "r -XCMPLX-0K6 s =XBOOLE-0R4 0NUMBERSK6 or r -XCMPLX-0K6 s =HIDDENR1 PISIN-COSK29"
          using A6 A10 comptrig_th_17 sorry
        thus "r =HIDDENR1 s"
          using A5 sin_cos_th_77 sorry
      qed
      have case2: "r <XXREAL-0R3 s implies r =HIDDENR1 s"
      proof(rule impI)
        assume A11: "r <XXREAL-0R3 s"
        have "s +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)+XCMPLX-0K2 r"
          using A1 A3 xreal_1_th_8 sorry
        then have "(s +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)+XCMPLX-0K2 r)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
          using xreal_1_th_9 sorry
        then have "s <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 r"
           sorry
        then have A12: "s -XCMPLX-0K6 r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
          using xreal_1_th_19 sorry
        have "s >XXREAL-0R4 r +XCMPLX-0K2 0NUMBERSK6"
          using A11 sorry
        then have "0NUMBERSK6 <=XXREAL-0R1 s -XCMPLX-0K6 r"
          using xreal_1_th_20 sorry
        then have "s -XCMPLX-0K6 r =XBOOLE-0R4 0NUMBERSK6 or s -XCMPLX-0K6 r =HIDDENR1 PISIN-COSK29"
          using A8 A12 comptrig_th_17 sorry
        thus "r =HIDDENR1 s"
          using A7 sin_cos_th_77 sorry
      qed
      have case3: "r =HIDDENR1 s implies r =HIDDENR1 s"
      proof(rule impI)
        assume "r =HIDDENR1 s"
        thus "r =HIDDENR1 s"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mdef sin_cos6_def_1 ("arcsinSIN-COS6K1" 164 ) where
"func arcsinSIN-COS6K1 \<rightarrow> PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) equals
  ((sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>"
proof-
  (*coherence*)
    show "((sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
       sorry
qed "sorry"

mdef sin_cos6_def_2 ("arcsinSIN-COS6K2  _ " [164]164 ) where
  mlet "r be objectHIDDENM1"
"func arcsinSIN-COS6K2 r \<rightarrow> numberORDINAL1M2 equals
  (arcsinSIN-COS6K1).FUNCT-1K1 r"
proof-
  (*coherence*)
    show "(arcsinSIN-COS6K1).FUNCT-1K1 r be numberORDINAL1M2"
       sorry
qed "sorry"

mtheorem sin_cos6_cl_28:
  mlet "r be objectHIDDENM1"
"cluster arcsinSIN-COS6K2 r as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "arcsinSIN-COS6K2 r be realXREAL-0V1"
     sorry
qed "sorry"

mlemma sin_cos6_lm_15:
"(arcsinSIN-COS6K1)\<inverse>FUNCT-1K4 =FUNCT-1R1 (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])"
  using funct_1_th_43 sorry

mtheorem sin_cos6_th_62:
"rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]"
proof-
  have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]"
    using relat_1_th_62 sin_cos_th_24 sorry
  thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]"
    using funct_1_th_33 sorry
qed

mtheorem sin_cos6_cl_29:
"cluster arcsinSIN-COS6K1 as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "arcsinSIN-COS6K1 be one-to-oneFUNCT-1V2"
     sorry
qed "sorry"

mtheorem sin_cos6_th_63:
"domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
  using comptrig_th_30 funct_1_th_33 sorry

mtheorem sin_cos6_th_64:
"(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) *FUNCT-1K3 (arcsinSIN-COS6K1) =FUNCT-1R1 idPARTFUN1K6 ([.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .])"
  using comptrig_th_30 funct_1_th_39 sorry

mtheorem sin_cos6_th_65:
"(arcsinSIN-COS6K1)*RELSET-1K4\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) =FUNCT-1R1 idPARTFUN1K6 ([.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .])"
  using comptrig_th_30 funct_1_th_39 sorry

mtheorem sin_cos6_th_66:
"(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) *RELSET-1K4\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) =FUNCT-1R1 idPARTFUN1K6 ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])"
  using sin_cos6_lm_15 sin_cos6_th_62 funct_1_th_39 sorry

mtheorem sin_cos6_th_67:
"(arcsinSIN-COS6K1)*FUNCT-1K3 (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) =FUNCT-1R1 idPARTFUN1K6 ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])"
  using sin_cos6_lm_15 sin_cos6_th_62 funct_1_th_39 sorry

mtheorem sin_cos6_th_68:
" for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M implies sinSIN-COSK18 (arcsinSIN-COS6K2 r) =HIDDENR1 r"
proof-
  have " for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M implies sinSIN-COSK18 (arcsinSIN-COS6K2 r) =HIDDENR1 r"
  proof(rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M"
    then have A1: "r inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
      using xxreal_1_th_1 sorry
    then have A2: "(arcsinSIN-COS6K1).FUNCT-1K1 r inTARSKIR2 [.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]"
      using sin_cos6_th_62 sin_cos6_th_63 funct_1_def_3 sorry
    have "sinSIN-COSK18 (arcsinSIN-COS6K2 r) =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 ((arcsinSIN-COS6K1).FUNCT-1K1 r)"
      using sin_cos_def_17 sorry
    also have "... = ((sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])).FUNCT-1K1 ((arcsinSIN-COS6K1).FUNCT-1K1 r)"
      using A2 funct_1_th_49 sorry
    also have "... = idPARTFUN1K6 ([.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]) .FUNCT-1K1 r"
      using A1 sin_cos6_th_63 sin_cos6_th_64 funct_1_th_13 sorry
    also have "... = r"
      using A1 funct_1_th_18 sorry
    finally show "sinSIN-COSK18 (arcsinSIN-COS6K2 r) =HIDDENR1 r"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_69:
" for r be RealXREAL-0M1 holds -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M implies arcsinSIN-COS6K2 (sinSIN-COSK18 r) =HIDDENR1 r"
proof-
  have " for r be RealXREAL-0M1 holds -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M implies arcsinSIN-COS6K2 (sinSIN-COSK18 r) =HIDDENR1 r"
  proof(rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    have A1: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]"
      using relat_1_th_62 sin_cos_th_24 sorry
    assume "-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
    then have A2: "r inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]"
      using xxreal_1_th_1 sorry
    have "arcsinSIN-COS6K2 (sinSIN-COSK18 r) =HIDDENR1 (arcsinSIN-COS6K1).FUNCT-1K1 ((sinSIN-COSK17).FUNCT-1K1 r)"
      using sin_cos_def_17 sorry
    also have "... = (arcsinSIN-COS6K1).FUNCT-1K1 (((sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])).FUNCT-1K1 r)"
      using A2 funct_1_th_49 sorry
    also have "... = idPARTFUN1K6 ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) .FUNCT-1K1 r"
      using A2 A1 sin_cos6_th_66 funct_1_th_13 sorry
    also have "... = r"
      using A2 funct_1_th_18 sorry
    finally show "arcsinSIN-COS6K2 (sinSIN-COSK18 r) =HIDDENR1 r"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_70:
"arcsinSIN-COS6K2 (-XCMPLX-0K4 \<one>\<^sub>M) =HIDDENR1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
  using sin_cos6_th_7 sin_cos6_th_69 sorry

mtheorem sin_cos6_th_71:
"arcsinSIN-COS6K2 (0NUMBERSK6) =XBOOLE-0R4 0NUMBERSK6"
  using sin_cos6_th_69 sin_cos_th_31 sorry

mtheorem sin_cos6_th_72:
"arcsinSIN-COS6K2 \<one>\<^sub>M =XBOOLE-0R4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
  using sin_cos6_th_69 sin_cos_th_77 sorry

mtheorem sin_cos6_th_73:
" for r be RealXREAL-0M1 holds (-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M) & arcsinSIN-COS6K2 r =HIDDENR1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M implies r =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
  using sin_cos6_th_7 sin_cos6_th_68 sorry

mtheorem sin_cos6_th_74:
" for r be RealXREAL-0M1 holds (-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M) & arcsinSIN-COS6K2 r =XBOOLE-0R4 0NUMBERSK6 implies r =HIDDENR1 0NUMBERSK6"
  using sin_cos6_th_68 sin_cos_th_31 sorry

mtheorem sin_cos6_th_75:
" for r be RealXREAL-0M1 holds (-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M) & arcsinSIN-COS6K2 r =XBOOLE-0R4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M implies r =HIDDENR1 \<one>\<^sub>M"
  using sin_cos6_th_68 sin_cos_th_77 sorry

mtheorem sin_cos6_th_76:
" for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M implies -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <=XXREAL-0R1 arcsinSIN-COS6K2 r & arcsinSIN-COS6K2 r <=XXREAL-0R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
proof-
  have " for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M implies -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <=XXREAL-0R1 arcsinSIN-COS6K2 r & arcsinSIN-COS6K2 r <=XXREAL-0R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
  proof(rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M"
    then have "r inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
      using xxreal_1_th_1 sorry
    then have "(arcsinSIN-COS6K1).FUNCT-1K1 r inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1)"
      using sin_cos6_th_63 funct_1_def_3 sorry
    thus "-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <=XXREAL-0R1 arcsinSIN-COS6K2 r & arcsinSIN-COS6K2 r <=XXREAL-0R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos6_th_62 xxreal_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_77:
" for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 r & r <XXREAL-0R3 \<one>\<^sub>M implies -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 arcsinSIN-COS6K2 r & arcsinSIN-COS6K2 r <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
proof-
  have " for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 r & r <XXREAL-0R3 \<one>\<^sub>M implies  not -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 arcsinSIN-COS6K2 r &  not arcsinSIN-COS6K2 r <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
  proof(rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 r & r <XXREAL-0R3 \<one>\<^sub>M"
    then have "-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <=XXREAL-0R1 arcsinSIN-COS6K2 r & arcsinSIN-COS6K2 r <=XXREAL-0R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos6_th_76 sorry
    then have "(-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 arcsinSIN-COS6K2 r & arcsinSIN-COS6K2 r <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M =HIDDENR1 arcsinSIN-COS6K2 r) or arcsinSIN-COS6K2 r =XBOOLE-0R4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using xxreal_0_th_1 sorry
    thus " not -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 arcsinSIN-COS6K2 r &  not arcsinSIN-COS6K2 r <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using A1 sin_cos6_th_7 sin_cos6_th_68 sin_cos_th_77 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_78:
" for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M implies arcsinSIN-COS6K2 r =HIDDENR1 -XCMPLX-0K4 arcsinSIN-COS6K2 (-XCMPLX-0K4 r)"
proof-
  have " for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M implies arcsinSIN-COS6K2 r =HIDDENR1 -XCMPLX-0K4 arcsinSIN-COS6K2 (-XCMPLX-0K4 r)"
  proof(rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M"
    then have A1: "-XCMPLX-0K4 (-XCMPLX-0K4 \<one>\<^sub>M) >=XXREAL-0R2 -XCMPLX-0K4 r & -XCMPLX-0K4 r >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M"
      using xreal_1_th_24 sorry
    then have "arcsinSIN-COS6K2 (-XCMPLX-0K4 r) <=XXREAL-0R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos6_th_76 sorry
    then have A2: "-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <=XXREAL-0R1 -XCMPLX-0K4 arcsinSIN-COS6K2 (-XCMPLX-0K4 r)"
      using xreal_1_th_24 sorry
    have "-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <=XXREAL-0R1 arcsinSIN-COS6K2 (-XCMPLX-0K4 r)"
      using A1 sin_cos6_th_76 sorry
    then have A3: "-XCMPLX-0K4 arcsinSIN-COS6K2 (-XCMPLX-0K4 r) <=XXREAL-0R1 -XCMPLX-0K4 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)"
      using xreal_1_th_24 sorry
    have "r =HIDDENR1 0NUMBERSK6 -XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 (-XCMPLX-0K4 r)"
       sorry
    also have "... = (sinSIN-COSK18 (0NUMBERSK6))*XCMPLX-0K3 (cosSIN-COSK20 (arcsinSIN-COS6K2 (-XCMPLX-0K4 r))) -XCMPLX-0K6 (cosSIN-COSK20 (0NUMBERSK6))*XCMPLX-0K3 (sinSIN-COSK18 (arcsinSIN-COS6K2 (-XCMPLX-0K4 r)))"
      using A1 sin_cos6_th_68 sin_cos_th_31 sorry
    also have "... = sinSIN-COSK18 (0NUMBERSK6 -XCMPLX-0K6 arcsinSIN-COS6K2 (-XCMPLX-0K4 r))"
      using complex2_th_3 sorry
    finally have "r =HIDDENR1 sinSIN-COSK18 (0NUMBERSK6 -XCMPLX-0K6 arcsinSIN-COS6K2 (-XCMPLX-0K4 r))"
       sorry
    thus "arcsinSIN-COS6K2 r =HIDDENR1 -XCMPLX-0K4 arcsinSIN-COS6K2 (-XCMPLX-0K4 r)"
      using A2 A3 sin_cos6_th_69 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_79:
" for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 s & r ^2SQUARE-1K1 +XCMPLX-0K2 s ^2SQUARE-1K1 =XBOOLE-0R4 \<one>\<^sub>M implies cosSIN-COSK20 (arcsinSIN-COS6K2 r) =HIDDENR1 s"
proof-
  have " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 s & r ^2SQUARE-1K1 +XCMPLX-0K2 s ^2SQUARE-1K1 =XBOOLE-0R4 \<one>\<^sub>M implies cosSIN-COSK20 (arcsinSIN-COS6K2 r) =HIDDENR1 s"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    let ?x = "arcsinSIN-COS6K2 r"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 s"
      and A2: "r ^2SQUARE-1K1 +XCMPLX-0K2 s ^2SQUARE-1K1 =XBOOLE-0R4 \<one>\<^sub>M"
    have A3: "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M"
      using A2 sin_cos6_lm_5 sorry
    then have "-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <=XXREAL-0R1 ?x & ?x <=XXREAL-0R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos6_th_76 sorry
    then have A4: "?x inTARSKIR2 [.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]"
      using xxreal_1_th_1 sorry
    have "((sinSIN-COSK17).FUNCT-1K1 ?x)^2SQUARE-1K1 +XCMPLX-0K2 ((cosSIN-COSK19).FUNCT-1K1 ?x)^2SQUARE-1K1 =XBOOLE-0R4 \<one>\<^sub>M"
      using sin_cos_th_28 sorry
    then have "((cosSIN-COSK19).FUNCT-1K1 ?x)^2SQUARE-1K1 =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 ((sinSIN-COSK17).FUNCT-1K1 ?x)^2SQUARE-1K1"
       sorry
    also have "... = \<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK18 ?x)^2SQUARE-1K1"
      using sin_cos_def_17 sorry
    also have "... = \<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1"
      using A3 sin_cos6_th_68 sorry
    finally have "((cosSIN-COSK19).FUNCT-1K1 ?x)^2SQUARE-1K1 =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1"
       sorry
    then have A5: "(cosSIN-COSK19).FUNCT-1K1 ?x =HIDDENR1 s or (cosSIN-COSK19).FUNCT-1K1 ?x =HIDDENR1 -XCMPLX-0K4 s"
      using A2 square_1_th_40 sorry
    have "-XCMPLX-0K4 (-XCMPLX-0K4 (-XCMPLX-0K4 s)) <XXREAL-0R3 0NUMBERSK6 or s =HIDDENR1 0NUMBERSK6"
      using A1 sorry
    thus "cosSIN-COSK20 (arcsinSIN-COS6K2 r) =HIDDENR1 s"
      using A5 A4 comptrig_th_12 sin_cos_def_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_80:
" for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds s <=XXREAL-0R1 0NUMBERSK6 & r ^2SQUARE-1K1 +XCMPLX-0K2 s ^2SQUARE-1K1 =XBOOLE-0R4 \<one>\<^sub>M implies cosSIN-COSK20 (arcsinSIN-COS6K2 r) =HIDDENR1 -XCMPLX-0K4 s"
proof-
  have " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds s <=XXREAL-0R1 0NUMBERSK6 & r ^2SQUARE-1K1 +XCMPLX-0K2 s ^2SQUARE-1K1 =XBOOLE-0R4 \<one>\<^sub>M implies cosSIN-COSK20 (arcsinSIN-COS6K2 r) =HIDDENR1 -XCMPLX-0K4 s"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    let ?x = "arcsinSIN-COS6K2 r"
    assume A1: "s <=XXREAL-0R1 0NUMBERSK6"
      and A2: "r ^2SQUARE-1K1 +XCMPLX-0K2 s ^2SQUARE-1K1 =XBOOLE-0R4 \<one>\<^sub>M"
    have A3: "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M"
      using A2 sin_cos6_lm_5 sorry
    then have "-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <=XXREAL-0R1 ?x & ?x <=XXREAL-0R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos6_th_76 sorry
    then have A4: "?x inTARSKIR2 [.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]"
      using xxreal_1_th_1 sorry
    have "((sinSIN-COSK17).FUNCT-1K1 ?x)^2SQUARE-1K1 +XCMPLX-0K2 ((cosSIN-COSK19).FUNCT-1K1 ?x)^2SQUARE-1K1 =XBOOLE-0R4 \<one>\<^sub>M"
      using sin_cos_th_28 sorry
    then have "((cosSIN-COSK19).FUNCT-1K1 ?x)^2SQUARE-1K1 =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 ((sinSIN-COSK17).FUNCT-1K1 ?x)^2SQUARE-1K1"
       sorry
    also have "... = \<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK18 ?x)^2SQUARE-1K1"
      using sin_cos_def_17 sorry
    also have "... = \<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1"
      using A3 sin_cos6_th_68 sorry
    finally have "((cosSIN-COSK19).FUNCT-1K1 ?x)^2SQUARE-1K1 =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1"
       sorry
    then have A5: "(cosSIN-COSK19).FUNCT-1K1 ?x =HIDDENR1 s or (cosSIN-COSK19).FUNCT-1K1 ?x =HIDDENR1 -XCMPLX-0K4 s"
      using A2 square_1_th_40 sorry
    have "0NUMBERSK6 >XXREAL-0R4 s or s =HIDDENR1 0NUMBERSK6"
      using A1 sorry
    thus "cosSIN-COSK20 (arcsinSIN-COS6K2 r) =HIDDENR1 -XCMPLX-0K4 s"
      using A5 A4 comptrig_th_12 sin_cos_def_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_81:
" for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M implies cosSIN-COSK20 (arcsinSIN-COS6K2 r) =HIDDENR1 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1)"
proof-
  have " for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M implies cosSIN-COSK20 (arcsinSIN-COS6K2 r) =HIDDENR1 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1)"
  proof(rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    let ?s = "sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1)"
    assume "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M"
    then have "r ^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 \<one>\<^sub>M ^2SQUARE-1K1"
      using square_1_th_49 sorry
    then have "0NUMBERSK6 <=XXREAL-0R1 \<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1"
      using xreal_1_th_19 sorry
    then have "0NUMBERSK6 <=XXREAL-0R1 ?s & r ^2SQUARE-1K1 +XCMPLX-0K2 ?s ^2SQUARE-1K1 =XBOOLE-0R4 r ^2SQUARE-1K1 +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1)"
      using square_1_def_2 sorry
    thus "cosSIN-COSK20 (arcsinSIN-COS6K2 r) =HIDDENR1 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1)"
      using sin_cos6_th_79 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_82:
"(arcsinSIN-COS6K1) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]) be increasingRFUNCT-2V1"
proof-
  let ?f = "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])"
  have "?f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .] & (?f  |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])) be increasingRFUNCT-2V1"
    using sin_cos6_th_45 comptrig_th_23 fcont_3_th_9 relat_1_th_129 sorry
  thus "(arcsinSIN-COS6K1) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]) be increasingRFUNCT-2V1"
    using relat_1_th_72 sorry
qed

mtheorem sin_cos6_th_83:
" for r be RealXREAL-0M1 holds arcsinSIN-COS6K1 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ & (-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 r & r <XXREAL-0R3 \<one>\<^sub>M implies diffFDIFF-1K1(arcsinSIN-COS6K1,r) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1))"
proof-
  have " for r be RealXREAL-0M1 holds arcsinSIN-COS6K1 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ & (-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 r & r <XXREAL-0R3 \<one>\<^sub>M implies diffFDIFF-1K1(arcsinSIN-COS6K1,r) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1))"
  proof(rule ballI,rule conjMI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    let ?g = "(arcsinSIN-COS6K1) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[)"
    let ?h = "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])"
    let ?f = "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[)"
    have A1: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f =HIDDENR1 (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[)/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> REALNUMBERSK2"
      using relat_1_th_61 sin_cos_th_24 sorry
    also have "... = ].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
      using xboole_1_th_28 sorry
    finally have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f =HIDDENR1 ].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
       sorry
    let ?x = "(arcsinSIN-COS6K1).FUNCT-1K1 r"
    let ?s = "sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1)"
    have A2: "].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1)"
      using sin_cos6_th_63 xxreal_1_th_25 sorry
    have A3: "sinSIN-COSK17 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
      using fdiff_1_th_26 sin_cos_th_68 sorry
    then have A4: "?f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
      using fdiff_2_th_16 sorry
    have A5: " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1((sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[),x0)"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be RealXREAL-0M1"
      assume A6: "x0 inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
      have "diffFDIFF-1K1(?f,x0) =HIDDENR1 (?f `|FDIFF-1K2 (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[)).FUNCT-1K1 x0"
        using A4 A6 fdiff_1_def_7 sorry
      also have "... = ((sinSIN-COSK17)`|FDIFF-1K2 (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[)).FUNCT-1K1 x0"
        using A3 fdiff_2_th_16 sorry
      also have "... = diffFDIFF-1K1(sinSIN-COSK17,x0)"
        using A3 A6 fdiff_1_def_7 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x0"
        using sin_cos_th_68 sorry
      finally have "diffFDIFF-1K1(?f,x0) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x0"
         sorry
      thus "0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1((sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[),x0)"
        using A6 comptrig_th_11 sorry
    qed "sorry"
    have A7: "?f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> =HIDDENR1 (?h  |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>"
      using relat_1_th_74 xxreal_1_th_25 sorry
    also have "... = ?h \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?h .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[))"
      using rfunct_2_th_17 sorry
    also have "... = ?g"
      using sin_cos6_th_46 relat_1_th_129 xxreal_1_th_25 sorry
    finally have "?f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> =HIDDENR1 ?g"
       sorry
    then have A8: "?f  |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?f & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =XBOOLE-0R4 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
      using sin_cos6_th_63 relat_1_th_62 relat_1_th_72 xxreal_1_th_25 sorry
    then have A9: "?g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
      using A7 A4 A1 A5 fdiff_2_th_48 sorry
    then have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ implies ?g is-differentiable-inFDIFF-1R1 x"
      using fdiff_1_th_9 sorry
    thus A10: "arcsinSIN-COS6K1 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
      using A2 fdiff_1_def_6 sorry
    assume A11: "-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 r & r <XXREAL-0R3 \<one>\<^sub>M"
    then have A12: "r inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
      using xxreal_1_th_4 sorry
    then have A13: "?g .FUNCT-1K1 r =XBOOLE-0R4 ?x"
      using funct_1_th_49 sorry
    have "?x =XBOOLE-0R4 arcsinSIN-COS6K2 r"
       sorry
    then have "-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 ?x & ?x <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using A11 sin_cos6_th_77 sorry
    then have A14: "?x inTARSKIR2 ].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
      using xxreal_1_th_4 sorry
    then have A15: "diffFDIFF-1K1(?f,?x) =HIDDENR1 (?f `|FDIFF-1K2 (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[)).FUNCT-1K1 ?x"
      using A4 fdiff_1_def_7 sorry
    also have "... = ((sinSIN-COSK17)`|FDIFF-1K2 (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[)).FUNCT-1K1 ?x"
      using A3 fdiff_2_th_16 sorry
    also have "... = diffFDIFF-1K1(sinSIN-COSK17,?x)"
      using A3 A14 fdiff_1_def_7 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 ?x"
      using sin_cos_th_68 sorry
    also have "... = cosSIN-COSK20 (arcsinSIN-COS6K2 r)"
      using sin_cos_def_19 sorry
    also have "... = ?s"
      using A11 sin_cos6_th_81 sorry
    finally have "diffFDIFF-1K1(?f,?x) =HIDDENR1 ?s"
       sorry
    have "diffFDIFF-1K1(arcsinSIN-COS6K1,r) =HIDDENR1 ((arcsinSIN-COS6K1)`|FDIFF-1K2 (].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[)).FUNCT-1K1 r"
      using A10 A12 fdiff_1_def_7 sorry
    also have "... = ((arcsinSIN-COS6K1) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[) `|FDIFF-1K2 (].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[)).FUNCT-1K1 r"
      using A10 fdiff_2_th_16 sorry
    also have "... = diffFDIFF-1K1((arcsinSIN-COS6K1) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[),r)"
      using A9 A12 fdiff_1_def_7 sorry
    also have "... = \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1)"
      using A7 A8 A4 A1 A5 A12 A13 A15 fdiff_2_th_48 sorry
    finally show "diffFDIFF-1K1(arcsinSIN-COS6K1,r) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_84:
"(arcsinSIN-COS6K1) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]) be continuousFCONT-1V1"
proof-
  let ?f = "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])"
  have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]"
    using relat_1_th_62 sin_cos_th_24 sorry
  then have "?f  |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?f & (?f  |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])) be continuousFCONT-1V1"
    using comptrig_th_23 fcont_1_th_47 relat_1_th_73 sorry
  thus "(arcsinSIN-COS6K1) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]) be continuousFCONT-1V1"
    using comptrig_th_30 relat_1_th_115 sorry
qed

(*begin*)
mdef sin_cos6_def_3 ("arccosSIN-COS6K3" 164 ) where
"func arccosSIN-COS6K3 \<rightarrow> PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) equals
  ((cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>"
proof-
  (*coherence*)
    show "((cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
       sorry
qed "sorry"

mdef sin_cos6_def_4 ("arccosSIN-COS6K4  _ " [164]164 ) where
  mlet "r be objectHIDDENM1"
"func arccosSIN-COS6K4 r \<rightarrow> numberORDINAL1M2 equals
  (arccosSIN-COS6K3).FUNCT-1K1 r"
proof-
  (*coherence*)
    show "(arccosSIN-COS6K3).FUNCT-1K1 r be numberORDINAL1M2"
       sorry
qed "sorry"

mtheorem sin_cos6_cl_30:
  mlet "r be objectHIDDENM1"
"cluster arccosSIN-COS6K4 r as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "arccosSIN-COS6K4 r be realXREAL-0V1"
     sorry
qed "sorry"

mlemma sin_cos6_lm_16:
"(arccosSIN-COS6K3)\<inverse>FUNCT-1K4 =FUNCT-1R1 (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])"
  using funct_1_th_43 sorry

mtheorem sin_cos6_th_85:
"rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) =XBOOLE-0R4 [.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]"
proof-
  have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])) =XBOOLE-0R4 [.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]"
    using relat_1_th_62 sin_cos_th_24 sorry
  thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) =XBOOLE-0R4 [.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]"
    using funct_1_th_33 sorry
qed

mtheorem sin_cos6_cl_31:
"cluster arccosSIN-COS6K3 as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "arccosSIN-COS6K3 be one-to-oneFUNCT-1V2"
     sorry
qed "sorry"

mtheorem sin_cos6_th_86:
"domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
  using comptrig_th_32 funct_1_th_33 sorry

mtheorem sin_cos6_th_87:
"(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]) *FUNCT-1K3 (arccosSIN-COS6K3) =FUNCT-1R1 idPARTFUN1K6 ([.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .])"
  using comptrig_th_32 funct_1_th_39 sorry

mtheorem sin_cos6_th_88:
"(arccosSIN-COS6K3)*RELSET-1K4\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]) =FUNCT-1R1 idPARTFUN1K6 ([.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .])"
  using comptrig_th_32 funct_1_th_39 sorry

mtheorem sin_cos6_th_89:
"(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]) *RELSET-1K4\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) =FUNCT-1R1 idPARTFUN1K6 ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])"
  using sin_cos6_lm_16 sin_cos6_th_85 funct_1_th_39 sorry

mtheorem sin_cos6_th_90:
"(arccosSIN-COS6K3)*FUNCT-1K3 (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]) =FUNCT-1R1 idPARTFUN1K6 ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])"
  using sin_cos6_lm_16 sin_cos6_th_85 funct_1_th_39 sorry

mtheorem sin_cos6_th_91:
" for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M implies cosSIN-COSK20 (arccosSIN-COS6K4 r) =HIDDENR1 r"
proof-
  have " for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M implies cosSIN-COSK20 (arccosSIN-COS6K4 r) =HIDDENR1 r"
  proof(rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M"
    then have A1: "r inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
      using xxreal_1_th_1 sorry
    then have A2: "(arccosSIN-COS6K3).FUNCT-1K1 r inTARSKIR2 [.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]"
      using sin_cos6_th_85 sin_cos6_th_86 funct_1_def_3 sorry
    have "cosSIN-COSK20 (arccosSIN-COS6K4 r) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 ((arccosSIN-COS6K3).FUNCT-1K1 r)"
      using sin_cos_def_19 sorry
    also have "... = ((cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])).FUNCT-1K1 ((arccosSIN-COS6K3).FUNCT-1K1 r)"
      using A2 funct_1_th_49 sorry
    also have "... = idPARTFUN1K6 ([.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]) .FUNCT-1K1 r"
      using A1 sin_cos6_th_86 sin_cos6_th_87 funct_1_th_13 sorry
    also have "... = r"
      using A1 funct_1_th_18 sorry
    finally show "cosSIN-COSK20 (arccosSIN-COS6K4 r) =HIDDENR1 r"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_92:
" for r be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 r & r <=XXREAL-0R1 PISIN-COSK29 implies arccosSIN-COS6K4 (cosSIN-COSK20 r) =HIDDENR1 r"
proof-
  have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 r & r <=XXREAL-0R1 PISIN-COSK29 implies arccosSIN-COS6K4 (cosSIN-COSK20 r) =HIDDENR1 r"
  proof(rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    have A1: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])) =XBOOLE-0R4 [.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]"
      using relat_1_th_62 sin_cos_th_24 sorry
    assume "0NUMBERSK6 <=XXREAL-0R1 r & r <=XXREAL-0R1 PISIN-COSK29"
    then have A2: "r inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]"
      using xxreal_1_th_1 sorry
    have "arccosSIN-COS6K4 (cosSIN-COSK20 r) =HIDDENR1 (arccosSIN-COS6K3).FUNCT-1K1 ((cosSIN-COSK19).FUNCT-1K1 r)"
      using sin_cos_def_19 sorry
    also have "... = (arccosSIN-COS6K3).FUNCT-1K1 (((cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])).FUNCT-1K1 r)"
      using A2 funct_1_th_49 sorry
    also have "... = idPARTFUN1K6 ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]) .FUNCT-1K1 r"
      using A2 A1 sin_cos6_th_89 funct_1_th_13 sorry
    also have "... = r"
      using A2 funct_1_th_18 sorry
    finally show "arccosSIN-COS6K4 (cosSIN-COSK20 r) =HIDDENR1 r"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_93:
"arccosSIN-COS6K4 (-XCMPLX-0K4 \<one>\<^sub>M) =HIDDENR1 PISIN-COSK29"
  using sin_cos6_th_92 sin_cos_th_77 sorry

mtheorem sin_cos6_th_94:
"arccosSIN-COS6K4 (0NUMBERSK6) =XBOOLE-0R4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
  using sin_cos6_lm_6 sin_cos6_th_92 sin_cos_th_77 sorry

mtheorem sin_cos6_th_95:
"arccosSIN-COS6K4 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
  using sin_cos6_th_92 sin_cos_th_31 sorry

mtheorem sin_cos6_th_96:
" for r be RealXREAL-0M1 holds (-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M) & arccosSIN-COS6K4 r =XBOOLE-0R4 0NUMBERSK6 implies r =HIDDENR1 \<one>\<^sub>M"
  using sin_cos6_th_91 sin_cos_th_31 sorry

mtheorem sin_cos6_th_97:
" for r be RealXREAL-0M1 holds (-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M) & arccosSIN-COS6K4 r =XBOOLE-0R4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M implies r =HIDDENR1 0NUMBERSK6"
  using sin_cos6_th_91 sin_cos_th_77 sorry

mtheorem sin_cos6_th_98:
" for r be RealXREAL-0M1 holds (-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M) & arccosSIN-COS6K4 r =HIDDENR1 PISIN-COSK29 implies r =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
  using sin_cos6_th_91 sin_cos_th_77 sorry

mtheorem sin_cos6_th_99:
" for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M implies 0NUMBERSK6 <=XXREAL-0R1 arccosSIN-COS6K4 r & arccosSIN-COS6K4 r <=XXREAL-0R1 PISIN-COSK29"
proof-
  have " for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M implies 0NUMBERSK6 <=XXREAL-0R1 arccosSIN-COS6K4 r & arccosSIN-COS6K4 r <=XXREAL-0R1 PISIN-COSK29"
  proof(rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M"
    then have "r inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
      using xxreal_1_th_1 sorry
    then have "(arccosSIN-COS6K3).FUNCT-1K1 r inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3)"
      using sin_cos6_th_86 funct_1_def_3 sorry
    thus "0NUMBERSK6 <=XXREAL-0R1 arccosSIN-COS6K4 r & arccosSIN-COS6K4 r <=XXREAL-0R1 PISIN-COSK29"
      using sin_cos6_th_85 xxreal_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_100:
" for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 r & r <XXREAL-0R3 \<one>\<^sub>M implies 0NUMBERSK6 <XXREAL-0R3 arccosSIN-COS6K4 r & arccosSIN-COS6K4 r <XXREAL-0R3 PISIN-COSK29"
proof-
  have " for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 r & r <XXREAL-0R3 \<one>\<^sub>M implies  not 0NUMBERSK6 <XXREAL-0R3 arccosSIN-COS6K4 r &  not arccosSIN-COS6K4 r <XXREAL-0R3 PISIN-COSK29"
  proof(rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 r & r <XXREAL-0R3 \<one>\<^sub>M"
    then have "arccosSIN-COS6K4 r <=XXREAL-0R1 PISIN-COSK29"
      using sin_cos6_th_99 sorry
    then have "(0NUMBERSK6 <XXREAL-0R3 arccosSIN-COS6K4 r & arccosSIN-COS6K4 r <XXREAL-0R3 PISIN-COSK29 or 0NUMBERSK6 =XBOOLE-0R4 arccosSIN-COS6K4 r) or arccosSIN-COS6K4 r =HIDDENR1 PISIN-COSK29"
      using A1 sin_cos6_th_99 xxreal_0_th_1 sorry
    thus " not 0NUMBERSK6 <XXREAL-0R3 arccosSIN-COS6K4 r &  not arccosSIN-COS6K4 r <XXREAL-0R3 PISIN-COSK29"
      using A1 sin_cos6_th_91 sin_cos_th_31 sin_cos_th_77 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_101:
" for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M implies arccosSIN-COS6K4 r =XBOOLE-0R4 PISIN-COSK29 -XCMPLX-0K6 arccosSIN-COS6K4 (-XCMPLX-0K4 r)"
proof-
  have " for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M implies arccosSIN-COS6K4 r =XBOOLE-0R4 PISIN-COSK29 -XCMPLX-0K6 arccosSIN-COS6K4 (-XCMPLX-0K4 r)"
  proof(rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M"
    then have A1: "-XCMPLX-0K4 (-XCMPLX-0K4 \<one>\<^sub>M) >=XXREAL-0R2 -XCMPLX-0K4 r & -XCMPLX-0K4 r >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M"
      using xreal_1_th_24 sorry
    then have "0NUMBERSK6 +XCMPLX-0K2 arccosSIN-COS6K4 (-XCMPLX-0K4 r) <=XXREAL-0R1 PISIN-COSK29"
      using sin_cos6_th_99 sorry
    then have A2: "0NUMBERSK6 <=XXREAL-0R1 PISIN-COSK29 -XCMPLX-0K6 arccosSIN-COS6K4 (-XCMPLX-0K4 r)"
      using xreal_1_th_19 sorry
    have "0NUMBERSK6 <=XXREAL-0R1 arccosSIN-COS6K4 (-XCMPLX-0K4 r)"
      using A1 sin_cos6_th_99 sorry
    then have "PISIN-COSK29 +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 PISIN-COSK29 +XCMPLX-0K2 arccosSIN-COS6K4 (-XCMPLX-0K4 r)"
      using xreal_1_th_6 sorry
    then have A3: "PISIN-COSK29 -XCMPLX-0K6 arccosSIN-COS6K4 (-XCMPLX-0K4 r) <=XXREAL-0R1 PISIN-COSK29"
      using xreal_1_th_20 sorry
    have "r =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (-XCMPLX-0K4 r)"
       sorry
    also have "... = (cosSIN-COSK20 (PISIN-COSK29))*XCMPLX-0K3 (cosSIN-COSK20 (arccosSIN-COS6K4 (-XCMPLX-0K4 r))) +XCMPLX-0K2 (sinSIN-COSK18 (PISIN-COSK29))*XCMPLX-0K3 (sinSIN-COSK18 (arccosSIN-COS6K4 (-XCMPLX-0K4 r)))"
      using A1 sin_cos6_th_91 sin_cos_th_77 sorry
    also have "... = cosSIN-COSK20 (PISIN-COSK29 -XCMPLX-0K6 arccosSIN-COS6K4 (-XCMPLX-0K4 r))"
      using complex2_th_3 sorry
    finally have "r =HIDDENR1 cosSIN-COSK20 (PISIN-COSK29 -XCMPLX-0K6 arccosSIN-COS6K4 (-XCMPLX-0K4 r))"
       sorry
    thus "arccosSIN-COS6K4 r =XBOOLE-0R4 PISIN-COSK29 -XCMPLX-0K6 arccosSIN-COS6K4 (-XCMPLX-0K4 r)"
      using A2 A3 sin_cos6_th_92 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_102:
" for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 s & r ^2SQUARE-1K1 +XCMPLX-0K2 s ^2SQUARE-1K1 =XBOOLE-0R4 \<one>\<^sub>M implies sinSIN-COSK18 (arccosSIN-COS6K4 r) =HIDDENR1 s"
proof-
  have " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 s & r ^2SQUARE-1K1 +XCMPLX-0K2 s ^2SQUARE-1K1 =XBOOLE-0R4 \<one>\<^sub>M implies sinSIN-COSK18 (arccosSIN-COS6K4 r) =HIDDENR1 s"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    let ?x = "arccosSIN-COS6K4 r"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 s"
      and A2: "r ^2SQUARE-1K1 +XCMPLX-0K2 s ^2SQUARE-1K1 =XBOOLE-0R4 \<one>\<^sub>M"
    have A3: "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M"
      using A2 sin_cos6_lm_5 sorry
    then have "0NUMBERSK6 <=XXREAL-0R1 ?x & ?x <=XXREAL-0R1 PISIN-COSK29"
      using sin_cos6_th_99 sorry
    then have A4: "?x inTARSKIR2 [.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]"
      using xxreal_1_th_1 sorry
    have "((sinSIN-COSK17).FUNCT-1K1 ?x)^2SQUARE-1K1 +XCMPLX-0K2 ((cosSIN-COSK19).FUNCT-1K1 ?x)^2SQUARE-1K1 =XBOOLE-0R4 \<one>\<^sub>M"
      using sin_cos_th_28 sorry
    then have "((sinSIN-COSK17).FUNCT-1K1 ?x)^2SQUARE-1K1 =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 ((cosSIN-COSK19).FUNCT-1K1 ?x)^2SQUARE-1K1"
       sorry
    also have "... = \<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK20 ?x)^2SQUARE-1K1"
      using sin_cos_def_19 sorry
    also have "... = \<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1"
      using A3 sin_cos6_th_91 sorry
    finally have "((sinSIN-COSK17).FUNCT-1K1 ?x)^2SQUARE-1K1 =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1"
       sorry
    then have A5: "(sinSIN-COSK17).FUNCT-1K1 ?x =HIDDENR1 s or (sinSIN-COSK17).FUNCT-1K1 ?x =HIDDENR1 -XCMPLX-0K4 s"
      using A2 square_1_th_40 sorry
    have "-XCMPLX-0K4 (-XCMPLX-0K4 (-XCMPLX-0K4 s)) <XXREAL-0R3 0NUMBERSK6 or s =HIDDENR1 0NUMBERSK6"
      using A1 sorry
    thus "sinSIN-COSK18 (arccosSIN-COS6K4 r) =HIDDENR1 s"
      using A5 A4 comptrig_th_8 sin_cos_def_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_103:
" for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds s <=XXREAL-0R1 0NUMBERSK6 & r ^2SQUARE-1K1 +XCMPLX-0K2 s ^2SQUARE-1K1 =XBOOLE-0R4 \<one>\<^sub>M implies sinSIN-COSK18 (arccosSIN-COS6K4 r) =HIDDENR1 -XCMPLX-0K4 s"
proof-
  have " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds s <=XXREAL-0R1 0NUMBERSK6 & r ^2SQUARE-1K1 +XCMPLX-0K2 s ^2SQUARE-1K1 =XBOOLE-0R4 \<one>\<^sub>M implies sinSIN-COSK18 (arccosSIN-COS6K4 r) =HIDDENR1 -XCMPLX-0K4 s"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    let ?x = "arccosSIN-COS6K4 r"
    assume A1: "s <=XXREAL-0R1 0NUMBERSK6"
      and A2: "r ^2SQUARE-1K1 +XCMPLX-0K2 s ^2SQUARE-1K1 =XBOOLE-0R4 \<one>\<^sub>M"
    have A3: "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M"
      using A2 sin_cos6_lm_5 sorry
    then have "0NUMBERSK6 <=XXREAL-0R1 ?x & ?x <=XXREAL-0R1 PISIN-COSK29"
      using sin_cos6_th_99 sorry
    then have A4: "?x inTARSKIR2 [.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]"
      using xxreal_1_th_1 sorry
    have "((sinSIN-COSK17).FUNCT-1K1 ?x)^2SQUARE-1K1 +XCMPLX-0K2 ((cosSIN-COSK19).FUNCT-1K1 ?x)^2SQUARE-1K1 =XBOOLE-0R4 \<one>\<^sub>M"
      using sin_cos_th_28 sorry
    then have "((sinSIN-COSK17).FUNCT-1K1 ?x)^2SQUARE-1K1 =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 ((cosSIN-COSK19).FUNCT-1K1 ?x)^2SQUARE-1K1"
       sorry
    also have "... = \<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK20 ?x)^2SQUARE-1K1"
      using sin_cos_def_19 sorry
    also have "... = \<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1"
      using A3 sin_cos6_th_91 sorry
    finally have "((sinSIN-COSK17).FUNCT-1K1 ?x)^2SQUARE-1K1 =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1"
       sorry
    then have A5: "(sinSIN-COSK17).FUNCT-1K1 ?x =HIDDENR1 s or (sinSIN-COSK17).FUNCT-1K1 ?x =HIDDENR1 -XCMPLX-0K4 s"
      using A2 square_1_th_40 sorry
    have "0NUMBERSK6 >XXREAL-0R4 s or s =HIDDENR1 0NUMBERSK6"
      using A1 sorry
    thus "sinSIN-COSK18 (arccosSIN-COS6K4 r) =HIDDENR1 -XCMPLX-0K4 s"
      using A5 A4 comptrig_th_8 sin_cos_def_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_104:
" for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M implies sinSIN-COSK18 (arccosSIN-COS6K4 r) =HIDDENR1 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1)"
proof-
  have " for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M implies sinSIN-COSK18 (arccosSIN-COS6K4 r) =HIDDENR1 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1)"
  proof(rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    let ?s = "sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1)"
    assume "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M"
    then have "r ^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 \<one>\<^sub>M ^2SQUARE-1K1"
      using square_1_th_49 sorry
    then have "0NUMBERSK6 <=XXREAL-0R1 \<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1"
      using xreal_1_th_19 sorry
    then have "0NUMBERSK6 <=XXREAL-0R1 ?s & r ^2SQUARE-1K1 +XCMPLX-0K2 ?s ^2SQUARE-1K1 =XBOOLE-0R4 r ^2SQUARE-1K1 +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1)"
      using square_1_def_2 sorry
    thus "sinSIN-COSK18 (arccosSIN-COS6K4 r) =HIDDENR1 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1)"
      using sin_cos6_th_102 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_105:
"(arccosSIN-COS6K3) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]) be decreasingRFUNCT-2V2"
proof-
  let ?f = "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])"
  have "?f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .] & (?f  |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])) be decreasingRFUNCT-2V2"
    using sin_cos6_th_49 comptrig_th_25 fcont_3_th_10 relat_1_th_129 sorry
  thus "(arccosSIN-COS6K3) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]) be decreasingRFUNCT-2V2"
    using relat_1_th_72 sorry
qed

mtheorem sin_cos6_th_106:
" for r be RealXREAL-0M1 holds arccosSIN-COS6K3 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ & (-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 r & r <XXREAL-0R3 \<one>\<^sub>M implies diffFDIFF-1K1(arccosSIN-COS6K3,r) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1))"
proof-
  have " for r be RealXREAL-0M1 holds arccosSIN-COS6K3 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ & (-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 r & r <XXREAL-0R3 \<one>\<^sub>M implies diffFDIFF-1K1(arccosSIN-COS6K3,r) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1))"
  proof(rule ballI,rule conjMI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    let ?g = "(arccosSIN-COS6K3) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[)"
    let ?h = "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])"
    let ?f = "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[)"
    have A1: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f =HIDDENR1 (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[)/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> REALNUMBERSK2"
      using relat_1_th_61 sin_cos_th_24 sorry
    also have "... = ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
      using xboole_1_th_28 sorry
    finally have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f =HIDDENR1 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
       sorry
    let ?x = "(arccosSIN-COS6K3).FUNCT-1K1 r"
    let ?s = "sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1)"
    have A2: "].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3)"
      using sin_cos6_th_86 xxreal_1_th_25 sorry
    have A3: "cosSIN-COSK19 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
      using fdiff_1_th_26 sin_cos_th_67 sorry
    then have A4: "?f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
      using fdiff_2_th_16 sorry
    have A5: " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[ implies 0NUMBERSK6 >XXREAL-0R4 diffFDIFF-1K1((cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[),x0)"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be RealXREAL-0M1"
      assume A6: "x0 inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
      have A7: "-XCMPLX-0K4 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x0) >XXREAL-0R4 0NUMBERSK6"
        using A6 comptrig_th_7 sorry
      have "diffFDIFF-1K1(?f,x0) =HIDDENR1 (?f `|FDIFF-1K2 (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[)).FUNCT-1K1 x0"
        using A4 A6 fdiff_1_def_7 sorry
      also have "... = ((cosSIN-COSK19)`|FDIFF-1K2 (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[)).FUNCT-1K1 x0"
        using A3 fdiff_2_th_16 sorry
      also have "... = diffFDIFF-1K1(cosSIN-COSK19,x0)"
        using A3 A6 fdiff_1_def_7 sorry
      also have "... = -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x0"
        using sin_cos_th_67 sorry
      finally have "diffFDIFF-1K1(?f,x0) =HIDDENR1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x0"
         sorry
      thus "0NUMBERSK6 >XXREAL-0R4 diffFDIFF-1K1((cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[),x0)"
        using A7 sorry
    qed "sorry"
    have A8: "?f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> =HIDDENR1 (?h  |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>"
      using relat_1_th_74 xxreal_1_th_25 sorry
    also have "... = ?h \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?h .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[))"
      using rfunct_2_th_17 sorry
    also have "... = ?g"
      using sin_cos6_th_50 relat_1_th_129 xxreal_1_th_25 sorry
    finally have "?f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> =HIDDENR1 ?g"
       sorry
    then have A9: "?f  |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?f & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =XBOOLE-0R4 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
      using sin_cos6_th_86 relat_1_th_62 relat_1_th_72 xxreal_1_th_25 sorry
    then have A10: "?g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
      using A8 A4 A1 A5 fdiff_2_th_48 sorry
    then have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ implies ?g is-differentiable-inFDIFF-1R1 x"
      using fdiff_1_th_9 sorry
    thus A11: "arccosSIN-COS6K3 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
      using A2 fdiff_1_def_6 sorry
    assume A12: "-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 r & r <XXREAL-0R3 \<one>\<^sub>M"
    then have A13: "r inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
      using xxreal_1_th_4 sorry
    then have A14: "?g .FUNCT-1K1 r =XBOOLE-0R4 ?x"
      using funct_1_th_49 sorry
    have "?x =XBOOLE-0R4 arccosSIN-COS6K4 r"
       sorry
    then have "0NUMBERSK6 <XXREAL-0R3 ?x & ?x <XXREAL-0R3 PISIN-COSK29"
      using A12 sin_cos6_th_100 sorry
    then have A15: "?x inTARSKIR2 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
      using xxreal_1_th_4 sorry
    then have A16: "diffFDIFF-1K1(?f,?x) =HIDDENR1 (?f `|FDIFF-1K2 (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[)).FUNCT-1K1 ?x"
      using A4 fdiff_1_def_7 sorry
    also have "... = ((cosSIN-COSK19)`|FDIFF-1K2 (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[)).FUNCT-1K1 ?x"
      using A3 fdiff_2_th_16 sorry
    also have "... = diffFDIFF-1K1(cosSIN-COSK19,?x)"
      using A3 A15 fdiff_1_def_7 sorry
    also have "... = -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 ?x"
      using sin_cos_th_67 sorry
    also have "... = -XCMPLX-0K4 sinSIN-COSK18 (arccosSIN-COS6K4 r)"
      using sin_cos_def_17 sorry
    also have "... = -XCMPLX-0K4 ?s"
      using A12 sin_cos6_th_104 sorry
    finally have "diffFDIFF-1K1(?f,?x) =HIDDENR1 -XCMPLX-0K4 ?s"
       sorry
    have "diffFDIFF-1K1(arccosSIN-COS6K3,r) =HIDDENR1 ((arccosSIN-COS6K3)`|FDIFF-1K2 (].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[)).FUNCT-1K1 r"
      using A11 A13 fdiff_1_def_7 sorry
    also have "... = ((arccosSIN-COS6K3) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[) `|FDIFF-1K2 (].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[)).FUNCT-1K1 r"
      using A11 fdiff_2_th_16 sorry
    also have "... = diffFDIFF-1K1((arccosSIN-COS6K3) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[),r)"
      using A10 A13 fdiff_1_def_7 sorry
    also have "... = \<one>\<^sub>M /XCMPLX-0K7 (-XCMPLX-0K4 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1))"
      using A8 A9 A4 A1 A5 A13 A14 A16 fdiff_2_th_48 sorry
    also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1)"
      using xcmplx_1_th_192 sorry
    also have "... = -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1)"
      using xcmplx_1_th_187 sorry
    finally show "diffFDIFF-1K1(arccosSIN-COS6K3,r) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_107:
"(arccosSIN-COS6K3) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]) be continuousFCONT-1V1"
proof-
  let ?f = "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])"
  have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f =XBOOLE-0R4 [.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]"
    using relat_1_th_62 sin_cos_th_24 sorry
  then have "?f  |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?f & (?f  |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])) be continuousFCONT-1V1"
    using comptrig_th_25 fcont_1_th_47 relat_1_th_73 sorry
  thus "(arccosSIN-COS6K3) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]) be continuousFCONT-1V1"
    using comptrig_th_32 relat_1_th_115 sorry
qed

mtheorem sin_cos6_th_108:
" for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M implies arcsinSIN-COS6K2 r +XCMPLX-0K2 arccosSIN-COS6K4 r =XBOOLE-0R4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
proof-
  have " for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M implies arcsinSIN-COS6K2 r +XCMPLX-0K2 arccosSIN-COS6K4 r =XBOOLE-0R4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
  proof(rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M"
    then have "(-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <=XXREAL-0R1 arccosSIN-COS6K4 r"
      using sin_cos6_th_99 sorry
    then have "-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <=XXREAL-0R1 arccosSIN-COS6K4 r -XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using xreal_1_th_19 sorry
    then have A2: "-XCMPLX-0K4 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) >=XXREAL-0R2 -XCMPLX-0K4 (arccosSIN-COS6K4 r -XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)"
      using xreal_1_th_24 sorry
    have "arccosSIN-COS6K4 r <=XXREAL-0R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using A1 sin_cos6_th_99 sorry
    then have "arccosSIN-COS6K4 r -XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <=XXREAL-0R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using xreal_1_th_20 sorry
    then have A3: "-XCMPLX-0K4 (arccosSIN-COS6K4 r -XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) >=XXREAL-0R2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using xreal_1_th_24 sorry
    have "r =HIDDENR1 (sinSIN-COSK18 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (arccosSIN-COS6K4 r)) -XCMPLX-0K6 (cosSIN-COSK20 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (arccosSIN-COS6K4 r))"
      using A1 sin_cos6_th_91 sin_cos_th_77 sorry
    also have "... = sinSIN-COSK18 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 arccosSIN-COS6K4 r)"
      using complex2_th_3 sorry
    finally have "r =HIDDENR1 sinSIN-COSK18 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 arccosSIN-COS6K4 r)"
       sorry
    then have "arcsinSIN-COS6K2 r =XBOOLE-0R4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 arccosSIN-COS6K4 r"
      using A2 A3 sin_cos6_th_69 sorry
    thus "arcsinSIN-COS6K2 r +XCMPLX-0K2 arccosSIN-COS6K4 r =XBOOLE-0R4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_109:
" for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M implies arccosSIN-COS6K4 (-XCMPLX-0K4 r) -XCMPLX-0K6 arcsinSIN-COS6K2 r =XBOOLE-0R4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
proof-
  have " for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M implies arccosSIN-COS6K4 (-XCMPLX-0K4 r) -XCMPLX-0K6 arcsinSIN-COS6K2 r =XBOOLE-0R4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
  proof(rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M"
    then have A2: "arcsinSIN-COS6K2 r +XCMPLX-0K2 arccosSIN-COS6K4 r =XBOOLE-0R4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 0NUMBERSK6"
      using sin_cos6_th_108 sorry
    have "-XCMPLX-0K4 (-XCMPLX-0K4 \<one>\<^sub>M) >=XXREAL-0R2 -XCMPLX-0K4 r & -XCMPLX-0K4 r >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M"
      using A1 xreal_1_th_24 sorry
    then have "arccosSIN-COS6K4 (-XCMPLX-0K4 r) =HIDDENR1 PISIN-COSK29 -XCMPLX-0K6 arccosSIN-COS6K4 (-XCMPLX-0K4 (-XCMPLX-0K4 r))"
      using sin_cos6_th_101 sorry
    also have "... = arcsinSIN-COS6K2 r +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using A2 sorry
    finally have "arccosSIN-COS6K4 (-XCMPLX-0K4 r) =HIDDENR1 arcsinSIN-COS6K2 r +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    thus "arccosSIN-COS6K4 (-XCMPLX-0K4 r) -XCMPLX-0K6 arcsinSIN-COS6K2 r =XBOOLE-0R4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos6_th_110:
" for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M implies arccosSIN-COS6K4 r -XCMPLX-0K6 arcsinSIN-COS6K2 (-XCMPLX-0K4 r) =XBOOLE-0R4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
proof-
  have " for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M implies arccosSIN-COS6K4 r -XCMPLX-0K6 arcsinSIN-COS6K2 (-XCMPLX-0K4 r) =XBOOLE-0R4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
  proof(rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M"
    then have A2: "arcsinSIN-COS6K2 r +XCMPLX-0K2 arccosSIN-COS6K4 r =XBOOLE-0R4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 0NUMBERSK6"
      using sin_cos6_th_108 sorry
    have "-XCMPLX-0K4 (-XCMPLX-0K4 \<one>\<^sub>M) >=XXREAL-0R2 -XCMPLX-0K4 r & -XCMPLX-0K4 r >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M"
      using A1 xreal_1_th_24 sorry
    then have "arcsinSIN-COS6K2 (-XCMPLX-0K4 r) =HIDDENR1 -XCMPLX-0K4 arcsinSIN-COS6K2 (-XCMPLX-0K4 (-XCMPLX-0K4 r))"
      using sin_cos6_th_78 sorry
    also have "... = arccosSIN-COS6K4 r -XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using A2 sorry
    finally have "arcsinSIN-COS6K2 (-XCMPLX-0K4 r) =HIDDENR1 arccosSIN-COS6K4 r -XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    thus "arccosSIN-COS6K4 r -XCMPLX-0K6 arcsinSIN-COS6K2 (-XCMPLX-0K4 r) =XBOOLE-0R4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
