theory relat_2
  imports relat_1
begin
(*begin*)
reserve X for "setHIDDENM2"
reserve a, b, c, x, y, z for "objectHIDDENM1"
reserve P, R for "RelationRELAT-1M1"
mdef relat_2_def_1 (" _ is-reflexive-inRELAT-2R1  _ " [50,50]50 ) where
  mlet "R be RelationRELAT-1M1", "X be setHIDDENM2"
"pred R is-reflexive-inRELAT-2R1 X means
   for x be objectHIDDENM1 holds x inHIDDENR3 X implies [TARSKIK4 x,x ] inHIDDENR3 R"..

mdef relat_2_def_2 (" _ is-irreflexive-inRELAT-2R2  _ " [50,50]50 ) where
  mlet "R be RelationRELAT-1M1", "X be setHIDDENM2"
"pred R is-irreflexive-inRELAT-2R2 X means
   for x be objectHIDDENM1 holds x inHIDDENR3 X implies  not [TARSKIK4 x,x ] inHIDDENR3 R"..

mdef relat_2_def_3 (" _ is-symmetric-inRELAT-2R3  _ " [50,50]50 ) where
  mlet "R be RelationRELAT-1M1", "X be setHIDDENM2"
"pred R is-symmetric-inRELAT-2R3 X means
   for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 X & y inHIDDENR3 X) & [TARSKIK4 x,y ] inHIDDENR3 R implies [TARSKIK4 y,x ] inHIDDENR3 R"..

mdef relat_2_def_4 (" _ is-antisymmetric-inRELAT-2R4  _ " [50,50]50 ) where
  mlet "R be RelationRELAT-1M1", "X be setHIDDENM2"
"pred R is-antisymmetric-inRELAT-2R4 X means
   for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ((x inHIDDENR3 X & y inHIDDENR3 X) & [TARSKIK4 x,y ] inHIDDENR3 R) & [TARSKIK4 y,x ] inHIDDENR3 R implies x =HIDDENR1 y"..

mdef relat_2_def_5 (" _ is-asymmetric-inRELAT-2R5  _ " [50,50]50 ) where
  mlet "R be RelationRELAT-1M1", "X be setHIDDENM2"
"pred R is-asymmetric-inRELAT-2R5 X means
   for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 X & y inHIDDENR3 X) & [TARSKIK4 x,y ] inHIDDENR3 R implies  not [TARSKIK4 y,x ] inHIDDENR3 R"..

mdef relat_2_def_6 (" _ is-connected-inRELAT-2R6  _ " [50,50]50 ) where
  mlet "R be RelationRELAT-1M1", "X be setHIDDENM2"
"pred R is-connected-inRELAT-2R6 X means
   for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 X & y inHIDDENR3 X) & x <>HIDDENR2 y implies [TARSKIK4 x,y ] inHIDDENR3 R or [TARSKIK4 y,x ] inHIDDENR3 R"..

mdef relat_2_def_7 (" _ is-strongly-connected-inRELAT-2R7  _ " [50,50]50 ) where
  mlet "R be RelationRELAT-1M1", "X be setHIDDENM2"
"pred R is-strongly-connected-inRELAT-2R7 X means
   for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 X & y inHIDDENR3 X implies [TARSKIK4 x,y ] inHIDDENR3 R or [TARSKIK4 y,x ] inHIDDENR3 R"..

mdef relat_2_def_8 (" _ is-transitive-inRELAT-2R8  _ " [50,50]50 ) where
  mlet "R be RelationRELAT-1M1", "X be setHIDDENM2"
"pred R is-transitive-inRELAT-2R8 X means
   for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds (((x inHIDDENR3 X & y inHIDDENR3 X) & z inHIDDENR3 X) & [TARSKIK4 x,y ] inHIDDENR3 R) & [TARSKIK4 y,z ] inHIDDENR3 R implies [TARSKIK4 x,z ] inHIDDENR3 R"..

mdef relat_2_def_9 ("reflexiveRELAT-2V1" 70 ) where
"attr reflexiveRELAT-2V1 for RelationRELAT-1M1 means
  (\<lambda>R. R is-reflexive-inRELAT-2R1 fieldRELAT-1K3 R)"..

mdef relat_2_def_10 ("irreflexiveRELAT-2V2" 70 ) where
"attr irreflexiveRELAT-2V2 for RelationRELAT-1M1 means
  (\<lambda>R. R is-irreflexive-inRELAT-2R2 fieldRELAT-1K3 R)"..

mdef relat_2_def_11 ("symmetricRELAT-2V3" 70 ) where
"attr symmetricRELAT-2V3 for RelationRELAT-1M1 means
  (\<lambda>R. R is-symmetric-inRELAT-2R3 fieldRELAT-1K3 R)"..

mdef relat_2_def_12 ("antisymmetricRELAT-2V4" 70 ) where
"attr antisymmetricRELAT-2V4 for RelationRELAT-1M1 means
  (\<lambda>R. R is-antisymmetric-inRELAT-2R4 fieldRELAT-1K3 R)"..

mdef relat_2_def_13 ("asymmetricRELAT-2V5" 70 ) where
"attr asymmetricRELAT-2V5 for RelationRELAT-1M1 means
  (\<lambda>R. R is-asymmetric-inRELAT-2R5 fieldRELAT-1K3 R)"..

mdef relat_2_def_14 ("connectedRELAT-2V6" 70 ) where
"attr connectedRELAT-2V6 for RelationRELAT-1M1 means
  (\<lambda>R. R is-connected-inRELAT-2R6 fieldRELAT-1K3 R)"..

mdef relat_2_def_15 ("strongly-connectedRELAT-2V7" 70 ) where
"attr strongly-connectedRELAT-2V7 for RelationRELAT-1M1 means
  (\<lambda>R. R is-strongly-connected-inRELAT-2R7 fieldRELAT-1K3 R)"..

mdef relat_2_def_16 ("transitiveRELAT-2V8" 70 ) where
"attr transitiveRELAT-2V8 for RelationRELAT-1M1 means
  (\<lambda>R. R is-transitive-inRELAT-2R8 fieldRELAT-1K3 R)"..

mtheorem relat_2_cl_1:
"cluster emptyXBOOLE-0V1 also-is reflexiveRELAT-2V1\<bar>irreflexiveRELAT-2V2\<bar>symmetricRELAT-2V3\<bar>antisymmetricRELAT-2V4\<bar>asymmetricRELAT-2V5\<bar>connectedRELAT-2V6\<bar>strongly-connectedRELAT-2V7\<bar>transitiveRELAT-2V8 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be emptyXBOOLE-0V1 implies it be reflexiveRELAT-2V1\<bar>irreflexiveRELAT-2V2\<bar>symmetricRELAT-2V3\<bar>antisymmetricRELAT-2V4\<bar>asymmetricRELAT-2V5\<bar>connectedRELAT-2V6\<bar>strongly-connectedRELAT-2V7\<bar>transitiveRELAT-2V8"
  proof-
    have " for R be RelationRELAT-1M1 holds R be emptyXBOOLE-0V1 implies R be reflexiveRELAT-2V1 & (R be irreflexiveRELAT-2V2 & (R be symmetricRELAT-2V3 & (R be antisymmetricRELAT-2V4 & (R be asymmetricRELAT-2V5 & (R be connectedRELAT-2V6 & (R be strongly-connectedRELAT-2V7 & R be transitiveRELAT-2V8))))))"
    proof(rule ballI,rule impI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI)
      fix R assume [ty]: "R be RelationRELAT-1M1"
      assume A1: "R be emptyXBOOLE-0V1"
      show "R be reflexiveRELAT-2V1"
      proof-
        have " for x be objectHIDDENM1 holds  not (x inHIDDENR3 fieldRELAT-1K3 R &  not [TARSKIK4 x,x ] inHIDDENR3 R)"
        proof(rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          show " not (x inHIDDENR3 fieldRELAT-1K3 R &  not [TARSKIK4 x,x ] inHIDDENR3 R)"
            using A1 relat_1_th_40 sorry
        qed "sorry"
        thus "R be reflexiveRELAT-2V1"
          using relat_2_def_1 relat_2_def_9 sorry
      qed
      show "R be irreflexiveRELAT-2V2"
      proof-
        have " for x be objectHIDDENM1 holds  not (x inHIDDENR3 fieldRELAT-1K3 R & [TARSKIK4 x,x ] inHIDDENR3 R)"
        proof(rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          show " not (x inHIDDENR3 fieldRELAT-1K3 R & [TARSKIK4 x,x ] inHIDDENR3 R)"
            using A1 sorry
        qed "sorry"
        thus "R be irreflexiveRELAT-2V2"
          using relat_2_def_2 relat_2_def_10 sorry
      qed
      show "R be symmetricRELAT-2V3"
      proof-
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not (((x inHIDDENR3 fieldRELAT-1K3 R & y inHIDDENR3 fieldRELAT-1K3 R) & [TARSKIK4 x,y ] inHIDDENR3 R) &  not [TARSKIK4 y,x ] inHIDDENR3 R)"
        proof(rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          show " for y be objectHIDDENM1 holds  not (((x inHIDDENR3 fieldRELAT-1K3 R & y inHIDDENR3 fieldRELAT-1K3 R) & [TARSKIK4 x,y ] inHIDDENR3 R) &  not [TARSKIK4 y,x ] inHIDDENR3 R)"
            using A1 sorry
        qed "sorry"
        thus "R be symmetricRELAT-2V3"
          using relat_2_def_3 relat_2_def_11 sorry
      qed
      show "R be antisymmetricRELAT-2V4"
      proof-
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ((((x inHIDDENR3 fieldRELAT-1K3 R & y inHIDDENR3 fieldRELAT-1K3 R) & [TARSKIK4 x,y ] inHIDDENR3 R) & [TARSKIK4 y,x ] inHIDDENR3 R) &  not x =HIDDENR1 y)"
        proof(rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          show " for y be objectHIDDENM1 holds  not ((((x inHIDDENR3 fieldRELAT-1K3 R & y inHIDDENR3 fieldRELAT-1K3 R) & [TARSKIK4 x,y ] inHIDDENR3 R) & [TARSKIK4 y,x ] inHIDDENR3 R) &  not x =HIDDENR1 y)"
            using A1 sorry
        qed "sorry"
        thus "R be antisymmetricRELAT-2V4"
          using relat_2_def_4 relat_2_def_12 sorry
      qed
      show "R be asymmetricRELAT-2V5"
      proof-
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not (((x inHIDDENR3 fieldRELAT-1K3 R & y inHIDDENR3 fieldRELAT-1K3 R) & [TARSKIK4 x,y ] inHIDDENR3 R) & [TARSKIK4 y,x ] inHIDDENR3 R)"
        proof(rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          show " for y be objectHIDDENM1 holds  not (((x inHIDDENR3 fieldRELAT-1K3 R & y inHIDDENR3 fieldRELAT-1K3 R) & [TARSKIK4 x,y ] inHIDDENR3 R) & [TARSKIK4 y,x ] inHIDDENR3 R)"
            using A1 sorry
        qed "sorry"
        thus "R be asymmetricRELAT-2V5"
          using relat_2_def_5 relat_2_def_13 sorry
      qed
      show "R be connectedRELAT-2V6"
      proof-
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ((((x inHIDDENR3 fieldRELAT-1K3 R & y inHIDDENR3 fieldRELAT-1K3 R) &  not x <>HIDDENR2 y) &  not [TARSKIK4 x,y ] inHIDDENR3 R) &  not [TARSKIK4 y,x ] inHIDDENR3 R)"
        proof(rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          show " for y be objectHIDDENM1 holds  not ((((x inHIDDENR3 fieldRELAT-1K3 R & y inHIDDENR3 fieldRELAT-1K3 R) &  not x <>HIDDENR2 y) &  not [TARSKIK4 x,y ] inHIDDENR3 R) &  not [TARSKIK4 y,x ] inHIDDENR3 R)"
            using A1 relat_1_th_40 sorry
        qed "sorry"
        thus "R be connectedRELAT-2V6"
          using relat_2_def_6 relat_2_def_14 sorry
      qed
      show "R be strongly-connectedRELAT-2V7"
      proof-
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not (((x inHIDDENR3 fieldRELAT-1K3 R & y inHIDDENR3 fieldRELAT-1K3 R) &  not [TARSKIK4 x,y ] inHIDDENR3 R) &  not [TARSKIK4 y,x ] inHIDDENR3 R)"
        proof(rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          show " for y be objectHIDDENM1 holds  not (((x inHIDDENR3 fieldRELAT-1K3 R & y inHIDDENR3 fieldRELAT-1K3 R) &  not [TARSKIK4 x,y ] inHIDDENR3 R) &  not [TARSKIK4 y,x ] inHIDDENR3 R)"
            using A1 relat_1_th_40 sorry
        qed "sorry"
        thus "R be strongly-connectedRELAT-2V7"
          using relat_2_def_7 relat_2_def_15 sorry
      qed
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  not (((((x inHIDDENR3 fieldRELAT-1K3 R & y inHIDDENR3 fieldRELAT-1K3 R) & z inHIDDENR3 fieldRELAT-1K3 R) & [TARSKIK4 x,y ] inHIDDENR3 R) & [TARSKIK4 y,z ] inHIDDENR3 R) &  not [TARSKIK4 x,z ] inHIDDENR3 R)"
      proof(rule ballI)
        fix x assume [ty]: "x be objectHIDDENM1"
        show " for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  not (((((x inHIDDENR3 fieldRELAT-1K3 R & y inHIDDENR3 fieldRELAT-1K3 R) & z inHIDDENR3 fieldRELAT-1K3 R) & [TARSKIK4 x,y ] inHIDDENR3 R) & [TARSKIK4 y,z ] inHIDDENR3 R) &  not [TARSKIK4 x,z ] inHIDDENR3 R)"
          using A1 sorry
      qed "sorry"
      thus "R be transitiveRELAT-2V8"
        using relat_2_def_8 relat_2_def_16 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem relat_2_th_1:
" for R be RelationRELAT-1M1 holds R be reflexiveRELAT-2V1 iff idRELAT-1K7 (fieldRELAT-1K3 R) c=RELAT-1R2 R"
proof-
  have " for R be RelationRELAT-1M1 holds (R be reflexiveRELAT-2V1 implies idRELAT-1K7 (fieldRELAT-1K3 R) c=RELAT-1R2 R) & (idRELAT-1K7 (fieldRELAT-1K3 R) c=RELAT-1R2 R implies R be reflexiveRELAT-2V1)"
  proof(rule ballI,rule conjMI,rule impI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "R be reflexiveRELAT-2V1 implies idRELAT-1K7 (fieldRELAT-1K3 R) c=RELAT-1R2 R"
    proof(rule impI)
      assume A1: "R be reflexiveRELAT-2V1"
      show "idRELAT-1K7 (fieldRELAT-1K3 R) c=RELAT-1R2 R"
      proof-
        have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 idRELAT-1K7 (fieldRELAT-1K3 R) implies [TARSKIK4 a,b ] inHIDDENR3 R"
        proof(rule ballI,rule ballI,rule impI)
          fix a assume [ty]: "a be objectHIDDENM1"
          fix b assume [ty]: "b be objectHIDDENM1"
          assume "[TARSKIK4 a,b ] inHIDDENR3 idRELAT-1K7 (fieldRELAT-1K3 R)"
          then have "a inHIDDENR3 fieldRELAT-1K3 R & a =HIDDENR1 b"
            using relat_1_def_10 sorry
          thus "[TARSKIK4 a,b ] inHIDDENR3 R"
            using A1 relat_2_def_1 sorry
        qed "sorry"
        thus "idRELAT-1K7 (fieldRELAT-1K3 R) c=RELAT-1R2 R"
          using relat_1_def_3 sorry
      qed
    qed
    assume A2: "idRELAT-1K7 (fieldRELAT-1K3 R) c=RELAT-1R2 R"
    have " for a be objectHIDDENM1 holds a inHIDDENR3 fieldRELAT-1K3 R implies [TARSKIK4 a,a ] inHIDDENR3 R"
    proof(rule ballI,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      assume "a inHIDDENR3 fieldRELAT-1K3 R"
      then have "[TARSKIK4 a,a ] inHIDDENR3 idRELAT-1K7 (fieldRELAT-1K3 R)"
        using relat_1_def_10 sorry
      thus "[TARSKIK4 a,a ] inHIDDENR3 R"
        using A2 sorry
    qed "sorry"
    thus "R be reflexiveRELAT-2V1"
      using relat_2_def_1 relat_2_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_2_th_2:
" for R be RelationRELAT-1M1 holds R be irreflexiveRELAT-2V2 iff idRELAT-1K7 (fieldRELAT-1K3 R) missesXBOOLE-0R1 R"
proof-
  have " for R be RelationRELAT-1M1 holds (R be irreflexiveRELAT-2V2 implies idRELAT-1K7 (fieldRELAT-1K3 R) missesXBOOLE-0R1 R) & (idRELAT-1K7 (fieldRELAT-1K3 R) missesXBOOLE-0R1 R implies R be irreflexiveRELAT-2V2)"
  proof(rule ballI,rule conjMI,rule impI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "R be irreflexiveRELAT-2V2 implies idRELAT-1K7 (fieldRELAT-1K3 R) missesXBOOLE-0R1 R"
    proof(rule impI)
      assume "R be irreflexiveRELAT-2V2"
      then have A1: "R is-irreflexive-inRELAT-2R2 fieldRELAT-1K3 R"
         sorry
      have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 idRELAT-1K7 (fieldRELAT-1K3 R) /\\XBOOLE-0K3 R implies  False "
      proof(rule ballI,rule ballI,rule impI)
        fix a assume [ty]: "a be objectHIDDENM1"
        fix b assume [ty]: "b be objectHIDDENM1"
        assume A2: "[TARSKIK4 a,b ] inHIDDENR3 idRELAT-1K7 (fieldRELAT-1K3 R) /\\XBOOLE-0K3 R"
        then have "[TARSKIK4 a,b ] inHIDDENR3 idRELAT-1K7 (fieldRELAT-1K3 R)"
          using xboole_0_def_4 sorry
        then have A3: "a inHIDDENR3 fieldRELAT-1K3 R & a =HIDDENR1 b"
          using relat_1_def_10 sorry
        have "[TARSKIK4 a,b ] inHIDDENR3 R"
          using A2 xboole_0_def_4 sorry
        thus " False "
          using A1 A3 sorry
      qed "sorry"
      thus "idRELAT-1K7 (fieldRELAT-1K3 R) missesXBOOLE-0R1 R"
        using relat_1_th_37 xboole_0_def_7 sorry
    qed
    assume A4: "idRELAT-1K7 (fieldRELAT-1K3 R) missesXBOOLE-0R1 R"
    have " for a be objectHIDDENM1 holds a inHIDDENR3 fieldRELAT-1K3 R implies  not [TARSKIK4 a,a ] inHIDDENR3 R"
    proof(rule ballI,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      assume "a inHIDDENR3 fieldRELAT-1K3 R"
      then have "[TARSKIK4 a,a ] inHIDDENR3 idRELAT-1K7 (fieldRELAT-1K3 R)"
        using relat_1_def_10 sorry
      thus " not [TARSKIK4 a,a ] inHIDDENR3 R"
        using A4 xboole_0_th_3 sorry
    qed "sorry"
    thus "R be irreflexiveRELAT-2V2"
      using relat_2_def_2 relat_2_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_2_th_3:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R is-antisymmetric-inRELAT-2R4 X iff R \\XBOOLE-0K4 idRELAT-1K7 X is-asymmetric-inRELAT-2R5 X"
proof-
  have " for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds (R is-antisymmetric-inRELAT-2R4 X implies R \\XBOOLE-0K4 idRELAT-1K7 X is-asymmetric-inRELAT-2R5 X) & (R \\XBOOLE-0K4 idRELAT-1K7 X is-asymmetric-inRELAT-2R5 X implies R is-antisymmetric-inRELAT-2R4 X)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "R is-antisymmetric-inRELAT-2R4 X implies R \\XBOOLE-0K4 idRELAT-1K7 X is-asymmetric-inRELAT-2R5 X"
    proof(rule impI)
      assume A1: "R is-antisymmetric-inRELAT-2R4 X"
      show "R \\XBOOLE-0K4 idRELAT-1K7 X is-asymmetric-inRELAT-2R5 X"
      proof-
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 X & (y inHIDDENR3 X & [TARSKIK4 x,y ] inHIDDENR3 R \\XBOOLE-0K4 idRELAT-1K7 X) implies  not [TARSKIK4 y,x ] inHIDDENR3 R \\XBOOLE-0K4 idRELAT-1K7 X"
        proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          assume A2: "x inHIDDENR3 X"
            and A3: "y inHIDDENR3 X"
            and A4: "[TARSKIK4 x,y ] inHIDDENR3 R \\XBOOLE-0K4 idRELAT-1K7 X"
          have " not [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X"
            using A4 xboole_0_def_5 sorry
          then have A5: "x <>HIDDENR2 y"
            using A2 relat_1_def_10 sorry
          have "[TARSKIK4 x,y ] inHIDDENR3 R"
            using A4 xboole_0_def_5 sorry
          then have " not [TARSKIK4 y,x ] inHIDDENR3 R"
            using A1 A2 A3 A5 sorry
          thus " not [TARSKIK4 y,x ] inHIDDENR3 R \\XBOOLE-0K4 idRELAT-1K7 X"
            using xboole_0_def_5 sorry
        qed "sorry"
        thus "R \\XBOOLE-0K4 idRELAT-1K7 X is-asymmetric-inRELAT-2R5 X"
          using relat_2_def_5 sorry
      qed
    qed
    assume A6: "R \\XBOOLE-0K4 idRELAT-1K7 X is-asymmetric-inRELAT-2R5 X"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 X & y inHIDDENR3 X) & ([TARSKIK4 x,y ] inHIDDENR3 R & [TARSKIK4 y,x ] inHIDDENR3 R) implies (x <>HIDDENR2 y implies  False )"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A7: "x inHIDDENR3 X & y inHIDDENR3 X"
        and A8: "[TARSKIK4 x,y ] inHIDDENR3 R"
        and A9: "[TARSKIK4 y,x ] inHIDDENR3 R"
      assume A10: "x <>HIDDENR2 y"
      then have " not [TARSKIK4 y,x ] inHIDDENR3 idRELAT-1K7 X"
        using relat_1_def_10 sorry
      then have A11: "[TARSKIK4 y,x ] inHIDDENR3 R \\XBOOLE-0K4 idRELAT-1K7 X"
        using A9 xboole_0_def_5 sorry
      have " not [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X"
        using A10 relat_1_def_10 sorry
      then have "[TARSKIK4 x,y ] inHIDDENR3 R \\XBOOLE-0K4 idRELAT-1K7 X"
        using A8 xboole_0_def_5 sorry
      thus " False "
        using A6 A7 A11 sorry
    qed "sorry"
    thus "R is-antisymmetric-inRELAT-2R4 X"
      using relat_2_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_2_th_4:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R is-asymmetric-inRELAT-2R5 X implies R \\/XBOOLE-0K2 idRELAT-1K7 X is-antisymmetric-inRELAT-2R4 X"
proof-
  have " for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R is-asymmetric-inRELAT-2R5 X implies R \\/XBOOLE-0K2 idRELAT-1K7 X is-antisymmetric-inRELAT-2R4 X"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume A1: "R is-asymmetric-inRELAT-2R5 X"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 X & y inHIDDENR3 X) & ([TARSKIK4 x,y ] inHIDDENR3 R \\/XBOOLE-0K2 idRELAT-1K7 X & [TARSKIK4 y,x ] inHIDDENR3 R \\/XBOOLE-0K2 idRELAT-1K7 X) implies (x <>HIDDENR2 y implies  False )"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A2: "x inHIDDENR3 X & y inHIDDENR3 X"
        and A3: "[TARSKIK4 x,y ] inHIDDENR3 R \\/XBOOLE-0K2 idRELAT-1K7 X"
        and A4: "[TARSKIK4 y,x ] inHIDDENR3 R \\/XBOOLE-0K2 idRELAT-1K7 X"
      assume A5: "x <>HIDDENR2 y"
      then have " not [TARSKIK4 y,x ] inHIDDENR3 idRELAT-1K7 X"
        using relat_1_def_10 sorry
      then have A6: "[TARSKIK4 y,x ] inHIDDENR3 R"
        using A4 xboole_0_def_3 sorry
      have " not [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X"
        using A5 relat_1_def_10 sorry
      then have "[TARSKIK4 x,y ] inHIDDENR3 R"
        using A3 xboole_0_def_3 sorry
      thus " False "
        using A1 A2 A6 sorry
    qed "sorry"
    thus "R \\/XBOOLE-0K2 idRELAT-1K7 X is-antisymmetric-inRELAT-2R4 X"
      using relat_2_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CT 7*)
mtheorem relat_2_cl_2:
"cluster symmetricRELAT-2V3\<bar>transitiveRELAT-2V8 also-is reflexiveRELAT-2V1 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be symmetricRELAT-2V3\<bar>transitiveRELAT-2V8 implies it be reflexiveRELAT-2V1"
  proof-
    have " for R be RelationRELAT-1M1 holds R be symmetricRELAT-2V3 & R be transitiveRELAT-2V8 implies R be reflexiveRELAT-2V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix R assume [ty]: "R be RelationRELAT-1M1"
      assume A1: "R be symmetricRELAT-2V3"
        and A2: "R be transitiveRELAT-2V8"
      have A3: "R is-transitive-inRELAT-2R8 fieldRELAT-1K3 R"
        using A2 sorry
      have A4: "R is-symmetric-inRELAT-2R3 fieldRELAT-1K3 R"
        using A1 sorry
      have " for a be objectHIDDENM1 holds  not (a inHIDDENR3 fieldRELAT-1K3 R &  not [TARSKIK4 a,a ] inHIDDENR3 R)"
      proof(rule ballI)
        fix a assume [ty]: "a be objectHIDDENM1"
        have A5: "a inHIDDENR3 domRELAT-1K1 R implies [TARSKIK4 a,a ] inHIDDENR3 R"
        proof(rule impI)
          assume "a inHIDDENR3 domRELAT-1K1 R"
          then obtain b where
            [ty]:"b be objectHIDDENM1" and 
            A6: "[TARSKIK4 a,b ] inHIDDENR3 R"
            using xtuple_0_def_12 sorry
          have A7: "a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R"
            using A6 relat_1_th_15 sorry
          then have "[TARSKIK4 b,a ] inHIDDENR3 R"
            using A4 A6 sorry
          thus "[TARSKIK4 a,a ] inHIDDENR3 R"
            using A3 A6 A7 sorry
        qed
        have "a inHIDDENR3 rngRELAT-1K2 R implies [TARSKIK4 a,a ] inHIDDENR3 R"
        proof(rule impI)
          assume "a inHIDDENR3 rngRELAT-1K2 R"
          then obtain b where
            [ty]:"b be objectHIDDENM1" and 
            A8: "[TARSKIK4 b,a ] inHIDDENR3 R"
            using xtuple_0_def_13 sorry
          have A9: "a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R"
            using A8 relat_1_th_15 sorry
          then have "[TARSKIK4 a,b ] inHIDDENR3 R"
            using A4 A8 sorry
          thus "[TARSKIK4 a,a ] inHIDDENR3 R"
            using A3 A8 A9 sorry
        qed
        thus " not (a inHIDDENR3 fieldRELAT-1K3 R &  not [TARSKIK4 a,a ] inHIDDENR3 R)"
          using A5 xboole_0_def_3 sorry
      qed "sorry"
      thus "R be reflexiveRELAT-2V1"
        using relat_2_def_1 relat_2_def_9 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem relat_2_cl_3:
  mlet "X be setHIDDENM2"
"cluster idRELAT-1K7 X as-term-is symmetricRELAT-2V3\<bar>transitiveRELAT-2V8\<bar>antisymmetricRELAT-2V4"
proof
(*coherence*)
  show "idRELAT-1K7 X be symmetricRELAT-2V3\<bar>transitiveRELAT-2V8\<bar>antisymmetricRELAT-2V4"
  proof-
    have "idRELAT-1K7 X be symmetricRELAT-2V3 & (idRELAT-1K7 X be transitiveRELAT-2V8 & idRELAT-1K7 X be antisymmetricRELAT-2V4)"
    proof(rule conjMI,rule conjMI)
      show "idRELAT-1K7 X be symmetricRELAT-2V3"
      proof-
        have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds a inHIDDENR3 fieldRELAT-1K3 (idRELAT-1K7 X) & (b inHIDDENR3 fieldRELAT-1K3 (idRELAT-1K7 X) & [TARSKIK4 a,b ] inHIDDENR3 idRELAT-1K7 X) implies [TARSKIK4 b,a ] inHIDDENR3 idRELAT-1K7 X"
        proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
          fix a assume [ty]: "a be objectHIDDENM1"
          fix b assume [ty]: "b be objectHIDDENM1"
          assume "a inHIDDENR3 fieldRELAT-1K3 (idRELAT-1K7 X)"
            and "b inHIDDENR3 fieldRELAT-1K3 (idRELAT-1K7 X)"
            and A1: "[TARSKIK4 a,b ] inHIDDENR3 idRELAT-1K7 X"
          have "a =HIDDENR1 b"
            using A1 relat_1_def_10 sorry
          thus "[TARSKIK4 b,a ] inHIDDENR3 idRELAT-1K7 X"
            using A1 sorry
        qed "sorry"
        thus "idRELAT-1K7 X be symmetricRELAT-2V3"
          using relat_2_def_3 relat_2_def_11 sorry
      qed
      show "idRELAT-1K7 X be transitiveRELAT-2V8"
      proof-
        have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds  not (((((a inHIDDENR3 fieldRELAT-1K3 (idRELAT-1K7 X) & b inHIDDENR3 fieldRELAT-1K3 (idRELAT-1K7 X)) & c inHIDDENR3 fieldRELAT-1K3 (idRELAT-1K7 X)) & [TARSKIK4 a,b ] inHIDDENR3 idRELAT-1K7 X) & [TARSKIK4 b,c ] inHIDDENR3 idRELAT-1K7 X) &  not [TARSKIK4 a,c ] inHIDDENR3 idRELAT-1K7 X)"
        proof(rule ballI,rule ballI,rule ballI)
          fix a assume [ty]: "a be objectHIDDENM1"
          fix b assume [ty]: "b be objectHIDDENM1"
          fix c assume [ty]: "c be objectHIDDENM1"
          show " not (((((a inHIDDENR3 fieldRELAT-1K3 (idRELAT-1K7 X) & b inHIDDENR3 fieldRELAT-1K3 (idRELAT-1K7 X)) & c inHIDDENR3 fieldRELAT-1K3 (idRELAT-1K7 X)) & [TARSKIK4 a,b ] inHIDDENR3 idRELAT-1K7 X) & [TARSKIK4 b,c ] inHIDDENR3 idRELAT-1K7 X) &  not [TARSKIK4 a,c ] inHIDDENR3 idRELAT-1K7 X)"
            using relat_1_def_10 sorry
        qed "sorry"
        thus "idRELAT-1K7 X be transitiveRELAT-2V8"
          using relat_2_def_8 relat_2_def_16 sorry
      qed
      show "idRELAT-1K7 X be antisymmetricRELAT-2V4"
      proof-
        have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  not ((((a inHIDDENR3 fieldRELAT-1K3 (idRELAT-1K7 X) & b inHIDDENR3 fieldRELAT-1K3 (idRELAT-1K7 X)) & [TARSKIK4 a,b ] inHIDDENR3 idRELAT-1K7 X) & [TARSKIK4 b,a ] inHIDDENR3 idRELAT-1K7 X) &  not a =HIDDENR1 b)"
        proof(rule ballI,rule ballI)
          fix a assume [ty]: "a be objectHIDDENM1"
          fix b assume [ty]: "b be objectHIDDENM1"
          show " not ((((a inHIDDENR3 fieldRELAT-1K3 (idRELAT-1K7 X) & b inHIDDENR3 fieldRELAT-1K3 (idRELAT-1K7 X)) & [TARSKIK4 a,b ] inHIDDENR3 idRELAT-1K7 X) & [TARSKIK4 b,a ] inHIDDENR3 idRELAT-1K7 X) &  not a =HIDDENR1 b)"
            using relat_1_def_10 sorry
        qed "sorry"
        thus "idRELAT-1K7 X be antisymmetricRELAT-2V4"
          using relat_2_def_4 relat_2_def_12 sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem relat_2_cl_4:
"cluster irreflexiveRELAT-2V2\<bar>transitiveRELAT-2V8 also-is asymmetricRELAT-2V5 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be irreflexiveRELAT-2V2\<bar>transitiveRELAT-2V8 implies it be asymmetricRELAT-2V5"
  proof-
    have " for R be RelationRELAT-1M1 holds  not ((R be irreflexiveRELAT-2V2 & R be transitiveRELAT-2V8) &  not R be asymmetricRELAT-2V5)"
    proof(rule ballI)
      fix R assume [ty]: "R be RelationRELAT-1M1"
      have "R is-irreflexive-inRELAT-2R2 fieldRELAT-1K3 R & R is-transitive-inRELAT-2R8 fieldRELAT-1K3 R implies R be asymmetricRELAT-2V5"
      proof(rule impMI ,rule impI)
        assume A1: "R is-irreflexive-inRELAT-2R2 fieldRELAT-1K3 R"
          and A2: "R is-transitive-inRELAT-2R8 fieldRELAT-1K3 R"
        have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R implies  not ([TARSKIK4 a,b ] inHIDDENR3 R & [TARSKIK4 b,a ] inHIDDENR3 R)"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix a assume [ty]: "a be objectHIDDENM1"
          fix b assume [ty]: "b be objectHIDDENM1"
          assume A3: "a inHIDDENR3 fieldRELAT-1K3 R"
            and A4: "b inHIDDENR3 fieldRELAT-1K3 R"
          have " not [TARSKIK4 a,a ] inHIDDENR3 R"
            using A1 A3 sorry
          thus " not ([TARSKIK4 a,b ] inHIDDENR3 R & [TARSKIK4 b,a ] inHIDDENR3 R)"
            using A2 A3 A4 sorry
        qed "sorry"
        thus "R be asymmetricRELAT-2V5"
          using relat_2_def_5 relat_2_def_13 sorry
      qed
      thus " not ((R be irreflexiveRELAT-2V2 & R be transitiveRELAT-2V8) &  not R be asymmetricRELAT-2V5)"
        using relat_2_def_10 relat_2_def_16 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem relat_2_cl_5:
"cluster asymmetricRELAT-2V5 also-is irreflexiveRELAT-2V2\<bar>antisymmetricRELAT-2V4 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be asymmetricRELAT-2V5 implies it be irreflexiveRELAT-2V2\<bar>antisymmetricRELAT-2V4"
  proof-
    have " for R be RelationRELAT-1M1 holds  not (R be asymmetricRELAT-2V5 &  not (R be irreflexiveRELAT-2V2 & R be antisymmetricRELAT-2V4))"
    proof(rule ballI)
      fix R assume [ty]: "R be RelationRELAT-1M1"
      have "R is-asymmetric-inRELAT-2R5 fieldRELAT-1K3 R implies R be irreflexiveRELAT-2V2 & R be antisymmetricRELAT-2V4"
      proof(rule impI,rule conjMI)
        assume A5: "R is-asymmetric-inRELAT-2R5 fieldRELAT-1K3 R"
        then have " for x be objectHIDDENM1 holds x inHIDDENR3 fieldRELAT-1K3 R implies  not [TARSKIK4 x,x ] inHIDDENR3 R"
           sorry
        thus "R be irreflexiveRELAT-2V2"
          using relat_2_def_2 sorry
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ((x inHIDDENR3 fieldRELAT-1K3 R & y inHIDDENR3 fieldRELAT-1K3 R) & [TARSKIK4 x,y ] inHIDDENR3 R) & [TARSKIK4 y,x ] inHIDDENR3 R implies x =HIDDENR1 y"
          using A5 sorry
        thus "R be antisymmetricRELAT-2V4"
          using relat_2_def_4 sorry
      qed
      thus " not (R be asymmetricRELAT-2V5 &  not (R be irreflexiveRELAT-2V2 & R be antisymmetricRELAT-2V4))"
        using relat_2_def_13 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem relat_2_cl_6:
  mlet "R be reflexiveRELAT-2V1\<bar>RelationRELAT-1M1"
"cluster R ~RELAT-1K4 as-term-is reflexiveRELAT-2V1"
proof
(*coherence*)
  show "R ~RELAT-1K4 be reflexiveRELAT-2V1"
  proof-
    have A1: "R is-reflexive-inRELAT-2R1 fieldRELAT-1K3 R"
      using relat_2_def_9 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 fieldRELAT-1K3 (R ~RELAT-1K4) implies [TARSKIK4 x,x ] inHIDDENR3 R ~RELAT-1K4"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 fieldRELAT-1K3 (R ~RELAT-1K4)"
      then have "x inHIDDENR3 fieldRELAT-1K3 R"
        using relat_1_th_21 sorry
      then have "[TARSKIK4 x,x ] inHIDDENR3 R"
        using A1 sorry
      thus "[TARSKIK4 x,x ] inHIDDENR3 R ~RELAT-1K4"
        using relat_1_def_7 sorry
    qed "sorry"
    thus "R ~RELAT-1K4 be reflexiveRELAT-2V1"
      using relat_2_def_1 relat_2_def_9 sorry
  qed
qed "sorry"

mtheorem relat_2_cl_7:
  mlet "R be irreflexiveRELAT-2V2\<bar>RelationRELAT-1M1"
"cluster R ~RELAT-1K4 as-term-is irreflexiveRELAT-2V2"
proof
(*coherence*)
  show "R ~RELAT-1K4 be irreflexiveRELAT-2V2"
  proof-
    have A1: "R is-irreflexive-inRELAT-2R2 fieldRELAT-1K3 R"
      using relat_2_def_10 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 fieldRELAT-1K3 (R ~RELAT-1K4) implies  not [TARSKIK4 x,x ] inHIDDENR3 R ~RELAT-1K4"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 fieldRELAT-1K3 (R ~RELAT-1K4)"
      then have "x inHIDDENR3 fieldRELAT-1K3 R"
        using relat_1_th_21 sorry
      then have " not [TARSKIK4 x,x ] inHIDDENR3 R"
        using A1 sorry
      thus " not [TARSKIK4 x,x ] inHIDDENR3 R ~RELAT-1K4"
        using relat_1_def_7 sorry
    qed "sorry"
    thus "R ~RELAT-1K4 be irreflexiveRELAT-2V2"
      using relat_2_def_2 relat_2_def_10 sorry
  qed
qed "sorry"

mtheorem relat_2_th_12:
" for R be RelationRELAT-1M1 holds R be reflexiveRELAT-2V1 implies domRELAT-1K1 R =XBOOLE-0R4 domRELAT-1K1 (R ~RELAT-1K4) & rngRELAT-1K2 R =XBOOLE-0R4 rngRELAT-1K2 (R ~RELAT-1K4)"
proof-
  have " for R be RelationRELAT-1M1 holds R be reflexiveRELAT-2V1 implies domRELAT-1K1 R =XBOOLE-0R4 domRELAT-1K1 (R ~RELAT-1K4) & rngRELAT-1K2 R =XBOOLE-0R4 rngRELAT-1K2 (R ~RELAT-1K4)"
  proof(rule ballI,rule impI,rule conjMI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume A1: "R be reflexiveRELAT-2V1"
    then have A2: "R is-reflexive-inRELAT-2R1 fieldRELAT-1K3 R"
       sorry
    have A3: "R ~RELAT-1K4 is-reflexive-inRELAT-2R1 fieldRELAT-1K3 (R ~RELAT-1K4)"
      using A1 relat_2_def_9 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 R iff x inHIDDENR3 domRELAT-1K1 (R ~RELAT-1K4)"
    proof(rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have A4: "x inHIDDENR3 domRELAT-1K1 (R ~RELAT-1K4) implies x inHIDDENR3 domRELAT-1K1 R"
      proof(rule impI)
        assume "x inHIDDENR3 domRELAT-1K1 (R ~RELAT-1K4)"
        then have "x inHIDDENR3 fieldRELAT-1K3 (R ~RELAT-1K4)"
          using xboole_0_def_3 sorry
        then have "[TARSKIK4 x,x ] inHIDDENR3 R ~RELAT-1K4"
          using A1 relat_2_def_1 relat_2_def_9 sorry
        then have "[TARSKIK4 x,x ] inHIDDENR3 R"
          using relat_1_def_7 sorry
        thus "x inHIDDENR3 domRELAT-1K1 R"
          using xtuple_0_def_12 sorry
      qed
      have "x inHIDDENR3 domRELAT-1K1 R implies x inHIDDENR3 domRELAT-1K1 (R ~RELAT-1K4)"
      proof(rule impI)
        assume "x inHIDDENR3 domRELAT-1K1 R"
        then have "x inHIDDENR3 fieldRELAT-1K3 R"
          using xboole_0_def_3 sorry
        then have "[TARSKIK4 x,x ] inHIDDENR3 R"
          using A1 relat_2_def_1 sorry
        then have "[TARSKIK4 x,x ] inHIDDENR3 R ~RELAT-1K4"
          using relat_1_def_7 sorry
        thus "x inHIDDENR3 domRELAT-1K1 (R ~RELAT-1K4)"
          using xtuple_0_def_12 sorry
      qed
      thus "x inHIDDENR3 domRELAT-1K1 R iff x inHIDDENR3 domRELAT-1K1 (R ~RELAT-1K4)"
        using A4 sorry
    qed "sorry"
    thus "domRELAT-1K1 R =XBOOLE-0R4 domRELAT-1K1 (R ~RELAT-1K4)"
      using tarski_th_2 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELAT-1K2 R iff x inHIDDENR3 rngRELAT-1K2 (R ~RELAT-1K4)"
    proof(rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have A5: "x inHIDDENR3 rngRELAT-1K2 (R ~RELAT-1K4) implies x inHIDDENR3 rngRELAT-1K2 R"
      proof(rule impI)
        assume "x inHIDDENR3 rngRELAT-1K2 (R ~RELAT-1K4)"
        then have "x inHIDDENR3 fieldRELAT-1K3 (R ~RELAT-1K4)"
          using xboole_0_def_3 sorry
        then have "[TARSKIK4 x,x ] inHIDDENR3 R ~RELAT-1K4"
          using A3 sorry
        then have "[TARSKIK4 x,x ] inHIDDENR3 R"
          using relat_1_def_7 sorry
        thus "x inHIDDENR3 rngRELAT-1K2 R"
          using xtuple_0_def_13 sorry
      qed
      have "x inHIDDENR3 rngRELAT-1K2 R implies x inHIDDENR3 rngRELAT-1K2 (R ~RELAT-1K4)"
      proof(rule impI)
        assume "x inHIDDENR3 rngRELAT-1K2 R"
        then have "x inHIDDENR3 fieldRELAT-1K3 R"
          using xboole_0_def_3 sorry
        then have "[TARSKIK4 x,x ] inHIDDENR3 R"
          using A2 sorry
        then have "[TARSKIK4 x,x ] inHIDDENR3 R ~RELAT-1K4"
          using relat_1_def_7 sorry
        thus "x inHIDDENR3 rngRELAT-1K2 (R ~RELAT-1K4)"
          using xtuple_0_def_13 sorry
      qed
      thus "x inHIDDENR3 rngRELAT-1K2 R iff x inHIDDENR3 rngRELAT-1K2 (R ~RELAT-1K4)"
        using A5 sorry
    qed "sorry"
    thus "rngRELAT-1K2 R =XBOOLE-0R4 rngRELAT-1K2 (R ~RELAT-1K4)"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_2_th_13:
" for R be RelationRELAT-1M1 holds R be symmetricRELAT-2V3 iff R =RELAT-1R1 R ~RELAT-1K4"
proof-
  have " for R be RelationRELAT-1M1 holds (R be symmetricRELAT-2V3 implies R =RELAT-1R1 R ~RELAT-1K4) & (R =RELAT-1R1 R ~RELAT-1K4 implies R be symmetricRELAT-2V3)"
  proof(rule ballI,rule conjMI,rule impI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "R be symmetricRELAT-2V3 implies R =RELAT-1R1 R ~RELAT-1K4"
    proof(rule impI)
      assume "R be symmetricRELAT-2V3"
      then have A1: "R is-symmetric-inRELAT-2R3 fieldRELAT-1K3 R"
         sorry
      have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R iff [TARSKIK4 a,b ] inHIDDENR3 R ~RELAT-1K4"
      proof(rule ballI,rule ballI)
        fix a assume [ty]: "a be objectHIDDENM1"
        fix b assume [ty]: "b be objectHIDDENM1"
        have A2: "[TARSKIK4 a,b ] inHIDDENR3 R ~RELAT-1K4 implies [TARSKIK4 a,b ] inHIDDENR3 R"
        proof(rule impI)
          assume "[TARSKIK4 a,b ] inHIDDENR3 R ~RELAT-1K4"
          then have A3: "[TARSKIK4 b,a ] inHIDDENR3 R"
            using relat_1_def_7 sorry
          then have "a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R"
            using relat_1_th_15 sorry
          thus "[TARSKIK4 a,b ] inHIDDENR3 R"
            using A1 A3 sorry
        qed
        have "[TARSKIK4 a,b ] inHIDDENR3 R implies [TARSKIK4 a,b ] inHIDDENR3 R ~RELAT-1K4"
        proof(rule impI)
          assume A4: "[TARSKIK4 a,b ] inHIDDENR3 R"
          then have "a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R"
            using relat_1_th_15 sorry
          then have "[TARSKIK4 b,a ] inHIDDENR3 R"
            using A1 A4 sorry
          thus "[TARSKIK4 a,b ] inHIDDENR3 R ~RELAT-1K4"
            using relat_1_def_7 sorry
        qed
        thus "[TARSKIK4 a,b ] inHIDDENR3 R iff [TARSKIK4 a,b ] inHIDDENR3 R ~RELAT-1K4"
          using A2 sorry
      qed "sorry"
      thus "R =RELAT-1R1 R ~RELAT-1K4"
         sorry
    qed
    assume "R =RELAT-1R1 R ~RELAT-1K4"
    then have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R) & [TARSKIK4 a,b ] inHIDDENR3 R implies [TARSKIK4 b,a ] inHIDDENR3 R"
      using relat_1_def_7 sorry
    thus "R be symmetricRELAT-2V3"
      using relat_2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_2_cl_8:
  mlet "P be reflexiveRELAT-2V1\<bar>RelationRELAT-1M1", "R be reflexiveRELAT-2V1\<bar>RelationRELAT-1M1"
"cluster P \\/XBOOLE-0K2 R as-term-is reflexiveRELAT-2V1"
proof
(*coherence*)
  show "P \\/XBOOLE-0K2 R be reflexiveRELAT-2V1"
  proof-
    have A1: "R is-reflexive-inRELAT-2R1 fieldRELAT-1K3 R"
      using relat_2_def_9 sorry
    have A2: "P is-reflexive-inRELAT-2R1 fieldRELAT-1K3 P"
      using relat_2_def_9 sorry
    have " for a be objectHIDDENM1 holds a inHIDDENR3 fieldRELAT-1K3 (P \\/XBOOLE-0K2 R) implies [TARSKIK4 a,a ] inHIDDENR3 P \\/XBOOLE-0K2 R"
    proof(rule ballI,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      have A3: "a inHIDDENR3 fieldRELAT-1K3 P implies [TARSKIK4 a,a ] inHIDDENR3 P \\/XBOOLE-0K2 R"
      proof(rule impI)
        assume "a inHIDDENR3 fieldRELAT-1K3 P"
        then have "[TARSKIK4 a,a ] inHIDDENR3 P"
          using A2 sorry
        thus "[TARSKIK4 a,a ] inHIDDENR3 P \\/XBOOLE-0K2 R"
          using xboole_0_def_3 sorry
      qed
      have A4: "a inHIDDENR3 fieldRELAT-1K3 R implies [TARSKIK4 a,a ] inHIDDENR3 P \\/XBOOLE-0K2 R"
      proof(rule impI)
        assume "a inHIDDENR3 fieldRELAT-1K3 R"
        then have "[TARSKIK4 a,a ] inHIDDENR3 R"
          using A1 sorry
        thus "[TARSKIK4 a,a ] inHIDDENR3 P \\/XBOOLE-0K2 R"
          using xboole_0_def_3 sorry
      qed
      assume "a inHIDDENR3 fieldRELAT-1K3 (P \\/XBOOLE-0K2 R)"
      then have "a inHIDDENR3 fieldRELAT-1K3 P \\/XBOOLE-0K2 fieldRELAT-1K3 R"
        using relat_1_th_18 sorry
      thus "[TARSKIK4 a,a ] inHIDDENR3 P \\/XBOOLE-0K2 R"
        using A3 A4 xboole_0_def_3 sorry
    qed "sorry"
    thus "P \\/XBOOLE-0K2 R be reflexiveRELAT-2V1"
      using relat_2_def_1 sorry
  qed
qed "sorry"

mtheorem relat_2_cl_9:
  mlet "P be reflexiveRELAT-2V1\<bar>RelationRELAT-1M1", "R be reflexiveRELAT-2V1\<bar>RelationRELAT-1M1"
"cluster P /\\XBOOLE-0K3 R as-term-is reflexiveRELAT-2V1"
proof
(*coherence*)
  show "P /\\XBOOLE-0K3 R be reflexiveRELAT-2V1"
  proof-
    have A5: "R is-reflexive-inRELAT-2R1 fieldRELAT-1K3 R"
      using relat_2_def_9 sorry
    have A6: "P is-reflexive-inRELAT-2R1 fieldRELAT-1K3 P"
      using relat_2_def_9 sorry
    have " for a be objectHIDDENM1 holds a inHIDDENR3 fieldRELAT-1K3 (P /\\XBOOLE-0K3 R) implies [TARSKIK4 a,a ] inHIDDENR3 P /\\XBOOLE-0K3 R"
    proof(rule ballI,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      assume A7: "a inHIDDENR3 fieldRELAT-1K3 (P /\\XBOOLE-0K3 R)"
      have A8: "fieldRELAT-1K3 (P /\\XBOOLE-0K3 R) c=TARSKIR1 fieldRELAT-1K3 P /\\XBOOLE-0K3 fieldRELAT-1K3 R"
        using relat_1_th_19 sorry
      then have "a inHIDDENR3 fieldRELAT-1K3 R"
        using A7 xboole_0_def_4 sorry
      then have A9: "[TARSKIK4 a,a ] inHIDDENR3 R"
        using A5 sorry
      have "a inHIDDENR3 fieldRELAT-1K3 P"
        using A8 A7 xboole_0_def_4 sorry
      then have "[TARSKIK4 a,a ] inHIDDENR3 P"
        using A6 sorry
      thus "[TARSKIK4 a,a ] inHIDDENR3 P /\\XBOOLE-0K3 R"
        using A9 xboole_0_def_4 sorry
    qed "sorry"
    thus "P /\\XBOOLE-0K3 R be reflexiveRELAT-2V1"
      using relat_2_def_1 sorry
  qed
qed "sorry"

mtheorem relat_2_cl_10:
  mlet "P be irreflexiveRELAT-2V2\<bar>RelationRELAT-1M1", "R be irreflexiveRELAT-2V2\<bar>RelationRELAT-1M1"
"cluster P \\/XBOOLE-0K2 R as-term-is irreflexiveRELAT-2V2"
proof
(*coherence*)
  show "P \\/XBOOLE-0K2 R be irreflexiveRELAT-2V2"
  proof-
    have A1: "P is-irreflexive-inRELAT-2R2 fieldRELAT-1K3 P"
      using relat_2_def_10 sorry
    have A2: "R is-irreflexive-inRELAT-2R2 fieldRELAT-1K3 R"
      using relat_2_def_10 sorry
    have " for a be objectHIDDENM1 holds a inHIDDENR3 fieldRELAT-1K3 (P \\/XBOOLE-0K2 R) implies  not [TARSKIK4 a,a ] inHIDDENR3 P \\/XBOOLE-0K2 R"
    proof(rule ballI,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      have A3: "a inHIDDENR3 fieldRELAT-1K3 P implies  not [TARSKIK4 a,a ] inHIDDENR3 P \\/XBOOLE-0K2 R"
      proof(rule impI)
        assume "a inHIDDENR3 fieldRELAT-1K3 P"
        then have A4: " not [TARSKIK4 a,a ] inHIDDENR3 P"
          using A1 sorry
        have A5: " not a inHIDDENR3 fieldRELAT-1K3 R implies  not [TARSKIK4 a,a ] inHIDDENR3 R"
          using relat_1_th_15 sorry
        have "a inHIDDENR3 fieldRELAT-1K3 R implies  not [TARSKIK4 a,a ] inHIDDENR3 R"
          using A2 sorry
        thus " not [TARSKIK4 a,a ] inHIDDENR3 P \\/XBOOLE-0K2 R"
          using A4 A5 xboole_0_def_3 sorry
      qed
      have A6: "a inHIDDENR3 fieldRELAT-1K3 R implies  not [TARSKIK4 a,a ] inHIDDENR3 P \\/XBOOLE-0K2 R"
      proof(rule impI)
        assume "a inHIDDENR3 fieldRELAT-1K3 R"
        then have A7: " not [TARSKIK4 a,a ] inHIDDENR3 R"
          using A2 sorry
        have A8: " not a inHIDDENR3 fieldRELAT-1K3 P implies  not [TARSKIK4 a,a ] inHIDDENR3 P"
          using relat_1_th_15 sorry
        have "a inHIDDENR3 fieldRELAT-1K3 P implies  not [TARSKIK4 a,a ] inHIDDENR3 P"
          using A1 sorry
        thus " not [TARSKIK4 a,a ] inHIDDENR3 P \\/XBOOLE-0K2 R"
          using A7 A8 xboole_0_def_3 sorry
      qed
      assume "a inHIDDENR3 fieldRELAT-1K3 (P \\/XBOOLE-0K2 R)"
      then have "a inHIDDENR3 fieldRELAT-1K3 P \\/XBOOLE-0K2 fieldRELAT-1K3 R"
        using relat_1_th_18 sorry
      thus " not [TARSKIK4 a,a ] inHIDDENR3 P \\/XBOOLE-0K2 R"
        using A3 A6 xboole_0_def_3 sorry
    qed "sorry"
    thus "P \\/XBOOLE-0K2 R be irreflexiveRELAT-2V2"
      using relat_2_def_2 relat_2_def_10 sorry
  qed
qed "sorry"

mtheorem relat_2_cl_11:
  mlet "P be irreflexiveRELAT-2V2\<bar>RelationRELAT-1M1", "R be irreflexiveRELAT-2V2\<bar>RelationRELAT-1M1"
"cluster P /\\XBOOLE-0K3 R as-term-is irreflexiveRELAT-2V2"
proof
(*coherence*)
  show "P /\\XBOOLE-0K3 R be irreflexiveRELAT-2V2"
  proof-
    have " for a be objectHIDDENM1 holds a inHIDDENR3 fieldRELAT-1K3 (P /\\XBOOLE-0K3 R) implies  not [TARSKIK4 a,a ] inHIDDENR3 P /\\XBOOLE-0K3 R"
    proof(rule ballI,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      assume A9: "a inHIDDENR3 fieldRELAT-1K3 (P /\\XBOOLE-0K3 R)"
      have "fieldRELAT-1K3 (P /\\XBOOLE-0K3 R) c=TARSKIR1 fieldRELAT-1K3 P /\\XBOOLE-0K3 fieldRELAT-1K3 R"
        using relat_1_th_19 sorry
      then have "a inHIDDENR3 fieldRELAT-1K3 P"
        using A9 xboole_0_def_4 sorry
      then have " not [TARSKIK4 a,a ] inHIDDENR3 P"
        using relat_2_def_10 relat_2_def_2 sorry
      thus " not [TARSKIK4 a,a ] inHIDDENR3 P /\\XBOOLE-0K3 R"
        using xboole_0_def_4 sorry
    qed "sorry"
    thus "P /\\XBOOLE-0K3 R be irreflexiveRELAT-2V2"
      using relat_2_def_2 relat_2_def_10 sorry
  qed
qed "sorry"

mtheorem relat_2_cl_12:
  mlet "P be irreflexiveRELAT-2V2\<bar>RelationRELAT-1M1", "R be RelationRELAT-1M1"
"cluster P \\XBOOLE-0K4 R as-term-is irreflexiveRELAT-2V2"
proof
(*coherence*)
  show "P \\XBOOLE-0K4 R be irreflexiveRELAT-2V2"
  proof-
    have A1: "P is-irreflexive-inRELAT-2R2 fieldRELAT-1K3 P"
      using relat_2_def_10 sorry
    have " for a be objectHIDDENM1 holds  not (a inHIDDENR3 fieldRELAT-1K3 (P \\XBOOLE-0K4 R) & [TARSKIK4 a,a ] inHIDDENR3 P \\XBOOLE-0K4 R)"
    proof(rule ballI)
      fix a assume [ty]: "a be objectHIDDENM1"
      have A2: "a inHIDDENR3 domRELAT-1K1 (P \\XBOOLE-0K4 R) implies  not [TARSKIK4 a,a ] inHIDDENR3 P"
      proof(rule impI)
        assume "a inHIDDENR3 domRELAT-1K1 (P \\XBOOLE-0K4 R)"
        then obtain b where
          [ty]:"b be objectHIDDENM1" and 
          A3: "[TARSKIK4 a,b ] inHIDDENR3 P \\XBOOLE-0K4 R"
          using xtuple_0_def_12 sorry
        have "[TARSKIK4 a,b ] inHIDDENR3 P"
          using A3 xboole_0_def_5 sorry
        then have "a inHIDDENR3 fieldRELAT-1K3 P"
          using relat_1_th_15 sorry
        thus " not [TARSKIK4 a,a ] inHIDDENR3 P"
          using A1 sorry
      qed
      have "a inHIDDENR3 rngRELAT-1K2 (P \\XBOOLE-0K4 R) implies  not [TARSKIK4 a,a ] inHIDDENR3 P"
      proof(rule impI)
        assume "a inHIDDENR3 rngRELAT-1K2 (P \\XBOOLE-0K4 R)"
        then obtain b where
          [ty]:"b be objectHIDDENM1" and 
          A4: "[TARSKIK4 b,a ] inHIDDENR3 P \\XBOOLE-0K4 R"
          using xtuple_0_def_13 sorry
        have "[TARSKIK4 b,a ] inHIDDENR3 P"
          using A4 xboole_0_def_5 sorry
        then have "a inHIDDENR3 fieldRELAT-1K3 P"
          using relat_1_th_15 sorry
        thus " not [TARSKIK4 a,a ] inHIDDENR3 P"
          using A1 sorry
      qed
      thus " not (a inHIDDENR3 fieldRELAT-1K3 (P \\XBOOLE-0K4 R) & [TARSKIK4 a,a ] inHIDDENR3 P \\XBOOLE-0K4 R)"
        using A2 xboole_0_def_3 xboole_0_def_5 sorry
    qed "sorry"
    thus "P \\XBOOLE-0K4 R be irreflexiveRELAT-2V2"
      using relat_2_def_2 relat_2_def_10 sorry
  qed
qed "sorry"

mtheorem relat_2_cl_13:
  mlet "R be symmetricRELAT-2V3\<bar>RelationRELAT-1M1"
"cluster R ~RELAT-1K4 as-term-is symmetricRELAT-2V3"
proof
(*coherence*)
  show "R ~RELAT-1K4 be symmetricRELAT-2V3"
    using relat_2_th_13 sorry
qed "sorry"

mtheorem relat_2_cl_14:
  mlet "P be symmetricRELAT-2V3\<bar>RelationRELAT-1M1", "R be symmetricRELAT-2V3\<bar>RelationRELAT-1M1"
"cluster P \\/XBOOLE-0K2 R as-term-is symmetricRELAT-2V3"
proof
(*coherence*)
  show "P \\/XBOOLE-0K2 R be symmetricRELAT-2V3"
  proof-
    have A1: "R is-symmetric-inRELAT-2R3 fieldRELAT-1K3 R"
      using relat_2_def_11 sorry
    have A2: "P is-symmetric-inRELAT-2R3 fieldRELAT-1K3 P"
      using relat_2_def_11 sorry
    have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds a inHIDDENR3 fieldRELAT-1K3 (P \\/XBOOLE-0K2 R) & (b inHIDDENR3 fieldRELAT-1K3 (P \\/XBOOLE-0K2 R) & [TARSKIK4 a,b ] inHIDDENR3 P \\/XBOOLE-0K2 R) implies [TARSKIK4 b,a ] inHIDDENR3 P \\/XBOOLE-0K2 R"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      fix b assume [ty]: "b be objectHIDDENM1"
      assume "a inHIDDENR3 fieldRELAT-1K3 (P \\/XBOOLE-0K2 R)"
        and "b inHIDDENR3 fieldRELAT-1K3 (P \\/XBOOLE-0K2 R)"
        and A3: "[TARSKIK4 a,b ] inHIDDENR3 P \\/XBOOLE-0K2 R"
      have A4: "[TARSKIK4 a,b ] inHIDDENR3 R implies [TARSKIK4 b,a ] inHIDDENR3 P \\/XBOOLE-0K2 R"
      proof(rule impI)
        assume A5: "[TARSKIK4 a,b ] inHIDDENR3 R"
        then have "a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R"
          using relat_1_th_15 sorry
        then have "[TARSKIK4 b,a ] inHIDDENR3 R"
          using A1 A5 sorry
        thus "[TARSKIK4 b,a ] inHIDDENR3 P \\/XBOOLE-0K2 R"
          using xboole_0_def_3 sorry
      qed
      have "[TARSKIK4 a,b ] inHIDDENR3 P implies [TARSKIK4 b,a ] inHIDDENR3 P \\/XBOOLE-0K2 R"
      proof(rule impI)
        assume A6: "[TARSKIK4 a,b ] inHIDDENR3 P"
        then have "a inHIDDENR3 fieldRELAT-1K3 P & b inHIDDENR3 fieldRELAT-1K3 P"
          using relat_1_th_15 sorry
        then have "[TARSKIK4 b,a ] inHIDDENR3 P"
          using A2 A6 sorry
        thus "[TARSKIK4 b,a ] inHIDDENR3 P \\/XBOOLE-0K2 R"
          using xboole_0_def_3 sorry
      qed
      thus "[TARSKIK4 b,a ] inHIDDENR3 P \\/XBOOLE-0K2 R"
        using A3 A4 xboole_0_def_3 sorry
    qed "sorry"
    thus "P \\/XBOOLE-0K2 R be symmetricRELAT-2V3"
      using relat_2_def_3 sorry
  qed
qed "sorry"

mtheorem relat_2_cl_15:
  mlet "P be symmetricRELAT-2V3\<bar>RelationRELAT-1M1", "R be symmetricRELAT-2V3\<bar>RelationRELAT-1M1"
"cluster P /\\XBOOLE-0K3 R as-term-is symmetricRELAT-2V3"
proof
(*coherence*)
  show "P /\\XBOOLE-0K3 R be symmetricRELAT-2V3"
  proof-
    have A7: "R is-symmetric-inRELAT-2R3 fieldRELAT-1K3 R"
      using relat_2_def_11 sorry
    have A8: "P is-symmetric-inRELAT-2R3 fieldRELAT-1K3 P"
      using relat_2_def_11 sorry
    have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a inHIDDENR3 fieldRELAT-1K3 (P /\\XBOOLE-0K3 R) & b inHIDDENR3 fieldRELAT-1K3 (P /\\XBOOLE-0K3 R)) & [TARSKIK4 a,b ] inHIDDENR3 P /\\XBOOLE-0K3 R implies [TARSKIK4 b,a ] inHIDDENR3 P /\\XBOOLE-0K3 R"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      fix b assume [ty]: "b be objectHIDDENM1"
      assume A9: "a inHIDDENR3 fieldRELAT-1K3 (P /\\XBOOLE-0K3 R) & b inHIDDENR3 fieldRELAT-1K3 (P /\\XBOOLE-0K3 R)"
        and A10: "[TARSKIK4 a,b ] inHIDDENR3 P /\\XBOOLE-0K3 R"
      have A11: "[TARSKIK4 a,b ] inHIDDENR3 R"
        using A10 xboole_0_def_4 sorry
      have A12: "fieldRELAT-1K3 (P /\\XBOOLE-0K3 R) c=TARSKIR1 fieldRELAT-1K3 P /\\XBOOLE-0K3 fieldRELAT-1K3 R"
        using relat_1_th_19 sorry
      then have "a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R"
        using A9 xboole_0_def_4 sorry
      then have A13: "[TARSKIK4 b,a ] inHIDDENR3 R"
        using A7 A11 sorry
      have A14: "[TARSKIK4 a,b ] inHIDDENR3 P"
        using A10 xboole_0_def_4 sorry
      have "a inHIDDENR3 fieldRELAT-1K3 P & b inHIDDENR3 fieldRELAT-1K3 P"
        using A12 A9 xboole_0_def_4 sorry
      then have "[TARSKIK4 b,a ] inHIDDENR3 P"
        using A8 A14 sorry
      thus "[TARSKIK4 b,a ] inHIDDENR3 P /\\XBOOLE-0K3 R"
        using A13 xboole_0_def_4 sorry
    qed "sorry"
    thus "P /\\XBOOLE-0K3 R be symmetricRELAT-2V3"
      using relat_2_def_3 sorry
  qed
qed "sorry"

mtheorem relat_2_cl_16:
  mlet "P be symmetricRELAT-2V3\<bar>RelationRELAT-1M1", "R be symmetricRELAT-2V3\<bar>RelationRELAT-1M1"
"cluster P \\XBOOLE-0K4 R as-term-is symmetricRELAT-2V3"
proof
(*coherence*)
  show "P \\XBOOLE-0K4 R be symmetricRELAT-2V3"
  proof-
    have A15: "R is-symmetric-inRELAT-2R3 fieldRELAT-1K3 R"
      using relat_2_def_11 sorry
    have A16: "P is-symmetric-inRELAT-2R3 fieldRELAT-1K3 P"
      using relat_2_def_11 sorry
    have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds a inHIDDENR3 fieldRELAT-1K3 (P \\XBOOLE-0K4 R) & (b inHIDDENR3 fieldRELAT-1K3 (P \\XBOOLE-0K4 R) & [TARSKIK4 a,b ] inHIDDENR3 P \\XBOOLE-0K4 R) implies [TARSKIK4 b,a ] inHIDDENR3 P \\XBOOLE-0K4 R"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      fix b assume [ty]: "b be objectHIDDENM1"
      assume "a inHIDDENR3 fieldRELAT-1K3 (P \\XBOOLE-0K4 R)"
        and "b inHIDDENR3 fieldRELAT-1K3 (P \\XBOOLE-0K4 R)"
        and A17: "[TARSKIK4 a,b ] inHIDDENR3 P \\XBOOLE-0K4 R"
      have " not [TARSKIK4 a,b ] inHIDDENR3 R"
        using A17 xboole_0_def_5 sorry
      then have A18: "( not b inHIDDENR3 fieldRELAT-1K3 R or  not a inHIDDENR3 fieldRELAT-1K3 R) or  not [TARSKIK4 b,a ] inHIDDENR3 R"
        using A15 sorry
      have A19: "[TARSKIK4 a,b ] inHIDDENR3 P"
        using A17 xboole_0_def_5 sorry
      then have "a inHIDDENR3 fieldRELAT-1K3 P & b inHIDDENR3 fieldRELAT-1K3 P"
        using relat_1_th_15 sorry
      then have A20: "[TARSKIK4 b,a ] inHIDDENR3 P"
        using A16 A19 sorry
      have " not b inHIDDENR3 fieldRELAT-1K3 R or  not a inHIDDENR3 fieldRELAT-1K3 R implies  not [TARSKIK4 b,a ] inHIDDENR3 R"
        using relat_1_th_15 sorry
      thus "[TARSKIK4 b,a ] inHIDDENR3 P \\XBOOLE-0K4 R"
        using A20 A18 xboole_0_def_5 sorry
    qed "sorry"
    thus "P \\XBOOLE-0K4 R be symmetricRELAT-2V3"
      using relat_2_def_3 sorry
  qed
qed "sorry"

mtheorem relat_2_cl_17:
  mlet "R be asymmetricRELAT-2V5\<bar>RelationRELAT-1M1"
"cluster R ~RELAT-1K4 as-term-is asymmetricRELAT-2V5"
proof
(*coherence*)
  show "R ~RELAT-1K4 be asymmetricRELAT-2V5"
  proof-
    have A1: "R is-asymmetric-inRELAT-2R5 fieldRELAT-1K3 R"
      using relat_2_def_13 sorry
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 fieldRELAT-1K3 (R ~RELAT-1K4) & y inHIDDENR3 fieldRELAT-1K3 (R ~RELAT-1K4)) & [TARSKIK4 x,y ] inHIDDENR3 R ~RELAT-1K4 implies  not [TARSKIK4 y,x ] inHIDDENR3 R ~RELAT-1K4"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A2: "x inHIDDENR3 fieldRELAT-1K3 (R ~RELAT-1K4) & y inHIDDENR3 fieldRELAT-1K3 (R ~RELAT-1K4)"
        and A3: "[TARSKIK4 x,y ] inHIDDENR3 R ~RELAT-1K4"
      have A4: "[TARSKIK4 y,x ] inHIDDENR3 R"
        using A3 relat_1_def_7 sorry
      have "x inHIDDENR3 fieldRELAT-1K3 R & y inHIDDENR3 fieldRELAT-1K3 R"
        using A2 relat_1_th_21 sorry
      then have " not [TARSKIK4 x,y ] inHIDDENR3 R"
        using A1 A4 sorry
      thus " not [TARSKIK4 y,x ] inHIDDENR3 R ~RELAT-1K4"
        using relat_1_def_7 sorry
    qed "sorry"
    thus "R ~RELAT-1K4 be asymmetricRELAT-2V5"
      using relat_2_def_5 relat_2_def_13 sorry
  qed
qed "sorry"

mtheorem relat_2_cl_18:
  mlet "P be RelationRELAT-1M1", "R be asymmetricRELAT-2V5\<bar>RelationRELAT-1M1"
"cluster P /\\XBOOLE-0K3 R as-term-is asymmetricRELAT-2V5"
proof
(*coherence*)
  show "P /\\XBOOLE-0K3 R be asymmetricRELAT-2V5"
  proof-
    have A1: "R is-asymmetric-inRELAT-2R5 fieldRELAT-1K3 R"
      using relat_2_def_13 sorry
    have A2: "fieldRELAT-1K3 (P /\\XBOOLE-0K3 R) c=TARSKIR1 fieldRELAT-1K3 P /\\XBOOLE-0K3 fieldRELAT-1K3 R"
      using relat_1_th_19 sorry
    have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a inHIDDENR3 fieldRELAT-1K3 (P /\\XBOOLE-0K3 R) & b inHIDDENR3 fieldRELAT-1K3 (P /\\XBOOLE-0K3 R)) & [TARSKIK4 a,b ] inHIDDENR3 P /\\XBOOLE-0K3 R implies  not [TARSKIK4 b,a ] inHIDDENR3 P /\\XBOOLE-0K3 R"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      fix b assume [ty]: "b be objectHIDDENM1"
      assume A3: "a inHIDDENR3 fieldRELAT-1K3 (P /\\XBOOLE-0K3 R) & b inHIDDENR3 fieldRELAT-1K3 (P /\\XBOOLE-0K3 R)"
        and A4: "[TARSKIK4 a,b ] inHIDDENR3 P /\\XBOOLE-0K3 R"
      have A5: "[TARSKIK4 a,b ] inHIDDENR3 R"
        using A4 xboole_0_def_4 sorry
      have "a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R"
        using A2 A3 xboole_0_def_4 sorry
      then have " not [TARSKIK4 b,a ] inHIDDENR3 R"
        using A1 A5 sorry
      thus " not [TARSKIK4 b,a ] inHIDDENR3 P /\\XBOOLE-0K3 R"
        using xboole_0_def_4 sorry
    qed "sorry"
    thus "P /\\XBOOLE-0K3 R be asymmetricRELAT-2V5"
      using relat_2_def_5 relat_2_def_13 sorry
  qed
qed "sorry"

mtheorem relat_2_cl_19:
  mlet "P be RelationRELAT-1M1", "R be asymmetricRELAT-2V5\<bar>RelationRELAT-1M1"
"cluster R /\\XBOOLE-0K3 P as-term-is asymmetricRELAT-2V5"
proof
(*coherence*)
  show "R /\\XBOOLE-0K3 P be asymmetricRELAT-2V5"
     sorry
qed "sorry"

mtheorem relat_2_cl_20:
  mlet "P be asymmetricRELAT-2V5\<bar>RelationRELAT-1M1", "R be RelationRELAT-1M1"
"cluster P \\XBOOLE-0K4 R as-term-is asymmetricRELAT-2V5"
proof
(*coherence*)
  show "P \\XBOOLE-0K4 R be asymmetricRELAT-2V5"
  proof-
    have A1: "P is-asymmetric-inRELAT-2R5 fieldRELAT-1K3 P"
      using relat_2_def_13 sorry
    have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds a inHIDDENR3 fieldRELAT-1K3 (P \\XBOOLE-0K4 R) & (b inHIDDENR3 fieldRELAT-1K3 (P \\XBOOLE-0K4 R) & [TARSKIK4 a,b ] inHIDDENR3 P \\XBOOLE-0K4 R) implies  not [TARSKIK4 b,a ] inHIDDENR3 P \\XBOOLE-0K4 R"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      fix b assume [ty]: "b be objectHIDDENM1"
      assume "a inHIDDENR3 fieldRELAT-1K3 (P \\XBOOLE-0K4 R)"
        and "b inHIDDENR3 fieldRELAT-1K3 (P \\XBOOLE-0K4 R)"
        and A2: "[TARSKIK4 a,b ] inHIDDENR3 P \\XBOOLE-0K4 R"
      have A3: "[TARSKIK4 a,b ] inHIDDENR3 P"
        using A2 xboole_0_def_5 sorry
      then have "a inHIDDENR3 fieldRELAT-1K3 P & b inHIDDENR3 fieldRELAT-1K3 P"
        using relat_1_th_15 sorry
      then have " not [TARSKIK4 b,a ] inHIDDENR3 P"
        using A1 A3 sorry
      thus " not [TARSKIK4 b,a ] inHIDDENR3 P \\XBOOLE-0K4 R"
        using xboole_0_def_5 sorry
    qed "sorry"
    thus "P \\XBOOLE-0K4 R be asymmetricRELAT-2V5"
      using relat_2_def_5 relat_2_def_13 sorry
  qed
qed "sorry"

(*\$CT 8*)
mtheorem relat_2_th_22:
" for R be RelationRELAT-1M1 holds R be antisymmetricRELAT-2V4 iff R /\\XBOOLE-0K3 R ~RELAT-1K4 c=RELAT-1R2 idRELAT-1K7 (domRELAT-1K1 R)"
proof-
  have " for R be RelationRELAT-1M1 holds  not (R be antisymmetricRELAT-2V4 &  not R /\\XBOOLE-0K3 R ~RELAT-1K4 c=RELAT-1R2 idRELAT-1K7 (domRELAT-1K1 R)) &  not (R /\\XBOOLE-0K3 R ~RELAT-1K4 c=RELAT-1R2 idRELAT-1K7 (domRELAT-1K1 R) &  not R be antisymmetricRELAT-2V4)"
  proof(rule ballI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have A1: "R be antisymmetricRELAT-2V4 implies R /\\XBOOLE-0K3 R ~RELAT-1K4 c=RELAT-1R2 idRELAT-1K7 (domRELAT-1K1 R)"
    proof(rule impI)
      assume "R be antisymmetricRELAT-2V4"
      then have A2: "R is-antisymmetric-inRELAT-2R4 fieldRELAT-1K3 R"
         sorry
      have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R /\\XBOOLE-0K3 R ~RELAT-1K4 implies [TARSKIK4 a,b ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 R)"
      proof(rule ballI,rule ballI,rule impI)
        fix a assume [ty]: "a be objectHIDDENM1"
        fix b assume [ty]: "b be objectHIDDENM1"
        assume A3: "[TARSKIK4 a,b ] inHIDDENR3 R /\\XBOOLE-0K3 R ~RELAT-1K4"
        then have "[TARSKIK4 a,b ] inHIDDENR3 R ~RELAT-1K4"
          using xboole_0_def_4 sorry
        then have A4: "[TARSKIK4 b,a ] inHIDDENR3 R"
          using relat_1_def_7 sorry
        then have A5: "b inHIDDENR3 domRELAT-1K1 R"
          using xtuple_0_def_12 sorry
        have A6: "[TARSKIK4 a,b ] inHIDDENR3 R"
          using A3 xboole_0_def_4 sorry
        then have "a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R"
          using relat_1_th_15 sorry
        then have "a =HIDDENR1 b"
          using A2 A6 A4 sorry
        thus "[TARSKIK4 a,b ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 R)"
          using A5 relat_1_def_10 sorry
      qed "sorry"
      thus "R /\\XBOOLE-0K3 R ~RELAT-1K4 c=RELAT-1R2 idRELAT-1K7 (domRELAT-1K1 R)"
         sorry
    qed
    have "R /\\XBOOLE-0K3 R ~RELAT-1K4 c=RELAT-1R2 idRELAT-1K7 (domRELAT-1K1 R) implies R be antisymmetricRELAT-2V4"
    proof(rule impI)
      assume A7: "R /\\XBOOLE-0K3 R ~RELAT-1K4 c=RELAT-1R2 idRELAT-1K7 (domRELAT-1K1 R)"
      have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds a inHIDDENR3 fieldRELAT-1K3 R & (b inHIDDENR3 fieldRELAT-1K3 R & ([TARSKIK4 a,b ] inHIDDENR3 R & [TARSKIK4 b,a ] inHIDDENR3 R)) implies a =HIDDENR1 b"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix a assume [ty]: "a be objectHIDDENM1"
        fix b assume [ty]: "b be objectHIDDENM1"
        assume "a inHIDDENR3 fieldRELAT-1K3 R"
          and "b inHIDDENR3 fieldRELAT-1K3 R"
          and A8: "[TARSKIK4 a,b ] inHIDDENR3 R"
          and A9: "[TARSKIK4 b,a ] inHIDDENR3 R"
        have "[TARSKIK4 a,b ] inHIDDENR3 R ~RELAT-1K4"
          using A9 relat_1_def_7 sorry
        then have "[TARSKIK4 a,b ] inHIDDENR3 R /\\XBOOLE-0K3 R ~RELAT-1K4"
          using A8 xboole_0_def_4 sorry
        thus "a =HIDDENR1 b"
          using A7 relat_1_def_10 sorry
      qed "sorry"
      thus "R be antisymmetricRELAT-2V4"
        using relat_2_def_4 sorry
    qed
    thus " not (R be antisymmetricRELAT-2V4 &  not R /\\XBOOLE-0K3 R ~RELAT-1K4 c=RELAT-1R2 idRELAT-1K7 (domRELAT-1K1 R)) &  not (R /\\XBOOLE-0K3 R ~RELAT-1K4 c=RELAT-1R2 idRELAT-1K7 (domRELAT-1K1 R) &  not R be antisymmetricRELAT-2V4)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_2_cl_21:
  mlet "R be antisymmetricRELAT-2V4\<bar>RelationRELAT-1M1"
"cluster R ~RELAT-1K4 as-term-is antisymmetricRELAT-2V4"
proof
(*coherence*)
  show "R ~RELAT-1K4 be antisymmetricRELAT-2V4"
  proof-
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 fieldRELAT-1K3 (R ~RELAT-1K4) & y inHIDDENR3 fieldRELAT-1K3 (R ~RELAT-1K4)) & ([TARSKIK4 x,y ] inHIDDENR3 R ~RELAT-1K4 & [TARSKIK4 y,x ] inHIDDENR3 R ~RELAT-1K4) implies x =HIDDENR1 y"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A1: "x inHIDDENR3 fieldRELAT-1K3 (R ~RELAT-1K4) & y inHIDDENR3 fieldRELAT-1K3 (R ~RELAT-1K4)"
        and A2: "[TARSKIK4 x,y ] inHIDDENR3 R ~RELAT-1K4 & [TARSKIK4 y,x ] inHIDDENR3 R ~RELAT-1K4"
      have A3: "[TARSKIK4 y,x ] inHIDDENR3 R & [TARSKIK4 x,y ] inHIDDENR3 R"
        using A2 relat_1_def_7 sorry
      have "x inHIDDENR3 fieldRELAT-1K3 R & y inHIDDENR3 fieldRELAT-1K3 R"
        using A1 relat_1_th_21 sorry
      thus "x =HIDDENR1 y"
        using A3 relat_2_def_4 relat_2_def_12 sorry
    qed "sorry"
    thus "R ~RELAT-1K4 be antisymmetricRELAT-2V4"
      using relat_2_def_4 relat_2_def_12 sorry
  qed
qed "sorry"

mtheorem relat_2_cl_22:
  mlet "P be antisymmetricRELAT-2V4\<bar>RelationRELAT-1M1", "R be RelationRELAT-1M1"
"cluster P /\\XBOOLE-0K3 R as-term-is antisymmetricRELAT-2V4"
proof
(*coherence*)
  show "P /\\XBOOLE-0K3 R be antisymmetricRELAT-2V4"
  proof-
    have A1: "P is-antisymmetric-inRELAT-2R4 fieldRELAT-1K3 P"
      using relat_2_def_12 sorry
    have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a inHIDDENR3 fieldRELAT-1K3 (P /\\XBOOLE-0K3 R) & b inHIDDENR3 fieldRELAT-1K3 (P /\\XBOOLE-0K3 R)) & ([TARSKIK4 a,b ] inHIDDENR3 P /\\XBOOLE-0K3 R & [TARSKIK4 b,a ] inHIDDENR3 P /\\XBOOLE-0K3 R) implies a =HIDDENR1 b"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      fix b assume [ty]: "b be objectHIDDENM1"
      assume "a inHIDDENR3 fieldRELAT-1K3 (P /\\XBOOLE-0K3 R) & b inHIDDENR3 fieldRELAT-1K3 (P /\\XBOOLE-0K3 R)"
        and A2: "[TARSKIK4 a,b ] inHIDDENR3 P /\\XBOOLE-0K3 R"
        and A3: "[TARSKIK4 b,a ] inHIDDENR3 P /\\XBOOLE-0K3 R"
      have A4: "[TARSKIK4 b,a ] inHIDDENR3 P"
        using A3 xboole_0_def_4 sorry
      have A5: "[TARSKIK4 a,b ] inHIDDENR3 P"
        using A2 xboole_0_def_4 sorry
      then have "a inHIDDENR3 fieldRELAT-1K3 P & b inHIDDENR3 fieldRELAT-1K3 P"
        using relat_1_th_15 sorry
      thus "a =HIDDENR1 b"
        using A1 A5 A4 sorry
    qed "sorry"
    thus "P /\\XBOOLE-0K3 R be antisymmetricRELAT-2V4"
      using relat_2_def_4 relat_2_def_12 sorry
  qed
qed "sorry"

mtheorem relat_2_cl_23:
  mlet "P be antisymmetricRELAT-2V4\<bar>RelationRELAT-1M1", "R be RelationRELAT-1M1"
"cluster R /\\XBOOLE-0K3 P as-term-is antisymmetricRELAT-2V4"
proof
(*coherence*)
  show "R /\\XBOOLE-0K3 P be antisymmetricRELAT-2V4"
     sorry
qed "sorry"

mtheorem relat_2_cl_24:
  mlet "P be antisymmetricRELAT-2V4\<bar>RelationRELAT-1M1", "R be RelationRELAT-1M1"
"cluster P \\XBOOLE-0K4 R as-term-is antisymmetricRELAT-2V4"
proof
(*coherence*)
  show "P \\XBOOLE-0K4 R be antisymmetricRELAT-2V4"
  proof-
    have A6: "P is-antisymmetric-inRELAT-2R4 fieldRELAT-1K3 P"
      using relat_2_def_12 sorry
    have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a inHIDDENR3 fieldRELAT-1K3 (P \\XBOOLE-0K4 R) & b inHIDDENR3 fieldRELAT-1K3 (P \\XBOOLE-0K4 R)) & ([TARSKIK4 a,b ] inHIDDENR3 P \\XBOOLE-0K4 R & [TARSKIK4 b,a ] inHIDDENR3 P \\XBOOLE-0K4 R) implies a =HIDDENR1 b"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      fix b assume [ty]: "b be objectHIDDENM1"
      assume "a inHIDDENR3 fieldRELAT-1K3 (P \\XBOOLE-0K4 R) & b inHIDDENR3 fieldRELAT-1K3 (P \\XBOOLE-0K4 R)"
        and A7: "[TARSKIK4 a,b ] inHIDDENR3 P \\XBOOLE-0K4 R"
        and A8: "[TARSKIK4 b,a ] inHIDDENR3 P \\XBOOLE-0K4 R"
      have A9: "[TARSKIK4 b,a ] inHIDDENR3 P"
        using A8 xboole_0_def_5 sorry
      have A10: "[TARSKIK4 a,b ] inHIDDENR3 P"
        using A7 xboole_0_def_5 sorry
      then have "a inHIDDENR3 fieldRELAT-1K3 P & b inHIDDENR3 fieldRELAT-1K3 P"
        using relat_1_th_15 sorry
      thus "a =HIDDENR1 b"
        using A6 A10 A9 sorry
    qed "sorry"
    thus "P \\XBOOLE-0K4 R be antisymmetricRELAT-2V4"
      using relat_2_def_4 relat_2_def_12 sorry
  qed
qed "sorry"

mtheorem relat_2_cl_25:
  mlet "R be transitiveRELAT-2V8\<bar>RelationRELAT-1M1"
"cluster R ~RELAT-1K4 as-term-is transitiveRELAT-2V8"
proof
(*coherence*)
  show "R ~RELAT-1K4 be transitiveRELAT-2V8"
  proof-
    have A1: "R is-transitive-inRELAT-2R8 fieldRELAT-1K3 R"
      using relat_2_def_16 sorry
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds (x inHIDDENR3 fieldRELAT-1K3 (R ~RELAT-1K4) & y inHIDDENR3 fieldRELAT-1K3 (R ~RELAT-1K4)) & (z inHIDDENR3 fieldRELAT-1K3 (R ~RELAT-1K4) & ([TARSKIK4 x,y ] inHIDDENR3 R ~RELAT-1K4 & [TARSKIK4 y,z ] inHIDDENR3 R ~RELAT-1K4)) implies [TARSKIK4 x,z ] inHIDDENR3 R ~RELAT-1K4"
    proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      fix z assume [ty]: "z be objectHIDDENM1"
      assume A2: "x inHIDDENR3 fieldRELAT-1K3 (R ~RELAT-1K4) & y inHIDDENR3 fieldRELAT-1K3 (R ~RELAT-1K4)"
        and A3: "z inHIDDENR3 fieldRELAT-1K3 (R ~RELAT-1K4)"
        and A4: "[TARSKIK4 x,y ] inHIDDENR3 R ~RELAT-1K4"
        and A5: "[TARSKIK4 y,z ] inHIDDENR3 R ~RELAT-1K4"
      have A6: "x inHIDDENR3 fieldRELAT-1K3 R & y inHIDDENR3 fieldRELAT-1K3 R"
        using A2 relat_1_th_21 sorry
      have A7: "[TARSKIK4 y,x ] inHIDDENR3 R"
        using A4 relat_1_def_7 sorry
      have "z inHIDDENR3 fieldRELAT-1K3 R & [TARSKIK4 z,y ] inHIDDENR3 R"
        using A3 A5 relat_1_th_21 relat_1_def_7 sorry
      then have "[TARSKIK4 z,x ] inHIDDENR3 R"
        using A1 A6 A7 sorry
      thus "[TARSKIK4 x,z ] inHIDDENR3 R ~RELAT-1K4"
        using relat_1_def_7 sorry
    qed "sorry"
    thus "R ~RELAT-1K4 be transitiveRELAT-2V8"
      using relat_2_def_8 relat_2_def_16 sorry
  qed
qed "sorry"

mtheorem relat_2_cl_26:
  mlet "P be transitiveRELAT-2V8\<bar>RelationRELAT-1M1", "R be transitiveRELAT-2V8\<bar>RelationRELAT-1M1"
"cluster P /\\XBOOLE-0K3 R as-term-is transitiveRELAT-2V8"
proof
(*coherence*)
  show "P /\\XBOOLE-0K3 R be transitiveRELAT-2V8"
  proof-
    have A1: "R is-transitive-inRELAT-2R8 fieldRELAT-1K3 R"
      using relat_2_def_16 sorry
    have A2: "P is-transitive-inRELAT-2R8 fieldRELAT-1K3 P"
      using relat_2_def_16 sorry
    have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds ((a inHIDDENR3 fieldRELAT-1K3 (P /\\XBOOLE-0K3 R) & b inHIDDENR3 fieldRELAT-1K3 (P /\\XBOOLE-0K3 R)) & c inHIDDENR3 fieldRELAT-1K3 (P /\\XBOOLE-0K3 R)) & ([TARSKIK4 a,b ] inHIDDENR3 P /\\XBOOLE-0K3 R & [TARSKIK4 b,c ] inHIDDENR3 P /\\XBOOLE-0K3 R) implies [TARSKIK4 a,c ] inHIDDENR3 P /\\XBOOLE-0K3 R"
    proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      fix b assume [ty]: "b be objectHIDDENM1"
      fix c assume [ty]: "c be objectHIDDENM1"
      assume "(a inHIDDENR3 fieldRELAT-1K3 (P /\\XBOOLE-0K3 R) & b inHIDDENR3 fieldRELAT-1K3 (P /\\XBOOLE-0K3 R)) & c inHIDDENR3 fieldRELAT-1K3 (P /\\XBOOLE-0K3 R)"
        and A3: "[TARSKIK4 a,b ] inHIDDENR3 P /\\XBOOLE-0K3 R"
        and A4: "[TARSKIK4 b,c ] inHIDDENR3 P /\\XBOOLE-0K3 R"
      have A5: "[TARSKIK4 b,c ] inHIDDENR3 R"
        using A4 xboole_0_def_4 sorry
      then have A6: "c inHIDDENR3 fieldRELAT-1K3 R"
        using relat_1_th_15 sorry
      have A7: "[TARSKIK4 a,b ] inHIDDENR3 R"
        using A3 xboole_0_def_4 sorry
      then have "a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R"
        using relat_1_th_15 sorry
      then have A8: "[TARSKIK4 a,c ] inHIDDENR3 R"
        using A1 A7 A5 A6 sorry
      have A9: "[TARSKIK4 b,c ] inHIDDENR3 P"
        using A4 xboole_0_def_4 sorry
      then have A10: "c inHIDDENR3 fieldRELAT-1K3 P"
        using relat_1_th_15 sorry
      have A11: "[TARSKIK4 a,b ] inHIDDENR3 P"
        using A3 xboole_0_def_4 sorry
      then have "a inHIDDENR3 fieldRELAT-1K3 P & b inHIDDENR3 fieldRELAT-1K3 P"
        using relat_1_th_15 sorry
      then have "[TARSKIK4 a,c ] inHIDDENR3 P"
        using A2 A11 A9 A10 sorry
      thus "[TARSKIK4 a,c ] inHIDDENR3 P /\\XBOOLE-0K3 R"
        using A8 xboole_0_def_4 sorry
    qed "sorry"
    thus "P /\\XBOOLE-0K3 R be transitiveRELAT-2V8"
      using relat_2_def_8 relat_2_def_16 sorry
  qed
qed "sorry"

(*\$CT 4*)
mtheorem relat_2_th_27:
" for R be RelationRELAT-1M1 holds R be transitiveRELAT-2V8 iff R *RELAT-1K6 R c=RELAT-1R2 R"
proof-
  have " for R be RelationRELAT-1M1 holds (R be transitiveRELAT-2V8 implies R *RELAT-1K6 R c=RELAT-1R2 R) & (R *RELAT-1K6 R c=RELAT-1R2 R implies R be transitiveRELAT-2V8)"
  proof(rule ballI,rule conjMI,rule impI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "R be transitiveRELAT-2V8 implies R *RELAT-1K6 R c=RELAT-1R2 R"
    proof(rule impI)
      assume "R be transitiveRELAT-2V8"
      then have A1: "R is-transitive-inRELAT-2R8 fieldRELAT-1K3 R"
         sorry
      have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R *RELAT-1K6 R implies [TARSKIK4 a,b ] inHIDDENR3 R"
      proof(rule ballI,rule ballI,rule impI)
        fix a assume [ty]: "a be objectHIDDENM1"
        fix b assume [ty]: "b be objectHIDDENM1"
        assume "[TARSKIK4 a,b ] inHIDDENR3 R *RELAT-1K6 R"
        then obtain c where
          [ty]:"c be objectHIDDENM1" and 
          A2: "[TARSKIK4 a,c ] inHIDDENR3 R"and A3: "[TARSKIK4 c,b ] inHIDDENR3 R"
          using relat_1_def_8 sorry
        have A4: "c inHIDDENR3 fieldRELAT-1K3 R"
          using A2 relat_1_th_15 sorry
        have "a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R"
          using A2 A3 relat_1_th_15 sorry
        thus "[TARSKIK4 a,b ] inHIDDENR3 R"
          using A1 A2 A3 A4 sorry
      qed "sorry"
      thus "R *RELAT-1K6 R c=RELAT-1R2 R"
         sorry
    qed
    assume A5: "R *RELAT-1K6 R c=RELAT-1R2 R"
    have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds (a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R) & c inHIDDENR3 fieldRELAT-1K3 R implies ([TARSKIK4 a,b ] inHIDDENR3 R & [TARSKIK4 b,c ] inHIDDENR3 R implies [TARSKIK4 a,c ] inHIDDENR3 R)"
    proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      fix b assume [ty]: "b be objectHIDDENM1"
      fix c assume [ty]: "c be objectHIDDENM1"
      assume "(a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R) & c inHIDDENR3 fieldRELAT-1K3 R"
      assume "[TARSKIK4 a,b ] inHIDDENR3 R & [TARSKIK4 b,c ] inHIDDENR3 R"
      then have "[TARSKIK4 a,c ] inHIDDENR3 R *RELAT-1K6 R"
        using relat_1_def_8 sorry
      thus "[TARSKIK4 a,c ] inHIDDENR3 R"
        using A5 sorry
    qed "sorry"
    thus "R be transitiveRELAT-2V8"
      using relat_2_def_8 relat_2_def_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_2_th_28:
" for R be RelationRELAT-1M1 holds R be connectedRELAT-2V6 iff [:ZFMISC-1K2 fieldRELAT-1K3 R,fieldRELAT-1K3 R :] \\XBOOLE-0K4 idRELAT-1K7 (fieldRELAT-1K3 R) c=RELAT-1R2 R \\/XBOOLE-0K2 R ~RELAT-1K4"
proof-
  have " for R be RelationRELAT-1M1 holds (R be connectedRELAT-2V6 implies [:ZFMISC-1K2 fieldRELAT-1K3 R,fieldRELAT-1K3 R :] \\XBOOLE-0K4 idRELAT-1K7 (fieldRELAT-1K3 R) c=RELAT-1R2 R \\/XBOOLE-0K2 R ~RELAT-1K4) & ([:ZFMISC-1K2 fieldRELAT-1K3 R,fieldRELAT-1K3 R :] \\XBOOLE-0K4 idRELAT-1K7 (fieldRELAT-1K3 R) c=RELAT-1R2 R \\/XBOOLE-0K2 R ~RELAT-1K4 implies R be connectedRELAT-2V6)"
  proof(rule ballI,rule conjMI,rule impI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "R be connectedRELAT-2V6 implies [:ZFMISC-1K2 fieldRELAT-1K3 R,fieldRELAT-1K3 R :] \\XBOOLE-0K4 idRELAT-1K7 (fieldRELAT-1K3 R) c=RELAT-1R2 R \\/XBOOLE-0K2 R ~RELAT-1K4"
    proof(rule impI)
      assume "R be connectedRELAT-2V6"
      then have A1: "R is-connected-inRELAT-2R6 fieldRELAT-1K3 R"
         sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 [:ZFMISC-1K2 fieldRELAT-1K3 R,fieldRELAT-1K3 R :] \\XBOOLE-0K4 idRELAT-1K7 (fieldRELAT-1K3 R) implies x inHIDDENR3 R \\/XBOOLE-0K2 R ~RELAT-1K4"
      proof(rule ballI)
        fix x assume [ty]: "x be objectHIDDENM1"
        have "x inHIDDENR3 [:ZFMISC-1K2 fieldRELAT-1K3 R,fieldRELAT-1K3 R :] \\XBOOLE-0K4 idRELAT-1K7 (fieldRELAT-1K3 R) implies x inHIDDENR3 R \\/XBOOLE-0K2 R ~RELAT-1K4"
        proof(rule impI)
          assume A2: "x inHIDDENR3 [:ZFMISC-1K2 fieldRELAT-1K3 R,fieldRELAT-1K3 R :] \\XBOOLE-0K4 idRELAT-1K7 (fieldRELAT-1K3 R)"
          then have "x inHIDDENR3 [:ZFMISC-1K2 fieldRELAT-1K3 R,fieldRELAT-1K3 R :]"
            using xboole_0_def_5 sorry
          then obtain y z where
            [ty]:"y be objectHIDDENM1" "z be objectHIDDENM1" and 
            A3: "y inHIDDENR3 fieldRELAT-1K3 R"and A4: "z inHIDDENR3 fieldRELAT-1K3 R"and A5: "x =HIDDENR1 [TARSKIK4 y,z ]"
            using zfmisc_1_def_2 sorry
          have " not x inHIDDENR3 idRELAT-1K7 (fieldRELAT-1K3 R)"
            using A2 xboole_0_def_5 sorry
          then have "y <>HIDDENR2 z"
            using A3 A5 relat_1_def_10 sorry
          then have "[TARSKIK4 y,z ] inHIDDENR3 R or [TARSKIK4 z,y ] inHIDDENR3 R"
            using A1 A3 A4 sorry
          then have "[TARSKIK4 y,z ] inHIDDENR3 R or [TARSKIK4 y,z ] inHIDDENR3 R ~RELAT-1K4"
            using relat_1_def_7 sorry
          thus "x inHIDDENR3 R \\/XBOOLE-0K2 R ~RELAT-1K4"
            using A5 xboole_0_def_3 sorry
        qed
        thus "x inHIDDENR3 [:ZFMISC-1K2 fieldRELAT-1K3 R,fieldRELAT-1K3 R :] \\XBOOLE-0K4 idRELAT-1K7 (fieldRELAT-1K3 R) implies x inHIDDENR3 R \\/XBOOLE-0K2 R ~RELAT-1K4"
           sorry
      qed "sorry"
      thus "[:ZFMISC-1K2 fieldRELAT-1K3 R,fieldRELAT-1K3 R :] \\XBOOLE-0K4 idRELAT-1K7 (fieldRELAT-1K3 R) c=RELAT-1R2 R \\/XBOOLE-0K2 R ~RELAT-1K4"
         sorry
    qed
    assume A6: "[:ZFMISC-1K2 fieldRELAT-1K3 R,fieldRELAT-1K3 R :] \\XBOOLE-0K4 idRELAT-1K7 (fieldRELAT-1K3 R) c=RELAT-1R2 R \\/XBOOLE-0K2 R ~RELAT-1K4"
    have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  not ((((a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R) &  not a <>HIDDENR2 b) &  not [TARSKIK4 a,b ] inHIDDENR3 R) &  not [TARSKIK4 b,a ] inHIDDENR3 R)"
    proof(rule ballI,rule ballI)
      fix a assume [ty]: "a be objectHIDDENM1"
      fix b assume [ty]: "b be objectHIDDENM1"
      have "[TARSKIK4 a,b ] inHIDDENR3 [:ZFMISC-1K2 fieldRELAT-1K3 R,fieldRELAT-1K3 R :] \\XBOOLE-0K4 idRELAT-1K7 (fieldRELAT-1K3 R) implies [TARSKIK4 a,b ] inHIDDENR3 R \\/XBOOLE-0K2 R ~RELAT-1K4"
        using A6 sorry
      then have "[TARSKIK4 a,b ] inHIDDENR3 [:ZFMISC-1K2 fieldRELAT-1K3 R,fieldRELAT-1K3 R :] &  not [TARSKIK4 a,b ] inHIDDENR3 idRELAT-1K7 (fieldRELAT-1K3 R) implies [TARSKIK4 a,b ] inHIDDENR3 R \\/XBOOLE-0K2 R ~RELAT-1K4"
        using xboole_0_def_5 sorry
      then have "(a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R) & a <>HIDDENR2 b implies [TARSKIK4 a,b ] inHIDDENR3 R or [TARSKIK4 a,b ] inHIDDENR3 R ~RELAT-1K4"
        using relat_1_def_10 xboole_0_def_3 zfmisc_1_th_87 sorry
      thus " not ((((a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R) &  not a <>HIDDENR2 b) &  not [TARSKIK4 a,b ] inHIDDENR3 R) &  not [TARSKIK4 b,a ] inHIDDENR3 R)"
        using relat_1_def_7 sorry
    qed "sorry"
    thus "R be connectedRELAT-2V6"
      using relat_2_def_6 relat_2_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_2_cl_27:
"cluster strongly-connectedRELAT-2V7 also-is connectedRELAT-2V6\<bar>reflexiveRELAT-2V1 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be strongly-connectedRELAT-2V7 implies it be connectedRELAT-2V6\<bar>reflexiveRELAT-2V1"
  proof-
    have " for R be RelationRELAT-1M1 holds  not (R be strongly-connectedRELAT-2V7 &  not (R be connectedRELAT-2V6 & R be reflexiveRELAT-2V1))"
    proof(rule ballI)
      fix R assume [ty]: "R be RelationRELAT-1M1"
      have "R is-strongly-connected-inRELAT-2R7 fieldRELAT-1K3 R implies R be connectedRELAT-2V6 & R be reflexiveRELAT-2V1"
      proof(rule impI,rule conjMI)
        assume A1: "R is-strongly-connected-inRELAT-2R7 fieldRELAT-1K3 R"
        then have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 fieldRELAT-1K3 R & y inHIDDENR3 fieldRELAT-1K3 R) & x <>HIDDENR2 y implies [TARSKIK4 x,y ] inHIDDENR3 R or [TARSKIK4 y,x ] inHIDDENR3 R"
           sorry
        thus "R be connectedRELAT-2V6"
          using relat_2_def_6 sorry
        have " for x be objectHIDDENM1 holds  not (x inHIDDENR3 fieldRELAT-1K3 R &  not [TARSKIK4 x,x ] inHIDDENR3 R)"
        proof(rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          show " not (x inHIDDENR3 fieldRELAT-1K3 R &  not [TARSKIK4 x,x ] inHIDDENR3 R)"
            using A1 sorry
        qed "sorry"
        thus "R be reflexiveRELAT-2V1"
          using relat_2_def_1 relat_2_def_9 sorry
      qed
      thus " not (R be strongly-connectedRELAT-2V7 &  not (R be connectedRELAT-2V6 & R be reflexiveRELAT-2V1))"
        using relat_2_def_15 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

(*\$CT*)
mtheorem relat_2_th_30:
" for R be RelationRELAT-1M1 holds R be strongly-connectedRELAT-2V7 iff [:ZFMISC-1K2 fieldRELAT-1K3 R,fieldRELAT-1K3 R :] =RELAT-1R1 R \\/XBOOLE-0K2 R ~RELAT-1K4"
proof-
  have " for R be RelationRELAT-1M1 holds (R be strongly-connectedRELAT-2V7 implies [:ZFMISC-1K2 fieldRELAT-1K3 R,fieldRELAT-1K3 R :] =RELAT-1R1 R \\/XBOOLE-0K2 R ~RELAT-1K4) & ([:ZFMISC-1K2 fieldRELAT-1K3 R,fieldRELAT-1K3 R :] =RELAT-1R1 R \\/XBOOLE-0K2 R ~RELAT-1K4 implies R be strongly-connectedRELAT-2V7)"
  proof(rule ballI,rule conjMI,rule impI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "R be strongly-connectedRELAT-2V7 implies [:ZFMISC-1K2 fieldRELAT-1K3 R,fieldRELAT-1K3 R :] =RELAT-1R1 R \\/XBOOLE-0K2 R ~RELAT-1K4"
    proof(rule impI)
      assume A1: "R be strongly-connectedRELAT-2V7"
      have " for x be objectHIDDENM1 holds x inHIDDENR3 [:ZFMISC-1K2 fieldRELAT-1K3 R,fieldRELAT-1K3 R :] iff x inHIDDENR3 R \\/XBOOLE-0K2 R ~RELAT-1K4"
      proof(rule ballI)
        fix x assume [ty]: "x be objectHIDDENM1"
        have A2: "x inHIDDENR3 R \\/XBOOLE-0K2 R ~RELAT-1K4 implies x inHIDDENR3 [:ZFMISC-1K2 fieldRELAT-1K3 R,fieldRELAT-1K3 R :]"
        proof(rule impI)
          assume A3: "x inHIDDENR3 R \\/XBOOLE-0K2 R ~RELAT-1K4"
          then obtain y z where
            [ty]:"y be objectHIDDENM1" "z be objectHIDDENM1" and 
            A4: "x =HIDDENR1 [TARSKIK4 y,z ]"
            using relat_1_def_1 sorry
          have "[TARSKIK4 y,z ] inHIDDENR3 R or [TARSKIK4 y,z ] inHIDDENR3 R ~RELAT-1K4"
            using A3 A4 xboole_0_def_3 sorry
          then have "[TARSKIK4 y,z ] inHIDDENR3 R or [TARSKIK4 z,y ] inHIDDENR3 R"
            using relat_1_def_7 sorry
          then have "y inHIDDENR3 fieldRELAT-1K3 R & z inHIDDENR3 fieldRELAT-1K3 R"
            using relat_1_th_15 sorry
          thus "x inHIDDENR3 [:ZFMISC-1K2 fieldRELAT-1K3 R,fieldRELAT-1K3 R :]"
            using A4 zfmisc_1_th_87 sorry
        qed
        have "x inHIDDENR3 [:ZFMISC-1K2 fieldRELAT-1K3 R,fieldRELAT-1K3 R :] implies x inHIDDENR3 R \\/XBOOLE-0K2 R ~RELAT-1K4"
        proof(rule impI)
          assume "x inHIDDENR3 [:ZFMISC-1K2 fieldRELAT-1K3 R,fieldRELAT-1K3 R :]"
          then obtain y z where
            [ty]:"y be objectHIDDENM1" "z be objectHIDDENM1" and 
            A5: "y inHIDDENR3 fieldRELAT-1K3 R & z inHIDDENR3 fieldRELAT-1K3 R"and A6: "x =HIDDENR1 [TARSKIK4 y,z ]"
            using zfmisc_1_def_2 sorry
          have "[TARSKIK4 y,z ] inHIDDENR3 R or [TARSKIK4 z,y ] inHIDDENR3 R"
            using A1 A5 relat_2_def_7 sorry
          then have "[TARSKIK4 y,z ] inHIDDENR3 R or [TARSKIK4 y,z ] inHIDDENR3 R ~RELAT-1K4"
            using relat_1_def_7 sorry
          thus "x inHIDDENR3 R \\/XBOOLE-0K2 R ~RELAT-1K4"
            using A6 xboole_0_def_3 sorry
        qed
        thus "x inHIDDENR3 [:ZFMISC-1K2 fieldRELAT-1K3 R,fieldRELAT-1K3 R :] iff x inHIDDENR3 R \\/XBOOLE-0K2 R ~RELAT-1K4"
          using A2 sorry
      qed "sorry"
      thus "[:ZFMISC-1K2 fieldRELAT-1K3 R,fieldRELAT-1K3 R :] =RELAT-1R1 R \\/XBOOLE-0K2 R ~RELAT-1K4"
         sorry
    qed
    assume A7: "[:ZFMISC-1K2 fieldRELAT-1K3 R,fieldRELAT-1K3 R :] =RELAT-1R1 R \\/XBOOLE-0K2 R ~RELAT-1K4"
    have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  not (((a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R) &  not [TARSKIK4 a,b ] inHIDDENR3 R) &  not [TARSKIK4 b,a ] inHIDDENR3 R)"
    proof(rule ballI,rule ballI)
      fix a assume [ty]: "a be objectHIDDENM1"
      fix b assume [ty]: "b be objectHIDDENM1"
      have "a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R implies [TARSKIK4 a,b ] inHIDDENR3 R \\/XBOOLE-0K2 R ~RELAT-1K4"
        using A7 zfmisc_1_th_87 sorry
      then have "a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R implies [TARSKIK4 a,b ] inHIDDENR3 R or [TARSKIK4 a,b ] inHIDDENR3 R ~RELAT-1K4"
        using xboole_0_def_3 sorry
      thus " not (((a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R) &  not [TARSKIK4 a,b ] inHIDDENR3 R) &  not [TARSKIK4 b,a ] inHIDDENR3 R)"
        using relat_1_def_7 sorry
    qed "sorry"
    thus "R be strongly-connectedRELAT-2V7"
      using relat_2_def_7 relat_2_def_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relat_2_th_31:
" for R be RelationRELAT-1M1 holds R be transitiveRELAT-2V8 iff ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R & [TARSKIK4 y,z ] inHIDDENR3 R implies [TARSKIK4 x,z ] inHIDDENR3 R)"
proof-
  have " for R be RelationRELAT-1M1 holds (R be transitiveRELAT-2V8 implies ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R & [TARSKIK4 y,z ] inHIDDENR3 R implies [TARSKIK4 x,z ] inHIDDENR3 R)) & (( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R & [TARSKIK4 y,z ] inHIDDENR3 R implies [TARSKIK4 x,z ] inHIDDENR3 R) implies R be transitiveRELAT-2V8)"
  proof(rule ballI,rule conjMI,rule impI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "R be transitiveRELAT-2V8 implies ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R & [TARSKIK4 y,z ] inHIDDENR3 R implies [TARSKIK4 x,z ] inHIDDENR3 R)"
    proof(rule impI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
      assume A1: "R be transitiveRELAT-2V8"
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      fix z assume [ty]: "z be objectHIDDENM1"
      assume A2: "[TARSKIK4 x,y ] inHIDDENR3 R"
        and A3: "[TARSKIK4 y,z ] inHIDDENR3 R"
      have A4: "z inHIDDENR3 fieldRELAT-1K3 R"
        using A3 relat_1_th_15 sorry
      have "x inHIDDENR3 fieldRELAT-1K3 R & y inHIDDENR3 fieldRELAT-1K3 R"
        using A2 relat_1_th_15 sorry
      thus "[TARSKIK4 x,z ] inHIDDENR3 R"
        using A1 A2 A3 A4 relat_2_def_8 sorry
    qed "sorry"
    assume " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R & [TARSKIK4 y,z ] inHIDDENR3 R implies [TARSKIK4 x,z ] inHIDDENR3 R"
    then have Cut983: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds (((x inHIDDENR3 fieldRELAT-1K3 R & y inHIDDENR3 fieldRELAT-1K3 R) & z inHIDDENR3 fieldRELAT-1K3 R) & [TARSKIK4 x,y ] inHIDDENR3 R) & [TARSKIK4 y,z ] inHIDDENR3 R implies [TARSKIK4 x,z ] inHIDDENR3 R"
       sorry
    have "R is-transitive-inRELAT-2R8 fieldRELAT-1K3 R"
    proof-
      show "R is-transitive-inRELAT-2R8 fieldRELAT-1K3 R"
        using Cut983 sorry
    qed
    thus "R be transitiveRELAT-2V8"
      using relat_2_def_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
