theory limfunc4
  imports limfunc3
begin
(*begin*)
reserve r, r1, r2, g, g1, g2, x0 for "RealXREAL-0M1"
reserve f1, f2 for "PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
mlemma limfunc4_lm_1:
" for r be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g implies r -XCMPLX-0K6 g <XXREAL-0R3 r & r <XXREAL-0R3 r +XCMPLX-0K2 g"
proof-
  have " for r be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g implies r -XCMPLX-0K6 g <XXREAL-0R3 r &  not r <XXREAL-0R3 r +XCMPLX-0K2 g"
  proof(rule ballI,rule ballI,rule impI,rule conjMI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix g assume [ty]: "g be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 g"
    then have "r -XCMPLX-0K6 g <XXREAL-0R3 r -XCMPLX-0K6 0NUMBERSK6"
      using xreal_1_th_15 sorry
    thus "r -XCMPLX-0K6 g <XXREAL-0R3 r"
       sorry
    have "r +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 r +XCMPLX-0K2 g"
      using A1 xreal_1_th_8 sorry
    thus " not r <XXREAL-0R3 r +XCMPLX-0K2 g"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma limfunc4_lm_2:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for s be Real-SequenceSEQ-1M1 holds rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for s be Real-SequenceSEQ-1M1 holds rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    assume A1: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    have A2: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      using relat_1_th_25 sorry
    thus "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      using A1 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s)"
      then obtain n where
        [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
        A3: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
        using funct_2_th_113 sorry
      have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngFUNCT-1K2 s"
        using valued_0_th_28 sorry
      then have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A1 funct_1_th_11 sorry
      thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A1 A2 A3 funct_2_th_108 xboole_1_th_1 sorry
    qed "sorry"
    thus "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_1:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for s be Real-SequenceSEQ-1M1 holds  for X be setHIDDENM2 holds rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> X implies (((rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) & rngFUNCT-1K2 s c=TARSKIR1 X) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> X) & rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for s be Real-SequenceSEQ-1M1 holds  for X be setHIDDENM2 holds rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> X implies (rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) & rngFUNCT-1K2 s c=TARSKIR1 X) & (rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & (rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> X & rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI,rule conjMI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    fix X assume [ty]: "X be setHIDDENM2"
    assume "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> X"
    thus A1: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) & rngFUNCT-1K2 s c=TARSKIR1 X"
      using xboole_1_th_18 sorry
    have A2: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      using relat_1_th_25 sorry
    thus "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      using A1 sorry
    thus "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> X"
      using A1 xboole_1_th_19 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s)"
      then obtain n where
        [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
        A3: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
        using funct_2_th_113 sorry
      have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngFUNCT-1K2 s"
        using valued_0_th_28 sorry
      then have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A1 funct_1_th_11 sorry
      thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A1 A2 A3 funct_2_th_108 xboole_1_th_1 sorry
    qed "sorry"
    thus "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_2:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for s be Real-SequenceSEQ-1M1 holds  for X be setHIDDENM2 holds rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> X implies ((rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> X) & rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for s be Real-SequenceSEQ-1M1 holds  for X be setHIDDENM2 holds rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> X implies rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) & (rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & (rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> X & rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI,rule conjMI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> X"
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      using xboole_1_th_36 sorry
    thus A2: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      using A1 sorry
    have A3: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      using relat_1_th_25 sorry
    thus A4: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      using A2 sorry
    show "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> X"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 s implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> X"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A5: "x inHIDDENR3 rngFUNCT-1K2 s"
        then have " not x inHIDDENR3 X"
          using A1 xboole_0_def_5 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> X"
          using A4 A5 xboole_0_def_5 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> X"
        using tarski_def_3 sorry
    qed
    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s)"
      then obtain n where
        [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
        A6: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
        using funct_2_th_113 sorry
      have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngFUNCT-1K2 s"
        using valued_0_th_28 sorry
      then have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A2 funct_1_th_11 sorry
      thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A2 A3 A6 funct_2_th_108 xboole_1_th_1 sorry
    qed "sorry"
    thus "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_3:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in+infty-to+inftyLIMFUNC1V4 & f2 be divergent-in+infty-to+inftyLIMFUNC1V4) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in+infty-to+inftyLIMFUNC1V4"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in+infty-to+inftyLIMFUNC1V4 & (f2 be divergent-in+infty-to+inftyLIMFUNC1V4 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in+infty-to+inftyLIMFUNC1V4"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be divergent-in+infty-to+inftyLIMFUNC1V4"
      and A2: "f2 be divergent-in+infty-to+inftyLIMFUNC1V4"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    have " for s be Real-SequenceSEQ-1M1 holds s be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A4: "s be divergent-to+inftyLIMFUNC1V1"
        and A5: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A5 limfunc4_lm_2 sorry
      then have A6: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A1 A4 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A5 limfunc4_lm_2 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) be divergent-to+inftyLIMFUNC1V1"
        using A2 A6 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A5 valued_0_th_31 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in+infty-to+inftyLIMFUNC1V4"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_4:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in+infty-to+inftyLIMFUNC1V4 & f2 be divergent-in+infty-to-inftyLIMFUNC1V5) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in+infty-to-inftyLIMFUNC1V5"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in+infty-to+inftyLIMFUNC1V4 & (f2 be divergent-in+infty-to-inftyLIMFUNC1V5 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in+infty-to-inftyLIMFUNC1V5"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be divergent-in+infty-to+inftyLIMFUNC1V4"
      and A2: "f2 be divergent-in+infty-to-inftyLIMFUNC1V5"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    have " for s be Real-SequenceSEQ-1M1 holds s be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A4: "s be divergent-to+inftyLIMFUNC1V1"
        and A5: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A5 limfunc4_lm_2 sorry
      then have A6: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A1 A4 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A5 limfunc4_lm_2 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) be divergent-to-inftyLIMFUNC1V2"
        using A2 A6 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A5 valued_0_th_31 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in+infty-to-inftyLIMFUNC1V5"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_5:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in+infty-to-inftyLIMFUNC1V5 & f2 be divergent-in-infty-to+inftyLIMFUNC1V7) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in+infty-to+inftyLIMFUNC1V4"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in+infty-to-inftyLIMFUNC1V5 & (f2 be divergent-in-infty-to+inftyLIMFUNC1V7 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in+infty-to+inftyLIMFUNC1V4"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be divergent-in+infty-to-inftyLIMFUNC1V5"
      and A2: "f2 be divergent-in-infty-to+inftyLIMFUNC1V7"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    have " for s be Real-SequenceSEQ-1M1 holds s be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A4: "s be divergent-to+inftyLIMFUNC1V1"
        and A5: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A5 limfunc4_lm_2 sorry
      then have A6: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A1 A4 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A5 limfunc4_lm_2 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) be divergent-to+inftyLIMFUNC1V1"
        using A2 A6 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A5 valued_0_th_31 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in+infty-to+inftyLIMFUNC1V4"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_6:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in+infty-to-inftyLIMFUNC1V5 & f2 be divergent-in-infty-to-inftyLIMFUNC1V8) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in+infty-to-inftyLIMFUNC1V5"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in+infty-to-inftyLIMFUNC1V5 & (f2 be divergent-in-infty-to-inftyLIMFUNC1V8 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in+infty-to-inftyLIMFUNC1V5"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be divergent-in+infty-to-inftyLIMFUNC1V5"
      and A2: "f2 be divergent-in-infty-to-inftyLIMFUNC1V8"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    have " for s be Real-SequenceSEQ-1M1 holds s be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A4: "s be divergent-to+inftyLIMFUNC1V1"
        and A5: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A5 limfunc4_lm_2 sorry
      then have A6: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A1 A4 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A5 limfunc4_lm_2 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) be divergent-to-inftyLIMFUNC1V2"
        using A2 A6 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A5 valued_0_th_31 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in+infty-to-inftyLIMFUNC1V5"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_7:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in-infty-to+inftyLIMFUNC1V7 & f2 be divergent-in+infty-to+inftyLIMFUNC1V4) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in-infty-to+inftyLIMFUNC1V7"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in-infty-to+inftyLIMFUNC1V7 & (f2 be divergent-in+infty-to+inftyLIMFUNC1V4 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in-infty-to+inftyLIMFUNC1V7"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be divergent-in-infty-to+inftyLIMFUNC1V7"
      and A2: "f2 be divergent-in+infty-to+inftyLIMFUNC1V4"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    have " for s be Real-SequenceSEQ-1M1 holds s be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A4: "s be divergent-to-inftyLIMFUNC1V2"
        and A5: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A5 limfunc4_lm_2 sorry
      then have A6: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A1 A4 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A5 limfunc4_lm_2 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) be divergent-to+inftyLIMFUNC1V1"
        using A2 A6 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A5 valued_0_th_31 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in-infty-to+inftyLIMFUNC1V7"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_8:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in-infty-to+inftyLIMFUNC1V7 & f2 be divergent-in+infty-to-inftyLIMFUNC1V5) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in-infty-to-inftyLIMFUNC1V8"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in-infty-to+inftyLIMFUNC1V7 & (f2 be divergent-in+infty-to-inftyLIMFUNC1V5 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in-infty-to-inftyLIMFUNC1V8"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be divergent-in-infty-to+inftyLIMFUNC1V7"
      and A2: "f2 be divergent-in+infty-to-inftyLIMFUNC1V5"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    have " for s be Real-SequenceSEQ-1M1 holds s be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A4: "s be divergent-to-inftyLIMFUNC1V2"
        and A5: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A5 limfunc4_lm_2 sorry
      then have A6: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A1 A4 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A5 limfunc4_lm_2 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) be divergent-to-inftyLIMFUNC1V2"
        using A2 A6 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A5 valued_0_th_31 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in-infty-to-inftyLIMFUNC1V8"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_9:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in-infty-to-inftyLIMFUNC1V8 & f2 be divergent-in-infty-to+inftyLIMFUNC1V7) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in-infty-to+inftyLIMFUNC1V7"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in-infty-to-inftyLIMFUNC1V8 & (f2 be divergent-in-infty-to+inftyLIMFUNC1V7 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in-infty-to+inftyLIMFUNC1V7"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be divergent-in-infty-to-inftyLIMFUNC1V8"
      and A2: "f2 be divergent-in-infty-to+inftyLIMFUNC1V7"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    have " for s be Real-SequenceSEQ-1M1 holds s be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A4: "s be divergent-to-inftyLIMFUNC1V2"
        and A5: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A5 limfunc4_lm_2 sorry
      then have A6: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A1 A4 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A5 limfunc4_lm_2 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) be divergent-to+inftyLIMFUNC1V1"
        using A2 A6 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A5 valued_0_th_31 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in-infty-to+inftyLIMFUNC1V7"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_10:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in-infty-to-inftyLIMFUNC1V8 & f2 be divergent-in-infty-to-inftyLIMFUNC1V8) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in-infty-to-inftyLIMFUNC1V8"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in-infty-to-inftyLIMFUNC1V8 & (f2 be divergent-in-infty-to-inftyLIMFUNC1V8 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in-infty-to-inftyLIMFUNC1V8"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be divergent-in-infty-to-inftyLIMFUNC1V8"
      and A2: "f2 be divergent-in-infty-to-inftyLIMFUNC1V8"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    have " for s be Real-SequenceSEQ-1M1 holds s be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A4: "s be divergent-to-inftyLIMFUNC1V2"
        and A5: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A5 limfunc4_lm_2 sorry
      then have A6: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A1 A4 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A5 limfunc4_lm_2 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) be divergent-to-inftyLIMFUNC1V2"
        using A2 A6 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A5 valued_0_th_31 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in-infty-to-inftyLIMFUNC1V8"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_11:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-left-divergent-to+infty-inLIMFUNC2R2 x0 & f2 be divergent-in+infty-to+inftyLIMFUNC1V4) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-divergent-to+infty-inLIMFUNC2R2 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-left-divergent-to+infty-inLIMFUNC2R2 x0 & (f2 be divergent-in+infty-to+inftyLIMFUNC1V4 & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-divergent-to+infty-inLIMFUNC2R2 x0"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-left-divergent-to+infty-inLIMFUNC2R2 x0"
      and A2: "f2 be divergent-in+infty-to+inftyLIMFUNC1V4"
      and A3: " for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    have " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A4: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A5: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
      have A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A5 limfunc4_th_1 sorry
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
        using A5 limfunc4_th_1 sorry
      then have A7: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A1 A4 limfunc2_def_2 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A5 limfunc4_th_1 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) be divergent-to+inftyLIMFUNC1V1"
        using A2 A7 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A6 valued_0_th_31 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-divergent-to+infty-inLIMFUNC2R2 x0"
      using A3 limfunc2_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_12:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-left-divergent-to+infty-inLIMFUNC2R2 x0 & f2 be divergent-in+infty-to-inftyLIMFUNC1V5) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-divergent-to-infty-inLIMFUNC2R3 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-left-divergent-to+infty-inLIMFUNC2R2 x0 & (f2 be divergent-in+infty-to-inftyLIMFUNC1V5 & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-divergent-to-infty-inLIMFUNC2R3 x0"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-left-divergent-to+infty-inLIMFUNC2R2 x0"
      and A2: "f2 be divergent-in+infty-to-inftyLIMFUNC1V5"
      and A3: " for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    have " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A4: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A5: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
      have A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A5 limfunc4_th_1 sorry
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
        using A5 limfunc4_th_1 sorry
      then have A7: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A1 A4 limfunc2_def_2 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A5 limfunc4_th_1 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) be divergent-to-inftyLIMFUNC1V2"
        using A2 A7 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A6 valued_0_th_31 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-divergent-to-infty-inLIMFUNC2R3 x0"
      using A3 limfunc2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_13:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-left-divergent-to-infty-inLIMFUNC2R3 x0 & f2 be divergent-in-infty-to+inftyLIMFUNC1V7) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-divergent-to+infty-inLIMFUNC2R2 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-left-divergent-to-infty-inLIMFUNC2R3 x0 & (f2 be divergent-in-infty-to+inftyLIMFUNC1V7 & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-divergent-to+infty-inLIMFUNC2R2 x0"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-left-divergent-to-infty-inLIMFUNC2R3 x0"
      and A2: "f2 be divergent-in-infty-to+inftyLIMFUNC1V7"
      and A3: " for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    have " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A4: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A5: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
      have A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A5 limfunc4_th_1 sorry
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
        using A5 limfunc4_th_1 sorry
      then have A7: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A1 A4 limfunc2_def_3 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A5 limfunc4_th_1 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) be divergent-to+inftyLIMFUNC1V1"
        using A2 A7 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A6 valued_0_th_31 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-divergent-to+infty-inLIMFUNC2R2 x0"
      using A3 limfunc2_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_14:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-left-divergent-to-infty-inLIMFUNC2R3 x0 & f2 be divergent-in-infty-to-inftyLIMFUNC1V8) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-divergent-to-infty-inLIMFUNC2R3 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-left-divergent-to-infty-inLIMFUNC2R3 x0 & (f2 be divergent-in-infty-to-inftyLIMFUNC1V8 & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-divergent-to-infty-inLIMFUNC2R3 x0"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-left-divergent-to-infty-inLIMFUNC2R3 x0"
      and A2: "f2 be divergent-in-infty-to-inftyLIMFUNC1V8"
      and A3: " for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    have " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A4: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A5: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
      have A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A5 limfunc4_th_1 sorry
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
        using A5 limfunc4_th_1 sorry
      then have A7: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A1 A4 limfunc2_def_3 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A5 limfunc4_th_1 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) be divergent-to-inftyLIMFUNC1V2"
        using A2 A7 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A6 valued_0_th_31 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-divergent-to-infty-inLIMFUNC2R3 x0"
      using A3 limfunc2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_15:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-right-divergent-to+infty-inLIMFUNC2R5 x0 & f2 be divergent-in+infty-to+inftyLIMFUNC1V4) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-divergent-to+infty-inLIMFUNC2R5 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-right-divergent-to+infty-inLIMFUNC2R5 x0 & (f2 be divergent-in+infty-to+inftyLIMFUNC1V4 & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-divergent-to+infty-inLIMFUNC2R5 x0"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-right-divergent-to+infty-inLIMFUNC2R5 x0"
      and A2: "f2 be divergent-in+infty-to+inftyLIMFUNC1V4"
      and A3: " for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    have " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A4: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A5: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
      have A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A5 limfunc4_th_1 sorry
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
        using A5 limfunc4_th_1 sorry
      then have A7: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A1 A4 limfunc2_def_5 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A5 limfunc4_th_1 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) be divergent-to+inftyLIMFUNC1V1"
        using A2 A7 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A6 valued_0_th_31 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-divergent-to+infty-inLIMFUNC2R5 x0"
      using A3 limfunc2_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_16:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-right-divergent-to+infty-inLIMFUNC2R5 x0 & f2 be divergent-in+infty-to-inftyLIMFUNC1V5) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-divergent-to-infty-inLIMFUNC2R6 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-right-divergent-to+infty-inLIMFUNC2R5 x0 & (f2 be divergent-in+infty-to-inftyLIMFUNC1V5 & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-divergent-to-infty-inLIMFUNC2R6 x0"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-right-divergent-to+infty-inLIMFUNC2R5 x0"
      and A2: "f2 be divergent-in+infty-to-inftyLIMFUNC1V5"
      and A3: " for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    have " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A4: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A5: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
      have A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A5 limfunc4_th_1 sorry
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
        using A5 limfunc4_th_1 sorry
      then have A7: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A1 A4 limfunc2_def_5 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A5 limfunc4_th_1 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) be divergent-to-inftyLIMFUNC1V2"
        using A2 A7 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A6 valued_0_th_31 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-divergent-to-infty-inLIMFUNC2R6 x0"
      using A3 limfunc2_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_17:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-right-divergent-to-infty-inLIMFUNC2R6 x0 & f2 be divergent-in-infty-to+inftyLIMFUNC1V7) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-divergent-to+infty-inLIMFUNC2R5 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-right-divergent-to-infty-inLIMFUNC2R6 x0 & (f2 be divergent-in-infty-to+inftyLIMFUNC1V7 & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-divergent-to+infty-inLIMFUNC2R5 x0"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-right-divergent-to-infty-inLIMFUNC2R6 x0"
      and A2: "f2 be divergent-in-infty-to+inftyLIMFUNC1V7"
      and A3: " for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    have " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A4: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A5: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
      have A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A5 limfunc4_th_1 sorry
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
        using A5 limfunc4_th_1 sorry
      then have A7: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A1 A4 limfunc2_def_6 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A5 limfunc4_th_1 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) be divergent-to+inftyLIMFUNC1V1"
        using A2 A7 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A6 valued_0_th_31 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-divergent-to+infty-inLIMFUNC2R5 x0"
      using A3 limfunc2_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_18:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-right-divergent-to-infty-inLIMFUNC2R6 x0 & f2 be divergent-in-infty-to-inftyLIMFUNC1V8) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-divergent-to-infty-inLIMFUNC2R6 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-right-divergent-to-infty-inLIMFUNC2R6 x0 & (f2 be divergent-in-infty-to-inftyLIMFUNC1V8 & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-divergent-to-infty-inLIMFUNC2R6 x0"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-right-divergent-to-infty-inLIMFUNC2R6 x0"
      and A2: "f2 be divergent-in-infty-to-inftyLIMFUNC1V8"
      and A3: " for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    have " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A4: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A5: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
      have A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A5 limfunc4_th_1 sorry
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
        using A5 limfunc4_th_1 sorry
      then have A7: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A1 A4 limfunc2_def_6 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A5 limfunc4_th_1 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) be divergent-to-inftyLIMFUNC1V2"
        using A2 A7 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A6 valued_0_th_31 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-divergent-to-infty-inLIMFUNC2R6 x0"
      using A3 limfunc2_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_19:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-left-convergent-inLIMFUNC2R1 x0 & f2 is-left-divergent-to+infty-inLIMFUNC2R2 lim-leftLIMFUNC2K1(f1,x0)) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) & ( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies f1 .FUNCT-1K1 r <XXREAL-0R3 lim-leftLIMFUNC2K1(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-divergent-to+infty-inLIMFUNC2R2 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-left-convergent-inLIMFUNC2R1 x0 & (f2 is-left-divergent-to+infty-inLIMFUNC2R2 lim-leftLIMFUNC2K1(f1,x0) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies (( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies f1 .FUNCT-1K1 r <XXREAL-0R3 lim-leftLIMFUNC2K1(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-divergent-to+infty-inLIMFUNC2R2 x0)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-left-convergent-inLIMFUNC2R1 x0"
      and A2: "f2 is-left-divergent-to+infty-inLIMFUNC2R2 lim-leftLIMFUNC2K1(f1,x0)"
      and A3: " for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    assume Given: " ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies f1 .FUNCT-1K1 r <XXREAL-0R3 lim-leftLIMFUNC2K1(f1,x0))"
    then obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 g"and A5: " for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies f1 .FUNCT-1K1 r <XXREAL-0R3 lim-leftLIMFUNC2K1(f1,x0)"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A6: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A7: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A8: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-1K1 n"
        using A4 A6 limfunc4_lm_1 limfunc2_th_1 sorry
      let ?q = "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A7 limfunc4_th_1 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 limfunc4_th_1 sorry
      then have A10: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A9 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have A11: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
        using A7 limfunc4_th_1 sorry
      then have A12: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A1 A2 A6 limfunc2_def_7 sorry
      have A13: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A7 limfunc4_th_1 sorry
      have A14: "rngFUNCT-1K2 s c=TARSKIR1 left-open-halflineLIMFUNC1K1 x0"
        using A7 limfunc4_th_1 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-leftLIMFUNC2K1(f1,x0)))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 ?q"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A15: "?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
          using funct_2_th_113 sorry
        have A16: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have A17: "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A13 funct_2_th_108 A16 sorry
        also have "... = x"
          using A15 nat_1_def_3 sorry
        finally have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 x"
           sorry
        have A18: "x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A8 nat_1_th_12 sorry
        have A19: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
          using valued_0_th_28 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 left-open-halflineLIMFUNC1K1 x0"
          using A14 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : g1 <XXREAL-0R3 x0 }"
          using xxreal_1_th_229 sorry
        then have " ex g1 be RealXREAL-0M1 st g1 =HIDDENR1 s .FUNCT-1K1 (n +XCMPLX-0K2 k) & g1 <XXREAL-0R3 x0"
           sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : x0 -XCMPLX-0K6 g <XXREAL-0R3 g2 & g2 <XXREAL-0R3 x0 }"
          using A18 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .["
          using rcomp_1_def_2 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[)"
          using A13 A19 xboole_0_def_4 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) <XXREAL-0R3 lim-leftLIMFUNC2K1(f1,x0)"
          using A5 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 {r1 where r1 be RealXREAL-0M1 : r1 <XXREAL-0R3 lim-leftLIMFUNC2K1(f1,x0) }"
           sorry
        then have A20: "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 left-open-halflineLIMFUNC1K1 (lim-leftLIMFUNC2K1(f1,x0))"
          using xxreal_1_th_229 sorry
        have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A9 A19 funct_1_th_11 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-leftLIMFUNC2K1(f1,x0)))"
          using A20 A17 xboole_0_def_4 sorry
      qed "sorry"
      then have A21: "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-leftLIMFUNC2K1(f1,x0)))"
         sorry
      have "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-leftLIMFUNC2K1(f1,x0)"
        using A1 A6 A11 limfunc2_def_7 sorry
      then have "limSEQ-2K1 ?q =HIDDENR1 lim-leftLIMFUNC2K1(f1,x0)"
        using A12 seq_4_th_20 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be divergent-to+inftyLIMFUNC1V1"
        using A2 A12 A21 limfunc2_def_2 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A10 limfunc1_th_7 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-divergent-to+infty-inLIMFUNC2R2 x0"
      using A3 limfunc2_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_20:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-left-convergent-inLIMFUNC2R1 x0 & f2 is-left-divergent-to-infty-inLIMFUNC2R3 lim-leftLIMFUNC2K1(f1,x0)) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) & ( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies f1 .FUNCT-1K1 r <XXREAL-0R3 lim-leftLIMFUNC2K1(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-divergent-to-infty-inLIMFUNC2R3 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-left-convergent-inLIMFUNC2R1 x0 & (f2 is-left-divergent-to-infty-inLIMFUNC2R3 lim-leftLIMFUNC2K1(f1,x0) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies (( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies f1 .FUNCT-1K1 r <XXREAL-0R3 lim-leftLIMFUNC2K1(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-divergent-to-infty-inLIMFUNC2R3 x0)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-left-convergent-inLIMFUNC2R1 x0"
      and A2: "f2 is-left-divergent-to-infty-inLIMFUNC2R3 lim-leftLIMFUNC2K1(f1,x0)"
      and A3: " for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    assume Given: " ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies f1 .FUNCT-1K1 r <XXREAL-0R3 lim-leftLIMFUNC2K1(f1,x0))"
    then obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 g"and A5: " for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies f1 .FUNCT-1K1 r <XXREAL-0R3 lim-leftLIMFUNC2K1(f1,x0)"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A6: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A7: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A8: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-1K1 n"
        using A4 A6 limfunc4_lm_1 limfunc2_th_1 sorry
      let ?q = "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A7 limfunc4_th_1 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 limfunc4_th_1 sorry
      then have A10: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A9 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have A11: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
        using A7 limfunc4_th_1 sorry
      then have A12: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A1 A2 A6 limfunc2_def_7 sorry
      have A13: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A7 limfunc4_th_1 sorry
      have A14: "rngFUNCT-1K2 s c=TARSKIR1 left-open-halflineLIMFUNC1K1 x0"
        using A7 limfunc4_th_1 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-leftLIMFUNC2K1(f1,x0)))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 ?q"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A15: "?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
          using funct_2_th_113 sorry
        have A16: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have A17: "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A13 funct_2_th_108 A16 sorry
        also have "... = x"
          using A15 nat_1_def_3 sorry
        finally have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 x"
           sorry
        have A18: "x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A8 nat_1_th_12 sorry
        have A19: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
          using valued_0_th_28 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 left-open-halflineLIMFUNC1K1 x0"
          using A14 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : g1 <XXREAL-0R3 x0 }"
          using xxreal_1_th_229 sorry
        then have " ex g1 be RealXREAL-0M1 st g1 =HIDDENR1 s .FUNCT-1K1 (n +XCMPLX-0K2 k) & g1 <XXREAL-0R3 x0"
           sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : x0 -XCMPLX-0K6 g <XXREAL-0R3 g2 & g2 <XXREAL-0R3 x0 }"
          using A18 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .["
          using rcomp_1_def_2 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[)"
          using A13 A19 xboole_0_def_4 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) <XXREAL-0R3 lim-leftLIMFUNC2K1(f1,x0)"
          using A5 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 {r1 where r1 be RealXREAL-0M1 : r1 <XXREAL-0R3 lim-leftLIMFUNC2K1(f1,x0) }"
           sorry
        then have A20: "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 left-open-halflineLIMFUNC1K1 (lim-leftLIMFUNC2K1(f1,x0))"
          using xxreal_1_th_229 sorry
        have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A9 A19 funct_1_th_11 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-leftLIMFUNC2K1(f1,x0)))"
          using A20 A17 xboole_0_def_4 sorry
      qed "sorry"
      then have A21: "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-leftLIMFUNC2K1(f1,x0)))"
         sorry
      have "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-leftLIMFUNC2K1(f1,x0)"
        using A1 A6 A11 limfunc2_def_7 sorry
      then have "limSEQ-2K1 ?q =HIDDENR1 lim-leftLIMFUNC2K1(f1,x0)"
        using A12 seq_4_th_20 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be divergent-to-inftyLIMFUNC1V2"
        using A2 A12 A21 limfunc2_def_3 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A10 limfunc1_th_7 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-divergent-to-infty-inLIMFUNC2R3 x0"
      using A3 limfunc2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_21:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-left-convergent-inLIMFUNC2R1 x0 & f2 is-right-divergent-to+infty-inLIMFUNC2R5 lim-leftLIMFUNC2K1(f1,x0)) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) & ( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies lim-leftLIMFUNC2K1(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 r)) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-divergent-to+infty-inLIMFUNC2R2 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-left-convergent-inLIMFUNC2R1 x0 & (f2 is-right-divergent-to+infty-inLIMFUNC2R5 lim-leftLIMFUNC2K1(f1,x0) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies (( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies lim-leftLIMFUNC2K1(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 r)) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-divergent-to+infty-inLIMFUNC2R2 x0)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-left-convergent-inLIMFUNC2R1 x0"
      and A2: "f2 is-right-divergent-to+infty-inLIMFUNC2R5 lim-leftLIMFUNC2K1(f1,x0)"
      and A3: " for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    assume Given: " ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies lim-leftLIMFUNC2K1(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 r)"
    then obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 g"and A5: " for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies lim-leftLIMFUNC2K1(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 r"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A6: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A7: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A8: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-1K1 n"
        using A4 A6 limfunc4_lm_1 limfunc2_th_1 sorry
      let ?q = "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A7 limfunc4_th_1 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 limfunc4_th_1 sorry
      then have A10: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A9 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have A11: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
        using A7 limfunc4_th_1 sorry
      then have A12: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A1 A2 A6 limfunc2_def_7 sorry
      have A13: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A7 limfunc4_th_1 sorry
      have A14: "rngFUNCT-1K2 s c=TARSKIR1 left-open-halflineLIMFUNC1K1 x0"
        using A7 limfunc4_th_1 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-leftLIMFUNC2K1(f1,x0)))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 ?q"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A15: "?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
          using funct_2_th_113 sorry
        have A16: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have A17: "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A13 funct_2_th_108 A16 sorry
        also have "... = x"
          using A15 nat_1_def_3 sorry
        finally have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 x"
           sorry
        have A18: "x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A8 nat_1_th_12 sorry
        have A19: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
          using valued_0_th_28 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 left-open-halflineLIMFUNC1K1 x0"
          using A14 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : g1 <XXREAL-0R3 x0 }"
          using xxreal_1_th_229 sorry
        then have " ex g1 be RealXREAL-0M1 st g1 =HIDDENR1 s .FUNCT-1K1 (n +XCMPLX-0K2 k) & g1 <XXREAL-0R3 x0"
           sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : x0 -XCMPLX-0K6 g <XXREAL-0R3 g2 & g2 <XXREAL-0R3 x0 }"
          using A18 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .["
          using rcomp_1_def_2 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[)"
          using A13 A19 xboole_0_def_4 sorry
        then have "lim-leftLIMFUNC2K1(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
          using A5 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 {r1 where r1 be RealXREAL-0M1 : lim-leftLIMFUNC2K1(f1,x0) <XXREAL-0R3 r1 }"
           sorry
        then have A20: "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 right-open-halflineLIMFUNC1K4 (lim-leftLIMFUNC2K1(f1,x0))"
          using xxreal_1_th_230 sorry
        have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A9 A19 funct_1_th_11 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-leftLIMFUNC2K1(f1,x0)))"
          using A20 A17 xboole_0_def_4 sorry
      qed "sorry"
      then have A21: "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-leftLIMFUNC2K1(f1,x0)))"
         sorry
      have "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-leftLIMFUNC2K1(f1,x0)"
        using A1 A6 A11 limfunc2_def_7 sorry
      then have "limSEQ-2K1 ?q =HIDDENR1 lim-leftLIMFUNC2K1(f1,x0)"
        using A12 seq_4_th_20 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be divergent-to+inftyLIMFUNC1V1"
        using A2 A12 A21 limfunc2_def_5 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A10 limfunc1_th_7 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-divergent-to+infty-inLIMFUNC2R2 x0"
      using A3 limfunc2_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_22:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-left-convergent-inLIMFUNC2R1 x0 & f2 is-right-divergent-to-infty-inLIMFUNC2R6 lim-leftLIMFUNC2K1(f1,x0)) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) & ( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies lim-leftLIMFUNC2K1(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 r)) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-divergent-to-infty-inLIMFUNC2R3 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-left-convergent-inLIMFUNC2R1 x0 & (f2 is-right-divergent-to-infty-inLIMFUNC2R6 lim-leftLIMFUNC2K1(f1,x0) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies (( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies lim-leftLIMFUNC2K1(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 r)) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-divergent-to-infty-inLIMFUNC2R3 x0)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-left-convergent-inLIMFUNC2R1 x0"
      and A2: "f2 is-right-divergent-to-infty-inLIMFUNC2R6 lim-leftLIMFUNC2K1(f1,x0)"
      and A3: " for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    assume Given: " ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies lim-leftLIMFUNC2K1(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 r)"
    then obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 g"and A5: " for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies lim-leftLIMFUNC2K1(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 r"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A6: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A7: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A8: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-1K1 n"
        using A4 A6 limfunc4_lm_1 limfunc2_th_1 sorry
      let ?q = "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A7 limfunc4_th_1 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 limfunc4_th_1 sorry
      then have A10: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A9 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have A11: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
        using A7 limfunc4_th_1 sorry
      then have A12: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A1 A2 A6 limfunc2_def_7 sorry
      have A13: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A7 limfunc4_th_1 sorry
      have A14: "rngFUNCT-1K2 s c=TARSKIR1 left-open-halflineLIMFUNC1K1 x0"
        using A7 limfunc4_th_1 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-leftLIMFUNC2K1(f1,x0)))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 ?q"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A15: "?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
          using funct_2_th_113 sorry
        have A16: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have A17: "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A13 funct_2_th_108 A16 sorry
        also have "... = x"
          using A15 nat_1_def_3 sorry
        finally have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 x"
           sorry
        have A18: "x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A8 nat_1_th_12 sorry
        have A19: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
          using valued_0_th_28 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 left-open-halflineLIMFUNC1K1 x0"
          using A14 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : g1 <XXREAL-0R3 x0 }"
          using xxreal_1_th_229 sorry
        then have " ex g1 be RealXREAL-0M1 st g1 =HIDDENR1 s .FUNCT-1K1 (n +XCMPLX-0K2 k) & g1 <XXREAL-0R3 x0"
           sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : x0 -XCMPLX-0K6 g <XXREAL-0R3 g2 & g2 <XXREAL-0R3 x0 }"
          using A18 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .["
          using rcomp_1_def_2 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[)"
          using A13 A19 xboole_0_def_4 sorry
        then have "lim-leftLIMFUNC2K1(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
          using A5 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 {r1 where r1 be RealXREAL-0M1 : lim-leftLIMFUNC2K1(f1,x0) <XXREAL-0R3 r1 }"
           sorry
        then have A20: "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 right-open-halflineLIMFUNC1K4 (lim-leftLIMFUNC2K1(f1,x0))"
          using xxreal_1_th_230 sorry
        have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A9 A19 funct_1_th_11 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-leftLIMFUNC2K1(f1,x0)))"
          using A20 A17 xboole_0_def_4 sorry
      qed "sorry"
      then have A21: "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-leftLIMFUNC2K1(f1,x0)))"
         sorry
      have "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-leftLIMFUNC2K1(f1,x0)"
        using A1 A6 A11 limfunc2_def_7 sorry
      then have "limSEQ-2K1 ?q =HIDDENR1 lim-leftLIMFUNC2K1(f1,x0)"
        using A12 seq_4_th_20 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be divergent-to-inftyLIMFUNC1V2"
        using A2 A12 A21 limfunc2_def_6 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A10 limfunc1_th_7 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-divergent-to-infty-inLIMFUNC2R3 x0"
      using A3 limfunc2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_23:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-right-convergent-inLIMFUNC2R4 x0 & f2 is-right-divergent-to+infty-inLIMFUNC2R5 lim-rightLIMFUNC2K2(f1,x0)) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) & ( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies lim-rightLIMFUNC2K2(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 r)) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-divergent-to+infty-inLIMFUNC2R5 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-right-convergent-inLIMFUNC2R4 x0 & (f2 is-right-divergent-to+infty-inLIMFUNC2R5 lim-rightLIMFUNC2K2(f1,x0) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies (( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies lim-rightLIMFUNC2K2(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 r)) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-divergent-to+infty-inLIMFUNC2R5 x0)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-right-convergent-inLIMFUNC2R4 x0"
      and A2: "f2 is-right-divergent-to+infty-inLIMFUNC2R5 lim-rightLIMFUNC2K2(f1,x0)"
      and A3: " for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    assume Given: " ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies lim-rightLIMFUNC2K2(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 r)"
    then obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 g"and A5: " for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies lim-rightLIMFUNC2K2(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 r"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A6: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A7: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A8: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies s .FUNCT-1K1 n <XXREAL-0R3 x0 +XCMPLX-0K2 g"
        using A4 A6 limfunc4_lm_1 limfunc2_th_2 sorry
      let ?q = "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A7 limfunc4_th_1 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 limfunc4_th_1 sorry
      then have A10: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A9 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have A11: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
        using A7 limfunc4_th_1 sorry
      then have A12: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A1 A2 A6 limfunc2_def_8 sorry
      have A13: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A7 limfunc4_th_1 sorry
      have A14: "rngFUNCT-1K2 s c=TARSKIR1 right-open-halflineLIMFUNC1K4 x0"
        using A7 limfunc4_th_1 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-rightLIMFUNC2K2(f1,x0)))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 ?q"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A15: "?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
          using funct_2_th_113 sorry
        have A16: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have A17: "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A13 funct_2_th_108 A16 sorry
        also have "... = x"
          using A15 nat_1_def_3 sorry
        finally have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 x"
           sorry
        have A18: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) <XXREAL-0R3 x0 +XCMPLX-0K2 g"
          using A8 nat_1_th_12 sorry
        have A19: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
          using valued_0_th_28 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 right-open-halflineLIMFUNC1K4 x0"
          using A14 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : x0 <XXREAL-0R3 g1 }"
          using xxreal_1_th_230 sorry
        then have " ex g1 be RealXREAL-0M1 st g1 =HIDDENR1 s .FUNCT-1K1 (n +XCMPLX-0K2 k) & x0 <XXREAL-0R3 g1"
           sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : x0 <XXREAL-0R3 g2 & g2 <XXREAL-0R3 x0 +XCMPLX-0K2 g }"
          using A18 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .["
          using rcomp_1_def_2 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[)"
          using A13 A19 xboole_0_def_4 sorry
        then have "lim-rightLIMFUNC2K2(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
          using A5 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 {r1 where r1 be RealXREAL-0M1 : lim-rightLIMFUNC2K2(f1,x0) <XXREAL-0R3 r1 }"
           sorry
        then have A20: "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 right-open-halflineLIMFUNC1K4 (lim-rightLIMFUNC2K2(f1,x0))"
          using xxreal_1_th_230 sorry
        have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A9 A19 funct_1_th_11 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-rightLIMFUNC2K2(f1,x0)))"
          using A20 A17 xboole_0_def_4 sorry
      qed "sorry"
      then have A21: "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-rightLIMFUNC2K2(f1,x0)))"
         sorry
      have "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-rightLIMFUNC2K2(f1,x0)"
        using A1 A6 A11 limfunc2_def_8 sorry
      then have "limSEQ-2K1 ?q =HIDDENR1 lim-rightLIMFUNC2K2(f1,x0)"
        using A12 seq_4_th_20 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be divergent-to+inftyLIMFUNC1V1"
        using A2 A12 A21 limfunc2_def_5 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A10 limfunc1_th_7 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-divergent-to+infty-inLIMFUNC2R5 x0"
      using A3 limfunc2_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_24:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-right-convergent-inLIMFUNC2R4 x0 & f2 is-right-divergent-to-infty-inLIMFUNC2R6 lim-rightLIMFUNC2K2(f1,x0)) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) & ( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies lim-rightLIMFUNC2K2(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 r)) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-divergent-to-infty-inLIMFUNC2R6 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-right-convergent-inLIMFUNC2R4 x0 & (f2 is-right-divergent-to-infty-inLIMFUNC2R6 lim-rightLIMFUNC2K2(f1,x0) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies (( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies lim-rightLIMFUNC2K2(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 r)) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-divergent-to-infty-inLIMFUNC2R6 x0)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-right-convergent-inLIMFUNC2R4 x0"
      and A2: "f2 is-right-divergent-to-infty-inLIMFUNC2R6 lim-rightLIMFUNC2K2(f1,x0)"
      and A3: " for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    assume Given: " ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies lim-rightLIMFUNC2K2(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 r)"
    then obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 g"and A5: " for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies lim-rightLIMFUNC2K2(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 r"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A6: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A7: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A8: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies s .FUNCT-1K1 n <XXREAL-0R3 x0 +XCMPLX-0K2 g"
        using A4 A6 limfunc4_lm_1 limfunc2_th_2 sorry
      let ?q = "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A7 limfunc4_th_1 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 limfunc4_th_1 sorry
      then have A10: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A9 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have A11: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
        using A7 limfunc4_th_1 sorry
      then have A12: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A1 A2 A6 limfunc2_def_8 sorry
      have A13: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A7 limfunc4_th_1 sorry
      have A14: "rngFUNCT-1K2 s c=TARSKIR1 right-open-halflineLIMFUNC1K4 x0"
        using A7 limfunc4_th_1 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-rightLIMFUNC2K2(f1,x0)))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 ?q"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A15: "?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
          using funct_2_th_113 sorry
        have A16: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have A17: "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A13 funct_2_th_108 A16 sorry
        also have "... = x"
          using A15 nat_1_def_3 sorry
        finally have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 x"
           sorry
        have A18: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) <XXREAL-0R3 x0 +XCMPLX-0K2 g"
          using A8 nat_1_th_12 sorry
        have A19: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
          using valued_0_th_28 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 right-open-halflineLIMFUNC1K4 x0"
          using A14 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : x0 <XXREAL-0R3 g1 }"
          using xxreal_1_th_230 sorry
        then have " ex g1 be RealXREAL-0M1 st g1 =HIDDENR1 s .FUNCT-1K1 (n +XCMPLX-0K2 k) & x0 <XXREAL-0R3 g1"
           sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : x0 <XXREAL-0R3 g2 & g2 <XXREAL-0R3 x0 +XCMPLX-0K2 g }"
          using A18 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .["
          using rcomp_1_def_2 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[)"
          using A13 A19 xboole_0_def_4 sorry
        then have "lim-rightLIMFUNC2K2(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
          using A5 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 {r1 where r1 be RealXREAL-0M1 : lim-rightLIMFUNC2K2(f1,x0) <XXREAL-0R3 r1 }"
           sorry
        then have A20: "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 right-open-halflineLIMFUNC1K4 (lim-rightLIMFUNC2K2(f1,x0))"
          using xxreal_1_th_230 sorry
        have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A9 A19 funct_1_th_11 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-rightLIMFUNC2K2(f1,x0)))"
          using A20 A17 xboole_0_def_4 sorry
      qed "sorry"
      then have A21: "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-rightLIMFUNC2K2(f1,x0)))"
         sorry
      have "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-rightLIMFUNC2K2(f1,x0)"
        using A1 A6 A11 limfunc2_def_8 sorry
      then have "limSEQ-2K1 ?q =HIDDENR1 lim-rightLIMFUNC2K2(f1,x0)"
        using A12 seq_4_th_20 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be divergent-to-inftyLIMFUNC1V2"
        using A2 A12 A21 limfunc2_def_6 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A10 limfunc1_th_7 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-divergent-to-infty-inLIMFUNC2R6 x0"
      using A3 limfunc2_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_25:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-right-convergent-inLIMFUNC2R4 x0 & f2 is-left-divergent-to+infty-inLIMFUNC2R2 lim-rightLIMFUNC2K2(f1,x0)) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) & ( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <XXREAL-0R3 lim-rightLIMFUNC2K2(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-divergent-to+infty-inLIMFUNC2R5 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-right-convergent-inLIMFUNC2R4 x0 & (f2 is-left-divergent-to+infty-inLIMFUNC2R2 lim-rightLIMFUNC2K2(f1,x0) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies (( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <XXREAL-0R3 lim-rightLIMFUNC2K2(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-divergent-to+infty-inLIMFUNC2R5 x0)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-right-convergent-inLIMFUNC2R4 x0"
      and A2: "f2 is-left-divergent-to+infty-inLIMFUNC2R2 lim-rightLIMFUNC2K2(f1,x0)"
      and A3: " for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    assume Given: " ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <XXREAL-0R3 lim-rightLIMFUNC2K2(f1,x0))"
    then obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 g"and A5: " for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <XXREAL-0R3 lim-rightLIMFUNC2K2(f1,x0)"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A6: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A7: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A8: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies s .FUNCT-1K1 n <XXREAL-0R3 x0 +XCMPLX-0K2 g"
        using A4 A6 limfunc4_lm_1 limfunc2_th_2 sorry
      let ?q = "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A7 limfunc4_th_1 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 limfunc4_th_1 sorry
      then have A10: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A9 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have A11: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
        using A7 limfunc4_th_1 sorry
      then have A12: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A1 A2 A6 limfunc2_def_8 sorry
      have A13: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A7 limfunc4_th_1 sorry
      have A14: "rngFUNCT-1K2 s c=TARSKIR1 right-open-halflineLIMFUNC1K4 x0"
        using A7 limfunc4_th_1 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-rightLIMFUNC2K2(f1,x0)))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 ?q"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A15: "?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
          using funct_2_th_113 sorry
        have A16: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have A17: "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A13 funct_2_th_108 A16 sorry
        also have "... = x"
          using A15 nat_1_def_3 sorry
        finally have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 x"
           sorry
        have A18: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) <XXREAL-0R3 x0 +XCMPLX-0K2 g"
          using A8 nat_1_th_12 sorry
        have A19: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
          using valued_0_th_28 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 right-open-halflineLIMFUNC1K4 x0"
          using A14 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : x0 <XXREAL-0R3 g1 }"
          using xxreal_1_th_230 sorry
        then have " ex g1 be RealXREAL-0M1 st g1 =HIDDENR1 s .FUNCT-1K1 (n +XCMPLX-0K2 k) & x0 <XXREAL-0R3 g1"
           sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : x0 <XXREAL-0R3 g2 & g2 <XXREAL-0R3 x0 +XCMPLX-0K2 g }"
          using A18 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .["
          using rcomp_1_def_2 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[)"
          using A13 A19 xboole_0_def_4 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) <XXREAL-0R3 lim-rightLIMFUNC2K2(f1,x0)"
          using A5 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 {r1 where r1 be RealXREAL-0M1 : r1 <XXREAL-0R3 lim-rightLIMFUNC2K2(f1,x0) }"
           sorry
        then have A20: "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 left-open-halflineLIMFUNC1K1 (lim-rightLIMFUNC2K2(f1,x0))"
          using xxreal_1_th_229 sorry
        have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A9 A19 funct_1_th_11 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-rightLIMFUNC2K2(f1,x0)))"
          using A20 A17 xboole_0_def_4 sorry
      qed "sorry"
      then have A21: "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-rightLIMFUNC2K2(f1,x0)))"
         sorry
      have "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-rightLIMFUNC2K2(f1,x0)"
        using A1 A6 A11 limfunc2_def_8 sorry
      then have "limSEQ-2K1 ?q =HIDDENR1 lim-rightLIMFUNC2K2(f1,x0)"
        using A12 seq_4_th_20 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be divergent-to+inftyLIMFUNC1V1"
        using A2 A12 A21 limfunc2_def_2 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A10 limfunc1_th_7 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-divergent-to+infty-inLIMFUNC2R5 x0"
      using A3 limfunc2_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_26:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-right-convergent-inLIMFUNC2R4 x0 & f2 is-left-divergent-to-infty-inLIMFUNC2R3 lim-rightLIMFUNC2K2(f1,x0)) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) & ( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <XXREAL-0R3 lim-rightLIMFUNC2K2(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-divergent-to-infty-inLIMFUNC2R6 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-right-convergent-inLIMFUNC2R4 x0 & (f2 is-left-divergent-to-infty-inLIMFUNC2R3 lim-rightLIMFUNC2K2(f1,x0) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies (( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <XXREAL-0R3 lim-rightLIMFUNC2K2(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-divergent-to-infty-inLIMFUNC2R6 x0)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-right-convergent-inLIMFUNC2R4 x0"
      and A2: "f2 is-left-divergent-to-infty-inLIMFUNC2R3 lim-rightLIMFUNC2K2(f1,x0)"
      and A3: " for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    assume Given: " ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <XXREAL-0R3 lim-rightLIMFUNC2K2(f1,x0))"
    then obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 g"and A5: " for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <XXREAL-0R3 lim-rightLIMFUNC2K2(f1,x0)"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A6: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A7: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A8: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies s .FUNCT-1K1 n <XXREAL-0R3 x0 +XCMPLX-0K2 g"
        using A4 A6 limfunc4_lm_1 limfunc2_th_2 sorry
      let ?q = "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A7 limfunc4_th_1 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 limfunc4_th_1 sorry
      then have A10: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A9 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have A11: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
        using A7 limfunc4_th_1 sorry
      then have A12: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A1 A2 A6 limfunc2_def_8 sorry
      have A13: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A7 limfunc4_th_1 sorry
      have A14: "rngFUNCT-1K2 s c=TARSKIR1 right-open-halflineLIMFUNC1K4 x0"
        using A7 limfunc4_th_1 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-rightLIMFUNC2K2(f1,x0)))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 ?q"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A15: "?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
          using funct_2_th_113 sorry
        have A16: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have A17: "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A13 funct_2_th_108 A16 sorry
        also have "... = x"
          using A15 nat_1_def_3 sorry
        finally have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 x"
           sorry
        have A18: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) <XXREAL-0R3 x0 +XCMPLX-0K2 g"
          using A8 nat_1_th_12 sorry
        have A19: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
          using valued_0_th_28 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 right-open-halflineLIMFUNC1K4 x0"
          using A14 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : x0 <XXREAL-0R3 g1 }"
          using xxreal_1_th_230 sorry
        then have " ex g1 be RealXREAL-0M1 st g1 =HIDDENR1 s .FUNCT-1K1 (n +XCMPLX-0K2 k) & x0 <XXREAL-0R3 g1"
           sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : x0 <XXREAL-0R3 g2 & g2 <XXREAL-0R3 x0 +XCMPLX-0K2 g }"
          using A18 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .["
          using rcomp_1_def_2 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[)"
          using A13 A19 xboole_0_def_4 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) <XXREAL-0R3 lim-rightLIMFUNC2K2(f1,x0)"
          using A5 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 {r1 where r1 be RealXREAL-0M1 : r1 <XXREAL-0R3 lim-rightLIMFUNC2K2(f1,x0) }"
           sorry
        then have A20: "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 left-open-halflineLIMFUNC1K1 (lim-rightLIMFUNC2K2(f1,x0))"
          using xxreal_1_th_229 sorry
        have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A9 A19 funct_1_th_11 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-rightLIMFUNC2K2(f1,x0)))"
          using A20 A17 xboole_0_def_4 sorry
      qed "sorry"
      then have A21: "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-rightLIMFUNC2K2(f1,x0)))"
         sorry
      have "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-rightLIMFUNC2K2(f1,x0)"
        using A1 A6 A11 limfunc2_def_8 sorry
      then have "limSEQ-2K1 ?q =HIDDENR1 lim-rightLIMFUNC2K2(f1,x0)"
        using A12 seq_4_th_20 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be divergent-to-inftyLIMFUNC1V2"
        using A2 A12 A21 limfunc2_def_3 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A10 limfunc1_th_7 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-divergent-to-infty-inLIMFUNC2R6 x0"
      using A3 limfunc2_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_27:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 be convergent-in+inftyLIMFUNC1V3 & f2 is-left-divergent-to+infty-inLIMFUNC2R2 lim-in+inftyLIMFUNC1K5 f1) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) & ( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <XXREAL-0R3 lim-in+inftyLIMFUNC1K5 f1) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in+infty-to+inftyLIMFUNC1V4"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be convergent-in+inftyLIMFUNC1V3 & (f2 is-left-divergent-to+infty-inLIMFUNC2R2 lim-in+inftyLIMFUNC1K5 f1 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies (( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <XXREAL-0R3 lim-in+inftyLIMFUNC1K5 f1) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in+infty-to+inftyLIMFUNC1V4)"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be convergent-in+inftyLIMFUNC1V3"
      and A2: "f2 is-left-divergent-to+infty-inLIMFUNC2R2 lim-in+inftyLIMFUNC1K5 f1"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    assume Given: " ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <XXREAL-0R3 lim-in+inftyLIMFUNC1K5 f1"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A4: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <XXREAL-0R3 lim-in+inftyLIMFUNC1K5 f1"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds s be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A5: "s be divergent-to+inftyLIMFUNC1V1"
        and A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A7: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies r <XXREAL-0R3 s .FUNCT-1K1 n"
        using A5 sorry
      have A8: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc4_lm_2 sorry
      let ?q = "s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "?q be divergent-to+inftyLIMFUNC1V1"
        using A5 limfunc1_th_26 sorry
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A6 limfunc4_lm_2 sorry
      have A11: "rngFUNCT-1K2 ?q c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      have A12: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-in+inftyLIMFUNC1K5 f1))"
      proof-
        have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-in+inftyLIMFUNC1K5 f1))"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-in+inftyLIMFUNC1K5 f1))"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q)"
            then obtain n where
              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A13: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
              using funct_2_th_113 sorry
            have A14: "x =HIDDENR1 f1 .FUNCT-1K1 (?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
              using A10 A11 A13 funct_2_th_108 xboole_1_th_1 sorry
            also have "... = f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
              using nat_1_def_3 sorry
            finally have "x =HIDDENR1 f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
               sorry
            have "r <XXREAL-0R3 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
              using A7 nat_1_th_12 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {r2 where r2 be RealXREAL-0M1 : r <XXREAL-0R3 r2 }"
               sorry
            then have A15: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 right-open-halflineLIMFUNC1K4 r"
              using xxreal_1_th_230 sorry
            have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
              using valued_0_th_28 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r)"
              using A10 A15 xboole_0_def_4 sorry
            then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) <XXREAL-0R3 lim-in+inftyLIMFUNC1K5 f1"
              using A4 sorry
            then have "x inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : g1 <XXREAL-0R3 lim-in+inftyLIMFUNC1K5 f1 }"
              using A14 sorry
            then have A16: "x inHIDDENR3 left-open-halflineLIMFUNC1K1 (lim-in+inftyLIMFUNC1K5 f1)"
              using xxreal_1_th_229 sorry
            have A17: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s)"
              using valued_0_th_28 sorry
            then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A8 sorry
            then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A10 A14 funct_2_th_108 A17 sorry
            thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-in+inftyLIMFUNC1K5 f1))"
              using A16 xboole_0_def_4 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-in+inftyLIMFUNC1K5 f1))"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A10 A11 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be convergentSEQ-2V5 & limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 lim-in+inftyLIMFUNC1K5 f1"
        using A1 A9 limfunc1_def_12 sorry
      then have A18: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) be divergent-to+inftyLIMFUNC1V1"
        using A2 A12 limfunc2_def_2 sorry
      have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        using A10 valued_0_th_27 sorry
      also have "... = f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A8 valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A6 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A18 limfunc1_th_7 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in+infty-to+inftyLIMFUNC1V4"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_28:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 be convergent-in+inftyLIMFUNC1V3 & f2 is-left-divergent-to-infty-inLIMFUNC2R3 lim-in+inftyLIMFUNC1K5 f1) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) & ( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <XXREAL-0R3 lim-in+inftyLIMFUNC1K5 f1) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in+infty-to-inftyLIMFUNC1V5"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be convergent-in+inftyLIMFUNC1V3 & (f2 is-left-divergent-to-infty-inLIMFUNC2R3 lim-in+inftyLIMFUNC1K5 f1 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies (( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <XXREAL-0R3 lim-in+inftyLIMFUNC1K5 f1) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in+infty-to-inftyLIMFUNC1V5)"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be convergent-in+inftyLIMFUNC1V3"
      and A2: "f2 is-left-divergent-to-infty-inLIMFUNC2R3 lim-in+inftyLIMFUNC1K5 f1"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    assume Given: " ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <XXREAL-0R3 lim-in+inftyLIMFUNC1K5 f1"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A4: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <XXREAL-0R3 lim-in+inftyLIMFUNC1K5 f1"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds s be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A5: "s be divergent-to+inftyLIMFUNC1V1"
        and A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A7: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies r <XXREAL-0R3 s .FUNCT-1K1 n"
        using A5 sorry
      have A8: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc4_lm_2 sorry
      let ?q = "s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "?q be divergent-to+inftyLIMFUNC1V1"
        using A5 limfunc1_th_26 sorry
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A6 limfunc4_lm_2 sorry
      have A11: "rngFUNCT-1K2 ?q c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      have A12: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-in+inftyLIMFUNC1K5 f1))"
      proof-
        have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-in+inftyLIMFUNC1K5 f1))"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-in+inftyLIMFUNC1K5 f1))"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q)"
            then obtain n where
              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A13: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
              using funct_2_th_113 sorry
            have A14: "x =HIDDENR1 f1 .FUNCT-1K1 (?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
              using A10 A11 A13 funct_2_th_108 xboole_1_th_1 sorry
            also have "... = f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
              using nat_1_def_3 sorry
            finally have "x =HIDDENR1 f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
               sorry
            have "r <XXREAL-0R3 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
              using A7 nat_1_th_12 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {r2 where r2 be RealXREAL-0M1 : r <XXREAL-0R3 r2 }"
               sorry
            then have A15: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 right-open-halflineLIMFUNC1K4 r"
              using xxreal_1_th_230 sorry
            have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
              using valued_0_th_28 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r)"
              using A10 A15 xboole_0_def_4 sorry
            then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) <XXREAL-0R3 lim-in+inftyLIMFUNC1K5 f1"
              using A4 sorry
            then have "x inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : g1 <XXREAL-0R3 lim-in+inftyLIMFUNC1K5 f1 }"
              using A14 sorry
            then have A16: "x inHIDDENR3 left-open-halflineLIMFUNC1K1 (lim-in+inftyLIMFUNC1K5 f1)"
              using xxreal_1_th_229 sorry
            have A17: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s)"
              using valued_0_th_28 sorry
            then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A8 sorry
            then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A10 A14 funct_2_th_108 A17 sorry
            thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-in+inftyLIMFUNC1K5 f1))"
              using A16 xboole_0_def_4 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-in+inftyLIMFUNC1K5 f1))"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A10 A11 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be convergentSEQ-2V5 & limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 lim-in+inftyLIMFUNC1K5 f1"
        using A1 A9 limfunc1_def_12 sorry
      then have A18: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) be divergent-to-inftyLIMFUNC1V2"
        using A2 A12 limfunc2_def_3 sorry
      have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        using A10 valued_0_th_27 sorry
      also have "... = f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A8 valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A6 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A18 limfunc1_th_7 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in+infty-to-inftyLIMFUNC1V5"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_29:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 be convergent-in+inftyLIMFUNC1V3 & f2 is-right-divergent-to+infty-inLIMFUNC2R5 lim-in+inftyLIMFUNC1K5 f1) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) & ( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies lim-in+inftyLIMFUNC1K5 f1 <XXREAL-0R3 f1 .FUNCT-1K1 g) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in+infty-to+inftyLIMFUNC1V4"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be convergent-in+inftyLIMFUNC1V3 & (f2 is-right-divergent-to+infty-inLIMFUNC2R5 lim-in+inftyLIMFUNC1K5 f1 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies (( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies lim-in+inftyLIMFUNC1K5 f1 <XXREAL-0R3 f1 .FUNCT-1K1 g) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in+infty-to+inftyLIMFUNC1V4)"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be convergent-in+inftyLIMFUNC1V3"
      and A2: "f2 is-right-divergent-to+infty-inLIMFUNC2R5 lim-in+inftyLIMFUNC1K5 f1"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    assume Given: " ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies lim-in+inftyLIMFUNC1K5 f1 <XXREAL-0R3 f1 .FUNCT-1K1 g"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A4: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies lim-in+inftyLIMFUNC1K5 f1 <XXREAL-0R3 f1 .FUNCT-1K1 g"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds s be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A5: "s be divergent-to+inftyLIMFUNC1V1"
        and A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A7: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies r <XXREAL-0R3 s .FUNCT-1K1 n"
        using A5 sorry
      have A8: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc4_lm_2 sorry
      let ?q = "s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "?q be divergent-to+inftyLIMFUNC1V1"
        using A5 limfunc1_th_26 sorry
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A6 limfunc4_lm_2 sorry
      have A11: "rngFUNCT-1K2 ?q c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      have A12: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-in+inftyLIMFUNC1K5 f1))"
      proof-
        have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-in+inftyLIMFUNC1K5 f1))"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-in+inftyLIMFUNC1K5 f1))"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q)"
            then obtain n where
              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A13: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
              using funct_2_th_113 sorry
            have A14: "x =HIDDENR1 f1 .FUNCT-1K1 (?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
              using A10 A11 A13 funct_2_th_108 xboole_1_th_1 sorry
            also have "... = f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
              using nat_1_def_3 sorry
            finally have "x =HIDDENR1 f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
               sorry
            have "r <XXREAL-0R3 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
              using A7 nat_1_th_12 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {r2 where r2 be RealXREAL-0M1 : r <XXREAL-0R3 r2 }"
               sorry
            then have A15: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 right-open-halflineLIMFUNC1K4 r"
              using xxreal_1_th_230 sorry
            have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
              using valued_0_th_28 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r)"
              using A10 A15 xboole_0_def_4 sorry
            then have "lim-in+inftyLIMFUNC1K5 f1 <XXREAL-0R3 f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
              using A4 sorry
            then have "x inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : lim-in+inftyLIMFUNC1K5 f1 <XXREAL-0R3 g1 }"
              using A14 sorry
            then have A16: "x inHIDDENR3 right-open-halflineLIMFUNC1K4 (lim-in+inftyLIMFUNC1K5 f1)"
              using xxreal_1_th_230 sorry
            have A17: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s)"
              using valued_0_th_28 sorry
            then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A8 sorry
            then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A10 A14 funct_2_th_108 A17 sorry
            thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-in+inftyLIMFUNC1K5 f1))"
              using A16 xboole_0_def_4 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-in+inftyLIMFUNC1K5 f1))"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A10 A11 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be convergentSEQ-2V5 & limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 lim-in+inftyLIMFUNC1K5 f1"
        using A1 A9 limfunc1_def_12 sorry
      then have A18: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) be divergent-to+inftyLIMFUNC1V1"
        using A2 A12 limfunc2_def_5 sorry
      have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        using A10 valued_0_th_27 sorry
      also have "... = f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A8 valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A6 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A18 limfunc1_th_7 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in+infty-to+inftyLIMFUNC1V4"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_30:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 be convergent-in+inftyLIMFUNC1V3 & f2 is-right-divergent-to-infty-inLIMFUNC2R6 lim-in+inftyLIMFUNC1K5 f1) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) & ( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies lim-in+inftyLIMFUNC1K5 f1 <XXREAL-0R3 f1 .FUNCT-1K1 g) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in+infty-to-inftyLIMFUNC1V5"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be convergent-in+inftyLIMFUNC1V3 & (f2 is-right-divergent-to-infty-inLIMFUNC2R6 lim-in+inftyLIMFUNC1K5 f1 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies (( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies lim-in+inftyLIMFUNC1K5 f1 <XXREAL-0R3 f1 .FUNCT-1K1 g) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in+infty-to-inftyLIMFUNC1V5)"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be convergent-in+inftyLIMFUNC1V3"
      and A2: "f2 is-right-divergent-to-infty-inLIMFUNC2R6 lim-in+inftyLIMFUNC1K5 f1"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    assume Given: " ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies lim-in+inftyLIMFUNC1K5 f1 <XXREAL-0R3 f1 .FUNCT-1K1 g"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A4: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies lim-in+inftyLIMFUNC1K5 f1 <XXREAL-0R3 f1 .FUNCT-1K1 g"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds s be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A5: "s be divergent-to+inftyLIMFUNC1V1"
        and A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A7: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies r <XXREAL-0R3 s .FUNCT-1K1 n"
        using A5 sorry
      have A8: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc4_lm_2 sorry
      let ?q = "s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "?q be divergent-to+inftyLIMFUNC1V1"
        using A5 limfunc1_th_26 sorry
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A6 limfunc4_lm_2 sorry
      have A11: "rngFUNCT-1K2 ?q c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      have A12: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-in+inftyLIMFUNC1K5 f1))"
      proof-
        have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-in+inftyLIMFUNC1K5 f1))"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-in+inftyLIMFUNC1K5 f1))"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q)"
            then obtain n where
              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A13: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
              using funct_2_th_113 sorry
            have A14: "x =HIDDENR1 f1 .FUNCT-1K1 (?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
              using A10 A11 A13 funct_2_th_108 xboole_1_th_1 sorry
            also have "... = f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
              using nat_1_def_3 sorry
            finally have "x =HIDDENR1 f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
               sorry
            have "r <XXREAL-0R3 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
              using A7 nat_1_th_12 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {r2 where r2 be RealXREAL-0M1 : r <XXREAL-0R3 r2 }"
               sorry
            then have A15: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 right-open-halflineLIMFUNC1K4 r"
              using xxreal_1_th_230 sorry
            have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
              using valued_0_th_28 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r)"
              using A10 A15 xboole_0_def_4 sorry
            then have "lim-in+inftyLIMFUNC1K5 f1 <XXREAL-0R3 f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
              using A4 sorry
            then have "x inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : lim-in+inftyLIMFUNC1K5 f1 <XXREAL-0R3 g1 }"
              using A14 sorry
            then have A16: "x inHIDDENR3 right-open-halflineLIMFUNC1K4 (lim-in+inftyLIMFUNC1K5 f1)"
              using xxreal_1_th_230 sorry
            have A17: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s)"
              using valued_0_th_28 sorry
            then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A8 sorry
            then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A10 A14 funct_2_th_108 A17 sorry
            thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-in+inftyLIMFUNC1K5 f1))"
              using A16 xboole_0_def_4 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-in+inftyLIMFUNC1K5 f1))"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A10 A11 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be convergentSEQ-2V5 & limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 lim-in+inftyLIMFUNC1K5 f1"
        using A1 A9 limfunc1_def_12 sorry
      then have A18: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) be divergent-to-inftyLIMFUNC1V2"
        using A2 A12 limfunc2_def_6 sorry
      have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        using A10 valued_0_th_27 sorry
      also have "... = f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A8 valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A6 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A18 limfunc1_th_7 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in+infty-to-inftyLIMFUNC1V5"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_31:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 be convergent-in-inftyLIMFUNC1V6 & f2 is-left-divergent-to+infty-inLIMFUNC2R2 lim-in-inftyLIMFUNC1K6 f1) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) & ( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <XXREAL-0R3 lim-in-inftyLIMFUNC1K6 f1) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in-infty-to+inftyLIMFUNC1V7"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be convergent-in-inftyLIMFUNC1V6 & (f2 is-left-divergent-to+infty-inLIMFUNC2R2 lim-in-inftyLIMFUNC1K6 f1 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies (( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <XXREAL-0R3 lim-in-inftyLIMFUNC1K6 f1) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in-infty-to+inftyLIMFUNC1V7)"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be convergent-in-inftyLIMFUNC1V6"
      and A2: "f2 is-left-divergent-to+infty-inLIMFUNC2R2 lim-in-inftyLIMFUNC1K6 f1"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    assume Given: " ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <XXREAL-0R3 lim-in-inftyLIMFUNC1K6 f1"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A4: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <XXREAL-0R3 lim-in-inftyLIMFUNC1K6 f1"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds s be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A5: "s be divergent-to-inftyLIMFUNC1V2"
        and A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A7: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies s .FUNCT-1K1 n <XXREAL-0R3 r"
        using A5 sorry
      have A8: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc4_lm_2 sorry
      let ?q = "s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "?q be divergent-to-inftyLIMFUNC1V2"
        using A5 limfunc1_th_27 sorry
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A6 limfunc4_lm_2 sorry
      have A11: "rngFUNCT-1K2 ?q c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      have A12: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-in-inftyLIMFUNC1K6 f1))"
      proof-
        have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-in-inftyLIMFUNC1K6 f1))"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-in-inftyLIMFUNC1K6 f1))"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q)"
            then obtain n where
              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A13: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
              using funct_2_th_113 sorry
            have A14: "x =HIDDENR1 f1 .FUNCT-1K1 (?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
              using A10 A11 A13 funct_2_th_108 xboole_1_th_1 sorry
            also have "... = f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
              using nat_1_def_3 sorry
            finally have "x =HIDDENR1 f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
               sorry
            have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) <XXREAL-0R3 r"
              using A7 nat_1_th_12 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {r2 where r2 be RealXREAL-0M1 : r2 <XXREAL-0R3 r }"
               sorry
            then have A15: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 left-open-halflineLIMFUNC1K1 r"
              using xxreal_1_th_229 sorry
            have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
              using valued_0_th_28 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r)"
              using A10 A15 xboole_0_def_4 sorry
            then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) <XXREAL-0R3 lim-in-inftyLIMFUNC1K6 f1"
              using A4 sorry
            then have "x inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : g1 <XXREAL-0R3 lim-in-inftyLIMFUNC1K6 f1 }"
              using A14 sorry
            then have A16: "x inHIDDENR3 left-open-halflineLIMFUNC1K1 (lim-in-inftyLIMFUNC1K6 f1)"
              using xxreal_1_th_229 sorry
            have A17: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s)"
              using valued_0_th_28 sorry
            then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A8 sorry
            then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A10 A14 funct_2_th_108 A17 sorry
            thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-in-inftyLIMFUNC1K6 f1))"
              using A16 xboole_0_def_4 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-in-inftyLIMFUNC1K6 f1))"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A10 A11 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be convergentSEQ-2V5 & limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 lim-in-inftyLIMFUNC1K6 f1"
        using A1 A9 limfunc1_def_13 sorry
      then have A18: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) be divergent-to+inftyLIMFUNC1V1"
        using A2 A12 limfunc2_def_2 sorry
      have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        using A10 valued_0_th_27 sorry
      also have "... = f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A8 valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A6 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A18 limfunc1_th_7 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in-infty-to+inftyLIMFUNC1V7"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_32:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 be convergent-in-inftyLIMFUNC1V6 & f2 is-left-divergent-to-infty-inLIMFUNC2R3 lim-in-inftyLIMFUNC1K6 f1) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) & ( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <XXREAL-0R3 lim-in-inftyLIMFUNC1K6 f1) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in-infty-to-inftyLIMFUNC1V8"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be convergent-in-inftyLIMFUNC1V6 & (f2 is-left-divergent-to-infty-inLIMFUNC2R3 lim-in-inftyLIMFUNC1K6 f1 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies (( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <XXREAL-0R3 lim-in-inftyLIMFUNC1K6 f1) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in-infty-to-inftyLIMFUNC1V8)"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be convergent-in-inftyLIMFUNC1V6"
      and A2: "f2 is-left-divergent-to-infty-inLIMFUNC2R3 lim-in-inftyLIMFUNC1K6 f1"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    assume Given: " ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <XXREAL-0R3 lim-in-inftyLIMFUNC1K6 f1"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A4: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <XXREAL-0R3 lim-in-inftyLIMFUNC1K6 f1"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds s be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A5: "s be divergent-to-inftyLIMFUNC1V2"
        and A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A7: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies s .FUNCT-1K1 n <XXREAL-0R3 r"
        using A5 sorry
      have A8: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc4_lm_2 sorry
      let ?q = "s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "?q be divergent-to-inftyLIMFUNC1V2"
        using A5 limfunc1_th_27 sorry
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A6 limfunc4_lm_2 sorry
      have A11: "rngFUNCT-1K2 ?q c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      have A12: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-in-inftyLIMFUNC1K6 f1))"
      proof-
        have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-in-inftyLIMFUNC1K6 f1))"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-in-inftyLIMFUNC1K6 f1))"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q)"
            then obtain n where
              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A13: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
              using funct_2_th_113 sorry
            have A14: "x =HIDDENR1 f1 .FUNCT-1K1 (?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
              using A10 A11 A13 funct_2_th_108 xboole_1_th_1 sorry
            also have "... = f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
              using nat_1_def_3 sorry
            finally have "x =HIDDENR1 f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
               sorry
            have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) <XXREAL-0R3 r"
              using A7 nat_1_th_12 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {r2 where r2 be RealXREAL-0M1 : r2 <XXREAL-0R3 r }"
               sorry
            then have A15: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 left-open-halflineLIMFUNC1K1 r"
              using xxreal_1_th_229 sorry
            have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
              using valued_0_th_28 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r)"
              using A10 A15 xboole_0_def_4 sorry
            then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) <XXREAL-0R3 lim-in-inftyLIMFUNC1K6 f1"
              using A4 sorry
            then have "x inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : g1 <XXREAL-0R3 lim-in-inftyLIMFUNC1K6 f1 }"
              using A14 sorry
            then have A16: "x inHIDDENR3 left-open-halflineLIMFUNC1K1 (lim-in-inftyLIMFUNC1K6 f1)"
              using xxreal_1_th_229 sorry
            have A17: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s)"
              using valued_0_th_28 sorry
            then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A8 sorry
            then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A10 A14 funct_2_th_108 A17 sorry
            thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-in-inftyLIMFUNC1K6 f1))"
              using A16 xboole_0_def_4 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-in-inftyLIMFUNC1K6 f1))"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A10 A11 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be convergentSEQ-2V5 & limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 lim-in-inftyLIMFUNC1K6 f1"
        using A1 A9 limfunc1_def_13 sorry
      then have A18: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) be divergent-to-inftyLIMFUNC1V2"
        using A2 A12 limfunc2_def_3 sorry
      have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        using A10 valued_0_th_27 sorry
      also have "... = f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A8 valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A6 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A18 limfunc1_th_7 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in-infty-to-inftyLIMFUNC1V8"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_33:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 be convergent-in-inftyLIMFUNC1V6 & f2 is-right-divergent-to+infty-inLIMFUNC2R5 lim-in-inftyLIMFUNC1K6 f1) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) & ( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies lim-in-inftyLIMFUNC1K6 f1 <XXREAL-0R3 f1 .FUNCT-1K1 g) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in-infty-to+inftyLIMFUNC1V7"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be convergent-in-inftyLIMFUNC1V6 & (f2 is-right-divergent-to+infty-inLIMFUNC2R5 lim-in-inftyLIMFUNC1K6 f1 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies (( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies lim-in-inftyLIMFUNC1K6 f1 <XXREAL-0R3 f1 .FUNCT-1K1 g) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in-infty-to+inftyLIMFUNC1V7)"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be convergent-in-inftyLIMFUNC1V6"
      and A2: "f2 is-right-divergent-to+infty-inLIMFUNC2R5 lim-in-inftyLIMFUNC1K6 f1"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    assume Given: " ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies lim-in-inftyLIMFUNC1K6 f1 <XXREAL-0R3 f1 .FUNCT-1K1 g"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A4: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies lim-in-inftyLIMFUNC1K6 f1 <XXREAL-0R3 f1 .FUNCT-1K1 g"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds s be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A5: "s be divergent-to-inftyLIMFUNC1V2"
        and A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A7: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies s .FUNCT-1K1 n <XXREAL-0R3 r"
        using A5 sorry
      have A8: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc4_lm_2 sorry
      let ?q = "s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "?q be divergent-to-inftyLIMFUNC1V2"
        using A5 limfunc1_th_27 sorry
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A6 limfunc4_lm_2 sorry
      have A11: "rngFUNCT-1K2 ?q c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      have A12: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-in-inftyLIMFUNC1K6 f1))"
      proof-
        have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-in-inftyLIMFUNC1K6 f1))"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-in-inftyLIMFUNC1K6 f1))"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q)"
            then obtain n where
              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A13: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
              using funct_2_th_113 sorry
            have A14: "x =HIDDENR1 f1 .FUNCT-1K1 (?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
              using A10 A11 A13 funct_2_th_108 xboole_1_th_1 sorry
            also have "... = f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
              using nat_1_def_3 sorry
            finally have "x =HIDDENR1 f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
               sorry
            have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) <XXREAL-0R3 r"
              using A7 nat_1_th_12 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {r2 where r2 be RealXREAL-0M1 : r2 <XXREAL-0R3 r }"
               sorry
            then have A15: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 left-open-halflineLIMFUNC1K1 r"
              using xxreal_1_th_229 sorry
            have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
              using valued_0_th_28 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r)"
              using A10 A15 xboole_0_def_4 sorry
            then have "lim-in-inftyLIMFUNC1K6 f1 <XXREAL-0R3 f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
              using A4 sorry
            then have "x inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : lim-in-inftyLIMFUNC1K6 f1 <XXREAL-0R3 g1 }"
              using A14 sorry
            then have A16: "x inHIDDENR3 right-open-halflineLIMFUNC1K4 (lim-in-inftyLIMFUNC1K6 f1)"
              using xxreal_1_th_230 sorry
            have A17: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s)"
              using valued_0_th_28 sorry
            then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A8 sorry
            then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A10 A14 funct_2_th_108 A17 sorry
            thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-in-inftyLIMFUNC1K6 f1))"
              using A16 xboole_0_def_4 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-in-inftyLIMFUNC1K6 f1))"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A10 A11 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be convergentSEQ-2V5 & limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 lim-in-inftyLIMFUNC1K6 f1"
        using A1 A9 limfunc1_def_13 sorry
      then have A18: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) be divergent-to+inftyLIMFUNC1V1"
        using A2 A12 limfunc2_def_5 sorry
      have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        using A10 valued_0_th_27 sorry
      also have "... = f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A8 valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A6 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A18 limfunc1_th_7 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in-infty-to+inftyLIMFUNC1V7"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_34:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 be convergent-in-inftyLIMFUNC1V6 & f2 is-right-divergent-to-infty-inLIMFUNC2R6 lim-in-inftyLIMFUNC1K6 f1) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) & ( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies lim-in-inftyLIMFUNC1K6 f1 <XXREAL-0R3 f1 .FUNCT-1K1 g) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in-infty-to-inftyLIMFUNC1V8"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be convergent-in-inftyLIMFUNC1V6 & (f2 is-right-divergent-to-infty-inLIMFUNC2R6 lim-in-inftyLIMFUNC1K6 f1 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies (( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies lim-in-inftyLIMFUNC1K6 f1 <XXREAL-0R3 f1 .FUNCT-1K1 g) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in-infty-to-inftyLIMFUNC1V8)"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be convergent-in-inftyLIMFUNC1V6"
      and A2: "f2 is-right-divergent-to-infty-inLIMFUNC2R6 lim-in-inftyLIMFUNC1K6 f1"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    assume Given: " ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies lim-in-inftyLIMFUNC1K6 f1 <XXREAL-0R3 f1 .FUNCT-1K1 g"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A4: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies lim-in-inftyLIMFUNC1K6 f1 <XXREAL-0R3 f1 .FUNCT-1K1 g"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds s be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A5: "s be divergent-to-inftyLIMFUNC1V2"
        and A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A7: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies s .FUNCT-1K1 n <XXREAL-0R3 r"
        using A5 sorry
      have A8: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc4_lm_2 sorry
      let ?q = "s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "?q be divergent-to-inftyLIMFUNC1V2"
        using A5 limfunc1_th_27 sorry
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A6 limfunc4_lm_2 sorry
      have A11: "rngFUNCT-1K2 ?q c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      have A12: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-in-inftyLIMFUNC1K6 f1))"
      proof-
        have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-in-inftyLIMFUNC1K6 f1))"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-in-inftyLIMFUNC1K6 f1))"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q)"
            then obtain n where
              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A13: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
              using funct_2_th_113 sorry
            have A14: "x =HIDDENR1 f1 .FUNCT-1K1 (?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
              using A10 A11 A13 funct_2_th_108 xboole_1_th_1 sorry
            also have "... = f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
              using nat_1_def_3 sorry
            finally have "x =HIDDENR1 f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
               sorry
            have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) <XXREAL-0R3 r"
              using A7 nat_1_th_12 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {r2 where r2 be RealXREAL-0M1 : r2 <XXREAL-0R3 r }"
               sorry
            then have A15: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 left-open-halflineLIMFUNC1K1 r"
              using xxreal_1_th_229 sorry
            have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
              using valued_0_th_28 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r)"
              using A10 A15 xboole_0_def_4 sorry
            then have "lim-in-inftyLIMFUNC1K6 f1 <XXREAL-0R3 f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
              using A4 sorry
            then have "x inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : lim-in-inftyLIMFUNC1K6 f1 <XXREAL-0R3 g1 }"
              using A14 sorry
            then have A16: "x inHIDDENR3 right-open-halflineLIMFUNC1K4 (lim-in-inftyLIMFUNC1K6 f1)"
              using xxreal_1_th_230 sorry
            have A17: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s)"
              using valued_0_th_28 sorry
            then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A8 sorry
            then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A10 A14 funct_2_th_108 A17 sorry
            thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-in-inftyLIMFUNC1K6 f1))"
              using A16 xboole_0_def_4 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-in-inftyLIMFUNC1K6 f1))"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A10 A11 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be convergentSEQ-2V5 & limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 lim-in-inftyLIMFUNC1K6 f1"
        using A1 A9 limfunc1_def_13 sorry
      then have A18: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) be divergent-to-inftyLIMFUNC1V2"
        using A2 A12 limfunc2_def_6 sorry
      have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        using A10 valued_0_th_27 sorry
      also have "... = f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A8 valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A6 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A18 limfunc1_th_7 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in-infty-to-inftyLIMFUNC1V8"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_35:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-divergent-to+infty-inLIMFUNC3R2 x0 & f2 be divergent-in+infty-to+inftyLIMFUNC1V4) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-divergent-to+infty-inLIMFUNC3R2 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-divergent-to+infty-inLIMFUNC3R2 x0 & (f2 be divergent-in+infty-to+inftyLIMFUNC1V4 & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-divergent-to+infty-inLIMFUNC3R2 x0"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-divergent-to+infty-inLIMFUNC3R2 x0"
      and A2: "f2 be divergent-in+infty-to+inftyLIMFUNC1V4"
      and A3: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    have " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0} implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A4: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A5: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
      have A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A5 limfunc4_th_2 sorry
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
        using A5 limfunc4_th_2 sorry
      then have A7: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A1 A4 limfunc3_def_2 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A5 limfunc4_th_2 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) be divergent-to+inftyLIMFUNC1V1"
        using A2 A7 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A6 valued_0_th_31 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-divergent-to+infty-inLIMFUNC3R2 x0"
      using A3 limfunc3_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_36:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-divergent-to+infty-inLIMFUNC3R2 x0 & f2 be divergent-in+infty-to-inftyLIMFUNC1V5) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-divergent-to-infty-inLIMFUNC3R3 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-divergent-to+infty-inLIMFUNC3R2 x0 & (f2 be divergent-in+infty-to-inftyLIMFUNC1V5 & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-divergent-to-infty-inLIMFUNC3R3 x0"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-divergent-to+infty-inLIMFUNC3R2 x0"
      and A2: "f2 be divergent-in+infty-to-inftyLIMFUNC1V5"
      and A3: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    have " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0} implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A4: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A5: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
      have A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A5 limfunc4_th_2 sorry
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
        using A5 limfunc4_th_2 sorry
      then have A7: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A1 A4 limfunc3_def_2 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A5 limfunc4_th_2 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) be divergent-to-inftyLIMFUNC1V2"
        using A2 A7 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A6 valued_0_th_31 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-divergent-to-infty-inLIMFUNC3R3 x0"
      using A3 limfunc3_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_37:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-divergent-to-infty-inLIMFUNC3R3 x0 & f2 be divergent-in-infty-to+inftyLIMFUNC1V7) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-divergent-to+infty-inLIMFUNC3R2 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-divergent-to-infty-inLIMFUNC3R3 x0 & (f2 be divergent-in-infty-to+inftyLIMFUNC1V7 & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-divergent-to+infty-inLIMFUNC3R2 x0"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-divergent-to-infty-inLIMFUNC3R3 x0"
      and A2: "f2 be divergent-in-infty-to+inftyLIMFUNC1V7"
      and A3: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    have " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0} implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A4: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A5: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
      have A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A5 limfunc4_th_2 sorry
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
        using A5 limfunc4_th_2 sorry
      then have A7: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A1 A4 limfunc3_def_3 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A5 limfunc4_th_2 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) be divergent-to+inftyLIMFUNC1V1"
        using A2 A7 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A6 valued_0_th_31 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-divergent-to+infty-inLIMFUNC3R2 x0"
      using A3 limfunc3_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_38:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-divergent-to-infty-inLIMFUNC3R3 x0 & f2 be divergent-in-infty-to-inftyLIMFUNC1V8) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-divergent-to-infty-inLIMFUNC3R3 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-divergent-to-infty-inLIMFUNC3R3 x0 & (f2 be divergent-in-infty-to-inftyLIMFUNC1V8 & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-divergent-to-infty-inLIMFUNC3R3 x0"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-divergent-to-infty-inLIMFUNC3R3 x0"
      and A2: "f2 be divergent-in-infty-to-inftyLIMFUNC1V8"
      and A3: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    have " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0} implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A4: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A5: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
      have A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A5 limfunc4_th_2 sorry
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
        using A5 limfunc4_th_2 sorry
      then have A7: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A1 A4 limfunc3_def_3 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A5 limfunc4_th_2 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) be divergent-to-inftyLIMFUNC1V2"
        using A2 A7 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A6 valued_0_th_31 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-divergent-to-infty-inLIMFUNC3R3 x0"
      using A3 limfunc3_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_39:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-convergent-inLIMFUNC3R1 x0 & f2 is-divergent-to+infty-inLIMFUNC3R2 limLIMFUNC3K1(f1,x0)) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) & ( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 limLIMFUNC3K1(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-divergent-to+infty-inLIMFUNC3R2 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-convergent-inLIMFUNC3R1 x0 & (f2 is-divergent-to+infty-inLIMFUNC3R2 limLIMFUNC3K1(f1,x0) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies (( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 limLIMFUNC3K1(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-divergent-to+infty-inLIMFUNC3R2 x0)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-convergent-inLIMFUNC3R1 x0"
      and A2: "f2 is-divergent-to+infty-inLIMFUNC3R2 limLIMFUNC3K1(f1,x0)"
      and A3: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    assume Given: " ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 limLIMFUNC3K1(f1,x0))"
    then obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 g"and A5: " for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 limLIMFUNC3K1(f1,x0)"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0} implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A6: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A7: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
      obtain k where
        [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
        A8: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0 +XCMPLX-0K2 g"
        using A4 A6 limfunc3_th_7 sorry
      let ?q = "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A7 limfunc4_th_2 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 limfunc4_th_2 sorry
      then have A10: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A9 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have A11: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
        using A7 limfunc4_th_2 sorry
      then have A12: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A1 A2 A6 limfunc3_def_4 sorry
      have A13: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A7 limfunc4_th_2 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 limLIMFUNC3K1(f1,x0) }"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 ?q"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A14: "?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
          using funct_2_th_113 sorry
        have A15: "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) =HIDDENR1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)"
          using A13 funct_2_th_108 sorry
        also have "... = x"
          using A14 nat_1_def_3 sorry
        finally have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) =HIDDENR1 x"
           sorry
        have "k <=XXREAL-0R1 n +NAT-1K1 k"
          using nat_1_th_12 sorry
        then have "x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) <XXREAL-0R3 x0 +XCMPLX-0K2 g"
          using A8 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : x0 -XCMPLX-0K6 g <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0 +XCMPLX-0K2 g }"
           sorry
        then have A16: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 +XCMPLX-0K2 g .["
          using rcomp_1_def_2 sorry
        have A17: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 rngFUNCT-1K2 s"
          using valued_0_th_28 sorry
        then have " not s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 {TARSKIK1 x0}"
          using A7 xboole_0_def_5 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 +XCMPLX-0K2 g .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
          using A16 xboole_0_def_5 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .["
          using A4 limfunc3_th_4 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[)"
          using A13 A17 xboole_0_def_4 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) <>HIDDENR2 limLIMFUNC3K1(f1,x0)"
          using A5 sorry
        then have A18: " not f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) inTARSKIR2 {TARSKIK1 limLIMFUNC3K1(f1,x0) }"
          using tarski_def_1 sorry
        have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A9 A17 funct_1_th_11 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 limLIMFUNC3K1(f1,x0) }"
          using A18 A15 xboole_0_def_5 sorry
      qed "sorry"
      then have A19: "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 limLIMFUNC3K1(f1,x0) }"
         sorry
      have "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 limLIMFUNC3K1(f1,x0)"
        using A1 A6 A11 limfunc3_def_4 sorry
      then have "limSEQ-2K1 ?q =HIDDENR1 limLIMFUNC3K1(f1,x0)"
        using A12 seq_4_th_20 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be divergent-to+inftyLIMFUNC1V1"
        using A2 A12 A19 limfunc3_def_2 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A10 limfunc1_th_7 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-divergent-to+infty-inLIMFUNC3R2 x0"
      using A3 limfunc3_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_40:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-convergent-inLIMFUNC3R1 x0 & f2 is-divergent-to-infty-inLIMFUNC3R3 limLIMFUNC3K1(f1,x0)) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) & ( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 limLIMFUNC3K1(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-divergent-to-infty-inLIMFUNC3R3 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-convergent-inLIMFUNC3R1 x0 & (f2 is-divergent-to-infty-inLIMFUNC3R3 limLIMFUNC3K1(f1,x0) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies (( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 limLIMFUNC3K1(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-divergent-to-infty-inLIMFUNC3R3 x0)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-convergent-inLIMFUNC3R1 x0"
      and A2: "f2 is-divergent-to-infty-inLIMFUNC3R3 limLIMFUNC3K1(f1,x0)"
      and A3: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    assume Given: " ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 limLIMFUNC3K1(f1,x0))"
    then obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 g"and A5: " for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 limLIMFUNC3K1(f1,x0)"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0} implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A6: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A7: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
      obtain k where
        [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
        A8: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0 +XCMPLX-0K2 g"
        using A4 A6 limfunc3_th_7 sorry
      let ?q = "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A7 limfunc4_th_2 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 limfunc4_th_2 sorry
      then have A10: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A9 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have A11: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
        using A7 limfunc4_th_2 sorry
      then have A12: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A1 A2 A6 limfunc3_def_4 sorry
      have A13: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A7 limfunc4_th_2 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 limLIMFUNC3K1(f1,x0) }"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 ?q"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A14: "?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
          using funct_2_th_113 sorry
        have A15: "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) =HIDDENR1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)"
          using A13 funct_2_th_108 sorry
        also have "... = x"
          using A14 nat_1_def_3 sorry
        finally have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) =HIDDENR1 x"
           sorry
        have "k <=XXREAL-0R1 n +NAT-1K1 k"
          using nat_1_th_12 sorry
        then have "x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) <XXREAL-0R3 x0 +XCMPLX-0K2 g"
          using A8 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : x0 -XCMPLX-0K6 g <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0 +XCMPLX-0K2 g }"
           sorry
        then have A16: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 +XCMPLX-0K2 g .["
          using rcomp_1_def_2 sorry
        have A17: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 rngFUNCT-1K2 s"
          using valued_0_th_28 sorry
        then have " not s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 {TARSKIK1 x0}"
          using A7 xboole_0_def_5 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 +XCMPLX-0K2 g .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
          using A16 xboole_0_def_5 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .["
          using A4 limfunc3_th_4 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[)"
          using A13 A17 xboole_0_def_4 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) <>HIDDENR2 limLIMFUNC3K1(f1,x0)"
          using A5 sorry
        then have A18: " not f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) inTARSKIR2 {TARSKIK1 limLIMFUNC3K1(f1,x0) }"
          using tarski_def_1 sorry
        have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A9 A17 funct_1_th_11 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 limLIMFUNC3K1(f1,x0) }"
          using A18 A15 xboole_0_def_5 sorry
      qed "sorry"
      then have A19: "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 limLIMFUNC3K1(f1,x0) }"
         sorry
      have "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 limLIMFUNC3K1(f1,x0)"
        using A1 A6 A11 limfunc3_def_4 sorry
      then have "limSEQ-2K1 ?q =HIDDENR1 limLIMFUNC3K1(f1,x0)"
        using A12 seq_4_th_20 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be divergent-to-inftyLIMFUNC1V2"
        using A2 A12 A19 limfunc3_def_3 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A10 limfunc1_th_7 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-divergent-to-infty-inLIMFUNC3R3 x0"
      using A3 limfunc3_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_41:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-convergent-inLIMFUNC3R1 x0 & f2 is-right-divergent-to+infty-inLIMFUNC2R5 limLIMFUNC3K1(f1,x0)) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) & ( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r >XXREAL-0R4 limLIMFUNC3K1(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-divergent-to+infty-inLIMFUNC3R2 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-convergent-inLIMFUNC3R1 x0 & (f2 is-right-divergent-to+infty-inLIMFUNC2R5 limLIMFUNC3K1(f1,x0) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies (( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies limLIMFUNC3K1(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 r)) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-divergent-to+infty-inLIMFUNC3R2 x0)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-convergent-inLIMFUNC3R1 x0"
      and A2: "f2 is-right-divergent-to+infty-inLIMFUNC2R5 limLIMFUNC3K1(f1,x0)"
      and A3: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    assume Given: " ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies limLIMFUNC3K1(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 r)"
    then obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 g"and A5: " for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies limLIMFUNC3K1(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 r"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0} implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A6: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A7: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
      obtain k where
        [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
        A8: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0 +XCMPLX-0K2 g"
        using A4 A6 limfunc3_th_7 sorry
      let ?q = "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A7 limfunc4_th_2 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 limfunc4_th_2 sorry
      then have A10: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A9 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have A11: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
        using A7 limfunc4_th_2 sorry
      then have A12: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A1 A2 A6 limfunc3_def_4 sorry
      have A13: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A7 limfunc4_th_2 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (limLIMFUNC3K1(f1,x0)))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 ?q"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A14: "?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
          using funct_2_th_113 sorry
        have A15: "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) =HIDDENR1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)"
          using A13 funct_2_th_108 sorry
        also have "... = x"
          using A14 nat_1_def_3 sorry
        finally have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) =HIDDENR1 x"
           sorry
        have "k <=XXREAL-0R1 n +NAT-1K1 k"
          using nat_1_th_12 sorry
        then have "x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) <XXREAL-0R3 x0 +XCMPLX-0K2 g"
          using A8 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : x0 -XCMPLX-0K6 g <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0 +XCMPLX-0K2 g }"
           sorry
        then have A16: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 +XCMPLX-0K2 g .["
          using rcomp_1_def_2 sorry
        have A17: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 rngFUNCT-1K2 s"
          using valued_0_th_28 sorry
        then have " not s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 {TARSKIK1 x0}"
          using A7 xboole_0_def_5 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 +XCMPLX-0K2 g .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
          using A16 xboole_0_def_5 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .["
          using A4 limfunc3_th_4 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[)"
          using A13 A17 xboole_0_def_4 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) >XXREAL-0R4 limLIMFUNC3K1(f1,x0)"
          using A5 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : limLIMFUNC3K1(f1,x0) <XXREAL-0R3 g2 }"
           sorry
        then have A18: "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) inTARSKIR2 right-open-halflineLIMFUNC1K4 (limLIMFUNC3K1(f1,x0))"
          using xxreal_1_th_230 sorry
        have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A9 A17 funct_1_th_11 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (limLIMFUNC3K1(f1,x0)))"
          using A18 A15 xboole_0_def_4 sorry
      qed "sorry"
      then have A19: "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (limLIMFUNC3K1(f1,x0)))"
         sorry
      have "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 limLIMFUNC3K1(f1,x0)"
        using A1 A6 A11 limfunc3_def_4 sorry
      then have "limSEQ-2K1 ?q =HIDDENR1 limLIMFUNC3K1(f1,x0)"
        using A12 seq_4_th_20 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be divergent-to+inftyLIMFUNC1V1"
        using A2 A12 A19 limfunc2_def_5 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A10 limfunc1_th_7 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-divergent-to+infty-inLIMFUNC3R2 x0"
      using A3 limfunc3_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_42:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-convergent-inLIMFUNC3R1 x0 & f2 is-right-divergent-to-infty-inLIMFUNC2R6 limLIMFUNC3K1(f1,x0)) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) & ( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r >XXREAL-0R4 limLIMFUNC3K1(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-divergent-to-infty-inLIMFUNC3R3 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-convergent-inLIMFUNC3R1 x0 & (f2 is-right-divergent-to-infty-inLIMFUNC2R6 limLIMFUNC3K1(f1,x0) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies (( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies limLIMFUNC3K1(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 r)) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-divergent-to-infty-inLIMFUNC3R3 x0)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-convergent-inLIMFUNC3R1 x0"
      and A2: "f2 is-right-divergent-to-infty-inLIMFUNC2R6 limLIMFUNC3K1(f1,x0)"
      and A3: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    assume Given: " ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies limLIMFUNC3K1(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 r)"
    then obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 g"and A5: " for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies limLIMFUNC3K1(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 r"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0} implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A6: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A7: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
      obtain k where
        [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
        A8: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0 +XCMPLX-0K2 g"
        using A4 A6 limfunc3_th_7 sorry
      let ?q = "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A7 limfunc4_th_2 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 limfunc4_th_2 sorry
      then have A10: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A9 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have A11: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
        using A7 limfunc4_th_2 sorry
      then have A12: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A1 A2 A6 limfunc3_def_4 sorry
      have A13: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A7 limfunc4_th_2 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (limLIMFUNC3K1(f1,x0)))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 ?q"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A14: "?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
          using funct_2_th_113 sorry
        have A15: "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) =HIDDENR1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)"
          using A13 funct_2_th_108 sorry
        also have "... = x"
          using A14 nat_1_def_3 sorry
        finally have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) =HIDDENR1 x"
           sorry
        have "k <=XXREAL-0R1 n +NAT-1K1 k"
          using nat_1_th_12 sorry
        then have "x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) <XXREAL-0R3 x0 +XCMPLX-0K2 g"
          using A8 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : x0 -XCMPLX-0K6 g <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0 +XCMPLX-0K2 g }"
           sorry
        then have A16: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 +XCMPLX-0K2 g .["
          using rcomp_1_def_2 sorry
        have A17: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 rngFUNCT-1K2 s"
          using valued_0_th_28 sorry
        then have " not s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 {TARSKIK1 x0}"
          using A7 xboole_0_def_5 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 +XCMPLX-0K2 g .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
          using A16 xboole_0_def_5 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .["
          using A4 limfunc3_th_4 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[)"
          using A13 A17 xboole_0_def_4 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) >XXREAL-0R4 limLIMFUNC3K1(f1,x0)"
          using A5 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : limLIMFUNC3K1(f1,x0) <XXREAL-0R3 g2 }"
           sorry
        then have A18: "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) inTARSKIR2 right-open-halflineLIMFUNC1K4 (limLIMFUNC3K1(f1,x0))"
          using xxreal_1_th_230 sorry
        have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A9 A17 funct_1_th_11 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (limLIMFUNC3K1(f1,x0)))"
          using A18 A15 xboole_0_def_4 sorry
      qed "sorry"
      then have A19: "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (limLIMFUNC3K1(f1,x0)))"
         sorry
      have "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 limLIMFUNC3K1(f1,x0)"
        using A1 A6 A11 limfunc3_def_4 sorry
      then have "limSEQ-2K1 ?q =HIDDENR1 limLIMFUNC3K1(f1,x0)"
        using A12 seq_4_th_20 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be divergent-to-inftyLIMFUNC1V2"
        using A2 A12 A19 limfunc2_def_6 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A10 limfunc1_th_7 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-divergent-to-infty-inLIMFUNC3R3 x0"
      using A3 limfunc3_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_43:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-right-convergent-inLIMFUNC2R4 x0 & f2 is-divergent-to+infty-inLIMFUNC3R2 lim-rightLIMFUNC2K2(f1,x0)) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) & ( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 lim-rightLIMFUNC2K2(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-divergent-to+infty-inLIMFUNC2R5 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-right-convergent-inLIMFUNC2R4 x0 & (f2 is-divergent-to+infty-inLIMFUNC3R2 lim-rightLIMFUNC2K2(f1,x0) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies (( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 lim-rightLIMFUNC2K2(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-divergent-to+infty-inLIMFUNC2R5 x0)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-right-convergent-inLIMFUNC2R4 x0"
      and A2: "f2 is-divergent-to+infty-inLIMFUNC3R2 lim-rightLIMFUNC2K2(f1,x0)"
      and A3: " for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    assume Given: " ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 lim-rightLIMFUNC2K2(f1,x0))"
    then obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 g"and A5: " for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 lim-rightLIMFUNC2K2(f1,x0)"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A6: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A7: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A8: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies s .FUNCT-1K1 n <XXREAL-0R3 x0 +XCMPLX-0K2 g"
        using A4 A6 limfunc4_lm_1 limfunc2_th_2 sorry
      let ?q = "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A7 limfunc4_th_1 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 limfunc4_th_1 sorry
      then have A10: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A9 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have A11: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
        using A7 limfunc4_th_1 sorry
      then have A12: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A1 A2 A6 limfunc2_def_8 sorry
      have A13: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A7 limfunc4_th_1 sorry
      have A14: "rngFUNCT-1K2 s c=TARSKIR1 right-open-halflineLIMFUNC1K4 x0"
        using A7 limfunc4_th_1 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-rightLIMFUNC2K2(f1,x0) }"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 ?q"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A15: "?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
          using funct_2_th_113 sorry
        have A16: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have A17: "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A13 funct_2_th_108 A16 sorry
        also have "... = x"
          using A15 nat_1_def_3 sorry
        finally have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 x"
           sorry
        have A18: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) <XXREAL-0R3 x0 +XCMPLX-0K2 g"
          using A8 nat_1_th_12 sorry
        have A19: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
          using valued_0_th_28 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 right-open-halflineLIMFUNC1K4 x0"
          using A14 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : x0 <XXREAL-0R3 g1 }"
          using xxreal_1_th_230 sorry
        then have " ex g1 be RealXREAL-0M1 st g1 =HIDDENR1 s .FUNCT-1K1 (n +XCMPLX-0K2 k) & x0 <XXREAL-0R3 g1"
           sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : x0 <XXREAL-0R3 g2 & g2 <XXREAL-0R3 x0 +XCMPLX-0K2 g }"
          using A18 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .["
          using rcomp_1_def_2 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[)"
          using A13 A19 xboole_0_def_4 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) <>HIDDENR2 lim-rightLIMFUNC2K2(f1,x0)"
          using A5 sorry
        then have A20: " not f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 {TARSKIK1 lim-rightLIMFUNC2K2(f1,x0) }"
          using tarski_def_1 sorry
        have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A9 A19 funct_1_th_11 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-rightLIMFUNC2K2(f1,x0) }"
          using A20 A17 xboole_0_def_5 sorry
      qed "sorry"
      then have A21: "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-rightLIMFUNC2K2(f1,x0) }"
         sorry
      have "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-rightLIMFUNC2K2(f1,x0)"
        using A1 A6 A11 limfunc2_def_8 sorry
      then have "limSEQ-2K1 ?q =HIDDENR1 lim-rightLIMFUNC2K2(f1,x0)"
        using A12 seq_4_th_20 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be divergent-to+inftyLIMFUNC1V1"
        using A2 A12 A21 limfunc3_def_2 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A10 limfunc1_th_7 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-divergent-to+infty-inLIMFUNC2R5 x0"
      using A3 limfunc2_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_44:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-right-convergent-inLIMFUNC2R4 x0 & f2 is-divergent-to-infty-inLIMFUNC3R3 lim-rightLIMFUNC2K2(f1,x0)) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) & ( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 lim-rightLIMFUNC2K2(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-divergent-to-infty-inLIMFUNC2R6 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-right-convergent-inLIMFUNC2R4 x0 & (f2 is-divergent-to-infty-inLIMFUNC3R3 lim-rightLIMFUNC2K2(f1,x0) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies (( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 lim-rightLIMFUNC2K2(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-divergent-to-infty-inLIMFUNC2R6 x0)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-right-convergent-inLIMFUNC2R4 x0"
      and A2: "f2 is-divergent-to-infty-inLIMFUNC3R3 lim-rightLIMFUNC2K2(f1,x0)"
      and A3: " for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    assume Given: " ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 lim-rightLIMFUNC2K2(f1,x0))"
    then obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 g"and A5: " for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 lim-rightLIMFUNC2K2(f1,x0)"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A6: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A7: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A8: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies s .FUNCT-1K1 n <XXREAL-0R3 x0 +XCMPLX-0K2 g"
        using A4 A6 limfunc4_lm_1 limfunc2_th_2 sorry
      let ?q = "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A7 limfunc4_th_1 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 limfunc4_th_1 sorry
      then have A10: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A9 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have A11: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
        using A7 limfunc4_th_1 sorry
      then have A12: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A1 A2 A6 limfunc2_def_8 sorry
      have A13: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A7 limfunc4_th_1 sorry
      have A14: "rngFUNCT-1K2 s c=TARSKIR1 right-open-halflineLIMFUNC1K4 x0"
        using A7 limfunc4_th_1 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-rightLIMFUNC2K2(f1,x0) }"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 ?q"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A15: "?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
          using funct_2_th_113 sorry
        have A16: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have A17: "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A13 funct_2_th_108 A16 sorry
        also have "... = x"
          using A15 nat_1_def_3 sorry
        finally have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 x"
           sorry
        have A18: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) <XXREAL-0R3 x0 +XCMPLX-0K2 g"
          using A8 nat_1_th_12 sorry
        have A19: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
          using valued_0_th_28 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 right-open-halflineLIMFUNC1K4 x0"
          using A14 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : x0 <XXREAL-0R3 g1 }"
          using xxreal_1_th_230 sorry
        then have " ex g1 be RealXREAL-0M1 st g1 =HIDDENR1 s .FUNCT-1K1 (n +XCMPLX-0K2 k) & x0 <XXREAL-0R3 g1"
           sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : x0 <XXREAL-0R3 g2 & g2 <XXREAL-0R3 x0 +XCMPLX-0K2 g }"
          using A18 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .["
          using rcomp_1_def_2 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[)"
          using A13 A19 xboole_0_def_4 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) <>HIDDENR2 lim-rightLIMFUNC2K2(f1,x0)"
          using A5 sorry
        then have A20: " not f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 {TARSKIK1 lim-rightLIMFUNC2K2(f1,x0) }"
          using tarski_def_1 sorry
        have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A9 A19 funct_1_th_11 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-rightLIMFUNC2K2(f1,x0) }"
          using A20 A17 xboole_0_def_5 sorry
      qed "sorry"
      then have A21: "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-rightLIMFUNC2K2(f1,x0) }"
         sorry
      have "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-rightLIMFUNC2K2(f1,x0)"
        using A1 A6 A11 limfunc2_def_8 sorry
      then have "limSEQ-2K1 ?q =HIDDENR1 lim-rightLIMFUNC2K2(f1,x0)"
        using A12 seq_4_th_20 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be divergent-to-inftyLIMFUNC1V2"
        using A2 A12 A21 limfunc3_def_3 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A10 limfunc1_th_7 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-divergent-to-infty-inLIMFUNC2R6 x0"
      using A3 limfunc2_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_45:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 be convergent-in+inftyLIMFUNC1V3 & f2 is-divergent-to+infty-inLIMFUNC3R2 lim-in+inftyLIMFUNC1K5 f1) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) & ( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <>HIDDENR2 lim-in+inftyLIMFUNC1K5 f1) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in+infty-to+inftyLIMFUNC1V4"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be convergent-in+inftyLIMFUNC1V3 & (f2 is-divergent-to+infty-inLIMFUNC3R2 lim-in+inftyLIMFUNC1K5 f1 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies (( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <>HIDDENR2 lim-in+inftyLIMFUNC1K5 f1) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in+infty-to+inftyLIMFUNC1V4)"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be convergent-in+inftyLIMFUNC1V3"
      and A2: "f2 is-divergent-to+infty-inLIMFUNC3R2 lim-in+inftyLIMFUNC1K5 f1"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    assume Given: " ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <>HIDDENR2 lim-in+inftyLIMFUNC1K5 f1"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A4: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <>HIDDENR2 lim-in+inftyLIMFUNC1K5 f1"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds s be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A5: "s be divergent-to+inftyLIMFUNC1V1"
        and A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A7: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies r <XXREAL-0R3 s .FUNCT-1K1 n"
        using A5 sorry
      have A8: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc4_lm_2 sorry
      let ?q = "s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "?q be divergent-to+inftyLIMFUNC1V1"
        using A5 limfunc1_th_26 sorry
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A6 limfunc4_lm_2 sorry
      have A11: "rngFUNCT-1K2 ?q c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      have A12: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-in+inftyLIMFUNC1K5 f1 }"
      proof-
        have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-in+inftyLIMFUNC1K5 f1 }"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-in+inftyLIMFUNC1K5 f1 }"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q)"
            then obtain n where
              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A13: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
              using funct_2_th_113 sorry
            have A14: "x =HIDDENR1 f1 .FUNCT-1K1 (?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
              using A10 A11 A13 funct_2_th_108 xboole_1_th_1 sorry
            also have "... = f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
              using nat_1_def_3 sorry
            finally have "x =HIDDENR1 f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
               sorry
            have "r <XXREAL-0R3 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
              using A7 nat_1_th_12 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {r2 where r2 be RealXREAL-0M1 : r <XXREAL-0R3 r2 }"
               sorry
            then have A15: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 right-open-halflineLIMFUNC1K4 r"
              using xxreal_1_th_230 sorry
            have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
              using valued_0_th_28 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r)"
              using A10 A15 xboole_0_def_4 sorry
            then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) <>HIDDENR2 lim-in+inftyLIMFUNC1K5 f1"
              using A4 sorry
            then have A16: " not f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 {TARSKIK1 lim-in+inftyLIMFUNC1K5 f1 }"
              using tarski_def_1 sorry
            have A17: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s)"
              using valued_0_th_28 sorry
            then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A8 sorry
            then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A10 A14 funct_2_th_108 A17 sorry
            thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-in+inftyLIMFUNC1K5 f1 }"
              using A14 A16 xboole_0_def_5 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-in+inftyLIMFUNC1K5 f1 }"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A10 A11 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be convergentSEQ-2V5 & limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 lim-in+inftyLIMFUNC1K5 f1"
        using A1 A9 limfunc1_def_12 sorry
      then have A18: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) be divergent-to+inftyLIMFUNC1V1"
        using A2 A12 limfunc3_def_2 sorry
      have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        using A10 valued_0_th_27 sorry
      also have "... = f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A8 valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A6 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A18 limfunc1_th_7 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in+infty-to+inftyLIMFUNC1V4"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_46:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 be convergent-in+inftyLIMFUNC1V3 & f2 is-divergent-to-infty-inLIMFUNC3R3 lim-in+inftyLIMFUNC1K5 f1) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) & ( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <>HIDDENR2 lim-in+inftyLIMFUNC1K5 f1) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in+infty-to-inftyLIMFUNC1V5"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be convergent-in+inftyLIMFUNC1V3 & (f2 is-divergent-to-infty-inLIMFUNC3R3 lim-in+inftyLIMFUNC1K5 f1 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies (( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <>HIDDENR2 lim-in+inftyLIMFUNC1K5 f1) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in+infty-to-inftyLIMFUNC1V5)"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be convergent-in+inftyLIMFUNC1V3"
      and A2: "f2 is-divergent-to-infty-inLIMFUNC3R3 lim-in+inftyLIMFUNC1K5 f1"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    assume Given: " ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <>HIDDENR2 lim-in+inftyLIMFUNC1K5 f1"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A4: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <>HIDDENR2 lim-in+inftyLIMFUNC1K5 f1"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds s be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A5: "s be divergent-to+inftyLIMFUNC1V1"
        and A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A7: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies r <XXREAL-0R3 s .FUNCT-1K1 n"
        using A5 sorry
      have A8: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc4_lm_2 sorry
      let ?q = "s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "?q be divergent-to+inftyLIMFUNC1V1"
        using A5 limfunc1_th_26 sorry
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A6 limfunc4_lm_2 sorry
      have A11: "rngFUNCT-1K2 ?q c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      have A12: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-in+inftyLIMFUNC1K5 f1 }"
      proof-
        have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-in+inftyLIMFUNC1K5 f1 }"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-in+inftyLIMFUNC1K5 f1 }"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q)"
            then obtain n where
              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A13: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
              using funct_2_th_113 sorry
            have A14: "x =HIDDENR1 f1 .FUNCT-1K1 (?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
              using A10 A11 A13 funct_2_th_108 xboole_1_th_1 sorry
            also have "... = f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
              using nat_1_def_3 sorry
            finally have "x =HIDDENR1 f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
               sorry
            have "r <XXREAL-0R3 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
              using A7 nat_1_th_12 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {r2 where r2 be RealXREAL-0M1 : r <XXREAL-0R3 r2 }"
               sorry
            then have A15: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 right-open-halflineLIMFUNC1K4 r"
              using xxreal_1_th_230 sorry
            have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
              using valued_0_th_28 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r)"
              using A10 A15 xboole_0_def_4 sorry
            then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) <>HIDDENR2 lim-in+inftyLIMFUNC1K5 f1"
              using A4 sorry
            then have A16: " not f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 {TARSKIK1 lim-in+inftyLIMFUNC1K5 f1 }"
              using tarski_def_1 sorry
            have A17: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s)"
              using valued_0_th_28 sorry
            then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A8 sorry
            then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A10 A14 funct_2_th_108 A17 sorry
            thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-in+inftyLIMFUNC1K5 f1 }"
              using A14 A16 xboole_0_def_5 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-in+inftyLIMFUNC1K5 f1 }"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A10 A11 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be convergentSEQ-2V5 & limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 lim-in+inftyLIMFUNC1K5 f1"
        using A1 A9 limfunc1_def_12 sorry
      then have A18: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) be divergent-to-inftyLIMFUNC1V2"
        using A2 A12 limfunc3_def_3 sorry
      have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        using A10 valued_0_th_27 sorry
      also have "... = f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A8 valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A6 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A18 limfunc1_th_7 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in+infty-to-inftyLIMFUNC1V5"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_47:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 be convergent-in-inftyLIMFUNC1V6 & f2 is-divergent-to+infty-inLIMFUNC3R2 lim-in-inftyLIMFUNC1K6 f1) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) & ( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <>HIDDENR2 lim-in-inftyLIMFUNC1K6 f1) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in-infty-to+inftyLIMFUNC1V7"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be convergent-in-inftyLIMFUNC1V6 & (f2 is-divergent-to+infty-inLIMFUNC3R2 lim-in-inftyLIMFUNC1K6 f1 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies (( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <>HIDDENR2 lim-in-inftyLIMFUNC1K6 f1) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in-infty-to+inftyLIMFUNC1V7)"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be convergent-in-inftyLIMFUNC1V6"
      and A2: "f2 is-divergent-to+infty-inLIMFUNC3R2 lim-in-inftyLIMFUNC1K6 f1"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    assume Given: " ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <>HIDDENR2 lim-in-inftyLIMFUNC1K6 f1"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A4: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <>HIDDENR2 lim-in-inftyLIMFUNC1K6 f1"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds s be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A5: "s be divergent-to-inftyLIMFUNC1V2"
        and A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A7: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies s .FUNCT-1K1 n <XXREAL-0R3 r"
        using A5 sorry
      have A8: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc4_lm_2 sorry
      let ?q = "s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "?q be divergent-to-inftyLIMFUNC1V2"
        using A5 limfunc1_th_27 sorry
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A6 limfunc4_lm_2 sorry
      have A11: "rngFUNCT-1K2 ?q c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      have A12: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-in-inftyLIMFUNC1K6 f1 }"
      proof-
        have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-in-inftyLIMFUNC1K6 f1 }"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-in-inftyLIMFUNC1K6 f1 }"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q)"
            then obtain n where
              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A13: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
              using funct_2_th_113 sorry
            have A14: "x =HIDDENR1 f1 .FUNCT-1K1 (?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
              using A10 A11 A13 funct_2_th_108 xboole_1_th_1 sorry
            also have "... = f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
              using nat_1_def_3 sorry
            finally have "x =HIDDENR1 f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
               sorry
            have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) <XXREAL-0R3 r"
              using A7 nat_1_th_12 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {r2 where r2 be RealXREAL-0M1 : r2 <XXREAL-0R3 r }"
               sorry
            then have A15: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 left-open-halflineLIMFUNC1K1 r"
              using xxreal_1_th_229 sorry
            have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
              using valued_0_th_28 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r)"
              using A10 A15 xboole_0_def_4 sorry
            then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) <>HIDDENR2 lim-in-inftyLIMFUNC1K6 f1"
              using A4 sorry
            then have A16: " not f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 {TARSKIK1 lim-in-inftyLIMFUNC1K6 f1 }"
              using tarski_def_1 sorry
            have A17: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s)"
              using valued_0_th_28 sorry
            then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A8 sorry
            then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A10 A14 funct_2_th_108 A17 sorry
            thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-in-inftyLIMFUNC1K6 f1 }"
              using A14 A16 xboole_0_def_5 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-in-inftyLIMFUNC1K6 f1 }"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A10 A11 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be convergentSEQ-2V5 & limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 lim-in-inftyLIMFUNC1K6 f1"
        using A1 A9 limfunc1_def_13 sorry
      then have A18: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) be divergent-to+inftyLIMFUNC1V1"
        using A2 A12 limfunc3_def_2 sorry
      have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        using A10 valued_0_th_27 sorry
      also have "... = f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A8 valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A6 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A18 limfunc1_th_7 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in-infty-to+inftyLIMFUNC1V7"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_48:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 be convergent-in-inftyLIMFUNC1V6 & f2 is-divergent-to-infty-inLIMFUNC3R3 lim-in-inftyLIMFUNC1K6 f1) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) & ( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <>HIDDENR2 lim-in-inftyLIMFUNC1K6 f1) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in-infty-to-inftyLIMFUNC1V8"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be convergent-in-inftyLIMFUNC1V6 & (f2 is-divergent-to-infty-inLIMFUNC3R3 lim-in-inftyLIMFUNC1K6 f1 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies (( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <>HIDDENR2 lim-in-inftyLIMFUNC1K6 f1) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in-infty-to-inftyLIMFUNC1V8)"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be convergent-in-inftyLIMFUNC1V6"
      and A2: "f2 is-divergent-to-infty-inLIMFUNC3R3 lim-in-inftyLIMFUNC1K6 f1"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    assume Given: " ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <>HIDDENR2 lim-in-inftyLIMFUNC1K6 f1"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A4: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <>HIDDENR2 lim-in-inftyLIMFUNC1K6 f1"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds s be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A5: "s be divergent-to-inftyLIMFUNC1V2"
        and A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A7: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies s .FUNCT-1K1 n <XXREAL-0R3 r"
        using A5 sorry
      have A8: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc4_lm_2 sorry
      let ?q = "s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "?q be divergent-to-inftyLIMFUNC1V2"
        using A5 limfunc1_th_27 sorry
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A6 limfunc4_lm_2 sorry
      have A11: "rngFUNCT-1K2 ?q c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      have A12: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-in-inftyLIMFUNC1K6 f1 }"
      proof-
        have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-in-inftyLIMFUNC1K6 f1 }"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-in-inftyLIMFUNC1K6 f1 }"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q)"
            then obtain n where
              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A13: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
              using funct_2_th_113 sorry
            have A14: "x =HIDDENR1 f1 .FUNCT-1K1 (?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
              using A10 A11 A13 funct_2_th_108 xboole_1_th_1 sorry
            also have "... = f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
              using nat_1_def_3 sorry
            finally have "x =HIDDENR1 f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
               sorry
            have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) <XXREAL-0R3 r"
              using A7 nat_1_th_12 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {r2 where r2 be RealXREAL-0M1 : r2 <XXREAL-0R3 r }"
               sorry
            then have A15: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 left-open-halflineLIMFUNC1K1 r"
              using xxreal_1_th_229 sorry
            have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
              using valued_0_th_28 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r)"
              using A10 A15 xboole_0_def_4 sorry
            then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) <>HIDDENR2 lim-in-inftyLIMFUNC1K6 f1"
              using A4 sorry
            then have A16: " not f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 {TARSKIK1 lim-in-inftyLIMFUNC1K6 f1 }"
              using tarski_def_1 sorry
            have A17: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s)"
              using valued_0_th_28 sorry
            then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A8 sorry
            then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A10 A14 funct_2_th_108 A17 sorry
            thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-in-inftyLIMFUNC1K6 f1 }"
              using A14 A16 xboole_0_def_5 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-in-inftyLIMFUNC1K6 f1 }"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A10 A11 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be convergentSEQ-2V5 & limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 lim-in-inftyLIMFUNC1K6 f1"
        using A1 A9 limfunc1_def_13 sorry
      then have A18: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) be divergent-to-inftyLIMFUNC1V2"
        using A2 A12 limfunc3_def_3 sorry
      have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        using A10 valued_0_th_27 sorry
      also have "... = f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A8 valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A6 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A18 limfunc1_th_7 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be divergent-in-infty-to-inftyLIMFUNC1V8"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_49:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-convergent-inLIMFUNC3R1 x0 & f2 is-left-divergent-to+infty-inLIMFUNC2R2 limLIMFUNC3K1(f1,x0)) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) & ( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <XXREAL-0R3 limLIMFUNC3K1(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-divergent-to+infty-inLIMFUNC3R2 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-convergent-inLIMFUNC3R1 x0 & (f2 is-left-divergent-to+infty-inLIMFUNC2R2 limLIMFUNC3K1(f1,x0) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies (( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies limLIMFUNC3K1(f1,x0) >XXREAL-0R4 f1 .FUNCT-1K1 r)) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-divergent-to+infty-inLIMFUNC3R2 x0)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-convergent-inLIMFUNC3R1 x0"
      and A2: "f2 is-left-divergent-to+infty-inLIMFUNC2R2 limLIMFUNC3K1(f1,x0)"
      and A3: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    assume Given: " ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies limLIMFUNC3K1(f1,x0) >XXREAL-0R4 f1 .FUNCT-1K1 r)"
    then obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 g"and A5: " for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies limLIMFUNC3K1(f1,x0) >XXREAL-0R4 f1 .FUNCT-1K1 r"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0} implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A6: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A7: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
      obtain k where
        [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
        A8: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0 +XCMPLX-0K2 g"
        using A4 A6 limfunc3_th_7 sorry
      let ?q = "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A7 limfunc4_th_2 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 limfunc4_th_2 sorry
      then have A10: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A9 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have A11: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
        using A7 limfunc4_th_2 sorry
      then have A12: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A1 A2 A6 limfunc3_def_4 sorry
      have A13: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A7 limfunc4_th_2 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (limLIMFUNC3K1(f1,x0)))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 ?q"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A14: "?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
          using funct_2_th_113 sorry
        have A15: "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) =HIDDENR1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)"
          using A13 funct_2_th_108 sorry
        also have "... = x"
          using A14 nat_1_def_3 sorry
        finally have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) =HIDDENR1 x"
           sorry
        have "k <=XXREAL-0R1 n +NAT-1K1 k"
          using nat_1_th_12 sorry
        then have "x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) <XXREAL-0R3 x0 +XCMPLX-0K2 g"
          using A8 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : x0 -XCMPLX-0K6 g <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0 +XCMPLX-0K2 g }"
           sorry
        then have A16: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 +XCMPLX-0K2 g .["
          using rcomp_1_def_2 sorry
        have A17: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 rngFUNCT-1K2 s"
          using valued_0_th_28 sorry
        then have " not s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 {TARSKIK1 x0}"
          using A7 xboole_0_def_5 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 +XCMPLX-0K2 g .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
          using A16 xboole_0_def_5 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .["
          using A4 limfunc3_th_4 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[)"
          using A13 A17 xboole_0_def_4 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) <XXREAL-0R3 limLIMFUNC3K1(f1,x0)"
          using A5 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : g2 <XXREAL-0R3 limLIMFUNC3K1(f1,x0) }"
           sorry
        then have A18: "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) inTARSKIR2 left-open-halflineLIMFUNC1K1 (limLIMFUNC3K1(f1,x0))"
          using xxreal_1_th_229 sorry
        have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A9 A17 funct_1_th_11 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (limLIMFUNC3K1(f1,x0)))"
          using A18 A15 xboole_0_def_4 sorry
      qed "sorry"
      then have A19: "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (limLIMFUNC3K1(f1,x0)))"
         sorry
      have "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 limLIMFUNC3K1(f1,x0)"
        using A1 A6 A11 limfunc3_def_4 sorry
      then have "limSEQ-2K1 ?q =HIDDENR1 limLIMFUNC3K1(f1,x0)"
        using A12 seq_4_th_20 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be divergent-to+inftyLIMFUNC1V1"
        using A2 A12 A19 limfunc2_def_2 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A10 limfunc1_th_7 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-divergent-to+infty-inLIMFUNC3R2 x0"
      using A3 limfunc3_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_50:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-convergent-inLIMFUNC3R1 x0 & f2 is-left-divergent-to-infty-inLIMFUNC2R3 limLIMFUNC3K1(f1,x0)) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) & ( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <XXREAL-0R3 limLIMFUNC3K1(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-divergent-to-infty-inLIMFUNC3R3 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-convergent-inLIMFUNC3R1 x0 & (f2 is-left-divergent-to-infty-inLIMFUNC2R3 limLIMFUNC3K1(f1,x0) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies (( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies limLIMFUNC3K1(f1,x0) >XXREAL-0R4 f1 .FUNCT-1K1 r)) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-divergent-to-infty-inLIMFUNC3R3 x0)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-convergent-inLIMFUNC3R1 x0"
      and A2: "f2 is-left-divergent-to-infty-inLIMFUNC2R3 limLIMFUNC3K1(f1,x0)"
      and A3: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    assume Given: " ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies limLIMFUNC3K1(f1,x0) >XXREAL-0R4 f1 .FUNCT-1K1 r)"
    then obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 g"and A5: " for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies limLIMFUNC3K1(f1,x0) >XXREAL-0R4 f1 .FUNCT-1K1 r"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0} implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A6: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A7: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
      obtain k where
        [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
        A8: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0 +XCMPLX-0K2 g"
        using A4 A6 limfunc3_th_7 sorry
      let ?q = "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A7 limfunc4_th_2 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 limfunc4_th_2 sorry
      then have A10: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A9 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have A11: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
        using A7 limfunc4_th_2 sorry
      then have A12: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A1 A2 A6 limfunc3_def_4 sorry
      have A13: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A7 limfunc4_th_2 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (limLIMFUNC3K1(f1,x0)))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 ?q"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A14: "?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
          using funct_2_th_113 sorry
        have A15: "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) =HIDDENR1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)"
          using A13 funct_2_th_108 sorry
        also have "... = x"
          using A14 nat_1_def_3 sorry
        finally have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) =HIDDENR1 x"
           sorry
        have "k <=XXREAL-0R1 n +NAT-1K1 k"
          using nat_1_th_12 sorry
        then have "x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) <XXREAL-0R3 x0 +XCMPLX-0K2 g"
          using A8 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : x0 -XCMPLX-0K6 g <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0 +XCMPLX-0K2 g }"
           sorry
        then have A16: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 +XCMPLX-0K2 g .["
          using rcomp_1_def_2 sorry
        have A17: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 rngFUNCT-1K2 s"
          using valued_0_th_28 sorry
        then have " not s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 {TARSKIK1 x0}"
          using A7 xboole_0_def_5 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 +XCMPLX-0K2 g .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
          using A16 xboole_0_def_5 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .["
          using A4 limfunc3_th_4 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[)"
          using A13 A17 xboole_0_def_4 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) <XXREAL-0R3 limLIMFUNC3K1(f1,x0)"
          using A5 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : g2 <XXREAL-0R3 limLIMFUNC3K1(f1,x0) }"
           sorry
        then have A18: "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) inTARSKIR2 left-open-halflineLIMFUNC1K1 (limLIMFUNC3K1(f1,x0))"
          using xxreal_1_th_229 sorry
        have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A9 A17 funct_1_th_11 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (limLIMFUNC3K1(f1,x0)))"
          using A18 A15 xboole_0_def_4 sorry
      qed "sorry"
      then have A19: "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (limLIMFUNC3K1(f1,x0)))"
         sorry
      have "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 limLIMFUNC3K1(f1,x0)"
        using A1 A6 A11 limfunc3_def_4 sorry
      then have "limSEQ-2K1 ?q =HIDDENR1 limLIMFUNC3K1(f1,x0)"
        using A12 seq_4_th_20 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be divergent-to-inftyLIMFUNC1V2"
        using A2 A12 A19 limfunc2_def_3 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A10 limfunc1_th_7 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-divergent-to-infty-inLIMFUNC3R3 x0"
      using A3 limfunc3_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_51:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-left-convergent-inLIMFUNC2R1 x0 & f2 is-divergent-to+infty-inLIMFUNC3R2 lim-leftLIMFUNC2K1(f1,x0)) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) & ( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 lim-leftLIMFUNC2K1(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-divergent-to+infty-inLIMFUNC2R2 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-left-convergent-inLIMFUNC2R1 x0 & (f2 is-divergent-to+infty-inLIMFUNC3R2 lim-leftLIMFUNC2K1(f1,x0) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies (( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 lim-leftLIMFUNC2K1(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-divergent-to+infty-inLIMFUNC2R2 x0)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-left-convergent-inLIMFUNC2R1 x0"
      and A2: "f2 is-divergent-to+infty-inLIMFUNC3R2 lim-leftLIMFUNC2K1(f1,x0)"
      and A3: " for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    assume Given: " ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 lim-leftLIMFUNC2K1(f1,x0))"
    then obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 g"and A5: " for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 lim-leftLIMFUNC2K1(f1,x0)"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A6: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A7: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A8: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-1K1 n"
        using A4 A6 limfunc4_lm_1 limfunc2_th_1 sorry
      let ?q = "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A7 limfunc4_th_1 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 limfunc4_th_1 sorry
      then have A10: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A9 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have A11: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
        using A7 limfunc4_th_1 sorry
      then have A12: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A1 A2 A6 limfunc2_def_7 sorry
      have A13: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A7 limfunc4_th_1 sorry
      have A14: "rngFUNCT-1K2 s c=TARSKIR1 left-open-halflineLIMFUNC1K1 x0"
        using A7 limfunc4_th_1 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-leftLIMFUNC2K1(f1,x0) }"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 ?q"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A15: "?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
          using funct_2_th_113 sorry
        have A16: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have A17: "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A13 funct_2_th_108 A16 sorry
        also have "... = x"
          using A15 nat_1_def_3 sorry
        finally have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 x"
           sorry
        have A18: "x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A8 nat_1_th_12 sorry
        have A19: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
          using valued_0_th_28 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 left-open-halflineLIMFUNC1K1 x0"
          using A14 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : g1 <XXREAL-0R3 x0 }"
          using xxreal_1_th_229 sorry
        then have " ex g1 be RealXREAL-0M1 st g1 =HIDDENR1 s .FUNCT-1K1 (n +XCMPLX-0K2 k) & g1 <XXREAL-0R3 x0"
           sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : x0 -XCMPLX-0K6 g <XXREAL-0R3 g2 & g2 <XXREAL-0R3 x0 }"
          using A18 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .["
          using rcomp_1_def_2 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[)"
          using A13 A19 xboole_0_def_4 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) <>HIDDENR2 lim-leftLIMFUNC2K1(f1,x0)"
          using A5 sorry
        then have A20: " not f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 {TARSKIK1 lim-leftLIMFUNC2K1(f1,x0) }"
          using tarski_def_1 sorry
        have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A9 A19 funct_1_th_11 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-leftLIMFUNC2K1(f1,x0) }"
          using A20 A17 xboole_0_def_5 sorry
      qed "sorry"
      then have A21: "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-leftLIMFUNC2K1(f1,x0) }"
         sorry
      have "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-leftLIMFUNC2K1(f1,x0)"
        using A1 A6 A11 limfunc2_def_7 sorry
      then have "limSEQ-2K1 ?q =HIDDENR1 lim-leftLIMFUNC2K1(f1,x0)"
        using A12 seq_4_th_20 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be divergent-to+inftyLIMFUNC1V1"
        using A2 A12 A21 limfunc3_def_2 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A10 limfunc1_th_7 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-divergent-to+infty-inLIMFUNC2R2 x0"
      using A3 limfunc2_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_52:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-left-convergent-inLIMFUNC2R1 x0 & f2 is-divergent-to-infty-inLIMFUNC3R3 lim-leftLIMFUNC2K1(f1,x0)) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) & ( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 lim-leftLIMFUNC2K1(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-divergent-to-infty-inLIMFUNC2R3 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-left-convergent-inLIMFUNC2R1 x0 & (f2 is-divergent-to-infty-inLIMFUNC3R3 lim-leftLIMFUNC2K1(f1,x0) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies (( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 lim-leftLIMFUNC2K1(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-divergent-to-infty-inLIMFUNC2R3 x0)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-left-convergent-inLIMFUNC2R1 x0"
      and A2: "f2 is-divergent-to-infty-inLIMFUNC3R3 lim-leftLIMFUNC2K1(f1,x0)"
      and A3: " for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    assume Given: " ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 lim-leftLIMFUNC2K1(f1,x0))"
    then obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 g"and A5: " for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 lim-leftLIMFUNC2K1(f1,x0)"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A6: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A7: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A8: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-1K1 n"
        using A4 A6 limfunc4_lm_1 limfunc2_th_1 sorry
      let ?q = "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A7 limfunc4_th_1 sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 limfunc4_th_1 sorry
      then have A10: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A9 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have A11: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
        using A7 limfunc4_th_1 sorry
      then have A12: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A1 A2 A6 limfunc2_def_7 sorry
      have A13: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A7 limfunc4_th_1 sorry
      have A14: "rngFUNCT-1K2 s c=TARSKIR1 left-open-halflineLIMFUNC1K1 x0"
        using A7 limfunc4_th_1 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-leftLIMFUNC2K1(f1,x0) }"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 ?q"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A15: "?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
          using funct_2_th_113 sorry
        have A16: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have A17: "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A13 funct_2_th_108 A16 sorry
        also have "... = x"
          using A15 nat_1_def_3 sorry
        finally have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 x"
           sorry
        have A18: "x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A8 nat_1_th_12 sorry
        have A19: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
          using valued_0_th_28 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 left-open-halflineLIMFUNC1K1 x0"
          using A14 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : g1 <XXREAL-0R3 x0 }"
          using xxreal_1_th_229 sorry
        then have " ex g1 be RealXREAL-0M1 st g1 =HIDDENR1 s .FUNCT-1K1 (n +XCMPLX-0K2 k) & g1 <XXREAL-0R3 x0"
           sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : x0 -XCMPLX-0K6 g <XXREAL-0R3 g2 & g2 <XXREAL-0R3 x0 }"
          using A18 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .["
          using rcomp_1_def_2 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[)"
          using A13 A19 xboole_0_def_4 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) <>HIDDENR2 lim-leftLIMFUNC2K1(f1,x0)"
          using A5 sorry
        then have A20: " not f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 {TARSKIK1 lim-leftLIMFUNC2K1(f1,x0) }"
          using tarski_def_1 sorry
        have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A9 A19 funct_1_th_11 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-leftLIMFUNC2K1(f1,x0) }"
          using A20 A17 xboole_0_def_5 sorry
      qed "sorry"
      then have A21: "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-leftLIMFUNC2K1(f1,x0) }"
         sorry
      have "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-leftLIMFUNC2K1(f1,x0)"
        using A1 A6 A11 limfunc2_def_7 sorry
      then have "limSEQ-2K1 ?q =HIDDENR1 lim-leftLIMFUNC2K1(f1,x0)"
        using A12 seq_4_th_20 sorry
      then have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be divergent-to-inftyLIMFUNC1V2"
        using A2 A12 A21 limfunc3_def_3 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A10 limfunc1_th_7 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-divergent-to-infty-inLIMFUNC2R3 x0"
      using A3 limfunc2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_53:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in+infty-to+inftyLIMFUNC1V4 & f2 be convergent-in+inftyLIMFUNC1V3) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) =HIDDENR1 lim-in+inftyLIMFUNC1K5 f2"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in+infty-to+inftyLIMFUNC1V4 & (f2 be convergent-in+inftyLIMFUNC1V3 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) =HIDDENR1 lim-in+inftyLIMFUNC1K5 f2"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be divergent-in+infty-to+inftyLIMFUNC1V4"
      and A2: "f2 be convergent-in+inftyLIMFUNC1V3"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    have A4: " for s be Real-SequenceSEQ-1M1 holds s be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-in+inftyLIMFUNC1K5 f2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A5: "s be divergent-to+inftyLIMFUNC1V1"
        and A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A6 limfunc4_lm_2 sorry
      then have A7: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A1 A5 sorry
      have A8: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc4_lm_2 sorry
      then have A9: "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) =HIDDENR1 lim-in+inftyLIMFUNC1K5 f2"
        using A2 A7 limfunc1_def_12 sorry
      have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) be convergentSEQ-2V5"
        using A2 A8 A7 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-in+inftyLIMFUNC1K5 f2"
        using A6 A9 valued_0_th_31 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be convergent-in+inftyLIMFUNC1V3"
      using A3 sorry
    thus "lim-in+inftyLIMFUNC1K5 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) =HIDDENR1 lim-in+inftyLIMFUNC1K5 f2"
      using A4 limfunc1_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_54:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in+infty-to-inftyLIMFUNC1V5 & f2 be convergent-in-inftyLIMFUNC1V6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) =HIDDENR1 lim-in-inftyLIMFUNC1K6 f2"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in+infty-to-inftyLIMFUNC1V5 & (f2 be convergent-in-inftyLIMFUNC1V6 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) =HIDDENR1 lim-in-inftyLIMFUNC1K6 f2"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be divergent-in+infty-to-inftyLIMFUNC1V5"
      and A2: "f2 be convergent-in-inftyLIMFUNC1V6"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    have A4: " for s be Real-SequenceSEQ-1M1 holds s be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-in-inftyLIMFUNC1K6 f2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A5: "s be divergent-to+inftyLIMFUNC1V1"
        and A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A6 limfunc4_lm_2 sorry
      then have A7: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A1 A5 sorry
      have A8: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc4_lm_2 sorry
      then have A9: "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) =HIDDENR1 lim-in-inftyLIMFUNC1K6 f2"
        using A2 A7 limfunc1_def_13 sorry
      have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) be convergentSEQ-2V5"
        using A2 A8 A7 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-in-inftyLIMFUNC1K6 f2"
        using A6 A9 valued_0_th_31 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be convergent-in+inftyLIMFUNC1V3"
      using A3 sorry
    thus "lim-in+inftyLIMFUNC1K5 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) =HIDDENR1 lim-in-inftyLIMFUNC1K6 f2"
      using A4 limfunc1_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_55:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in-infty-to+inftyLIMFUNC1V7 & f2 be convergent-in+inftyLIMFUNC1V3) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) =HIDDENR1 lim-in+inftyLIMFUNC1K5 f2"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in-infty-to+inftyLIMFUNC1V7 & (f2 be convergent-in+inftyLIMFUNC1V3 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) =HIDDENR1 lim-in+inftyLIMFUNC1K5 f2"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be divergent-in-infty-to+inftyLIMFUNC1V7"
      and A2: "f2 be convergent-in+inftyLIMFUNC1V3"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    have A4: " for s be Real-SequenceSEQ-1M1 holds s be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-in+inftyLIMFUNC1K5 f2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A5: "s be divergent-to-inftyLIMFUNC1V2"
        and A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A6 limfunc4_lm_2 sorry
      then have A7: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A1 A5 sorry
      have A8: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc4_lm_2 sorry
      then have A9: "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) =HIDDENR1 lim-in+inftyLIMFUNC1K5 f2"
        using A2 A7 limfunc1_def_12 sorry
      have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) be convergentSEQ-2V5"
        using A2 A8 A7 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-in+inftyLIMFUNC1K5 f2"
        using A6 A9 valued_0_th_31 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be convergent-in-inftyLIMFUNC1V6"
      using A3 sorry
    thus "lim-in-inftyLIMFUNC1K6 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) =HIDDENR1 lim-in+inftyLIMFUNC1K5 f2"
      using A4 limfunc1_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_56:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in-infty-to-inftyLIMFUNC1V8 & f2 be convergent-in-inftyLIMFUNC1V6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) =HIDDENR1 lim-in-inftyLIMFUNC1K6 f2"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in-infty-to-inftyLIMFUNC1V8 & (f2 be convergent-in-inftyLIMFUNC1V6 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) =HIDDENR1 lim-in-inftyLIMFUNC1K6 f2"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be divergent-in-infty-to-inftyLIMFUNC1V8"
      and A2: "f2 be convergent-in-inftyLIMFUNC1V6"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    have A4: " for s be Real-SequenceSEQ-1M1 holds s be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-in-inftyLIMFUNC1K6 f2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A5: "s be divergent-to-inftyLIMFUNC1V2"
        and A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A6 limfunc4_lm_2 sorry
      then have A7: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A1 A5 sorry
      have A8: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc4_lm_2 sorry
      then have A9: "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) =HIDDENR1 lim-in-inftyLIMFUNC1K6 f2"
        using A2 A7 limfunc1_def_13 sorry
      have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) be convergentSEQ-2V5"
        using A2 A8 A7 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-in-inftyLIMFUNC1K6 f2"
        using A6 A9 valued_0_th_31 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be convergent-in-inftyLIMFUNC1V6"
      using A3 sorry
    thus "lim-in-inftyLIMFUNC1K6 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) =HIDDENR1 lim-in-inftyLIMFUNC1K6 f2"
      using A4 limfunc1_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_57:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-left-divergent-to+infty-inLIMFUNC2R2 x0 & f2 be convergent-in+inftyLIMFUNC1V3) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-convergent-inLIMFUNC2R1 x0 & lim-leftLIMFUNC2K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-in+inftyLIMFUNC1K5 f2"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-left-divergent-to+infty-inLIMFUNC2R2 x0 & (f2 be convergent-in+inftyLIMFUNC1V3 & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-convergent-inLIMFUNC2R1 x0 & lim-leftLIMFUNC2K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-in+inftyLIMFUNC1K5 f2"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-left-divergent-to+infty-inLIMFUNC2R2 x0"
      and A2: "f2 be convergent-in+inftyLIMFUNC1V3"
      and A3: " for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    have A4: " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-in+inftyLIMFUNC1K5 f2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A5: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
        using A6 limfunc4_th_1 sorry
      then have A7: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A1 A5 limfunc2_def_2 sorry
      have A8: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc4_th_1 sorry
      then have A9: "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) =HIDDENR1 lim-in+inftyLIMFUNC1K5 f2"
        using A2 A7 limfunc1_def_12 sorry
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A6 limfunc4_th_1 sorry
      have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) be convergentSEQ-2V5"
        using A2 A8 A7 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-in+inftyLIMFUNC1K5 f2"
        using A10 A9 valued_0_th_31 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-convergent-inLIMFUNC2R1 x0"
      using A3 limfunc2_def_1 sorry
    thus "lim-leftLIMFUNC2K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-in+inftyLIMFUNC1K5 f2"
      using A4 limfunc2_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_58:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-left-divergent-to-infty-inLIMFUNC2R3 x0 & f2 be convergent-in-inftyLIMFUNC1V6) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-convergent-inLIMFUNC2R1 x0 & lim-leftLIMFUNC2K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-in-inftyLIMFUNC1K6 f2"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-left-divergent-to-infty-inLIMFUNC2R3 x0 & (f2 be convergent-in-inftyLIMFUNC1V6 & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-convergent-inLIMFUNC2R1 x0 & lim-leftLIMFUNC2K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-in-inftyLIMFUNC1K6 f2"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-left-divergent-to-infty-inLIMFUNC2R3 x0"
      and A2: "f2 be convergent-in-inftyLIMFUNC1V6"
      and A3: " for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    have A4: " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-in-inftyLIMFUNC1K6 f2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A5: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
        using A6 limfunc4_th_1 sorry
      then have A7: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A1 A5 limfunc2_def_3 sorry
      have A8: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc4_th_1 sorry
      then have A9: "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) =HIDDENR1 lim-in-inftyLIMFUNC1K6 f2"
        using A2 A7 limfunc1_def_13 sorry
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A6 limfunc4_th_1 sorry
      have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) be convergentSEQ-2V5"
        using A2 A8 A7 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-in-inftyLIMFUNC1K6 f2"
        using A10 A9 valued_0_th_31 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-convergent-inLIMFUNC2R1 x0"
      using A3 limfunc2_def_1 sorry
    thus "lim-leftLIMFUNC2K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-in-inftyLIMFUNC1K6 f2"
      using A4 limfunc2_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_59:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-right-divergent-to+infty-inLIMFUNC2R5 x0 & f2 be convergent-in+inftyLIMFUNC1V3) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-convergent-inLIMFUNC2R4 x0 & lim-rightLIMFUNC2K2(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-in+inftyLIMFUNC1K5 f2"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-right-divergent-to+infty-inLIMFUNC2R5 x0 & (f2 be convergent-in+inftyLIMFUNC1V3 & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-convergent-inLIMFUNC2R4 x0 & lim-rightLIMFUNC2K2(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-in+inftyLIMFUNC1K5 f2"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-right-divergent-to+infty-inLIMFUNC2R5 x0"
      and A2: "f2 be convergent-in+inftyLIMFUNC1V3"
      and A3: " for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    have A4: " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-in+inftyLIMFUNC1K5 f2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A5: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
        using A6 limfunc4_th_1 sorry
      then have A7: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A1 A5 limfunc2_def_5 sorry
      have A8: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc4_th_1 sorry
      then have A9: "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) =HIDDENR1 lim-in+inftyLIMFUNC1K5 f2"
        using A2 A7 limfunc1_def_12 sorry
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A6 limfunc4_th_1 sorry
      have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) be convergentSEQ-2V5"
        using A2 A8 A7 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-in+inftyLIMFUNC1K5 f2"
        using A10 A9 valued_0_th_31 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-convergent-inLIMFUNC2R4 x0"
      using A3 limfunc2_def_4 sorry
    thus "lim-rightLIMFUNC2K2(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-in+inftyLIMFUNC1K5 f2"
      using A4 limfunc2_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_60:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-right-divergent-to-infty-inLIMFUNC2R6 x0 & f2 be convergent-in-inftyLIMFUNC1V6) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-convergent-inLIMFUNC2R4 x0 & lim-rightLIMFUNC2K2(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-in-inftyLIMFUNC1K6 f2"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-right-divergent-to-infty-inLIMFUNC2R6 x0 & (f2 be convergent-in-inftyLIMFUNC1V6 & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-convergent-inLIMFUNC2R4 x0 & lim-rightLIMFUNC2K2(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-in-inftyLIMFUNC1K6 f2"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-right-divergent-to-infty-inLIMFUNC2R6 x0"
      and A2: "f2 be convergent-in-inftyLIMFUNC1V6"
      and A3: " for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    have A4: " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-in-inftyLIMFUNC1K6 f2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A5: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
        using A6 limfunc4_th_1 sorry
      then have A7: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A1 A5 limfunc2_def_6 sorry
      have A8: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc4_th_1 sorry
      then have A9: "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) =HIDDENR1 lim-in-inftyLIMFUNC1K6 f2"
        using A2 A7 limfunc1_def_13 sorry
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A6 limfunc4_th_1 sorry
      have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) be convergentSEQ-2V5"
        using A2 A8 A7 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-in-inftyLIMFUNC1K6 f2"
        using A10 A9 valued_0_th_31 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-convergent-inLIMFUNC2R4 x0"
      using A3 limfunc2_def_4 sorry
    thus "lim-rightLIMFUNC2K2(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-in-inftyLIMFUNC1K6 f2"
      using A4 limfunc2_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_61:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-left-convergent-inLIMFUNC2R1 x0 & f2 is-left-convergent-inLIMFUNC2R1 lim-leftLIMFUNC2K1(f1,x0)) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) & ( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies f1 .FUNCT-1K1 r <XXREAL-0R3 lim-leftLIMFUNC2K1(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-convergent-inLIMFUNC2R1 x0 & lim-leftLIMFUNC2K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-leftLIMFUNC2K1(f2,lim-leftLIMFUNC2K1(f1,x0))"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-left-convergent-inLIMFUNC2R1 x0 & (f2 is-left-convergent-inLIMFUNC2R1 lim-leftLIMFUNC2K1(f1,x0) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies (( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies f1 .FUNCT-1K1 r <XXREAL-0R3 lim-leftLIMFUNC2K1(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-convergent-inLIMFUNC2R1 x0 & lim-leftLIMFUNC2K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-leftLIMFUNC2K1(f2,lim-leftLIMFUNC2K1(f1,x0)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-left-convergent-inLIMFUNC2R1 x0"
      and A2: "f2 is-left-convergent-inLIMFUNC2R1 lim-leftLIMFUNC2K1(f1,x0)"
      and A3: " for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    assume Given: " ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies f1 .FUNCT-1K1 r <XXREAL-0R3 lim-leftLIMFUNC2K1(f1,x0))"
    then obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 g"and A5: " for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies f1 .FUNCT-1K1 r <XXREAL-0R3 lim-leftLIMFUNC2K1(f1,x0)"
       sorry
    have A6: " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-leftLIMFUNC2K1(f2,lim-leftLIMFUNC2K1(f1,x0))"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A7: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A8: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A9: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-1K1 n"
        using A4 A7 limfunc4_lm_1 limfunc2_th_1 sorry
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A8 limfunc4_th_1 sorry
      let ?q = "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A11: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A8 limfunc4_th_1 sorry
      have A12: "rngFUNCT-1K2 s c=TARSKIR1 left-open-halflineLIMFUNC1K1 x0"
        using A8 limfunc4_th_1 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-leftLIMFUNC2K1(f1,x0)))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 ?q"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A13: "?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
          using funct_2_th_113 sorry
        have A14: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have A15: "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A10 funct_2_th_108 A14 sorry
        also have "... = x"
          using A13 nat_1_def_3 sorry
        finally have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 x"
           sorry
        have A16: "x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A9 nat_1_th_12 sorry
        have A17: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
          using valued_0_th_28 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 left-open-halflineLIMFUNC1K1 x0"
          using A12 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : g1 <XXREAL-0R3 x0 }"
          using xxreal_1_th_229 sorry
        then have " ex g1 be RealXREAL-0M1 st g1 =HIDDENR1 s .FUNCT-1K1 (n +XCMPLX-0K2 k) & g1 <XXREAL-0R3 x0"
           sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : x0 -XCMPLX-0K6 g <XXREAL-0R3 g2 & g2 <XXREAL-0R3 x0 }"
          using A16 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .["
          using rcomp_1_def_2 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[)"
          using A10 A17 xboole_0_def_4 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) <XXREAL-0R3 lim-leftLIMFUNC2K1(f1,x0)"
          using A5 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 {r1 where r1 be RealXREAL-0M1 : r1 <XXREAL-0R3 lim-leftLIMFUNC2K1(f1,x0) }"
           sorry
        then have A18: "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 left-open-halflineLIMFUNC1K1 (lim-leftLIMFUNC2K1(f1,x0))"
          using xxreal_1_th_229 sorry
        have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A11 A17 funct_1_th_11 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-leftLIMFUNC2K1(f1,x0)))"
          using A18 A15 xboole_0_def_4 sorry
      qed "sorry"
      then have A19: "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-leftLIMFUNC2K1(f1,x0)))"
         sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A8 limfunc4_th_1 sorry
      then have A20: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A11 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have A21: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
        using A8 limfunc4_th_1 sorry
      then have A22: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A1 A2 A7 limfunc2_def_7 sorry
      have "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-leftLIMFUNC2K1(f1,x0)"
        using A1 A7 A21 limfunc2_def_7 sorry
      then have A23: "limSEQ-2K1 ?q =HIDDENR1 lim-leftLIMFUNC2K1(f1,x0)"
        using A22 seq_4_th_20 sorry
      have "lim-leftLIMFUNC2K1(f2,lim-leftLIMFUNC2K1(f1,x0)) =HIDDENR1 lim-leftLIMFUNC2K1(f2,lim-leftLIMFUNC2K1(f1,x0))"
         sorry
      then have A24: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be convergentSEQ-2V5"
        using A2 A22 A23 A19 limfunc2_def_7 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A20 seq_4_th_21 sorry
      have "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 lim-leftLIMFUNC2K1(f2,lim-leftLIMFUNC2K1(f1,x0))"
        using A2 A22 A23 A19 limfunc2_def_7 sorry
      thus "limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-leftLIMFUNC2K1(f2,lim-leftLIMFUNC2K1(f1,x0))"
        using A24 A20 seq_4_th_22 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-convergent-inLIMFUNC2R1 x0"
      using A3 limfunc2_def_1 sorry
    thus "lim-leftLIMFUNC2K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-leftLIMFUNC2K1(f2,lim-leftLIMFUNC2K1(f1,x0))"
      using A6 limfunc2_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_62:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-right-convergent-inLIMFUNC2R4 x0 & f2 is-right-convergent-inLIMFUNC2R4 lim-rightLIMFUNC2K2(f1,x0)) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) & ( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies lim-rightLIMFUNC2K2(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 r)) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-convergent-inLIMFUNC2R4 x0 & lim-rightLIMFUNC2K2(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-rightLIMFUNC2K2(f2,lim-rightLIMFUNC2K2(f1,x0))"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-right-convergent-inLIMFUNC2R4 x0 & (f2 is-right-convergent-inLIMFUNC2R4 lim-rightLIMFUNC2K2(f1,x0) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies (( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies lim-rightLIMFUNC2K2(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 r)) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-convergent-inLIMFUNC2R4 x0 & lim-rightLIMFUNC2K2(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-rightLIMFUNC2K2(f2,lim-rightLIMFUNC2K2(f1,x0)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-right-convergent-inLIMFUNC2R4 x0"
      and A2: "f2 is-right-convergent-inLIMFUNC2R4 lim-rightLIMFUNC2K2(f1,x0)"
      and A3: " for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    assume Given: " ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies lim-rightLIMFUNC2K2(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 r)"
    then obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 g"and A5: " for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies lim-rightLIMFUNC2K2(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 r"
       sorry
    have A6: " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-rightLIMFUNC2K2(f2,lim-rightLIMFUNC2K2(f1,x0))"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A7: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A8: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A9: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies s .FUNCT-1K1 n <XXREAL-0R3 x0 +XCMPLX-0K2 g"
        using A4 A7 limfunc4_lm_1 limfunc2_th_2 sorry
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A8 limfunc4_th_1 sorry
      let ?q = "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A11: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A8 limfunc4_th_1 sorry
      have A12: "rngFUNCT-1K2 s c=TARSKIR1 right-open-halflineLIMFUNC1K4 x0"
        using A8 limfunc4_th_1 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-rightLIMFUNC2K2(f1,x0)))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 ?q"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A13: "?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
          using funct_2_th_113 sorry
        have A14: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have A15: "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A10 funct_2_th_108 A14 sorry
        also have "... = x"
          using A13 nat_1_def_3 sorry
        finally have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 x"
           sorry
        have A16: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) <XXREAL-0R3 x0 +XCMPLX-0K2 g"
          using A9 nat_1_th_12 sorry
        have A17: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
          using valued_0_th_28 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 right-open-halflineLIMFUNC1K4 x0"
          using A12 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : x0 <XXREAL-0R3 g1 }"
          using xxreal_1_th_230 sorry
        then have " ex g1 be RealXREAL-0M1 st g1 =HIDDENR1 s .FUNCT-1K1 (n +XCMPLX-0K2 k) & x0 <XXREAL-0R3 g1"
           sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : x0 <XXREAL-0R3 g2 & g2 <XXREAL-0R3 x0 +XCMPLX-0K2 g }"
          using A16 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .["
          using rcomp_1_def_2 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[)"
          using A10 A17 xboole_0_def_4 sorry
        then have "lim-rightLIMFUNC2K2(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
          using A5 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 {r1 where r1 be RealXREAL-0M1 : lim-rightLIMFUNC2K2(f1,x0) <XXREAL-0R3 r1 }"
           sorry
        then have A18: "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 right-open-halflineLIMFUNC1K4 (lim-rightLIMFUNC2K2(f1,x0))"
          using xxreal_1_th_230 sorry
        have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A11 A17 funct_1_th_11 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-rightLIMFUNC2K2(f1,x0)))"
          using A18 A15 xboole_0_def_4 sorry
      qed "sorry"
      then have A19: "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-rightLIMFUNC2K2(f1,x0)))"
         sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A8 limfunc4_th_1 sorry
      then have A20: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A11 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have A21: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
        using A8 limfunc4_th_1 sorry
      then have A22: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A1 A2 A7 limfunc2_def_8 sorry
      have "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-rightLIMFUNC2K2(f1,x0)"
        using A1 A7 A21 limfunc2_def_8 sorry
      then have A23: "limSEQ-2K1 ?q =HIDDENR1 lim-rightLIMFUNC2K2(f1,x0)"
        using A22 seq_4_th_20 sorry
      have "lim-rightLIMFUNC2K2(f2,lim-rightLIMFUNC2K2(f1,x0)) =HIDDENR1 lim-rightLIMFUNC2K2(f2,lim-rightLIMFUNC2K2(f1,x0))"
         sorry
      then have A24: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be convergentSEQ-2V5"
        using A2 A22 A23 A19 limfunc2_def_8 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A20 seq_4_th_21 sorry
      have "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 lim-rightLIMFUNC2K2(f2,lim-rightLIMFUNC2K2(f1,x0))"
        using A2 A22 A23 A19 limfunc2_def_8 sorry
      thus "limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-rightLIMFUNC2K2(f2,lim-rightLIMFUNC2K2(f1,x0))"
        using A24 A20 seq_4_th_22 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-convergent-inLIMFUNC2R4 x0"
      using A3 limfunc2_def_4 sorry
    thus "lim-rightLIMFUNC2K2(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-rightLIMFUNC2K2(f2,lim-rightLIMFUNC2K2(f1,x0))"
      using A6 limfunc2_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_63:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-left-convergent-inLIMFUNC2R1 x0 & f2 is-right-convergent-inLIMFUNC2R4 lim-leftLIMFUNC2K1(f1,x0)) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) & ( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies lim-leftLIMFUNC2K1(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 r)) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-convergent-inLIMFUNC2R1 x0 & lim-leftLIMFUNC2K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-rightLIMFUNC2K2(f2,lim-leftLIMFUNC2K1(f1,x0))"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-left-convergent-inLIMFUNC2R1 x0 & (f2 is-right-convergent-inLIMFUNC2R4 lim-leftLIMFUNC2K1(f1,x0) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies (( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies lim-leftLIMFUNC2K1(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 r)) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-convergent-inLIMFUNC2R1 x0 & lim-leftLIMFUNC2K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-rightLIMFUNC2K2(f2,lim-leftLIMFUNC2K1(f1,x0)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-left-convergent-inLIMFUNC2R1 x0"
      and A2: "f2 is-right-convergent-inLIMFUNC2R4 lim-leftLIMFUNC2K1(f1,x0)"
      and A3: " for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    assume Given: " ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies lim-leftLIMFUNC2K1(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 r)"
    then obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 g"and A5: " for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies lim-leftLIMFUNC2K1(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 r"
       sorry
    have A6: " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-rightLIMFUNC2K2(f2,lim-leftLIMFUNC2K1(f1,x0))"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A7: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A8: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A9: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-1K1 n"
        using A4 A7 limfunc4_lm_1 limfunc2_th_1 sorry
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A8 limfunc4_th_1 sorry
      let ?q = "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A11: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A8 limfunc4_th_1 sorry
      have A12: "rngFUNCT-1K2 s c=TARSKIR1 left-open-halflineLIMFUNC1K1 x0"
        using A8 limfunc4_th_1 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-leftLIMFUNC2K1(f1,x0)))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 ?q"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A13: "?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
          using funct_2_th_113 sorry
        have A14: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have A15: "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A10 funct_2_th_108 A14 sorry
        also have "... = x"
          using A13 nat_1_def_3 sorry
        finally have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 x"
           sorry
        have A16: "x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A9 nat_1_th_12 sorry
        have A17: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
          using valued_0_th_28 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 left-open-halflineLIMFUNC1K1 x0"
          using A12 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : g1 <XXREAL-0R3 x0 }"
          using xxreal_1_th_229 sorry
        then have " ex g1 be RealXREAL-0M1 st g1 =HIDDENR1 s .FUNCT-1K1 (n +XCMPLX-0K2 k) & g1 <XXREAL-0R3 x0"
           sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : x0 -XCMPLX-0K6 g <XXREAL-0R3 g2 & g2 <XXREAL-0R3 x0 }"
          using A16 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .["
          using rcomp_1_def_2 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[)"
          using A10 A17 xboole_0_def_4 sorry
        then have "lim-leftLIMFUNC2K1(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
          using A5 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 {r1 where r1 be RealXREAL-0M1 : lim-leftLIMFUNC2K1(f1,x0) <XXREAL-0R3 r1 }"
           sorry
        then have A18: "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 right-open-halflineLIMFUNC1K4 (lim-leftLIMFUNC2K1(f1,x0))"
          using xxreal_1_th_230 sorry
        have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A11 A17 funct_1_th_11 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-leftLIMFUNC2K1(f1,x0)))"
          using A18 A15 xboole_0_def_4 sorry
      qed "sorry"
      then have A19: "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-leftLIMFUNC2K1(f1,x0)))"
         sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A8 limfunc4_th_1 sorry
      then have A20: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A11 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have A21: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
        using A8 limfunc4_th_1 sorry
      then have A22: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A1 A2 A7 limfunc2_def_7 sorry
      have "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-leftLIMFUNC2K1(f1,x0)"
        using A1 A7 A21 limfunc2_def_7 sorry
      then have A23: "limSEQ-2K1 ?q =HIDDENR1 lim-leftLIMFUNC2K1(f1,x0)"
        using A22 seq_4_th_20 sorry
      have "lim-rightLIMFUNC2K2(f2,lim-leftLIMFUNC2K1(f1,x0)) =HIDDENR1 lim-rightLIMFUNC2K2(f2,lim-leftLIMFUNC2K1(f1,x0))"
         sorry
      then have A24: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be convergentSEQ-2V5"
        using A2 A22 A23 A19 limfunc2_def_8 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A20 seq_4_th_21 sorry
      have "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 lim-rightLIMFUNC2K2(f2,lim-leftLIMFUNC2K1(f1,x0))"
        using A2 A22 A23 A19 limfunc2_def_8 sorry
      thus "limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-rightLIMFUNC2K2(f2,lim-leftLIMFUNC2K1(f1,x0))"
        using A24 A20 seq_4_th_22 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-convergent-inLIMFUNC2R1 x0"
      using A3 limfunc2_def_1 sorry
    thus "lim-leftLIMFUNC2K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-rightLIMFUNC2K2(f2,lim-leftLIMFUNC2K1(f1,x0))"
      using A6 limfunc2_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_64:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-right-convergent-inLIMFUNC2R4 x0 & f2 is-left-convergent-inLIMFUNC2R1 lim-rightLIMFUNC2K2(f1,x0)) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) & ( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <XXREAL-0R3 lim-rightLIMFUNC2K2(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-convergent-inLIMFUNC2R4 x0 & lim-rightLIMFUNC2K2(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-leftLIMFUNC2K1(f2,lim-rightLIMFUNC2K2(f1,x0))"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-right-convergent-inLIMFUNC2R4 x0 & (f2 is-left-convergent-inLIMFUNC2R1 lim-rightLIMFUNC2K2(f1,x0) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies (( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <XXREAL-0R3 lim-rightLIMFUNC2K2(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-convergent-inLIMFUNC2R4 x0 & lim-rightLIMFUNC2K2(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-leftLIMFUNC2K1(f2,lim-rightLIMFUNC2K2(f1,x0)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-right-convergent-inLIMFUNC2R4 x0"
      and A2: "f2 is-left-convergent-inLIMFUNC2R1 lim-rightLIMFUNC2K2(f1,x0)"
      and A3: " for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    assume Given: " ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <XXREAL-0R3 lim-rightLIMFUNC2K2(f1,x0))"
    then obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 g"and A5: " for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <XXREAL-0R3 lim-rightLIMFUNC2K2(f1,x0)"
       sorry
    have A6: " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-leftLIMFUNC2K1(f2,lim-rightLIMFUNC2K2(f1,x0))"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A7: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A8: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A9: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies s .FUNCT-1K1 n <XXREAL-0R3 x0 +XCMPLX-0K2 g"
        using A4 A7 limfunc4_lm_1 limfunc2_th_2 sorry
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A8 limfunc4_th_1 sorry
      let ?q = "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A11: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A8 limfunc4_th_1 sorry
      have A12: "rngFUNCT-1K2 s c=TARSKIR1 right-open-halflineLIMFUNC1K4 x0"
        using A8 limfunc4_th_1 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-rightLIMFUNC2K2(f1,x0)))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 ?q"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A13: "?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
          using funct_2_th_113 sorry
        have A14: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have A15: "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A10 funct_2_th_108 A14 sorry
        also have "... = x"
          using A13 nat_1_def_3 sorry
        finally have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 x"
           sorry
        have A16: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) <XXREAL-0R3 x0 +XCMPLX-0K2 g"
          using A9 nat_1_th_12 sorry
        have A17: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
          using valued_0_th_28 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 right-open-halflineLIMFUNC1K4 x0"
          using A12 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : x0 <XXREAL-0R3 g1 }"
          using xxreal_1_th_230 sorry
        then have " ex g1 be RealXREAL-0M1 st g1 =HIDDENR1 s .FUNCT-1K1 (n +XCMPLX-0K2 k) & x0 <XXREAL-0R3 g1"
           sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : x0 <XXREAL-0R3 g2 & g2 <XXREAL-0R3 x0 +XCMPLX-0K2 g }"
          using A16 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .["
          using rcomp_1_def_2 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[)"
          using A10 A17 xboole_0_def_4 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) <XXREAL-0R3 lim-rightLIMFUNC2K2(f1,x0)"
          using A5 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 {r1 where r1 be RealXREAL-0M1 : r1 <XXREAL-0R3 lim-rightLIMFUNC2K2(f1,x0) }"
           sorry
        then have A18: "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 left-open-halflineLIMFUNC1K1 (lim-rightLIMFUNC2K2(f1,x0))"
          using xxreal_1_th_229 sorry
        have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A11 A17 funct_1_th_11 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-rightLIMFUNC2K2(f1,x0)))"
          using A18 A15 xboole_0_def_4 sorry
      qed "sorry"
      then have A19: "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-rightLIMFUNC2K2(f1,x0)))"
         sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A8 limfunc4_th_1 sorry
      then have A20: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A11 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have A21: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
        using A8 limfunc4_th_1 sorry
      then have A22: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A1 A2 A7 limfunc2_def_8 sorry
      have "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-rightLIMFUNC2K2(f1,x0)"
        using A1 A7 A21 limfunc2_def_8 sorry
      then have A23: "limSEQ-2K1 ?q =HIDDENR1 lim-rightLIMFUNC2K2(f1,x0)"
        using A22 seq_4_th_20 sorry
      have "lim-leftLIMFUNC2K1(f2,lim-rightLIMFUNC2K2(f1,x0)) =HIDDENR1 lim-leftLIMFUNC2K1(f2,lim-rightLIMFUNC2K2(f1,x0))"
         sorry
      then have A24: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be convergentSEQ-2V5"
        using A2 A22 A23 A19 limfunc2_def_7 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A20 seq_4_th_21 sorry
      have "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 lim-leftLIMFUNC2K1(f2,lim-rightLIMFUNC2K2(f1,x0))"
        using A2 A22 A23 A19 limfunc2_def_7 sorry
      thus "limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-leftLIMFUNC2K1(f2,lim-rightLIMFUNC2K2(f1,x0))"
        using A24 A20 seq_4_th_22 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-convergent-inLIMFUNC2R4 x0"
      using A3 limfunc2_def_4 sorry
    thus "lim-rightLIMFUNC2K2(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-leftLIMFUNC2K1(f2,lim-rightLIMFUNC2K2(f1,x0))"
      using A6 limfunc2_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_65:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 be convergent-in+inftyLIMFUNC1V3 & f2 is-left-convergent-inLIMFUNC2R1 lim-in+inftyLIMFUNC1K5 f1) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) & ( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <XXREAL-0R3 lim-in+inftyLIMFUNC1K5 f1) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) =HIDDENR1 lim-leftLIMFUNC2K1(f2,lim-in+inftyLIMFUNC1K5 f1)"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be convergent-in+inftyLIMFUNC1V3 & (f2 is-left-convergent-inLIMFUNC2R1 lim-in+inftyLIMFUNC1K5 f1 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies (( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <XXREAL-0R3 lim-in+inftyLIMFUNC1K5 f1) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) =HIDDENR1 lim-leftLIMFUNC2K1(f2,lim-in+inftyLIMFUNC1K5 f1))"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI,rule conjMI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be convergent-in+inftyLIMFUNC1V3"
      and A2: "f2 is-left-convergent-inLIMFUNC2R1 lim-in+inftyLIMFUNC1K5 f1"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    assume Given: " ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <XXREAL-0R3 lim-in+inftyLIMFUNC1K5 f1"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A4: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <XXREAL-0R3 lim-in+inftyLIMFUNC1K5 f1"
       sorry
    have A5: " for s be Real-SequenceSEQ-1M1 holds s be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-leftLIMFUNC2K1(f2,lim-in+inftyLIMFUNC1K5 f1)"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      let ?L = "lim-leftLIMFUNC2K1(f2,lim-in+inftyLIMFUNC1K5 f1)"
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A6: "s be divergent-to+inftyLIMFUNC1V1"
        and A7: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A8: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies r <XXREAL-0R3 s .FUNCT-1K1 n"
        using A6 sorry
      let ?q = "s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "?q be divergent-to+inftyLIMFUNC1V1"
        using A6 limfunc1_th_26 sorry
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A7 limfunc4_lm_2 sorry
      have A11: "rngFUNCT-1K2 ?q c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      then have "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A10 sorry
      then have A12: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be convergentSEQ-2V5 & limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 lim-in+inftyLIMFUNC1K5 f1"
        using A1 A9 limfunc1_def_12 sorry
      have A13: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 limfunc4_lm_2 sorry
      have A14: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-in+inftyLIMFUNC1K5 f1))"
      proof-
        have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-in+inftyLIMFUNC1K5 f1))"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-in+inftyLIMFUNC1K5 f1))"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q)"
            then obtain n where
              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A15: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
              using funct_2_th_113 sorry
            have A16: "x =HIDDENR1 f1 .FUNCT-1K1 (?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
              using A10 A11 A15 funct_2_th_108 xboole_1_th_1 sorry
            also have "... = f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
              using nat_1_def_3 sorry
            finally have "x =HIDDENR1 f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
               sorry
            have "r <XXREAL-0R3 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
              using A8 nat_1_th_12 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {r2 where r2 be RealXREAL-0M1 : r <XXREAL-0R3 r2 }"
               sorry
            then have A17: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 right-open-halflineLIMFUNC1K4 r"
              using xxreal_1_th_230 sorry
            have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
              using valued_0_th_28 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r)"
              using A10 A17 xboole_0_def_4 sorry
            then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) <XXREAL-0R3 lim-in+inftyLIMFUNC1K5 f1"
              using A4 sorry
            then have "x inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : g1 <XXREAL-0R3 lim-in+inftyLIMFUNC1K5 f1 }"
              using A16 sorry
            then have A18: "x inHIDDENR3 left-open-halflineLIMFUNC1K1 (lim-in+inftyLIMFUNC1K5 f1)"
              using xxreal_1_th_229 sorry
            have A19: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s)"
              using valued_0_th_28 sorry
            then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A13 sorry
            then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A10 A16 funct_2_th_108 A19 sorry
            thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-in+inftyLIMFUNC1K5 f1))"
              using A18 xboole_0_def_4 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-in+inftyLIMFUNC1K5 f1))"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have A20: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        using A10 valued_0_th_27 sorry
      also have "... = f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A13 valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A7 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have "?L =HIDDENR1 ?L"
         sorry
      then have A21: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) be convergentSEQ-2V5"
        using A2 A12 A14 limfunc2_def_7 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A20 seq_4_th_21 sorry
      have "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 ?L"
        using A2 A12 A14 limfunc2_def_7 sorry
      thus "limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-leftLIMFUNC2K1(f2,lim-in+inftyLIMFUNC1K5 f1)"
        using A21 A20 seq_4_th_22 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be convergent-in+inftyLIMFUNC1V3"
      using A3 sorry
    thus "lim-in+inftyLIMFUNC1K5 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) =HIDDENR1 lim-leftLIMFUNC2K1(f2,lim-in+inftyLIMFUNC1K5 f1)"
      using A5 limfunc1_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_66:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 be convergent-in+inftyLIMFUNC1V3 & f2 is-right-convergent-inLIMFUNC2R4 lim-in+inftyLIMFUNC1K5 f1) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) & ( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies lim-in+inftyLIMFUNC1K5 f1 <XXREAL-0R3 f1 .FUNCT-1K1 g) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) =HIDDENR1 lim-rightLIMFUNC2K2(f2,lim-in+inftyLIMFUNC1K5 f1)"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be convergent-in+inftyLIMFUNC1V3 & (f2 is-right-convergent-inLIMFUNC2R4 lim-in+inftyLIMFUNC1K5 f1 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies (( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies lim-in+inftyLIMFUNC1K5 f1 <XXREAL-0R3 f1 .FUNCT-1K1 g) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) =HIDDENR1 lim-rightLIMFUNC2K2(f2,lim-in+inftyLIMFUNC1K5 f1))"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI,rule conjMI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be convergent-in+inftyLIMFUNC1V3"
      and A2: "f2 is-right-convergent-inLIMFUNC2R4 lim-in+inftyLIMFUNC1K5 f1"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    assume Given: " ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies lim-in+inftyLIMFUNC1K5 f1 <XXREAL-0R3 f1 .FUNCT-1K1 g"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A4: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies lim-in+inftyLIMFUNC1K5 f1 <XXREAL-0R3 f1 .FUNCT-1K1 g"
       sorry
    have A5: " for s be Real-SequenceSEQ-1M1 holds s be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-rightLIMFUNC2K2(f2,lim-in+inftyLIMFUNC1K5 f1)"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      let ?L = "lim-rightLIMFUNC2K2(f2,lim-in+inftyLIMFUNC1K5 f1)"
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A6: "s be divergent-to+inftyLIMFUNC1V1"
        and A7: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A8: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies r <XXREAL-0R3 s .FUNCT-1K1 n"
        using A6 sorry
      let ?q = "s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "?q be divergent-to+inftyLIMFUNC1V1"
        using A6 limfunc1_th_26 sorry
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A7 limfunc4_lm_2 sorry
      have A11: "rngFUNCT-1K2 ?q c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      then have "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A10 sorry
      then have A12: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be convergentSEQ-2V5 & limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 lim-in+inftyLIMFUNC1K5 f1"
        using A1 A9 limfunc1_def_12 sorry
      have A13: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 limfunc4_lm_2 sorry
      have A14: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-in+inftyLIMFUNC1K5 f1))"
      proof-
        have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-in+inftyLIMFUNC1K5 f1))"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-in+inftyLIMFUNC1K5 f1))"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q)"
            then obtain n where
              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A15: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
              using funct_2_th_113 sorry
            have A16: "x =HIDDENR1 f1 .FUNCT-1K1 (?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
              using A10 A11 A15 funct_2_th_108 xboole_1_th_1 sorry
            also have "... = f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
              using nat_1_def_3 sorry
            finally have "x =HIDDENR1 f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
               sorry
            have "r <XXREAL-0R3 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
              using A8 nat_1_th_12 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {r2 where r2 be RealXREAL-0M1 : r <XXREAL-0R3 r2 }"
               sorry
            then have A17: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 right-open-halflineLIMFUNC1K4 r"
              using xxreal_1_th_230 sorry
            have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
              using valued_0_th_28 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r)"
              using A10 A17 xboole_0_def_4 sorry
            then have "lim-in+inftyLIMFUNC1K5 f1 <XXREAL-0R3 f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
              using A4 sorry
            then have "x inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : lim-in+inftyLIMFUNC1K5 f1 <XXREAL-0R3 g1 }"
              using A16 sorry
            then have A18: "x inHIDDENR3 right-open-halflineLIMFUNC1K4 (lim-in+inftyLIMFUNC1K5 f1)"
              using xxreal_1_th_230 sorry
            have A19: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s)"
              using valued_0_th_28 sorry
            then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A13 sorry
            then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A10 A16 funct_2_th_108 A19 sorry
            thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-in+inftyLIMFUNC1K5 f1))"
              using A18 xboole_0_def_4 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-in+inftyLIMFUNC1K5 f1))"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have A20: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        using A10 valued_0_th_27 sorry
      also have "... = f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A13 valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A7 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have "?L =HIDDENR1 ?L"
         sorry
      then have A21: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) be convergentSEQ-2V5"
        using A2 A12 A14 limfunc2_def_8 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A20 seq_4_th_21 sorry
      have "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 ?L"
        using A2 A12 A14 limfunc2_def_8 sorry
      thus "limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-rightLIMFUNC2K2(f2,lim-in+inftyLIMFUNC1K5 f1)"
        using A21 A20 seq_4_th_22 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be convergent-in+inftyLIMFUNC1V3"
      using A3 sorry
    thus "lim-in+inftyLIMFUNC1K5 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) =HIDDENR1 lim-rightLIMFUNC2K2(f2,lim-in+inftyLIMFUNC1K5 f1)"
      using A5 limfunc1_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_67:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 be convergent-in-inftyLIMFUNC1V6 & f2 is-left-convergent-inLIMFUNC2R1 lim-in-inftyLIMFUNC1K6 f1) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) & ( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <XXREAL-0R3 lim-in-inftyLIMFUNC1K6 f1) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) =HIDDENR1 lim-leftLIMFUNC2K1(f2,lim-in-inftyLIMFUNC1K6 f1)"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be convergent-in-inftyLIMFUNC1V6 & (f2 is-left-convergent-inLIMFUNC2R1 lim-in-inftyLIMFUNC1K6 f1 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies (( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <XXREAL-0R3 lim-in-inftyLIMFUNC1K6 f1) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) =HIDDENR1 lim-leftLIMFUNC2K1(f2,lim-in-inftyLIMFUNC1K6 f1))"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI,rule conjMI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be convergent-in-inftyLIMFUNC1V6"
      and A2: "f2 is-left-convergent-inLIMFUNC2R1 lim-in-inftyLIMFUNC1K6 f1"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    assume Given: " ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <XXREAL-0R3 lim-in-inftyLIMFUNC1K6 f1"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A4: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <XXREAL-0R3 lim-in-inftyLIMFUNC1K6 f1"
       sorry
    have A5: " for s be Real-SequenceSEQ-1M1 holds s be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-leftLIMFUNC2K1(f2,lim-in-inftyLIMFUNC1K6 f1)"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      let ?L = "lim-leftLIMFUNC2K1(f2,lim-in-inftyLIMFUNC1K6 f1)"
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A6: "s be divergent-to-inftyLIMFUNC1V2"
        and A7: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A8: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies s .FUNCT-1K1 n <XXREAL-0R3 r"
        using A6 sorry
      let ?q = "s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "?q be divergent-to-inftyLIMFUNC1V2"
        using A6 limfunc1_th_27 sorry
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A7 limfunc4_lm_2 sorry
      have A11: "rngFUNCT-1K2 ?q c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      then have "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A10 sorry
      then have A12: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be convergentSEQ-2V5 & limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 lim-in-inftyLIMFUNC1K6 f1"
        using A1 A9 limfunc1_def_13 sorry
      have A13: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 limfunc4_lm_2 sorry
      have A14: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-in-inftyLIMFUNC1K6 f1))"
      proof-
        have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-in-inftyLIMFUNC1K6 f1))"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-in-inftyLIMFUNC1K6 f1))"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q)"
            then obtain n where
              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A15: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
              using funct_2_th_113 sorry
            have A16: "x =HIDDENR1 f1 .FUNCT-1K1 (?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
              using A10 A11 A15 funct_2_th_108 xboole_1_th_1 sorry
            also have "... = f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
              using nat_1_def_3 sorry
            finally have "x =HIDDENR1 f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
               sorry
            have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) <XXREAL-0R3 r"
              using A8 nat_1_th_12 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {r2 where r2 be RealXREAL-0M1 : r2 <XXREAL-0R3 r }"
               sorry
            then have A17: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 left-open-halflineLIMFUNC1K1 r"
              using xxreal_1_th_229 sorry
            have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
              using valued_0_th_28 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r)"
              using A10 A17 xboole_0_def_4 sorry
            then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) <XXREAL-0R3 lim-in-inftyLIMFUNC1K6 f1"
              using A4 sorry
            then have "x inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : g1 <XXREAL-0R3 lim-in-inftyLIMFUNC1K6 f1 }"
              using A16 sorry
            then have A18: "x inHIDDENR3 left-open-halflineLIMFUNC1K1 (lim-in-inftyLIMFUNC1K6 f1)"
              using xxreal_1_th_229 sorry
            have A19: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s)"
              using valued_0_th_28 sorry
            then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A13 sorry
            then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A10 A16 funct_2_th_108 A19 sorry
            thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-in-inftyLIMFUNC1K6 f1))"
              using A18 xboole_0_def_4 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (lim-in-inftyLIMFUNC1K6 f1))"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have A20: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        using A10 valued_0_th_27 sorry
      also have "... = f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A13 valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A7 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have "?L =HIDDENR1 ?L"
         sorry
      then have A21: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) be convergentSEQ-2V5"
        using A2 A12 A14 limfunc2_def_7 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A20 seq_4_th_21 sorry
      have "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 ?L"
        using A2 A12 A14 limfunc2_def_7 sorry
      thus "limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-leftLIMFUNC2K1(f2,lim-in-inftyLIMFUNC1K6 f1)"
        using A21 A20 seq_4_th_22 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be convergent-in-inftyLIMFUNC1V6"
      using A3 sorry
    thus "lim-in-inftyLIMFUNC1K6 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) =HIDDENR1 lim-leftLIMFUNC2K1(f2,lim-in-inftyLIMFUNC1K6 f1)"
      using A5 limfunc1_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_68:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 be convergent-in-inftyLIMFUNC1V6 & f2 is-right-convergent-inLIMFUNC2R4 lim-in-inftyLIMFUNC1K6 f1) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) & ( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies lim-in-inftyLIMFUNC1K6 f1 <XXREAL-0R3 f1 .FUNCT-1K1 g) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) =HIDDENR1 lim-rightLIMFUNC2K2(f2,lim-in-inftyLIMFUNC1K6 f1)"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be convergent-in-inftyLIMFUNC1V6 & (f2 is-right-convergent-inLIMFUNC2R4 lim-in-inftyLIMFUNC1K6 f1 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies (( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies lim-in-inftyLIMFUNC1K6 f1 <XXREAL-0R3 f1 .FUNCT-1K1 g) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) =HIDDENR1 lim-rightLIMFUNC2K2(f2,lim-in-inftyLIMFUNC1K6 f1))"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI,rule conjMI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be convergent-in-inftyLIMFUNC1V6"
      and A2: "f2 is-right-convergent-inLIMFUNC2R4 lim-in-inftyLIMFUNC1K6 f1"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    assume Given: " ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies lim-in-inftyLIMFUNC1K6 f1 <XXREAL-0R3 f1 .FUNCT-1K1 g"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A4: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies lim-in-inftyLIMFUNC1K6 f1 <XXREAL-0R3 f1 .FUNCT-1K1 g"
       sorry
    have A5: " for s be Real-SequenceSEQ-1M1 holds s be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-rightLIMFUNC2K2(f2,lim-in-inftyLIMFUNC1K6 f1)"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      let ?L = "lim-rightLIMFUNC2K2(f2,lim-in-inftyLIMFUNC1K6 f1)"
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A6: "s be divergent-to-inftyLIMFUNC1V2"
        and A7: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A8: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies s .FUNCT-1K1 n <XXREAL-0R3 r"
        using A6 sorry
      let ?q = "s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "?q be divergent-to-inftyLIMFUNC1V2"
        using A6 limfunc1_th_27 sorry
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A7 limfunc4_lm_2 sorry
      have A11: "rngFUNCT-1K2 ?q c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      then have "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A10 sorry
      then have A12: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be convergentSEQ-2V5 & limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 lim-in-inftyLIMFUNC1K6 f1"
        using A1 A9 limfunc1_def_13 sorry
      have A13: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 limfunc4_lm_2 sorry
      have A14: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-in-inftyLIMFUNC1K6 f1))"
      proof-
        have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-in-inftyLIMFUNC1K6 f1))"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-in-inftyLIMFUNC1K6 f1))"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q)"
            then obtain n where
              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A15: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
              using funct_2_th_113 sorry
            have A16: "x =HIDDENR1 f1 .FUNCT-1K1 (?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
              using A10 A11 A15 funct_2_th_108 xboole_1_th_1 sorry
            also have "... = f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
              using nat_1_def_3 sorry
            finally have "x =HIDDENR1 f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
               sorry
            have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) <XXREAL-0R3 r"
              using A8 nat_1_th_12 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {r2 where r2 be RealXREAL-0M1 : r2 <XXREAL-0R3 r }"
               sorry
            then have A17: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 left-open-halflineLIMFUNC1K1 r"
              using xxreal_1_th_229 sorry
            have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
              using valued_0_th_28 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r)"
              using A10 A17 xboole_0_def_4 sorry
            then have "lim-in-inftyLIMFUNC1K6 f1 <XXREAL-0R3 f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
              using A4 sorry
            then have "x inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : lim-in-inftyLIMFUNC1K6 f1 <XXREAL-0R3 g1 }"
              using A16 sorry
            then have A18: "x inHIDDENR3 right-open-halflineLIMFUNC1K4 (lim-in-inftyLIMFUNC1K6 f1)"
              using xxreal_1_th_230 sorry
            have A19: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s)"
              using valued_0_th_28 sorry
            then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A13 sorry
            then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A10 A16 funct_2_th_108 A19 sorry
            thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-in-inftyLIMFUNC1K6 f1))"
              using A18 xboole_0_def_4 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (lim-in-inftyLIMFUNC1K6 f1))"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have A20: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        using A10 valued_0_th_27 sorry
      also have "... = f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A13 valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A7 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have "?L =HIDDENR1 ?L"
         sorry
      then have A21: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) be convergentSEQ-2V5"
        using A2 A12 A14 limfunc2_def_8 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A20 seq_4_th_21 sorry
      have "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 ?L"
        using A2 A12 A14 limfunc2_def_8 sorry
      thus "limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-rightLIMFUNC2K2(f2,lim-in-inftyLIMFUNC1K6 f1)"
        using A21 A20 seq_4_th_22 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be convergent-in-inftyLIMFUNC1V6"
      using A3 sorry
    thus "lim-in-inftyLIMFUNC1K6 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) =HIDDENR1 lim-rightLIMFUNC2K2(f2,lim-in-inftyLIMFUNC1K6 f1)"
      using A5 limfunc1_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_69:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-divergent-to+infty-inLIMFUNC3R2 x0 & f2 be convergent-in+inftyLIMFUNC1V3) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-in+inftyLIMFUNC1K5 f2"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-divergent-to+infty-inLIMFUNC3R2 x0 & (f2 be convergent-in+inftyLIMFUNC1V3 & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-in+inftyLIMFUNC1K5 f2"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-divergent-to+infty-inLIMFUNC3R2 x0"
      and A2: "f2 be convergent-in+inftyLIMFUNC1V3"
      and A3: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    have A4: " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0} implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-in+inftyLIMFUNC1K5 f2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A5: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
        using A6 limfunc4_th_2 sorry
      then have A7: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A1 A5 limfunc3_def_2 sorry
      have A8: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc4_th_2 sorry
      then have A9: "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) =HIDDENR1 lim-in+inftyLIMFUNC1K5 f2"
        using A2 A7 limfunc1_def_12 sorry
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A6 limfunc4_th_2 sorry
      have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) be convergentSEQ-2V5"
        using A2 A8 A7 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-in+inftyLIMFUNC1K5 f2"
        using A10 A9 valued_0_th_31 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-convergent-inLIMFUNC3R1 x0"
      using A3 limfunc3_def_1 sorry
    thus "limLIMFUNC3K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-in+inftyLIMFUNC1K5 f2"
      using A4 limfunc3_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_70:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-divergent-to-infty-inLIMFUNC3R3 x0 & f2 be convergent-in-inftyLIMFUNC1V6) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-in-inftyLIMFUNC1K6 f2"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-divergent-to-infty-inLIMFUNC3R3 x0 & (f2 be convergent-in-inftyLIMFUNC1V6 & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-in-inftyLIMFUNC1K6 f2"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-divergent-to-infty-inLIMFUNC3R3 x0"
      and A2: "f2 be convergent-in-inftyLIMFUNC1V6"
      and A3: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    have A4: " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0} implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-in-inftyLIMFUNC1K6 f2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A5: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
        using A6 limfunc4_th_2 sorry
      then have A7: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A1 A5 limfunc3_def_3 sorry
      have A8: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc4_th_2 sorry
      then have A9: "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) =HIDDENR1 lim-in-inftyLIMFUNC1K6 f2"
        using A2 A7 limfunc1_def_13 sorry
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A6 limfunc4_th_2 sorry
      have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) be convergentSEQ-2V5"
        using A2 A8 A7 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-in-inftyLIMFUNC1K6 f2"
        using A10 A9 valued_0_th_31 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-convergent-inLIMFUNC3R1 x0"
      using A3 limfunc3_def_1 sorry
    thus "limLIMFUNC3K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-in-inftyLIMFUNC1K6 f2"
      using A4 limfunc3_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_71:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 be convergent-in+inftyLIMFUNC1V3 & f2 is-convergent-inLIMFUNC3R1 lim-in+inftyLIMFUNC1K5 f1) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) & ( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <>HIDDENR2 lim-in+inftyLIMFUNC1K5 f1) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) =HIDDENR1 limLIMFUNC3K1(f2,lim-in+inftyLIMFUNC1K5 f1)"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be convergent-in+inftyLIMFUNC1V3 & (f2 is-convergent-inLIMFUNC3R1 lim-in+inftyLIMFUNC1K5 f1 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies (( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <>HIDDENR2 lim-in+inftyLIMFUNC1K5 f1) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) =HIDDENR1 limLIMFUNC3K1(f2,lim-in+inftyLIMFUNC1K5 f1))"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI,rule conjMI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be convergent-in+inftyLIMFUNC1V3"
      and A2: "f2 is-convergent-inLIMFUNC3R1 lim-in+inftyLIMFUNC1K5 f1"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    assume Given: " ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <>HIDDENR2 lim-in+inftyLIMFUNC1K5 f1"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A4: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <>HIDDENR2 lim-in+inftyLIMFUNC1K5 f1"
       sorry
    have A5: " for s be Real-SequenceSEQ-1M1 holds s be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 limLIMFUNC3K1(f2,lim-in+inftyLIMFUNC1K5 f1)"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      let ?L = "limLIMFUNC3K1(f2,lim-in+inftyLIMFUNC1K5 f1)"
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A6: "s be divergent-to+inftyLIMFUNC1V1"
        and A7: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A8: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies r <XXREAL-0R3 s .FUNCT-1K1 n"
        using A6 sorry
      let ?q = "s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "?q be divergent-to+inftyLIMFUNC1V1"
        using A6 limfunc1_th_26 sorry
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A7 limfunc4_lm_2 sorry
      have A11: "rngFUNCT-1K2 ?q c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      then have "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A10 sorry
      then have A12: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be convergentSEQ-2V5 & limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 lim-in+inftyLIMFUNC1K5 f1"
        using A1 A9 limfunc1_def_12 sorry
      have A13: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 limfunc4_lm_2 sorry
      have A14: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-in+inftyLIMFUNC1K5 f1 }"
      proof-
        have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-in+inftyLIMFUNC1K5 f1 }"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-in+inftyLIMFUNC1K5 f1 }"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q)"
            then obtain n where
              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A15: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
              using funct_2_th_113 sorry
            have A16: "x =HIDDENR1 f1 .FUNCT-1K1 (?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
              using A10 A11 A15 funct_2_th_108 xboole_1_th_1 sorry
            also have "... = f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
              using nat_1_def_3 sorry
            finally have "x =HIDDENR1 f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
               sorry
            have "r <XXREAL-0R3 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
              using A8 nat_1_th_12 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {r2 where r2 be RealXREAL-0M1 : r <XXREAL-0R3 r2 }"
               sorry
            then have A17: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 right-open-halflineLIMFUNC1K4 r"
              using xxreal_1_th_230 sorry
            have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
              using valued_0_th_28 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r)"
              using A10 A17 xboole_0_def_4 sorry
            then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) <>HIDDENR2 lim-in+inftyLIMFUNC1K5 f1"
              using A4 sorry
            then have A18: " not f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 {TARSKIK1 lim-in+inftyLIMFUNC1K5 f1 }"
              using tarski_def_1 sorry
            have A19: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s)"
              using valued_0_th_28 sorry
            then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A13 sorry
            then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A10 A16 funct_2_th_108 A19 sorry
            thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-in+inftyLIMFUNC1K5 f1 }"
              using A16 A18 xboole_0_def_5 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-in+inftyLIMFUNC1K5 f1 }"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have A20: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        using A10 valued_0_th_27 sorry
      also have "... = f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A13 valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A7 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have "?L =HIDDENR1 ?L"
         sorry
      then have A21: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) be convergentSEQ-2V5"
        using A2 A12 A14 limfunc3_def_4 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A20 seq_4_th_21 sorry
      have "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 ?L"
        using A2 A12 A14 limfunc3_def_4 sorry
      thus "limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 limLIMFUNC3K1(f2,lim-in+inftyLIMFUNC1K5 f1)"
        using A21 A20 seq_4_th_22 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be convergent-in+inftyLIMFUNC1V3"
      using A3 sorry
    thus "lim-in+inftyLIMFUNC1K5 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) =HIDDENR1 limLIMFUNC3K1(f2,lim-in+inftyLIMFUNC1K5 f1)"
      using A5 limfunc1_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_72:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 be convergent-in-inftyLIMFUNC1V6 & f2 is-convergent-inLIMFUNC3R1 lim-in-inftyLIMFUNC1K6 f1) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) & ( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <>HIDDENR2 lim-in-inftyLIMFUNC1K6 f1) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) =HIDDENR1 limLIMFUNC3K1(f2,lim-in-inftyLIMFUNC1K6 f1)"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be convergent-in-inftyLIMFUNC1V6 & (f2 is-convergent-inLIMFUNC3R1 lim-in-inftyLIMFUNC1K6 f1 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) implies (( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <>HIDDENR2 lim-in-inftyLIMFUNC1K6 f1) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) =HIDDENR1 limLIMFUNC3K1(f2,lim-in-inftyLIMFUNC1K6 f1))"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI,rule conjMI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be convergent-in-inftyLIMFUNC1V6"
      and A2: "f2 is-convergent-inLIMFUNC3R1 lim-in-inftyLIMFUNC1K6 f1"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    assume Given: " ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <>HIDDENR2 lim-in-inftyLIMFUNC1K6 f1"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A4: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <>HIDDENR2 lim-in-inftyLIMFUNC1K6 f1"
       sorry
    have A5: " for s be Real-SequenceSEQ-1M1 holds s be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 limLIMFUNC3K1(f2,lim-in-inftyLIMFUNC1K6 f1)"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      let ?L = "limLIMFUNC3K1(f2,lim-in-inftyLIMFUNC1K6 f1)"
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A6: "s be divergent-to-inftyLIMFUNC1V2"
        and A7: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A8: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies s .FUNCT-1K1 n <XXREAL-0R3 r"
        using A6 sorry
      let ?q = "s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A9: "?q be divergent-to-inftyLIMFUNC1V2"
        using A6 limfunc1_th_27 sorry
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A7 limfunc4_lm_2 sorry
      have A11: "rngFUNCT-1K2 ?q c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      then have "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A10 sorry
      then have A12: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be convergentSEQ-2V5 & limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 lim-in-inftyLIMFUNC1K6 f1"
        using A1 A9 limfunc1_def_13 sorry
      have A13: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 limfunc4_lm_2 sorry
      have A14: "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-in-inftyLIMFUNC1K6 f1 }"
      proof-
        have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-in-inftyLIMFUNC1K6 f1 }"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-in-inftyLIMFUNC1K6 f1 }"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q)"
            then obtain n where
              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A15: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
              using funct_2_th_113 sorry
            have A16: "x =HIDDENR1 f1 .FUNCT-1K1 (?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
              using A10 A11 A15 funct_2_th_108 xboole_1_th_1 sorry
            also have "... = f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
              using nat_1_def_3 sorry
            finally have "x =HIDDENR1 f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k))"
               sorry
            have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) <XXREAL-0R3 r"
              using A8 nat_1_th_12 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {r2 where r2 be RealXREAL-0M1 : r2 <XXREAL-0R3 r }"
               sorry
            then have A17: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 left-open-halflineLIMFUNC1K1 r"
              using xxreal_1_th_229 sorry
            have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
              using valued_0_th_28 sorry
            then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r)"
              using A10 A17 xboole_0_def_4 sorry
            then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) <>HIDDENR2 lim-in-inftyLIMFUNC1K6 f1"
              using A4 sorry
            then have A18: " not f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 {TARSKIK1 lim-in-inftyLIMFUNC1K6 f1 }"
              using tarski_def_1 sorry
            have A19: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s)"
              using valued_0_th_28 sorry
            then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A13 sorry
            then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A10 A16 funct_2_th_108 A19 sorry
            thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-in-inftyLIMFUNC1K6 f1 }"
              using A16 A18 xboole_0_def_5 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-in-inftyLIMFUNC1K6 f1 }"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have A20: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        using A10 valued_0_th_27 sorry
      also have "... = f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A13 valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A7 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have "?L =HIDDENR1 ?L"
         sorry
      then have A21: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) be convergentSEQ-2V5"
        using A2 A12 A14 limfunc3_def_4 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A20 seq_4_th_21 sorry
      have "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q) =HIDDENR1 ?L"
        using A2 A12 A14 limfunc3_def_4 sorry
      thus "limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 limLIMFUNC3K1(f2,lim-in-inftyLIMFUNC1K6 f1)"
        using A21 A20 seq_4_th_22 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 be convergent-in-inftyLIMFUNC1V6"
      using A3 sorry
    thus "lim-in-inftyLIMFUNC1K6 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) =HIDDENR1 limLIMFUNC3K1(f2,lim-in-inftyLIMFUNC1K6 f1)"
      using A5 limfunc1_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_73:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-convergent-inLIMFUNC3R1 x0 & f2 is-left-convergent-inLIMFUNC2R1 limLIMFUNC3K1(f1,x0)) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) & ( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <XXREAL-0R3 limLIMFUNC3K1(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-leftLIMFUNC2K1(f2,limLIMFUNC3K1(f1,x0))"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-convergent-inLIMFUNC3R1 x0 & (f2 is-left-convergent-inLIMFUNC2R1 limLIMFUNC3K1(f1,x0) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies (( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <XXREAL-0R3 limLIMFUNC3K1(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-leftLIMFUNC2K1(f2,limLIMFUNC3K1(f1,x0)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-convergent-inLIMFUNC3R1 x0"
      and A2: "f2 is-left-convergent-inLIMFUNC2R1 limLIMFUNC3K1(f1,x0)"
      and A3: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    assume Given: " ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <XXREAL-0R3 limLIMFUNC3K1(f1,x0))"
    then obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 g"and A5: " for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <XXREAL-0R3 limLIMFUNC3K1(f1,x0)"
       sorry
    have A6: " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0} implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-leftLIMFUNC2K1(f2,limLIMFUNC3K1(f1,x0))"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A7: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A8: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
      obtain k where
        [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
        A9: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0 +XCMPLX-0K2 g"
        using A4 A7 limfunc3_th_7 sorry
      let ?q = "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A8 limfunc4_th_2 sorry
      have A11: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A8 limfunc4_th_2 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (limLIMFUNC3K1(f1,x0)))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 ?q"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A12: "?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
          using funct_2_th_113 sorry
        have A13: "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) =HIDDENR1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)"
          using A11 funct_2_th_108 sorry
        also have "... = x"
          using A12 nat_1_def_3 sorry
        finally have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) =HIDDENR1 x"
           sorry
        have "k <=XXREAL-0R1 n +NAT-1K1 k"
          using nat_1_th_12 sorry
        then have "x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) <XXREAL-0R3 x0 +XCMPLX-0K2 g"
          using A9 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : x0 -XCMPLX-0K6 g <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0 +XCMPLX-0K2 g }"
           sorry
        then have A14: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 +XCMPLX-0K2 g .["
          using rcomp_1_def_2 sorry
        have A15: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 rngFUNCT-1K2 s"
          using valued_0_th_28 sorry
        then have " not s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 {TARSKIK1 x0}"
          using A8 xboole_0_def_5 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 +XCMPLX-0K2 g .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
          using A14 xboole_0_def_5 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .["
          using A4 limfunc3_th_4 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[)"
          using A11 A15 xboole_0_def_4 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) <XXREAL-0R3 limLIMFUNC3K1(f1,x0)"
          using A5 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : g2 <XXREAL-0R3 limLIMFUNC3K1(f1,x0) }"
           sorry
        then have A16: "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) inTARSKIR2 left-open-halflineLIMFUNC1K1 (limLIMFUNC3K1(f1,x0))"
          using xxreal_1_th_229 sorry
        have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A10 A15 funct_1_th_11 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (limLIMFUNC3K1(f1,x0)))"
          using A16 A13 xboole_0_def_4 sorry
      qed "sorry"
      then have A17: "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 (limLIMFUNC3K1(f1,x0)))"
         sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A8 limfunc4_th_2 sorry
      then have A18: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A10 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have A19: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
        using A8 limfunc4_th_2 sorry
      then have A20: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A1 A2 A7 limfunc3_def_4 sorry
      have "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 limLIMFUNC3K1(f1,x0)"
        using A1 A7 A19 limfunc3_def_4 sorry
      then have A21: "limSEQ-2K1 ?q =HIDDENR1 limLIMFUNC3K1(f1,x0)"
        using A20 seq_4_th_20 sorry
      have "lim-leftLIMFUNC2K1(f2,limLIMFUNC3K1(f1,x0)) =HIDDENR1 lim-leftLIMFUNC2K1(f2,limLIMFUNC3K1(f1,x0))"
         sorry
      then have A22: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be convergentSEQ-2V5"
        using A2 A20 A21 A17 limfunc2_def_7 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A18 seq_4_th_21 sorry
      have "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 lim-leftLIMFUNC2K1(f2,limLIMFUNC3K1(f1,x0))"
        using A2 A20 A21 A17 limfunc2_def_7 sorry
      thus "limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-leftLIMFUNC2K1(f2,limLIMFUNC3K1(f1,x0))"
        using A22 A18 seq_4_th_22 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-convergent-inLIMFUNC3R1 x0"
      using A3 limfunc3_def_1 sorry
    thus "limLIMFUNC3K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-leftLIMFUNC2K1(f2,limLIMFUNC3K1(f1,x0))"
      using A6 limfunc3_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_74:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-left-convergent-inLIMFUNC2R1 x0 & f2 is-convergent-inLIMFUNC3R1 lim-leftLIMFUNC2K1(f1,x0)) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) & ( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 lim-leftLIMFUNC2K1(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-convergent-inLIMFUNC2R1 x0 & lim-leftLIMFUNC2K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 limLIMFUNC3K1(f2,lim-leftLIMFUNC2K1(f1,x0))"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-left-convergent-inLIMFUNC2R1 x0 & (f2 is-convergent-inLIMFUNC3R1 lim-leftLIMFUNC2K1(f1,x0) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies (( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 lim-leftLIMFUNC2K1(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-convergent-inLIMFUNC2R1 x0 & lim-leftLIMFUNC2K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 limLIMFUNC3K1(f2,lim-leftLIMFUNC2K1(f1,x0)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-left-convergent-inLIMFUNC2R1 x0"
      and A2: "f2 is-convergent-inLIMFUNC3R1 lim-leftLIMFUNC2K1(f1,x0)"
      and A3: " for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    assume Given: " ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 lim-leftLIMFUNC2K1(f1,x0))"
    then obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 g"and A5: " for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 lim-leftLIMFUNC2K1(f1,x0)"
       sorry
    have A6: " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 limLIMFUNC3K1(f2,lim-leftLIMFUNC2K1(f1,x0))"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A7: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A8: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A9: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-1K1 n"
        using A4 A7 limfunc4_lm_1 limfunc2_th_1 sorry
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A8 limfunc4_th_1 sorry
      let ?q = "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A11: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A8 limfunc4_th_1 sorry
      have A12: "rngFUNCT-1K2 s c=TARSKIR1 left-open-halflineLIMFUNC1K1 x0"
        using A8 limfunc4_th_1 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-leftLIMFUNC2K1(f1,x0) }"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 ?q"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A13: "?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
          using funct_2_th_113 sorry
        have A14: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have A15: "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A10 funct_2_th_108 A14 sorry
        also have "... = x"
          using A13 nat_1_def_3 sorry
        finally have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 x"
           sorry
        have A16: "x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A9 nat_1_th_12 sorry
        have A17: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
          using valued_0_th_28 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 left-open-halflineLIMFUNC1K1 x0"
          using A12 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : g1 <XXREAL-0R3 x0 }"
          using xxreal_1_th_229 sorry
        then have " ex g1 be RealXREAL-0M1 st g1 =HIDDENR1 s .FUNCT-1K1 (n +XCMPLX-0K2 k) & g1 <XXREAL-0R3 x0"
           sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : x0 -XCMPLX-0K6 g <XXREAL-0R3 g2 & g2 <XXREAL-0R3 x0 }"
          using A16 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .["
          using rcomp_1_def_2 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[)"
          using A10 A17 xboole_0_def_4 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) <>HIDDENR2 lim-leftLIMFUNC2K1(f1,x0)"
          using A5 sorry
        then have A18: " not f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 {TARSKIK1 lim-leftLIMFUNC2K1(f1,x0) }"
          using tarski_def_1 sorry
        have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A11 A17 funct_1_th_11 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-leftLIMFUNC2K1(f1,x0) }"
          using A18 A15 xboole_0_def_5 sorry
      qed "sorry"
      then have A19: "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-leftLIMFUNC2K1(f1,x0) }"
         sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A8 limfunc4_th_1 sorry
      then have A20: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A11 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have A21: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
        using A8 limfunc4_th_1 sorry
      then have A22: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A1 A2 A7 limfunc2_def_7 sorry
      have "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-leftLIMFUNC2K1(f1,x0)"
        using A1 A7 A21 limfunc2_def_7 sorry
      then have A23: "limSEQ-2K1 ?q =HIDDENR1 lim-leftLIMFUNC2K1(f1,x0)"
        using A22 seq_4_th_20 sorry
      have "limLIMFUNC3K1(f2,lim-leftLIMFUNC2K1(f1,x0)) =HIDDENR1 limLIMFUNC3K1(f2,lim-leftLIMFUNC2K1(f1,x0))"
         sorry
      then have A24: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be convergentSEQ-2V5"
        using A2 A22 A23 A19 limfunc3_def_4 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A20 seq_4_th_21 sorry
      have "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 limLIMFUNC3K1(f2,lim-leftLIMFUNC2K1(f1,x0))"
        using A2 A22 A23 A19 limfunc3_def_4 sorry
      thus "limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 limLIMFUNC3K1(f2,lim-leftLIMFUNC2K1(f1,x0))"
        using A24 A20 seq_4_th_22 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-left-convergent-inLIMFUNC2R1 x0"
      using A3 limfunc2_def_1 sorry
    thus "lim-leftLIMFUNC2K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 limLIMFUNC3K1(f2,lim-leftLIMFUNC2K1(f1,x0))"
      using A6 limfunc2_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_75:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-convergent-inLIMFUNC3R1 x0 & f2 is-right-convergent-inLIMFUNC2R4 limLIMFUNC3K1(f1,x0)) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) & ( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies limLIMFUNC3K1(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 r)) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-rightLIMFUNC2K2(f2,limLIMFUNC3K1(f1,x0))"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-convergent-inLIMFUNC3R1 x0 & (f2 is-right-convergent-inLIMFUNC2R4 limLIMFUNC3K1(f1,x0) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies (( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies limLIMFUNC3K1(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 r)) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-rightLIMFUNC2K2(f2,limLIMFUNC3K1(f1,x0)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-convergent-inLIMFUNC3R1 x0"
      and A2: "f2 is-right-convergent-inLIMFUNC2R4 limLIMFUNC3K1(f1,x0)"
      and A3: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    assume Given: " ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies limLIMFUNC3K1(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 r)"
    then obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 g"and A5: " for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies limLIMFUNC3K1(f1,x0) <XXREAL-0R3 f1 .FUNCT-1K1 r"
       sorry
    have A6: " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0} implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-rightLIMFUNC2K2(f2,limLIMFUNC3K1(f1,x0))"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A7: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A8: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
      obtain k where
        [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
        A9: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0 +XCMPLX-0K2 g"
        using A4 A7 limfunc3_th_7 sorry
      let ?q = "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A8 limfunc4_th_2 sorry
      have A11: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A8 limfunc4_th_2 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (limLIMFUNC3K1(f1,x0)))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 ?q"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A12: "?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
          using funct_2_th_113 sorry
        have A13: "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) =HIDDENR1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)"
          using A11 funct_2_th_108 sorry
        also have "... = x"
          using A12 nat_1_def_3 sorry
        finally have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) =HIDDENR1 x"
           sorry
        have "k <=XXREAL-0R1 n +NAT-1K1 k"
          using nat_1_th_12 sorry
        then have "x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) <XXREAL-0R3 x0 +XCMPLX-0K2 g"
          using A9 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : x0 -XCMPLX-0K6 g <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0 +XCMPLX-0K2 g }"
           sorry
        then have A14: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 +XCMPLX-0K2 g .["
          using rcomp_1_def_2 sorry
        have A15: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 rngFUNCT-1K2 s"
          using valued_0_th_28 sorry
        then have " not s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 {TARSKIK1 x0}"
          using A8 xboole_0_def_5 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 +XCMPLX-0K2 g .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
          using A14 xboole_0_def_5 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .["
          using A4 limfunc3_th_4 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[)"
          using A11 A15 xboole_0_def_4 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) >XXREAL-0R4 limLIMFUNC3K1(f1,x0)"
          using A5 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : limLIMFUNC3K1(f1,x0) <XXREAL-0R3 g2 }"
           sorry
        then have A16: "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) inTARSKIR2 right-open-halflineLIMFUNC1K4 (limLIMFUNC3K1(f1,x0))"
          using xxreal_1_th_230 sorry
        have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A10 A15 funct_1_th_11 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (limLIMFUNC3K1(f1,x0)))"
          using A16 A13 xboole_0_def_4 sorry
      qed "sorry"
      then have A17: "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (limLIMFUNC3K1(f1,x0)))"
         sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A8 limfunc4_th_2 sorry
      then have A18: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A10 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have A19: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
        using A8 limfunc4_th_2 sorry
      then have A20: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A1 A2 A7 limfunc3_def_4 sorry
      have "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 limLIMFUNC3K1(f1,x0)"
        using A1 A7 A19 limfunc3_def_4 sorry
      then have A21: "limSEQ-2K1 ?q =HIDDENR1 limLIMFUNC3K1(f1,x0)"
        using A20 seq_4_th_20 sorry
      have "lim-rightLIMFUNC2K2(f2,limLIMFUNC3K1(f1,x0)) =HIDDENR1 lim-rightLIMFUNC2K2(f2,limLIMFUNC3K1(f1,x0))"
         sorry
      then have A22: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be convergentSEQ-2V5"
        using A2 A20 A21 A17 limfunc2_def_8 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A18 seq_4_th_21 sorry
      have "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 lim-rightLIMFUNC2K2(f2,limLIMFUNC3K1(f1,x0))"
        using A2 A20 A21 A17 limfunc2_def_8 sorry
      thus "limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-rightLIMFUNC2K2(f2,limLIMFUNC3K1(f1,x0))"
        using A22 A18 seq_4_th_22 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-convergent-inLIMFUNC3R1 x0"
      using A3 limfunc3_def_1 sorry
    thus "limLIMFUNC3K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 lim-rightLIMFUNC2K2(f2,limLIMFUNC3K1(f1,x0))"
      using A6 limfunc3_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_76:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-right-convergent-inLIMFUNC2R4 x0 & f2 is-convergent-inLIMFUNC3R1 lim-rightLIMFUNC2K2(f1,x0)) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) & ( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 lim-rightLIMFUNC2K2(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-convergent-inLIMFUNC2R4 x0 & lim-rightLIMFUNC2K2(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 limLIMFUNC3K1(f2,lim-rightLIMFUNC2K2(f1,x0))"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-right-convergent-inLIMFUNC2R4 x0 & (f2 is-convergent-inLIMFUNC3R1 lim-rightLIMFUNC2K2(f1,x0) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies (( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 lim-rightLIMFUNC2K2(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-convergent-inLIMFUNC2R4 x0 & lim-rightLIMFUNC2K2(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 limLIMFUNC3K1(f2,lim-rightLIMFUNC2K2(f1,x0)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-right-convergent-inLIMFUNC2R4 x0"
      and A2: "f2 is-convergent-inLIMFUNC3R1 lim-rightLIMFUNC2K2(f1,x0)"
      and A3: " for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    assume Given: " ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 lim-rightLIMFUNC2K2(f1,x0))"
    then obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 g"and A5: " for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 lim-rightLIMFUNC2K2(f1,x0)"
       sorry
    have A6: " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 limLIMFUNC3K1(f2,lim-rightLIMFUNC2K2(f1,x0))"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A7: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A8: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A9: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies s .FUNCT-1K1 n <XXREAL-0R3 x0 +XCMPLX-0K2 g"
        using A4 A7 limfunc4_lm_1 limfunc2_th_2 sorry
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A8 limfunc4_th_1 sorry
      let ?q = "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A11: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A8 limfunc4_th_1 sorry
      have A12: "rngFUNCT-1K2 s c=TARSKIR1 right-open-halflineLIMFUNC1K4 x0"
        using A8 limfunc4_th_1 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-rightLIMFUNC2K2(f1,x0) }"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 ?q"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A13: "?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
          using funct_2_th_113 sorry
        have A14: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have A15: "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A10 funct_2_th_108 A14 sorry
        also have "... = x"
          using A13 nat_1_def_3 sorry
        finally have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) =HIDDENR1 x"
           sorry
        have A16: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) <XXREAL-0R3 x0 +XCMPLX-0K2 g"
          using A9 nat_1_th_12 sorry
        have A17: "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 s"
          using valued_0_th_28 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 right-open-halflineLIMFUNC1K4 x0"
          using A12 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : x0 <XXREAL-0R3 g1 }"
          using xxreal_1_th_230 sorry
        then have " ex g1 be RealXREAL-0M1 st g1 =HIDDENR1 s .FUNCT-1K1 (n +XCMPLX-0K2 k) & x0 <XXREAL-0R3 g1"
           sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : x0 <XXREAL-0R3 g2 & g2 <XXREAL-0R3 x0 +XCMPLX-0K2 g }"
          using A16 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .["
          using rcomp_1_def_2 sorry
        then have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[)"
          using A10 A17 xboole_0_def_4 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) <>HIDDENR2 lim-rightLIMFUNC2K2(f1,x0)"
          using A5 sorry
        then have A18: " not f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 {TARSKIK1 lim-rightLIMFUNC2K2(f1,x0) }"
          using tarski_def_1 sorry
        have "f1 .FUNCT-1K1 (s .FUNCT-1K1 (n +XCMPLX-0K2 k)) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A11 A17 funct_1_th_11 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-rightLIMFUNC2K2(f1,x0) }"
          using A18 A15 xboole_0_def_5 sorry
      qed "sorry"
      then have A19: "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 lim-rightLIMFUNC2K2(f1,x0) }"
         sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A8 limfunc4_th_1 sorry
      then have A20: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A11 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have A21: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
        using A8 limfunc4_th_1 sorry
      then have A22: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A1 A2 A7 limfunc2_def_8 sorry
      have "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 lim-rightLIMFUNC2K2(f1,x0)"
        using A1 A7 A21 limfunc2_def_8 sorry
      then have A23: "limSEQ-2K1 ?q =HIDDENR1 lim-rightLIMFUNC2K2(f1,x0)"
        using A22 seq_4_th_20 sorry
      have "limLIMFUNC3K1(f2,lim-rightLIMFUNC2K2(f1,x0)) =HIDDENR1 limLIMFUNC3K1(f2,lim-rightLIMFUNC2K2(f1,x0))"
         sorry
      then have A24: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be convergentSEQ-2V5"
        using A2 A22 A23 A19 limfunc3_def_4 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A20 seq_4_th_21 sorry
      have "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 limLIMFUNC3K1(f2,lim-rightLIMFUNC2K2(f1,x0))"
        using A2 A22 A23 A19 limfunc3_def_4 sorry
      thus "limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 limLIMFUNC3K1(f2,lim-rightLIMFUNC2K2(f1,x0))"
        using A24 A20 seq_4_th_22 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-right-convergent-inLIMFUNC2R4 x0"
      using A3 limfunc2_def_4 sorry
    thus "lim-rightLIMFUNC2K2(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 limLIMFUNC3K1(f2,lim-rightLIMFUNC2K2(f1,x0))"
      using A6 limfunc2_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc4_th_77:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-convergent-inLIMFUNC3R1 x0 & f2 is-convergent-inLIMFUNC3R1 limLIMFUNC3K1(f1,x0)) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) & ( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 limLIMFUNC3K1(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 limLIMFUNC3K1(f2,limLIMFUNC3K1(f1,x0))"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-convergent-inLIMFUNC3R1 x0 & (f2 is-convergent-inLIMFUNC3R1 limLIMFUNC3K1(f1,x0) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))) implies (( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 limLIMFUNC3K1(f1,x0))) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 limLIMFUNC3K1(f2,limLIMFUNC3K1(f1,x0)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-convergent-inLIMFUNC3R1 x0"
      and A2: "f2 is-convergent-inLIMFUNC3R1 limLIMFUNC3K1(f1,x0)"
      and A3: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
    assume Given: " ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ( for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 limLIMFUNC3K1(f1,x0))"
    then obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 g"and A5: " for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[) implies f1 .FUNCT-1K1 r <>HIDDENR2 limLIMFUNC3K1(f1,x0)"
       sorry
    have A6: " for s be Real-SequenceSEQ-1M1 holds (s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0) & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0} implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 limLIMFUNC3K1(f2,limLIMFUNC3K1(f1,x0))"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A7: "s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 x0"
        and A8: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
      obtain k where
        [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
        A9: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0 +XCMPLX-0K2 g"
        using A4 A7 limfunc3_th_7 sorry
      let ?q = "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A8 limfunc4_th_2 sorry
      have A11: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A8 limfunc4_th_2 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 limLIMFUNC3K1(f1,x0) }"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 ?q"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A12: "?q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
          using funct_2_th_113 sorry
        have A13: "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) =HIDDENR1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)"
          using A11 funct_2_th_108 sorry
        also have "... = x"
          using A12 nat_1_def_3 sorry
        finally have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) =HIDDENR1 x"
           sorry
        have "k <=XXREAL-0R1 n +NAT-1K1 k"
          using nat_1_th_12 sorry
        then have "x0 -XCMPLX-0K6 g <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) <XXREAL-0R3 x0 +XCMPLX-0K2 g"
          using A9 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : x0 -XCMPLX-0K6 g <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0 +XCMPLX-0K2 g }"
           sorry
        then have A14: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 +XCMPLX-0K2 g .["
          using rcomp_1_def_2 sorry
        have A15: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 rngFUNCT-1K2 s"
          using valued_0_th_28 sorry
        then have " not s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 {TARSKIK1 x0}"
          using A8 xboole_0_def_5 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 +XCMPLX-0K2 g .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
          using A14 xboole_0_def_5 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .["
          using A4 limfunc3_th_4 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 g .[)"
          using A11 A15 xboole_0_def_4 sorry
        then have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) <>HIDDENR2 limLIMFUNC3K1(f1,x0)"
          using A5 sorry
        then have A16: " not f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) inTARSKIR2 {TARSKIK1 limLIMFUNC3K1(f1,x0) }"
          using tarski_def_1 sorry
        have "f1 .FUNCT-1K1 (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A10 A15 funct_1_th_11 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 limLIMFUNC3K1(f1,x0) }"
          using A16 A13 xboole_0_def_5 sorry
      qed "sorry"
      then have A17: "rngFUNCT-1K2 ?q c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 limLIMFUNC3K1(f1,x0) }"
         sorry
      have "rngFUNCT-1K2 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A8 limfunc4_th_2 sorry
      then have A18: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using valued_0_th_27 sorry
      also have "... = (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A10 valued_0_th_31 sorry
      finally have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have A19: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
        using A8 limfunc4_th_2 sorry
      then have A20: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A1 A2 A7 limfunc3_def_4 sorry
      have "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 limLIMFUNC3K1(f1,x0)"
        using A1 A7 A19 limfunc3_def_4 sorry
      then have A21: "limSEQ-2K1 ?q =HIDDENR1 limLIMFUNC3K1(f1,x0)"
        using A20 seq_4_th_20 sorry
      have "limLIMFUNC3K1(f2,limLIMFUNC3K1(f1,x0)) =HIDDENR1 limLIMFUNC3K1(f2,limLIMFUNC3K1(f1,x0))"
         sorry
      then have A22: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q be convergentSEQ-2V5"
        using A2 A20 A21 A17 limfunc3_def_4 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A18 seq_4_th_21 sorry
      have "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q =HIDDENR1 limLIMFUNC3K1(f2,limLIMFUNC3K1(f1,x0))"
        using A2 A20 A21 A17 limfunc3_def_4 sorry
      thus "limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 limLIMFUNC3K1(f2,limLIMFUNC3K1(f1,x0))"
        using A22 A18 seq_4_th_22 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-convergent-inLIMFUNC3R1 x0"
      using A3 limfunc3_def_1 sorry
    thus "limLIMFUNC3K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =HIDDENR1 limLIMFUNC3K1(f2,limLIMFUNC3K1(f1,x0))"
      using A6 limfunc3_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
