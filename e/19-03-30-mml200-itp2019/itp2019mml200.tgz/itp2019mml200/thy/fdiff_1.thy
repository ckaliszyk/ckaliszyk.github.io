theory fdiff_1
  imports fcont_1 realset1 finset_1 rvsum_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve X for "setHIDDENM2"
reserve x, x0, x1, x2, g, g1, g2, r, r1, s, p, p1 for "RealXREAL-0M1"
reserve n, m, k for "ElementSUBSET-1M1-of NATNUMBERSK1"
reserve Y for "SubsetSUBSET-1M2-of REALNUMBERSK2"
reserve Z for "openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
reserve s1, s3 for "Real-SequenceSEQ-1M1"
reserve f, f1, f2 for "PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
mtheorem fdiff_1_th_1:
" for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds ( for r be RealXREAL-0M1 holds r inHIDDENR3 Y iff r inHIDDENR3 REALNUMBERSK2) iff Y =XBOOLE-0R4 REALNUMBERSK2"
proof-
  have " for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds (( for r be RealXREAL-0M1 holds r inHIDDENR3 Y iff r inHIDDENR3 REALNUMBERSK2) implies Y =XBOOLE-0R4 REALNUMBERSK2) & (Y =XBOOLE-0R4 REALNUMBERSK2 implies ( for r be RealXREAL-0M1 holds (r inHIDDENR3 Y implies r inHIDDENR3 REALNUMBERSK2) &  not (r inHIDDENR3 REALNUMBERSK2 &  not r inHIDDENR3 Y)))"
  proof(rule ballI,rule conjMI,rule impI,rule ballI,rule conjMI)
    fix Y assume [ty]: "Y be SubsetSUBSET-1M2-of REALNUMBERSK2"
    show "( for r be RealXREAL-0M1 holds r inHIDDENR3 Y iff r inHIDDENR3 REALNUMBERSK2) implies Y =XBOOLE-0R4 REALNUMBERSK2"
    proof(rule impI)
      assume " for r be RealXREAL-0M1 holds r inHIDDENR3 Y iff r inHIDDENR3 REALNUMBERSK2"
      then have " for y be objectHIDDENM1 holds y inHIDDENR3 Y iff y inHIDDENR3 REALNUMBERSK2"
         sorry
      thus "Y =XBOOLE-0R4 REALNUMBERSK2"
        using tarski_th_2 sorry
    qed
    assume A1: "Y =XBOOLE-0R4 REALNUMBERSK2"
    fix r assume [ty]: "r be RealXREAL-0M1"
    show "r inHIDDENR3 Y implies r inHIDDENR3 REALNUMBERSK2"
       sorry
    show " not (r inHIDDENR3 REALNUMBERSK2 &  not r inHIDDENR3 Y)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef fdiff_1_def_1 (" _ -convergentFDIFF-1V1" [70]70 ) where
  mlet "x be RealXREAL-0M1"
"attr x -convergentFDIFF-1V1 for Real-SequenceSEQ-1M1 means
  (\<lambda>IT. IT be convergentSEQ-2V5 & limSEQ-2K1 IT =COMPLEX1R1 x)"..

mtheorem fdiff_1_cl_1:
"cluster 0NUMBERSK6 -convergentFDIFF-1V1\<bar>non-zeroORDINAL1V9 for Real-SequenceSEQ-1M1"
proof
(*existence*)
  show " ex it be Real-SequenceSEQ-1M1 st it be 0NUMBERSK6 -convergentFDIFF-1V1\<bar>non-zeroORDINAL1V9"
  proof-
    have " ex tVar1 be Real-SequenceSEQ-1M1 st tVar1 be 0NUMBERSK6 -convergentFDIFF-1V1 & tVar1 be non-zeroORDINAL1V9"
    proof-
      let ?F = "\<lambda>Lamb1. \<one>\<^sub>M /XCMPLX-0K7 (Lamb1 +NAT-1K1 \<one>\<^sub>M)"
      obtain s1 where
        [ty]:"s1 be Real-SequenceSEQ-1M1" and 
        A1: " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n =COMPLEX1R1 ?F(n)"
        using seq_1_sch_1 sorry
      show " ex tVar1 be Real-SequenceSEQ-1M1 st tVar1 be 0NUMBERSK6 -convergentFDIFF-1V1 & tVar1 be non-zeroORDINAL1V9"
      proof(rule bexI[of _ "s1"])
        have " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n <>HIDDENR2 0NUMBERSK6"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have "(n +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5 <>HIDDENR2 0NUMBERSK6"
             sorry
          then have "\<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 0NUMBERSK6"
            using xcmplx_1_th_215 sorry
          thus "s1 .FUNCT-1K1 n <>HIDDENR2 0NUMBERSK6"
            using A1 sorry
        qed "sorry"
        then have A2: "s1 be non-zeroORDINAL1V9"
          using seq_1_th_5 sorry
        have "limSEQ-2K1 s1 =COMPLEX1R1 0NUMBERSK6 & s1 be convergentSEQ-2V5"
          using A1 seq_4_th_31 sorry
        then have "s1 be 0NUMBERSK6 -convergentFDIFF-1V1"
           sorry
        thus "s1 be 0NUMBERSK6 -convergentFDIFF-1V1 & s1 be non-zeroORDINAL1V9"
          using A2 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem fdiff_1_cl_2:
  mlet "f be 0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
"cluster limSEQ-2K1 f as-term-is zeroORDINAL1V8"
proof
(*coherence*)
  show "limSEQ-2K1 f be zeroORDINAL1V8"
    using fdiff_1_def_1 sorry
qed "sorry"

mtheorem fdiff_1_cl_3:
"cluster 0NUMBERSK6 -convergentFDIFF-1V1 also-is convergentSEQ-2V5 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it be 0NUMBERSK6 -convergentFDIFF-1V1 implies it be convergentSEQ-2V5"
     sorry
qed "sorry"

reserve h for "non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
reserve c for "constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1"
mdef fdiff_1_def_2 ("RestFunc-likeFDIFF-1V2" 70 ) where
"attr RestFunc-likeFDIFF-1V2 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  (\<lambda>IT. IT be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub> & ( for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> IT /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> IT /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 0NUMBERSK6))"..

mtheorem fdiff_1_cl_4:
"cluster RestFunc-likeFDIFF-1V2 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*existence*)
  show " ex it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st it be RestFunc-likeFDIFF-1V2"
  proof-
    have " ex f be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st f be RestFunc-likeFDIFF-1V2"
    proof-
      obtain cf where 
        [ty]:"cf be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)" and cfDef:"cf = REALNUMBERSK2 -->FUNCOP-1K8\<^bsub>(REALNUMBERSK2)\<^esub> InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)"
         sorry
      obtain f where 
        [ty]:"f be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)" and fDef:"f = cf"
         sorry
      show " ex f be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st f be RestFunc-likeFDIFF-1V2"
      proof(rule bexI[of _ "f"])
        have "f be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub> & ( for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 0NUMBERSK6)"
        proof(rule conjMI)
          show "f be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
             sorry
          have A1: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f =XBOOLE-0R4 REALNUMBERSK2"
            using funcop_1_th_13 sorry
          have " for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 0NUMBERSK6"
          proof(rule ballI)
            fix h assume [ty]: "h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
            have " for n be NatNAT-1M1 holds (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 n =HIDDENR1 InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)"
            proof(rule ballI)
              fix n assume [ty]: "n be NatNAT-1M1"
              have A2: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> h c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
                using A1 sorry
              have A3: "h .FUNCT-1K1 n inTARSKIR2 REALNUMBERSK2"
                using xreal_0_def_1 sorry
              have A4: "n inTARSKIR2 NATNUMBERSK1"
                using ordinal1_def_12 sorry
              have "(h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 n =HIDDENR1 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n *XCMPLX-0K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h .FUNCT-1K1 n"
                using seq_1_th_8 sorry
              also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n *XCMPLX-0K3 f .FUNCT-1K1 (h .FUNCT-1K1 n)"
                using A4 A2 funct_2_th_108 sorry
              also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n *XCMPLX-0K3 (0NUMBERSK6)"
                using funcop_1_th_7 A3 sorry
              also have "... = InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)"
                 sorry
              finally show "(h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 n =HIDDENR1 InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)"
                 sorry
            qed "sorry"
            then have "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be constantFUNCT-1V5 & (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6"
              using valued_0_def_18 sorry
            thus "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 0NUMBERSK6"
              using seq_4_th_25 sorry
          qed "sorry"
          thus " for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 0NUMBERSK6"
             sorry
        qed
        thus "f be RestFunc-likeFDIFF-1V2"
          using fdiff_1_def_2 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax FDIFF_1M1 :: "Ty" ("RestFuncFDIFF-1M1" 70)
translations "RestFuncFDIFF-1M1" \<rightharpoonup> "RestFunc-likeFDIFF-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"

mdef fdiff_1_def_3 ("linearFDIFF-1V3" 70 ) where
"attr linearFDIFF-1V3 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  (\<lambda>IT. IT be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub> & ( ex r be RealXREAL-0M1 st  for p be RealXREAL-0M1 holds IT .FUNCT-1K1 p =COMPLEX1R1 r *XCMPLX-0K3 p))"..

mtheorem fdiff_1_cl_5:
"cluster linearFDIFF-1V3 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*existence*)
  show " ex it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st it be linearFDIFF-1V3"
  proof-
    have " ex tVar3 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st tVar3 be linearFDIFF-1V3"
    proof-
      let ?F = "\<lambda>Lamb1. InSUBSET-1K10(\<one>\<^sub>M *XCMPLX-0K3 Lamb1,REALNUMBERSK2)"
      let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 REALNUMBERSK2"
      obtain f where
        [ty]:"f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
        A1: "( for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f iff ?P(r)) & ( for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 r =COMPLEX1R1 ?F(r))"
        using seq_1_sch_3 sorry
      show " ex tVar3 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st tVar3 be linearFDIFF-1V3"
      proof(rule bexI[of _ "f"])
        have " for y be objectHIDDENM1 holds y inHIDDENR3 REALNUMBERSK2 implies y inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A1 sorry
        then have "REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
           sorry
        then have Cut169: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f =XBOOLE-0R4 REALNUMBERSK2"
           sorry
        have "f be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub> &  not ( for r be RealXREAL-0M1 holds  not ( for p be RealXREAL-0M1 holds f .FUNCT-1K1 p =COMPLEX1R1 r *XCMPLX-0K3 p))"
        proof(rule conjMI)
          show "f be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
            using partfun1_def_2 Cut169 sorry
          have " for p be RealXREAL-0M1 holds f .FUNCT-1K1 p =COMPLEX1R1 \<one>\<^sub>M *XCMPLX-0K3 p"
          proof(rule ballI)
            fix p assume [ty]: "p be RealXREAL-0M1"
            have "InSUBSET-1K10(\<one>\<^sub>M *XCMPLX-0K3 p,REALNUMBERSK2) =COMPLEX1R1 \<one>\<^sub>M *XCMPLX-0K3 p"
               sorry
            thus "f .FUNCT-1K1 p =COMPLEX1R1 \<one>\<^sub>M *XCMPLX-0K3 p"
              using A1 sorry
          qed "sorry"
          thus " not ( for r be RealXREAL-0M1 holds  not ( for p be RealXREAL-0M1 holds f .FUNCT-1K1 p =COMPLEX1R1 r *XCMPLX-0K3 p))"
             sorry
        qed
        thus "f be linearFDIFF-1V3"
          using fdiff_1_def_3 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax FDIFF_1M2 :: "Ty" ("LinearFuncFDIFF-1M2" 70)
translations "LinearFuncFDIFF-1M2" \<rightharpoonup> "linearFDIFF-1V3\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"

reserve R, R1, R2 for "RestFuncFDIFF-1M1"
reserve L, L1, L2 for "LinearFuncFDIFF-1M2"
mtheorem fdiff_1_th_2:
" for L1 be LinearFuncFDIFF-1M2 holds  for L2 be LinearFuncFDIFF-1M2 holds L1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2 be LinearFuncFDIFF-1M2 & L1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2 be LinearFuncFDIFF-1M2"
proof-
  have " for L1 be LinearFuncFDIFF-1M2 holds  for L2 be LinearFuncFDIFF-1M2 holds L1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2 be LinearFuncFDIFF-1M2 & L1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2 be LinearFuncFDIFF-1M2"
  proof(rule ballI,rule ballI,rule conjMI)
    fix L1 assume [ty]: "L1 be LinearFuncFDIFF-1M2"
    fix L2 assume [ty]: "L2 be LinearFuncFDIFF-1M2"
    obtain g1 where
      [ty]:"g1 be RealXREAL-0M1" and 
      A1: " for p be RealXREAL-0M1 holds L1 .FUNCT-1K1 p =COMPLEX1R1 g1 *XCMPLX-0K3 p"
      using fdiff_1_def_3 sorry
    obtain g2 where
      [ty]:"g2 be RealXREAL-0M1" and 
      A2: " for p be RealXREAL-0M1 holds L2 .FUNCT-1K1 p =COMPLEX1R1 g2 *XCMPLX-0K3 p"
      using fdiff_1_def_3 sorry
    have A3: "L1 be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub> & L2 be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
      using fdiff_1_def_3 sorry
    have " for p be RealXREAL-0M1 holds (L1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2).FUNCT-1K1 p =HIDDENR1 (g1 +XCMPLX-0K2 g2)*XCMPLX-0K3 p"
    proof(rule ballI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      obtain pp where 
        [ty]:"pp be ElementSUBSET-1M1-of REALNUMBERSK2" and ppDef:"pp = p"
        using xreal_0_def_1 sorry
      have "(L1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2).FUNCT-1K1 p =HIDDENR1 L1 .FUNCT-1K1 pp +XCMPLX-0K2 L2 .FUNCT-1K1 pp"
        using A3 rfunct_1_th_56 sorry
      also have "... = g1 *XCMPLX-0K3 p +XCMPLX-0K2 L2 .FUNCT-1K1 p"
        using A1 sorry
      also have "... = g1 *XCMPLX-0K3 p +XCMPLX-0K2 g2 *XCMPLX-0K3 p"
        using A2 sorry
      also have "... = (g1 +XCMPLX-0K2 g2)*XCMPLX-0K3 p"
         sorry
      finally show "(L1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2).FUNCT-1K1 p =HIDDENR1 (g1 +XCMPLX-0K2 g2)*XCMPLX-0K3 p"
         sorry
    qed "sorry"
    thus "L1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2 be LinearFuncFDIFF-1M2"
      using A3 fdiff_1_def_3 sorry
    have " for p be RealXREAL-0M1 holds (L1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2).FUNCT-1K1 p =HIDDENR1 (g1 -XCMPLX-0K6 g2)*XCMPLX-0K3 p"
    proof(rule ballI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      obtain pp where 
        [ty]:"pp be ElementSUBSET-1M1-of REALNUMBERSK2" and ppDef:"pp = p"
        using xreal_0_def_1 sorry
      have "(L1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2).FUNCT-1K1 p =HIDDENR1 L1 .FUNCT-1K1 pp -XCMPLX-0K6 L2 .FUNCT-1K1 pp"
        using A3 rfunct_1_th_56 sorry
      also have "... = g1 *XCMPLX-0K3 p -XCMPLX-0K6 L2 .FUNCT-1K1 p"
        using A1 sorry
      also have "... = g1 *XCMPLX-0K3 p -XCMPLX-0K6 g2 *XCMPLX-0K3 p"
        using A2 sorry
      also have "... = (g1 -XCMPLX-0K6 g2)*XCMPLX-0K3 p"
         sorry
      finally show "(L1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2).FUNCT-1K1 p =HIDDENR1 (g1 -XCMPLX-0K6 g2)*XCMPLX-0K3 p"
         sorry
    qed "sorry"
    thus "L1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2 be LinearFuncFDIFF-1M2"
      using A3 fdiff_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_1_th_3:
" for r be RealXREAL-0M1 holds  for L be LinearFuncFDIFF-1M2 holds r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> L be LinearFuncFDIFF-1M2"
proof-
  have " for r be RealXREAL-0M1 holds  for L be LinearFuncFDIFF-1M2 holds r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> L be LinearFuncFDIFF-1M2"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix L assume [ty]: "L be LinearFuncFDIFF-1M2"
    obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A1: " for p be RealXREAL-0M1 holds L .FUNCT-1K1 p =COMPLEX1R1 g *XCMPLX-0K3 p"
      using fdiff_1_def_3 sorry
    have A2: "L be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
      using fdiff_1_def_3 sorry
    have " for p be RealXREAL-0M1 holds (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> L).FUNCT-1K1 p =HIDDENR1 (r *XCMPLX-0K3 g)*XCMPLX-0K3 p"
    proof(rule ballI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      obtain pp where 
        [ty]:"pp be ElementSUBSET-1M1-of REALNUMBERSK2" and ppDef:"pp = p"
        using xreal_0_def_1 sorry
      have "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> L).FUNCT-1K1 p =HIDDENR1 r *XCMPLX-0K3 L .FUNCT-1K1 pp"
        using A2 rfunct_1_th_57 sorry
      also have "... = r *XCMPLX-0K3 (g *XCMPLX-0K3 p)"
        using A1 sorry
      also have "... = (r *XCMPLX-0K3 g)*XCMPLX-0K3 p"
         sorry
      finally show "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> L).FUNCT-1K1 p =HIDDENR1 (r *XCMPLX-0K3 g)*XCMPLX-0K3 p"
         sorry
    qed "sorry"
    thus "r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> L be LinearFuncFDIFF-1M2"
      using A2 fdiff_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_1_th_4:
" for R1 be RestFuncFDIFF-1M1 holds  for R2 be RestFuncFDIFF-1M1 holds (R1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2 be RestFuncFDIFF-1M1 & R1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2 be RestFuncFDIFF-1M1) & R1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2 be RestFuncFDIFF-1M1"
proof-
  have " for R1 be RestFuncFDIFF-1M1 holds  for R2 be RestFuncFDIFF-1M1 holds R1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2 be RestFuncFDIFF-1M1 & (R1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2 be RestFuncFDIFF-1M1 & R1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2 be RestFuncFDIFF-1M1)"
  proof(rule ballI,rule ballI,rule conjMI,rule conjMI)
    fix R1 assume [ty]: "R1 be RestFuncFDIFF-1M1"
    fix R2 assume [ty]: "R2 be RestFuncFDIFF-1M1"
    have A1: "R1 be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub> & R2 be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
      using fdiff_1_def_2 sorry
    have " for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (R1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (R1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =HIDDENR1 0NUMBERSK6"
    proof(rule ballI,rule conjMI)
      fix h assume [ty]: "h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
      have A2: "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (R1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h =HIDDENR1 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
        using A1 rfunct_2_th_13 sorry
      also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h"
        using seq_1_th_16 sorry
      finally have "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (R1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h =HIDDENR1 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h"
         sorry
      have A3: "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5 & h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5"
        using fdiff_1_def_2 sorry
      thus "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (R1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5"
        using A2 sorry
      have "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 0NUMBERSK6 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 0NUMBERSK6"
        using fdiff_1_def_2 sorry
      then have "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (R1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =HIDDENR1 0NUMBERSK6 +NAT-1K1 0NUMBERSK6"
        using A3 A2 seq_2_th_6 sorry
      also have "... = 0NUMBERSK6"
         sorry
      finally show "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (R1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =HIDDENR1 0NUMBERSK6"
         sorry
    qed "sorry"
    thus "R1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2 be RestFuncFDIFF-1M1"
      using A1 fdiff_1_def_2 sorry
    have " for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (R1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (R1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =HIDDENR1 0NUMBERSK6"
    proof(rule ballI,rule conjMI)
      fix h assume [ty]: "h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
      have A4: "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (R1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h =HIDDENR1 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
        using A1 rfunct_2_th_13 sorry
      also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h"
        using seq_1_th_21 sorry
      finally have "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (R1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h =HIDDENR1 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h"
         sorry
      have A5: "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5 & h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5"
        using fdiff_1_def_2 sorry
      thus "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (R1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5"
        using A4 sorry
      have "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 0NUMBERSK6 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 0NUMBERSK6"
        using fdiff_1_def_2 sorry
      then have "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (R1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =HIDDENR1 0NUMBERSK6 -XCMPLX-0K6 0NUMBERSK6"
        using A5 A4 seq_2_th_12 sorry
      also have "... = 0NUMBERSK6"
         sorry
      finally show "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (R1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =HIDDENR1 0NUMBERSK6"
         sorry
    qed "sorry"
    thus "R1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2 be RestFuncFDIFF-1M1"
      using A1 fdiff_1_def_2 sorry
    have " for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (R1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (R1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =HIDDENR1 0NUMBERSK6"
    proof(rule ballI,rule conjMI)
      fix h assume [ty]: "h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
      have A6: "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5"
        using fdiff_1_def_2 sorry
      have A7: "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be non-zeroORDINAL1V9"
        using seq_1_th_33 sorry
      have A8: "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5 & h be convergentSEQ-2V5"
        using fdiff_1_def_2 sorry
      then have A9: "h (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) be convergentSEQ-2V5"
         sorry
      have "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 0NUMBERSK6 & limSEQ-2K1 h =COMPLEX1R1 0NUMBERSK6"
        using fdiff_1_def_2 sorry
      then have A10: "limSEQ-2K1 (h (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)) =HIDDENR1 (0NUMBERSK6)*NAT-1K2 (0NUMBERSK6)"
        using A8 seq_2_th_15 sorry
      also have "... = 0NUMBERSK6"
         sorry
      finally have "limSEQ-2K1 (h (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)) =HIDDENR1 0NUMBERSK6"
         sorry
      have A11: "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (R1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h =HIDDENR1 (R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h"
        using A1 rfunct_2_th_13 sorry
      also have "... = ((R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)"
        using A7 seq_1_th_43 sorry
      also have "... = ((R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)"
        using seq_1_th_36 sorry
      also have "... = (h (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h))"
        using seq_1_th_14 sorry
      also have "... = ((h (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
        using seq_1_th_14 sorry
      also have "... = (h (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h))(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
        using seq_1_th_14 sorry
      finally have "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (R1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h =HIDDENR1 (h (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h))(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
         sorry
      thus "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (R1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5"
        using A6 A9 sorry
      have "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 0NUMBERSK6"
        using fdiff_1_def_2 sorry
      then have "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (R1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =HIDDENR1 (0NUMBERSK6)*NAT-1K2 (0NUMBERSK6)"
        using A6 A9 A10 A11 seq_2_th_15 sorry
      also have "... = 0NUMBERSK6"
         sorry
      finally show "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (R1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =HIDDENR1 0NUMBERSK6"
         sorry
    qed "sorry"
    thus "R1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2 be RestFuncFDIFF-1M1"
      using A1 fdiff_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_1_th_5:
" for r be RealXREAL-0M1 holds  for R be RestFuncFDIFF-1M1 holds r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> R be RestFuncFDIFF-1M1"
proof-
  have " for r be RealXREAL-0M1 holds  for R be RestFuncFDIFF-1M1 holds r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> R be RestFuncFDIFF-1M1"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix R assume [ty]: "R be RestFuncFDIFF-1M1"
    have A1: "R be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
      using fdiff_1_def_2 sorry
    have " for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> R)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> R)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =HIDDENR1 0NUMBERSK6"
    proof(rule ballI,rule conjMI)
      fix h assume [ty]: "h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
      have A2: "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> R)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h =HIDDENR1 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
        using A1 rfunct_2_th_14 sorry
      also have "... = r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
        using seq_1_th_19 sorry
      finally have "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> R)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h =HIDDENR1 r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
         sorry
      have A3: "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5"
        using fdiff_1_def_2 sorry
      thus "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> R)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5"
        using A2 sorry
      have "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 0NUMBERSK6"
        using fdiff_1_def_2 sorry
      then have "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> R)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =HIDDENR1 r *XCMPLX-0K3 (0NUMBERSK6)"
        using A3 A2 seq_2_th_8 sorry
      also have "... = 0NUMBERSK6"
         sorry
      finally show "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> R)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =HIDDENR1 0NUMBERSK6"
         sorry
    qed "sorry"
    thus "r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> R be RestFuncFDIFF-1M1"
      using A1 fdiff_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_1_th_6:
" for L1 be LinearFuncFDIFF-1M2 holds  for L2 be LinearFuncFDIFF-1M2 holds L1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2 be RestFunc-likeFDIFF-1V2"
proof-
  have " for L1 be LinearFuncFDIFF-1M2 holds  for L2 be LinearFuncFDIFF-1M2 holds L1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2 be RestFunc-likeFDIFF-1V2"
  proof(rule ballI,rule ballI)
    fix L1 assume [ty]: "L1 be LinearFuncFDIFF-1M2"
    fix L2 assume [ty]: "L2 be LinearFuncFDIFF-1M2"
    obtain x1 where
      [ty]:"x1 be RealXREAL-0M1" and 
      A1: " for p be RealXREAL-0M1 holds L1 .FUNCT-1K1 p =COMPLEX1R1 x1 *XCMPLX-0K3 p"
      using fdiff_1_def_3 sorry
    have A2: "L1 be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub> & L2 be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
      using fdiff_1_def_3 sorry
    have "L1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2 be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub> & ( for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (L1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (L1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 0NUMBERSK6)"
    proof(rule conjMI)
      show "L1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2 be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
        using A2 sorry
      obtain x2 where
        [ty]:"x2 be RealXREAL-0M1" and 
        A3: " for p be RealXREAL-0M1 holds L2 .FUNCT-1K1 p =COMPLEX1R1 x2 *XCMPLX-0K3 p"
        using fdiff_1_def_3 sorry
      have " for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (L1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (L1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =HIDDENR1 0NUMBERSK6"
      proof(rule ballI,rule conjMI)
        fix h assume [ty]: "h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
        have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (L1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ((x1 *XCMPLX-0K3 x2)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        proof(rule ballI)
          fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
          have A4: "h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6"
            using seq_1_th_5 sorry
          have "(h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (L1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (L1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
            using seq_1_th_8 sorry
          also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (L1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2).FUNCT-1K1 (h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
            using A2 funct_2_th_115 sorry
          also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (L1 .FUNCT-1K1 (h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) *XCMPLX-0K3 L2 .FUNCT-1K1 (h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n))"
            using A2 rfunct_1_th_56 sorry
          also have "... = (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 L1 .FUNCT-1K1 (h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n))*XCMPLX-0K3 L2 .FUNCT-1K1 (h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
             sorry
          also have "... = ((h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2 *XCMPLX-0K3 L1 .FUNCT-1K1 (h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n))*XCMPLX-0K3 L2 .FUNCT-1K1 (h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
            using valued_1_th_10 sorry
          also have "... = ((h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2 *XCMPLX-0K3 (h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 x1))*XCMPLX-0K3 L2 .FUNCT-1K1 (h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
            using A1 sorry
          also have "... = (((h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2 *REAL-1K4 h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)*XCMPLX-0K3 x1)*XCMPLX-0K3 L2 .FUNCT-1K1 (h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
             sorry
          also have "... = (\<one>\<^sub>M *XCMPLX-0K3 x1)*XCMPLX-0K3 L2 .FUNCT-1K1 (h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
            using A4 xcmplx_0_def_7 sorry
          also have "... = x1 *XCMPLX-0K3 (x2 *XCMPLX-0K3 h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
            using A3 sorry
          also have "... = (x1 *XCMPLX-0K3 x2)*XCMPLX-0K3 h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
             sorry
          also have "... = ((x1 *XCMPLX-0K3 x2)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
            using seq_1_th_9 sorry
          finally show "(h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (L1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ((x1 *XCMPLX-0K3 x2)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
             sorry
        qed "sorry"
        then have A5: "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (L1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (x1 *XCMPLX-0K3 x2)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h"
          using funct_2_th_63 sorry
        show "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (L1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5"
          using A5 sorry
        have "limSEQ-2K1 h =COMPLEX1R1 0NUMBERSK6"
           sorry
        then have "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (L1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =HIDDENR1 (x1 *XCMPLX-0K3 x2)*XCMPLX-0K3 (0NUMBERSK6)"
          using A5 seq_2_th_8 sorry
        also have "... = 0NUMBERSK6"
           sorry
        finally show "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (L1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =HIDDENR1 0NUMBERSK6"
           sorry
      qed "sorry"
      thus " for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (L1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (L1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 0NUMBERSK6"
         sorry
    qed
    thus "L1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2 be RestFunc-likeFDIFF-1V2"
      using fdiff_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_1_th_7:
" for R be RestFuncFDIFF-1M1 holds  for L be LinearFuncFDIFF-1M2 holds R (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L be RestFuncFDIFF-1M1 & L (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R be RestFuncFDIFF-1M1"
proof-
  have " for R be RestFuncFDIFF-1M1 holds  for L be LinearFuncFDIFF-1M2 holds R (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L be RestFuncFDIFF-1M1 & L (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R be RestFuncFDIFF-1M1"
  proof(rule ballI,rule ballI,rule conjMI)
    fix R assume [ty]: "R be RestFuncFDIFF-1M1"
    fix L assume [ty]: "L be LinearFuncFDIFF-1M2"
    have A1: "L be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
      using fdiff_1_def_3 sorry
    obtain x1 where
      [ty]:"x1 be RealXREAL-0M1" and 
      A2: " for p be RealXREAL-0M1 holds L .FUNCT-1K1 p =COMPLEX1R1 x1 *XCMPLX-0K3 p"
      using fdiff_1_def_3 sorry
    have A3: "R be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
      using fdiff_1_def_2 sorry
    have A4: " for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (R (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (R (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =HIDDENR1 0NUMBERSK6"
    proof(rule ballI,rule conjMI)
      fix h assume [ty]: "h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
      have A5: "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5"
        using fdiff_1_def_2 sorry
      have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (x1 (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have "L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 L .FUNCT-1K1 (h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
          using A1 funct_2_th_115 sorry
        also have "... = x1 *XCMPLX-0K3 h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
          using A2 sorry
        also have "... = (x1 (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
          using seq_1_th_9 sorry
        finally show "L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (x1 (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
           sorry
      qed "sorry"
      then have A6: "L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> x1 (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h"
        using funct_2_th_63 sorry
      have A7: "L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5"
        using A6 sorry
      have "limSEQ-2K1 h =COMPLEX1R1 0NUMBERSK6"
         sorry
      then have A8: "limSEQ-2K1 L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h =HIDDENR1 x1 *XCMPLX-0K3 (0NUMBERSK6)"
        using A6 seq_2_th_8 sorry
      also have "... = 0NUMBERSK6"
         sorry
      finally have "limSEQ-2K1 L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h =HIDDENR1 0NUMBERSK6"
         sorry
      have A9: "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (R (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h =HIDDENR1 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
        using A3 A1 rfunct_2_th_13 sorry
      also have "... = (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h"
        using seq_1_th_14 sorry
      finally have "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (R (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h =HIDDENR1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h"
         sorry
      thus "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (R (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5"
        using A7 A5 sorry
      have "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 0NUMBERSK6"
        using fdiff_1_def_2 sorry
      then have "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (R (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =HIDDENR1 (0NUMBERSK6)*NAT-1K2 (0NUMBERSK6)"
        using A9 A7 A8 A5 seq_2_th_15 sorry
      also have "... = 0NUMBERSK6"
         sorry
      finally show "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (R (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =HIDDENR1 0NUMBERSK6"
         sorry
    qed "sorry"
    thus "R (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L be RestFuncFDIFF-1M1"
      using A3 A1 fdiff_1_def_2 sorry
    show "L (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R be RestFuncFDIFF-1M1"
      using A3 A1 A4 fdiff_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef fdiff_1_def_4 (" _ is-differentiable-inFDIFF-1R1  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "x0 be RealXREAL-0M1"
"pred f is-differentiable-inFDIFF-1R1 x0 means
   ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st  for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0))"..

mdef fdiff_1_def_5 ("diffFDIFF-1K1'( _ , _ ')" [0,0]164 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "x0 be RealXREAL-0M1"
"assume f is-differentiable-inFDIFF-1R1 x0 func diffFDIFF-1K1(f,x0) \<rightarrow> RealXREAL-0M1 means
  \<lambda>it.  ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st it =COMPLEX1R1 L .FUNCT-1K1 \<one>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)))"
proof-
  (*existence*)
    show "f is-differentiable-inFDIFF-1R1 x0 implies ( ex it be RealXREAL-0M1 st  ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st it =COMPLEX1R1 L .FUNCT-1K1 \<one>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0))))"
    proof(rule impI)
      assume Assume: "f is-differentiable-inFDIFF-1R1 x0"
      have A1: "f is-differentiable-inFDIFF-1R1 x0"
        using Assume sorry
      show " ex it be RealXREAL-0M1 st  ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st it =COMPLEX1R1 L .FUNCT-1K1 \<one>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)))"
      proof-
        have " ex tVar4 be RealXREAL-0M1 st  not ( for N be NeighbourhoodRCOMP-1M1-of x0 holds  not (N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f &  not ( for L be LinearFuncFDIFF-1M2 holds  for R be RestFuncFDIFF-1M1 holds  not (tVar4 =COMPLEX1R1 L .FUNCT-1K1 \<one>\<^sub>M & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 N &  not f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)))))))"
        proof-
          obtain N where
            [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
            A2: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and A3: " ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st  for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
            using A1 sorry
          obtain L R where
            [ty]:"L be LinearFuncFDIFF-1M2" "R be RestFuncFDIFF-1M1" and 
            A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
            using A3 sorry
          obtain r where
            [ty]:"r be RealXREAL-0M1" and 
            A5: " for p be RealXREAL-0M1 holds L .FUNCT-1K1 p =COMPLEX1R1 r *XCMPLX-0K3 p"
            using fdiff_1_def_3 sorry
          show " ex tVar4 be RealXREAL-0M1 st  not ( for N be NeighbourhoodRCOMP-1M1-of x0 holds  not (N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f &  not ( for L be LinearFuncFDIFF-1M2 holds  for R be RestFuncFDIFF-1M1 holds  not (tVar4 =COMPLEX1R1 L .FUNCT-1K1 \<one>\<^sub>M & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 N &  not f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)))))))"
          proof(rule bexI[of _ "r"])
            have "L .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 r *XCMPLX-0K3 \<one>\<^sub>M"
              using A5 sorry
            also have "... = r"
               sorry
            finally have "L .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 r"
               sorry
            thus " not ( for N be NeighbourhoodRCOMP-1M1-of x0 holds  not (N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f &  not ( for L be LinearFuncFDIFF-1M2 holds  for R be RestFuncFDIFF-1M1 holds  not (r =COMPLEX1R1 L .FUNCT-1K1 \<one>\<^sub>M & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 N &  not f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)))))))"
              using A2 A4 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show "f is-differentiable-inFDIFF-1R1 x0 implies ( for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds ( ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st it1 =COMPLEX1R1 L .FUNCT-1K1 \<one>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)))) & ( ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st it2 =COMPLEX1R1 L .FUNCT-1K1 \<one>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)))) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "f is-differentiable-inFDIFF-1R1 x0"
      have A1: "f is-differentiable-inFDIFF-1R1 x0"
        using Assume sorry
      show " for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds ( ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st it1 =COMPLEX1R1 L .FUNCT-1K1 \<one>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)))) & ( ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st it2 =COMPLEX1R1 L .FUNCT-1K1 \<one>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)))) implies it1 =HIDDENR1 it2"
      proof-
        have " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds ( ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st r =COMPLEX1R1 L .FUNCT-1K1 \<one>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)))) & ( ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st s =COMPLEX1R1 L .FUNCT-1K1 \<one>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)))) implies r =HIDDENR1 s"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix r assume [ty]: "r be RealXREAL-0M1"
          fix s assume [ty]: "s be RealXREAL-0M1"
          assume A6: " ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st r =COMPLEX1R1 L .FUNCT-1K1 \<one>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)))"
            and A7: " ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st s =COMPLEX1R1 L .FUNCT-1K1 \<one>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)))"
          obtain N where
            [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
            "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and A8: " ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st r =COMPLEX1R1 L .FUNCT-1K1 \<one>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0))"
            using A6 sorry
          obtain L R where
            [ty]:"L be LinearFuncFDIFF-1M2" "R be RestFuncFDIFF-1M1" and 
            A9: "r =COMPLEX1R1 L .FUNCT-1K1 \<one>\<^sub>M"and A10: " for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
            using A8 sorry
          obtain r1 where
            [ty]:"r1 be RealXREAL-0M1" and 
            A11: " for p be RealXREAL-0M1 holds L .FUNCT-1K1 p =COMPLEX1R1 r1 *XCMPLX-0K3 p"
            using fdiff_1_def_3 sorry
          obtain N1 where
            [ty]:"N1 be NeighbourhoodRCOMP-1M1-of x0" and 
            "N1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and A12: " ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st s =COMPLEX1R1 L .FUNCT-1K1 \<one>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 N1 implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0))"
            using A7 sorry
          obtain L1 R1 where
            [ty]:"L1 be LinearFuncFDIFF-1M2" "R1 be RestFuncFDIFF-1M1" and 
            A13: "s =COMPLEX1R1 L1 .FUNCT-1K1 \<one>\<^sub>M"and A14: " for x be RealXREAL-0M1 holds x inHIDDENR3 N1 implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L1 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
            using A12 sorry
          obtain p1 where
            [ty]:"p1 be RealXREAL-0M1" and 
            A15: " for p be RealXREAL-0M1 holds L1 .FUNCT-1K1 p =COMPLEX1R1 p1 *XCMPLX-0K3 p"
            using fdiff_1_def_3 sorry
          obtain N0 where
            [ty]:"N0 be NeighbourhoodRCOMP-1M1-of x0" and 
            A16: "N0 c=TARSKIR1 N & N0 c=TARSKIR1 N1"
            using rcomp_1_th_17 sorry
          obtain g where
            [ty]:"g be RealXREAL-0M1" and 
            A17: "0NUMBERSK6 <XXREAL-0R3 g"and A18: "N0 =XBOOLE-0R4 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 +XCMPLX-0K2 g .["
            using rcomp_1_def_6 sorry
          let ?F = "\<lambda>Lamb1. g /XCMPLX-0K7 (Lamb1 +NAT-1K1 \<two>\<^sub>M)"
          obtain s1 where
            [ty]:"s1 be Real-SequenceSEQ-1M1" and 
            A19: " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n =COMPLEX1R1 ?F(n)"
            using seq_1_sch_1 sorry
          have " for n be NatNAT-1M1 holds 0NUMBERSK6 <>HIDDENR2 s1 .FUNCT-1K1 n"
          proof(rule ballI)
            fix n assume [ty]: "n be NatNAT-1M1"
            have "0NUMBERSK6 <>HIDDENR2 g /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M)"
              using A17 xreal_1_th_139 sorry
            thus "0NUMBERSK6 <>HIDDENR2 s1 .FUNCT-1K1 n"
              using A19 sorry
          qed "sorry"
          then have A20: "s1 be non-zeroORDINAL1V9"
            using seq_1_th_5 sorry
          have "s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 =COMPLEX1R1 0NUMBERSK6"
            using A19 seq_4_th_31 sorry
          then have "s1 be 0NUMBERSK6 -convergentFDIFF-1V1"
             sorry
          then obtain h where 
            [ty]:"h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1" and hDef:"h = s1"
            using A20 sorry
          have A21: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex x be RealXREAL-0M1 st (x inHIDDENR3 N & x inHIDDENR3 N1) & h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 x -XCMPLX-0K6 x0"
          proof-
            have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex tVar5 be RealXREAL-0M1 st (tVar5 inHIDDENR3 N & tVar5 inHIDDENR3 N1) & h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 tVar5 -XCMPLX-0K6 x0"
            proof(rule ballI)
              fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
              show " ex tVar5 be RealXREAL-0M1 st (tVar5 inHIDDENR3 N & tVar5 inHIDDENR3 N1) & h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 tVar5 -XCMPLX-0K6 x0"
              proof(rule bexI[of _ "x0 +XCMPLX-0K2 g /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M)"])
                have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
                  using xreal_1_th_6 sorry
                then have "g /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M) <XXREAL-0R3 g /XCMPLX-0K7 \<one>\<^sub>M"
                  using A17 xreal_1_th_76 sorry
                then have A22: "x0 +XCMPLX-0K2 g /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M) <XXREAL-0R3 x0 +XCMPLX-0K2 g"
                  using xreal_1_th_6 sorry
                have "0NUMBERSK6 <XXREAL-0R3 g /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M)"
                  using A17 xreal_1_th_139 sorry
                then have "x0 +XCMPLX-0K2 (-XCMPLX-0K4 g) <XXREAL-0R3 x0 +XCMPLX-0K2 g /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M)"
                  using A17 xreal_1_th_6 sorry
                then have "x0 +XCMPLX-0K2 g /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M) inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 +XCMPLX-0K2 g .["
                  using A22 sorry
                thus "(x0 +XCMPLX-0K2 g /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M) inHIDDENR3 N & x0 +XCMPLX-0K2 g /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M) inHIDDENR3 N1) & h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (x0 +XCMPLX-0K2 g /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M))-XCMPLX-0K6 x0"
                  using A16 A18 A19 sorry
              qed "sorry"
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have A23: "s =COMPLEX1R1 p1 *XCMPLX-0K3 \<one>\<^sub>M"
            using A13 A15 sorry
          have A24: "r =COMPLEX1R1 r1 *XCMPLX-0K3 \<one>\<^sub>M"
            using A9 A11 sorry
          have A25: " for x be RealXREAL-0M1 holds x inHIDDENR3 N & x inHIDDENR3 N1 implies r *XCMPLX-0K3 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0) =COMPLEX1R1 s *XCMPLX-0K3 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
          proof(rule ballI,rule impMI ,rule impI)
            fix x assume [ty]: "x be RealXREAL-0M1"
            assume A26: "x inHIDDENR3 N"
              and A27: "x inHIDDENR3 N1"
            have "f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
              using A10 A26 sorry
            then have "L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0) =COMPLEX1R1 L1 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
              using A14 A27 sorry
            then have "r1 *XCMPLX-0K3 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0) =COMPLEX1R1 L1 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
              using A11 sorry
            thus "r *XCMPLX-0K3 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0) =COMPLEX1R1 s *XCMPLX-0K3 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
              using A15 A24 A23 sorry
          qed "sorry"
          obtain rs where 
            [ty]:"rs be ElementSUBSET-1M1-of REALNUMBERSK2" and rsDef:"rs = r -XCMPLX-0K6 s"
            using xreal_0_def_1 sorry
          have " for n be NatNAT-1M1 holds rs =COMPLEX1R1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 n"
          proof(rule ballI)
            have "R1 be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
              using fdiff_1_def_2 sorry
            then have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> R1 =XBOOLE-0R4 REALNUMBERSK2"
              using partfun1_def_2 sorry
            then have A28: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> h c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> R1"
               sorry
            fix n assume [ty]: "n be NatNAT-1M1"
            have "R be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
              using fdiff_1_def_2 sorry
            then have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> R =XBOOLE-0R4 REALNUMBERSK2"
              using partfun1_def_2 sorry
            then have A29: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> h c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> R"
               sorry
            have A30: "n inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            then have " ex x be RealXREAL-0M1 st (x inHIDDENR3 N & x inHIDDENR3 N1) & h .FUNCT-1K1 n =COMPLEX1R1 x -XCMPLX-0K6 x0"
              using A21 sorry
            then have "r *XCMPLX-0K3 h .FUNCT-1K1 n +XCMPLX-0K2 R .FUNCT-1K1 (h .FUNCT-1K1 n) =COMPLEX1R1 s *XCMPLX-0K3 h .FUNCT-1K1 n +XCMPLX-0K2 R1 .FUNCT-1K1 (h .FUNCT-1K1 n)"
              using A25 sorry
            then have A31: "(r *XCMPLX-0K3 h .FUNCT-1K1 n)/XCMPLX-0K7 h .FUNCT-1K1 n +XCMPLX-0K2 R .FUNCT-1K1 (h .FUNCT-1K1 n) /XCMPLX-0K7 h .FUNCT-1K1 n =COMPLEX1R1 (s *XCMPLX-0K3 h .FUNCT-1K1 n +XCMPLX-0K2 R1 .FUNCT-1K1 (h .FUNCT-1K1 n))/XCMPLX-0K7 h .FUNCT-1K1 n"
              using xcmplx_1_th_62 sorry
            have A32: "R .FUNCT-1K1 (h .FUNCT-1K1 n) /XCMPLX-0K7 h .FUNCT-1K1 n =HIDDENR1 R .FUNCT-1K1 (h .FUNCT-1K1 n) *XCMPLX-0K3 (h .FUNCT-1K1 n)\<inverse>XCMPLX-0K5"
              using xcmplx_0_def_9 sorry
            also have "... = R .FUNCT-1K1 (h .FUNCT-1K1 n) *XCMPLX-0K3 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n"
              using valued_1_th_10 sorry
            also have "... = R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h .FUNCT-1K1 n *XCMPLX-0K3 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n"
              using A30 A29 funct_2_th_108 sorry
            also have "... = (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 n"
              using seq_1_th_8 sorry
            finally have "R .FUNCT-1K1 (h .FUNCT-1K1 n) /XCMPLX-0K7 h .FUNCT-1K1 n =HIDDENR1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 n"
               sorry
            have A33: "h .FUNCT-1K1 n <>HIDDENR2 0NUMBERSK6"
              using seq_1_th_5 sorry
            have A34: "R1 .FUNCT-1K1 (h .FUNCT-1K1 n) /XCMPLX-0K7 h .FUNCT-1K1 n =HIDDENR1 R1 .FUNCT-1K1 (h .FUNCT-1K1 n) *XCMPLX-0K3 (h .FUNCT-1K1 n)\<inverse>XCMPLX-0K5"
              using xcmplx_0_def_9 sorry
            also have "... = R1 .FUNCT-1K1 (h .FUNCT-1K1 n) *XCMPLX-0K3 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n"
              using valued_1_th_10 sorry
            also have "... = R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h .FUNCT-1K1 n *XCMPLX-0K3 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n"
              using A30 A28 funct_2_th_108 sorry
            also have "... = (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 n"
              using seq_1_th_8 sorry
            finally have "R1 .FUNCT-1K1 (h .FUNCT-1K1 n) /XCMPLX-0K7 h .FUNCT-1K1 n =HIDDENR1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 n"
               sorry
            have A35: "(s *XCMPLX-0K3 h .FUNCT-1K1 n)/XCMPLX-0K7 h .FUNCT-1K1 n =HIDDENR1 s *XCMPLX-0K3 (h .FUNCT-1K1 n /XCMPLX-0K7 h .FUNCT-1K1 n)"
              using xcmplx_1_th_74 sorry
            also have "... = s *XCMPLX-0K3 \<one>\<^sub>M"
              using A33 xcmplx_1_th_60 sorry
            also have "... = s"
               sorry
            finally have "(s *XCMPLX-0K3 h .FUNCT-1K1 n)/XCMPLX-0K7 h .FUNCT-1K1 n =HIDDENR1 s"
               sorry
            have "(r *XCMPLX-0K3 h .FUNCT-1K1 n)/XCMPLX-0K7 h .FUNCT-1K1 n =HIDDENR1 r *XCMPLX-0K3 (h .FUNCT-1K1 n /XCMPLX-0K7 h .FUNCT-1K1 n)"
              using xcmplx_1_th_74 sorry
            also have "... = r *XCMPLX-0K3 \<one>\<^sub>M"
              using A33 xcmplx_1_th_60 sorry
            also have "... = r"
               sorry
            finally have "(r *XCMPLX-0K3 h .FUNCT-1K1 n)/XCMPLX-0K7 h .FUNCT-1K1 n =HIDDENR1 r"
               sorry
            then have "r +XCMPLX-0K2 R .FUNCT-1K1 (h .FUNCT-1K1 n) /XCMPLX-0K7 h .FUNCT-1K1 n =COMPLEX1R1 s +XCMPLX-0K2 R1 .FUNCT-1K1 (h .FUNCT-1K1 n) /XCMPLX-0K7 h .FUNCT-1K1 n"
              using A31 A35 xcmplx_1_th_62 sorry
            then have "r =COMPLEX1R1 s +XCMPLX-0K2 ((h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 n -XCMPLX-0K6 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 n)"
              using A32 A34 sorry
            thus "rs =COMPLEX1R1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 n"
              using rfunct_2_th_1 sorry
          qed "sorry"
          then have "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be constantFUNCT-1V5 & (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> \<one>\<^sub>M =COMPLEX1R1 rs"
            using valued_0_def_18 sorry
          then have A36: "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 r -XCMPLX-0K6 s"
            using seq_4_th_25 sorry
          have A37: "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 0NUMBERSK6"
            using fdiff_1_def_2 sorry
          have "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 0NUMBERSK6"
            using fdiff_1_def_2 sorry
          then have "r -XCMPLX-0K6 s =COMPLEX1R1 0NUMBERSK6 -XCMPLX-0K6 0NUMBERSK6"
            using A36 A37 seq_2_th_12 sorry
          thus "r =HIDDENR1 s"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mdef fdiff_1_def_6 (" _ is-differentiable-onFDIFF-1R2  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "X be setHIDDENM2"
"pred f is-differentiable-onFDIFF-1R2 X means
  X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for x be RealXREAL-0M1 holds x inHIDDENR3 X implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-differentiable-inFDIFF-1R1 x)"..

mtheorem fdiff_1_th_8:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-onFDIFF-1R2 X implies X be SubsetSUBSET-1M2-of REALNUMBERSK2"
  using xboole_1_th_1 sorry

mtheorem fdiff_1_th_9:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-onFDIFF-1R2 Z iff Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f is-differentiable-inFDIFF-1R1 x)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-differentiable-onFDIFF-1R2 Z implies Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f is-differentiable-inFDIFF-1R1 x)) & (Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f is-differentiable-inFDIFF-1R1 x) implies f is-differentiable-onFDIFF-1R2 Z)"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "f is-differentiable-onFDIFF-1R2 Z implies Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f is-differentiable-inFDIFF-1R1 x)"
    proof-
      have "f is-differentiable-onFDIFF-1R2 Z implies Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 Z implies f is-differentiable-inFDIFF-1R1 x0)"
      proof(rule impI,rule conjMI,rule ballI,rule impI)
        assume A1: "f is-differentiable-onFDIFF-1R2 Z"
        thus "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
           sorry
        fix x0 assume [ty]: "x0 be RealXREAL-0M1"
        assume A2: "x0 inHIDDENR3 Z"
        then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z is-differentiable-inFDIFF-1R1 x0"
          using A1 sorry
        then obtain N where
          [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
          A3: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(Z)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z)"and A4: " ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st  for x be RealXREAL-0M1 holds x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
           sorry
        have "domRELSET-1K1\<^bsub>(Z)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> Z"
          using relat_1_th_61 sorry
        then have Cut550: "domRELSET-1K1\<^bsub>(Z)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using xboole_1_th_17 sorry
        have "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( ex tVar7 be LinearFuncFDIFF-1M2 st  ex tVar8 be RestFuncFDIFF-1M1 st  for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 tVar7 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 tVar8 .FUNCT-1K1 (x -XCMPLX-0K6 x0))"
        proof(rule conjMI)
          show "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using A3 Cut550 sorry
          obtain L R where
            [ty]:"L be LinearFuncFDIFF-1M2" "R be RestFuncFDIFF-1M1" and 
            A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
            using A4 sorry
          show " ex tVar7 be LinearFuncFDIFF-1M2 st  ex tVar8 be RestFuncFDIFF-1M1 st  for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 tVar7 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 tVar8 .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
          proof(rule bexI[of _ "L"])
            show " ex tVar8 be RestFuncFDIFF-1M1 st  for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 tVar8 .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
            proof(rule bexI[of _ "R"],rule ballI,rule impI)
              fix x assume [ty]: "x be RealXREAL-0M1"
              assume A6: "x inHIDDENR3 N"
              then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
                using A5 sorry
              then have "f .FUNCT-1K1 x -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
                using A3 A6 funct_1_th_47 sorry
              thus "f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
                using A2 funct_1_th_49 sorry
            qed "sorry"
          qed "sorry"
        qed
        thus "f is-differentiable-inFDIFF-1R1 x0"
          using bexI[of _ "N"] fdiff_1_def_4 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A7: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A8: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f is-differentiable-inFDIFF-1R1 x"
    have "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 Z implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z is-differentiable-inFDIFF-1R1 x0)"
    proof(rule conjMI,rule ballI,rule impI)
      show "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A7 sorry
      fix x0 assume [ty]: "x0 be RealXREAL-0M1"
      assume A9: "x0 inHIDDENR3 Z"
      then obtain N1 where
        [ty]:"N1 be NeighbourhoodRCOMP-1M1-of x0" and 
        A10: "N1 c=TARSKIR1 Z"
        using rcomp_1_th_18 sorry
      have "f is-differentiable-inFDIFF-1R1 x0"
        using A8 A9 sorry
      then obtain N where
        [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
        A11: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and A12: " ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st  for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
         sorry
      obtain N2 where
        [ty]:"N2 be NeighbourhoodRCOMP-1M1-of x0" and 
        A13: "N2 c=TARSKIR1 N1"and A14: "N2 c=TARSKIR1 N"
        using rcomp_1_th_17 sorry
      have A15: "N2 c=TARSKIR1 Z"
        using A10 A13 sorry
      have "N2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A11 A14 sorry
      then have Cut581: "N2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> Z"
        using A15 xboole_1_th_19 sorry
      have "N2 c=TARSKIR1 domRELSET-1K1\<^bsub>(Z)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z) & ( ex tVar10 be LinearFuncFDIFF-1M2 st  ex tVar11 be RestFuncFDIFF-1M1 st  for x be RealXREAL-0M1 holds x inHIDDENR3 N2 implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x0 =COMPLEX1R1 tVar10 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 tVar11 .FUNCT-1K1 (x -XCMPLX-0K6 x0))"
      proof(rule conjMI)
        show A16: "N2 c=TARSKIR1 domRELSET-1K1\<^bsub>(Z)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z)"
          using relat_1_th_61 Cut581 sorry
        obtain L R where
          [ty]:"L be LinearFuncFDIFF-1M2" "R be RestFuncFDIFF-1M1" and 
          A17: " for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
          using A12 sorry
        have A18: "x0 inHIDDENR3 N2"
          using rcomp_1_th_16 sorry
        show " ex tVar10 be LinearFuncFDIFF-1M2 st  ex tVar11 be RestFuncFDIFF-1M1 st  for x be RealXREAL-0M1 holds x inHIDDENR3 N2 implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x0 =COMPLEX1R1 tVar10 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 tVar11 .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
        proof(rule bexI[of _ "L"])
          show " ex tVar11 be RestFuncFDIFF-1M1 st  for x be RealXREAL-0M1 holds x inHIDDENR3 N2 implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 tVar11 .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
          proof(rule bexI[of _ "R"],rule ballI,rule impI)
            fix x assume [ty]: "x be RealXREAL-0M1"
            assume A19: "x inHIDDENR3 N2"
            then have "f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
              using A14 A17 sorry
            then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
              using A16 A19 funct_1_th_47 sorry
            thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
              using A16 A18 funct_1_th_47 sorry
          qed "sorry"
        qed "sorry"
      qed
      thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z is-differentiable-inFDIFF-1R1 x0"
        using bexI[of _ "N2"] fdiff_1_def_4 sorry
    qed "sorry"
    thus "f is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_1_th_10:
" for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-onFDIFF-1R2 Y implies Y be openRCOMP-1V3"
proof-
  have " for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-onFDIFF-1R2 Y implies Y be openRCOMP-1V3"
  proof(rule ballI,rule ballI,rule impI)
    fix Y assume [ty]: "Y be SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f is-differentiable-onFDIFF-1R2 Y"
    have " for x0 be ElementSUBSET-1M1-of REALNUMBERSK2 holds x0 inTARSKIR2 Y implies ( ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 Y)"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be ElementSUBSET-1M1-of REALNUMBERSK2"
      assume "x0 inTARSKIR2 Y"
      then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y is-differentiable-inFDIFF-1R1 x0"
        using A1 sorry
      then obtain N where
        [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
        A2: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(Y)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)"and " ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st  for x be RealXREAL-0M1 holds x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 x -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
         sorry
      show " ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 Y"
      proof(rule bexI[of _ "N"])
        show "N c=TARSKIR1 Y"
          using A2 xboole_1_th_1 sorry
      qed "sorry"
    qed "sorry"
    thus "Y be openRCOMP-1V3"
      using rcomp_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef fdiff_1_def_7 (" _ `|FDIFF-1K2  _ " [164,164]164 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "X be setHIDDENM2"
"assume f is-differentiable-onFDIFF-1R2 X func f `|FDIFF-1K2 X \<rightarrow> PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  \<lambda>it. domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> it =XBOOLE-0R4 X & ( for x be RealXREAL-0M1 holds x inHIDDENR3 X implies it .FUNCT-1K1 x =COMPLEX1R1 diffFDIFF-1K1(f,x))"
proof-
  (*existence*)
    show "f is-differentiable-onFDIFF-1R2 X implies ( ex it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> it =XBOOLE-0R4 X & ( for x be RealXREAL-0M1 holds x inHIDDENR3 X implies it .FUNCT-1K1 x =COMPLEX1R1 diffFDIFF-1K1(f,x)))"
    proof(rule impI)
      assume Assume: "f is-differentiable-onFDIFF-1R2 X"
      have A1: "f is-differentiable-onFDIFF-1R2 X"
        using Assume sorry
      show " ex it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> it =XBOOLE-0R4 X & ( for x be RealXREAL-0M1 holds x inHIDDENR3 X implies it .FUNCT-1K1 x =COMPLEX1R1 diffFDIFF-1K1(f,x))"
      proof-
        have " ex tVar13 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> tVar13 =XBOOLE-0R4 X & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 X &  not tVar13 .FUNCT-1K1 x =COMPLEX1R1 diffFDIFF-1K1(f,x)))"
        proof-
          let ?F = "\<lambda>Lamb1. InSUBSET-1K10(diffFDIFF-1K1(f,Lamb1),REALNUMBERSK2)"
          let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 X"
          obtain F where
            [ty]:"F be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
            A2: "( for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds x inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F iff ?P(x)) & ( for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds x inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F implies F .FUNCT-1K1 x =COMPLEX1R1 ?F(x))"
            using seq_1_sch_3 sorry
          show " ex tVar13 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> tVar13 =XBOOLE-0R4 X & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 X &  not tVar13 .FUNCT-1K1 x =COMPLEX1R1 diffFDIFF-1K1(f,x)))"
          proof(rule bexI[of _ "F"],rule conjMI)
            have " for y be objectHIDDENM1 holds y inHIDDENR3 X implies y inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F"
            proof(rule ballI,rule impI)
              have A3: "X be SubsetSUBSET-1M2-of REALNUMBERSK2"
                using A1 fdiff_1_th_8 sorry
              fix y assume [ty]: "y be objectHIDDENM1"
              assume "y inHIDDENR3 X"
              thus "y inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F"
                using A2 A3 sorry
            qed "sorry"
            then have A4: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F"
               sorry
            have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F implies y inHIDDENR3 X"
              using A2 sorry
            then have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F c=TARSKIR1 X"
               sorry
            thus "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F =XBOOLE-0R4 X"
              using A4 sorry
            have " for x be RealXREAL-0M1 holds x inHIDDENR3 X implies F .FUNCT-1K1 x =COMPLEX1R1 diffFDIFF-1K1(f,x)"
            proof-
              have " for x be RealXREAL-0M1 holds  not (x inHIDDENR3 X &  not F .FUNCT-1K1 x =COMPLEX1R1 diffFDIFF-1K1(f,x))"
              proof(rule ballI)
                fix x assume [ty]: "x be RealXREAL-0M1"
                have 
                  [ty]:"x be ElementSUBSET-1M1-of REALNUMBERSK2"
                  using xreal_0_def_1 sorry
                have "x inTARSKIR2 X implies F .FUNCT-1K1 x =COMPLEX1R1 ?F(x)"
                  using A2 sorry
                thus " not (x inHIDDENR3 X &  not F .FUNCT-1K1 x =COMPLEX1R1 diffFDIFF-1K1(f,x))"
                   sorry
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            thus " for x be RealXREAL-0M1 holds  not (x inHIDDENR3 X &  not F .FUNCT-1K1 x =COMPLEX1R1 diffFDIFF-1K1(f,x))"
               sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show "f is-differentiable-onFDIFF-1R2 X implies ( for it1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for it2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> it1 =XBOOLE-0R4 X & ( for x be RealXREAL-0M1 holds x inHIDDENR3 X implies it1 .FUNCT-1K1 x =COMPLEX1R1 diffFDIFF-1K1(f,x))) & (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> it2 =XBOOLE-0R4 X & ( for x be RealXREAL-0M1 holds x inHIDDENR3 X implies it2 .FUNCT-1K1 x =COMPLEX1R1 diffFDIFF-1K1(f,x))) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "f is-differentiable-onFDIFF-1R2 X"
      have A1: "f is-differentiable-onFDIFF-1R2 X"
        using Assume sorry
      show " for it1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for it2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> it1 =XBOOLE-0R4 X & ( for x be RealXREAL-0M1 holds x inHIDDENR3 X implies it1 .FUNCT-1K1 x =COMPLEX1R1 diffFDIFF-1K1(f,x))) & (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> it2 =XBOOLE-0R4 X & ( for x be RealXREAL-0M1 holds x inHIDDENR3 X implies it2 .FUNCT-1K1 x =COMPLEX1R1 diffFDIFF-1K1(f,x))) implies it1 =HIDDENR1 it2"
      proof-
        have " for F be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for G be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F =XBOOLE-0R4 X & (( for x be RealXREAL-0M1 holds x inHIDDENR3 X implies F .FUNCT-1K1 x =COMPLEX1R1 diffFDIFF-1K1(f,x)) & (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> G =XBOOLE-0R4 X & ( for x be RealXREAL-0M1 holds x inHIDDENR3 X implies G .FUNCT-1K1 x =COMPLEX1R1 diffFDIFF-1K1(f,x)))) implies F =HIDDENR1 G"
        proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
          fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
          fix G assume [ty]: "G be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
          assume A5: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F =XBOOLE-0R4 X"
            and A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 X implies F .FUNCT-1K1 x =COMPLEX1R1 diffFDIFF-1K1(f,x)"
            and A7: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> G =XBOOLE-0R4 X"
            and A8: " for x be RealXREAL-0M1 holds x inHIDDENR3 X implies G .FUNCT-1K1 x =COMPLEX1R1 diffFDIFF-1K1(f,x)"
          have " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds x inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F implies F .FUNCT-1K1 x =COMPLEX1R1 G .FUNCT-1K1 x"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
            assume A9: "x inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F"
            then have "F .FUNCT-1K1 x =COMPLEX1R1 diffFDIFF-1K1(f,x)"
              using A5 A6 sorry
            thus "F .FUNCT-1K1 x =COMPLEX1R1 G .FUNCT-1K1 x"
              using A5 A8 A9 sorry
          qed "sorry"
          thus "F =HIDDENR1 G"
            using A5 A7 partfun1_th_5 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem fdiff_1_th_11:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( ex r be RealXREAL-0M1 st rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f =XBOOLE-0R4 {TARSKIK1 r}) implies f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f `|FDIFF-1K2 Z).FUNCT-1K1 x =COMPLEX1R1 0NUMBERSK6)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (( ex r be RealXREAL-0M1 st rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f =XBOOLE-0R4 {TARSKIK1 r}) implies f is-differentiable-onFDIFF-1R2 Z & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 Z implies (f `|FDIFF-1K2 Z).FUNCT-1K1 x0 =HIDDENR1 0NUMBERSK6))"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule conjMI,rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    obtain cf where 
      [ty]:"cf be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)" and cfDef:"cf = REALNUMBERSK2 -->FUNCOP-1K8\<^bsub>(REALNUMBERSK2)\<^esub> InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)"
       sorry
    let ?R = "cf"
    have A1: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?R =XBOOLE-0R4 REALNUMBERSK2"
      using funcop_1_th_13 sorry
    have " for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 0NUMBERSK6"
    proof(rule ballI,rule conjMI)
      fix h assume [ty]: "h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
      have A2: " for n be NatNAT-1M1 holds (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 n =HIDDENR1 0NUMBERSK6"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A3: "h .FUNCT-1K1 n inTARSKIR2 REALNUMBERSK2"
          using xreal_0_def_1 sorry
        have A4: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> h c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?R"
          using A1 sorry
        have A5: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "(h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 n =HIDDENR1 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n *XCMPLX-0K3 cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h .FUNCT-1K1 n"
          using seq_1_th_8 sorry
        also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n *XCMPLX-0K3 cf .FUNCT-1K1 (h .FUNCT-1K1 n)"
          using A5 A4 funct_2_th_108 sorry
        also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n *XCMPLX-0K3 (0NUMBERSK6)"
          using funcop_1_th_7 A3 sorry
        also have "... = 0NUMBERSK6"
           sorry
        finally show "(h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 n =HIDDENR1 0NUMBERSK6"
           sorry
      qed "sorry"
      then have A6: "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be constantFUNCT-1V5"
        using valued_0_def_18 sorry
      thus "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5"
         sorry
      have "(h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6"
        using A2 sorry
      thus "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 0NUMBERSK6"
        using A6 seq_4_th_25 sorry
    qed "sorry"
    then obtain R where 
      [ty]:"R be RestFuncFDIFF-1M1" and RDef:"R = ?R"
      using fdiff_1_def_2 sorry
    let ?L = "cf"
    have " for p be RealXREAL-0M1 holds ?L .FUNCT-1K1 p =COMPLEX1R1 (0NUMBERSK6)*XCMPLX-0K3 p"
      using xreal_0_def_1 funcop_1_th_7 sorry
    then obtain L where 
      [ty]:"L be LinearFuncFDIFF-1M2" and LDef:"L = ?L"
      using fdiff_1_def_3 sorry
    assume A7: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    assume Given: " ex r be RealXREAL-0M1 st rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f =XBOOLE-0R4 {TARSKIK1 r}"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A8: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f =XBOOLE-0R4 {TARSKIK1 r}"
       sorry
    have A9: " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 x0 =COMPLEX1R1 r"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be RealXREAL-0M1"
      assume "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      then have "f .FUNCT-1K1 x0 inTARSKIR2 {TARSKIK1 r}"
        using A8 funct_1_def_3 sorry
      thus "f .FUNCT-1K1 x0 =COMPLEX1R1 r"
        using tarski_def_1 sorry
    qed "sorry"
    have A10: " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 Z implies f is-differentiable-inFDIFF-1R1 x0"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be RealXREAL-0M1"
      assume A11: "x0 inHIDDENR3 Z"
      then obtain N where
        [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
        A12: "N c=TARSKIR1 Z"
        using rcomp_1_th_18 sorry
      have A13: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A7 A12 sorry
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
      proof-
        have " for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =HIDDENR1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be RealXREAL-0M1"
          obtain xx xx0 where 
            [ty]:"xx be ElementSUBSET-1M1-of REALNUMBERSK2" and xxDef:"xx = x" and
            [ty]:"xx0 be ElementSUBSET-1M1-of REALNUMBERSK2" and xx0Def:"xx0 = x0"
            using xreal_0_def_1 sorry
          assume "x inHIDDENR3 N"
          then have "f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =HIDDENR1 r -XCMPLX-0K6 f .FUNCT-1K1 x0"
            using A9 A13 sorry
          also have "... = r -XCMPLX-0K6 r"
            using A7 A9 A11 sorry
          also have "... = L .FUNCT-1K1 (xx -REAL-1K5 xx0) +XCMPLX-0K2 0NUMBERSK6"
            using funcop_1_th_7 sorry
          also have "... = L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
            using funcop_1_th_7 sorry
          finally show "f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =HIDDENR1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus "f is-differentiable-inFDIFF-1R1 x0"
        using A13 sorry
    qed "sorry"
    thus A14: "f is-differentiable-onFDIFF-1R2 Z"
      using A7 fdiff_1_th_9 sorry
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    assume A15: "x0 inHIDDENR3 Z"
    then have A16: "f is-differentiable-inFDIFF-1R1 x0"
      using A10 sorry
    then have " ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st  for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0))"
       sorry
    then obtain N where
      [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
      A17: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
       sorry
    have A18: " for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =HIDDENR1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        obtain xx xx0 where 
          [ty]:"xx be ElementSUBSET-1M1-of REALNUMBERSK2" and xxDef:"xx = x" and
          [ty]:"xx0 be ElementSUBSET-1M1-of REALNUMBERSK2" and xx0Def:"xx0 = x0"
          using xreal_0_def_1 sorry
        assume "x inHIDDENR3 N"
        then have "f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =HIDDENR1 r -XCMPLX-0K6 f .FUNCT-1K1 x0"
          using A9 A17 sorry
        also have "... = r -XCMPLX-0K6 r"
          using A7 A9 A15 sorry
        also have "... = L .FUNCT-1K1 (xx -REAL-1K5 xx0) +XCMPLX-0K2 0NUMBERSK6"
          using funcop_1_th_7 sorry
        also have "... = L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
          using funcop_1_th_7 sorry
        finally show "f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =HIDDENR1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain j where 
      [ty]:"j be ElementSUBSET-1M1-of REALNUMBERSK2" and jDef:"j = \<one>\<^sub>M"
      using xreal_0_def_1 sorry
    have "(f `|FDIFF-1K2 Z).FUNCT-1K1 x0 =HIDDENR1 diffFDIFF-1K1(f,x0)"
      using A14 A15 fdiff_1_def_7 sorry
    also have "... = L .FUNCT-1K1 j"
      using A16 A17 A18 fdiff_1_def_5 sorry
    also have "... = 0NUMBERSK6"
      using funcop_1_th_7 sorry
    finally show "(f `|FDIFF-1K2 Z).FUNCT-1K1 x0 =HIDDENR1 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_1_cl_6:
  mlet "h be non-zeroORDINAL1V9\<bar>Real-SequenceSEQ-1M1", "n be NatNAT-1M1"
"cluster h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n as-term-is non-zeroORDINAL1V9 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it =HIDDENR1 h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n implies it be non-zeroORDINAL1V9"
  proof-
    have " for hh be Real-SequenceSEQ-1M1 holds hh =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n implies hh be non-zeroORDINAL1V9"
    proof(rule ballI,rule impI)
      fix hh assume [ty]: "hh be Real-SequenceSEQ-1M1"
      assume A1: "hh =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n"
      have Cut761: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> hh c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> h"
        using A1 nat_1_th_55 sorry
      have " not 0NUMBERSK6 inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> hh"
      proof-
        show " not 0NUMBERSK6 inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> hh"
          using Cut761 sorry
      qed
      thus "hh be non-zeroORDINAL1V9"
        using ordinal1_def_15 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem fdiff_1_cl_7:
  mlet "h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1", "n be NatNAT-1M1"
"cluster h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n as-term-is non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it =HIDDENR1 h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n implies it be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1"
  proof-
    have " for VarFor1 be Real-SequenceSEQ-1M1 holds  not (VarFor1 =HIDDENR1 h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n &  not (VarFor1 be non-zeroORDINAL1V9 & VarFor1 be 0NUMBERSK6 -convergentFDIFF-1V1))"
    proof-
      have "limSEQ-2K1 h =COMPLEX1R1 0NUMBERSK6"
         sorry
      then have "limSEQ-2K1 (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) =COMPLEX1R1 0NUMBERSK6"
        using seq_4_th_20 sorry
      then have "h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n be 0NUMBERSK6 -convergentFDIFF-1V1"
         sorry
      thus " for VarFor1 be Real-SequenceSEQ-1M1 holds  not (VarFor1 =HIDDENR1 h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n &  not (VarFor1 be non-zeroORDINAL1V9 & VarFor1 be 0NUMBERSK6 -convergentFDIFF-1V1))"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem fdiff_1_th_12:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for x0 be RealXREAL-0M1 holds  for N be NeighbourhoodRCOMP-1M1-of x0 holds f is-differentiable-inFDIFF-1R1 x0 & N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies ( for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 N implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & diffFDIFF-1K1(f,x0) =COMPLEX1R1 limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)))"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for x0 be RealXREAL-0M1 holds  for N be NeighbourhoodRCOMP-1M1-of x0 holds f is-differentiable-inFDIFF-1R1 x0 & N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies ( for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 N implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & diffFDIFF-1K1(f,x0) =COMPLEX1R1 limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix N assume [ty]: "N be NeighbourhoodRCOMP-1M1-of x0"
    assume A1: "f is-differentiable-inFDIFF-1R1 x0"
      and A2: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    obtain N1 where
      [ty]:"N1 be NeighbourhoodRCOMP-1M1-of x0" and 
      "N1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and A3: " ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st  for x be RealXREAL-0M1 holds x inHIDDENR3 N1 implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
      using A1 sorry
    obtain N2 where
      [ty]:"N2 be NeighbourhoodRCOMP-1M1-of x0" and 
      A4: "N2 c=TARSKIR1 N"and A5: "N2 c=TARSKIR1 N1"
      using rcomp_1_th_17 sorry
    have A6: "N2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A2 A4 sorry
    fix h assume [ty]: "h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
    fix c assume [ty]: "c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1"
    assume A7: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0}"
      and A8: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 N"
    obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A9: "0NUMBERSK6 <XXREAL-0R3 g"and A10: "N2 =XBOOLE-0R4 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 +XCMPLX-0K2 g .["
      using rcomp_1_def_6 sorry
    have "x0 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 x0 +XCMPLX-0K2 g & x0 -XCMPLX-0K6 g <XXREAL-0R3 x0 -XCMPLX-0K6 0NUMBERSK6"
      using A9 xreal_1_th_8 xreal_1_th_15 sorry
    then have A11: "x0 inHIDDENR3 N2"
      using A10 sorry
    have A12: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c implies y inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c"
        then have "y =HIDDENR1 x0"
          using A7 tarski_def_1 sorry
        then have "y inHIDDENR3 N"
          using A4 A11 sorry
        thus "y inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A2 sorry
      qed "sorry"
      thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using tarski_def_3 sorry
    qed
    have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) c=TARSKIR1 N2 & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) c=TARSKIR1 N2"
    proof-
      have " ex tVar14 be ElementSUBSET-1M1-of NATNUMBERSK1 st rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> tVar14) c=TARSKIR1 N2 & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> tVar14) c=TARSKIR1 N2"
      proof-
        have "x0 inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c"
          using A7 tarski_def_1 sorry
        then have A13: "limSEQ-2K1 c =COMPLEX1R1 x0"
          using seq_4_th_25 sorry
        have "limSEQ-2K1 h =COMPLEX1R1 0NUMBERSK6"
           sorry
        then have "limSEQ-2K1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) =HIDDENR1 0NUMBERSK6 +XCMPLX-0K2 x0"
          using A13 seq_2_th_6 sorry
        also have "... = x0"
           sorry
        finally have "limSEQ-2K1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) =HIDDENR1 x0"
           sorry
        then obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A14: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-1K1 m -XCMPLX-0K6 x0 .| <XXREAL-0R3 g"
          using A9 seq_2_def_7 sorry
        have 
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
          using ordinal1_def_12 sorry
        show " ex tVar14 be ElementSUBSET-1M1-of NATNUMBERSK1 st rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> tVar14) c=TARSKIR1 N2 & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> tVar14) c=TARSKIR1 N2"
        proof(rule bexI[of _ "n"],rule conjMI)
          have A15: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) =XBOOLE-0R4 {TARSKIK1 x0}"
            using A7 valued_0_th_26 sorry
          show "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) c=TARSKIR1 N2"
            using A11 A15 tarski_def_1 sorry
          have " for y be objectHIDDENM1 holds y inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) implies y inHIDDENR3 N2"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            assume "y inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)"
            then obtain m where
              [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A16: "y =HIDDENR1 ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m"
              using funct_2_th_113 sorry
            have "n +NAT-1K1 0NUMBERSK6 <=XXREAL-0R1 n +NAT-1K1 m"
              using xreal_1_th_7 sorry
            then have A17: " |.COMPLEX1K10 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 m) -XCMPLX-0K6 x0 .| <XXREAL-0R3 g"
              using A14 sorry
            then have "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (m +NAT-1K1 n) -XCMPLX-0K6 x0 <XXREAL-0R3 g"
              using seq_2_th_1 sorry
            then have "((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 x0 <XXREAL-0R3 g"
              using nat_1_def_3 sorry
            then have A18: "((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <XXREAL-0R3 x0 +XCMPLX-0K2 g"
              using xreal_1_th_19 sorry
            have "-XCMPLX-0K4 g <XXREAL-0R3 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (m +NAT-1K1 n) -XCMPLX-0K6 x0"
              using A17 seq_2_th_1 sorry
            then have "-XCMPLX-0K4 g <XXREAL-0R3 ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 x0"
              using nat_1_def_3 sorry
            then have "x0 +XCMPLX-0K2 (-XCMPLX-0K4 g) <XXREAL-0R3 ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m"
              using xreal_1_th_20 sorry
            thus "y inHIDDENR3 N2"
              using A10 A16 A18 sorry
          qed "sorry"
          thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) c=TARSKIR1 N2"
            using tarski_def_3 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    then obtain n where
      [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
      "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) c=TARSKIR1 N2"and A19: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) c=TARSKIR1 N2"
       sorry
    obtain L R where
      [ty]:"L be LinearFuncFDIFF-1M2" "R be RestFuncFDIFF-1M1" and 
      A20: " for x be RealXREAL-0M1 holds x inHIDDENR3 N1 implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
      using A3 sorry
    have A21: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) implies y inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A22: "y inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)"
        have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c"
          using valued_0_th_26 sorry
        then have "y =HIDDENR1 x0"
          using A7 A22 tarski_def_1 sorry
        then have "y inHIDDENR3 N"
          using A4 A11 sorry
        thus "y inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A2 sorry
      qed "sorry"
      thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using tarski_def_3 sorry
    qed
    have A23: "L be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
      using fdiff_1_def_3 sorry
    have A24: "(L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n))(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5 & limSEQ-2K1 ((L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n))(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 L .FUNCT-1K1 \<one>\<^sub>M"
    proof(rule conjMI)
      let ?F = "\<lambda>Lamb1. L .FUNCT-1K1 \<one>\<^sub>M +XCMPLX-0K2 (R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>).FUNCT-1K1 Lamb1"
      obtain s1 where
        [ty]:"s1 be Real-SequenceSEQ-1M1" and 
        A25: " for k be NatNAT-1M1 holds s1 .FUNCT-1K1 k =COMPLEX1R1 ?F(k)"
        using seq_1_sch_1 sorry
      have A26: " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex n1 be NatNAT-1M1 st  for k be NatNAT-1M1 holds n1 <=XXREAL-0R1 k implies  |.COMPLEX1K10 s1 .FUNCT-1K1 k -XCMPLX-0K6 L .FUNCT-1K1 \<one>\<^sub>M .| <XXREAL-0R3 r)"
      proof(rule ballI,rule impI)
        have A27: "(h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) be convergentSEQ-2V5 & limSEQ-2K1 ((h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)) =COMPLEX1R1 0NUMBERSK6"
          using fdiff_1_def_2 sorry
        fix r assume [ty]: "r be RealXREAL-0M1"
        assume "0NUMBERSK6 <XXREAL-0R3 r"
        then obtain m where
          [ty]:"m be NatNAT-1M1" and 
          A28: " for k be NatNAT-1M1 holds m <=XXREAL-0R1 k implies  |.COMPLEX1K10 ((h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)).FUNCT-1K1 k -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 r"
          using A27 seq_2_def_7 sorry
        obtain n1 where 
          [ty]:"n1 be NatNAT-1M1" and n1Def:"n1 = m"
           sorry
        show " ex n1 be NatNAT-1M1 st  for k be NatNAT-1M1 holds n1 <=XXREAL-0R1 k implies  |.COMPLEX1K10 s1 .FUNCT-1K1 k -XCMPLX-0K6 L .FUNCT-1K1 \<one>\<^sub>M .| <XXREAL-0R3 r"
        proof(rule bexI[of _ "n1"],rule ballI,rule impI)
          fix k assume [ty]: "k be NatNAT-1M1"
          assume A29: "n1 <=XXREAL-0R1 k"
          have " |.COMPLEX1K10 s1 .FUNCT-1K1 k -XCMPLX-0K6 L .FUNCT-1K1 \<one>\<^sub>M .| =HIDDENR1  |.COMPLEX1K10 (L .FUNCT-1K1 \<one>\<^sub>M +XCMPLX-0K2 (R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>).FUNCT-1K1 k)-XCMPLX-0K6 L .FUNCT-1K1 \<one>\<^sub>M .|"
            using A25 sorry
          also have "... =  |.COMPLEX1K10 ((h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)).FUNCT-1K1 k -XCMPLX-0K6 0NUMBERSK6 .|"
             sorry
          finally have " |.COMPLEX1K10 s1 .FUNCT-1K1 k -XCMPLX-0K6 L .FUNCT-1K1 \<one>\<^sub>M .| =HIDDENR1  |.COMPLEX1K10 ((h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)).FUNCT-1K1 k -XCMPLX-0K6 0NUMBERSK6 .|"
             sorry
          thus " |.COMPLEX1K10 s1 .FUNCT-1K1 k -XCMPLX-0K6 L .FUNCT-1K1 \<one>\<^sub>M .| <XXREAL-0R3 r"
            using A28 A29 sorry
        qed "sorry"
      qed "sorry"
      obtain s where
        [ty]:"s be RealXREAL-0M1" and 
        A30: " for p1 be RealXREAL-0M1 holds L .FUNCT-1K1 p1 =COMPLEX1R1 s *XCMPLX-0K3 p1"
        using fdiff_1_def_3 sorry
      have A31: "L .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 s *XCMPLX-0K3 \<one>\<^sub>M"
        using A30 sorry
      also have "... = s"
         sorry
      finally have "L .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 s"
         sorry
      have " for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n))(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m =HIDDENR1 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m"
      proof(rule ballI)
        fix m assume [ty]: "m be ElementSUBSET-1M1-of NATNUMBERSK1"
        have A32: "(h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <>HIDDENR2 0NUMBERSK6"
          using seq_1_th_5 sorry
        have "((L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n))(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m =HIDDENR1 (L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m *REAL-1K4 (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m"
          using seq_1_th_8 sorry
        also have "... = (L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m +REAL-1K3 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m)*REAL-1K4 (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m"
          using seq_1_th_7 sorry
        also have "... = L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m *REAL-1K4 (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m +REAL-1K3 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m *REAL-1K4 (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m"
           sorry
        also have "... = L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m *REAL-1K4 (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m +REAL-1K3 (R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m"
          using seq_1_th_8 sorry
        also have "... = L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m *REAL-1K4 ((h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m)\<inverse>REAL-1K2 +REAL-1K3 (R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m"
          using valued_1_th_10 sorry
        also have "... = L .FUNCT-1K1 ((h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m) *XCMPLX-0K3 ((h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m)\<inverse>REAL-1K2 +XCMPLX-0K2 (R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m"
          using A23 funct_2_th_115 sorry
        also have "... = (s *XCMPLX-0K3 (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m)*XCMPLX-0K3 ((h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m)\<inverse>REAL-1K2 +XCMPLX-0K2 (R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m"
          using A30 sorry
        also have "... = s *XCMPLX-0K3 ((h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m *REAL-1K4 ((h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m)\<inverse>REAL-1K2) +XCMPLX-0K2 (R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m"
           sorry
        also have "... = s *XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 (R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m"
          using A32 xcmplx_0_def_7 sorry
        also have "... = s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m"
          using A25 A31 sorry
        finally show "((L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n))(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m =HIDDENR1 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m"
           sorry
      qed "sorry"
      then have A33: "(L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n))(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> s1"
        using funct_2_th_63 sorry
      thus "(L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n))(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5"
        using A26 seq_2_def_6 sorry
      thus "limSEQ-2K1 ((L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n))(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 L .FUNCT-1K1 \<one>\<^sub>M"
        using A33 A26 seq_2_def_7 sorry
    qed
    have A34: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A19 A4 A2 sorry
    have A35: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A8 A2 sorry
    have A36: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds f .FUNCT-1K1 (((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k) -XCMPLX-0K6 f .FUNCT-1K1 ((c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 L .FUNCT-1K1 ((h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k) +XCMPLX-0K2 R .FUNCT-1K1 ((h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k)"
    proof(rule ballI)
      fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)"
        using valued_0_th_28 sorry
      then have A37: "((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k inTARSKIR2 N2"
        using A19 sorry
      have "(c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c"
        using valued_0_th_26 valued_0_th_28 sorry
      then have A38: "(c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k =COMPLEX1R1 x0"
        using A7 tarski_def_1 sorry
      have "((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k -REAL-1K5 (c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k =HIDDENR1 (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k -REAL-1K5 (c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k"
        using seqm_3_th_15 sorry
      also have "... = ((h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k +REAL-1K3 (c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k)-REAL-1K5 (c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k"
        using seq_1_th_7 sorry
      also have "... = (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k"
         sorry
      finally have "((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k -REAL-1K5 (c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k =HIDDENR1 (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k"
         sorry
      thus "f .FUNCT-1K1 (((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k) -XCMPLX-0K6 f .FUNCT-1K1 ((c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 L .FUNCT-1K1 ((h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k) +XCMPLX-0K2 R .FUNCT-1K1 ((h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k)"
        using A20 A5 A37 A38 sorry
    qed "sorry"
    have A39: "R be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
      using fdiff_1_def_2 sorry
    have " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k =HIDDENR1 (L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k"
    proof(rule ballI)
      fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k =HIDDENR1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k -REAL-1K5 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k"
        using rfunct_2_th_1 sorry
      also have "... = f .FUNCT-1K1 (((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k) -XCMPLX-0K6 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k"
        using A34 funct_2_th_108 sorry
      also have "... = f .FUNCT-1K1 (((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k) -XCMPLX-0K6 f .FUNCT-1K1 ((c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k)"
        using A21 funct_2_th_108 sorry
      also have "... = L .FUNCT-1K1 ((h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k) +XCMPLX-0K2 R .FUNCT-1K1 ((h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k)"
        using A36 sorry
      also have "... = L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k +XCMPLX-0K2 R .FUNCT-1K1 ((h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k)"
        using A23 funct_2_th_115 sorry
      also have "... = L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k +REAL-1K3 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k"
        using A39 funct_2_th_115 sorry
      also have "... = (L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k"
        using seq_1_th_7 sorry
      finally show "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k =HIDDENR1 (L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k"
         sorry
    qed "sorry"
    then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)"
      using funct_2_th_63 sorry
    then have A40: "(L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n))(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =HIDDENR1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n))(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
      using A35 valued_0_th_27 sorry
    also have "... = (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
      using A12 valued_0_th_27 sorry
    also have "... = ((f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
      using seqm_3_th_17 sorry
    also have "... = ((f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)"
      using seqm_3_th_18 sorry
    also have "... = ((f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using seqm_3_th_19 sorry
    finally have "(L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n))(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =HIDDENR1 ((f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n"
       sorry
    then have A41: "L .FUNCT-1K1 \<one>\<^sub>M =COMPLEX1R1 limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))"
      using A24 seq_4_th_22 sorry
    show "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5"
      using A24 A40 seq_4_th_21 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 N2 implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
      using A20 A5 sorry
    thus "diffFDIFF-1K1(f,x0) =COMPLEX1R1 limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))"
      using A1 A6 A41 fdiff_1_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_1_th_13:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-differentiable-inFDIFF-1R1 x0 & f2 is-differentiable-inFDIFF-1R1 x0 implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 diffFDIFF-1K1(f1,x0) +XCMPLX-0K2 diffFDIFF-1K1(f2,x0)"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-differentiable-inFDIFF-1R1 x0 & f2 is-differentiable-inFDIFF-1R1 x0 implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =HIDDENR1 diffFDIFF-1K1(f1,x0) +XCMPLX-0K2 diffFDIFF-1K1(f2,x0)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    obtain j where 
      [ty]:"j be ElementSUBSET-1M1-of REALNUMBERSK2" and jDef:"j = \<one>\<^sub>M"
      using xreal_0_def_1 sorry
    assume A1: "f1 is-differentiable-inFDIFF-1R1 x0"
      and A2: "f2 is-differentiable-inFDIFF-1R1 x0"
    obtain N1 where
      [ty]:"N1 be NeighbourhoodRCOMP-1M1-of x0" and 
      A3: "N1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"and A4: " ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st  for x be RealXREAL-0M1 holds x inHIDDENR3 N1 implies f1 .FUNCT-1K1 x -XCMPLX-0K6 f1 .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
      using A1 sorry
    obtain L1 R1 where
      [ty]:"L1 be LinearFuncFDIFF-1M2" "R1 be RestFuncFDIFF-1M1" and 
      A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 N1 implies f1 .FUNCT-1K1 x -XCMPLX-0K6 f1 .FUNCT-1K1 x0 =COMPLEX1R1 L1 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
      using A4 sorry
    obtain N2 where
      [ty]:"N2 be NeighbourhoodRCOMP-1M1-of x0" and 
      A6: "N2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"and A7: " ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st  for x be RealXREAL-0M1 holds x inHIDDENR3 N2 implies f2 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
      using A2 sorry
    obtain L2 R2 where
      [ty]:"L2 be LinearFuncFDIFF-1M2" "R2 be RestFuncFDIFF-1M1" and 
      A8: " for x be RealXREAL-0M1 holds x inHIDDENR3 N2 implies f2 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x0 =COMPLEX1R1 L2 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R2 .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
      using A7 sorry
    obtain R where 
      [ty]:"R be RestFuncFDIFF-1M1" and RDef:"R = R1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2"
      using fdiff_1_th_4 sorry
    obtain L where 
      [ty]:"L be LinearFuncFDIFF-1M2" and LDef:"L = L1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2"
      using fdiff_1_th_2 sorry
    have A9: "L1 be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub> & L2 be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
      using fdiff_1_def_3 sorry
    obtain N where
      [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
      A10: "N c=TARSKIR1 N1"and A11: "N c=TARSKIR1 N2"
      using rcomp_1_th_17 sorry
    have A12: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using A6 A11 sorry
    have "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      using A3 A10 sorry
    then have "N /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using A12 xboole_1_th_27 sorry
    then have A13: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using valued_1_def_1 sorry
    have A14: "R1 be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub> & R2 be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
      using fdiff_1_def_2 sorry
    have A15: " for x be RealXREAL-0M1 holds x inHIDDENR3 N implies (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x -XCMPLX-0K6 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x0 =HIDDENR1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A16: "x0 inHIDDENR3 N"
        using rcomp_1_th_16 sorry
      obtain xx xx0 where 
        [ty]:"xx be ElementSUBSET-1M1-of REALNUMBERSK2" and xxDef:"xx = x" and
        [ty]:"xx0 be ElementSUBSET-1M1-of REALNUMBERSK2" and xx0Def:"xx0 = x0"
        using xreal_0_def_1 sorry
      assume A17: "x inHIDDENR3 N"
      then have "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x -XCMPLX-0K6 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x0 =HIDDENR1 (f1 .FUNCT-1K1 x +XCMPLX-0K2 f2 .FUNCT-1K1 x)-XCMPLX-0K6 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x0"
        using A13 valued_1_def_1 sorry
      also have "... = (f1 .FUNCT-1K1 x +XCMPLX-0K2 f2 .FUNCT-1K1 x)-XCMPLX-0K6 (f1 .FUNCT-1K1 x0 +XCMPLX-0K2 f2 .FUNCT-1K1 x0)"
        using A13 A16 valued_1_def_1 sorry
      also have "... = (f1 .FUNCT-1K1 x -XCMPLX-0K6 f1 .FUNCT-1K1 x0)+XCMPLX-0K2 (f2 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x0)"
         sorry
      also have "... = (L1 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 .FUNCT-1K1 (x -XCMPLX-0K6 x0))+XCMPLX-0K2 (f2 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x0)"
        using A5 A10 A17 sorry
      also have "... = (L1 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 .FUNCT-1K1 (x -XCMPLX-0K6 x0))+XCMPLX-0K2 (L2 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R2 .FUNCT-1K1 (x -XCMPLX-0K6 x0))"
        using A8 A11 A17 sorry
      also have "... = (L1 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 L2 .FUNCT-1K1 (x -XCMPLX-0K6 x0))+XCMPLX-0K2 (R1 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R2 .FUNCT-1K1 (x -XCMPLX-0K6 x0))"
         sorry
      also have "... = L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 (R1 .FUNCT-1K1 (xx -REAL-1K5 xx0) +XCMPLX-0K2 R2 .FUNCT-1K1 (xx -REAL-1K5 xx0))"
        using A9 rfunct_1_th_56 sorry
      also have "... = L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
        using A14 rfunct_1_th_56 sorry
      finally show "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x -XCMPLX-0K6 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x0 =HIDDENR1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
         sorry
    qed "sorry"
    thus "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x0"
      using A13 sorry
    then have "diffFDIFF-1K1(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =HIDDENR1 L .FUNCT-1K1 \<one>\<^sub>M"
      using A13 A15 fdiff_1_def_5 sorry
    also have "... = L1 .FUNCT-1K1 j +XCMPLX-0K2 L2 .FUNCT-1K1 j"
      using A9 rfunct_1_th_56 sorry
    also have "... = diffFDIFF-1K1(f1,x0) +XCMPLX-0K2 L2 .FUNCT-1K1 \<one>\<^sub>M"
      using A1 A3 A5 fdiff_1_def_5 sorry
    also have "... = diffFDIFF-1K1(f1,x0) +XCMPLX-0K2 diffFDIFF-1K1(f2,x0)"
      using A2 A6 A8 fdiff_1_def_5 sorry
    finally show "diffFDIFF-1K1(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =HIDDENR1 diffFDIFF-1K1(f1,x0) +XCMPLX-0K2 diffFDIFF-1K1(f2,x0)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_1_th_14:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-differentiable-inFDIFF-1R1 x0 & f2 is-differentiable-inFDIFF-1R1 x0 implies f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 diffFDIFF-1K1(f1,x0) -XCMPLX-0K6 diffFDIFF-1K1(f2,x0)"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-differentiable-inFDIFF-1R1 x0 & f2 is-differentiable-inFDIFF-1R1 x0 implies f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =HIDDENR1 diffFDIFF-1K1(f1,x0) -XCMPLX-0K6 diffFDIFF-1K1(f2,x0)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    obtain j where 
      [ty]:"j be ElementSUBSET-1M1-of REALNUMBERSK2" and jDef:"j = \<one>\<^sub>M"
      using xreal_0_def_1 sorry
    assume A1: "f1 is-differentiable-inFDIFF-1R1 x0"
      and A2: "f2 is-differentiable-inFDIFF-1R1 x0"
    obtain N1 where
      [ty]:"N1 be NeighbourhoodRCOMP-1M1-of x0" and 
      A3: "N1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"and A4: " ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st  for x be RealXREAL-0M1 holds x inHIDDENR3 N1 implies f1 .FUNCT-1K1 x -XCMPLX-0K6 f1 .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
      using A1 sorry
    obtain L1 R1 where
      [ty]:"L1 be LinearFuncFDIFF-1M2" "R1 be RestFuncFDIFF-1M1" and 
      A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 N1 implies f1 .FUNCT-1K1 x -XCMPLX-0K6 f1 .FUNCT-1K1 x0 =COMPLEX1R1 L1 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
      using A4 sorry
    obtain N2 where
      [ty]:"N2 be NeighbourhoodRCOMP-1M1-of x0" and 
      A6: "N2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"and A7: " ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st  for x be RealXREAL-0M1 holds x inHIDDENR3 N2 implies f2 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
      using A2 sorry
    obtain L2 R2 where
      [ty]:"L2 be LinearFuncFDIFF-1M2" "R2 be RestFuncFDIFF-1M1" and 
      A8: " for x be RealXREAL-0M1 holds x inHIDDENR3 N2 implies f2 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x0 =COMPLEX1R1 L2 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R2 .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
      using A7 sorry
    obtain R where 
      [ty]:"R be RestFuncFDIFF-1M1" and RDef:"R = R1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2"
      using fdiff_1_th_4 sorry
    obtain L where 
      [ty]:"L be LinearFuncFDIFF-1M2" and LDef:"L = L1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2"
      using fdiff_1_th_2 sorry
    have A9: "L1 be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub> & L2 be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
      using fdiff_1_def_3 sorry
    obtain N where
      [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
      A10: "N c=TARSKIR1 N1"and A11: "N c=TARSKIR1 N2"
      using rcomp_1_th_17 sorry
    have A12: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using A6 A11 sorry
    have "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      using A3 A10 sorry
    then have "N /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using A12 xboole_1_th_27 sorry
    then have A13: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using valued_1_th_12 sorry
    have A14: "R1 be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub> & R2 be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
      using fdiff_1_def_2 sorry
    have A15: " for x be RealXREAL-0M1 holds x inHIDDENR3 N implies (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x -XCMPLX-0K6 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x0 =HIDDENR1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A16: "x0 inHIDDENR3 N"
        using rcomp_1_th_16 sorry
      obtain xx xx0 where 
        [ty]:"xx be ElementSUBSET-1M1-of REALNUMBERSK2" and xxDef:"xx = x" and
        [ty]:"xx0 be ElementSUBSET-1M1-of REALNUMBERSK2" and xx0Def:"xx0 = x0"
        using xreal_0_def_1 sorry
      assume A17: "x inHIDDENR3 N"
      then have "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x -XCMPLX-0K6 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x0 =HIDDENR1 (f1 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x)-XCMPLX-0K6 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x0"
        using A13 valued_1_th_13 sorry
      also have "... = (f1 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x)-XCMPLX-0K6 (f1 .FUNCT-1K1 x0 -XCMPLX-0K6 f2 .FUNCT-1K1 x0)"
        using A13 A16 valued_1_th_13 sorry
      also have "... = (f1 .FUNCT-1K1 x -XCMPLX-0K6 f1 .FUNCT-1K1 x0)-XCMPLX-0K6 (f2 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x0)"
         sorry
      also have "... = (L1 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 .FUNCT-1K1 (x -XCMPLX-0K6 x0))-XCMPLX-0K6 (f2 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x0)"
        using A5 A10 A17 sorry
      also have "... = (L1 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 .FUNCT-1K1 (x -XCMPLX-0K6 x0))-XCMPLX-0K6 (L2 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R2 .FUNCT-1K1 (x -XCMPLX-0K6 x0))"
        using A8 A11 A17 sorry
      also have "... = (L1 .FUNCT-1K1 (x -XCMPLX-0K6 x0) -XCMPLX-0K6 L2 .FUNCT-1K1 (x -XCMPLX-0K6 x0))+XCMPLX-0K2 (R1 .FUNCT-1K1 (x -XCMPLX-0K6 x0) -XCMPLX-0K6 R2 .FUNCT-1K1 (x -XCMPLX-0K6 x0))"
         sorry
      also have "... = L .FUNCT-1K1 (xx -REAL-1K5 xx0) +XCMPLX-0K2 (R1 .FUNCT-1K1 (xx -REAL-1K5 xx0) -XCMPLX-0K6 R2 .FUNCT-1K1 (xx -REAL-1K5 xx0))"
        using A9 rfunct_1_th_56 sorry
      also have "... = L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
        using A14 rfunct_1_th_56 sorry
      finally show "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x -XCMPLX-0K6 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x0 =HIDDENR1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
         sorry
    qed "sorry"
    thus "f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x0"
      using A13 sorry
    then have "diffFDIFF-1K1(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =HIDDENR1 L .FUNCT-1K1 \<one>\<^sub>M"
      using A13 A15 fdiff_1_def_5 sorry
    also have "... = L1 .FUNCT-1K1 j -XCMPLX-0K6 L2 .FUNCT-1K1 j"
      using A9 rfunct_1_th_56 sorry
    also have "... = diffFDIFF-1K1(f1,x0) -XCMPLX-0K6 L2 .FUNCT-1K1 \<one>\<^sub>M"
      using A1 A3 A5 fdiff_1_def_5 sorry
    also have "... = diffFDIFF-1K1(f1,x0) -XCMPLX-0K6 diffFDIFF-1K1(f2,x0)"
      using A2 A6 A8 fdiff_1_def_5 sorry
    finally show "diffFDIFF-1K1(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =HIDDENR1 diffFDIFF-1K1(f1,x0) -XCMPLX-0K6 diffFDIFF-1K1(f2,x0)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_1_th_15:
" for x0 be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-inFDIFF-1R1 x0 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =COMPLEX1R1 r *XCMPLX-0K3 (diffFDIFF-1K1(f,x0))"
proof-
  have " for x0 be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-inFDIFF-1R1 x0 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =HIDDENR1 r *XCMPLX-0K3 (diffFDIFF-1K1(f,x0))"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    obtain j where 
      [ty]:"j be ElementSUBSET-1M1-of REALNUMBERSK2" and jDef:"j = \<one>\<^sub>M"
      using xreal_0_def_1 sorry
    assume A1: "f is-differentiable-inFDIFF-1R1 x0"
    then obtain N1 where
      [ty]:"N1 be NeighbourhoodRCOMP-1M1-of x0" and 
      A2: "N1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and A3: " ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st  for x be RealXREAL-0M1 holds x inHIDDENR3 N1 implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
       sorry
    obtain L1 R1 where
      [ty]:"L1 be LinearFuncFDIFF-1M2" "R1 be RestFuncFDIFF-1M1" and 
      A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 N1 implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L1 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
      using A3 sorry
    obtain R where 
      [ty]:"R be RestFuncFDIFF-1M1" and RDef:"R = r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> R1"
      using fdiff_1_th_5 sorry
    obtain L where 
      [ty]:"L be LinearFuncFDIFF-1M2" and LDef:"L = r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> L1"
      using fdiff_1_th_3 sorry
    have A5: "L1 be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
      using fdiff_1_def_3 sorry
    have A6: "N1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A2 valued_1_def_5 sorry
    have A7: "R1 be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
      using fdiff_1_def_2 sorry
    have A8: " for x be RealXREAL-0M1 holds x inHIDDENR3 N1 implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x -XCMPLX-0K6 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x0 =HIDDENR1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A9: "x0 inHIDDENR3 N1"
        using rcomp_1_th_16 sorry
      obtain xx xx0 where 
        [ty]:"xx be ElementSUBSET-1M1-of REALNUMBERSK2" and xxDef:"xx = x" and
        [ty]:"xx0 be ElementSUBSET-1M1-of REALNUMBERSK2" and xx0Def:"xx0 = x0"
        using xreal_0_def_1 sorry
      assume A10: "x inHIDDENR3 N1"
      then have "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x -XCMPLX-0K6 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x0 =HIDDENR1 r *XCMPLX-0K3 f .FUNCT-1K1 x -XCMPLX-0K6 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x0"
        using A6 valued_1_def_5 sorry
      also have "... = r *XCMPLX-0K3 f .FUNCT-1K1 x -XCMPLX-0K6 r *XCMPLX-0K3 f .FUNCT-1K1 x0"
        using A6 A9 valued_1_def_5 sorry
      also have "... = r *XCMPLX-0K3 (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0)"
         sorry
      also have "... = r *XCMPLX-0K3 (L1 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 .FUNCT-1K1 (x -XCMPLX-0K6 x0))"
        using A4 A10 sorry
      also have "... = r *XCMPLX-0K3 L1 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 r *XCMPLX-0K3 R1 .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
         sorry
      also have "... = L .FUNCT-1K1 (xx -REAL-1K5 xx0) +XCMPLX-0K2 r *XCMPLX-0K3 R1 .FUNCT-1K1 (xx -REAL-1K5 xx0)"
        using A5 rfunct_1_th_57 sorry
      also have "... = L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
        using A7 rfunct_1_th_57 sorry
      finally show "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x -XCMPLX-0K6 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x0 =HIDDENR1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
         sorry
    qed "sorry"
    thus "r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x0"
      using A6 sorry
    then have "diffFDIFF-1K1(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =HIDDENR1 L .FUNCT-1K1 \<one>\<^sub>M"
      using A6 A8 fdiff_1_def_5 sorry
    also have "... = r *XCMPLX-0K3 L1 .FUNCT-1K1 j"
      using A5 rfunct_1_th_57 sorry
    also have "... = r *XCMPLX-0K3 (diffFDIFF-1K1(f,x0))"
      using A1 A2 A4 fdiff_1_def_5 sorry
    finally show "diffFDIFF-1K1(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =HIDDENR1 r *XCMPLX-0K3 (diffFDIFF-1K1(f,x0))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_1_th_16:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-differentiable-inFDIFF-1R1 x0 & f2 is-differentiable-inFDIFF-1R1 x0 implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 f2 .FUNCT-1K1 x0 *XCMPLX-0K3 (diffFDIFF-1K1(f1,x0)) +XCMPLX-0K2 f1 .FUNCT-1K1 x0 *XCMPLX-0K3 (diffFDIFF-1K1(f2,x0))"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-differentiable-inFDIFF-1R1 x0 & f2 is-differentiable-inFDIFF-1R1 x0 implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =HIDDENR1 f2 .FUNCT-1K1 x0 *XCMPLX-0K3 (diffFDIFF-1K1(f1,x0)) +XCMPLX-0K2 f1 .FUNCT-1K1 x0 *XCMPLX-0K3 (diffFDIFF-1K1(f2,x0))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    obtain j where 
      [ty]:"j be ElementSUBSET-1M1-of REALNUMBERSK2" and jDef:"j = \<one>\<^sub>M"
      using xreal_0_def_1 sorry
    assume A1: "f1 is-differentiable-inFDIFF-1R1 x0"
      and A2: "f2 is-differentiable-inFDIFF-1R1 x0"
    obtain N1 where
      [ty]:"N1 be NeighbourhoodRCOMP-1M1-of x0" and 
      A3: "N1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"and A4: " ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st  for x be RealXREAL-0M1 holds x inHIDDENR3 N1 implies f1 .FUNCT-1K1 x -XCMPLX-0K6 f1 .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
      using A1 sorry
    obtain L1 R1 where
      [ty]:"L1 be LinearFuncFDIFF-1M2" "R1 be RestFuncFDIFF-1M1" and 
      A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 N1 implies f1 .FUNCT-1K1 x -XCMPLX-0K6 f1 .FUNCT-1K1 x0 =COMPLEX1R1 L1 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
      using A4 sorry
    obtain N2 where
      [ty]:"N2 be NeighbourhoodRCOMP-1M1-of x0" and 
      A6: "N2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"and A7: " ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st  for x be RealXREAL-0M1 holds x inHIDDENR3 N2 implies f2 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
      using A2 sorry
    obtain L2 R2 where
      [ty]:"L2 be LinearFuncFDIFF-1M2" "R2 be RestFuncFDIFF-1M1" and 
      A8: " for x be RealXREAL-0M1 holds x inHIDDENR3 N2 implies f2 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x0 =COMPLEX1R1 L2 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R2 .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
      using A7 sorry
    obtain R18 where 
      [ty]:"R18 be RestFuncFDIFF-1M1" and R18Def:"R18 = R2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L1"
      using fdiff_1_th_7 sorry
    obtain R17 where 
      [ty]:"R17 be RestFuncFDIFF-1M1" and R17Def:"R17 = R1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2"
      using fdiff_1_th_4 sorry
    have A9: "R18 be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
      using fdiff_1_def_2 sorry
    obtain R16 where 
      [ty]:"R16 be RestFuncFDIFF-1M1" and R16Def:"R16 = R1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2"
      using fdiff_1_th_7 sorry
    obtain R14 where 
      [ty]:"R14 be RestFuncFDIFF-1M1" and R14Def:"R14 = L1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2"
      using fdiff_1_th_6 sorry
    obtain R19 where 
      [ty]:"R19 be RestFuncFDIFF-1M1" and R19Def:"R19 = R16 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R17"
      using fdiff_1_th_4 sorry
    obtain R20 where 
      [ty]:"R20 be RestFuncFDIFF-1M1" and R20Def:"R20 = R19 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R18"
      using fdiff_1_th_4 sorry
    have A10: "R14 be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
      using fdiff_1_def_2 sorry
    obtain R12 where 
      [ty]:"R12 be RestFuncFDIFF-1M1" and R12Def:"R12 = f1 .FUNCT-1K1 x0 (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2"
      using fdiff_1_th_5 sorry
    have A11: "R2 be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
      using fdiff_1_def_2 sorry
    obtain L11 where 
      [ty]:"L11 be LinearFuncFDIFF-1M2" and L11Def:"L11 = f2 .FUNCT-1K1 x0 (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> L1"
      using fdiff_1_th_3 sorry
    have A12: "L1 be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
      using fdiff_1_def_3 sorry
    obtain R11 where 
      [ty]:"R11 be RestFuncFDIFF-1M1" and R11Def:"R11 = f2 .FUNCT-1K1 x0 (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> R1"
      using fdiff_1_th_5 sorry
    have A13: "R1 be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
      using fdiff_1_def_2 sorry
    obtain R13 where 
      [ty]:"R13 be RestFuncFDIFF-1M1" and R13Def:"R13 = R11 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R12"
      using fdiff_1_th_4 sorry
    obtain R15 where 
      [ty]:"R15 be RestFuncFDIFF-1M1" and R15Def:"R15 = R13 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R14"
      using fdiff_1_th_4 sorry
    obtain R where 
      [ty]:"R be RestFuncFDIFF-1M1" and RDef:"R = R15 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R20"
      using fdiff_1_th_4 sorry
    obtain N where
      [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
      A14: "N c=TARSKIR1 N1"and A15: "N c=TARSKIR1 N2"
      using rcomp_1_th_17 sorry
    have A16: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using A6 A15 sorry
    have "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      using A3 A14 sorry
    then have "N /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using A16 xboole_1_th_27 sorry
    then have A17: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using valued_1_def_4 sorry
    obtain L12 where 
      [ty]:"L12 be LinearFuncFDIFF-1M2" and L12Def:"L12 = f1 .FUNCT-1K1 x0 (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2"
      using fdiff_1_th_3 sorry
    have A18: "L2 be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
      using fdiff_1_def_3 sorry
    obtain L where 
      [ty]:"L be LinearFuncFDIFF-1M2" and LDef:"L = L11 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L12"
      using fdiff_1_th_2 sorry
    have A19: "R16 be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
      using fdiff_1_def_2 sorry
    have A20: "L11 be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub> & L12 be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
      using fdiff_1_def_3 sorry
    have A21: " for x be RealXREAL-0M1 holds x inHIDDENR3 N implies (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x -XCMPLX-0K6 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x0 =HIDDENR1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      obtain xx xx0 xxx0 where 
        [ty]:"xx be ElementSUBSET-1M1-of REALNUMBERSK2" and xxDef:"xx = x" and
        [ty]:"xx0 be ElementSUBSET-1M1-of REALNUMBERSK2" and xx0Def:"xx0 = x0" and
        [ty]:"xxx0 be ElementSUBSET-1M1-of REALNUMBERSK2" and xxx0Def:"xxx0 = x -XCMPLX-0K6 x0"
        using xreal_0_def_1 sorry
      assume A22: "x inHIDDENR3 N"
      then have A23: "(f1 .FUNCT-1K1 x -XCMPLX-0K6 f1 .FUNCT-1K1 x0)+XCMPLX-0K2 f1 .FUNCT-1K1 x0 =COMPLEX1R1 (L1 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 .FUNCT-1K1 (x -XCMPLX-0K6 x0))+XCMPLX-0K2 f1 .FUNCT-1K1 x0"
        using A5 A14 sorry
      have "(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x -XCMPLX-0K6 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x0 =HIDDENR1 f1 .FUNCT-1K1 x *XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x0"
        using valued_1_th_5 sorry
      also have "... = ((f1 .FUNCT-1K1 x *XCMPLX-0K3 f2 .FUNCT-1K1 x +XCMPLX-0K2 (-XCMPLX-0K4 f1 .FUNCT-1K1 x *XCMPLX-0K3 f2 .FUNCT-1K1 x0))+XCMPLX-0K2 f1 .FUNCT-1K1 x *XCMPLX-0K3 f2 .FUNCT-1K1 x0)-XCMPLX-0K6 f1 .FUNCT-1K1 x0 *XCMPLX-0K3 f2 .FUNCT-1K1 x0"
        using valued_1_th_5 sorry
      also have "... = f1 .FUNCT-1K1 x *XCMPLX-0K3 (f2 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x0) +XCMPLX-0K2 (f1 .FUNCT-1K1 x -XCMPLX-0K6 f1 .FUNCT-1K1 x0)*XCMPLX-0K3 f2 .FUNCT-1K1 x0"
         sorry
      also have "... = f1 .FUNCT-1K1 x *XCMPLX-0K3 (f2 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x0) +XCMPLX-0K2 (L1 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 .FUNCT-1K1 (x -XCMPLX-0K6 x0))*XCMPLX-0K3 f2 .FUNCT-1K1 x0"
        using A5 A14 A22 sorry
      also have "... = f1 .FUNCT-1K1 x *XCMPLX-0K3 (f2 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x0) +XCMPLX-0K2 (f2 .FUNCT-1K1 x0 *XCMPLX-0K3 L1 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 .FUNCT-1K1 (x -XCMPLX-0K6 x0) *XCMPLX-0K3 f2 .FUNCT-1K1 x0)"
         sorry
      also have "... = f1 .FUNCT-1K1 xx *XCMPLX-0K3 (f2 .FUNCT-1K1 xx -XCMPLX-0K6 f2 .FUNCT-1K1 xx0) +XCMPLX-0K2 (L11 .FUNCT-1K1 (xx -REAL-1K5 xx0) +XCMPLX-0K2 f2 .FUNCT-1K1 xx0 *XCMPLX-0K3 R1 .FUNCT-1K1 (xx -REAL-1K5 xx0))"
        using A12 rfunct_1_th_57 sorry
      also have "... = ((L1 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 .FUNCT-1K1 (x -XCMPLX-0K6 x0))+XCMPLX-0K2 f1 .FUNCT-1K1 x0)*XCMPLX-0K3 (f2 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x0) +XCMPLX-0K2 (L11 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R11 .FUNCT-1K1 (x -XCMPLX-0K6 x0))"
        using A13 A23 rfunct_1_th_57 sorry
      also have "... = ((L1 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 .FUNCT-1K1 (x -XCMPLX-0K6 x0))+XCMPLX-0K2 f1 .FUNCT-1K1 x0)*XCMPLX-0K3 (L2 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R2 .FUNCT-1K1 (x -XCMPLX-0K6 x0)) +XCMPLX-0K2 (L11 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R11 .FUNCT-1K1 (x -XCMPLX-0K6 x0))"
        using A8 A15 A22 sorry
      also have "... = ((L1 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 .FUNCT-1K1 (x -XCMPLX-0K6 x0))*XCMPLX-0K3 (L2 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R2 .FUNCT-1K1 (x -XCMPLX-0K6 x0)) +XCMPLX-0K2 (f1 .FUNCT-1K1 x0 *XCMPLX-0K3 L2 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 f1 .FUNCT-1K1 x0 *XCMPLX-0K3 R2 .FUNCT-1K1 (x -XCMPLX-0K6 x0)))+XCMPLX-0K2 (L11 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R11 .FUNCT-1K1 (x -XCMPLX-0K6 x0))"
         sorry
      also have "... = ((L1 .FUNCT-1K1 (xx -REAL-1K5 xx0) +XCMPLX-0K2 R1 .FUNCT-1K1 (xx -REAL-1K5 xx0))*XCMPLX-0K3 (L2 .FUNCT-1K1 (xx -REAL-1K5 xx0) +XCMPLX-0K2 R2 .FUNCT-1K1 (xx -REAL-1K5 xx0)) +XCMPLX-0K2 (L12 .FUNCT-1K1 (xx -XCMPLX-0K6 x0) +XCMPLX-0K2 f1 .FUNCT-1K1 x0 *XCMPLX-0K3 R2 .FUNCT-1K1 (xx -XCMPLX-0K6 x0)))+XCMPLX-0K2 (L11 .FUNCT-1K1 (xx -XCMPLX-0K6 x0) +XCMPLX-0K2 R11 .FUNCT-1K1 (xx -XCMPLX-0K6 x0))"
        using A18 rfunct_1_th_57 sorry
      also have "... = ((L1 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 .FUNCT-1K1 (x -XCMPLX-0K6 x0))*XCMPLX-0K3 (L2 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R2 .FUNCT-1K1 (x -XCMPLX-0K6 x0)) +XCMPLX-0K2 (L12 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R12 .FUNCT-1K1 (x -XCMPLX-0K6 x0)))+XCMPLX-0K2 (L11 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R11 .FUNCT-1K1 (x -XCMPLX-0K6 x0))"
        using A11 rfunct_1_th_57 sorry
      also have "... = (L1 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 .FUNCT-1K1 (x -XCMPLX-0K6 x0))*XCMPLX-0K3 (L2 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R2 .FUNCT-1K1 (x -XCMPLX-0K6 x0)) +XCMPLX-0K2 (L12 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 (L11 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 (R11 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R12 .FUNCT-1K1 (x -XCMPLX-0K6 x0))))"
         sorry
      also have "... = (L1 .FUNCT-1K1 (xx -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 .FUNCT-1K1 (xx -XCMPLX-0K6 x0))*XCMPLX-0K3 (L2 .FUNCT-1K1 (xx -XCMPLX-0K6 x0) +XCMPLX-0K2 R2 .FUNCT-1K1 (xx -XCMPLX-0K6 x0)) +XCMPLX-0K2 (L12 .FUNCT-1K1 (xx -XCMPLX-0K6 x0) +XCMPLX-0K2 (L11 .FUNCT-1K1 (xx -XCMPLX-0K6 x0) +XCMPLX-0K2 R13 .FUNCT-1K1 (xx -REAL-1K5 xx0)))"
        using A13 A11 rfunct_1_th_56 sorry
      also have "... = (L1 .FUNCT-1K1 (xx -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 .FUNCT-1K1 (xx -XCMPLX-0K6 x0))*XCMPLX-0K3 (L2 .FUNCT-1K1 (xx -XCMPLX-0K6 x0) +XCMPLX-0K2 R2 .FUNCT-1K1 (xx -XCMPLX-0K6 x0)) +XCMPLX-0K2 ((L11 .FUNCT-1K1 (xx -XCMPLX-0K6 x0) +XCMPLX-0K2 L12 .FUNCT-1K1 (xx -XCMPLX-0K6 x0))+XCMPLX-0K2 R13 .FUNCT-1K1 (xx -REAL-1K5 xx0))"
         sorry
      also have "... = ((L1 .FUNCT-1K1 (x -XCMPLX-0K6 x0) *XCMPLX-0K3 L2 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 L1 .FUNCT-1K1 (x -XCMPLX-0K6 x0) *XCMPLX-0K3 R2 .FUNCT-1K1 (x -XCMPLX-0K6 x0))+XCMPLX-0K2 R1 .FUNCT-1K1 (x -XCMPLX-0K6 x0) *XCMPLX-0K3 (L2 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R2 .FUNCT-1K1 (x -XCMPLX-0K6 x0)))+XCMPLX-0K2 (L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R13 .FUNCT-1K1 (x -XCMPLX-0K6 x0))"
        using A20 rfunct_1_th_56 sorry
      also have "... = ((R14 .FUNCT-1K1 (xx -XCMPLX-0K6 x0) +XCMPLX-0K2 R2 .FUNCT-1K1 (x -XCMPLX-0K6 x0) *XCMPLX-0K3 L1 .FUNCT-1K1 (x -XCMPLX-0K6 x0))+XCMPLX-0K2 R1 .FUNCT-1K1 (x -XCMPLX-0K6 x0) *XCMPLX-0K3 (L2 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R2 .FUNCT-1K1 (x -XCMPLX-0K6 x0)))+XCMPLX-0K2 (L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R13 .FUNCT-1K1 xxx0)"
        using A12 A18 rfunct_1_th_56 sorry
      also have "... = ((R14 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R18 .FUNCT-1K1 (x -XCMPLX-0K6 x0))+XCMPLX-0K2 (R1 .FUNCT-1K1 (x -XCMPLX-0K6 x0) *XCMPLX-0K3 L2 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 .FUNCT-1K1 (x -XCMPLX-0K6 x0) *XCMPLX-0K3 R2 .FUNCT-1K1 (x -XCMPLX-0K6 x0)))+XCMPLX-0K2 (L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R13 .FUNCT-1K1 (xx -REAL-1K5 xx0))"
        using A12 A11 rfunct_1_th_56 sorry
      also have "... = ((R14 .FUNCT-1K1 (xx -XCMPLX-0K6 x0) +XCMPLX-0K2 R18 .FUNCT-1K1 (x -XCMPLX-0K6 x0))+XCMPLX-0K2 (R16 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 .FUNCT-1K1 (x -XCMPLX-0K6 x0) *XCMPLX-0K3 R2 .FUNCT-1K1 (x -XCMPLX-0K6 x0)))+XCMPLX-0K2 (L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R13 .FUNCT-1K1 xxx0)"
        using A18 A13 rfunct_1_th_56 sorry
      also have "... = ((R14 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R18 .FUNCT-1K1 (x -XCMPLX-0K6 x0))+XCMPLX-0K2 (R16 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R17 .FUNCT-1K1 (x -XCMPLX-0K6 x0)))+XCMPLX-0K2 (L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R13 .FUNCT-1K1 (x -XCMPLX-0K6 x0))"
        using A13 A11 rfunct_1_th_56 sorry
      also have "... = ((R14 .FUNCT-1K1 (xx -REAL-1K5 xx0) +XCMPLX-0K2 R18 .FUNCT-1K1 (x -XCMPLX-0K6 x0))+XCMPLX-0K2 R19 .FUNCT-1K1 (x -XCMPLX-0K6 x0))+XCMPLX-0K2 (L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R13 .FUNCT-1K1 (x -XCMPLX-0K6 x0))"
        using A13 A11 A19 rfunct_1_th_56 sorry
      also have "... = (R14 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 (R19 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R18 .FUNCT-1K1 (x -XCMPLX-0K6 x0)))+XCMPLX-0K2 (L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R13 .FUNCT-1K1 (x -XCMPLX-0K6 x0))"
         sorry
      also have "... = (L .FUNCT-1K1 xxx0 +XCMPLX-0K2 R13 .FUNCT-1K1 (x -XCMPLX-0K6 xx0))+XCMPLX-0K2 (R14 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R20 .FUNCT-1K1 (x -XCMPLX-0K6 x0))"
        using A13 A11 A19 A9 rfunct_1_th_56 sorry
      also have "... = L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 ((R13 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R14 .FUNCT-1K1 (x -XCMPLX-0K6 x0))+XCMPLX-0K2 R20 .FUNCT-1K1 (x -XCMPLX-0K6 x0))"
         sorry
      also have "... = L .FUNCT-1K1 (xx -REAL-1K5 xx0) +XCMPLX-0K2 (R15 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R20 .FUNCT-1K1 (x -XCMPLX-0K6 x0))"
        using A13 A11 A10 rfunct_1_th_56 sorry
      also have "... = L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
        using A13 A11 A10 A19 A9 rfunct_1_th_56 sorry
      finally show "(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x -XCMPLX-0K6 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x0 =HIDDENR1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
         sorry
    qed "sorry"
    thus "f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x0"
      using A17 sorry
    then have "diffFDIFF-1K1(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =HIDDENR1 L .FUNCT-1K1 \<one>\<^sub>M"
      using A17 A21 fdiff_1_def_5 sorry
    also have "... = L11 .FUNCT-1K1 j +XCMPLX-0K2 L12 .FUNCT-1K1 j"
      using A20 rfunct_1_th_56 sorry
    also have "... = f2 .FUNCT-1K1 x0 *XCMPLX-0K3 L1 .FUNCT-1K1 j +XCMPLX-0K2 L12 .FUNCT-1K1 j"
      using A12 rfunct_1_th_57 sorry
    also have "... = f2 .FUNCT-1K1 x0 *XCMPLX-0K3 L1 .FUNCT-1K1 \<one>\<^sub>M +XCMPLX-0K2 f1 .FUNCT-1K1 x0 *XCMPLX-0K3 L2 .FUNCT-1K1 \<one>\<^sub>M"
      using A18 rfunct_1_th_57 sorry
    also have "... = f2 .FUNCT-1K1 x0 *XCMPLX-0K3 (diffFDIFF-1K1(f1,x0)) +XCMPLX-0K2 f1 .FUNCT-1K1 x0 *XCMPLX-0K3 L2 .FUNCT-1K1 \<one>\<^sub>M"
      using A1 A3 A5 fdiff_1_def_5 sorry
    also have "... = f2 .FUNCT-1K1 x0 *XCMPLX-0K3 (diffFDIFF-1K1(f1,x0)) +XCMPLX-0K2 f1 .FUNCT-1K1 x0 *XCMPLX-0K3 (diffFDIFF-1K1(f2,x0))"
      using A2 A6 A8 fdiff_1_def_5 sorry
    finally show "diffFDIFF-1K1(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =HIDDENR1 f2 .FUNCT-1K1 x0 *XCMPLX-0K3 (diffFDIFF-1K1(f1,x0)) +XCMPLX-0K2 f1 .FUNCT-1K1 x0 *XCMPLX-0K3 (diffFDIFF-1K1(f2,x0))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_1_th_17:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z implies f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f `|FDIFF-1K2 Z).FUNCT-1K1 x =COMPLEX1R1 \<one>\<^sub>M)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z implies f is-differentiable-onFDIFF-1R2 Z & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 Z implies (f `|FDIFF-1K2 Z).FUNCT-1K1 x0 =HIDDENR1 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    obtain j where 
      [ty]:"j be ElementSUBSET-1M1-of REALNUMBERSK2" and jDef:"j = \<one>\<^sub>M"
      using xreal_0_def_1 sorry
    obtain cf where 
      [ty]:"cf be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)" and cfDef:"cf = REALNUMBERSK2 -->FUNCOP-1K8\<^bsub>(REALNUMBERSK2)\<^esub> InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)"
       sorry
    let ?R = "cf"
    have A1: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?R =XBOOLE-0R4 REALNUMBERSK2"
      using funcop_1_th_13 sorry
    have " for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 0NUMBERSK6"
    proof(rule ballI,rule conjMI)
      fix h assume [ty]: "h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
      have A2: " for n be NatNAT-1M1 holds (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 n =HIDDENR1 0NUMBERSK6"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A3: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> h c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?R"
          using A1 sorry
        have A4: "h .FUNCT-1K1 n inTARSKIR2 REALNUMBERSK2"
          using xreal_0_def_1 sorry
        have A5: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "(h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 n =HIDDENR1 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n *XCMPLX-0K3 cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h .FUNCT-1K1 n"
          using seq_1_th_8 sorry
        also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n *XCMPLX-0K3 cf .FUNCT-1K1 (h .FUNCT-1K1 n)"
          using A5 A3 funct_2_th_108 sorry
        also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n *XCMPLX-0K3 (0NUMBERSK6)"
          using funcop_1_th_7 A4 sorry
        also have "... = 0NUMBERSK6"
           sorry
        finally show "(h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 n =HIDDENR1 0NUMBERSK6"
           sorry
      qed "sorry"
      then have A6: "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be constantFUNCT-1V5"
        using valued_0_def_18 sorry
      thus "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5"
         sorry
      have "(h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6"
        using A2 sorry
      thus "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 0NUMBERSK6"
        using A6 seq_4_th_25 sorry
    qed "sorry"
    then obtain R where 
      [ty]:"R be RestFuncFDIFF-1M1" and RDef:"R = ?R"
      using fdiff_1_def_2 sorry
    obtain L where 
      [ty]:"L be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and LDef:"L = idPARTFUN1K6 REALNUMBERSK2"
       sorry
    have " for p be RealXREAL-0M1 holds L .FUNCT-1K1 p =COMPLEX1R1 \<one>\<^sub>M *XCMPLX-0K3 p"
      using xreal_0_def_1 funct_1_th_18 sorry
    then have 
      [ty]:"L be LinearFuncFDIFF-1M2"
      using fdiff_1_def_3 sorry
    assume A7: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A8: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z"
    have A9: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =COMPLEX1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A10: "x inHIDDENR3 Z"
      then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x =COMPLEX1R1 x"
        using A8 funct_1_th_18 sorry
      thus "f .FUNCT-1K1 x =COMPLEX1R1 x"
        using A10 funct_1_th_49 sorry
    qed "sorry"
    have A11: " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 Z implies f is-differentiable-inFDIFF-1R1 x0"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be RealXREAL-0M1"
      assume A12: "x0 inHIDDENR3 Z"
      then obtain N where
        [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
        A13: "N c=TARSKIR1 Z"
        using rcomp_1_th_18 sorry
      have A14: " for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
      proof-
        have " for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =HIDDENR1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be RealXREAL-0M1"
          obtain xx xx0 where 
            [ty]:"xx be ElementSUBSET-1M1-of REALNUMBERSK2" and xxDef:"xx = x" and
            [ty]:"xx0 be ElementSUBSET-1M1-of REALNUMBERSK2" and xx0Def:"xx0 = x0"
            using xreal_0_def_1 sorry
          assume "x inHIDDENR3 N"
          then have "f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =HIDDENR1 x -XCMPLX-0K6 f .FUNCT-1K1 x0"
            using A9 A13 sorry
          also have "... = x -XCMPLX-0K6 x0"
            using A9 A12 sorry
          also have "... = L .FUNCT-1K1 (xx -REAL-1K5 xx0) +XCMPLX-0K2 0NUMBERSK6"
             sorry
          also have "... = L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
            using funcop_1_th_7 sorry
          finally show "f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =HIDDENR1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A7 A13 sorry
      thus "f is-differentiable-inFDIFF-1R1 x0"
        using A14 sorry
    qed "sorry"
    thus A15: "f is-differentiable-onFDIFF-1R2 Z"
      using A7 fdiff_1_th_9 sorry
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    assume A16: "x0 inHIDDENR3 Z"
    then obtain N1 where
      [ty]:"N1 be NeighbourhoodRCOMP-1M1-of x0" and 
      A17: "N1 c=TARSKIR1 Z"
      using rcomp_1_th_18 sorry
    have A18: "f is-differentiable-inFDIFF-1R1 x0"
      using A11 A16 sorry
    then have " ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st  for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0))"
       sorry
    then obtain N where
      [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
      A19: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
       sorry
    obtain N2 where
      [ty]:"N2 be NeighbourhoodRCOMP-1M1-of x0" and 
      A20: "N2 c=TARSKIR1 N1"and A21: "N2 c=TARSKIR1 N"
      using rcomp_1_th_17 sorry
    have A22: "N2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A19 A21 sorry
    have A23: " for x be RealXREAL-0M1 holds x inHIDDENR3 N2 implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 N2 implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =HIDDENR1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        obtain xx xx0 where 
          [ty]:"xx be ElementSUBSET-1M1-of REALNUMBERSK2" and xxDef:"xx = x" and
          [ty]:"xx0 be ElementSUBSET-1M1-of REALNUMBERSK2" and xx0Def:"xx0 = x0"
          using xreal_0_def_1 sorry
        assume "x inHIDDENR3 N2"
        then have "x inHIDDENR3 N1"
          using A20 sorry
        then have "f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =HIDDENR1 x -XCMPLX-0K6 f .FUNCT-1K1 x0"
          using A9 A17 sorry
        also have "... = x -XCMPLX-0K6 x0"
          using A9 A16 sorry
        also have "... = L .FUNCT-1K1 (xx -REAL-1K5 xx0) +XCMPLX-0K2 0NUMBERSK6"
           sorry
        also have "... = L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
          using funcop_1_th_7 sorry
        finally show "f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =HIDDENR1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "(f `|FDIFF-1K2 Z).FUNCT-1K1 x0 =HIDDENR1 diffFDIFF-1K1(f,x0)"
      using A15 A16 fdiff_1_def_7 sorry
    also have "... = L .FUNCT-1K1 j"
      using A18 A22 A23 fdiff_1_def_5 sorry
    also have "... = \<one>\<^sub>M"
       sorry
    finally show "(f `|FDIFF-1K2 Z).FUNCT-1K1 x0 =HIDDENR1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_1_th_18:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & f1 is-differentiable-onFDIFF-1R2 Z) & f2 is-differentiable-onFDIFF-1R2 Z implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =COMPLEX1R1 diffFDIFF-1K1(f1,x) +XCMPLX-0K2 diffFDIFF-1K1(f2,x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & (f1 is-differentiable-onFDIFF-1R2 Z & f2 is-differentiable-onFDIFF-1R2 Z) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =COMPLEX1R1 diffFDIFF-1K1(f1,x) +XCMPLX-0K2 diffFDIFF-1K1(f2,x)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      and A2: "f1 is-differentiable-onFDIFF-1R2 Z & f2 is-differentiable-onFDIFF-1R2 Z"
    have " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 Z implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x0"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be RealXREAL-0M1"
      assume "x0 inHIDDENR3 Z"
      then have "f1 is-differentiable-inFDIFF-1R1 x0 & f2 is-differentiable-inFDIFF-1R1 x0"
        using A2 fdiff_1_th_9 sorry
      thus "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x0"
        using fdiff_1_th_13 sorry
    qed "sorry"
    thus A3: "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(f1,x) +XCMPLX-0K2 diffFDIFF-1K1(f2,x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A4: "x inHIDDENR3 Z"
      then have A5: "f1 is-differentiable-inFDIFF-1R1 x & f2 is-differentiable-inFDIFF-1R1 x"
        using A2 fdiff_1_th_9 sorry
      have "((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x)"
        using A3 A4 fdiff_1_def_7 sorry
      also have "... = diffFDIFF-1K1(f1,x) +XCMPLX-0K2 diffFDIFF-1K1(f2,x)"
        using A5 fdiff_1_th_13 sorry
      finally show "((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(f1,x) +XCMPLX-0K2 diffFDIFF-1K1(f2,x)"
         sorry
    qed "sorry"
    thus " for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =COMPLEX1R1 diffFDIFF-1K1(f1,x) +XCMPLX-0K2 diffFDIFF-1K1(f2,x))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_1_th_19:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & f1 is-differentiable-onFDIFF-1R2 Z) & f2 is-differentiable-onFDIFF-1R2 Z implies f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =COMPLEX1R1 diffFDIFF-1K1(f1,x) -XCMPLX-0K6 diffFDIFF-1K1(f2,x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & (f1 is-differentiable-onFDIFF-1R2 Z & f2 is-differentiable-onFDIFF-1R2 Z) implies f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =COMPLEX1R1 diffFDIFF-1K1(f1,x) -XCMPLX-0K6 diffFDIFF-1K1(f2,x)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      and A2: "f1 is-differentiable-onFDIFF-1R2 Z & f2 is-differentiable-onFDIFF-1R2 Z"
    have " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 Z implies f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x0"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be RealXREAL-0M1"
      assume "x0 inHIDDENR3 Z"
      then have "f1 is-differentiable-inFDIFF-1R1 x0 & f2 is-differentiable-inFDIFF-1R1 x0"
        using A2 fdiff_1_th_9 sorry
      thus "f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x0"
        using fdiff_1_th_14 sorry
    qed "sorry"
    thus A3: "f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(f1,x) -XCMPLX-0K6 diffFDIFF-1K1(f2,x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A4: "x inHIDDENR3 Z"
      then have A5: "f1 is-differentiable-inFDIFF-1R1 x & f2 is-differentiable-inFDIFF-1R1 x"
        using A2 fdiff_1_th_9 sorry
      have "((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x)"
        using A3 A4 fdiff_1_def_7 sorry
      also have "... = diffFDIFF-1K1(f1,x) -XCMPLX-0K6 diffFDIFF-1K1(f2,x)"
        using A5 fdiff_1_th_14 sorry
      finally show "((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(f1,x) -XCMPLX-0K6 diffFDIFF-1K1(f2,x)"
         sorry
    qed "sorry"
    thus " for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =COMPLEX1R1 diffFDIFF-1K1(f1,x) -XCMPLX-0K6 diffFDIFF-1K1(f2,x))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_1_th_20:
" for r be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & f is-differentiable-onFDIFF-1R2 Z implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =COMPLEX1R1 r *XCMPLX-0K3 (diffFDIFF-1K1(f,x)))"
proof-
  have " for r be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & f is-differentiable-onFDIFF-1R2 Z implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =COMPLEX1R1 r *XCMPLX-0K3 (diffFDIFF-1K1(f,x))))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: "f is-differentiable-onFDIFF-1R2 Z"
    have " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 Z implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x0"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be RealXREAL-0M1"
      assume "x0 inHIDDENR3 Z"
      then have "f is-differentiable-inFDIFF-1R1 x0"
        using A2 fdiff_1_th_9 sorry
      thus "r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x0"
        using fdiff_1_th_15 sorry
    qed "sorry"
    thus A3: "r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 r *XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A4: "x inHIDDENR3 Z"
      then have A5: "f is-differentiable-inFDIFF-1R1 x"
        using A2 fdiff_1_th_9 sorry
      have "((r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)"
        using A3 A4 fdiff_1_def_7 sorry
      also have "... = r *XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using A5 fdiff_1_th_15 sorry
      finally show "((r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 r *XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
         sorry
    qed "sorry"
    thus " for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =COMPLEX1R1 r *XCMPLX-0K3 (diffFDIFF-1K1(f,x)))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_1_th_21:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & f1 is-differentiable-onFDIFF-1R2 Z) & f2 is-differentiable-onFDIFF-1R2 Z implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =COMPLEX1R1 f2 .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(f1,x)) +XCMPLX-0K2 f1 .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(f2,x)))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & (f1 is-differentiable-onFDIFF-1R2 Z & f2 is-differentiable-onFDIFF-1R2 Z) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =COMPLEX1R1 f2 .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(f1,x)) +XCMPLX-0K2 f1 .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(f2,x))))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      and A2: "f1 is-differentiable-onFDIFF-1R2 Z & f2 is-differentiable-onFDIFF-1R2 Z"
    have " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 Z implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x0"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be RealXREAL-0M1"
      assume "x0 inHIDDENR3 Z"
      then have "f1 is-differentiable-inFDIFF-1R1 x0 & f2 is-differentiable-inFDIFF-1R1 x0"
        using A2 fdiff_1_th_9 sorry
      thus "f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x0"
        using fdiff_1_th_16 sorry
    qed "sorry"
    thus A3: "f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 f2 .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(f1,x)) +XCMPLX-0K2 f1 .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(f2,x))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A4: "x inHIDDENR3 Z"
      then have A5: "f1 is-differentiable-inFDIFF-1R1 x & f2 is-differentiable-inFDIFF-1R1 x"
        using A2 fdiff_1_th_9 sorry
      have "((f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x)"
        using A3 A4 fdiff_1_def_7 sorry
      also have "... = f2 .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(f1,x)) +XCMPLX-0K2 f1 .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(f2,x))"
        using A5 fdiff_1_th_16 sorry
      finally show "((f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 f2 .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(f1,x)) +XCMPLX-0K2 f1 .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(f2,x))"
         sorry
    qed "sorry"
    thus " for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =COMPLEX1R1 f2 .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(f1,x)) +XCMPLX-0K2 f1 .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(f2,x)))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_1_th_22:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z be constantFUNCT-1V5 implies f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f `|FDIFF-1K2 Z).FUNCT-1K1 x =COMPLEX1R1 0NUMBERSK6)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z be constantFUNCT-1V5 implies f is-differentiable-onFDIFF-1R2 Z & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 Z implies (f `|FDIFF-1K2 Z).FUNCT-1K1 x0 =HIDDENR1 0NUMBERSK6)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    obtain cf where 
      [ty]:"cf be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)" and cfDef:"cf = REALNUMBERSK2 -->FUNCOP-1K8\<^bsub>(REALNUMBERSK2)\<^esub> InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)"
       sorry
    let ?R = "cf"
    have A1: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?R =XBOOLE-0R4 REALNUMBERSK2"
      using funcop_1_th_13 sorry
    have " for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 0NUMBERSK6"
    proof(rule ballI,rule conjMI)
      fix h assume [ty]: "h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
      have A2: " for n be NatNAT-1M1 holds (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 n =HIDDENR1 0NUMBERSK6"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A3: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> h c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?R"
          using A1 sorry
        have A4: "h .FUNCT-1K1 n inTARSKIR2 REALNUMBERSK2"
          using xreal_0_def_1 sorry
        have A5: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "(h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 n =HIDDENR1 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n *XCMPLX-0K3 cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h .FUNCT-1K1 n"
          using seq_1_th_8 sorry
        also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n *XCMPLX-0K3 cf .FUNCT-1K1 (h .FUNCT-1K1 n)"
          using A5 A3 funct_2_th_108 sorry
        also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n *XCMPLX-0K3 (0NUMBERSK6)"
          using funcop_1_th_7 A4 sorry
        also have "... = 0NUMBERSK6"
           sorry
        finally show "(h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 n =HIDDENR1 0NUMBERSK6"
           sorry
      qed "sorry"
      then have A6: "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be constantFUNCT-1V5"
        using valued_0_def_18 sorry
      thus "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5"
         sorry
      have "(h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6"
        using A2 sorry
      thus "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 0NUMBERSK6"
        using A6 seq_4_th_25 sorry
    qed "sorry"
    then obtain R where 
      [ty]:"R be RestFuncFDIFF-1M1" and RDef:"R = ?R"
      using fdiff_1_def_2 sorry
    let ?L = "cf"
    have " for p be RealXREAL-0M1 holds ?L .FUNCT-1K1 p =COMPLEX1R1 (0NUMBERSK6)*XCMPLX-0K3 p"
      using xreal_0_def_1 funcop_1_th_7 sorry
    then obtain L where 
      [ty]:"L be LinearFuncFDIFF-1M2" and LDef:"L = ?L"
      using fdiff_1_def_3 sorry
    assume A7: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A8: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z be constantFUNCT-1V5"
    obtain r where
      [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2" and 
      A9: " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds x inTARSKIR2 Z /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 x =COMPLEX1R1 r"
      using A8 partfun2_th_57 sorry
    have A10: " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 Z implies f is-differentiable-inFDIFF-1R1 x0"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be RealXREAL-0M1"
      assume A11: "x0 inHIDDENR3 Z"
      then obtain N where
        [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
        A12: "N c=TARSKIR1 Z"
        using rcomp_1_th_18 sorry
      have A13: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A7 A12 sorry
      have A14: "x0 inHIDDENR3 Z /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A7 A11 xboole_0_def_4 sorry
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
      proof-
        have " for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =HIDDENR1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be RealXREAL-0M1"
          obtain xx xx0 where 
            [ty]:"xx be ElementSUBSET-1M1-of REALNUMBERSK2" and xxDef:"xx = x" and
            [ty]:"xx0 be ElementSUBSET-1M1-of REALNUMBERSK2" and xx0Def:"xx0 = x0"
            using xreal_0_def_1 sorry
          assume "x inHIDDENR3 N"
          then have "x inHIDDENR3 Z /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using A12 A13 xboole_0_def_4 sorry
          then have "f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =HIDDENR1 r -XCMPLX-0K6 f .FUNCT-1K1 x0"
            using A9 sorry
          also have "... = r -REAL-1K5 r"
            using A9 A14 sorry
          also have "... = L .FUNCT-1K1 (xx -REAL-1K5 xx0) +XCMPLX-0K2 0NUMBERSK6"
            using funcop_1_th_7 sorry
          also have "... = L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
            using funcop_1_th_7 sorry
          finally show "f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =HIDDENR1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus "f is-differentiable-inFDIFF-1R1 x0"
        using A13 sorry
    qed "sorry"
    thus A15: "f is-differentiable-onFDIFF-1R2 Z"
      using A7 fdiff_1_th_9 sorry
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    assume A16: "x0 inHIDDENR3 Z"
    then obtain N where
      [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
      A17: "N c=TARSKIR1 Z"
      using rcomp_1_th_18 sorry
    have A18: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A7 A17 sorry
    have A19: "x0 inHIDDENR3 Z /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A7 A16 xboole_0_def_4 sorry
    have A20: " for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =HIDDENR1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        obtain xx xx0 where 
          [ty]:"xx be ElementSUBSET-1M1-of REALNUMBERSK2" and xxDef:"xx = x" and
          [ty]:"xx0 be ElementSUBSET-1M1-of REALNUMBERSK2" and xx0Def:"xx0 = x0"
          using xreal_0_def_1 sorry
        assume "x inHIDDENR3 N"
        then have "x inHIDDENR3 Z /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A17 A18 xboole_0_def_4 sorry
        then have "f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =HIDDENR1 r -XCMPLX-0K6 f .FUNCT-1K1 x0"
          using A9 sorry
        also have "... = r -REAL-1K5 r"
          using A9 A19 sorry
        also have "... = L .FUNCT-1K1 (xx -REAL-1K5 xx0) +XCMPLX-0K2 0NUMBERSK6"
          using funcop_1_th_7 sorry
        also have "... = L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
          using funcop_1_th_7 sorry
        finally show "f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =HIDDENR1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A21: "f is-differentiable-inFDIFF-1R1 x0"
      using A10 A16 sorry
    obtain j where 
      [ty]:"j be ElementSUBSET-1M1-of REALNUMBERSK2" and jDef:"j = \<one>\<^sub>M"
      using xreal_0_def_1 sorry
    have "(f `|FDIFF-1K2 Z).FUNCT-1K1 x0 =HIDDENR1 diffFDIFF-1K1(f,x0)"
      using A15 A16 fdiff_1_def_7 sorry
    also have "... = L .FUNCT-1K1 j"
      using A21 A18 A20 fdiff_1_def_5 sorry
    also have "... = 0NUMBERSK6"
      using funcop_1_th_7 sorry
    finally show "(f `|FDIFF-1K2 Z).FUNCT-1K1 x0 =HIDDENR1 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_1_th_23:
" for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =COMPLEX1R1 r *XCMPLX-0K3 x +XCMPLX-0K2 p) implies f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f `|FDIFF-1K2 Z).FUNCT-1K1 x =COMPLEX1R1 r)"
proof-
  have " for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =COMPLEX1R1 r *XCMPLX-0K3 x +XCMPLX-0K2 p) implies f is-differentiable-onFDIFF-1R2 Z & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 Z implies (f `|FDIFF-1K2 Z).FUNCT-1K1 x0 =HIDDENR1 r)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    obtain cf where 
      [ty]:"cf be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)" and cfDef:"cf = REALNUMBERSK2 -->FUNCOP-1K8\<^bsub>(REALNUMBERSK2)\<^esub> InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)"
       sorry
    let ?R = "cf"
    let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 REALNUMBERSK2"
    have A1: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?R =XBOOLE-0R4 REALNUMBERSK2"
      using funcop_1_th_13 sorry
    have " for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 0NUMBERSK6"
    proof(rule ballI,rule conjMI)
      fix h assume [ty]: "h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
      have A2: " for n be NatNAT-1M1 holds (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 n =HIDDENR1 0NUMBERSK6"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A3: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> h c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?R"
          using A1 sorry
        have A4: "h .FUNCT-1K1 n inTARSKIR2 REALNUMBERSK2"
          using xreal_0_def_1 sorry
        have A5: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "(h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 n =HIDDENR1 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n *XCMPLX-0K3 cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h .FUNCT-1K1 n"
          using seq_1_th_8 sorry
        also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n *XCMPLX-0K3 cf .FUNCT-1K1 (h .FUNCT-1K1 n)"
          using A5 A3 funct_2_th_108 sorry
        also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n *XCMPLX-0K3 (0NUMBERSK6)"
          using funcop_1_th_7 A4 sorry
        also have "... = 0NUMBERSK6"
           sorry
        finally show "(h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 n =HIDDENR1 0NUMBERSK6"
           sorry
      qed "sorry"
      then have A6: "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be constantFUNCT-1V5"
        using valued_0_def_18 sorry
      thus "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5"
         sorry
      have "(h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6"
        using A2 sorry
      thus "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 0NUMBERSK6"
        using A6 seq_4_th_25 sorry
    qed "sorry"
    then obtain R where 
      [ty]:"R be RestFuncFDIFF-1M1" and RDef:"R = ?R"
      using fdiff_1_def_2 sorry
    assume A7: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A8: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =COMPLEX1R1 r *XCMPLX-0K3 x +XCMPLX-0K2 p"
    let ?G = "\<lambda>Lamb1. InSUBSET-1K10(r *XCMPLX-0K3 Lamb1,REALNUMBERSK2)"
    obtain L where
      [ty]:"L be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
      A9: "( for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds x inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> L iff ?P(x)) & ( for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds x inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> L implies L .FUNCT-1K1 x =COMPLEX1R1 ?G(x))"
      using seq_1_sch_3 sorry
    have " for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> L iff r inHIDDENR3 REALNUMBERSK2"
      using A9 sorry
    then have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> L =XBOOLE-0R4 REALNUMBERSK2"
      using fdiff_1_th_1 sorry
    then have A10: "L be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
      using partfun1_def_2 sorry
    have A11: " for x be RealXREAL-0M1 holds L .FUNCT-1K1 x =COMPLEX1R1 r *XCMPLX-0K3 x"
    proof(rule ballI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have 
        [ty]:"x be ElementSUBSET-1M1-of REALNUMBERSK2"
        using xreal_0_def_1 sorry
      have "L .FUNCT-1K1 x =COMPLEX1R1 ?G(x)"
        using A9 sorry
      thus "L .FUNCT-1K1 x =COMPLEX1R1 r *XCMPLX-0K3 x"
         sorry
    qed "sorry"
    then have 
      [ty]:"L be LinearFuncFDIFF-1M2"
      using A10 fdiff_1_def_3 sorry
    have A12: " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 Z implies f is-differentiable-inFDIFF-1R1 x0"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be RealXREAL-0M1"
      assume A13: "x0 inHIDDENR3 Z"
      then obtain N where
        [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
        A14: "N c=TARSKIR1 Z"
        using rcomp_1_th_18 sorry
      have A15: " for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
      proof-
        have " for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =HIDDENR1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be RealXREAL-0M1"
          obtain xx xx0 where 
            [ty]:"xx be ElementSUBSET-1M1-of REALNUMBERSK2" and xxDef:"xx = x" and
            [ty]:"xx0 be ElementSUBSET-1M1-of REALNUMBERSK2" and xx0Def:"xx0 = x0"
            using xreal_0_def_1 sorry
          assume "x inHIDDENR3 N"
          then have "f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =HIDDENR1 (r *XCMPLX-0K3 x +XCMPLX-0K2 p)-XCMPLX-0K6 f .FUNCT-1K1 x0"
            using A8 A14 sorry
          also have "... = (r *XCMPLX-0K3 x +XCMPLX-0K2 p)-XCMPLX-0K6 (r *XCMPLX-0K3 x0 +XCMPLX-0K2 p)"
            using A8 A13 sorry
          also have "... = r *XCMPLX-0K3 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 0NUMBERSK6"
             sorry
          also have "... = L .FUNCT-1K1 (xx -REAL-1K5 xx0) +XCMPLX-0K2 0NUMBERSK6"
            using A11 sorry
          also have "... = L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
            using funcop_1_th_7 sorry
          finally show "f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =HIDDENR1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A7 A14 sorry
      thus "f is-differentiable-inFDIFF-1R1 x0"
        using A15 sorry
    qed "sorry"
    thus A16: "f is-differentiable-onFDIFF-1R2 Z"
      using A7 fdiff_1_th_9 sorry
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    assume A17: "x0 inHIDDENR3 Z"
    then obtain N where
      [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
      A18: "N c=TARSKIR1 Z"
      using rcomp_1_th_18 sorry
    have A19: " for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =HIDDENR1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        obtain xx xx0 where 
          [ty]:"xx be ElementSUBSET-1M1-of REALNUMBERSK2" and xxDef:"xx = x" and
          [ty]:"xx0 be ElementSUBSET-1M1-of REALNUMBERSK2" and xx0Def:"xx0 = x0"
          using xreal_0_def_1 sorry
        assume "x inHIDDENR3 N"
        then have "f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =HIDDENR1 (r *XCMPLX-0K3 x +XCMPLX-0K2 p)-XCMPLX-0K6 f .FUNCT-1K1 x0"
          using A8 A18 sorry
        also have "... = (r *XCMPLX-0K3 x +XCMPLX-0K2 p)-XCMPLX-0K6 (r *XCMPLX-0K3 x0 +XCMPLX-0K2 p)"
          using A8 A17 sorry
        also have "... = r *XCMPLX-0K3 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 0NUMBERSK6"
           sorry
        also have "... = L .FUNCT-1K1 (xx -REAL-1K5 xx0) +XCMPLX-0K2 0NUMBERSK6"
          using A11 sorry
        also have "... = L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
          using funcop_1_th_7 sorry
        finally show "f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =HIDDENR1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A20: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A7 A18 sorry
    have A21: "f is-differentiable-inFDIFF-1R1 x0"
      using A12 A17 sorry
    have "(f `|FDIFF-1K2 Z).FUNCT-1K1 x0 =HIDDENR1 diffFDIFF-1K1(f,x0)"
      using A16 A17 fdiff_1_def_7 sorry
    also have "... = L .FUNCT-1K1 \<one>\<^sub>M"
      using A21 A20 A19 fdiff_1_def_5 sorry
    also have "... = r *XCMPLX-0K3 \<one>\<^sub>M"
      using A11 sorry
    also have "... = r"
       sorry
    finally show "(f `|FDIFF-1K2 Z).FUNCT-1K1 x0 =HIDDENR1 r"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_1_th_24:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for x0 be RealXREAL-0M1 holds f is-differentiable-inFDIFF-1R1 x0 implies f is-continuous-inFCONT-1R1 x0"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for x0 be RealXREAL-0M1 holds f is-differentiable-inFDIFF-1R1 x0 implies f is-continuous-inFCONT-1R1 x0"
  proof(rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    assume A1: "f is-differentiable-inFDIFF-1R1 x0"
    then obtain N where
      [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
      A2: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and " ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st  for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
       sorry
    have " for s1 be Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (s1 be convergentSEQ-2V5 & (limSEQ-2K1 s1 =COMPLEX1R1 x0 & ( for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n <>HIDDENR2 x0))) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & f .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
    proof(rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI,rule conjMI)
      obtain g where
        [ty]:"g be RealXREAL-0M1" and 
        A3: "0NUMBERSK6 <XXREAL-0R3 g"and A4: "N =XBOOLE-0R4 ].RCOMP-1K2 x0 -XCMPLX-0K6 g,x0 +XCMPLX-0K2 g .["
        using rcomp_1_def_6 sorry
      let ?s2 = "seq-constSEQ-1K1 x0"
      fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
      assume A5: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        and A6: "s1 be convergentSEQ-2V5"
        and A7: "limSEQ-2K1 s1 =COMPLEX1R1 x0"
        and A8: " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n <>HIDDENR2 x0"
      obtain l where
        [ty]:"l be NatNAT-1M1" and 
        A9: " for m be NatNAT-1M1 holds l <=XXREAL-0R1 m implies  |.COMPLEX1K10 s1 .FUNCT-1K1 m -XCMPLX-0K6 x0 .| <XXREAL-0R3 g"
        using A6 A7 A3 seq_2_def_7 sorry
      obtain c where 
        [ty]:"c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1" and cDef:"c = ?s2 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> l"
         sorry
      let ?G = "\<lambda>Lamb1. s1 .FUNCT-1K1 Lamb1 -XCMPLX-0K6 ?s2 .FUNCT-1K1 Lamb1"
      obtain s3 where
        [ty]:"s3 be Real-SequenceSEQ-1M1" and 
        A10: " for n be NatNAT-1M1 holds s3 .FUNCT-1K1 n =COMPLEX1R1 ?G(n)"
        using seq_1_sch_1 sorry
      have A11: "s3 =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> s1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s2"
        using A10 rfunct_2_th_1 sorry
      then have A12: "s3 be convergentSEQ-2V5"
        using A6 sorry
      have A13: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0}"
      proof-
        have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c c=TARSKIR1 {TARSKIK1 x0} & {TARSKIK1 x0} c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c"
        proof(rule conjMI)
          show "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c c=TARSKIR1 {TARSKIK1 x0}"
          proof-
            have " for y be objectHIDDENM1 holds y inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c implies y inHIDDENR3 {TARSKIK1 x0}"
            proof(rule ballI,rule impI)
              fix y assume [ty]: "y be objectHIDDENM1"
              assume "y inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c"
              then obtain n where
                [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                A14: "y =HIDDENR1 (?s2 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> l).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using funct_2_th_113 sorry
              have A15: "?s2 .FUNCT-1K1 (n +XCMPLX-0K2 l) =COMPLEX1R1 x0"
                using seq_1_th_57 sorry
              have "y =HIDDENR1 ?s2 .FUNCT-1K1 (n +XCMPLX-0K2 l)"
                using A14 nat_1_def_3 sorry
              then have "y =HIDDENR1 x0"
                using A15 sorry
              thus "y inHIDDENR3 {TARSKIK1 x0}"
                using tarski_def_1 sorry
            qed "sorry"
            thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c c=TARSKIR1 {TARSKIK1 x0}"
              using tarski_def_3 sorry
          qed
          have " for y be objectHIDDENM1 holds y inHIDDENR3 {TARSKIK1 x0} implies y inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            assume "y inHIDDENR3 {TARSKIK1 x0}"
            then have A16: "y =HIDDENR1 x0"
              using tarski_def_1 sorry
            have "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 ?s2 .FUNCT-1K1 (0NUMBERSK6 +XCMPLX-0K2 l)"
              using nat_1_def_3 sorry
            also have "... = y"
              using A16 seq_1_th_57 sorry
            finally have "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 y"
               sorry
            thus "y inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c"
              using valued_0_th_28 sorry
          qed "sorry"
          thus "{TARSKIK1 x0} c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c"
            using tarski_def_3 sorry
        qed
        thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0}"
          using xboole_0_def_10 sorry
      qed
      have A17: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-1K1 m -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 p)"
      proof(rule ballI,rule impI)
        fix p assume [ty]: "p be RealXREAL-0M1"
        assume A18: "0NUMBERSK6 <XXREAL-0R3 p"
        obtain n where 
          [ty]:"n be NatNAT-1M1" and nDef:"n = 0NUMBERSK6"
           sorry
        show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-1K1 m -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 p"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          assume "n <=XXREAL-0R1 m"
          have A19: "m inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          have "x0 inHIDDENR3 N"
            using rcomp_1_th_16 sorry
          then have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using A2 A13 zfmisc_1_th_31 sorry
          then have " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-1K1 m -XCMPLX-0K6 f .FUNCT-1K1 x0 .| =HIDDENR1  |.COMPLEX1K10 f .FUNCT-1K1 (c .FUNCT-1K1 m) -XCMPLX-0K6 f .FUNCT-1K1 x0 .|"
            using funct_2_th_108 A19 sorry
          also have "... =  |.COMPLEX1K10 f .FUNCT-1K1 (?s2 .FUNCT-1K1 (m +XCMPLX-0K2 l)) -XCMPLX-0K6 f .FUNCT-1K1 x0 .|"
            using nat_1_def_3 sorry
          also have "... =  |.COMPLEX1K10 f .FUNCT-1K1 x0 -XCMPLX-0K6 f .FUNCT-1K1 x0 .|"
            using seq_1_th_57 sorry
          also have "... = 0NUMBERSK6"
            using absvalue_th_2 sorry
          finally have " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-1K1 m -XCMPLX-0K6 f .FUNCT-1K1 x0 .| =HIDDENR1 0NUMBERSK6"
             sorry
          thus " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-1K1 m -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 p"
            using A18 sorry
        qed "sorry"
      qed "sorry"
      then have A20: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c be convergentSEQ-2V5"
        using seq_2_def_6 sorry
      have "limSEQ-2K1 ?s2 =HIDDENR1 ?s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
        using seq_4_th_26 sorry
      also have "... = x0"
        using seq_1_th_57 sorry
      finally have "limSEQ-2K1 ?s2 =HIDDENR1 x0"
         sorry
      then have "limSEQ-2K1 s3 =HIDDENR1 x0 -XCMPLX-0K6 x0"
        using A6 A7 A11 seq_2_th_12 sorry
      also have "... = 0NUMBERSK6"
         sorry
      finally have "limSEQ-2K1 s3 =HIDDENR1 0NUMBERSK6"
         sorry
      then have A21: "limSEQ-2K1 (s3 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> l) =COMPLEX1R1 0NUMBERSK6"
        using A12 seq_4_th_20 sorry
      have A22: "( ex n be NatNAT-1M1 st s3 .FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6) implies  False "
      proof(rule impI)
        assume Given: " ex n be NatNAT-1M1 st s3 .FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6"
        then obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A23: "s3 .FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6"
           sorry
        have "s1 .FUNCT-1K1 n -XCMPLX-0K6 ?s2 .FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6"
          using A10 A23 sorry
        thus " False "
          using A8 seq_1_th_57 sorry
      qed
      have A24: "( ex n be NatNAT-1M1 st (s3 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> l).FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6) implies  False "
      proof(rule impI)
        assume Given: " ex n be NatNAT-1M1 st (s3 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> l).FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6"
        then obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A25: "(s3 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> l).FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6"
           sorry
        have "s3 .FUNCT-1K1 (n +XCMPLX-0K2 l) =COMPLEX1R1 0NUMBERSK6"
          using A25 nat_1_def_3 sorry
        thus " False "
          using A22 sorry
      qed
      have "s3 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> l be 0NUMBERSK6 -convergentFDIFF-1V1"
        using A12 A21 sorry
      then obtain h where 
        [ty]:"h be 0NUMBERSK6 -convergentFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Real-SequenceSEQ-1M1" and hDef:"h = s3 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> l"
        using A24 seq_1_th_5 sorry
      have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have "((f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
          using seq_1_th_7 sorry
        also have "... = (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)+REAL-1K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
          using rfunct_2_th_1 sorry
        also have "... = f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
           sorry
        finally show "((f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
           sorry
      qed "sorry"
      then have A26: "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
        using funct_2_th_63 sorry
      have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (s1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> l).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (((s1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq-constSEQ-1K1 x0)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq-constSEQ-1K1 x0)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> l).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
          using A11 seqm_3_th_15 sorry
        also have "... = ((s1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq-constSEQ-1K1 x0)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq-constSEQ-1K1 x0).FUNCT-1K1 (n +XCMPLX-0K2 l)"
          using nat_1_def_3 sorry
        also have "... = (s1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq-constSEQ-1K1 x0).FUNCT-1K1 (n +XCMPLX-0K2 l) +XCMPLX-0K2 (seq-constSEQ-1K1 x0).FUNCT-1K1 (n +XCMPLX-0K2 l)"
          using seq_1_th_7 sorry
        also have "... = (s1 .FUNCT-1K1 (n +XCMPLX-0K2 l) -XCMPLX-0K6 (seq-constSEQ-1K1 x0).FUNCT-1K1 (n +XCMPLX-0K2 l))+XCMPLX-0K2 (seq-constSEQ-1K1 x0).FUNCT-1K1 (n +XCMPLX-0K2 l)"
          using rfunct_2_th_1 sorry
        also have "... = (s1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> l).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
          using nat_1_def_3 sorry
        finally show "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (s1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> l).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
           sorry
      qed "sorry"
      then have A27: "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c =HIDDENR1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> l)"
        using A26 funct_2_th_63 sorry
      also have "... = f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> l"
        using A5 valued_0_th_27 sorry
      finally have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c =HIDDENR1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> l"
         sorry
      have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 N"
      proof-
        have " for y be objectHIDDENM1 holds y inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) implies y inHIDDENR3 N"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "y inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
          then obtain n where
            [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
            A28: "y =HIDDENR1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
            using funct_2_th_113 sorry
          have "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (((s1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s2)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s2)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> l).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
            using A11 seqm_3_th_15 sorry
          also have "... = ((s1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s2)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s2).FUNCT-1K1 (n +XCMPLX-0K2 l)"
            using nat_1_def_3 sorry
          also have "... = (s1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s2).FUNCT-1K1 (n +XCMPLX-0K2 l) +XCMPLX-0K2 ?s2 .FUNCT-1K1 (n +XCMPLX-0K2 l)"
            using seq_1_th_7 sorry
          also have "... = (s1 .FUNCT-1K1 (n +XCMPLX-0K2 l) -XCMPLX-0K6 ?s2 .FUNCT-1K1 (n +XCMPLX-0K2 l))+XCMPLX-0K2 ?s2 .FUNCT-1K1 (n +XCMPLX-0K2 l)"
            using rfunct_2_th_1 sorry
          also have "... = s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (l +NAT-1K1 n)"
             sorry
          finally have "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (l +NAT-1K1 n)"
             sorry
          then have " |.COMPLEX1K10 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -XCMPLX-0K6 x0 .| <XXREAL-0R3 g"
            using A9 nat_1_th_12 sorry
          thus "y inHIDDENR3 N"
            using A4 A28 rcomp_1_th_1 sorry
        qed "sorry"
        thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 N"
          using tarski_def_3 sorry
      qed
      then have A29: "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5"
        using A1 A2 A13 fdiff_1_th_12 sorry
      then have A30: "limSEQ-2K1 (h (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))) =HIDDENR1 (0NUMBERSK6)*XCMPLX-0K3 (limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)))"
        using A21 seq_2_th_15 sorry
      also have "... = 0NUMBERSK6"
         sorry
      finally have "limSEQ-2K1 (h (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))) =HIDDENR1 0NUMBERSK6"
         sorry
      have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (h (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have A31: "h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6"
          using A24 sorry
        have "(h (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
          using seq_1_th_8 sorry
        also have "... = h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
          using seq_1_th_8 sorry
        also have "... = h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 ((h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2 *REAL-1K4 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
          using valued_1_th_10 sorry
        also have "... = (h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2)*REAL-1K4 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
           sorry
        also have "... = \<one>\<^sub>M *XCMPLX-0K3 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
          using A31 xcmplx_0_def_7 sorry
        also have "... = (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
           sorry
        finally show "(h (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
           sorry
      qed "sorry"
      then have A32: "h (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c"
        using funct_2_th_63 sorry
      then have A33: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c be convergentSEQ-2V5"
        using A29 sorry
      then have A34: "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c be convergentSEQ-2V5"
        using A20 sorry
      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
        using A27 seq_4_th_21 sorry
      have "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c =COMPLEX1R1 f .FUNCT-1K1 x0"
        using A17 A20 seq_2_def_7 sorry
      then have "limSEQ-2K1 ((f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) =HIDDENR1 0NUMBERSK6 +XCMPLX-0K2 f .FUNCT-1K1 x0"
        using A30 A32 A33 A20 seq_2_th_6 sorry
      also have "... = f .FUNCT-1K1 x0"
         sorry
      finally have "limSEQ-2K1 ((f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) =HIDDENR1 f .FUNCT-1K1 x0"
         sorry
      thus "f .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A34 A27 seq_4_th_22 sorry
    qed "sorry"
    thus "f is-continuous-inFCONT-1R1 x0"
      using fcont_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_1_th_25:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-onFDIFF-1R2 X implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
proof-
  have " for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-onFDIFF-1R2 X implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f is-differentiable-onFDIFF-1R2 X"
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
      then have "x be RealXREAL-0M1 & x inHIDDENR3 X"
         sorry
      then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-differentiable-inFDIFF-1R1 x"
        using A1 sorry
      thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x"
        using fdiff_1_th_24 sorry
    qed "sorry"
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
      using fcont_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_1_th_26:
" for X be setHIDDENM2 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-onFDIFF-1R2 X & Z c=TARSKIR1 X implies f is-differentiable-onFDIFF-1R2 Z"
proof-
  have " for X be setHIDDENM2 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-onFDIFF-1R2 X & Z c=TARSKIR1 X implies f is-differentiable-onFDIFF-1R2 Z"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f is-differentiable-onFDIFF-1R2 X"
      and A2: "Z c=TARSKIR1 X"
    have Cut1766: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A1 sorry
    have "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 Z implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z is-differentiable-inFDIFF-1R1 x0)"
    proof(rule conjMI,rule ballI,rule impI)
      show "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A2 Cut1766 sorry
      fix x0 assume [ty]: "x0 be RealXREAL-0M1"
      assume A3: "x0 inHIDDENR3 Z"
      then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-differentiable-inFDIFF-1R1 x0"
        using A1 A2 sorry
      then obtain N where
        [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
        A4: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"and A5: " ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st  for x be RealXREAL-0M1 holds x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
         sorry
      obtain N1 where
        [ty]:"N1 be NeighbourhoodRCOMP-1M1-of x0" and 
        A6: "N1 c=TARSKIR1 Z"
        using A3 rcomp_1_th_18 sorry
      obtain N2 where
        [ty]:"N2 be NeighbourhoodRCOMP-1M1-of x0" and 
        A7: "N2 c=TARSKIR1 N"and A8: "N2 c=TARSKIR1 N1"
        using rcomp_1_th_17 sorry
      have A9: "N2 c=TARSKIR1 Z"
        using A6 A8 sorry
      have "domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> X"
        using relat_1_th_61 sorry
      then have "domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using xboole_1_th_17 sorry
      then have "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A4 sorry
      then have "N2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A7 sorry
      then have Cut1786: "N2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> Z"
        using A9 xboole_1_th_19 sorry
      have "N2 c=TARSKIR1 domRELSET-1K1\<^bsub>(Z)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z) & ( ex tVar18 be LinearFuncFDIFF-1M2 st  ex tVar19 be RestFuncFDIFF-1M1 st  for x be RealXREAL-0M1 holds x inHIDDENR3 N2 implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x0 =COMPLEX1R1 tVar18 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 tVar19 .FUNCT-1K1 (x -XCMPLX-0K6 x0))"
      proof(rule conjMI)
        show A10: "N2 c=TARSKIR1 domRELSET-1K1\<^bsub>(Z)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z)"
          using relat_1_th_61 Cut1786 sorry
        obtain L R where
          [ty]:"L be LinearFuncFDIFF-1M2" "R be RestFuncFDIFF-1M1" and 
          A11: " for x be RealXREAL-0M1 holds x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
          using A5 sorry
        show " ex tVar18 be LinearFuncFDIFF-1M2 st  ex tVar19 be RestFuncFDIFF-1M1 st  for x be RealXREAL-0M1 holds x inHIDDENR3 N2 implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x0 =COMPLEX1R1 tVar18 .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 tVar19 .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
        proof(rule bexI[of _ "L"])
          show " ex tVar19 be RestFuncFDIFF-1M1 st  for x be RealXREAL-0M1 holds x inHIDDENR3 N2 implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 tVar19 .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
          proof(rule bexI[of _ "R"],rule ballI,rule impI)
            fix x assume [ty]: "x be RealXREAL-0M1"
            assume A12: "x inHIDDENR3 N2"
            then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
              using A7 A11 sorry
            then have A13: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
              using A2 A3 funct_1_th_49 sorry
            have "x inHIDDENR3 N"
              using A7 A12 sorry
            then have "f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
              using A4 A13 funct_1_th_47 sorry
            then have "f .FUNCT-1K1 x -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
              using A3 funct_1_th_49 sorry
            thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
              using A10 A12 funct_1_th_47 sorry
          qed "sorry"
        qed "sorry"
      qed
      thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z is-differentiable-inFDIFF-1R1 x0"
        using bexI[of _ "N2"] fdiff_1_def_4 sorry
    qed "sorry"
    thus "f is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_1_th_27:
" ex R be RestFuncFDIFF-1M1 st R .FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & R is-continuous-inFCONT-1R1 0NUMBERSK6"
proof-
  have " ex tVar20 be RestFuncFDIFF-1M1 st tVar20 .FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & tVar20 is-continuous-inFCONT-1R1 0NUMBERSK6"
  proof-
    have A1: "{}SUBSET-1K1 REALNUMBERSK2 be closedRCOMP-1V2"
      using xboole_1_th_3 sorry
    have "(([#]SUBSET-1K2 REALNUMBERSK2)`SUBSET-1K3\<^bsub>(REALNUMBERSK2)\<^esub> =XBOOLE-0R4 {}SUBSET-1K1 REALNUMBERSK2 & REALNUMBERSK2 c=TARSKIR1 REALNUMBERSK2) & [#]SUBSET-1K2 REALNUMBERSK2 =XBOOLE-0R4 REALNUMBERSK2"
      using xboole_1_th_37 sorry
    then obtain Z where 
      [ty]:"Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2" and ZDef:"Z = [#]SUBSET-1K2 REALNUMBERSK2"
      using A1 rcomp_1_def_5 sorry
    obtain cf where 
      [ty]:"cf be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)" and cfDef:"cf = REALNUMBERSK2 -->FUNCOP-1K8\<^bsub>(REALNUMBERSK2)\<^esub> InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)"
       sorry
    let ?R = "cf"
    obtain f where 
      [ty]:"f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and fDef:"f = ?R"
       sorry
    have A2: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?R =XBOOLE-0R4 REALNUMBERSK2"
      using funcop_1_th_13 sorry
    have " for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 0NUMBERSK6"
    proof(rule ballI,rule conjMI)
      fix h assume [ty]: "h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
      have A3: " for n be NatNAT-1M1 holds (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 n =HIDDENR1 0NUMBERSK6"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A4: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> h c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?R"
          using A2 sorry
        have A5: "h .FUNCT-1K1 n inTARSKIR2 REALNUMBERSK2"
          using xreal_0_def_1 sorry
        have A6: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "(h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 n =HIDDENR1 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n *XCMPLX-0K3 cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h .FUNCT-1K1 n"
          using seq_1_th_8 sorry
        also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n *XCMPLX-0K3 cf .FUNCT-1K1 (h .FUNCT-1K1 n)"
          using A6 A4 funct_2_th_108 sorry
        also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n *XCMPLX-0K3 (0NUMBERSK6)"
          using funcop_1_th_7 A5 sorry
        also have "... = 0NUMBERSK6"
           sorry
        finally show "(h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 n =HIDDENR1 0NUMBERSK6"
           sorry
      qed "sorry"
      then have A7: "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be constantFUNCT-1V5"
        using valued_0_def_18 sorry
      thus "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5"
         sorry
      have "(h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6"
        using A3 sorry
      thus "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 0NUMBERSK6"
        using A7 seq_4_th_25 sorry
    qed "sorry"
    then obtain R where 
      [ty]:"R be RestFuncFDIFF-1M1" and RDef:"R = ?R"
      using fdiff_1_def_2 sorry
    let ?L = "cf"
    have " for p be RealXREAL-0M1 holds ?L .FUNCT-1K1 p =COMPLEX1R1 (0NUMBERSK6)*XCMPLX-0K3 p"
      using xreal_0_def_1 funcop_1_th_7 sorry
    then obtain L where 
      [ty]:"L be LinearFuncFDIFF-1M2" and LDef:"L = ?L"
      using fdiff_1_def_3 sorry
    have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z be constantFUNCT-1V5"
       sorry
    then obtain r where
      [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2" and 
      A8: " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds x inTARSKIR2 Z /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 x =COMPLEX1R1 r"
      using partfun2_th_57 sorry
    have A9: " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 Z implies f is-differentiable-inFDIFF-1R1 x0"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be RealXREAL-0M1"
      obtain xx0 where 
        [ty]:"xx0 be ElementSUBSET-1M1-of REALNUMBERSK2" and xx0Def:"xx0 = x0"
        using xreal_0_def_1 sorry
      assume "x0 inHIDDENR3 Z"
      let ?N = "the NeighbourhoodRCOMP-1M1-of x0"
      have A10: "?N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A2 sorry
      have A11: "xx0 inTARSKIR2 Z /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A2 sorry
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 ?N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
      proof-
        have " for x be RealXREAL-0M1 holds x inHIDDENR3 the NeighbourhoodRCOMP-1M1-of x0 implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =HIDDENR1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be RealXREAL-0M1"
          obtain xx where 
            [ty]:"xx be ElementSUBSET-1M1-of REALNUMBERSK2" and xxDef:"xx = x"
            using xreal_0_def_1 sorry
          assume "x inHIDDENR3 ?N"
          then have "x inHIDDENR3 Z /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using A10 xboole_0_def_4 sorry
          then have "f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =HIDDENR1 r -XCMPLX-0K6 f .FUNCT-1K1 x0"
            using A8 sorry
          also have "... = r -REAL-1K5 r"
            using A8 A11 sorry
          also have "... = L .FUNCT-1K1 (xx -REAL-1K5 xx0) +XCMPLX-0K2 0NUMBERSK6"
            using funcop_1_th_7 sorry
          also have "... = L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
            using funcop_1_th_7 sorry
          finally show "f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =HIDDENR1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus "f is-differentiable-inFDIFF-1R1 x0"
        using A10 sorry
    qed "sorry"
    let ?x0 = "the ElementSUBSET-1M1-of REALNUMBERSK2"
    have "f is-differentiable-inFDIFF-1R1 ?x0"
      using A9 sorry
    then obtain N where
      [ty]:"N be NeighbourhoodRCOMP-1M1-of ?x0" and 
      "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and A12: " ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st  for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 ?x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 ?x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 ?x0)"
       sorry
    obtain L R where
      [ty]:"L be LinearFuncFDIFF-1M2" "R be RestFuncFDIFF-1M1" and 
      A13: " for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 ?x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 ?x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 ?x0)"
      using A12 sorry
    show " ex tVar20 be RestFuncFDIFF-1M1 st tVar20 .FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & tVar20 is-continuous-inFCONT-1R1 0NUMBERSK6"
    proof(rule bexI[of _ "R"],rule conjMI)
      obtain p where
        [ty]:"p be RealXREAL-0M1" and 
        A14: " for r be RealXREAL-0M1 holds L .FUNCT-1K1 r =COMPLEX1R1 p *XCMPLX-0K3 r"
        using fdiff_1_def_3 sorry
      have "f .FUNCT-1K1 ?x0 -XCMPLX-0K6 f .FUNCT-1K1 ?x0 =COMPLEX1R1 L .FUNCT-1K1 (?x0 -REAL-1K5 ?x0) +XCMPLX-0K2 R .FUNCT-1K1 (?x0 -REAL-1K5 ?x0)"
        using A13 rcomp_1_th_16 sorry
      then have A15: "0NUMBERSK6 =COMPLEX1R1 p *XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 R .FUNCT-1K1 (0NUMBERSK6)"
        using A14 sorry
      thus "R .FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6"
         sorry
      have A16: " for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5 & limSEQ-2K1 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h =COMPLEX1R1 R .FUNCT-1K1 (0NUMBERSK6)"
      proof(rule ballI)
        let ?s3 = "seq-constSEQ-1K1 (0NUMBERSK6)"
        fix h assume [ty]: "h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
        have A17: "?s3 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> \<one>\<^sub>M =COMPLEX1R1 0NUMBERSK6"
          using seq_1_th_57 sorry
        have "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5"
          using fdiff_1_def_2 sorry
        then have "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be boundedSEQ-2V6"
           sorry
        then obtain M where
          [ty]:"M be RealXREAL-0M1" and 
          "M >XXREAL-0R4 0NUMBERSK6"and A18: " for n be NatNAT-1M1 holds  |.COMPLEX1K10 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 n.| <XXREAL-0R3 M"
          using seq_2_th_3 sorry
        have A19: " for n be NatNAT-1M1 holds (seq-constSEQ-1K1 (0NUMBERSK6)).FUNCT-1K1 n <=XXREAL-0R1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) .FUNCT-1K1 n & absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) .FUNCT-1K1 n <=XXREAL-0R1 (M (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 n"
        proof(rule ballI,rule conjMI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have " |.COMPLEX1K10 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 n.| =HIDDENR1  |.COMPLEX1K10 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n *XCMPLX-0K3 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h .FUNCT-1K1 n .|"
            using seq_1_th_8 sorry
          also have "... =  |.COMPLEX1K10 (h .FUNCT-1K1 n)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h .FUNCT-1K1 n .|"
            using valued_1_th_10 sorry
          finally have " |.COMPLEX1K10 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 n.| =HIDDENR1  |.COMPLEX1K10 (h .FUNCT-1K1 n)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h .FUNCT-1K1 n .|"
             sorry
          then have A20: " |.COMPLEX1K10 (h .FUNCT-1K1 n)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h .FUNCT-1K1 n .| <=XXREAL-0R1 M"
            using A18 sorry
          have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h .FUNCT-1K1 n.|"
            using complex1_th_46 sorry
          then have "0NUMBERSK6 <=XXREAL-0R1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) .FUNCT-1K1 n"
            using seq_1_th_12 sorry
          thus "(seq-constSEQ-1K1 (0NUMBERSK6)).FUNCT-1K1 n <=XXREAL-0R1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) .FUNCT-1K1 n"
            using seq_1_th_57 sorry
          have " |.COMPLEX1K10 h .FUNCT-1K1 n.| >=XXREAL-0R2 0NUMBERSK6"
            using complex1_th_46 sorry
          then have "( |.COMPLEX1K10 h .FUNCT-1K1 n.|)*XCMPLX-0K3 ( |.COMPLEX1K10 (h .FUNCT-1K1 n)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h .FUNCT-1K1 n .|) <=XXREAL-0R1 M *XCMPLX-0K3 ( |.COMPLEX1K10 h .FUNCT-1K1 n.|)"
            using A20 xreal_1_th_64 sorry
          then have " |.COMPLEX1K10 h .FUNCT-1K1 n *XCMPLX-0K3 ((h .FUNCT-1K1 n)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h .FUNCT-1K1 n) .| <=XXREAL-0R1 M *XCMPLX-0K3 ( |.COMPLEX1K10 h .FUNCT-1K1 n.|)"
            using complex1_th_65 sorry
          then have A21: " |.COMPLEX1K10 (h .FUNCT-1K1 n *XCMPLX-0K3 (h .FUNCT-1K1 n)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h .FUNCT-1K1 n .| <=XXREAL-0R1 M *XCMPLX-0K3 ( |.COMPLEX1K10 h .FUNCT-1K1 n.|)"
             sorry
          have "h .FUNCT-1K1 n <>HIDDENR2 0NUMBERSK6"
            using seq_1_th_5 sorry
          then have " |.COMPLEX1K10 \<one>\<^sub>M *XCMPLX-0K3 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h .FUNCT-1K1 n .| <=XXREAL-0R1 M *XCMPLX-0K3 ( |.COMPLEX1K10 h .FUNCT-1K1 n.|)"
            using A21 xcmplx_0_def_7 sorry
          then have " |.COMPLEX1K10 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h .FUNCT-1K1 n.| <=XXREAL-0R1 M *XCMPLX-0K3 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h .FUNCT-1K1 n"
            using seq_1_th_12 sorry
          then have " |.COMPLEX1K10 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h .FUNCT-1K1 n.| <=XXREAL-0R1 (M (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 n"
            using seq_1_th_9 sorry
          thus "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) .FUNCT-1K1 n <=XXREAL-0R1 (M (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 n"
            using seq_1_th_12 sorry
        qed "sorry"
        have "limSEQ-2K1 h =COMPLEX1R1 0NUMBERSK6"
           sorry
        then have "limSEQ-2K1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h =HIDDENR1  |.COMPLEX1K10 0NUMBERSK6 .|"
          using seq_4_th_14 sorry
        also have "... = 0NUMBERSK6"
          using absvalue_th_2 sorry
        finally have "limSEQ-2K1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h =HIDDENR1 0NUMBERSK6"
           sorry
        then have A22: "limSEQ-2K1 (M (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h) =HIDDENR1 M *XCMPLX-0K3 (0NUMBERSK6)"
          using seq_2_th_8 sorry
        also have "... = limSEQ-2K1 ?s3"
          using A17 seq_4_th_25 sorry
        finally have "limSEQ-2K1 (M (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h) =HIDDENR1 limSEQ-2K1 ?s3"
           sorry
        have A23: "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) be convergentSEQ-2V5"
          using A22 A19 seq_2_th_19 sorry
        have "limSEQ-2K1 ?s3 =COMPLEX1R1 0NUMBERSK6"
          using A17 seq_4_th_25 sorry
        then have "limSEQ-2K1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 0NUMBERSK6"
          using A22 A19 seq_2_th_20 sorry
        thus "R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5 & limSEQ-2K1 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h =COMPLEX1R1 R .FUNCT-1K1 (0NUMBERSK6)"
          using A15 A23 seq_4_th_15 sorry
      qed "sorry"
      have " for s1 be Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> R & ((s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 =COMPLEX1R1 0NUMBERSK6) & ( for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n <>HIDDENR2 0NUMBERSK6)) implies R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & limSEQ-2K1 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 =COMPLEX1R1 R .FUNCT-1K1 (0NUMBERSK6)"
      proof(rule ballI,rule impMI ,rule impMI ,rule impI)
        fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
        assume "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> R"
          and A24: "s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 =COMPLEX1R1 0NUMBERSK6"
          and A25: " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n <>HIDDENR2 0NUMBERSK6"
        have "s1 be 0NUMBERSK6 -convergentFDIFF-1V1"
          using A24 sorry
        then have "s1 be 0NUMBERSK6 -convergentFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Real-SequenceSEQ-1M1"
          using A25 seq_1_th_5 sorry
        thus "R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & limSEQ-2K1 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 =COMPLEX1R1 R .FUNCT-1K1 (0NUMBERSK6)"
          using A16 sorry
      qed "sorry"
      thus "R is-continuous-inFCONT-1R1 0NUMBERSK6"
        using fcont_1_th_2 sorry
    qed "sorry"
  qed
  thus " ?thesis "
     sorry
qed

mdef fdiff_1_def_8 ("differentiableFDIFF-1V4" 70 ) where
"attr differentiableFDIFF-1V4 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  (\<lambda>f. f is-differentiable-onFDIFF-1R2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)"..

mlemma fdiff_1_lm_1:
"{}SUBSET-1K1 REALNUMBERSK2 be closedRCOMP-1V2"
  using xboole_1_th_3 sorry

mlemma fdiff_1_lm_2:
"[#]SUBSET-1K2 REALNUMBERSK2 be openRCOMP-1V3"
  using xboole_1_th_37 fdiff_1_lm_1 sorry

mtheorem fdiff_1_cl_8:
"cluster differentiableFDIFF-1V4 for FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*existence*)
  show " ex it be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st it be differentiableFDIFF-1V4"
  proof-
    have " ex tVar21 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st tVar21 be differentiableFDIFF-1V4"
    proof-
      obtain Z where 
        [ty]:"Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2" and ZDef:"Z = REALNUMBERSK2"
        using fdiff_1_lm_2 sorry
      obtain f where 
        [ty]:"f be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)" and fDef:"f = idPARTFUN1K6 REALNUMBERSK2"
         sorry
      show " ex tVar21 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st tVar21 be differentiableFDIFF-1V4"
      proof(rule bexI[of _ "f"])
        have A1: "Z =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
           sorry
        have "f is-differentiable-onFDIFF-1R2 Z"
          using A1 fdiff_1_th_17 sorry
        thus "f be differentiableFDIFF-1V4"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem fdiff_1_th_28:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be differentiableFDIFF-1V4\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f is-differentiable-onFDIFF-1R2 Z"
  using fdiff_1_th_26 fdiff_1_def_8 sorry

end
