theory rvsum_1
  imports square_1 binop_2 finseq_4 setwop_2 rfunct_1 xxreal_1
   "../mizar_extension/E_number"
begin
(*begin*)
mtheorem rvsum_1_cl_1:
  mlet "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster n -elementCARD-1V3\<bar>natural-valuedVALUED-0V8 for FinSequenceFINSEQ-1M1"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M1 st it be n -elementCARD-1V3\<bar>natural-valuedVALUED-0V8"
  proof-
    have " ex tVar1 be FinSequenceFINSEQ-1M1 st tVar1 be n -elementCARD-1V3 & tVar1 be natural-valuedVALUED-0V8"
    proof-
      show " ex tVar1 be FinSequenceFINSEQ-1M1 st tVar1 be n -elementCARD-1V3 & tVar1 be natural-valuedVALUED-0V8"
      proof(rule bexI[of _ "n  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)"])
        show "n  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6) be n -elementCARD-1V3 & n  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6) be natural-valuedVALUED-0V8"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rvsum_1_cl_2:
"cluster real-valuedVALUED-0V7 for FinSequenceFINSEQ-1M1"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M1 st it be real-valuedVALUED-0V7"
  proof-
    have " not ( for VarFor1 be FinSequenceFINSEQ-1M1 holds  not VarFor1 be real-valuedVALUED-0V7)"
    proof-
      have "the FinSequenceFINSEQ-1M3-of REALNUMBERSK2 be real-valuedVALUED-0V7"
         sorry
      thus " not ( for VarFor1 be FinSequenceFINSEQ-1M1 holds  not VarFor1 be real-valuedVALUED-0V7)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

abbreviation(input) RVSUM_1K1("rngRVSUM-1K1  _ " [228]228) where
  "rngRVSUM-1K1 F \<equiv> rngRELAT-1K2 F"

mtheorem rvsum_1_add_1:
  mlet "F be real-valuedVALUED-0V3\<bar>RelationRELAT-1M1"
"cluster rngRELAT-1K2 F as-term-is SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show "rngRELAT-1K2 F be SubsetSUBSET-1M2-of REALNUMBERSK2"
    using valued_0_def_3 sorry
qed "sorry"

mtheorem rvsum_1_cl_3:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be FunctionFUNCT-2M1-of(REALNUMBERSK2,D)", "F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
"cluster F *FUNCT-1K3 F1 as-term-is FinSequence-likeFINSEQ-1V1"
proof
(*coherence*)
  show "F *FUNCT-1K3 F1 be FinSequence-likeFINSEQ-1V1"
  proof-
    obtain n1 where
      [ty]:"n1 be NatNAT-1M1" and 
      A1: "domFINSEQ-1K5 F1 =XBOOLE-0R4 SegFINSEQ-1K2 n1"
      using finseq_1_def_2 sorry
    have Cut80: "domRELAT-1K1 F =XBOOLE-0R4 REALNUMBERSK2 & rngRVSUM-1K1 F1 c=TARSKIR1 REALNUMBERSK2"
      using funct_2_def_1 sorry
    have "domRELAT-1K1 (F *FUNCT-1K3 F1) =HIDDENR1 SegFINSEQ-1K2 n1"
    proof-
      show "domRELAT-1K1 (F *FUNCT-1K3 F1) =HIDDENR1 SegFINSEQ-1K2 n1"
        using A1 relat_1_th_27 Cut80 sorry
    qed
    thus "F *FUNCT-1K3 F1 be FinSequence-likeFINSEQ-1V1"
      using bexI[of _ "n1"] finseq_1_def_2 sorry
  qed
qed "sorry"

mtheorem rvsum_1_cl_4:
  mlet "r be RealXREAL-0M1"
"cluster <*FINSEQ-1K10 r*> as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "<*FINSEQ-1K10 r*> be real-valuedVALUED-0V7"
  proof-
    have "<*FINSEQ-1K10 r*> be real-valuedVALUED-0V3"
    proof-
      obtain p where 
        [ty]:"p be ElementSUBSET-1M1-of REALNUMBERSK2" and pDef:"p = r"
        using xreal_0_def_1 sorry
      have "<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> p*> be FinSequence-likeFINSEQ-1V1"
         sorry
      thus "<*FINSEQ-1K10 r*> be real-valuedVALUED-0V3"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rvsum_1_cl_5:
  mlet "r1 be RealXREAL-0M1", "r2 be RealXREAL-0M1"
"cluster <*FINSEQ-1K11 r1,r2 *> as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "<*FINSEQ-1K11 r1,r2 *> be real-valuedVALUED-0V7"
  proof-
    have "<*FINSEQ-1K11 r1,r2 *> be real-valuedVALUED-0V3"
    proof-
      obtain p1 p2 where 
        [ty]:"p1 be ElementSUBSET-1M1-of REALNUMBERSK2" and p1Def:"p1 = r1" and
        [ty]:"p2 be ElementSUBSET-1M1-of REALNUMBERSK2" and p2Def:"p2 = r2"
        using xreal_0_def_1 sorry
      have "<*FINSEQ-4K2\<^bsub>(REALNUMBERSK2)\<^esub> p1,p2 *> be FinSequence-likeFINSEQ-1V1"
         sorry
      thus "<*FINSEQ-1K11 r1,r2 *> be real-valuedVALUED-0V3"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rvsum_1_cl_6:
  mlet "r1 be RealXREAL-0M1", "r2 be RealXREAL-0M1", "r3 be RealXREAL-0M1"
"cluster <*FINSEQ-1K12 r1,r2,r3 *> as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "<*FINSEQ-1K12 r1,r2,r3 *> be real-valuedVALUED-0V7"
  proof-
    have "<*FINSEQ-1K12 r1,r2,r3 *> be real-valuedVALUED-0V3"
    proof-
      obtain p1 p2 p3 where 
        [ty]:"p1 be ElementSUBSET-1M1-of REALNUMBERSK2" and p1Def:"p1 = r1" and
        [ty]:"p2 be ElementSUBSET-1M1-of REALNUMBERSK2" and p2Def:"p2 = r2" and
        [ty]:"p3 be ElementSUBSET-1M1-of REALNUMBERSK2" and p3Def:"p3 = r3"
        using xreal_0_def_1 sorry
      have "<*FINSEQ-4K3\<^bsub>(REALNUMBERSK2)\<^esub> p1,p2,p3 *> be FinSequence-likeFINSEQ-1V1"
         sorry
      thus "<*FINSEQ-1K12 r1,r2,r3 *> be real-valuedVALUED-0V3"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rvsum_1_cl_7:
  mlet "r1 be RealXREAL-0M1", "r2 be RealXREAL-0M1", "r3 be RealXREAL-0M1", "r4 be RealXREAL-0M1"
"cluster <*FINSEQ-4K7 r1,r2,r3,r4 *> as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "<*FINSEQ-4K7 r1,r2,r3,r4 *> be real-valuedVALUED-0V7"
  proof-
    have "<*FINSEQ-4K7 r1,r2,r3,r4 *> be real-valuedVALUED-0V3"
    proof-
      obtain p1 p2 p3 p4 where 
        [ty]:"p1 be ElementSUBSET-1M1-of REALNUMBERSK2" and p1Def:"p1 = r1" and
        [ty]:"p2 be ElementSUBSET-1M1-of REALNUMBERSK2" and p2Def:"p2 = r2" and
        [ty]:"p3 be ElementSUBSET-1M1-of REALNUMBERSK2" and p3Def:"p3 = r3" and
        [ty]:"p4 be ElementSUBSET-1M1-of REALNUMBERSK2" and p4Def:"p4 = r4"
        using xreal_0_def_1 sorry
      have "<*FINSEQ-4K9\<^bsub>(REALNUMBERSK2)\<^esub> p1,p2,p3,p4 *> be FinSequence-likeFINSEQ-1V1"
         sorry
      thus "<*FINSEQ-4K7 r1,r2,r3,r4 *> be real-valuedVALUED-0V3"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rvsum_1_cl_8:
  mlet "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "r be RealXREAL-0M1"
"cluster j  |->FINSEQ-2K2 r as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "j  |->FINSEQ-2K2 r be real-valuedVALUED-0V7"
     sorry
qed "sorry"

mtheorem rvsum_1_cl_9:
  mlet "f be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1", "g be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
"cluster f ^FINSEQ-1K8 g as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "f ^FINSEQ-1K8 g be real-valuedVALUED-0V7"
  proof-
    have "f ^FINSEQ-1K8 g be real-valuedVALUED-0V3"
    proof-
      have "rngFUNCT-1K2 (f ^FINSEQ-1K8 g) =XBOOLE-0R4 rngRVSUM-1K1 f \\/XBOOLE-0K2 rngRVSUM-1K1 g"
        using finseq_1_th_31 sorry
      then have "rngFUNCT-1K2 (f ^FINSEQ-1K8 g) c=TARSKIR1 REALNUMBERSK2"
        using xboole_1_th_8 sorry
      thus "f ^FINSEQ-1K8 g be real-valuedVALUED-0V3"
        using valued_0_def_3 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

reserve s for "setHIDDENM2"
reserve i, j for "naturalORDINAL1V7\<bar>NumberORDINAL1M1"
reserve k for "NatNAT-1M1"
reserve r, r1, r2, r3, r4 for "RealXREAL-0M1"
reserve F, F1, F2, F3 for "real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
reserve R, R1, R2 for "ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
mtheorem rvsum_1_th_1:
"0NUMBERSK6 is-a-unity-wrtBINOP-1R3\<^bsub>(REALNUMBERSK2)\<^esub> addrealBINOP-2K9"
  using binop_2_th_2 setwiseo_th_14 sorry

abbreviation(input) RVSUM_1K2("diffrealRVSUM-1K2" 228) where
  "diffrealRVSUM-1K2 \<equiv> diffrealBINOP-2K10"

mtheorem rvsum_1_def_1:
"redefine func diffrealRVSUM-1K2 \<rightarrow> ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 [:ZFMISC-1K2 REALNUMBERSK2,REALNUMBERSK2 :],REALNUMBERSK2 :]) equals
  (addrealBINOP-2K9)*FINSEQOPK7\<^bsub>(REALNUMBERSK2)\<^esub>(idPARTFUN1K6 REALNUMBERSK2,comprealBINOP-2K7)"
proof
(*compatibility*)
  show " for it be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 [:ZFMISC-1K2 REALNUMBERSK2,REALNUMBERSK2 :],REALNUMBERSK2 :]) holds it =HIDDENR1 diffrealRVSUM-1K2 iff it =HIDDENR1 (addrealBINOP-2K9)*FINSEQOPK7\<^bsub>(REALNUMBERSK2)\<^esub>(idPARTFUN1K6 REALNUMBERSK2,comprealBINOP-2K7)"
  proof-
    have " for b be BinOpBINOP-1M2-of REALNUMBERSK2 holds  not (b =HIDDENR1 diffrealBINOP-2K10 &  not b =HIDDENR1 (addrealBINOP-2K9)*FINSEQOPK7\<^bsub>(REALNUMBERSK2)\<^esub>(idPARTFUN1K6 REALNUMBERSK2,comprealBINOP-2K7)) &  not (b =HIDDENR1 (addrealBINOP-2K9)*FINSEQOPK7\<^bsub>(REALNUMBERSK2)\<^esub>(idPARTFUN1K6 REALNUMBERSK2,comprealBINOP-2K7) &  not b =HIDDENR1 diffrealBINOP-2K10)"
    proof(rule ballI)
      fix b assume [ty]: "b be BinOpBINOP-1M2-of REALNUMBERSK2"
      have " for r1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for r2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds diffrealBINOP-2K10 .BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r1,r2) =HIDDENR1 ((addrealBINOP-2K9)*FINSEQOPK7\<^bsub>(REALNUMBERSK2)\<^esub>(idPARTFUN1K6 REALNUMBERSK2,comprealBINOP-2K7)).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r1,r2)"
      proof(rule ballI,rule ballI)
        fix r1 assume [ty]: "r1 be ElementSUBSET-1M1-of REALNUMBERSK2"
        fix r2 assume [ty]: "r2 be ElementSUBSET-1M1-of REALNUMBERSK2"
        have "diffrealBINOP-2K10 .BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r1,r2) =HIDDENR1 r1 -REAL-1K5 r2"
          using binop_2_def_10 sorry
        also have "... = r1 +REAL-1K3 (-REAL-1K1 r2)"
           sorry
        also have "... = (addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r1,-REAL-1K1 r2)"
          using binop_2_def_9 sorry
        also have "... = (addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r1,(comprealBINOP-2K7).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r2)"
          using binop_2_def_7 sorry
        also have "... = ((addrealBINOP-2K9)*FINSEQOPK7\<^bsub>(REALNUMBERSK2)\<^esub>(idPARTFUN1K6 REALNUMBERSK2,comprealBINOP-2K7)).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r1,r2)"
          using finseqop_th_82 sorry
        finally show "diffrealBINOP-2K10 .BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r1,r2) =HIDDENR1 ((addrealBINOP-2K9)*FINSEQOPK7\<^bsub>(REALNUMBERSK2)\<^esub>(idPARTFUN1K6 REALNUMBERSK2,comprealBINOP-2K7)).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(r1,r2)"
           sorry
      qed "sorry"
      thus " not (b =HIDDENR1 diffrealBINOP-2K10 &  not b =HIDDENR1 (addrealBINOP-2K9)*FINSEQOPK7\<^bsub>(REALNUMBERSK2)\<^esub>(idPARTFUN1K6 REALNUMBERSK2,comprealBINOP-2K7)) &  not (b =HIDDENR1 (addrealBINOP-2K9)*FINSEQOPK7\<^bsub>(REALNUMBERSK2)\<^esub>(idPARTFUN1K6 REALNUMBERSK2,comprealBINOP-2K7) &  not b =HIDDENR1 diffrealBINOP-2K10)"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef rvsum_1_def_2 ("sqrrealRVSUM-1K3" 228 ) where
"func sqrrealRVSUM-1K3 \<rightarrow> UnOpBINOP-1M1-of REALNUMBERSK2 means
  \<lambda>it.  for r be RealXREAL-0M1 holds it .FUNCT-1K1 r =XBOOLE-0R4 r ^2SQUARE-1K1"
proof-
  (*existence*)
    show " ex it be UnOpBINOP-1M1-of REALNUMBERSK2 st  for r be RealXREAL-0M1 holds it .FUNCT-1K1 r =XBOOLE-0R4 r ^2SQUARE-1K1"
    proof-
      have " ex tVar3 be UnOpBINOP-1M1-of REALNUMBERSK2 st  for r be RealXREAL-0M1 holds tVar3 .FUNCT-1K1 r =XBOOLE-0R4 r ^2SQUARE-1K1"
      proof-
        let ?F = "\<lambda>Lamb1. InSUBSET-1K10(Lamb1 ^2SQUARE-1K1,REALNUMBERSK2)"
        obtain G where
          [ty]:"G be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
          A1: " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds G .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x =XBOOLE-0R4 ?F(x)"
          using funct_2_sch_4 sorry
        show " ex tVar3 be UnOpBINOP-1M1-of REALNUMBERSK2 st  for r be RealXREAL-0M1 holds tVar3 .FUNCT-1K1 r =XBOOLE-0R4 r ^2SQUARE-1K1"
        proof(rule bexI[of _ "G"],rule ballI)
          fix r assume [ty]: "r be RealXREAL-0M1"
          have "r inHIDDENR3 REALNUMBERSK2"
            using xreal_0_def_1 sorry
          then have "G .FUNCT-1K1 r =XBOOLE-0R4 ?F(r)"
            using A1 sorry
          thus "G .FUNCT-1K1 r =XBOOLE-0R4 r ^2SQUARE-1K1"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be UnOpBINOP-1M1-of REALNUMBERSK2 holds  for it2 be UnOpBINOP-1M1-of REALNUMBERSK2 holds ( for r be RealXREAL-0M1 holds it1 .FUNCT-1K1 r =XBOOLE-0R4 r ^2SQUARE-1K1) & ( for r be RealXREAL-0M1 holds it2 .FUNCT-1K1 r =XBOOLE-0R4 r ^2SQUARE-1K1) implies it1 =HIDDENR1 it2"
    proof-
      have " for G1 be UnOpBINOP-1M1-of REALNUMBERSK2 holds  for G2 be UnOpBINOP-1M1-of REALNUMBERSK2 holds ( for r be RealXREAL-0M1 holds G1 .FUNCT-1K1 r =XBOOLE-0R4 r ^2SQUARE-1K1) & ( for r be RealXREAL-0M1 holds G2 .FUNCT-1K1 r =XBOOLE-0R4 r ^2SQUARE-1K1) implies G1 =HIDDENR1 G2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix G1 assume [ty]: "G1 be UnOpBINOP-1M1-of REALNUMBERSK2"
        fix G2 assume [ty]: "G2 be UnOpBINOP-1M1-of REALNUMBERSK2"
        assume A2: " for r be RealXREAL-0M1 holds G1 .FUNCT-1K1 r =XBOOLE-0R4 r ^2SQUARE-1K1"
          and A3: " for r be RealXREAL-0M1 holds G2 .FUNCT-1K1 r =XBOOLE-0R4 r ^2SQUARE-1K1"
        have " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds G1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x =XBOOLE-0R4 G2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x"
        proof(rule ballI)
          fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
          have "G1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x =XBOOLE-0R4 x ^2SQUARE-1K1"
            using A2 sorry
          thus "G1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x =XBOOLE-0R4 G2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x"
            using A3 sorry
        qed "sorry"
        thus "G1 =HIDDENR1 G2"
          using funct_2_th_63 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem rvsum_1_th_2:
"\<one>\<^sub>M is-a-unity-wrtBINOP-1R3\<^bsub>(REALNUMBERSK2)\<^esub> multrealBINOP-2K11"
  using binop_2_th_7 setwiseo_th_14 sorry

mtheorem rvsum_1_th_3:
"multrealBINOP-2K11 is-distributive-wrtBINOP-1R6\<^bsub>(REALNUMBERSK2)\<^esub> addrealBINOP-2K9"
proof-
  have " for x1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for x2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for x3 be ElementSUBSET-1M1-of REALNUMBERSK2 holds (multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x1,(addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x2,x3)) =HIDDENR1 (addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>((multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x1,x2),(multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x1,x3)) & (multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>((addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x1,x2),x3) =HIDDENR1 (addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>((multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x1,x3),(multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x2,x3))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix x1 assume [ty]: "x1 be ElementSUBSET-1M1-of REALNUMBERSK2"
    fix x2 assume [ty]: "x2 be ElementSUBSET-1M1-of REALNUMBERSK2"
    fix x3 assume [ty]: "x3 be ElementSUBSET-1M1-of REALNUMBERSK2"
    have "(multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x1,(addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x2,x3)) =HIDDENR1 (multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x1,x2 +REAL-1K3 x3)"
      using binop_2_def_9 sorry
    also have "... = x1 *REAL-1K4 (x2 +REAL-1K3 x3)"
      using binop_2_def_11 sorry
    also have "... = x1 *REAL-1K4 x2 +REAL-1K3 x1 *REAL-1K4 x3"
       sorry
    also have "... = (addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x1 *REAL-1K4 x2,x1 *REAL-1K4 x3)"
      using binop_2_def_9 sorry
    also have "... = (addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>((multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x1,x2),x1 *REAL-1K4 x3)"
      using binop_2_def_11 sorry
    also have "... = (addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>((multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x1,x2),(multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x1,x3))"
      using binop_2_def_11 sorry
    finally show "(multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x1,(addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x2,x3)) =HIDDENR1 (addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>((multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x1,x2),(multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x1,x3))"
       sorry
    have "(multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>((addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x1,x2),x3) =HIDDENR1 (multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x1 +REAL-1K3 x2,x3)"
      using binop_2_def_9 sorry
    also have "... = (x1 +REAL-1K3 x2)*REAL-1K4 x3"
      using binop_2_def_11 sorry
    also have "... = x1 *REAL-1K4 x3 +REAL-1K3 x2 *REAL-1K4 x3"
       sorry
    also have "... = (addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x1 *REAL-1K4 x3,x2 *REAL-1K4 x3)"
      using binop_2_def_9 sorry
    also have "... = (addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>((multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x1,x3),x2 *REAL-1K4 x3)"
      using binop_2_def_11 sorry
    also have "... = (addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>((multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x1,x3),(multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x2,x3))"
      using binop_2_def_11 sorry
    finally show "(multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>((addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x1,x2),x3) =HIDDENR1 (addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>((multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x1,x3),(multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x2,x3))"
       sorry
  qed "sorry"
  thus "multrealBINOP-2K11 is-distributive-wrtBINOP-1R6\<^bsub>(REALNUMBERSK2)\<^esub> addrealBINOP-2K9"
    using binop_1_th_11 sorry
qed

mtheorem rvsum_1_th_4:
"sqrrealRVSUM-1K3 is-distributive-wrtBINOP-1R12\<^bsub>(REALNUMBERSK2)\<^esub> multrealBINOP-2K11"
proof-
  have " for x1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for x2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds sqrrealRVSUM-1K3 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x1,x2)) =HIDDENR1 (multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(sqrrealRVSUM-1K3 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x1,sqrrealRVSUM-1K3 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x2)"
  proof(rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be ElementSUBSET-1M1-of REALNUMBERSK2"
    fix x2 assume [ty]: "x2 be ElementSUBSET-1M1-of REALNUMBERSK2"
    have "sqrrealRVSUM-1K3 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x1,x2)) =HIDDENR1 sqrrealRVSUM-1K3 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (x1 *REAL-1K4 x2)"
      using binop_2_def_11 sorry
    also have "... = (x1 *REAL-1K4 x2)^2SQUARE-1K1"
      using rvsum_1_def_2 sorry
    also have "... = x1 ^2SQUARE-1K1 *XCMPLX-0K3 x2 ^2SQUARE-1K1"
       sorry
    also have "... = (multrealBINOP-2K11).BINOP-1K1(x1 ^2SQUARE-1K1,x2 ^2SQUARE-1K1)"
      using binop_2_def_11 sorry
    also have "... = (multrealBINOP-2K11).BINOP-1K1(sqrrealRVSUM-1K3 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x1,x2 ^2SQUARE-1K1)"
      using rvsum_1_def_2 sorry
    also have "... = (multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(sqrrealRVSUM-1K3 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x1,sqrrealRVSUM-1K3 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x2)"
      using rvsum_1_def_2 sorry
    finally show "sqrrealRVSUM-1K3 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x1,x2)) =HIDDENR1 (multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(sqrrealRVSUM-1K3 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x1,sqrrealRVSUM-1K3 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x2)"
       sorry
  qed "sorry"
  thus "sqrrealRVSUM-1K3 is-distributive-wrtBINOP-1R12\<^bsub>(REALNUMBERSK2)\<^esub> multrealBINOP-2K11"
    using binop_1_def_20 sorry
qed

mdef rvsum_1_def_3 (" _ multrealRVSUM-1K4" [164]164 ) where
  mlet "x be RealXREAL-0M1"
"func x multrealRVSUM-1K4 \<rightarrow> UnOpBINOP-1M1-of REALNUMBERSK2 equals
  (multrealBINOP-2K11)[;]FUNCOP-1K5(x,idPARTFUN1K6 REALNUMBERSK2)"
proof-
  (*coherence*)
    show "(multrealBINOP-2K11)[;]FUNCOP-1K5(x,idPARTFUN1K6 REALNUMBERSK2) be UnOpBINOP-1M1-of REALNUMBERSK2"
    proof-
      obtain y where 
        [ty]:"y be ElementSUBSET-1M1-of REALNUMBERSK2" and yDef:"y = x"
        using xreal_0_def_1 sorry
      have "(multrealBINOP-2K11)[;]FUNCOP-1K10\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>(y,idPARTFUN1K6 REALNUMBERSK2) be UnOpBINOP-1M1-of REALNUMBERSK2"
         sorry
      thus "(multrealBINOP-2K11)[;]FUNCOP-1K5(x,idPARTFUN1K6 REALNUMBERSK2) be UnOpBINOP-1M1-of REALNUMBERSK2"
         sorry
    qed
qed "sorry"

mlemma rvsum_1_lm_1:
" for r be RealXREAL-0M1 holds  for r1 be RealXREAL-0M1 holds ((multrealBINOP-2K11)[;]FUNCOP-1K5(r,idPARTFUN1K6 REALNUMBERSK2)).FUNCT-1K1 r1 =XBOOLE-0R4 r *XCMPLX-0K3 r1"
proof-
  have " for r be RealXREAL-0M1 holds  for r1 be RealXREAL-0M1 holds ((multrealBINOP-2K11)[;]FUNCOP-1K5(r,idPARTFUN1K6 REALNUMBERSK2)).FUNCT-1K1 r1 =HIDDENR1 r *XCMPLX-0K3 r1"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix r1 assume [ty]: "r1 be RealXREAL-0M1"
    obtain a s where 
      [ty]:"a be ElementSUBSET-1M1-of REALNUMBERSK2" and aDef:"a = r" and
      [ty]:"s be ElementSUBSET-1M1-of REALNUMBERSK2" and sDef:"s = r1"
      using xreal_0_def_1 sorry
    have "((multrealBINOP-2K11)[;]FUNCOP-1K5(r,idPARTFUN1K6 REALNUMBERSK2)).FUNCT-1K1 r1 =HIDDENR1 (multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(a,idPARTFUN1K6 REALNUMBERSK2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> s)"
      using funcop_1_th_53 sorry
    also have "... = (multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(a,s)"
       sorry
    also have "... = r *XCMPLX-0K3 r1"
      using binop_2_def_11 sorry
    finally show "((multrealBINOP-2K11)[;]FUNCOP-1K5(r,idPARTFUN1K6 REALNUMBERSK2)).FUNCT-1K1 r1 =HIDDENR1 r *XCMPLX-0K3 r1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_5:
" for r be RealXREAL-0M1 holds  for r1 be RealXREAL-0M1 holds (r multrealRVSUM-1K4).FUNCT-1K1 r1 =XBOOLE-0R4 r *XCMPLX-0K3 r1"
  using rvsum_1_lm_1 sorry

mtheorem rvsum_1_th_6:
" for r be RealXREAL-0M1 holds r multrealRVSUM-1K4 is-distributive-wrtBINOP-1R12\<^bsub>(REALNUMBERSK2)\<^esub> addrealBINOP-2K9"
proof-
  have " for r be RealXREAL-0M1 holds r multrealRVSUM-1K4 is-distributive-wrtBINOP-1R12\<^bsub>(REALNUMBERSK2)\<^esub> addrealBINOP-2K9"
  proof(rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    have "r inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    thus "r multrealRVSUM-1K4 is-distributive-wrtBINOP-1R12\<^bsub>(REALNUMBERSK2)\<^esub> addrealBINOP-2K9"
      using rvsum_1_th_3 finseqop_th_54 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_7:
"comprealBINOP-2K7 is-an-inverseOp-wrtFINSEQOPR1\<^bsub>(REALNUMBERSK2)\<^esub> addrealBINOP-2K9"
proof-
  have " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds (addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x,(comprealBINOP-2K7).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x) =HIDDENR1 the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> (addrealBINOP-2K9) & (addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>((comprealBINOP-2K7).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x,x) =HIDDENR1 the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> (addrealBINOP-2K9)"
  proof(rule ballI,rule conjMI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
    have "(addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x,(comprealBINOP-2K7).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x) =HIDDENR1 x +REAL-1K3 (comprealBINOP-2K7).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x"
      using binop_2_def_9 sorry
    also have "... = x +REAL-1K3 (-REAL-1K1 x)"
      using binop_2_def_7 sorry
    also have "... = the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> (addrealBINOP-2K9)"
      using binop_2_th_2 sorry
    finally show "(addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x,(comprealBINOP-2K7).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x) =HIDDENR1 the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> (addrealBINOP-2K9)"
       sorry
    have "(addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>((comprealBINOP-2K7).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x,x) =HIDDENR1 (comprealBINOP-2K7).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x +REAL-1K3 x"
      using binop_2_def_9 sorry
    also have "... = (-REAL-1K1 x)+REAL-1K3 x"
      using binop_2_def_7 sorry
    also have "... = the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> (addrealBINOP-2K9)"
      using binop_2_th_2 sorry
    finally show "(addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>((comprealBINOP-2K7).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x,x) =HIDDENR1 the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> (addrealBINOP-2K9)"
       sorry
  qed "sorry"
  thus "comprealBINOP-2K7 is-an-inverseOp-wrtFINSEQOPR1\<^bsub>(REALNUMBERSK2)\<^esub> addrealBINOP-2K9"
    using finseqop_def_1 sorry
qed

mtheorem rvsum_1_th_8:
"addrealBINOP-2K9 be having-an-inverseOpFINSEQOPV1\<^bsub>(REALNUMBERSK2)\<^esub>"
  using rvsum_1_th_7 sorry

mtheorem rvsum_1_th_9:
"the-inverseOp-wrtFINSEQOPK5\<^bsub>(REALNUMBERSK2)\<^esub> (addrealBINOP-2K9) =FUNCT-2R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7"
  using rvsum_1_th_7 rvsum_1_th_8 finseqop_def_3 sorry

mtheorem rvsum_1_th_10:
"comprealBINOP-2K7 is-distributive-wrtBINOP-1R12\<^bsub>(REALNUMBERSK2)\<^esub> addrealBINOP-2K9"
  using rvsum_1_th_8 rvsum_1_th_9 finseqop_th_63 sorry

mlemma rvsum_1_lm_2:
" for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
proof-
  have " for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
  proof(rule ballI)
    fix F assume [ty]: "F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    have "rngRVSUM-1K1 F c=TARSKIR1 REALNUMBERSK2"
    proof-
      show "rngRVSUM-1K1 F c=TARSKIR1 REALNUMBERSK2"
         sorry
    qed
    thus "F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
      using finseq_1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) RVSUM_1K5(" _ +RVSUM-1K5  _ " [132,132]132) where
  "F1 +RVSUM-1K5 F2 \<equiv> F1 +VALUED-1K1 F2"

mtheorem rvsum_1_def_4:
  mlet "F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1", "F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
"redefine func F1 +RVSUM-1K5 F2 \<rightarrow> FinSequenceFINSEQ-1M3-of REALNUMBERSK2 equals
  (addrealBINOP-2K9).:FUNCOP-1K3(F1,F2)"
proof
(*compatibility*)
  show " for it be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds it =HIDDENR1 F1 +RVSUM-1K5 F2 iff it =HIDDENR1 (addrealBINOP-2K9).:FUNCOP-1K3(F1,F2)"
  proof-
    have " for F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (F =FINSEQ-1R1 F1 +VALUED-1K1 F2 implies F =FUNCT-1R1 (addrealBINOP-2K9).:FUNCOP-1K3(F1,F2)) & (F =FUNCT-1R1 (addrealBINOP-2K9).:FUNCOP-1K3(F1,F2) implies F =HIDDENR1 F1 +VALUED-1K1 F2)"
    proof(rule ballI,rule conjMI,rule impI)
      obtain F3 F4 where 
        [ty]:"F3 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2" and F3Def:"F3 = F1" and
        [ty]:"F4 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2" and F4Def:"F4 = F2"
        using rvsum_1_lm_2 sorry
      fix F assume [ty]: "F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
      have "domRELAT-1K1 (addrealBINOP-2K9) =XBOOLE-0R4 [:ZFMISC-1K2 REALNUMBERSK2,REALNUMBERSK2 :]"
        using funct_2_def_1 sorry
      then have "[:ZFMISC-1K2 rngRVSUM-1K1 F3,rngRVSUM-1K1 F4 :] c=RELAT-1R2 domRELAT-1K1 (addrealBINOP-2K9)"
        using zfmisc_1_th_96 sorry
      then have A1: "domRELAT-1K1 ((addrealBINOP-2K9).:FUNCOP-1K3(F1,F2)) =XBOOLE-0R4 domFINSEQ-1K5 F1 /\\XBOOLE-0K3 domFINSEQ-1K5 F2"
        using funcop_1_th_69 sorry
      have A2: "domFINSEQ-1K5 (F1 +VALUED-1K1 F2) =XBOOLE-0R4 domFINSEQ-1K5 F1 /\\XBOOLE-0K3 domFINSEQ-1K5 F2"
        using valued_1_def_1 sorry
      show "F =FINSEQ-1R1 F1 +VALUED-1K1 F2 implies F =FUNCT-1R1 (addrealBINOP-2K9).:FUNCOP-1K3(F1,F2)"
      proof(rule impI)
        assume A3: "F =FINSEQ-1R1 F1 +VALUED-1K1 F2"
        have " for z be setHIDDENM2 holds z inTARSKIR2 domRELAT-1K1 ((addrealBINOP-2K9).:FUNCOP-1K3(F1,F2)) implies F .FUNCT-1K1 z =XBOOLE-0R4 (addrealBINOP-2K9).BINOP-1K1(F1 .FUNCT-1K1 z,F2 .FUNCT-1K1 z)"
        proof-
          have " for z be setHIDDENM2 holds z inTARSKIR2 domRELAT-1K1 ((addrealBINOP-2K9).:FUNCOP-1K3(F1,F2)) implies F .FUNCT-1K1 z =HIDDENR1 (addrealBINOP-2K9).BINOP-1K1(F1 .FUNCT-1K1 z,F2 .FUNCT-1K1 z)"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be setHIDDENM2"
            assume "z inTARSKIR2 domRELAT-1K1 ((addrealBINOP-2K9).:FUNCOP-1K3(F1,F2))"
            then have "F .FUNCT-1K1 z =HIDDENR1 F1 .FUNCT-1K1 z +XCMPLX-0K2 F2 .FUNCT-1K1 z"
              using A2 A1 A3 valued_1_def_1 sorry
            also have "... = (addrealBINOP-2K9).BINOP-1K1(F1 .FUNCT-1K1 z,F2 .FUNCT-1K1 z)"
              using binop_2_def_9 sorry
            finally show "F .FUNCT-1K1 z =HIDDENR1 (addrealBINOP-2K9).BINOP-1K1(F1 .FUNCT-1K1 z,F2 .FUNCT-1K1 z)"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "F =FUNCT-1R1 (addrealBINOP-2K9).:FUNCOP-1K3(F1,F2)"
          using A2 A1 A3 funcop_1_th_21 sorry
      qed
      assume A4: "F =FUNCT-1R1 (addrealBINOP-2K9).:FUNCOP-1K3(F1,F2)"
      have " for c be objectHIDDENM1 holds c inHIDDENR3 domFINSEQ-1K5 F implies F .FUNCT-1K1 c =HIDDENR1 F1 .FUNCT-1K1 c +XCMPLX-0K2 F2 .FUNCT-1K1 c"
      proof(rule ballI,rule impI)
        fix c assume [ty]: "c be objectHIDDENM1"
        assume "c inHIDDENR3 domFINSEQ-1K5 F"
        then have "F .FUNCT-1K1 c =HIDDENR1 (addrealBINOP-2K9).BINOP-1K1(F1 .FUNCT-1K1 c,F2 .FUNCT-1K1 c)"
          using A4 funcop_1_th_22 sorry
        also have "... = F1 .FUNCT-1K1 c +XCMPLX-0K2 F2 .FUNCT-1K1 c"
          using binop_2_def_9 sorry
        finally show "F .FUNCT-1K1 c =HIDDENR1 F1 .FUNCT-1K1 c +XCMPLX-0K2 F2 .FUNCT-1K1 c"
           sorry
      qed "sorry"
      thus "F =HIDDENR1 F1 +VALUED-1K1 F2"
        using A1 A4 valued_1_def_1 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rvsum_1_add_2:
  mlet "F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1", "F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
"cluster F1 +VALUED-1K1 F2 as-term-is FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
proof
(*coherence*)
  show "F1 +VALUED-1K1 F2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    using rvsum_1_lm_2 sorry
qed "sorry"

mtheorem RVSUM_1K5_commutativity:
" for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds F1 +RVSUM-1K5 F2 =HIDDENR1 F2 +RVSUM-1K5 F1"
proof-
  have " for it be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds it =HIDDENR1 F1 +RVSUM-1K5 F2 implies it =HIDDENR1 F2 +RVSUM-1K5 F1"
  proof-
    have " for it be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds it =HIDDENR1 (addrealBINOP-2K9).:FUNCOP-1K3(F1,F2) implies it =HIDDENR1 (addrealBINOP-2K9).:FUNCOP-1K3(F2,F1)"
    proof-
      have " for F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds F =FUNCT-1R1 (addrealBINOP-2K9).:FUNCOP-1K3(F1,F2) implies F =HIDDENR1 (addrealBINOP-2K9).:FUNCOP-1K3(F2,F1)"
      proof(rule ballI,rule ballI,rule ballI,rule impI)
        fix F assume [ty]: "F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
        fix F1 assume [ty]: "F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
        fix F2 assume [ty]: "F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
        assume A5: "F =FUNCT-1R1 (addrealBINOP-2K9).:FUNCOP-1K3(F1,F2)"
        have 
          [ty]:"F1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2" and
          [ty]:"F2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
          using rvsum_1_lm_2 sorry
        have A6: "domRELAT-1K1 (addrealBINOP-2K9) =XBOOLE-0R4 [:ZFMISC-1K2 REALNUMBERSK2,REALNUMBERSK2 :]"
          using funct_2_def_1 sorry
        then have A7: "[:ZFMISC-1K2 rngRVSUM-1K1 F2,rngRVSUM-1K1 F1 :] c=RELAT-1R2 domRELAT-1K1 (addrealBINOP-2K9)"
          using zfmisc_1_th_96 sorry
        have "[:ZFMISC-1K2 rngRVSUM-1K1 F1,rngRVSUM-1K1 F2 :] c=RELAT-1R2 domRELAT-1K1 (addrealBINOP-2K9)"
          using A6 zfmisc_1_th_96 sorry
        then have A8: "domFINSEQ-1K5 ((addrealBINOP-2K9).:FINSEQOPK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub>(F1,F2)) =HIDDENR1 domFINSEQ-1K5 F1 /\\XBOOLE-0K3 domFINSEQ-1K5 F2"
          using funcop_1_th_69 sorry
        also have "... = domFINSEQ-1K5 ((addrealBINOP-2K9).:FINSEQOPK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub>(F2,F1))"
          using A7 funcop_1_th_69 sorry
        finally have "domFINSEQ-1K5 ((addrealBINOP-2K9).:FINSEQOPK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub>(F1,F2)) =HIDDENR1 domFINSEQ-1K5 ((addrealBINOP-2K9).:FINSEQOPK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub>(F2,F1))"
           sorry
        have " for z be setHIDDENM2 holds z inTARSKIR2 domFINSEQ-1K5 ((addrealBINOP-2K9).:FINSEQOPK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub>(F2,F1)) implies F .FUNCT-1K1 z =XBOOLE-0R4 (addrealBINOP-2K9).BINOP-1K1(F2 .FUNCT-1K1 z,F1 .FUNCT-1K1 z)"
        proof-
          have " for z be setHIDDENM2 holds z inTARSKIR2 domFINSEQ-1K5 ((addrealBINOP-2K9).:FINSEQOPK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub>(F2,F1)) implies F .FUNCT-1K1 z =HIDDENR1 (addrealBINOP-2K9).BINOP-1K1(F2 .FUNCT-1K1 z,F1 .FUNCT-1K1 z)"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be setHIDDENM2"
            assume "z inTARSKIR2 domFINSEQ-1K5 ((addrealBINOP-2K9).:FINSEQOPK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub>(F2,F1))"
            then have "F .FUNCT-1K1 z =HIDDENR1 (addrealBINOP-2K9).BINOP-1K1(F1 .FUNCT-1K1 z,F2 .FUNCT-1K1 z)"
              using A5 A8 funcop_1_th_22 sorry
            also have "... = F1 .FUNCT-1K1 z +XCMPLX-0K2 F2 .FUNCT-1K1 z"
              using binop_2_def_9 sorry
            also have "... = (addrealBINOP-2K9).BINOP-1K1(F2 .FUNCT-1K1 z,F1 .FUNCT-1K1 z)"
              using binop_2_def_9 sorry
            finally show "F .FUNCT-1K1 z =HIDDENR1 (addrealBINOP-2K9).BINOP-1K1(F2 .FUNCT-1K1 z,F1 .FUNCT-1K1 z)"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "F =HIDDENR1 (addrealBINOP-2K9).:FUNCOP-1K3(F2,F1)"
          using A5 A8 funcop_1_th_21 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus " ?thesis "
      using rvsum_1_def_4 sorry
  qed
  thus " ?thesis "
     sorry
qed

syntax RVSUM_1K6 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ +RVSUM-1K6\<^bsub>'( _ ')\<^esub>  _ " [132,0,132]132)
translations "R1 +RVSUM-1K6\<^bsub>(i)\<^esub> R2" \<rightharpoonup> "R1 +VALUED-1K1 R2"

mtheorem rvsum_1_add_3:
  mlet "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2", "R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
"cluster R1 +VALUED-1K1 R2 as-term-is ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
proof
(*coherence*)
  show "R1 +VALUED-1K1 R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    using finseq_2_th_120 sorry
qed "sorry"

mtheorem rvsum_1_th_11:
" for s be setHIDDENM2 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds (R1 +RVSUM-1K6\<^bsub>(i)\<^esub> R2).FUNCT-1K1 s =XBOOLE-0R4 R1 .FUNCT-1K1 s +XCMPLX-0K2 R2 .FUNCT-1K1 s"
proof-
  have " for s be setHIDDENM2 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds (R1 +RVSUM-1K6\<^bsub>(i)\<^esub> R2).FUNCT-1K1 s =HIDDENR1 R1 .FUNCT-1K1 s +XCMPLX-0K2 R2 .FUNCT-1K1 s"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix s assume [ty]: "s be setHIDDENM2"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix R1 assume [ty]: "R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    fix R2 assume [ty]: "R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    show "(R1 +RVSUM-1K6\<^bsub>(i)\<^esub> R2).FUNCT-1K1 s =HIDDENR1 R1 .FUNCT-1K1 s +XCMPLX-0K2 R2 .FUNCT-1K1 s"
    proof-
      have cases: " not s inTARSKIR2 SegFINSEQ-1K1 i or s inTARSKIR2 SegFINSEQ-1K1 i"
         sorry
      have case1: " not s inTARSKIR2 SegFINSEQ-1K1 i implies (R1 +RVSUM-1K6\<^bsub>(i)\<^esub> R2).FUNCT-1K1 s =HIDDENR1 R1 .FUNCT-1K1 s +XCMPLX-0K2 R2 .FUNCT-1K1 s"
      proof(rule impI)
        assume A1: " not s inTARSKIR2 SegFINSEQ-1K1 i"
        then have A2: " not s inTARSKIR2 domFINSEQ-1K5 R2"
          using finseq_2_th_124 sorry
        have A3: " not s inTARSKIR2 domFINSEQ-1K5 R1"
          using A1 finseq_2_th_124 sorry
        have " not s inTARSKIR2 domFINSEQ-1K5 (R1 +RVSUM-1K6\<^bsub>(i)\<^esub> R2)"
          using A1 finseq_2_th_124 sorry
        then have "(R1 +RVSUM-1K6\<^bsub>(i)\<^esub> R2).FUNCT-1K1 s =HIDDENR1 0NUMBERSK6 +NAT-1K1 0NUMBERSK6"
          using funct_1_def_2 sorry
        also have "... = R1 .FUNCT-1K1 s +XCMPLX-0K2 0NUMBERSK6"
          using A3 funct_1_def_2 sorry
        also have "... = R1 .FUNCT-1K1 s +XCMPLX-0K2 R2 .FUNCT-1K1 s"
          using A2 funct_1_def_2 sorry
        finally show "(R1 +RVSUM-1K6\<^bsub>(i)\<^esub> R2).FUNCT-1K1 s =HIDDENR1 R1 .FUNCT-1K1 s +XCMPLX-0K2 R2 .FUNCT-1K1 s"
           sorry
      qed
      have case2: "s inTARSKIR2 SegFINSEQ-1K1 i implies (R1 +RVSUM-1K6\<^bsub>(i)\<^esub> R2).FUNCT-1K1 s =XBOOLE-0R4 R1 .FUNCT-1K1 s +XCMPLX-0K2 R2 .FUNCT-1K1 s"
      proof(rule impI)
        assume "s inTARSKIR2 SegFINSEQ-1K1 i"
        then have "s inTARSKIR2 domFINSEQ-1K5 (R1 +RVSUM-1K6\<^bsub>(i)\<^esub> R2)"
          using finseq_2_th_124 sorry
        thus "(R1 +RVSUM-1K6\<^bsub>(i)\<^esub> R2).FUNCT-1K1 s =XBOOLE-0R4 R1 .FUNCT-1K1 s +XCMPLX-0K2 R2 .FUNCT-1K1 s"
          using valued_1_def_1 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_12:
" for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds <*>FINSEQ-1K7 REALNUMBERSK2 +RVSUM-1K5 F =FINSEQ-1R1 <*>FINSEQ-1K7 REALNUMBERSK2"
proof-
  have " for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds <*>FINSEQ-1K7 REALNUMBERSK2 +RVSUM-1K5 F =FINSEQ-1R1 <*>FINSEQ-1K7 REALNUMBERSK2"
  proof(rule ballI)
    fix F assume [ty]: "F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    have "F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
      using rvsum_1_lm_2 sorry
    thus "<*>FINSEQ-1K7 REALNUMBERSK2 +RVSUM-1K5 F =FINSEQ-1R1 <*>FINSEQ-1K7 REALNUMBERSK2"
      using finseq_2_th_73 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_13:
" for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds <*FINSEQ-1K10 r1*> +RVSUM-1K5 <*FINSEQ-1K10 r2*> =FINSEQ-1R1 <*FINSEQ-1K10 r1 +XCMPLX-0K2 r2 *>"
proof-
  have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds <*FINSEQ-1K10 r1*> +RVSUM-1K5 <*FINSEQ-1K10 r2*> =FINSEQ-1R1 <*FINSEQ-1K10 r1 +XCMPLX-0K2 r2 *>"
  proof(rule ballI,rule ballI)
    fix r1 assume [ty]: "r1 be RealXREAL-0M1"
    fix r2 assume [ty]: "r2 be RealXREAL-0M1"
    obtain s1 s2 where 
      [ty]:"s1 be ElementSUBSET-1M1-of REALNUMBERSK2" and s1Def:"s1 = r1" and
      [ty]:"s2 be ElementSUBSET-1M1-of REALNUMBERSK2" and s2Def:"s2 = r2"
      using xreal_0_def_1 sorry
    have "<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> s1*> +RVSUM-1K5 <*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> s2*> =HIDDENR1 <*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> (addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(s1,s2)*>"
      using finseq_2_th_74 sorry
    also have "... = <*FINSEQ-1K10 r1 +XCMPLX-0K2 r2 *>"
      using binop_2_def_9 sorry
    finally have "<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> s1*> +RVSUM-1K5 <*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> s2*> =HIDDENR1 <*FINSEQ-1K10 r1 +XCMPLX-0K2 r2 *>"
       sorry
    thus "<*FINSEQ-1K10 r1*> +RVSUM-1K5 <*FINSEQ-1K10 r2*> =FINSEQ-1R1 <*FINSEQ-1K10 r1 +XCMPLX-0K2 r2 *>"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_14:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds i  |->FINSEQ-2K2 r1 +RVSUM-1K5 i  |->FINSEQ-2K2 r2 =FINSEQ-1R1 i  |->FINSEQ-2K2 (r1 +XCMPLX-0K2 r2)"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds i  |->FINSEQ-2K2 r1 +RVSUM-1K5 i  |->FINSEQ-2K2 r2 =FINSEQ-1R1 i  |->FINSEQ-2K2 (r1 +XCMPLX-0K2 r2)"
  proof(rule ballI,rule ballI,rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix r1 assume [ty]: "r1 be RealXREAL-0M1"
    fix r2 assume [ty]: "r2 be RealXREAL-0M1"
    obtain s1 s2 where 
      [ty]:"s1 be ElementSUBSET-1M1-of REALNUMBERSK2" and s1Def:"s1 = r1" and
      [ty]:"s2 be ElementSUBSET-1M1-of REALNUMBERSK2" and s2Def:"s2 = r2"
      using xreal_0_def_1 sorry
    have "i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s1 +RVSUM-1K6\<^bsub>(i)\<^esub> i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s2 =HIDDENR1 i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> (addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(s1,s2)"
      using finseqop_th_17 sorry
    also have "... = i  |->FINSEQ-2K2 (r1 +XCMPLX-0K2 r2)"
      using binop_2_def_9 sorry
    finally have "i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s1 +RVSUM-1K6\<^bsub>(i)\<^esub> i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s2 =HIDDENR1 i  |->FINSEQ-2K2 (r1 +XCMPLX-0K2 r2)"
       sorry
    thus "i  |->FINSEQ-2K2 r1 +RVSUM-1K5 i  |->FINSEQ-2K2 r2 =FINSEQ-1R1 i  |->FINSEQ-2K2 (r1 +XCMPLX-0K2 r2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_15:
" for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F3 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds F1 +RVSUM-1K5 (F2 +RVSUM-1K5 F3) =FINSEQ-1R1 (F1 +RVSUM-1K5 F2)+RVSUM-1K5 F3"
  using rfunct_1_th_8 sorry

mtheorem rvsum_1_th_16:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds R +RVSUM-1K5 i  |->FINSEQ-2K2 (0NUMBERSK6) =FINSEQ-1R1 R"
  using binop_2_th_2 finseqop_th_56 sorry

mtheorem rvsum_1_th_17:
" for s be setHIDDENM2 holds  for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds (-VALUED-1K32 F).FUNCT-1K1 s =HIDDENR1 -XCMPLX-0K4 F .FUNCT-1K1 s"
  using valued_1_th_8 sorry

abbreviation(input) RVSUM_1K7("-RVSUM-1K7  _ " [132]132) where
  "-RVSUM-1K7 F \<equiv> -VALUED-1K32 F"

mtheorem rvsum_1_def_5:
  mlet "F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
"redefine func -RVSUM-1K7 F \<rightarrow> FinSequenceFINSEQ-1M3-of REALNUMBERSK2 equals
  (comprealBINOP-2K7)*FUNCT-1K3 F"
proof
(*compatibility*)
  show " for it be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds it =HIDDENR1 -RVSUM-1K7 F iff it =HIDDENR1 (comprealBINOP-2K7)*FUNCT-1K3 F"
  proof-
    have " for F1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (F1 =FINSEQ-1R1 -VALUED-1K32 F implies F1 =FINSEQ-1R1 (comprealBINOP-2K7)*FUNCT-1K3 F) & (F1 =FINSEQ-1R1 (comprealBINOP-2K7)*FUNCT-1K3 F implies F1 =HIDDENR1 -VALUED-1K32 F)"
    proof(rule ballI,rule conjMI,rule impI)
      fix F1 assume [ty]: "F1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
      have A1: "domFINSEQ-1K5 (-VALUED-1K32 F) =XBOOLE-0R4 domFINSEQ-1K5 F"
        using valued_1_th_8 sorry
      have A2: "rngRVSUM-1K1 F c=TARSKIR1 REALNUMBERSK2 & domRELAT-1K1 (comprealBINOP-2K7) =XBOOLE-0R4 REALNUMBERSK2"
        using funct_2_def_1 sorry
      then have A3: "domFINSEQ-1K5 ((comprealBINOP-2K7)*FUNCT-1K3 F) =XBOOLE-0R4 domFINSEQ-1K5 F"
        using relat_1_th_27 sorry
      show "F1 =FINSEQ-1R1 -VALUED-1K32 F implies F1 =FINSEQ-1R1 (comprealBINOP-2K7)*FUNCT-1K3 F"
      proof(rule impI)
        assume A4: "F1 =FINSEQ-1R1 -VALUED-1K32 F"
        have " for c be objectHIDDENM1 holds c inHIDDENR3 domFINSEQ-1K5 F1 implies F1 .FUNCT-1K1 c =HIDDENR1 ((comprealBINOP-2K7)*FUNCT-1K3 F).FUNCT-1K1 c"
        proof(rule ballI,rule impI)
          fix c assume [ty]: "c be objectHIDDENM1"
          assume A5: "c inHIDDENR3 domFINSEQ-1K5 F1"
          have "F1 .FUNCT-1K1 c =HIDDENR1 -XCMPLX-0K4 F .FUNCT-1K1 c"
            using A4 valued_1_th_8 sorry
          also have "... = (comprealBINOP-2K7).FUNCT-1K1 (F .FUNCT-1K1 c)"
            using binop_2_def_7 sorry
          also have "... = ((comprealBINOP-2K7)*FUNCT-1K3 F).FUNCT-1K1 c"
            using A1 A4 A5 funct_1_th_13 sorry
          finally show "F1 .FUNCT-1K1 c =HIDDENR1 ((comprealBINOP-2K7)*FUNCT-1K3 F).FUNCT-1K1 c"
             sorry
        qed "sorry"
        thus "F1 =FINSEQ-1R1 (comprealBINOP-2K7)*FUNCT-1K3 F"
          using A3 A4 funct_1_th_2 valued_1_th_8 sorry
      qed
      assume A6: "F1 =FINSEQ-1R1 (comprealBINOP-2K7)*FUNCT-1K3 F"
      have " for c be objectHIDDENM1 holds c inHIDDENR3 domFINSEQ-1K5 F1 implies (-VALUED-1K32 F).FUNCT-1K1 c =HIDDENR1 ((comprealBINOP-2K7)*FUNCT-1K3 F).FUNCT-1K1 c"
      proof(rule ballI,rule impI)
        fix c assume [ty]: "c be objectHIDDENM1"
        assume A7: "c inHIDDENR3 domFINSEQ-1K5 F1"
        have "(-VALUED-1K32 F).FUNCT-1K1 c =HIDDENR1 -XCMPLX-0K4 F .FUNCT-1K1 c"
          using valued_1_th_8 sorry
        also have "... = (comprealBINOP-2K7).FUNCT-1K1 (F .FUNCT-1K1 c)"
          using binop_2_def_7 sorry
        also have "... = ((comprealBINOP-2K7)*FUNCT-1K3 F).FUNCT-1K1 c"
          using A6 A7 funct_1_th_12 sorry
        finally show "(-VALUED-1K32 F).FUNCT-1K1 c =HIDDENR1 ((comprealBINOP-2K7)*FUNCT-1K3 F).FUNCT-1K1 c"
           sorry
      qed "sorry"
      thus "F1 =HIDDENR1 -VALUED-1K32 F"
        using A1 A2 A6 funct_1_th_2 relat_1_th_27 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rvsum_1_add_4:
  mlet "F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
"cluster -VALUED-1K32 F as-term-is FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
proof
(*coherence*)
  show "-VALUED-1K32 F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    using rvsum_1_lm_2 sorry
qed "sorry"

syntax RVSUM_1K8 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("-RVSUM-1K8\<^bsub>'( _ ')\<^esub>  _ " [0,132]132)
translations "-RVSUM-1K8\<^bsub>(i)\<^esub> R" \<rightharpoonup> "-VALUED-1K32 R"

mtheorem rvsum_1_add_5:
  mlet "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
"cluster -VALUED-1K32 R as-term-is ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
proof
(*coherence*)
  show "-VALUED-1K32 R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    using finseq_2_th_113 sorry
qed "sorry"

mtheorem rvsum_1_th_18:
" for s be setHIDDENM2 holds  for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds (-RVSUM-1K7 F).FUNCT-1K1 s =HIDDENR1 -XCMPLX-0K4 F .FUNCT-1K1 s"
  using valued_1_th_8 sorry

mtheorem rvsum_1_th_19:
"-RVSUM-1K7 <*>FINSEQ-1K7 REALNUMBERSK2 =FINSEQ-1R1 <*>FINSEQ-1K7 REALNUMBERSK2"
   sorry

mtheorem rvsum_1_th_20:
" for r be RealXREAL-0M1 holds -RVSUM-1K7 <*FINSEQ-1K10 r*> =FINSEQ-1R1 <*FINSEQ-1K10 -XCMPLX-0K4 r *>"
proof-
  have " for r be RealXREAL-0M1 holds -RVSUM-1K7 <*FINSEQ-1K10 r*> =FINSEQ-1R1 <*FINSEQ-1K10 -XCMPLX-0K4 r *>"
  proof(rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    obtain s where 
      [ty]:"s be ElementSUBSET-1M1-of REALNUMBERSK2" and sDef:"s = r"
      using xreal_0_def_1 sorry
    have "-RVSUM-1K7 <*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> s*> =HIDDENR1 <*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> (comprealBINOP-2K7).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> s*>"
      using finseq_2_th_35 sorry
    also have "... = <*FINSEQ-1K10 -XCMPLX-0K4 r *>"
      using binop_2_def_7 sorry
    finally have "-RVSUM-1K7 <*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> s*> =HIDDENR1 <*FINSEQ-1K10 -XCMPLX-0K4 r *>"
       sorry
    thus "-RVSUM-1K7 <*FINSEQ-1K10 r*> =FINSEQ-1R1 <*FINSEQ-1K10 -XCMPLX-0K4 r *>"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_21:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r be RealXREAL-0M1 holds -RVSUM-1K7 i  |->FINSEQ-2K2 r =FINSEQ-1R1 i  |->FINSEQ-2K2 (-XCMPLX-0K4 r)"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r be RealXREAL-0M1 holds -RVSUM-1K7 i  |->FINSEQ-2K2 r =FINSEQ-1R1 i  |->FINSEQ-2K2 (-XCMPLX-0K4 r)"
  proof(rule ballI,rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    obtain s where 
      [ty]:"s be ElementSUBSET-1M1-of REALNUMBERSK2" and sDef:"s = r"
      using xreal_0_def_1 sorry
    have "-RVSUM-1K8\<^bsub>(i)\<^esub> i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s =HIDDENR1 i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> (comprealBINOP-2K7).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> s"
      using finseqop_th_16 sorry
    also have "... = i  |->FINSEQ-2K2 (-XCMPLX-0K4 r)"
      using binop_2_def_7 sorry
    finally have "-RVSUM-1K8\<^bsub>(i)\<^esub> i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s =HIDDENR1 i  |->FINSEQ-2K2 (-XCMPLX-0K4 r)"
       sorry
    thus "-RVSUM-1K7 i  |->FINSEQ-2K2 r =FINSEQ-1R1 i  |->FINSEQ-2K2 (-XCMPLX-0K4 r)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_22:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds R +RVSUM-1K6\<^bsub>(i)\<^esub> (-RVSUM-1K8\<^bsub>(i)\<^esub> R) =FINSEQ-1R1 i  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)"
  using rvsum_1_th_8 rvsum_1_th_9 binop_2_th_2 finseqop_th_73 sorry

mtheorem rvsum_1_th_23:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds R1 +RVSUM-1K6\<^bsub>(i)\<^esub> R2 =FINSEQ-1R1 i  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6) implies R1 =FINSEQ-1R1 -RVSUM-1K8\<^bsub>(i)\<^esub> R2"
  using rvsum_1_th_8 rvsum_1_th_9 binop_2_th_2 finseqop_th_74 sorry

mtheorem rvsum_1_th_24:
" for R1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for R2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds -VALUED-1K32 R1 =FUNCT-1R1 -VALUED-1K32 R2 implies R1 =FUNCT-1R1 R2"
proof-
  have " for R1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for R2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds -VALUED-1K32 R1 =FUNCT-1R1 -VALUED-1K32 R2 implies R1 =HIDDENR1 R2"
  proof(rule ballI,rule ballI,rule impI)
    fix R1 assume [ty]: "R1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix R2 assume [ty]: "R2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    assume "-VALUED-1K32 R1 =FUNCT-1R1 -VALUED-1K32 R2"
    then have "R1 =HIDDENR1 -VALUED-1K32 (-VALUED-1K32 R2)"
       sorry
    also have "... = R2"
       sorry
    finally show "R1 =HIDDENR1 R2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_25:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds R1 +RVSUM-1K6\<^bsub>(i)\<^esub> R =FINSEQ-1R1 R2 +RVSUM-1K6\<^bsub>(i)\<^esub> R implies R1 =FINSEQ-1R1 R2"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds R1 +RVSUM-1K6\<^bsub>(i)\<^esub> R =FINSEQ-1R1 R2 +RVSUM-1K6\<^bsub>(i)\<^esub> R implies R1 =FINSEQ-1R1 R2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix R assume [ty]: "R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    fix R1 assume [ty]: "R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    fix R2 assume [ty]: "R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    assume "R1 +RVSUM-1K6\<^bsub>(i)\<^esub> R =FINSEQ-1R1 R2 +RVSUM-1K6\<^bsub>(i)\<^esub> R"
    then have "R1 +RVSUM-1K6\<^bsub>(i)\<^esub> (R +RVSUM-1K6\<^bsub>(i)\<^esub> (-RVSUM-1K8\<^bsub>(i)\<^esub> R)) =FINSEQ-1R1 (R2 +RVSUM-1K6\<^bsub>(i)\<^esub> R)+RVSUM-1K6\<^bsub>(i)\<^esub> (-RVSUM-1K8\<^bsub>(i)\<^esub> R)"
      using finseqop_th_28 sorry
    then have A1: "R1 +RVSUM-1K6\<^bsub>(i)\<^esub> (R +RVSUM-1K6\<^bsub>(i)\<^esub> (-RVSUM-1K8\<^bsub>(i)\<^esub> R)) =FINSEQ-1R1 R2 +RVSUM-1K6\<^bsub>(i)\<^esub> (R +RVSUM-1K6\<^bsub>(i)\<^esub> (-RVSUM-1K8\<^bsub>(i)\<^esub> R))"
      using finseqop_th_28 sorry
    have "R +RVSUM-1K6\<^bsub>(i)\<^esub> (-RVSUM-1K8\<^bsub>(i)\<^esub> R) =FINSEQ-1R1 i  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)"
      using rvsum_1_th_8 rvsum_1_th_9 binop_2_th_2 finseqop_th_73 sorry
    then have "R1 =FINSEQ-1R1 R2 +RVSUM-1K5 i  |->FINSEQ-2K2 (0NUMBERSK6)"
      using A1 binop_2_th_2 finseqop_th_56 sorry
    thus "R1 =FINSEQ-1R1 R2"
      using binop_2_th_2 finseqop_th_56 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_26:
" for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds -RVSUM-1K7 (F1 +RVSUM-1K5 F2) =FINSEQ-1R1 (-RVSUM-1K7 F1)+RVSUM-1K5 (-RVSUM-1K7 F2)"
proof-
  have " for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds -RVSUM-1K7 (F1 +RVSUM-1K5 F2) =FINSEQ-1R1 (-RVSUM-1K7 F1)+RVSUM-1K5 (-RVSUM-1K7 F2)"
  proof(rule ballI,rule ballI)
    fix F1 assume [ty]: "F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    fix F2 assume [ty]: "F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    have A1: "domFINSEQ-1K5 (-RVSUM-1K7 (F1 +RVSUM-1K5 F2)) =XBOOLE-0R4 domFINSEQ-1K5 (F1 +RVSUM-1K5 F2)"
      using valued_1_th_8 sorry
    have A2: "domFINSEQ-1K5 (F1 +RVSUM-1K5 F2) =XBOOLE-0R4 domFINSEQ-1K5 F1 /\\XBOOLE-0K3 domFINSEQ-1K5 F2"
      using valued_1_def_1 sorry
    have A3: "domFINSEQ-1K5 ((-RVSUM-1K7 F1)+RVSUM-1K5 (-RVSUM-1K7 F2)) =HIDDENR1 domFINSEQ-1K5 (-RVSUM-1K7 F1) /\\XBOOLE-0K3 domFINSEQ-1K5 (-RVSUM-1K7 F2)"
      using valued_1_def_1 sorry
    also have "... = domFINSEQ-1K5 F1 /\\XBOOLE-0K3 domFINSEQ-1K5 (-RVSUM-1K7 F2)"
      using valued_1_th_8 sorry
    also have "... = domFINSEQ-1K5 F1 /\\XBOOLE-0K3 domFINSEQ-1K5 F2"
      using valued_1_th_8 sorry
    finally have "domFINSEQ-1K5 ((-RVSUM-1K7 F1)+RVSUM-1K5 (-RVSUM-1K7 F2)) =HIDDENR1 domFINSEQ-1K5 F1 /\\XBOOLE-0K3 domFINSEQ-1K5 F2"
       sorry
    have " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 (-RVSUM-1K7 (F1 +RVSUM-1K5 F2)) implies (-RVSUM-1K7 (F1 +RVSUM-1K5 F2)).FUNCT-1K1 i =HIDDENR1 ((-RVSUM-1K7 F1)+RVSUM-1K5 (-RVSUM-1K7 F2)).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be NatNAT-1M1"
      assume A4: "i inTARSKIR2 domFINSEQ-1K5 (-RVSUM-1K7 (F1 +RVSUM-1K5 F2))"
      have "(-RVSUM-1K7 (F1 +RVSUM-1K5 F2)).FUNCT-1K1 i =HIDDENR1 -XCMPLX-0K4 (F1 +RVSUM-1K5 F2).FUNCT-1K1 i"
        using valued_1_th_8 sorry
      also have "... = -XCMPLX-0K4 (F1 .FUNCT-1K1 i +XCMPLX-0K2 F2 .FUNCT-1K1 i)"
        using A1 A4 valued_1_def_1 sorry
      also have "... = (-XCMPLX-0K4 F1 .FUNCT-1K1 i)+XCMPLX-0K2 (-XCMPLX-0K4 F2 .FUNCT-1K1 i)"
         sorry
      also have "... = (-XCMPLX-0K4 F1 .FUNCT-1K1 i)+XCMPLX-0K2 (-RVSUM-1K7 F2).FUNCT-1K1 i"
        using valued_1_th_8 sorry
      also have "... = (-RVSUM-1K7 F1).FUNCT-1K1 i +XCMPLX-0K2 (-RVSUM-1K7 F2).FUNCT-1K1 i"
        using valued_1_th_8 sorry
      also have "... = ((-RVSUM-1K7 F1)+RVSUM-1K5 (-RVSUM-1K7 F2)).FUNCT-1K1 i"
        using A1 A2 A3 A4 valued_1_def_1 sorry
      finally show "(-RVSUM-1K7 (F1 +RVSUM-1K5 F2)).FUNCT-1K1 i =HIDDENR1 ((-RVSUM-1K7 F1)+RVSUM-1K5 (-RVSUM-1K7 F2)).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "-RVSUM-1K7 (F1 +RVSUM-1K5 F2) =FINSEQ-1R1 (-RVSUM-1K7 F1)+RVSUM-1K5 (-RVSUM-1K7 F2)"
      using A2 A3 finseq_1_th_13 valued_1_th_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) RVSUM_1K9(" _ -RVSUM-1K9  _ " [132,132]132) where
  "F1 -RVSUM-1K9 F2 \<equiv> F1 -VALUED-1K47 F2"

mtheorem rvsum_1_def_6:
  mlet "F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1", "F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
"redefine func F1 -RVSUM-1K9 F2 \<rightarrow> FinSequenceFINSEQ-1M3-of REALNUMBERSK2 equals
  diffrealRVSUM-1K2 .:FUNCOP-1K3(F1,F2)"
proof
(*compatibility*)
  show " for it be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds it =HIDDENR1 F1 -RVSUM-1K9 F2 iff it =HIDDENR1 diffrealRVSUM-1K2 .:FUNCOP-1K3(F1,F2)"
  proof-
    have " for F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (F =FINSEQ-1R1 F1 -VALUED-1K47 F2 implies F =FUNCT-1R1 diffrealRVSUM-1K2 .:FUNCOP-1K3(F1,F2)) & (F =FUNCT-1R1 diffrealRVSUM-1K2 .:FUNCOP-1K3(F1,F2) implies F =HIDDENR1 F1 -VALUED-1K47 F2)"
    proof(rule ballI,rule conjMI,rule impI)
      obtain F3 F4 where 
        [ty]:"F3 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2" and F3Def:"F3 = F1" and
        [ty]:"F4 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2" and F4Def:"F4 = F2"
        using rvsum_1_lm_2 sorry
      fix F assume [ty]: "F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
      have A1: "domFINSEQ-1K5 (F1 -VALUED-1K47 F2) =XBOOLE-0R4 domFINSEQ-1K5 F1 /\\XBOOLE-0K3 domFINSEQ-1K5 F2"
        using valued_1_th_12 sorry
      have "domRELAT-1K1 (diffrealRVSUM-1K2) =XBOOLE-0R4 [:ZFMISC-1K2 REALNUMBERSK2,REALNUMBERSK2 :]"
        using funct_2_def_1 sorry
      then have A2: "[:ZFMISC-1K2 rngRVSUM-1K1 F3,rngRVSUM-1K1 F4 :] c=RELAT-1R2 domRELAT-1K1 (diffrealRVSUM-1K2)"
        using zfmisc_1_th_96 sorry
      then have A3: "domRELAT-1K1 (diffrealRVSUM-1K2 .:FUNCOP-1K3(F1,F2)) =XBOOLE-0R4 domFINSEQ-1K5 F1 /\\XBOOLE-0K3 domFINSEQ-1K5 F2"
        using funcop_1_th_69 sorry
      show "F =FINSEQ-1R1 F1 -VALUED-1K47 F2 implies F =FUNCT-1R1 diffrealRVSUM-1K2 .:FUNCOP-1K3(F1,F2)"
      proof(rule impI)
        assume A4: "F =FINSEQ-1R1 F1 -VALUED-1K47 F2"
        have " for z be setHIDDENM2 holds z inTARSKIR2 domRELAT-1K1 (diffrealRVSUM-1K2 .:FUNCOP-1K3(F1,F2)) implies F .FUNCT-1K1 z =XBOOLE-0R4 diffrealRVSUM-1K2 .BINOP-1K1(F1 .FUNCT-1K1 z,F2 .FUNCT-1K1 z)"
        proof-
          have " for z be setHIDDENM2 holds z inTARSKIR2 domRELAT-1K1 (diffrealRVSUM-1K2 .:FUNCOP-1K3(F1,F2)) implies F .FUNCT-1K1 z =HIDDENR1 diffrealRVSUM-1K2 .BINOP-1K1(F1 .FUNCT-1K1 z,F2 .FUNCT-1K1 z)"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be setHIDDENM2"
            assume "z inTARSKIR2 domRELAT-1K1 (diffrealRVSUM-1K2 .:FUNCOP-1K3(F1,F2))"
            then have "F .FUNCT-1K1 z =HIDDENR1 F1 .FUNCT-1K1 z -XCMPLX-0K6 F2 .FUNCT-1K1 z"
              using A1 A3 A4 valued_1_th_13 sorry
            also have "... = diffrealRVSUM-1K2 .BINOP-1K1(F1 .FUNCT-1K1 z,F2 .FUNCT-1K1 z)"
              using binop_2_def_10 sorry
            finally show "F .FUNCT-1K1 z =HIDDENR1 diffrealRVSUM-1K2 .BINOP-1K1(F1 .FUNCT-1K1 z,F2 .FUNCT-1K1 z)"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "F =FUNCT-1R1 diffrealRVSUM-1K2 .:FUNCOP-1K3(F1,F2)"
          using A1 A3 A4 funcop_1_th_21 sorry
      qed
      assume A5: "F =FUNCT-1R1 diffrealRVSUM-1K2 .:FUNCOP-1K3(F1,F2)"
      have " for c be objectHIDDENM1 holds c inHIDDENR3 domFINSEQ-1K5 F implies F .FUNCT-1K1 c =HIDDENR1 F1 .FUNCT-1K1 c -XCMPLX-0K6 F2 .FUNCT-1K1 c"
      proof(rule ballI,rule impI)
        fix c assume [ty]: "c be objectHIDDENM1"
        assume "c inHIDDENR3 domFINSEQ-1K5 F"
        then have "F .FUNCT-1K1 c =HIDDENR1 diffrealRVSUM-1K2 .BINOP-1K1(F1 .FUNCT-1K1 c,F2 .FUNCT-1K1 c)"
          using A5 funcop_1_th_22 sorry
        also have "... = F1 .FUNCT-1K1 c -XCMPLX-0K6 F2 .FUNCT-1K1 c"
          using binop_2_def_10 sorry
        finally show "F .FUNCT-1K1 c =HIDDENR1 F1 .FUNCT-1K1 c -XCMPLX-0K6 F2 .FUNCT-1K1 c"
           sorry
      qed "sorry"
      thus "F =HIDDENR1 F1 -VALUED-1K47 F2"
        using A1 A2 A5 funcop_1_th_69 valued_1_th_14 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rvsum_1_add_6:
  mlet "F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1", "F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
"cluster F1 -VALUED-1K47 F2 as-term-is FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
proof
(*coherence*)
  show "F1 -VALUED-1K47 F2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    using rvsum_1_lm_2 sorry
qed "sorry"

syntax RVSUM_1K10 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ -RVSUM-1K10\<^bsub>'( _ ')\<^esub>  _ " [132,0,132]132)
translations "R1 -RVSUM-1K10\<^bsub>(i)\<^esub> R2" \<rightharpoonup> "R1 -VALUED-1K47 R2"

mtheorem rvsum_1_add_7:
  mlet "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2", "R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
"cluster R1 -VALUED-1K47 R2 as-term-is ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
proof
(*coherence*)
  show "R1 -VALUED-1K47 R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    using finseq_2_th_120 sorry
qed "sorry"

mtheorem rvsum_1_th_27:
" for s be setHIDDENM2 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds (R1 -RVSUM-1K10\<^bsub>(i)\<^esub> R2).FUNCT-1K1 s =XBOOLE-0R4 R1 .FUNCT-1K1 s -XCMPLX-0K6 R2 .FUNCT-1K1 s"
proof-
  have " for s be setHIDDENM2 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds (R1 -RVSUM-1K10\<^bsub>(i)\<^esub> R2).FUNCT-1K1 s =HIDDENR1 R1 .FUNCT-1K1 s -XCMPLX-0K6 R2 .FUNCT-1K1 s"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix s assume [ty]: "s be setHIDDENM2"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix R1 assume [ty]: "R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    fix R2 assume [ty]: "R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    show "(R1 -RVSUM-1K10\<^bsub>(i)\<^esub> R2).FUNCT-1K1 s =HIDDENR1 R1 .FUNCT-1K1 s -XCMPLX-0K6 R2 .FUNCT-1K1 s"
    proof-
      have cases: " not s inTARSKIR2 SegFINSEQ-1K1 i or s inTARSKIR2 SegFINSEQ-1K1 i"
         sorry
      have case1: " not s inTARSKIR2 SegFINSEQ-1K1 i implies (R1 -RVSUM-1K10\<^bsub>(i)\<^esub> R2).FUNCT-1K1 s =HIDDENR1 R1 .FUNCT-1K1 s -XCMPLX-0K6 R2 .FUNCT-1K1 s"
      proof(rule impI)
        assume A1: " not s inTARSKIR2 SegFINSEQ-1K1 i"
        then have A2: " not s inTARSKIR2 domFINSEQ-1K5 R2"
          using finseq_2_th_124 sorry
        have A3: " not s inTARSKIR2 domFINSEQ-1K5 R1"
          using A1 finseq_2_th_124 sorry
        have " not s inTARSKIR2 domFINSEQ-1K5 (R1 -RVSUM-1K10\<^bsub>(i)\<^esub> R2)"
          using A1 finseq_2_th_124 sorry
        then have "(R1 -RVSUM-1K10\<^bsub>(i)\<^esub> R2).FUNCT-1K1 s =HIDDENR1 0NUMBERSK6 -XCMPLX-0K6 0NUMBERSK6"
          using funct_1_def_2 sorry
        also have "... = R1 .FUNCT-1K1 s -XCMPLX-0K6 0NUMBERSK6"
          using A3 funct_1_def_2 sorry
        also have "... = R1 .FUNCT-1K1 s -XCMPLX-0K6 R2 .FUNCT-1K1 s"
          using A2 funct_1_def_2 sorry
        finally show "(R1 -RVSUM-1K10\<^bsub>(i)\<^esub> R2).FUNCT-1K1 s =HIDDENR1 R1 .FUNCT-1K1 s -XCMPLX-0K6 R2 .FUNCT-1K1 s"
           sorry
      qed
      have case2: "s inTARSKIR2 SegFINSEQ-1K1 i implies (R1 -RVSUM-1K10\<^bsub>(i)\<^esub> R2).FUNCT-1K1 s =XBOOLE-0R4 R1 .FUNCT-1K1 s -XCMPLX-0K6 R2 .FUNCT-1K1 s"
      proof(rule impI)
        assume "s inTARSKIR2 SegFINSEQ-1K1 i"
        then have "s inTARSKIR2 domFINSEQ-1K5 (R1 -RVSUM-1K10\<^bsub>(i)\<^esub> R2)"
          using finseq_2_th_124 sorry
        thus "(R1 -RVSUM-1K10\<^bsub>(i)\<^esub> R2).FUNCT-1K1 s =XBOOLE-0R4 R1 .FUNCT-1K1 s -XCMPLX-0K6 R2 .FUNCT-1K1 s"
          using valued_1_th_13 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_28:
" for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds <*>FINSEQ-1K7 REALNUMBERSK2 -RVSUM-1K9 F =FINSEQ-1R1 <*>FINSEQ-1K7 REALNUMBERSK2 & F -RVSUM-1K9 <*>FINSEQ-1K7 REALNUMBERSK2 =FINSEQ-1R1 <*>FINSEQ-1K7 REALNUMBERSK2"
proof-
  have " for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds <*>FINSEQ-1K7 REALNUMBERSK2 -RVSUM-1K9 F =FINSEQ-1R1 <*>FINSEQ-1K7 REALNUMBERSK2 & F -RVSUM-1K9 <*>FINSEQ-1K7 REALNUMBERSK2 =FINSEQ-1R1 <*>FINSEQ-1K7 REALNUMBERSK2"
  proof(rule ballI)
    fix F assume [ty]: "F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    have "F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
      using rvsum_1_lm_2 sorry
    thus "<*>FINSEQ-1K7 REALNUMBERSK2 -RVSUM-1K9 F =FINSEQ-1R1 <*>FINSEQ-1K7 REALNUMBERSK2 & F -RVSUM-1K9 <*>FINSEQ-1K7 REALNUMBERSK2 =FINSEQ-1R1 <*>FINSEQ-1K7 REALNUMBERSK2"
      using finseq_2_th_73 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_29:
" for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds <*FINSEQ-1K10 r1*> -RVSUM-1K9 <*FINSEQ-1K10 r2*> =FINSEQ-1R1 <*FINSEQ-1K10 r1 -XCMPLX-0K6 r2 *>"
proof-
  have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds <*FINSEQ-1K10 r1*> -RVSUM-1K9 <*FINSEQ-1K10 r2*> =FINSEQ-1R1 <*FINSEQ-1K10 r1 -XCMPLX-0K6 r2 *>"
  proof(rule ballI,rule ballI)
    fix r1 assume [ty]: "r1 be RealXREAL-0M1"
    fix r2 assume [ty]: "r2 be RealXREAL-0M1"
    obtain s1 s2 where 
      [ty]:"s1 be ElementSUBSET-1M1-of REALNUMBERSK2" and s1Def:"s1 = r1" and
      [ty]:"s2 be ElementSUBSET-1M1-of REALNUMBERSK2" and s2Def:"s2 = r2"
      using xreal_0_def_1 sorry
    have "<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> s1*> -RVSUM-1K9 <*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> s2*> =HIDDENR1 <*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> diffrealRVSUM-1K2 .BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(s1,s2)*>"
      using finseq_2_th_74 sorry
    also have "... = <*FINSEQ-1K10 r1 -XCMPLX-0K6 r2 *>"
      using binop_2_def_10 sorry
    finally have "<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> s1*> -RVSUM-1K9 <*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> s2*> =HIDDENR1 <*FINSEQ-1K10 r1 -XCMPLX-0K6 r2 *>"
       sorry
    thus "<*FINSEQ-1K10 r1*> -RVSUM-1K9 <*FINSEQ-1K10 r2*> =FINSEQ-1R1 <*FINSEQ-1K10 r1 -XCMPLX-0K6 r2 *>"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_30:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds i  |->FINSEQ-2K2 r1 -RVSUM-1K9 i  |->FINSEQ-2K2 r2 =FINSEQ-1R1 i  |->FINSEQ-2K2 (r1 -XCMPLX-0K6 r2)"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds i  |->FINSEQ-2K2 r1 -RVSUM-1K9 i  |->FINSEQ-2K2 r2 =FINSEQ-1R1 i  |->FINSEQ-2K2 (r1 -XCMPLX-0K6 r2)"
  proof(rule ballI,rule ballI,rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix r1 assume [ty]: "r1 be RealXREAL-0M1"
    fix r2 assume [ty]: "r2 be RealXREAL-0M1"
    obtain s1 s2 where 
      [ty]:"s1 be ElementSUBSET-1M1-of REALNUMBERSK2" and s1Def:"s1 = r1" and
      [ty]:"s2 be ElementSUBSET-1M1-of REALNUMBERSK2" and s2Def:"s2 = r2"
      using xreal_0_def_1 sorry
    have "i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s1 -RVSUM-1K10\<^bsub>(i)\<^esub> i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s2 =HIDDENR1 i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> diffrealRVSUM-1K2 .BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(s1,s2)"
      using finseqop_th_17 sorry
    also have "... = i  |->FINSEQ-2K2 (r1 -XCMPLX-0K6 r2)"
      using binop_2_def_10 sorry
    finally have "i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s1 -RVSUM-1K10\<^bsub>(i)\<^esub> i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s2 =HIDDENR1 i  |->FINSEQ-2K2 (r1 -XCMPLX-0K6 r2)"
       sorry
    thus "i  |->FINSEQ-2K2 r1 -RVSUM-1K9 i  |->FINSEQ-2K2 r2 =FINSEQ-1R1 i  |->FINSEQ-2K2 (r1 -XCMPLX-0K6 r2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_31:
" for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds F1 -RVSUM-1K9 F2 =FINSEQ-1R1 F1 +RVSUM-1K5 (-RVSUM-1K7 F2)"
   sorry

mtheorem rvsum_1_th_32:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds R -RVSUM-1K9 i  |->FINSEQ-2K2 (0NUMBERSK6) =FINSEQ-1R1 R"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds R -RVSUM-1K9 i  |->FINSEQ-2K2 (0NUMBERSK6) =HIDDENR1 R"
  proof(rule ballI,rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix R assume [ty]: "R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    have "R -RVSUM-1K9 i  |->FINSEQ-2K2 (0NUMBERSK6) =HIDDENR1 R +RVSUM-1K5 i  |->FINSEQ-2K2 (-XCMPLX-0K4 0NUMBERSK6)"
      using rvsum_1_th_21 sorry
    also have "... = R"
      using binop_2_th_2 finseqop_th_56 sorry
    finally show "R -RVSUM-1K9 i  |->FINSEQ-2K2 (0NUMBERSK6) =HIDDENR1 R"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_33:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds i  |->FINSEQ-2K2 (0NUMBERSK6) -RVSUM-1K9 R =FINSEQ-1R1 -RVSUM-1K8\<^bsub>(i)\<^esub> R"
  using binop_2_th_2 finseqop_th_56 sorry

mtheorem rvsum_1_th_34:
" for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds F1 -RVSUM-1K9 (-RVSUM-1K7 F2) =FINSEQ-1R1 F1 +RVSUM-1K5 F2"
   sorry

mtheorem rvsum_1_th_35:
" for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds -RVSUM-1K7 (F1 -RVSUM-1K9 F2) =FINSEQ-1R1 F2 -RVSUM-1K9 F1"
proof-
  have " for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds -RVSUM-1K7 (F1 -RVSUM-1K9 F2) =HIDDENR1 F2 -RVSUM-1K9 F1"
  proof(rule ballI,rule ballI)
    fix F1 assume [ty]: "F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    fix F2 assume [ty]: "F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    have "-RVSUM-1K7 (F1 -RVSUM-1K9 F2) =HIDDENR1 (-RVSUM-1K7 F1)+RVSUM-1K5 (-RVSUM-1K7 (-RVSUM-1K7 F2))"
      using rvsum_1_th_26 sorry
    also have "... = F2 -RVSUM-1K9 F1"
       sorry
    finally show "-RVSUM-1K7 (F1 -RVSUM-1K9 F2) =HIDDENR1 F2 -RVSUM-1K9 F1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_36:
" for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds -RVSUM-1K7 (F1 -RVSUM-1K9 F2) =FINSEQ-1R1 (-RVSUM-1K7 F1)+RVSUM-1K5 F2"
proof-
  have " for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds -RVSUM-1K7 (F1 -RVSUM-1K9 F2) =HIDDENR1 (-RVSUM-1K7 F1)+RVSUM-1K5 F2"
  proof(rule ballI,rule ballI)
    fix F1 assume [ty]: "F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    fix F2 assume [ty]: "F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    have "-RVSUM-1K7 (F1 -RVSUM-1K9 F2) =HIDDENR1 (-RVSUM-1K7 F1)+RVSUM-1K5 (-RVSUM-1K7 (-RVSUM-1K7 F2))"
      using rvsum_1_th_26 sorry
    also have "... = (-RVSUM-1K7 F1)+RVSUM-1K5 F2"
       sorry
    finally show "-RVSUM-1K7 (F1 -RVSUM-1K9 F2) =HIDDENR1 (-RVSUM-1K7 F1)+RVSUM-1K5 F2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_37:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds R -RVSUM-1K10\<^bsub>(i)\<^esub> R =FINSEQ-1R1 i  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)"
  using rvsum_1_th_8 rvsum_1_th_9 binop_2_th_2 finseqop_th_73 sorry

mtheorem rvsum_1_th_38:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds R1 -RVSUM-1K10\<^bsub>(i)\<^esub> R2 =FINSEQ-1R1 i  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6) implies R1 =FINSEQ-1R1 R2"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds R1 -RVSUM-1K10\<^bsub>(i)\<^esub> R2 =FINSEQ-1R1 i  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6) implies R1 =FINSEQ-1R1 R2"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix R1 assume [ty]: "R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    fix R2 assume [ty]: "R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    assume "R1 -RVSUM-1K10\<^bsub>(i)\<^esub> R2 =FINSEQ-1R1 i  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)"
    then have "R1 =FINSEQ-1R1 -RVSUM-1K8\<^bsub>(i)\<^esub> (-RVSUM-1K8\<^bsub>(i)\<^esub> R2)"
      using rvsum_1_th_8 rvsum_1_th_9 binop_2_th_2 finseqop_th_74 sorry
    thus "R1 =FINSEQ-1R1 R2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_39:
" for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F3 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds (F1 -RVSUM-1K9 F2)-RVSUM-1K9 F3 =FINSEQ-1R1 F1 -RVSUM-1K9 (F2 +RVSUM-1K5 F3)"
  using rfunct_1_th_20 sorry

mtheorem rvsum_1_th_40:
" for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F3 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds F1 +RVSUM-1K5 (F2 -RVSUM-1K9 F3) =FINSEQ-1R1 (F1 +RVSUM-1K5 F2)-RVSUM-1K9 F3"
  using rfunct_1_th_23 sorry

mtheorem rvsum_1_th_41:
" for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F3 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds F1 -RVSUM-1K9 (F2 -RVSUM-1K9 F3) =FINSEQ-1R1 (F1 -RVSUM-1K9 F2)+RVSUM-1K5 F3"
  using rfunct_1_th_22 sorry

mtheorem rvsum_1_th_42:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds R1 =FINSEQ-1R1 (R1 +RVSUM-1K6\<^bsub>(i)\<^esub> R)-RVSUM-1K10\<^bsub>(i)\<^esub> R"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds R1 =HIDDENR1 (R1 +RVSUM-1K6\<^bsub>(i)\<^esub> R)-RVSUM-1K10\<^bsub>(i)\<^esub> R"
  proof(rule ballI,rule ballI,rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix R assume [ty]: "R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    fix R1 assume [ty]: "R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    have "R1 =HIDDENR1 R1 +RVSUM-1K5 i  |->FINSEQ-2K2 (0NUMBERSK6)"
      using binop_2_th_2 finseqop_th_56 sorry
    also have "... = R1 +RVSUM-1K6\<^bsub>(i)\<^esub> (R -RVSUM-1K10\<^bsub>(i)\<^esub> R)"
      using rvsum_1_th_8 rvsum_1_th_9 binop_2_th_2 finseqop_th_73 sorry
    also have "... = (R1 +RVSUM-1K6\<^bsub>(i)\<^esub> R)-RVSUM-1K10\<^bsub>(i)\<^esub> R"
      using rfunct_1_th_23 sorry
    finally show "R1 =HIDDENR1 (R1 +RVSUM-1K6\<^bsub>(i)\<^esub> R)-RVSUM-1K10\<^bsub>(i)\<^esub> R"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_43:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds R1 =FINSEQ-1R1 (R1 -RVSUM-1K10\<^bsub>(i)\<^esub> R)+RVSUM-1K6\<^bsub>(i)\<^esub> R"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds R1 =HIDDENR1 (R1 -RVSUM-1K10\<^bsub>(i)\<^esub> R)+RVSUM-1K6\<^bsub>(i)\<^esub> R"
  proof(rule ballI,rule ballI,rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix R assume [ty]: "R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    fix R1 assume [ty]: "R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    have "R1 =HIDDENR1 R1 +RVSUM-1K5 i  |->FINSEQ-2K2 (0NUMBERSK6)"
      using binop_2_th_2 finseqop_th_56 sorry
    also have "... = R1 +RVSUM-1K6\<^bsub>(i)\<^esub> ((-RVSUM-1K8\<^bsub>(i)\<^esub> R)+RVSUM-1K6\<^bsub>(i)\<^esub> R)"
      using rvsum_1_th_8 rvsum_1_th_9 binop_2_th_2 finseqop_th_73 sorry
    also have "... = (R1 -RVSUM-1K10\<^bsub>(i)\<^esub> R)+RVSUM-1K6\<^bsub>(i)\<^esub> R"
      using finseqop_th_28 sorry
    finally show "R1 =HIDDENR1 (R1 -RVSUM-1K10\<^bsub>(i)\<^esub> R)+RVSUM-1K6\<^bsub>(i)\<^esub> R"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) RVSUM_1K11(" _ *RVSUM-1K11  _ " [164,164]164) where
  "r *RVSUM-1K11 F \<equiv> r (#)VALUED-1K25 F"

mtheorem rvsum_1_th_44:
" for s be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds (r *RVSUM-1K11 F).FUNCT-1K1 s =XBOOLE-0R4 r *XCMPLX-0K3 F .FUNCT-1K1 s"
  using valued_1_th_6 sorry

abbreviation(input) RVSUM_1K12(" _ *RVSUM-1K12  _ " [164,164]164) where
  "r *RVSUM-1K12 F \<equiv> r (#)VALUED-1K25 F"

mtheorem rvsum_1_def_7:
  mlet "F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1", "r be RealXREAL-0M1"
"redefine func r *RVSUM-1K12 F \<rightarrow> FinSequenceFINSEQ-1M3-of REALNUMBERSK2 equals
  (r multrealRVSUM-1K4)*FUNCT-1K3 F"
proof
(*compatibility*)
  show " for it be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds it =HIDDENR1 r *RVSUM-1K12 F iff it =HIDDENR1 (r multrealRVSUM-1K4)*FUNCT-1K3 F"
  proof-
    have " for F1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (F1 =FINSEQ-1R1 r *RVSUM-1K11 F implies F1 =FINSEQ-1R1 (r multrealRVSUM-1K4)*FUNCT-1K3 F) & (F1 =FINSEQ-1R1 (r multrealRVSUM-1K4)*FUNCT-1K3 F implies F1 =HIDDENR1 r (#)VALUED-1K25 F)"
    proof(rule ballI,rule conjMI,rule impI)
      fix F1 assume [ty]: "F1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
      have A1: "domFINSEQ-1K5 (r *RVSUM-1K11 F) =XBOOLE-0R4 domFINSEQ-1K5 F"
        using valued_1_def_5 sorry
      have A2: "rngRVSUM-1K1 F c=TARSKIR1 REALNUMBERSK2 & domRELAT-1K1 (r multrealRVSUM-1K4) =XBOOLE-0R4 REALNUMBERSK2"
        using funct_2_def_1 sorry
      then have A3: "domFINSEQ-1K5 ((r multrealRVSUM-1K4)*FUNCT-1K3 F) =XBOOLE-0R4 domFINSEQ-1K5 F"
        using relat_1_th_27 sorry
      show "F1 =FINSEQ-1R1 r *RVSUM-1K11 F implies F1 =FINSEQ-1R1 (r multrealRVSUM-1K4)*FUNCT-1K3 F"
      proof(rule impI)
        assume A4: "F1 =FINSEQ-1R1 r *RVSUM-1K11 F"
        have " for c be objectHIDDENM1 holds c inHIDDENR3 domFINSEQ-1K5 F1 implies F1 .FUNCT-1K1 c =HIDDENR1 ((r multrealRVSUM-1K4)*FUNCT-1K3 F).FUNCT-1K1 c"
        proof(rule ballI,rule impI)
          fix c assume [ty]: "c be objectHIDDENM1"
          assume A5: "c inHIDDENR3 domFINSEQ-1K5 F1"
          then have "F1 .FUNCT-1K1 c =HIDDENR1 r *XCMPLX-0K3 F .FUNCT-1K1 c"
            using A4 valued_1_def_5 sorry
          also have "... = (r multrealRVSUM-1K4).FUNCT-1K1 (F .FUNCT-1K1 c)"
            using rvsum_1_lm_1 sorry
          also have "... = ((r multrealRVSUM-1K4)*FUNCT-1K3 F).FUNCT-1K1 c"
            using A1 A4 A5 funct_1_th_13 sorry
          finally show "F1 .FUNCT-1K1 c =HIDDENR1 ((r multrealRVSUM-1K4)*FUNCT-1K3 F).FUNCT-1K1 c"
             sorry
        qed "sorry"
        thus "F1 =FINSEQ-1R1 (r multrealRVSUM-1K4)*FUNCT-1K3 F"
          using A1 A3 A4 funct_1_th_2 sorry
      qed
      assume A6: "F1 =FINSEQ-1R1 (r multrealRVSUM-1K4)*FUNCT-1K3 F"
      have " for c be objectHIDDENM1 holds c inHIDDENR3 domFINSEQ-1K5 F1 implies (r *RVSUM-1K11 F).FUNCT-1K1 c =HIDDENR1 ((r multrealRVSUM-1K4)*FUNCT-1K3 F).FUNCT-1K1 c"
      proof(rule ballI,rule impI)
        fix c assume [ty]: "c be objectHIDDENM1"
        assume A7: "c inHIDDENR3 domFINSEQ-1K5 F1"
        have "(r *RVSUM-1K11 F).FUNCT-1K1 c =HIDDENR1 r *XCMPLX-0K3 F .FUNCT-1K1 c"
          using valued_1_th_6 sorry
        also have "... = (r multrealRVSUM-1K4).FUNCT-1K1 (F .FUNCT-1K1 c)"
          using rvsum_1_lm_1 sorry
        also have "... = ((r multrealRVSUM-1K4)*FUNCT-1K3 F).FUNCT-1K1 c"
          using A6 A7 funct_1_th_12 sorry
        finally show "(r *RVSUM-1K11 F).FUNCT-1K1 c =HIDDENR1 ((r multrealRVSUM-1K4)*FUNCT-1K3 F).FUNCT-1K1 c"
           sorry
      qed "sorry"
      thus "F1 =HIDDENR1 r (#)VALUED-1K25 F"
        using A1 A2 A6 funct_1_th_2 relat_1_th_27 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rvsum_1_add_8:
  mlet "F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1", "r be RealXREAL-0M1"
"cluster r (#)VALUED-1K25 F as-term-is FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
proof
(*coherence*)
  show "r (#)VALUED-1K25 F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    using rvsum_1_lm_2 sorry
qed "sorry"

syntax RVSUM_1K13 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ *RVSUM-1K13\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164)
translations "r *RVSUM-1K13\<^bsub>(i)\<^esub> R" \<rightharpoonup> "r (#)VALUED-1K25 R"

mtheorem rvsum_1_add_9:
  mlet "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2", "r be RealXREAL-0M1"
"cluster r (#)VALUED-1K25 R as-term-is ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
proof
(*coherence*)
  show "r (#)VALUED-1K25 R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    using finseq_2_th_113 sorry
qed "sorry"

mtheorem rvsum_1_th_45:
" for s be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds (r *RVSUM-1K12 F).FUNCT-1K1 s =XBOOLE-0R4 r *XCMPLX-0K3 F .FUNCT-1K1 s"
  using valued_1_th_6 sorry

mtheorem rvsum_1_th_46:
" for r be RealXREAL-0M1 holds r *RVSUM-1K12 <*>FINSEQ-1K7 REALNUMBERSK2 =FINSEQ-1R1 <*>FINSEQ-1K7 REALNUMBERSK2"
   sorry

mtheorem rvsum_1_th_47:
" for r be RealXREAL-0M1 holds  for r1 be RealXREAL-0M1 holds r *RVSUM-1K12 (<*FINSEQ-1K10 r1*>) =FINSEQ-1R1 <*FINSEQ-1K10 r *XCMPLX-0K3 r1 *>"
proof-
  have " for r be RealXREAL-0M1 holds  for r1 be RealXREAL-0M1 holds r *RVSUM-1K12 (<*FINSEQ-1K10 r1*>) =FINSEQ-1R1 <*FINSEQ-1K10 r *XCMPLX-0K3 r1 *>"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix r1 assume [ty]: "r1 be RealXREAL-0M1"
    obtain s s1 where 
      [ty]:"s be ElementSUBSET-1M1-of REALNUMBERSK2" and sDef:"s = r" and
      [ty]:"s1 be ElementSUBSET-1M1-of REALNUMBERSK2" and s1Def:"s1 = r1"
      using xreal_0_def_1 sorry
    have "s *RVSUM-1K12 (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> s1*>) =HIDDENR1 <*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> ((multrealBINOP-2K11)[;]FUNCOP-1K10\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>(s,idPARTFUN1K6 REALNUMBERSK2)).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1*>"
      using finseq_2_th_35 sorry
    also have "... = <*FINSEQ-1K10 r *XCMPLX-0K3 r1 *>"
      using rvsum_1_lm_1 sorry
    finally have "s *RVSUM-1K12 (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> s1*>) =HIDDENR1 <*FINSEQ-1K10 r *XCMPLX-0K3 r1 *>"
       sorry
    thus "r *RVSUM-1K12 (<*FINSEQ-1K10 r1*>) =FINSEQ-1R1 <*FINSEQ-1K10 r *XCMPLX-0K3 r1 *>"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_48:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 *RVSUM-1K12 (i  |->FINSEQ-2K2 r2) =FINSEQ-1R1 i  |->FINSEQ-2K2 (r1 *XCMPLX-0K3 r2)"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 *RVSUM-1K12 (i  |->FINSEQ-2K2 r2) =FINSEQ-1R1 i  |->FINSEQ-2K2 (r1 *XCMPLX-0K3 r2)"
  proof(rule ballI,rule ballI,rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix r1 assume [ty]: "r1 be RealXREAL-0M1"
    fix r2 assume [ty]: "r2 be RealXREAL-0M1"
    obtain s1 s2 where 
      [ty]:"s1 be ElementSUBSET-1M1-of REALNUMBERSK2" and s1Def:"s1 = r1" and
      [ty]:"s2 be ElementSUBSET-1M1-of REALNUMBERSK2" and s2Def:"s2 = r2"
      using xreal_0_def_1 sorry
    have "s1 *RVSUM-1K13\<^bsub>(i)\<^esub> (i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s2) =HIDDENR1 i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> ((multrealBINOP-2K11)[;]FUNCOP-1K10\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>(s1,idPARTFUN1K6 REALNUMBERSK2)).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2"
      using finseqop_th_16 sorry
    also have "... = i  |->FINSEQ-2K2 (r1 *XCMPLX-0K3 r2)"
      using rvsum_1_lm_1 sorry
    finally have "s1 *RVSUM-1K13\<^bsub>(i)\<^esub> (i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s2) =HIDDENR1 i  |->FINSEQ-2K2 (r1 *XCMPLX-0K3 r2)"
       sorry
    thus "r1 *RVSUM-1K12 (i  |->FINSEQ-2K2 r2) =FINSEQ-1R1 i  |->FINSEQ-2K2 (r1 *XCMPLX-0K3 r2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_49:
" for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds  for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds (r1 *XCMPLX-0K3 r2)*RVSUM-1K12 F =FINSEQ-1R1 r1 *RVSUM-1K12 (r2 *RVSUM-1K12 F)"
  using rfunct_1_th_17 sorry

mtheorem rvsum_1_th_50:
" for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds  for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds (r1 +XCMPLX-0K2 r2)*RVSUM-1K12 F =FINSEQ-1R1 r1 *RVSUM-1K12 F +RVSUM-1K5 r2 *RVSUM-1K12 F"
proof-
  have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds  for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds (r1 +XCMPLX-0K2 r2)*RVSUM-1K12 F =FINSEQ-1R1 r1 *RVSUM-1K12 F +RVSUM-1K5 r2 *RVSUM-1K12 F"
  proof(rule ballI,rule ballI,rule ballI)
    fix r1 assume [ty]: "r1 be RealXREAL-0M1"
    fix r2 assume [ty]: "r2 be RealXREAL-0M1"
    fix F assume [ty]: "F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    have A1: "domFINSEQ-1K5 ((r1 +XCMPLX-0K2 r2)*RVSUM-1K12 F) =XBOOLE-0R4 domFINSEQ-1K5 F"
      using valued_1_def_5 sorry
    have A2: "domFINSEQ-1K5 (r1 *RVSUM-1K12 F +RVSUM-1K5 r2 *RVSUM-1K12 F) =XBOOLE-0R4 domFINSEQ-1K5 (r1 *RVSUM-1K12 F) /\\XBOOLE-0K3 domFINSEQ-1K5 (r2 *RVSUM-1K12 F)"
      using valued_1_def_1 sorry
    have A3: "domFINSEQ-1K5 (r1 *RVSUM-1K12 F) =XBOOLE-0R4 domFINSEQ-1K5 F"
      using valued_1_def_5 sorry
    have A4: "domFINSEQ-1K5 (r2 *RVSUM-1K12 F) =XBOOLE-0R4 domFINSEQ-1K5 F"
      using valued_1_def_5 sorry
    have " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 ((r1 +XCMPLX-0K2 r2)*RVSUM-1K12 F) implies ((r1 +XCMPLX-0K2 r2)*RVSUM-1K12 F).FUNCT-1K1 i =HIDDENR1 (r1 *RVSUM-1K12 F +RVSUM-1K5 r2 *RVSUM-1K12 F).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be NatNAT-1M1"
      assume A5: "i inTARSKIR2 domFINSEQ-1K5 ((r1 +XCMPLX-0K2 r2)*RVSUM-1K12 F)"
      have "((r1 +XCMPLX-0K2 r2)*RVSUM-1K12 F).FUNCT-1K1 i =HIDDENR1 (r1 +XCMPLX-0K2 r2)*XCMPLX-0K3 F .FUNCT-1K1 i"
        using valued_1_th_6 sorry
      also have "... = r1 *XCMPLX-0K3 F .FUNCT-1K1 i +XCMPLX-0K2 r2 *XCMPLX-0K3 F .FUNCT-1K1 i"
         sorry
      also have "... = r1 *XCMPLX-0K3 F .FUNCT-1K1 i +XCMPLX-0K2 (r2 *RVSUM-1K12 F).FUNCT-1K1 i"
        using valued_1_th_6 sorry
      also have "... = (r1 *RVSUM-1K12 F).FUNCT-1K1 i +XCMPLX-0K2 (r2 *RVSUM-1K12 F).FUNCT-1K1 i"
        using valued_1_th_6 sorry
      also have "... = (r1 *RVSUM-1K12 F +RVSUM-1K5 r2 *RVSUM-1K12 F).FUNCT-1K1 i"
        using A1 A2 A3 A4 A5 valued_1_def_1 sorry
      finally show "((r1 +XCMPLX-0K2 r2)*RVSUM-1K12 F).FUNCT-1K1 i =HIDDENR1 (r1 *RVSUM-1K12 F +RVSUM-1K5 r2 *RVSUM-1K12 F).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "(r1 +XCMPLX-0K2 r2)*RVSUM-1K12 F =FINSEQ-1R1 r1 *RVSUM-1K12 F +RVSUM-1K5 r2 *RVSUM-1K12 F"
      using A1 A2 A3 A4 finseq_1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_51:
" for r be RealXREAL-0M1 holds  for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds r *RVSUM-1K12 (F1 +RVSUM-1K5 F2) =FINSEQ-1R1 r *RVSUM-1K12 F1 +RVSUM-1K5 r *RVSUM-1K12 F2"
  using rfunct_1_th_16 sorry

mtheorem rvsum_1_th_52:
" for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds \<one>\<^sub>M *RVSUM-1K12 F =FINSEQ-1R1 F"
  using rfunct_1_th_21 sorry

mtheorem rvsum_1_th_53:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds (0NUMBERSK6)*RVSUM-1K13\<^bsub>(i)\<^esub> R =FINSEQ-1R1 i  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds (0NUMBERSK6)*RVSUM-1K13\<^bsub>(i)\<^esub> R =HIDDENR1 i  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)"
  proof(rule ballI,rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix R assume [ty]: "R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    have A1: "rngRVSUM-1K1 R c=TARSKIR1 REALNUMBERSK2"
       sorry
    have "(0NUMBERSK6)*RVSUM-1K13\<^bsub>(i)\<^esub> R =HIDDENR1 (multrealBINOP-2K11)[;]FUNCOP-1K5(0NUMBERSK6,idPARTFUN1K6 REALNUMBERSK2 *FINSEQOPK4\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> R)"
      using funcop_1_th_34 sorry
    also have "... = (multrealBINOP-2K11)[;]FUNCOP-1K5(0NUMBERSK6,R)"
      using A1 relat_1_th_53 sorry
    also have "... = i  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)"
      using rvsum_1_th_3 rvsum_1_th_8 binop_2_th_2 finseqop_th_76 sorry
    finally show "(0NUMBERSK6)*RVSUM-1K13\<^bsub>(i)\<^esub> R =HIDDENR1 i  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_54:
" for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds (-XCMPLX-0K4 \<one>\<^sub>M)*RVSUM-1K12 F =FINSEQ-1R1 -RVSUM-1K7 F"
   sorry

abbreviation(input) RVSUM_1K14("sqrRVSUM-1K14  _ " [228]228) where
  "sqrRVSUM-1K14 F \<equiv> F ^2VALUED-1K41"

abbreviation(input) RVSUM_1K15("sqrRVSUM-1K15  _ " [228]228) where
  "sqrRVSUM-1K15 F \<equiv> F ^2VALUED-1K41"

mtheorem rvsum_1_def_8:
  mlet "F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
"redefine func sqrRVSUM-1K15 F \<rightarrow> FinSequenceFINSEQ-1M3-of REALNUMBERSK2 equals
  sqrrealRVSUM-1K3 *FUNCT-1K3 F"
proof
(*compatibility*)
  show " for it be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds it =HIDDENR1 sqrRVSUM-1K15 F iff it =HIDDENR1 sqrrealRVSUM-1K3 *FUNCT-1K3 F"
  proof-
    have " for f be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  not (f =HIDDENR1 F ^2VALUED-1K41 &  not f =HIDDENR1 sqrrealRVSUM-1K3 *FUNCT-1K3 F) &  not (f =HIDDENR1 sqrrealRVSUM-1K3 *FUNCT-1K3 F &  not f =HIDDENR1 F ^2VALUED-1K41)"
    proof(rule ballI)
      fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
      have "sqrRVSUM-1K14 F =FINSEQ-1R1 sqrrealRVSUM-1K3 *FUNCT-1K3 F"
      proof-
        have "domRELAT-1K1 (sqrrealRVSUM-1K3) =XBOOLE-0R4 REALNUMBERSK2"
          using funct_2_def_1 sorry
        then have A1: "rngRVSUM-1K1 F c=TARSKIR1 domRELAT-1K1 (sqrrealRVSUM-1K3)"
           sorry
        have A2: "domFINSEQ-1K5 (sqrRVSUM-1K14 F) =HIDDENR1 domFINSEQ-1K5 F"
          using valued_1_th_11 sorry
        also have "... = domFINSEQ-1K5 (sqrrealRVSUM-1K3 *FUNCT-1K3 F)"
          using A1 relat_1_th_27 sorry
        finally have "domFINSEQ-1K5 (sqrRVSUM-1K14 F) =HIDDENR1 domFINSEQ-1K5 (sqrrealRVSUM-1K3 *FUNCT-1K3 F)"
           sorry
        have "lenFINSEQ-1K4 (sqrRVSUM-1K14 F) =XBOOLE-0R4 lenFINSEQ-1K4 (sqrrealRVSUM-1K3 *FUNCT-1K3 F) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 (sqrRVSUM-1K14 F) implies sqrRVSUM-1K14 F .FUNCT-1K1 k =HIDDENR1 (sqrrealRVSUM-1K3 *FUNCT-1K3 F).FUNCT-1K1 k)"
        proof(rule conjMI,rule ballI,rule impI)
          show "lenFINSEQ-1K4 (sqrRVSUM-1K14 F) =XBOOLE-0R4 lenFINSEQ-1K4 (sqrrealRVSUM-1K3 *FUNCT-1K3 F)"
            using finseq_3_th_29 A2 sorry
          fix k assume [ty]: "k be NatNAT-1M1"
          assume "\<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 (sqrRVSUM-1K14 F)"
          then have A3: "k inTARSKIR2 domFINSEQ-1K5 (sqrRVSUM-1K14 F)"
            using finseq_3_th_25 sorry
          have "sqrRVSUM-1K14 F .FUNCT-1K1 k =HIDDENR1 (F .FUNCT-1K1 k)^2SQUARE-1K1"
            using valued_1_th_11 sorry
          also have "... = sqrrealRVSUM-1K3 .FUNCT-1K1 (F .FUNCT-1K1 k)"
            using rvsum_1_def_2 sorry
          also have "... = (sqrrealRVSUM-1K3 *FUNCT-1K3 F).FUNCT-1K1 k"
            using A2 A3 funct_1_th_12 sorry
          finally show "sqrRVSUM-1K14 F .FUNCT-1K1 k =HIDDENR1 (sqrrealRVSUM-1K3 *FUNCT-1K3 F).FUNCT-1K1 k"
             sorry
        qed "sorry"
        thus "sqrRVSUM-1K14 F =FINSEQ-1R1 sqrrealRVSUM-1K3 *FUNCT-1K3 F"
          using finseq_1_def_17 sorry
      qed
      thus " not (f =HIDDENR1 F ^2VALUED-1K41 &  not f =HIDDENR1 sqrrealRVSUM-1K3 *FUNCT-1K3 F) &  not (f =HIDDENR1 sqrrealRVSUM-1K3 *FUNCT-1K3 F &  not f =HIDDENR1 F ^2VALUED-1K41)"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rvsum_1_add_10:
  mlet "F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
"cluster F ^2VALUED-1K41 as-term-is FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
proof
(*coherence*)
  show "F ^2VALUED-1K41 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    using rvsum_1_lm_2 sorry
qed "sorry"

syntax RVSUM_1K16 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("sqrRVSUM-1K16\<^bsub>'( _ ')\<^esub>  _ " [0,228]228)
translations "sqrRVSUM-1K16\<^bsub>(i)\<^esub> R" \<rightharpoonup> "R ^2VALUED-1K41"

mtheorem rvsum_1_add_11:
  mlet "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
"cluster R ^2VALUED-1K41 as-term-is ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
proof
(*coherence*)
  show "R ^2VALUED-1K41 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    using finseq_2_th_113 sorry
qed "sorry"

mtheorem rvsum_1_th_55:
" for r be RealXREAL-0M1 holds sqrRVSUM-1K15 (<*FINSEQ-1K10 r*>) =FINSEQ-1R1 <*FINSEQ-1K10 r ^2SQUARE-1K1*>"
proof-
  have " for r be RealXREAL-0M1 holds sqrRVSUM-1K15 (<*FINSEQ-1K10 r*>) =FINSEQ-1R1 <*FINSEQ-1K10 r ^2SQUARE-1K1*>"
  proof(rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    obtain s where 
      [ty]:"s be ElementSUBSET-1M1-of REALNUMBERSK2" and sDef:"s = r"
      using xreal_0_def_1 sorry
    have "sqrRVSUM-1K15 (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> s*>) =HIDDENR1 <*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> sqrrealRVSUM-1K3 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> s*>"
      using finseq_2_th_35 sorry
    also have "... = <*FINSEQ-1K10 r ^2SQUARE-1K1*>"
      using rvsum_1_def_2 sorry
    finally have "sqrRVSUM-1K15 (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> s*>) =HIDDENR1 <*FINSEQ-1K10 r ^2SQUARE-1K1*>"
       sorry
    thus "sqrRVSUM-1K15 (<*FINSEQ-1K10 r*>) =FINSEQ-1R1 <*FINSEQ-1K10 r ^2SQUARE-1K1*>"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_56:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r be RealXREAL-0M1 holds sqrRVSUM-1K15 (i  |->FINSEQ-2K2 r) =FINSEQ-1R1 i  |->FINSEQ-2K2 r ^2SQUARE-1K1"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r be RealXREAL-0M1 holds sqrRVSUM-1K15 (i  |->FINSEQ-2K2 r) =FINSEQ-1R1 i  |->FINSEQ-2K2 r ^2SQUARE-1K1"
  proof(rule ballI,rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    obtain s where 
      [ty]:"s be ElementSUBSET-1M1-of REALNUMBERSK2" and sDef:"s = r"
      using xreal_0_def_1 sorry
    have "sqrRVSUM-1K16\<^bsub>(i)\<^esub> (i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s) =HIDDENR1 i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> sqrrealRVSUM-1K3 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> s"
      using finseqop_th_16 sorry
    also have "... = i  |->FINSEQ-2K2 r ^2SQUARE-1K1"
      using rvsum_1_def_2 sorry
    finally have "sqrRVSUM-1K16\<^bsub>(i)\<^esub> (i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s) =HIDDENR1 i  |->FINSEQ-2K2 r ^2SQUARE-1K1"
       sorry
    thus "sqrRVSUM-1K15 (i  |->FINSEQ-2K2 r) =FINSEQ-1R1 i  |->FINSEQ-2K2 r ^2SQUARE-1K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_57:
" for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds sqrRVSUM-1K15 (-RVSUM-1K7 F) =FINSEQ-1R1 sqrRVSUM-1K15 F"
proof-
  have " for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds sqrRVSUM-1K15 (-RVSUM-1K7 F) =FINSEQ-1R1 sqrRVSUM-1K15 F"
  proof(rule ballI)
    fix F assume [ty]: "F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    have A1: "domFINSEQ-1K5 (sqrRVSUM-1K15 (-RVSUM-1K7 F)) =HIDDENR1 domFINSEQ-1K5 (-RVSUM-1K7 F)"
      using valued_1_th_11 sorry
    also have "... = domFINSEQ-1K5 F"
      using valued_1_th_8 sorry
    finally have "domFINSEQ-1K5 (sqrRVSUM-1K15 (-RVSUM-1K7 F)) =HIDDENR1 domFINSEQ-1K5 F"
       sorry
    have A2: "domFINSEQ-1K5 (sqrRVSUM-1K15 F) =XBOOLE-0R4 domFINSEQ-1K5 F"
      using valued_1_th_11 sorry
    have " for j be NatNAT-1M1 holds j inTARSKIR2 domFINSEQ-1K5 (sqrRVSUM-1K15 (-RVSUM-1K7 F)) implies sqrRVSUM-1K15 (-RVSUM-1K7 F) .FUNCT-1K1 j =HIDDENR1 sqrRVSUM-1K15 F .FUNCT-1K1 j"
    proof(rule ballI,rule impI)
      fix j assume [ty]: "j be NatNAT-1M1"
      assume "j inTARSKIR2 domFINSEQ-1K5 (sqrRVSUM-1K15 (-RVSUM-1K7 F))"
      let ?r = "F .FUNCT-1K1 j"
      let ?r9 = "(-RVSUM-1K7 F).FUNCT-1K1 j"
      have "sqrRVSUM-1K15 (-RVSUM-1K7 F) .FUNCT-1K1 j =HIDDENR1 ((-RVSUM-1K7 F).FUNCT-1K1 j)^2SQUARE-1K1"
        using valued_1_th_11 sorry
      also have "... = (-XCMPLX-0K4 F .FUNCT-1K1 j)^2SQUARE-1K1"
        using valued_1_th_8 sorry
      also have "... = (F .FUNCT-1K1 j)^2SQUARE-1K1"
         sorry
      also have "... = sqrRVSUM-1K15 F .FUNCT-1K1 j"
        using valued_1_th_11 sorry
      finally show "sqrRVSUM-1K15 (-RVSUM-1K7 F) .FUNCT-1K1 j =HIDDENR1 sqrRVSUM-1K15 F .FUNCT-1K1 j"
         sorry
    qed "sorry"
    thus "sqrRVSUM-1K15 (-RVSUM-1K7 F) =FINSEQ-1R1 sqrRVSUM-1K15 F"
      using A1 A2 finseq_1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_58:
" for r be RealXREAL-0M1 holds  for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds sqrRVSUM-1K15 (r *RVSUM-1K12 F) =FINSEQ-1R1 r ^2SQUARE-1K1 *RVSUM-1K12 sqrRVSUM-1K15 F"
proof-
  have " for r be RealXREAL-0M1 holds  for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds sqrRVSUM-1K15 (r *RVSUM-1K12 F) =FINSEQ-1R1 r ^2SQUARE-1K1 *RVSUM-1K12 sqrRVSUM-1K15 F"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix F assume [ty]: "F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    have A1: "domFINSEQ-1K5 (r *RVSUM-1K12 F) =XBOOLE-0R4 domFINSEQ-1K5 F"
      using valued_1_def_5 sorry
    have A2: "domFINSEQ-1K5 (r ^2SQUARE-1K1 *RVSUM-1K12 sqrRVSUM-1K15 F) =XBOOLE-0R4 domFINSEQ-1K5 (sqrRVSUM-1K15 F)"
      using valued_1_def_5 sorry
    have A3: "domFINSEQ-1K5 (sqrRVSUM-1K15 F) =XBOOLE-0R4 domFINSEQ-1K5 F"
      using valued_1_th_11 sorry
    have " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 (sqrRVSUM-1K15 (r *RVSUM-1K12 F)) implies sqrRVSUM-1K15 (r *RVSUM-1K12 F) .FUNCT-1K1 i =HIDDENR1 (r ^2SQUARE-1K1 *RVSUM-1K12 sqrRVSUM-1K15 F).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be NatNAT-1M1"
      assume "i inTARSKIR2 domFINSEQ-1K5 (sqrRVSUM-1K15 (r *RVSUM-1K12 F))"
      have "sqrRVSUM-1K15 (r *RVSUM-1K12 F) .FUNCT-1K1 i =HIDDENR1 ((r *RVSUM-1K12 F).FUNCT-1K1 i)^2SQUARE-1K1"
        using valued_1_th_11 sorry
      also have "... = (r *XCMPLX-0K3 F .FUNCT-1K1 i)^2SQUARE-1K1"
        using valued_1_th_6 sorry
      also have "... = r ^2SQUARE-1K1 *XCMPLX-0K3 (F .FUNCT-1K1 i)^2SQUARE-1K1"
         sorry
      also have "... = r ^2SQUARE-1K1 *XCMPLX-0K3 sqrRVSUM-1K15 F .FUNCT-1K1 i"
        using valued_1_th_11 sorry
      also have "... = (r ^2SQUARE-1K1 *RVSUM-1K12 sqrRVSUM-1K15 F).FUNCT-1K1 i"
        using valued_1_th_6 sorry
      finally show "sqrRVSUM-1K15 (r *RVSUM-1K12 F) .FUNCT-1K1 i =HIDDENR1 (r ^2SQUARE-1K1 *RVSUM-1K12 sqrRVSUM-1K15 F).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "sqrRVSUM-1K15 (r *RVSUM-1K12 F) =FINSEQ-1R1 r ^2SQUARE-1K1 *RVSUM-1K12 sqrRVSUM-1K15 F"
      using A1 A2 A3 finseq_1_th_13 valued_1_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) RVSUM_1K17("mltRVSUM-1K17'( _ , _ ')" [0,0]228) where
  "mltRVSUM-1K17(F1,F2) \<equiv> F1 (#)VALUED-1K19 F2"

abbreviation(input) RVSUM_1K18("mltRVSUM-1K18'( _ , _ ')" [0,0]228) where
  "mltRVSUM-1K18(F1,F2) \<equiv> F1 (#)VALUED-1K19 F2"

mtheorem rvsum_1_def_9:
  mlet "F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1", "F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
"redefine func mltRVSUM-1K18(F1,F2) \<rightarrow> FinSequenceFINSEQ-1M3-of REALNUMBERSK2 equals
  (multrealBINOP-2K11).:FUNCOP-1K3(F1,F2)"
proof
(*compatibility*)
  show " for it be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds it =HIDDENR1 mltRVSUM-1K18(F1,F2) iff it =HIDDENR1 (multrealBINOP-2K11).:FUNCOP-1K3(F1,F2)"
  proof-
    have " for F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (F =FINSEQ-1R1 mltRVSUM-1K17(F1,F2) implies F =FUNCT-1R1 (multrealBINOP-2K11).:FUNCOP-1K3(F1,F2)) & (F =FUNCT-1R1 (multrealBINOP-2K11).:FUNCOP-1K3(F1,F2) implies F =HIDDENR1 F1 (#)VALUED-1K19 F2)"
    proof(rule ballI,rule conjMI,rule impI)
      obtain F3 F4 where 
        [ty]:"F3 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2" and F3Def:"F3 = F1" and
        [ty]:"F4 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2" and F4Def:"F4 = F2"
        using rvsum_1_lm_2 sorry
      fix F assume [ty]: "F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
      have "domRELAT-1K1 (multrealBINOP-2K11) =XBOOLE-0R4 [:ZFMISC-1K2 REALNUMBERSK2,REALNUMBERSK2 :]"
        using funct_2_def_1 sorry
      then have "[:ZFMISC-1K2 rngRVSUM-1K1 F3,rngRVSUM-1K1 F4 :] c=RELAT-1R2 domRELAT-1K1 (multrealBINOP-2K11)"
        using zfmisc_1_th_96 sorry
      then have A1: "domRELAT-1K1 ((multrealBINOP-2K11).:FUNCOP-1K3(F1,F2)) =XBOOLE-0R4 domFINSEQ-1K5 F1 /\\XBOOLE-0K3 domFINSEQ-1K5 F2"
        using funcop_1_th_69 sorry
      have A2: "domFINSEQ-1K5 (mltRVSUM-1K17(F1,F2)) =XBOOLE-0R4 domFINSEQ-1K5 F1 /\\XBOOLE-0K3 domFINSEQ-1K5 F2"
        using valued_1_def_4 sorry
      show "F =FINSEQ-1R1 mltRVSUM-1K17(F1,F2) implies F =FUNCT-1R1 (multrealBINOP-2K11).:FUNCOP-1K3(F1,F2)"
      proof(rule impI)
        assume A3: "F =FINSEQ-1R1 mltRVSUM-1K17(F1,F2)"
        have " for z be setHIDDENM2 holds z inTARSKIR2 domRELAT-1K1 ((multrealBINOP-2K11).:FUNCOP-1K3(F1,F2)) implies F .FUNCT-1K1 z =XBOOLE-0R4 (multrealBINOP-2K11).BINOP-1K1(F1 .FUNCT-1K1 z,F2 .FUNCT-1K1 z)"
        proof-
          have " for z be setHIDDENM2 holds z inTARSKIR2 domRELAT-1K1 ((multrealBINOP-2K11).:FUNCOP-1K3(F1,F2)) implies F .FUNCT-1K1 z =HIDDENR1 (multrealBINOP-2K11).BINOP-1K1(F1 .FUNCT-1K1 z,F2 .FUNCT-1K1 z)"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be setHIDDENM2"
            assume "z inTARSKIR2 domRELAT-1K1 ((multrealBINOP-2K11).:FUNCOP-1K3(F1,F2))"
            have "F .FUNCT-1K1 z =HIDDENR1 F1 .FUNCT-1K1 z *XCMPLX-0K3 F2 .FUNCT-1K1 z"
              using A3 valued_1_th_5 sorry
            also have "... = (multrealBINOP-2K11).BINOP-1K1(F1 .FUNCT-1K1 z,F2 .FUNCT-1K1 z)"
              using binop_2_def_11 sorry
            finally show "F .FUNCT-1K1 z =HIDDENR1 (multrealBINOP-2K11).BINOP-1K1(F1 .FUNCT-1K1 z,F2 .FUNCT-1K1 z)"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "F =FUNCT-1R1 (multrealBINOP-2K11).:FUNCOP-1K3(F1,F2)"
          using A2 A1 A3 funcop_1_th_21 sorry
      qed
      assume A4: "F =FUNCT-1R1 (multrealBINOP-2K11).:FUNCOP-1K3(F1,F2)"
      have " for c be objectHIDDENM1 holds c inHIDDENR3 domFINSEQ-1K5 F implies F .FUNCT-1K1 c =HIDDENR1 F1 .FUNCT-1K1 c *XCMPLX-0K3 F2 .FUNCT-1K1 c"
      proof(rule ballI,rule impI)
        fix c assume [ty]: "c be objectHIDDENM1"
        assume "c inHIDDENR3 domFINSEQ-1K5 F"
        then have "F .FUNCT-1K1 c =HIDDENR1 (multrealBINOP-2K11).BINOP-1K1(F1 .FUNCT-1K1 c,F2 .FUNCT-1K1 c)"
          using A4 funcop_1_th_22 sorry
        also have "... = F1 .FUNCT-1K1 c *XCMPLX-0K3 F2 .FUNCT-1K1 c"
          using binop_2_def_11 sorry
        finally show "F .FUNCT-1K1 c =HIDDENR1 F1 .FUNCT-1K1 c *XCMPLX-0K3 F2 .FUNCT-1K1 c"
           sorry
      qed "sorry"
      thus "F =HIDDENR1 F1 (#)VALUED-1K19 F2"
        using A1 A4 valued_1_def_4 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rvsum_1_add_12:
  mlet "F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1", "F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
"cluster F1 (#)VALUED-1K19 F2 as-term-is FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
proof
(*coherence*)
  show "F1 (#)VALUED-1K19 F2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    using rvsum_1_lm_2 sorry
qed "sorry"

mtheorem RVSUM_1K18_commutativity:
" for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds mltRVSUM-1K18(F1,F2) =HIDDENR1 mltRVSUM-1K18(F2,F1)"
proof-
  have " for it be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds it =HIDDENR1 mltRVSUM-1K18(F1,F2) implies it =HIDDENR1 mltRVSUM-1K18(F2,F1)"
  proof-
    have " for it be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds it =HIDDENR1 (multrealBINOP-2K11).:FUNCOP-1K3(F1,F2) implies it =HIDDENR1 (multrealBINOP-2K11).:FUNCOP-1K3(F2,F1)"
    proof-
      have " for F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds F =FUNCT-1R1 (multrealBINOP-2K11).:FUNCOP-1K3(F1,F2) implies F =HIDDENR1 (multrealBINOP-2K11).:FUNCOP-1K3(F2,F1)"
      proof(rule ballI,rule ballI,rule ballI,rule impI)
        fix F assume [ty]: "F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
        fix F1 assume [ty]: "F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
        fix F2 assume [ty]: "F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
        obtain F3 F4 where 
          [ty]:"F3 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2" and F3Def:"F3 = F1" and
          [ty]:"F4 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2" and F4Def:"F4 = F2"
          using rvsum_1_lm_2 sorry
        have A5: "domRELAT-1K1 (multrealBINOP-2K11) =XBOOLE-0R4 [:ZFMISC-1K2 REALNUMBERSK2,REALNUMBERSK2 :]"
          using funct_2_def_1 sorry
        then have A6: "[:ZFMISC-1K2 rngRVSUM-1K1 F4,rngRVSUM-1K1 F3 :] c=RELAT-1R2 domRELAT-1K1 (multrealBINOP-2K11)"
          using zfmisc_1_th_96 sorry
        have "[:ZFMISC-1K2 rngRVSUM-1K1 F3,rngRVSUM-1K1 F4 :] c=RELAT-1R2 domRELAT-1K1 (multrealBINOP-2K11)"
          using A5 zfmisc_1_th_96 sorry
        then have A7: "domRELAT-1K1 ((multrealBINOP-2K11).:FUNCOP-1K3(F1,F2)) =HIDDENR1 domFINSEQ-1K5 F1 /\\XBOOLE-0K3 domFINSEQ-1K5 F2"
          using funcop_1_th_69 sorry
        also have "... = domRELAT-1K1 ((multrealBINOP-2K11).:FUNCOP-1K3(F2,F1))"
          using A6 funcop_1_th_69 sorry
        finally have "domRELAT-1K1 ((multrealBINOP-2K11).:FUNCOP-1K3(F1,F2)) =HIDDENR1 domRELAT-1K1 ((multrealBINOP-2K11).:FUNCOP-1K3(F2,F1))"
           sorry
        assume A8: "F =FUNCT-1R1 (multrealBINOP-2K11).:FUNCOP-1K3(F1,F2)"
        have " for z be setHIDDENM2 holds z inTARSKIR2 domRELAT-1K1 ((multrealBINOP-2K11).:FUNCOP-1K3(F2,F1)) implies F .FUNCT-1K1 z =XBOOLE-0R4 (multrealBINOP-2K11).BINOP-1K1(F2 .FUNCT-1K1 z,F1 .FUNCT-1K1 z)"
        proof-
          have " for z be setHIDDENM2 holds z inTARSKIR2 domRELAT-1K1 ((multrealBINOP-2K11).:FUNCOP-1K3(F2,F1)) implies F .FUNCT-1K1 z =HIDDENR1 (multrealBINOP-2K11).BINOP-1K1(F2 .FUNCT-1K1 z,F1 .FUNCT-1K1 z)"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be setHIDDENM2"
            assume A9: "z inTARSKIR2 domRELAT-1K1 ((multrealBINOP-2K11).:FUNCOP-1K3(F2,F1))"
            let ?F1z = "F1 .FUNCT-1K1 z"
            let ?F2z = "F2 .FUNCT-1K1 z"
            have "F .FUNCT-1K1 z =HIDDENR1 (multrealBINOP-2K11).BINOP-1K1(F1 .FUNCT-1K1 z,F2 .FUNCT-1K1 z)"
              using A8 A7 A9 funcop_1_th_22 sorry
            also have "... = F1 .FUNCT-1K1 z *XCMPLX-0K3 F2 .FUNCT-1K1 z"
              using binop_2_def_11 sorry
            also have "... = (multrealBINOP-2K11).BINOP-1K1(F2 .FUNCT-1K1 z,F1 .FUNCT-1K1 z)"
              using binop_2_def_11 sorry
            finally show "F .FUNCT-1K1 z =HIDDENR1 (multrealBINOP-2K11).BINOP-1K1(F2 .FUNCT-1K1 z,F1 .FUNCT-1K1 z)"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "F =HIDDENR1 (multrealBINOP-2K11).:FUNCOP-1K3(F2,F1)"
          using A8 A7 funcop_1_th_21 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus " ?thesis "
      using rvsum_1_def_9 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_59:
" for s be setHIDDENM2 holds  for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds mltRVSUM-1K18(F1,F2) .FUNCT-1K1 s =XBOOLE-0R4 F1 .FUNCT-1K1 s *XCMPLX-0K3 F2 .FUNCT-1K1 s"
  using valued_1_th_5 sorry

syntax RVSUM_1K19 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("mltRVSUM-1K19\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]228)
translations "mltRVSUM-1K19\<^bsub>(i)\<^esub>(R1,R2)" \<rightharpoonup> "R1 (#)VALUED-1K19 R2"

mtheorem rvsum_1_add_13:
  mlet "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2", "R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
"cluster R1 (#)VALUED-1K19 R2 as-term-is ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
proof
(*coherence*)
  show "R1 (#)VALUED-1K19 R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    using finseq_2_th_120 sorry
qed "sorry"

mtheorem rvsum_1_th_60:
" for s be setHIDDENM2 holds  for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds mltRVSUM-1K18(F1,F2) .FUNCT-1K1 s =XBOOLE-0R4 F1 .FUNCT-1K1 s *XCMPLX-0K3 F2 .FUNCT-1K1 s"
  using valued_1_th_5 sorry

mtheorem rvsum_1_th_61:
" for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds mltRVSUM-1K18(<*>FINSEQ-1K7 REALNUMBERSK2,F) =FINSEQ-1R1 <*>FINSEQ-1K7 REALNUMBERSK2"
proof-
  have " for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds mltRVSUM-1K18(<*>FINSEQ-1K7 REALNUMBERSK2,F) =FINSEQ-1R1 <*>FINSEQ-1K7 REALNUMBERSK2"
  proof(rule ballI)
    fix F assume [ty]: "F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    have "F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
      using rvsum_1_lm_2 sorry
    thus "mltRVSUM-1K18(<*>FINSEQ-1K7 REALNUMBERSK2,F) =FINSEQ-1R1 <*>FINSEQ-1K7 REALNUMBERSK2"
      using finseq_2_th_73 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_62:
" for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds mltRVSUM-1K18(<*FINSEQ-1K10 r1*>,<*FINSEQ-1K10 r2*>) =FINSEQ-1R1 <*FINSEQ-1K10 r1 *XCMPLX-0K3 r2 *>"
proof-
  have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds mltRVSUM-1K18(<*FINSEQ-1K10 r1*>,<*FINSEQ-1K10 r2*>) =FINSEQ-1R1 <*FINSEQ-1K10 r1 *XCMPLX-0K3 r2 *>"
  proof(rule ballI,rule ballI)
    fix r1 assume [ty]: "r1 be RealXREAL-0M1"
    fix r2 assume [ty]: "r2 be RealXREAL-0M1"
    obtain s1 s2 where 
      [ty]:"s1 be ElementSUBSET-1M1-of REALNUMBERSK2" and s1Def:"s1 = r1" and
      [ty]:"s2 be ElementSUBSET-1M1-of REALNUMBERSK2" and s2Def:"s2 = r2"
      using xreal_0_def_1 sorry
    have "mltRVSUM-1K18(<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> s1*>,<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> s2*>) =HIDDENR1 <*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> (multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(s1,s2)*>"
      using finseq_2_th_74 sorry
    also have "... = <*FINSEQ-1K10 r1 *XCMPLX-0K3 r2 *>"
      using binop_2_def_11 sorry
    finally have "mltRVSUM-1K18(<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> s1*>,<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> s2*>) =HIDDENR1 <*FINSEQ-1K10 r1 *XCMPLX-0K3 r2 *>"
       sorry
    thus "mltRVSUM-1K18(<*FINSEQ-1K10 r1*>,<*FINSEQ-1K10 r2*>) =FINSEQ-1R1 <*FINSEQ-1K10 r1 *XCMPLX-0K3 r2 *>"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_63:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r be RealXREAL-0M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds mltRVSUM-1K18(i  |->FINSEQ-2K2 r,R) =FINSEQ-1R1 r *RVSUM-1K13\<^bsub>(i)\<^esub> R"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r be RealXREAL-0M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds mltRVSUM-1K18(i  |->FINSEQ-2K2 r,R) =FINSEQ-1R1 r *RVSUM-1K13\<^bsub>(i)\<^esub> R"
  proof(rule ballI,rule ballI,rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix R assume [ty]: "R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    obtain s where 
      [ty]:"s be ElementSUBSET-1M1-of REALNUMBERSK2" and sDef:"s = r"
      using xreal_0_def_1 sorry
    have "mltRVSUM-1K19\<^bsub>(i)\<^esub>(i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s,R) =HIDDENR1 (multrealBINOP-2K11)[;]FINSEQOPK3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub>(s,R)"
      using finseqop_th_20 sorry
    also have "... = r *RVSUM-1K13\<^bsub>(i)\<^esub> R"
      using finseqop_th_22 sorry
    finally have "mltRVSUM-1K19\<^bsub>(i)\<^esub>(i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s,R) =HIDDENR1 r *RVSUM-1K13\<^bsub>(i)\<^esub> R"
       sorry
    thus "mltRVSUM-1K18(i  |->FINSEQ-2K2 r,R) =FINSEQ-1R1 r *RVSUM-1K13\<^bsub>(i)\<^esub> R"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_64:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds mltRVSUM-1K18(i  |->FINSEQ-2K2 r1,i  |->FINSEQ-2K2 r2) =FINSEQ-1R1 i  |->FINSEQ-2K2 (r1 *XCMPLX-0K3 r2)"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds mltRVSUM-1K18(i  |->FINSEQ-2K2 r1,i  |->FINSEQ-2K2 r2) =FINSEQ-1R1 i  |->FINSEQ-2K2 (r1 *XCMPLX-0K3 r2)"
  proof(rule ballI,rule ballI,rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix r1 assume [ty]: "r1 be RealXREAL-0M1"
    fix r2 assume [ty]: "r2 be RealXREAL-0M1"
    obtain s1 s2 where 
      [ty]:"s1 be ElementSUBSET-1M1-of REALNUMBERSK2" and s1Def:"s1 = r1" and
      [ty]:"s2 be ElementSUBSET-1M1-of REALNUMBERSK2" and s2Def:"s2 = r2"
      using xreal_0_def_1 sorry
    have "mltRVSUM-1K19\<^bsub>(i)\<^esub>(i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s1,i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s2) =HIDDENR1 s1 *RVSUM-1K13\<^bsub>(i)\<^esub> (i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s2)"
      using rvsum_1_th_63 sorry
    also have "... = i  |->FINSEQ-2K2 (r1 *XCMPLX-0K3 r2)"
      using rvsum_1_th_48 sorry
    finally have "mltRVSUM-1K19\<^bsub>(i)\<^esub>(i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s1,i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s2) =HIDDENR1 i  |->FINSEQ-2K2 (r1 *XCMPLX-0K3 r2)"
       sorry
    thus "mltRVSUM-1K18(i  |->FINSEQ-2K2 r1,i  |->FINSEQ-2K2 r2) =FINSEQ-1R1 i  |->FINSEQ-2K2 (r1 *XCMPLX-0K3 r2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_65:
" for r be RealXREAL-0M1 holds  for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds r *RVSUM-1K12 mltRVSUM-1K18(F1,F2) =FINSEQ-1R1 mltRVSUM-1K18(r *RVSUM-1K12 F1,F2)"
  using rfunct_1_th_12 sorry

mtheorem rvsum_1_th_66:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r be RealXREAL-0M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds r *RVSUM-1K13\<^bsub>(i)\<^esub> R =FINSEQ-1R1 mltRVSUM-1K18(i  |->FINSEQ-2K2 r,R)"
  using rvsum_1_th_63 sorry

mtheorem rvsum_1_th_67:
" for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds sqrRVSUM-1K15 F =FINSEQ-1R1 mltRVSUM-1K18(F,F)"
   sorry

mtheorem rvsum_1_th_68:
" for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds sqrRVSUM-1K15 (F1 +RVSUM-1K5 F2) =FINSEQ-1R1 (sqrRVSUM-1K15 F1 +RVSUM-1K5 \<two>\<^sub>M *RVSUM-1K12 mltRVSUM-1K18(F1,F2))+RVSUM-1K5 sqrRVSUM-1K15 F2"
proof-
  have " for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds sqrRVSUM-1K15 (F1 +RVSUM-1K5 F2) =FINSEQ-1R1 (sqrRVSUM-1K15 F1 +RVSUM-1K5 \<two>\<^sub>M *RVSUM-1K12 mltRVSUM-1K18(F1,F2))+RVSUM-1K5 sqrRVSUM-1K15 F2"
  proof(rule ballI,rule ballI)
    fix F1 assume [ty]: "F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    fix F2 assume [ty]: "F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    have A1: "domFINSEQ-1K5 (sqrRVSUM-1K15 (F1 +RVSUM-1K5 F2)) =XBOOLE-0R4 domFINSEQ-1K5 (F1 +RVSUM-1K5 F2)"
      using valued_1_th_11 sorry
    have A2: "domFINSEQ-1K5 (F1 +RVSUM-1K5 F2) =XBOOLE-0R4 domFINSEQ-1K5 F1 /\\XBOOLE-0K3 domFINSEQ-1K5 F2"
      using valued_1_def_1 sorry
    have A3: "domFINSEQ-1K5 (sqrRVSUM-1K15 F1 +RVSUM-1K5 \<two>\<^sub>M *RVSUM-1K12 mltRVSUM-1K18(F1,F2)) =HIDDENR1 domFINSEQ-1K5 (sqrRVSUM-1K15 F1) /\\XBOOLE-0K3 domFINSEQ-1K5 (\<two>\<^sub>M *RVSUM-1K12 mltRVSUM-1K18(F1,F2))"
      using valued_1_def_1 sorry
    also have "... = domFINSEQ-1K5 F1 /\\XBOOLE-0K3 domFINSEQ-1K5 (\<two>\<^sub>M *RVSUM-1K12 mltRVSUM-1K18(F1,F2))"
      using valued_1_th_11 sorry
    also have "... = domFINSEQ-1K5 F1 /\\XBOOLE-0K3 domFINSEQ-1K5 (mltRVSUM-1K18(F1,F2))"
      using valued_1_def_5 sorry
    also have "... = domFINSEQ-1K5 F1 /\\XBOOLE-0K3 (domFINSEQ-1K5 F1 /\\XBOOLE-0K3 domFINSEQ-1K5 F2)"
      using valued_1_def_4 sorry
    also have "... = (domFINSEQ-1K5 F1 /\\XBOOLE-0K3 domFINSEQ-1K5 F1)/\\XBOOLE-0K3 domFINSEQ-1K5 F2"
      using xboole_1_th_16 sorry
    also have "... = domFINSEQ-1K5 F1 /\\XBOOLE-0K3 domFINSEQ-1K5 F2"
       sorry
    finally have "domFINSEQ-1K5 (sqrRVSUM-1K15 F1 +RVSUM-1K5 \<two>\<^sub>M *RVSUM-1K12 mltRVSUM-1K18(F1,F2)) =HIDDENR1 domFINSEQ-1K5 F1 /\\XBOOLE-0K3 domFINSEQ-1K5 F2"
       sorry
    then have A4: "domFINSEQ-1K5 ((sqrRVSUM-1K15 F1 +RVSUM-1K5 \<two>\<^sub>M *RVSUM-1K12 mltRVSUM-1K18(F1,F2))+RVSUM-1K5 sqrRVSUM-1K15 F2) =HIDDENR1 (domFINSEQ-1K5 F1 /\\XBOOLE-0K3 domFINSEQ-1K5 F2)/\\XBOOLE-0K3 domFINSEQ-1K5 (sqrRVSUM-1K15 F2)"
      using valued_1_def_1 sorry
    also have "... = (domFINSEQ-1K5 F1 /\\XBOOLE-0K3 domFINSEQ-1K5 F2)/\\XBOOLE-0K3 domFINSEQ-1K5 F2"
      using valued_1_th_11 sorry
    also have "... = domFINSEQ-1K5 F1 /\\XBOOLE-0K3 (domFINSEQ-1K5 F2 /\\XBOOLE-0K3 domFINSEQ-1K5 F2)"
      using xboole_1_th_16 sorry
    finally have "domFINSEQ-1K5 ((sqrRVSUM-1K15 F1 +RVSUM-1K5 \<two>\<^sub>M *RVSUM-1K12 mltRVSUM-1K18(F1,F2))+RVSUM-1K5 sqrRVSUM-1K15 F2) =HIDDENR1 domFINSEQ-1K5 F1 /\\XBOOLE-0K3 (domFINSEQ-1K5 F2 /\\XBOOLE-0K3 domFINSEQ-1K5 F2)"
       sorry
    have " for j be NatNAT-1M1 holds j inTARSKIR2 domFINSEQ-1K5 (sqrRVSUM-1K15 (F1 +RVSUM-1K5 F2)) implies sqrRVSUM-1K15 (F1 +RVSUM-1K5 F2) .FUNCT-1K1 j =HIDDENR1 ((sqrRVSUM-1K15 F1 +RVSUM-1K5 \<two>\<^sub>M *RVSUM-1K12 mltRVSUM-1K18(F1,F2))+RVSUM-1K5 sqrRVSUM-1K15 F2).FUNCT-1K1 j"
    proof(rule ballI,rule impI)
      fix j assume [ty]: "j be NatNAT-1M1"
      assume A5: "j inTARSKIR2 domFINSEQ-1K5 (sqrRVSUM-1K15 (F1 +RVSUM-1K5 F2))"
      let ?r1r2 = "(F1 +RVSUM-1K5 F2).FUNCT-1K1 j"
      let ?r1 = "F1 .FUNCT-1K1 j"
      let ?r2 = "F2 .FUNCT-1K1 j"
      let ?r192 = "sqrRVSUM-1K15 F1 .FUNCT-1K1 j"
      let ?r292 = "sqrRVSUM-1K15 F2 .FUNCT-1K1 j"
      let ?r1r2a = "mltRVSUM-1K18(F1,F2) .FUNCT-1K1 j"
      let ?D2r1r2 = "(\<two>\<^sub>M *RVSUM-1K12 mltRVSUM-1K18(F1,F2)).FUNCT-1K1 j"
      let ?r1922r1r2 = "(sqrRVSUM-1K15 F1 +RVSUM-1K5 \<two>\<^sub>M *RVSUM-1K12 mltRVSUM-1K18(F1,F2)).FUNCT-1K1 j"
      have "sqrRVSUM-1K15 (F1 +RVSUM-1K5 F2) .FUNCT-1K1 j =HIDDENR1 ((F1 +RVSUM-1K5 F2).FUNCT-1K1 j)^2SQUARE-1K1"
        using valued_1_th_11 sorry
      also have "... = (F1 .FUNCT-1K1 j +XCMPLX-0K2 F2 .FUNCT-1K1 j)^2SQUARE-1K1"
        using A1 A5 valued_1_def_1 sorry
      also have "... = ((F1 .FUNCT-1K1 j)^2SQUARE-1K1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 F1 .FUNCT-1K1 j)*XCMPLX-0K3 F2 .FUNCT-1K1 j)+XCMPLX-0K2 (F2 .FUNCT-1K1 j)^2SQUARE-1K1"
         sorry
      also have "... = (sqrRVSUM-1K15 F1 .FUNCT-1K1 j +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (F1 .FUNCT-1K1 j *XCMPLX-0K3 F2 .FUNCT-1K1 j))+XCMPLX-0K2 (F2 .FUNCT-1K1 j)^2SQUARE-1K1"
        using valued_1_th_11 sorry
      also have "... = (sqrRVSUM-1K15 F1 .FUNCT-1K1 j +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (F1 .FUNCT-1K1 j *XCMPLX-0K3 F2 .FUNCT-1K1 j))+XCMPLX-0K2 sqrRVSUM-1K15 F2 .FUNCT-1K1 j"
        using valued_1_th_11 sorry
      also have "... = (sqrRVSUM-1K15 F1 .FUNCT-1K1 j +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 mltRVSUM-1K18(F1,F2) .FUNCT-1K1 j)+XCMPLX-0K2 sqrRVSUM-1K15 F2 .FUNCT-1K1 j"
        using valued_1_th_5 sorry
      also have "... = (sqrRVSUM-1K15 F1 .FUNCT-1K1 j +XCMPLX-0K2 (\<two>\<^sub>M *RVSUM-1K12 mltRVSUM-1K18(F1,F2)).FUNCT-1K1 j)+XCMPLX-0K2 sqrRVSUM-1K15 F2 .FUNCT-1K1 j"
        using valued_1_th_6 sorry
      also have "... = (sqrRVSUM-1K15 F1 +RVSUM-1K5 \<two>\<^sub>M *RVSUM-1K12 mltRVSUM-1K18(F1,F2)).FUNCT-1K1 j +XCMPLX-0K2 sqrRVSUM-1K15 F2 .FUNCT-1K1 j"
        using A1 A2 A3 A5 valued_1_def_1 sorry
      also have "... = ((sqrRVSUM-1K15 F1 +RVSUM-1K5 \<two>\<^sub>M *RVSUM-1K12 mltRVSUM-1K18(F1,F2))+RVSUM-1K5 sqrRVSUM-1K15 F2).FUNCT-1K1 j"
        using A1 A2 A4 A5 valued_1_def_1 sorry
      finally show "sqrRVSUM-1K15 (F1 +RVSUM-1K5 F2) .FUNCT-1K1 j =HIDDENR1 ((sqrRVSUM-1K15 F1 +RVSUM-1K5 \<two>\<^sub>M *RVSUM-1K12 mltRVSUM-1K18(F1,F2))+RVSUM-1K5 sqrRVSUM-1K15 F2).FUNCT-1K1 j"
         sorry
    qed "sorry"
    thus "sqrRVSUM-1K15 (F1 +RVSUM-1K5 F2) =FINSEQ-1R1 (sqrRVSUM-1K15 F1 +RVSUM-1K5 \<two>\<^sub>M *RVSUM-1K12 mltRVSUM-1K18(F1,F2))+RVSUM-1K5 sqrRVSUM-1K15 F2"
      using A2 A4 finseq_1_th_13 valued_1_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_69:
" for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds sqrRVSUM-1K15 (F1 -RVSUM-1K9 F2) =FINSEQ-1R1 (sqrRVSUM-1K15 F1 -RVSUM-1K9 \<two>\<^sub>M *RVSUM-1K12 mltRVSUM-1K18(F1,F2))+RVSUM-1K5 sqrRVSUM-1K15 F2"
proof-
  have " for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds sqrRVSUM-1K15 (F1 -RVSUM-1K9 F2) =HIDDENR1 (sqrRVSUM-1K15 F1 -RVSUM-1K9 \<two>\<^sub>M *RVSUM-1K12 mltRVSUM-1K18(F1,F2))+RVSUM-1K5 sqrRVSUM-1K15 F2"
  proof(rule ballI,rule ballI)
    fix F1 assume [ty]: "F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    fix F2 assume [ty]: "F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    have "sqrRVSUM-1K15 (F1 -RVSUM-1K9 F2) =HIDDENR1 (sqrRVSUM-1K15 F1 +RVSUM-1K5 \<two>\<^sub>M *RVSUM-1K12 mltRVSUM-1K18(F1,-RVSUM-1K7 F2))+RVSUM-1K5 sqrRVSUM-1K15 (-RVSUM-1K7 F2)"
      using rvsum_1_th_68 sorry
    also have "... = (sqrRVSUM-1K15 F1 +RVSUM-1K5 \<two>\<^sub>M *RVSUM-1K12 mltRVSUM-1K18(F1,-RVSUM-1K7 F2))+RVSUM-1K5 sqrRVSUM-1K15 F2"
      using rvsum_1_th_57 sorry
    also have "... = (sqrRVSUM-1K15 F1 +RVSUM-1K5 \<two>\<^sub>M *RVSUM-1K12 ((-XCMPLX-0K4 \<one>\<^sub>M)*RVSUM-1K12 mltRVSUM-1K18(F1,F2)))+RVSUM-1K5 sqrRVSUM-1K15 F2"
      using rfunct_1_th_12 sorry
    also have "... = (sqrRVSUM-1K15 F1 +RVSUM-1K5 ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 \<two>\<^sub>M)*RVSUM-1K12 mltRVSUM-1K18(F1,F2))+RVSUM-1K5 sqrRVSUM-1K15 F2"
      using rfunct_1_th_17 sorry
    also have "... = (sqrRVSUM-1K15 F1 -RVSUM-1K9 \<two>\<^sub>M *RVSUM-1K12 mltRVSUM-1K18(F1,F2))+RVSUM-1K5 sqrRVSUM-1K15 F2"
      using rfunct_1_th_17 sorry
    finally show "sqrRVSUM-1K15 (F1 -RVSUM-1K9 F2) =HIDDENR1 (sqrRVSUM-1K15 F1 -RVSUM-1K9 \<two>\<^sub>M *RVSUM-1K12 mltRVSUM-1K18(F1,F2))+RVSUM-1K5 sqrRVSUM-1K15 F2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_70:
" for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds sqrRVSUM-1K15 (mltRVSUM-1K18(F1,F2)) =FINSEQ-1R1 mltRVSUM-1K18(sqrRVSUM-1K15 F1,sqrRVSUM-1K15 F2)"
proof-
  have " for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds sqrRVSUM-1K15 (mltRVSUM-1K18(F1,F2)) =FINSEQ-1R1 mltRVSUM-1K18(sqrRVSUM-1K15 F1,sqrRVSUM-1K15 F2)"
  proof(rule ballI,rule ballI)
    fix F1 assume [ty]: "F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    fix F2 assume [ty]: "F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    have A1: "domFINSEQ-1K5 (mltRVSUM-1K18(F1,F2)) =XBOOLE-0R4 domFINSEQ-1K5 F1 /\\XBOOLE-0K3 domFINSEQ-1K5 F2"
      using valued_1_def_4 sorry
    have A2: "domFINSEQ-1K5 (mltRVSUM-1K18(sqrRVSUM-1K15 F1,sqrRVSUM-1K15 F2)) =XBOOLE-0R4 domFINSEQ-1K5 (sqrRVSUM-1K15 F1) /\\XBOOLE-0K3 domFINSEQ-1K5 (sqrRVSUM-1K15 F2)"
      using valued_1_def_4 sorry
    have A3: "domFINSEQ-1K5 (sqrRVSUM-1K15 F1) =XBOOLE-0R4 domFINSEQ-1K5 F1"
      using valued_1_th_11 sorry
    have A4: "domFINSEQ-1K5 (sqrRVSUM-1K15 F2) =XBOOLE-0R4 domFINSEQ-1K5 F2"
      using valued_1_th_11 sorry
    have " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 (sqrRVSUM-1K15 (mltRVSUM-1K18(F1,F2))) implies sqrRVSUM-1K15 (mltRVSUM-1K18(F1,F2)) .FUNCT-1K1 i =HIDDENR1 mltRVSUM-1K18(sqrRVSUM-1K15 F1,sqrRVSUM-1K15 F2) .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be NatNAT-1M1"
      assume "i inTARSKIR2 domFINSEQ-1K5 (sqrRVSUM-1K15 (mltRVSUM-1K18(F1,F2)))"
      have "sqrRVSUM-1K15 (mltRVSUM-1K18(F1,F2)) .FUNCT-1K1 i =HIDDENR1 (mltRVSUM-1K18(F1,F2) .FUNCT-1K1 i)^2SQUARE-1K1"
        using valued_1_th_11 sorry
      also have "... = (F1 .FUNCT-1K1 i *XCMPLX-0K3 F2 .FUNCT-1K1 i)^2SQUARE-1K1"
        using valued_1_th_5 sorry
      also have "... = (F1 .FUNCT-1K1 i)^2SQUARE-1K1 *XCMPLX-0K3 (F2 .FUNCT-1K1 i)^2SQUARE-1K1"
         sorry
      also have "... = sqrRVSUM-1K15 F1 .FUNCT-1K1 i *XCMPLX-0K3 (F2 .FUNCT-1K1 i)^2SQUARE-1K1"
        using valued_1_th_11 sorry
      also have "... = sqrRVSUM-1K15 F1 .FUNCT-1K1 i *XCMPLX-0K3 sqrRVSUM-1K15 F2 .FUNCT-1K1 i"
        using valued_1_th_11 sorry
      also have "... = mltRVSUM-1K18(sqrRVSUM-1K15 F1,sqrRVSUM-1K15 F2) .FUNCT-1K1 i"
        using valued_1_th_5 sorry
      finally show "sqrRVSUM-1K15 (mltRVSUM-1K18(F1,F2)) .FUNCT-1K1 i =HIDDENR1 mltRVSUM-1K18(sqrRVSUM-1K15 F1,sqrRVSUM-1K15 F2) .FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "sqrRVSUM-1K15 (mltRVSUM-1K18(F1,F2)) =FINSEQ-1R1 mltRVSUM-1K18(sqrRVSUM-1K15 F1,sqrRVSUM-1K15 F2)"
      using A1 A2 A3 A4 finseq_1_th_13 valued_1_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_cl_10:
"cluster note-that complex-valuedVALUED-0V5 for FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
proof
(*coherence*)
  show " for it be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 holds it be complex-valuedVALUED-0V5"
     sorry
qed "sorry"

mtheorem rvsum_1_cl_11:
"cluster real-valuedVALUED-0V7\<bar>complex-valuedVALUED-0V5 for FinSequenceFINSEQ-1M1"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M1 st it be real-valuedVALUED-0V7\<bar>complex-valuedVALUED-0V5"
  proof-
    have " not ( for VarFor1 be FinSequenceFINSEQ-1M1 holds  not (VarFor1 be real-valuedVALUED-0V7 & VarFor1 be complex-valuedVALUED-0V5))"
    proof-
      have "<*>FINSEQ-1K7 REALNUMBERSK2 be real-valuedVALUED-0V7"
         sorry
      thus " not ( for VarFor1 be FinSequenceFINSEQ-1M1 holds  not (VarFor1 be real-valuedVALUED-0V7 & VarFor1 be complex-valuedVALUED-0V5))"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef rvsum_1_def_10 ("SumRVSUM-1K20  _ " [260]260 ) where
  mlet "F be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1"
"func SumRVSUM-1K20 F \<rightarrow> ComplexXCMPLX-0M1 means
  \<lambda>it.  ex f be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 st f =FINSEQ-1R1 F & it =HIDDENR1 addcomplexBINOP-2K3 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
proof-
  (*existence*)
    show " ex it be ComplexXCMPLX-0M1 st  ex f be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 st f =FINSEQ-1R1 F & it =HIDDENR1 addcomplexBINOP-2K3 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
    proof-
      have " ex IT be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 st  not ( for f be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 holds  not (f =FINSEQ-1R1 F & IT =HIDDENR1 addcomplexBINOP-2K3 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f))"
      proof-
        have "rngFUNCT-1K2 F c=TARSKIR1 COMPLEXNUMBERSK3"
          using valued_0_def_1 sorry
        then obtain f where 
          [ty]:"f be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3" and fDef:"f = F"
          using finseq_1_def_4 sorry
        obtain IT where 
          [ty]:"IT be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and ITDef:"IT = addcomplexBINOP-2K3 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
           sorry
        show " ex IT be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 st  not ( for f be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 holds  not (f =FINSEQ-1R1 F & IT =HIDDENR1 addcomplexBINOP-2K3 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f))"
        proof(rule bexI[of _ "IT"])
          show " not ( for f be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 holds  not (f =FINSEQ-1R1 F & IT =HIDDENR1 addcomplexBINOP-2K3 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f))"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be ComplexXCMPLX-0M1 holds  for it2 be ComplexXCMPLX-0M1 holds ( ex f be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 st f =FINSEQ-1R1 F & it1 =HIDDENR1 addcomplexBINOP-2K3 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f) & ( ex f be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 st f =FINSEQ-1R1 F & it2 =HIDDENR1 addcomplexBINOP-2K3 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f) implies it1 =HIDDENR1 it2"
       sorry
qed "sorry"

mtheorem rvsum_1_cl_12:
  mlet "F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
"cluster SumRVSUM-1K20 F as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "SumRVSUM-1K20 F be realXREAL-0V1"
  proof-
    let ?mc = "addcomplexBINOP-2K3"
    obtain f where
      [ty]:"f be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3" and 
      A1: "f =FINSEQ-1R1 F"and A2: "SumRVSUM-1K20 F =HIDDENR1 addcomplexBINOP-2K3 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
      using rvsum_1_def_10 sorry
    let ?g = "[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ?mc)"
    let ?P = "\<lambda>Lamb1. ?mc $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 Lamb1,[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ?mc)) be realXREAL-0V1"
    have A3: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds addcomplexBINOP-2K3 $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 k,[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (addcomplexBINOP-2K3))) be realXREAL-0V1 implies addcomplexBINOP-2K3 $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 (k +NAT-1K1 \<one>\<^sub>M),[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (addcomplexBINOP-2K3))) be realXREAL-0V1"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A4: "?P(k)"
        have 
          [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "?g .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) be realXREAL-0V1"
        proof-
          have "[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (addcomplexBINOP-2K3)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) be realXREAL-0V1"
          proof-
            show "[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (addcomplexBINOP-2K3)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) be realXREAL-0V1"
            proof-
              have cases: "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f or  not k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
                 sorry
              have case1: "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f implies [#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (addcomplexBINOP-2K3)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) be realXREAL-0V1"
              proof(rule impI)
                assume "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
                then have "?g .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
                  using setwop_2_th_20 sorry
                thus "[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (addcomplexBINOP-2K3)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) be realXREAL-0V1"
                  using A1 sorry
              qed
              have case2: " not k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f implies [#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (addcomplexBINOP-2K3)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) be realXREAL-0V1"
              proof(rule impI)
                assume " not k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
                thus "[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (addcomplexBINOP-2K3)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) be realXREAL-0V1"
                  using binop_2_th_1 setwop_2_th_20 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus " ?thesis "
             sorry
        qed
        then obtain a b where 
          [ty]:"a be RealXREAL-0M1" and aDef:"a = ?g .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)" and
          [ty]:"b be RealXREAL-0M1" and bDef:"b = ?mc $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 k,?g)"
          using A4 sorry
        have " not k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 k"
          using finseq_3_th_8 sorry
        then have "?mc $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 k \\/SETWISEOK8\<^bsub>(NATNUMBERSK1)\<^esub> {.SETWISEOK5\<^bsub>(NATNUMBERSK1)\<^esub> InSUBSET-1K10(k +NAT-1K1 \<one>\<^sub>M,NATNUMBERSK1) .},?g) =HIDDENR1 ?mc .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(?mc $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 k,?g),?g .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
          using setwop_2_th_2 sorry
        also have "... = b +XCMPLX-0K2 a"
          using binop_2_def_3 sorry
        finally have "?mc $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 k \\/SETWISEOK8\<^bsub>(NATNUMBERSK1)\<^esub> {.SETWISEOK5\<^bsub>(NATNUMBERSK1)\<^esub> InSUBSET-1K10(k +NAT-1K1 \<one>\<^sub>M,NATNUMBERSK1) .},?g) =HIDDENR1 b +XCMPLX-0K2 a"
           sorry
        thus "addcomplexBINOP-2K3 $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 (k +NAT-1K1 \<one>\<^sub>M),[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (addcomplexBINOP-2K3))) be realXREAL-0V1"
          using finseq_1_th_9 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A5: "?mc $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f =XBOOLE-0R4 ?mc $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(findomFINSOP-1K4 f,[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ?mc)) & ( ex n be NatNAT-1M1 st domFINSEQ-1K5 f =XBOOLE-0R4 SegFINSEQ-1K2 n)"
      using finseq_1_def_2 setwop_2_def_2 sorry
    have "SegFINSEQ-1K2 (0NUMBERSK6) =FINSEQ-1R1 {}.SETWISEOK1 NATNUMBERSK1"
       sorry
    then have A6: "?P(0NUMBERSK6)"
      using binop_2_th_1 setwiseo_th_31 sorry
    have " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A6 A3 sorry
    thus "SumRVSUM-1K20 F be realXREAL-0V1"
      using A2 A5 sorry
  qed
qed "sorry"

mtheorem rvsum_1_th_71:
" for F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds SumRVSUM-1K20 F =HIDDENR1 (addrealBINOP-2K9)$$SETWOP-2K5\<^bsub>(REALNUMBERSK2)\<^esub> F"
proof(rule ballI)
  let ?g = "addrealBINOP-2K9"
  let ?h = "addcomplexBINOP-2K3"
  fix F assume [ty]: "F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
  have "rngRVSUM-1K1 F c=TARSKIR1 COMPLEXNUMBERSK3"
    using numbers_th_11 xboole_1_th_1 sorry
  then obtain f where 
    [ty]:"f be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3" and fDef:"f = F"
    using finseq_1_def_4 sorry
  let ?P = "\<lambda>Lamb1. ?g $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub>(finSegSETWOP-2K3 Lamb1,[#]SETWOP-2K1\<^bsub>(REALNUMBERSK2)\<^esub>(F,the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> ?g)) =XBOOLE-0R4 ?h $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 Lamb1,[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ?h))"
  obtain n where
    [ty]:"n be NatNAT-1M1" and 
    A1: "domFINSEQ-1K5 f =XBOOLE-0R4 SegFINSEQ-1K2 n"
    using finseq_1_def_2 sorry
  have A2: "?g $$SETWOP-2K5\<^bsub>(REALNUMBERSK2)\<^esub> F =XBOOLE-0R4 ?g $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub>(finSegSETWOP-2K3 n,[#]SETWOP-2K1\<^bsub>(REALNUMBERSK2)\<^esub>(F,the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> ?g)) & ?h $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f =XBOOLE-0R4 ?h $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 n,[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ?h))"
    using A1 setwop_2_def_2 sorry
  have A3: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
  proof-
    have " for k be NatNAT-1M1 holds (addrealBINOP-2K9)$$SETWISEOK10\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub>(finSegSETWOP-2K3 k,[#]SETWOP-2K1\<^bsub>(REALNUMBERSK2)\<^esub>(F,the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> (addrealBINOP-2K9))) =XBOOLE-0R4 addcomplexBINOP-2K3 $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 k,[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (addcomplexBINOP-2K3))) implies (addrealBINOP-2K9)$$SETWISEOK10\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub>(finSegSETWOP-2K3 (k +NAT-1K1 \<one>\<^sub>M),[#]SETWOP-2K1\<^bsub>(REALNUMBERSK2)\<^esub>(F,the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> (addrealBINOP-2K9))) =XBOOLE-0R4 addcomplexBINOP-2K3 $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 (k +NAT-1K1 \<one>\<^sub>M),[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (addcomplexBINOP-2K3)))"
    proof(rule ballI,rule impI)
      let ?j = "[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ?h)"
      let ?i = "[#]SETWOP-2K1\<^bsub>(REALNUMBERSK2)\<^esub>(F,the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> ?g)"
      fix k assume [ty]: "k be NatNAT-1M1"
      assume A4: "?P(k)"
      have 
        [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1"
        using ordinal1_def_12 sorry
      have A5: "?i .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 ?j .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
      proof-
        have "[#]SETWOP-2K1\<^bsub>(REALNUMBERSK2)\<^esub>(F,the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> (addrealBINOP-2K9)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 [#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (addcomplexBINOP-2K3)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
        proof-
          show "[#]SETWOP-2K1\<^bsub>(REALNUMBERSK2)\<^esub>(F,the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> (addrealBINOP-2K9)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 [#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (addcomplexBINOP-2K3)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          proof-
            have cases: "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f or  not k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
               sorry
            have case1: "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f implies [#]SETWOP-2K1\<^bsub>(REALNUMBERSK2)\<^esub>(F,the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> (addrealBINOP-2K9)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 [#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (addcomplexBINOP-2K3)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
            proof(rule impI)
              assume A6: "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
              then have "?j .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 F .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
                using setwop_2_th_20 sorry
              also have "... = ?i .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
                using A6 setwop_2_th_20 sorry
              finally have "?j .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ?i .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
                 sorry
              thus "[#]SETWOP-2K1\<^bsub>(REALNUMBERSK2)\<^esub>(F,the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> (addrealBINOP-2K9)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 [#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (addcomplexBINOP-2K3)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
                 sorry
            qed
            have case2: " not k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f implies [#]SETWOP-2K1\<^bsub>(REALNUMBERSK2)\<^esub>(F,the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> (addrealBINOP-2K9)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 [#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (addcomplexBINOP-2K3)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
            proof(rule impI)
              assume A7: " not k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
              then have "?j .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ?h"
                using setwop_2_th_20 sorry
              also have "... = ?i .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
                using A7 binop_2_th_1 binop_2_th_2 setwop_2_th_20 sorry
              finally have "?j .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ?i .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
                 sorry
              thus "[#]SETWOP-2K1\<^bsub>(REALNUMBERSK2)\<^esub>(F,the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> (addrealBINOP-2K9)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 [#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (addcomplexBINOP-2K3)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus " ?thesis "
           sorry
      qed
      have A8: " not k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 k"
        using finseq_3_th_8 sorry
      have "?g $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub>(finSegSETWOP-2K3 (k +NAT-1K1 \<one>\<^sub>M),?i) =HIDDENR1 ?g $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub>(finSegSETWOP-2K3 k \\/SETWISEOK8\<^bsub>(NATNUMBERSK1)\<^esub> {.SETWISEOK5\<^bsub>(NATNUMBERSK1)\<^esub> InSUBSET-1K10(k +NAT-1K1 \<one>\<^sub>M,NATNUMBERSK1) .},?i)"
        using finseq_1_th_9 sorry
      also have "... = ?g .BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(?g $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub>(finSegSETWOP-2K3 k,?i),?i .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
        using A8 setwop_2_th_2 sorry
      also have "... = ?g $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub>(finSegSETWOP-2K3 k,?i) +REAL-1K3 ?i .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
        using binop_2_def_9 sorry
      also have "... = ?h .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(?h $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 k,?j),?j .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
        using A4 A5 binop_2_def_3 sorry
      also have "... = ?h $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 k \\/SETWISEOK8\<^bsub>(NATNUMBERSK1)\<^esub> {.SETWISEOK5\<^bsub>(NATNUMBERSK1)\<^esub> InSUBSET-1K10(k +NAT-1K1 \<one>\<^sub>M,NATNUMBERSK1) .},?j)"
        using A8 setwop_2_th_2 sorry
      also have "... = ?h $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 (k +NAT-1K1 \<one>\<^sub>M),?j)"
        using finseq_1_th_9 sorry
      finally have "?g $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub>(finSegSETWOP-2K3 (k +NAT-1K1 \<one>\<^sub>M),?i) =HIDDENR1 ?h $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 (k +NAT-1K1 \<one>\<^sub>M),?j)"
         sorry
      thus "(addrealBINOP-2K9)$$SETWISEOK10\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub>(finSegSETWOP-2K3 (k +NAT-1K1 \<one>\<^sub>M),[#]SETWOP-2K1\<^bsub>(REALNUMBERSK2)\<^esub>(F,the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> (addrealBINOP-2K9))) =XBOOLE-0R4 addcomplexBINOP-2K3 $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 (k +NAT-1K1 \<one>\<^sub>M),[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (addcomplexBINOP-2K3)))"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have A9: "SegFINSEQ-1K2 (0NUMBERSK6) =FINSEQ-1R1 {}.SETWISEOK1 NATNUMBERSK1"
     sorry
  then have "?g $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub>(finSegSETWOP-2K3 (0NUMBERSK6),[#]SETWOP-2K1\<^bsub>(REALNUMBERSK2)\<^esub>(F,the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> ?g)) =HIDDENR1 the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ?h"
    using binop_2_th_1 binop_2_th_2 setwiseo_th_31 sorry
  also have "... = ?h $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 (0NUMBERSK6),[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ?h))"
    using A9 setwiseo_th_31 sorry
  finally have "?g $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub>(finSegSETWOP-2K3 (0NUMBERSK6),[#]SETWOP-2K1\<^bsub>(REALNUMBERSK2)\<^esub>(F,the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> ?g)) =HIDDENR1 ?h $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 (0NUMBERSK6),[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ?h))"
     sorry
  then have A10: "?P(0NUMBERSK6)"
     sorry
  have " for k be NatNAT-1M1 holds ?P(k)"
    using nat_1_sch_2 A10 A3 sorry
  then have "?g $$SETWOP-2K5\<^bsub>(REALNUMBERSK2)\<^esub> F =XBOOLE-0R4 ?h $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
    using A2 sorry
  thus "SumRVSUM-1K20 F =HIDDENR1 (addrealBINOP-2K9)$$SETWOP-2K5\<^bsub>(REALNUMBERSK2)\<^esub> F"
    using rvsum_1_def_10 sorry
qed "sorry"

abbreviation(input) RVSUM_1K21("SumRVSUM-1K21  _ " [260]260) where
  "SumRVSUM-1K21 F \<equiv> SumRVSUM-1K20 F"

mtheorem rvsum_1_def_11:
  mlet "F be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
"redefine func SumRVSUM-1K21 F \<rightarrow> ElementSUBSET-1M1-of COMPLEXNUMBERSK3 equals
  addcomplexBINOP-2K3 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> F"
proof
(*compatibility*)
  show " for it be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds it =HIDDENR1 SumRVSUM-1K21 F iff it =HIDDENR1 addcomplexBINOP-2K3 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> F"
    using rvsum_1_def_10 sorry
qed "sorry"

mtheorem rvsum_1_add_14:
  mlet "F be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
"cluster SumRVSUM-1K20 F as-term-is ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
proof
(*coherence*)
  show "SumRVSUM-1K20 F be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    using xcmplx_0_def_2 sorry
qed "sorry"

abbreviation(input) RVSUM_1K22("SumRVSUM-1K22  _ " [260]260) where
  "SumRVSUM-1K22 F \<equiv> SumRVSUM-1K20 F"

mtheorem rvsum_1_def_12:
  mlet "F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
"redefine func SumRVSUM-1K22 F \<rightarrow> RealXREAL-0M1 equals
  (addrealBINOP-2K9)$$SETWOP-2K5\<^bsub>(REALNUMBERSK2)\<^esub> F"
proof
(*compatibility*)
  show " for it be RealXREAL-0M1 holds it =HIDDENR1 SumRVSUM-1K22 F iff it =HIDDENR1 (addrealBINOP-2K9)$$SETWOP-2K5\<^bsub>(REALNUMBERSK2)\<^esub> F"
    using rvsum_1_th_71 sorry
qed "sorry"

mtheorem rvsum_1_add_15:
  mlet "F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
"cluster SumRVSUM-1K20 F as-term-is RealXREAL-0M1"
proof
(*coherence*)
  show "SumRVSUM-1K20 F be RealXREAL-0M1"
     sorry
qed "sorry"

mtheorem rvsum_1_th_72:
"SumRVSUM-1K22 <*>FINSEQ-1K7 REALNUMBERSK2 =HIDDENR1 0NUMBERSK6"
  using binop_2_th_2 finsop_1_th_10 sorry

mtheorem rvsum_1_th_73:
" for r be RealXREAL-0M1 holds SumRVSUM-1K20 (<*FINSEQ-1K10 r*>) =HIDDENR1 r"
proof-
  have " for r be RealXREAL-0M1 holds SumRVSUM-1K20 (<*FINSEQ-1K10 r*>) =HIDDENR1 r"
  proof(rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    have 
      [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2"
      using xreal_0_def_1 sorry
    have "SumRVSUM-1K22 (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r*>) =HIDDENR1 r"
      using finsop_1_th_11 sorry
    thus "SumRVSUM-1K20 (<*FINSEQ-1K10 r*>) =HIDDENR1 r"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_74:
" for r be RealXREAL-0M1 holds  for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds SumRVSUM-1K20 (F ^FINSEQ-1K8 (<*FINSEQ-1K10 r*>)) =HIDDENR1 SumRVSUM-1K20 F +XCMPLX-0K2 r"
proof-
  have " for r be RealXREAL-0M1 holds  for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds SumRVSUM-1K20 (F ^FINSEQ-1K8 (<*FINSEQ-1K10 r*>)) =HIDDENR1 SumRVSUM-1K20 F +XCMPLX-0K2 r"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix F assume [ty]: "F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    obtain s where 
      [ty]:"s be ElementSUBSET-1M1-of REALNUMBERSK2" and sDef:"s = r"
      using xreal_0_def_1 sorry
    obtain F1 where 
      [ty]:"F1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2" and F1Def:"F1 = F"
      using rvsum_1_lm_2 sorry
    have "SumRVSUM-1K20 (F ^FINSEQ-1K8 (<*FINSEQ-1K10 r*>)) =HIDDENR1 SumRVSUM-1K22 (F1 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> s*>))"
       sorry
    also have "... = (addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>((addrealBINOP-2K9)$$SETWOP-2K5\<^bsub>(REALNUMBERSK2)\<^esub> F1,s)"
      using finsop_1_th_4 sorry
    also have "... = SumRVSUM-1K22 F1 +XCMPLX-0K2 r"
      using binop_2_def_9 sorry
    also have "... = SumRVSUM-1K20 F +XCMPLX-0K2 r"
       sorry
    finally show "SumRVSUM-1K20 (F ^FINSEQ-1K8 (<*FINSEQ-1K10 r*>)) =HIDDENR1 SumRVSUM-1K20 F +XCMPLX-0K2 r"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_75:
" for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds SumRVSUM-1K20 (F1 ^FINSEQ-1K8 F2) =HIDDENR1 SumRVSUM-1K20 F1 +XCMPLX-0K2 SumRVSUM-1K20 F2"
proof-
  have " for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds SumRVSUM-1K20 (F1 ^FINSEQ-1K8 F2) =HIDDENR1 SumRVSUM-1K20 F1 +XCMPLX-0K2 SumRVSUM-1K20 F2"
  proof(rule ballI,rule ballI)
    fix F1 assume [ty]: "F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    fix F2 assume [ty]: "F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    obtain F3 F4 where 
      [ty]:"F3 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2" and F3Def:"F3 = F1" and
      [ty]:"F4 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2" and F4Def:"F4 = F2"
      using rvsum_1_lm_2 sorry
    have "SumRVSUM-1K20 (F1 ^FINSEQ-1K8 F2) =HIDDENR1 SumRVSUM-1K22 (F3 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> F4)"
       sorry
    also have "... = (addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>((addrealBINOP-2K9)$$SETWOP-2K5\<^bsub>(REALNUMBERSK2)\<^esub> F3,(addrealBINOP-2K9)$$SETWOP-2K5\<^bsub>(REALNUMBERSK2)\<^esub> F4)"
      using finsop_1_th_5 sorry
    also have "... = SumRVSUM-1K22 F3 +XCMPLX-0K2 SumRVSUM-1K22 F4"
      using binop_2_def_9 sorry
    also have "... = SumRVSUM-1K20 F1 +XCMPLX-0K2 SumRVSUM-1K20 F2"
       sorry
    finally show "SumRVSUM-1K20 (F1 ^FINSEQ-1K8 F2) =HIDDENR1 SumRVSUM-1K20 F1 +XCMPLX-0K2 SumRVSUM-1K20 F2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_76:
" for r be RealXREAL-0M1 holds  for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds SumRVSUM-1K20 ((<*FINSEQ-1K10 r*>)^FINSEQ-1K8 F) =HIDDENR1 r +XCMPLX-0K2 SumRVSUM-1K20 F"
proof-
  have " for r be RealXREAL-0M1 holds  for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds SumRVSUM-1K20 ((<*FINSEQ-1K10 r*>)^FINSEQ-1K8 F) =HIDDENR1 r +XCMPLX-0K2 SumRVSUM-1K20 F"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix F assume [ty]: "F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    obtain s where 
      [ty]:"s be ElementSUBSET-1M1-of REALNUMBERSK2" and sDef:"s = r"
      using xreal_0_def_1 sorry
    have "SumRVSUM-1K20 ((<*FINSEQ-1K10 r*>)^FINSEQ-1K8 F) =HIDDENR1 SumRVSUM-1K22 (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> s*>) +XCMPLX-0K2 SumRVSUM-1K20 F"
      using rvsum_1_th_75 sorry
    also have "... = r +XCMPLX-0K2 SumRVSUM-1K20 F"
      using finsop_1_th_11 sorry
    finally show "SumRVSUM-1K20 ((<*FINSEQ-1K10 r*>)^FINSEQ-1K8 F) =HIDDENR1 r +XCMPLX-0K2 SumRVSUM-1K20 F"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_77:
" for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds SumRVSUM-1K20 (<*FINSEQ-1K11 r1,r2 *>) =HIDDENR1 r1 +XCMPLX-0K2 r2"
proof-
  have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds SumRVSUM-1K20 (<*FINSEQ-1K11 r1,r2 *>) =HIDDENR1 r1 +XCMPLX-0K2 r2"
  proof(rule ballI,rule ballI)
    fix r1 assume [ty]: "r1 be RealXREAL-0M1"
    fix r2 assume [ty]: "r2 be RealXREAL-0M1"
    obtain s1 where 
      [ty]:"s1 be ElementSUBSET-1M1-of REALNUMBERSK2" and s1Def:"s1 = r1"
      using xreal_0_def_1 sorry
    have "SumRVSUM-1K20 (<*FINSEQ-1K11 r1,r2 *>) =HIDDENR1 SumRVSUM-1K22 (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> s1*>) +XCMPLX-0K2 r2"
      using rvsum_1_th_74 sorry
    also have "... = r1 +XCMPLX-0K2 r2"
      using finsop_1_th_11 sorry
    finally show "SumRVSUM-1K20 (<*FINSEQ-1K11 r1,r2 *>) =HIDDENR1 r1 +XCMPLX-0K2 r2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_78:
" for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds  for r3 be RealXREAL-0M1 holds SumRVSUM-1K20 (<*FINSEQ-1K12 r1,r2,r3 *>) =HIDDENR1 (r1 +XCMPLX-0K2 r2)+XCMPLX-0K2 r3"
proof-
  have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds  for r3 be RealXREAL-0M1 holds SumRVSUM-1K20 (<*FINSEQ-1K12 r1,r2,r3 *>) =HIDDENR1 (r1 +XCMPLX-0K2 r2)+XCMPLX-0K2 r3"
  proof(rule ballI,rule ballI,rule ballI)
    fix r1 assume [ty]: "r1 be RealXREAL-0M1"
    fix r2 assume [ty]: "r2 be RealXREAL-0M1"
    fix r3 assume [ty]: "r3 be RealXREAL-0M1"
    have "SumRVSUM-1K20 (<*FINSEQ-1K12 r1,r2,r3 *>) =HIDDENR1 SumRVSUM-1K20 (<*FINSEQ-1K11 r1,r2 *>) +XCMPLX-0K2 r3"
      using rvsum_1_th_74 sorry
    also have "... = (r1 +XCMPLX-0K2 r2)+XCMPLX-0K2 r3"
      using rvsum_1_th_77 sorry
    finally show "SumRVSUM-1K20 (<*FINSEQ-1K12 r1,r2,r3 *>) =HIDDENR1 (r1 +XCMPLX-0K2 r2)+XCMPLX-0K2 r3"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_79:
" for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of (0NUMBERSK6)-tuples-onFINSEQ-2K4 REALNUMBERSK2 holds SumRVSUM-1K22 R =HIDDENR1 0NUMBERSK6"
  using rvsum_1_th_72 sorry

mtheorem rvsum_1_th_80:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r be RealXREAL-0M1 holds SumRVSUM-1K20 (i  |->FINSEQ-2K2 r) =HIDDENR1 i *XCMPLX-0K3 r"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r be RealXREAL-0M1 holds SumRVSUM-1K20 (i  |->FINSEQ-2K2 r) =HIDDENR1 i *XCMPLX-0K3 r"
  proof(rule ballI,rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    have A0: "i be NatNAT-1M1"
      using tarski_th_1 sorry
    have 
      [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2"
      using xreal_0_def_1 sorry
    let ?P = "\<lambda>Lamb1. SumRVSUM-1K22 (Lamb1  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> r) =HIDDENR1 Lamb1 *XCMPLX-0K3 r"
    have A1: " for i be NatNAT-1M1 holds ?P(i) implies ?P(i +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for i be NatNAT-1M1 holds SumRVSUM-1K22 (i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> r) =HIDDENR1 i *XCMPLX-0K3 r implies SumRVSUM-1K22 ((i +NAT-1K1 \<one>\<^sub>M) |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> r) =HIDDENR1 (i +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 r"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be NatNAT-1M1"
        assume A2: "SumRVSUM-1K22 (i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> r) =HIDDENR1 i *XCMPLX-0K3 r"
        have "SumRVSUM-1K22 ((i +NAT-1K1 \<one>\<^sub>M) |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> r) =HIDDENR1 SumRVSUM-1K22 ((i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> r)^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r*>))"
          using finseq_2_th_60 sorry
        also have "... = i *XCMPLX-0K3 r +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 r"
          using A2 rvsum_1_th_74 sorry
        also have "... = (i +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 r"
           sorry
        finally show "SumRVSUM-1K22 ((i +NAT-1K1 \<one>\<^sub>M) |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> r) =HIDDENR1 (i +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 r"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A3: "?P(0NUMBERSK6)"
      using rvsum_1_th_72 sorry
    have " for i be NatNAT-1M1 holds ?P(i)"
      using nat_1_sch_2 A3 A1 sorry
    thus "SumRVSUM-1K20 (i  |->FINSEQ-2K2 r) =HIDDENR1 i *XCMPLX-0K3 r"
      using A0 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_81:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds SumRVSUM-1K20 (i  |->FINSEQ-2K2 (0NUMBERSK6)) =HIDDENR1 0NUMBERSK6"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds SumRVSUM-1K20 (i  |->FINSEQ-2K2 (0NUMBERSK6)) =HIDDENR1 0NUMBERSK6"
  proof(rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have "SumRVSUM-1K20 (i  |->FINSEQ-2K2 (0NUMBERSK6)) =HIDDENR1 i *XCMPLX-0K3 (0NUMBERSK6)"
      using rvsum_1_th_80 sorry
    also have "... = 0NUMBERSK6"
       sorry
    finally show "SumRVSUM-1K20 (i  |->FINSEQ-2K2 (0NUMBERSK6)) =HIDDENR1 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma rvsum_1_lm_3:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R1 be i -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R1 be i -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
  proof(rule ballI,rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix R1 assume [ty]: "R1 be i -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    have A1: "R1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
      using rvsum_1_lm_2 sorry
    have "lenFINSEQ-1K4 R1 =HIDDENR1 i"
      using card_1_def_7 sorry
    thus "R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
      using A1 finseq_2_th_92 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_82:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R1 be i -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for R2 be i -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds ( for j be NatNAT-1M1 holds j inTARSKIR2 SegFINSEQ-1K1 i implies R1 .FUNCT-1K1 j <=XXREAL-0R1 R2 .FUNCT-1K1 j) implies SumRVSUM-1K20 R1 <=XXREAL-0R1 SumRVSUM-1K20 R2"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R1 be i -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for R2 be i -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  not (( for j be NatNAT-1M1 holds  not (j inTARSKIR2 SegFINSEQ-1K1 i &  not R1 .FUNCT-1K1 j <=XXREAL-0R1 R2 .FUNCT-1K1 j)) &  not SumRVSUM-1K20 R1 <=XXREAL-0R1 SumRVSUM-1K20 R2)"
  proof(rule ballI,rule ballI,rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix R1 assume [ty]: "R1 be i -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    fix R2 assume [ty]: "R2 be i -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    have A0: "i be NatNAT-1M1"
      using tarski_th_1 sorry
    let ?P = "\<lambda>Lamb1.  for R1 be Lamb1 -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for R2 be Lamb1 -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds ( for j be NatNAT-1M1 holds j inTARSKIR2 SegFINSEQ-1K2 Lamb1 implies R1 .FUNCT-1K1 j <=XXREAL-0R1 R2 .FUNCT-1K1 j) implies SumRVSUM-1K20 R1 <=XXREAL-0R1 SumRVSUM-1K20 R2"
    have A1: " for i be NatNAT-1M1 holds ?P(i) implies ?P(i +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for i be NatNAT-1M1 holds ( for R1 be i -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for R2 be i -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds ( for j be NatNAT-1M1 holds j inTARSKIR2 SegFINSEQ-1K2 i implies R1 .FUNCT-1K1 j <=XXREAL-0R1 R2 .FUNCT-1K1 j) implies SumRVSUM-1K20 R1 <=XXREAL-0R1 SumRVSUM-1K20 R2) implies ( for R1 be i +NAT-1K1 \<one>\<^sub>M -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for R2 be i +NAT-1K1 \<one>\<^sub>M -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds ( for j be NatNAT-1M1 holds j inTARSKIR2 SegFINSEQ-1K2 (i +NAT-1K1 \<one>\<^sub>M) implies R1 .FUNCT-1K1 j <=XXREAL-0R1 R2 .FUNCT-1K1 j) implies SumRVSUM-1K20 R1 <=XXREAL-0R1 SumRVSUM-1K20 R2)"
      proof(rule ballI,rule impI,rule ballI,rule ballI,rule impI)
        fix i assume [ty]: "i be NatNAT-1M1"
        assume A2: " for R1 be i -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for R2 be i -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds ( for j be NatNAT-1M1 holds j inTARSKIR2 SegFINSEQ-1K2 i implies R1 .FUNCT-1K1 j <=XXREAL-0R1 R2 .FUNCT-1K1 j) implies SumRVSUM-1K20 R1 <=XXREAL-0R1 SumRVSUM-1K20 R2"
        let ?n = "i +NAT-1K1 \<one>\<^sub>M"
        fix R1 assume [ty]: "R1 be ?n -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
        fix R2 assume [ty]: "R2 be ?n -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
        assume A3: " for j be NatNAT-1M1 holds j inTARSKIR2 SegFINSEQ-1K2 ?n implies R1 .FUNCT-1K1 j <=XXREAL-0R1 R2 .FUNCT-1K1 j"
        have "R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of ?n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
          using rvsum_1_lm_3 sorry
        then obtain R19 x1 where
          [ty]:"R19 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2" "x1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
          A4: "R1 =FINSEQ-1R1 R19 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> x1*>)"
          using finseq_2_th_117 sorry
        have "R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of ?n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
          using rvsum_1_lm_3 sorry
        then obtain R29 x2 where
          [ty]:"R29 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2" "x2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
          A5: "R2 =FINSEQ-1R1 R29 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> x2*>)"
          using finseq_2_th_117 sorry
        have " for j be NatNAT-1M1 holds j inTARSKIR2 SegFINSEQ-1K2 i implies R19 .FUNCT-1K1 j <=XXREAL-0R1 R29 .FUNCT-1K1 j"
        proof(rule ballI,rule impI)
          fix j assume [ty]: "j be NatNAT-1M1"
          assume A6: "j inTARSKIR2 SegFINSEQ-1K2 i"
          have "SegFINSEQ-1K2 (lenFINSEQ-1K4 R29) =XBOOLE-0R4 domFINSEQ-1K5 R29 & lenFINSEQ-1K4 R29 =XBOOLE-0R4 i"
            using card_1_def_7 finseq_1_def_3 sorry
          then have A7: "R29 .FUNCT-1K1 j =XBOOLE-0R4 R2 .FUNCT-1K1 j"
            using A5 A6 finseq_1_def_7 sorry
          have "SegFINSEQ-1K2 (lenFINSEQ-1K4 R19) =XBOOLE-0R4 domFINSEQ-1K5 R19 & lenFINSEQ-1K4 R19 =XBOOLE-0R4 i"
            using card_1_def_7 finseq_1_def_3 sorry
          then have "R19 .FUNCT-1K1 j =XBOOLE-0R4 R1 .FUNCT-1K1 j"
            using A4 A6 finseq_1_def_7 sorry
          thus "R19 .FUNCT-1K1 j <=XXREAL-0R1 R29 .FUNCT-1K1 j"
            using A3 A6 A7 finseq_2_th_8 sorry
        qed "sorry"
        then have A8: "SumRVSUM-1K22 R19 <=XXREAL-0R1 SumRVSUM-1K22 R29"
          using A2 sorry
        have A9: "R2 .FUNCT-1K1 ?n =XBOOLE-0R4 x2"
          using A5 finseq_2_th_116 sorry
        have "R1 .FUNCT-1K1 ?n =XBOOLE-0R4 x1"
          using A4 finseq_2_th_116 sorry
        then have A10: "x1 <=XXREAL-0R1 x2"
          using A3 A9 finseq_1_th_4 sorry
        have A11: "SumRVSUM-1K20 R2 =HIDDENR1 SumRVSUM-1K22 R29 +XCMPLX-0K2 x2"
          using A5 rvsum_1_th_74 sorry
        have "SumRVSUM-1K20 R1 =HIDDENR1 SumRVSUM-1K22 R19 +XCMPLX-0K2 x1"
          using A4 rvsum_1_th_74 sorry
        thus "SumRVSUM-1K20 R1 <=XXREAL-0R1 SumRVSUM-1K20 R2"
          using A10 A8 A11 xreal_1_th_7 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A12: "?P(0NUMBERSK6)"
       sorry
    have " for i be NatNAT-1M1 holds ?P(i)"
      using nat_1_sch_2 A12 A1 sorry
    thus " not (( for j be NatNAT-1M1 holds  not (j inTARSKIR2 SegFINSEQ-1K1 i &  not R1 .FUNCT-1K1 j <=XXREAL-0R1 R2 .FUNCT-1K1 j)) &  not SumRVSUM-1K20 R1 <=XXREAL-0R1 SumRVSUM-1K20 R2)"
      using A0 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_83:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R1 be i -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for R2 be i -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds ( for j be NatNAT-1M1 holds j inTARSKIR2 SegFINSEQ-1K1 i implies R1 .FUNCT-1K1 j <=XXREAL-0R1 R2 .FUNCT-1K1 j) & ( ex j be NatNAT-1M1 st j inTARSKIR2 SegFINSEQ-1K1 i & R1 .FUNCT-1K1 j <XXREAL-0R3 R2 .FUNCT-1K1 j) implies SumRVSUM-1K20 R1 <XXREAL-0R3 SumRVSUM-1K20 R2"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R1 be i -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for R2 be i -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  not ((( for j be NatNAT-1M1 holds  not (j inTARSKIR2 SegFINSEQ-1K1 i &  not R1 .FUNCT-1K1 j <=XXREAL-0R1 R2 .FUNCT-1K1 j)) &  not ( for j be NatNAT-1M1 holds  not (j inTARSKIR2 SegFINSEQ-1K1 i &  not R1 .FUNCT-1K1 j <XXREAL-0R3 R2 .FUNCT-1K1 j))) & SumRVSUM-1K20 R1 <XXREAL-0R3 SumRVSUM-1K20 R2)"
  proof(rule ballI,rule ballI,rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix R1 assume [ty]: "R1 be i -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    fix R2 assume [ty]: "R2 be i -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    have A0: "i be NatNAT-1M1"
      using tarski_th_1 sorry
    let ?P = "\<lambda>Lamb1.  for R1 be Lamb1 -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for R2 be Lamb1 -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds ( for j be NatNAT-1M1 holds j inTARSKIR2 SegFINSEQ-1K2 Lamb1 implies R1 .FUNCT-1K1 j <=XXREAL-0R1 R2 .FUNCT-1K1 j) & ( ex j be NatNAT-1M1 st j inTARSKIR2 SegFINSEQ-1K2 Lamb1 & R1 .FUNCT-1K1 j <XXREAL-0R3 R2 .FUNCT-1K1 j) implies SumRVSUM-1K20 R1 <XXREAL-0R3 SumRVSUM-1K20 R2"
    have " for i be NatNAT-1M1 holds ( for R1 be i -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for R2 be i -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds ( for j be NatNAT-1M1 holds j inTARSKIR2 SegFINSEQ-1K2 i implies R1 .FUNCT-1K1 j <=XXREAL-0R1 R2 .FUNCT-1K1 j) & ( ex j be NatNAT-1M1 st j inTARSKIR2 SegFINSEQ-1K2 i & R1 .FUNCT-1K1 j <XXREAL-0R3 R2 .FUNCT-1K1 j) implies SumRVSUM-1K20 R1 <XXREAL-0R3 SumRVSUM-1K20 R2) implies ( for R1 be i +NAT-1K1 \<one>\<^sub>M -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for R2 be i +NAT-1K1 \<one>\<^sub>M -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds ( for j be NatNAT-1M1 holds j inTARSKIR2 SegFINSEQ-1K2 (i +NAT-1K1 \<one>\<^sub>M) implies R1 .FUNCT-1K1 j <=XXREAL-0R1 R2 .FUNCT-1K1 j) implies (( ex j be NatNAT-1M1 st j inTARSKIR2 SegFINSEQ-1K2 (i +NAT-1K1 \<one>\<^sub>M) & R1 .FUNCT-1K1 j <XXREAL-0R3 R2 .FUNCT-1K1 j) implies SumRVSUM-1K20 R1 <XXREAL-0R3 SumRVSUM-1K20 R2))"
    proof(rule ballI,rule impI,rule ballI,rule ballI,rule impI,rule impI)
      fix i assume [ty]: "i be NatNAT-1M1"
      assume A1: "?P(i)"
      fix R1 assume [ty]: "R1 be i +NAT-1K1 \<one>\<^sub>M -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
      fix R2 assume [ty]: "R2 be i +NAT-1K1 \<one>\<^sub>M -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
      assume A2: " for j be NatNAT-1M1 holds j inTARSKIR2 SegFINSEQ-1K2 (i +NAT-1K1 \<one>\<^sub>M) implies R1 .FUNCT-1K1 j <=XXREAL-0R1 R2 .FUNCT-1K1 j"
      assume Given: " ex j be NatNAT-1M1 st j inTARSKIR2 SegFINSEQ-1K2 (i +NAT-1K1 \<one>\<^sub>M) & R1 .FUNCT-1K1 j <XXREAL-0R3 R2 .FUNCT-1K1 j"
      then obtain j where
        [ty]:"j be NatNAT-1M1" and 
        A3: "j inTARSKIR2 SegFINSEQ-1K2 (i +NAT-1K1 \<one>\<^sub>M)"and A4: "R1 .FUNCT-1K1 j <XXREAL-0R3 R2 .FUNCT-1K1 j"
         sorry
      have "R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of (i +NAT-1K1 \<one>\<^sub>M)-tuples-onFINSEQ-2K4 REALNUMBERSK2"
        using rvsum_1_lm_3 sorry
      then obtain R19 x1 where
        [ty]:"R19 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2" "x1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
        A5: "R1 =FINSEQ-1R1 R19 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> x1*>)"
        using finseq_2_th_117 sorry
      have "R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of (i +NAT-1K1 \<one>\<^sub>M)-tuples-onFINSEQ-2K4 REALNUMBERSK2"
        using rvsum_1_lm_3 sorry
      then obtain R29 x2 where
        [ty]:"R29 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2" "x2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
        A6: "R2 =FINSEQ-1R1 R29 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> x2*>)"
        using finseq_2_th_117 sorry
      have A7: " for j be NatNAT-1M1 holds j inTARSKIR2 SegFINSEQ-1K2 i implies R19 .FUNCT-1K1 j <=XXREAL-0R1 R29 .FUNCT-1K1 j"
      proof(rule ballI,rule impI)
        fix j assume [ty]: "j be NatNAT-1M1"
        assume A8: "j inTARSKIR2 SegFINSEQ-1K2 i"
        have "SegFINSEQ-1K2 (lenFINSEQ-1K4 R29) =XBOOLE-0R4 domFINSEQ-1K5 R29 & lenFINSEQ-1K4 R29 =XBOOLE-0R4 i"
          using card_1_def_7 finseq_1_def_3 sorry
        then have A9: "R29 .FUNCT-1K1 j =XBOOLE-0R4 R2 .FUNCT-1K1 j"
          using A6 A8 finseq_1_def_7 sorry
        have "SegFINSEQ-1K2 (lenFINSEQ-1K4 R19) =XBOOLE-0R4 domFINSEQ-1K5 R19 & lenFINSEQ-1K4 R19 =XBOOLE-0R4 i"
          using card_1_def_7 finseq_1_def_3 sorry
        then have "R19 .FUNCT-1K1 j =XBOOLE-0R4 R1 .FUNCT-1K1 j"
          using A5 A8 finseq_1_def_7 sorry
        thus "R19 .FUNCT-1K1 j <=XXREAL-0R1 R29 .FUNCT-1K1 j"
          using A2 A8 A9 finseq_2_th_8 sorry
      qed "sorry"
      have A10: "R2 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 x2"
        using A6 finseq_2_th_116 sorry
      have A11: "R1 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 x1"
        using A5 finseq_2_th_116 sorry
      have "SumRVSUM-1K20 R1 <XXREAL-0R3 SumRVSUM-1K20 R2"
      proof-
        show "SumRVSUM-1K20 R1 <XXREAL-0R3 SumRVSUM-1K20 R2"
        proof-
          have cases: "j inTARSKIR2 SegFINSEQ-1K2 i or j =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M"
            using A3 finseq_2_th_7 sorry
          have case1: "j inTARSKIR2 SegFINSEQ-1K2 i implies SumRVSUM-1K20 R1 <XXREAL-0R3 SumRVSUM-1K20 R2"
          proof(rule impI)
            assume A12: "j inTARSKIR2 SegFINSEQ-1K2 i"
            have "SegFINSEQ-1K2 (lenFINSEQ-1K4 R29) =XBOOLE-0R4 domFINSEQ-1K5 R29 & lenFINSEQ-1K4 R29 =XBOOLE-0R4 i"
              using card_1_def_7 finseq_1_def_3 sorry
            then have A13: "R29 .FUNCT-1K1 j =XBOOLE-0R4 R2 .FUNCT-1K1 j"
              using A6 A12 finseq_1_def_7 sorry
            have A14: "SumRVSUM-1K20 R1 =HIDDENR1 SumRVSUM-1K22 R19 +XCMPLX-0K2 x1 & SumRVSUM-1K20 R2 =HIDDENR1 SumRVSUM-1K22 R29 +XCMPLX-0K2 x2"
              using A5 A6 rvsum_1_th_74 sorry
            have A15: "x1 <=XXREAL-0R1 x2"
              using A2 A11 A10 finseq_1_th_4 sorry
            have "SegFINSEQ-1K2 (lenFINSEQ-1K4 R19) =XBOOLE-0R4 domFINSEQ-1K5 R19 & lenFINSEQ-1K4 R19 =XBOOLE-0R4 i"
              using card_1_def_7 finseq_1_def_3 sorry
            then have "R19 .FUNCT-1K1 j =XBOOLE-0R4 R1 .FUNCT-1K1 j"
              using A5 A12 finseq_1_def_7 sorry
            then have "SumRVSUM-1K22 R19 <XXREAL-0R3 SumRVSUM-1K22 R29"
              using A1 A4 A7 A12 A13 sorry
            thus "SumRVSUM-1K20 R1 <XXREAL-0R3 SumRVSUM-1K20 R2"
              using A14 A15 xreal_1_th_8 sorry
          qed
          have case2: "j =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M implies SumRVSUM-1K20 R1 <XXREAL-0R3 SumRVSUM-1K20 R2"
          proof(rule impI)
            assume A16: "j =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M"
            have A17: "SumRVSUM-1K20 R2 =HIDDENR1 SumRVSUM-1K22 R29 +XCMPLX-0K2 x2"
              using A6 rvsum_1_th_74 sorry
            have "SumRVSUM-1K22 R19 <=XXREAL-0R1 SumRVSUM-1K22 R29 & SumRVSUM-1K20 R1 =HIDDENR1 SumRVSUM-1K22 R19 +XCMPLX-0K2 x1"
              using A5 A7 rvsum_1_th_74 rvsum_1_th_82 sorry
            thus "SumRVSUM-1K20 R1 <XXREAL-0R3 SumRVSUM-1K20 R2"
              using A4 A11 A10 A16 A17 xreal_1_th_8 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "SumRVSUM-1K20 R1 <XXREAL-0R3 SumRVSUM-1K20 R2"
         sorry
    qed "sorry"
    then have A18: " for i be NatNAT-1M1 holds ?P(i) implies ?P(i +NAT-1K1 \<one>\<^sub>M)"
       sorry
    have A19: "?P(0NUMBERSK6)"
       sorry
    have " for i be NatNAT-1M1 holds ?P(i)"
      using nat_1_sch_2 A19 A18 sorry
    thus " not ((( for j be NatNAT-1M1 holds  not (j inTARSKIR2 SegFINSEQ-1K1 i &  not R1 .FUNCT-1K1 j <=XXREAL-0R1 R2 .FUNCT-1K1 j)) &  not ( for j be NatNAT-1M1 holds  not (j inTARSKIR2 SegFINSEQ-1K1 i &  not R1 .FUNCT-1K1 j <XXREAL-0R3 R2 .FUNCT-1K1 j))) & SumRVSUM-1K20 R1 <XXREAL-0R3 SumRVSUM-1K20 R2)"
      using A0 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_84:
" for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 F implies 0NUMBERSK6 <=XXREAL-0R1 F .FUNCT-1K1 i) implies 0NUMBERSK6 <=XXREAL-0R1 SumRVSUM-1K20 F"
proof-
  have " for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 F implies 0NUMBERSK6 <=XXREAL-0R1 F .FUNCT-1K1 i) implies 0NUMBERSK6 <=XXREAL-0R1 SumRVSUM-1K20 F"
  proof(rule ballI,rule impI)
    fix F assume [ty]: "F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    obtain F1 where 
      [ty]:"F1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2" and F1Def:"F1 = F"
      using rvsum_1_lm_2 sorry
    let ?i = "lenFINSEQ-1K4 F"
    let ?R1 = "?i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> (InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2))"
    obtain R2 where 
      [ty]:"R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of ?i -tuples-onFINSEQ-2K4 REALNUMBERSK2" and R2Def:"R2 = F1"
      using finseq_2_th_92 sorry
    have A1: "SegFINSEQ-1K2 (lenFINSEQ-1K4 F) =XBOOLE-0R4 domFINSEQ-1K5 F"
      using finseq_1_def_3 sorry
    assume A2: " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 F implies 0NUMBERSK6 <=XXREAL-0R1 F .FUNCT-1K1 i"
    have " for j be NatNAT-1M1 holds j inTARSKIR2 SegFINSEQ-1K2 ?i implies ?R1 .FUNCT-1K1 j <=XXREAL-0R1 R2 .FUNCT-1K1 j"
    proof-
      have " for j be NatNAT-1M1 holds j inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 F) implies (lenFINSEQ-1K4 F  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> (InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2))).FUNCT-1K1 j <=XXREAL-0R1 R2 .FUNCT-1K1 j"
      proof(rule ballI,rule impI)
        fix j assume [ty]: "j be NatNAT-1M1"
        assume A3: "j inTARSKIR2 SegFINSEQ-1K2 ?i"
        have "?R1 .FUNCT-1K1 j =XBOOLE-0R4 InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)"
           sorry
        thus "(lenFINSEQ-1K4 F  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> (InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2))).FUNCT-1K1 j <=XXREAL-0R1 R2 .FUNCT-1K1 j"
          using A2 A1 A3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have "SumRVSUM-1K22 ?R1 <=XXREAL-0R1 SumRVSUM-1K22 R2"
      using rvsum_1_th_82 sorry
    thus "0NUMBERSK6 <=XXREAL-0R1 SumRVSUM-1K20 F"
      using rvsum_1_th_81 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_85:
" for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 F implies 0NUMBERSK6 <=XXREAL-0R1 F .FUNCT-1K1 i) & ( ex i be NatNAT-1M1 st i inTARSKIR2 domFINSEQ-1K5 F & 0NUMBERSK6 <XXREAL-0R3 F .FUNCT-1K1 i) implies 0NUMBERSK6 <XXREAL-0R3 SumRVSUM-1K20 F"
proof-
  have " for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 F implies 0NUMBERSK6 <=XXREAL-0R1 F .FUNCT-1K1 i) implies (( ex j be NatNAT-1M1 st j inTARSKIR2 domFINSEQ-1K5 F & 0NUMBERSK6 <XXREAL-0R3 F .FUNCT-1K1 j) implies  not 0NUMBERSK6 <XXREAL-0R3 SumRVSUM-1K20 F)"
  proof(rule ballI,rule impI,rule impI)
    fix F assume [ty]: "F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    obtain F1 where 
      [ty]:"F1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2" and F1Def:"F1 = F"
      using rvsum_1_lm_2 sorry
    let ?i = "lenFINSEQ-1K4 F"
    let ?R1 = "?i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> (InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2))"
    obtain R2 where 
      [ty]:"R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of ?i -tuples-onFINSEQ-2K4 REALNUMBERSK2" and R2Def:"R2 = F1"
      using finseq_2_th_92 sorry
    have A1: "SegFINSEQ-1K2 (lenFINSEQ-1K4 F) =XBOOLE-0R4 domFINSEQ-1K5 F"
      using finseq_1_def_3 sorry
    assume A2: " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 F implies 0NUMBERSK6 <=XXREAL-0R1 F .FUNCT-1K1 i"
    have A3: " for j be NatNAT-1M1 holds j inTARSKIR2 SegFINSEQ-1K2 ?i implies ?R1 .FUNCT-1K1 j <=XXREAL-0R1 R2 .FUNCT-1K1 j"
    proof-
      have " for j be NatNAT-1M1 holds  not (j inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 F) &  not (lenFINSEQ-1K4 F  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> (InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2))).FUNCT-1K1 j <=XXREAL-0R1 R2 .FUNCT-1K1 j)"
      proof(rule ballI)
        fix j assume [ty]: "j be NatNAT-1M1"
        have "?R1 .FUNCT-1K1 j =XBOOLE-0R4 InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)"
           sorry
        thus " not (j inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 F) &  not (lenFINSEQ-1K4 F  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> (InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2))).FUNCT-1K1 j <=XXREAL-0R1 R2 .FUNCT-1K1 j)"
          using A2 A1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex j be NatNAT-1M1 st j inTARSKIR2 domFINSEQ-1K5 F & 0NUMBERSK6 <XXREAL-0R3 F .FUNCT-1K1 j"
    then obtain j where
      [ty]:"j be NatNAT-1M1" and 
      A4: "j inTARSKIR2 domFINSEQ-1K5 F"and A5: "0NUMBERSK6 <XXREAL-0R3 F .FUNCT-1K1 j"
       sorry
    have "?R1 .FUNCT-1K1 j =XBOOLE-0R4 0NUMBERSK6"
       sorry
    then have "SumRVSUM-1K22 ?R1 <XXREAL-0R3 SumRVSUM-1K22 R2"
      using A1 A3 A4 A5 rvsum_1_th_83 sorry
    thus " not 0NUMBERSK6 <XXREAL-0R3 SumRVSUM-1K20 F"
      using rvsum_1_th_81 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_86:
" for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 SumRVSUM-1K22 (sqrRVSUM-1K15 F)"
proof-
  have " for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 SumRVSUM-1K22 (sqrRVSUM-1K15 F)"
  proof(rule ballI)
    fix F assume [ty]: "F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    have " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 (sqrRVSUM-1K15 F) implies 0NUMBERSK6 <=XXREAL-0R1 sqrRVSUM-1K15 F .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be NatNAT-1M1"
      assume "i inTARSKIR2 domFINSEQ-1K5 (sqrRVSUM-1K15 F)"
      have "0NUMBERSK6 <=XXREAL-0R1 (F .FUNCT-1K1 i)^2SQUARE-1K1"
        using xreal_1_th_63 sorry
      thus "0NUMBERSK6 <=XXREAL-0R1 sqrRVSUM-1K15 F .FUNCT-1K1 i"
        using valued_1_th_11 sorry
    qed "sorry"
    thus "0NUMBERSK6 <=XXREAL-0R1 SumRVSUM-1K22 (sqrRVSUM-1K15 F)"
      using rvsum_1_th_84 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_87:
" for r be RealXREAL-0M1 holds  for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds SumRVSUM-1K22 (r *RVSUM-1K12 F) =HIDDENR1 r *XCMPLX-0K3 SumRVSUM-1K20 F"
proof-
  have " for r be RealXREAL-0M1 holds  for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds SumRVSUM-1K22 (r *RVSUM-1K12 F) =HIDDENR1 r *XCMPLX-0K3 SumRVSUM-1K20 F"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix F assume [ty]: "F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    obtain F1 where 
      [ty]:"F1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2" and F1Def:"F1 = F"
      using rvsum_1_lm_2 sorry
    obtain s where 
      [ty]:"s be ElementSUBSET-1M1-of REALNUMBERSK2" and sDef:"s = r"
      using xreal_0_def_1 sorry
    let ?rM = "(multrealBINOP-2K11)[;]FUNCOP-1K10\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>(s,idPARTFUN1K6 REALNUMBERSK2)"
    have "SumRVSUM-1K22 (r *RVSUM-1K12 F) =HIDDENR1 ((multrealBINOP-2K11)[;]FUNCOP-1K10\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>(s,idPARTFUN1K6 REALNUMBERSK2)).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((addrealBINOP-2K9)$$SETWOP-2K5\<^bsub>(REALNUMBERSK2)\<^esub> F1)"
      using rvsum_1_th_3 rvsum_1_th_8 setwop_2_th_30 sorry
    also have "... = r *XCMPLX-0K3 SumRVSUM-1K22 F1"
      using rvsum_1_lm_1 sorry
    also have "... = r *XCMPLX-0K3 SumRVSUM-1K20 F"
       sorry
    finally show "SumRVSUM-1K22 (r *RVSUM-1K12 F) =HIDDENR1 r *XCMPLX-0K3 SumRVSUM-1K20 F"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_88:
" for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds SumRVSUM-1K22 (-RVSUM-1K7 F) =HIDDENR1 -XCMPLX-0K4 SumRVSUM-1K20 F"
proof-
  have " for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds SumRVSUM-1K22 (-RVSUM-1K7 F) =HIDDENR1 -XCMPLX-0K4 SumRVSUM-1K20 F"
  proof(rule ballI)
    fix F assume [ty]: "F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    obtain F1 where 
      [ty]:"F1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2" and F1Def:"F1 = F"
      using rvsum_1_lm_2 sorry
    have "SumRVSUM-1K22 (-RVSUM-1K7 F) =HIDDENR1 (comprealBINOP-2K7).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((addrealBINOP-2K9)$$SETWOP-2K5\<^bsub>(REALNUMBERSK2)\<^esub> F1)"
      using rvsum_1_th_8 rvsum_1_th_9 setwop_2_th_31 sorry
    also have "... = -XCMPLX-0K4 SumRVSUM-1K22 F1"
      using binop_2_def_7 sorry
    also have "... = -XCMPLX-0K4 SumRVSUM-1K20 F"
       sorry
    finally show "SumRVSUM-1K22 (-RVSUM-1K7 F) =HIDDENR1 -XCMPLX-0K4 SumRVSUM-1K20 F"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_89:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds SumRVSUM-1K22 (R1 +RVSUM-1K6\<^bsub>(i)\<^esub> R2) =HIDDENR1 SumRVSUM-1K22 R1 +XCMPLX-0K2 SumRVSUM-1K22 R2"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds SumRVSUM-1K22 (R1 +RVSUM-1K6\<^bsub>(i)\<^esub> R2) =HIDDENR1 SumRVSUM-1K22 R1 +XCMPLX-0K2 SumRVSUM-1K22 R2"
  proof(rule ballI,rule ballI,rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix R1 assume [ty]: "R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    fix R2 assume [ty]: "R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    have "i be NatNAT-1M1"
      using tarski_th_1 sorry
    then have "SumRVSUM-1K22 (R1 +RVSUM-1K6\<^bsub>(i)\<^esub> R2) =HIDDENR1 (addrealBINOP-2K9).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>((addrealBINOP-2K9)$$SETWOP-2K5\<^bsub>(REALNUMBERSK2)\<^esub> R1,(addrealBINOP-2K9)$$SETWOP-2K5\<^bsub>(REALNUMBERSK2)\<^esub> R2)"
      using setwop_2_th_35 sorry
    also have "... = SumRVSUM-1K22 R1 +XCMPLX-0K2 SumRVSUM-1K22 R2"
      using binop_2_def_9 sorry
    finally show "SumRVSUM-1K22 (R1 +RVSUM-1K6\<^bsub>(i)\<^esub> R2) =HIDDENR1 SumRVSUM-1K22 R1 +XCMPLX-0K2 SumRVSUM-1K22 R2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_90:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds SumRVSUM-1K22 (R1 -RVSUM-1K10\<^bsub>(i)\<^esub> R2) =HIDDENR1 SumRVSUM-1K22 R1 -XCMPLX-0K6 SumRVSUM-1K22 R2"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds SumRVSUM-1K22 (R1 -RVSUM-1K10\<^bsub>(i)\<^esub> R2) =HIDDENR1 SumRVSUM-1K22 R1 -XCMPLX-0K6 SumRVSUM-1K22 R2"
  proof(rule ballI,rule ballI,rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix R1 assume [ty]: "R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    fix R2 assume [ty]: "R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    have "SumRVSUM-1K22 (R1 -RVSUM-1K10\<^bsub>(i)\<^esub> R2) =HIDDENR1 SumRVSUM-1K22 R1 +XCMPLX-0K2 SumRVSUM-1K22 (-RVSUM-1K8\<^bsub>(i)\<^esub> R2)"
      using rvsum_1_th_89 sorry
    also have "... = SumRVSUM-1K22 R1 +XCMPLX-0K2 (-XCMPLX-0K4 SumRVSUM-1K22 R2)"
      using rvsum_1_th_88 sorry
    also have "... = SumRVSUM-1K22 R1 -XCMPLX-0K6 SumRVSUM-1K22 R2"
       sorry
    finally show "SumRVSUM-1K22 (R1 -RVSUM-1K10\<^bsub>(i)\<^esub> R2) =HIDDENR1 SumRVSUM-1K22 R1 -XCMPLX-0K6 SumRVSUM-1K22 R2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_91:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(i)\<^esub> R) =HIDDENR1 0NUMBERSK6 implies R =FINSEQ-1R1 i  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(i)\<^esub> R) =HIDDENR1 0NUMBERSK6 implies (R <>HIDDENR2 i  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6) implies  not  True )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix R assume [ty]: "R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    assume A1: "SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(i)\<^esub> R) =HIDDENR1 0NUMBERSK6"
    have A2: "lenFINSEQ-1K4 R =HIDDENR1 i"
      using card_1_def_7 sorry
    have A3: "lenFINSEQ-1K4 (i  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)) =HIDDENR1 i"
      using card_1_def_7 sorry
    assume "R <>HIDDENR2 i  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)"
    then obtain j where
      [ty]:"j be NatNAT-1M1" and 
      A4: "j inTARSKIR2 domFINSEQ-1K5 R"and A5: "R .FUNCT-1K1 j <>HIDDENR2 (i  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)).FUNCT-1K1 j"
      using A2 A3 finseq_2_th_9 sorry
    let ?x = "R .FUNCT-1K1 j"
    let ?x9 = "sqrRVSUM-1K16\<^bsub>(i)\<^esub> R .FUNCT-1K1 j"
    have A6: "domFINSEQ-1K5 R =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 R)"
      using finseq_1_def_3 sorry
    have "?x <>HIDDENR2 0NUMBERSK6"
      using A5 sorry
    then have "0NUMBERSK6 <XXREAL-0R3 ?x ^2SQUARE-1K1"
      using square_1_th_12 sorry
    then have A7: "0NUMBERSK6 <XXREAL-0R3 ?x9"
      using valued_1_th_11 sorry
    have A8: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 (sqrRVSUM-1K16\<^bsub>(i)\<^esub> R) implies 0NUMBERSK6 <=XXREAL-0R1 sqrRVSUM-1K16\<^bsub>(i)\<^esub> R .FUNCT-1K1 k"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume "k inTARSKIR2 domFINSEQ-1K5 (sqrRVSUM-1K16\<^bsub>(i)\<^esub> R)"
      let ?r = "sqrRVSUM-1K16\<^bsub>(i)\<^esub> R .FUNCT-1K1 k"
      let ?x = "R .FUNCT-1K1 k"
      have "0NUMBERSK6 <=XXREAL-0R1 ?x ^2SQUARE-1K1"
        using xreal_1_th_63 sorry
      thus "0NUMBERSK6 <=XXREAL-0R1 sqrRVSUM-1K16\<^bsub>(i)\<^esub> R .FUNCT-1K1 k"
        using valued_1_th_11 sorry
    qed "sorry"
    have "domFINSEQ-1K5 (sqrRVSUM-1K16\<^bsub>(i)\<^esub> R) =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 (sqrRVSUM-1K16\<^bsub>(i)\<^esub> R))"
      using finseq_1_def_3 sorry
    then have "j inTARSKIR2 domFINSEQ-1K5 (sqrRVSUM-1K16\<^bsub>(i)\<^esub> R)"
      using A4 A6 finseq_2_th_33 sorry
    thus " not  True "
      using A1 A8 A7 rvsum_1_th_85 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_92:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds (SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(i)\<^esub>(R1,R2)))^2SQUARE-1K1 <=XXREAL-0R1 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(i)\<^esub> R1) *XCMPLX-0K3 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(i)\<^esub> R2)"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds (SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(i)\<^esub>(R1,R2)))^2SQUARE-1K1 <=XXREAL-0R1 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(i)\<^esub> R1) *XCMPLX-0K3 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(i)\<^esub> R2)"
  proof(rule ballI,rule ballI,rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix R1 assume [ty]: "R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    fix R2 assume [ty]: "R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    have A0: "i be NatNAT-1M1"
      using tarski_th_1 sorry
    let ?P = "\<lambda>Lamb1.  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of Lamb1 -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of Lamb1 -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds (SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(Lamb1)\<^esub>(R1,R2)))^2SQUARE-1K1 <=XXREAL-0R1 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(Lamb1)\<^esub> R1) *XCMPLX-0K3 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(Lamb1)\<^esub> R2)"
    have A1: " for c be NatNAT-1M1 holds ?P(c) implies ?P(c +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for c be NatNAT-1M1 holds ( for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of c -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of c -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds (SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(c)\<^esub>(R1,R2)))^2SQUARE-1K1 <=XXREAL-0R1 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R1) *XCMPLX-0K3 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R2)) implies ( for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of (c +NAT-1K1 \<one>\<^sub>M)-tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of (c +NAT-1K1 \<one>\<^sub>M)-tuples-onFINSEQ-2K4 REALNUMBERSK2 holds (SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(c +NAT-1K1 \<one>\<^sub>M)\<^esub>(R1,R2)))^2SQUARE-1K1 <=XXREAL-0R1 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c +NAT-1K1 \<one>\<^sub>M)\<^esub> R1) *XCMPLX-0K3 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c +NAT-1K1 \<one>\<^sub>M)\<^esub> R2))"
      proof(rule ballI,rule impI,rule ballI,rule ballI)
        fix c assume [ty]: "c be NatNAT-1M1"
        assume A2: " for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of c -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of c -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds (SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(c)\<^esub>(R1,R2)))^2SQUARE-1K1 <=XXREAL-0R1 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R1) *XCMPLX-0K3 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R2)"
        fix R1 assume [ty]: "R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of (c +NAT-1K1 \<one>\<^sub>M)-tuples-onFINSEQ-2K4 REALNUMBERSK2"
        fix R2 assume [ty]: "R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of (c +NAT-1K1 \<one>\<^sub>M)-tuples-onFINSEQ-2K4 REALNUMBERSK2"
        obtain R19 x1 where
          [ty]:"R19 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of c -tuples-onFINSEQ-2K4 REALNUMBERSK2" "x1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
          A3: "R1 =FINSEQ-1R1 R19 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> x1*>)"
          using finseq_2_th_117 sorry
        obtain R29 x2 where
          [ty]:"R29 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of c -tuples-onFINSEQ-2K4 REALNUMBERSK2" "x2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
          A4: "R2 =FINSEQ-1R1 R29 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> x2*>)"
          using finseq_2_th_117 sorry
        have A5: " for r be RealXREAL-0M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of c -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds SumRVSUM-1K22 (sqrRVSUM-1K15 (R ^FINSEQ-1K8 (<*FINSEQ-1K10 r*>))) =HIDDENR1 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R) +XCMPLX-0K2 r ^2SQUARE-1K1"
        proof-
          have " for r be RealXREAL-0M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of c -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds SumRVSUM-1K22 (sqrRVSUM-1K15 (R ^FINSEQ-1K8 (<*FINSEQ-1K10 r*>))) =HIDDENR1 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R) +XCMPLX-0K2 r ^2SQUARE-1K1"
          proof(rule ballI,rule ballI)
            fix r assume [ty]: "r be RealXREAL-0M1"
            fix R assume [ty]: "R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of c -tuples-onFINSEQ-2K4 REALNUMBERSK2"
            obtain s where 
              [ty]:"s be ElementSUBSET-1M1-of REALNUMBERSK2" and sDef:"s = r"
              using xreal_0_def_1 sorry
            have "sqrRVSUM-1K15 (R ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> s*>)) =HIDDENR1 (sqrrealRVSUM-1K3 *FINSEQOPK4\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> R)^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> sqrrealRVSUM-1K3 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> s*>)"
              using finseqop_th_8 sorry
            also have "... = sqrRVSUM-1K16\<^bsub>(c)\<^esub> R ^FINSEQ-1K8 (<*FINSEQ-1K10 r ^2SQUARE-1K1*>)"
              using rvsum_1_def_2 sorry
            finally have "sqrRVSUM-1K15 (R ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> s*>)) =HIDDENR1 sqrRVSUM-1K16\<^bsub>(c)\<^esub> R ^FINSEQ-1K8 (<*FINSEQ-1K10 r ^2SQUARE-1K1*>)"
               sorry
            thus "SumRVSUM-1K22 (sqrRVSUM-1K15 (R ^FINSEQ-1K8 (<*FINSEQ-1K10 r*>))) =HIDDENR1 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R) +XCMPLX-0K2 r ^2SQUARE-1K1"
              using rvsum_1_th_74 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        then have A6: "SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R29) +XCMPLX-0K2 x2 ^2SQUARE-1K1 =HIDDENR1 SumRVSUM-1K22 (sqrRVSUM-1K15 (R29 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> x2*>)))"
           sorry
        also have "... = SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c +NAT-1K1 \<one>\<^sub>M)\<^esub> R2)"
          using A4 sorry
        finally have "SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R29) +XCMPLX-0K2 x2 ^2SQUARE-1K1 =HIDDENR1 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c +NAT-1K1 \<one>\<^sub>M)\<^esub> R2)"
           sorry
        have "(SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(c)\<^esub>(R19,R29)))^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R19) *XCMPLX-0K3 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R29)"
          using A2 sorry
        then have A7: "0NUMBERSK6 <=XXREAL-0R1 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R19) *XCMPLX-0K3 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R29) -XCMPLX-0K6 (SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(c)\<^esub>(R19,R29)))^2SQUARE-1K1"
          using xreal_1_th_19 sorry
        have "mltRVSUM-1K18(R19 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> x1*>),R29 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> x2*>)) =HIDDENR1 (multrealBINOP-2K11).:FINSEQOPK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub>(R19,R29) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> (multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(x1,x2)*>)"
          using finseqop_th_10 sorry
        also have "... = mltRVSUM-1K19\<^bsub>(c)\<^esub>(R19,R29) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> x1 *REAL-1K4 x2 *>)"
          using binop_2_def_11 sorry
        finally have "mltRVSUM-1K18(R19 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> x1*>),R29 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> x2*>)) =HIDDENR1 mltRVSUM-1K19\<^bsub>(c)\<^esub>(R19,R29) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> x1 *REAL-1K4 x2 *>)"
           sorry
        then have A8: "SumRVSUM-1K22 (mltRVSUM-1K18(R19 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> x1*>),R29 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> x2*>))) =HIDDENR1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(c)\<^esub>(R19,R29)) +XCMPLX-0K2 x1 *REAL-1K4 x2"
          using rvsum_1_th_74 sorry
        have A9: "(\<two>\<^sub>M *XCMPLX-0K3 (x1 *REAL-1K4 x2))*XCMPLX-0K3 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(c)\<^esub>(R19,R29)) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((x1 *REAL-1K4 x2)*XCMPLX-0K3 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(c)\<^esub>(R19,R29)))"
           sorry
        also have "... = \<two>\<^sub>M *XCMPLX-0K3 SumRVSUM-1K22 ((x1 *REAL-1K4 x2)*RVSUM-1K13\<^bsub>(c)\<^esub> mltRVSUM-1K19\<^bsub>(c)\<^esub>(R19,R29))"
          using rvsum_1_th_87 sorry
        also have "... = \<two>\<^sub>M *XCMPLX-0K3 SumRVSUM-1K22 (x1 *RVSUM-1K13\<^bsub>(c)\<^esub> (x2 *RVSUM-1K13\<^bsub>(c)\<^esub> mltRVSUM-1K19\<^bsub>(c)\<^esub>(R19,R29)))"
          using rfunct_1_th_17 sorry
        also have "... = \<two>\<^sub>M *XCMPLX-0K3 SumRVSUM-1K22 (x1 *RVSUM-1K13\<^bsub>(c)\<^esub> mltRVSUM-1K19\<^bsub>(c)\<^esub>(R29,x2 *RVSUM-1K13\<^bsub>(c)\<^esub> R19))"
          using rfunct_1_th_12 sorry
        also have "... = \<two>\<^sub>M *XCMPLX-0K3 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(c)\<^esub>(x1 *RVSUM-1K13\<^bsub>(c)\<^esub> R29,x2 *RVSUM-1K13\<^bsub>(c)\<^esub> R19))"
          using finseqop_th_26 sorry
        finally have "(\<two>\<^sub>M *XCMPLX-0K3 (x1 *REAL-1K4 x2))*XCMPLX-0K3 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(c)\<^esub>(R19,R29)) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(c)\<^esub>(x1 *RVSUM-1K13\<^bsub>(c)\<^esub> R29,x2 *RVSUM-1K13\<^bsub>(c)\<^esub> R19))"
           sorry
        have A10: "-XCMPLX-0K4 (SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(c)\<^esub>(R19,R29)) +XCMPLX-0K2 x1 *REAL-1K4 x2)^2SQUARE-1K1 =HIDDENR1 (-XCMPLX-0K4 (x1 *REAL-1K4 x2)^2SQUARE-1K1)+XCMPLX-0K2 (-XCMPLX-0K4 ((\<two>\<^sub>M *XCMPLX-0K3 (x1 *REAL-1K4 x2))*XCMPLX-0K3 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(c)\<^esub>(R19,R29)) +XCMPLX-0K2 (SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(c)\<^esub>(R19,R29)))^2SQUARE-1K1))"
           sorry
        also have "... = (-XCMPLX-0K4 x1 ^2SQUARE-1K1 *XCMPLX-0K3 x2 ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 (SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(c)\<^esub>(R19,R29)))^2SQUARE-1K1)+XCMPLX-0K2 (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(c)\<^esub>(x1 *RVSUM-1K13\<^bsub>(c)\<^esub> R29,x2 *RVSUM-1K13\<^bsub>(c)\<^esub> R19))))"
          using A9 sorry
        finally have "-XCMPLX-0K4 (SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(c)\<^esub>(R19,R29)) +XCMPLX-0K2 x1 *REAL-1K4 x2)^2SQUARE-1K1 =HIDDENR1 (-XCMPLX-0K4 x1 ^2SQUARE-1K1 *XCMPLX-0K3 x2 ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 (SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(c)\<^esub>(R19,R29)))^2SQUARE-1K1)+XCMPLX-0K2 (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(c)\<^esub>(x1 *RVSUM-1K13\<^bsub>(c)\<^esub> R29,x2 *RVSUM-1K13\<^bsub>(c)\<^esub> R19))))"
           sorry
        have A11: "0NUMBERSK6 <=XXREAL-0R1 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> (x1 *RVSUM-1K13\<^bsub>(c)\<^esub> R29 -RVSUM-1K10\<^bsub>(c)\<^esub> x2 *RVSUM-1K13\<^bsub>(c)\<^esub> R19))"
          using rvsum_1_th_86 sorry
        have A12: "(SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R19) +XCMPLX-0K2 x1 ^2SQUARE-1K1)*XCMPLX-0K3 (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R29) +XCMPLX-0K2 x2 ^2SQUARE-1K1) =HIDDENR1 (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R19) *XCMPLX-0K3 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R29) +XCMPLX-0K2 (x1 ^2SQUARE-1K1 *XCMPLX-0K3 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R29) +XCMPLX-0K2 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R19) *XCMPLX-0K3 x2 ^2SQUARE-1K1))+XCMPLX-0K2 x1 ^2SQUARE-1K1 *XCMPLX-0K3 x2 ^2SQUARE-1K1"
           sorry
        also have "... = (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R19) *XCMPLX-0K3 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R29) +XCMPLX-0K2 (SumRVSUM-1K22 (x1 ^2SQUARE-1K1 *RVSUM-1K13\<^bsub>(c)\<^esub> sqrRVSUM-1K16\<^bsub>(c)\<^esub> R29) +XCMPLX-0K2 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R19) *XCMPLX-0K3 x2 ^2SQUARE-1K1))+XCMPLX-0K2 x1 ^2SQUARE-1K1 *XCMPLX-0K3 x2 ^2SQUARE-1K1"
          using rvsum_1_th_87 sorry
        also have "... = (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R19) *XCMPLX-0K3 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R29) +XCMPLX-0K2 (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> (x1 *RVSUM-1K13\<^bsub>(c)\<^esub> R29)) +XCMPLX-0K2 x2 ^2SQUARE-1K1 *XCMPLX-0K3 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R19)))+XCMPLX-0K2 x1 ^2SQUARE-1K1 *XCMPLX-0K3 x2 ^2SQUARE-1K1"
          using rvsum_1_th_58 sorry
        also have "... = (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R19) *XCMPLX-0K3 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R29) +XCMPLX-0K2 (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> (x1 *RVSUM-1K13\<^bsub>(c)\<^esub> R29)) +XCMPLX-0K2 SumRVSUM-1K22 (x2 ^2SQUARE-1K1 *RVSUM-1K13\<^bsub>(c)\<^esub> sqrRVSUM-1K16\<^bsub>(c)\<^esub> R19)))+XCMPLX-0K2 x1 ^2SQUARE-1K1 *XCMPLX-0K3 x2 ^2SQUARE-1K1"
          using rvsum_1_th_87 sorry
        also have "... = (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R19) *XCMPLX-0K3 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R29) +XCMPLX-0K2 (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> (x1 *RVSUM-1K13\<^bsub>(c)\<^esub> R29)) +XCMPLX-0K2 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> (x2 *RVSUM-1K13\<^bsub>(c)\<^esub> R19))))+XCMPLX-0K2 x1 ^2SQUARE-1K1 *XCMPLX-0K3 x2 ^2SQUARE-1K1"
          using rvsum_1_th_58 sorry
        finally have "(SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R19) +XCMPLX-0K2 x1 ^2SQUARE-1K1)*XCMPLX-0K3 (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R29) +XCMPLX-0K2 x2 ^2SQUARE-1K1) =HIDDENR1 (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R19) *XCMPLX-0K3 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R29) +XCMPLX-0K2 (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> (x1 *RVSUM-1K13\<^bsub>(c)\<^esub> R29)) +XCMPLX-0K2 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> (x2 *RVSUM-1K13\<^bsub>(c)\<^esub> R19))))+XCMPLX-0K2 x1 ^2SQUARE-1K1 *XCMPLX-0K3 x2 ^2SQUARE-1K1"
           sorry
        have A13: "(SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> (x1 *RVSUM-1K13\<^bsub>(c)\<^esub> R29)) +XCMPLX-0K2 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> (x2 *RVSUM-1K13\<^bsub>(c)\<^esub> R19)))+XCMPLX-0K2 (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(c)\<^esub>(x1 *RVSUM-1K13\<^bsub>(c)\<^esub> R29,x2 *RVSUM-1K13\<^bsub>(c)\<^esub> R19))) =HIDDENR1 (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> (x1 *RVSUM-1K13\<^bsub>(c)\<^esub> R29)) -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(c)\<^esub>(x1 *RVSUM-1K13\<^bsub>(c)\<^esub> R29,x2 *RVSUM-1K13\<^bsub>(c)\<^esub> R19)))+XCMPLX-0K2 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> (x2 *RVSUM-1K13\<^bsub>(c)\<^esub> R19))"
           sorry
        also have "... = (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> (x1 *RVSUM-1K13\<^bsub>(c)\<^esub> R29)) -XCMPLX-0K6 SumRVSUM-1K22 (\<two>\<^sub>M *RVSUM-1K13\<^bsub>(c)\<^esub> mltRVSUM-1K19\<^bsub>(c)\<^esub>(x1 *RVSUM-1K13\<^bsub>(c)\<^esub> R29,x2 *RVSUM-1K13\<^bsub>(c)\<^esub> R19)))+XCMPLX-0K2 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> (x2 *RVSUM-1K13\<^bsub>(c)\<^esub> R19))"
          using rvsum_1_th_87 sorry
        also have "... = SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> (x1 *RVSUM-1K13\<^bsub>(c)\<^esub> R29) -RVSUM-1K10\<^bsub>(c)\<^esub> \<two>\<^sub>M *RVSUM-1K13\<^bsub>(c)\<^esub> mltRVSUM-1K19\<^bsub>(c)\<^esub>(x1 *RVSUM-1K13\<^bsub>(c)\<^esub> R29,x2 *RVSUM-1K13\<^bsub>(c)\<^esub> R19)) +XCMPLX-0K2 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> (x2 *RVSUM-1K13\<^bsub>(c)\<^esub> R19))"
          using rvsum_1_th_90 sorry
        also have "... = SumRVSUM-1K22 ((sqrRVSUM-1K16\<^bsub>(c)\<^esub> (x1 *RVSUM-1K13\<^bsub>(c)\<^esub> R29) -RVSUM-1K10\<^bsub>(c)\<^esub> \<two>\<^sub>M *RVSUM-1K13\<^bsub>(c)\<^esub> mltRVSUM-1K19\<^bsub>(c)\<^esub>(x1 *RVSUM-1K13\<^bsub>(c)\<^esub> R29,x2 *RVSUM-1K13\<^bsub>(c)\<^esub> R19))+RVSUM-1K6\<^bsub>(c)\<^esub> sqrRVSUM-1K16\<^bsub>(c)\<^esub> (x2 *RVSUM-1K13\<^bsub>(c)\<^esub> R19))"
          using rvsum_1_th_89 sorry
        finally have "(SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> (x1 *RVSUM-1K13\<^bsub>(c)\<^esub> R29)) +XCMPLX-0K2 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> (x2 *RVSUM-1K13\<^bsub>(c)\<^esub> R19)))+XCMPLX-0K2 (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(c)\<^esub>(x1 *RVSUM-1K13\<^bsub>(c)\<^esub> R29,x2 *RVSUM-1K13\<^bsub>(c)\<^esub> R19))) =HIDDENR1 SumRVSUM-1K22 ((sqrRVSUM-1K16\<^bsub>(c)\<^esub> (x1 *RVSUM-1K13\<^bsub>(c)\<^esub> R29) -RVSUM-1K10\<^bsub>(c)\<^esub> \<two>\<^sub>M *RVSUM-1K13\<^bsub>(c)\<^esub> mltRVSUM-1K19\<^bsub>(c)\<^esub>(x1 *RVSUM-1K13\<^bsub>(c)\<^esub> R29,x2 *RVSUM-1K13\<^bsub>(c)\<^esub> R19))+RVSUM-1K6\<^bsub>(c)\<^esub> sqrRVSUM-1K16\<^bsub>(c)\<^esub> (x2 *RVSUM-1K13\<^bsub>(c)\<^esub> R19))"
           sorry
        have "SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R19) +XCMPLX-0K2 x1 ^2SQUARE-1K1 =HIDDENR1 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c +NAT-1K1 \<one>\<^sub>M)\<^esub> R1)"
          using A3 A5 sorry
        then have "SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c +NAT-1K1 \<one>\<^sub>M)\<^esub> R1) *XCMPLX-0K3 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c +NAT-1K1 \<one>\<^sub>M)\<^esub> R2) -XCMPLX-0K6 (SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(c +NAT-1K1 \<one>\<^sub>M)\<^esub>(R1,R2)))^2SQUARE-1K1 =HIDDENR1 (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R19) +XCMPLX-0K2 x1 ^2SQUARE-1K1)*XCMPLX-0K3 (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R29) +XCMPLX-0K2 x2 ^2SQUARE-1K1) +XCMPLX-0K2 (-XCMPLX-0K4 (SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(c)\<^esub>(R19,R29)) +XCMPLX-0K2 x1 *REAL-1K4 x2)^2SQUARE-1K1)"
          using A3 A4 A8 A6 sorry
        also have "... = (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R19) *XCMPLX-0K3 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R29) +XCMPLX-0K2 (-XCMPLX-0K4 (SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(c)\<^esub>(R19,R29)))^2SQUARE-1K1))+XCMPLX-0K2 ((SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> (x1 *RVSUM-1K13\<^bsub>(c)\<^esub> R29)) +XCMPLX-0K2 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> (x2 *RVSUM-1K13\<^bsub>(c)\<^esub> R19)))+XCMPLX-0K2 (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(c)\<^esub>(x1 *RVSUM-1K13\<^bsub>(c)\<^esub> R29,x2 *RVSUM-1K13\<^bsub>(c)\<^esub> R19))))"
          using A12 A10 sorry
        also have "... = (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R19) *XCMPLX-0K3 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R29) -XCMPLX-0K6 (SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(c)\<^esub>(R19,R29)))^2SQUARE-1K1)+XCMPLX-0K2 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> (x1 *RVSUM-1K13\<^bsub>(c)\<^esub> R29 -RVSUM-1K10\<^bsub>(c)\<^esub> x2 *RVSUM-1K13\<^bsub>(c)\<^esub> R19))"
          using A13 rvsum_1_th_69 sorry
        finally have "SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c +NAT-1K1 \<one>\<^sub>M)\<^esub> R1) *XCMPLX-0K3 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c +NAT-1K1 \<one>\<^sub>M)\<^esub> R2) -XCMPLX-0K6 (SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(c +NAT-1K1 \<one>\<^sub>M)\<^esub>(R1,R2)))^2SQUARE-1K1 =HIDDENR1 (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R19) *XCMPLX-0K3 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> R29) -XCMPLX-0K6 (SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(c)\<^esub>(R19,R29)))^2SQUARE-1K1)+XCMPLX-0K2 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c)\<^esub> (x1 *RVSUM-1K13\<^bsub>(c)\<^esub> R29 -RVSUM-1K10\<^bsub>(c)\<^esub> x2 *RVSUM-1K13\<^bsub>(c)\<^esub> R19))"
           sorry
        then have "(SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(c +NAT-1K1 \<one>\<^sub>M)\<^esub>(R1,R2)))^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c +NAT-1K1 \<one>\<^sub>M)\<^esub> R1) *XCMPLX-0K3 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c +NAT-1K1 \<one>\<^sub>M)\<^esub> R2)"
          using A7 A11 xreal_1_th_19 sorry
        thus "(SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(c +NAT-1K1 \<one>\<^sub>M)\<^esub>(R1,R2)))^2SQUARE-1K1 <=XXREAL-0R1 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c +NAT-1K1 \<one>\<^sub>M)\<^esub> R1) *XCMPLX-0K3 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(c +NAT-1K1 \<one>\<^sub>M)\<^esub> R2)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A14: "?P(0NUMBERSK6)"
       sorry
    have " for i be NatNAT-1M1 holds ?P(i)"
      using nat_1_sch_2 A14 A1 sorry
    thus "(SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(i)\<^esub>(R1,R2)))^2SQUARE-1K1 <=XXREAL-0R1 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(i)\<^esub> R1) *XCMPLX-0K3 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(i)\<^esub> R2)"
      using A0 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef rvsum_1_def_13 ("ProductRVSUM-1K23  _ " [228]228 ) where
  mlet "F be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1"
"func ProductRVSUM-1K23 F \<rightarrow> ComplexXCMPLX-0M1 means
  \<lambda>it.  ex f be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 st f =FINSEQ-1R1 F & it =HIDDENR1 multcomplexBINOP-2K5 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
proof-
  (*existence*)
    show " ex it be ComplexXCMPLX-0M1 st  ex f be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 st f =FINSEQ-1R1 F & it =HIDDENR1 multcomplexBINOP-2K5 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
    proof-
      have " ex IT be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 st  not ( for f be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 holds  not (f =FINSEQ-1R1 F & IT =HIDDENR1 multcomplexBINOP-2K5 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f))"
      proof-
        have "rngFUNCT-1K2 F c=TARSKIR1 COMPLEXNUMBERSK3"
          using valued_0_def_1 sorry
        then obtain f where 
          [ty]:"f be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3" and fDef:"f = F"
          using finseq_1_def_4 sorry
        obtain IT where 
          [ty]:"IT be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and ITDef:"IT = multcomplexBINOP-2K5 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
           sorry
        show " ex IT be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 st  not ( for f be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 holds  not (f =FINSEQ-1R1 F & IT =HIDDENR1 multcomplexBINOP-2K5 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f))"
        proof(rule bexI[of _ "IT"])
          show " not ( for f be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 holds  not (f =FINSEQ-1R1 F & IT =HIDDENR1 multcomplexBINOP-2K5 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f))"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be ComplexXCMPLX-0M1 holds  for it2 be ComplexXCMPLX-0M1 holds ( ex f be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 st f =FINSEQ-1R1 F & it1 =HIDDENR1 multcomplexBINOP-2K5 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f) & ( ex f be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 st f =FINSEQ-1R1 F & it2 =HIDDENR1 multcomplexBINOP-2K5 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f) implies it1 =HIDDENR1 it2"
       sorry
qed "sorry"

mtheorem rvsum_1_cl_13:
  mlet "F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
"cluster ProductRVSUM-1K23 F as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "ProductRVSUM-1K23 F be realXREAL-0V1"
  proof-
    let ?mc = "multcomplexBINOP-2K5"
    obtain f where
      [ty]:"f be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3" and 
      A1: "f =FINSEQ-1R1 F"and A2: "ProductRVSUM-1K23 F =HIDDENR1 multcomplexBINOP-2K5 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
      using rvsum_1_def_13 sorry
    let ?g = "[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ?mc)"
    let ?P = "\<lambda>Lamb1. ?mc $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 Lamb1,[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ?mc)) be realXREAL-0V1"
    have A3: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds multcomplexBINOP-2K5 $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 k,[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (multcomplexBINOP-2K5))) be realXREAL-0V1 implies multcomplexBINOP-2K5 $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 (k +NAT-1K1 \<one>\<^sub>M),[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (multcomplexBINOP-2K5))) be realXREAL-0V1"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A4: "?P(k)"
        have 
          [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "?g .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) be realXREAL-0V1"
        proof-
          have "[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (multcomplexBINOP-2K5)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) be realXREAL-0V1"
          proof-
            show "[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (multcomplexBINOP-2K5)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) be realXREAL-0V1"
            proof-
              have cases: "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f or  not k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
                 sorry
              have case1: "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f implies [#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (multcomplexBINOP-2K5)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) be realXREAL-0V1"
              proof(rule impI)
                assume "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
                then have "?g .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
                  using setwop_2_th_20 sorry
                thus "[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (multcomplexBINOP-2K5)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) be realXREAL-0V1"
                  using A1 sorry
              qed
              have case2: " not k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f implies [#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (multcomplexBINOP-2K5)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) be realXREAL-0V1"
              proof(rule impI)
                assume " not k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
                thus "[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (multcomplexBINOP-2K5)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) be realXREAL-0V1"
                  using binop_2_th_6 setwop_2_th_20 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus " ?thesis "
             sorry
        qed
        then obtain a b where 
          [ty]:"a be RealXREAL-0M1" and aDef:"a = ?g .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)" and
          [ty]:"b be RealXREAL-0M1" and bDef:"b = ?mc $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 k,?g)"
          using A4 sorry
        have " not k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 k"
          using finseq_3_th_8 sorry
        then have "?mc $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 k \\/SETWISEOK8\<^bsub>(NATNUMBERSK1)\<^esub> {.SETWISEOK5\<^bsub>(NATNUMBERSK1)\<^esub> InSUBSET-1K10(k +NAT-1K1 \<one>\<^sub>M,NATNUMBERSK1) .},?g) =HIDDENR1 ?mc .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(?mc $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 k,?g),?g .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
          using setwop_2_th_2 sorry
        also have "... = b *XCMPLX-0K3 a"
          using binop_2_def_5 sorry
        finally have "?mc $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 k \\/SETWISEOK8\<^bsub>(NATNUMBERSK1)\<^esub> {.SETWISEOK5\<^bsub>(NATNUMBERSK1)\<^esub> InSUBSET-1K10(k +NAT-1K1 \<one>\<^sub>M,NATNUMBERSK1) .},?g) =HIDDENR1 b *XCMPLX-0K3 a"
           sorry
        thus "multcomplexBINOP-2K5 $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 (k +NAT-1K1 \<one>\<^sub>M),[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (multcomplexBINOP-2K5))) be realXREAL-0V1"
          using finseq_1_th_9 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A5: "?mc $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f =XBOOLE-0R4 ?mc $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(findomFINSOP-1K4 f,[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ?mc)) & ( ex n be NatNAT-1M1 st domFINSEQ-1K5 f =XBOOLE-0R4 SegFINSEQ-1K2 n)"
      using finseq_1_def_2 setwop_2_def_2 sorry
    have "SegFINSEQ-1K2 (0NUMBERSK6) =FINSEQ-1R1 {}.SETWISEOK1 NATNUMBERSK1"
       sorry
    then have A6: "?P(0NUMBERSK6)"
      using binop_2_th_6 setwiseo_th_31 sorry
    have " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A6 A3 sorry
    thus "ProductRVSUM-1K23 F be realXREAL-0V1"
      using A2 A5 sorry
  qed
qed "sorry"

mtheorem rvsum_1_th_93:
" for F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds ProductRVSUM-1K23 F =HIDDENR1 (multrealBINOP-2K11)$$SETWOP-2K5\<^bsub>(REALNUMBERSK2)\<^esub> F"
proof(rule ballI)
  let ?g = "multrealBINOP-2K11"
  let ?h = "multcomplexBINOP-2K5"
  fix F assume [ty]: "F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
  have "rngRVSUM-1K1 F c=TARSKIR1 COMPLEXNUMBERSK3"
    using numbers_th_11 xboole_1_th_1 sorry
  then obtain f where 
    [ty]:"f be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3" and fDef:"f = F"
    using finseq_1_def_4 sorry
  let ?P = "\<lambda>Lamb1. ?g $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub>(finSegSETWOP-2K3 Lamb1,[#]SETWOP-2K1\<^bsub>(REALNUMBERSK2)\<^esub>(F,the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> ?g)) =XBOOLE-0R4 ?h $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 Lamb1,[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ?h))"
  obtain n where
    [ty]:"n be NatNAT-1M1" and 
    A1: "domFINSEQ-1K5 f =XBOOLE-0R4 SegFINSEQ-1K2 n"
    using finseq_1_def_2 sorry
  have A2: "?g $$SETWOP-2K5\<^bsub>(REALNUMBERSK2)\<^esub> F =XBOOLE-0R4 ?g $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub>(finSegSETWOP-2K3 n,[#]SETWOP-2K1\<^bsub>(REALNUMBERSK2)\<^esub>(F,the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> ?g)) & ?h $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f =XBOOLE-0R4 ?h $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 n,[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ?h))"
    using A1 setwop_2_def_2 sorry
  have A3: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
  proof-
    have " for k be NatNAT-1M1 holds (multrealBINOP-2K11)$$SETWISEOK10\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub>(finSegSETWOP-2K3 k,[#]SETWOP-2K1\<^bsub>(REALNUMBERSK2)\<^esub>(F,the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> (multrealBINOP-2K11))) =XBOOLE-0R4 multcomplexBINOP-2K5 $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 k,[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (multcomplexBINOP-2K5))) implies (multrealBINOP-2K11)$$SETWISEOK10\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub>(finSegSETWOP-2K3 (k +NAT-1K1 \<one>\<^sub>M),[#]SETWOP-2K1\<^bsub>(REALNUMBERSK2)\<^esub>(F,the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> (multrealBINOP-2K11))) =XBOOLE-0R4 multcomplexBINOP-2K5 $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 (k +NAT-1K1 \<one>\<^sub>M),[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (multcomplexBINOP-2K5)))"
    proof(rule ballI,rule impI)
      let ?j = "[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ?h)"
      let ?i = "[#]SETWOP-2K1\<^bsub>(REALNUMBERSK2)\<^esub>(F,the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> ?g)"
      fix k assume [ty]: "k be NatNAT-1M1"
      assume A4: "?P(k)"
      have A5: "?i .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 ?j .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
      proof-
        have "[#]SETWOP-2K1\<^bsub>(REALNUMBERSK2)\<^esub>(F,the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> (multrealBINOP-2K11)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 [#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (multcomplexBINOP-2K5)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
        proof-
          show "[#]SETWOP-2K1\<^bsub>(REALNUMBERSK2)\<^esub>(F,the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> (multrealBINOP-2K11)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 [#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (multcomplexBINOP-2K5)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          proof-
            have cases: "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f or  not k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
               sorry
            have case1: "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f implies [#]SETWOP-2K1\<^bsub>(REALNUMBERSK2)\<^esub>(F,the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> (multrealBINOP-2K11)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 [#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (multcomplexBINOP-2K5)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
            proof(rule impI)
              assume A6: "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
              then have "?j .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 F .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
                using setwop_2_th_20 sorry
              also have "... = ?i .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
                using A6 setwop_2_th_20 sorry
              finally have "?j .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ?i .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
                 sorry
              thus "[#]SETWOP-2K1\<^bsub>(REALNUMBERSK2)\<^esub>(F,the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> (multrealBINOP-2K11)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 [#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (multcomplexBINOP-2K5)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
                 sorry
            qed
            have case2: " not k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f implies [#]SETWOP-2K1\<^bsub>(REALNUMBERSK2)\<^esub>(F,the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> (multrealBINOP-2K11)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 [#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (multcomplexBINOP-2K5)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
            proof(rule impI)
              assume A7: " not k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
              then have "?j .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ?h"
                using setwop_2_th_20 sorry
              also have "... = ?i .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
                using A7 binop_2_th_6 binop_2_th_7 setwop_2_th_20 sorry
              finally have "?j .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ?i .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
                 sorry
              thus "[#]SETWOP-2K1\<^bsub>(REALNUMBERSK2)\<^esub>(F,the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> (multrealBINOP-2K11)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 [#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (multcomplexBINOP-2K5)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus " ?thesis "
           sorry
      qed
      have A8: " not k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 k"
        using finseq_3_th_8 sorry
      have 
        [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1"
        using ordinal1_def_12 sorry
      have "?g $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub>(finSegSETWOP-2K3 (k +NAT-1K1 \<one>\<^sub>M),?i) =HIDDENR1 ?g $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub>(finSegSETWOP-2K3 k \\/SETWISEOK8\<^bsub>(NATNUMBERSK1)\<^esub> {.SETWISEOK5\<^bsub>(NATNUMBERSK1)\<^esub> InSUBSET-1K10(k +NAT-1K1 \<one>\<^sub>M,NATNUMBERSK1) .},?i)"
        using finseq_1_th_9 sorry
      also have "... = ?g .BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(?g $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub>(finSegSETWOP-2K3 k,?i),?i .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
        using A8 setwop_2_th_2 sorry
      also have "... = ?g $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub>(finSegSETWOP-2K3 k,?i) *REAL-1K4 ?i .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
        using binop_2_def_11 sorry
      also have "... = ?h .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(?h $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 k,?j),?j .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
        using A4 A5 binop_2_def_5 sorry
      also have "... = ?h $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 k \\/SETWISEOK8\<^bsub>(NATNUMBERSK1)\<^esub> {.SETWISEOK5\<^bsub>(NATNUMBERSK1)\<^esub> InSUBSET-1K10(k +NAT-1K1 \<one>\<^sub>M,NATNUMBERSK1) .},?j)"
        using A8 setwop_2_th_2 sorry
      also have "... = ?h $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 (k +NAT-1K1 \<one>\<^sub>M),?j)"
        using finseq_1_th_9 sorry
      finally have "?g $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub>(finSegSETWOP-2K3 (k +NAT-1K1 \<one>\<^sub>M),?i) =HIDDENR1 ?h $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 (k +NAT-1K1 \<one>\<^sub>M),?j)"
         sorry
      thus "(multrealBINOP-2K11)$$SETWISEOK10\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub>(finSegSETWOP-2K3 (k +NAT-1K1 \<one>\<^sub>M),[#]SETWOP-2K1\<^bsub>(REALNUMBERSK2)\<^esub>(F,the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> (multrealBINOP-2K11))) =XBOOLE-0R4 multcomplexBINOP-2K5 $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 (k +NAT-1K1 \<one>\<^sub>M),[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (multcomplexBINOP-2K5)))"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have A9: "SegFINSEQ-1K2 (0NUMBERSK6) =FINSEQ-1R1 {}.SETWISEOK1 NATNUMBERSK1"
     sorry
  then have "?g $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub>(finSegSETWOP-2K3 (0NUMBERSK6),[#]SETWOP-2K1\<^bsub>(REALNUMBERSK2)\<^esub>(F,the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> ?g)) =HIDDENR1 the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ?h"
    using binop_2_th_6 binop_2_th_7 setwiseo_th_31 sorry
  also have "... = ?h $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 (0NUMBERSK6),[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ?h))"
    using A9 setwiseo_th_31 sorry
  finally have "?g $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub>(finSegSETWOP-2K3 (0NUMBERSK6),[#]SETWOP-2K1\<^bsub>(REALNUMBERSK2)\<^esub>(F,the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> ?g)) =HIDDENR1 ?h $$SETWISEOK10\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub>(finSegSETWOP-2K3 (0NUMBERSK6),[#]SETWOP-2K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(f,the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ?h))"
     sorry
  then have A10: "?P(0NUMBERSK6)"
     sorry
  have " for k be NatNAT-1M1 holds ?P(k)"
    using nat_1_sch_2 A10 A3 sorry
  then have "?g $$SETWOP-2K5\<^bsub>(REALNUMBERSK2)\<^esub> F =XBOOLE-0R4 ?h $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
    using A2 sorry
  thus "ProductRVSUM-1K23 F =HIDDENR1 (multrealBINOP-2K11)$$SETWOP-2K5\<^bsub>(REALNUMBERSK2)\<^esub> F"
    using rvsum_1_def_13 sorry
qed "sorry"

abbreviation(input) RVSUM_1K24("ProductRVSUM-1K24  _ " [228]228) where
  "ProductRVSUM-1K24 F \<equiv> ProductRVSUM-1K23 F"

mtheorem rvsum_1_def_14:
  mlet "F be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
"redefine func ProductRVSUM-1K24 F \<rightarrow> ElementSUBSET-1M1-of COMPLEXNUMBERSK3 equals
  multcomplexBINOP-2K5 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> F"
proof
(*compatibility*)
  show " for it be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds it =HIDDENR1 ProductRVSUM-1K24 F iff it =HIDDENR1 multcomplexBINOP-2K5 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> F"
    using rvsum_1_def_13 sorry
qed "sorry"

mtheorem rvsum_1_add_16:
  mlet "F be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
"cluster ProductRVSUM-1K23 F as-term-is ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
proof
(*coherence*)
  show "ProductRVSUM-1K23 F be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    using xcmplx_0_def_2 sorry
qed "sorry"

abbreviation(input) RVSUM_1K25("ProductRVSUM-1K25  _ " [228]228) where
  "ProductRVSUM-1K25 F \<equiv> ProductRVSUM-1K23 F"

mtheorem rvsum_1_def_15:
  mlet "F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
"redefine func ProductRVSUM-1K25 F \<rightarrow> RealXREAL-0M1 equals
  (multrealBINOP-2K11)$$SETWOP-2K5\<^bsub>(REALNUMBERSK2)\<^esub> F"
proof
(*compatibility*)
  show " for it be RealXREAL-0M1 holds it =HIDDENR1 ProductRVSUM-1K25 F iff it =HIDDENR1 (multrealBINOP-2K11)$$SETWOP-2K5\<^bsub>(REALNUMBERSK2)\<^esub> F"
    using rvsum_1_th_93 sorry
qed "sorry"

mtheorem rvsum_1_add_17:
  mlet "F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
"cluster ProductRVSUM-1K23 F as-term-is RealXREAL-0M1"
proof
(*coherence*)
  show "ProductRVSUM-1K23 F be RealXREAL-0M1"
     sorry
qed "sorry"

mlemma rvsum_1_lm_4:
" for F be emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M1 holds ProductRVSUM-1K23 F =HIDDENR1 \<one>\<^sub>M"
proof-
  have "ProductRVSUM-1K25 <*>FINSEQ-1K7 REALNUMBERSK2 =HIDDENR1 \<one>\<^sub>M"
    using binop_2_th_7 finsop_1_th_10 sorry
  thus " for F be emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M1 holds ProductRVSUM-1K23 F =HIDDENR1 \<one>\<^sub>M"
     sorry
qed

mtheorem rvsum_1_th_94:
"ProductRVSUM-1K25 <*>FINSEQ-1K7 REALNUMBERSK2 =HIDDENR1 \<one>\<^sub>M"
  using rvsum_1_lm_4 sorry

mtheorem rvsum_1_cl_14:
  mlet "r be ComplexXCMPLX-0M1"
"cluster <*FINSEQ-1K10 r*> as-term-is complex-valuedVALUED-0V5"
proof
(*coherence*)
  show "<*FINSEQ-1K10 r*> be complex-valuedVALUED-0V5"
  proof-
    have "<*FINSEQ-1K10 r*> be complex-valuedVALUED-0V1"
    proof-
      obtain p where 
        [ty]:"p be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and pDef:"p = r"
        using xcmplx_0_def_2 sorry
      obtain f where 
        [ty]:"f be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3" and fDef:"f = <*FINSEQ-1K13\<^bsub>(COMPLEXNUMBERSK3)\<^esub> p*>"
         sorry
      have "f be FinSequence-likeFINSEQ-1V1"
         sorry
      thus "<*FINSEQ-1K10 r*> be complex-valuedVALUED-0V1"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rvsum_1_cl_15:
  mlet "r1 be ComplexXCMPLX-0M1", "r2 be ComplexXCMPLX-0M1"
"cluster <*FINSEQ-1K11 r1,r2 *> as-term-is complex-valuedVALUED-0V5"
proof
(*coherence*)
  show "<*FINSEQ-1K11 r1,r2 *> be complex-valuedVALUED-0V5"
  proof-
    have "<*FINSEQ-1K11 r1,r2 *> be complex-valuedVALUED-0V1"
    proof-
      obtain p1 p2 where 
        [ty]:"p1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and p1Def:"p1 = r1" and
        [ty]:"p2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and p2Def:"p2 = r2"
        using xcmplx_0_def_2 sorry
      obtain f where 
        [ty]:"f be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3" and fDef:"f = <*FINSEQ-4K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> p1,p2 *>"
         sorry
      have "f be FinSequence-likeFINSEQ-1V1"
         sorry
      thus "<*FINSEQ-1K11 r1,r2 *> be complex-valuedVALUED-0V1"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rvsum_1_cl_16:
  mlet "r1 be ComplexXCMPLX-0M1", "r2 be ComplexXCMPLX-0M1", "r3 be ComplexXCMPLX-0M1"
"cluster <*FINSEQ-1K12 r1,r2,r3 *> as-term-is complex-valuedVALUED-0V5"
proof
(*coherence*)
  show "<*FINSEQ-1K12 r1,r2,r3 *> be complex-valuedVALUED-0V5"
  proof-
    have "<*FINSEQ-1K12 r1,r2,r3 *> be complex-valuedVALUED-0V1"
    proof-
      obtain p1 p2 p3 where 
        [ty]:"p1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and p1Def:"p1 = r1" and
        [ty]:"p2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and p2Def:"p2 = r2" and
        [ty]:"p3 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and p3Def:"p3 = r3"
        using xcmplx_0_def_2 sorry
      obtain f where 
        [ty]:"f be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3" and fDef:"f = <*FINSEQ-4K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> p1,p2,p3 *>"
         sorry
      have "f be FinSequence-likeFINSEQ-1V1"
         sorry
      thus "<*FINSEQ-1K12 r1,r2,r3 *> be complex-valuedVALUED-0V1"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rvsum_1_cl_17:
  mlet "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "c be ComplexXCMPLX-0M1"
"cluster j  |->FINSEQ-2K2 c as-term-is complex-valuedVALUED-0V5"
proof
(*coherence*)
  show "j  |->FINSEQ-2K2 c be complex-valuedVALUED-0V5"
     sorry
qed "sorry"

mtheorem rvsum_1_th_95:
" for r be ComplexXCMPLX-0M1 holds ProductRVSUM-1K23 (<*FINSEQ-1K10 r*>) =HIDDENR1 r"
proof(rule ballI)
  fix r assume [ty]: "r be ComplexXCMPLX-0M1"
  obtain r9 where 
    [ty]:"r9 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and r9Def:"r9 = r"
    using xcmplx_0_def_2 sorry
  obtain F where 
    [ty]:"F be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3" and FDef:"F = <*FINSEQ-1K13\<^bsub>(COMPLEXNUMBERSK3)\<^esub> r9*>"
     sorry
  have "multcomplexBINOP-2K5 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> F =HIDDENR1 r"
    using finsop_1_th_11 sorry
  thus "ProductRVSUM-1K23 (<*FINSEQ-1K10 r*>) =HIDDENR1 r"
    using rvsum_1_def_13 sorry
qed "sorry"

mtheorem rvsum_1_cl_18:
  mlet "f be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1", "g be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1"
"cluster f ^FINSEQ-1K8 g as-term-is complex-valuedVALUED-0V5"
proof
(*coherence*)
  show "f ^FINSEQ-1K8 g be complex-valuedVALUED-0V5"
  proof-
    have "f ^FINSEQ-1K8 g be complex-valuedVALUED-0V1"
    proof-
      have A1: "rngFUNCT-1K2 (f ^FINSEQ-1K8 g) =XBOOLE-0R4 rngFUNCT-1K2 f \\/XBOOLE-0K2 rngFUNCT-1K2 g"
        using finseq_1_th_31 sorry
      have "rngFUNCT-1K2 f c=TARSKIR1 COMPLEXNUMBERSK3 & rngFUNCT-1K2 g c=TARSKIR1 COMPLEXNUMBERSK3"
        using valued_0_def_1 sorry
      then have "rngFUNCT-1K2 (f ^FINSEQ-1K8 g) c=TARSKIR1 COMPLEXNUMBERSK3"
        using A1 xboole_1_th_8 sorry
      thus "f ^FINSEQ-1K8 g be complex-valuedVALUED-0V1"
        using valued_0_def_1 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rvsum_1_th_96:
" for F be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1 holds  for r be ComplexXCMPLX-0M1 holds ProductRVSUM-1K23 (F ^FINSEQ-1K8 (<*FINSEQ-1K10 r*>)) =HIDDENR1 ProductRVSUM-1K23 F *XCMPLX-0K3 r"
proof(rule ballI,rule ballI)
  fix F assume [ty]: "F be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1"
  fix r assume [ty]: "r be ComplexXCMPLX-0M1"
  obtain p where 
    [ty]:"p be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and pDef:"p = r"
    using xcmplx_0_def_2 sorry
  have "rngFUNCT-1K2 F c=TARSKIR1 COMPLEXNUMBERSK3 & rngFUNCT-1K2 (F ^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(COMPLEXNUMBERSK3)\<^esub> p*>)) c=TARSKIR1 COMPLEXNUMBERSK3"
    using valued_0_def_1 sorry
  then obtain Fr Ff where 
    [ty]:"Fr be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3" and FrDef:"Fr = F ^FINSEQ-1K8 (<*FINSEQ-1K10 r*>)" and
    [ty]:"Ff be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3" and FfDef:"Ff = F"
    using finseq_1_def_4 sorry
  have "ProductRVSUM-1K23 (F ^FINSEQ-1K8 (<*FINSEQ-1K10 r*>)) =HIDDENR1 multcomplexBINOP-2K5 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Fr"
    using rvsum_1_def_13 sorry
  also have "... = multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(ProductRVSUM-1K24 Ff,p)"
    using finsop_1_th_4 sorry
  also have "... = ProductRVSUM-1K23 F *XCMPLX-0K3 r"
    using binop_2_def_5 sorry
  finally show "ProductRVSUM-1K23 (F ^FINSEQ-1K8 (<*FINSEQ-1K10 r*>)) =HIDDENR1 ProductRVSUM-1K23 F *XCMPLX-0K3 r"
     sorry
qed "sorry"

mtheorem rvsum_1_th_97:
" for F1 be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1 holds ProductRVSUM-1K23 (F1 ^FINSEQ-1K8 F2) =HIDDENR1 ProductRVSUM-1K23 F1 *XCMPLX-0K3 ProductRVSUM-1K23 F2"
proof(rule ballI,rule ballI)
  fix F1 assume [ty]: "F1 be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1"
  fix F2 assume [ty]: "F2 be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1"
  have A1: "rngFUNCT-1K2 (F1 ^FINSEQ-1K8 F2) c=TARSKIR1 COMPLEXNUMBERSK3"
    using valued_0_def_1 sorry
  have "rngFUNCT-1K2 F1 c=TARSKIR1 COMPLEXNUMBERSK3 & rngFUNCT-1K2 F2 c=TARSKIR1 COMPLEXNUMBERSK3"
    using valued_0_def_1 sorry
  then obtain FF f1 f2 where 
    [ty]:"FF be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3" and FFDef:"FF = F1 ^FINSEQ-1K8 F2" and
    [ty]:"f1 be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3" and f1Def:"f1 = F1" and
    [ty]:"f2 be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3" and f2Def:"f2 = F2"
    using A1 finseq_1_def_4 sorry
  have "ProductRVSUM-1K23 (F1 ^FINSEQ-1K8 F2) =HIDDENR1 multcomplexBINOP-2K5 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> FF"
    using rvsum_1_def_13 sorry
  also have "... = multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(ProductRVSUM-1K24 f1,ProductRVSUM-1K24 f2)"
    using finsop_1_th_5 sorry
  also have "... = ProductRVSUM-1K23 F1 *XCMPLX-0K3 ProductRVSUM-1K23 F2"
    using binop_2_def_5 sorry
  finally show "ProductRVSUM-1K23 (F1 ^FINSEQ-1K8 F2) =HIDDENR1 ProductRVSUM-1K23 F1 *XCMPLX-0K3 ProductRVSUM-1K23 F2"
     sorry
qed "sorry"

mtheorem rvsum_1_th_98:
" for r be RealXREAL-0M1 holds  for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds ProductRVSUM-1K23 ((<*FINSEQ-1K10 r*>)^FINSEQ-1K8 F) =HIDDENR1 r *XCMPLX-0K3 ProductRVSUM-1K23 F"
proof-
  have " for r be RealXREAL-0M1 holds  for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds ProductRVSUM-1K23 ((<*FINSEQ-1K10 r*>)^FINSEQ-1K8 F) =HIDDENR1 r *XCMPLX-0K3 ProductRVSUM-1K23 F"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix F assume [ty]: "F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    have "ProductRVSUM-1K23 ((<*FINSEQ-1K10 r*>)^FINSEQ-1K8 F) =HIDDENR1 ProductRVSUM-1K23 (<*FINSEQ-1K10 r*>) *XCMPLX-0K3 ProductRVSUM-1K23 F"
      using rvsum_1_th_97 sorry
    also have "... = r *XCMPLX-0K3 ProductRVSUM-1K23 F"
      using rvsum_1_th_95 sorry
    finally show "ProductRVSUM-1K23 ((<*FINSEQ-1K10 r*>)^FINSEQ-1K8 F) =HIDDENR1 r *XCMPLX-0K3 ProductRVSUM-1K23 F"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_99:
" for r1 be ComplexXCMPLX-0M1 holds  for r2 be ComplexXCMPLX-0M1 holds ProductRVSUM-1K23 (<*FINSEQ-1K11 r1,r2 *>) =HIDDENR1 r1 *XCMPLX-0K3 r2"
proof(rule ballI,rule ballI)
  fix r1 assume [ty]: "r1 be ComplexXCMPLX-0M1"
  fix r2 assume [ty]: "r2 be ComplexXCMPLX-0M1"
  have "ProductRVSUM-1K23 (<*FINSEQ-1K11 r1,r2 *>) =HIDDENR1 ProductRVSUM-1K23 (<*FINSEQ-1K10 r1*>) *XCMPLX-0K3 r2"
    using rvsum_1_th_96 sorry
  also have "... = r1 *XCMPLX-0K3 r2"
    using rvsum_1_th_95 sorry
  finally show "ProductRVSUM-1K23 (<*FINSEQ-1K11 r1,r2 *>) =HIDDENR1 r1 *XCMPLX-0K3 r2"
     sorry
qed "sorry"

mtheorem rvsum_1_th_100:
" for r1 be ComplexXCMPLX-0M1 holds  for r2 be ComplexXCMPLX-0M1 holds  for r3 be ComplexXCMPLX-0M1 holds ProductRVSUM-1K23 (<*FINSEQ-1K12 r1,r2,r3 *>) =HIDDENR1 (r1 *XCMPLX-0K3 r2)*XCMPLX-0K3 r3"
proof(rule ballI,rule ballI,rule ballI)
  fix r1 assume [ty]: "r1 be ComplexXCMPLX-0M1"
  fix r2 assume [ty]: "r2 be ComplexXCMPLX-0M1"
  fix r3 assume [ty]: "r3 be ComplexXCMPLX-0M1"
  have "ProductRVSUM-1K23 (<*FINSEQ-1K12 r1,r2,r3 *>) =HIDDENR1 ProductRVSUM-1K23 (<*FINSEQ-1K11 r1,r2 *>) *XCMPLX-0K3 r3"
    using rvsum_1_th_96 sorry
  also have "... = (r1 *XCMPLX-0K3 r2)*XCMPLX-0K3 r3"
    using rvsum_1_th_99 sorry
  finally show "ProductRVSUM-1K23 (<*FINSEQ-1K12 r1,r2,r3 *>) =HIDDENR1 (r1 *XCMPLX-0K3 r2)*XCMPLX-0K3 r3"
     sorry
qed "sorry"

mtheorem rvsum_1_th_101:
" for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of (0NUMBERSK6)-tuples-onFINSEQ-2K4 REALNUMBERSK2 holds ProductRVSUM-1K25 R =HIDDENR1 \<one>\<^sub>M"
  using rvsum_1_lm_4 sorry

mtheorem rvsum_1_th_102:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds ProductRVSUM-1K23 (i  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M) =HIDDENR1 \<one>\<^sub>M"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds ProductRVSUM-1K23 (i  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M) =HIDDENR1 \<one>\<^sub>M"
  proof(rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have "i be NatNAT-1M1"
      using tarski_th_1 sorry
    then have "ProductRVSUM-1K25 (i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> (multrealBINOP-2K11)) =HIDDENR1 the-unity-wrtBINOP-1K3\<^bsub>(REALNUMBERSK2)\<^esub> (multrealBINOP-2K11)"
      using setwop_2_th_25 sorry
    thus "ProductRVSUM-1K23 (i  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M) =HIDDENR1 \<one>\<^sub>M"
      using binop_2_th_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma rvsum_1_lm_5:
" for p be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 p <>HIDDENR2 0NUMBERSK6 implies ( ex q be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1 st  ex d be ComplexXCMPLX-0M1 st p =FINSEQ-1R1 q ^FINSEQ-1K8 (<*FINSEQ-1K10 d*>))"
proof-
  have " for p be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 p <>HIDDENR2 0NUMBERSK6 implies  not ( for q be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1 holds  for d be ComplexXCMPLX-0M1 holds  not p =FINSEQ-1R1 q ^FINSEQ-1K8 (<*FINSEQ-1K10 d*>))"
  proof(rule ballI,rule impI)
    fix p assume [ty]: "p be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1"
    assume "lenFINSEQ-1K4 p <>HIDDENR2 0NUMBERSK6"
    then obtain q d where
      [ty]:"q be FinSequenceFINSEQ-1M1" "d be objectHIDDENM1" and 
      A1: "p =FINSEQ-1R1 q ^FINSEQ-1K8 (<*FINSEQ-1K10 d*>)"
      using card_1_th_27 finseq_1_th_46 sorry
    have "rngFUNCT-1K2 p c=TARSKIR1 COMPLEXNUMBERSK3"
      using valued_0_def_1 sorry
    then have A2: "p be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
      using finseq_1_def_4 sorry
    have " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 q implies q .FUNCT-1K1 i inTARSKIR2 COMPLEXNUMBERSK3"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be NatNAT-1M1"
      assume "i inTARSKIR2 domFINSEQ-1K5 q"
      then have "p .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i & i inTARSKIR2 domFINSEQ-1K5 p"
        using A1 finseq_1_def_7 finseq_2_th_15 sorry
      thus "q .FUNCT-1K1 i inTARSKIR2 COMPLEXNUMBERSK3"
        using A2 finseq_2_th_11 sorry
    qed "sorry"
    then have A3: "q be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
      using finseq_2_th_12 sorry
    have "lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M"
      using A1 finseq_2_th_16 sorry
    then have "p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 d"
      using A1 finseq_1_th_42 sorry
    thus " not ( for q be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1 holds  for d be ComplexXCMPLX-0M1 holds  not p =FINSEQ-1R1 q ^FINSEQ-1K8 (<*FINSEQ-1K10 d*>))"
      using A1 A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_103:
" for F be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1 holds ( ex k be NatNAT-1M1 st k inTARSKIR2 domFINSEQ-1K5 F & F .FUNCT-1K1 k =XBOOLE-0R4 0NUMBERSK6) iff ProductRVSUM-1K23 F =HIDDENR1 0NUMBERSK6"
proof-
  have " for F be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1 holds  not ( not ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 domFINSEQ-1K5 F & F .FUNCT-1K1 k =XBOOLE-0R4 0NUMBERSK6)) &  not ProductRVSUM-1K23 F =HIDDENR1 0NUMBERSK6) &  not (ProductRVSUM-1K23 F =HIDDENR1 0NUMBERSK6 & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 domFINSEQ-1K5 F & F .FUNCT-1K1 k =XBOOLE-0R4 0NUMBERSK6)))"
  proof(rule ballI)
    let ?P = "\<lambda>Lamb1.  for F be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 F =XBOOLE-0R4 Lamb1 implies (( ex k be NatNAT-1M1 st k inTARSKIR2 SegFINSEQ-1K2 Lamb1 & F .FUNCT-1K1 k =XBOOLE-0R4 0NUMBERSK6) iff ProductRVSUM-1K23 F =HIDDENR1 0NUMBERSK6)"
    fix F assume [ty]: "F be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1"
    have A1: "SegFINSEQ-1K2 (lenFINSEQ-1K4 F) =XBOOLE-0R4 domFINSEQ-1K5 F"
      using finseq_1_def_3 sorry
    have A2: " for i be NatNAT-1M1 holds ?P(i) implies ?P(i +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for i be NatNAT-1M1 holds ( for F be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 F =XBOOLE-0R4 i implies (( ex k be NatNAT-1M1 st k inTARSKIR2 SegFINSEQ-1K2 i & F .FUNCT-1K1 k =XBOOLE-0R4 0NUMBERSK6) iff ProductRVSUM-1K23 F =HIDDENR1 0NUMBERSK6)) implies ( for F be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 F =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M implies (( ex k be NatNAT-1M1 st k inTARSKIR2 SegFINSEQ-1K2 (i +NAT-1K1 \<one>\<^sub>M) & F .FUNCT-1K1 k =XBOOLE-0R4 0NUMBERSK6) implies ProductRVSUM-1K23 F =HIDDENR1 0NUMBERSK6) & (ProductRVSUM-1K23 F =HIDDENR1 0NUMBERSK6 implies  not ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 SegFINSEQ-1K2 (i +NAT-1K1 \<one>\<^sub>M) & F .FUNCT-1K1 k =XBOOLE-0R4 0NUMBERSK6))))"
      proof(rule ballI,rule impI,rule ballI,rule impI,rule conjMI,rule impI)
        fix i assume [ty]: "i be NatNAT-1M1"
        assume A3: " for F be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 F =XBOOLE-0R4 i implies (( ex k be NatNAT-1M1 st k inTARSKIR2 SegFINSEQ-1K2 i & F .FUNCT-1K1 k =XBOOLE-0R4 0NUMBERSK6) iff ProductRVSUM-1K23 F =HIDDENR1 0NUMBERSK6)"
        fix F assume [ty]: "F be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1"
        assume A4: "lenFINSEQ-1K4 F =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M"
        then obtain F9 x where
          [ty]:"F9 be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1" "x be ComplexXCMPLX-0M1" and 
          A5: "F =FINSEQ-1R1 F9 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)"
          using rvsum_1_lm_5 sorry
        have A6: "lenFINSEQ-1K4 F =XBOOLE-0R4 lenFINSEQ-1K4 F9 +NAT-1K1 \<one>\<^sub>M"
          using A5 finseq_2_th_16 sorry
        have A7: "ProductRVSUM-1K23 F =HIDDENR1 ProductRVSUM-1K23 F9 *XCMPLX-0K3 x"
          using A5 rvsum_1_th_96 sorry
        show "( ex k be NatNAT-1M1 st k inTARSKIR2 SegFINSEQ-1K2 (i +NAT-1K1 \<one>\<^sub>M) & F .FUNCT-1K1 k =XBOOLE-0R4 0NUMBERSK6) implies ProductRVSUM-1K23 F =HIDDENR1 0NUMBERSK6"
        proof(rule impI)
          assume Given: " ex k be NatNAT-1M1 st k inTARSKIR2 SegFINSEQ-1K2 (i +NAT-1K1 \<one>\<^sub>M) & F .FUNCT-1K1 k =XBOOLE-0R4 0NUMBERSK6"
          then obtain k where
            [ty]:"k be NatNAT-1M1" and 
            A8: "k inTARSKIR2 SegFINSEQ-1K2 (i +NAT-1K1 \<one>\<^sub>M)"and A9: "F .FUNCT-1K1 k =XBOOLE-0R4 0NUMBERSK6"
             sorry
          have "ProductRVSUM-1K23 F =HIDDENR1 0NUMBERSK6"
          proof-
            show "ProductRVSUM-1K23 F =HIDDENR1 0NUMBERSK6"
            proof-
              have cases: "k inTARSKIR2 SegFINSEQ-1K2 i or k =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M"
                using A8 finseq_2_th_7 sorry
              have case1: "k inTARSKIR2 SegFINSEQ-1K2 i implies ProductRVSUM-1K23 F =HIDDENR1 0NUMBERSK6"
              proof(rule impI)
                assume A10: "k inTARSKIR2 SegFINSEQ-1K2 i"
                have "SegFINSEQ-1K2 (lenFINSEQ-1K4 F9) =XBOOLE-0R4 domFINSEQ-1K5 F9"
                  using finseq_1_def_3 sorry
                then have "F9 .FUNCT-1K1 k =XBOOLE-0R4 F .FUNCT-1K1 k"
                  using A4 A5 A6 A10 finseq_1_def_7 sorry
                then have "ProductRVSUM-1K23 F9 =HIDDENR1 0NUMBERSK6"
                  using A3 A4 A6 A9 A10 sorry
                thus "ProductRVSUM-1K23 F =HIDDENR1 0NUMBERSK6"
                  using A7 sorry
              qed
              have case2: "k =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M implies ProductRVSUM-1K23 F =HIDDENR1 0NUMBERSK6"
              proof(rule impI)
                assume "k =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M"
                then have "x =HIDDENR1 0NUMBERSK6"
                  using A4 A5 A6 A9 finseq_1_th_42 sorry
                thus "ProductRVSUM-1K23 F =HIDDENR1 0NUMBERSK6"
                  using A7 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "ProductRVSUM-1K23 F =HIDDENR1 0NUMBERSK6"
             sorry
        qed
        assume A11: "ProductRVSUM-1K23 F =HIDDENR1 0NUMBERSK6"
        show " not ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 SegFINSEQ-1K2 (i +NAT-1K1 \<one>\<^sub>M) & F .FUNCT-1K1 k =XBOOLE-0R4 0NUMBERSK6))"
        proof-
          have cases: "ProductRVSUM-1K23 F9 =HIDDENR1 0NUMBERSK6 or x =HIDDENR1 0NUMBERSK6"
            using A7 A11 sorry
          have case1: "ProductRVSUM-1K23 F9 =HIDDENR1 0NUMBERSK6 implies  not ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 SegFINSEQ-1K2 (i +NAT-1K1 \<one>\<^sub>M) & F .FUNCT-1K1 k =XBOOLE-0R4 0NUMBERSK6))"
          proof(rule impI)
            assume "ProductRVSUM-1K23 F9 =HIDDENR1 0NUMBERSK6"
            then obtain k where
              [ty]:"k be NatNAT-1M1" and 
              A12: "k inTARSKIR2 SegFINSEQ-1K2 i"and A13: "F9 .FUNCT-1K1 k =XBOOLE-0R4 0NUMBERSK6"
              using A3 A4 A6 sorry
            have "SegFINSEQ-1K2 (lenFINSEQ-1K4 F9) =XBOOLE-0R4 domFINSEQ-1K5 F9"
              using finseq_1_def_3 sorry
            then have "F .FUNCT-1K1 k =XBOOLE-0R4 0NUMBERSK6"
              using A4 A5 A6 A12 A13 finseq_1_def_7 sorry
            thus " not ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 SegFINSEQ-1K2 (i +NAT-1K1 \<one>\<^sub>M) & F .FUNCT-1K1 k =XBOOLE-0R4 0NUMBERSK6))"
              using A12 finseq_2_th_8 sorry
          qed
          have case2: "x =HIDDENR1 0NUMBERSK6 implies  not ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 SegFINSEQ-1K2 (i +NAT-1K1 \<one>\<^sub>M) & F .FUNCT-1K1 k =XBOOLE-0R4 0NUMBERSK6))"
          proof(rule impI)
            assume "x =HIDDENR1 0NUMBERSK6"
            then have "F .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6"
              using A4 A5 A6 finseq_1_th_42 sorry
            thus " not ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 SegFINSEQ-1K2 (i +NAT-1K1 \<one>\<^sub>M) & F .FUNCT-1K1 k =XBOOLE-0R4 0NUMBERSK6))"
              using finseq_1_th_4 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A14: "?P(0NUMBERSK6)"
    proof-
      have " for F be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 F =XBOOLE-0R4 0NUMBERSK6 implies  not ( not ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 SegFINSEQ-1K2 (0NUMBERSK6) & F .FUNCT-1K1 k =XBOOLE-0R4 0NUMBERSK6)) &  not ProductRVSUM-1K23 F =HIDDENR1 0NUMBERSK6) &  not (ProductRVSUM-1K23 F =HIDDENR1 0NUMBERSK6 & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 SegFINSEQ-1K2 (0NUMBERSK6) & F .FUNCT-1K1 k =XBOOLE-0R4 0NUMBERSK6)))"
      proof(rule ballI,rule impI)
        fix F assume [ty]: "F be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1"
        assume "lenFINSEQ-1K4 F =XBOOLE-0R4 0NUMBERSK6"
        then have "F =FINSEQ-1R1 <*>FINSEQ-1K7 (COMPLEXNUMBERSK3)"
           sorry
        thus " not ( not ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 SegFINSEQ-1K2 (0NUMBERSK6) & F .FUNCT-1K1 k =XBOOLE-0R4 0NUMBERSK6)) &  not ProductRVSUM-1K23 F =HIDDENR1 0NUMBERSK6) &  not (ProductRVSUM-1K23 F =HIDDENR1 0NUMBERSK6 & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 SegFINSEQ-1K2 (0NUMBERSK6) & F .FUNCT-1K1 k =XBOOLE-0R4 0NUMBERSK6)))"
          using rvsum_1_th_94 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for i be NatNAT-1M1 holds ?P(i)"
      using nat_1_sch_2 A14 A2 sorry
    thus " not ( not ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 domFINSEQ-1K5 F & F .FUNCT-1K1 k =XBOOLE-0R4 0NUMBERSK6)) &  not ProductRVSUM-1K23 F =HIDDENR1 0NUMBERSK6) &  not (ProductRVSUM-1K23 F =HIDDENR1 0NUMBERSK6 & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 domFINSEQ-1K5 F & F .FUNCT-1K1 k =XBOOLE-0R4 0NUMBERSK6)))"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_104:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r be RealXREAL-0M1 holds ProductRVSUM-1K23 ((i +XCMPLX-0K2 j) |->FINSEQ-2K2 r) =HIDDENR1 ProductRVSUM-1K23 (i  |->FINSEQ-2K2 r) *XCMPLX-0K3 ProductRVSUM-1K23 (j  |->FINSEQ-2K2 r)"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r be RealXREAL-0M1 holds ProductRVSUM-1K23 ((i +XCMPLX-0K2 j) |->FINSEQ-2K2 r) =HIDDENR1 ProductRVSUM-1K23 (i  |->FINSEQ-2K2 r) *XCMPLX-0K3 ProductRVSUM-1K23 (j  |->FINSEQ-2K2 r)"
  proof(rule ballI,rule ballI,rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix j assume [ty]: "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    have 
      [ty]:"i be NatNAT-1M1" and
      [ty]:"j be NatNAT-1M1"
      using tarski_th_1 sorry
    obtain s where 
      [ty]:"s be ElementSUBSET-1M1-of REALNUMBERSK2" and sDef:"s = r"
      using xreal_0_def_1 sorry
    have "ProductRVSUM-1K25 ((i +XCMPLX-0K2 j) |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s) =HIDDENR1 (multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>((multrealBINOP-2K11)$$SETWOP-2K5\<^bsub>(REALNUMBERSK2)\<^esub> (i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s),(multrealBINOP-2K11)$$SETWOP-2K5\<^bsub>(REALNUMBERSK2)\<^esub> (j  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s))"
      using setwop_2_th_26 sorry
    also have "... = ProductRVSUM-1K25 (i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s) *XCMPLX-0K3 ProductRVSUM-1K25 (j  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s)"
      using binop_2_def_11 sorry
    finally have "ProductRVSUM-1K25 ((i +XCMPLX-0K2 j) |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s) =HIDDENR1 ProductRVSUM-1K25 (i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s) *XCMPLX-0K3 ProductRVSUM-1K25 (j  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s)"
       sorry
    thus "ProductRVSUM-1K23 ((i +XCMPLX-0K2 j) |->FINSEQ-2K2 r) =HIDDENR1 ProductRVSUM-1K23 (i  |->FINSEQ-2K2 r) *XCMPLX-0K3 ProductRVSUM-1K23 (j  |->FINSEQ-2K2 r)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_105:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r be RealXREAL-0M1 holds ProductRVSUM-1K23 ((i *XCMPLX-0K3 j) |->FINSEQ-2K2 r) =HIDDENR1 ProductRVSUM-1K23 (j  |->FINSEQ-2K2 ProductRVSUM-1K23 (i  |->FINSEQ-2K2 r))"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r be RealXREAL-0M1 holds ProductRVSUM-1K23 ((i *XCMPLX-0K3 j) |->FINSEQ-2K2 r) =HIDDENR1 ProductRVSUM-1K23 (j  |->FINSEQ-2K2 ProductRVSUM-1K23 (i  |->FINSEQ-2K2 r))"
  proof(rule ballI,rule ballI,rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix j assume [ty]: "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    have 
      [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2"
      using xreal_0_def_1 sorry
    obtain pr where 
      [ty]:"pr be ElementSUBSET-1M1-of REALNUMBERSK2" and prDef:"pr = ProductRVSUM-1K25 (i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> r)"
       sorry
    have "i be NatNAT-1M1 & j be NatNAT-1M1"
      using tarski_th_1 sorry
    then have "ProductRVSUM-1K25 ((i *XCMPLX-0K3 j) |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> r) =HIDDENR1 ProductRVSUM-1K25 (j  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> pr)"
      using setwop_2_th_27 sorry
    thus "ProductRVSUM-1K23 ((i *XCMPLX-0K3 j) |->FINSEQ-2K2 r) =HIDDENR1 ProductRVSUM-1K23 (j  |->FINSEQ-2K2 ProductRVSUM-1K23 (i  |->FINSEQ-2K2 r))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_106:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds ProductRVSUM-1K23 (i  |->FINSEQ-2K2 (r1 *XCMPLX-0K3 r2)) =HIDDENR1 ProductRVSUM-1K23 (i  |->FINSEQ-2K2 r1) *XCMPLX-0K3 ProductRVSUM-1K23 (i  |->FINSEQ-2K2 r2)"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds ProductRVSUM-1K23 (i  |->FINSEQ-2K2 (r1 *XCMPLX-0K3 r2)) =HIDDENR1 ProductRVSUM-1K23 (i  |->FINSEQ-2K2 r1) *XCMPLX-0K3 ProductRVSUM-1K23 (i  |->FINSEQ-2K2 r2)"
  proof(rule ballI,rule ballI,rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix r1 assume [ty]: "r1 be RealXREAL-0M1"
    fix r2 assume [ty]: "r2 be RealXREAL-0M1"
    have 
      [ty]:"i be NatNAT-1M1"
      using tarski_th_1 sorry
    obtain s1 s2 where 
      [ty]:"s1 be ElementSUBSET-1M1-of REALNUMBERSK2" and s1Def:"s1 = r1" and
      [ty]:"s2 be ElementSUBSET-1M1-of REALNUMBERSK2" and s2Def:"s2 = r2"
      using xreal_0_def_1 sorry
    obtain ss where 
      [ty]:"ss be ElementSUBSET-1M1-of REALNUMBERSK2" and ssDef:"ss = s1 *REAL-1K4 s2"
       sorry
    have "ProductRVSUM-1K25 (i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> ss) =HIDDENR1 (multrealBINOP-2K11)$$SETWOP-2K5\<^bsub>(REALNUMBERSK2)\<^esub> (i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> (multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(s1,s2))"
      using binop_2_def_11 sorry
    also have "... = (multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>((multrealBINOP-2K11)$$SETWOP-2K5\<^bsub>(REALNUMBERSK2)\<^esub> (i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s1),(multrealBINOP-2K11)$$SETWOP-2K5\<^bsub>(REALNUMBERSK2)\<^esub> (i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s2))"
      using setwop_2_th_36 sorry
    also have "... = ProductRVSUM-1K25 (i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s1) *XCMPLX-0K3 ProductRVSUM-1K25 (i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s2)"
      using binop_2_def_11 sorry
    finally have "ProductRVSUM-1K25 (i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> ss) =HIDDENR1 ProductRVSUM-1K25 (i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s1) *XCMPLX-0K3 ProductRVSUM-1K25 (i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s2)"
       sorry
    thus "ProductRVSUM-1K23 (i  |->FINSEQ-2K2 (r1 *XCMPLX-0K3 r2)) =HIDDENR1 ProductRVSUM-1K23 (i  |->FINSEQ-2K2 r1) *XCMPLX-0K3 ProductRVSUM-1K23 (i  |->FINSEQ-2K2 r2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_107:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds ProductRVSUM-1K25 (mltRVSUM-1K19\<^bsub>(i)\<^esub>(R1,R2)) =HIDDENR1 ProductRVSUM-1K25 R1 *XCMPLX-0K3 ProductRVSUM-1K25 R2"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds ProductRVSUM-1K25 (mltRVSUM-1K19\<^bsub>(i)\<^esub>(R1,R2)) =HIDDENR1 ProductRVSUM-1K25 R1 *XCMPLX-0K3 ProductRVSUM-1K25 R2"
  proof(rule ballI,rule ballI,rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix R1 assume [ty]: "R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    fix R2 assume [ty]: "R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    have "i be NatNAT-1M1"
      using tarski_th_1 sorry
    then have "ProductRVSUM-1K25 (mltRVSUM-1K19\<^bsub>(i)\<^esub>(R1,R2)) =HIDDENR1 (multrealBINOP-2K11).BINOP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>((multrealBINOP-2K11)$$SETWOP-2K5\<^bsub>(REALNUMBERSK2)\<^esub> R1,(multrealBINOP-2K11)$$SETWOP-2K5\<^bsub>(REALNUMBERSK2)\<^esub> R2)"
      using setwop_2_th_35 sorry
    also have "... = ProductRVSUM-1K25 R1 *XCMPLX-0K3 ProductRVSUM-1K25 R2"
      using binop_2_def_11 sorry
    finally show "ProductRVSUM-1K25 (mltRVSUM-1K19\<^bsub>(i)\<^esub>(R1,R2)) =HIDDENR1 ProductRVSUM-1K25 R1 *XCMPLX-0K3 ProductRVSUM-1K25 R2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_108:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r be RealXREAL-0M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds ProductRVSUM-1K25 (r *RVSUM-1K13\<^bsub>(i)\<^esub> R) =HIDDENR1 ProductRVSUM-1K23 (i  |->FINSEQ-2K2 r) *XCMPLX-0K3 ProductRVSUM-1K25 R"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r be RealXREAL-0M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds ProductRVSUM-1K25 (r *RVSUM-1K13\<^bsub>(i)\<^esub> R) =HIDDENR1 ProductRVSUM-1K23 (i  |->FINSEQ-2K2 r) *XCMPLX-0K3 ProductRVSUM-1K25 R"
  proof(rule ballI,rule ballI,rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix R assume [ty]: "R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    obtain s where 
      [ty]:"s be ElementSUBSET-1M1-of REALNUMBERSK2" and sDef:"s = r"
      using xreal_0_def_1 sorry
    have "ProductRVSUM-1K25 (r *RVSUM-1K13\<^bsub>(i)\<^esub> R) =HIDDENR1 ProductRVSUM-1K25 (mltRVSUM-1K19\<^bsub>(i)\<^esub>(i  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> s,R))"
      using rvsum_1_th_63 sorry
    also have "... = ProductRVSUM-1K23 (i  |->FINSEQ-2K2 r) *XCMPLX-0K3 ProductRVSUM-1K25 R"
      using rvsum_1_th_107 sorry
    finally show "ProductRVSUM-1K25 (r *RVSUM-1K13\<^bsub>(i)\<^esub> R) =HIDDENR1 ProductRVSUM-1K23 (i  |->FINSEQ-2K2 r) *XCMPLX-0K3 ProductRVSUM-1K25 R"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_109:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds ProductRVSUM-1K25 (sqrRVSUM-1K16\<^bsub>(i)\<^esub> R) =HIDDENR1 (ProductRVSUM-1K25 R)^2SQUARE-1K1"
  using rvsum_1_th_107 sorry

(*begin*)
reserve z, z1, z2 for "ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
mtheorem rvsum_1_th_110:
" for F be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 holds ProductRVSUM-1K24 F =XBOOLE-0R4 multcomplexBINOP-2K5 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> F"
   sorry

mtheorem rvsum_1_th_111:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds ProductRVSUM-1K24 ((i +XCMPLX-0K2 j) |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z) =XBOOLE-0R4 ProductRVSUM-1K24 (i  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z) *XCMPLX-0K3 ProductRVSUM-1K24 (j  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z)"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds ProductRVSUM-1K24 ((i +XCMPLX-0K2 j) |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z) =XBOOLE-0R4 ProductRVSUM-1K24 (i  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z) *XCMPLX-0K3 ProductRVSUM-1K24 (j  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z)"
  proof(rule ballI,rule ballI,rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix j assume [ty]: "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    have 
      [ty]:"i be NatNAT-1M1" and
      [ty]:"j be NatNAT-1M1"
      using tarski_th_1 sorry
    have "ProductRVSUM-1K24 ((i +XCMPLX-0K2 j) |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z) =HIDDENR1 multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(multcomplexBINOP-2K5 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (i  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z),multcomplexBINOP-2K5 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (j  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z))"
      using setwop_2_th_26 sorry
    also have "... = ProductRVSUM-1K24 (i  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z) *XCMPLX-0K3 ProductRVSUM-1K24 (j  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z)"
      using binop_2_def_5 sorry
    finally have "ProductRVSUM-1K24 ((i +XCMPLX-0K2 j) |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z) =HIDDENR1 ProductRVSUM-1K24 (i  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z) *XCMPLX-0K3 ProductRVSUM-1K24 (j  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z)"
       sorry
    thus "ProductRVSUM-1K24 ((i +XCMPLX-0K2 j) |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z) =XBOOLE-0R4 ProductRVSUM-1K24 (i  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z) *XCMPLX-0K3 ProductRVSUM-1K24 (j  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_112:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds ProductRVSUM-1K24 ((i *XCMPLX-0K3 j) |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z) =XBOOLE-0R4 ProductRVSUM-1K24 (j  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ProductRVSUM-1K24 (i  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z))"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds ProductRVSUM-1K24 ((i *XCMPLX-0K3 j) |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z) =XBOOLE-0R4 ProductRVSUM-1K24 (j  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ProductRVSUM-1K24 (i  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z))"
  proof(rule ballI,rule ballI,rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix j assume [ty]: "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    have "i be NatNAT-1M1 & j be NatNAT-1M1"
      using tarski_th_1 sorry
    thus "ProductRVSUM-1K24 ((i *XCMPLX-0K3 j) |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z) =XBOOLE-0R4 ProductRVSUM-1K24 (j  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ProductRVSUM-1K24 (i  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z))"
      using setwop_2_th_27 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma rvsum_1_lm_6:
" for F be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1 holds F be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
proof(rule ballI)
  fix F assume [ty]: "F be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1"
  have "rngFUNCT-1K2 F c=TARSKIR1 COMPLEXNUMBERSK3"
  proof-
    show "rngFUNCT-1K2 F c=TARSKIR1 COMPLEXNUMBERSK3"
      using valued_0_def_1 sorry
  qed
  thus "F be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
    using finseq_1_def_4 sorry
qed "sorry"

mtheorem rvsum_1_th_113:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for z1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for z2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds ProductRVSUM-1K23 (i  |->FINSEQ-2K2 (z1 *XCMPLX-0K3 z2)) =HIDDENR1 ProductRVSUM-1K24 (i  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1) *XCMPLX-0K3 ProductRVSUM-1K24 (i  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2)"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for z1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for z2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds ProductRVSUM-1K23 (i  |->FINSEQ-2K2 (z1 *XCMPLX-0K3 z2)) =HIDDENR1 ProductRVSUM-1K24 (i  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1) *XCMPLX-0K3 ProductRVSUM-1K24 (i  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2)"
  proof(rule ballI,rule ballI,rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix z1 assume [ty]: "z1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    fix z2 assume [ty]: "z2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    have 
      [ty]:"i be NatNAT-1M1"
      using tarski_th_1 sorry
    obtain zz where 
      [ty]:"zz be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3" and zzDef:"zz = i  |->FINSEQ-2K2 (z1 *XCMPLX-0K3 z2)"
      using rvsum_1_lm_6 sorry
    have "ProductRVSUM-1K23 (i  |->FINSEQ-2K2 (z1 *XCMPLX-0K3 z2)) =HIDDENR1 ProductRVSUM-1K24 zz"
       sorry
    also have "... = multcomplexBINOP-2K5 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (i  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(z1,z2))"
      using binop_2_def_5 sorry
    also have "... = multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(multcomplexBINOP-2K5 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (i  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1),multcomplexBINOP-2K5 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (i  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2))"
      using setwop_2_th_36 sorry
    also have "... = ProductRVSUM-1K24 (i  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1) *XCMPLX-0K3 ProductRVSUM-1K24 (i  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2)"
      using binop_2_def_5 sorry
    finally have "ProductRVSUM-1K23 (i  |->FINSEQ-2K2 (z1 *XCMPLX-0K3 z2)) =HIDDENR1 ProductRVSUM-1K24 (i  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1) *XCMPLX-0K3 ProductRVSUM-1K24 (i  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2)"
       sorry
    thus "ProductRVSUM-1K23 (i  |->FINSEQ-2K2 (z1 *XCMPLX-0K3 z2)) =HIDDENR1 ProductRVSUM-1K24 (i  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1) *XCMPLX-0K3 ProductRVSUM-1K24 (i  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
reserve n for "NatNAT-1M1"
reserve x, y, a for "RealXREAL-0M1"
reserve p, p1, p2, p3, q, q1, q2 for "ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
mtheorem rvsum_1_th_114:
" for x be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 (-RVSUM-1K7 x) =XBOOLE-0R4 lenFINSEQ-1K4 x"
proof(rule ballI)
  fix x assume [ty]: "x be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
  have "domFINSEQ-1K5 (-RVSUM-1K7 x) =XBOOLE-0R4 domFINSEQ-1K5 x"
    using valued_1_th_8 sorry
  thus "lenFINSEQ-1K4 (-RVSUM-1K7 x) =XBOOLE-0R4 lenFINSEQ-1K4 x"
    using finseq_3_th_29 sorry
qed "sorry"

mtheorem rvsum_1_th_115:
" for x1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for x2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 x1 =XBOOLE-0R4 lenFINSEQ-1K4 x2 implies lenFINSEQ-1K4 (x1 +RVSUM-1K5 x2) =XBOOLE-0R4 lenFINSEQ-1K4 x1"
proof(rule ballI,rule ballI,rule impI)
  fix x1 assume [ty]: "x1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
  fix x2 assume [ty]: "x2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
  let ?n = "lenFINSEQ-1K4 x1"
  have A1: "x2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    using rvsum_1_lm_2 sorry
  have "x1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    using rvsum_1_lm_2 sorry
  then obtain z1 where 
    [ty]:"z1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of (lenFINSEQ-1K4 x1)-tuples-onFINSEQ-2K4 REALNUMBERSK2" and z1Def:"z1 = x1"
    using finseq_2_th_92 sorry
  assume "lenFINSEQ-1K4 x1 =XBOOLE-0R4 lenFINSEQ-1K4 x2"
  then obtain z2 where 
    [ty]:"z2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of ?n -tuples-onFINSEQ-2K4 REALNUMBERSK2" and z2Def:"z2 = x2"
    using A1 finseq_2_th_92 sorry
  have "domFINSEQ-1K5 (z1 +RVSUM-1K6\<^bsub>(lenFINSEQ-1K4 x1)\<^esub> z2) =XBOOLE-0R4 SegFINSEQ-1K2 ?n"
    using finseq_2_th_124 sorry
  thus "lenFINSEQ-1K4 (x1 +RVSUM-1K5 x2) =XBOOLE-0R4 lenFINSEQ-1K4 x1"
    using finseq_1_def_3 sorry
qed "sorry"

mtheorem rvsum_1_th_116:
" for x1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for x2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 x1 =XBOOLE-0R4 lenFINSEQ-1K4 x2 implies lenFINSEQ-1K4 (x1 -RVSUM-1K9 x2) =XBOOLE-0R4 lenFINSEQ-1K4 x1"
proof(rule ballI,rule ballI,rule impI)
  fix x1 assume [ty]: "x1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
  fix x2 assume [ty]: "x2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
  let ?n = "lenFINSEQ-1K4 x1"
  have A1: "x2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    using rvsum_1_lm_2 sorry
  have "x1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    using rvsum_1_lm_2 sorry
  then obtain z1 where 
    [ty]:"z1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of (lenFINSEQ-1K4 x1)-tuples-onFINSEQ-2K4 REALNUMBERSK2" and z1Def:"z1 = x1"
    using finseq_2_th_92 sorry
  assume "lenFINSEQ-1K4 x1 =XBOOLE-0R4 lenFINSEQ-1K4 x2"
  then obtain z2 where 
    [ty]:"z2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of ?n -tuples-onFINSEQ-2K4 REALNUMBERSK2" and z2Def:"z2 = x2"
    using A1 finseq_2_th_92 sorry
  have "domFINSEQ-1K5 (z1 -RVSUM-1K10\<^bsub>(lenFINSEQ-1K4 x1)\<^esub> z2) =XBOOLE-0R4 SegFINSEQ-1K2 ?n"
    using finseq_2_th_124 sorry
  thus "lenFINSEQ-1K4 (x1 -RVSUM-1K9 x2) =XBOOLE-0R4 lenFINSEQ-1K4 x1"
    using finseq_1_def_3 sorry
qed "sorry"

mtheorem rvsum_1_th_117:
" for a be RealXREAL-0M1 holds  for x be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 (a *RVSUM-1K12 x) =XBOOLE-0R4 lenFINSEQ-1K4 x"
proof(rule ballI,rule ballI)
  fix a assume [ty]: "a be RealXREAL-0M1"
  fix x assume [ty]: "x be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
  let ?n = "lenFINSEQ-1K4 x"
  have "x be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    using rvsum_1_lm_2 sorry
  then obtain z where 
    [ty]:"z be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of ?n -tuples-onFINSEQ-2K4 REALNUMBERSK2" and zDef:"z = x"
    using finseq_2_th_92 sorry
  have "lenFINSEQ-1K4 (a *RVSUM-1K13\<^bsub>(lenFINSEQ-1K4 x)\<^esub> z) =XBOOLE-0R4 ?n"
    using card_1_def_7 sorry
  thus "lenFINSEQ-1K4 (a *RVSUM-1K12 x) =XBOOLE-0R4 lenFINSEQ-1K4 x"
     sorry
qed "sorry"

mtheorem rvsum_1_th_118:
" for x be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for y be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for z be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 x =XBOOLE-0R4 lenFINSEQ-1K4 y & lenFINSEQ-1K4 y =XBOOLE-0R4 lenFINSEQ-1K4 z implies mltRVSUM-1K18(x +RVSUM-1K5 y,z) =FINSEQ-1R1 mltRVSUM-1K18(x,z) +RVSUM-1K5 mltRVSUM-1K18(y,z)"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix x assume [ty]: "x be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
  fix y assume [ty]: "y be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
  fix z assume [ty]: "z be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
  have A1: "(x be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 & y be FinSequenceFINSEQ-1M3-of REALNUMBERSK2) & z be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    using rvsum_1_lm_2 sorry
  assume "lenFINSEQ-1K4 x =XBOOLE-0R4 lenFINSEQ-1K4 y & lenFINSEQ-1K4 y =XBOOLE-0R4 lenFINSEQ-1K4 z"
  then obtain x2 y2 z2 where 
    [ty]:"x2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of (lenFINSEQ-1K4 x)-tuples-onFINSEQ-2K4 REALNUMBERSK2" and x2Def:"x2 = x" and
    [ty]:"y2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of (lenFINSEQ-1K4 x)-tuples-onFINSEQ-2K4 REALNUMBERSK2" and y2Def:"y2 = y" and
    [ty]:"z2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of (lenFINSEQ-1K4 x)-tuples-onFINSEQ-2K4 REALNUMBERSK2" and z2Def:"z2 = z"
    using A1 finseq_2_th_92 sorry
  have A2: "domFINSEQ-1K5 (mltRVSUM-1K18(x +RVSUM-1K5 y,z)) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 (mltRVSUM-1K19\<^bsub>(lenFINSEQ-1K4 x)\<^esub>(x2 +RVSUM-1K6\<^bsub>(lenFINSEQ-1K4 x)\<^esub> y2,z2)))"
    using finseq_1_def_3 sorry
  also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 x)"
    using card_1_def_7 sorry
  also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 (mltRVSUM-1K19\<^bsub>(lenFINSEQ-1K4 x)\<^esub>(x2,z2) +RVSUM-1K6\<^bsub>(lenFINSEQ-1K4 x)\<^esub> mltRVSUM-1K19\<^bsub>(lenFINSEQ-1K4 x)\<^esub>(y2,z2)))"
    using card_1_def_7 sorry
  also have "... = domFINSEQ-1K5 (mltRVSUM-1K19\<^bsub>(lenFINSEQ-1K4 x)\<^esub>(x2,z2) +RVSUM-1K6\<^bsub>(lenFINSEQ-1K4 x)\<^esub> mltRVSUM-1K19\<^bsub>(lenFINSEQ-1K4 x)\<^esub>(y2,z2))"
    using finseq_1_def_3 sorry
  finally have "domFINSEQ-1K5 (mltRVSUM-1K18(x +RVSUM-1K5 y,z)) =HIDDENR1 domFINSEQ-1K5 (mltRVSUM-1K19\<^bsub>(lenFINSEQ-1K4 x)\<^esub>(x2,z2) +RVSUM-1K6\<^bsub>(lenFINSEQ-1K4 x)\<^esub> mltRVSUM-1K19\<^bsub>(lenFINSEQ-1K4 x)\<^esub>(y2,z2))"
     sorry
  have A3: "domFINSEQ-1K5 (mltRVSUM-1K18(x,z)) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 (mltRVSUM-1K19\<^bsub>(lenFINSEQ-1K4 x)\<^esub>(x2,z2)))"
    using finseq_1_def_3 sorry
  also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 x)"
    using card_1_def_7 sorry
  also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 (mltRVSUM-1K19\<^bsub>(lenFINSEQ-1K4 x)\<^esub>(x2,z2) +RVSUM-1K6\<^bsub>(lenFINSEQ-1K4 x)\<^esub> mltRVSUM-1K19\<^bsub>(lenFINSEQ-1K4 x)\<^esub>(y2,z2)))"
    using card_1_def_7 sorry
  also have "... = domFINSEQ-1K5 (mltRVSUM-1K19\<^bsub>(lenFINSEQ-1K4 x)\<^esub>(x2,z2) +RVSUM-1K6\<^bsub>(lenFINSEQ-1K4 x)\<^esub> mltRVSUM-1K19\<^bsub>(lenFINSEQ-1K4 x)\<^esub>(y2,z2))"
    using finseq_1_def_3 sorry
  finally have "domFINSEQ-1K5 (mltRVSUM-1K18(x,z)) =HIDDENR1 domFINSEQ-1K5 (mltRVSUM-1K19\<^bsub>(lenFINSEQ-1K4 x)\<^esub>(x2,z2) +RVSUM-1K6\<^bsub>(lenFINSEQ-1K4 x)\<^esub> mltRVSUM-1K19\<^bsub>(lenFINSEQ-1K4 x)\<^esub>(y2,z2))"
     sorry
  have " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 (mltRVSUM-1K18(x +RVSUM-1K5 y,z)) implies mltRVSUM-1K18(x +RVSUM-1K5 y,z) .FUNCT-1K1 i =XBOOLE-0R4 (mltRVSUM-1K18(x,z) +RVSUM-1K5 mltRVSUM-1K18(y,z)).FUNCT-1K1 i"
  proof-
    have " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 (mltRVSUM-1K18(x +RVSUM-1K5 y,z)) implies mltRVSUM-1K18(x +RVSUM-1K5 y,z) .FUNCT-1K1 i =HIDDENR1 (mltRVSUM-1K18(x,z) +RVSUM-1K5 mltRVSUM-1K18(y,z)).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be NatNAT-1M1"
      assume A4: "i inTARSKIR2 domFINSEQ-1K5 (mltRVSUM-1K18(x +RVSUM-1K5 y,z))"
      let ?a = "x .FUNCT-1K1 i"
      let ?b = "y .FUNCT-1K1 i"
      let ?d = "(x +RVSUM-1K5 y).FUNCT-1K1 i"
      let ?e = "z .FUNCT-1K1 i"
      have "lenFINSEQ-1K4 (x2 +RVSUM-1K6\<^bsub>(lenFINSEQ-1K4 x)\<^esub> y2) =XBOOLE-0R4 lenFINSEQ-1K4 x"
        using card_1_def_7 sorry
      then have "domFINSEQ-1K5 (x2 +RVSUM-1K6\<^bsub>(lenFINSEQ-1K4 x)\<^esub> y2) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 x)"
        using finseq_1_def_3 sorry
      also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 (mltRVSUM-1K19\<^bsub>(lenFINSEQ-1K4 x)\<^esub>(x2,z2)))"
        using card_1_def_7 sorry
      also have "... = domFINSEQ-1K5 (mltRVSUM-1K18(x,z))"
        using finseq_1_def_3 sorry
      finally have "domFINSEQ-1K5 (x2 +RVSUM-1K6\<^bsub>(lenFINSEQ-1K4 x)\<^esub> y2) =HIDDENR1 domFINSEQ-1K5 (mltRVSUM-1K18(x,z))"
         sorry
      then have A5: "?d =XBOOLE-0R4 ?a +XCMPLX-0K2 ?b"
        using A2 A3 A4 valued_1_def_1 sorry
      have "mltRVSUM-1K18(x +RVSUM-1K5 y,z) .FUNCT-1K1 i =HIDDENR1 (x +RVSUM-1K5 y).FUNCT-1K1 i *XCMPLX-0K3 z .FUNCT-1K1 i"
        using valued_1_th_5 sorry
      also have "... = x .FUNCT-1K1 i *XCMPLX-0K3 z .FUNCT-1K1 i +XCMPLX-0K2 y .FUNCT-1K1 i *XCMPLX-0K3 z .FUNCT-1K1 i"
        using A5 sorry
      also have "... = mltRVSUM-1K18(x,z) .FUNCT-1K1 i +XCMPLX-0K2 y .FUNCT-1K1 i *XCMPLX-0K3 z .FUNCT-1K1 i"
        using valued_1_th_5 sorry
      also have "... = mltRVSUM-1K18(x,z) .FUNCT-1K1 i +XCMPLX-0K2 mltRVSUM-1K18(y,z) .FUNCT-1K1 i"
        using valued_1_th_5 sorry
      also have "... = (mltRVSUM-1K18(x,z) +RVSUM-1K5 mltRVSUM-1K18(y,z)).FUNCT-1K1 i"
        using A2 A4 valued_1_def_1 sorry
      finally show "mltRVSUM-1K18(x +RVSUM-1K5 y,z) .FUNCT-1K1 i =HIDDENR1 (mltRVSUM-1K18(x,z) +RVSUM-1K5 mltRVSUM-1K18(y,z)).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus "mltRVSUM-1K18(x +RVSUM-1K5 y,z) =FINSEQ-1R1 mltRVSUM-1K18(x,z) +RVSUM-1K5 mltRVSUM-1K18(y,z)"
    using A2 finseq_1_th_13 sorry
qed "sorry"

(*begin*)
mdef rvsum_1_def_16 (" |'(RVSUM-1K26 _ , _ ')|" [0,0]164 ) where
  mlet "x1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1", "x2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
"func  |(RVSUM-1K26 x1,x2 )| \<rightarrow> RealXREAL-0M1 equals
  SumRVSUM-1K22 (mltRVSUM-1K18(x1,x2))"
proof-
  (*coherence*)
    show "SumRVSUM-1K22 (mltRVSUM-1K18(x1,x2)) be RealXREAL-0M1"
       sorry
qed "sorry"

mtheorem RVSUM_1K26_commutativity:
" for x1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for x2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  |(RVSUM-1K26 x1,x2 )| =HIDDENR1  |(RVSUM-1K26 x2,x1 )|"
proof-
  have " for it be RealXREAL-0M1 holds  for x1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for x2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds it =HIDDENR1  |(RVSUM-1K26 x1,x2 )| implies it =HIDDENR1  |(RVSUM-1K26 x2,x1 )|"
  proof-
    have " for it be RealXREAL-0M1 holds  for x1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for x2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds it =HIDDENR1 SumRVSUM-1K22 (mltRVSUM-1K18(x1,x2)) implies it =HIDDENR1 SumRVSUM-1K22 (mltRVSUM-1K18(x2,x1))"
       sorry
    thus " ?thesis "
      using rvsum_1_def_16 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_119:
" for x be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  |(RVSUM-1K26 x,x )| >=XXREAL-0R2 0NUMBERSK6"
proof(rule ballI)
  fix x assume [ty]: "x be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
  let ?n = "lenFINSEQ-1K4 x"
  have "x be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    using rvsum_1_lm_2 sorry
  then obtain w where 
    [ty]:"w be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of ?n -tuples-onFINSEQ-2K4 REALNUMBERSK2" and wDef:"w = x"
    using finseq_2_th_92 sorry
  have " |(RVSUM-1K26 x,x )| =HIDDENR1 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(lenFINSEQ-1K4 x)\<^esub> w)"
     sorry
  thus " |(RVSUM-1K26 x,x )| >=XXREAL-0R2 0NUMBERSK6"
    using rvsum_1_th_86 sorry
qed "sorry"

mtheorem rvsum_1_th_120:
" for x be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for y be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for z be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 x =XBOOLE-0R4 lenFINSEQ-1K4 y & lenFINSEQ-1K4 y =XBOOLE-0R4 lenFINSEQ-1K4 z implies  |(RVSUM-1K26 x +RVSUM-1K5 y,z )| =HIDDENR1  |(RVSUM-1K26 x,z )| +XCMPLX-0K2  |(RVSUM-1K26 y,z )|"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix x assume [ty]: "x be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
  fix y assume [ty]: "y be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
  fix z assume [ty]: "z be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
  have A1: "(x be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 & y be FinSequenceFINSEQ-1M3-of REALNUMBERSK2) & z be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    using rvsum_1_lm_2 sorry
  assume A2: "lenFINSEQ-1K4 x =XBOOLE-0R4 lenFINSEQ-1K4 y & lenFINSEQ-1K4 y =XBOOLE-0R4 lenFINSEQ-1K4 z"
  then obtain x2 y2 z2 where 
    [ty]:"x2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of (lenFINSEQ-1K4 x)-tuples-onFINSEQ-2K4 REALNUMBERSK2" and x2Def:"x2 = x" and
    [ty]:"y2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of (lenFINSEQ-1K4 x)-tuples-onFINSEQ-2K4 REALNUMBERSK2" and y2Def:"y2 = y" and
    [ty]:"z2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of (lenFINSEQ-1K4 x)-tuples-onFINSEQ-2K4 REALNUMBERSK2" and z2Def:"z2 = z"
    using A1 finseq_2_th_92 sorry
  have " |(RVSUM-1K26 x +RVSUM-1K5 y,z )| =HIDDENR1 SumRVSUM-1K22 (mltRVSUM-1K18(x,z) +RVSUM-1K5 mltRVSUM-1K18(y,z))"
    using A2 rvsum_1_th_118 sorry
  also have "... = SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(lenFINSEQ-1K4 x)\<^esub>(x2,z2)) +XCMPLX-0K2 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(lenFINSEQ-1K4 x)\<^esub>(y2,z2))"
    using rvsum_1_th_89 sorry
  also have "... =  |(RVSUM-1K26 x,z )| +XCMPLX-0K2  |(RVSUM-1K26 y,z )|"
     sorry
  finally have " |(RVSUM-1K26 x +RVSUM-1K5 y,z )| =HIDDENR1  |(RVSUM-1K26 x,z )| +XCMPLX-0K2  |(RVSUM-1K26 y,z )|"
     sorry
  thus " |(RVSUM-1K26 x +RVSUM-1K5 y,z )| =HIDDENR1  |(RVSUM-1K26 x,z )| +XCMPLX-0K2  |(RVSUM-1K26 y,z )|"
     sorry
qed "sorry"

mtheorem rvsum_1_th_121:
" for x be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for y be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for a be RealXREAL-0M1 holds lenFINSEQ-1K4 x =XBOOLE-0R4 lenFINSEQ-1K4 y implies  |(RVSUM-1K26 a *RVSUM-1K12 x,y )| =HIDDENR1 a *XCMPLX-0K3 ( |(RVSUM-1K26 x,y )|)"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix x assume [ty]: "x be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
  fix y assume [ty]: "y be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
  fix a assume [ty]: "a be RealXREAL-0M1"
  obtain a2 where 
    [ty]:"a2 be ElementSUBSET-1M1-of REALNUMBERSK2" and a2Def:"a2 = a"
    using xreal_0_def_1 sorry
  have A1: "x be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 & y be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    using rvsum_1_lm_2 sorry
  assume "lenFINSEQ-1K4 x =XBOOLE-0R4 lenFINSEQ-1K4 y"
  then obtain x2 y2 where 
    [ty]:"x2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of (lenFINSEQ-1K4 x)-tuples-onFINSEQ-2K4 REALNUMBERSK2" and x2Def:"x2 = x" and
    [ty]:"y2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of (lenFINSEQ-1K4 x)-tuples-onFINSEQ-2K4 REALNUMBERSK2" and y2Def:"y2 = y"
    using A1 finseq_2_th_92 sorry
  have " |(RVSUM-1K26 a *RVSUM-1K12 x,y )| =HIDDENR1 SumRVSUM-1K22 (a2 *RVSUM-1K13\<^bsub>(lenFINSEQ-1K4 x)\<^esub> mltRVSUM-1K19\<^bsub>(lenFINSEQ-1K4 x)\<^esub>(x2,y2))"
    using finseqop_th_26 sorry
  also have "... = a *XCMPLX-0K3 ( |(RVSUM-1K26 x,y )|)"
    using rvsum_1_th_87 sorry
  finally have " |(RVSUM-1K26 a *RVSUM-1K12 x,y )| =HIDDENR1 a *XCMPLX-0K3 ( |(RVSUM-1K26 x,y )|)"
     sorry
  thus " |(RVSUM-1K26 a *RVSUM-1K12 x,y )| =HIDDENR1 a *XCMPLX-0K3 ( |(RVSUM-1K26 x,y )|)"
     sorry
qed "sorry"

mtheorem rvsum_1_th_122:
" for x1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for x2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 x1 =XBOOLE-0R4 lenFINSEQ-1K4 x2 implies  |(RVSUM-1K26 -RVSUM-1K7 x1,x2 )| =HIDDENR1 -XCMPLX-0K4  |(RVSUM-1K26 x1,x2 )|"
proof(rule ballI,rule ballI,rule impI)
  fix x1 assume [ty]: "x1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
  fix x2 assume [ty]: "x2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
  assume "lenFINSEQ-1K4 x1 =XBOOLE-0R4 lenFINSEQ-1K4 x2"
  then have " |(RVSUM-1K26 -RVSUM-1K7 x1,x2 )| =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 ( |(RVSUM-1K26 x1,x2 )|)"
    using rvsum_1_th_121 sorry
  thus " |(RVSUM-1K26 -RVSUM-1K7 x1,x2 )| =HIDDENR1 -XCMPLX-0K4  |(RVSUM-1K26 x1,x2 )|"
     sorry
qed "sorry"

mtheorem rvsum_1_th_123:
" for x1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for x2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 x1 =XBOOLE-0R4 lenFINSEQ-1K4 x2 implies  |(RVSUM-1K26 -RVSUM-1K7 x1,-RVSUM-1K7 x2 )| =HIDDENR1  |(RVSUM-1K26 x1,x2 )|"
proof(rule ballI,rule ballI,rule impI)
  fix x1 assume [ty]: "x1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
  fix x2 assume [ty]: "x2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
  assume A1: "lenFINSEQ-1K4 x1 =XBOOLE-0R4 lenFINSEQ-1K4 x2"
  then have "lenFINSEQ-1K4 (-RVSUM-1K7 x2) =XBOOLE-0R4 lenFINSEQ-1K4 x1"
    using rvsum_1_th_114 sorry
  then have " |(RVSUM-1K26 -RVSUM-1K7 x1,-RVSUM-1K7 x2 )| =HIDDENR1 -XCMPLX-0K4  |(RVSUM-1K26 x1,-RVSUM-1K7 x2 )|"
    using rvsum_1_th_122 sorry
  also have "... = -XCMPLX-0K4 (-XCMPLX-0K4  |(RVSUM-1K26 x1,x2 )|)"
    using A1 rvsum_1_th_122 sorry
  finally have " |(RVSUM-1K26 -RVSUM-1K7 x1,-RVSUM-1K7 x2 )| =HIDDENR1 -XCMPLX-0K4 (-XCMPLX-0K4  |(RVSUM-1K26 x1,x2 )|)"
     sorry
  thus " |(RVSUM-1K26 -RVSUM-1K7 x1,-RVSUM-1K7 x2 )| =HIDDENR1  |(RVSUM-1K26 x1,x2 )|"
     sorry
qed "sorry"

mtheorem rvsum_1_th_124:
" for x1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for x2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for x3 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 x1 =XBOOLE-0R4 lenFINSEQ-1K4 x2 & lenFINSEQ-1K4 x2 =XBOOLE-0R4 lenFINSEQ-1K4 x3 implies  |(RVSUM-1K26 x1 -RVSUM-1K9 x2,x3 )| =HIDDENR1  |(RVSUM-1K26 x1,x3 )| -XCMPLX-0K6  |(RVSUM-1K26 x2,x3 )|"
proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix x1 assume [ty]: "x1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
  fix x2 assume [ty]: "x2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
  fix x3 assume [ty]: "x3 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
  assume A1: "lenFINSEQ-1K4 x1 =XBOOLE-0R4 lenFINSEQ-1K4 x2"
    and A2: "lenFINSEQ-1K4 x2 =XBOOLE-0R4 lenFINSEQ-1K4 x3"
  have "lenFINSEQ-1K4 (-RVSUM-1K7 x2) =XBOOLE-0R4 lenFINSEQ-1K4 x2"
    using rvsum_1_th_114 sorry
  then have " |(RVSUM-1K26 x1 -RVSUM-1K9 x2,x3 )| =HIDDENR1  |(RVSUM-1K26 x1,x3 )| +XCMPLX-0K2  |(RVSUM-1K26 -RVSUM-1K7 x2,x3 )|"
    using A1 A2 rvsum_1_th_120 sorry
  also have "... =  |(RVSUM-1K26 x1,x3 )| +XCMPLX-0K2 (-XCMPLX-0K4  |(RVSUM-1K26 x2,x3 )|)"
    using A2 rvsum_1_th_122 sorry
  finally have " |(RVSUM-1K26 x1 -RVSUM-1K9 x2,x3 )| =HIDDENR1  |(RVSUM-1K26 x1,x3 )| +XCMPLX-0K2 (-XCMPLX-0K4  |(RVSUM-1K26 x2,x3 )|)"
     sorry
  thus " |(RVSUM-1K26 x1 -RVSUM-1K9 x2,x3 )| =HIDDENR1  |(RVSUM-1K26 x1,x3 )| -XCMPLX-0K6  |(RVSUM-1K26 x2,x3 )|"
     sorry
qed "sorry"

mtheorem rvsum_1_th_125:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for x1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for x2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for x3 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 x1 =XBOOLE-0R4 lenFINSEQ-1K4 x2 & lenFINSEQ-1K4 x2 =XBOOLE-0R4 lenFINSEQ-1K4 x3 implies  |(RVSUM-1K26 x *RVSUM-1K12 x1 +RVSUM-1K5 y *RVSUM-1K12 x2,x3 )| =HIDDENR1 x *XCMPLX-0K3 ( |(RVSUM-1K26 x1,x3 )|) +XCMPLX-0K2 y *XCMPLX-0K3 ( |(RVSUM-1K26 x2,x3 )|)"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix x assume [ty]: "x be RealXREAL-0M1"
  fix y assume [ty]: "y be RealXREAL-0M1"
  fix x1 assume [ty]: "x1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
  fix x2 assume [ty]: "x2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
  fix x3 assume [ty]: "x3 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
  assume A1: "lenFINSEQ-1K4 x1 =XBOOLE-0R4 lenFINSEQ-1K4 x2"
    and A2: "lenFINSEQ-1K4 x2 =XBOOLE-0R4 lenFINSEQ-1K4 x3"
  have "lenFINSEQ-1K4 (x *RVSUM-1K12 x1) =XBOOLE-0R4 lenFINSEQ-1K4 x1 & lenFINSEQ-1K4 (y *RVSUM-1K12 x2) =XBOOLE-0R4 lenFINSEQ-1K4 x2"
    using rvsum_1_th_117 sorry
  then have " |(RVSUM-1K26 x *RVSUM-1K12 x1 +RVSUM-1K5 y *RVSUM-1K12 x2,x3 )| =HIDDENR1  |(RVSUM-1K26 x *RVSUM-1K12 x1,x3 )| +XCMPLX-0K2  |(RVSUM-1K26 y *RVSUM-1K12 x2,x3 )|"
    using A1 A2 rvsum_1_th_120 sorry
  also have "... = x *XCMPLX-0K3 ( |(RVSUM-1K26 x1,x3 )|) +XCMPLX-0K2  |(RVSUM-1K26 y *RVSUM-1K12 x2,x3 )|"
    using A1 A2 rvsum_1_th_121 sorry
  also have "... = x *XCMPLX-0K3 ( |(RVSUM-1K26 x1,x3 )|) +XCMPLX-0K2 y *XCMPLX-0K3 ( |(RVSUM-1K26 x2,x3 )|)"
    using A2 rvsum_1_th_121 sorry
  finally have " |(RVSUM-1K26 x *RVSUM-1K12 x1 +RVSUM-1K5 y *RVSUM-1K12 x2,x3 )| =HIDDENR1 x *XCMPLX-0K3 ( |(RVSUM-1K26 x1,x3 )|) +XCMPLX-0K2 y *XCMPLX-0K3 ( |(RVSUM-1K26 x2,x3 )|)"
     sorry
  thus " |(RVSUM-1K26 x *RVSUM-1K12 x1 +RVSUM-1K5 y *RVSUM-1K12 x2,x3 )| =HIDDENR1 x *XCMPLX-0K3 ( |(RVSUM-1K26 x1,x3 )|) +XCMPLX-0K2 y *XCMPLX-0K3 ( |(RVSUM-1K26 x2,x3 )|)"
     sorry
qed "sorry"

mtheorem rvsum_1_th_126:
" for x1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for x2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for y1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for y2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds (lenFINSEQ-1K4 x1 =XBOOLE-0R4 lenFINSEQ-1K4 x2 & lenFINSEQ-1K4 x2 =XBOOLE-0R4 lenFINSEQ-1K4 y1) & lenFINSEQ-1K4 y1 =XBOOLE-0R4 lenFINSEQ-1K4 y2 implies  |(RVSUM-1K26 x1 +RVSUM-1K5 x2,y1 +RVSUM-1K5 y2 )| =HIDDENR1 (( |(RVSUM-1K26 x1,y1 )| +XCMPLX-0K2  |(RVSUM-1K26 x1,y2 )|)+XCMPLX-0K2  |(RVSUM-1K26 x2,y1 )|)+XCMPLX-0K2  |(RVSUM-1K26 x2,y2 )|"
proof-
  have " for x1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for x2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for y1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for y2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 x1 =XBOOLE-0R4 lenFINSEQ-1K4 x2 & (lenFINSEQ-1K4 x2 =XBOOLE-0R4 lenFINSEQ-1K4 y1 & lenFINSEQ-1K4 y1 =XBOOLE-0R4 lenFINSEQ-1K4 y2) implies  |(RVSUM-1K26 x1 +RVSUM-1K5 x2,y1 +RVSUM-1K5 y2 )| =HIDDENR1 (( |(RVSUM-1K26 x1,y1 )| +XCMPLX-0K2  |(RVSUM-1K26 x1,y2 )|)+XCMPLX-0K2  |(RVSUM-1K26 x2,y1 )|)+XCMPLX-0K2  |(RVSUM-1K26 x2,y2 )|"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x1 assume [ty]: "x1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    fix x2 assume [ty]: "x2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    fix y1 assume [ty]: "y1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    fix y2 assume [ty]: "y2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    assume A1: "lenFINSEQ-1K4 x1 =XBOOLE-0R4 lenFINSEQ-1K4 x2"
      and A2: "lenFINSEQ-1K4 x2 =XBOOLE-0R4 lenFINSEQ-1K4 y1"
      and A3: "lenFINSEQ-1K4 y1 =XBOOLE-0R4 lenFINSEQ-1K4 y2"
    have " |(RVSUM-1K26 x1 +RVSUM-1K5 x2,y2 )| =HIDDENR1  |(RVSUM-1K26 x1,y2 )| +XCMPLX-0K2  |(RVSUM-1K26 x2,y2 )|"
      using A1 A2 A3 rvsum_1_th_120 sorry
    then have A4: " |(RVSUM-1K26 x1 +RVSUM-1K5 x2,y1 )| +XCMPLX-0K2  |(RVSUM-1K26 x1 +RVSUM-1K5 x2,y2 )| =XBOOLE-0R4 ( |(RVSUM-1K26 x1,y1 )| +XCMPLX-0K2  |(RVSUM-1K26 x2,y1 )|)+XCMPLX-0K2 ( |(RVSUM-1K26 x1,y2 )| +XCMPLX-0K2  |(RVSUM-1K26 x2,y2 )|)"
      using A1 A2 rvsum_1_th_120 sorry
    have "lenFINSEQ-1K4 (x1 +RVSUM-1K5 x2) =XBOOLE-0R4 lenFINSEQ-1K4 x1"
      using A1 rvsum_1_th_115 sorry
    thus " |(RVSUM-1K26 x1 +RVSUM-1K5 x2,y1 +RVSUM-1K5 y2 )| =HIDDENR1 (( |(RVSUM-1K26 x1,y1 )| +XCMPLX-0K2  |(RVSUM-1K26 x1,y2 )|)+XCMPLX-0K2  |(RVSUM-1K26 x2,y1 )|)+XCMPLX-0K2  |(RVSUM-1K26 x2,y2 )|"
      using A1 A2 A3 A4 rvsum_1_th_120 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_127:
" for x1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for x2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for y1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for y2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds (lenFINSEQ-1K4 x1 =XBOOLE-0R4 lenFINSEQ-1K4 x2 & lenFINSEQ-1K4 x2 =XBOOLE-0R4 lenFINSEQ-1K4 y1) & lenFINSEQ-1K4 y1 =XBOOLE-0R4 lenFINSEQ-1K4 y2 implies  |(RVSUM-1K26 x1 -RVSUM-1K9 x2,y1 -RVSUM-1K9 y2 )| =HIDDENR1 (( |(RVSUM-1K26 x1,y1 )| -XCMPLX-0K6  |(RVSUM-1K26 x1,y2 )|)-XCMPLX-0K6  |(RVSUM-1K26 x2,y1 )|)+XCMPLX-0K2  |(RVSUM-1K26 x2,y2 )|"
proof-
  have " for x1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for x2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for y1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for y2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 x1 =XBOOLE-0R4 lenFINSEQ-1K4 x2 & (lenFINSEQ-1K4 x2 =XBOOLE-0R4 lenFINSEQ-1K4 y1 & lenFINSEQ-1K4 y1 =XBOOLE-0R4 lenFINSEQ-1K4 y2) implies  |(RVSUM-1K26 x1 -RVSUM-1K9 x2,y1 -RVSUM-1K9 y2 )| =HIDDENR1 (( |(RVSUM-1K26 x1,y1 )| -XCMPLX-0K6  |(RVSUM-1K26 x1,y2 )|)-XCMPLX-0K6  |(RVSUM-1K26 x2,y1 )|)+XCMPLX-0K2  |(RVSUM-1K26 x2,y2 )|"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x1 assume [ty]: "x1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    fix x2 assume [ty]: "x2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    fix y1 assume [ty]: "y1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    fix y2 assume [ty]: "y2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    assume A1: "lenFINSEQ-1K4 x1 =XBOOLE-0R4 lenFINSEQ-1K4 x2"
      and A2: "lenFINSEQ-1K4 x2 =XBOOLE-0R4 lenFINSEQ-1K4 y1"
      and A3: "lenFINSEQ-1K4 y1 =XBOOLE-0R4 lenFINSEQ-1K4 y2"
    have " |(RVSUM-1K26 x1,y1 -RVSUM-1K9 y2 )| =HIDDENR1  |(RVSUM-1K26 x1,y1 )| -XCMPLX-0K6  |(RVSUM-1K26 x1,y2 )|"
      using A1 A2 A3 rvsum_1_th_124 sorry
    then have A4: " |(RVSUM-1K26 x1,y1 -RVSUM-1K9 y2 )| -XCMPLX-0K6  |(RVSUM-1K26 x2,y1 -RVSUM-1K9 y2 )| =XBOOLE-0R4 ( |(RVSUM-1K26 x1,y1 )| -XCMPLX-0K6  |(RVSUM-1K26 x1,y2 )|)-XCMPLX-0K6 ( |(RVSUM-1K26 x2,y1 )| -XCMPLX-0K6  |(RVSUM-1K26 x2,y2 )|)"
      using A2 A3 rvsum_1_th_124 sorry
    have "lenFINSEQ-1K4 (y1 -RVSUM-1K9 y2) =XBOOLE-0R4 lenFINSEQ-1K4 y1"
      using A3 rvsum_1_th_116 sorry
    thus " |(RVSUM-1K26 x1 -RVSUM-1K9 x2,y1 -RVSUM-1K9 y2 )| =HIDDENR1 (( |(RVSUM-1K26 x1,y1 )| -XCMPLX-0K6  |(RVSUM-1K26 x1,y2 )|)-XCMPLX-0K6  |(RVSUM-1K26 x2,y1 )|)+XCMPLX-0K2  |(RVSUM-1K26 x2,y2 )|"
      using A1 A2 A4 rvsum_1_th_124 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_128:
" for x be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for y be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 x =XBOOLE-0R4 lenFINSEQ-1K4 y implies  |(RVSUM-1K26 x +RVSUM-1K5 y,x +RVSUM-1K5 y )| =HIDDENR1 ( |(RVSUM-1K26 x,x )| +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 ( |(RVSUM-1K26 x,y )|))+XCMPLX-0K2  |(RVSUM-1K26 y,y )|"
proof(rule ballI,rule ballI,rule impI)
  fix x assume [ty]: "x be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
  fix y assume [ty]: "y be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
  have A1: "( |(RVSUM-1K26 x,x )| +XCMPLX-0K2  |(RVSUM-1K26 x,y )|)+XCMPLX-0K2  |(RVSUM-1K26 x,y )| =XBOOLE-0R4  |(RVSUM-1K26 x,x )| +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 ( |(RVSUM-1K26 x,y )|)"
     sorry
  assume "lenFINSEQ-1K4 x =XBOOLE-0R4 lenFINSEQ-1K4 y"
  thus " |(RVSUM-1K26 x +RVSUM-1K5 y,x +RVSUM-1K5 y )| =HIDDENR1 ( |(RVSUM-1K26 x,x )| +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 ( |(RVSUM-1K26 x,y )|))+XCMPLX-0K2  |(RVSUM-1K26 y,y )|"
    using A1 rvsum_1_th_126 sorry
qed "sorry"

mtheorem rvsum_1_th_129:
" for x be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for y be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 x =XBOOLE-0R4 lenFINSEQ-1K4 y implies  |(RVSUM-1K26 x -RVSUM-1K9 y,x -RVSUM-1K9 y )| =HIDDENR1 ( |(RVSUM-1K26 x,x )| -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 ( |(RVSUM-1K26 x,y )|))+XCMPLX-0K2  |(RVSUM-1K26 y,y )|"
proof(rule ballI,rule ballI,rule impI)
  fix x assume [ty]: "x be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
  fix y assume [ty]: "y be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
  assume "lenFINSEQ-1K4 x =XBOOLE-0R4 lenFINSEQ-1K4 y"
  then have " |(RVSUM-1K26 x -RVSUM-1K9 y,x -RVSUM-1K9 y )| =HIDDENR1 (( |(RVSUM-1K26 x,x )| -XCMPLX-0K6  |(RVSUM-1K26 x,y )|)-XCMPLX-0K6  |(RVSUM-1K26 y,x )|)+XCMPLX-0K2  |(RVSUM-1K26 y,y )|"
    using rvsum_1_th_127 sorry
  also have "... = ( |(RVSUM-1K26 x,x )| -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 ( |(RVSUM-1K26 x,y )|))+XCMPLX-0K2  |(RVSUM-1K26 y,y )|"
     sorry
  finally have " |(RVSUM-1K26 x -RVSUM-1K9 y,x -RVSUM-1K9 y )| =HIDDENR1 ( |(RVSUM-1K26 x,x )| -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 ( |(RVSUM-1K26 x,y )|))+XCMPLX-0K2  |(RVSUM-1K26 y,y )|"
     sorry
  thus " |(RVSUM-1K26 x -RVSUM-1K9 y,x -RVSUM-1K9 y )| =HIDDENR1 ( |(RVSUM-1K26 x,x )| -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 ( |(RVSUM-1K26 x,y )|))+XCMPLX-0K2  |(RVSUM-1K26 y,y )|"
     sorry
qed "sorry"

mtheorem rvsum_1_th_130:
" for n be NatNAT-1M1 holds  for p1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for p2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for p3 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  |(RVSUM-1K26 p1 +RVSUM-1K6\<^bsub>(n)\<^esub> p2,p3 )| =HIDDENR1  |(RVSUM-1K26 p1,p3 )| +XCMPLX-0K2  |(RVSUM-1K26 p2,p3 )|"
proof-
  have " for n be NatNAT-1M1 holds  for p1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for p2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for p3 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  |(RVSUM-1K26 p1 +RVSUM-1K6\<^bsub>(n)\<^esub> p2,p3 )| =HIDDENR1  |(RVSUM-1K26 p1,p3 )| +XCMPLX-0K2  |(RVSUM-1K26 p2,p3 )|"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p1 assume [ty]: "p1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    fix p2 assume [ty]: "p2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    fix p3 assume [ty]: "p3 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    obtain f1 f2 f3 where 
      [ty]:"f1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1" and f1Def:"f1 = p1" and
      [ty]:"f2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1" and f2Def:"f2 = p2" and
      [ty]:"f3 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1" and f3Def:"f3 = p3"
       sorry
    have "lenFINSEQ-1K4 f2 =XBOOLE-0R4 n"
      using card_1_def_7 sorry
    then have "lenFINSEQ-1K4 f1 =XBOOLE-0R4 lenFINSEQ-1K4 f2 & lenFINSEQ-1K4 f2 =XBOOLE-0R4 lenFINSEQ-1K4 f3"
      using card_1_def_7 sorry
    thus " |(RVSUM-1K26 p1 +RVSUM-1K6\<^bsub>(n)\<^esub> p2,p3 )| =HIDDENR1  |(RVSUM-1K26 p1,p3 )| +XCMPLX-0K2  |(RVSUM-1K26 p2,p3 )|"
      using rvsum_1_th_120 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_131:
" for n be NatNAT-1M1 holds  for p1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for p2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for x be RealXREAL-0M1 holds  |(RVSUM-1K26 x *RVSUM-1K13\<^bsub>(n)\<^esub> p1,p2 )| =HIDDENR1 x *XCMPLX-0K3 ( |(RVSUM-1K26 p1,p2 )|)"
proof-
  have " for n be NatNAT-1M1 holds  for p1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for p2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for x be RealXREAL-0M1 holds  |(RVSUM-1K26 x *RVSUM-1K13\<^bsub>(n)\<^esub> p1,p2 )| =HIDDENR1 x *XCMPLX-0K3 ( |(RVSUM-1K26 p1,p2 )|)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p1 assume [ty]: "p1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    fix p2 assume [ty]: "p2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    fix x assume [ty]: "x be RealXREAL-0M1"
    obtain f1 f2 where 
      [ty]:"f1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1" and f1Def:"f1 = p1" and
      [ty]:"f2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1" and f2Def:"f2 = p2"
       sorry
    have "lenFINSEQ-1K4 f1 =XBOOLE-0R4 n & lenFINSEQ-1K4 f2 =XBOOLE-0R4 n"
      using card_1_def_7 sorry
    thus " |(RVSUM-1K26 x *RVSUM-1K13\<^bsub>(n)\<^esub> p1,p2 )| =HIDDENR1 x *XCMPLX-0K3 ( |(RVSUM-1K26 p1,p2 )|)"
      using rvsum_1_th_121 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_132:
" for n be NatNAT-1M1 holds  for p1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for p2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  |(RVSUM-1K26 -RVSUM-1K8\<^bsub>(n)\<^esub> p1,p2 )| =HIDDENR1 -XCMPLX-0K4  |(RVSUM-1K26 p1,p2 )|"
proof-
  have " for n be NatNAT-1M1 holds  for p1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for p2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  |(RVSUM-1K26 -RVSUM-1K8\<^bsub>(n)\<^esub> p1,p2 )| =HIDDENR1 -XCMPLX-0K4  |(RVSUM-1K26 p1,p2 )|"
  proof(rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p1 assume [ty]: "p1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    fix p2 assume [ty]: "p2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    have " |(RVSUM-1K26 -RVSUM-1K8\<^bsub>(n)\<^esub> p1,p2 )| =HIDDENR1  |(RVSUM-1K26 (-XCMPLX-0K4 \<one>\<^sub>M)*RVSUM-1K13\<^bsub>(n)\<^esub> p1,p2 )|"
       sorry
    also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 ( |(RVSUM-1K26 p1,p2 )|)"
      using rvsum_1_th_131 sorry
    finally have " |(RVSUM-1K26 -RVSUM-1K8\<^bsub>(n)\<^esub> p1,p2 )| =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 ( |(RVSUM-1K26 p1,p2 )|)"
       sorry
    thus " |(RVSUM-1K26 -RVSUM-1K8\<^bsub>(n)\<^esub> p1,p2 )| =HIDDENR1 -XCMPLX-0K4  |(RVSUM-1K26 p1,p2 )|"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_133:
" for n be NatNAT-1M1 holds  for p1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for p2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  |(RVSUM-1K26 -RVSUM-1K8\<^bsub>(n)\<^esub> p1,-RVSUM-1K8\<^bsub>(n)\<^esub> p2 )| =HIDDENR1  |(RVSUM-1K26 p1,p2 )|"
proof-
  have " for n be NatNAT-1M1 holds  for p1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for p2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  |(RVSUM-1K26 -RVSUM-1K8\<^bsub>(n)\<^esub> p1,-RVSUM-1K8\<^bsub>(n)\<^esub> p2 )| =HIDDENR1  |(RVSUM-1K26 p1,p2 )|"
  proof(rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p1 assume [ty]: "p1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    fix p2 assume [ty]: "p2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    have " |(RVSUM-1K26 -RVSUM-1K8\<^bsub>(n)\<^esub> p1,-RVSUM-1K8\<^bsub>(n)\<^esub> p2 )| =HIDDENR1 -XCMPLX-0K4  |(RVSUM-1K26 p1,-RVSUM-1K8\<^bsub>(n)\<^esub> p2 )|"
      using rvsum_1_th_132 sorry
    also have "... = -XCMPLX-0K4 (-XCMPLX-0K4  |(RVSUM-1K26 p1,p2 )|)"
      using rvsum_1_th_132 sorry
    finally have " |(RVSUM-1K26 -RVSUM-1K8\<^bsub>(n)\<^esub> p1,-RVSUM-1K8\<^bsub>(n)\<^esub> p2 )| =HIDDENR1 -XCMPLX-0K4 (-XCMPLX-0K4  |(RVSUM-1K26 p1,p2 )|)"
       sorry
    thus " |(RVSUM-1K26 -RVSUM-1K8\<^bsub>(n)\<^esub> p1,-RVSUM-1K8\<^bsub>(n)\<^esub> p2 )| =HIDDENR1  |(RVSUM-1K26 p1,p2 )|"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_134:
" for n be NatNAT-1M1 holds  for p1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for p2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for p3 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  |(RVSUM-1K26 p1 -RVSUM-1K10\<^bsub>(n)\<^esub> p2,p3 )| =HIDDENR1  |(RVSUM-1K26 p1,p3 )| -XCMPLX-0K6  |(RVSUM-1K26 p2,p3 )|"
proof-
  have " for n be NatNAT-1M1 holds  for p1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for p2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for p3 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  |(RVSUM-1K26 p1 -RVSUM-1K10\<^bsub>(n)\<^esub> p2,p3 )| =HIDDENR1  |(RVSUM-1K26 p1,p3 )| -XCMPLX-0K6  |(RVSUM-1K26 p2,p3 )|"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p1 assume [ty]: "p1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    fix p2 assume [ty]: "p2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    fix p3 assume [ty]: "p3 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    have " |(RVSUM-1K26 p1 -RVSUM-1K10\<^bsub>(n)\<^esub> p2,p3 )| =HIDDENR1  |(RVSUM-1K26 p1,p3 )| +XCMPLX-0K2  |(RVSUM-1K26 -RVSUM-1K8\<^bsub>(n)\<^esub> p2,p3 )|"
      using rvsum_1_th_130 sorry
    also have "... =  |(RVSUM-1K26 p1,p3 )| +XCMPLX-0K2 (-XCMPLX-0K4  |(RVSUM-1K26 p2,p3 )|)"
      using rvsum_1_th_132 sorry
    finally have " |(RVSUM-1K26 p1 -RVSUM-1K10\<^bsub>(n)\<^esub> p2,p3 )| =HIDDENR1  |(RVSUM-1K26 p1,p3 )| +XCMPLX-0K2 (-XCMPLX-0K4  |(RVSUM-1K26 p2,p3 )|)"
       sorry
    thus " |(RVSUM-1K26 p1 -RVSUM-1K10\<^bsub>(n)\<^esub> p2,p3 )| =HIDDENR1  |(RVSUM-1K26 p1,p3 )| -XCMPLX-0K6  |(RVSUM-1K26 p2,p3 )|"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_135:
" for n be NatNAT-1M1 holds  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for p1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for p2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for p3 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  |(RVSUM-1K26 x *RVSUM-1K13\<^bsub>(n)\<^esub> p1 +RVSUM-1K6\<^bsub>(n)\<^esub> y *RVSUM-1K13\<^bsub>(n)\<^esub> p2,p3 )| =HIDDENR1 x *XCMPLX-0K3 ( |(RVSUM-1K26 p1,p3 )|) +XCMPLX-0K2 y *XCMPLX-0K3 ( |(RVSUM-1K26 p2,p3 )|)"
proof-
  have " for n be NatNAT-1M1 holds  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for p1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for p2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for p3 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  |(RVSUM-1K26 x *RVSUM-1K13\<^bsub>(n)\<^esub> p1 +RVSUM-1K6\<^bsub>(n)\<^esub> y *RVSUM-1K13\<^bsub>(n)\<^esub> p2,p3 )| =HIDDENR1 x *XCMPLX-0K3 ( |(RVSUM-1K26 p1,p3 )|) +XCMPLX-0K2 y *XCMPLX-0K3 ( |(RVSUM-1K26 p2,p3 )|)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    fix p1 assume [ty]: "p1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    fix p2 assume [ty]: "p2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    fix p3 assume [ty]: "p3 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    have " |(RVSUM-1K26 x *RVSUM-1K13\<^bsub>(n)\<^esub> p1 +RVSUM-1K6\<^bsub>(n)\<^esub> y *RVSUM-1K13\<^bsub>(n)\<^esub> p2,p3 )| =HIDDENR1  |(RVSUM-1K26 x *RVSUM-1K13\<^bsub>(n)\<^esub> p1,p3 )| +XCMPLX-0K2  |(RVSUM-1K26 y *RVSUM-1K13\<^bsub>(n)\<^esub> p2,p3 )|"
      using rvsum_1_th_130 sorry
    also have "... = x *XCMPLX-0K3 ( |(RVSUM-1K26 p1,p3 )|) +XCMPLX-0K2  |(RVSUM-1K26 y *RVSUM-1K13\<^bsub>(n)\<^esub> p2,p3 )|"
      using rvsum_1_th_131 sorry
    also have "... = x *XCMPLX-0K3 ( |(RVSUM-1K26 p1,p3 )|) +XCMPLX-0K2 y *XCMPLX-0K3 ( |(RVSUM-1K26 p2,p3 )|)"
      using rvsum_1_th_131 sorry
    finally have " |(RVSUM-1K26 x *RVSUM-1K13\<^bsub>(n)\<^esub> p1 +RVSUM-1K6\<^bsub>(n)\<^esub> y *RVSUM-1K13\<^bsub>(n)\<^esub> p2,p3 )| =HIDDENR1 x *XCMPLX-0K3 ( |(RVSUM-1K26 p1,p3 )|) +XCMPLX-0K2 y *XCMPLX-0K3 ( |(RVSUM-1K26 p2,p3 )|)"
       sorry
    thus " |(RVSUM-1K26 x *RVSUM-1K13\<^bsub>(n)\<^esub> p1 +RVSUM-1K6\<^bsub>(n)\<^esub> y *RVSUM-1K13\<^bsub>(n)\<^esub> p2,p3 )| =HIDDENR1 x *XCMPLX-0K3 ( |(RVSUM-1K26 p1,p3 )|) +XCMPLX-0K2 y *XCMPLX-0K3 ( |(RVSUM-1K26 p2,p3 )|)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_136:
" for n be NatNAT-1M1 holds  for p1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for p2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for q1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for q2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  |(RVSUM-1K26 p1 +RVSUM-1K6\<^bsub>(n)\<^esub> p2,q1 +RVSUM-1K6\<^bsub>(n)\<^esub> q2 )| =HIDDENR1 (( |(RVSUM-1K26 p1,q1 )| +XCMPLX-0K2  |(RVSUM-1K26 p1,q2 )|)+XCMPLX-0K2  |(RVSUM-1K26 p2,q1 )|)+XCMPLX-0K2  |(RVSUM-1K26 p2,q2 )|"
proof-
  have " for n be NatNAT-1M1 holds  for p1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for p2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for q1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for q2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  |(RVSUM-1K26 p1 +RVSUM-1K6\<^bsub>(n)\<^esub> p2,q1 +RVSUM-1K6\<^bsub>(n)\<^esub> q2 )| =HIDDENR1 (( |(RVSUM-1K26 p1,q1 )| +XCMPLX-0K2  |(RVSUM-1K26 p1,q2 )|)+XCMPLX-0K2  |(RVSUM-1K26 p2,q1 )|)+XCMPLX-0K2  |(RVSUM-1K26 p2,q2 )|"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p1 assume [ty]: "p1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    fix p2 assume [ty]: "p2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    fix q1 assume [ty]: "q1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    fix q2 assume [ty]: "q2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    have A1: " |(RVSUM-1K26 p1 +RVSUM-1K6\<^bsub>(n)\<^esub> p2,q1 )| =HIDDENR1  |(RVSUM-1K26 p1,q1 )| +XCMPLX-0K2  |(RVSUM-1K26 p2,q1 )| &  |(RVSUM-1K26 p1 +RVSUM-1K6\<^bsub>(n)\<^esub> p2,q2 )| =HIDDENR1  |(RVSUM-1K26 p1,q2 )| +XCMPLX-0K2  |(RVSUM-1K26 p2,q2 )|"
      using rvsum_1_th_130 sorry
    have " |(RVSUM-1K26 p1 +RVSUM-1K6\<^bsub>(n)\<^esub> p2,q1 +RVSUM-1K6\<^bsub>(n)\<^esub> q2 )| =HIDDENR1  |(RVSUM-1K26 p1 +RVSUM-1K6\<^bsub>(n)\<^esub> p2,q1 )| +XCMPLX-0K2  |(RVSUM-1K26 p1 +RVSUM-1K6\<^bsub>(n)\<^esub> p2,q2 )|"
      using rvsum_1_th_130 sorry
    also have "... = (( |(RVSUM-1K26 p1,q1 )| +XCMPLX-0K2  |(RVSUM-1K26 p1,q2 )|)+XCMPLX-0K2  |(RVSUM-1K26 p2,q1 )|)+XCMPLX-0K2  |(RVSUM-1K26 p2,q2 )|"
      using A1 sorry
    finally have " |(RVSUM-1K26 p1 +RVSUM-1K6\<^bsub>(n)\<^esub> p2,q1 +RVSUM-1K6\<^bsub>(n)\<^esub> q2 )| =HIDDENR1 (( |(RVSUM-1K26 p1,q1 )| +XCMPLX-0K2  |(RVSUM-1K26 p1,q2 )|)+XCMPLX-0K2  |(RVSUM-1K26 p2,q1 )|)+XCMPLX-0K2  |(RVSUM-1K26 p2,q2 )|"
       sorry
    thus " |(RVSUM-1K26 p1 +RVSUM-1K6\<^bsub>(n)\<^esub> p2,q1 +RVSUM-1K6\<^bsub>(n)\<^esub> q2 )| =HIDDENR1 (( |(RVSUM-1K26 p1,q1 )| +XCMPLX-0K2  |(RVSUM-1K26 p1,q2 )|)+XCMPLX-0K2  |(RVSUM-1K26 p2,q1 )|)+XCMPLX-0K2  |(RVSUM-1K26 p2,q2 )|"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_137:
" for n be NatNAT-1M1 holds  for p1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for p2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for q1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for q2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  |(RVSUM-1K26 p1 -RVSUM-1K10\<^bsub>(n)\<^esub> p2,q1 -RVSUM-1K10\<^bsub>(n)\<^esub> q2 )| =HIDDENR1 (( |(RVSUM-1K26 p1,q1 )| -XCMPLX-0K6  |(RVSUM-1K26 p1,q2 )|)-XCMPLX-0K6  |(RVSUM-1K26 p2,q1 )|)+XCMPLX-0K2  |(RVSUM-1K26 p2,q2 )|"
proof-
  have " for n be NatNAT-1M1 holds  for p1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for p2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for q1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for q2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  |(RVSUM-1K26 p1 -RVSUM-1K10\<^bsub>(n)\<^esub> p2,q1 -RVSUM-1K10\<^bsub>(n)\<^esub> q2 )| =HIDDENR1 (( |(RVSUM-1K26 p1,q1 )| -XCMPLX-0K6  |(RVSUM-1K26 p1,q2 )|)-XCMPLX-0K6  |(RVSUM-1K26 p2,q1 )|)+XCMPLX-0K2  |(RVSUM-1K26 p2,q2 )|"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p1 assume [ty]: "p1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    fix p2 assume [ty]: "p2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    fix q1 assume [ty]: "q1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    fix q2 assume [ty]: "q2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    have A1: " |(RVSUM-1K26 p1,q1 -RVSUM-1K10\<^bsub>(n)\<^esub> q2 )| =HIDDENR1  |(RVSUM-1K26 p1,q1 )| -XCMPLX-0K6  |(RVSUM-1K26 p1,q2 )| &  |(RVSUM-1K26 p2,q1 -RVSUM-1K10\<^bsub>(n)\<^esub> q2 )| =HIDDENR1  |(RVSUM-1K26 p2,q1 )| -XCMPLX-0K6  |(RVSUM-1K26 p2,q2 )|"
      using rvsum_1_th_134 sorry
    have " |(RVSUM-1K26 p1 -RVSUM-1K10\<^bsub>(n)\<^esub> p2,q1 -RVSUM-1K10\<^bsub>(n)\<^esub> q2 )| =HIDDENR1  |(RVSUM-1K26 p1,q1 -RVSUM-1K10\<^bsub>(n)\<^esub> q2 )| -XCMPLX-0K6  |(RVSUM-1K26 p2,q1 -RVSUM-1K10\<^bsub>(n)\<^esub> q2 )|"
      using rvsum_1_th_134 sorry
    also have "... = (( |(RVSUM-1K26 p1,q1 )| -XCMPLX-0K6  |(RVSUM-1K26 p1,q2 )|)-XCMPLX-0K6  |(RVSUM-1K26 p2,q1 )|)+XCMPLX-0K2  |(RVSUM-1K26 p2,q2 )|"
      using A1 sorry
    finally have " |(RVSUM-1K26 p1 -RVSUM-1K10\<^bsub>(n)\<^esub> p2,q1 -RVSUM-1K10\<^bsub>(n)\<^esub> q2 )| =HIDDENR1 (( |(RVSUM-1K26 p1,q1 )| -XCMPLX-0K6  |(RVSUM-1K26 p1,q2 )|)-XCMPLX-0K6  |(RVSUM-1K26 p2,q1 )|)+XCMPLX-0K2  |(RVSUM-1K26 p2,q2 )|"
       sorry
    thus " |(RVSUM-1K26 p1 -RVSUM-1K10\<^bsub>(n)\<^esub> p2,q1 -RVSUM-1K10\<^bsub>(n)\<^esub> q2 )| =HIDDENR1 (( |(RVSUM-1K26 p1,q1 )| -XCMPLX-0K6  |(RVSUM-1K26 p1,q2 )|)-XCMPLX-0K6  |(RVSUM-1K26 p2,q1 )|)+XCMPLX-0K2  |(RVSUM-1K26 p2,q2 )|"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_138:
" for n be NatNAT-1M1 holds  for p be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for q be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  |(RVSUM-1K26 p +RVSUM-1K6\<^bsub>(n)\<^esub> q,p +RVSUM-1K6\<^bsub>(n)\<^esub> q )| =HIDDENR1 ( |(RVSUM-1K26 p,p )| +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 ( |(RVSUM-1K26 p,q )|))+XCMPLX-0K2  |(RVSUM-1K26 q,q )|"
proof-
  have " for n be NatNAT-1M1 holds  for p be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for q be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  |(RVSUM-1K26 p +RVSUM-1K6\<^bsub>(n)\<^esub> q,p +RVSUM-1K6\<^bsub>(n)\<^esub> q )| =HIDDENR1 ( |(RVSUM-1K26 p,p )| +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 ( |(RVSUM-1K26 p,q )|))+XCMPLX-0K2  |(RVSUM-1K26 q,q )|"
  proof(rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p assume [ty]: "p be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    fix q assume [ty]: "q be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    have "( |(RVSUM-1K26 p,p )| +XCMPLX-0K2  |(RVSUM-1K26 p,q )|)+XCMPLX-0K2  |(RVSUM-1K26 p,q )| =XBOOLE-0R4  |(RVSUM-1K26 p,p )| +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 ( |(RVSUM-1K26 p,q )|)"
       sorry
    thus " |(RVSUM-1K26 p +RVSUM-1K6\<^bsub>(n)\<^esub> q,p +RVSUM-1K6\<^bsub>(n)\<^esub> q )| =HIDDENR1 ( |(RVSUM-1K26 p,p )| +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 ( |(RVSUM-1K26 p,q )|))+XCMPLX-0K2  |(RVSUM-1K26 q,q )|"
      using rvsum_1_th_136 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_139:
" for n be NatNAT-1M1 holds  for p be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for q be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  |(RVSUM-1K26 p -RVSUM-1K10\<^bsub>(n)\<^esub> q,p -RVSUM-1K10\<^bsub>(n)\<^esub> q )| =HIDDENR1 ( |(RVSUM-1K26 p,p )| -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 ( |(RVSUM-1K26 p,q )|))+XCMPLX-0K2  |(RVSUM-1K26 q,q )|"
proof-
  have " for n be NatNAT-1M1 holds  for p be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for q be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  |(RVSUM-1K26 p -RVSUM-1K10\<^bsub>(n)\<^esub> q,p -RVSUM-1K10\<^bsub>(n)\<^esub> q )| =HIDDENR1 ( |(RVSUM-1K26 p,p )| -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 ( |(RVSUM-1K26 p,q )|))+XCMPLX-0K2  |(RVSUM-1K26 q,q )|"
  proof(rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p assume [ty]: "p be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    fix q assume [ty]: "q be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    have " |(RVSUM-1K26 p -RVSUM-1K10\<^bsub>(n)\<^esub> q,p -RVSUM-1K10\<^bsub>(n)\<^esub> q )| =HIDDENR1 (( |(RVSUM-1K26 p,p )| -XCMPLX-0K6  |(RVSUM-1K26 p,q )|)-XCMPLX-0K6  |(RVSUM-1K26 p,q )|)+XCMPLX-0K2  |(RVSUM-1K26 q,q )|"
      using rvsum_1_th_137 sorry
    also have "... = ( |(RVSUM-1K26 p,p )| -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 ( |(RVSUM-1K26 p,q )|))+XCMPLX-0K2  |(RVSUM-1K26 q,q )|"
       sorry
    finally have " |(RVSUM-1K26 p -RVSUM-1K10\<^bsub>(n)\<^esub> q,p -RVSUM-1K10\<^bsub>(n)\<^esub> q )| =HIDDENR1 ( |(RVSUM-1K26 p,p )| -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 ( |(RVSUM-1K26 p,q )|))+XCMPLX-0K2  |(RVSUM-1K26 q,q )|"
       sorry
    thus " |(RVSUM-1K26 p -RVSUM-1K10\<^bsub>(n)\<^esub> q,p -RVSUM-1K10\<^bsub>(n)\<^esub> q )| =HIDDENR1 ( |(RVSUM-1K26 p,p )| -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 ( |(RVSUM-1K26 p,q )|))+XCMPLX-0K2  |(RVSUM-1K26 q,q )|"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_140:
" for n be NatNAT-1M1 holds  for p be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for q be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  |(RVSUM-1K26 p,q )| <=XXREAL-0R1  |(RVSUM-1K26 p,p )| +XCMPLX-0K2  |(RVSUM-1K26 q,q )|"
proof-
  have " for n be NatNAT-1M1 holds  for p be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for q be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  |(RVSUM-1K26 p,q )| <=XXREAL-0R1  |(RVSUM-1K26 p,p )| +XCMPLX-0K2  |(RVSUM-1K26 q,q )|"
  proof(rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p assume [ty]: "p be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    fix q assume [ty]: "q be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    have "0NUMBERSK6 <=XXREAL-0R1  |(RVSUM-1K26 p,p )| & 0NUMBERSK6 <=XXREAL-0R1  |(RVSUM-1K26 q,q )|"
      using rvsum_1_th_119 sorry
    then have A1: "(0NUMBERSK6)/XCMPLX-0K7 \<two>\<^sub>M <=XXREAL-0R1 ( |(RVSUM-1K26 p,p )| +XCMPLX-0K2  |(RVSUM-1K26 q,q )|)/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    have " |(RVSUM-1K26 p -RVSUM-1K10\<^bsub>(n)\<^esub> q,p -RVSUM-1K10\<^bsub>(n)\<^esub> q )| =HIDDENR1 ( |(RVSUM-1K26 p,p )| -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 ( |(RVSUM-1K26 p,q )|))+XCMPLX-0K2  |(RVSUM-1K26 q,q )|"
      using rvsum_1_th_139 sorry
    also have "... = ( |(RVSUM-1K26 p,p )| +XCMPLX-0K2  |(RVSUM-1K26 q,q )|)-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 ( |(RVSUM-1K26 p,q )|)"
       sorry
    finally have " |(RVSUM-1K26 p -RVSUM-1K10\<^bsub>(n)\<^esub> q,p -RVSUM-1K10\<^bsub>(n)\<^esub> q )| =HIDDENR1 ( |(RVSUM-1K26 p,p )| +XCMPLX-0K2  |(RVSUM-1K26 q,q )|)-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 ( |(RVSUM-1K26 p,q )|)"
       sorry
    then have "\<two>\<^sub>M *XCMPLX-0K3 ( |(RVSUM-1K26 p,q )|) <=XXREAL-0R1 ( |(RVSUM-1K26 p,p )| +XCMPLX-0K2  |(RVSUM-1K26 q,q )|)-XCMPLX-0K6 0NUMBERSK6"
      using rvsum_1_th_119 xreal_1_th_11 sorry
    then have "(\<two>\<^sub>M *XCMPLX-0K3 ( |(RVSUM-1K26 p,q )|))/XCMPLX-0K7 \<two>\<^sub>M <=XXREAL-0R1 ( |(RVSUM-1K26 p,p )| +XCMPLX-0K2  |(RVSUM-1K26 q,q )|)/XCMPLX-0K7 \<two>\<^sub>M"
      using xreal_1_th_72 sorry
    then have "0NUMBERSK6 +XCMPLX-0K2  |(RVSUM-1K26 p,q )| <=XXREAL-0R1 ( |(RVSUM-1K26 p,p )| +XCMPLX-0K2  |(RVSUM-1K26 q,q )|)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 ( |(RVSUM-1K26 p,p )| +XCMPLX-0K2  |(RVSUM-1K26 q,q )|)/XCMPLX-0K7 \<two>\<^sub>M"
      using A1 xreal_1_th_7 sorry
    thus " |(RVSUM-1K26 p,q )| <=XXREAL-0R1  |(RVSUM-1K26 p,p )| +XCMPLX-0K2  |(RVSUM-1K26 q,q )|"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef rvsum_1_def_17 ("'( _ , _ ')are-orthogonalRVSUM-1R1" [0,0]50 ) where
  mlet "p be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1", "q be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
"pred (p,q)are-orthogonalRVSUM-1R1 means
   |(RVSUM-1K26 p,q )| =HIDDENR1 0NUMBERSK6"..

mtheorem RVSUM_1R1_symmetry:
" for p be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for q be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds (p,q)are-orthogonalRVSUM-1R1 implies (q,p)are-orthogonalRVSUM-1R1"
proof-
  have " for p be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for q be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  |(RVSUM-1K26 p,q )| =HIDDENR1 0NUMBERSK6 implies  |(RVSUM-1K26 q,p )| =HIDDENR1 0NUMBERSK6"
     sorry
  thus " ?thesis "
    using rvsum_1_def_17 sorry
qed

mtheorem rvsum_1_th_141:
" for n be NatNAT-1M1 holds  for a be RealXREAL-0M1 holds  for p be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for q be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds (p,q)are-orthogonalRVSUM-1R1 implies (a *RVSUM-1K13\<^bsub>(n)\<^esub> p,q)are-orthogonalRVSUM-1R1"
proof-
  have " for n be NatNAT-1M1 holds  for a be RealXREAL-0M1 holds  for p be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for q be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds (p,q)are-orthogonalRVSUM-1R1 implies (a *RVSUM-1K13\<^bsub>(n)\<^esub> p,q)are-orthogonalRVSUM-1R1"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix p assume [ty]: "p be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    fix q assume [ty]: "q be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    assume "(p,q)are-orthogonalRVSUM-1R1"
    then have " |(RVSUM-1K26 p,q )| =HIDDENR1 0NUMBERSK6"
       sorry
    then have "a *XCMPLX-0K3 ( |(RVSUM-1K26 p,q )|) =XBOOLE-0R4 0NUMBERSK6"
       sorry
    then have " |(RVSUM-1K26 a *RVSUM-1K13\<^bsub>(n)\<^esub> p,q )| =HIDDENR1 0NUMBERSK6"
      using rvsum_1_th_131 sorry
    thus "(a *RVSUM-1K13\<^bsub>(n)\<^esub> p,q)are-orthogonalRVSUM-1R1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_142:
" for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds  for r3 be RealXREAL-0M1 holds  for r4 be RealXREAL-0M1 holds SumRVSUM-1K20 (<*FINSEQ-4K7 r1,r2,r3,r4 *>) =HIDDENR1 ((r1 +XCMPLX-0K2 r2)+XCMPLX-0K2 r3)+XCMPLX-0K2 r4"
proof-
  have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds  for r3 be RealXREAL-0M1 holds  for r4 be RealXREAL-0M1 holds SumRVSUM-1K20 (<*FINSEQ-4K7 r1,r2,r3,r4 *>) =HIDDENR1 ((r1 +XCMPLX-0K2 r2)+XCMPLX-0K2 r3)+XCMPLX-0K2 r4"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix r1 assume [ty]: "r1 be RealXREAL-0M1"
    fix r2 assume [ty]: "r2 be RealXREAL-0M1"
    fix r3 assume [ty]: "r3 be RealXREAL-0M1"
    fix r4 assume [ty]: "r4 be RealXREAL-0M1"
    have "SumRVSUM-1K20 (<*FINSEQ-4K7 r1,r2,r3,r4 *>) =HIDDENR1 SumRVSUM-1K20 (<*FINSEQ-1K12 r1,r2,r3 *>) +XCMPLX-0K2 r4"
      using rvsum_1_th_74 sorry
    also have "... = ((r1 +XCMPLX-0K2 r2)+XCMPLX-0K2 r3)+XCMPLX-0K2 r4"
      using rvsum_1_th_78 sorry
    finally show "SumRVSUM-1K20 (<*FINSEQ-4K7 r1,r2,r3,r4 *>) =HIDDENR1 ((r1 +XCMPLX-0K2 r2)+XCMPLX-0K2 r3)+XCMPLX-0K2 r4"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve f, g for "real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
mtheorem rvsum_1_th_143:
" for f be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 f =XBOOLE-0R4 lenFINSEQ-1K4 (sqrRVSUM-1K15 f) & domFINSEQ-1K5 f =XBOOLE-0R4 domFINSEQ-1K5 (sqrRVSUM-1K15 f)"
proof-
  have " for f be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 f =HIDDENR1 lenFINSEQ-1K4 (sqrRVSUM-1K15 f) & domFINSEQ-1K5 f =XBOOLE-0R4 domFINSEQ-1K5 (sqrRVSUM-1K15 f)"
  proof(rule ballI,rule conjMI)
    fix f assume [ty]: "f be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    have "rngRVSUM-1K1 f c=TARSKIR1 REALNUMBERSK2 & domRELAT-1K1 (sqrrealRVSUM-1K3) =XBOOLE-0R4 REALNUMBERSK2"
      using funct_2_def_1 sorry
    then have "lenFINSEQ-1K4 f =HIDDENR1 lenFINSEQ-1K4 (sqrrealRVSUM-1K3 *FUNCT-1K3 f)"
      using finseq_2_th_29 sorry
    also have "... = lenFINSEQ-1K4 (sqrRVSUM-1K15 f)"
       sorry
    finally show "lenFINSEQ-1K4 f =HIDDENR1 lenFINSEQ-1K4 (sqrRVSUM-1K15 f)"
       sorry
    thus "domFINSEQ-1K5 f =XBOOLE-0R4 domFINSEQ-1K5 (sqrRVSUM-1K15 f)"
      using finseq_3_th_29 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_144:
" for f be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for g be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds sqrRVSUM-1K15 (f ^FINSEQ-1K8 g) =FINSEQ-1R1 sqrRVSUM-1K15 f ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> sqrRVSUM-1K15 g"
proof-
  have " for f be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for g be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds sqrRVSUM-1K15 (f ^FINSEQ-1K8 g) =FINSEQ-1R1 sqrRVSUM-1K15 f ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> sqrRVSUM-1K15 g"
  proof(rule ballI,rule ballI)
    fix f assume [ty]: "f be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    fix g assume [ty]: "g be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
    have A1: "lenFINSEQ-1K4 f =XBOOLE-0R4 lenFINSEQ-1K4 (sqrRVSUM-1K15 f)"
      using rvsum_1_th_143 sorry
    have A2: "lenFINSEQ-1K4 (sqrRVSUM-1K15 (f ^FINSEQ-1K8 g)) =XBOOLE-0R4 lenFINSEQ-1K4 (f ^FINSEQ-1K8 g)"
      using rvsum_1_th_143 sorry
    have A3: "lenFINSEQ-1K4 g =XBOOLE-0R4 lenFINSEQ-1K4 (sqrRVSUM-1K15 g) & lenFINSEQ-1K4 (f ^FINSEQ-1K8 g) =XBOOLE-0R4 lenFINSEQ-1K4 f +NAT-1K1 lenFINSEQ-1K4 g"
      using rvsum_1_th_143 finseq_1_th_22 sorry
    have A4: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 (sqrRVSUM-1K15 (f ^FINSEQ-1K8 g)) implies sqrRVSUM-1K15 (f ^FINSEQ-1K8 g) .FUNCT-1K1 i =XBOOLE-0R4 (sqrRVSUM-1K15 f ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> sqrRVSUM-1K15 g).FUNCT-1K1 i"
    proof-
      have " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 (sqrRVSUM-1K15 (f ^FINSEQ-1K8 g)) implies sqrRVSUM-1K15 (f ^FINSEQ-1K8 g) .FUNCT-1K1 i =HIDDENR1 (sqrRVSUM-1K15 f ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> sqrRVSUM-1K15 g).FUNCT-1K1 i"
      proof(rule ballI,rule impMI ,rule impI)
        fix i assume [ty]: "i be NatNAT-1M1"
        assume A5: "\<one>\<^sub>M <=XXREAL-0R1 i"
          and A6: "i <=XXREAL-0R1 lenFINSEQ-1K4 (sqrRVSUM-1K15 (f ^FINSEQ-1K8 g))"
        have A7: "i inTARSKIR2 domFINSEQ-1K5 (f ^FINSEQ-1K8 g)"
          using A2 A5 A6 finseq_3_th_25 sorry
        show "sqrRVSUM-1K15 (f ^FINSEQ-1K8 g) .FUNCT-1K1 i =HIDDENR1 (sqrRVSUM-1K15 f ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> sqrRVSUM-1K15 g).FUNCT-1K1 i"
        proof-
          have cases: "i inTARSKIR2 domFINSEQ-1K5 f or  not i inTARSKIR2 domFINSEQ-1K5 f"
             sorry
          have case1: "i inTARSKIR2 domFINSEQ-1K5 f implies sqrRVSUM-1K15 (f ^FINSEQ-1K8 g) .FUNCT-1K1 i =HIDDENR1 (sqrRVSUM-1K15 f ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> sqrRVSUM-1K15 g).FUNCT-1K1 i"
          proof(rule impI)
            assume A8: "i inTARSKIR2 domFINSEQ-1K5 f"
            then have A9: "i inTARSKIR2 domFINSEQ-1K5 (sqrRVSUM-1K15 f)"
              using rvsum_1_th_143 sorry
            have "sqrRVSUM-1K15 (f ^FINSEQ-1K8 g) .FUNCT-1K1 i =HIDDENR1 (sqrrealRVSUM-1K3 *FUNCT-1K3 (f ^FINSEQ-1K8 g)).FUNCT-1K1 i"
               sorry
            also have "... = sqrrealRVSUM-1K3 .FUNCT-1K1 ((f ^FINSEQ-1K8 g).FUNCT-1K1 i)"
              using A7 funct_1_th_13 sorry
            also have "... = sqrrealRVSUM-1K3 .FUNCT-1K1 (f .FUNCT-1K1 i)"
              using A8 finseq_1_def_7 sorry
            also have "... = (f .FUNCT-1K1 i)^2SQUARE-1K1"
              using rvsum_1_def_2 sorry
            also have "... = sqrRVSUM-1K15 f .FUNCT-1K1 i"
              using valued_1_th_11 sorry
            also have "... = (sqrRVSUM-1K15 f ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> sqrRVSUM-1K15 g).FUNCT-1K1 i"
              using A9 finseq_1_def_7 sorry
            finally show "sqrRVSUM-1K15 (f ^FINSEQ-1K8 g) .FUNCT-1K1 i =HIDDENR1 (sqrRVSUM-1K15 f ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> sqrRVSUM-1K15 g).FUNCT-1K1 i"
               sorry
          qed
          have case2: " not i inTARSKIR2 domFINSEQ-1K5 f implies sqrRVSUM-1K15 (f ^FINSEQ-1K8 g) .FUNCT-1K1 i =HIDDENR1 (sqrRVSUM-1K15 f ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> sqrRVSUM-1K15 g).FUNCT-1K1 i"
          proof(rule impI)
            assume " not i inTARSKIR2 domFINSEQ-1K5 f"
            then have A10: "lenFINSEQ-1K4 f <XXREAL-0R3 i"
              using A5 finseq_3_th_25 sorry
            then obtain j where 
              [ty]:"j be ElementSUBSET-1M1-of NATNUMBERSK1" and jDef:"j = i -XCMPLX-0K6 lenFINSEQ-1K4 f"
              using int_1_th_5 sorry
            have A11: "i <=XXREAL-0R1 lenFINSEQ-1K4 (f ^FINSEQ-1K8 g)"
              using A6 rvsum_1_th_143 sorry
            have A12: "i <=XXREAL-0R1 lenFINSEQ-1K4 (sqrRVSUM-1K15 f ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> sqrRVSUM-1K15 g)"
              using A1 A3 A2 A6 finseq_1_th_22 sorry
            have "sqrRVSUM-1K15 (f ^FINSEQ-1K8 g) .FUNCT-1K1 i =HIDDENR1 (sqrrealRVSUM-1K3 *FUNCT-1K3 (f ^FINSEQ-1K8 g)).FUNCT-1K1 i"
               sorry
            also have "... = sqrrealRVSUM-1K3 .FUNCT-1K1 ((f ^FINSEQ-1K8 g).FUNCT-1K1 i)"
              using A7 funct_1_th_13 sorry
            also have "... = sqrrealRVSUM-1K3 .FUNCT-1K1 (g .FUNCT-1K1 j)"
              using A10 A11 finseq_1_th_24 sorry
            also have "... = (g .FUNCT-1K1 j)^2SQUARE-1K1"
              using rvsum_1_def_2 sorry
            also have "... = sqrRVSUM-1K15 g .FUNCT-1K1 j"
              using valued_1_th_11 sorry
            also have "... = (sqrRVSUM-1K15 f ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> sqrRVSUM-1K15 g).FUNCT-1K1 i"
              using A1 A10 A12 finseq_1_th_24 sorry
            finally show "sqrRVSUM-1K15 (f ^FINSEQ-1K8 g) .FUNCT-1K1 i =HIDDENR1 (sqrRVSUM-1K15 f ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> sqrRVSUM-1K15 g).FUNCT-1K1 i"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "lenFINSEQ-1K4 (sqrRVSUM-1K15 (f ^FINSEQ-1K8 g)) =XBOOLE-0R4 lenFINSEQ-1K4 (sqrRVSUM-1K15 f ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> sqrRVSUM-1K15 g)"
      using A1 A3 A2 finseq_1_th_22 sorry
    thus "sqrRVSUM-1K15 (f ^FINSEQ-1K8 g) =FINSEQ-1R1 sqrRVSUM-1K15 f ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> sqrRVSUM-1K15 g"
      using A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rvsum_1_th_145:
" for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
proof(rule ballI)
  fix F assume [ty]: "F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
  have "rngRVSUM-1K1 F c=TARSKIR1 REALNUMBERSK2"
  proof-
    show "rngRVSUM-1K1 F c=TARSKIR1 REALNUMBERSK2"
       sorry
  qed
  thus "F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    using finseq_1_def_4 sorry
qed "sorry"

mtheorem rvsum_1_th_146:
" for F be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1 holds F be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
  using rvsum_1_lm_6 sorry

mtheorem rvsum_1_cl_19:
  mlet "r be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster <*FINSEQ-1K10 r*> as-term-is natural-valuedVALUED-0V8"
proof
(*coherence*)
  show "<*FINSEQ-1K10 r*> be natural-valuedVALUED-0V8"
  proof-
    have "<*FINSEQ-1K10 r*> be natural-valuedVALUED-0V4"
    proof-
      obtain p where 
        [ty]:"p be ElementSUBSET-1M1-of NATNUMBERSK1" and pDef:"p = r"
        using ordinal1_def_12 sorry
      have "<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> p*> be FinSequence-likeFINSEQ-1V1"
         sorry
      thus "<*FINSEQ-1K10 r*> be natural-valuedVALUED-0V4"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rvsum_1_cl_20:
  mlet "r1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "r2 be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster <*FINSEQ-1K11 r1,r2 *> as-term-is natural-valuedVALUED-0V8"
proof
(*coherence*)
  show "<*FINSEQ-1K11 r1,r2 *> be natural-valuedVALUED-0V8"
  proof-
    have "<*FINSEQ-1K11 r1,r2 *> be natural-valuedVALUED-0V4"
    proof-
      obtain p1 p2 where 
        [ty]:"p1 be ElementSUBSET-1M1-of NATNUMBERSK1" and p1Def:"p1 = r1" and
        [ty]:"p2 be ElementSUBSET-1M1-of NATNUMBERSK1" and p2Def:"p2 = r2"
        using ordinal1_def_12 sorry
      have "<*FINSEQ-4K2\<^bsub>(NATNUMBERSK1)\<^esub> p1,p2 *> be FinSequence-likeFINSEQ-1V1"
         sorry
      thus "<*FINSEQ-1K11 r1,r2 *> be natural-valuedVALUED-0V4"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rvsum_1_cl_21:
  mlet "r1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "r2 be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "r3 be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster <*FINSEQ-1K12 r1,r2,r3 *> as-term-is natural-valuedVALUED-0V8"
proof
(*coherence*)
  show "<*FINSEQ-1K12 r1,r2,r3 *> be natural-valuedVALUED-0V8"
  proof-
    have "<*FINSEQ-1K12 r1,r2,r3 *> be natural-valuedVALUED-0V4"
    proof-
      obtain p1 p2 p3 where 
        [ty]:"p1 be ElementSUBSET-1M1-of NATNUMBERSK1" and p1Def:"p1 = r1" and
        [ty]:"p2 be ElementSUBSET-1M1-of NATNUMBERSK1" and p2Def:"p2 = r2" and
        [ty]:"p3 be ElementSUBSET-1M1-of NATNUMBERSK1" and p3Def:"p3 = r3"
        using ordinal1_def_12 sorry
      have "<*FINSEQ-4K3\<^bsub>(NATNUMBERSK1)\<^esub> p1,p2,p3 *> be FinSequence-likeFINSEQ-1V1"
         sorry
      thus "<*FINSEQ-1K12 r1,r2,r3 *> be natural-valuedVALUED-0V4"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rvsum_1_cl_22:
  mlet "f be natural-valuedVALUED-0V8\<bar>FinSequenceFINSEQ-1M1", "g be natural-valuedVALUED-0V8\<bar>FinSequenceFINSEQ-1M1"
"cluster f ^FINSEQ-1K8 g as-term-is natural-valuedVALUED-0V8"
proof
(*coherence*)
  show "f ^FINSEQ-1K8 g be natural-valuedVALUED-0V8"
  proof-
    have "f ^FINSEQ-1K8 g be natural-valuedVALUED-0V4"
    proof-
      have A1: "rngRVSUM-1K1 f c=TARSKIR1 NATNUMBERSK1 & rngRVSUM-1K1 g c=TARSKIR1 NATNUMBERSK1"
        using valued_0_def_6 sorry
      have "rngRVSUM-1K1 (f ^FINSEQ-1K8 g) =XBOOLE-0R4 rngRVSUM-1K1 f \\/XBOOLE-0K2 rngRVSUM-1K1 g"
        using finseq_1_th_31 sorry
      then have "rngRVSUM-1K1 (f ^FINSEQ-1K8 g) c=TARSKIR1 NATNUMBERSK1"
        using A1 xboole_1_th_8 sorry
      thus "f ^FINSEQ-1K8 g be natural-valuedVALUED-0V4"
        using valued_0_def_6 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

end
