theory real_1
  imports xreal_0
   "../mizar_extension/E_number"
begin
(*begin*)
mtheorem real_1_cl_1:
"cluster note-that realXREAL-0V1 for ElementSUBSET-1M1-of REALNUMBERSK2"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of REALNUMBERSK2 holds it be realXREAL-0V1"
     sorry
qed "sorry"

mtheorem real_1_cl_2:
"cluster positiveXXREAL-0V2 for RealXREAL-0M1"
proof
(*existence*)
  show " ex it be RealXREAL-0M1 st it be positiveXXREAL-0V2"
  proof-
    have " ex tVar1 be RealXREAL-0M1 st tVar1 be positiveXXREAL-0V2"
    proof-
      show " ex tVar1 be RealXREAL-0M1 st tVar1 be positiveXXREAL-0V2"
      proof(rule bexI[of _ "\<one>\<^sub>M /XCMPLX-0K7 \<one>\<^sub>M"])
        show "\<one>\<^sub>M /XCMPLX-0K7 \<one>\<^sub>M be positiveXXREAL-0V2"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem real_1_cl_3:
"cluster positiveXXREAL-0V2 for ElementSUBSET-1M1-of REALNUMBERSK2"
proof
(*existence*)
  show " ex it be ElementSUBSET-1M1-of REALNUMBERSK2 st it be positiveXXREAL-0V2"
  proof-
    have " ex tVar2 be ElementSUBSET-1M1-of REALNUMBERSK2 st tVar2 be positiveXXREAL-0V2"
    proof-
      obtain j where 
        [ty]:"j be ElementSUBSET-1M1-of REALNUMBERSK2" and jDef:"j = \<one>\<^sub>M"
        using numbers_th_19 sorry
      show " ex tVar2 be ElementSUBSET-1M1-of REALNUMBERSK2 st tVar2 be positiveXXREAL-0V2"
      proof(rule bexI[of _ "j"])
        show "j be positiveXXREAL-0V2"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

abbreviation(input) REAL_1K1("-REAL-1K1  _ " [132]132) where
  "-REAL-1K1 x \<equiv> -XCMPLX-0K4 x"

mtheorem real_1_add_1:
  mlet "x be ElementSUBSET-1M1-of REALNUMBERSK2"
"cluster -XCMPLX-0K4 x as-term-is ElementSUBSET-1M1-of REALNUMBERSK2"
proof
(*coherence*)
  show "-XCMPLX-0K4 x be ElementSUBSET-1M1-of REALNUMBERSK2"
    using xreal_0_def_1 sorry
qed "sorry"

abbreviation(input) REAL_1K2(" _ \<inverse>REAL-1K2" [228]228) where
  "x \<inverse>REAL-1K2 \<equiv> x \<inverse>XCMPLX-0K5"

mtheorem real_1_add_2:
  mlet "x be ElementSUBSET-1M1-of REALNUMBERSK2"
"cluster x \<inverse>XCMPLX-0K5 as-term-is ElementSUBSET-1M1-of REALNUMBERSK2"
proof
(*coherence*)
  show "x \<inverse>XCMPLX-0K5 be ElementSUBSET-1M1-of REALNUMBERSK2"
    using xreal_0_def_1 sorry
qed "sorry"

abbreviation(input) REAL_1K3(" _ +REAL-1K3  _ " [132,132]132) where
  "x +REAL-1K3 y \<equiv> x +XCMPLX-0K2 y"

mtheorem real_1_add_3:
  mlet "x be ElementSUBSET-1M1-of REALNUMBERSK2", "y be ElementSUBSET-1M1-of REALNUMBERSK2"
"cluster x +XCMPLX-0K2 y as-term-is ElementSUBSET-1M1-of REALNUMBERSK2"
proof
(*coherence*)
  show "x +XCMPLX-0K2 y be ElementSUBSET-1M1-of REALNUMBERSK2"
    using xreal_0_def_1 sorry
qed "sorry"

abbreviation(input) REAL_1K4(" _ *REAL-1K4  _ " [164,164]164) where
  "x *REAL-1K4 y \<equiv> x *XCMPLX-0K3 y"

mtheorem real_1_add_4:
  mlet "x be ElementSUBSET-1M1-of REALNUMBERSK2", "y be ElementSUBSET-1M1-of REALNUMBERSK2"
"cluster x *XCMPLX-0K3 y as-term-is ElementSUBSET-1M1-of REALNUMBERSK2"
proof
(*coherence*)
  show "x *XCMPLX-0K3 y be ElementSUBSET-1M1-of REALNUMBERSK2"
    using xreal_0_def_1 sorry
qed "sorry"

abbreviation(input) REAL_1K5(" _ -REAL-1K5  _ " [132,132]132) where
  "x -REAL-1K5 y \<equiv> x -XCMPLX-0K6 y"

mtheorem real_1_add_5:
  mlet "x be ElementSUBSET-1M1-of REALNUMBERSK2", "y be ElementSUBSET-1M1-of REALNUMBERSK2"
"cluster x -XCMPLX-0K6 y as-term-is ElementSUBSET-1M1-of REALNUMBERSK2"
proof
(*coherence*)
  show "x -XCMPLX-0K6 y be ElementSUBSET-1M1-of REALNUMBERSK2"
    using xreal_0_def_1 sorry
qed "sorry"

abbreviation(input) REAL_1K6(" _ '/REAL-1K6  _ " [164,164]164) where
  "x /REAL-1K6 y \<equiv> x /XCMPLX-0K7 y"

mtheorem real_1_add_6:
  mlet "x be ElementSUBSET-1M1-of REALNUMBERSK2", "y be ElementSUBSET-1M1-of REALNUMBERSK2"
"cluster x /XCMPLX-0K7 y as-term-is ElementSUBSET-1M1-of REALNUMBERSK2"
proof
(*coherence*)
  show "x /XCMPLX-0K7 y be ElementSUBSET-1M1-of REALNUMBERSK2"
    using xreal_0_def_1 sorry
qed "sorry"

mtheorem real_1_th_1:
"REAL+ARYTM-2K2 =XBOOLE-0R4 {r where r be RealXREAL-0M1 : 0NUMBERSK6 <=XXREAL-0R1 r }"
proof-
  let ?RP = "{r where r be RealXREAL-0M1 : 0NUMBERSK6 <=XXREAL-0R1 r }"
  have "REAL+ARYTM-2K2 c=TARSKIR1 {r where r be RealXREAL-0M1 : 0NUMBERSK6 <=XXREAL-0R1 r } & {r where r be RealXREAL-0M1 : 0NUMBERSK6 <=XXREAL-0R1 r } c=TARSKIR1 REAL+ARYTM-2K2"
  proof(rule conjMI)
    show "REAL+ARYTM-2K2 c=TARSKIR1 {r where r be RealXREAL-0M1 : 0NUMBERSK6 <=XXREAL-0R1 r }"
    proof-
      have " for e be objectHIDDENM1 holds e inHIDDENR3 REAL+ARYTM-2K2 implies e inHIDDENR3 {r where r be RealXREAL-0M1 : 0NUMBERSK6 <=XXREAL-0R1 r }"
      proof(rule ballI,rule impI)
        fix e assume [ty]: "e be objectHIDDENM1"
        assume A1: "e inHIDDENR3 REAL+ARYTM-2K2"
        then obtain r where 
          [ty]:"r be RealXREAL-0M1" and rDef:"r = e"
          using arytm_0_th_1 sorry
        obtain o s where 
          [ty]:"o be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and oDef:"o = 0NUMBERSK6" and
          [ty]:"s be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and sDef:"s = r"
          using A1 arytm_2_th_20 sorry
        have "o <='ARYTM-2R1 s"
          using arytm_1_th_6 sorry
        then have "0NUMBERSK6 <=XXREAL-0R1 r"
          using arytm_2_th_20 xxreal_0_def_5 sorry
        thus "e inHIDDENR3 {r where r be RealXREAL-0M1 : 0NUMBERSK6 <=XXREAL-0R1 r }"
           sorry
      qed "sorry"
      thus "REAL+ARYTM-2K2 c=TARSKIR1 {r where r be RealXREAL-0M1 : 0NUMBERSK6 <=XXREAL-0R1 r }"
        using tarski_def_3 sorry
    qed
    have " for e be objectHIDDENM1 holds e inHIDDENR3 {r where r be RealXREAL-0M1 : 0NUMBERSK6 <=XXREAL-0R1 r } implies e inHIDDENR3 REAL+ARYTM-2K2"
    proof(rule ballI,rule impI)
      fix e assume [ty]: "e be objectHIDDENM1"
      assume "e inHIDDENR3 ?RP"
      then have A2: " ex r be RealXREAL-0M1 st e =HIDDENR1 r & 0NUMBERSK6 <=XXREAL-0R1 r"
         sorry
      have " not 0NUMBERSK6 inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
        using arytm_0_th_5 arytm_2_th_20 xboole_0_th_3 sorry
      thus "e inHIDDENR3 REAL+ARYTM-2K2"
        using A2 xxreal_0_def_5 sorry
    qed "sorry"
    thus "{r where r be RealXREAL-0M1 : 0NUMBERSK6 <=XXREAL-0R1 r } c=TARSKIR1 REAL+ARYTM-2K2"
      using tarski_def_3 sorry
  qed
  thus "REAL+ARYTM-2K2 =XBOOLE-0R4 {r where r be RealXREAL-0M1 : 0NUMBERSK6 <=XXREAL-0R1 r }"
    using xboole_0_def_10 sorry
qed

end
