theory extreal1
  imports rfunct_3 measure6 finseq_5 binarith arytm_2
   "../mizar_extension/E_number"
begin
(*begin*)
abbreviation(input) EXTREAL1K1(" _ *EXTREAL1K1  _ " [164,164]164) where
  "x *EXTREAL1K1 y \<equiv> x *XXREAL-3K4 y"

mtheorem extreal1_add_1:
  mlet "x be R-ealSUPINF-1M1", "y be R-ealSUPINF-1M1"
"cluster x *XXREAL-3K4 y as-term-is R-ealSUPINF-1M1"
proof
(*coherence*)
  show "x *XXREAL-3K4 y be R-ealSUPINF-1M1"
    using xxreal_0_def_1 sorry
qed "sorry"

mtheorem extreal1_th_1:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds x =HIDDENR1 a & y =HIDDENR1 b implies x *XXREAL-3K4 y =HIDDENR1 a *XCMPLX-0K3 b"
  using xxreal_3_def_5 sorry

abbreviation(input) EXTREAL1K2(" _ '/EXTREAL1K2  _ " [164,164]164) where
  "x /EXTREAL1K2 y \<equiv> x /XXREAL-3K6 y"

mtheorem extreal1_add_2:
  mlet "x be ExtRealXXREAL-0M1", "y be ExtRealXXREAL-0M1"
"cluster x /XXREAL-3K6 y as-term-is R-ealSUPINF-1M1"
proof
(*coherence*)
  show "x /XXREAL-3K6 y be R-ealSUPINF-1M1"
    using xxreal_0_def_1 sorry
qed "sorry"

mtheorem extreal1_th_2:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds x =HIDDENR1 a & y =HIDDENR1 b implies x /EXTREAL1K2 y =XBOOLE-0R4 a /EXTREAL1K2 b"
   sorry

mdef extreal1_def_1 (" |.EXTREAL1K3  _ .|" [0]164 ) where
  mlet "x be ExtRealXXREAL-0M1"
"func  |.EXTREAL1K3 x.| \<rightarrow> R-ealSUPINF-1M1 equals
  x if 0NUMBERSK6 <=XXREAL-3R1 x otherwise -XXREAL-3K2 x"
proof-
  (*coherence*)
    show "(0NUMBERSK6 <=XXREAL-3R1 x implies x be R-ealSUPINF-1M1) & ( not 0NUMBERSK6 <=XXREAL-3R1 x implies -XXREAL-3K2 x be R-ealSUPINF-1M1)"
      using xxreal_0_def_1 sorry
  (*consistency*)
    show " for it be R-ealSUPINF-1M1 holds  True "
       sorry
qed "sorry"

mtheorem EXTREAL1K3_projectivity:
" for x be ExtRealXXREAL-0M1 holds  |.EXTREAL1K3  |.EXTREAL1K3 x.| .| =HIDDENR1  |.EXTREAL1K3 x.|"
proof-
  have " for it be R-ealSUPINF-1M1 holds  for x be ExtRealXXREAL-0M1 holds it =HIDDENR1  |.EXTREAL1K3 x.| implies it =HIDDENR1  |.EXTREAL1K3 it.|"
  proof-
    have " for it be R-ealSUPINF-1M1 holds  for x be ExtRealXXREAL-0M1 holds (0NUMBERSK6 <=XXREAL-3R1 x implies it =HIDDENR1 x) & ( not 0NUMBERSK6 <=XXREAL-3R1 x implies it =HIDDENR1 -XXREAL-3K2 x) implies (0NUMBERSK6 <=XXREAL-3R1 it implies it =HIDDENR1 it) & ( not 0NUMBERSK6 <=XXREAL-3R1 it implies it =HIDDENR1 -XXREAL-3K2 it)"
       sorry
    thus " ?thesis "
      using extreal1_def_1 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem extreal1_ident_1:
  mlet "x be RealXREAL-0M1", "a be ComplexXCMPLX-0M1"
"identify  |.EXTREAL1K3 x.| with  |.COMPLEX1K10 a.| when x =HIDDENR1 a"
proof
(*compatibility*)
  show "x =HIDDENR1 a implies  |.EXTREAL1K3 x.| =HIDDENR1  |.COMPLEX1K10 a.|"
  proof-
    have "x =COMPLEX1R1 a implies  |.EXTREAL1K3 x.| =HIDDENR1  |.COMPLEX1K10 a.|"
    proof(rule impI)
      assume A1: "x =COMPLEX1R1 a"
      show " |.EXTREAL1K3 x.| =HIDDENR1  |.COMPLEX1K10 a.|"
      proof-
        have cases: "0NUMBERSK6 <=XXREAL-3R1 x or 0NUMBERSK6 >XXREAL-0R4 x"
           sorry
        have case1: "0NUMBERSK6 <=XXREAL-3R1 x implies  |.EXTREAL1K3 x.| =HIDDENR1  |.COMPLEX1K10 a.|"
        proof(rule impI)
          assume A2: "0NUMBERSK6 <=XXREAL-3R1 x"
          then have " |.EXTREAL1K3 x.| =HIDDENR1 a"
            using A1 extreal1_def_1 sorry
          also have "... =  |.COMPLEX1K10 a.|"
            using A2 A1 absvalue_def_1 sorry
          finally show " |.EXTREAL1K3 x.| =HIDDENR1  |.COMPLEX1K10 a.|"
             sorry
        qed
        have case2: "0NUMBERSK6 >XXREAL-0R4 x implies  |.EXTREAL1K3 x.| =HIDDENR1  |.COMPLEX1K10 a.|"
        proof(rule impI)
          assume A3: "0NUMBERSK6 >XXREAL-0R4 x"
          then have " |.EXTREAL1K3 x.| =HIDDENR1 -XXREAL-3K2 x"
            using extreal1_def_1 sorry
          also have "... = -XCMPLX-0K4 a"
            using A1 sorry
          also have "... =  |.COMPLEX1K10 a.|"
            using A3 A1 absvalue_def_1 sorry
          finally show " |.EXTREAL1K3 x.| =HIDDENR1  |.COMPLEX1K10 a.|"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem extreal1_th_3:
" for x be R-ealSUPINF-1M1 holds 0NUMBERSK6 <=XXREAL-3R1 x implies  |.EXTREAL1K3 x.| =XBOOLE-0R4 x"
  using extreal1_def_1 sorry

mtheorem extreal1_th_4:
" for x be R-ealSUPINF-1M1 holds x <XXREAL-0R3 0NUMBERSK6 implies  |.EXTREAL1K3 x.| =XBOOLE-0R4 -SUPINF-2K3 x"
  using extreal1_def_1 sorry

mtheorem extreal1_cl_1:
  mlet "x be R-ealSUPINF-1M1"
"cluster  |.EXTREAL1K3 x.| as-term-is  non negativeXXREAL-0V3"
proof
(*coherence*)
  show " |.EXTREAL1K3 x.| be  non negativeXXREAL-0V3"
  proof-
    have " not  |.EXTREAL1K3 x.| be negativeXXREAL-0V3"
    proof-
      show " not  |.EXTREAL1K3 x.| be negativeXXREAL-0V3"
      proof-
        have cases: "0NUMBERSK6 <=XXREAL-3R1 x or x <XXREAL-0R3 0NUMBERSK6"
           sorry
        have case1: "0NUMBERSK6 <=XXREAL-3R1 x implies  not  |.EXTREAL1K3 x.| be negativeXXREAL-0V3"
        proof(rule impI)
          assume A1: "0NUMBERSK6 <=XXREAL-3R1 x"
          then have " |.EXTREAL1K3 x.| =XBOOLE-0R4 x"
            using extreal1_def_1 sorry
          thus " not  |.EXTREAL1K3 x.| be negativeXXREAL-0V3"
            using A1 sorry
        qed
        have case2: "x <XXREAL-0R3 0NUMBERSK6 implies  not  |.EXTREAL1K3 x.| be negativeXXREAL-0V3"
        proof(rule impI)
          assume A2: "x <XXREAL-0R3 0NUMBERSK6"
          then have " |.EXTREAL1K3 x.| =XBOOLE-0R4 -SUPINF-2K3 x"
            using extreal1_def_1 sorry
          thus " not  |.EXTREAL1K3 x.| be negativeXXREAL-0V3"
            using A2 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

(*\$CT 2*)
(*begin*)
mdef extreal1_def_2 ("SumEXTREAL1K4  _ " [260]260 ) where
  mlet "F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3"
"func SumEXTREAL1K4 F \<rightarrow> R-ealSUPINF-1M1 means
  \<lambda>it.  ex f be sequenceNAT-1M2-of ExtREALXXREAL-0K3 st (it =XBOOLE-0R4 f .SUPINF-2K15 lenFINSEQ-1K4 F & f .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 0.SUPINF-2K2) & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 F implies f .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .SUPINF-2K15 i +SUPINF-2K4 F .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M))"
proof-
  (*existence*)
    show " ex it be R-ealSUPINF-1M1 st  ex f be sequenceNAT-1M2-of ExtREALXXREAL-0K3 st (it =XBOOLE-0R4 f .SUPINF-2K15 lenFINSEQ-1K4 F & f .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 0.SUPINF-2K2) & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 F implies f .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .SUPINF-2K15 i +SUPINF-2K4 F .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M))"
    proof-
      have " ex FF be ElementSUBSET-1M1-of ExtREALNUMBERSK7 st  not ( for f be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds  not ((FF =XBOOLE-0R4 f .SUPINF-2K15 lenFINSEQ-1K4 F & f .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 0.SUPINF-2K2) & ( for i be NatNAT-1M1 holds  not ( not i <XXREAL-0R3 lenFINSEQ-1K4 F &  not f .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .SUPINF-2K15 i +SUPINF-2K4 F .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M)))))"
      proof-
        let ?P = "\<lambda>Lamb1.  ex f be sequenceNAT-1M2-of ExtREALXXREAL-0K3 st f .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 0.SUPINF-2K2 & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i <XXREAL-0R3 lenFINSEQ-1K4 Lamb1 implies f .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .SUPINF-2K15 i +SUPINF-2K4 Lamb1 .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M))"
        have A1: " for F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  for x be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 holds ?P(F) implies ?P(F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>))"
        proof-
          have " for F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  for x be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 holds ( ex f be sequenceNAT-1M2-of ExtREALXXREAL-0K3 st f .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 0.SUPINF-2K2 & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i <XXREAL-0R3 lenFINSEQ-1K4 F implies f .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .SUPINF-2K15 i +SUPINF-2K4 F .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M))) implies ( ex f be sequenceNAT-1M2-of ExtREALXXREAL-0K3 st f .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 0.SUPINF-2K2 & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i <XXREAL-0R3 lenFINSEQ-1K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)) implies f .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .SUPINF-2K15 i +SUPINF-2K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)).SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M)))"
          proof(rule ballI,rule ballI,rule impI)
            fix F assume [ty]: "F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3"
            fix x assume [ty]: "x be ElementSUBSET-1M1-of ExtREALXXREAL-0K3"
            assume "?P(F)"
            then obtain f where
              [ty]:"f be sequenceNAT-1M2-of ExtREALXXREAL-0K3" and 
              A2: "f .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 0.SUPINF-2K2"and A3: " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i <XXREAL-0R3 lenFINSEQ-1K4 F implies f .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .SUPINF-2K15 i +SUPINF-2K4 F .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M)"
               sorry
            let ?R = "\<lambda>Lamb1. \<lambda>Lamb2. (Lamb1 <=XXREAL-3R1 lenFINSEQ-1K4 F implies Lamb2 =XBOOLE-0R4 f .SUPINF-2K15 Lamb1) & (Lamb1 =COMPLEX1R1 lenFINSEQ-1K4 F +NAT-1K1 \<one>\<^sub>M implies Lamb2 =XBOOLE-0R4 f .SUPINF-2K15 lenFINSEQ-1K4 F +SUPINF-2K4 x)"
            have A4: " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex g be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st ?R(i,g)"
            proof-
              have " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex tVar1 be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st (i <=XXREAL-3R1 lenFINSEQ-1K4 F implies tVar1 =XBOOLE-0R4 tVar1) & (i =COMPLEX1R1 lenFINSEQ-1K4 F +NAT-1K1 \<one>\<^sub>M implies tVar1 =XBOOLE-0R4 f .SUPINF-2K15 lenFINSEQ-1K4 F +SUPINF-2K4 x)"
              proof(rule ballI)
                fix i assume [ty]: "i be ElementSUBSET-1M1-of NATNUMBERSK1"
                show " ex tVar1 be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st (i <=XXREAL-3R1 lenFINSEQ-1K4 F implies tVar1 =XBOOLE-0R4 tVar1) & (i =COMPLEX1R1 lenFINSEQ-1K4 F +NAT-1K1 \<one>\<^sub>M implies tVar1 =XBOOLE-0R4 f .SUPINF-2K15 lenFINSEQ-1K4 F +SUPINF-2K4 x)"
                proof-
                  have cases: "i <>HIDDENR2 lenFINSEQ-1K4 F +NAT-1K1 \<one>\<^sub>M or i =COMPLEX1R1 lenFINSEQ-1K4 F +NAT-1K1 \<one>\<^sub>M"
                     sorry
                  have case1: "i <>HIDDENR2 lenFINSEQ-1K4 F +NAT-1K1 \<one>\<^sub>M implies ( ex tVar1 be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st (i <=XXREAL-3R1 lenFINSEQ-1K4 F implies tVar1 =XBOOLE-0R4 tVar1) & (i =COMPLEX1R1 lenFINSEQ-1K4 F +NAT-1K1 \<one>\<^sub>M implies tVar1 =XBOOLE-0R4 f .SUPINF-2K15 lenFINSEQ-1K4 F +SUPINF-2K4 x))"
                  proof(rule impI)
                    assume A5: "i <>HIDDENR2 lenFINSEQ-1K4 F +NAT-1K1 \<one>\<^sub>M"
                    show " ex tVar1 be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st (i <=XXREAL-3R1 lenFINSEQ-1K4 F implies tVar1 =XBOOLE-0R4 tVar1) & (i =COMPLEX1R1 lenFINSEQ-1K4 F +NAT-1K1 \<one>\<^sub>M implies tVar1 =XBOOLE-0R4 f .SUPINF-2K15 lenFINSEQ-1K4 F +SUPINF-2K4 x)"
                    proof(rule bexI[of _ "f .SUPINF-2K15 i"])
                      show "(i <=XXREAL-3R1 lenFINSEQ-1K4 F implies f .SUPINF-2K15 i =XBOOLE-0R4 f .SUPINF-2K15 i) & (i =COMPLEX1R1 lenFINSEQ-1K4 F +NAT-1K1 \<one>\<^sub>M implies f .SUPINF-2K15 i =XBOOLE-0R4 f .SUPINF-2K15 lenFINSEQ-1K4 F +SUPINF-2K4 x)"
                        using A5 sorry
                    qed "sorry"
                  qed
                  have case2: "i =COMPLEX1R1 lenFINSEQ-1K4 F +NAT-1K1 \<one>\<^sub>M implies ( ex tVar2 be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st (i <=XXREAL-3R1 lenFINSEQ-1K4 F implies tVar2 =XBOOLE-0R4 f .SUPINF-2K15 i) & (i =COMPLEX1R1 lenFINSEQ-1K4 F +NAT-1K1 \<one>\<^sub>M implies tVar2 =XBOOLE-0R4 tVar2))"
                  proof(rule impI)
                    assume A6: "i =COMPLEX1R1 lenFINSEQ-1K4 F +NAT-1K1 \<one>\<^sub>M"
                    show " ex tVar2 be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st (i <=XXREAL-3R1 lenFINSEQ-1K4 F implies tVar2 =XBOOLE-0R4 f .SUPINF-2K15 i) & (i =COMPLEX1R1 lenFINSEQ-1K4 F +NAT-1K1 \<one>\<^sub>M implies tVar2 =XBOOLE-0R4 tVar2)"
                    proof(rule bexI[of _ "f .SUPINF-2K15 lenFINSEQ-1K4 F +SUPINF-2K4 x"])
                      show "(i <=XXREAL-3R1 lenFINSEQ-1K4 F implies f .SUPINF-2K15 lenFINSEQ-1K4 F +SUPINF-2K4 x =XBOOLE-0R4 f .SUPINF-2K15 i) & (i =COMPLEX1R1 lenFINSEQ-1K4 F +NAT-1K1 \<one>\<^sub>M implies f .SUPINF-2K15 lenFINSEQ-1K4 F +SUPINF-2K4 x =XBOOLE-0R4 f .SUPINF-2K15 lenFINSEQ-1K4 F +SUPINF-2K4 x)"
                        using A6 nat_1_th_13 sorry
                    qed "sorry"
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            obtain f9 where
              [ty]:"f9 be sequenceNAT-1M2-of ExtREALXXREAL-0K3" and 
              A7: " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?R(i,f9 .SUPINF-2K15 i)"
              using funct_2_sch_3 A4 sorry
            show " ex f be sequenceNAT-1M2-of ExtREALXXREAL-0K3 st f .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 0.SUPINF-2K2 & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i <XXREAL-0R3 lenFINSEQ-1K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)) implies f .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .SUPINF-2K15 i +SUPINF-2K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)).SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M))"
            proof-
              have " ex tVar3 be sequenceNAT-1M2-of ExtREALXXREAL-0K3 st tVar3 .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 0.SUPINF-2K2 & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i <XXREAL-0R3 lenFINSEQ-1K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)) implies tVar3 .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 tVar3 .SUPINF-2K15 i +SUPINF-2K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)).SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M))"
              proof-
                show " ex tVar3 be sequenceNAT-1M2-of ExtREALXXREAL-0K3 st tVar3 .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 0.SUPINF-2K2 & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i <XXREAL-0R3 lenFINSEQ-1K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)) implies tVar3 .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 tVar3 .SUPINF-2K15 i +SUPINF-2K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)).SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M))"
                proof(rule bexI[of _ "f9"],rule conjMI)
                  show "f9 .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 0.SUPINF-2K2"
                    using A2 A7 sorry
                  show " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i <XXREAL-0R3 lenFINSEQ-1K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)) implies f9 .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f9 .SUPINF-2K15 i +SUPINF-2K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)).SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M)"
                  proof(rule ballI,rule impI)
                    fix i assume [ty]: "i be ElementSUBSET-1M1-of NATNUMBERSK1"
                    assume "i <XXREAL-0R3 lenFINSEQ-1K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>))"
                    then have "i <XXREAL-0R3 lenFINSEQ-1K4 F +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)"
                      using finseq_1_th_22 sorry
                    then have "i <XXREAL-0R3 lenFINSEQ-1K4 F +NAT-1K1 \<one>\<^sub>M"
                      using finseq_1_th_39 sorry
                    then have A8: "i <=XXREAL-3R1 lenFINSEQ-1K4 F"
                      using nat_1_th_13 sorry
                    then have A9: "f9 .SUPINF-2K15 i =XBOOLE-0R4 f .SUPINF-2K15 i"
                      using A7 sorry
                    show "f9 .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f9 .SUPINF-2K15 i +SUPINF-2K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)).SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M)"
                    proof-
                      have cases: "i <XXREAL-0R3 lenFINSEQ-1K4 F or i =COMPLEX1R1 lenFINSEQ-1K4 F"
                        using A8 xxreal_0_th_1 sorry
                      have case1: "i <XXREAL-0R3 lenFINSEQ-1K4 F implies f9 .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f9 .SUPINF-2K15 i +SUPINF-2K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)).SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M)"
                      proof(rule impI)
                        assume A10: "i <XXREAL-0R3 lenFINSEQ-1K4 F"
                        then have A11: "i +NAT-1K1 \<one>\<^sub>M <=XXREAL-3R1 lenFINSEQ-1K4 F"
                          using int_1_th_7 sorry
                        have "\<one>\<^sub>M <=XXREAL-3R1 i +NAT-1K1 \<one>\<^sub>M"
                          using nat_1_th_12 sorry
                        then have "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 F)"
                          using A11 finseq_1_th_1 sorry
                        then have A12: "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 F"
                          using finseq_1_def_3 sorry
                        have "f9 .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M)"
                          using A7 A11 sorry
                        then have "f9 .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f9 .SUPINF-2K15 i +SUPINF-2K4 F .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M)"
                          using A3 A9 A10 sorry
                        thus "f9 .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f9 .SUPINF-2K15 i +SUPINF-2K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)).SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M)"
                          using A12 finseq_1_def_7 sorry
                      qed
                      have case2: "i =COMPLEX1R1 lenFINSEQ-1K4 F implies f9 .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f9 .SUPINF-2K15 i +SUPINF-2K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)).SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M)"
                      proof(rule impI)
                        assume A13: "i =COMPLEX1R1 lenFINSEQ-1K4 F"
                        then have "f9 .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f9 .SUPINF-2K15 i +SUPINF-2K4 x"
                          using A7 A9 sorry
                        thus "f9 .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f9 .SUPINF-2K15 i +SUPINF-2K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)).SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M)"
                          using A13 finseq_1_th_42 sorry
                      qed
                      show " ?thesis "
                        using cases case1 case2 sorry
                    qed
                  qed "sorry"
                qed "sorry"
              qed
              thus " ?thesis "
                 sorry
            qed
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have A14: "?P(<*>FINSEQ-1K7 (ExtREALXXREAL-0K3))"
        proof-
          have " ex tVar4 be sequenceNAT-1M2-of ExtREALXXREAL-0K3 st tVar4 .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 0.SUPINF-2K2 & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not ( not i <XXREAL-0R3 lenFINSEQ-1K4 <*>FINSEQ-1K7 (ExtREALXXREAL-0K3) &  not tVar4 .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 tVar4 .SUPINF-2K15 i +SUPINF-2K4 <*>FINSEQ-1K7 (ExtREALXXREAL-0K3) .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M)))"
          proof-
            obtain f where 
              [ty]:"f be sequenceNAT-1M2-of ExtREALXXREAL-0K3" and fDef:"f = NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(ExtREALNUMBERSK7)\<^esub> 0.SUPINF-2K2"
               sorry
            show " ex tVar4 be sequenceNAT-1M2-of ExtREALXXREAL-0K3 st tVar4 .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 0.SUPINF-2K2 & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not ( not i <XXREAL-0R3 lenFINSEQ-1K4 <*>FINSEQ-1K7 (ExtREALXXREAL-0K3) &  not tVar4 .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 tVar4 .SUPINF-2K15 i +SUPINF-2K4 <*>FINSEQ-1K7 (ExtREALXXREAL-0K3) .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M)))"
            proof(rule bexI[of _ "f"],rule conjMI)
              show "f .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 0.SUPINF-2K2"
                using funcop_1_th_7 sorry
              show " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not ( not i <XXREAL-0R3 lenFINSEQ-1K4 <*>FINSEQ-1K7 (ExtREALXXREAL-0K3) &  not f .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .SUPINF-2K15 i +SUPINF-2K4 <*>FINSEQ-1K7 (ExtREALXXREAL-0K3) .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M))"
                 sorry
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
        have " for F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds ?P(F)"
          using finseq_2_sch_2 A14 A1 sorry
        then obtain f1 where
          [ty]:"f1 be sequenceNAT-1M2-of ExtREALXXREAL-0K3" and 
          A15: "f1 .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 0.SUPINF-2K2"and A16: " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i <XXREAL-0R3 lenFINSEQ-1K4 F implies f1 .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f1 .SUPINF-2K15 i +SUPINF-2K4 F .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M)"
           sorry
        have A17: " for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 F implies f1 .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f1 .SUPINF-2K15 i +SUPINF-2K4 F .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M)"
        proof-
          have " for i be NatNAT-1M1 holds  not ( not i <XXREAL-0R3 lenFINSEQ-1K4 F &  not f1 .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f1 .SUPINF-2K15 i +SUPINF-2K4 F .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M))"
          proof(rule ballI)
            fix i assume [ty]: "i be NatNAT-1M1"
            have "i inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            thus " not ( not i <XXREAL-0R3 lenFINSEQ-1K4 F &  not f1 .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f1 .SUPINF-2K15 i +SUPINF-2K4 F .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M))"
              using A16 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain FF where 
          [ty]:"FF be ElementSUBSET-1M1-of ExtREALNUMBERSK7" and FFDef:"FF = f1 .SUPINF-2K15 lenFINSEQ-1K4 F"
           sorry
        show " ex FF be ElementSUBSET-1M1-of ExtREALNUMBERSK7 st  not ( for f be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds  not ((FF =XBOOLE-0R4 f .SUPINF-2K15 lenFINSEQ-1K4 F & f .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 0.SUPINF-2K2) & ( for i be NatNAT-1M1 holds  not ( not i <XXREAL-0R3 lenFINSEQ-1K4 F &  not f .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .SUPINF-2K15 i +SUPINF-2K4 F .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M)))))"
        proof(rule bexI[of _ "FF"])
          show " not ( for f be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds  not ((FF =XBOOLE-0R4 f .SUPINF-2K15 lenFINSEQ-1K4 F & f .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 0.SUPINF-2K2) & ( for i be NatNAT-1M1 holds  not ( not i <XXREAL-0R3 lenFINSEQ-1K4 F &  not f .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .SUPINF-2K15 i +SUPINF-2K4 F .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M)))))"
            using A15 A17 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be R-ealSUPINF-1M1 holds  for it2 be R-ealSUPINF-1M1 holds ( ex f be sequenceNAT-1M2-of ExtREALXXREAL-0K3 st (it1 =XBOOLE-0R4 f .SUPINF-2K15 lenFINSEQ-1K4 F & f .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 0.SUPINF-2K2) & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 F implies f .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .SUPINF-2K15 i +SUPINF-2K4 F .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M))) & ( ex f be sequenceNAT-1M2-of ExtREALXXREAL-0K3 st (it2 =XBOOLE-0R4 f .SUPINF-2K15 lenFINSEQ-1K4 F & f .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 0.SUPINF-2K2) & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 F implies f .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .SUPINF-2K15 i +SUPINF-2K4 F .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M))) implies it1 =HIDDENR1 it2"
    proof-
      have " for g1 be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 holds  for g2 be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 holds ( ex f1 be sequenceNAT-1M2-of ExtREALXXREAL-0K3 st (g1 =XBOOLE-0R4 f1 .SUPINF-2K15 lenFINSEQ-1K4 F & f1 .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 0.SUPINF-2K2) & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 F implies f1 .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f1 .SUPINF-2K15 i +SUPINF-2K4 F .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M))) implies (( ex f2 be sequenceNAT-1M2-of ExtREALXXREAL-0K3 st (g2 =XBOOLE-0R4 f2 .SUPINF-2K15 lenFINSEQ-1K4 F & f2 .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 0.SUPINF-2K2) & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 F implies f2 .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f2 .SUPINF-2K15 i +SUPINF-2K4 F .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M))) implies g1 =HIDDENR1 g2)"
      proof(rule ballI,rule ballI,rule impI,rule impI)
        fix g1 assume [ty]: "g1 be ElementSUBSET-1M1-of ExtREALXXREAL-0K3"
        fix g2 assume [ty]: "g2 be ElementSUBSET-1M1-of ExtREALXXREAL-0K3"
        assume Given: " ex f1 be sequenceNAT-1M2-of ExtREALXXREAL-0K3 st (g1 =XBOOLE-0R4 f1 .SUPINF-2K15 lenFINSEQ-1K4 F & f1 .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 0.SUPINF-2K2) & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 F implies f1 .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f1 .SUPINF-2K15 i +SUPINF-2K4 F .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M))"
        then obtain f1 where
          [ty]:"f1 be sequenceNAT-1M2-of ExtREALXXREAL-0K3" and 
          A18: "g1 =XBOOLE-0R4 f1 .SUPINF-2K15 lenFINSEQ-1K4 F"and A19: "f1 .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 0.SUPINF-2K2"and A20: " for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 F implies f1 .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f1 .SUPINF-2K15 i +SUPINF-2K4 F .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M)"
           sorry
        assume Given: " ex f2 be sequenceNAT-1M2-of ExtREALXXREAL-0K3 st (g2 =XBOOLE-0R4 f2 .SUPINF-2K15 lenFINSEQ-1K4 F & f2 .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 0.SUPINF-2K2) & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 F implies f2 .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f2 .SUPINF-2K15 i +SUPINF-2K4 F .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M))"
        then obtain f2 where
          [ty]:"f2 be sequenceNAT-1M2-of ExtREALXXREAL-0K3" and 
          A21: "g2 =XBOOLE-0R4 f2 .SUPINF-2K15 lenFINSEQ-1K4 F"and A22: "f2 .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 0.SUPINF-2K2"and A23: " for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 F implies f2 .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f2 .SUPINF-2K15 i +SUPINF-2K4 F .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M)"
           sorry
        let ?P = "\<lambda>Lamb1. Lamb1 <=XXREAL-3R1 lenFINSEQ-1K4 F implies f1 .SUPINF-2K15 Lamb1 =XBOOLE-0R4 f2 .SUPINF-2K15 Lamb1"
        have A24: " for i be NatNAT-1M1 holds ?P(i) implies ?P(i +NAT-1K1 \<one>\<^sub>M)"
        proof-
          have " for i be NatNAT-1M1 holds (i <=XXREAL-3R1 lenFINSEQ-1K4 F implies f1 .SUPINF-2K15 i =XBOOLE-0R4 f2 .SUPINF-2K15 i) implies (i +NAT-1K1 \<one>\<^sub>M <=XXREAL-3R1 lenFINSEQ-1K4 F implies f1 .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f2 .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M))"
          proof(rule ballI,rule impI)
            fix i assume [ty]: "i be NatNAT-1M1"
            assume A25: "?P(i)"
            show "i +NAT-1K1 \<one>\<^sub>M <=XXREAL-3R1 lenFINSEQ-1K4 F implies f1 .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f2 .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M)"
            proof(rule impI)
              assume "i +NAT-1K1 \<one>\<^sub>M <=XXREAL-3R1 lenFINSEQ-1K4 F"
              then have A26: "i <XXREAL-0R3 lenFINSEQ-1K4 F"
                using nat_1_th_13 sorry
              then have "f1 .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f1 .SUPINF-2K15 i +SUPINF-2K4 F .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M)"
                using A20 sorry
              thus "f1 .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f2 .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M)"
                using A23 A25 A26 sorry
            qed
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have A27: "?P(0NUMBERSK6)"
          using A19 A22 sorry
        have " for i be NatNAT-1M1 holds ?P(i)"
          using nat_1_sch_2 A27 A24 sorry
        thus "g1 =HIDDENR1 g2"
          using A18 A21 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem extreal1_th_7:
"SumEXTREAL1K4 <*>FINSEQ-1K7 (ExtREALXXREAL-0K3) =XBOOLE-0R4 0.SUPINF-2K2"
proof-
  obtain F where 
    [ty]:"F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3" and FDef:"F = <*>FINSEQ-1K7 (ExtREALXXREAL-0K3)"
     sorry
  have " ex f be sequenceNAT-1M2-of ExtREALXXREAL-0K3 st (SumEXTREAL1K4 F =XBOOLE-0R4 f .SUPINF-2K15 lenFINSEQ-1K4 F & f .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 0.SUPINF-2K2) & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 F implies f .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .SUPINF-2K15 i +SUPINF-2K4 F .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M))"
    using extreal1_def_2 sorry
  thus "SumEXTREAL1K4 <*>FINSEQ-1K7 (ExtREALXXREAL-0K3) =XBOOLE-0R4 0.SUPINF-2K2"
     sorry
qed

mtheorem extreal1_th_8:
" for a be R-ealSUPINF-1M1 holds SumEXTREAL1K4 (<*FINSEQ-1K13\<^bsub>(ExtREALNUMBERSK7)\<^esub> a*>) =XBOOLE-0R4 a"
proof(rule ballI)
  fix a assume [ty]: "a be R-ealSUPINF-1M1"
  let ?F = "<*FINSEQ-1K13\<^bsub>(ExtREALNUMBERSK7)\<^esub> a*>"
  obtain f where
    [ty]:"f be sequenceNAT-1M2-of ExtREALXXREAL-0K3" and 
    A1: "SumEXTREAL1K4 ?F =XBOOLE-0R4 f .SUPINF-2K15 lenFINSEQ-1K4 ?F"and A2: "f .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 0.SUPINF-2K2"and A3: " for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 ?F implies f .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .SUPINF-2K15 i +SUPINF-2K4 ?F .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M)"
    using extreal1_def_2 sorry
  have A4: "f .SUPINF-2K15 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .SUPINF-2K15 (0NUMBERSK6) +SUPINF-2K4 ?F .SUPINF-2K15 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)"
    using A3 sorry
  have "SumEXTREAL1K4 ?F =XBOOLE-0R4 f .SUPINF-2K15 \<one>\<^sub>M"
    using A1 finseq_1_th_39 sorry
  then have "SumEXTREAL1K4 ?F =HIDDENR1 ?F .SUPINF-2K15 \<one>\<^sub>M"
    using A2 A4 xxreal_3_th_4 sorry
  also have "... = a"
    using finseq_1_th_40 sorry
  finally have "SumEXTREAL1K4 ?F =HIDDENR1 a"
     sorry
  thus "SumEXTREAL1K4 (<*FINSEQ-1K13\<^bsub>(ExtREALNUMBERSK7)\<^esub> a*>) =XBOOLE-0R4 a"
     sorry
qed "sorry"

mlemma extreal1_lm_1:
" for F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  for x be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 holds SumEXTREAL1K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)) =XBOOLE-0R4 SumEXTREAL1K4 F +SUPINF-2K4 x"
proof(rule ballI,rule ballI)
  fix F assume [ty]: "F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3"
  fix x assume [ty]: "x be ElementSUBSET-1M1-of ExtREALXXREAL-0K3"
  obtain f where
    [ty]:"f be sequenceNAT-1M2-of ExtREALXXREAL-0K3" and 
    A1: "SumEXTREAL1K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)) =XBOOLE-0R4 f .SUPINF-2K15 lenFINSEQ-1K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>))"and A2: "f .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 0.SUPINF-2K2"and A3: " for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)) implies f .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .SUPINF-2K15 i +SUPINF-2K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)).SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M)"
    using extreal1_def_2 sorry
  have A4: "lenFINSEQ-1K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)) =HIDDENR1 lenFINSEQ-1K4 F +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)"
    using finseq_1_th_22 sorry
  also have "... = lenFINSEQ-1K4 F +NAT-1K1 \<one>\<^sub>M"
    using finseq_1_th_39 sorry
  finally have "lenFINSEQ-1K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)) =HIDDENR1 lenFINSEQ-1K4 F +NAT-1K1 \<one>\<^sub>M"
     sorry
  have " for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 F implies f .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .SUPINF-2K15 i +SUPINF-2K4 F .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M)"
  proof(rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    have A5: "\<one>\<^sub>M <=XXREAL-3R1 i +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_11 sorry
    assume A6: "i <XXREAL-0R3 lenFINSEQ-1K4 F"
    then have "i +NAT-1K1 \<one>\<^sub>M <=XXREAL-3R1 lenFINSEQ-1K4 F"
      using int_1_th_7 sorry
    then have "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 F)"
      using A5 finseq_1_th_1 sorry
    then have A7: "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 F"
      using finseq_1_def_3 sorry
    have "i <XXREAL-0R3 lenFINSEQ-1K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>))"
      using A4 A6 nat_1_th_13 sorry
    then have "f .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .SUPINF-2K15 i +SUPINF-2K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)).SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M)"
      using A3 sorry
    thus "f .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .SUPINF-2K15 i +SUPINF-2K4 F .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M)"
      using A7 finseq_1_def_7 sorry
  qed "sorry"
  then have A8: "SumEXTREAL1K4 F =XBOOLE-0R4 f .SUPINF-2K15 lenFINSEQ-1K4 F"
    using A2 extreal1_def_2 sorry
  have "lenFINSEQ-1K4 F <XXREAL-0R3 lenFINSEQ-1K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>))"
    using A4 nat_1_th_13 sorry
  then have "f .SUPINF-2K15 (lenFINSEQ-1K4 F +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .SUPINF-2K15 lenFINSEQ-1K4 F +SUPINF-2K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)).SUPINF-2K15 (lenFINSEQ-1K4 F +NAT-1K1 \<one>\<^sub>M)"
    using A3 sorry
  thus "SumEXTREAL1K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)) =XBOOLE-0R4 SumEXTREAL1K4 F +SUPINF-2K4 x"
    using A1 A4 A8 finseq_1_th_42 sorry
qed "sorry"

mtheorem extreal1_th_9:
" for a be R-ealSUPINF-1M1 holds  for b be R-ealSUPINF-1M1 holds SumEXTREAL1K4 (<*FINSEQ-4K2\<^bsub>(ExtREALNUMBERSK7)\<^esub> a,b *>) =XBOOLE-0R4 a +SUPINF-2K4 b"
proof-
  have " for a be R-ealSUPINF-1M1 holds  for b be R-ealSUPINF-1M1 holds SumEXTREAL1K4 (<*FINSEQ-4K2\<^bsub>(ExtREALNUMBERSK7)\<^esub> a,b *>) =HIDDENR1 a +SUPINF-2K4 b"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be R-ealSUPINF-1M1"
    fix b assume [ty]: "b be R-ealSUPINF-1M1"
    have "SumEXTREAL1K4 (<*FINSEQ-4K2\<^bsub>(ExtREALNUMBERSK7)\<^esub> a,b *>) =HIDDENR1 SumEXTREAL1K4 ((<*FINSEQ-1K13\<^bsub>(ExtREALNUMBERSK7)\<^esub> a*>)^FINSEQ-1K9\<^bsub>(ExtREALNUMBERSK7)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALNUMBERSK7)\<^esub> b*>))"
      using finseq_1_def_9 sorry
    also have "... = SumEXTREAL1K4 (<*FINSEQ-1K13\<^bsub>(ExtREALNUMBERSK7)\<^esub> a*>) +SUPINF-2K4 b"
      using extreal1_lm_1 sorry
    also have "... = a +SUPINF-2K4 b"
      using extreal1_th_8 sorry
    finally show "SumEXTREAL1K4 (<*FINSEQ-4K2\<^bsub>(ExtREALNUMBERSK7)\<^esub> a,b *>) =HIDDENR1 a +SUPINF-2K4 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma extreal1_lm_2:
" for F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F implies SumEXTREAL1K4 F <>HIDDENR2 -inftySUPINF-1K2"
proof-
  let ?P = "\<lambda>Lamb1.  not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> Lamb1 implies SumEXTREAL1K4 Lamb1 <>HIDDENR2 -inftySUPINF-1K2"
  have A1: " for F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  for x be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 holds ?P(F) implies ?P(F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>))"
  proof-
    have " for F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  for x be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 holds ( not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F implies SumEXTREAL1K4 F <>HIDDENR2 -inftySUPINF-1K2) implies ( not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)) implies  not SumEXTREAL1K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)) <>HIDDENR2 -inftySUPINF-1K2)"
    proof(rule ballI,rule ballI,rule impI,rule impI)
      fix F assume [ty]: "F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3"
      fix x assume [ty]: "x be ElementSUBSET-1M1-of ExtREALXXREAL-0K3"
      assume A2: "?P(F)"
      have A3: "SumEXTREAL1K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)) =XBOOLE-0R4 SumEXTREAL1K4 F +SUPINF-2K4 x"
        using extreal1_lm_1 sorry
      assume " not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>))"
      then have A4: " not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F \\/SUBSET-1K4\<^bsub>(ExtREALXXREAL-0K3)\<^esub> rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)"
        using finseq_1_th_31 sorry
      then have " not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)"
        using xboole_0_def_3 sorry
      then have " not -inftySUPINF-1K2 inTARSKIR2 {DOMAIN-1K6\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x}"
        using finseq_1_th_38 sorry
      then have "x <>HIDDENR2 -inftySUPINF-1K2"
        using tarski_def_1 sorry
      thus " not SumEXTREAL1K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)) <>HIDDENR2 -inftySUPINF-1K2"
        using A2 A4 A3 xboole_0_def_3 xxreal_3_th_17 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have A5: "?P(<*>FINSEQ-1K7 (ExtREALXXREAL-0K3))"
    using extreal1_th_7 sorry
  show " for F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F implies SumEXTREAL1K4 F <>HIDDENR2 -inftySUPINF-1K2"
    using finseq_2_sch_2 A5 A1 sorry
qed

mtheorem extreal1_th_10:
" for F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  for G be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F &  not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> G implies SumEXTREAL1K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> G) =XBOOLE-0R4 SumEXTREAL1K4 F +SUPINF-2K4 SumEXTREAL1K4 G"
proof-
  have " for F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  for G be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F implies ( not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> G implies SumEXTREAL1K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> G) =XBOOLE-0R4 SumEXTREAL1K4 F +SUPINF-2K4 SumEXTREAL1K4 G)"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix F assume [ty]: "F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3"
    fix G assume [ty]: "G be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3"
    let ?P = "\<lambda>Lamb1.  not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> Lamb1 implies SumEXTREAL1K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> Lamb1) =XBOOLE-0R4 SumEXTREAL1K4 F +SUPINF-2K4 SumEXTREAL1K4 Lamb1"
    assume A1: " not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F"
    have A2: " for H be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  for x be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 holds ?P(H) implies ?P(H ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>))"
    proof-
      have " for H be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  for x be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 holds ( not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> H implies SumEXTREAL1K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> H) =XBOOLE-0R4 SumEXTREAL1K4 F +SUPINF-2K4 SumEXTREAL1K4 H) implies ( not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (H ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)) implies SumEXTREAL1K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (H ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>))) =XBOOLE-0R4 SumEXTREAL1K4 F +SUPINF-2K4 SumEXTREAL1K4 (H ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)))"
      proof(rule ballI,rule ballI,rule impI)
        fix H assume [ty]: "H be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3"
        fix x assume [ty]: "x be ElementSUBSET-1M1-of ExtREALXXREAL-0K3"
        assume A3: "?P(H)"
        show " not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (H ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)) implies SumEXTREAL1K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (H ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>))) =XBOOLE-0R4 SumEXTREAL1K4 F +SUPINF-2K4 SumEXTREAL1K4 (H ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>))"
        proof-
          have " not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (H ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)) implies SumEXTREAL1K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (H ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>))) =HIDDENR1 SumEXTREAL1K4 F +SUPINF-2K4 SumEXTREAL1K4 (H ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>))"
          proof(rule impI)
            assume " not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (H ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>))"
            then have A4: " not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> H \\/SUBSET-1K4\<^bsub>(ExtREALXXREAL-0K3)\<^esub> rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)"
              using finseq_1_th_31 sorry
            then have " not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> H"
              using xboole_0_def_3 sorry
            then have A5: "SumEXTREAL1K4 H <>HIDDENR2 -inftySUPINF-1K2"
              using extreal1_lm_2 sorry
            have " not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)"
              using A4 xboole_0_def_3 sorry
            then have " not -inftySUPINF-1K2 inTARSKIR2 {DOMAIN-1K6\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x}"
              using finseq_1_th_38 sorry
            then have A6: "x <>HIDDENR2 -inftySUPINF-1K2"
              using tarski_def_1 sorry
            have A7: "SumEXTREAL1K4 F <>HIDDENR2 -inftySUPINF-1K2"
              using A1 extreal1_lm_2 sorry
            have "F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (H ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)) =FINSEQ-1R1 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> H)^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)"
              using finseq_1_th_32 sorry
            then have "SumEXTREAL1K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (H ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>))) =HIDDENR1 (SumEXTREAL1K4 F +SUPINF-2K4 SumEXTREAL1K4 H)+SUPINF-2K4 x"
              using A3 A4 extreal1_lm_1 xboole_0_def_3 sorry
            also have "... = SumEXTREAL1K4 F +SUPINF-2K4 (SumEXTREAL1K4 H +SUPINF-2K4 x)"
              using A6 A7 A5 xxreal_3_th_29 sorry
            also have "... = SumEXTREAL1K4 F +SUPINF-2K4 SumEXTREAL1K4 (H ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>))"
              using extreal1_lm_1 sorry
            finally show "SumEXTREAL1K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (H ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>))) =HIDDENR1 SumEXTREAL1K4 F +SUPINF-2K4 SumEXTREAL1K4 (H ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>))"
               sorry
          qed
          thus " ?thesis "
             sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A8: " not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> G"
    have A9: "?P(<*>FINSEQ-1K7 (ExtREALXXREAL-0K3))"
    proof-
      have " not -inftySUPINF-1K2 inTARSKIR2 rngRVSUM-1K1 <*>FINSEQ-1K7 (ExtREALXXREAL-0K3) implies SumEXTREAL1K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> <*>FINSEQ-1K7 (ExtREALXXREAL-0K3)) =HIDDENR1 SumEXTREAL1K4 F +SUPINF-2K4 SumEXTREAL1K4 <*>FINSEQ-1K7 (ExtREALXXREAL-0K3)"
      proof(rule impI)
        let ?H = "<*>FINSEQ-1K7 (ExtREALXXREAL-0K3)"
        assume " not -inftySUPINF-1K2 inTARSKIR2 rngRVSUM-1K1 ?H"
        have "SumEXTREAL1K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> <*>FINSEQ-1K7 (ExtREALXXREAL-0K3)) =HIDDENR1 SumEXTREAL1K4 F"
          using finseq_1_th_34 sorry
        also have "... = SumEXTREAL1K4 F +SUPINF-2K4 SumEXTREAL1K4 <*>FINSEQ-1K7 (ExtREALXXREAL-0K3)"
          using extreal1_th_7 xxreal_3_th_4 sorry
        finally show "SumEXTREAL1K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> <*>FINSEQ-1K7 (ExtREALXXREAL-0K3)) =HIDDENR1 SumEXTREAL1K4 F +SUPINF-2K4 SumEXTREAL1K4 <*>FINSEQ-1K7 (ExtREALXXREAL-0K3)"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have " for H be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds ?P(H)"
      using finseq_2_sch_2 A9 A2 sorry
    thus "SumEXTREAL1K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> G) =XBOOLE-0R4 SumEXTREAL1K4 F +SUPINF-2K4 SumEXTREAL1K4 G"
      using A8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma extreal1_lm_3:
" for n be NatNAT-1M1 holds  for q be NatNAT-1M1 holds q inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies ( ex p be PermutationFUNCT-2M2-of SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) st  for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies ((i <XXREAL-0R3 q implies p .FUNCT-1K1 i =XBOOLE-0R4 i) & (i =COMPLEX1R1 q implies p .FUNCT-1K1 i =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M)) & (i >XXREAL-0R4 q implies p .FUNCT-1K1 i =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M))"
proof-
  have " for n be NatNAT-1M1 holds  for q be NatNAT-1M1 holds q inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies ( ex tVar9 be PermutationFUNCT-2M2-of SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) st  for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (i inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) &  not (( not ( not i <XXREAL-0R3 q &  not tVar9 .FUNCT-1K1 i =XBOOLE-0R4 i) &  not (i =COMPLEX1R1 q &  not tVar9 .FUNCT-1K1 i =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M)) &  not ( not i >XXREAL-0R4 q &  not tVar9 .FUNCT-1K1 i =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M))))"
  proof(rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix q assume [ty]: "q be NatNAT-1M1"
    let ?R = "\<lambda>Lamb1. \<lambda>Lamb2. ((Lamb1 <XXREAL-0R3 q implies Lamb2 =XBOOLE-0R4 Lamb1) & (Lamb1 =COMPLEX1R1 q implies Lamb2 =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M)) & (Lamb1 >XXREAL-0R4 q implies Lamb2 =XBOOLE-0R4 Lamb1 -XCMPLX-0K6 \<one>\<^sub>M)"
    assume A1: "q inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
    have A2: " for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies ( ex p be ElementSUBSET-1M1-of NATNUMBERSK1 st ?R(i,p))"
    proof-
      have " for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies ( ex tVar6 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar6 be ElementSUBSET-1M1-of NATNUMBERSK1 & (((tVar6 <XXREAL-0R3 q implies tVar6 =XBOOLE-0R4 tVar6) & (tVar6 =COMPLEX1R1 q implies tVar6 =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M)) & (tVar6 >XXREAL-0R4 q implies tVar6 =XBOOLE-0R4 tVar6 -XCMPLX-0K6 \<one>\<^sub>M)))"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be NatNAT-1M1"
        assume "i inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
        show " ex tVar6 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar6 be ElementSUBSET-1M1-of NATNUMBERSK1 & (((tVar6 <XXREAL-0R3 q implies tVar6 =XBOOLE-0R4 tVar6) & (tVar6 =COMPLEX1R1 q implies tVar6 =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M)) & (tVar6 >XXREAL-0R4 q implies tVar6 =XBOOLE-0R4 tVar6 -XCMPLX-0K6 \<one>\<^sub>M))"
        proof-
          have cases: "(i <XXREAL-0R3 q or i =COMPLEX1R1 q) or i >XXREAL-0R4 q"
            using xxreal_0_th_1 sorry
          have case1: "i <XXREAL-0R3 q implies ( ex tVar6 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar6 be ElementSUBSET-1M1-of NATNUMBERSK1 & (((tVar6 <XXREAL-0R3 q implies tVar6 =XBOOLE-0R4 tVar6) & (tVar6 =COMPLEX1R1 q implies tVar6 =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M)) & (tVar6 >XXREAL-0R4 q implies tVar6 =XBOOLE-0R4 tVar6 -XCMPLX-0K6 \<one>\<^sub>M)))"
          proof(rule impI)
            assume A3: "i <XXREAL-0R3 q"
            show " ex tVar6 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar6 be ElementSUBSET-1M1-of NATNUMBERSK1 & (((tVar6 <XXREAL-0R3 q implies tVar6 =XBOOLE-0R4 tVar6) & (tVar6 =COMPLEX1R1 q implies tVar6 =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M)) & (tVar6 >XXREAL-0R4 q implies tVar6 =XBOOLE-0R4 tVar6 -XCMPLX-0K6 \<one>\<^sub>M))"
            proof(rule bexI[of _ "i"])
              have "i inTARSKIR2 NATNUMBERSK1"
                using ordinal1_def_12 sorry
              thus "i be ElementSUBSET-1M1-of NATNUMBERSK1 & (((i <XXREAL-0R3 q implies i =XBOOLE-0R4 i) & (i =COMPLEX1R1 q implies i =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M)) & (i >XXREAL-0R4 q implies i =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M))"
                using A3 sorry
            qed "sorry"
          qed
          have case2: "i =COMPLEX1R1 q implies ( ex tVar7 be ElementSUBSET-1M1-of NATNUMBERSK1 st ((i <XXREAL-0R3 q implies tVar7 =XBOOLE-0R4 i) & (i =COMPLEX1R1 q implies tVar7 =XBOOLE-0R4 tVar7)) & (i >XXREAL-0R4 q implies tVar7 =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M))"
          proof(rule impI)
            assume A4: "i =COMPLEX1R1 q"
            show " ex tVar7 be ElementSUBSET-1M1-of NATNUMBERSK1 st ((i <XXREAL-0R3 q implies tVar7 =XBOOLE-0R4 i) & (i =COMPLEX1R1 q implies tVar7 =XBOOLE-0R4 tVar7)) & (i >XXREAL-0R4 q implies tVar7 =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M)"
            proof(rule bexI[of _ "n +NAT-1K1 \<one>\<^sub>M"])
              show "((i <XXREAL-0R3 q implies n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 i) & (i =COMPLEX1R1 q implies n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M)) & (i >XXREAL-0R4 q implies n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M)"
                using A4 sorry
            qed "sorry"
          qed
          have case3: "i >XXREAL-0R4 q implies ( ex tVar8 be ElementSUBSET-1M1-of NATNUMBERSK1 st ((i <XXREAL-0R3 q implies tVar8 =XBOOLE-0R4 i) & (i =COMPLEX1R1 q implies tVar8 =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M)) & (i >XXREAL-0R4 q implies tVar8 =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M))"
          proof(rule impI)
            assume A5: "i >XXREAL-0R4 q"
            have "\<one>\<^sub>M <=XXREAL-3R1 q"
              using A1 finseq_1_th_1 sorry
            then obtain p where 
              [ty]:"p be ElementSUBSET-1M1-of NATNUMBERSK1" and pDef:"p = i -XCMPLX-0K6 \<one>\<^sub>M"
              using A5 int_1_th_5 xxreal_0_th_2 sorry
            show " ex tVar8 be ElementSUBSET-1M1-of NATNUMBERSK1 st ((i <XXREAL-0R3 q implies tVar8 =XBOOLE-0R4 i) & (i =COMPLEX1R1 q implies tVar8 =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M)) & (i >XXREAL-0R4 q implies tVar8 =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M)"
            proof(rule bexI[of _ "p"])
              show "((i <XXREAL-0R3 q implies p =XBOOLE-0R4 i) & (i =COMPLEX1R1 q implies p =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M)) & (i >XXREAL-0R4 q implies p =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M)"
                using A5 sorry
            qed "sorry"
          qed
          show " ?thesis "
            using cases case1 case2 case3 sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain p where
      [ty]:"p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
      A6: "domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"and A7: " for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies ?R(i,p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i)"
      using recdef_1_sch_17 A2 sorry
    have A8: " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies (i =COMPLEX1R1 q iff p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies (i =COMPLEX1R1 q implies p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M) & (p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M implies i =COMPLEX1R1 q)"
      proof(rule ballI,rule impI,rule conjMI)
        fix i assume [ty]: "i be ElementSUBSET-1M1-of NATNUMBERSK1"
        assume A9: "i inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
        thus "i =COMPLEX1R1 q implies p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
          using A7 sorry
        show "p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M implies i =COMPLEX1R1 q"
        proof(rule impI)
          assume A10: "p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
          show "i =COMPLEX1R1 q"
          proof-
            have cases: "(i =COMPLEX1R1 q or i <XXREAL-0R3 q) or i >XXREAL-0R4 q"
              using xxreal_0_th_1 sorry
            have case1: "i =COMPLEX1R1 q implies i =COMPLEX1R1 q"
            proof(rule impI)
              assume "i =COMPLEX1R1 q"
              thus "i =COMPLEX1R1 q"
                 sorry
            qed
            have case2: "i <XXREAL-0R3 q implies i =COMPLEX1R1 q"
            proof(rule impI)
              assume "i <XXREAL-0R3 q"
              then have "n +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 q"
                using A7 A9 A10 sorry
              thus "i =COMPLEX1R1 q"
                using A1 finseq_1_th_1 sorry
            qed
            have case3: "i >XXREAL-0R4 q implies i =COMPLEX1R1 q"
            proof(rule impI)
              assume "i >XXREAL-0R4 q"
              then have "i -XCMPLX-0K6 \<one>\<^sub>M =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
                using A7 A9 A10 sorry
              then have "i >=XXREAL-0R2 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
                 sorry
              then have "i >XXREAL-0R4 n +NAT-1K1 \<one>\<^sub>M"
                using nat_1_th_13 sorry
              thus "i =COMPLEX1R1 q"
                using A9 finseq_1_th_1 sorry
            qed
            show " ?thesis "
              using cases case1 case2 case3 sorry
          qed
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A11: " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies ((i <XXREAL-0R3 q implies p .SUPINF-2K15 i =COMPLEX1R1 i) & (i =COMPLEX1R1 q implies p .SUPINF-2K15 i =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M)) & (i >XXREAL-0R4 q implies p .SUPINF-2K15 i =COMPLEX1R1 i -XCMPLX-0K6 \<one>\<^sub>M)"
    proof-
      have " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies ( not ( not i <XXREAL-0R3 q &  not p .SUPINF-2K15 i =COMPLEX1R1 i) &  not (i =COMPLEX1R1 q &  not p .SUPINF-2K15 i =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M)) &  not ( not i >XXREAL-0R4 q &  not p .SUPINF-2K15 i =COMPLEX1R1 i -XCMPLX-0K6 \<one>\<^sub>M)"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be ElementSUBSET-1M1-of NATNUMBERSK1"
        assume A12: "i inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
        then have "p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i =COMPLEX1R1 p .SUPINF-2K15 i"
          using A6 partfun1_def_6 sorry
        thus "( not ( not i <XXREAL-0R3 q &  not p .SUPINF-2K15 i =COMPLEX1R1 i) &  not (i =COMPLEX1R1 q &  not p .SUPINF-2K15 i =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M)) &  not ( not i >XXREAL-0R4 q &  not p .SUPINF-2K15 i =COMPLEX1R1 i -XCMPLX-0K6 \<one>\<^sub>M)"
          using A7 A12 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for i be objectHIDDENM1 holds i inHIDDENR3 rngRVSUM-1K1 p iff i inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for i be objectHIDDENM1 holds (i inHIDDENR3 rngRVSUM-1K1 p implies i inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)) & (i inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies i inHIDDENR3 rngRVSUM-1K1 p)"
      proof(rule ballI,rule conjMI)
        fix i assume [ty]: "i be objectHIDDENM1"
        show "i inHIDDENR3 rngRVSUM-1K1 p implies i inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
        proof(rule impI)
          assume "i inHIDDENR3 rngRVSUM-1K1 p"
          then obtain j where
            [ty]:"j be objectHIDDENM1" and 
            A13: "j inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"and A14: "p .FUNCT-1K1 j =HIDDENR1 i"
            using A6 funct_1_def_3 sorry
          have 
            [ty]:"j be ElementSUBSET-1M1-of NATNUMBERSK1"
            using A13 sorry
          show "i inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
          proof-
            have cases: "(j <XXREAL-0R3 q or j =COMPLEX1R1 q) or j >XXREAL-0R4 q"
              using xxreal_0_th_1 sorry
            have case1: "j <XXREAL-0R3 q implies i inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
            proof(rule impI)
              assume "j <XXREAL-0R3 q"
              thus "i inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
                using A11 A13 A14 sorry
            qed
            have case2: "j =COMPLEX1R1 q implies i inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
            proof(rule impI)
              assume "j =COMPLEX1R1 q"
              then have "i =HIDDENR1 n +NAT-1K1 \<one>\<^sub>M"
                using A11 A13 A14 sorry
              thus "i inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
                using finseq_1_th_4 sorry
            qed
            have case3: "j >XXREAL-0R4 q implies i inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
            proof(rule impI)
              assume A15: "j >XXREAL-0R4 q"
              then have A16: "i =HIDDENR1 j -XCMPLX-0K6 \<one>\<^sub>M"
                using A11 A13 A14 sorry
              have A17: "\<one>\<^sub>M <=XXREAL-3R1 q"
                using A1 finseq_1_th_1 sorry
              then have 
                [ty]:"i be ElementSUBSET-1M1-of NATNUMBERSK1"
                using A15 A16 int_1_th_5 xxreal_0_th_2 sorry
              have "j <=XXREAL-3R1 n +NAT-1K1 \<one>\<^sub>M"
                using A13 finseq_1_th_1 sorry
              then have "i <=XXREAL-3R1 n"
                using A16 xreal_1_th_20 sorry
              then have A18: "i <=XXREAL-3R1 n +NAT-1K1 \<one>\<^sub>M"
                using nat_1_th_12 sorry
              have "\<one>\<^sub>M <XXREAL-0R3 i +NAT-1K1 \<one>\<^sub>M"
                using A15 A16 A17 xxreal_0_th_2 sorry
              then have "\<one>\<^sub>M <=XXREAL-3R1 i"
                using nat_1_th_13 sorry
              thus "i inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
                using A18 finseq_1_th_1 sorry
            qed
            show " ?thesis "
              using cases case1 case2 case3 sorry
          qed
        qed
        show "i inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies i inHIDDENR3 rngRVSUM-1K1 p"
        proof(rule impI)
          assume A19: "i inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
          then have 
            [ty]:"i be ElementSUBSET-1M1-of NATNUMBERSK1"
             sorry
          have "i <=XXREAL-3R1 n +NAT-1K1 \<one>\<^sub>M"
            using A19 finseq_1_th_1 sorry
          then have A20: "i =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M or i <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
            using xxreal_0_th_1 sorry
          show "i inHIDDENR3 rngRVSUM-1K1 p"
          proof-
            have cases: "(i <XXREAL-0R3 q or q <=XXREAL-3R1 i & i <=XXREAL-3R1 n) or i =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
              using A20 nat_1_th_13 sorry
            have case1: "i <XXREAL-0R3 q implies i inHIDDENR3 rngRVSUM-1K1 p"
            proof(rule impI)
              assume "i <XXREAL-0R3 q"
              then have "p .SUPINF-2K15 i =COMPLEX1R1 i"
                using A11 A19 sorry
              thus "i inHIDDENR3 rngRVSUM-1K1 p"
                using A6 A19 funct_1_th_3 sorry
            qed
            have case2: "q <=XXREAL-3R1 i & i <=XXREAL-3R1 n implies i inHIDDENR3 rngRVSUM-1K1 p"
            proof(rule impI)
              assume A21: "q <=XXREAL-3R1 i & i <=XXREAL-3R1 n"
              have A22: "\<one>\<^sub>M <=XXREAL-3R1 i +NAT-1K1 \<one>\<^sub>M"
                using nat_1_th_12 sorry
              have "i +NAT-1K1 \<one>\<^sub>M <=XXREAL-3R1 n +NAT-1K1 \<one>\<^sub>M"
                using A21 xreal_1_th_6 sorry
              then have A23: "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
                using A22 finseq_1_th_1 sorry
              have "q <XXREAL-0R3 i +NAT-1K1 \<one>\<^sub>M"
                using A21 nat_1_th_13 sorry
              then have "p .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (i +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
                using A11 A23 sorry
              also have "... = i"
                 sorry
              finally have "p .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 i"
                 sorry
              thus "i inHIDDENR3 rngRVSUM-1K1 p"
                using A6 A23 funct_1_th_3 sorry
            qed
            have case3: "i =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M implies i inHIDDENR3 rngRVSUM-1K1 p"
            proof(rule impI)
              assume "i =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
              then have "p .SUPINF-2K15 q =COMPLEX1R1 i"
                using A1 A11 sorry
              thus "i inHIDDENR3 rngRVSUM-1K1 p"
                using A1 A6 funct_1_th_3 sorry
            qed
            show " ?thesis "
              using cases case1 case2 case3 sorry
          qed
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have A24: "rngRVSUM-1K1 p =XBOOLE-0R4 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
      using tarski_th_2 sorry
    then have A25: "p be FunctionFUNCT-2M1-of(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))"
      using A6 funct_2_th_1 sorry
    have A26: " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) & p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i <>HIDDENR2 n +NAT-1K1 \<one>\<^sub>M implies (i <XXREAL-0R3 q iff p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i <XXREAL-0R3 q)"
    proof-
      have " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) & p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i <>HIDDENR2 n +NAT-1K1 \<one>\<^sub>M implies (i <XXREAL-0R3 q implies p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i <XXREAL-0R3 q) & (p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i <XXREAL-0R3 q implies i <XXREAL-0R3 q)"
      proof(rule ballI,rule impMI ,rule impI,rule conjMI)
        fix i assume [ty]: "i be ElementSUBSET-1M1-of NATNUMBERSK1"
        assume A27: "i inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
          and A28: "p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i <>HIDDENR2 n +NAT-1K1 \<one>\<^sub>M"
        show "i <XXREAL-0R3 q implies p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i <XXREAL-0R3 q"
          using A7 A27 sorry
        show "p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i <XXREAL-0R3 q implies i <XXREAL-0R3 q"
        proof-
          have "p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i <XXREAL-0R3 q implies  not i <XXREAL-0R3 q"
          proof(rule impI)
            assume A29: "p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i <XXREAL-0R3 q"
            show " not i <XXREAL-0R3 q"
            proof-
              have cases: "(i <XXREAL-0R3 q or i =COMPLEX1R1 q) or i >XXREAL-0R4 q"
                using xxreal_0_th_1 sorry
              have case1: "i <XXREAL-0R3 q implies  not i <XXREAL-0R3 q"
              proof(rule impI)
                assume "i <XXREAL-0R3 q"
                thus " not i <XXREAL-0R3 q"
                   sorry
              qed
              have case2: "i =COMPLEX1R1 q implies  not i <XXREAL-0R3 q"
              proof(rule impI)
                assume "i =COMPLEX1R1 q"
                thus " not i <XXREAL-0R3 q"
                  using A7 A27 A28 sorry
              qed
              have case3: "i >XXREAL-0R4 q implies  not i <XXREAL-0R3 q"
              proof(rule impI)
                assume A30: "i >XXREAL-0R4 q"
                then have "p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i =COMPLEX1R1 i -XCMPLX-0K6 \<one>\<^sub>M"
                  using A7 A27 sorry
                then have "(i -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M <XXREAL-0R3 q +NAT-1K1 \<one>\<^sub>M"
                  using A29 xreal_1_th_8 sorry
                thus " not i <XXREAL-0R3 q"
                  using A30 nat_1_th_13 sorry
              qed
              show " ?thesis "
                using cases case1 case2 case3 sorry
            qed
          qed
          thus " ?thesis "
             sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for i1 be objectHIDDENM1 holds  for i2 be objectHIDDENM1 holds (i1 inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) & i2 inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)) & p .FUNCT-1K1 i1 =COMPLEX1R1 p .FUNCT-1K1 i2 implies i1 =HIDDENR1 i2"
    proof-
      have " for i1 be objectHIDDENM1 holds  for i2 be objectHIDDENM1 holds i1 inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) & (i2 inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) & p .FUNCT-1K1 i1 =COMPLEX1R1 p .FUNCT-1K1 i2) implies i1 =HIDDENR1 i2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        fix i1 assume [ty]: "i1 be objectHIDDENM1"
        fix i2 assume [ty]: "i2 be objectHIDDENM1"
        assume A31: "i1 inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
          and A32: "i2 inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
          and A33: "p .FUNCT-1K1 i1 =COMPLEX1R1 p .FUNCT-1K1 i2"
        have 
          [ty]:"i1 be ElementSUBSET-1M1-of NATNUMBERSK1"
          using A31 sorry
        have A34: "p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i1 =COMPLEX1R1 p .SUPINF-2K15 i1"
          using A6 A31 partfun1_def_6 sorry
        have 
          [ty]:"i2 be ElementSUBSET-1M1-of NATNUMBERSK1"
          using A32 sorry
        have A35: "p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i2 =COMPLEX1R1 p .SUPINF-2K15 i2"
          using A6 A32 partfun1_def_6 sorry
        show "i1 =HIDDENR1 i2"
        proof-
          have cases: "(p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i1 =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M or p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i1 <>HIDDENR2 n +NAT-1K1 \<one>\<^sub>M & p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i1 <XXREAL-0R3 q) or p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i1 <>HIDDENR2 n +NAT-1K1 \<one>\<^sub>M & p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i1 >=XXREAL-0R2 q"
             sorry
          have case1: "p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i1 =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M implies i1 =HIDDENR1 i2"
          proof(rule impI)
            assume A36: "p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i1 =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
            then have "i1 =COMPLEX1R1 q"
              using A8 A31 sorry
            thus "i1 =HIDDENR1 i2"
              using A8 A32 A33 A34 A35 A36 sorry
          qed
          have case2: "p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i1 <>HIDDENR2 n +NAT-1K1 \<one>\<^sub>M & p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i1 <XXREAL-0R3 q implies i1 =HIDDENR1 i2"
          proof(rule impI)
            assume A37: "p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i1 <>HIDDENR2 n +NAT-1K1 \<one>\<^sub>M & p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i1 <XXREAL-0R3 q"
            then have "i1 <XXREAL-0R3 q"
              using A26 A31 sorry
            then have A38: "p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i1 =COMPLEX1R1 i1"
              using A7 A31 sorry
            have "i2 <XXREAL-0R3 q"
              using A26 A32 A33 A34 A35 A37 sorry
            thus "i1 =HIDDENR1 i2"
              using A7 A32 A33 A34 A35 A38 sorry
          qed
          have case3: "p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i1 <>HIDDENR2 n +NAT-1K1 \<one>\<^sub>M & p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i1 >=XXREAL-0R2 q implies i1 =HIDDENR1 i2"
          proof(rule impI)
            assume A39: "p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i1 <>HIDDENR2 n +NAT-1K1 \<one>\<^sub>M & p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i1 >=XXREAL-0R2 q"
            then have A40: "i1 <>HIDDENR2 q"
              using A8 A31 sorry
            have "i1 >=XXREAL-0R2 q"
              using A26 A31 A39 sorry
            then have "i1 >XXREAL-0R4 q"
              using A40 xxreal_0_th_1 sorry
            then have A41: "p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i1 =COMPLEX1R1 i1 -XCMPLX-0K6 \<one>\<^sub>M"
              using A7 A31 sorry
            have A42: "i2 <>HIDDENR2 q"
              using A8 A32 A33 A34 A35 A39 sorry
            have "i2 >=XXREAL-0R2 q"
              using A26 A32 A33 A34 A35 A39 sorry
            then have "i2 >XXREAL-0R4 q"
              using A42 xxreal_0_th_1 sorry
            then have "p /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i2 =COMPLEX1R1 i2 -XCMPLX-0K6 \<one>\<^sub>M"
              using A7 A32 sorry
            thus "i1 =HIDDENR1 i2"
              using A6 A32 A33 A34 A41 partfun1_def_6 xcmplx_1_th_19 sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have "p be one-to-oneFUNCT-1V2"
      using A6 funct_1_def_4 sorry
    then have 
      [ty]:"p be PermutationFUNCT-2M2-of SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
      using A24 A25 funct_2_th_57 sorry
    show " ex tVar9 be PermutationFUNCT-2M2-of SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) st  for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (i inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) &  not (( not ( not i <XXREAL-0R3 q &  not tVar9 .FUNCT-1K1 i =XBOOLE-0R4 i) &  not (i =COMPLEX1R1 q &  not tVar9 .FUNCT-1K1 i =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M)) &  not ( not i >XXREAL-0R4 q &  not tVar9 .FUNCT-1K1 i =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M)))"
    proof(rule bexI[of _ "p"])
      show " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (i inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) &  not (( not ( not i <XXREAL-0R3 q &  not p .FUNCT-1K1 i =XBOOLE-0R4 i) &  not (i =COMPLEX1R1 q &  not p .FUNCT-1K1 i =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M)) &  not ( not i >XXREAL-0R4 q &  not p .FUNCT-1K1 i =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M)))"
        using A11 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma extreal1_lm_4:
" for n be NatNAT-1M1 holds  for q be NatNAT-1M1 holds  for s be PermutationFUNCT-2M2-of SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) holds  for p be PermutationFUNCT-2M2-of SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) holds  for s9 be FinSequenceFINSEQ-1M3-of SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) holds (s9 =FUNCT-1R1 s & q =XBOOLE-0R4 s .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies ((i <XXREAL-0R3 q implies p .FUNCT-1K1 i =XBOOLE-0R4 i) & (i =COMPLEX1R1 q implies p .FUNCT-1K1 i =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M)) & (i >XXREAL-0R4 q implies p .FUNCT-1K1 i =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M)) implies p *PARTFUN1K1\<^bsub>(NATNUMBERSK1,SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> s9  |FINSEQ-1K18\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> n be PermutationFUNCT-2M2-of SegFINSEQ-1K2 n"
proof-
  have " for n be NatNAT-1M1 holds  for q be NatNAT-1M1 holds  for s be PermutationFUNCT-2M2-of SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) holds  for p be PermutationFUNCT-2M2-of SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) holds  for s9 be FinSequenceFINSEQ-1M3-of SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) holds s9 =FUNCT-1R1 s & (q =XBOOLE-0R4 s .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies ((i <XXREAL-0R3 q implies p .FUNCT-1K1 i =XBOOLE-0R4 i) & (i =COMPLEX1R1 q implies p .FUNCT-1K1 i =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M)) & (i >XXREAL-0R4 q implies p .FUNCT-1K1 i =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M))) implies p *PARTFUN1K1\<^bsub>(NATNUMBERSK1,SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> s9  |FINSEQ-1K18\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> n be PermutationFUNCT-2M2-of SegFINSEQ-1K2 n"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix q assume [ty]: "q be NatNAT-1M1"
    fix s assume [ty]: "s be PermutationFUNCT-2M2-of SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
    fix p assume [ty]: "p be PermutationFUNCT-2M2-of SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
    fix s9 assume [ty]: "s9 be FinSequenceFINSEQ-1M3-of SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
    assume A1: "s9 =FUNCT-1R1 s"
      and A2: "q =XBOOLE-0R4 s .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
      and A3: " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies ((i <XXREAL-0R3 q implies p .FUNCT-1K1 i =XBOOLE-0R4 i) & (i =COMPLEX1R1 q implies p .FUNCT-1K1 i =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M)) & (i >XXREAL-0R4 q implies p .FUNCT-1K1 i =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M)"
    have A4: "domRELSET-1K1\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> p =XBOOLE-0R4 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
      using funct_2_def_1 sorry
    obtain r where 
      [ty]:"r be FinSequenceFINSEQ-1M3-of SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)" and rDef:"r = p *PARTFUN1K1\<^bsub>(NATNUMBERSK1,SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> s9  |FINSEQ-1K18\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> n"
      using finseq_2_th_32 sorry
    have A5: "0NUMBERSK6 +XCMPLX-0K2 n <=XXREAL-3R1 \<one>\<^sub>M +XCMPLX-0K2 n"
      using xreal_1_th_6 sorry
    then have A6: "SegFINSEQ-1K2 n c=TARSKIR1 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
      using finseq_1_th_5 sorry
    have "s9  |FINSEQ-1K18\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> n =RELSET-1R2\<^bsub>(NATNUMBERSK1,SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> s9  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> SegFINSEQ-1K2 n"
      using finseq_1_def_15 sorry
    then have A7: "s9  |FINSEQ-1K18\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> n be one-to-oneFUNCT-1V2"
      using A1 funct_1_th_52 sorry
    have A8: "rngRELSET-1K2\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> p =XBOOLE-0R4 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
      using funct_2_def_3 sorry
    have A9: "domRELSET-1K1\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> s =XBOOLE-0R4 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
      using funct_2_def_1 sorry
    then have "lenFINSEQ-1K4 s9 =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
      using A1 finseq_1_def_3 sorry
    then have "lenFINSEQ-1K4 (s9  |FINSEQ-1K18\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> n) =COMPLEX1R1 n"
      using A5 finseq_1_th_59 sorry
    then have "lenFINSEQ-1K4 r =COMPLEX1R1 n"
      using finseq_2_th_33 sorry
    then have A10: "domFINSEQ-1K5 r =XBOOLE-0R4 SegFINSEQ-1K2 n"
      using finseq_1_def_3 sorry
    have A11: "rngRELSET-1K2\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> s =XBOOLE-0R4 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
      using funct_2_def_3 sorry
    then have "q inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
      using A2 A9 finseq_1_th_4 funct_1_th_3 sorry
    then have A12: "q <=XXREAL-3R1 n +NAT-1K1 \<one>\<^sub>M"
      using finseq_1_th_1 sorry
    have " for i be objectHIDDENM1 holds i inHIDDENR3 rngRELSET-1K2\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> r iff i inHIDDENR3 SegFINSEQ-1K2 n"
    proof-
      have " for i be objectHIDDENM1 holds (i inHIDDENR3 rngRELSET-1K2\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> r implies i inHIDDENR3 SegFINSEQ-1K2 n) & (i inHIDDENR3 SegFINSEQ-1K2 n implies i inHIDDENR3 rngRELSET-1K2\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> r)"
      proof(rule ballI,rule conjMI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        show "i inHIDDENR3 rngRELSET-1K2\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> r implies i inHIDDENR3 SegFINSEQ-1K2 n"
        proof(rule impI)
          assume "i inHIDDENR3 rngRELSET-1K2\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> r"
          then obtain j where
            [ty]:"j be objectHIDDENM1" and 
            A13: "j inHIDDENR3 SegFINSEQ-1K2 n"and A14: "r .FUNCT-1K1 j =HIDDENR1 i"
            using A10 funct_1_def_3 sorry
          have 
            [ty]:"j be ElementSUBSET-1M1-of NATNUMBERSK1"
            using A13 sorry
          have A15: "j <=XXREAL-3R1 n"
            using A13 finseq_1_th_1 sorry
          then have A16: "(s9  |FINSEQ-1K18\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> n).FUNCT-1K1 j =XBOOLE-0R4 s .FUNCT-1K1 j"
            using A1 finseq_3_th_112 sorry
          then have A17: "i =HIDDENR1 p .FUNCT-1K1 (s .FUNCT-1K1 j)"
            using A10 A13 A14 funct_1_th_12 sorry
          have "s .FUNCT-1K1 j inTARSKIR2 domRELSET-1K1\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> p"
            using A9 A11 A4 A6 A13 funct_1_th_3 sorry
          then have A18: "p .FUNCT-1K1 (s .FUNCT-1K1 j) inTARSKIR2 rngRELSET-1K2\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> p"
            using funct_1_th_3 sorry
          then have 
            [ty]:"i be ElementSUBSET-1M1-of NATNUMBERSK1"
            using A8 A10 A13 A14 A16 funct_1_th_12 sorry
          have A19: "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domRELSET-1K1\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> s"
            using A9 finseq_1_th_4 sorry
          have A20: "s .FUNCT-1K1 j inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
            using A9 A11 A6 A13 funct_1_th_3 sorry
          then obtain q1 where 
            [ty]:"q1 be ElementSUBSET-1M1-of NATNUMBERSK1" and q1Def:"q1 = s .FUNCT-1K1 j"
             sorry
          have "j <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
            using A15 nat_1_th_13 sorry
          then have A21: "q1 <>HIDDENR2 q"
            using A2 A9 A6 A13 A19 funct_1_def_4 sorry
          show "i inHIDDENR3 SegFINSEQ-1K2 n"
          proof-
            have cases: "q1 <XXREAL-0R3 q or q1 >XXREAL-0R4 q"
              using A21 xxreal_0_th_1 sorry
            have case1: "q1 <XXREAL-0R3 q implies i inHIDDENR3 SegFINSEQ-1K2 n"
            proof(rule impI)
              assume "q1 <XXREAL-0R3 q"
              then have "i <XXREAL-0R3 q"
                using A3 A17 A20 sorry
              then have "i <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
                using A12 xxreal_0_th_2 sorry
              then have A22: "i <=XXREAL-3R1 n"
                using nat_1_th_13 sorry
              have "\<one>\<^sub>M <=XXREAL-3R1 i"
                using A17 A18 finseq_1_th_1 sorry
              thus "i inHIDDENR3 SegFINSEQ-1K2 n"
                using A22 finseq_1_th_1 sorry
            qed
            have case2: "q1 >XXREAL-0R4 q implies i inHIDDENR3 SegFINSEQ-1K2 n"
            proof(rule impI)
              assume A23: "q1 >XXREAL-0R4 q"
              have A24: "q1 <=XXREAL-3R1 n +NAT-1K1 \<one>\<^sub>M"
                using A20 finseq_1_th_1 sorry
              have "i =COMPLEX1R1 q1 -XCMPLX-0K6 \<one>\<^sub>M"
                using A3 A17 A20 A23 sorry
              then have A25: "i <=XXREAL-3R1 n"
                using A24 xreal_1_th_20 sorry
              have "\<one>\<^sub>M <=XXREAL-3R1 i"
                using A17 A18 finseq_1_th_1 sorry
              thus "i inHIDDENR3 SegFINSEQ-1K2 n"
                using A25 finseq_1_th_1 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        assume A26: "i inHIDDENR3 SegFINSEQ-1K2 n"
        then have 
          [ty]:"i be ElementSUBSET-1M1-of NATNUMBERSK1"
           sorry
        show "i inHIDDENR3 rngRELSET-1K2\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> r"
        proof-
          have cases: "i <XXREAL-0R3 q or i >=XXREAL-0R2 q"
             sorry
          have case1: "i <XXREAL-0R3 q implies i inHIDDENR3 rngRELSET-1K2\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> r"
          proof(rule impI)
            assume A27: "i <XXREAL-0R3 q"
            then have A28: "p .FUNCT-1K1 i =XBOOLE-0R4 i"
              using A3 A6 A26 sorry
            obtain j where
              [ty]:"j be objectHIDDENM1" and 
              A29: "j inHIDDENR3 domRELSET-1K1\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> s"and A30: "i =XBOOLE-0R4 s .FUNCT-1K1 j"
              using A11 A6 A26 funct_1_def_3 sorry
            have "j inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
              using A29 sorry
            then have 
              [ty]:"j be ElementSUBSET-1M1-of NATNUMBERSK1"
               sorry
            have "j <=XXREAL-3R1 n +NAT-1K1 \<one>\<^sub>M"
              using A29 finseq_1_th_1 sorry
            then have "j <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
              using A2 A27 A30 xxreal_0_th_1 sorry
            then have A31: "j <=XXREAL-3R1 n"
              using nat_1_th_13 sorry
            have "\<one>\<^sub>M <=XXREAL-3R1 j"
              using A29 finseq_1_th_1 sorry
            then have A32: "j inTARSKIR2 domFINSEQ-1K5 r"
              using A10 A31 finseq_1_th_1 sorry
            have "(s9  |FINSEQ-1K18\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> n).FUNCT-1K1 j =XBOOLE-0R4 s .FUNCT-1K1 j"
              using A1 A31 finseq_3_th_112 sorry
            then have "r .FUNCT-1K1 j =XBOOLE-0R4 i"
              using A28 A30 A32 funct_1_th_12 sorry
            thus "i inHIDDENR3 rngRELSET-1K2\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> r"
              using A32 funct_1_th_3 sorry
          qed
          have case2: "i >=XXREAL-0R2 q implies i inHIDDENR3 rngRELSET-1K2\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> r"
          proof(rule impI)
            assume A33: "i >=XXREAL-0R2 q"
            have "i <=XXREAL-3R1 n"
              using A26 finseq_1_th_1 sorry
            then have A34: "i +NAT-1K1 \<one>\<^sub>M <=XXREAL-3R1 n +NAT-1K1 \<one>\<^sub>M"
              using xreal_1_th_6 sorry
            have "\<one>\<^sub>M <=XXREAL-3R1 i +NAT-1K1 \<one>\<^sub>M"
              using nat_1_th_12 sorry
            then have A35: "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
              using A34 finseq_1_th_1 sorry
            then obtain j where
              [ty]:"j be objectHIDDENM1" and 
              A36: "j inHIDDENR3 domRELSET-1K1\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> s"and A37: "i +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 s .FUNCT-1K1 j"
              using A11 funct_1_def_3 sorry
            have "j inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
              using A36 sorry
            then have 
              [ty]:"j be ElementSUBSET-1M1-of NATNUMBERSK1"
               sorry
            have A38: "j <=XXREAL-3R1 n +NAT-1K1 \<one>\<^sub>M"
              using A36 finseq_1_th_1 sorry
            have "j <>HIDDENR2 n +NAT-1K1 \<one>\<^sub>M"
              using A2 A33 A37 nat_1_th_13 sorry
            then have "j <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
              using A38 xxreal_0_th_1 sorry
            then have A39: "j <=XXREAL-3R1 n"
              using nat_1_th_13 sorry
            have "\<one>\<^sub>M <=XXREAL-3R1 j"
              using A36 finseq_1_th_1 sorry
            then have A40: "j inTARSKIR2 SegFINSEQ-1K2 n"
              using A39 finseq_1_th_1 sorry
            have "i +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 q"
              using A33 nat_1_th_13 sorry
            then have A41: "p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (i +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
              using A3 A35 sorry
            also have "... = i"
               sorry
            finally have "p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 i"
               sorry
            have "(s9  |FINSEQ-1K18\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> n).FUNCT-1K1 j =XBOOLE-0R4 s .FUNCT-1K1 j"
              using A1 A39 finseq_3_th_112 sorry
            then have "r .FUNCT-1K1 j =XBOOLE-0R4 p .FUNCT-1K1 (s .FUNCT-1K1 j)"
              using A10 A40 funct_1_th_12 sorry
            thus "i inHIDDENR3 rngRELSET-1K2\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> r"
              using A10 A37 A41 A40 funct_1_th_3 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have A42: "rngRELSET-1K2\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> r =XBOOLE-0R4 SegFINSEQ-1K2 n"
      using tarski_th_2 sorry
    then have "p *PARTFUN1K1\<^bsub>(NATNUMBERSK1,SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> s9  |FINSEQ-1K18\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> n be FunctionFUNCT-2M1-of(SegFINSEQ-1K2 n,SegFINSEQ-1K2 n)"
      using A10 funct_2_th_1 sorry
    thus "p *PARTFUN1K1\<^bsub>(NATNUMBERSK1,SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> s9  |FINSEQ-1K18\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> n be PermutationFUNCT-2M2-of SegFINSEQ-1K2 n"
      using A42 A7 funct_2_th_57 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma extreal1_lm_5:
" for n be NatNAT-1M1 holds  for q be NatNAT-1M1 holds  for p be PermutationFUNCT-2M2-of SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) holds  for F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  for H be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds (((F =FUNCT-1R1 H *PARTFUN1K1\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> p & q inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)) & lenFINSEQ-1K4 H =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M) &  not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> H) & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies ((i <XXREAL-0R3 q implies p .FUNCT-1K1 i =XBOOLE-0R4 i) & (i =COMPLEX1R1 q implies p .FUNCT-1K1 i =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M)) & (i >XXREAL-0R4 q implies p .FUNCT-1K1 i =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M)) implies SumEXTREAL1K4 F =XBOOLE-0R4 SumEXTREAL1K4 H"
proof-
  have " for n be NatNAT-1M1 holds  for q be NatNAT-1M1 holds  for p be PermutationFUNCT-2M2-of SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) holds  for F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  for H be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds F =FUNCT-1R1 H *PARTFUN1K1\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> p & (q inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) & (lenFINSEQ-1K4 H =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M & ( not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> H & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies ((i <XXREAL-0R3 q implies p .FUNCT-1K1 i =XBOOLE-0R4 i) & (i =COMPLEX1R1 q implies p .FUNCT-1K1 i =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M)) & (i >XXREAL-0R4 q implies p .FUNCT-1K1 i =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M))))) implies SumEXTREAL1K4 F =HIDDENR1 SumEXTREAL1K4 H"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix q assume [ty]: "q be NatNAT-1M1"
    fix p assume [ty]: "p be PermutationFUNCT-2M2-of SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
    fix F assume [ty]: "F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3"
    fix H assume [ty]: "H be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3"
    assume A1: "F =FUNCT-1R1 H *PARTFUN1K1\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> p"
      and A2: "q inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
      and A3: "lenFINSEQ-1K4 H =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
      and A4: " not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> H"
      and A5: " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies ((i <XXREAL-0R3 q implies p .FUNCT-1K1 i =XBOOLE-0R4 i) & (i =COMPLEX1R1 q implies p .FUNCT-1K1 i =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M)) & (i >XXREAL-0R4 q implies p .FUNCT-1K1 i =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M)"
    have A6: "\<one>\<^sub>M <=XXREAL-3R1 q"
      using A2 finseq_1_th_1 sorry
    then have "q -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
      using xreal_1_th_9 sorry
    then have A7: "q -'NAT-DK9 \<one>\<^sub>M =COMPLEX1R1 q -XCMPLX-0K6 \<one>\<^sub>M"
      using xreal_0_def_2 sorry
    let ?H1 = "H  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n"
    have A8: "?H1 =FINSEQ-1R1 ?H1  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M) ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (?H1 /^RFINSEQK2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M))"
      using rfinseq_th_8 sorry
    obtain p9 where 
      [ty]:"p9 be FinSequenceFINSEQ-1M3-of SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)" and p9Def:"p9 = p"
      using finseq_2_th_25 sorry
    have "domRELSET-1K1\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> p =XBOOLE-0R4 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
      using funct_2_def_1 sorry
    then have A9: "lenFINSEQ-1K4 p9 =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
      using finseq_1_def_3 sorry
    have A10: "q <=XXREAL-3R1 n +NAT-1K1 \<one>\<^sub>M"
      using A2 finseq_1_th_1 sorry
    then have A11: "q -'NAT-DK9 \<one>\<^sub>M <=XXREAL-3R1 (n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
      using A7 xreal_1_th_9 sorry
    have A12: "domFINSEQ-1K5 H =XBOOLE-0R4 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
      using A3 finseq_1_def_3 sorry
    then have "H be FunctionFUNCT-2M1-of(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),ExtREALXXREAL-0K3)"
      using finseq_2_th_26 sorry
    then have A13: "lenFINSEQ-1K4 F =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
      using A1 A9 finseq_2_th_33 sorry
    then have A14: "lenFINSEQ-1K4 (F /^RFINSEQK2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> q) =COMPLEX1R1 (n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 q"
      using A10 rfinseq_def_1 sorry
    have A15: "n <=XXREAL-3R1 n +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_11 sorry
    then have A16: "lenFINSEQ-1K4 (F  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M)) =COMPLEX1R1 q -'NAT-DK9 \<one>\<^sub>M"
      using A11 A13 finseq_1_th_59 xxreal_0_th_2 sorry
    have A17: "domFINSEQ-1K5 F =XBOOLE-0R4 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
      using A13 finseq_1_def_3 sorry
    have A18: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-3R1 i & i <=XXREAL-3R1 q -'NAT-DK9 \<one>\<^sub>M implies (F  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M)).SUPINF-2K15 i =XBOOLE-0R4 (?H1  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M)).SUPINF-2K15 i"
    proof-
      have " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-3R1 i & i <=XXREAL-3R1 q -'NAT-DK9 \<one>\<^sub>M implies (F  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M)).SUPINF-2K15 i =XBOOLE-0R4 ((H  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n) |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M)).SUPINF-2K15 i"
      proof(rule ballI,rule impMI ,rule impI)
        fix i assume [ty]: "i be NatNAT-1M1"
        assume A19: "\<one>\<^sub>M <=XXREAL-3R1 i"
          and A20: "i <=XXREAL-3R1 q -'NAT-DK9 \<one>\<^sub>M"
        have A21: "(F  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M)).SUPINF-2K15 i =XBOOLE-0R4 F .SUPINF-2K15 i"
          using A20 finseq_3_th_112 sorry
        have A22: "?H1 .SUPINF-2K15 i =XBOOLE-0R4 H .SUPINF-2K15 i"
          using A11 A20 finseq_3_th_112 xxreal_0_th_2 sorry
        have A23: "(?H1  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M)).SUPINF-2K15 i =XBOOLE-0R4 ?H1 .SUPINF-2K15 i"
          using A20 finseq_3_th_112 sorry
        have A24: "i <XXREAL-0R3 (q -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
          using A20 nat_1_th_13 sorry
        have "i <=XXREAL-3R1 n"
          using A11 A20 xxreal_0_th_2 sorry
        then have "i <=XXREAL-3R1 n +NAT-1K1 \<one>\<^sub>M"
          using A15 xxreal_0_th_2 sorry
        then have A25: "i inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
          using A19 finseq_1_th_1 sorry
        then have "F .SUPINF-2K15 i =XBOOLE-0R4 H .SUPINF-2K15 (p .FUNCT-1K1 i)"
          using A1 A17 funct_1_th_12 sorry
        thus "(F  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M)).SUPINF-2K15 i =XBOOLE-0R4 ((H  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n) |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M)).SUPINF-2K15 i"
          using A5 A7 A21 A23 A22 A25 A24 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "0NUMBERSK6 +XCMPLX-0K2 n <=XXREAL-3R1 \<one>\<^sub>M +XCMPLX-0K2 n"
      using xreal_1_th_6 sorry
    then have A26: "lenFINSEQ-1K4 ?H1 =COMPLEX1R1 n"
      using A3 finseq_1_th_59 sorry
    then have A27: "lenFINSEQ-1K4 (?H1  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M)) =COMPLEX1R1 q -'NAT-DK9 \<one>\<^sub>M"
      using A11 finseq_1_th_59 sorry
    have A28: "lenFINSEQ-1K4 (?H1 /^RFINSEQK2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M)) =COMPLEX1R1 n -XCMPLX-0K6 (q -XCMPLX-0K6 \<one>\<^sub>M)"
      using A7 A11 A26 rfinseq_def_1 sorry
    have " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-3R1 i & i <=XXREAL-3R1 (n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 q implies (F /^RFINSEQK2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> q).SUPINF-2K15 i =XBOOLE-0R4 (?H1 /^RFINSEQK2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M)).SUPINF-2K15 i"
    proof-
      have " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-3R1 i & i <=XXREAL-3R1 (n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 q implies (F /^RFINSEQK2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> q).SUPINF-2K15 i =XBOOLE-0R4 (H  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n /^RFINSEQK2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M)).SUPINF-2K15 i"
      proof(rule ballI,rule impMI ,rule impI)
        obtain n1 where 
          [ty]:"n1 be ElementSUBSET-1M1-of NATNUMBERSK1" and n1Def:"n1 = (n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 q"
          using A10 int_1_th_5 sorry
        fix i assume [ty]: "i be NatNAT-1M1"
        assume A29: "\<one>\<^sub>M <=XXREAL-3R1 i"
          and A30: "i <=XXREAL-3R1 (n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 q"
        have A31: "i +XCMPLX-0K2 q <=XXREAL-3R1 n +NAT-1K1 \<one>\<^sub>M"
          using A30 xreal_1_th_19 sorry
        have A32: "i inTARSKIR2 SegFINSEQ-1K2 n1"
          using A29 A30 finseq_1_th_1 sorry
        then have "i inTARSKIR2 domFINSEQ-1K5 (?H1 /^RFINSEQK2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M))"
          using A28 finseq_1_def_3 sorry
        then have A33: "(?H1 /^RFINSEQK2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M)).SUPINF-2K15 i =XBOOLE-0R4 ?H1 .SUPINF-2K15 (i +NAT-1K1 (q -'NAT-DK9 \<one>\<^sub>M))"
          using A11 A26 rfinseq_def_1 sorry
        have "i +NAT-1K1 (q -'NAT-DK9 \<one>\<^sub>M) =COMPLEX1R1 (i +XCMPLX-0K2 q)-XCMPLX-0K6 \<one>\<^sub>M"
          using A7 sorry
        then have "i +NAT-1K1 (q -'NAT-DK9 \<one>\<^sub>M) <=XXREAL-3R1 n"
          using A31 xreal_1_th_20 sorry
        then have A34: "(?H1 /^RFINSEQK2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M)).SUPINF-2K15 i =XBOOLE-0R4 H .SUPINF-2K15 ((i +XCMPLX-0K2 q)-XCMPLX-0K6 \<one>\<^sub>M)"
          using A7 A33 finseq_3_th_112 sorry
        have A35: "\<one>\<^sub>M <=XXREAL-3R1 i +XCMPLX-0K2 q"
          using A29 nat_1_th_12 sorry
        then have "i +XCMPLX-0K2 q inTARSKIR2 domFINSEQ-1K5 F"
          using A17 A31 finseq_1_th_1 sorry
        then have A36: "F .SUPINF-2K15 (i +XCMPLX-0K2 q) =XBOOLE-0R4 H .SUPINF-2K15 (p .FUNCT-1K1 (i +XCMPLX-0K2 q))"
          using A1 funct_1_th_12 sorry
        have "domFINSEQ-1K5 (F /^RFINSEQK2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> q) =XBOOLE-0R4 SegFINSEQ-1K2 n1"
          using A14 finseq_1_def_3 sorry
        then have A37: "(F /^RFINSEQK2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> q).SUPINF-2K15 i =XBOOLE-0R4 F .SUPINF-2K15 (i +XCMPLX-0K2 q)"
          using A10 A13 A32 rfinseq_def_1 sorry
        have "i +XCMPLX-0K2 q >=XXREAL-0R2 \<one>\<^sub>M +XCMPLX-0K2 q"
          using A29 xreal_1_th_6 sorry
        then have A38: "i +XCMPLX-0K2 q >XXREAL-0R4 q"
          using nat_1_th_13 sorry
        have "i +XCMPLX-0K2 q inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
          using A31 A35 finseq_1_th_1 sorry
        thus "(F /^RFINSEQK2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> q).SUPINF-2K15 i =XBOOLE-0R4 (H  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n /^RFINSEQK2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M)).SUPINF-2K15 i"
          using A5 A37 A34 A36 A38 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have A39: "F /^RFINSEQK2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> q =FINSEQ-1R1 ?H1 /^RFINSEQK2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M)"
      using A14 A28 finseq_1_th_14 sorry
    have A40: "F =FINSEQ-1R1 (F  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M) ^FINSEQ-1K9\<^bsub>(ExtREALNUMBERSK7)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALNUMBERSK7)\<^esub> F .SUPINF-2K15 q*>))^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (F /^RFINSEQK2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> q)"
      using A6 A10 A13 finseq_5_th_84 sorry
    then have A41: "rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(ExtREALNUMBERSK7)\<^esub> (F  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M) ^FINSEQ-1K9\<^bsub>(ExtREALNUMBERSK7)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALNUMBERSK7)\<^esub> F .SUPINF-2K15 q*>)) \\/SUBSET-1K4\<^bsub>(ExtREALXXREAL-0K3)\<^esub> rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (F /^RFINSEQK2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> q)"
      using finseq_1_th_31 sorry
    have "p .FUNCT-1K1 q =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
      using A2 A5 sorry
    then have A42: "F .SUPINF-2K15 q =XBOOLE-0R4 H .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M)"
      using A1 A2 A17 funct_1_th_12 sorry
    have A43: "?H1 =RELSET-1R2\<^bsub>(NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> H  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> SegFINSEQ-1K2 n"
      using finseq_1_def_15 sorry
    then have "rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> ?H1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> H"
      using relat_1_th_70 sorry
    then have " not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> ?H1"
      using A4 sorry
    then have A44: " not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (?H1  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M)) \\/SUBSET-1K4\<^bsub>(ExtREALXXREAL-0K3)\<^esub> rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (?H1 /^RFINSEQK2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M))"
      using A8 finseq_1_th_31 sorry
    then have A45: " not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (?H1  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M))"
      using xboole_0_def_3 sorry
    have A46: " not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F"
      using A1 A4 funct_1_th_14 sorry
    then have A47: " not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALNUMBERSK7)\<^esub> (F  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M) ^FINSEQ-1K9\<^bsub>(ExtREALNUMBERSK7)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALNUMBERSK7)\<^esub> F .SUPINF-2K15 q*>))"
      using A41 xboole_0_def_3 sorry
    then have A48: " not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (F  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M)) \\/SUBSET-1K4\<^bsub>(ExtREALNUMBERSK7)\<^esub> rngRELSET-1K2\<^bsub>(ExtREALNUMBERSK7)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALNUMBERSK7)\<^esub> F .SUPINF-2K15 q*>)"
      using finseq_1_th_31 sorry
    then have " not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (F  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M))"
      using xboole_0_def_3 sorry
    then have A49: "SumEXTREAL1K4 (F  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M)) <>HIDDENR2 -inftySUPINF-1K2"
      using extreal1_lm_2 sorry
    have " not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALNUMBERSK7)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALNUMBERSK7)\<^esub> F .SUPINF-2K15 q*>)"
      using A48 xboole_0_def_3 sorry
    then have " not -inftySUPINF-1K2 inTARSKIR2 {DOMAIN-1K6\<^bsub>(ExtREALNUMBERSK7)\<^esub> F .SUPINF-2K15 q }"
      using finseq_1_th_39 sorry
    then have A50: "-inftySUPINF-1K2 <>HIDDENR2 F .SUPINF-2K15 q"
      using tarski_def_1 sorry
    have A51: " not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (F /^RFINSEQK2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> q)"
      using A46 A41 xboole_0_def_3 sorry
    then have A52: "SumEXTREAL1K4 (F /^RFINSEQK2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> q) <>HIDDENR2 -inftySUPINF-1K2"
      using extreal1_lm_2 sorry
    have A53: "H  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =RELSET-1R2\<^bsub>(NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> H  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
      using finseq_1_def_15 sorry
    have "H  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 H"
      using A3 finseq_1_th_58 sorry
    then have A54: "H =FINSEQ-1R1 ?H1 ^FINSEQ-1K9\<^bsub>(ExtREALNUMBERSK7)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALNUMBERSK7)\<^esub> H .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M)*>)"
      using A12 A43 A53 finseq_1_th_4 finseq_5_th_10 sorry
    have A55: " not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (?H1 /^RFINSEQK2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M))"
      using A44 xboole_0_def_3 sorry
    have "SumEXTREAL1K4 F =HIDDENR1 SumEXTREAL1K4 (F  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M) ^FINSEQ-1K9\<^bsub>(ExtREALNUMBERSK7)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALNUMBERSK7)\<^esub> F .SUPINF-2K15 q*>)) +SUPINF-2K4 SumEXTREAL1K4 (F /^RFINSEQK2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> q)"
      using A40 A47 A51 extreal1_th_10 sorry
    also have "... = (SumEXTREAL1K4 (F  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M)) +SUPINF-2K4 F .SUPINF-2K15 q)+SUPINF-2K4 SumEXTREAL1K4 (F /^RFINSEQK2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> q)"
      using extreal1_lm_1 sorry
    also have "... = (SumEXTREAL1K4 (F  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M)) +SUPINF-2K4 SumEXTREAL1K4 (F /^RFINSEQK2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> q))+SUPINF-2K4 F .SUPINF-2K15 q"
      using A50 A49 A52 xxreal_3_th_29 sorry
    also have "... = (SumEXTREAL1K4 ((H  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n) |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M)) +SUPINF-2K4 SumEXTREAL1K4 (H  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n /^RFINSEQK2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (q -'NAT-DK9 \<one>\<^sub>M)))+SUPINF-2K4 H .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M)"
      using A16 A27 A18 A42 A39 finseq_1_th_14 sorry
    also have "... = SumEXTREAL1K4 (H  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n) +SUPINF-2K4 H .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M)"
      using A8 A45 A55 extreal1_th_10 sorry
    also have "... = SumEXTREAL1K4 H"
      using A54 extreal1_lm_1 sorry
    finally show "SumEXTREAL1K4 F =HIDDENR1 SumEXTREAL1K4 H"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem extreal1_th_11:
" for F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  for G be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  for s be PermutationFUNCT-2M2-of domFINSEQ-1K5 F holds G =FUNCT-1R1 F *PARTFUN1K1\<^bsub>(domFINSEQ-1K5 F,domFINSEQ-1K5 F,NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> s &  not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F implies SumEXTREAL1K4 F =XBOOLE-0R4 SumEXTREAL1K4 G"
proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix F assume [ty]: "F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3"
  fix G assume [ty]: "G be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3"
  fix s assume [ty]: "s be PermutationFUNCT-2M2-of domFINSEQ-1K5 F"
  let ?P = "\<lambda>Lamb1.  for F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  for G be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  for s be PermutationFUNCT-2M2-of SegFINSEQ-1K2 Lamb1 holds (lenFINSEQ-1K4 F =COMPLEX1R1 Lamb1 & G =FUNCT-1R1 F *PARTFUN1K1\<^bsub>(SegFINSEQ-1K2 Lamb1,SegFINSEQ-1K2 Lamb1,NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> s) &  not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F implies SumEXTREAL1K4 F =XBOOLE-0R4 SumEXTREAL1K4 G"
  have A1: "?P(0NUMBERSK6)"
  proof-
    have " for F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  for G be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  for s be PermutationFUNCT-2M2-of SegFINSEQ-1K2 (0NUMBERSK6) holds lenFINSEQ-1K4 F =COMPLEX1R1 0NUMBERSK6 & G =FINSEQ-1R1 F *PARTFUN1K1\<^bsub>(SegFINSEQ-1K2 (0NUMBERSK6),SegFINSEQ-1K2 (0NUMBERSK6),NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> s implies  not ( not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F &  not SumEXTREAL1K4 F =XBOOLE-0R4 SumEXTREAL1K4 G)"
    proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
      fix F assume [ty]: "F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3"
      fix G assume [ty]: "G be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3"
      fix s assume [ty]: "s be PermutationFUNCT-2M2-of SegFINSEQ-1K2 (0NUMBERSK6)"
      assume A2: "lenFINSEQ-1K4 F =COMPLEX1R1 0NUMBERSK6"
        and A3: "G =FINSEQ-1R1 F *PARTFUN1K1\<^bsub>(SegFINSEQ-1K2 (0NUMBERSK6),SegFINSEQ-1K2 (0NUMBERSK6),NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> s"
      have "F =FINSEQ-1R1 <*>FINSEQ-1K7 (ExtREALXXREAL-0K3)"
        using A2 sorry
      thus " not ( not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F &  not SumEXTREAL1K4 F =XBOOLE-0R4 SumEXTREAL1K4 G)"
        using A3 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have A4: " for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
  proof-
    have " for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds ( for F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  for G be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  for s be PermutationFUNCT-2M2-of SegFINSEQ-1K2 n holds (lenFINSEQ-1K4 F =COMPLEX1R1 n & G =FUNCT-1R1 F *PARTFUN1K1\<^bsub>(SegFINSEQ-1K2 n,SegFINSEQ-1K2 n,NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> s) &  not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F implies SumEXTREAL1K4 F =XBOOLE-0R4 SumEXTREAL1K4 G) implies ( for F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  for G be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  for s be PermutationFUNCT-2M2-of SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) holds (lenFINSEQ-1K4 F =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M & G =FUNCT-1R1 F *PARTFUN1K1\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> s) &  not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F implies SumEXTREAL1K4 F =XBOOLE-0R4 SumEXTREAL1K4 G)"
    proof(rule ballI,rule impI)
      fix n assume [ty]: "n be  non zeroORDINAL1V8\<bar>NatNAT-1M1"
      assume A5: "?P(n)"
      show " for F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  for G be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  for s be PermutationFUNCT-2M2-of SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) holds (lenFINSEQ-1K4 F =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M & G =FUNCT-1R1 F *PARTFUN1K1\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> s) &  not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F implies SumEXTREAL1K4 F =XBOOLE-0R4 SumEXTREAL1K4 G"
      proof-
        have " for F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  for G be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  for s be PermutationFUNCT-2M2-of SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) holds lenFINSEQ-1K4 F =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M & (G =FUNCT-1R1 F *PARTFUN1K1\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> s &  not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F) implies SumEXTREAL1K4 F =XBOOLE-0R4 SumEXTREAL1K4 G"
        proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
          fix F assume [ty]: "F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3"
          fix G assume [ty]: "G be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3"
          fix s assume [ty]: "s be PermutationFUNCT-2M2-of SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
          assume A6: "lenFINSEQ-1K4 F =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
            and A7: "G =FUNCT-1R1 F *PARTFUN1K1\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> s"
            and A8: " not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F"
          obtain s9 where 
            [ty]:"s9 be FinSequenceFINSEQ-1M3-of SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)" and s9Def:"s9 = s"
            using finseq_2_th_25 sorry
          have A9: "rngRELSET-1K2\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> s =XBOOLE-0R4 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
            using funct_2_def_3 sorry
          have A10: "domRELSET-1K1\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> s =XBOOLE-0R4 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
            using funct_2_def_1 sorry
          then have "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domRELSET-1K1\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> s"
            using finseq_1_th_4 sorry
          then have A11: "s .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
            using A9 funct_1_def_3 sorry
          then obtain q where 
            [ty]:"q be ElementSUBSET-1M1-of NATNUMBERSK1" and qDef:"q = s .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
             sorry
          obtain p where
            [ty]:"p be PermutationFUNCT-2M2-of SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)" and 
            A12: " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies ((i <XXREAL-0R3 q implies p .FUNCT-1K1 i =XBOOLE-0R4 i) & (i =COMPLEX1R1 q implies p .FUNCT-1K1 i =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M)) & (i >XXREAL-0R4 q implies p .FUNCT-1K1 i =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M)"
            using A11 extreal1_lm_3 sorry
          obtain p2 where 
            [ty]:"p2 be FinSequenceFINSEQ-1M3-of SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)" and p2Def:"p2 = p \<inverse>FUNCT-2K2\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub>"
            using finseq_2_th_25 sorry
          have A13: "domRELSET-1K1\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> p =XBOOLE-0R4 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
            using funct_2_def_1 sorry
          have "p .FUNCT-1K1 q =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
            using A11 A12 sorry
          then have A14: "F .SUPINF-2K15 (s .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 F .SUPINF-2K15 (p2 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
            using A11 A13 funct_1_th_34 sorry
          have A15: "0NUMBERSK6 +XCMPLX-0K2 n <=XXREAL-3R1 \<one>\<^sub>M +XCMPLX-0K2 n"
            using xreal_1_th_6 sorry
          then have A16: "SegFINSEQ-1K2 n c=TARSKIR1 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
            using finseq_1_th_5 sorry
          have A17: "domFINSEQ-1K5 F =XBOOLE-0R4 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
            using A6 finseq_1_def_3 sorry
          then have A18: "F be FunctionFUNCT-2M1-of(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),ExtREALXXREAL-0K3)"
            using finseq_2_th_26 sorry
          then obtain H where 
            [ty]:"H be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3" and HDef:"H = F *PARTFUN1K1\<^bsub>(NATNUMBERSK1,SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> p2"
            using finseq_2_th_32 sorry
          have A19: "H *PARTFUN1K1\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> p =HIDDENR1 F *PARTFUN1K1\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> (p2 *PARTFUN1K1\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),NATNUMBERSK1,SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> p)"
            using relat_1_th_36 sorry
          also have "... = F *PARTFUN1K1\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> idPARTFUN1K6 (SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))"
            using A13 funct_1_th_39 sorry
          also have "... = F"
            using A17 relat_1_th_52 sorry
          finally have "H *PARTFUN1K1\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> p =HIDDENR1 F"
             sorry
          have "lenFINSEQ-1K4 s9 =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
            using A10 finseq_1_def_3 sorry
          then have A20: "lenFINSEQ-1K4 G =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
            using A7 A18 finseq_2_th_33 sorry
          then have A21: "domFINSEQ-1K5 G =XBOOLE-0R4 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
            using finseq_1_def_3 sorry
          then have A22: "G .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 F .SUPINF-2K15 (s .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
            using A7 finseq_1_th_4 funct_1_th_12 sorry
          obtain p1 where 
            [ty]:"p1 be PermutationFUNCT-2M2-of SegFINSEQ-1K2 n" and p1Def:"p1 = p *PARTFUN1K1\<^bsub>(NATNUMBERSK1,SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> s9  |FINSEQ-1K18\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> n"
            using A12 extreal1_lm_4 sorry
          have A23: "domRELSET-1K1\<^bsub>(SegFINSEQ-1K2 n)\<^esub> p1 =XBOOLE-0R4 SegFINSEQ-1K2 n"
            using funct_2_def_1 sorry
          obtain p19 where 
            [ty]:"p19 be FinSequenceFINSEQ-1M3-of SegFINSEQ-1K2 n" and p19Def:"p19 = p1"
            using finseq_2_th_25 sorry
          have A24: " not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> H"
            using A8 funct_1_th_14 sorry
          have "domFINSEQ-1K5 p2 =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> p"
            using funct_1_th_33 sorry
          then have "domFINSEQ-1K5 p2 =XBOOLE-0R4 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
            using funct_2_def_3 sorry
          then have "lenFINSEQ-1K4 p2 =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
            using finseq_1_def_3 sorry
          then have A25: "lenFINSEQ-1K4 H =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
            using A18 finseq_2_th_33 sorry
          then have A26: "domFINSEQ-1K5 H =XBOOLE-0R4 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
            using finseq_1_def_3 sorry
          have A27: "lenFINSEQ-1K4 (H  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n) =COMPLEX1R1 n"
            using A25 A15 finseq_1_th_59 sorry
          have A28: "G  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n =FUNCT-1R1 H  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n *PARTFUN1K1\<^bsub>(SegFINSEQ-1K2 n,SegFINSEQ-1K2 n,NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> p1"
          proof-
            have "domFINSEQ-1K5 (H  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n) =XBOOLE-0R4 SegFINSEQ-1K2 n"
              using A27 finseq_1_def_3 sorry
            then have A29: "H  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n be FunctionFUNCT-2M1-of(SegFINSEQ-1K2 n,ExtREALXXREAL-0K3)"
              using finseq_2_th_26 sorry
            then obtain H1 where 
              [ty]:"H1 be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3" and H1Def:"H1 = H  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n *PARTFUN1K1\<^bsub>(NATNUMBERSK1,SegFINSEQ-1K2 n,NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> p19"
              using finseq_2_th_32 sorry
            have "n inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            then have "lenFINSEQ-1K4 p19 =COMPLEX1R1 n"
              using A23 finseq_1_def_3 sorry
            then have A30: "lenFINSEQ-1K4 H1 =COMPLEX1R1 n"
              using A29 finseq_2_th_33 sorry
            have A31: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-3R1 i & i <=XXREAL-3R1 n implies (G  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n).SUPINF-2K15 i =XBOOLE-0R4 (H  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n *PARTFUN1K1\<^bsub>(SegFINSEQ-1K2 n,SegFINSEQ-1K2 n,NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> p1).SUPINF-2K15 i"
            proof(rule ballI,rule impMI ,rule impI)
              fix i assume [ty]: "i be NatNAT-1M1"
              assume A32: "\<one>\<^sub>M <=XXREAL-3R1 i"
                and A33: "i <=XXREAL-3R1 n"
              have A34: "i inTARSKIR2 SegFINSEQ-1K2 n"
                using A32 A33 finseq_1_th_1 sorry
              then have A35: "s .FUNCT-1K1 i inTARSKIR2 rngRELSET-1K2\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> s"
                using A10 A16 funct_1_th_3 sorry
              have "i inTARSKIR2 domFINSEQ-1K5 H1"
                using A30 A34 finseq_1_def_3 sorry
              then have A36: "(H  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n *PARTFUN1K1\<^bsub>(SegFINSEQ-1K2 n,SegFINSEQ-1K2 n,NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> p1).SUPINF-2K15 i =XBOOLE-0R4 (H  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n).SUPINF-2K15 (p1 .FUNCT-1K1 i)"
                using funct_1_th_12 sorry
              have "rngRELSET-1K2\<^bsub>(SegFINSEQ-1K2 n)\<^esub> p1 =XBOOLE-0R4 SegFINSEQ-1K2 n"
                using funct_2_def_3 sorry
              then have A37: "p1 .FUNCT-1K1 i inTARSKIR2 SegFINSEQ-1K2 n"
                using A23 A34 funct_1_th_3 sorry
              then obtain a where 
                [ty]:"a be ElementSUBSET-1M1-of NATNUMBERSK1" and aDef:"a = p1 .FUNCT-1K1 i"
                 sorry
              have "a <=XXREAL-3R1 n"
                using A37 finseq_1_th_1 sorry
              then have A38: "(H  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n *PARTFUN1K1\<^bsub>(SegFINSEQ-1K2 n,SegFINSEQ-1K2 n,NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> p1).SUPINF-2K15 i =XBOOLE-0R4 H .SUPINF-2K15 (p1 .FUNCT-1K1 i)"
                using A36 finseq_3_th_112 sorry
              have "(s9  |FINSEQ-1K18\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> n).FUNCT-1K1 i =XBOOLE-0R4 s .FUNCT-1K1 i"
                using A33 finseq_3_th_112 sorry
              then have A39: "p1 .FUNCT-1K1 i =XBOOLE-0R4 p .FUNCT-1K1 (s .FUNCT-1K1 i)"
                using A23 A34 funct_1_th_12 sorry
              have A40: "(G  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n).SUPINF-2K15 i =XBOOLE-0R4 G .SUPINF-2K15 i"
                using A33 finseq_3_th_112 sorry
              have "H .SUPINF-2K15 (p1 .FUNCT-1K1 i) =XBOOLE-0R4 F .SUPINF-2K15 (p2 .FUNCT-1K1 (p1 .FUNCT-1K1 i))"
                using A26 A16 A37 funct_1_th_12 sorry
              then have "(H  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n *PARTFUN1K1\<^bsub>(SegFINSEQ-1K2 n,SegFINSEQ-1K2 n,NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> p1).SUPINF-2K15 i =XBOOLE-0R4 F .SUPINF-2K15 (s .FUNCT-1K1 i)"
                using A13 A39 A38 A35 funct_1_th_34 sorry
              thus "(G  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n).SUPINF-2K15 i =XBOOLE-0R4 (H  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n *PARTFUN1K1\<^bsub>(SegFINSEQ-1K2 n,SegFINSEQ-1K2 n,NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> p1).SUPINF-2K15 i"
                using A7 A21 A16 A40 A34 funct_1_th_12 sorry
            qed "sorry"
            have "lenFINSEQ-1K4 (G  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n) =COMPLEX1R1 n"
              using A20 A15 finseq_1_th_59 sorry
            thus "G  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n =FUNCT-1R1 H  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n *PARTFUN1K1\<^bsub>(SegFINSEQ-1K2 n,SegFINSEQ-1K2 n,NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> p1"
              using A30 A31 finseq_1_th_14 sorry
          qed
          have "G  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n =RELSET-1R2\<^bsub>(NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> G  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> SegFINSEQ-1K2 n"
            using finseq_1_def_15 sorry
          then have "G =FINSEQ-1R1 G  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(ExtREALNUMBERSK7)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALNUMBERSK7)\<^esub> G .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M)*>)"
            using A20 finseq_3_th_55 sorry
          then have A41: "SumEXTREAL1K4 G =XBOOLE-0R4 SumEXTREAL1K4 (G  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n) +SUPINF-2K4 G .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M)"
            using extreal1_lm_1 sorry
          have A42: "H  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n =RELSET-1R2\<^bsub>(NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> H  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> SegFINSEQ-1K2 n"
            using finseq_1_def_15 sorry
          then have "H =FINSEQ-1R1 H  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(ExtREALNUMBERSK7)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALNUMBERSK7)\<^esub> H .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M)*>)"
            using A25 finseq_3_th_55 sorry
          then have A43: "SumEXTREAL1K4 H =XBOOLE-0R4 SumEXTREAL1K4 (H  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n) +SUPINF-2K4 H .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M)"
            using extreal1_lm_1 sorry
          have "rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (H  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n) c=TARSKIR1 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> H"
            using A42 relat_1_th_70 sorry
          then have " not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (H  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n)"
            using A8 funct_1_th_14 sorry
          then have A44: "SumEXTREAL1K4 (G  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n) =XBOOLE-0R4 SumEXTREAL1K4 (H  |FINSEQ-1K18\<^bsub>(ExtREALXXREAL-0K3)\<^esub> n)"
            using A5 A27 A28 sorry
          have "H .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 F .SUPINF-2K15 (p2 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
            using A26 finseq_1_th_4 funct_1_th_12 sorry
          thus "SumEXTREAL1K4 F =XBOOLE-0R4 SumEXTREAL1K4 G"
            using A11 A12 A25 A44 A14 A22 A41 A43 A24 A19 extreal1_lm_5 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have A45: "?P(\<one>\<^sub>M)"
  proof-
    have " for F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  for G be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  for s be PermutationFUNCT-2M2-of SegFINSEQ-1K2 \<one>\<^sub>M holds lenFINSEQ-1K4 F =COMPLEX1R1 \<one>\<^sub>M & G =FUNCT-1R1 F *PARTFUN1K1\<^bsub>(SegFINSEQ-1K2 \<one>\<^sub>M,SegFINSEQ-1K2 \<one>\<^sub>M,NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> s implies  not ( not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F &  not SumEXTREAL1K4 F =XBOOLE-0R4 SumEXTREAL1K4 G)"
    proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
      fix F assume [ty]: "F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3"
      fix G assume [ty]: "G be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3"
      fix s assume [ty]: "s be PermutationFUNCT-2M2-of SegFINSEQ-1K2 \<one>\<^sub>M"
      assume A46: "lenFINSEQ-1K4 F =COMPLEX1R1 \<one>\<^sub>M"
        and A47: "G =FUNCT-1R1 F *PARTFUN1K1\<^bsub>(SegFINSEQ-1K2 \<one>\<^sub>M,SegFINSEQ-1K2 \<one>\<^sub>M,NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> s"
      obtain s1 where 
        [ty]:"s1 be FinSequenceFINSEQ-1M3-of SegFINSEQ-1K2 \<one>\<^sub>M" and s1Def:"s1 = s"
        using finseq_2_th_25 sorry
      have "domRELSET-1K1\<^bsub>(SegFINSEQ-1K2 \<one>\<^sub>M)\<^esub> s =XBOOLE-0R4 SegFINSEQ-1K2 \<one>\<^sub>M"
        using funct_2_def_1 sorry
      then have A48: "lenFINSEQ-1K4 s1 =COMPLEX1R1 \<one>\<^sub>M"
        using finseq_1_def_3 sorry
      have "domFINSEQ-1K5 F =XBOOLE-0R4 SegFINSEQ-1K2 \<one>\<^sub>M"
        using A46 finseq_1_def_3 sorry
      then have "F be FunctionFUNCT-2M1-of(SegFINSEQ-1K2 \<one>\<^sub>M,ExtREALXXREAL-0K3)"
        using finseq_2_th_26 sorry
      then have "lenFINSEQ-1K4 G =COMPLEX1R1 \<one>\<^sub>M"
        using A47 A48 finseq_2_th_33 sorry
      then have A49: "G =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(ExtREALNUMBERSK7)\<^esub> G .SUPINF-2K15 \<one>\<^sub>M*>"
        using finseq_1_th_40 sorry
      then have "rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> G =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(ExtREALNUMBERSK7)\<^esub> G .SUPINF-2K15 \<one>\<^sub>M }"
        using finseq_1_th_39 sorry
      then have "G .SUPINF-2K15 \<one>\<^sub>M inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> G"
        using tarski_def_1 sorry
      then have A50: "G .SUPINF-2K15 \<one>\<^sub>M inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F"
        using A47 funct_1_th_14 sorry
      have A51: "F =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(ExtREALNUMBERSK7)\<^esub> F .SUPINF-2K15 \<one>\<^sub>M*>"
        using A46 finseq_1_th_40 sorry
      then have "rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(ExtREALNUMBERSK7)\<^esub> F .SUPINF-2K15 \<one>\<^sub>M }"
        using finseq_1_th_39 sorry
      thus " not ( not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F &  not SumEXTREAL1K4 F =XBOOLE-0R4 SumEXTREAL1K4 G)"
        using A51 A49 A50 tarski_def_1 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have A52: " for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds ?P(n)"
    using nat_1_sch_10 A45 A4 sorry
  have "lenFINSEQ-1K4 F =COMPLEX1R1 0NUMBERSK6 or lenFINSEQ-1K4 F <>HIDDENR2 0NUMBERSK6"
     sorry
  then have A53: "?P(lenFINSEQ-1K4 F)"
    using A1 A52 sorry
  assume A54: "G =FUNCT-1R1 F *PARTFUN1K1\<^bsub>(domFINSEQ-1K5 F,domFINSEQ-1K5 F,NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> s"
    and A55: " not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F"
  have "domFINSEQ-1K5 F =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 F)"
    using finseq_1_def_3 sorry
  thus "SumEXTREAL1K4 F =XBOOLE-0R4 SumEXTREAL1K4 G"
    using A53 A54 A55 sorry
qed "sorry"

reserve x, y, w, z for "ExtRealXXREAL-0M1"
reserve a for "RealXREAL-0M1"
(*begin*)
mtheorem extreal1_th_12:
" for x be ExtRealXXREAL-0M1 holds  for a be RealXREAL-0M1 holds x =HIDDENR1 a implies  |.EXTREAL1K3 x.| =HIDDENR1  |.COMPLEX1K10 a.|"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for a be RealXREAL-0M1 holds x =HIDDENR1 a implies  |.EXTREAL1K3 x.| =HIDDENR1  |.COMPLEX1K10 a.|"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume A1: "x =HIDDENR1 a"
    have 
      [ty]:"x be R-ealSUPINF-1M1"
      using xxreal_0_def_1 sorry
    show " |.EXTREAL1K3 x.| =HIDDENR1  |.COMPLEX1K10 a.|"
    proof-
      have cases: "0NUMBERSK6 <=XXREAL-3R1 x or  not 0NUMBERSK6 <=XXREAL-3R1 x"
         sorry
      have case1: "0NUMBERSK6 <=XXREAL-3R1 x implies  |.EXTREAL1K3 x.| =HIDDENR1  |.COMPLEX1K10 a.|"
      proof(rule impI)
        assume "0NUMBERSK6 <=XXREAL-3R1 x"
        then have " |.EXTREAL1K3 x.| =HIDDENR1 a"
          using A1 extreal1_def_1 sorry
        thus " |.EXTREAL1K3 x.| =HIDDENR1  |.COMPLEX1K10 a.|"
          using absvalue_def_1 sorry
      qed
      have case2: " not 0NUMBERSK6 <=XXREAL-3R1 x implies  |.EXTREAL1K3 x.| =HIDDENR1  |.COMPLEX1K10 a.|"
      proof(rule impI)
        assume A2: " not 0NUMBERSK6 <=XXREAL-3R1 x"
        then have " |.EXTREAL1K3 x.| =HIDDENR1 -SUPINF-2K3 x"
          using extreal1_def_1 sorry
        also have "... = -XCMPLX-0K4 a"
          using A1 supinf_2_th_2 sorry
        finally have " |.EXTREAL1K3 x.| =HIDDENR1 -XCMPLX-0K4 a"
           sorry
        thus " |.EXTREAL1K3 x.| =HIDDENR1  |.COMPLEX1K10 a.|"
          using A1 A2 absvalue_def_1 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem extreal1_th_13:
" for x be ExtRealXXREAL-0M1 holds  |.EXTREAL1K3 x.| =HIDDENR1 x or  |.EXTREAL1K3 x.| =HIDDENR1 -XXREAL-3K2 x"
  using extreal1_def_1 sorry

mtheorem extreal1_th_14:
" for x be ExtRealXXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-3R1  |.EXTREAL1K3 x.|"
proof-
  have " for x be ExtRealXXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-3R1  |.EXTREAL1K3 x.|"
  proof(rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    have 
      [ty]:"x be R-ealSUPINF-1M1"
      using xxreal_0_def_1 sorry
    have "0NUMBERSK6 <=XXREAL-3R1  |.EXTREAL1K3 x.|"
       sorry
    thus "0NUMBERSK6 <=XXREAL-3R1  |.EXTREAL1K3 x.|"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem extreal1_th_15:
" for x be ExtRealXXREAL-0M1 holds x <>HIDDENR2 0NUMBERSK6 implies 0NUMBERSK6 <XXREAL-0R3  |.EXTREAL1K3 x.|"
proof-
  have " for x be ExtRealXXREAL-0M1 holds x <>HIDDENR2 0NUMBERSK6 implies  not 0NUMBERSK6 <XXREAL-0R3  |.EXTREAL1K3 x.|"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    assume A1: "x <>HIDDENR2 0NUMBERSK6"
    show " not 0NUMBERSK6 <XXREAL-0R3  |.EXTREAL1K3 x.|"
    proof-
      have cases: "0NUMBERSK6 <=XXREAL-3R1 x or  not 0NUMBERSK6 <=XXREAL-3R1 x"
         sorry
      have case1: "0NUMBERSK6 <=XXREAL-3R1 x implies  not 0NUMBERSK6 <XXREAL-0R3  |.EXTREAL1K3 x.|"
      proof(rule impI)
        assume "0NUMBERSK6 <=XXREAL-3R1 x"
        thus " not 0NUMBERSK6 <XXREAL-0R3  |.EXTREAL1K3 x.|"
          using A1 extreal1_def_1 sorry
      qed
      have case2: " not 0NUMBERSK6 <=XXREAL-3R1 x implies  not 0NUMBERSK6 <XXREAL-0R3  |.EXTREAL1K3 x.|"
      proof(rule impI)
        assume A2: " not 0NUMBERSK6 <=XXREAL-3R1 x"
        then have "0NUMBERSK6 <XXREAL-0R3 -XXREAL-3K2 x"
           sorry
        thus " not 0NUMBERSK6 <XXREAL-0R3  |.EXTREAL1K3 x.|"
          using A2 extreal1_def_1 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem extreal1_th_16:
" for x be ExtRealXXREAL-0M1 holds x =HIDDENR1 0NUMBERSK6 iff  |.EXTREAL1K3 x.| =XBOOLE-0R4 0NUMBERSK6"
  using extreal1_th_15 extreal1_def_1 sorry

mtheorem extreal1_th_17:
" for x be ExtRealXXREAL-0M1 holds  |.EXTREAL1K3 x.| =HIDDENR1 -XXREAL-3K2 x & x <>HIDDENR2 0NUMBERSK6 implies x <XXREAL-0R3 0NUMBERSK6"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  not (( |.EXTREAL1K3 x.| =HIDDENR1 -XXREAL-3K2 x &  not x <>HIDDENR2 0NUMBERSK6) & x <XXREAL-0R3 0NUMBERSK6)"
  proof(rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    have 
      [ty]:"x be R-ealSUPINF-1M1"
      using xxreal_0_def_1 sorry
    have "0NUMBERSK6 <=XXREAL-3R1  |.EXTREAL1K3 x.|"
       sorry
    thus " not (( |.EXTREAL1K3 x.| =HIDDENR1 -XXREAL-3K2 x &  not x <>HIDDENR2 0NUMBERSK6) & x <XXREAL-0R3 0NUMBERSK6)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem extreal1_th_18:
" for x be ExtRealXXREAL-0M1 holds x <=XXREAL-3R1 0NUMBERSK6 implies  |.EXTREAL1K3 x.| =HIDDENR1 -XXREAL-3K2 x"
proof-
  have " for x be ExtRealXXREAL-0M1 holds x <=XXREAL-3R1 0NUMBERSK6 implies  |.EXTREAL1K3 x.| =HIDDENR1 -XXREAL-3K2 x"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    assume A1: "x <=XXREAL-3R1 0NUMBERSK6"
    show " |.EXTREAL1K3 x.| =HIDDENR1 -XXREAL-3K2 x"
    proof-
      have cases: "x <XXREAL-0R3 0NUMBERSK6 or x =HIDDENR1 0NUMBERSK6"
        using A1 sorry
      have case1: "x <XXREAL-0R3 0NUMBERSK6 implies  |.EXTREAL1K3 x.| =HIDDENR1 -XXREAL-3K2 x"
      proof(rule impI)
        assume "x <XXREAL-0R3 0NUMBERSK6"
        thus " |.EXTREAL1K3 x.| =HIDDENR1 -XXREAL-3K2 x"
          using extreal1_def_1 sorry
      qed
      have case2: "x =HIDDENR1 0NUMBERSK6 implies  |.EXTREAL1K3 x.| =HIDDENR1 -XXREAL-3K2 x"
      proof(rule impI)
        assume A2: "x =HIDDENR1 0NUMBERSK6"
        then have "-XCMPLX-0K4 0NUMBERSK6 =HIDDENR1 -XXREAL-3K2 x"
           sorry
        thus " |.EXTREAL1K3 x.| =HIDDENR1 -XXREAL-3K2 x"
          using A2 extreal1_def_1 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem extreal1_th_19:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  |.EXTREAL1K3 x *XXREAL-3K4 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 y.|)"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  |.EXTREAL1K3 x *XXREAL-3K4 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 y.|)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    have 
      [ty]:"x be R-ealSUPINF-1M1" and
      [ty]:"y be R-ealSUPINF-1M1"
      using xxreal_0_def_1 sorry
    show " |.EXTREAL1K3 x *XXREAL-3K4 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 y.|)"
    proof-
      have cases: "(x =XBOOLE-0R4 0NUMBERSK6 or 0NUMBERSK6 <XXREAL-0R3 x) or x <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "x =XBOOLE-0R4 0NUMBERSK6 implies  |.EXTREAL1K3 x *XXREAL-3K4 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 y.|)"
      proof(rule impI)
        assume "x =XBOOLE-0R4 0NUMBERSK6"
        then have " |.EXTREAL1K3 x.| =XBOOLE-0R4 0NUMBERSK6 &  |.EXTREAL1K3 x *EXTREAL1K1 y .| =XBOOLE-0R4 0NUMBERSK6"
          using extreal1_def_1 sorry
        thus " |.EXTREAL1K3 x *XXREAL-3K4 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 y.|)"
           sorry
      qed
      have case2: "0NUMBERSK6 <XXREAL-0R3 x implies  |.EXTREAL1K3 x *XXREAL-3K4 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 y.|)"
      proof(rule impI)
        assume A1: "0NUMBERSK6 <XXREAL-0R3 x"
        show " |.EXTREAL1K3 x *XXREAL-3K4 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 y.|)"
        proof-
          have cases: "(y =XBOOLE-0R4 0NUMBERSK6 or 0NUMBERSK6 <XXREAL-0R3 y) or y <XXREAL-0R3 0NUMBERSK6"
             sorry
          have case1: "y =XBOOLE-0R4 0NUMBERSK6 implies  |.EXTREAL1K3 x *XXREAL-3K4 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 y.|)"
          proof(rule impI)
            assume "y =XBOOLE-0R4 0NUMBERSK6"
            then have " |.EXTREAL1K3 y.| =XBOOLE-0R4 0NUMBERSK6 &  |.EXTREAL1K3 x *EXTREAL1K1 y .| =XBOOLE-0R4 0NUMBERSK6"
              using extreal1_def_1 sorry
            thus " |.EXTREAL1K3 x *XXREAL-3K4 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 y.|)"
               sorry
          qed
          have case2: "0NUMBERSK6 <XXREAL-0R3 y implies  |.EXTREAL1K3 x *XXREAL-3K4 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 y.|)"
          proof(rule impI)
            assume "0NUMBERSK6 <XXREAL-0R3 y"
            then have A2: " |.EXTREAL1K3 y.| =XBOOLE-0R4 y"
              using extreal1_def_1 sorry
            have " |.EXTREAL1K3 x.| =XBOOLE-0R4 x"
              using A1 extreal1_def_1 sorry
            thus " |.EXTREAL1K3 x *XXREAL-3K4 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 y.|)"
              using A2 extreal1_def_1 sorry
          qed
          have case3: "y <XXREAL-0R3 0NUMBERSK6 implies  |.EXTREAL1K3 x *XXREAL-3K4 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 y.|)"
          proof(rule impI)
            assume A3: "y <XXREAL-0R3 0NUMBERSK6"
            then have A4: " |.EXTREAL1K3 y.| =XBOOLE-0R4 -SUPINF-2K3 y"
              using extreal1_def_1 sorry
            have " |.EXTREAL1K3 x.| =XBOOLE-0R4 x"
              using A1 extreal1_def_1 sorry
            then have "( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 y.|) =XBOOLE-0R4 -SUPINF-2K3 x *EXTREAL1K1 y"
              using A4 xxreal_3_th_92 sorry
            thus " |.EXTREAL1K3 x *XXREAL-3K4 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 y.|)"
              using A1 A3 extreal1_def_1 sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 sorry
        qed
      qed
      have case3: "x <XXREAL-0R3 0NUMBERSK6 implies  |.EXTREAL1K3 x *XXREAL-3K4 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 y.|)"
      proof(rule impI)
        assume A5: "x <XXREAL-0R3 0NUMBERSK6"
        show " |.EXTREAL1K3 x *XXREAL-3K4 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 y.|)"
        proof-
          have cases: "(y =XBOOLE-0R4 0NUMBERSK6 or 0NUMBERSK6 <XXREAL-0R3 y) or y <XXREAL-0R3 0NUMBERSK6"
             sorry
          have case1: "y =XBOOLE-0R4 0NUMBERSK6 implies  |.EXTREAL1K3 x *XXREAL-3K4 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 y.|)"
          proof(rule impI)
            assume "y =XBOOLE-0R4 0NUMBERSK6"
            then have " |.EXTREAL1K3 y.| =XBOOLE-0R4 0NUMBERSK6 &  |.EXTREAL1K3 x *EXTREAL1K1 y .| =XBOOLE-0R4 0NUMBERSK6"
              using extreal1_def_1 sorry
            thus " |.EXTREAL1K3 x *XXREAL-3K4 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 y.|)"
               sorry
          qed
          have case2: "0NUMBERSK6 <XXREAL-0R3 y implies  |.EXTREAL1K3 x *XXREAL-3K4 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 y.|)"
          proof(rule impI)
            assume A6: "0NUMBERSK6 <XXREAL-0R3 y"
            then have " |.EXTREAL1K3 y.| =XBOOLE-0R4 y"
              using extreal1_def_1 sorry
            then have A7: "( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 y.|) =XBOOLE-0R4 (-SUPINF-2K3 x)*EXTREAL1K1 y"
              using A5 extreal1_def_1 sorry
            have " |.EXTREAL1K3 x *EXTREAL1K1 y .| =XBOOLE-0R4 -SUPINF-2K3 x *EXTREAL1K1 y"
              using A5 A6 extreal1_def_1 sorry
            thus " |.EXTREAL1K3 x *XXREAL-3K4 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 y.|)"
              using A7 xxreal_3_th_92 sorry
          qed
          have case3: "y <XXREAL-0R3 0NUMBERSK6 implies  |.EXTREAL1K3 x *XXREAL-3K4 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 y.|)"
          proof(rule impI)
            assume "y <XXREAL-0R3 0NUMBERSK6"
            then have " |.EXTREAL1K3 y.| =XBOOLE-0R4 -SUPINF-2K3 y"
              using extreal1_def_1 sorry
            then have "( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 y.|) =XBOOLE-0R4 (-SUPINF-2K3 x)*EXTREAL1K1 (-SUPINF-2K3 y)"
              using A5 extreal1_def_1 sorry
            then have "( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 y.|) =HIDDENR1 -SUPINF-2K3 x *EXTREAL1K1 (-SUPINF-2K3 y)"
              using xxreal_3_th_92 sorry
            also have "... = -SUPINF-2K3 (-SUPINF-2K3 x *EXTREAL1K1 y)"
              using xxreal_3_th_92 sorry
            finally have "( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 y.|) =HIDDENR1 -SUPINF-2K3 (-SUPINF-2K3 x *EXTREAL1K1 y)"
               sorry
            thus " |.EXTREAL1K3 x *XXREAL-3K4 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 y.|)"
              using extreal1_def_1 sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 sorry
        qed
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem extreal1_th_20:
" for x be ExtRealXXREAL-0M1 holds -SUPINF-2K3  |.EXTREAL1K3 x.| <=XXREAL-3R1 x & x <=XXREAL-3R1  |.EXTREAL1K3 x.|"
proof-
  have " for x be ExtRealXXREAL-0M1 holds -SUPINF-2K3  |.EXTREAL1K3 x.| <=XXREAL-3R1 x & x <=XXREAL-3R1  |.EXTREAL1K3 x.|"
  proof(rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    have 
      [ty]:"x be R-ealSUPINF-1M1"
      using xxreal_0_def_1 sorry
    show "-SUPINF-2K3  |.EXTREAL1K3 x.| <=XXREAL-3R1 x & x <=XXREAL-3R1  |.EXTREAL1K3 x.|"
    proof-
      have cases: "0NUMBERSK6 <=XXREAL-3R1 x or  not 0NUMBERSK6 <=XXREAL-3R1 x"
         sorry
      have case1: "0NUMBERSK6 <=XXREAL-3R1 x implies -SUPINF-2K3  |.EXTREAL1K3 x.| <=XXREAL-3R1 x & x <=XXREAL-3R1  |.EXTREAL1K3 x.|"
      proof(rule impI)
        assume A1: "0NUMBERSK6 <=XXREAL-3R1 x"
        show "-SUPINF-2K3  |.EXTREAL1K3 x.| <=XXREAL-3R1 x & x <=XXREAL-3R1  |.EXTREAL1K3 x.|"
          using A1 extreal1_def_1 sorry
      qed
      have case2: " not 0NUMBERSK6 <=XXREAL-3R1 x implies -SUPINF-2K3  |.EXTREAL1K3 x.| <=XXREAL-3R1 x & x <=XXREAL-3R1  |.EXTREAL1K3 x.|"
      proof(rule impI)
        assume " not 0NUMBERSK6 <=XXREAL-3R1 x"
        then have " |.EXTREAL1K3 x.| =XBOOLE-0R4 -SUPINF-2K3 x"
          using extreal1_def_1 sorry
        thus "-SUPINF-2K3  |.EXTREAL1K3 x.| <=XXREAL-3R1 x & x <=XXREAL-3R1  |.EXTREAL1K3 x.|"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem extreal1_th_21:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  |.EXTREAL1K3 x.| <XXREAL-0R3 y implies -XXREAL-3K2 y <XXREAL-0R3 x & x <XXREAL-0R3 y"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  |.EXTREAL1K3 x.| <XXREAL-0R3 y implies  not -XXREAL-3K2 y <XXREAL-0R3 x &  not x <XXREAL-0R3 y"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: " |.EXTREAL1K3 x.| <XXREAL-0R3 y"
    have 
      [ty]:"x be R-ealSUPINF-1M1" and
      [ty]:"y be R-ealSUPINF-1M1"
      using xxreal_0_def_1 sorry
    have A2: " |.EXTREAL1K3 x.| <XXREAL-0R3 y"
      using A1 sorry
    show " not -XXREAL-3K2 y <XXREAL-0R3 x &  not x <XXREAL-0R3 y"
    proof-
      have cases: "0NUMBERSK6 <=XXREAL-3R1 x or  not 0NUMBERSK6 <=XXREAL-3R1 x"
         sorry
      have case1: "0NUMBERSK6 <=XXREAL-3R1 x implies  not -XXREAL-3K2 y <XXREAL-0R3 x &  not x <XXREAL-0R3 y"
      proof(rule impI)
        assume "0NUMBERSK6 <=XXREAL-3R1 x"
        thus " not -XXREAL-3K2 y <XXREAL-0R3 x &  not x <XXREAL-0R3 y"
          using A2 extreal1_def_1 sorry
      qed
      have case2: " not 0NUMBERSK6 <=XXREAL-3R1 x implies  not -XXREAL-3K2 y <XXREAL-0R3 x &  not x <XXREAL-0R3 y"
      proof(rule impI)
        assume A3: " not 0NUMBERSK6 <=XXREAL-3R1 x"
        then have " |.EXTREAL1K3 x.| =XBOOLE-0R4 -SUPINF-2K3 x"
          using extreal1_def_1 sorry
        thus " not -XXREAL-3K2 y <XXREAL-0R3 x &  not x <XXREAL-0R3 y"
          using A1 A3 xxreal_3_th_60 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem extreal1_th_22:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds -XXREAL-3K2 y <XXREAL-0R3 x & x <XXREAL-0R3 y implies 0NUMBERSK6 <XXREAL-0R3 y &  |.EXTREAL1K3 x.| <XXREAL-0R3 y"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds -XXREAL-3K2 y <XXREAL-0R3 x & x <XXREAL-0R3 y implies  not 0NUMBERSK6 <XXREAL-0R3 y &  not  |.EXTREAL1K3 x.| <XXREAL-0R3 y"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "-XXREAL-3K2 y <XXREAL-0R3 x"
      and A2: "x <XXREAL-0R3 y"
    show " not 0NUMBERSK6 <XXREAL-0R3 y &  not  |.EXTREAL1K3 x.| <XXREAL-0R3 y"
    proof-
      have cases: "0NUMBERSK6 <=XXREAL-3R1 x or  not 0NUMBERSK6 <=XXREAL-3R1 x"
         sorry
      have case1: "0NUMBERSK6 <=XXREAL-3R1 x implies  not 0NUMBERSK6 <XXREAL-0R3 y &  not  |.EXTREAL1K3 x.| <XXREAL-0R3 y"
      proof(rule impI)
        assume "0NUMBERSK6 <=XXREAL-3R1 x"
        thus " not 0NUMBERSK6 <XXREAL-0R3 y &  not  |.EXTREAL1K3 x.| <XXREAL-0R3 y"
          using A2 extreal1_def_1 sorry
      qed
      have case2: " not 0NUMBERSK6 <=XXREAL-3R1 x implies  not 0NUMBERSK6 <XXREAL-0R3 y &  not  |.EXTREAL1K3 x.| <XXREAL-0R3 y"
      proof(rule impI)
        assume A3: " not 0NUMBERSK6 <=XXREAL-3R1 x"
        have "-XXREAL-3K2 x <XXREAL-0R3 y"
          using A1 xxreal_3_th_60 sorry
        thus " not 0NUMBERSK6 <XXREAL-0R3 y &  not  |.EXTREAL1K3 x.| <XXREAL-0R3 y"
          using A3 extreal1_def_1 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem extreal1_th_23:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds -XXREAL-3K2 y <=XXREAL-3R1 x & x <=XXREAL-3R1 y iff  |.EXTREAL1K3 x.| <=XXREAL-3R1 y"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  not ((-XXREAL-3K2 y <=XXREAL-3R1 x & x <=XXREAL-3R1 y) &  not  |.EXTREAL1K3 x.| <=XXREAL-3R1 y) &  not ( |.EXTREAL1K3 x.| <=XXREAL-3R1 y &  not (-XXREAL-3K2 y <=XXREAL-3R1 x & x <=XXREAL-3R1 y))"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    have A1: "-XXREAL-3K2 y <=XXREAL-3R1 x & x <=XXREAL-3R1 y implies  |.EXTREAL1K3 x.| <=XXREAL-3R1 y"
    proof(rule impMI ,rule impI)
      assume A2: "-XXREAL-3K2 y <=XXREAL-3R1 x"
        and A3: "x <=XXREAL-3R1 y"
      show " |.EXTREAL1K3 x.| <=XXREAL-3R1 y"
      proof-
        have cases: "0NUMBERSK6 <=XXREAL-3R1 x or  not 0NUMBERSK6 <=XXREAL-3R1 x"
           sorry
        have case1: "0NUMBERSK6 <=XXREAL-3R1 x implies  |.EXTREAL1K3 x.| <=XXREAL-3R1 y"
        proof(rule impI)
          assume "0NUMBERSK6 <=XXREAL-3R1 x"
          thus " |.EXTREAL1K3 x.| <=XXREAL-3R1 y"
            using A3 extreal1_def_1 sorry
        qed
        have case2: " not 0NUMBERSK6 <=XXREAL-3R1 x implies  |.EXTREAL1K3 x.| <=XXREAL-3R1 y"
        proof(rule impI)
          assume A4: " not 0NUMBERSK6 <=XXREAL-3R1 x"
          have "-XXREAL-3K2 x <=XXREAL-3R1 y"
            using A2 xxreal_3_th_60 sorry
          thus " |.EXTREAL1K3 x.| <=XXREAL-3R1 y"
            using A4 extreal1_def_1 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    have " |.EXTREAL1K3 x.| <=XXREAL-3R1 y implies -XXREAL-3K2 y <=XXREAL-3R1 x & x <=XXREAL-3R1 y"
    proof(rule impI)
      assume A5: " |.EXTREAL1K3 x.| <=XXREAL-3R1 y"
      show "-XXREAL-3K2 y <=XXREAL-3R1 x & x <=XXREAL-3R1 y"
      proof-
        have cases: " |.EXTREAL1K3 x.| =HIDDENR1 y or  |.EXTREAL1K3 x.| <XXREAL-0R3 y"
          using A5 xxreal_0_th_1 sorry
        have case1: " |.EXTREAL1K3 x.| =HIDDENR1 y implies -XXREAL-3K2 y <=XXREAL-3R1 x & x <=XXREAL-3R1 y"
        proof(rule impI)
          assume " |.EXTREAL1K3 x.| =HIDDENR1 y"
          thus "-XXREAL-3K2 y <=XXREAL-3R1 x & x <=XXREAL-3R1 y"
            using extreal1_th_20 sorry
        qed
        have case2: " |.EXTREAL1K3 x.| <XXREAL-0R3 y implies -XXREAL-3K2 y <=XXREAL-3R1 x & x <=XXREAL-3R1 y"
        proof(rule impI)
          assume " |.EXTREAL1K3 x.| <XXREAL-0R3 y"
          thus "-XXREAL-3K2 y <=XXREAL-3R1 x & x <=XXREAL-3R1 y"
            using extreal1_th_21 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not ((-XXREAL-3K2 y <=XXREAL-3R1 x & x <=XXREAL-3R1 y) &  not  |.EXTREAL1K3 x.| <=XXREAL-3R1 y) &  not ( |.EXTREAL1K3 x.| <=XXREAL-3R1 y &  not (-XXREAL-3K2 y <=XXREAL-3R1 x & x <=XXREAL-3R1 y))"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem extreal1_th_24:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  |.EXTREAL1K3 x +XXREAL-3K1 y .| <=XXREAL-3R1  |.EXTREAL1K3 x.| +SUPINF-2K4  |.EXTREAL1K3 y.|"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  |.EXTREAL1K3 x +XXREAL-3K1 y .| <=XXREAL-3R1  |.EXTREAL1K3 x.| +SUPINF-2K4  |.EXTREAL1K3 y.|"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    have A1: "-SUPINF-2K3  |.EXTREAL1K3 x.| <=XXREAL-3R1 x & -SUPINF-2K3  |.EXTREAL1K3 y.| <=XXREAL-3R1 y"
      using extreal1_th_20 sorry
    have A2: "x <=XXREAL-3R1  |.EXTREAL1K3 x.| & y <=XXREAL-3R1  |.EXTREAL1K3 y.|"
      using extreal1_th_20 sorry
    have A3: "(-SUPINF-2K3  |.EXTREAL1K3 x.|)-SUPINF-2K5  |.EXTREAL1K3 y.| =XBOOLE-0R4 -SUPINF-2K3 ( |.EXTREAL1K3 x.| +SUPINF-2K4  |.EXTREAL1K3 y.|)"
      using xxreal_3_th_25 sorry
    have "x +XXREAL-3K1 y <=XXREAL-3R1  |.EXTREAL1K3 x.| +SUPINF-2K4  |.EXTREAL1K3 y.| & (-SUPINF-2K3  |.EXTREAL1K3 x.|)+SUPINF-2K4 (-SUPINF-2K3  |.EXTREAL1K3 y.|) <=XXREAL-3R1 x +XXREAL-3K1 y"
      using A1 A2 xxreal_3_th_36 sorry
    thus " |.EXTREAL1K3 x +XXREAL-3K1 y .| <=XXREAL-3R1  |.EXTREAL1K3 x.| +SUPINF-2K4  |.EXTREAL1K3 y.|"
      using A3 extreal1_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem extreal1_th_25:
" for x be ExtRealXXREAL-0M1 holds (-inftySUPINF-1K2 <XXREAL-0R3 x & x <XXREAL-0R3 +inftySUPINF-1K1) & x <>HIDDENR2 0NUMBERSK6 implies ( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 (1.SUPINF-2K21)/EXTREAL1K2 x .|) =XBOOLE-0R4 1.SUPINF-2K21"
proof-
  have " for x be ExtRealXXREAL-0M1 holds (-inftySUPINF-1K2 <XXREAL-0R3 x & x <XXREAL-0R3 +inftySUPINF-1K1) & x <>HIDDENR2 0NUMBERSK6 implies ( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 (1.SUPINF-2K21)/EXTREAL1K2 x .|) =XBOOLE-0R4 1.SUPINF-2K21"
  proof(rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    assume A1: "-inftySUPINF-1K2 <XXREAL-0R3 x & x <XXREAL-0R3 +inftySUPINF-1K1"
      and A2: "x <>HIDDENR2 0NUMBERSK6"
    obtain a where 
      [ty]:"a be ElementSUBSET-1M1-of REALNUMBERSK2" and aDef:"a = x"
      using A1 xxreal_0_th_14 sorry
    have A3: "(1.SUPINF-2K21)/EXTREAL1K2 x =XBOOLE-0R4 \<one>\<^sub>M /EXTREAL1K2 a"
       sorry
    show "( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 (1.SUPINF-2K21)/EXTREAL1K2 x .|) =XBOOLE-0R4 1.SUPINF-2K21"
    proof-
      have cases: "0NUMBERSK6 <=XXREAL-3R1 x or  not 0NUMBERSK6 <=XXREAL-3R1 x"
         sorry
      have case1: "0NUMBERSK6 <=XXREAL-3R1 x implies ( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 (1.SUPINF-2K21)/EXTREAL1K2 x .|) =XBOOLE-0R4 1.SUPINF-2K21"
      proof(rule impI)
        assume "0NUMBERSK6 <=XXREAL-3R1 x"
        then have " |.EXTREAL1K3 x.| =XBOOLE-0R4 a &  |.EXTREAL1K3 (1.SUPINF-2K21)/EXTREAL1K2 x .| =XBOOLE-0R4 \<one>\<^sub>M /EXTREAL1K2 a"
          using extreal1_def_1 sorry
        then have "( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 (1.SUPINF-2K21)/EXTREAL1K2 x .|) =XBOOLE-0R4 a *XCMPLX-0K3 (\<one>\<^sub>M /EXTREAL1K2 a)"
          using xxreal_3_def_5 sorry
        thus "( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 (1.SUPINF-2K21)/EXTREAL1K2 x .|) =XBOOLE-0R4 1.SUPINF-2K21"
          using A2 xcmplx_1_th_106 sorry
      qed
      have case2: " not 0NUMBERSK6 <=XXREAL-3R1 x implies ( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 (1.SUPINF-2K21)/EXTREAL1K2 x .|) =XBOOLE-0R4 1.SUPINF-2K21"
      proof(rule impI)
        assume A4: " not 0NUMBERSK6 <=XXREAL-3R1 x"
        then have A5: " |.EXTREAL1K3 x.| =HIDDENR1 -XXREAL-3K2 x"
          using extreal1_def_1 sorry
        also have "... = -REAL-1K1 a"
          using supinf_2_th_2 sorry
        finally have " |.EXTREAL1K3 x.| =HIDDENR1 -REAL-1K1 a"
           sorry
        have " |.EXTREAL1K3 (1.SUPINF-2K21)/EXTREAL1K2 x .| =HIDDENR1 -SUPINF-2K3 (1.SUPINF-2K21)/EXTREAL1K2 x"
          using A3 A4 extreal1_def_1 sorry
        also have "... = -SUPINF-2K3 \<one>\<^sub>M /EXTREAL1K2 a"
           sorry
        finally have " |.EXTREAL1K3 (1.SUPINF-2K21)/EXTREAL1K2 x .| =HIDDENR1 -SUPINF-2K3 \<one>\<^sub>M /EXTREAL1K2 a"
           sorry
        then have "( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 (1.SUPINF-2K21)/EXTREAL1K2 x .|) =HIDDENR1 (-REAL-1K1 a)*XCMPLX-0K3 (-SUPINF-2K3 \<one>\<^sub>M /EXTREAL1K2 a)"
          using A5 xxreal_3_def_5 sorry
        also have "... = a *XCMPLX-0K3 (\<one>\<^sub>M /EXTREAL1K2 a)"
           sorry
        finally have "( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 (1.SUPINF-2K21)/EXTREAL1K2 x .|) =HIDDENR1 a *XCMPLX-0K3 (\<one>\<^sub>M /EXTREAL1K2 a)"
           sorry
        thus "( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 (1.SUPINF-2K21)/EXTREAL1K2 x .|) =XBOOLE-0R4 1.SUPINF-2K21"
          using A4 xcmplx_1_th_106 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem extreal1_th_26:
" for x be ExtRealXXREAL-0M1 holds x =HIDDENR1 +inftySUPINF-1K1 or x =HIDDENR1 -inftySUPINF-1K2 implies ( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 (1.SUPINF-2K21)/EXTREAL1K2 x .|) =XBOOLE-0R4 0NUMBERSK6"
proof-
  have " for x be ExtRealXXREAL-0M1 holds x =HIDDENR1 +inftySUPINF-1K1 or x =HIDDENR1 -inftySUPINF-1K2 implies ( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 (1.SUPINF-2K21)/EXTREAL1K2 x .|) =XBOOLE-0R4 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    assume "x =HIDDENR1 +inftySUPINF-1K1 or x =HIDDENR1 -inftySUPINF-1K2"
    then have " |.EXTREAL1K3 (1.SUPINF-2K21)/EXTREAL1K2 x .| =XBOOLE-0R4 0NUMBERSK6"
      using extreal1_def_1 sorry
    thus "( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 (1.SUPINF-2K21)/EXTREAL1K2 x .|) =XBOOLE-0R4 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem extreal1_th_27:
" for x be ExtRealXXREAL-0M1 holds x <>HIDDENR2 0NUMBERSK6 implies  |.EXTREAL1K3 (1.SUPINF-2K21)/EXTREAL1K2 x .| =XBOOLE-0R4 (1.SUPINF-2K21)/EXTREAL1K2 ( |.EXTREAL1K3 x.|)"
proof-
  have " for x be ExtRealXXREAL-0M1 holds x <>HIDDENR2 0NUMBERSK6 implies  |.EXTREAL1K3 (1.SUPINF-2K21)/EXTREAL1K2 x .| =XBOOLE-0R4 (1.SUPINF-2K21)/EXTREAL1K2 ( |.EXTREAL1K3 x.|)"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    assume A1: "x <>HIDDENR2 0NUMBERSK6"
    show " |.EXTREAL1K3 (1.SUPINF-2K21)/EXTREAL1K2 x .| =XBOOLE-0R4 (1.SUPINF-2K21)/EXTREAL1K2 ( |.EXTREAL1K3 x.|)"
    proof-
      have cases: "(x =HIDDENR1 +inftySUPINF-1K1 or x =HIDDENR1 -inftySUPINF-1K2) or x <>HIDDENR2 +inftySUPINF-1K1 & x <>HIDDENR2 -inftySUPINF-1K2"
         sorry
      have case1: "x =HIDDENR1 +inftySUPINF-1K1 implies  |.EXTREAL1K3 (1.SUPINF-2K21)/EXTREAL1K2 x .| =XBOOLE-0R4 (1.SUPINF-2K21)/EXTREAL1K2 ( |.EXTREAL1K3 x.|)"
      proof(rule impI)
        assume A2: "x =HIDDENR1 +inftySUPINF-1K1"
        then have " |.EXTREAL1K3 (1.SUPINF-2K21)/EXTREAL1K2 x .| =XBOOLE-0R4 0NUMBERSK6"
          using extreal1_def_1 sorry
        thus " |.EXTREAL1K3 (1.SUPINF-2K21)/EXTREAL1K2 x .| =XBOOLE-0R4 (1.SUPINF-2K21)/EXTREAL1K2 ( |.EXTREAL1K3 x.|)"
          using A2 extreal1_def_1 sorry
      qed
      have case2: "x =HIDDENR1 -inftySUPINF-1K2 implies  |.EXTREAL1K3 (1.SUPINF-2K21)/EXTREAL1K2 x .| =XBOOLE-0R4 (1.SUPINF-2K21)/EXTREAL1K2 ( |.EXTREAL1K3 x.|)"
      proof(rule impI)
        assume "x =HIDDENR1 -inftySUPINF-1K2"
        then have " |.EXTREAL1K3 (1.SUPINF-2K21)/EXTREAL1K2 x .| =XBOOLE-0R4 0NUMBERSK6 &  |.EXTREAL1K3 x.| =XBOOLE-0R4 +inftySUPINF-1K1"
          using extreal1_def_1 xxreal_3_th_5 sorry
        thus " |.EXTREAL1K3 (1.SUPINF-2K21)/EXTREAL1K2 x .| =XBOOLE-0R4 (1.SUPINF-2K21)/EXTREAL1K2 ( |.EXTREAL1K3 x.|)"
           sorry
      qed
      have case3: "x <>HIDDENR2 +inftySUPINF-1K1 & x <>HIDDENR2 -inftySUPINF-1K2 implies  |.EXTREAL1K3 (1.SUPINF-2K21)/EXTREAL1K2 x .| =XBOOLE-0R4 (1.SUPINF-2K21)/EXTREAL1K2 ( |.EXTREAL1K3 x.|)"
      proof(rule impI)
        assume A3: "x <>HIDDENR2 +inftySUPINF-1K1 & x <>HIDDENR2 -inftySUPINF-1K2"
        have A4: "0NUMBERSK6 <XXREAL-0R3  |.EXTREAL1K3 x.|"
          using A1 extreal1_th_15 sorry
        have A5: "x <XXREAL-0R3 +inftySUPINF-1K1"
          using A3 xxreal_0_th_4 sorry
        have "-inftySUPINF-1K2 <=XXREAL-3R1 x"
          using xxreal_0_th_5 sorry
        then have A6: "-inftySUPINF-1K2 <XXREAL-0R3 x"
          using A3 xxreal_0_th_1 sorry
        then have "-SUPINF-2K3 +inftySUPINF-1K1 <XXREAL-0R3 x"
          using xxreal_3_def_3 sorry
        then have A7: " |.EXTREAL1K3 x.| <XXREAL-0R3 +inftySUPINF-1K1"
          using A5 extreal1_th_22 sorry
        have "( |.EXTREAL1K3 (1.SUPINF-2K21)/EXTREAL1K2 x .|)*EXTREAL1K1 ( |.EXTREAL1K3 x.|) =XBOOLE-0R4 1.SUPINF-2K21"
          using A1 A6 A5 extreal1_th_25 sorry
        thus " |.EXTREAL1K3 (1.SUPINF-2K21)/EXTREAL1K2 x .| =XBOOLE-0R4 (1.SUPINF-2K21)/EXTREAL1K2 ( |.EXTREAL1K3 x.|)"
          using A4 A7 xxreal_3_th_88 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem extreal1_th_28:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  not ((x =HIDDENR1 -inftySUPINF-1K2 or x =HIDDENR1 +inftySUPINF-1K1) & (y =HIDDENR1 -inftySUPINF-1K2 or y =HIDDENR1 +inftySUPINF-1K1)) & y <>HIDDENR2 0NUMBERSK6 implies  |.EXTREAL1K3 x /EXTREAL1K2 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)/EXTREAL1K2 ( |.EXTREAL1K3 y.|)"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  not ((x =HIDDENR1 -inftySUPINF-1K2 or x =HIDDENR1 +inftySUPINF-1K1) & (y =HIDDENR1 -inftySUPINF-1K2 or y =HIDDENR1 +inftySUPINF-1K1)) & y <>HIDDENR2 0NUMBERSK6 implies  |.EXTREAL1K3 x /EXTREAL1K2 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)/EXTREAL1K2 ( |.EXTREAL1K3 y.|)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: " not ((x =HIDDENR1 -inftySUPINF-1K2 or x =HIDDENR1 +inftySUPINF-1K1) & (y =HIDDENR1 -inftySUPINF-1K2 or y =HIDDENR1 +inftySUPINF-1K1))"
      and A2: "y <>HIDDENR2 0NUMBERSK6"
    have 
      [ty]:"y be R-ealSUPINF-1M1"
      using xxreal_0_def_1 sorry
    show " |.EXTREAL1K3 x /EXTREAL1K2 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)/EXTREAL1K2 ( |.EXTREAL1K3 y.|)"
    proof-
      have cases: "(x =HIDDENR1 +inftySUPINF-1K1 or x =HIDDENR1 -inftySUPINF-1K2) or x <>HIDDENR2 +inftySUPINF-1K1 & x <>HIDDENR2 -inftySUPINF-1K2"
         sorry
      have case1: "x =HIDDENR1 +inftySUPINF-1K1 implies  |.EXTREAL1K3 x /EXTREAL1K2 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)/EXTREAL1K2 ( |.EXTREAL1K3 y.|)"
      proof(rule impI)
        assume A3: "x =HIDDENR1 +inftySUPINF-1K1"
        have A4: "-inftySUPINF-1K2 <XXREAL-0R3 y"
          using A1 A3 xxreal_0_th_12 xxreal_0_th_14 sorry
        show " |.EXTREAL1K3 x /EXTREAL1K2 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)/EXTREAL1K2 ( |.EXTREAL1K3 y.|)"
        proof-
          have cases: "0NUMBERSK6 <XXREAL-0R3 y or y <XXREAL-0R3 0NUMBERSK6"
            using A2 sorry
          have case1: "0NUMBERSK6 <XXREAL-0R3 y implies  |.EXTREAL1K3 x /EXTREAL1K2 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)/EXTREAL1K2 ( |.EXTREAL1K3 y.|)"
          proof(rule impI)
            assume A5: "0NUMBERSK6 <XXREAL-0R3 y"
            then have "x /EXTREAL1K2 y =XBOOLE-0R4 +inftySUPINF-1K1"
              using A3 A1 xxreal_3_th_83 sorry
            then have A6: " |.EXTREAL1K3 x /EXTREAL1K2 y .| =XBOOLE-0R4 +inftySUPINF-1K1"
              using extreal1_def_1 sorry
            have " |.EXTREAL1K3 y.| =XBOOLE-0R4 y"
              using A5 extreal1_def_1 sorry
            thus " |.EXTREAL1K3 x /EXTREAL1K2 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)/EXTREAL1K2 ( |.EXTREAL1K3 y.|)"
              using A3 A1 A5 A6 xxreal_3_th_83 sorry
          qed
          have case2: "y <XXREAL-0R3 0NUMBERSK6 implies  |.EXTREAL1K3 x /EXTREAL1K2 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)/EXTREAL1K2 ( |.EXTREAL1K3 y.|)"
          proof(rule impI)
            assume A7: "y <XXREAL-0R3 0NUMBERSK6"
            then have " |.EXTREAL1K3 y.| =XBOOLE-0R4 -SUPINF-2K3 y"
              using extreal1_def_1 sorry
            then have A8: " |.EXTREAL1K3 y.| <XXREAL-0R3 +inftySUPINF-1K1"
              using A4 xxreal_3_th_5 xxreal_3_th_38 sorry
            have "x /EXTREAL1K2 y =XBOOLE-0R4 -inftySUPINF-1K2"
              using A3 A1 A7 xxreal_3_th_85 sorry
            then have " |.EXTREAL1K3 x /EXTREAL1K2 y .| =XBOOLE-0R4 +inftySUPINF-1K1"
              using extreal1_def_1 xxreal_3_th_5 sorry
            thus " |.EXTREAL1K3 x /EXTREAL1K2 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)/EXTREAL1K2 ( |.EXTREAL1K3 y.|)"
              using A8 A2 A3 extreal1_th_15 xxreal_3_th_83 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      have case2: "x =HIDDENR1 -inftySUPINF-1K2 implies  |.EXTREAL1K3 x /EXTREAL1K2 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)/EXTREAL1K2 ( |.EXTREAL1K3 y.|)"
      proof(rule impI)
        assume A9: "x =HIDDENR1 -inftySUPINF-1K2"
        have A10: "-inftySUPINF-1K2 <XXREAL-0R3 y"
          using A1 A9 xxreal_0_th_12 xxreal_0_th_14 sorry
        show " |.EXTREAL1K3 x /EXTREAL1K2 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)/EXTREAL1K2 ( |.EXTREAL1K3 y.|)"
        proof-
          have cases: "0NUMBERSK6 <XXREAL-0R3 y or y <XXREAL-0R3 0NUMBERSK6"
            using A2 sorry
          have case1: "0NUMBERSK6 <XXREAL-0R3 y implies  |.EXTREAL1K3 x /EXTREAL1K2 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)/EXTREAL1K2 ( |.EXTREAL1K3 y.|)"
          proof(rule impI)
            assume A11: "0NUMBERSK6 <XXREAL-0R3 y"
            then have A12: "x /EXTREAL1K2 y =XBOOLE-0R4 -inftySUPINF-1K2"
              using A9 A1 xxreal_3_th_86 sorry
            have A13: " |.EXTREAL1K3 x.| =XBOOLE-0R4 +inftySUPINF-1K1"
              using A9 extreal1_def_1 xxreal_3_th_5 sorry
            have " |.EXTREAL1K3 y.| =XBOOLE-0R4 y"
              using A11 extreal1_def_1 sorry
            thus " |.EXTREAL1K3 x /EXTREAL1K2 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)/EXTREAL1K2 ( |.EXTREAL1K3 y.|)"
              using A9 A1 A11 A12 A13 xxreal_3_th_83 sorry
          qed
          have case2: "y <XXREAL-0R3 0NUMBERSK6 implies  |.EXTREAL1K3 x /EXTREAL1K2 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)/EXTREAL1K2 ( |.EXTREAL1K3 y.|)"
          proof(rule impI)
            assume A14: "y <XXREAL-0R3 0NUMBERSK6"
            then have " |.EXTREAL1K3 y.| =XBOOLE-0R4 -SUPINF-2K3 y"
              using extreal1_def_1 sorry
            then have A15: " |.EXTREAL1K3 y.| <XXREAL-0R3 +inftySUPINF-1K1"
              using A10 xxreal_3_th_5 xxreal_3_th_38 sorry
            have A16: "x /EXTREAL1K2 y =XBOOLE-0R4 +inftySUPINF-1K1"
              using A9 A1 A14 xxreal_3_th_84 sorry
            have "0NUMBERSK6 <XXREAL-0R3  |.EXTREAL1K3 y.| &  |.EXTREAL1K3 x.| =XBOOLE-0R4 +inftySUPINF-1K1"
              using A2 A9 extreal1_th_15 extreal1_def_1 xxreal_3_th_5 sorry
            thus " |.EXTREAL1K3 x /EXTREAL1K2 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)/EXTREAL1K2 ( |.EXTREAL1K3 y.|)"
              using A15 A16 xxreal_3_th_83 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      have case3: "x <>HIDDENR2 +inftySUPINF-1K1 & x <>HIDDENR2 -inftySUPINF-1K2 implies  |.EXTREAL1K3 x /EXTREAL1K2 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)/EXTREAL1K2 ( |.EXTREAL1K3 y.|)"
      proof(rule impI)
        assume "x <>HIDDENR2 +inftySUPINF-1K1 & x <>HIDDENR2 -inftySUPINF-1K2"
        then obtain a where 
          [ty]:"a be ElementSUBSET-1M1-of REALNUMBERSK2" and aDef:"a = x"
          using xxreal_0_th_14 sorry
        show " |.EXTREAL1K3 x /EXTREAL1K2 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)/EXTREAL1K2 ( |.EXTREAL1K3 y.|)"
        proof-
          have cases: "(y =XBOOLE-0R4 +inftySUPINF-1K1 or y =XBOOLE-0R4 -inftySUPINF-1K2) or y <>HIDDENR2 +inftySUPINF-1K1 & y <>HIDDENR2 -inftySUPINF-1K2"
             sorry
          have case1: "y =XBOOLE-0R4 +inftySUPINF-1K1 implies  |.EXTREAL1K3 x /EXTREAL1K2 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)/EXTREAL1K2 ( |.EXTREAL1K3 y.|)"
          proof(rule impI)
            assume "y =XBOOLE-0R4 +inftySUPINF-1K1"
            then have " |.EXTREAL1K3 x /EXTREAL1K2 y .| =XBOOLE-0R4 0NUMBERSK6 &  |.EXTREAL1K3 y.| =XBOOLE-0R4 +inftySUPINF-1K1"
              using extreal1_def_1 sorry
            thus " |.EXTREAL1K3 x /EXTREAL1K2 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)/EXTREAL1K2 ( |.EXTREAL1K3 y.|)"
               sorry
          qed
          have case2: "y =XBOOLE-0R4 -inftySUPINF-1K2 implies  |.EXTREAL1K3 x /EXTREAL1K2 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)/EXTREAL1K2 ( |.EXTREAL1K3 y.|)"
          proof(rule impI)
            assume "y =XBOOLE-0R4 -inftySUPINF-1K2"
            then have " |.EXTREAL1K3 x /EXTREAL1K2 y .| =XBOOLE-0R4 0NUMBERSK6 &  |.EXTREAL1K3 y.| =XBOOLE-0R4 +inftySUPINF-1K1"
              using extreal1_def_1 xxreal_3_th_5 sorry
            thus " |.EXTREAL1K3 x /EXTREAL1K2 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)/EXTREAL1K2 ( |.EXTREAL1K3 y.|)"
               sorry
          qed
          have case3: "y <>HIDDENR2 +inftySUPINF-1K1 & y <>HIDDENR2 -inftySUPINF-1K2 implies  |.EXTREAL1K3 x /EXTREAL1K2 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)/EXTREAL1K2 ( |.EXTREAL1K3 y.|)"
          proof(rule impI)
            assume "y <>HIDDENR2 +inftySUPINF-1K1 & y <>HIDDENR2 -inftySUPINF-1K2"
            then obtain b where 
              [ty]:"b be ElementSUBSET-1M1-of REALNUMBERSK2" and bDef:"b = y"
              using xxreal_0_th_14 sorry
            have " |.EXTREAL1K3 x.| =HIDDENR1  |.COMPLEX1K10 a.| &  |.EXTREAL1K3 y.| =HIDDENR1  |.COMPLEX1K10 b.|"
              using extreal1_th_12 sorry
            then have A17: "( |.EXTREAL1K3 x.|)/EXTREAL1K2 ( |.EXTREAL1K3 y.|) =XBOOLE-0R4 ( |.COMPLEX1K10 a.|)/EXTREAL1K2 ( |.COMPLEX1K10 b.|)"
               sorry
            have " |.EXTREAL1K3 x /EXTREAL1K2 y .| =HIDDENR1  |.COMPLEX1K10 a /EXTREAL1K2 b .|"
              using extreal1_th_12 sorry
            thus " |.EXTREAL1K3 x /EXTREAL1K2 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)/EXTREAL1K2 ( |.EXTREAL1K3 y.|)"
              using A17 complex1_th_67 sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 sorry
        qed
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem extreal1_th_29:
" for x be ExtRealXXREAL-0M1 holds  |.EXTREAL1K3 x.| =XBOOLE-0R4  |.EXTREAL1K3 -XXREAL-3K2 x .|"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  |.EXTREAL1K3 x.| =XBOOLE-0R4  |.EXTREAL1K3 -XXREAL-3K2 x .|"
  proof(rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    have 
      [ty]:"x be R-ealSUPINF-1M1"
      using xxreal_0_def_1 sorry
    show " |.EXTREAL1K3 x.| =XBOOLE-0R4  |.EXTREAL1K3 -XXREAL-3K2 x .|"
    proof-
      have cases: "(0NUMBERSK6 <XXREAL-0R3 x or x <XXREAL-0R3 0NUMBERSK6) or x =XBOOLE-0R4 0NUMBERSK6"
         sorry
      have case1: "0NUMBERSK6 <XXREAL-0R3 x implies  |.EXTREAL1K3 x.| =XBOOLE-0R4  |.EXTREAL1K3 -XXREAL-3K2 x .|"
      proof(rule impI)
        assume "0NUMBERSK6 <XXREAL-0R3 x"
        then have " |.EXTREAL1K3 -SUPINF-2K3 x .| =HIDDENR1 -SUPINF-2K3 (-SUPINF-2K3 x)"
          using extreal1_def_1 sorry
        also have "... = x"
           sorry
        finally have " |.EXTREAL1K3 -SUPINF-2K3 x .| =HIDDENR1 x"
           sorry
        thus " |.EXTREAL1K3 x.| =XBOOLE-0R4  |.EXTREAL1K3 -XXREAL-3K2 x .|"
           sorry
      qed
      have case2: "x <XXREAL-0R3 0NUMBERSK6 implies  |.EXTREAL1K3 x.| =XBOOLE-0R4  |.EXTREAL1K3 -XXREAL-3K2 x .|"
      proof(rule impI)
        assume "x <XXREAL-0R3 0NUMBERSK6"
        then have " |.EXTREAL1K3 x.| =XBOOLE-0R4 -SUPINF-2K3 x"
          using extreal1_def_1 sorry
        thus " |.EXTREAL1K3 x.| =XBOOLE-0R4  |.EXTREAL1K3 -XXREAL-3K2 x .|"
           sorry
      qed
      have case3: "x =XBOOLE-0R4 0NUMBERSK6 implies  |.EXTREAL1K3 x.| =XBOOLE-0R4  |.EXTREAL1K3 -XXREAL-3K2 x .|"
      proof(rule impI)
        assume "x =XBOOLE-0R4 0NUMBERSK6"
        thus " |.EXTREAL1K3 x.| =XBOOLE-0R4  |.EXTREAL1K3 -XXREAL-3K2 x .|"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem extreal1_th_30:
" |.EXTREAL1K3 +inftySUPINF-1K1.| =XBOOLE-0R4 +inftySUPINF-1K1 &  |.EXTREAL1K3 -inftySUPINF-1K2.| =XBOOLE-0R4 +inftySUPINF-1K1"
proof(rule conjMI)
  show " |.EXTREAL1K3 +inftySUPINF-1K1.| =XBOOLE-0R4 +inftySUPINF-1K1"
    using extreal1_def_1 sorry
  have "-SUPINF-2K3 -inftySUPINF-1K2 =XBOOLE-0R4 +inftySUPINF-1K1"
    using xxreal_3_th_23 sorry
  thus " |.EXTREAL1K3 -inftySUPINF-1K2.| =XBOOLE-0R4 +inftySUPINF-1K1"
    using extreal1_def_1 sorry
qed

mtheorem extreal1_th_31:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x be RealXREAL-0M1 or y be RealXREAL-0M1 implies  |.EXTREAL1K3 x.| -SUPINF-2K5  |.EXTREAL1K3 y.| <=XXREAL-3R1  |.EXTREAL1K3 x -XXREAL-3K3 y .|"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x be RealXREAL-0M1 or y be RealXREAL-0M1 implies  |.EXTREAL1K3 x.| -SUPINF-2K5  |.EXTREAL1K3 y.| <=XXREAL-3R1  |.EXTREAL1K3 x -XXREAL-3K3 y .|"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "x be RealXREAL-0M1 or y be RealXREAL-0M1"
    have 
      [ty]:"x be R-ealSUPINF-1M1" and
      [ty]:"y be R-ealSUPINF-1M1"
      using xxreal_0_def_1 sorry
    show " |.EXTREAL1K3 x.| -SUPINF-2K5  |.EXTREAL1K3 y.| <=XXREAL-3R1  |.EXTREAL1K3 x -XXREAL-3K3 y .|"
    proof-
      have cases: "y be RealXREAL-0M1 or x be RealXREAL-0M1"
        using A1 sorry
      have case1: "y be RealXREAL-0M1 implies  |.EXTREAL1K3 x.| -SUPINF-2K5  |.EXTREAL1K3 y.| <=XXREAL-3R1  |.EXTREAL1K3 x -XXREAL-3K3 y .|"
      proof(rule impI)
        assume "y be RealXREAL-0M1"
        then have "(x -SUPINF-2K5 y)+SUPINF-2K4 y =XBOOLE-0R4 x"
          using xxreal_3_th_22 sorry
        then have " |.EXTREAL1K3 x.| <=XXREAL-3R1  |.EXTREAL1K3 x -SUPINF-2K5 y .| +SUPINF-2K4  |.EXTREAL1K3 y.|"
          using extreal1_th_24 sorry
        thus " |.EXTREAL1K3 x.| -SUPINF-2K5  |.EXTREAL1K3 y.| <=XXREAL-3R1  |.EXTREAL1K3 x -XXREAL-3K3 y .|"
          using xxreal_3_th_42 sorry
      qed
      have case2: "x be RealXREAL-0M1 implies  |.EXTREAL1K3 x.| -SUPINF-2K5  |.EXTREAL1K3 y.| <=XXREAL-3R1  |.EXTREAL1K3 x -XXREAL-3K3 y .|"
      proof(rule impI)
        assume "x be RealXREAL-0M1"
        then obtain a where 
          [ty]:"a be RealXREAL-0M1" and aDef:"a = x"
           sorry
        have A2: " |.EXTREAL1K3 x.| =XBOOLE-0R4  |.EXTREAL1K3 a.|"
           sorry
        show " |.EXTREAL1K3 x.| -SUPINF-2K5  |.EXTREAL1K3 y.| <=XXREAL-3R1  |.EXTREAL1K3 x -XXREAL-3K3 y .|"
        proof-
          have cases: "(y =XBOOLE-0R4 +inftySUPINF-1K1 or y =XBOOLE-0R4 -inftySUPINF-1K2) or y <>HIDDENR2 +inftySUPINF-1K1 & y <>HIDDENR2 -inftySUPINF-1K2"
             sorry
          have case1: "y =XBOOLE-0R4 +inftySUPINF-1K1 or y =XBOOLE-0R4 -inftySUPINF-1K2 implies  |.EXTREAL1K3 x.| -SUPINF-2K5  |.EXTREAL1K3 y.| <=XXREAL-3R1  |.EXTREAL1K3 x -XXREAL-3K3 y .|"
          proof(rule impI)
            assume A3: "y =XBOOLE-0R4 +inftySUPINF-1K1 or y =XBOOLE-0R4 -inftySUPINF-1K2"
            have " |.EXTREAL1K3 y.| =XBOOLE-0R4 +inftySUPINF-1K1"
              using extreal1_th_30 A3 sorry
            then have " |.EXTREAL1K3 x.| -SUPINF-2K5  |.EXTREAL1K3 y.| =XBOOLE-0R4 -inftySUPINF-1K2"
              using A2 xxreal_3_th_13 sorry
            then have " |.EXTREAL1K3 x.| -SUPINF-2K5  |.EXTREAL1K3 y.| <=XXREAL-3R1  |.EXTREAL1K3 x -SUPINF-2K5 y .|"
               sorry
            thus " |.EXTREAL1K3 x.| -SUPINF-2K5  |.EXTREAL1K3 y.| <=XXREAL-3R1  |.EXTREAL1K3 x -XXREAL-3K3 y .|"
               sorry
          qed
          have case2: "y <>HIDDENR2 +inftySUPINF-1K1 & y <>HIDDENR2 -inftySUPINF-1K2 implies  |.EXTREAL1K3 x.| -SUPINF-2K5  |.EXTREAL1K3 y.| <=XXREAL-3R1  |.EXTREAL1K3 x -XXREAL-3K3 y .|"
          proof(rule impI)
            assume "y <>HIDDENR2 +inftySUPINF-1K1 & y <>HIDDENR2 -inftySUPINF-1K2"
            then obtain b where 
              [ty]:"b be ElementSUBSET-1M1-of REALNUMBERSK2" and bDef:"b = y"
              using xxreal_0_th_14 sorry
            have "x -SUPINF-2K5 y =XBOOLE-0R4 a -XCMPLX-0K6 b"
              using supinf_2_th_3 sorry
            then have A4: " |.EXTREAL1K3 x -SUPINF-2K5 y .| =HIDDENR1  |.COMPLEX1K10 a -XCMPLX-0K6 b .|"
              using extreal1_th_12 sorry
            have " |.EXTREAL1K3 y.| =HIDDENR1  |.COMPLEX1K10 b.|"
              using extreal1_th_12 sorry
            then have " |.EXTREAL1K3 x.| -SUPINF-2K5  |.EXTREAL1K3 y.| =XBOOLE-0R4  |.COMPLEX1K10 a.| -XCMPLX-0K6  |.COMPLEX1K10 b.|"
              using A2 supinf_2_th_3 sorry
            thus " |.EXTREAL1K3 x.| -SUPINF-2K5  |.EXTREAL1K3 y.| <=XXREAL-3R1  |.EXTREAL1K3 x -XXREAL-3K3 y .|"
              using A4 complex1_th_59 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem extreal1_th_32:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  |.EXTREAL1K3 x -XXREAL-3K3 y .| <=XXREAL-3R1  |.EXTREAL1K3 x.| +SUPINF-2K4  |.EXTREAL1K3 y.|"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  |.EXTREAL1K3 x -XXREAL-3K3 y .| <=XXREAL-3R1  |.EXTREAL1K3 x.| +SUPINF-2K4  |.EXTREAL1K3 y.|"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    have 
      [ty]:"x be R-ealSUPINF-1M1" and
      [ty]:"y be R-ealSUPINF-1M1"
      using xxreal_0_def_1 sorry
    show " |.EXTREAL1K3 x -XXREAL-3K3 y .| <=XXREAL-3R1  |.EXTREAL1K3 x.| +SUPINF-2K4  |.EXTREAL1K3 y.|"
    proof-
      have cases: "(x =XBOOLE-0R4 +inftySUPINF-1K1 or x =XBOOLE-0R4 -inftySUPINF-1K2) or x <>HIDDENR2 +inftySUPINF-1K1 & x <>HIDDENR2 -inftySUPINF-1K2"
         sorry
      have case1: "x =XBOOLE-0R4 +inftySUPINF-1K1 or x =XBOOLE-0R4 -inftySUPINF-1K2 implies  |.EXTREAL1K3 x -XXREAL-3K3 y .| <=XXREAL-3R1  |.EXTREAL1K3 x.| +SUPINF-2K4  |.EXTREAL1K3 y.|"
      proof(rule impI)
        assume "x =XBOOLE-0R4 +inftySUPINF-1K1 or x =XBOOLE-0R4 -inftySUPINF-1K2"
        then have " |.EXTREAL1K3 x.| +SUPINF-2K4  |.EXTREAL1K3 y.| =XBOOLE-0R4 +inftySUPINF-1K1"
          using extreal1_th_30 xxreal_3_def_2 sorry
        thus " |.EXTREAL1K3 x -XXREAL-3K3 y .| <=XXREAL-3R1  |.EXTREAL1K3 x.| +SUPINF-2K4  |.EXTREAL1K3 y.|"
          using xxreal_0_th_3 sorry
      qed
      have case2: "x <>HIDDENR2 +inftySUPINF-1K1 & x <>HIDDENR2 -inftySUPINF-1K2 implies  |.EXTREAL1K3 x -XXREAL-3K3 y .| <=XXREAL-3R1  |.EXTREAL1K3 x.| +SUPINF-2K4  |.EXTREAL1K3 y.|"
      proof(rule impI)
        assume A1: "x <>HIDDENR2 +inftySUPINF-1K1 & x <>HIDDENR2 -inftySUPINF-1K2"
        then obtain a where 
          [ty]:"a be ElementSUBSET-1M1-of REALNUMBERSK2" and aDef:"a = x"
          using xxreal_0_th_14 sorry
        show " |.EXTREAL1K3 x -XXREAL-3K3 y .| <=XXREAL-3R1  |.EXTREAL1K3 x.| +SUPINF-2K4  |.EXTREAL1K3 y.|"
        proof-
          have cases: "(y =XBOOLE-0R4 +inftySUPINF-1K1 or y =XBOOLE-0R4 -inftySUPINF-1K2) or y <>HIDDENR2 +inftySUPINF-1K1 & y <>HIDDENR2 -inftySUPINF-1K2"
             sorry
          have case1: "y =XBOOLE-0R4 +inftySUPINF-1K1 implies  |.EXTREAL1K3 x -XXREAL-3K3 y .| <=XXREAL-3R1  |.EXTREAL1K3 x.| +SUPINF-2K4  |.EXTREAL1K3 y.|"
          proof(rule impI)
            assume A2: "y =XBOOLE-0R4 +inftySUPINF-1K1"
            have "x -SUPINF-2K5 y =XBOOLE-0R4 -inftySUPINF-1K2"
              using A1 A2 xxreal_3_th_13 sorry
            thus " |.EXTREAL1K3 x -XXREAL-3K3 y .| <=XXREAL-3R1  |.EXTREAL1K3 x.| +SUPINF-2K4  |.EXTREAL1K3 y.|"
              using A2 extreal1_th_30 xxreal_3_def_2 sorry
          qed
          have case2: "y =XBOOLE-0R4 -inftySUPINF-1K2 implies  |.EXTREAL1K3 x -XXREAL-3K3 y .| <=XXREAL-3R1  |.EXTREAL1K3 x.| +SUPINF-2K4  |.EXTREAL1K3 y.|"
          proof(rule impI)
            assume A3: "y =XBOOLE-0R4 -inftySUPINF-1K2"
            have "x -SUPINF-2K5 y =XBOOLE-0R4 +inftySUPINF-1K1"
              using A1 A3 xxreal_3_th_14 sorry
            thus " |.EXTREAL1K3 x -XXREAL-3K3 y .| <=XXREAL-3R1  |.EXTREAL1K3 x.| +SUPINF-2K4  |.EXTREAL1K3 y.|"
              using A3 extreal1_th_30 xxreal_3_def_2 sorry
          qed
          have case3: "y <>HIDDENR2 +inftySUPINF-1K1 & y <>HIDDENR2 -inftySUPINF-1K2 implies  |.EXTREAL1K3 x -XXREAL-3K3 y .| <=XXREAL-3R1  |.EXTREAL1K3 x.| +SUPINF-2K4  |.EXTREAL1K3 y.|"
          proof(rule impI)
            assume "y <>HIDDENR2 +inftySUPINF-1K1 & y <>HIDDENR2 -inftySUPINF-1K2"
            then obtain b where 
              [ty]:"b be ElementSUBSET-1M1-of REALNUMBERSK2" and bDef:"b = y"
              using xxreal_0_th_14 sorry
            have " |.EXTREAL1K3 x.| =HIDDENR1  |.COMPLEX1K10 a.| &  |.EXTREAL1K3 y.| =HIDDENR1  |.COMPLEX1K10 b.|"
              using extreal1_th_12 sorry
            then have A4: " |.EXTREAL1K3 x.| +SUPINF-2K4  |.EXTREAL1K3 y.| =XBOOLE-0R4  |.COMPLEX1K10 a.| +XCMPLX-0K2  |.COMPLEX1K10 b.|"
              using supinf_2_th_1 sorry
            have "x -SUPINF-2K5 y =XBOOLE-0R4 a -REAL-1K5 b"
              using supinf_2_th_3 sorry
            then have " |.EXTREAL1K3 x -SUPINF-2K5 y .| =HIDDENR1  |.COMPLEX1K10 a -REAL-1K5 b .|"
              using extreal1_th_12 sorry
            thus " |.EXTREAL1K3 x -XXREAL-3K3 y .| <=XXREAL-3R1  |.EXTREAL1K3 x.| +SUPINF-2K4  |.EXTREAL1K3 y.|"
              using A4 complex1_th_57 sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 sorry
        qed
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CT*)
mtheorem extreal1_th_34:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for w be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds  |.EXTREAL1K3 x.| <=XXREAL-3R1 z &  |.EXTREAL1K3 y.| <=XXREAL-3R1 w implies  |.EXTREAL1K3 x +XXREAL-3K1 y .| <=XXREAL-3R1 z +XXREAL-3K1 w"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for w be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds  |.EXTREAL1K3 x.| <=XXREAL-3R1 z &  |.EXTREAL1K3 y.| <=XXREAL-3R1 w implies  |.EXTREAL1K3 x +XXREAL-3K1 y .| <=XXREAL-3R1 z +XXREAL-3K1 w"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix w assume [ty]: "w be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: " |.EXTREAL1K3 x.| <=XXREAL-3R1 z &  |.EXTREAL1K3 y.| <=XXREAL-3R1 w"
    then have "-XXREAL-3K2 z <=XXREAL-3R1 x & -XXREAL-3K2 w <=XXREAL-3R1 y"
      using extreal1_th_23 sorry
    then have A2: "(-XXREAL-3K2 z)+XXREAL-3K1 (-XXREAL-3K2 w) <=XXREAL-3R1 x +XXREAL-3K1 y"
      using xxreal_3_th_36 sorry
    have "x <=XXREAL-3R1 z & y <=XXREAL-3R1 w"
      using A1 extreal1_th_23 sorry
    then have A3: "x +XXREAL-3K1 y <=XXREAL-3R1 z +XXREAL-3K1 w"
      using xxreal_3_th_36 sorry
    have "(-XXREAL-3K2 z)-XXREAL-3K3 w =HIDDENR1 -XXREAL-3K2 (z +XXREAL-3K1 w)"
      using xxreal_3_th_25 sorry
    thus " |.EXTREAL1K3 x +XXREAL-3K1 y .| <=XXREAL-3R1 z +XXREAL-3K1 w"
      using A3 A2 extreal1_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem extreal1_th_35:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x be RealXREAL-0M1 or y be RealXREAL-0M1 implies  |.EXTREAL1K3  |.EXTREAL1K3 x.| -SUPINF-2K5  |.EXTREAL1K3 y.| .| <=XXREAL-3R1  |.EXTREAL1K3 x -XXREAL-3K3 y .|"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x be RealXREAL-0M1 or y be RealXREAL-0M1 implies  |.EXTREAL1K3  |.EXTREAL1K3 x.| -SUPINF-2K5  |.EXTREAL1K3 y.| .| <=XXREAL-3R1  |.EXTREAL1K3 x -XXREAL-3K3 y .|"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    have A1: " |.EXTREAL1K3 y.| -SUPINF-2K5  |.EXTREAL1K3 x.| =XBOOLE-0R4 -SUPINF-2K3 ( |.EXTREAL1K3 x.| -SUPINF-2K5  |.EXTREAL1K3 y.|)"
      using xxreal_3_th_26 sorry
    assume A2: "x be RealXREAL-0M1 or y be RealXREAL-0M1"
    then have A3: " |.EXTREAL1K3 x.| -SUPINF-2K5  |.EXTREAL1K3 y.| <=XXREAL-3R1  |.EXTREAL1K3 x -XXREAL-3K3 y .|"
      using extreal1_th_31 sorry
    have "y -XXREAL-3K3 x =HIDDENR1 -XXREAL-3K2 (x -XXREAL-3K3 y)"
      using xxreal_3_th_26 sorry
    then have A4: " |.EXTREAL1K3 y -XXREAL-3K3 x .| =XBOOLE-0R4  |.EXTREAL1K3 x -XXREAL-3K3 y .|"
      using extreal1_th_29 sorry
    have " |.EXTREAL1K3 y.| -SUPINF-2K5  |.EXTREAL1K3 x.| <=XXREAL-3R1  |.EXTREAL1K3 y -XXREAL-3K3 x .|"
      using A2 extreal1_th_31 sorry
    then have "-SUPINF-2K3  |.EXTREAL1K3 x -XXREAL-3K3 y .| <=XXREAL-3R1 -SUPINF-2K3 (-SUPINF-2K3 ( |.EXTREAL1K3 x.| -SUPINF-2K5  |.EXTREAL1K3 y.|))"
      using A4 A1 xxreal_3_th_38 sorry
    thus " |.EXTREAL1K3  |.EXTREAL1K3 x.| -SUPINF-2K5  |.EXTREAL1K3 y.| .| <=XXREAL-3R1  |.EXTREAL1K3 x -XXREAL-3K3 y .|"
      using A3 extreal1_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem extreal1_th_36:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-3R1 x *XXREAL-3K4 y implies  |.EXTREAL1K3 x +XXREAL-3K1 y .| =XBOOLE-0R4  |.EXTREAL1K3 x.| +SUPINF-2K4  |.EXTREAL1K3 y.|"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-3R1 x *XXREAL-3K4 y implies  |.EXTREAL1K3 x +XXREAL-3K1 y .| =XBOOLE-0R4  |.EXTREAL1K3 x.| +SUPINF-2K4  |.EXTREAL1K3 y.|"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-3R1 x *XXREAL-3K4 y"
    show " |.EXTREAL1K3 x +XXREAL-3K1 y .| =XBOOLE-0R4  |.EXTREAL1K3 x.| +SUPINF-2K4  |.EXTREAL1K3 y.|"
    proof-
      have cases: "(0NUMBERSK6 <=XXREAL-3R1 x or 0NUMBERSK6 <XXREAL-0R3 x) & (0NUMBERSK6 <=XXREAL-3R1 y or 0NUMBERSK6 <XXREAL-0R3 y) or (x <=XXREAL-3R1 0NUMBERSK6 or x <XXREAL-0R3 0NUMBERSK6) & (y <=XXREAL-3R1 0NUMBERSK6 or y <XXREAL-0R3 0NUMBERSK6)"
        using A1 sorry
      have case1: "(0NUMBERSK6 <=XXREAL-3R1 x or 0NUMBERSK6 <XXREAL-0R3 x) & (0NUMBERSK6 <=XXREAL-3R1 y or 0NUMBERSK6 <XXREAL-0R3 y) implies  |.EXTREAL1K3 x +XXREAL-3K1 y .| =XBOOLE-0R4  |.EXTREAL1K3 x.| +SUPINF-2K4  |.EXTREAL1K3 y.|"
      proof(rule impI)
        assume "(0NUMBERSK6 <=XXREAL-3R1 x or 0NUMBERSK6 <XXREAL-0R3 x) & (0NUMBERSK6 <=XXREAL-3R1 y or 0NUMBERSK6 <XXREAL-0R3 y)"
        then have " |.EXTREAL1K3 x.| =HIDDENR1 x &  |.EXTREAL1K3 y.| =HIDDENR1 y"
          using extreal1_def_1 sorry
        thus " |.EXTREAL1K3 x +XXREAL-3K1 y .| =XBOOLE-0R4  |.EXTREAL1K3 x.| +SUPINF-2K4  |.EXTREAL1K3 y.|"
          using extreal1_def_1 sorry
      qed
      have case2: "(x <=XXREAL-3R1 0NUMBERSK6 or x <XXREAL-0R3 0NUMBERSK6) & (y <=XXREAL-3R1 0NUMBERSK6 or y <XXREAL-0R3 0NUMBERSK6) implies  |.EXTREAL1K3 x +XXREAL-3K1 y .| =XBOOLE-0R4  |.EXTREAL1K3 x.| +SUPINF-2K4  |.EXTREAL1K3 y.|"
      proof(rule impI)
        assume A2: "(x <=XXREAL-3R1 0NUMBERSK6 or x <XXREAL-0R3 0NUMBERSK6) & (y <=XXREAL-3R1 0NUMBERSK6 or y <XXREAL-0R3 0NUMBERSK6)"
        then have A3: " |.EXTREAL1K3 x +XXREAL-3K1 y .| =HIDDENR1 -XXREAL-3K2 (x +XXREAL-3K1 y)"
          using extreal1_th_18 sorry
        also have "... = (-XXREAL-3K2 x)-XXREAL-3K3 y"
          using xxreal_3_th_25 sorry
        finally have " |.EXTREAL1K3 x +XXREAL-3K1 y .| =HIDDENR1 (-XXREAL-3K2 x)-XXREAL-3K3 y"
           sorry
        have " |.EXTREAL1K3 x.| =HIDDENR1 -XXREAL-3K2 x"
          using A2 extreal1_th_18 sorry
        thus " |.EXTREAL1K3 x +XXREAL-3K1 y .| =XBOOLE-0R4  |.EXTREAL1K3 x.| +SUPINF-2K4  |.EXTREAL1K3 y.|"
          using A2 A3 extreal1_th_18 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem extreal1_th_37:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds (x <>HIDDENR2 +inftySUPINF-1K1 & y <>HIDDENR2 +inftySUPINF-1K1) &  not (x =HIDDENR1 +inftySUPINF-1K1 & y =HIDDENR1 +inftySUPINF-1K1 or x =HIDDENR1 -inftySUPINF-1K2 & y =HIDDENR1 -inftySUPINF-1K2) implies minXXREAL-0K4(x,y) =HIDDENR1 ((x +XXREAL-3K1 y)-XXREAL-3K3  |.EXTREAL1K3 x -XXREAL-3K3 y .|)/EXTREAL1K2 \<two>\<^sub>M"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x <>HIDDENR2 +inftySUPINF-1K1 & (y <>HIDDENR2 +inftySUPINF-1K1 &  not (x =HIDDENR1 +inftySUPINF-1K1 & y =HIDDENR1 +inftySUPINF-1K1 or x =HIDDENR1 -inftySUPINF-1K2 & y =HIDDENR1 -inftySUPINF-1K2)) implies minXXREAL-0K4(x,y) =HIDDENR1 ((x +XXREAL-3K1 y)-XXREAL-3K3  |.EXTREAL1K3 x -XXREAL-3K3 y .|)/EXTREAL1K2 \<two>\<^sub>M"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "x <>HIDDENR2 +inftySUPINF-1K1"
      and A2: "y <>HIDDENR2 +inftySUPINF-1K1"
      and A3: " not (x =HIDDENR1 +inftySUPINF-1K1 & y =HIDDENR1 +inftySUPINF-1K1 or x =HIDDENR1 -inftySUPINF-1K2 & y =HIDDENR1 -inftySUPINF-1K2)"
    show "minXXREAL-0K4(x,y) =HIDDENR1 ((x +XXREAL-3K1 y)-XXREAL-3K3  |.EXTREAL1K3 x -XXREAL-3K3 y .|)/EXTREAL1K2 \<two>\<^sub>M"
    proof-
      have cases: "x =HIDDENR1 -inftySUPINF-1K2 or x <>HIDDENR2 -inftySUPINF-1K2"
         sorry
      have case1: "x =HIDDENR1 -inftySUPINF-1K2 implies minXXREAL-0K4(x,y) =HIDDENR1 ((x +XXREAL-3K1 y)-XXREAL-3K3  |.EXTREAL1K3 x -XXREAL-3K3 y .|)/EXTREAL1K2 \<two>\<^sub>M"
      proof(rule impI)
        assume A4: "x =HIDDENR1 -inftySUPINF-1K2"
        then have "x +XXREAL-3K1 y =HIDDENR1 -inftySUPINF-1K2 & x -XXREAL-3K3 y =HIDDENR1 -inftySUPINF-1K2"
          using A2 A3 xxreal_3_th_14 xxreal_3_def_2 sorry
        then have A5: "(x +XXREAL-3K1 y)-XXREAL-3K3  |.EXTREAL1K3 x -XXREAL-3K3 y .| =HIDDENR1 -inftySUPINF-1K2"
          using xxreal_3_th_14 sorry
        have A6: "minXXREAL-0K4(x,y) =HIDDENR1 -inftySUPINF-1K2"
          using A4 xxreal_0_th_44 sorry
        show "minXXREAL-0K4(x,y) =HIDDENR1 ((x +XXREAL-3K1 y)-XXREAL-3K3  |.EXTREAL1K3 x -XXREAL-3K3 y .|)/EXTREAL1K2 \<two>\<^sub>M"
          using A6 A5 xxreal_3_th_86 sorry
      qed
      have case2: "x <>HIDDENR2 -inftySUPINF-1K2 implies minXXREAL-0K4(x,y) =HIDDENR1 ((x +XXREAL-3K1 y)-XXREAL-3K3  |.EXTREAL1K3 x -XXREAL-3K3 y .|)/EXTREAL1K2 \<two>\<^sub>M"
      proof(rule impI)
        assume "x <>HIDDENR2 -inftySUPINF-1K2"
        then obtain a where 
          [ty]:"a be ElementSUBSET-1M1-of REALNUMBERSK2" and aDef:"a = x"
          using A1 xxreal_0_th_14 sorry
        show "minXXREAL-0K4(x,y) =HIDDENR1 ((x +XXREAL-3K1 y)-XXREAL-3K3  |.EXTREAL1K3 x -XXREAL-3K3 y .|)/EXTREAL1K2 \<two>\<^sub>M"
        proof-
          have cases: "y =HIDDENR1 -inftySUPINF-1K2 or y <>HIDDENR2 -inftySUPINF-1K2"
             sorry
          have case1: "y =HIDDENR1 -inftySUPINF-1K2 implies minXXREAL-0K4(x,y) =HIDDENR1 ((x +XXREAL-3K1 y)-XXREAL-3K3  |.EXTREAL1K3 x -XXREAL-3K3 y .|)/EXTREAL1K2 \<two>\<^sub>M"
          proof(rule impI)
            assume A7: "y =HIDDENR1 -inftySUPINF-1K2"
            then have "x +XXREAL-3K1 y =HIDDENR1 -inftySUPINF-1K2 & x -XXREAL-3K3 y =HIDDENR1 +inftySUPINF-1K1"
              using A1 A3 xxreal_3_th_14 xxreal_3_def_2 sorry
            then have A8: "(x +XXREAL-3K1 y)-XXREAL-3K3  |.EXTREAL1K3 x -XXREAL-3K3 y .| =HIDDENR1 -inftySUPINF-1K2"
              using xxreal_3_th_14 sorry
            have A9: "minXXREAL-0K4(x,y) =HIDDENR1 -inftySUPINF-1K2"
              using A7 xxreal_0_th_44 sorry
            show "minXXREAL-0K4(x,y) =HIDDENR1 ((x +XXREAL-3K1 y)-XXREAL-3K3  |.EXTREAL1K3 x -XXREAL-3K3 y .|)/EXTREAL1K2 \<two>\<^sub>M"
              using A9 A8 xxreal_3_th_86 sorry
          qed
          have case2: "y <>HIDDENR2 -inftySUPINF-1K2 implies minXXREAL-0K4(x,y) =HIDDENR1 ((x +XXREAL-3K1 y)-XXREAL-3K3  |.EXTREAL1K3 x -XXREAL-3K3 y .|)/EXTREAL1K2 \<two>\<^sub>M"
          proof(rule impI)
            assume "y <>HIDDENR2 -inftySUPINF-1K2"
            then obtain b where 
              [ty]:"b be ElementSUBSET-1M1-of REALNUMBERSK2" and bDef:"b = y"
              using A2 xxreal_0_th_14 sorry
            have "x -XXREAL-3K3 y =HIDDENR1 a -REAL-1K5 b"
              using supinf_2_th_3 sorry
            then have "x +XXREAL-3K1 y =HIDDENR1 a +REAL-1K3 b &  |.EXTREAL1K3 x -XXREAL-3K3 y .| =XBOOLE-0R4  |.EXTREAL1K3 a -REAL-1K5 b .|"
              using supinf_2_th_1 sorry
            then have A10: "(x +XXREAL-3K1 y)-XXREAL-3K3  |.EXTREAL1K3 x -XXREAL-3K3 y .| =HIDDENR1 (a +REAL-1K3 b)-XCMPLX-0K6  |.COMPLEX1K10 a -REAL-1K5 b .|"
              using supinf_2_th_3 sorry
            have "((x +XXREAL-3K1 y)-XXREAL-3K3  |.EXTREAL1K3 x -XXREAL-3K3 y .|)/EXTREAL1K2 \<two>\<^sub>M =XBOOLE-0R4 ((a +REAL-1K3 b)-XCMPLX-0K6  |.COMPLEX1K10 a -REAL-1K5 b .|)/EXTREAL1K2 \<two>\<^sub>M"
              using A10 sorry
            thus "minXXREAL-0K4(x,y) =HIDDENR1 ((x +XXREAL-3K1 y)-XXREAL-3K3  |.EXTREAL1K3 x -XXREAL-3K3 y .|)/EXTREAL1K2 \<two>\<^sub>M"
              using complex1_th_73 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem extreal1_th_38:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds (x <>HIDDENR2 -inftySUPINF-1K2 & y <>HIDDENR2 -inftySUPINF-1K2) &  not (x =HIDDENR1 +inftySUPINF-1K1 & y =HIDDENR1 +inftySUPINF-1K1 or x =HIDDENR1 -inftySUPINF-1K2 & y =HIDDENR1 -inftySUPINF-1K2) implies maxXXREAL-0K5(x,y) =HIDDENR1 ((x +XXREAL-3K1 y)+XXREAL-3K1  |.EXTREAL1K3 x -XXREAL-3K3 y .|)/EXTREAL1K2 \<two>\<^sub>M"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x <>HIDDENR2 -inftySUPINF-1K2 & (y <>HIDDENR2 -inftySUPINF-1K2 &  not (x =HIDDENR1 +inftySUPINF-1K1 & y =HIDDENR1 +inftySUPINF-1K1 or x =HIDDENR1 -inftySUPINF-1K2 & y =HIDDENR1 -inftySUPINF-1K2)) implies maxXXREAL-0K5(x,y) =HIDDENR1 ((x +XXREAL-3K1 y)+XXREAL-3K1  |.EXTREAL1K3 x -XXREAL-3K3 y .|)/EXTREAL1K2 \<two>\<^sub>M"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "x <>HIDDENR2 -inftySUPINF-1K2"
      and A2: "y <>HIDDENR2 -inftySUPINF-1K2"
      and A3: " not (x =HIDDENR1 +inftySUPINF-1K1 & y =HIDDENR1 +inftySUPINF-1K1 or x =HIDDENR1 -inftySUPINF-1K2 & y =HIDDENR1 -inftySUPINF-1K2)"
    show "maxXXREAL-0K5(x,y) =HIDDENR1 ((x +XXREAL-3K1 y)+XXREAL-3K1  |.EXTREAL1K3 x -XXREAL-3K3 y .|)/EXTREAL1K2 \<two>\<^sub>M"
    proof-
      have cases: "x =HIDDENR1 +inftySUPINF-1K1 or x <>HIDDENR2 +inftySUPINF-1K1"
         sorry
      have case1: "x =HIDDENR1 +inftySUPINF-1K1 implies maxXXREAL-0K5(x,y) =HIDDENR1 ((x +XXREAL-3K1 y)+XXREAL-3K1  |.EXTREAL1K3 x -XXREAL-3K3 y .|)/EXTREAL1K2 \<two>\<^sub>M"
      proof(rule impI)
        assume A4: "x =HIDDENR1 +inftySUPINF-1K1"
        then have "x +XXREAL-3K1 y =HIDDENR1 +inftySUPINF-1K1 & x -XXREAL-3K3 y =HIDDENR1 +inftySUPINF-1K1"
          using A2 A3 xxreal_3_th_13 xxreal_3_def_2 sorry
        then have A5: "(x +XXREAL-3K1 y)+XXREAL-3K1  |.EXTREAL1K3 x -XXREAL-3K3 y .| =HIDDENR1 +inftySUPINF-1K1"
          using xxreal_3_def_2 sorry
        have A6: "maxXXREAL-0K5(x,y) =HIDDENR1 +inftySUPINF-1K1"
          using A4 xxreal_0_th_41 sorry
        show "maxXXREAL-0K5(x,y) =HIDDENR1 ((x +XXREAL-3K1 y)+XXREAL-3K1  |.EXTREAL1K3 x -XXREAL-3K3 y .|)/EXTREAL1K2 \<two>\<^sub>M"
          using A6 A5 xxreal_3_th_83 sorry
      qed
      have case2: "x <>HIDDENR2 +inftySUPINF-1K1 implies maxXXREAL-0K5(x,y) =HIDDENR1 ((x +XXREAL-3K1 y)+XXREAL-3K1  |.EXTREAL1K3 x -XXREAL-3K3 y .|)/EXTREAL1K2 \<two>\<^sub>M"
      proof(rule impI)
        assume "x <>HIDDENR2 +inftySUPINF-1K1"
        then obtain a where 
          [ty]:"a be ElementSUBSET-1M1-of REALNUMBERSK2" and aDef:"a = x"
          using A1 xxreal_0_th_14 sorry
        show "maxXXREAL-0K5(x,y) =HIDDENR1 ((x +XXREAL-3K1 y)+XXREAL-3K1  |.EXTREAL1K3 x -XXREAL-3K3 y .|)/EXTREAL1K2 \<two>\<^sub>M"
        proof-
          have cases: "y =HIDDENR1 +inftySUPINF-1K1 or y <>HIDDENR2 +inftySUPINF-1K1"
             sorry
          have case1: "y =HIDDENR1 +inftySUPINF-1K1 implies maxXXREAL-0K5(x,y) =HIDDENR1 ((x +XXREAL-3K1 y)+XXREAL-3K1  |.EXTREAL1K3 x -XXREAL-3K3 y .|)/EXTREAL1K2 \<two>\<^sub>M"
          proof(rule impI)
            assume A7: "y =HIDDENR1 +inftySUPINF-1K1"
            then have "x +XXREAL-3K1 y =HIDDENR1 +inftySUPINF-1K1 & x -XXREAL-3K3 y =HIDDENR1 -inftySUPINF-1K2"
              using A1 A3 xxreal_3_th_13 xxreal_3_def_2 sorry
            then have A8: "(x +XXREAL-3K1 y)+XXREAL-3K1  |.EXTREAL1K3 x -XXREAL-3K3 y .| =HIDDENR1 +inftySUPINF-1K1"
              using xxreal_3_def_2 sorry
            have A9: "maxXXREAL-0K5(x,y) =HIDDENR1 +inftySUPINF-1K1"
              using A7 xxreal_0_th_41 sorry
            show "maxXXREAL-0K5(x,y) =HIDDENR1 ((x +XXREAL-3K1 y)+XXREAL-3K1  |.EXTREAL1K3 x -XXREAL-3K3 y .|)/EXTREAL1K2 \<two>\<^sub>M"
              using A9 A8 xxreal_3_th_83 sorry
          qed
          have case2: "y <>HIDDENR2 +inftySUPINF-1K1 implies maxXXREAL-0K5(x,y) =HIDDENR1 ((x +XXREAL-3K1 y)+XXREAL-3K1  |.EXTREAL1K3 x -XXREAL-3K3 y .|)/EXTREAL1K2 \<two>\<^sub>M"
          proof(rule impI)
            assume "y <>HIDDENR2 +inftySUPINF-1K1"
            then obtain b where 
              [ty]:"b be ElementSUBSET-1M1-of REALNUMBERSK2" and bDef:"b = y"
              using A2 xxreal_0_th_14 sorry
            have "x -XXREAL-3K3 y =HIDDENR1 a -REAL-1K5 b"
              using supinf_2_th_3 sorry
            then have "x +XXREAL-3K1 y =HIDDENR1 a +REAL-1K3 b &  |.EXTREAL1K3 x -XXREAL-3K3 y .| =XBOOLE-0R4  |.EXTREAL1K3 a -REAL-1K5 b .|"
              using supinf_2_th_1 sorry
            then have A10: "(x +XXREAL-3K1 y)+XXREAL-3K1  |.EXTREAL1K3 x -XXREAL-3K3 y .| =HIDDENR1 (a +REAL-1K3 b)+XCMPLX-0K2  |.COMPLEX1K10 a -REAL-1K5 b .|"
              using supinf_2_th_1 sorry
            have "((x +XXREAL-3K1 y)+XXREAL-3K1  |.EXTREAL1K3 x -XXREAL-3K3 y .|)/EXTREAL1K2 \<two>\<^sub>M =XBOOLE-0R4 ((a +REAL-1K3 b)+XCMPLX-0K2  |.COMPLEX1K10 a -REAL-1K5 b .|)/EXTREAL1K2 \<two>\<^sub>M"
              using A10 sorry
            thus "maxXXREAL-0K5(x,y) =HIDDENR1 ((x +XXREAL-3K1 y)+XXREAL-3K1  |.EXTREAL1K3 x -XXREAL-3K3 y .|)/EXTREAL1K2 \<two>\<^sub>M"
              using complex1_th_74 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) EXTREAL1K5("maxEXTREAL1K5'( _ , _ ')" [0,0]228) where
  "maxEXTREAL1K5(x,y) \<equiv> maxXXREAL-0K5(x,y)"

mtheorem extreal1_add_3:
  mlet "x be R-ealSUPINF-1M1", "y be R-ealSUPINF-1M1"
"cluster maxXXREAL-0K5(x,y) as-term-is R-ealSUPINF-1M1"
proof
(*coherence*)
  show "maxXXREAL-0K5(x,y) be R-ealSUPINF-1M1"
    using xxreal_0_def_1 sorry
qed "sorry"

abbreviation(input) EXTREAL1K6("minEXTREAL1K6'( _ , _ ')" [0,0]228) where
  "minEXTREAL1K6(x,y) \<equiv> minXXREAL-0K4(x,y)"

mtheorem extreal1_add_4:
  mlet "x be R-ealSUPINF-1M1", "y be R-ealSUPINF-1M1"
"cluster minXXREAL-0K4(x,y) as-term-is R-ealSUPINF-1M1"
proof
(*coherence*)
  show "minXXREAL-0K4(x,y) be R-ealSUPINF-1M1"
    using xxreal_0_def_1 sorry
qed "sorry"

mtheorem extreal1_th_39:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds minXXREAL-0K4(x,y) +XXREAL-3K1 maxXXREAL-0K5(x,y) =HIDDENR1 x +XXREAL-3K1 y"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds minXXREAL-0K4(x,y) +XXREAL-3K1 maxXXREAL-0K5(x,y) =HIDDENR1 x +XXREAL-3K1 y"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    show "minXXREAL-0K4(x,y) +XXREAL-3K1 maxXXREAL-0K5(x,y) =HIDDENR1 x +XXREAL-3K1 y"
    proof-
      have cases: "x <=XXREAL-3R1 y or  not x <=XXREAL-3R1 y"
         sorry
      have case1: "x <=XXREAL-3R1 y implies minXXREAL-0K4(x,y) +XXREAL-3K1 maxXXREAL-0K5(x,y) =HIDDENR1 x +XXREAL-3K1 y"
      proof(rule impI)
        assume A1: "x <=XXREAL-3R1 y"
        then have "minXXREAL-0K4(x,y) =HIDDENR1 x"
          using xxreal_0_def_9 sorry
        thus "minXXREAL-0K4(x,y) +XXREAL-3K1 maxXXREAL-0K5(x,y) =HIDDENR1 x +XXREAL-3K1 y"
          using A1 xxreal_0_def_10 sorry
      qed
      have case2: " not x <=XXREAL-3R1 y implies minXXREAL-0K4(x,y) +XXREAL-3K1 maxXXREAL-0K5(x,y) =HIDDENR1 x +XXREAL-3K1 y"
      proof(rule impI)
        assume A2: " not x <=XXREAL-3R1 y"
        then have "minXXREAL-0K4(x,y) =HIDDENR1 y"
          using xxreal_0_def_9 sorry
        thus "minXXREAL-0K4(x,y) +XXREAL-3K1 maxXXREAL-0K5(x,y) =HIDDENR1 x +XXREAL-3K1 y"
          using A2 xxreal_0_def_10 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem extreal1_th_40:
" for x be ExtRealXXREAL-0M1 holds  |.EXTREAL1K3 x.| =XBOOLE-0R4 +inftySUPINF-1K1 implies x =HIDDENR1 +inftySUPINF-1K1 or x =HIDDENR1 -inftySUPINF-1K2"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  |.EXTREAL1K3 x.| =XBOOLE-0R4 +inftySUPINF-1K1 implies  not ( not x =HIDDENR1 +inftySUPINF-1K1 &  not x =HIDDENR1 -inftySUPINF-1K2)"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    have A1: " |.EXTREAL1K3 x.| =HIDDENR1 x or -SUPINF-2K3  |.EXTREAL1K3 x.| =HIDDENR1 -XXREAL-3K2 (-XXREAL-3K2 x)"
      using extreal1_def_1 sorry
    assume " |.EXTREAL1K3 x.| =XBOOLE-0R4 +inftySUPINF-1K1"
    thus " not ( not x =HIDDENR1 +inftySUPINF-1K1 &  not x =HIDDENR1 -inftySUPINF-1K2)"
      using A1 xxreal_3_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem extreal1_th_41:
" for x be ExtRealXXREAL-0M1 holds  |.EXTREAL1K3 x.| <XXREAL-0R3 +inftySUPINF-1K1 iff x inHIDDENR3 REALNUMBERSK2"
  using extreal1_th_30 extreal1_th_40 xxreal_0_th_4 xxreal_0_th_14 sorry

end
