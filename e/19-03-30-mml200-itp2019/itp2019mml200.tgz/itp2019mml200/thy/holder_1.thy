theory holder_1
  imports taylor_1 int_2
   "../mizar_extension/E_number"
begin
(*begin*)
reserve a, b, p, q for "RealXREAL-0M1"
mtheorem holder_1_cl_1:
  mlet "x be RealXREAL-0M1"
"cluster right-closed-halflineLIMFUNC1K3 x as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "right-closed-halflineLIMFUNC1K3 x be  non emptyXBOOLE-0V1"
  proof-
    have " not right-closed-halflineLIMFUNC1K3 x be emptyXBOOLE-0V1"
    proof-
      have 
        [ty]:"x be RealXREAL-0M1"
         sorry
      have "x inHIDDENR3 {g where g be RealXREAL-0M1 : x <=XXREAL-0R1 g }"
         sorry
      thus " not right-closed-halflineLIMFUNC1K3 x be emptyXBOOLE-0V1"
        using xxreal_1_th_232 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem holder_1_th_1:
" for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & 0NUMBERSK6 <XXREAL-0R3 q implies ( for a be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a implies a to-powerPOWERK2 p *XCMPLX-0K3 a to-powerPOWERK2 q =COMPLEX1R1 a to-powerPOWERK2 (p +XCMPLX-0K2 q))"
proof(rule ballI,rule ballI,rule impMI ,rule impI,rule ballI,rule impI)
  fix p assume [ty]: "p be RealXREAL-0M1"
  fix q assume [ty]: "q be RealXREAL-0M1"
  assume A1: "0NUMBERSK6 <XXREAL-0R3 p"
    and A2: "0NUMBERSK6 <XXREAL-0R3 q"
  fix a assume [ty]: "a be RealXREAL-0M1"
  assume A3: "0NUMBERSK6 <=XXREAL-0R1 a"
  have "a =COMPLEX1R1 0NUMBERSK6 & a to-powerPOWERK2 p *XCMPLX-0K3 a to-powerPOWERK2 q =COMPLEX1R1 a to-powerPOWERK2 (p +XCMPLX-0K2 q) or a <>HIDDENR2 0NUMBERSK6 & (a <>HIDDENR2 0NUMBERSK6 implies a to-powerPOWERK2 p *XCMPLX-0K3 a to-powerPOWERK2 q =COMPLEX1R1 a to-powerPOWERK2 (p +XCMPLX-0K2 q))"
  proof-
    show "a =COMPLEX1R1 0NUMBERSK6 & a to-powerPOWERK2 p *XCMPLX-0K3 a to-powerPOWERK2 q =COMPLEX1R1 a to-powerPOWERK2 (p +XCMPLX-0K2 q) or a <>HIDDENR2 0NUMBERSK6 & (a <>HIDDENR2 0NUMBERSK6 implies a to-powerPOWERK2 p *XCMPLX-0K3 a to-powerPOWERK2 q =COMPLEX1R1 a to-powerPOWERK2 (p +XCMPLX-0K2 q))"
    proof-
      have cases: "a =COMPLEX1R1 0NUMBERSK6 or a <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "a =COMPLEX1R1 0NUMBERSK6 implies a to-powerPOWERK2 p *XCMPLX-0K3 a to-powerPOWERK2 q =COMPLEX1R1 a to-powerPOWERK2 (p +XCMPLX-0K2 q)"
      proof(rule impI)
        assume A4: "a =COMPLEX1R1 0NUMBERSK6"
        then have "a to-powerPOWERK2 p *XCMPLX-0K3 a to-powerPOWERK2 q =HIDDENR1 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6)to-powerPOWERK2 q"
          using A1 power_def_2 sorry
        also have "... = 0NUMBERSK6"
           sorry
        finally have "a to-powerPOWERK2 p *XCMPLX-0K3 a to-powerPOWERK2 q =HIDDENR1 0NUMBERSK6"
           sorry
        thus "a to-powerPOWERK2 p *XCMPLX-0K3 a to-powerPOWERK2 q =COMPLEX1R1 a to-powerPOWERK2 (p +XCMPLX-0K2 q)"
          using A1 A2 A4 power_def_2 sorry
      qed
      have case2: "a <>HIDDENR2 0NUMBERSK6 implies a to-powerPOWERK2 p *XCMPLX-0K3 a to-powerPOWERK2 q =COMPLEX1R1 a to-powerPOWERK2 (p +XCMPLX-0K2 q)"
      proof(rule impI)
        assume "a <>HIDDENR2 0NUMBERSK6"
        thus "a to-powerPOWERK2 p *XCMPLX-0K3 a to-powerPOWERK2 q =COMPLEX1R1 a to-powerPOWERK2 (p +XCMPLX-0K2 q)"
          using A3 power_th_27 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
  thus "a to-powerPOWERK2 p *XCMPLX-0K3 a to-powerPOWERK2 q =COMPLEX1R1 a to-powerPOWERK2 (p +XCMPLX-0K2 q)"
     sorry
qed "sorry"

mtheorem holder_1_th_2:
" for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & 0NUMBERSK6 <XXREAL-0R3 q implies ( for a be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a implies (a to-powerPOWERK2 p)to-powerPOWERK2 q =COMPLEX1R1 a to-powerPOWERK2 (p *XCMPLX-0K3 q))"
proof(rule ballI,rule ballI,rule impMI ,rule impI,rule ballI,rule impI)
  fix p assume [ty]: "p be RealXREAL-0M1"
  fix q assume [ty]: "q be RealXREAL-0M1"
  assume A1: "0NUMBERSK6 <XXREAL-0R3 p"
    and A2: "0NUMBERSK6 <XXREAL-0R3 q"
  have A3: "0NUMBERSK6 <XXREAL-0R3 p *XCMPLX-0K3 q"
    using A1 A2 xreal_1_th_129 sorry
  fix a assume [ty]: "a be RealXREAL-0M1"
  assume A4: "0NUMBERSK6 <=XXREAL-0R1 a"
  have "a =COMPLEX1R1 0NUMBERSK6 & (a to-powerPOWERK2 p)to-powerPOWERK2 q =COMPLEX1R1 a to-powerPOWERK2 (p *XCMPLX-0K3 q) or a <>HIDDENR2 0NUMBERSK6 & (a <>HIDDENR2 0NUMBERSK6 implies (a to-powerPOWERK2 p)to-powerPOWERK2 q =COMPLEX1R1 a to-powerPOWERK2 (p *XCMPLX-0K3 q))"
  proof-
    show "a =COMPLEX1R1 0NUMBERSK6 & (a to-powerPOWERK2 p)to-powerPOWERK2 q =COMPLEX1R1 a to-powerPOWERK2 (p *XCMPLX-0K3 q) or a <>HIDDENR2 0NUMBERSK6 & (a <>HIDDENR2 0NUMBERSK6 implies (a to-powerPOWERK2 p)to-powerPOWERK2 q =COMPLEX1R1 a to-powerPOWERK2 (p *XCMPLX-0K3 q))"
    proof-
      have cases: "a =COMPLEX1R1 0NUMBERSK6 or a <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "a =COMPLEX1R1 0NUMBERSK6 implies (a to-powerPOWERK2 p)to-powerPOWERK2 q =COMPLEX1R1 a to-powerPOWERK2 (p *XCMPLX-0K3 q)"
      proof(rule impI)
        assume A5: "a =COMPLEX1R1 0NUMBERSK6"
        then have "(a to-powerPOWERK2 p)to-powerPOWERK2 q =HIDDENR1 (0NUMBERSK6)to-powerPOWERK2 q"
          using A1 power_def_2 sorry
        also have "... = 0NUMBERSK6"
          using A2 power_def_2 sorry
        finally have "(a to-powerPOWERK2 p)to-powerPOWERK2 q =HIDDENR1 0NUMBERSK6"
           sorry
        thus "(a to-powerPOWERK2 p)to-powerPOWERK2 q =COMPLEX1R1 a to-powerPOWERK2 (p *XCMPLX-0K3 q)"
          using A3 A5 power_def_2 sorry
      qed
      have case2: "a <>HIDDENR2 0NUMBERSK6 implies (a to-powerPOWERK2 p)to-powerPOWERK2 q =COMPLEX1R1 a to-powerPOWERK2 (p *XCMPLX-0K3 q)"
      proof(rule impI)
        assume "a <>HIDDENR2 0NUMBERSK6"
        thus "(a to-powerPOWERK2 p)to-powerPOWERK2 q =COMPLEX1R1 a to-powerPOWERK2 (p *XCMPLX-0K3 q)"
          using A4 power_th_33 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
  thus "(a to-powerPOWERK2 p)to-powerPOWERK2 q =COMPLEX1R1 a to-powerPOWERK2 (p *XCMPLX-0K3 q)"
     sorry
qed "sorry"

mtheorem holder_1_th_3:
" for p be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 p implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & a <=XXREAL-0R1 b implies a to-powerPOWERK2 p <=XXREAL-0R1 b to-powerPOWERK2 p)"
proof(rule ballI,rule impI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix p assume [ty]: "p be RealXREAL-0M1"
  assume A1: "0NUMBERSK6 <=XXREAL-0R1 p"
  fix a assume [ty]: "a be RealXREAL-0M1"
  fix b assume [ty]: "b be RealXREAL-0M1"
  assume A2: "0NUMBERSK6 <=XXREAL-0R1 a"
    and A3: "a <=XXREAL-0R1 b"
  show "a to-powerPOWERK2 p <=XXREAL-0R1 b to-powerPOWERK2 p"
  proof-
    have cases: "0NUMBERSK6 =COMPLEX1R1 p or 0NUMBERSK6 <XXREAL-0R3 p"
      using A1 sorry
    have case1: "0NUMBERSK6 =COMPLEX1R1 p implies a to-powerPOWERK2 p <=XXREAL-0R1 b to-powerPOWERK2 p"
    proof(rule impI)
      assume S1: "0NUMBERSK6 =COMPLEX1R1 p"
      have "a to-powerPOWERK2 (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M & b to-powerPOWERK2 (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M"
        using power_th_24 sorry
      thus "a to-powerPOWERK2 p <=XXREAL-0R1 b to-powerPOWERK2 p"
        using S1 sorry
    qed
    have case2: "0NUMBERSK6 <XXREAL-0R3 p implies a to-powerPOWERK2 p <=XXREAL-0R1 b to-powerPOWERK2 p"
    proof(rule impI)
      assume S2: "0NUMBERSK6 <XXREAL-0R3 p"
      show "a to-powerPOWERK2 p <=XXREAL-0R1 b to-powerPOWERK2 p"
      proof-
        have cases: "a =COMPLEX1R1 b or a <>HIDDENR2 b"
           sorry
        have case1: "a =COMPLEX1R1 b implies a to-powerPOWERK2 p <=XXREAL-0R1 b to-powerPOWERK2 p"
        proof(rule impI)
          assume "a =COMPLEX1R1 b"
          thus "a to-powerPOWERK2 p <=XXREAL-0R1 b to-powerPOWERK2 p"
             sorry
        qed
        have case2: "a <>HIDDENR2 b implies a to-powerPOWERK2 p <=XXREAL-0R1 b to-powerPOWERK2 p"
        proof(rule impI)
          assume A4: "a <>HIDDENR2 b"
          have A5: "a <XXREAL-0R3 b"
            using A3 A4 xxreal_0_th_1 sorry
          have "a to-powerPOWERK2 p <=XXREAL-0R1 b to-powerPOWERK2 p"
          proof-
            show "a to-powerPOWERK2 p <=XXREAL-0R1 b to-powerPOWERK2 p"
            proof-
              have cases: "a =COMPLEX1R1 0NUMBERSK6 or a <>HIDDENR2 0NUMBERSK6"
                 sorry
              have case1: "a =COMPLEX1R1 0NUMBERSK6 implies a to-powerPOWERK2 p <=XXREAL-0R1 b to-powerPOWERK2 p"
              proof(rule impI)
                assume A6: "a =COMPLEX1R1 0NUMBERSK6"
                then have "a to-powerPOWERK2 p =COMPLEX1R1 0NUMBERSK6"
                  using S2 power_def_2 sorry
                thus "a to-powerPOWERK2 p <=XXREAL-0R1 b to-powerPOWERK2 p"
                  using A3 A4 A6 power_th_34 sorry
              qed
              have case2: "a <>HIDDENR2 0NUMBERSK6 implies a to-powerPOWERK2 p <=XXREAL-0R1 b to-powerPOWERK2 p"
              proof(rule impI)
                assume "a <>HIDDENR2 0NUMBERSK6"
                thus "a to-powerPOWERK2 p <=XXREAL-0R1 b to-powerPOWERK2 p"
                  using A2 A5 S2 power_th_37 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "a to-powerPOWERK2 p <=XXREAL-0R1 b to-powerPOWERK2 p"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem holder_1_th_4:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds ((\<one>\<^sub>M <XXREAL-0R3 p & \<one>\<^sub>M /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q =COMPLEX1R1 \<one>\<^sub>M) & 0NUMBERSK6 <XXREAL-0R3 a) & 0NUMBERSK6 <XXREAL-0R3 b implies a *XCMPLX-0K3 b <=XXREAL-0R1 a #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 b #RPREPOWERK6 q /XCMPLX-0K7 q & (a *XCMPLX-0K3 b =COMPLEX1R1 a #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 b #RPREPOWERK6 q /XCMPLX-0K7 q iff a #RPREPOWERK6 p =COMPLEX1R1 b #RPREPOWERK6 q)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds \<one>\<^sub>M <XXREAL-0R3 p & (\<one>\<^sub>M /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q =COMPLEX1R1 \<one>\<^sub>M & (0NUMBERSK6 <XXREAL-0R3 a & 0NUMBERSK6 <XXREAL-0R3 b)) implies (a *XCMPLX-0K3 b <=XXREAL-0R1 a #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 b #RPREPOWERK6 q /XCMPLX-0K7 q &  not (a *XCMPLX-0K3 b =COMPLEX1R1 a #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 b #RPREPOWERK6 q /XCMPLX-0K7 q &  not a #RPREPOWERK6 p =COMPLEX1R1 b #RPREPOWERK6 q)) &  not (a #RPREPOWERK6 p =COMPLEX1R1 b #RPREPOWERK6 q &  not a *XCMPLX-0K3 b =COMPLEX1R1 a #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 b #RPREPOWERK6 q /XCMPLX-0K7 q)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix q assume [ty]: "q be RealXREAL-0M1"
    assume A1: "\<one>\<^sub>M <XXREAL-0R3 p"
      and A2: "\<one>\<^sub>M /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q =COMPLEX1R1 \<one>\<^sub>M"
      and A3: "0NUMBERSK6 <XXREAL-0R3 a"
      and A4: "0NUMBERSK6 <XXREAL-0R3 b"
    have A5: "0NUMBERSK6 <XXREAL-0R3 b #RPREPOWERK6 q"
      using A4 prepower_th_81 sorry
    obtain pp where 
      [ty]:"pp be RealXREAL-0M1" and ppDef:"pp = \<one>\<^sub>M /XCMPLX-0K7 p"
       sorry
    have "\<one>\<^sub>M -XCMPLX-0K6 pp <>HIDDENR2 0NUMBERSK6"
      using A1 xreal_1_th_189 sorry
    then have A6: "(q \<inverse>XCMPLX-0K5)\<inverse>XCMPLX-0K5 <>HIDDENR2 0NUMBERSK6"
      using A2 sorry
    then have "((\<one>\<^sub>M *XCMPLX-0K3 q +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 p)/XCMPLX-0K7 (p *XCMPLX-0K3 q))*XCMPLX-0K3 (p *XCMPLX-0K3 q) =COMPLEX1R1 \<one>\<^sub>M *XCMPLX-0K3 (p *XCMPLX-0K3 q)"
      using A1 A2 xcmplx_1_th_116 sorry
    then have A7: "q +XCMPLX-0K2 p =COMPLEX1R1 p *XCMPLX-0K3 q"
      using A1 A6 xcmplx_1_th_6 xcmplx_1_th_87 sorry
    then have A8: "(q -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 p =COMPLEX1R1 q"
       sorry
    have A9: "0NUMBERSK6 <XXREAL-0R3 b #RPREPOWERK6 (q -XCMPLX-0K6 \<one>\<^sub>M)"
      using A4 prepower_th_81 sorry
    have A10: "a #RPREPOWERK6 p =COMPLEX1R1 b #RPREPOWERK6 q implies a #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 b #RPREPOWERK6 q /XCMPLX-0K7 q =HIDDENR1 a *XCMPLX-0K3 b"
    proof(rule impI)
      assume A11: "a #RPREPOWERK6 p =COMPLEX1R1 b #RPREPOWERK6 q"
      then have A12: "a #RPREPOWERK6 p =COMPLEX1R1 (b #RPREPOWERK6 (q -XCMPLX-0K6 \<one>\<^sub>M))#RPREPOWERK6 p"
        using A4 A8 prepower_th_91 sorry
      have "a =HIDDENR1 a #RPREPOWERK6 \<one>\<^sub>M"
        using A3 prepower_th_72 sorry
      also have "... = a #RPREPOWERK6 (p *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 p))"
        using A1 xcmplx_1_th_106 sorry
      also have "... = (a #RPREPOWERK6 p)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 p)"
        using A3 prepower_th_91 sorry
      also have "... = (b #RPREPOWERK6 (q -XCMPLX-0K6 \<one>\<^sub>M))#RPREPOWERK6 (p *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 p))"
        using A4 A12 prepower_th_81 prepower_th_91 sorry
      also have "... = (b #RPREPOWERK6 (q -XCMPLX-0K6 \<one>\<^sub>M))#RPREPOWERK6 \<one>\<^sub>M"
        using A1 xcmplx_1_th_106 sorry
      also have "... = b #RPREPOWERK6 (q -XCMPLX-0K6 \<one>\<^sub>M)"
        using A4 prepower_th_72 prepower_th_81 sorry
      finally have "a =HIDDENR1 b #RPREPOWERK6 (q -XCMPLX-0K6 \<one>\<^sub>M)"
         sorry
      then have "a *XCMPLX-0K3 \<one>\<^sub>M =COMPLEX1R1 b #RPREPOWERK6 (q -XCMPLX-0K6 \<one>\<^sub>M)"
         sorry
      then have "a *XCMPLX-0K3 b #RPREPOWERK6 ((\<one>\<^sub>M -XCMPLX-0K6 q)+XCMPLX-0K2 (q -XCMPLX-0K6 \<one>\<^sub>M)) =COMPLEX1R1 b #RPREPOWERK6 (q -XCMPLX-0K6 \<one>\<^sub>M)"
        using A4 prepower_th_71 sorry
      then have "a *XCMPLX-0K3 (b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q) *XCMPLX-0K3 b #RPREPOWERK6 (q -XCMPLX-0K6 \<one>\<^sub>M)) =COMPLEX1R1 \<one>\<^sub>M *XCMPLX-0K3 b #RPREPOWERK6 (q -XCMPLX-0K6 \<one>\<^sub>M)"
        using A4 prepower_th_75 sorry
      then have A13: "(a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q))*XCMPLX-0K3 b #RPREPOWERK6 (q -XCMPLX-0K6 \<one>\<^sub>M) =COMPLEX1R1 \<one>\<^sub>M *XCMPLX-0K3 b #RPREPOWERK6 (q -XCMPLX-0K6 \<one>\<^sub>M)"
         sorry
      have "a #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 b #RPREPOWERK6 q /XCMPLX-0K7 q =HIDDENR1 b #RPREPOWERK6 q *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 p) +XCMPLX-0K2 b #RPREPOWERK6 q /XCMPLX-0K7 q"
        using A11 xcmplx_1_th_99 sorry
      also have "... = b #RPREPOWERK6 q *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 p) +XCMPLX-0K2 b #RPREPOWERK6 q *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 q)"
        using xcmplx_1_th_99 sorry
      also have "... = b #RPREPOWERK6 q *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q)"
         sorry
      also have "... = b #RPREPOWERK6 q *XCMPLX-0K3 (a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q))"
        using A2 A9 A13 xcmplx_1_th_5 sorry
      also have "... = a *XCMPLX-0K3 (b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q) *XCMPLX-0K3 b #RPREPOWERK6 q)"
         sorry
      also have "... = a *XCMPLX-0K3 b #RPREPOWERK6 ((\<one>\<^sub>M -XCMPLX-0K6 q)+XCMPLX-0K2 q)"
        using A4 prepower_th_75 sorry
      also have "... = a *XCMPLX-0K3 b"
        using A4 prepower_th_72 sorry
      finally show "a #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 b #RPREPOWERK6 q /XCMPLX-0K7 q =HIDDENR1 a *XCMPLX-0K3 b"
         sorry
    qed
    have A14: "0NUMBERSK6 <XXREAL-0R3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q)"
      using A4 prepower_th_81 sorry
    then have A15: "(0NUMBERSK6)*XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q) <XXREAL-0R3 a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q)"
      using A3 xreal_1_th_68 sorry
    have " ex h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st domRELAT-1K1 h =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) & ( for x be RealXREAL-0M1 holds x >XXREAL-0R4 0NUMBERSK6 implies (h .FUNCT-1K1 x =COMPLEX1R1 x #RPREPOWERK6 p /XCMPLX-0K7 p & h is-differentiable-inFDIFF-1R1 x) & diffFDIFF-1K1(h,x) =COMPLEX1R1 x #RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M))"
    proof-
      have " ex tVar1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st domRELAT-1K1 tVar1 =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) & ( for x be RealXREAL-0M1 holds  not ( not x >XXREAL-0R4 0NUMBERSK6 &  not ((tVar1 .FUNCT-1K1 x =COMPLEX1R1 x #RPREPOWERK6 p /XCMPLX-0K7 p & tVar1 is-differentiable-inFDIFF-1R1 x) & diffFDIFF-1K1(tVar1,x) =COMPLEX1R1 x #RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M))))"
      proof-
        let ?h = "(\<one>\<^sub>M /XCMPLX-0K7 p)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 p"
        show " ex tVar1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st domRELAT-1K1 tVar1 =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) & ( for x be RealXREAL-0M1 holds  not ( not x >XXREAL-0R4 0NUMBERSK6 &  not ((tVar1 .FUNCT-1K1 x =COMPLEX1R1 x #RPREPOWERK6 p /XCMPLX-0K7 p & tVar1 is-differentiable-inFDIFF-1R1 x) & diffFDIFF-1K1(tVar1,x) =COMPLEX1R1 x #RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M))))"
        proof(rule bexI[of _ "?h"],rule conjMI)
          have "domRELAT-1K1 (#RTAYLOR-1K4 p) =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
            using taylor_1_def_4 sorry
          thus A16: "domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 p)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 p) =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
            using valued_1_def_5 sorry
          have " for x be RealXREAL-0M1 holds x >XXREAL-0R4 0NUMBERSK6 implies ((\<one>\<^sub>M /XCMPLX-0K7 p)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 p).FUNCT-1K1 x =HIDDENR1 x #RPREPOWERK6 p /XCMPLX-0K7 p & ((\<one>\<^sub>M /XCMPLX-0K7 p)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 p is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1((\<one>\<^sub>M /XCMPLX-0K7 p)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 p,x) =HIDDENR1 x #RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M))"
          proof(rule ballI,rule impI,rule conjMI,rule conjMI)
            fix x assume [ty]: "x be RealXREAL-0M1"
            assume A17: "x >XXREAL-0R4 0NUMBERSK6"
            have "x inHIDDENR3 {g where g be RealXREAL-0M1 : 0NUMBERSK6 <XXREAL-0R3 g }"
              using A17 sorry
            then have A18: "x inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
              using xxreal_1_th_230 sorry
            then have "((\<one>\<^sub>M /XCMPLX-0K7 p)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 p).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 p)*XCMPLX-0K3 #RTAYLOR-1K4 p .FUNCT-1K1 x"
              using A16 valued_1_def_5 sorry
            also have "... = (\<one>\<^sub>M /XCMPLX-0K7 p)*XCMPLX-0K3 x #RPREPOWERK6 p"
              using A18 taylor_1_def_4 sorry
            also have "... = x #RPREPOWERK6 p /XCMPLX-0K7 p"
              using xcmplx_1_th_99 sorry
            finally show "((\<one>\<^sub>M /XCMPLX-0K7 p)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 p).FUNCT-1K1 x =HIDDENR1 x #RPREPOWERK6 p /XCMPLX-0K7 p"
               sorry
            have A19: "#RTAYLOR-1K4 p is-differentiable-inFDIFF-1R1 x"
              using A17 taylor_1_th_21 sorry
            thus "(\<one>\<^sub>M /XCMPLX-0K7 p)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 p is-differentiable-inFDIFF-1R1 x"
              using fdiff_1_th_15 sorry
            have "diffFDIFF-1K1((\<one>\<^sub>M /XCMPLX-0K7 p)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 p,x) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 p)*XCMPLX-0K3 (diffFDIFF-1K1(#RTAYLOR-1K4 p,x))"
              using A19 fdiff_1_th_15 sorry
            also have "... = (\<one>\<^sub>M /XCMPLX-0K7 p)*XCMPLX-0K3 (p *XCMPLX-0K3 x #RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M))"
              using A17 taylor_1_th_21 sorry
            also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 p)*XCMPLX-0K3 p)*XCMPLX-0K3 x #RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M)"
               sorry
            also have "... = \<one>\<^sub>M *XCMPLX-0K3 x #RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M)"
              using A1 xcmplx_1_th_106 sorry
            also have "... = x #RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M)"
               sorry
            finally show "diffFDIFF-1K1((\<one>\<^sub>M /XCMPLX-0K7 p)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 p,x) =HIDDENR1 x #RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M)"
               sorry
          qed "sorry"
          thus " for x be RealXREAL-0M1 holds  not ( not x >XXREAL-0R4 0NUMBERSK6 &  not ((((\<one>\<^sub>M /XCMPLX-0K7 p)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 p).FUNCT-1K1 x =COMPLEX1R1 x #RPREPOWERK6 p /XCMPLX-0K7 p & (\<one>\<^sub>M /XCMPLX-0K7 p)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 p is-differentiable-inFDIFF-1R1 x) & diffFDIFF-1K1((\<one>\<^sub>M /XCMPLX-0K7 p)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 p,x) =COMPLEX1R1 x #RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M)))"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    then obtain h where
      [ty]:"h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
      A20: "domRELAT-1K1 h =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"and A21: " for x be RealXREAL-0M1 holds x >XXREAL-0R4 0NUMBERSK6 implies (h .FUNCT-1K1 x =COMPLEX1R1 x #RPREPOWERK6 p /XCMPLX-0K7 p & h is-differentiable-inFDIFF-1R1 x) & diffFDIFF-1K1(h,x) =COMPLEX1R1 x #RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M)"
       sorry
    have " ex g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st domRELAT-1K1 g =XBOOLE-0R4 REALNUMBERSK2 & ( for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds (g .FUNCT-1K1 x =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 q -XCMPLX-0K6 x & g is-differentiable-inFDIFF-1R1 x) & diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M)"
    proof-
      have " ex tVar2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st domRELAT-1K1 tVar2 =XBOOLE-0R4 REALNUMBERSK2 & ( for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds (tVar2 .FUNCT-1K1 x =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 q -XCMPLX-0K6 x & tVar2 is-differentiable-inFDIFF-1R1 x) & diffFDIFF-1K1(tVar2,x) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M)"
      proof-
        let ?U = "\<lambda>Lamb1. InSUBSET-1K10(\<one>\<^sub>M /XCMPLX-0K7 q -XCMPLX-0K6 Lamb1,REALNUMBERSK2)"
        let ?X = "\<lambda>Lamb1. Lamb1 inTARSKIR2 REALNUMBERSK2"
        obtain g where
          [ty]:"g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
          A22: " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds d inTARSKIR2 domRELAT-1K1 g iff ?X(d)"and A23: " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds d inTARSKIR2 domRELAT-1K1 g implies g /.PARTFUN1K7\<^bsub>(REALNUMBERSK2)\<^esub> d =COMPLEX1R1 ?U(d)"
          using partfun2_sch_2 sorry
        show " ex tVar2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st domRELAT-1K1 tVar2 =XBOOLE-0R4 REALNUMBERSK2 & ( for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds (tVar2 .FUNCT-1K1 x =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 q -XCMPLX-0K6 x & tVar2 is-differentiable-inFDIFF-1R1 x) & diffFDIFF-1K1(tVar2,x) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M)"
        proof(rule bexI[of _ "g"])
          have " for x be objectHIDDENM1 holds x inHIDDENR3 REALNUMBERSK2 implies x inHIDDENR3 domRELAT-1K1 g"
            using A22 sorry
          then have A24: "domRELAT-1K1 g c=TARSKIR1 REALNUMBERSK2 & REALNUMBERSK2 c=TARSKIR1 domRELAT-1K1 g"
            using relat_1_def_18 sorry
          then have A25: "domRELAT-1K1 g =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2"
            using xboole_0_def_10 sorry
          have A26: " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds g .FUNCT-1K1 d =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 q -XCMPLX-0K6 d"
          proof(rule ballI)
            fix d assume [ty]: "d be ElementSUBSET-1M1-of REALNUMBERSK2"
            have "g /.PARTFUN1K7\<^bsub>(REALNUMBERSK2)\<^esub> d =COMPLEX1R1 ?U(d)"
              using A23 A25 sorry
            thus "g .FUNCT-1K1 d =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 q -XCMPLX-0K6 d"
              using A25 partfun1_def_6 sorry
          qed "sorry"
          have A27: " for d be RealXREAL-0M1 holds d inHIDDENR3 REALNUMBERSK2 implies g .FUNCT-1K1 d =COMPLEX1R1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 d +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q"
          proof-
            have " for d be RealXREAL-0M1 holds d inHIDDENR3 REALNUMBERSK2 implies g .FUNCT-1K1 d =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 d +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q"
            proof(rule ballI,rule impI)
              fix d assume [ty]: "d be RealXREAL-0M1"
              assume A28: "d inHIDDENR3 REALNUMBERSK2"
              have "g .FUNCT-1K1 d =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 q -XCMPLX-0K6 d"
                using A26 A28 sorry
              also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 d +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q"
                 sorry
              finally show "g .FUNCT-1K1 d =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 d +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q"
                 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          then have A29: "g is-differentiable-onFDIFF-1R2 domRELAT-1K1 g"
            using A25 fdiff_1_th_23 sorry
          have " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds g is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
          proof-
            have " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds g is-differentiable-inFDIFF-1R1 d & diffFDIFF-1K1(g,d) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
            proof(rule ballI,rule conjMI)
              fix d assume [ty]: "d be ElementSUBSET-1M1-of REALNUMBERSK2"
              show "g is-differentiable-inFDIFF-1R1 d"
                using A25 A29 fdiff_1_th_9 sorry
              have "diffFDIFF-1K1(g,d) =HIDDENR1 (g `|FDIFF-1K2 domRELAT-1K1 g).FUNCT-1K1 d"
                using A25 A29 fdiff_1_def_7 sorry
              also have "... = -XCMPLX-0K4 \<one>\<^sub>M"
                using A25 A27 fdiff_1_th_23 sorry
              finally show "diffFDIFF-1K1(g,d) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
                 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          thus "domRELAT-1K1 g =XBOOLE-0R4 REALNUMBERSK2 & ( for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds (g .FUNCT-1K1 x =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 q -XCMPLX-0K6 x & g is-differentiable-inFDIFF-1R1 x) & diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M)"
            using A24 A26 xboole_0_def_10 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    then obtain g where
      [ty]:"g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
      A30: "domRELAT-1K1 g =XBOOLE-0R4 REALNUMBERSK2"and A31: " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds g .FUNCT-1K1 x =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 q -XCMPLX-0K6 x"and A32: " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds g is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
       sorry
    let ?f = "h +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g"
    have A33: "domRELAT-1K1 ?f =HIDDENR1 (right-open-halflineLIMFUNC1K4 (0NUMBERSK6))/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> REALNUMBERSK2"
      using A30 A20 valued_1_def_1 sorry
    also have "... = right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
      using xboole_1_th_28 sorry
    finally have "domRELAT-1K1 ?f =HIDDENR1 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
       sorry
    have A34: " for x be RealXREAL-0M1 holds x inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) implies (?f .FUNCT-1K1 x =COMPLEX1R1 (x #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q)-XCMPLX-0K6 x & ?f is-differentiable-inFDIFF-1R1 x) & diffFDIFF-1K1(?f,x) =COMPLEX1R1 x #RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M) -XCMPLX-0K6 \<one>\<^sub>M"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) implies (h +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 x =HIDDENR1 (x #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q)-XCMPLX-0K6 x & (h +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(h +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g,x) =HIDDENR1 x #RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M) -XCMPLX-0K6 \<one>\<^sub>M)"
      proof(rule ballI,rule impI,rule conjMI,rule conjMI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A35: "x inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
        obtain xx where 
          [ty]:"xx be ElementSUBSET-1M1-of REALNUMBERSK2" and xxDef:"xx = x"
          using xreal_0_def_1 sorry
        have "x inHIDDENR3 {y where y be RealXREAL-0M1 : 0NUMBERSK6 <XXREAL-0R3 y }"
          using A35 xxreal_1_th_230 sorry
        then have A36: " ex y be RealXREAL-0M1 st x =COMPLEX1R1 y & 0NUMBERSK6 <XXREAL-0R3 y"
           sorry
        then have A37: "diffFDIFF-1K1(h,x) =COMPLEX1R1 x #RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M)"
          using A21 sorry
        have "(h +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 x =HIDDENR1 h .FUNCT-1K1 x +XCMPLX-0K2 g .FUNCT-1K1 x"
          using A33 A35 valued_1_def_1 sorry
        also have "... = x #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 g .FUNCT-1K1 xx"
          using A21 A36 sorry
        also have "... = x #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 q -XCMPLX-0K6 x)"
          using A31 sorry
        also have "... = (x #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q)-XCMPLX-0K6 x"
           sorry
        finally show "(h +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 x =HIDDENR1 (x #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q)-XCMPLX-0K6 x"
           sorry
        have A38: "g is-differentiable-inFDIFF-1R1 xx"
          using A32 sorry
        have A39: "h is-differentiable-inFDIFF-1R1 x"
          using A21 A36 sorry
        thus "h +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g is-differentiable-inFDIFF-1R1 x"
          using A38 fdiff_1_th_13 sorry
        have A40: "diffFDIFF-1K1(g,xx) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
          using A32 sorry
        have "diffFDIFF-1K1(h +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g,x) =HIDDENR1 diffFDIFF-1K1(h,x) +XCMPLX-0K2 diffFDIFF-1K1(g,x)"
          using A38 A39 fdiff_1_th_13 sorry
        also have "... = x #RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M) -XCMPLX-0K6 \<one>\<^sub>M"
          using A40 A37 sorry
        finally show "diffFDIFF-1K1(h +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g,x) =HIDDENR1 x #RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M) -XCMPLX-0K6 \<one>\<^sub>M"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A41: " for x be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 x & x <>HIDDENR2 \<one>\<^sub>M implies x <XXREAL-0R3 x #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q"
    proof-
      have " for x be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 x & x <>HIDDENR2 \<one>\<^sub>M implies  not x <XXREAL-0R3 x #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q"
      proof(rule ballI,rule impMI ,rule impI)
        have "\<one>\<^sub>M inTARSKIR2 {y where y be RealXREAL-0M1 : 0NUMBERSK6 <XXREAL-0R3 y }"
           sorry
        then have "\<one>\<^sub>M inTARSKIR2 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
          using xxreal_1_th_230 sorry
        then have A42: "?f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 (\<one>\<^sub>M #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q)-XCMPLX-0K6 \<one>\<^sub>M"
          using A34 sorry
        also have "... = (\<one>\<^sub>M /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q)-XCMPLX-0K6 \<one>\<^sub>M"
          using prepower_th_73 sorry
        also have "... = 0NUMBERSK6"
          using A2 sorry
        finally have "?f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 0NUMBERSK6"
           sorry
        have " for x be RealXREAL-0M1 holds x inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) implies ?f is-differentiable-inFDIFF-1R1 x"
          using A34 sorry
        then have A43: "?f is-differentiable-onFDIFF-1R2 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
          using A33 fdiff_1_th_9 sorry
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A44: "0NUMBERSK6 <XXREAL-0R3 x"
          and A45: "x <>HIDDENR2 \<one>\<^sub>M"
        have "x inHIDDENR3 {y where y be RealXREAL-0M1 : 0NUMBERSK6 <XXREAL-0R3 y }"
          using A44 sorry
        then have A46: "x inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
          using xxreal_1_th_230 sorry
        have "x <XXREAL-0R3 \<one>\<^sub>M &  not x <XXREAL-0R3 x #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q or x >XXREAL-0R4 \<one>\<^sub>M & (x >XXREAL-0R4 \<one>\<^sub>M implies  not x <XXREAL-0R3 x #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q)"
        proof-
          show "x <XXREAL-0R3 \<one>\<^sub>M &  not x <XXREAL-0R3 x #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q or x >XXREAL-0R4 \<one>\<^sub>M & (x >XXREAL-0R4 \<one>\<^sub>M implies  not x <XXREAL-0R3 x #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q)"
          proof-
            have cases: "x <XXREAL-0R3 \<one>\<^sub>M or x >XXREAL-0R4 \<one>\<^sub>M"
              using A45 xxreal_0_th_1 sorry
            have case1: "x <XXREAL-0R3 \<one>\<^sub>M implies  not x <XXREAL-0R3 x #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q"
            proof(rule impI)
              assume "x <XXREAL-0R3 \<one>\<^sub>M"
              then have A47: "\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 \<one>\<^sub>M -XCMPLX-0K6 x"
                using xreal_1_th_15 sorry
              let ?t = "\<one>\<^sub>M -XCMPLX-0K6 x"
              have A48: "\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 p -XCMPLX-0K6 \<one>\<^sub>M"
                using A1 xreal_1_th_14 sorry
              have " for z be objectHIDDENM1 holds z inHIDDENR3 [.RCOMP-1K1 x,x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 x) .] implies z inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
              proof(rule ballI,rule impI)
                fix z assume [ty]: "z be objectHIDDENM1"
                assume "z inHIDDENR3 [.RCOMP-1K1 x,x +XCMPLX-0K2 ?t .]"
                then have "z inHIDDENR3 {r where r be RealXREAL-0M1 : x <=XXREAL-0R1 r & r <=XXREAL-0R1 x +XCMPLX-0K2 ?t }"
                  using rcomp_1_def_1 sorry
                then have " ex r be RealXREAL-0M1 st (r =HIDDENR1 z & x <=XXREAL-0R1 r) & r <=XXREAL-0R1 x +XCMPLX-0K2 ?t"
                   sorry
                then have "z inHIDDENR3 {y where y be RealXREAL-0M1 : 0NUMBERSK6 <XXREAL-0R3 y }"
                  using A44 sorry
                thus "z inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
                  using xxreal_1_th_230 sorry
              qed "sorry"
              then have A49: "[.RCOMP-1K1 x,x +XCMPLX-0K2 ?t .] c=TARSKIR1 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
                 sorry
              have "?f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (0NUMBERSK6)) be continuousFCONT-1V1"
                using A43 fdiff_1_th_25 sorry
              then have A50: "?f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x,x +XCMPLX-0K2 ?t .]) be continuousFCONT-1V1"
                using A49 fcont_1_th_16 sorry
              have "].RCOMP-1K2 x,x +XCMPLX-0K2 ?t .[ c=TARSKIR1 [.RCOMP-1K1 x,x +XCMPLX-0K2 ?t .]"
                using xxreal_1_th_25 sorry
              then have "?f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 x,x +XCMPLX-0K2 ?t .["
                using A43 A49 fdiff_1_th_26 xboole_1_th_1 sorry
              then obtain s where
                [ty]:"s be RealXREAL-0M1" and 
                A51: "0NUMBERSK6 <XXREAL-0R3 s"and A52: "s <XXREAL-0R3 \<one>\<^sub>M"and A53: "?f .FUNCT-1K1 (x +XCMPLX-0K2 ?t) =COMPLEX1R1 ?f .FUNCT-1K1 x +XCMPLX-0K2 ?t *XCMPLX-0K3 (diffFDIFF-1K1(?f,x +XCMPLX-0K2 s *XCMPLX-0K3 ?t))"
                using A33 A47 A49 A50 rolle_th_4 sorry
              have "s *XCMPLX-0K3 ?t <XXREAL-0R3 \<one>\<^sub>M *XCMPLX-0K3 ?t"
                using A47 A52 xreal_1_th_68 sorry
              then have "x +XCMPLX-0K2 s *XCMPLX-0K3 ?t <XXREAL-0R3 x +XCMPLX-0K2 ?t"
                using xreal_1_th_8 sorry
              then have "(x +XCMPLX-0K2 s *XCMPLX-0K3 ?t)to-powerPOWERK2 (p -XCMPLX-0K6 \<one>\<^sub>M) <XXREAL-0R3 (x +XCMPLX-0K2 s *XCMPLX-0K3 ?t)to-powerPOWERK2 (0NUMBERSK6)"
                using A44 A47 A51 A48 power_th_40 sorry
              then have "(x +XCMPLX-0K2 s *XCMPLX-0K3 ?t)#RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M) <XXREAL-0R3 (x +XCMPLX-0K2 s *XCMPLX-0K3 ?t)to-powerPOWERK2 (0NUMBERSK6)"
                using A44 A47 A51 power_def_2 sorry
              then have "(x +XCMPLX-0K2 s *XCMPLX-0K3 ?t)#RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M) <XXREAL-0R3 (x +XCMPLX-0K2 s *XCMPLX-0K3 ?t)#RPREPOWERK6 (0NUMBERSK6)"
                using A44 A47 A51 power_def_2 sorry
              then have "(x +XCMPLX-0K2 s *XCMPLX-0K3 ?t)#RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M) <XXREAL-0R3 \<one>\<^sub>M"
                using A44 A47 A51 prepower_th_71 sorry
              then have A54: "(x +XCMPLX-0K2 s *XCMPLX-0K3 ?t)#RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M) -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
                using xreal_1_th_14 sorry
              have "x +XCMPLX-0K2 s *XCMPLX-0K3 ?t inTARSKIR2 {y where y be RealXREAL-0M1 : 0NUMBERSK6 <XXREAL-0R3 y }"
                using A44 A47 A51 sorry
              then have "x +XCMPLX-0K2 s *XCMPLX-0K3 ?t inTARSKIR2 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
                using xxreal_1_th_230 sorry
              then have "diffFDIFF-1K1(?f,x +XCMPLX-0K2 s *XCMPLX-0K3 ?t) =COMPLEX1R1 (x +XCMPLX-0K2 s *XCMPLX-0K3 ?t)#RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M) -XCMPLX-0K6 \<one>\<^sub>M"
                using A34 sorry
              then have "?t *XCMPLX-0K3 (diffFDIFF-1K1(?f,x +XCMPLX-0K2 s *XCMPLX-0K3 ?t)) <XXREAL-0R3 ?t *XCMPLX-0K3 (0NUMBERSK6)"
                using A47 A54 xreal_1_th_68 sorry
              then have "?f .FUNCT-1K1 x +XCMPLX-0K2 ?t *XCMPLX-0K3 (diffFDIFF-1K1(?f,x +XCMPLX-0K2 s *XCMPLX-0K3 ?t)) <XXREAL-0R3 ?f .FUNCT-1K1 x +XCMPLX-0K2 0NUMBERSK6"
                using xreal_1_th_8 sorry
              then have "0NUMBERSK6 <XXREAL-0R3 (x #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q)-XCMPLX-0K6 x"
                using A34 A46 A42 A53 sorry
              then have "0NUMBERSK6 +XCMPLX-0K2 x <XXREAL-0R3 ((x #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q)-XCMPLX-0K6 x)+XCMPLX-0K2 x"
                using xreal_1_th_8 sorry
              thus " not x <XXREAL-0R3 x #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q"
                 sorry
            qed
            have case2: "x >XXREAL-0R4 \<one>\<^sub>M implies  not x <XXREAL-0R3 x #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q"
            proof(rule impI)
              assume "x >XXREAL-0R4 \<one>\<^sub>M"
              then have A55: "\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 x -XCMPLX-0K6 \<one>\<^sub>M"
                using xreal_1_th_14 sorry
              let ?t = "x -XCMPLX-0K6 \<one>\<^sub>M"
              have " for z be objectHIDDENM1 holds z inHIDDENR3 [.RCOMP-1K1 \<one>\<^sub>M,\<one>\<^sub>M +XCMPLX-0K2 (x -XCMPLX-0K6 \<one>\<^sub>M) .] implies z inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
              proof(rule ballI,rule impI)
                fix z assume [ty]: "z be objectHIDDENM1"
                assume "z inHIDDENR3 [.RCOMP-1K1 \<one>\<^sub>M,\<one>\<^sub>M +XCMPLX-0K2 ?t .]"
                then have "z inHIDDENR3 {r where r be RealXREAL-0M1 : \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 ?t }"
                  using rcomp_1_def_1 sorry
                then have " ex r be RealXREAL-0M1 st (r =HIDDENR1 z & \<one>\<^sub>M <=XXREAL-0R1 r) & r <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 ?t"
                   sorry
                then have "z inHIDDENR3 {y where y be RealXREAL-0M1 : 0NUMBERSK6 <XXREAL-0R3 y }"
                   sorry
                thus "z inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
                  using xxreal_1_th_230 sorry
              qed "sorry"
              then have A56: "[.RCOMP-1K1 \<one>\<^sub>M,\<one>\<^sub>M +XCMPLX-0K2 ?t .] c=TARSKIR1 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
                 sorry
              have A57: "\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 p -XCMPLX-0K6 \<one>\<^sub>M"
                using A1 xreal_1_th_14 sorry
              have "?f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 (0NUMBERSK6)) be continuousFCONT-1V1"
                using A43 fdiff_1_th_25 sorry
              then have A58: "?f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 \<one>\<^sub>M,\<one>\<^sub>M +XCMPLX-0K2 ?t .]) be continuousFCONT-1V1"
                using A56 fcont_1_th_16 sorry
              have "].RCOMP-1K2 \<one>\<^sub>M,\<one>\<^sub>M +XCMPLX-0K2 ?t .[ c=TARSKIR1 [.RCOMP-1K1 \<one>\<^sub>M,\<one>\<^sub>M +XCMPLX-0K2 ?t .]"
                using xxreal_1_th_25 sorry
              then have "?f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 \<one>\<^sub>M,\<one>\<^sub>M +XCMPLX-0K2 ?t .["
                using A43 A56 fdiff_1_th_26 xboole_1_th_1 sorry
              then obtain s where
                [ty]:"s be RealXREAL-0M1" and 
                A59: "0NUMBERSK6 <XXREAL-0R3 s"and "s <XXREAL-0R3 \<one>\<^sub>M"and A60: "?f .FUNCT-1K1 (\<one>\<^sub>M +XCMPLX-0K2 ?t) =COMPLEX1R1 ?f .FUNCT-1K1 \<one>\<^sub>M +XCMPLX-0K2 ?t *XCMPLX-0K3 (diffFDIFF-1K1(?f,\<one>\<^sub>M +XCMPLX-0K2 s *XCMPLX-0K3 ?t))"
                using A33 A55 A56 A58 rolle_th_4 sorry
              have "(0NUMBERSK6)*XCMPLX-0K3 ?t <XXREAL-0R3 s *XCMPLX-0K3 ?t"
                using A55 A59 xreal_1_th_68 sorry
              then have "\<one>\<^sub>M +NAT-1K1 0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M +XCMPLX-0K2 s *XCMPLX-0K3 ?t"
                using xreal_1_th_8 sorry
              then have "\<one>\<^sub>M <XXREAL-0R3 (\<one>\<^sub>M +XCMPLX-0K2 s *XCMPLX-0K3 ?t)#RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M)"
                using A57 prepower_th_86 sorry
              then have A61: "\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 (\<one>\<^sub>M +XCMPLX-0K2 s *XCMPLX-0K3 ?t)#RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M) -XCMPLX-0K6 \<one>\<^sub>M"
                using xreal_1_th_14 sorry
              have "\<one>\<^sub>M +XCMPLX-0K2 s *XCMPLX-0K3 ?t inTARSKIR2 {y where y be RealXREAL-0M1 : 0NUMBERSK6 <XXREAL-0R3 y }"
                using A55 A59 sorry
              then have "\<one>\<^sub>M +XCMPLX-0K2 s *XCMPLX-0K3 ?t inTARSKIR2 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
                using xxreal_1_th_230 sorry
              then have "diffFDIFF-1K1(?f,\<one>\<^sub>M +XCMPLX-0K2 s *XCMPLX-0K3 ?t) =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 s *XCMPLX-0K3 ?t)#RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M) -XCMPLX-0K6 \<one>\<^sub>M"
                using A34 sorry
              then have "?t *XCMPLX-0K3 (0NUMBERSK6) <XXREAL-0R3 ?t *XCMPLX-0K3 (diffFDIFF-1K1(?f,\<one>\<^sub>M +XCMPLX-0K2 s *XCMPLX-0K3 ?t))"
                using A55 A61 xreal_1_th_68 sorry
              then have "0NUMBERSK6 <XXREAL-0R3 (x #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q)-XCMPLX-0K6 x"
                using A34 A46 A42 A60 sorry
              then have "0NUMBERSK6 +XCMPLX-0K2 x <XXREAL-0R3 ((x #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q)-XCMPLX-0K6 x)+XCMPLX-0K2 x"
                using xreal_1_th_8 sorry
              thus " not x <XXREAL-0R3 x #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus " not x <XXREAL-0R3 x #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A62: "(\<one>\<^sub>M -XCMPLX-0K6 q)*XCMPLX-0K3 p +XCMPLX-0K2 q =COMPLEX1R1 0NUMBERSK6"
      using A7 sorry
    have A63: "a *XCMPLX-0K3 b =COMPLEX1R1 a #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 b #RPREPOWERK6 q /XCMPLX-0K7 q implies a #RPREPOWERK6 p =COMPLEX1R1 b #RPREPOWERK6 q"
    proof(rule impI)
      assume "a *XCMPLX-0K3 b =COMPLEX1R1 a #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 b #RPREPOWERK6 q /XCMPLX-0K7 q"
      then have "a *XCMPLX-0K3 b =COMPLEX1R1 a #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 b #RPREPOWERK6 q"
        using xcmplx_1_th_99 sorry
      then have "a *XCMPLX-0K3 b =COMPLEX1R1 a #RPREPOWERK6 p *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 p) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 b #RPREPOWERK6 q"
        using xcmplx_1_th_99 sorry
      then have "a *XCMPLX-0K3 b =COMPLEX1R1 a #RPREPOWERK6 p *XCMPLX-0K3 (b #RPREPOWERK6 (0NUMBERSK6) /XCMPLX-0K7 p) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 b #RPREPOWERK6 q"
        using A4 prepower_th_71 sorry
      then have "a *XCMPLX-0K3 b =COMPLEX1R1 a #RPREPOWERK6 p *XCMPLX-0K3 ((b #RPREPOWERK6 ((\<one>\<^sub>M -XCMPLX-0K6 q)*XCMPLX-0K3 p) *XCMPLX-0K3 b #RPREPOWERK6 q)/XCMPLX-0K7 p) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 b #RPREPOWERK6 q"
        using A4 A62 prepower_th_75 sorry
      then have "a *XCMPLX-0K3 b =COMPLEX1R1 a #RPREPOWERK6 p *XCMPLX-0K3 ((b #RPREPOWERK6 ((\<one>\<^sub>M -XCMPLX-0K6 q)*XCMPLX-0K3 p) /XCMPLX-0K7 p)*XCMPLX-0K3 b #RPREPOWERK6 q) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 b #RPREPOWERK6 q"
        using xcmplx_1_th_74 sorry
      then have "a *XCMPLX-0K3 b =COMPLEX1R1 (a #RPREPOWERK6 p *XCMPLX-0K3 (b #RPREPOWERK6 ((\<one>\<^sub>M -XCMPLX-0K6 q)*XCMPLX-0K3 p) /XCMPLX-0K7 p))*XCMPLX-0K3 b #RPREPOWERK6 q +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 b #RPREPOWERK6 q"
         sorry
      then have "a *XCMPLX-0K3 b =COMPLEX1R1 ((a #RPREPOWERK6 p *XCMPLX-0K3 b #RPREPOWERK6 ((\<one>\<^sub>M -XCMPLX-0K6 q)*XCMPLX-0K3 p))/XCMPLX-0K7 p)*XCMPLX-0K3 b #RPREPOWERK6 q +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 b #RPREPOWERK6 q"
        using xcmplx_1_th_74 sorry
      then have "a *XCMPLX-0K3 b =COMPLEX1R1 ((a #RPREPOWERK6 p *XCMPLX-0K3 b #RPREPOWERK6 ((\<one>\<^sub>M -XCMPLX-0K6 q)*XCMPLX-0K3 p))/XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 b #RPREPOWERK6 q"
         sorry
      then have "a *XCMPLX-0K3 b =COMPLEX1R1 ((a #RPREPOWERK6 p *XCMPLX-0K3 (b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q))#RPREPOWERK6 p)/XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 b #RPREPOWERK6 q"
        using A4 prepower_th_91 sorry
      then have "a *XCMPLX-0K3 b =COMPLEX1R1 ((a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q))#RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 b #RPREPOWERK6 q"
        using A3 A14 prepower_th_78 sorry
      then have "a *XCMPLX-0K3 b #RPREPOWERK6 ((\<one>\<^sub>M -XCMPLX-0K6 q)+XCMPLX-0K2 q) =COMPLEX1R1 ((a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q))#RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 b #RPREPOWERK6 q"
        using A4 prepower_th_72 sorry
      then have "a *XCMPLX-0K3 (b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q) *XCMPLX-0K3 b #RPREPOWERK6 q) =COMPLEX1R1 ((a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q))#RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 b #RPREPOWERK6 q"
        using A4 prepower_th_75 sorry
      then have "(a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q))*XCMPLX-0K3 b #RPREPOWERK6 q =COMPLEX1R1 ((a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q))#RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 b #RPREPOWERK6 q"
         sorry
      then have A64: "a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q) =COMPLEX1R1 (a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q))#RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q"
        using A5 xcmplx_1_th_5 sorry
      have "a *XCMPLX-0K3 (b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q) *XCMPLX-0K3 b #RPREPOWERK6 (q -XCMPLX-0K6 \<one>\<^sub>M)) =HIDDENR1 (a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q))*XCMPLX-0K3 b #RPREPOWERK6 (q -XCMPLX-0K6 \<one>\<^sub>M)"
         sorry
      also have "... = \<one>\<^sub>M *XCMPLX-0K3 b #RPREPOWERK6 (q -XCMPLX-0K6 \<one>\<^sub>M)"
        using A41 A15 A64 sorry
      finally have "a *XCMPLX-0K3 (b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q) *XCMPLX-0K3 b #RPREPOWERK6 (q -XCMPLX-0K6 \<one>\<^sub>M)) =HIDDENR1 \<one>\<^sub>M *XCMPLX-0K3 b #RPREPOWERK6 (q -XCMPLX-0K6 \<one>\<^sub>M)"
         sorry
      then have "a *XCMPLX-0K3 b #RPREPOWERK6 ((\<one>\<^sub>M -XCMPLX-0K6 q)+XCMPLX-0K2 (q -XCMPLX-0K6 \<one>\<^sub>M)) =COMPLEX1R1 b #RPREPOWERK6 (q -XCMPLX-0K6 \<one>\<^sub>M)"
        using A4 prepower_th_75 sorry
      then have "a *XCMPLX-0K3 \<one>\<^sub>M =COMPLEX1R1 b #RPREPOWERK6 (q -XCMPLX-0K6 \<one>\<^sub>M)"
        using A4 prepower_th_71 sorry
      thus "a #RPREPOWERK6 p =COMPLEX1R1 b #RPREPOWERK6 q"
        using A4 A8 prepower_th_91 sorry
    qed
    have "a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q) <=XXREAL-0R1 (a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q))#RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q"
    proof-
      have "a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q) =COMPLEX1R1 \<one>\<^sub>M & a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q) =COMPLEX1R1 (a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q))#RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q or a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q) <>HIDDENR2 \<one>\<^sub>M & (a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q) <>HIDDENR2 \<one>\<^sub>M implies a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q) <=XXREAL-0R1 (a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q))#RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q)"
      proof-
        show "a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q) =COMPLEX1R1 \<one>\<^sub>M & a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q) =COMPLEX1R1 (a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q))#RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q or a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q) <>HIDDENR2 \<one>\<^sub>M & (a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q) <>HIDDENR2 \<one>\<^sub>M implies a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q) <=XXREAL-0R1 (a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q))#RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q)"
        proof-
          have cases: "a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q) =COMPLEX1R1 \<one>\<^sub>M or a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q) <>HIDDENR2 \<one>\<^sub>M"
             sorry
          have case1: "a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q) =COMPLEX1R1 \<one>\<^sub>M implies a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q) =COMPLEX1R1 (a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q))#RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q"
          proof(rule impI)
            assume "a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q) =COMPLEX1R1 \<one>\<^sub>M"
            thus "a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q) =COMPLEX1R1 (a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q))#RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q"
              using A2 prepower_th_73 sorry
          qed
          have case2: "a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q) <>HIDDENR2 \<one>\<^sub>M implies a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q) <=XXREAL-0R1 (a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q))#RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q"
          proof(rule impI)
            assume "a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q) <>HIDDENR2 \<one>\<^sub>M"
            thus "a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q) <=XXREAL-0R1 (a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q))#RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q"
              using A41 A15 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q) <=XXREAL-0R1 (a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q))#RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q"
         sorry
    qed
    then have "(a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q))*XCMPLX-0K3 b #RPREPOWERK6 q <=XXREAL-0R1 ((a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q))#RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 b #RPREPOWERK6 q"
      using A5 xreal_1_th_64 sorry
    then have "a *XCMPLX-0K3 (b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q) *XCMPLX-0K3 b #RPREPOWERK6 q) <=XXREAL-0R1 ((a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q))#RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 b #RPREPOWERK6 q"
       sorry
    then have "a *XCMPLX-0K3 b #RPREPOWERK6 ((\<one>\<^sub>M -XCMPLX-0K6 q)+XCMPLX-0K2 q) <=XXREAL-0R1 ((a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q))#RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 b #RPREPOWERK6 q"
      using A4 prepower_th_75 sorry
    then have "a *XCMPLX-0K3 b <=XXREAL-0R1 ((a *XCMPLX-0K3 b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q))#RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 b #RPREPOWERK6 q"
      using A4 prepower_th_72 sorry
    then have "a *XCMPLX-0K3 b <=XXREAL-0R1 ((a #RPREPOWERK6 p *XCMPLX-0K3 (b #RPREPOWERK6 (\<one>\<^sub>M -XCMPLX-0K6 q))#RPREPOWERK6 p)/XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 b #RPREPOWERK6 q"
      using A3 A14 prepower_th_78 sorry
    then have "a *XCMPLX-0K3 b <=XXREAL-0R1 ((a #RPREPOWERK6 p *XCMPLX-0K3 b #RPREPOWERK6 ((\<one>\<^sub>M -XCMPLX-0K6 q)*XCMPLX-0K3 p))/XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 b #RPREPOWERK6 q"
      using A4 prepower_th_91 sorry
    then have "a *XCMPLX-0K3 b <=XXREAL-0R1 ((a #RPREPOWERK6 p *XCMPLX-0K3 b #RPREPOWERK6 ((\<one>\<^sub>M -XCMPLX-0K6 q)*XCMPLX-0K3 p))/XCMPLX-0K7 p)*XCMPLX-0K3 b #RPREPOWERK6 q +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 b #RPREPOWERK6 q"
       sorry
    then have "a *XCMPLX-0K3 b <=XXREAL-0R1 (a #RPREPOWERK6 p *XCMPLX-0K3 (b #RPREPOWERK6 ((\<one>\<^sub>M -XCMPLX-0K6 q)*XCMPLX-0K3 p) /XCMPLX-0K7 p))*XCMPLX-0K3 b #RPREPOWERK6 q +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 b #RPREPOWERK6 q"
      using xcmplx_1_th_74 sorry
    then have "a *XCMPLX-0K3 b <=XXREAL-0R1 a #RPREPOWERK6 p *XCMPLX-0K3 ((b #RPREPOWERK6 ((\<one>\<^sub>M -XCMPLX-0K6 q)*XCMPLX-0K3 p) /XCMPLX-0K7 p)*XCMPLX-0K3 b #RPREPOWERK6 q) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 b #RPREPOWERK6 q"
       sorry
    then have "a *XCMPLX-0K3 b <=XXREAL-0R1 a #RPREPOWERK6 p *XCMPLX-0K3 ((b #RPREPOWERK6 ((\<one>\<^sub>M -XCMPLX-0K6 q)*XCMPLX-0K3 p) *XCMPLX-0K3 b #RPREPOWERK6 q)/XCMPLX-0K7 p) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 b #RPREPOWERK6 q"
      using xcmplx_1_th_74 sorry
    then have "a *XCMPLX-0K3 b <=XXREAL-0R1 a #RPREPOWERK6 p *XCMPLX-0K3 (b #RPREPOWERK6 ((\<one>\<^sub>M -XCMPLX-0K6 q)*XCMPLX-0K3 p +XCMPLX-0K2 q) /XCMPLX-0K7 p) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 b #RPREPOWERK6 q"
      using A4 prepower_th_75 sorry
    then have "a *XCMPLX-0K3 b <=XXREAL-0R1 a #RPREPOWERK6 p *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 p) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 b #RPREPOWERK6 q"
      using A4 A7 prepower_th_71 sorry
    then have "a *XCMPLX-0K3 b <=XXREAL-0R1 a #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 b #RPREPOWERK6 q"
      using xcmplx_1_th_99 sorry
    thus "(a *XCMPLX-0K3 b <=XXREAL-0R1 a #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 b #RPREPOWERK6 q /XCMPLX-0K7 q &  not (a *XCMPLX-0K3 b =COMPLEX1R1 a #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 b #RPREPOWERK6 q /XCMPLX-0K7 q &  not a #RPREPOWERK6 p =COMPLEX1R1 b #RPREPOWERK6 q)) &  not (a #RPREPOWERK6 p =COMPLEX1R1 b #RPREPOWERK6 q &  not a *XCMPLX-0K3 b =COMPLEX1R1 a #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 b #RPREPOWERK6 q /XCMPLX-0K7 q)"
      using A63 A10 xcmplx_1_th_99 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem holder_1_th_5:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds ((\<one>\<^sub>M <XXREAL-0R3 p & \<one>\<^sub>M /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q =COMPLEX1R1 \<one>\<^sub>M) & 0NUMBERSK6 <=XXREAL-0R1 a) & 0NUMBERSK6 <=XXREAL-0R1 b implies a *XCMPLX-0K3 b <=XXREAL-0R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q & (a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q iff a to-powerPOWERK2 p =COMPLEX1R1 b to-powerPOWERK2 q)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds \<one>\<^sub>M <XXREAL-0R3 p & (\<one>\<^sub>M /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q =COMPLEX1R1 \<one>\<^sub>M & (0NUMBERSK6 <=XXREAL-0R1 a & 0NUMBERSK6 <=XXREAL-0R1 b)) implies (a *XCMPLX-0K3 b <=XXREAL-0R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q &  not (a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q &  not a to-powerPOWERK2 p =COMPLEX1R1 b to-powerPOWERK2 q)) &  not (a to-powerPOWERK2 p =COMPLEX1R1 b to-powerPOWERK2 q &  not a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix q assume [ty]: "q be RealXREAL-0M1"
    assume A1: "\<one>\<^sub>M <XXREAL-0R3 p"
      and A2: "\<one>\<^sub>M /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q =COMPLEX1R1 \<one>\<^sub>M"
      and A3: "0NUMBERSK6 <=XXREAL-0R1 a"
      and A4: "0NUMBERSK6 <=XXREAL-0R1 b"
    have A5: "0NUMBERSK6 <=XXREAL-0R1 a to-powerPOWERK2 p /XCMPLX-0K7 p"
    proof-
      have "0NUMBERSK6 <XXREAL-0R3 a & 0NUMBERSK6 <=XXREAL-0R1 a to-powerPOWERK2 p /XCMPLX-0K7 p or 0NUMBERSK6 =COMPLEX1R1 a & (0NUMBERSK6 =COMPLEX1R1 a implies 0NUMBERSK6 <=XXREAL-0R1 a to-powerPOWERK2 p /XCMPLX-0K7 p)"
      proof-
        show "0NUMBERSK6 <XXREAL-0R3 a & 0NUMBERSK6 <=XXREAL-0R1 a to-powerPOWERK2 p /XCMPLX-0K7 p or 0NUMBERSK6 =COMPLEX1R1 a & (0NUMBERSK6 =COMPLEX1R1 a implies 0NUMBERSK6 <=XXREAL-0R1 a to-powerPOWERK2 p /XCMPLX-0K7 p)"
        proof-
          have cases: "0NUMBERSK6 <XXREAL-0R3 a or 0NUMBERSK6 =COMPLEX1R1 a"
            using A3 sorry
          have case1: "0NUMBERSK6 <XXREAL-0R3 a implies 0NUMBERSK6 <=XXREAL-0R1 a to-powerPOWERK2 p /XCMPLX-0K7 p"
          proof(rule impI)
            assume "0NUMBERSK6 <XXREAL-0R3 a"
            then have "0NUMBERSK6 <XXREAL-0R3 a to-powerPOWERK2 p"
              using power_th_34 sorry
            thus "0NUMBERSK6 <=XXREAL-0R1 a to-powerPOWERK2 p /XCMPLX-0K7 p"
              using A1 sorry
          qed
          have case2: "0NUMBERSK6 =COMPLEX1R1 a implies 0NUMBERSK6 <=XXREAL-0R1 a to-powerPOWERK2 p /XCMPLX-0K7 p"
          proof(rule impI)
            assume "0NUMBERSK6 =COMPLEX1R1 a"
            then have "0NUMBERSK6 =COMPLEX1R1 a to-powerPOWERK2 p"
              using A1 power_def_2 sorry
            thus "0NUMBERSK6 <=XXREAL-0R1 a to-powerPOWERK2 p /XCMPLX-0K7 p"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "0NUMBERSK6 <=XXREAL-0R1 a to-powerPOWERK2 p /XCMPLX-0K7 p"
         sorry
    qed
    obtain pp where 
      [ty]:"pp be RealXREAL-0M1" and ppDef:"pp = \<one>\<^sub>M /XCMPLX-0K7 p"
       sorry
    have "\<one>\<^sub>M /XCMPLX-0K7 p <XXREAL-0R3 \<one>\<^sub>M"
      using A1 xreal_1_th_189 sorry
    then have A6: "\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 \<one>\<^sub>M -XCMPLX-0K6 pp"
      using xreal_1_th_15 sorry
    then have A7: "0NUMBERSK6 <XXREAL-0R3 q"
      using A2 sorry
    have A8: "0NUMBERSK6 <=XXREAL-0R1 b to-powerPOWERK2 q /XCMPLX-0K7 q"
    proof-
      have "0NUMBERSK6 <XXREAL-0R3 b & 0NUMBERSK6 <=XXREAL-0R1 b to-powerPOWERK2 q /XCMPLX-0K7 q or 0NUMBERSK6 =COMPLEX1R1 b & (0NUMBERSK6 =COMPLEX1R1 b implies 0NUMBERSK6 <=XXREAL-0R1 b to-powerPOWERK2 q /XCMPLX-0K7 q)"
      proof-
        show "0NUMBERSK6 <XXREAL-0R3 b & 0NUMBERSK6 <=XXREAL-0R1 b to-powerPOWERK2 q /XCMPLX-0K7 q or 0NUMBERSK6 =COMPLEX1R1 b & (0NUMBERSK6 =COMPLEX1R1 b implies 0NUMBERSK6 <=XXREAL-0R1 b to-powerPOWERK2 q /XCMPLX-0K7 q)"
        proof-
          have cases: "0NUMBERSK6 <XXREAL-0R3 b or 0NUMBERSK6 =COMPLEX1R1 b"
            using A4 sorry
          have case1: "0NUMBERSK6 <XXREAL-0R3 b implies 0NUMBERSK6 <=XXREAL-0R1 b to-powerPOWERK2 q /XCMPLX-0K7 q"
          proof(rule impI)
            assume "0NUMBERSK6 <XXREAL-0R3 b"
            then have "0NUMBERSK6 <XXREAL-0R3 b to-powerPOWERK2 q"
              using power_th_34 sorry
            thus "0NUMBERSK6 <=XXREAL-0R1 b to-powerPOWERK2 q /XCMPLX-0K7 q"
              using A7 sorry
          qed
          have case2: "0NUMBERSK6 =COMPLEX1R1 b implies 0NUMBERSK6 <=XXREAL-0R1 b to-powerPOWERK2 q /XCMPLX-0K7 q"
          proof(rule impI)
            assume "0NUMBERSK6 =COMPLEX1R1 b"
            then have "0NUMBERSK6 =COMPLEX1R1 b to-powerPOWERK2 q"
              using A7 power_def_2 sorry
            thus "0NUMBERSK6 <=XXREAL-0R1 b to-powerPOWERK2 q /XCMPLX-0K7 q"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "0NUMBERSK6 <=XXREAL-0R1 b to-powerPOWERK2 q /XCMPLX-0K7 q"
         sorry
    qed
    have "a *XCMPLX-0K3 b =COMPLEX1R1 0NUMBERSK6 & ((a *XCMPLX-0K3 b <=XXREAL-0R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q &  not (a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q &  not a to-powerPOWERK2 p =COMPLEX1R1 b to-powerPOWERK2 q)) &  not (a to-powerPOWERK2 p =COMPLEX1R1 b to-powerPOWERK2 q &  not a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q)) or a *XCMPLX-0K3 b <>HIDDENR2 0NUMBERSK6 & (a *XCMPLX-0K3 b <>HIDDENR2 0NUMBERSK6 implies (a *XCMPLX-0K3 b <=XXREAL-0R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q &  not (a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q &  not a to-powerPOWERK2 p =COMPLEX1R1 b to-powerPOWERK2 q)) &  not (a to-powerPOWERK2 p =COMPLEX1R1 b to-powerPOWERK2 q &  not a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q))"
    proof-
      show "a *XCMPLX-0K3 b =COMPLEX1R1 0NUMBERSK6 & ((a *XCMPLX-0K3 b <=XXREAL-0R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q &  not (a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q &  not a to-powerPOWERK2 p =COMPLEX1R1 b to-powerPOWERK2 q)) &  not (a to-powerPOWERK2 p =COMPLEX1R1 b to-powerPOWERK2 q &  not a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q)) or a *XCMPLX-0K3 b <>HIDDENR2 0NUMBERSK6 & (a *XCMPLX-0K3 b <>HIDDENR2 0NUMBERSK6 implies (a *XCMPLX-0K3 b <=XXREAL-0R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q &  not (a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q &  not a to-powerPOWERK2 p =COMPLEX1R1 b to-powerPOWERK2 q)) &  not (a to-powerPOWERK2 p =COMPLEX1R1 b to-powerPOWERK2 q &  not a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q))"
      proof-
        have cases: "a *XCMPLX-0K3 b =COMPLEX1R1 0NUMBERSK6 or a *XCMPLX-0K3 b <>HIDDENR2 0NUMBERSK6"
           sorry
        have case1: "a *XCMPLX-0K3 b =COMPLEX1R1 0NUMBERSK6 implies (a *XCMPLX-0K3 b <=XXREAL-0R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q &  not (a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q &  not a to-powerPOWERK2 p =COMPLEX1R1 b to-powerPOWERK2 q)) &  not (a to-powerPOWERK2 p =COMPLEX1R1 b to-powerPOWERK2 q &  not a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q)"
        proof(rule impI)
          assume A9: "a *XCMPLX-0K3 b =COMPLEX1R1 0NUMBERSK6"
          have "a =COMPLEX1R1 0NUMBERSK6 & (a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q iff a to-powerPOWERK2 p =COMPLEX1R1 b to-powerPOWERK2 q) or b =COMPLEX1R1 0NUMBERSK6 & (b =COMPLEX1R1 0NUMBERSK6 implies (a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q iff a to-powerPOWERK2 p =COMPLEX1R1 b to-powerPOWERK2 q))"
          proof-
            show "a =COMPLEX1R1 0NUMBERSK6 & (a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q iff a to-powerPOWERK2 p =COMPLEX1R1 b to-powerPOWERK2 q) or b =COMPLEX1R1 0NUMBERSK6 & (b =COMPLEX1R1 0NUMBERSK6 implies (a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q iff a to-powerPOWERK2 p =COMPLEX1R1 b to-powerPOWERK2 q))"
            proof-
              have cases: "a =COMPLEX1R1 0NUMBERSK6 or b =COMPLEX1R1 0NUMBERSK6"
                using A9 xcmplx_1_th_6 sorry
              have case1: "a =COMPLEX1R1 0NUMBERSK6 implies (a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q iff a to-powerPOWERK2 p =COMPLEX1R1 b to-powerPOWERK2 q)"
              proof(rule impI)
                assume A10: "a =COMPLEX1R1 0NUMBERSK6"
                have A11: "a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q implies a to-powerPOWERK2 p =HIDDENR1 b to-powerPOWERK2 q"
                proof(rule impI)
                  assume "a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q"
                  then have "0NUMBERSK6 =COMPLEX1R1 (0NUMBERSK6)/XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q"
                    using A1 A10 power_def_2 sorry
                  then have "(0NUMBERSK6)*XCMPLX-0K3 q =COMPLEX1R1 (b to-powerPOWERK2 q /XCMPLX-0K7 q)*XCMPLX-0K3 q"
                     sorry
                  then have "0NUMBERSK6 =COMPLEX1R1 b to-powerPOWERK2 q"
                    using A7 xcmplx_1_th_87 sorry
                  then have A12: "0NUMBERSK6 =COMPLEX1R1 (b to-powerPOWERK2 q)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)"
                    using A2 A6 power_def_2 sorry
                  have A13: "0NUMBERSK6 =COMPLEX1R1 b"
                  proof-
                    have "b <>HIDDENR2 0NUMBERSK6 implies  False "
                    proof(rule impI)
                      assume A14: "b <>HIDDENR2 0NUMBERSK6"
                      then have "0NUMBERSK6 =COMPLEX1R1 b to-powerPOWERK2 (q *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 q))"
                        using A4 A12 power_th_33 sorry
                      then have "0NUMBERSK6 =COMPLEX1R1 b to-powerPOWERK2 \<one>\<^sub>M"
                        using A7 xcmplx_1_th_106 sorry
                      thus " False "
                        using A14 power_th_25 sorry
                    qed
                    thus " ?thesis "
                       sorry
                  qed
                  have "a to-powerPOWERK2 p =HIDDENR1 0NUMBERSK6"
                    using A1 A10 power_def_2 sorry
                  also have "... = b to-powerPOWERK2 q"
                    using A7 A13 power_def_2 sorry
                  finally show "a to-powerPOWERK2 p =HIDDENR1 b to-powerPOWERK2 q"
                     sorry
                qed
                have "a to-powerPOWERK2 p =COMPLEX1R1 b to-powerPOWERK2 q implies a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q"
                proof(rule impI)
                  assume "a to-powerPOWERK2 p =COMPLEX1R1 b to-powerPOWERK2 q"
                  then have A15: "b to-powerPOWERK2 q /XCMPLX-0K7 q =HIDDENR1 (0NUMBERSK6)/XCMPLX-0K7 q"
                    using A1 A10 power_def_2 sorry
                  also have "... = 0NUMBERSK6"
                     sorry
                  finally have "b to-powerPOWERK2 q /XCMPLX-0K7 q =HIDDENR1 0NUMBERSK6"
                     sorry
                  have "a to-powerPOWERK2 p /XCMPLX-0K7 p =HIDDENR1 (0NUMBERSK6)/XCMPLX-0K7 p"
                    using A1 A10 power_def_2 sorry
                  also have "... = 0NUMBERSK6"
                     sorry
                  finally have "a to-powerPOWERK2 p /XCMPLX-0K7 p =HIDDENR1 0NUMBERSK6"
                     sorry
                  thus "a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q"
                    using A9 A15 sorry
                qed
                thus "a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q iff a to-powerPOWERK2 p =COMPLEX1R1 b to-powerPOWERK2 q"
                  using A11 sorry
              qed
              have case2: "b =COMPLEX1R1 0NUMBERSK6 implies (a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q iff a to-powerPOWERK2 p =COMPLEX1R1 b to-powerPOWERK2 q)"
              proof(rule impI)
                assume A16: "b =COMPLEX1R1 0NUMBERSK6"
                have A17: "\<one>\<^sub>M /XCMPLX-0K7 p >XXREAL-0R4 0NUMBERSK6"
                  using A1 xreal_1_th_139 sorry
                have A18: "a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q implies b to-powerPOWERK2 q =HIDDENR1 a to-powerPOWERK2 p"
                proof(rule impI)
                  assume "a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q"
                  then have "0NUMBERSK6 =COMPLEX1R1 (0NUMBERSK6)/XCMPLX-0K7 q +XCMPLX-0K2 a to-powerPOWERK2 p /XCMPLX-0K7 p"
                    using A7 A16 power_def_2 sorry
                  then have "(0NUMBERSK6)*XCMPLX-0K3 p =COMPLEX1R1 (a to-powerPOWERK2 p /XCMPLX-0K7 p)*XCMPLX-0K3 p"
                     sorry
                  then have "0NUMBERSK6 =COMPLEX1R1 a to-powerPOWERK2 p"
                    using A1 xcmplx_1_th_87 sorry
                  then have A19: "0NUMBERSK6 =COMPLEX1R1 (a to-powerPOWERK2 p)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
                    using A17 power_def_2 sorry
                  have A20: "0NUMBERSK6 =COMPLEX1R1 a"
                  proof-
                    have "a <>HIDDENR2 0NUMBERSK6 implies  False "
                    proof(rule impI)
                      assume A21: "a <>HIDDENR2 0NUMBERSK6"
                      then have "0NUMBERSK6 =COMPLEX1R1 a to-powerPOWERK2 (p *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 p))"
                        using A3 A19 power_th_33 sorry
                      then have "0NUMBERSK6 =COMPLEX1R1 a to-powerPOWERK2 \<one>\<^sub>M"
                        using A1 xcmplx_1_th_106 sorry
                      thus " False "
                        using A21 power_th_25 sorry
                    qed
                    thus " ?thesis "
                       sorry
                  qed
                  have "b to-powerPOWERK2 q =HIDDENR1 0NUMBERSK6"
                    using A7 A16 power_def_2 sorry
                  also have "... = a to-powerPOWERK2 p"
                    using A1 A20 power_def_2 sorry
                  finally show "b to-powerPOWERK2 q =HIDDENR1 a to-powerPOWERK2 p"
                     sorry
                qed
                have "a to-powerPOWERK2 p =COMPLEX1R1 b to-powerPOWERK2 q implies a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q"
                proof(rule impI)
                  assume "a to-powerPOWERK2 p =COMPLEX1R1 b to-powerPOWERK2 q"
                  then have A22: "a to-powerPOWERK2 p /XCMPLX-0K7 p =HIDDENR1 (0NUMBERSK6)/XCMPLX-0K7 p"
                    using A7 A16 power_def_2 sorry
                  also have "... = 0NUMBERSK6"
                     sorry
                  finally have "a to-powerPOWERK2 p /XCMPLX-0K7 p =HIDDENR1 0NUMBERSK6"
                     sorry
                  have "b to-powerPOWERK2 q /XCMPLX-0K7 q =HIDDENR1 (0NUMBERSK6)/XCMPLX-0K7 q"
                    using A7 A16 power_def_2 sorry
                  also have "... = 0NUMBERSK6"
                     sorry
                  finally have "b to-powerPOWERK2 q /XCMPLX-0K7 q =HIDDENR1 0NUMBERSK6"
                     sorry
                  thus "a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q"
                    using A9 A22 sorry
                qed
                thus "a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q iff a to-powerPOWERK2 p =COMPLEX1R1 b to-powerPOWERK2 q"
                  using A18 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "(a *XCMPLX-0K3 b <=XXREAL-0R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q &  not (a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q &  not a to-powerPOWERK2 p =COMPLEX1R1 b to-powerPOWERK2 q)) &  not (a to-powerPOWERK2 p =COMPLEX1R1 b to-powerPOWERK2 q &  not a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q)"
            using A5 A8 sorry
        qed
        have case2: "a *XCMPLX-0K3 b <>HIDDENR2 0NUMBERSK6 implies (a *XCMPLX-0K3 b <=XXREAL-0R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q &  not (a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q &  not a to-powerPOWERK2 p =COMPLEX1R1 b to-powerPOWERK2 q)) &  not (a to-powerPOWERK2 p =COMPLEX1R1 b to-powerPOWERK2 q &  not a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q)"
        proof(rule impI)
          assume A23: "a *XCMPLX-0K3 b <>HIDDENR2 0NUMBERSK6"
          then have A24: "a <>HIDDENR2 0NUMBERSK6"
             sorry
          have A25: "b <>HIDDENR2 0NUMBERSK6"
            using A23 sorry
          then have "a *XCMPLX-0K3 b =COMPLEX1R1 a #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 b #RPREPOWERK6 q /XCMPLX-0K7 q iff a #RPREPOWERK6 p =COMPLEX1R1 b #RPREPOWERK6 q"
            using A1 A2 A3 A4 A24 holder_1_th_4 sorry
          then have A26: "a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b #RPREPOWERK6 q /XCMPLX-0K7 q iff a to-powerPOWERK2 p =COMPLEX1R1 b #RPREPOWERK6 q"
            using A3 A24 power_def_2 sorry
          have "a *XCMPLX-0K3 b <=XXREAL-0R1 a #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 b #RPREPOWERK6 q /XCMPLX-0K7 q"
            using A1 A2 A3 A4 A24 A25 holder_1_th_4 sorry
          then have "a *XCMPLX-0K3 b <=XXREAL-0R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b #RPREPOWERK6 q /XCMPLX-0K7 q"
            using A3 A24 power_def_2 sorry
          thus "(a *XCMPLX-0K3 b <=XXREAL-0R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q &  not (a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q &  not a to-powerPOWERK2 p =COMPLEX1R1 b to-powerPOWERK2 q)) &  not (a to-powerPOWERK2 p =COMPLEX1R1 b to-powerPOWERK2 q &  not a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q)"
            using A4 A25 A26 power_def_2 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "(a *XCMPLX-0K3 b <=XXREAL-0R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q &  not (a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q &  not a to-powerPOWERK2 p =COMPLEX1R1 b to-powerPOWERK2 q)) &  not (a to-powerPOWERK2 p =COMPLEX1R1 b to-powerPOWERK2 q &  not a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma holder_1_lm_1:
" for a be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
proof(rule ballI,rule impI)
  fix a assume [ty]: "a be Real-SequenceSEQ-1M1"
  assume A1: " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
  let ?P = "\<lambda>Lamb1. a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 <=XXREAL-0R1 Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1"
  have A2: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
  proof-
    have " for n be NatNAT-1M1 holds a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n implies a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix n assume [ty]: "n be NatNAT-1M1"
      assume "?P(n)"
      then have A3: "Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) & a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using series_1_def_1 xreal_1_th_6 sorry
      have "0NUMBERSK6 <=XXREAL-0R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A1 sorry
      then have "0NUMBERSK6 +XCMPLX-0K2 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using xreal_1_th_6 sorry
      thus "a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using A3 xxreal_0_th_2 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have A4: "?P(0NUMBERSK6)"
    using series_1_def_1 sorry
  have " for n be NatNAT-1M1 holds ?P(n)"
    using nat_1_sch_2 A4 A2 sorry
  thus " for n be NatNAT-1M1 holds a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
     sorry
qed "sorry"

mlemma holder_1_lm_2:
" for a be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
proof(rule ballI,rule impI,rule ballI)
  fix a assume [ty]: "a be Real-SequenceSEQ-1M1"
  assume A1: " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
  fix n assume [ty]: "n be NatNAT-1M1"
  have "a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    using A1 holder_1_lm_1 sorry
  thus "0NUMBERSK6 <=XXREAL-0R1 Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    using A1 sorry
qed "sorry"

mlemma holder_1_lm_3:
" for a be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6 implies ( for k be NatNAT-1M1 holds k <=XXREAL-0R1 n implies a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6))"
proof-
  have " for a be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6 implies ( for k be NatNAT-1M1 holds  not (k <=XXREAL-0R1 n &  not a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6)))"
  proof(rule ballI,rule impI,rule ballI,rule impI)
    fix a assume [ty]: "a be Real-SequenceSEQ-1M1"
    assume A1: " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A2: "Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6"
    have " for k be NatNAT-1M1 holds k <=XXREAL-0R1 n implies a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6"
    proof(rule ballI,rule impI)
      have A3: "Partial-SumsSERIES-1K3 a be non-decreasingVALUED-0V11"
        using A1 series_1_th_16 sorry
      fix k assume [ty]: "k be NatNAT-1M1"
      assume "k <=XXREAL-0R1 n"
      then have A4: "Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k <=XXREAL-0R1 Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A3 seqm_3_th_6 sorry
      have "a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k <=XXREAL-0R1 Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A1 holder_1_lm_1 sorry
      thus "a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6"
        using A1 A2 A4 sorry
    qed "sorry"
    thus " for k be NatNAT-1M1 holds  not (k <=XXREAL-0R1 n &  not a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma holder_1_lm_4:
" for a be Real-SequenceSEQ-1M1 holds  for n be NatNAT-1M1 holds ( for k be NatNAT-1M1 holds k <=XXREAL-0R1 n implies a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6) implies Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6"
proof(rule ballI)
  fix a assume [ty]: "a be Real-SequenceSEQ-1M1"
  let ?P = "\<lambda>Lamb1. ( for k be NatNAT-1M1 holds k <=XXREAL-0R1 Lamb1 implies a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6) implies Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 =COMPLEX1R1 0NUMBERSK6"
  have A1: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
  proof-
    have " for n be NatNAT-1M1 holds (( for k be NatNAT-1M1 holds k <=XXREAL-0R1 n implies a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6) implies Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6) implies (( for k be NatNAT-1M1 holds k <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M implies a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6) implies Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 0NUMBERSK6)"
    proof(rule ballI,rule impI)
      fix n assume [ty]: "n be NatNAT-1M1"
      assume A2: "?P(n)"
      have "( for k be NatNAT-1M1 holds k <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M implies a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6) implies Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 0NUMBERSK6"
      proof(rule impI)
        assume A3: " for k be NatNAT-1M1 holds k <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M implies a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6"
        have A4: " for k be NatNAT-1M1 holds k <=XXREAL-0R1 n implies a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6"
        proof(rule ballI,rule impI)
          have A5: "n <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
            using nat_1_th_11 sorry
          fix k assume [ty]: "k be NatNAT-1M1"
          assume "k <=XXREAL-0R1 n"
          thus "a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6"
            using A3 A5 xxreal_0_th_2 sorry
        qed "sorry"
        have "Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        also have "... = 0NUMBERSK6"
          using A2 A3 A4 sorry
        finally show "Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 0NUMBERSK6"
           sorry
      qed
      thus "( for k be NatNAT-1M1 holds k <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M implies a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6) implies Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 0NUMBERSK6"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have A6: "?P(0NUMBERSK6)"
  proof-
    have "( for k be NatNAT-1M1 holds k <=XXREAL-0R1 0NUMBERSK6 implies a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6) implies Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6"
    proof(rule impI)
      assume " for k be NatNAT-1M1 holds k <=XXREAL-0R1 0NUMBERSK6 implies a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6"
      then have "a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6"
         sorry
      thus "Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6"
        using series_1_def_1 sorry
    qed
    thus " ?thesis "
       sorry
  qed
  show " for n be NatNAT-1M1 holds ( for k be NatNAT-1M1 holds k <=XXREAL-0R1 n implies a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6) implies Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6"
    using nat_1_sch_2 A6 A1 sorry
qed "sorry"

(*begin*)
mtheorem holder_1_th_6:
" for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds \<one>\<^sub>M <XXREAL-0R3 p & \<one>\<^sub>M /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q =COMPLEX1R1 \<one>\<^sub>M implies ( for a be Real-SequenceSEQ-1M1 holds  for b be Real-SequenceSEQ-1M1 holds  for ap be Real-SequenceSEQ-1M1 holds  for bq be Real-SequenceSEQ-1M1 holds  for ab be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds (ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p & bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q) & ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)))"
proof(rule ballI,rule ballI,rule impMI ,rule impI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule ballI)
  fix p assume [ty]: "p be RealXREAL-0M1"
  fix q assume [ty]: "q be RealXREAL-0M1"
  assume A1: "\<one>\<^sub>M <XXREAL-0R3 p"
    and A2: "\<one>\<^sub>M /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q =COMPLEX1R1 \<one>\<^sub>M"
  obtain pp where 
    [ty]:"pp be RealXREAL-0M1" and ppDef:"pp = \<one>\<^sub>M /XCMPLX-0K7 p"
     sorry
  fix a assume [ty]: "a be Real-SequenceSEQ-1M1"
  fix b assume [ty]: "b be Real-SequenceSEQ-1M1"
  fix ap assume [ty]: "ap be Real-SequenceSEQ-1M1"
  fix bq assume [ty]: "bq be Real-SequenceSEQ-1M1"
  fix ab assume [ty]: "ab be Real-SequenceSEQ-1M1"
  assume A3: " for n be NatNAT-1M1 holds (ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p & bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q) & ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
  fix n assume [ty]: "n be NatNAT-1M1"
  let ?B = "Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
  have "\<one>\<^sub>M /XCMPLX-0K7 p <XXREAL-0R3 \<one>\<^sub>M"
    using A1 xreal_1_th_189 sorry
  then have A4: "\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 \<one>\<^sub>M -XCMPLX-0K6 pp"
    using xreal_1_th_15 sorry
  then have A5: "0NUMBERSK6 <XXREAL-0R3 q"
    using A2 sorry
  have A6: " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have A7: "bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q"
      using A3 sorry
    have " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 & 0NUMBERSK6 <=XXREAL-0R1 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n or  |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 & ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
    proof-
      show " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 & 0NUMBERSK6 <=XXREAL-0R1 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n or  |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 & ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
      proof-
        have cases: " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 or  |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6"
          using complex1_th_46 sorry
        have case1: " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        proof(rule impI)
          assume " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6"
          thus "0NUMBERSK6 <=XXREAL-0R1 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
            using A5 A7 power_def_2 sorry
        qed
        have case2: " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        proof(rule impI)
          assume " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6"
          thus "0NUMBERSK6 <=XXREAL-0R1 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
            using A7 power_th_34 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "0NUMBERSK6 <=XXREAL-0R1 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
       sorry
  qed "sorry"
  then have A8: "0NUMBERSK6 <=XXREAL-0R1 ?B"
    using holder_1_lm_2 sorry
  let ?A = "Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
  have A9: " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have A10: "ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p"
      using A3 sorry
    have " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 & 0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n or  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 & ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
    proof-
      show " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 & 0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n or  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 & ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
      proof-
        have cases: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 or  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6"
          using complex1_th_46 sorry
        have case1: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        proof(rule impI)
          assume " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6"
          thus "0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
            using A1 A10 power_def_2 sorry
        qed
        have case2: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        proof(rule impI)
          assume " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6"
          thus "0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
            using A10 power_th_34 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
       sorry
  qed "sorry"
  then have A11: "0NUMBERSK6 <=XXREAL-0R1 ?A"
    using holder_1_lm_2 sorry
  let ?Bq = "?B to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)"
  let ?Ap = "?A to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
  have A12: "\<one>\<^sub>M /XCMPLX-0K7 p >XXREAL-0R4 0NUMBERSK6"
    using A1 xreal_1_th_139 sorry
  have "?A *REAL-1K4 ?B =COMPLEX1R1 0NUMBERSK6 & Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q) or ?A *REAL-1K4 ?B <>HIDDENR2 0NUMBERSK6 & (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6 implies Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))"
  proof-
    show "?A *REAL-1K4 ?B =COMPLEX1R1 0NUMBERSK6 & Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q) or ?A *REAL-1K4 ?B <>HIDDENR2 0NUMBERSK6 & (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6 implies Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))"
    proof-
      have cases: "?A *REAL-1K4 ?B =COMPLEX1R1 0NUMBERSK6 or ?A *REAL-1K4 ?B <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6 implies Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)"
      proof(rule impI)
        assume A13: "?A *REAL-1K4 ?B =COMPLEX1R1 0NUMBERSK6"
        have A14: "0NUMBERSK6 <=XXREAL-0R1 ?Ap"
        proof-
          have "0NUMBERSK6 <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
          proof-
            have "0NUMBERSK6 <XXREAL-0R3 ?A & 0NUMBERSK6 <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) or 0NUMBERSK6 =COMPLEX1R1 ?A & (0NUMBERSK6 =COMPLEX1R1 Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n implies 0NUMBERSK6 <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))"
            proof-
              show "0NUMBERSK6 <XXREAL-0R3 ?A & 0NUMBERSK6 <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) or 0NUMBERSK6 =COMPLEX1R1 ?A & (0NUMBERSK6 =COMPLEX1R1 Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n implies 0NUMBERSK6 <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))"
              proof-
                have cases: "0NUMBERSK6 <XXREAL-0R3 ?A or 0NUMBERSK6 =COMPLEX1R1 ?A"
                  using A9 holder_1_lm_2 sorry
                have case1: "0NUMBERSK6 <XXREAL-0R3 Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n implies 0NUMBERSK6 <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
                proof(rule impI)
                  assume "0NUMBERSK6 <XXREAL-0R3 ?A"
                  thus "0NUMBERSK6 <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
                    using power_th_34 sorry
                qed
                have case2: "0NUMBERSK6 =COMPLEX1R1 Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n implies 0NUMBERSK6 <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
                proof(rule impI)
                  assume "0NUMBERSK6 =COMPLEX1R1 ?A"
                  thus "0NUMBERSK6 <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
                    using A12 power_def_2 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "0NUMBERSK6 <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
               sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have "0NUMBERSK6 <=XXREAL-0R1 ?Bq"
        proof-
          have "0NUMBERSK6 <=XXREAL-0R1 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)"
          proof-
            have "0NUMBERSK6 <XXREAL-0R3 ?B & 0NUMBERSK6 <=XXREAL-0R1 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q) or 0NUMBERSK6 =COMPLEX1R1 ?B & (0NUMBERSK6 =COMPLEX1R1 Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n implies 0NUMBERSK6 <=XXREAL-0R1 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))"
            proof-
              show "0NUMBERSK6 <XXREAL-0R3 ?B & 0NUMBERSK6 <=XXREAL-0R1 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q) or 0NUMBERSK6 =COMPLEX1R1 ?B & (0NUMBERSK6 =COMPLEX1R1 Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n implies 0NUMBERSK6 <=XXREAL-0R1 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))"
              proof-
                have cases: "0NUMBERSK6 <XXREAL-0R3 ?B or 0NUMBERSK6 =COMPLEX1R1 ?B"
                  using A6 holder_1_lm_2 sorry
                have case1: "0NUMBERSK6 <XXREAL-0R3 Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n implies 0NUMBERSK6 <=XXREAL-0R1 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)"
                proof(rule impI)
                  assume "0NUMBERSK6 <XXREAL-0R3 ?B"
                  thus "0NUMBERSK6 <=XXREAL-0R1 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)"
                    using power_th_34 sorry
                qed
                have case2: "0NUMBERSK6 =COMPLEX1R1 Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n implies 0NUMBERSK6 <=XXREAL-0R1 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)"
                proof(rule impI)
                  assume "0NUMBERSK6 =COMPLEX1R1 ?B"
                  thus "0NUMBERSK6 <=XXREAL-0R1 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)"
                    using A2 A4 power_def_2 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "0NUMBERSK6 <=XXREAL-0R1 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)"
               sorry
          qed
          thus " ?thesis "
             sorry
        qed
        then have A15: "0NUMBERSK6 <=XXREAL-0R1 ?Ap *XCMPLX-0K3 ?Bq"
          using A14 sorry
        have "?A =COMPLEX1R1 0NUMBERSK6 & Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q) or ?B =COMPLEX1R1 0NUMBERSK6 & (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6 implies Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))"
        proof-
          show "?A =COMPLEX1R1 0NUMBERSK6 & Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q) or ?B =COMPLEX1R1 0NUMBERSK6 & (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6 implies Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))"
          proof-
            have cases: "?A =COMPLEX1R1 0NUMBERSK6 or ?B =COMPLEX1R1 0NUMBERSK6"
              using A13 xcmplx_1_th_6 sorry
            have case1: "Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6 implies Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)"
            proof(rule impI)
              assume A16: "?A =COMPLEX1R1 0NUMBERSK6"
              have A17: " for k be NatNAT-1M1 holds k <=XXREAL-0R1 n implies a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6"
              proof(rule ballI,rule impI)
                fix k assume [ty]: "k be NatNAT-1M1"
                assume "k <=XXREAL-0R1 n"
                then have "ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6"
                  using A9 A16 holder_1_lm_3 sorry
                then have A18: "( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k.|)to-powerPOWERK2 p =COMPLEX1R1 0NUMBERSK6"
                  using A3 sorry
                have " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k.| =COMPLEX1R1 0NUMBERSK6"
                proof-
                  have " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k.| <>HIDDENR2 0NUMBERSK6 implies  False "
                  proof(rule impI)
                    assume " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k.| <>HIDDENR2 0NUMBERSK6"
                    then have " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k.| >XXREAL-0R4 0NUMBERSK6"
                      using complex1_th_46 sorry
                    thus " False "
                      using A18 power_th_34 sorry
                  qed
                  thus " ?thesis "
                     sorry
                qed
                thus "a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6"
                  using absvalue_th_2 sorry
              qed "sorry"
              have " for k be NatNAT-1M1 holds k <=XXREAL-0R1 n implies ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6"
              proof-
                have " for k be NatNAT-1M1 holds k <=XXREAL-0R1 n implies ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =HIDDENR1 0NUMBERSK6"
                proof(rule ballI,rule impI)
                  fix k assume [ty]: "k be NatNAT-1M1"
                  assume A19: "k <=XXREAL-0R1 n"
                  have "ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =HIDDENR1  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k *REAL-1K4 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k .|"
                    using A3 sorry
                  also have "... =  |.COMPLEX1K10 (0NUMBERSK6)*XCMPLX-0K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k .|"
                    using A17 A19 sorry
                  also have "... = 0NUMBERSK6"
                    using absvalue_th_2 sorry
                  finally show "ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =HIDDENR1 0NUMBERSK6"
                     sorry
                qed "sorry"
                thus " ?thesis "
                   sorry
              qed
              thus "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)"
                using A15 holder_1_lm_4 sorry
            qed
            have case2: "Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6 implies Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)"
            proof(rule impI)
              assume A20: "?B =COMPLEX1R1 0NUMBERSK6"
              have A21: " for k be NatNAT-1M1 holds k <=XXREAL-0R1 n implies b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6"
              proof(rule ballI,rule impI)
                fix k assume [ty]: "k be NatNAT-1M1"
                assume "k <=XXREAL-0R1 n"
                then have "bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6"
                  using A6 A20 holder_1_lm_3 sorry
                then have A22: "( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k.|)to-powerPOWERK2 q =COMPLEX1R1 0NUMBERSK6"
                  using A3 sorry
                have " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k.| =COMPLEX1R1 0NUMBERSK6"
                proof-
                  have " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k.| <>HIDDENR2 0NUMBERSK6 implies  False "
                  proof(rule impI)
                    assume " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k.| <>HIDDENR2 0NUMBERSK6"
                    then have " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k.| >XXREAL-0R4 0NUMBERSK6"
                      using complex1_th_46 sorry
                    thus " False "
                      using A22 power_th_34 sorry
                  qed
                  thus " ?thesis "
                     sorry
                qed
                thus "b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6"
                  using absvalue_th_2 sorry
              qed "sorry"
              have " for k be NatNAT-1M1 holds k <=XXREAL-0R1 n implies ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6"
              proof-
                have " for k be NatNAT-1M1 holds k <=XXREAL-0R1 n implies ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =HIDDENR1 0NUMBERSK6"
                proof(rule ballI,rule impI)
                  fix k assume [ty]: "k be NatNAT-1M1"
                  assume A23: "k <=XXREAL-0R1 n"
                  have "ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =HIDDENR1  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k *REAL-1K4 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k .|"
                    using A3 sorry
                  also have "... =  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k *XCMPLX-0K3 (0NUMBERSK6) .|"
                    using A21 A23 sorry
                  also have "... = 0NUMBERSK6"
                    using absvalue_th_2 sorry
                  finally show "ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =HIDDENR1 0NUMBERSK6"
                     sorry
                qed "sorry"
                thus " ?thesis "
                   sorry
              qed
              thus "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)"
                using A15 holder_1_lm_4 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)"
           sorry
      qed
      have case2: "Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6 implies Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)"
      proof(rule impI)
        assume A24: "?A *REAL-1K4 ?B <>HIDDENR2 0NUMBERSK6"
        let ?G = "\<lambda>Lamb1. ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1.|)/XCMPLX-0K7 ?Bq"
        obtain y where
          [ty]:"y be Real-SequenceSEQ-1M1" and 
          A25: " for n be NatNAT-1M1 holds y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ?G(n)"
          using seq_1_sch_1 sorry
        have A26: "?B <>HIDDENR2 0NUMBERSK6"
          using A24 sorry
        then have A27: "?Bq >XXREAL-0R4 0NUMBERSK6"
          using A8 power_th_34 sorry
        have A28: " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|"
            using complex1_th_46 sorry
          then have "0NUMBERSK6 <=XXREAL-0R1 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)/XCMPLX-0K7 ?Bq"
            using A27 sorry
          thus "0NUMBERSK6 <=XXREAL-0R1 y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
            using A25 sorry
        qed "sorry"
        let ?F = "\<lambda>Lamb1. ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1.|)/XCMPLX-0K7 ?Ap"
        obtain x where
          [ty]:"x be Real-SequenceSEQ-1M1" and 
          A29: " for n be NatNAT-1M1 holds x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ?F(n)"
          using seq_1_sch_1 sorry
        have A30: " for n be NatNAT-1M1 holds ((\<one>\<^sub>M /XCMPLX-0K7 (?Ap *XCMPLX-0K3 ?Bq))(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ab).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        proof-
          have " for n be NatNAT-1M1 holds x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 ((Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)))(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ab).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          proof(rule ballI)
            fix n assume [ty]: "n be NatNAT-1M1"
            have "x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)/XCMPLX-0K7 ?Ap & y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)/XCMPLX-0K7 ?Bq"
              using A29 A25 sorry
            then have "x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|))/XCMPLX-0K7 ((Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))"
              using xcmplx_1_th_76 sorry
            also have "... = ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|)/XCMPLX-0K7 ((Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))"
              using complex1_th_65 sorry
            also have "... = ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n /XCMPLX-0K7 ((Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))"
              using A3 sorry
            also have "... = (\<one>\<^sub>M /XCMPLX-0K7 ((Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)))*XCMPLX-0K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
              using xcmplx_1_th_99 sorry
            also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 ((Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)))(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ab).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
              using seq_1_th_9 sorry
            finally show "x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 ((Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)))(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ab).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have A31: "Partial-SumsSERIES-1K3 ((\<one>\<^sub>M /XCMPLX-0K7 (?Ap *XCMPLX-0K3 ?Bq))(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ab) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 (?Ap *XCMPLX-0K3 ?Bq))(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> Partial-SumsSERIES-1K3 ab).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using series_1_th_9 sorry
        also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (?Ap *XCMPLX-0K3 ?Bq))*XCMPLX-0K3 Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using seq_1_th_9 sorry
        finally have "Partial-SumsSERIES-1K3 ((\<one>\<^sub>M /XCMPLX-0K7 (?Ap *XCMPLX-0K3 ?Bq))(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ab) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 (?Ap *XCMPLX-0K3 ?Bq))*XCMPLX-0K3 Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
           sorry
        have A32: "?A <>HIDDENR2 0NUMBERSK6"
          using A24 sorry
        then have A33: "?Ap >XXREAL-0R4 0NUMBERSK6"
          using A11 power_th_34 sorry
        then have A34: "?Ap *XCMPLX-0K3 ?Bq >XXREAL-0R4 0NUMBERSK6"
          using A27 xreal_1_th_129 sorry
        have A35: " for n be NatNAT-1M1 holds ((\<one>\<^sub>M /XCMPLX-0K7 p)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 ?A)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ap) +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 q)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 ?B)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> bq)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 (y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 q /XCMPLX-0K7 q"
        proof-
          have " for n be NatNAT-1M1 holds ((\<one>\<^sub>M /XCMPLX-0K7 p)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ap) +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 q)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> bq)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 (y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 q /XCMPLX-0K7 q"
          proof(rule ballI)
            fix n assume [ty]: "n be NatNAT-1M1"
            have A36: "(( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)/XCMPLX-0K7 ?Ap)to-powerPOWERK2 p =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p /XCMPLX-0K7 ?Ap to-powerPOWERK2 p"
            proof-
              have "(( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)/XCMPLX-0K7 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))to-powerPOWERK2 p =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p /XCMPLX-0K7 ((Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))to-powerPOWERK2 p"
              proof-
                have " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 & (( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)/XCMPLX-0K7 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))to-powerPOWERK2 p =HIDDENR1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p /XCMPLX-0K7 ((Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))to-powerPOWERK2 p or  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| <>HIDDENR2 0NUMBERSK6 & ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| <>HIDDENR2 0NUMBERSK6 implies (( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)/XCMPLX-0K7 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))to-powerPOWERK2 p =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p /XCMPLX-0K7 ((Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))to-powerPOWERK2 p)"
                proof-
                  show " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 & (( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)/XCMPLX-0K7 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))to-powerPOWERK2 p =HIDDENR1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p /XCMPLX-0K7 ((Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))to-powerPOWERK2 p or  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| <>HIDDENR2 0NUMBERSK6 & ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| <>HIDDENR2 0NUMBERSK6 implies (( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)/XCMPLX-0K7 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))to-powerPOWERK2 p =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p /XCMPLX-0K7 ((Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))to-powerPOWERK2 p)"
                  proof-
                    have cases: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 or  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| <>HIDDENR2 0NUMBERSK6"
                       sorry
                    have case1: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 implies (( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)/XCMPLX-0K7 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))to-powerPOWERK2 p =HIDDENR1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p /XCMPLX-0K7 ((Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))to-powerPOWERK2 p"
                    proof(rule impI)
                      assume A37: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6"
                      then have "(( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)/XCMPLX-0K7 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))to-powerPOWERK2 p =HIDDENR1 (0NUMBERSK6)/XCMPLX-0K7 ((Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))to-powerPOWERK2 p"
                        using A1 power_def_2 sorry
                      also have "... = ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p /XCMPLX-0K7 ((Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))to-powerPOWERK2 p"
                        using A1 A37 power_def_2 sorry
                      finally show "(( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)/XCMPLX-0K7 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))to-powerPOWERK2 p =HIDDENR1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p /XCMPLX-0K7 ((Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))to-powerPOWERK2 p"
                         sorry
                    qed
                    have case2: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| <>HIDDENR2 0NUMBERSK6 implies (( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)/XCMPLX-0K7 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))to-powerPOWERK2 p =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p /XCMPLX-0K7 ((Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))to-powerPOWERK2 p"
                    proof(rule impI)
                      assume " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| <>HIDDENR2 0NUMBERSK6"
                      then have " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6"
                        using complex1_th_46 sorry
                      thus "(( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)/XCMPLX-0K7 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))to-powerPOWERK2 p =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p /XCMPLX-0K7 ((Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))to-powerPOWERK2 p"
                        using A33 power_th_31 sorry
                    qed
                    show " ?thesis "
                      using cases case1 case2 sorry
                  qed
                qed
                thus "(( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)/XCMPLX-0K7 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))to-powerPOWERK2 p =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p /XCMPLX-0K7 ((Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))to-powerPOWERK2 p"
                   sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            have A38: "(( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)/XCMPLX-0K7 ?Bq)to-powerPOWERK2 q =COMPLEX1R1 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q /XCMPLX-0K7 ?Bq to-powerPOWERK2 q"
            proof-
              have "(( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)/XCMPLX-0K7 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))to-powerPOWERK2 q =COMPLEX1R1 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q /XCMPLX-0K7 ((Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))to-powerPOWERK2 q"
              proof-
                have " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 & (( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)/XCMPLX-0K7 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))to-powerPOWERK2 q =HIDDENR1 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q /XCMPLX-0K7 ((Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))to-powerPOWERK2 q or  |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| <>HIDDENR2 0NUMBERSK6 & ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| <>HIDDENR2 0NUMBERSK6 implies (( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)/XCMPLX-0K7 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))to-powerPOWERK2 q =COMPLEX1R1 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q /XCMPLX-0K7 ((Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))to-powerPOWERK2 q)"
                proof-
                  show " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 & (( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)/XCMPLX-0K7 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))to-powerPOWERK2 q =HIDDENR1 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q /XCMPLX-0K7 ((Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))to-powerPOWERK2 q or  |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| <>HIDDENR2 0NUMBERSK6 & ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| <>HIDDENR2 0NUMBERSK6 implies (( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)/XCMPLX-0K7 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))to-powerPOWERK2 q =COMPLEX1R1 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q /XCMPLX-0K7 ((Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))to-powerPOWERK2 q)"
                  proof-
                    have cases: " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 or  |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| <>HIDDENR2 0NUMBERSK6"
                       sorry
                    have case1: " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 implies (( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)/XCMPLX-0K7 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))to-powerPOWERK2 q =HIDDENR1 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q /XCMPLX-0K7 ((Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))to-powerPOWERK2 q"
                    proof(rule impI)
                      assume A39: " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6"
                      then have "(( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)/XCMPLX-0K7 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))to-powerPOWERK2 q =HIDDENR1 (0NUMBERSK6)/XCMPLX-0K7 ((Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))to-powerPOWERK2 q"
                        using A5 power_def_2 sorry
                      also have "... = ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q /XCMPLX-0K7 ((Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))to-powerPOWERK2 q"
                        using A5 A39 power_def_2 sorry
                      finally show "(( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)/XCMPLX-0K7 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))to-powerPOWERK2 q =HIDDENR1 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q /XCMPLX-0K7 ((Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))to-powerPOWERK2 q"
                         sorry
                    qed
                    have case2: " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| <>HIDDENR2 0NUMBERSK6 implies (( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)/XCMPLX-0K7 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))to-powerPOWERK2 q =COMPLEX1R1 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q /XCMPLX-0K7 ((Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))to-powerPOWERK2 q"
                    proof(rule impI)
                      assume " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| <>HIDDENR2 0NUMBERSK6"
                      then have " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6"
                        using complex1_th_46 sorry
                      thus "(( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)/XCMPLX-0K7 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))to-powerPOWERK2 q =COMPLEX1R1 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q /XCMPLX-0K7 ((Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))to-powerPOWERK2 q"
                        using A27 power_th_31 sorry
                    qed
                    show " ?thesis "
                      using cases case1 case2 sorry
                  qed
                qed
                thus "(( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)/XCMPLX-0K7 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))to-powerPOWERK2 q =COMPLEX1R1 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q /XCMPLX-0K7 ((Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))to-powerPOWERK2 q"
                   sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            have "y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)/XCMPLX-0K7 ?Bq"
              using A25 sorry
            then have A40: "(y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 q /XCMPLX-0K7 q =HIDDENR1 (bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n /XCMPLX-0K7 ?Bq to-powerPOWERK2 q)/XCMPLX-0K7 q"
              using A3 A38 sorry
            also have "... = (bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n /XCMPLX-0K7 ?B to-powerPOWERK2 ((\<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 q))/XCMPLX-0K7 q"
              using A8 A26 power_th_33 sorry
            also have "... = (bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n /XCMPLX-0K7 ?B to-powerPOWERK2 \<one>\<^sub>M)/XCMPLX-0K7 q"
              using A5 xcmplx_1_th_87 sorry
            also have "... = (bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n /REAL-1K6 ?B)/XCMPLX-0K7 q"
              using power_th_25 sorry
            also have "... = (\<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 (bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n /REAL-1K6 ?B)"
              using xcmplx_1_th_99 sorry
            also have "... = (\<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 ?B)*XCMPLX-0K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
              using xcmplx_1_th_99 sorry
            also have "... = (\<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 ?B)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
              using seq_1_th_9 sorry
            also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 q)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 ?B)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> bq)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
              using seq_1_th_9 sorry
            finally have "(y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 q /XCMPLX-0K7 q =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 q)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 ?B)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> bq)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
               sorry
            have "x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)/XCMPLX-0K7 ?Ap"
              using A29 sorry
            then have "(x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p /XCMPLX-0K7 p =HIDDENR1 (ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n /XCMPLX-0K7 ?Ap to-powerPOWERK2 p)/XCMPLX-0K7 p"
              using A3 A36 sorry
            also have "... = (ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n /XCMPLX-0K7 ?A to-powerPOWERK2 ((\<one>\<^sub>M /XCMPLX-0K7 p)*XCMPLX-0K3 p))/XCMPLX-0K7 p"
              using A11 A32 power_th_33 sorry
            also have "... = (ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n /XCMPLX-0K7 ?A to-powerPOWERK2 \<one>\<^sub>M)/XCMPLX-0K7 p"
              using A1 xcmplx_1_th_87 sorry
            also have "... = (ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n /REAL-1K6 ?A)/XCMPLX-0K7 p"
              using power_th_25 sorry
            also have "... = (\<one>\<^sub>M /XCMPLX-0K7 p)*XCMPLX-0K3 (ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n /REAL-1K6 ?A)"
              using xcmplx_1_th_99 sorry
            also have "... = (\<one>\<^sub>M /XCMPLX-0K7 p)*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 ?A)*XCMPLX-0K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
              using xcmplx_1_th_99 sorry
            also have "... = (\<one>\<^sub>M /XCMPLX-0K7 p)*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 ?A)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ap).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
              using seq_1_th_9 sorry
            also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 p)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 ?A)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ap)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
              using seq_1_th_9 sorry
            finally have "(x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p /XCMPLX-0K7 p =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 p)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 ?A)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ap)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
               sorry
            thus "((\<one>\<^sub>M /XCMPLX-0K7 p)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ap) +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 q)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> bq)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 (y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 q /XCMPLX-0K7 q"
              using A40 seq_1_th_7 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have A41: " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|"
            using complex1_th_46 sorry
          then have "0NUMBERSK6 <=XXREAL-0R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)/XCMPLX-0K7 ?Ap"
            using A33 sorry
          thus "0NUMBERSK6 <=XXREAL-0R1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
            using A29 sorry
        qed "sorry"
        have A42: " for n be NatNAT-1M1 holds x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 (y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 q /XCMPLX-0K7 q & (x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 (y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 q /XCMPLX-0K7 q iff (x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p =COMPLEX1R1 (y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 q)"
        proof-
          have " for n be NatNAT-1M1 holds (x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 (y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 q /XCMPLX-0K7 q &  not (x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 (y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 q /XCMPLX-0K7 q &  not (x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p =COMPLEX1R1 (y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 q)) &  not ((x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p =COMPLEX1R1 (y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 q &  not x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 (y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 q /XCMPLX-0K7 q)"
          proof(rule ballI)
            fix n assume [ty]: "n be NatNAT-1M1"
            have "0NUMBERSK6 <=XXREAL-0R1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & 0NUMBERSK6 <=XXREAL-0R1 y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
              using A41 A28 sorry
            thus "(x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 (y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 q /XCMPLX-0K7 q &  not (x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 (y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 q /XCMPLX-0K7 q &  not (x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p =COMPLEX1R1 (y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 q)) &  not ((x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p =COMPLEX1R1 (y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 q &  not x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 (y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 q /XCMPLX-0K7 q)"
              using A1 A2 holder_1_th_5 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have " for n be NatNAT-1M1 holds ((\<one>\<^sub>M /XCMPLX-0K7 (?Ap *XCMPLX-0K3 ?Bq))(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ab).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 ((\<one>\<^sub>M /XCMPLX-0K7 p)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 ?A)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ap) +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 q)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 ?B)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> bq)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        proof-
          have " for n be NatNAT-1M1 holds ((\<one>\<^sub>M /XCMPLX-0K7 ((Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)))(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ab).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 ((\<one>\<^sub>M /XCMPLX-0K7 p)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ap) +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 q)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> bq)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          proof(rule ballI)
            fix n assume [ty]: "n be NatNAT-1M1"
            have "x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 (y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 q /XCMPLX-0K7 q & ((\<one>\<^sub>M /XCMPLX-0K7 p)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 ?A)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ap) +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 q)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 ?B)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> bq)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 (y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 q /XCMPLX-0K7 q"
              using A42 A35 sorry
            thus "((\<one>\<^sub>M /XCMPLX-0K7 ((Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)))(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ab).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 ((\<one>\<^sub>M /XCMPLX-0K7 p)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ap) +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 q)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> bq)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
              using A30 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        then have A43: "Partial-SumsSERIES-1K3 ((\<one>\<^sub>M /XCMPLX-0K7 (?Ap *XCMPLX-0K3 ?Bq))(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ab) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 Partial-SumsSERIES-1K3 ((\<one>\<^sub>M /XCMPLX-0K7 p)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 ?A)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ap) +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 q)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 ?B)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> bq)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using series_1_th_14 sorry
        have "Partial-SumsSERIES-1K3 ((\<one>\<^sub>M /XCMPLX-0K7 p)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 ?A)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ap) +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 q)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 ?B)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> bq)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (Partial-SumsSERIES-1K3 ((\<one>\<^sub>M /XCMPLX-0K7 p)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 ?A)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ap)) +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> Partial-SumsSERIES-1K3 ((\<one>\<^sub>M /XCMPLX-0K7 q)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 ?B)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> bq))).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using series_1_th_5 sorry
        also have "... = Partial-SumsSERIES-1K3 ((\<one>\<^sub>M /XCMPLX-0K7 p)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 ?A)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ap)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 Partial-SumsSERIES-1K3 ((\<one>\<^sub>M /XCMPLX-0K7 q)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 ?B)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> bq)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using seq_1_th_7 sorry
        also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 p)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> Partial-SumsSERIES-1K3 ((\<one>\<^sub>M /XCMPLX-0K7 ?A)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ap)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 Partial-SumsSERIES-1K3 ((\<one>\<^sub>M /XCMPLX-0K7 q)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 ?B)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> bq)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using series_1_th_9 sorry
        also have "... = (\<one>\<^sub>M /XCMPLX-0K7 p)*XCMPLX-0K3 Partial-SumsSERIES-1K3 ((\<one>\<^sub>M /XCMPLX-0K7 ?A)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ap) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 Partial-SumsSERIES-1K3 ((\<one>\<^sub>M /XCMPLX-0K7 q)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 ?B)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> bq)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using seq_1_th_9 sorry
        also have "... = (\<one>\<^sub>M /XCMPLX-0K7 p)*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 ?A)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> Partial-SumsSERIES-1K3 ap).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 Partial-SumsSERIES-1K3 ((\<one>\<^sub>M /XCMPLX-0K7 q)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 ?B)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> bq)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using series_1_th_9 sorry
        also have "... = (\<one>\<^sub>M /XCMPLX-0K7 p)*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 ?A)*XCMPLX-0K3 Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) +XCMPLX-0K2 Partial-SumsSERIES-1K3 ((\<one>\<^sub>M /XCMPLX-0K7 q)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 ?B)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> bq)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using seq_1_th_9 sorry
        also have "... = (\<one>\<^sub>M /XCMPLX-0K7 p)*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 ?A)*XCMPLX-0K3 Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) +XCMPLX-0K2 ((\<one>\<^sub>M /XCMPLX-0K7 q)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> Partial-SumsSERIES-1K3 ((\<one>\<^sub>M /XCMPLX-0K7 ?B)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> bq)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using series_1_th_9 sorry
        also have "... = (\<one>\<^sub>M /XCMPLX-0K7 p)*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 ?A)*XCMPLX-0K3 Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 Partial-SumsSERIES-1K3 ((\<one>\<^sub>M /XCMPLX-0K7 ?B)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> bq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using seq_1_th_9 sorry
        also have "... = (\<one>\<^sub>M /XCMPLX-0K7 p)*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 ?A)*XCMPLX-0K3 Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 ?B)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> Partial-SumsSERIES-1K3 bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using series_1_th_9 sorry
        also have "... = (\<one>\<^sub>M /XCMPLX-0K7 p)*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 ?A)*XCMPLX-0K3 Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 ?B)*XCMPLX-0K3 Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
          using seq_1_th_9 sorry
        also have "... = (\<one>\<^sub>M /XCMPLX-0K7 p)*XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 ?B)*XCMPLX-0K3 ?B)"
          using A32 xcmplx_1_th_87 sorry
        also have "... = (\<one>\<^sub>M /XCMPLX-0K7 p)*XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 q)*XCMPLX-0K3 \<one>\<^sub>M"
          using A26 xcmplx_1_th_87 sorry
        also have "... = \<one>\<^sub>M"
          using A2 sorry
        finally have "Partial-SumsSERIES-1K3 ((\<one>\<^sub>M /XCMPLX-0K7 p)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 ?A)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ap) +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 q)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 ?B)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> bq)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<one>\<^sub>M"
           sorry
        then have "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n /XCMPLX-0K7 (?Ap *XCMPLX-0K3 ?Bq) <=XXREAL-0R1 \<one>\<^sub>M"
          using A43 A31 xcmplx_1_th_99 sorry
        thus "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)"
          using A34 xreal_1_th_187 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
  thus "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)"
     sorry
qed "sorry"

mtheorem holder_1_th_7:
" for p be RealXREAL-0M1 holds \<one>\<^sub>M <XXREAL-0R3 p implies ( for a be Real-SequenceSEQ-1M1 holds  for b be Real-SequenceSEQ-1M1 holds  for ap be Real-SequenceSEQ-1M1 holds  for bp be Real-SequenceSEQ-1M1 holds  for ab be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds (ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p & bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p) & ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|)to-powerPOWERK2 p) implies ( for n be NatNAT-1M1 holds (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) +XCMPLX-0K2 (Partial-SumsSERIES-1K3 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)))"
proof(rule ballI,rule impI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix p assume [ty]: "p be RealXREAL-0M1"
  assume A1: "\<one>\<^sub>M <XXREAL-0R3 p"
  have A2: "\<one>\<^sub>M /XCMPLX-0K7 p >XXREAL-0R4 0NUMBERSK6"
    using A1 xreal_1_th_139 sorry
  fix a assume [ty]: "a be Real-SequenceSEQ-1M1"
  fix b assume [ty]: "b be Real-SequenceSEQ-1M1"
  fix ap assume [ty]: "ap be Real-SequenceSEQ-1M1"
  fix bp assume [ty]: "bp be Real-SequenceSEQ-1M1"
  fix ab assume [ty]: "ab be Real-SequenceSEQ-1M1"
  assume A3: " for n be NatNAT-1M1 holds (ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p & bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p) & ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|)to-powerPOWERK2 p"
  have A4: " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have A5: "ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p"
      using A3 sorry
    have " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 & 0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n or  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 & ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
    proof-
      show " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 & 0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n or  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 & ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
      proof-
        have cases: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 or  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6"
          using complex1_th_46 sorry
        have case1: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        proof(rule impI)
          assume " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6"
          thus "0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
            using A1 A5 power_def_2 sorry
        qed
        have case2: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        proof(rule impI)
          assume " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6"
          thus "0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
            using A5 power_th_34 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
       sorry
  qed "sorry"
  have A6: " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have A7: "bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p"
      using A3 sorry
    have " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 & 0NUMBERSK6 <=XXREAL-0R1 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n or  |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 & ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
    proof-
      show " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 & 0NUMBERSK6 <=XXREAL-0R1 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n or  |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 & ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
      proof-
        have cases: " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 or  |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6"
          using complex1_th_46 sorry
        have case1: " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        proof(rule impI)
          assume " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6"
          thus "0NUMBERSK6 <=XXREAL-0R1 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
            using A1 A7 power_def_2 sorry
        qed
        have case2: " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        proof(rule impI)
          assume " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6"
          thus "0NUMBERSK6 <=XXREAL-0R1 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
            using A7 power_th_34 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "0NUMBERSK6 <=XXREAL-0R1 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
       sorry
  qed "sorry"
  let ?F = "\<lambda>Lamb1. ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 .|)to-powerPOWERK2 (p -XCMPLX-0K6 \<one>\<^sub>M)"
  obtain x where
    [ty]:"x be Real-SequenceSEQ-1M1" and 
    A8: " for n be NatNAT-1M1 holds x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ?F(n)"
    using seq_1_sch_1 sorry
  have A9: "\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 p -XCMPLX-0K6 \<one>\<^sub>M"
    using A1 xreal_1_th_14 sorry
  have A10: " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have A11: "x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|)to-powerPOWERK2 (p -XCMPLX-0K6 \<one>\<^sub>M)"
      using A8 sorry
    have " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| =COMPLEX1R1 0NUMBERSK6 & 0NUMBERSK6 <=XXREAL-0R1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n or  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| >XXREAL-0R4 0NUMBERSK6 & ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| >XXREAL-0R4 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
    proof-
      show " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| =COMPLEX1R1 0NUMBERSK6 & 0NUMBERSK6 <=XXREAL-0R1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n or  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| >XXREAL-0R4 0NUMBERSK6 & ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| >XXREAL-0R4 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
      proof-
        have cases: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| =COMPLEX1R1 0NUMBERSK6 or  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| >XXREAL-0R4 0NUMBERSK6"
          using complex1_th_46 sorry
        have case1: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| =COMPLEX1R1 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        proof(rule impI)
          assume " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| =COMPLEX1R1 0NUMBERSK6"
          thus "0NUMBERSK6 <=XXREAL-0R1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
            using A9 A11 power_def_2 sorry
        qed
        have case2: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| >XXREAL-0R4 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        proof(rule impI)
          assume " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| >XXREAL-0R4 0NUMBERSK6"
          thus "0NUMBERSK6 <=XXREAL-0R1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
            using A11 power_th_34 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "0NUMBERSK6 <=XXREAL-0R1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
       sorry
  qed "sorry"
  have A12: " for n be NatNAT-1M1 holds (x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> b).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1  |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
  proof-
    have " for n be NatNAT-1M1 holds (x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> b).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1  |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "0NUMBERSK6 <=XXREAL-0R1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A10 sorry
      then have A13: " |.COMPLEX1K10 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using absvalue_def_1 sorry
      have "(x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> b).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_8 sorry
      also have "... = x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)"
        using seq_1_th_12 sorry
      also have "... =  |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
        using A13 complex1_th_65 sorry
      finally show "(x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> b).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1  |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  obtain pp where 
    [ty]:"pp be RealXREAL-0M1" and ppDef:"pp = \<one>\<^sub>M /XCMPLX-0K7 p"
     sorry
  obtain qq where 
    [ty]:"qq be RealXREAL-0M1" and qqDef:"qq = \<one>\<^sub>M -XCMPLX-0K6 pp"
     sorry
  obtain q where 
    [ty]:"q be RealXREAL-0M1" and qDef:"q = \<one>\<^sub>M /XCMPLX-0K7 qq"
     sorry
  have A14: "qq =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 q"
    using xcmplx_1_th_56 sorry
  then have A15: "\<one>\<^sub>M /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q =COMPLEX1R1 \<one>\<^sub>M"
     sorry
  have "\<one>\<^sub>M /XCMPLX-0K7 p <XXREAL-0R3 \<one>\<^sub>M"
    using A1 xreal_1_th_189 sorry
  then have A16: "\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 \<one>\<^sub>M -XCMPLX-0K6 pp"
    using xreal_1_th_15 sorry
  then have A17: "q <>HIDDENR2 0NUMBERSK6"
    using A14 sorry
  then have "((\<one>\<^sub>M *XCMPLX-0K3 q +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 p)/XCMPLX-0K7 (p *XCMPLX-0K3 q))*XCMPLX-0K3 (p *XCMPLX-0K3 q) =COMPLEX1R1 \<one>\<^sub>M *XCMPLX-0K3 (p *XCMPLX-0K3 q)"
    using A1 A15 xcmplx_1_th_116 sorry
  then have A18: "q +XCMPLX-0K2 p =COMPLEX1R1 p *XCMPLX-0K3 q"
    using A1 A17 xcmplx_1_th_6 xcmplx_1_th_87 sorry
  have A19: " for n be NatNAT-1M1 holds ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|)"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| =COMPLEX1R1 0NUMBERSK6 & ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|) or  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <>HIDDENR2 0NUMBERSK6 & ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <>HIDDENR2 0NUMBERSK6 implies ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|))"
    proof-
      show " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| =COMPLEX1R1 0NUMBERSK6 & ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|) or  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <>HIDDENR2 0NUMBERSK6 & ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <>HIDDENR2 0NUMBERSK6 implies ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|))"
      proof-
        have cases: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| =COMPLEX1R1 0NUMBERSK6 or  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <>HIDDENR2 0NUMBERSK6"
           sorry
        have case1: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| =COMPLEX1R1 0NUMBERSK6 implies ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|)"
        proof(rule impI)
          assume A20: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| =COMPLEX1R1 0NUMBERSK6"
          have "ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|)to-powerPOWERK2 p"
            using A3 sorry
          also have "... = x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|)"
            using A1 A20 power_def_2 sorry
          finally show "ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|)"
             sorry
        qed
        have case2: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <>HIDDENR2 0NUMBERSK6 implies ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|)"
        proof(rule impI)
          assume A21: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <>HIDDENR2 0NUMBERSK6"
          have A22: "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
            using complex1_th_46 sorry
          have "ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|)to-powerPOWERK2 ((p -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M)"
            using A3 sorry
          also have "... = ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|)to-powerPOWERK2 (p -XCMPLX-0K6 \<one>\<^sub>M) *XCMPLX-0K3 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|)to-powerPOWERK2 \<one>\<^sub>M"
            using A21 A22 power_th_27 sorry
          also have "... = ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|)to-powerPOWERK2 (p -XCMPLX-0K6 \<one>\<^sub>M) *XCMPLX-0K3 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|)"
            using power_th_25 sorry
          also have "... = x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|)"
            using A8 sorry
          finally show "ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|)"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|)"
       sorry
  qed "sorry"
  have A23: " for n be NatNAT-1M1 holds ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> a +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> b).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have A24: "x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| +XCMPLX-0K2  |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|) =HIDDENR1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|) +XCMPLX-0K2 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)"
       sorry
    also have "... = x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)"
      using seq_1_th_12 sorry
    also have "... = x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using seq_1_th_12 sorry
    also have "... = (x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> a).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using seq_1_th_8 sorry
    also have "... = (x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> a).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 (x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> b).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using seq_1_th_8 sorry
    also have "... = (x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> a +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> b).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using seq_1_th_7 sorry
    finally have "x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| +XCMPLX-0K2  |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|) =HIDDENR1 (x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> a +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> b).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
       sorry
    have "0NUMBERSK6 <=XXREAL-0R1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|)"
      using A10 A19 sorry
    thus "ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> a +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> b).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using A24 complex1_th_56 xreal_1_th_64 sorry
  qed "sorry"
  have A25: "0NUMBERSK6 <XXREAL-0R3 q"
    using A16 A14 sorry
  have A26: " for n be NatNAT-1M1 holds ( |.COMPLEX1K10 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q =COMPLEX1R1 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have "0NUMBERSK6 <=XXREAL-0R1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using A10 sorry
    then have " |.COMPLEX1K10 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using absvalue_def_1 sorry
    then have A27: "( |.COMPLEX1K10 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q =COMPLEX1R1 (( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|)to-powerPOWERK2 (p -XCMPLX-0K6 \<one>\<^sub>M))to-powerPOWERK2 q"
      using A8 sorry
    have " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| =COMPLEX1R1 0NUMBERSK6 & ( |.COMPLEX1K10 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q =COMPLEX1R1 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n or  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <>HIDDENR2 0NUMBERSK6 & ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <>HIDDENR2 0NUMBERSK6 implies ( |.COMPLEX1K10 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q =HIDDENR1 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
    proof-
      show " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| =COMPLEX1R1 0NUMBERSK6 & ( |.COMPLEX1K10 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q =COMPLEX1R1 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n or  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <>HIDDENR2 0NUMBERSK6 & ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <>HIDDENR2 0NUMBERSK6 implies ( |.COMPLEX1K10 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q =HIDDENR1 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
      proof-
        have cases: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| =COMPLEX1R1 0NUMBERSK6 or  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <>HIDDENR2 0NUMBERSK6"
           sorry
        have case1: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| =COMPLEX1R1 0NUMBERSK6 implies ( |.COMPLEX1K10 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q =COMPLEX1R1 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        proof(rule impI)
          assume A28: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| =COMPLEX1R1 0NUMBERSK6"
          then have A29: "ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (0NUMBERSK6)to-powerPOWERK2 p"
            using A3 sorry
          also have "... = 0NUMBERSK6"
            using A1 power_def_2 sorry
          finally have "ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 0NUMBERSK6"
             sorry
          have "( |.COMPLEX1K10 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q =HIDDENR1 (0NUMBERSK6)to-powerPOWERK2 q"
            using A9 A27 A28 power_def_2 sorry
          also have "... = 0NUMBERSK6"
            using A25 power_def_2 sorry
          finally have "( |.COMPLEX1K10 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q =HIDDENR1 0NUMBERSK6"
             sorry
          thus "( |.COMPLEX1K10 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q =COMPLEX1R1 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
            using A29 sorry
        qed
        have case2: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <>HIDDENR2 0NUMBERSK6 implies ( |.COMPLEX1K10 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q =HIDDENR1 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        proof(rule impI)
          assume " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <>HIDDENR2 0NUMBERSK6"
          then have "0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
            using complex1_th_46 sorry
          then have "( |.COMPLEX1K10 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q =HIDDENR1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|)to-powerPOWERK2 ((p -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 q)"
            using A27 power_th_33 sorry
          also have "... = ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
            using A3 A18 sorry
          finally show "( |.COMPLEX1K10 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q =HIDDENR1 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "( |.COMPLEX1K10 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q =COMPLEX1R1 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
       sorry
  qed "sorry"
  have A30: " for n be NatNAT-1M1 holds (x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> a).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
  proof-
    have " for n be NatNAT-1M1 holds (x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> a).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "0NUMBERSK6 <=XXREAL-0R1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A10 sorry
      then have A31: " |.COMPLEX1K10 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using absvalue_def_1 sorry
      have "(x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> a).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_8 sorry
      also have "... = x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)"
        using seq_1_th_12 sorry
      also have "... =  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
        using A31 complex1_th_65 sorry
      finally show "(x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> a).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have A32: " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 ((Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) +XCMPLX-0K2 (Partial-SumsSERIES-1K3 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))*XCMPLX-0K3 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have A33: "Partial-SumsSERIES-1K3 (x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> a +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> b) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (Partial-SumsSERIES-1K3 (x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> a) +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> Partial-SumsSERIES-1K3 (x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> b)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using series_1_th_5 sorry
    also have "... = Partial-SumsSERIES-1K3 (x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> a) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 Partial-SumsSERIES-1K3 (x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> b) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using seq_1_th_7 sorry
    finally have "Partial-SumsSERIES-1K3 (x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> a +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> b) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 Partial-SumsSERIES-1K3 (x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> a) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 Partial-SumsSERIES-1K3 (x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> b) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
       sorry
    have "Partial-SumsSERIES-1K3 (x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> a) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q) & Partial-SumsSERIES-1K3 (x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> b) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (Partial-SumsSERIES-1K3 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)"
      using A1 A3 A15 A30 A12 A26 holder_1_th_6 sorry
    then have A34: "Partial-SumsSERIES-1K3 (x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> a) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 Partial-SumsSERIES-1K3 (x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> b) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q) +XCMPLX-0K2 (Partial-SumsSERIES-1K3 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)"
      using xreal_1_th_7 sorry
    have "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 Partial-SumsSERIES-1K3 (x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> a +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> b) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using A23 series_1_th_14 sorry
    thus "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 ((Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) +XCMPLX-0K2 (Partial-SumsSERIES-1K3 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))*XCMPLX-0K3 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)"
      using A33 A34 xxreal_0_th_2 sorry
  qed "sorry"
  have A35: " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
      using complex1_th_46 sorry
    then have A36: "(0NUMBERSK6)to-powerPOWERK2 p <=XXREAL-0R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|)to-powerPOWERK2 p"
      using A1 holder_1_th_3 sorry
    have "ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|)to-powerPOWERK2 p"
      using A3 sorry
    thus "0NUMBERSK6 <=XXREAL-0R1 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using A1 A36 power_def_2 sorry
  qed "sorry"
  have " for n be NatNAT-1M1 holds (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) +XCMPLX-0K2 (Partial-SumsSERIES-1K3 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?A = "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    let ?C = "(Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) +XCMPLX-0K2 (Partial-SumsSERIES-1K3 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
    let ?D = "?A to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)"
    have A37: "0NUMBERSK6 <=XXREAL-0R1 ?A"
      using A35 holder_1_lm_2 sorry
    have "0NUMBERSK6 <=XXREAL-0R1 Partial-SumsSERIES-1K3 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using A6 holder_1_lm_2 sorry
    then have "(0NUMBERSK6)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 (Partial-SumsSERIES-1K3 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
      using A2 holder_1_th_3 sorry
    then have A38: "0NUMBERSK6 <=XXREAL-0R1 (Partial-SumsSERIES-1K3 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
      using A2 power_def_2 sorry
    have "0NUMBERSK6 <=XXREAL-0R1 Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using A4 holder_1_lm_2 sorry
    then have "(0NUMBERSK6)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
      using A2 holder_1_th_3 sorry
    then have "0NUMBERSK6 <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
      using A2 power_def_2 sorry
    then have A39: "0NUMBERSK6 +NAT-1K1 0NUMBERSK6 <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) +XCMPLX-0K2 (Partial-SumsSERIES-1K3 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
      using A38 sorry
    have "?A =COMPLEX1R1 0NUMBERSK6 & (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) +XCMPLX-0K2 (Partial-SumsSERIES-1K3 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) or ?A <>HIDDENR2 0NUMBERSK6 & (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6 implies (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) +XCMPLX-0K2 (Partial-SumsSERIES-1K3 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))"
    proof-
      show "?A =COMPLEX1R1 0NUMBERSK6 & (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) +XCMPLX-0K2 (Partial-SumsSERIES-1K3 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) or ?A <>HIDDENR2 0NUMBERSK6 & (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6 implies (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) +XCMPLX-0K2 (Partial-SumsSERIES-1K3 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))"
      proof-
        have cases: "?A =COMPLEX1R1 0NUMBERSK6 or ?A <>HIDDENR2 0NUMBERSK6"
           sorry
        have case1: "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6 implies (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) +XCMPLX-0K2 (Partial-SumsSERIES-1K3 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
        proof(rule impI)
          assume "?A =COMPLEX1R1 0NUMBERSK6"
          thus "(Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) +XCMPLX-0K2 (Partial-SumsSERIES-1K3 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
            using A2 A39 power_def_2 sorry
        qed
        have case2: "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6 implies (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) +XCMPLX-0K2 (Partial-SumsSERIES-1K3 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
        proof(rule impI)
          assume A40: "?A <>HIDDENR2 0NUMBERSK6"
          let ?B = "\<one>\<^sub>M /XCMPLX-0K7 ?D"
          have A41: "0NUMBERSK6 <XXREAL-0R3 ?D"
            using A37 A40 power_th_34 sorry
          then have A42: "0NUMBERSK6 <XXREAL-0R3 ?B"
            using xreal_1_th_139 sorry
          have A43: "(?C *XCMPLX-0K3 ?D)*XCMPLX-0K3 ?B =HIDDENR1 ?C *XCMPLX-0K3 (?D *XCMPLX-0K3 ?B)"
             sorry
          also have "... = ?C *XCMPLX-0K3 \<one>\<^sub>M"
            using A41 xcmplx_1_th_87 sorry
          also have "... = ?C"
             sorry
          finally have "(?C *XCMPLX-0K3 ?D)*XCMPLX-0K3 ?B =HIDDENR1 ?C"
             sorry
          have "?A *XCMPLX-0K3 ?B =HIDDENR1 ?A /XCMPLX-0K7 ?D"
            using xcmplx_1_th_99 sorry
          also have "... = ?A to-powerPOWERK2 \<one>\<^sub>M /XCMPLX-0K7 ?D"
            using power_th_25 sorry
          also have "... = ?A to-powerPOWERK2 (\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 q)"
            using A37 A40 power_th_29 sorry
          also have "... = ?A to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
            using A14 sorry
          finally have "?A *XCMPLX-0K3 ?B =HIDDENR1 ?A to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
             sorry
          thus "(Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) +XCMPLX-0K2 (Partial-SumsSERIES-1K3 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
            using A32 A42 A43 xreal_1_th_64 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "(Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) +XCMPLX-0K2 (Partial-SumsSERIES-1K3 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
       sorry
  qed "sorry"
  thus " for n be NatNAT-1M1 holds (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) +XCMPLX-0K2 (Partial-SumsSERIES-1K3 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
     sorry
qed "sorry"

mtheorem holder_1_th_8:
" for a be Real-SequenceSEQ-1M1 holds  for b be Real-SequenceSEQ-1M1 holds (( for n be NatNAT-1M1 holds a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) & b be convergentSEQ-2V5) & a be non-decreasingVALUED-0V11 implies a be convergentSEQ-2V5 & limSEQ-2K1 a <=XXREAL-0R1 limSEQ-2K1 b"
proof-
  have " for a be Real-SequenceSEQ-1M1 holds  for b be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) & (b be convergentSEQ-2V5 & a be non-decreasingVALUED-0V11) implies a be convergentSEQ-2V5 & limSEQ-2K1 a <=XXREAL-0R1 limSEQ-2K1 b"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix a assume [ty]: "a be Real-SequenceSEQ-1M1"
    fix b assume [ty]: "b be Real-SequenceSEQ-1M1"
    assume A1: " for n be NatNAT-1M1 holds a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      and A2: "b be convergentSEQ-2V5"
      and A3: "a be non-decreasingVALUED-0V11"
    have A4: "b be boundedSEQ-2V6"
      using A2 sorry
    have A5: "a be bounded-aboveSEQ-2V3"
    proof-
      obtain r where
        [ty]:"r be RealXREAL-0M1" and 
        A6: " for n be NatNAT-1M1 holds b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 r"
        using A4 seq_2_def_3 sorry
      have " for n be NatNAT-1M1 holds a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have "a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using A1 sorry
        then have "a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 r"
          using A6 xxreal_0_th_2 sorry
        then have "a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M"
          using xreal_1_th_8 sorry
        thus "a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M"
           sorry
      qed "sorry"
      thus "a be bounded-aboveSEQ-2V3"
        using seq_2_def_3 sorry
    qed
    thus "a be convergentSEQ-2V5"
      using A3 sorry
    show "limSEQ-2K1 a <=XXREAL-0R1 limSEQ-2K1 b"
      using A1 A2 A3 A5 seq_2_th_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem holder_1_th_9:
" for a be Real-SequenceSEQ-1M1 holds  for b be Real-SequenceSEQ-1M1 holds  for c be Real-SequenceSEQ-1M1 holds ((( for n be NatNAT-1M1 holds a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 c .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) & b be convergentSEQ-2V5) & c be convergentSEQ-2V5) & a be non-decreasingVALUED-0V11 implies a be convergentSEQ-2V5 & limSEQ-2K1 a <=XXREAL-0R1 limSEQ-2K1 b +XCMPLX-0K2 limSEQ-2K1 c"
proof-
  have " for a be Real-SequenceSEQ-1M1 holds  for b be Real-SequenceSEQ-1M1 holds  for c be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 c .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) & ((b be convergentSEQ-2V5 & c be convergentSEQ-2V5) & a be non-decreasingVALUED-0V11) implies a be convergentSEQ-2V5 & limSEQ-2K1 a <=XXREAL-0R1 limSEQ-2K1 b +XCMPLX-0K2 limSEQ-2K1 c"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix a assume [ty]: "a be Real-SequenceSEQ-1M1"
    fix b assume [ty]: "b be Real-SequenceSEQ-1M1"
    fix c assume [ty]: "c be Real-SequenceSEQ-1M1"
    assume A1: " for n be NatNAT-1M1 holds a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 c .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      and A2: "b be convergentSEQ-2V5 & c be convergentSEQ-2V5"
      and A3: "a be non-decreasingVALUED-0V11"
    have A4: " for n be NatNAT-1M1 holds a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (b +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> c).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 c .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A1 sorry
      thus "a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (b +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> c).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_7 sorry
    qed "sorry"
    have A5: "b +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> c be convergentSEQ-2V5"
      using A2 sorry
    thus "a be convergentSEQ-2V5"
      using A3 A4 holder_1_th_8 sorry
    have "limSEQ-2K1 (b +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> c) =COMPLEX1R1 limSEQ-2K1 b +XCMPLX-0K2 limSEQ-2K1 c"
      using A2 seq_2_th_6 sorry
    thus "limSEQ-2K1 a <=XXREAL-0R1 limSEQ-2K1 b +XCMPLX-0K2 limSEQ-2K1 c"
      using A3 A5 A4 holder_1_th_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem holder_1_th_10:
" for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( for a be Real-SequenceSEQ-1M1 holds  for ap be Real-SequenceSEQ-1M1 holds (a be convergentSEQ-2V5 & ( for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & ( for n be NatNAT-1M1 holds ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p) implies ap be convergentSEQ-2V5 & limSEQ-2K1 ap =COMPLEX1R1 (limSEQ-2K1 a)to-powerPOWERK2 p)"
proof-
  have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( for a be Real-SequenceSEQ-1M1 holds  for ap be Real-SequenceSEQ-1M1 holds a be convergentSEQ-2V5 & (( for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) & ( for n be NatNAT-1M1 holds ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p)) implies ap be convergentSEQ-2V5 & limSEQ-2K1 ap =COMPLEX1R1 (limSEQ-2K1 a)to-powerPOWERK2 p)"
  proof(rule ballI,rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 p"
    fix a assume [ty]: "a be Real-SequenceSEQ-1M1"
    fix ap assume [ty]: "ap be Real-SequenceSEQ-1M1"
    assume A2: "a be convergentSEQ-2V5"
      and A3: " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      and A4: " for n be NatNAT-1M1 holds ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p"
    have "limSEQ-2K1 a =COMPLEX1R1 0NUMBERSK6 & (ap be convergentSEQ-2V5 & limSEQ-2K1 ap =COMPLEX1R1 (limSEQ-2K1 a)to-powerPOWERK2 p) or limSEQ-2K1 a <>HIDDENR2 0NUMBERSK6 & (limSEQ-2K1 a <>HIDDENR2 0NUMBERSK6 implies ap be convergentSEQ-2V5 & limSEQ-2K1 ap =COMPLEX1R1 (limSEQ-2K1 a)to-powerPOWERK2 p)"
    proof-
      show "limSEQ-2K1 a =COMPLEX1R1 0NUMBERSK6 & (ap be convergentSEQ-2V5 & limSEQ-2K1 ap =COMPLEX1R1 (limSEQ-2K1 a)to-powerPOWERK2 p) or limSEQ-2K1 a <>HIDDENR2 0NUMBERSK6 & (limSEQ-2K1 a <>HIDDENR2 0NUMBERSK6 implies ap be convergentSEQ-2V5 & limSEQ-2K1 ap =COMPLEX1R1 (limSEQ-2K1 a)to-powerPOWERK2 p)"
      proof-
        have cases: "limSEQ-2K1 a =COMPLEX1R1 0NUMBERSK6 or limSEQ-2K1 a <>HIDDENR2 0NUMBERSK6"
           sorry
        have case1: "limSEQ-2K1 a =COMPLEX1R1 0NUMBERSK6 implies ap be convergentSEQ-2V5 & limSEQ-2K1 ap =COMPLEX1R1 (limSEQ-2K1 a)to-powerPOWERK2 p"
        proof(rule impI)
          assume A5: "limSEQ-2K1 a =COMPLEX1R1 0NUMBERSK6"
          have "( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =COMPLEX1R1 0NUMBERSK6) & (ap be convergentSEQ-2V5 & limSEQ-2K1 ap =COMPLEX1R1 (limSEQ-2K1 a)to-powerPOWERK2 p) or ( for n be NatNAT-1M1 holds  ex m be NatNAT-1M1 st n <=XXREAL-0R1 m & a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <>HIDDENR2 0NUMBERSK6) & (( for n be NatNAT-1M1 holds  ex m be NatNAT-1M1 st n <=XXREAL-0R1 m & a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <>HIDDENR2 0NUMBERSK6) implies ap be convergentSEQ-2V5 & limSEQ-2K1 ap =COMPLEX1R1 (limSEQ-2K1 a)to-powerPOWERK2 p)"
          proof-
            show "( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =COMPLEX1R1 0NUMBERSK6) & (ap be convergentSEQ-2V5 & limSEQ-2K1 ap =COMPLEX1R1 (limSEQ-2K1 a)to-powerPOWERK2 p) or ( for n be NatNAT-1M1 holds  ex m be NatNAT-1M1 st n <=XXREAL-0R1 m & a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <>HIDDENR2 0NUMBERSK6) & (( for n be NatNAT-1M1 holds  ex m be NatNAT-1M1 st n <=XXREAL-0R1 m & a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <>HIDDENR2 0NUMBERSK6) implies ap be convergentSEQ-2V5 & limSEQ-2K1 ap =COMPLEX1R1 (limSEQ-2K1 a)to-powerPOWERK2 p)"
            proof-
              have cases: "( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =COMPLEX1R1 0NUMBERSK6) or ( for n be NatNAT-1M1 holds  ex m be NatNAT-1M1 st n <=XXREAL-0R1 m & a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <>HIDDENR2 0NUMBERSK6)"
                 sorry
              have case1: "( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =COMPLEX1R1 0NUMBERSK6) implies ap be convergentSEQ-2V5 & limSEQ-2K1 ap =COMPLEX1R1 (limSEQ-2K1 a)to-powerPOWERK2 p"
              proof(rule impI)
                assume " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =COMPLEX1R1 0NUMBERSK6"
                then obtain N where
                  [ty]:"N be NatNAT-1M1" and 
                  A6: " for m be NatNAT-1M1 holds N <=XXREAL-0R1 m implies a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =COMPLEX1R1 0NUMBERSK6"
                   sorry
                have A7: " for n be NatNAT-1M1 holds (a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> N).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6"
                proof(rule ballI)
                  fix n assume [ty]: "n be NatNAT-1M1"
                  have "a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 N) =COMPLEX1R1 0NUMBERSK6"
                    using A6 nat_1_th_12 sorry
                  thus "(a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> N).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6"
                    using nat_1_def_3 sorry
                qed "sorry"
                have A8: " for e be RealXREAL-0M1 holds e >XXREAL-0R4 0NUMBERSK6 implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 (ap ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> N).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 (limSEQ-2K1 a)to-powerPOWERK2 p .| <XXREAL-0R3 e)"
                proof(rule ballI,rule impI)
                  fix e assume [ty]: "e be RealXREAL-0M1"
                  assume A9: "e >XXREAL-0R4 0NUMBERSK6"
                  obtain n where 
                    [ty]:"n be NatNAT-1M1" and nDef:"n = 0NUMBERSK6"
                     sorry
                  show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 (ap ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> N).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 (limSEQ-2K1 a)to-powerPOWERK2 p .| <XXREAL-0R3 e"
                  proof(rule bexI[of _ "n"],rule ballI,rule impI)
                    fix m assume [ty]: "m be NatNAT-1M1"
                    assume "n <=XXREAL-0R1 m"
                    have A10: "(limSEQ-2K1 a)to-powerPOWERK2 p =COMPLEX1R1 0NUMBERSK6"
                      using A1 A5 power_def_2 sorry
                    have "(ap ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> N).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =HIDDENR1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (m +XCMPLX-0K2 N)"
                      using nat_1_def_3 sorry
                    also have "... = (a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (m +XCMPLX-0K2 N))to-powerPOWERK2 p"
                      using A4 sorry
                    also have "... = ((a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> N).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)to-powerPOWERK2 p"
                      using nat_1_def_3 sorry
                    also have "... = (0NUMBERSK6)to-powerPOWERK2 p"
                      using A7 sorry
                    also have "... = 0NUMBERSK6"
                      using A1 power_def_2 sorry
                    finally have "(ap ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> N).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =HIDDENR1 0NUMBERSK6"
                       sorry
                    thus " |.COMPLEX1K10 (ap ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> N).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 (limSEQ-2K1 a)to-powerPOWERK2 p .| <XXREAL-0R3 e"
                      using A9 A10 absvalue_th_2 sorry
                  qed "sorry"
                qed "sorry"
                then have A11: "ap ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> N be convergentSEQ-2V5"
                  using seq_2_def_6 sorry
                then have "(limSEQ-2K1 a)to-powerPOWERK2 p =COMPLEX1R1 limSEQ-2K1 (ap ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> N)"
                  using A8 seq_2_def_7 sorry
                thus "ap be convergentSEQ-2V5 & limSEQ-2K1 ap =COMPLEX1R1 (limSEQ-2K1 a)to-powerPOWERK2 p"
                  using A11 seq_4_th_20 seq_4_th_21 sorry
              qed
              have case2: "( for n be NatNAT-1M1 holds  ex m be NatNAT-1M1 st n <=XXREAL-0R1 m & a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <>HIDDENR2 0NUMBERSK6) implies ap be convergentSEQ-2V5 & limSEQ-2K1 ap =COMPLEX1R1 (limSEQ-2K1 a)to-powerPOWERK2 p"
              proof(rule impI,rule conjMI)
                assume A12: " for n be NatNAT-1M1 holds  ex m be NatNAT-1M1 st n <=XXREAL-0R1 m & a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <>HIDDENR2 0NUMBERSK6"
                let ?P = "\<lambda>Lamb1. a .FUNCT-1K1 Lamb1 <>HIDDENR2 0NUMBERSK6"
                have " ex m1 be NatNAT-1M1 st 0NUMBERSK6 <=XXREAL-0R1 m1 & a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m1 <>HIDDENR2 0NUMBERSK6"
                  using A12 sorry
                then have A13: " ex m be NatNAT-1M1 st ?P(m)"
                   sorry
                obtain M where
                  [ty]:"M be NatNAT-1M1" and 
                  A14: "?P(M) & ( for n be NatNAT-1M1 holds ?P(n) implies M <=XXREAL-0R1 n)"
                  using nat_1_sch_5 A13 sorry
                let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3.  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds Lamb2 =XBOOLE-0R4 n & Lamb3 =XBOOLE-0R4 m implies (n <XXREAL-0R3 m & a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <>HIDDENR2 0NUMBERSK6) & ( for k be NatNAT-1M1 holds n <XXREAL-0R3 k & a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k <>HIDDENR2 0NUMBERSK6 implies m <=XXREAL-0R1 k)"
                have A15: "(limSEQ-2K1 a)to-powerPOWERK2 p =COMPLEX1R1 0NUMBERSK6"
                  using A1 A5 power_def_2 sorry
                have 
                  [ty]:"M be NatNAT-1M1"
                   sorry
                have A16: " for n be NatNAT-1M1 holds  ex m be NatNAT-1M1 st n <XXREAL-0R3 m & a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <>HIDDENR2 0NUMBERSK6"
                proof(rule ballI)
                  fix n assume [ty]: "n be NatNAT-1M1"
                  obtain m where
                    [ty]:"m be NatNAT-1M1" and 
                    A17: "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m & a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <>HIDDENR2 0NUMBERSK6"
                    using A12 sorry
                  show " ex m be NatNAT-1M1 st n <XXREAL-0R3 m & a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <>HIDDENR2 0NUMBERSK6"
                  proof(rule bexI[of _ "m"])
                    show "n <XXREAL-0R3 m & a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <>HIDDENR2 0NUMBERSK6"
                      using A17 nat_1_th_13 sorry
                  qed "sorry"
                qed "sorry"
                have A18: " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex y be ElementSUBSET-1M1-of NATNUMBERSK1 st ?P(n,x,y)"
                proof-
                  have " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex tVar5 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar5 be ElementSUBSET-1M1-of NATNUMBERSK1 & ( for nc be NatNAT-1M1 holds  for m be NatNAT-1M1 holds x =XBOOLE-0R4 nc & tVar5 =XBOOLE-0R4 m implies (nc <XXREAL-0R3 m & a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <>HIDDENR2 0NUMBERSK6) & ( for k be NatNAT-1M1 holds nc <XXREAL-0R3 k & a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k <>HIDDENR2 0NUMBERSK6 implies m <=XXREAL-0R1 k))"
                  proof(rule ballI,rule ballI)
                    fix n assume [ty]: "n be NatNAT-1M1"
                    fix x assume [ty]: "x be ElementSUBSET-1M1-of NATNUMBERSK1"
                    let ?P = "\<lambda>Lamb1. x <XXREAL-0R3 Lamb1 & a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 <>HIDDENR2 0NUMBERSK6"
                    have " ex m be NatNAT-1M1 st ?P(m)"
                      using A16 sorry
                    then have A19: " ex m be NatNAT-1M1 st ?P(m)"
                       sorry
                    obtain l where
                      [ty]:"l be NatNAT-1M1" and 
                      A20: "?P(l) & ( for k be NatNAT-1M1 holds ?P(k) implies l <=XXREAL-0R1 k)"
                      using nat_1_sch_5 A19 sorry
                    show " ex tVar5 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar5 be ElementSUBSET-1M1-of NATNUMBERSK1 & ( for nc be NatNAT-1M1 holds  for m be NatNAT-1M1 holds x =XBOOLE-0R4 nc & tVar5 =XBOOLE-0R4 m implies (nc <XXREAL-0R3 m & a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <>HIDDENR2 0NUMBERSK6) & ( for k be NatNAT-1M1 holds nc <XXREAL-0R3 k & a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k <>HIDDENR2 0NUMBERSK6 implies m <=XXREAL-0R1 k))"
                    proof(rule bexI[of _ "l"])
                      have "l inTARSKIR2 NATNUMBERSK1"
                        using ordinal1_def_12 sorry
                      thus "l be ElementSUBSET-1M1-of NATNUMBERSK1 & ( for nc be NatNAT-1M1 holds  for m be NatNAT-1M1 holds x =XBOOLE-0R4 nc & l =XBOOLE-0R4 m implies (nc <XXREAL-0R3 m & a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <>HIDDENR2 0NUMBERSK6) & ( for k be NatNAT-1M1 holds nc <XXREAL-0R3 k & a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k <>HIDDENR2 0NUMBERSK6 implies m <=XXREAL-0R1 k))"
                        using A20 sorry
                    qed "sorry"
                  qed "sorry"
                  thus " ?thesis "
                     sorry
                qed
                obtain zz where 
                  [ty]:"zz be ElementSUBSET-1M1-of NATNUMBERSK1" and zzDef:"zz = 0NUMBERSK6"
                   sorry
                obtain F where
                  [ty]:"F be sequenceNAT-1M2-of NATNUMBERSK1" and 
                  A21: "F .RECDEF-1K1 (0NUMBERSK6) =COMPLEX1R1 InSUBSET-1K10(M,NATNUMBERSK1) & ( for n be NatNAT-1M1 holds ?P(n,F .RECDEF-1K1 n,F .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M)))"
                  using recdef_1_sch_2 A18 sorry
                have "rngFUNCT-1K2 F c=TARSKIR1 NATNUMBERSK1"
                  using relat_1_def_19 sorry
                then have A22: "rngFUNCT-1K2 F c=TARSKIR1 REALNUMBERSK2"
                  using numbers_th_19 sorry
                have "domRELAT-1K1 F =XBOOLE-0R4 NATNUMBERSK1"
                  using funct_2_def_1 sorry
                then have 
                  [ty]:"F be Real-SequenceSEQ-1M1"
                  using A22 relset_1_th_4 sorry
                have " for n be NatNAT-1M1 holds F .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 F .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
                  using A21 sorry
                then have 
                  [ty]:"F be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
                  using seqm_3_def_6 sorry
                have A23: " for n be NatNAT-1M1 holds a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6 implies ( ex m be NatNAT-1M1 st F .RECDEF-1K1 m =COMPLEX1R1 n)"
                proof-
                  have "( ex n be NatNAT-1M1 st a .FUNCT-1K1 n <>HIDDENR2 0NUMBERSK6 & ( for m be NatNAT-1M1 holds F .RECDEF-1K1 m <>HIDDENR2 n)) implies  False "
                  proof(rule impI)
                    let ?P = "\<lambda>Lamb1. a .FUNCT-1K1 Lamb1 <>HIDDENR2 0NUMBERSK6 & ( for m be NatNAT-1M1 holds F .RECDEF-1K1 m <>HIDDENR2 Lamb1)"
                    assume " ex n be NatNAT-1M1 st ?P(n)"
                    then have A24: " ex n be NatNAT-1M1 st ?P(n)"
                       sorry
                    obtain M1 where
                      [ty]:"M1 be NatNAT-1M1" and 
                      A25: "?P(M1) & ( for n be NatNAT-1M1 holds ?P(n) implies M1 <=XXREAL-0R1 n)"
                      using nat_1_sch_5 A24 sorry
                    let ?P = "\<lambda>Lamb1. (Lamb1 <XXREAL-0R3 M1 & a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 <>HIDDENR2 0NUMBERSK6) & ( ex m be NatNAT-1M1 st F .RECDEF-1K1 m =COMPLEX1R1 Lamb1)"
                    have A26: " ex n be NatNAT-1M1 st ?P(n)"
                    proof-
                      have " ex tVar6 be NatNAT-1M1 st tVar6 <XXREAL-0R3 M1 & (a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> tVar6 <>HIDDENR2 0NUMBERSK6 & ( ex tVar7 be NatNAT-1M1 st F .RECDEF-1K1 tVar7 =COMPLEX1R1 tVar6))"
                      proof-
                        show " ex tVar6 be NatNAT-1M1 st tVar6 <XXREAL-0R3 M1 & (a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> tVar6 <>HIDDENR2 0NUMBERSK6 & ( ex tVar7 be NatNAT-1M1 st F .RECDEF-1K1 tVar7 =COMPLEX1R1 tVar6))"
                        proof(rule bexI[of _ "M"],rule conjMI,rule conjMI)
                          have "M <=XXREAL-0R1 M1 & M <>HIDDENR2 M1"
                            using A14 A21 A25 sorry
                          thus "M <XXREAL-0R3 M1"
                            using xxreal_0_th_1 sorry
                          show "a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> M <>HIDDENR2 0NUMBERSK6"
                            using A14 sorry
                          show " ex tVar7 be NatNAT-1M1 st F .RECDEF-1K1 tVar7 =COMPLEX1R1 M"
                          proof(rule bexI[of _ "0NUMBERSK6"])
                            show "F .RECDEF-1K1 (0NUMBERSK6) =COMPLEX1R1 M"
                              using A21 sorry
                          qed "sorry"
                        qed "sorry"
                      qed
                      thus " ?thesis "
                         sorry
                    qed
                    have A27: " for n be NatNAT-1M1 holds ?P(n) implies n <=XXREAL-0R1 M1"
                       sorry
                    obtain MX where
                      [ty]:"MX be NatNAT-1M1" and 
                      A28: "?P(MX) & ( for n be NatNAT-1M1 holds ?P(n) implies n <=XXREAL-0R1 MX)"
                      using nat_1_sch_6 A27 A26 sorry
                    have A29: " for k be NatNAT-1M1 holds MX <XXREAL-0R3 k & k <XXREAL-0R3 M1 implies a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6"
                    proof-
                      have "( ex k be NatNAT-1M1 st MX <XXREAL-0R3 k & (k <XXREAL-0R3 M1 & a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k <>HIDDENR2 0NUMBERSK6)) implies  False "
                      proof(rule impI)
                        assume Given: " ex k be NatNAT-1M1 st MX <XXREAL-0R3 k & (k <XXREAL-0R3 M1 & a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k <>HIDDENR2 0NUMBERSK6)"
                        then obtain k where
                          [ty]:"k be NatNAT-1M1" and 
                          A30: "MX <XXREAL-0R3 k"and A31: "k <XXREAL-0R3 M1 & a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k <>HIDDENR2 0NUMBERSK6"
                           sorry
                        have "( ex m be NatNAT-1M1 st F .RECDEF-1K1 m =COMPLEX1R1 k) &  False  or ( for m be NatNAT-1M1 holds F .RECDEF-1K1 m <>HIDDENR2 k) & (( for m be NatNAT-1M1 holds F .RECDEF-1K1 m <>HIDDENR2 k) implies  False )"
                        proof-
                          show "( ex m be NatNAT-1M1 st F .RECDEF-1K1 m =COMPLEX1R1 k) &  False  or ( for m be NatNAT-1M1 holds F .RECDEF-1K1 m <>HIDDENR2 k) & (( for m be NatNAT-1M1 holds F .RECDEF-1K1 m <>HIDDENR2 k) implies  False )"
                          proof-
                            have cases: "( ex m be NatNAT-1M1 st F .RECDEF-1K1 m =COMPLEX1R1 k) or ( for m be NatNAT-1M1 holds F .RECDEF-1K1 m <>HIDDENR2 k)"
                               sorry
                            have case1: "( ex m be NatNAT-1M1 st F .RECDEF-1K1 m =COMPLEX1R1 k) implies  False "
                            proof(rule impI)
                              assume " ex m be NatNAT-1M1 st F .RECDEF-1K1 m =COMPLEX1R1 k"
                              thus " False "
                                using A28 A30 A31 sorry
                            qed
                            have case2: "( for m be NatNAT-1M1 holds F .RECDEF-1K1 m <>HIDDENR2 k) implies  False "
                            proof(rule impI)
                              assume " for m be NatNAT-1M1 holds F .RECDEF-1K1 m <>HIDDENR2 k"
                              thus " False "
                                using A25 A31 sorry
                            qed
                            show " ?thesis "
                              using cases case1 case2 sorry
                          qed
                        qed
                        thus " False "
                           sorry
                      qed
                      thus " ?thesis "
                         sorry
                    qed
                    obtain m where
                      [ty]:"m be NatNAT-1M1" and 
                      A32: "F .RECDEF-1K1 m =COMPLEX1R1 MX"
                      using A28 sorry
                    have A33: "MX <XXREAL-0R3 F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) & a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M)) <>HIDDENR2 0NUMBERSK6"
                      using A21 A32 sorry
                    have A34: "F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 M1"
                      using A21 A25 A28 A32 sorry
                    have "F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 M1 implies  False "
                    proof(rule impI)
                      assume "F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 M1"
                      then have "F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 M1"
                        using A34 xxreal_0_th_1 sorry
                      thus " False "
                        using A29 A33 sorry
                    qed
                    thus " False "
                      using A25 sorry
                  qed
                  thus " ?thesis "
                     sorry
                qed
                have A35: "a *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> F be convergentSEQ-2V5 & limSEQ-2K1 (a *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> F) =COMPLEX1R1 0NUMBERSK6"
                  using A2 A5 seq_4_th_16 seq_4_th_17 sorry
                have A36: " for e be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 e implies ( ex k be NatNAT-1M1 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 (limSEQ-2K1 a)to-powerPOWERK2 p .| <XXREAL-0R3 e)"
                proof(rule ballI,rule impI)
                  fix e assume [ty]: "e be RealXREAL-0M1"
                  assume A37: "0NUMBERSK6 <XXREAL-0R3 e"
                  then have "0NUMBERSK6 <XXREAL-0R3 e to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
                    using power_th_34 sorry
                  then obtain n where
                    [ty]:"n be NatNAT-1M1" and 
                    A38: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 (a *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> F).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 e to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
                    using A35 seq_2_def_7 sorry
                  obtain k where 
                    [ty]:"k be NatNAT-1M1" and kDef:"k = F .RECDEF-1K1 n"
                     sorry
                  show " ex k be NatNAT-1M1 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 (limSEQ-2K1 a)to-powerPOWERK2 p .| <XXREAL-0R3 e"
                  proof(rule bexI[of _ "k"],rule ballI,rule impI)
                    fix m assume [ty]: "m be NatNAT-1M1"
                    assume A39: "k <=XXREAL-0R1 m"
                    have "a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =COMPLEX1R1 0NUMBERSK6 &  |.COMPLEX1K10 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 (limSEQ-2K1 a)to-powerPOWERK2 p .| <XXREAL-0R3 e or a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <>HIDDENR2 0NUMBERSK6 & (a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <>HIDDENR2 0NUMBERSK6 implies  |.COMPLEX1K10 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 (limSEQ-2K1 a)to-powerPOWERK2 p .| <XXREAL-0R3 e)"
                    proof-
                      show "a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =COMPLEX1R1 0NUMBERSK6 &  |.COMPLEX1K10 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 (limSEQ-2K1 a)to-powerPOWERK2 p .| <XXREAL-0R3 e or a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <>HIDDENR2 0NUMBERSK6 & (a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <>HIDDENR2 0NUMBERSK6 implies  |.COMPLEX1K10 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 (limSEQ-2K1 a)to-powerPOWERK2 p .| <XXREAL-0R3 e)"
                      proof-
                        have cases: "a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =COMPLEX1R1 0NUMBERSK6 or a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <>HIDDENR2 0NUMBERSK6"
                           sorry
                        have case1: "a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =COMPLEX1R1 0NUMBERSK6 implies  |.COMPLEX1K10 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 (limSEQ-2K1 a)to-powerPOWERK2 p .| <XXREAL-0R3 e"
                        proof(rule impI)
                          assume "a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =COMPLEX1R1 0NUMBERSK6"
                          then have "ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =HIDDENR1 (0NUMBERSK6)to-powerPOWERK2 p"
                            using A4 sorry
                          also have "... = 0NUMBERSK6"
                            using A1 power_def_2 sorry
                          finally have "ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =HIDDENR1 0NUMBERSK6"
                             sorry
                          thus " |.COMPLEX1K10 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 (limSEQ-2K1 a)to-powerPOWERK2 p .| <XXREAL-0R3 e"
                            using A15 A37 absvalue_th_2 sorry
                        qed
                        have case2: "a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <>HIDDENR2 0NUMBERSK6 implies  |.COMPLEX1K10 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 (limSEQ-2K1 a)to-powerPOWERK2 p .| <XXREAL-0R3 e"
                        proof(rule impI)
                          assume A40: "a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <>HIDDENR2 0NUMBERSK6"
                          then obtain l where
                            [ty]:"l be NatNAT-1M1" and 
                            A41: "m =COMPLEX1R1 F .RECDEF-1K1 l"
                            using A23 sorry
                          have A42: "l inTARSKIR2 NATNUMBERSK1"
                            using ordinal1_def_12 sorry
                          have "n <=XXREAL-0R1 l"
                            using A39 A41 seqm_3_th_1 sorry
                          then have " |.COMPLEX1K10 (a *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> F).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 e to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
                            using A38 sorry
                          then have A43: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (F .RECDEF-1K1 l).| <XXREAL-0R3 e to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
                            using funct_2_th_15 A42 sorry
                          have A44: "(a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)to-powerPOWERK2 p =COMPLEX1R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
                            using A4 sorry
                          have A45: "a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m >XXREAL-0R4 0NUMBERSK6"
                            using A3 A40 sorry
                          then have A46: "0NUMBERSK6 <XXREAL-0R3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
                            using A44 power_th_34 sorry
                          have " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m.| >XXREAL-0R4 0NUMBERSK6"
                            using A40 complex1_th_47 sorry
                          then have "( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m.|)to-powerPOWERK2 p <XXREAL-0R3 (e to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))to-powerPOWERK2 p"
                            using A1 A41 A43 power_th_37 sorry
                          then have "( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m.|)to-powerPOWERK2 p <XXREAL-0R3 e to-powerPOWERK2 ((\<one>\<^sub>M /XCMPLX-0K7 p)*XCMPLX-0K3 p)"
                            using A37 power_th_33 sorry
                          then have "( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m.|)to-powerPOWERK2 p <XXREAL-0R3 e to-powerPOWERK2 \<one>\<^sub>M"
                            using A1 xcmplx_1_th_106 sorry
                          then have "( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m.|)to-powerPOWERK2 p <XXREAL-0R3 e"
                            using power_th_25 sorry
                          then have "ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <XXREAL-0R3 e"
                            using A45 A44 absvalue_def_1 sorry
                          thus " |.COMPLEX1K10 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 (limSEQ-2K1 a)to-powerPOWERK2 p .| <XXREAL-0R3 e"
                            using A15 A46 absvalue_def_1 sorry
                        qed
                        show " ?thesis "
                          using cases case1 case2 sorry
                      qed
                    qed
                    thus " |.COMPLEX1K10 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 (limSEQ-2K1 a)to-powerPOWERK2 p .| <XXREAL-0R3 e"
                       sorry
                  qed "sorry"
                qed "sorry"
                thus "ap be convergentSEQ-2V5"
                  using seq_2_def_6 sorry
                thus "limSEQ-2K1 ap =COMPLEX1R1 (limSEQ-2K1 a)to-powerPOWERK2 p"
                  using A36 seq_2_def_7 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "ap be convergentSEQ-2V5 & limSEQ-2K1 ap =COMPLEX1R1 (limSEQ-2K1 a)to-powerPOWERK2 p"
             sorry
        qed
        have case2: "limSEQ-2K1 a <>HIDDENR2 0NUMBERSK6 implies ap be convergentSEQ-2V5 & limSEQ-2K1 ap =COMPLEX1R1 (limSEQ-2K1 a)to-powerPOWERK2 p"
        proof(rule impI)
          assume A47: "limSEQ-2K1 a <>HIDDENR2 0NUMBERSK6"
          have A48: "0NUMBERSK6 <=XXREAL-0R1 limSEQ-2K1 a"
            using A2 A3 seq_2_th_17 sorry
          have " ex k be NatNAT-1M1 st rngFUNCT-1K2 (a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 (#RTAYLOR-1K4 p)"
          proof-
            have " ex tVar9 be NatNAT-1M1 st rngFUNCT-1K2 (a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> tVar9) c=TARSKIR1 domRELAT-1K1 (#RTAYLOR-1K4 p)"
            proof-
              let ?e0 = "limSEQ-2K1 a"
              have A49: "?e0 /XCMPLX-0K7 \<two>\<^sub>M >XXREAL-0R4 0NUMBERSK6"
                using A47 A48 xreal_1_th_215 sorry
              then obtain k where
                [ty]:"k be NatNAT-1M1" and 
                A50: " for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 ?e0 .| <XXREAL-0R3 ?e0 /XCMPLX-0K7 \<two>\<^sub>M"
                using A2 seq_2_def_7 sorry
              show " ex tVar9 be NatNAT-1M1 st rngFUNCT-1K2 (a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> tVar9) c=TARSKIR1 domRELAT-1K1 (#RTAYLOR-1K4 p)"
              proof(rule bexI[of _ "k"])
                have A51: " for m be NatNAT-1M1 holds 0NUMBERSK6 <XXREAL-0R3 (a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
                proof(rule ballI)
                  fix m assume [ty]: "m be NatNAT-1M1"
                  have " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +XCMPLX-0K2 m) -XCMPLX-0K6 ?e0 .| <XXREAL-0R3 ?e0 /XCMPLX-0K7 \<two>\<^sub>M"
                    using A50 nat_1_th_12 sorry
                  then have "-XCMPLX-0K4 ?e0 /XCMPLX-0K7 \<two>\<^sub>M <=XXREAL-0R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +XCMPLX-0K2 m) -XCMPLX-0K6 ?e0"
                    using absvalue_th_5 sorry
                  then have "(-XCMPLX-0K4 ?e0 /XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 ?e0 <=XXREAL-0R1 (a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +XCMPLX-0K2 m) -XCMPLX-0K6 ?e0)+XCMPLX-0K2 ?e0"
                    using xreal_1_th_7 sorry
                  thus "0NUMBERSK6 <XXREAL-0R3 (a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
                    using A49 nat_1_def_3 sorry
                qed "sorry"
                have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELAT-1K1 (#RTAYLOR-1K4 p)"
                proof(rule ballI,rule impI)
                  fix x assume [ty]: "x be objectHIDDENM1"
                  assume "x inHIDDENR3 rngFUNCT-1K2 (a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
                  then obtain n where
                    [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                    A52: "x =HIDDENR1 (a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
                    using funct_2_th_113 sorry
                  have "0NUMBERSK6 <XXREAL-0R3 (a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
                    using A51 sorry
                  then have "(a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n inTARSKIR2 {g where g be RealXREAL-0M1 : 0NUMBERSK6 <XXREAL-0R3 g }"
                     sorry
                  then have "(a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n inTARSKIR2 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
                    using xxreal_1_th_230 sorry
                  thus "x inHIDDENR3 domRELAT-1K1 (#RTAYLOR-1K4 p)"
                    using A52 taylor_1_def_4 sorry
                qed "sorry"
                thus "rngFUNCT-1K2 (a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 (#RTAYLOR-1K4 p)"
                  using tarski_def_3 sorry
              qed "sorry"
            qed
            thus " ?thesis "
               sorry
          qed
          then obtain k where
            [ty]:"k be NatNAT-1M1" and 
            A53: "rngFUNCT-1K2 (a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 (#RTAYLOR-1K4 p)"
             sorry
          have " for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies (#RTAYLOR-1K4 p)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 x =HIDDENR1 (ap ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 x"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 NATNUMBERSK1"
            then obtain n where 
              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = x"
               sorry
            have "(a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n inTARSKIR2 rngFUNCT-1K2 (a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
              using valued_0_th_28 sorry
            then have "(a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n inTARSKIR2 domRELAT-1K1 (#RTAYLOR-1K4 p)"
              using A53 sorry
            then have A54: "(a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n inTARSKIR2 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
              using taylor_1_def_4 sorry
            then have "a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 n) inTARSKIR2 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
              using nat_1_def_3 sorry
            then have "a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 n) inTARSKIR2 {g where g be RealXREAL-0M1 : 0NUMBERSK6 <XXREAL-0R3 g }"
              using xxreal_1_th_230 sorry
            then have A55: " ex g be RealXREAL-0M1 st a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 n) =COMPLEX1R1 g & g >XXREAL-0R4 0NUMBERSK6"
               sorry
            have "(#RTAYLOR-1K4 p)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 x =HIDDENR1 #RTAYLOR-1K4 p .FUNCT-1K1 ((a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
              using A53 funct_2_th_108 sorry
            also have "... = ((a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)#RPREPOWERK6 p"
              using A54 taylor_1_def_4 sorry
            also have "... = (a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 n))#RPREPOWERK6 p"
              using nat_1_def_3 sorry
            also have "... = (a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 n))to-powerPOWERK2 p"
              using A55 power_def_2 sorry
            also have "... = ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 n)"
              using A4 sorry
            also have "... = (ap ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 x"
              using nat_1_def_3 sorry
            finally show "(#RTAYLOR-1K4 p)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 x =HIDDENR1 (ap ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 x"
               sorry
          qed "sorry"
          then have A56: "(#RTAYLOR-1K4 p)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ap ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
            using funct_2_th_12 sorry
          have A57: "limSEQ-2K1 (a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 limSEQ-2K1 a"
            using A2 seq_4_th_20 sorry
          have "limSEQ-2K1 a >XXREAL-0R4 0NUMBERSK6"
            using A2 A3 A47 seq_2_th_17 sorry
          then have "#RTAYLOR-1K4 p is-continuous-inFCONT-1R1 limSEQ-2K1 (a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
            using A57 fdiff_1_th_24 taylor_1_th_21 sorry
          then have A58: "(#RTAYLOR-1K4 p)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5 & #RTAYLOR-1K4 p .FUNCT-1K1 (limSEQ-2K1 (a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) =COMPLEX1R1 limSEQ-2K1 (#RTAYLOR-1K4 p)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
            using A2 A53 fcont_1_def_1 sorry
          have "limSEQ-2K1 a inHIDDENR3 {g where g be RealXREAL-0M1 : 0NUMBERSK6 <XXREAL-0R3 g }"
            using A47 A48 sorry
          then have "limSEQ-2K1 a inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
            using xxreal_1_th_230 sorry
          then have "#RTAYLOR-1K4 p .FUNCT-1K1 (limSEQ-2K1 (a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) =HIDDENR1 (limSEQ-2K1 a)#RPREPOWERK6 p"
            using A57 taylor_1_def_4 sorry
          also have "... = (limSEQ-2K1 a)to-powerPOWERK2 p"
            using A47 A48 power_def_2 sorry
          finally have "#RTAYLOR-1K4 p .FUNCT-1K1 (limSEQ-2K1 (a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) =HIDDENR1 (limSEQ-2K1 a)to-powerPOWERK2 p"
             sorry
          thus "ap be convergentSEQ-2V5 & limSEQ-2K1 ap =COMPLEX1R1 (limSEQ-2K1 a)to-powerPOWERK2 p"
            using A58 A56 seq_4_th_21 seq_4_th_22 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "ap be convergentSEQ-2V5 & limSEQ-2K1 ap =COMPLEX1R1 (limSEQ-2K1 a)to-powerPOWERK2 p"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem holder_1_th_11:
" for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( for a be Real-SequenceSEQ-1M1 holds  for ap be Real-SequenceSEQ-1M1 holds (a be summableSERIES-1V1 & ( for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & ( for n be NatNAT-1M1 holds ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p) implies ((ap be convergentSEQ-2V5 & limSEQ-2K1 ap =COMPLEX1R1 SumSERIES-1K4 a to-powerPOWERK2 p) & ap be non-decreasingVALUED-0V11) & ( for n be NatNAT-1M1 holds ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 SumSERIES-1K4 a to-powerPOWERK2 p))"
proof-
  have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( for a be Real-SequenceSEQ-1M1 holds  for ap be Real-SequenceSEQ-1M1 holds a be summableSERIES-1V1 & (( for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) & ( for n be NatNAT-1M1 holds ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p)) implies (ap be convergentSEQ-2V5 & limSEQ-2K1 ap =COMPLEX1R1 SumSERIES-1K4 a to-powerPOWERK2 p) & (ap be non-decreasingVALUED-0V11 & ( for n be NatNAT-1M1 holds ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 SumSERIES-1K4 a to-powerPOWERK2 p)))"
  proof(rule ballI,rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI,rule conjMI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 p"
    fix a assume [ty]: "a be Real-SequenceSEQ-1M1"
    fix ap assume [ty]: "ap be Real-SequenceSEQ-1M1"
    assume A2: "a be summableSERIES-1V1"
      and A3: " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      and A4: " for n be NatNAT-1M1 holds ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p"
    have A5: "Partial-SumsSERIES-1K3 a be convergentSEQ-2V5 & ( for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
      using A2 A3 holder_1_lm_2 series_1_def_2 sorry
    then have "limSEQ-2K1 ap =COMPLEX1R1 (limSEQ-2K1 Partial-SumsSERIES-1K3 a)to-powerPOWERK2 p"
      using A1 A4 holder_1_th_10 sorry
    thus A6: "ap be convergentSEQ-2V5 & limSEQ-2K1 ap =COMPLEX1R1 SumSERIES-1K4 a to-powerPOWERK2 p"
      using A1 A4 A5 holder_1_th_10 series_1_def_3 sorry
    have A7: "Partial-SumsSERIES-1K3 a be non-decreasingVALUED-0V11"
      using A3 series_1_th_16 sorry
    have " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
    proof(rule ballI,rule ballI,rule impI)
      fix n assume [ty]: "n be NatNAT-1M1"
      fix m assume [ty]: "m be NatNAT-1M1"
      assume "n <=XXREAL-0R1 m"
      then have A8: "Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
        using A7 seqm_3_th_6 sorry
      have A9: "ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p & ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =COMPLEX1R1 (Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)to-powerPOWERK2 p"
        using A4 sorry
      have "0NUMBERSK6 <=XXREAL-0R1 Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A3 holder_1_lm_2 sorry
      thus "ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
        using A1 A9 A8 holder_1_th_3 sorry
    qed "sorry"
    thus A10: "ap be non-decreasingVALUED-0V11"
      using seqm_3_th_6 sorry
    show " for n be NatNAT-1M1 holds ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 SumSERIES-1K4 a to-powerPOWERK2 p"
      using A6 A10 seq_4_th_37 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem holder_1_th_12:
" for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds \<one>\<^sub>M <XXREAL-0R3 p & \<one>\<^sub>M /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q =COMPLEX1R1 \<one>\<^sub>M implies ( for a be Real-SequenceSEQ-1M1 holds  for b be Real-SequenceSEQ-1M1 holds  for ap be Real-SequenceSEQ-1M1 holds  for bq be Real-SequenceSEQ-1M1 holds  for ab be Real-SequenceSEQ-1M1 holds (( for n be NatNAT-1M1 holds (ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p & bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q) & ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|) & ap be summableSERIES-1V1) & bq be summableSERIES-1V1 implies ab be summableSERIES-1V1 & SumSERIES-1K4 ab <=XXREAL-0R1 SumSERIES-1K4 ap to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 SumSERIES-1K4 bq to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))"
proof-
  have " for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds \<one>\<^sub>M <XXREAL-0R3 p & \<one>\<^sub>M /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q =COMPLEX1R1 \<one>\<^sub>M implies ( for a be Real-SequenceSEQ-1M1 holds  for b be Real-SequenceSEQ-1M1 holds  for ap be Real-SequenceSEQ-1M1 holds  for bq be Real-SequenceSEQ-1M1 holds  for ab be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds (ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p & bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q) & ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|) & (ap be summableSERIES-1V1 & bq be summableSERIES-1V1) implies ab be summableSERIES-1V1 & SumSERIES-1K4 ab <=XXREAL-0R1 SumSERIES-1K4 ap to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 SumSERIES-1K4 bq to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix q assume [ty]: "q be RealXREAL-0M1"
    assume A1: "\<one>\<^sub>M <XXREAL-0R3 p"
      and A2: "\<one>\<^sub>M /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q =COMPLEX1R1 \<one>\<^sub>M"
    fix a assume [ty]: "a be Real-SequenceSEQ-1M1"
    fix b assume [ty]: "b be Real-SequenceSEQ-1M1"
    fix ap assume [ty]: "ap be Real-SequenceSEQ-1M1"
    fix bq assume [ty]: "bq be Real-SequenceSEQ-1M1"
    fix ab assume [ty]: "ab be Real-SequenceSEQ-1M1"
    assume A3: " for n be NatNAT-1M1 holds (ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p & bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q) & ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
      and A4: "ap be summableSERIES-1V1"
      and A5: "bq be summableSERIES-1V1"
    have A6: "Partial-SumsSERIES-1K3 ap be convergentSEQ-2V5"
      using A4 series_1_def_2 sorry
    obtain pp where 
      [ty]:"pp be RealXREAL-0M1" and ppDef:"pp = \<one>\<^sub>M /XCMPLX-0K7 p"
       sorry
    have "\<one>\<^sub>M /XCMPLX-0K7 p <XXREAL-0R3 \<one>\<^sub>M"
      using A1 xreal_1_th_189 sorry
    then have A7: "\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 \<one>\<^sub>M -XCMPLX-0K6 pp"
      using xreal_1_th_15 sorry
    then have A8: "0NUMBERSK6 <XXREAL-0R3 q"
      using A2 sorry
    have " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have A9: "bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q"
        using A3 sorry
      have " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 & 0NUMBERSK6 <=XXREAL-0R1 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n or  |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 & ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
      proof-
        show " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 & 0NUMBERSK6 <=XXREAL-0R1 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n or  |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 & ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
        proof-
          have cases: " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 or  |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6"
            using complex1_th_46 sorry
          have case1: " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          proof(rule impI)
            assume " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6"
            thus "0NUMBERSK6 <=XXREAL-0R1 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
              using A8 A9 power_def_2 sorry
          qed
          have case2: " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          proof(rule impI)
            assume " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6"
            thus "0NUMBERSK6 <=XXREAL-0R1 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
              using A9 power_th_34 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "0NUMBERSK6 <=XXREAL-0R1 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    then have A10: " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using holder_1_lm_2 sorry
    have " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
        using A3 sorry
      thus "0NUMBERSK6 <=XXREAL-0R1 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using complex1_th_46 sorry
    qed "sorry"
    then have A11: "Partial-SumsSERIES-1K3 ab be non-decreasingVALUED-0V11"
      using series_1_th_16 sorry
    let ?G = "\<lambda>Lamb1. (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)"
    obtain y where
      [ty]:"y be Real-SequenceSEQ-1M1" and 
      A12: " for n be NatNAT-1M1 holds y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ?G(n)"
      using seq_1_sch_1 sorry
    have " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have A13: "ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p"
        using A3 sorry
      have " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 & 0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n or  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 & ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
      proof-
        show " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 & 0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n or  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 & ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
        proof-
          have cases: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 or  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6"
            using complex1_th_46 sorry
          have case1: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          proof(rule impI)
            assume " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6"
            thus "0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
              using A1 A13 power_def_2 sorry
          qed
          have case2: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          proof(rule impI)
            assume " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6"
            thus "0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
              using A13 power_th_34 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    then have A14: " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using holder_1_lm_2 sorry
    let ?F = "\<lambda>Lamb1. (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
    obtain x where
      [ty]:"x be Real-SequenceSEQ-1M1" and 
      A15: " for n be NatNAT-1M1 holds x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ?F(n)"
      using seq_1_sch_1 sorry
    have A16: " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> y).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have A17: "y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)"
        using A12 sorry
      have "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q) & x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
        using A1 A2 A3 A15 holder_1_th_6 sorry
      thus "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> y).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A17 seq_1_th_8 sorry
    qed "sorry"
    have A18: "\<one>\<^sub>M /XCMPLX-0K7 p >XXREAL-0R4 0NUMBERSK6"
      using A1 xreal_1_th_139 sorry
    then have A19: "x be convergentSEQ-2V5"
      using A15 A6 A14 holder_1_th_10 sorry
    have A20: "Partial-SumsSERIES-1K3 bq be convergentSEQ-2V5"
      using A5 series_1_def_2 sorry
    then have A21: "y be convergentSEQ-2V5"
      using A2 A7 A12 A10 holder_1_th_10 sorry
    then have "x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> y be convergentSEQ-2V5"
      using A19 sorry
    then have A22: "Partial-SumsSERIES-1K3 ab be convergentSEQ-2V5 & limSEQ-2K1 Partial-SumsSERIES-1K3 ab <=XXREAL-0R1 limSEQ-2K1 (x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> y)"
      using A16 A11 holder_1_th_8 sorry
    have "SumSERIES-1K4 ap =COMPLEX1R1 limSEQ-2K1 Partial-SumsSERIES-1K3 ap"
      using series_1_def_3 sorry
    then have A23: "limSEQ-2K1 x =COMPLEX1R1 SumSERIES-1K4 ap to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
      using A18 A15 A6 A14 holder_1_th_10 sorry
    have "SumSERIES-1K4 bq =COMPLEX1R1 limSEQ-2K1 Partial-SumsSERIES-1K3 bq"
      using series_1_def_3 sorry
    then have "limSEQ-2K1 y =COMPLEX1R1 SumSERIES-1K4 bq to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)"
      using A2 A7 A12 A20 A10 holder_1_th_10 sorry
    then have "limSEQ-2K1 (x (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> y) =COMPLEX1R1 SumSERIES-1K4 ap to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 SumSERIES-1K4 bq to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)"
      using A19 A23 A21 seq_2_th_15 sorry
    thus "ab be summableSERIES-1V1 & SumSERIES-1K4 ab <=XXREAL-0R1 SumSERIES-1K4 ap to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 SumSERIES-1K4 bq to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)"
      using A22 series_1_def_2 series_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem holder_1_th_13:
" for p be RealXREAL-0M1 holds \<one>\<^sub>M <XXREAL-0R3 p implies ( for a be Real-SequenceSEQ-1M1 holds  for b be Real-SequenceSEQ-1M1 holds  for ap be Real-SequenceSEQ-1M1 holds  for bp be Real-SequenceSEQ-1M1 holds  for ab be Real-SequenceSEQ-1M1 holds (( for n be NatNAT-1M1 holds (ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p & bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p) & ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|)to-powerPOWERK2 p) & ap be summableSERIES-1V1) & bp be summableSERIES-1V1 implies ab be summableSERIES-1V1 & SumSERIES-1K4 ab to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 SumSERIES-1K4 ap to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) +XCMPLX-0K2 SumSERIES-1K4 bp to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))"
proof-
  have " for p be RealXREAL-0M1 holds \<one>\<^sub>M <XXREAL-0R3 p implies ( for a be Real-SequenceSEQ-1M1 holds  for b be Real-SequenceSEQ-1M1 holds  for ap be Real-SequenceSEQ-1M1 holds  for bp be Real-SequenceSEQ-1M1 holds  for ab be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds (ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p & bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p) & ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|)to-powerPOWERK2 p) & (ap be summableSERIES-1V1 & bp be summableSERIES-1V1) implies ab be summableSERIES-1V1 & SumSERIES-1K4 ab to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 SumSERIES-1K4 ap to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) +XCMPLX-0K2 SumSERIES-1K4 bp to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))"
  proof(rule ballI,rule impI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    assume A1: "\<one>\<^sub>M <XXREAL-0R3 p"
    have A2: "\<one>\<^sub>M /XCMPLX-0K7 p >XXREAL-0R4 0NUMBERSK6"
      using A1 xreal_1_th_139 sorry
    fix a assume [ty]: "a be Real-SequenceSEQ-1M1"
    fix b assume [ty]: "b be Real-SequenceSEQ-1M1"
    fix ap assume [ty]: "ap be Real-SequenceSEQ-1M1"
    fix bp assume [ty]: "bp be Real-SequenceSEQ-1M1"
    fix ab assume [ty]: "ab be Real-SequenceSEQ-1M1"
    assume A3: " for n be NatNAT-1M1 holds (ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p & bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p) & ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|)to-powerPOWERK2 p"
      and A4: "ap be summableSERIES-1V1"
      and A5: "bp be summableSERIES-1V1"
    let ?H = "\<lambda>Lamb1. (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
    obtain z where
      [ty]:"z be Real-SequenceSEQ-1M1" and 
      A6: " for n be NatNAT-1M1 holds z .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ?H(n)"
      using seq_1_sch_1 sorry
    have A7: " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have A8: "ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|)to-powerPOWERK2 p"
        using A3 sorry
      show "0NUMBERSK6 <=XXREAL-0R1 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      proof-
        have cases: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| =COMPLEX1R1 0NUMBERSK6 or  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| >XXREAL-0R4 0NUMBERSK6"
          using complex1_th_46 sorry
        have case1: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| =COMPLEX1R1 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        proof(rule impI)
          assume " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| =COMPLEX1R1 0NUMBERSK6"
          thus "0NUMBERSK6 <=XXREAL-0R1 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
            using A1 A8 power_def_2 sorry
        qed
        have case2: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| >XXREAL-0R4 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        proof(rule impI)
          assume " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| >XXREAL-0R4 0NUMBERSK6"
          thus "0NUMBERSK6 <=XXREAL-0R1 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
            using A8 power_th_34 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    have A9: " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 z .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have A10: "z .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
        using A6 sorry
      show "0NUMBERSK6 <=XXREAL-0R1 z .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      proof-
        have cases: "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6 or Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6"
          using A7 holder_1_lm_2 sorry
        have case1: "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 z .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        proof(rule impI)
          assume "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6"
          thus "0NUMBERSK6 <=XXREAL-0R1 z .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
            using A2 A10 power_def_2 sorry
        qed
        have case2: "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 z .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        proof(rule impI)
          assume "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6"
          thus "0NUMBERSK6 <=XXREAL-0R1 z .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
            using A10 power_th_34 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    have A11: "Partial-SumsSERIES-1K3 ab be non-decreasingVALUED-0V11"
      using A7 series_1_th_16 sorry
    have A12: " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
    proof(rule ballI,rule ballI,rule impI)
      fix n assume [ty]: "n be NatNAT-1M1"
      fix m assume [ty]: "m be NatNAT-1M1"
      assume "n <=XXREAL-0R1 m"
      then have A13: "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
        using A11 seqm_3_th_6 sorry
      have A14: "0NUMBERSK6 <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
      proof-
        show "0NUMBERSK6 <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
        proof-
          have cases: "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =COMPLEX1R1 0NUMBERSK6 or Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m >XXREAL-0R4 0NUMBERSK6"
            using A7 holder_1_lm_2 sorry
          have case1: "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =COMPLEX1R1 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
          proof(rule impI)
            assume "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =COMPLEX1R1 0NUMBERSK6"
            thus "0NUMBERSK6 <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
              using A2 power_def_2 sorry
          qed
          have case2: "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m >XXREAL-0R4 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
          proof(rule impI)
            assume "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m >XXREAL-0R4 0NUMBERSK6"
            thus "0NUMBERSK6 <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
              using power_th_34 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      have "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m & (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) or Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m & (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m implies (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))"
      proof-
        show "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m & (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) or Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m & (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m implies (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))"
        proof-
          have cases: "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m or Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
             sorry
          have case1: "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m implies (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
          proof(rule impI)
            assume "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
            thus "(Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
               sorry
          qed
          have case2: "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m implies (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
          proof(rule impI)
            assume "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
            then have A15: "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
              using A13 xxreal_0_th_1 sorry
            have "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6 & (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) or Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6 & (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6 implies (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))"
            proof-
              show "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6 & (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) or Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6 & (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6 implies (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))"
              proof-
                have cases: "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6 or Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6"
                   sorry
                have case1: "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6 implies (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
                proof(rule impI)
                  assume "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6"
                  thus "(Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
                    using A2 A14 power_def_2 sorry
                qed
                have case2: "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6 implies (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
                proof(rule impI)
                  assume A16: "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6"
                  have "0NUMBERSK6 <=XXREAL-0R1 Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
                    using A7 holder_1_lm_2 sorry
                  thus "(Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
                    using A2 A15 A16 power_th_37 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "(Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "(Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
         sorry
    qed "sorry"
    have " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies z .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 z .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
    proof(rule ballI,rule ballI,rule impI)
      fix n assume [ty]: "n be NatNAT-1M1"
      fix m assume [ty]: "m be NatNAT-1M1"
      assume A17: "n <=XXREAL-0R1 m"
      have "z .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) & z .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =COMPLEX1R1 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
        using A6 sorry
      thus "z .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 z .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
        using A12 A17 sorry
    qed "sorry"
    then have A18: "z be non-decreasingVALUED-0V11"
      using seqm_3_th_6 sorry
    have " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have A19: "ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p"
        using A3 sorry
      have " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 & 0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n or  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 & ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
      proof-
        show " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 & 0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n or  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 & ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
        proof-
          have cases: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 or  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6"
            using complex1_th_46 sorry
          have case1: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          proof(rule impI)
            assume " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6"
            thus "0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
              using A1 A19 power_def_2 sorry
          qed
          have case2: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          proof(rule impI)
            assume " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6"
            thus "0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
              using A19 power_th_34 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "0NUMBERSK6 <=XXREAL-0R1 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    then have A20: " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using holder_1_lm_2 sorry
    let ?F = "\<lambda>Lamb1. (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
    obtain x where
      [ty]:"x be Real-SequenceSEQ-1M1" and 
      A21: " for n be NatNAT-1M1 holds x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ?F(n)"
      using seq_1_sch_1 sorry
    have " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have A22: "bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p"
        using A3 sorry
      have " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 & 0NUMBERSK6 <=XXREAL-0R1 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n or  |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 & ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
      proof-
        show " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 & 0NUMBERSK6 <=XXREAL-0R1 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n or  |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 & ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
        proof-
          have cases: " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 or  |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6"
            using complex1_th_46 sorry
          have case1: " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          proof(rule impI)
            assume " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 0NUMBERSK6"
            thus "0NUMBERSK6 <=XXREAL-0R1 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
              using A1 A22 power_def_2 sorry
          qed
          have case2: " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          proof(rule impI)
            assume " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >XXREAL-0R4 0NUMBERSK6"
            thus "0NUMBERSK6 <=XXREAL-0R1 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
              using A22 power_th_34 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "0NUMBERSK6 <=XXREAL-0R1 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    then have A23: " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 Partial-SumsSERIES-1K3 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using holder_1_lm_2 sorry
    let ?G = "\<lambda>Lamb1. (Partial-SumsSERIES-1K3 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
    obtain y where
      [ty]:"y be Real-SequenceSEQ-1M1" and 
      A24: " for n be NatNAT-1M1 holds y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ?G(n)"
      using seq_1_sch_1 sorry
    have A25: "Partial-SumsSERIES-1K3 bp be convergentSEQ-2V5"
      using A5 series_1_def_2 sorry
    then have A26: "y be convergentSEQ-2V5"
      using A2 A24 A23 holder_1_th_10 sorry
    have A27: "Partial-SumsSERIES-1K3 ap be convergentSEQ-2V5"
      using A4 series_1_def_2 sorry
    then have A28: "x be convergentSEQ-2V5"
      using A2 A21 A20 holder_1_th_10 sorry
    have A29: " for n be NatNAT-1M1 holds z .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have A30: "y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (Partial-SumsSERIES-1K3 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
        using A24 sorry
      have "(Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) +XCMPLX-0K2 (Partial-SumsSERIES-1K3 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) & x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
        using A1 A3 A21 holder_1_th_7 sorry
      thus "z .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 x .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 y .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A6 A30 sorry
    qed "sorry"
    then have A31: "z be convergentSEQ-2V5"
      using A28 A26 A18 holder_1_th_9 sorry
    have A32: " for n be NatNAT-1M1 holds (z .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p =COMPLEX1R1 Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have A33: "z .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
        using A6 sorry
      have "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6 & (z .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p =COMPLEX1R1 Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n or Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6 & (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6 implies (z .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p =HIDDENR1 Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
      proof-
        show "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6 & (z .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p =COMPLEX1R1 Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n or Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6 & (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6 implies (z .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p =HIDDENR1 Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
        proof-
          have cases: "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6 or Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6"
             sorry
          have case1: "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6 implies (z .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p =COMPLEX1R1 Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          proof(rule impI)
            assume A34: "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6"
            then have "z .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6"
              using A2 A33 power_def_2 sorry
            thus "(z .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p =COMPLEX1R1 Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
              using A1 A34 power_def_2 sorry
          qed
          have case2: "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6 implies (z .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p =HIDDENR1 Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          proof(rule impI)
            assume A35: "Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6"
            have "0NUMBERSK6 <=XXREAL-0R1 Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
              using A7 holder_1_lm_2 sorry
            then have "(z .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p =HIDDENR1 (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 ((\<one>\<^sub>M /XCMPLX-0K7 p)*XCMPLX-0K3 p)"
              using A33 A35 power_th_33 sorry
            also have "... = (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 \<one>\<^sub>M"
              using A1 xcmplx_1_th_106 sorry
            also have "... = Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
              using power_th_25 sorry
            finally show "(z .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p =HIDDENR1 Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "(z .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p =COMPLEX1R1 Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    then have "limSEQ-2K1 Partial-SumsSERIES-1K3 ab =COMPLEX1R1 (limSEQ-2K1 z)to-powerPOWERK2 p"
      using A1 A9 A31 holder_1_th_10 sorry
    then have A36: "SumSERIES-1K4 ab =COMPLEX1R1 (limSEQ-2K1 z)to-powerPOWERK2 p"
      using series_1_def_3 sorry
    have A37: "SumSERIES-1K4 ab to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) =COMPLEX1R1 limSEQ-2K1 z"
    proof-
      have "SumSERIES-1K4 ab to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) =HIDDENR1 limSEQ-2K1 z"
      proof-
        show "SumSERIES-1K4 ab to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) =HIDDENR1 limSEQ-2K1 z"
        proof-
          have cases: "limSEQ-2K1 z =COMPLEX1R1 0NUMBERSK6 or limSEQ-2K1 z <>HIDDENR2 0NUMBERSK6"
             sorry
          have case1: "limSEQ-2K1 z =COMPLEX1R1 0NUMBERSK6 implies SumSERIES-1K4 ab to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) =HIDDENR1 limSEQ-2K1 z"
          proof(rule impI)
            assume A38: "limSEQ-2K1 z =COMPLEX1R1 0NUMBERSK6"
            then have "SumSERIES-1K4 ab to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) =HIDDENR1 (0NUMBERSK6)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
              using A1 A36 power_def_2 sorry
            also have "... = limSEQ-2K1 z"
              using A2 A38 power_def_2 sorry
            finally show "SumSERIES-1K4 ab to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) =HIDDENR1 limSEQ-2K1 z"
               sorry
          qed
          have case2: "limSEQ-2K1 z <>HIDDENR2 0NUMBERSK6 implies SumSERIES-1K4 ab to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) =HIDDENR1 limSEQ-2K1 z"
          proof(rule impI)
            assume "limSEQ-2K1 z <>HIDDENR2 0NUMBERSK6"
            then have "0NUMBERSK6 <XXREAL-0R3 limSEQ-2K1 z"
              using A9 A31 seq_2_th_17 sorry
            then have "SumSERIES-1K4 ab to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) =HIDDENR1 (limSEQ-2K1 z)to-powerPOWERK2 ((\<one>\<^sub>M /XCMPLX-0K7 p)*XCMPLX-0K3 p)"
              using A36 power_th_33 sorry
            also have "... = (limSEQ-2K1 z)to-powerPOWERK2 \<one>\<^sub>M"
              using A1 xcmplx_1_th_106 sorry
            also have "... = limSEQ-2K1 z"
              using power_th_25 sorry
            finally show "SumSERIES-1K4 ab to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) =HIDDENR1 limSEQ-2K1 z"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus " ?thesis "
         sorry
    qed
    have "SumSERIES-1K4 bp =COMPLEX1R1 limSEQ-2K1 Partial-SumsSERIES-1K3 bp"
      using series_1_def_3 sorry
    then have A39: "limSEQ-2K1 y =COMPLEX1R1 SumSERIES-1K4 bp to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
      using A2 A24 A25 A23 holder_1_th_10 sorry
    have "SumSERIES-1K4 ap =COMPLEX1R1 limSEQ-2K1 Partial-SumsSERIES-1K3 ap"
      using series_1_def_3 sorry
    then have A40: "limSEQ-2K1 x =COMPLEX1R1 SumSERIES-1K4 ap to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
      using A2 A21 A27 A20 holder_1_th_10 sorry
    have "Partial-SumsSERIES-1K3 ab be convergentSEQ-2V5"
      using A1 A9 A31 A32 holder_1_th_10 sorry
    thus "ab be summableSERIES-1V1 & SumSERIES-1K4 ab to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 SumSERIES-1K4 ap to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) +XCMPLX-0K2 SumSERIES-1K4 bp to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)"
      using A28 A40 A26 A39 A29 A18 A37 holder_1_th_9 series_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
