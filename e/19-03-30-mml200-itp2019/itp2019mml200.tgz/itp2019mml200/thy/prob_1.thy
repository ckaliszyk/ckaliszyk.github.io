theory prob_1
  imports funct_7 card_3 seq_2 xxreal_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve Omega for "setHIDDENM2"
reserve X, Y, Z, p, x, y, z for "setHIDDENM2"
reserve D, E for "SubsetSUBSET-1M2-of Omega"
reserve f for "FunctionFUNCT-1M1"
reserve m, n for "NatNAT-1M1"
reserve r, r1 for "RealXREAL-0M1"
reserve seq for "Real-SequenceSEQ-1M1"
mtheorem prob_1_th_1:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =COMPLEX1R1 r) implies seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 r"
proof(rule ballI,rule ballI,rule impI)
  fix r assume [ty]: "r be RealXREAL-0M1"
  fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
  assume A1: " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =COMPLEX1R1 r"
  have A2: " for r1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r1 implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 r .| <XXREAL-0R3 r1)"
  proof-
    have " for r1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r1 implies ( ex tVar1 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar1 <=XXREAL-0R1 m implies  not  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 r .| <XXREAL-0R3 r1)"
    proof(rule ballI,rule impI)
      obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A3: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =COMPLEX1R1 r"
        using A1 sorry
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      assume A4: "0NUMBERSK6 <XXREAL-0R3 r1"
      show " ex tVar1 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar1 <=XXREAL-0R1 m implies  not  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 r .| <XXREAL-0R3 r1"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "n <=XXREAL-0R1 m"
        then have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =COMPLEX1R1 r"
          using A3 sorry
        thus " not  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 r .| <XXREAL-0R3 r1"
          using A4 absvalue_th_2 sorry
      qed "sorry"
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  then have "seq be convergentSEQ-2V5"
    using seq_2_def_6 sorry
  thus "seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 r"
    using A2 seq_2_def_7 sorry
qed "sorry"

mdef prob_1_def_1 ("compl-closedPROB-1V1\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "X be setHIDDENM2"
"attr compl-closedPROB-1V1\<^bsub>(X)\<^esub> for Subset-FamilySETFAM-1M1-of X means
  (\<lambda>IT.  for A be SubsetSUBSET-1M2-of X holds A inTARSKIR2 IT implies A `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 IT)"..

mtheorem prob_1_cl_1:
  mlet "X be setHIDDENM2"
"cluster boolSETFAM-1K9 X as-term-is cap-closedFINSUB-1V2"
proof
(*coherence*)
  show "boolSETFAM-1K9 X be cap-closedFINSUB-1V2"
  proof-
    have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds A inTARSKIR2 boolSETFAM-1K9 X & B inTARSKIR2 boolSETFAM-1K9 X implies A /\\XBOOLE-0K3 B inTARSKIR2 boolSETFAM-1K9 X"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix A assume [ty]: "A be setHIDDENM2"
      fix B assume [ty]: "B be setHIDDENM2"
      assume A1: "A inTARSKIR2 boolSETFAM-1K9 X"
        and "B inTARSKIR2 boolSETFAM-1K9 X"
      have "A /\\XBOOLE-0K3 B c=TARSKIR1 X"
        using A1 xboole_1_th_108 sorry
      thus "A /\\XBOOLE-0K3 B inTARSKIR2 boolSETFAM-1K9 X"
         sorry
    qed "sorry"
    thus "boolSETFAM-1K9 X be cap-closedFINSUB-1V2"
      using finsub_1_def_2 sorry
  qed
qed "sorry"

mtheorem prob_1_cl_2:
  mlet "X be setHIDDENM2"
"cluster boolSETFAM-1K9 X as-term-is compl-closedPROB-1V1\<^bsub>(X)\<^esub> for Subset-FamilySETFAM-1M1-of X"
proof
(*coherence*)
  show " for it be Subset-FamilySETFAM-1M1-of X holds it =HIDDENR1 boolSETFAM-1K9 X implies it be compl-closedPROB-1V1\<^bsub>(X)\<^esub>"
     sorry
qed "sorry"

mtheorem prob_1_cl_3:
  mlet "X be setHIDDENM2"
"cluster  non emptyXBOOLE-0V1\<bar>compl-closedPROB-1V1\<^bsub>(X)\<^esub>\<bar>cap-closedFINSUB-1V2 for Subset-FamilySETFAM-1M1-of X"
proof
(*existence*)
  show " ex it be Subset-FamilySETFAM-1M1-of X st it be  non emptyXBOOLE-0V1\<bar>compl-closedPROB-1V1\<^bsub>(X)\<^esub>\<bar>cap-closedFINSUB-1V2"
  proof-
    have " ex tVar2 be Subset-FamilySETFAM-1M1-of X st ( not tVar2 be emptyXBOOLE-0V1 & tVar2 be compl-closedPROB-1V1\<^bsub>(X)\<^esub>) & tVar2 be cap-closedFINSUB-1V2"
    proof-
      show " ex tVar2 be Subset-FamilySETFAM-1M1-of X st ( not tVar2 be emptyXBOOLE-0V1 & tVar2 be compl-closedPROB-1V1\<^bsub>(X)\<^esub>) & tVar2 be cap-closedFINSUB-1V2"
      proof(rule bexI[of _ "boolSETFAM-1K9 X"])
        show "( not boolSETFAM-1K9 X be emptyXBOOLE-0V1 & boolSETFAM-1K9 X be compl-closedPROB-1V1\<^bsub>(X)\<^esub>) & boolSETFAM-1K9 X be cap-closedFINSUB-1V2"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax PROB_1M1 :: " Set \<Rightarrow> Ty" ("Field-SubsetPROB-1M1-of  _ " [70]70)
translations "Field-SubsetPROB-1M1-of X" \<rightharpoonup> " non emptyXBOOLE-0V1\<bar>compl-closedPROB-1V1\<^bsub>(X)\<^esub>\<bar>cap-closedFINSUB-1V2\<bar>Subset-FamilySETFAM-1M1-of X"

reserve F for "Field-SubsetPROB-1M1-of X"
mtheorem prob_1_th_2:
" for X be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of X holds  for B be SubsetSUBSET-1M2-of X holds {TARSKIK2 A,B } be Subset-FamilySETFAM-1M1-of X"
proof-
  have " for X be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of X holds  for B be SubsetSUBSET-1M2-of X holds {TARSKIK2 A,B } be Subset-FamilySETFAM-1M1-of X"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of X"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of X"
    let ?C = "{TARSKIK2 A,B }"
    have "?C c=TARSKIR1 boolSETFAM-1K9 X"
    proof-
      have "{TARSKIK2 A,B } c=TARSKIR1 boolSETFAM-1K9 X"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK2 A,B } implies x inHIDDENR3 boolSETFAM-1K9 X"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 ?C"
          then have "x =HIDDENR1 A or x =HIDDENR1 B"
            using tarski_def_2 sorry
          thus "x inHIDDENR3 boolSETFAM-1K9 X"
             sorry
        qed "sorry"
        thus "{TARSKIK2 A,B } c=TARSKIR1 boolSETFAM-1K9 X"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus "{TARSKIK2 A,B } be Subset-FamilySETFAM-1M1-of X"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prob_1_th_3:
" for X be setHIDDENM2 holds  for F be Field-SubsetPROB-1M1-of X holds  for A be setHIDDENM2 holds  for B be setHIDDENM2 holds A inTARSKIR2 F & B inTARSKIR2 F implies A \\/XBOOLE-0K2 B inTARSKIR2 F"
proof-
  have " for X be setHIDDENM2 holds  for F be Field-SubsetPROB-1M1-of X holds  for A be setHIDDENM2 holds  for B be setHIDDENM2 holds A inTARSKIR2 F & B inTARSKIR2 F implies A \\/XBOOLE-0K2 B inTARSKIR2 F"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix F assume [ty]: "F be Field-SubsetPROB-1M1-of X"
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    assume A1: "A inTARSKIR2 F & B inTARSKIR2 F"
    then obtain A1 B1 where 
      [ty]:"A1 be SubsetSUBSET-1M2-of X" and A1Def:"A1 = A" and
      [ty]:"B1 be SubsetSUBSET-1M2-of X" and B1Def:"B1 = B"
       sorry
    have "A1 `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F & B1 `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F"
      using A1 prob_1_def_1 sorry
    then have "A1 `SUBSET-1K3\<^bsub>(X)\<^esub> /\\SUBSET-1K9\<^bsub>(X)\<^esub> B1 `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F"
      using finsub_1_def_2 sorry
    then have "(A1 \\/SUBSET-1K4\<^bsub>(X)\<^esub> B1)`SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F"
      using xboole_1_th_53 sorry
    then have "((A1 \\/SUBSET-1K4\<^bsub>(X)\<^esub> B1)`SUBSET-1K3\<^bsub>(X)\<^esub>)`SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F"
      using prob_1_def_1 sorry
    thus "A \\/XBOOLE-0K2 B inTARSKIR2 F"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prob_1_th_4:
" for X be setHIDDENM2 holds  for F be Field-SubsetPROB-1M1-of X holds {}XBOOLE-0K1 inTARSKIR2 F"
proof-
  have " for X be setHIDDENM2 holds  for F be Field-SubsetPROB-1M1-of X holds {}XBOOLE-0K1 inTARSKIR2 F"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix F assume [ty]: "F be Field-SubsetPROB-1M1-of X"
    obtain A where
      [ty]:"A be SubsetSUBSET-1M2-of X" and 
      A1: "A inTARSKIR2 F"
      using subset_1_th_4 sorry
    have "A missesXBOOLE-0R1 A `SUBSET-1K3\<^bsub>(X)\<^esub>"
      using xboole_1_th_79 sorry
    then have A2: "A /\\SUBSET-1K9\<^bsub>(X)\<^esub> A `SUBSET-1K3\<^bsub>(X)\<^esub> =XBOOLE-0R4 {}XBOOLE-0K1"
      using xboole_0_def_7 sorry
    have "A `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F"
      using A1 prob_1_def_1 sorry
    thus "{}XBOOLE-0K1 inTARSKIR2 F"
      using A1 A2 finsub_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prob_1_th_5:
" for X be setHIDDENM2 holds  for F be Field-SubsetPROB-1M1-of X holds X inTARSKIR2 F"
proof-
  have " for X be setHIDDENM2 holds  for F be Field-SubsetPROB-1M1-of X holds X inTARSKIR2 F"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix F assume [ty]: "F be Field-SubsetPROB-1M1-of X"
    obtain A where
      [ty]:"A be SubsetSUBSET-1M2-of X" and 
      A1: "A inTARSKIR2 F"
      using subset_1_th_4 sorry
    have A2: "A \\/SUBSET-1K4\<^bsub>(X)\<^esub> A `SUBSET-1K3\<^bsub>(X)\<^esub> =HIDDENR1 [#]SUBSET-1K2 X"
      using subset_1_th_10 sorry
    also have "... = X"
       sorry
    finally have "A \\/SUBSET-1K4\<^bsub>(X)\<^esub> A `SUBSET-1K3\<^bsub>(X)\<^esub> =HIDDENR1 X"
       sorry
    have "A `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F"
      using A1 prob_1_def_1 sorry
    thus "X inTARSKIR2 F"
      using A1 A2 prob_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prob_1_th_6:
" for X be setHIDDENM2 holds  for F be Field-SubsetPROB-1M1-of X holds  for A be SubsetSUBSET-1M2-of X holds  for B be SubsetSUBSET-1M2-of X holds A inTARSKIR2 F & B inTARSKIR2 F implies A \\SUBSET-1K7\<^bsub>(X)\<^esub> B inTARSKIR2 F"
proof-
  have " for X be setHIDDENM2 holds  for F be Field-SubsetPROB-1M1-of X holds  for A be SubsetSUBSET-1M2-of X holds  for B be SubsetSUBSET-1M2-of X holds A inTARSKIR2 F implies (B inTARSKIR2 F implies A \\SUBSET-1K7\<^bsub>(X)\<^esub> B inTARSKIR2 F)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix F assume [ty]: "F be Field-SubsetPROB-1M1-of X"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of X"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of X"
    assume A1: "A inTARSKIR2 F"
    assume "B inTARSKIR2 F"
    then have "B `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F"
      using prob_1_def_1 sorry
    then have "A /\\SUBSET-1K9\<^bsub>(X)\<^esub> B `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F"
      using A1 finsub_1_def_2 sorry
    thus "A \\SUBSET-1K7\<^bsub>(X)\<^esub> B inTARSKIR2 F"
      using subset_1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prob_1_th_7:
" for X be setHIDDENM2 holds  for F be Field-SubsetPROB-1M1-of X holds  for A be setHIDDENM2 holds  for B be setHIDDENM2 holds A inTARSKIR2 F & B inTARSKIR2 F implies (A \\SUBSET-1K6 B)\\/XBOOLE-0K2 B inTARSKIR2 F"
proof-
  have " for X be setHIDDENM2 holds  for F be Field-SubsetPROB-1M1-of X holds  for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  not ((A inTARSKIR2 F & B inTARSKIR2 F) &  not (A \\SUBSET-1K6 B)\\/XBOOLE-0K2 B inTARSKIR2 F)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix F assume [ty]: "F be Field-SubsetPROB-1M1-of X"
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    have "A \\/XBOOLE-0K2 B =XBOOLE-0R4 (A \\SUBSET-1K6 B)\\/XBOOLE-0K2 B"
      using xboole_1_th_39 sorry
    thus " not ((A inTARSKIR2 F & B inTARSKIR2 F) &  not (A \\SUBSET-1K6 B)\\/XBOOLE-0K2 B inTARSKIR2 F)"
      using prob_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prob_1_cl_4:
  mlet "X be setHIDDENM2"
"cluster {TARSKIK2 {}XBOOLE-0K1,X } as-term-is cap-closedFINSUB-1V2"
proof
(*coherence*)
  show "{TARSKIK2 {}XBOOLE-0K1,X } be cap-closedFINSUB-1V2"
  proof-
    have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  not ((A inTARSKIR2 {TARSKIK2 {}XBOOLE-0K1,X } & B inTARSKIR2 {TARSKIK2 {}XBOOLE-0K1,X }) &  not A /\\XBOOLE-0K3 B inTARSKIR2 {TARSKIK2 {}XBOOLE-0K1,X })"
    proof(rule ballI,rule ballI)
      fix A assume [ty]: "A be setHIDDENM2"
      fix B assume [ty]: "B be setHIDDENM2"
      have A1: "A =XBOOLE-0R4 {}XBOOLE-0K1 or B =XBOOLE-0R4 {}XBOOLE-0K1 implies A /\\XBOOLE-0K3 B =XBOOLE-0R4 {}XBOOLE-0K1"
         sorry
      have "A =XBOOLE-0R4 X & B =XBOOLE-0R4 X implies A /\\XBOOLE-0K3 B =XBOOLE-0R4 X"
         sorry
      thus " not ((A inTARSKIR2 {TARSKIK2 {}XBOOLE-0K1,X } & B inTARSKIR2 {TARSKIK2 {}XBOOLE-0K1,X }) &  not A /\\XBOOLE-0K3 B inTARSKIR2 {TARSKIK2 {}XBOOLE-0K1,X })"
        using A1 tarski_def_2 sorry
    qed "sorry"
    thus "{TARSKIK2 {}XBOOLE-0K1,X } be cap-closedFINSUB-1V2"
      using finsub_1_def_2 sorry
  qed
qed "sorry"

mtheorem prob_1_th_8:
" for X be setHIDDENM2 holds {TARSKIK2 {}XBOOLE-0K1,X } be Field-SubsetPROB-1M1-of X"
proof-
  have " for X be setHIDDENM2 holds {TARSKIK2 {}XBOOLE-0K1,X } be Field-SubsetPROB-1M1-of X"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have "{}XBOOLE-0K1 c=RELAT-1R2 X & X inTARSKIR2 boolSETFAM-1K9 X"
      using zfmisc_1_def_1 sorry
    then obtain EXx where 
      [ty]:"EXx be Subset-FamilySETFAM-1M1-of X" and EXxDef:"EXx = {TARSKIK2 {}XBOOLE-0K1,X }"
      using prob_1_th_2 sorry
    have " for A be SubsetSUBSET-1M2-of X holds A inTARSKIR2 EXx implies A `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 EXx"
    proof(rule ballI)
      fix A assume [ty]: "A be SubsetSUBSET-1M2-of X"
      have A1: "A =XBOOLE-0R4 {}XBOOLE-0K1 implies A `SUBSET-1K3\<^bsub>(X)\<^esub> =XBOOLE-0R4 X"
         sorry
      have "A =XBOOLE-0R4 X implies A `SUBSET-1K3\<^bsub>(X)\<^esub> =XBOOLE-0R4 {}SUBSET-1K1 X"
        using xboole_1_th_37 sorry
      thus "A inTARSKIR2 EXx implies A `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 EXx"
        using A1 tarski_def_2 sorry
    qed "sorry"
    thus "{TARSKIK2 {}XBOOLE-0K1,X } be Field-SubsetPROB-1M1-of X"
      using prob_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prob_1_th_9:
" for X be setHIDDENM2 holds boolSETFAM-1K9 X be Field-SubsetPROB-1M1-of X"
   sorry

mtheorem prob_1_th_10:
" for X be setHIDDENM2 holds  for F be Field-SubsetPROB-1M1-of X holds {TARSKIK2 {}XBOOLE-0K1,X } c=TARSKIR1 F & F c=TARSKIR1 boolSETFAM-1K9 X"
proof-
  have " for X be setHIDDENM2 holds  for F be Field-SubsetPROB-1M1-of X holds {TARSKIK2 {}XBOOLE-0K1,X } c=TARSKIR1 F & F c=TARSKIR1 boolSETFAM-1K9 X"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix F assume [ty]: "F be Field-SubsetPROB-1M1-of X"
    have "{}XBOOLE-0K1 inTARSKIR2 F & X inTARSKIR2 F"
      using prob_1_th_4 prob_1_th_5 sorry
    then have " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK2 {}XBOOLE-0K1,X } implies x inHIDDENR3 F"
      using tarski_def_2 sorry
    thus "{TARSKIK2 {}XBOOLE-0K1,X } c=TARSKIR1 F & F c=TARSKIR1 boolSETFAM-1K9 X"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) PROB_1M2("SetSequencePROB-1M2-of  _ " [70]70) where
  "SetSequencePROB-1M2-of X \<equiv> sequenceNAT-1M2-of boolSETFAM-1K9 X"

reserve ASeq, BSeq for "SetSequencePROB-1M2-of Omega"
reserve A1 for "SetSequencePROB-1M2-of X"
mtheorem prob_1_th_11:
" for X be setHIDDENM2 holds  for A1 be SetSequencePROB-1M2-of X holds unionTARSKIK3 (rngFUNCT-1K2 A1) be SubsetSUBSET-1M2-of X"
proof-
  have " for X be setHIDDENM2 holds  for A1 be SetSequencePROB-1M2-of X holds unionTARSKIK3 (rngFUNCT-1K2 A1) be SubsetSUBSET-1M2-of X"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix A1 assume [ty]: "A1 be SetSequencePROB-1M2-of X"
    have " for Y be setHIDDENM2 holds Y inTARSKIR2 rngFUNCT-1K2 A1 implies Y c=TARSKIR1 X"
    proof(rule ballI,rule impI)
      fix Y assume [ty]: "Y be setHIDDENM2"
      assume "Y inTARSKIR2 rngFUNCT-1K2 A1"
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A1: "y inHIDDENR3 domRELAT-1K1 A1"and A2: "Y =XBOOLE-0R4 A1 .FUNCT-1K1 y"
        using funct_1_def_3 sorry
      have 
        [ty]:"y be ElementSUBSET-1M1-of NATNUMBERSK1"
        using A1 funct_2_def_1 sorry
      have "Y =XBOOLE-0R4 A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> y"
        using A2 sorry
      thus "Y c=TARSKIR1 X"
         sorry
    qed "sorry"
    thus "unionTARSKIK3 (rngFUNCT-1K2 A1) be SubsetSUBSET-1M2-of X"
      using zfmisc_1_th_76 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax PROB_1K1 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("UnionPROB-1K1\<^bsub>'( _ ')\<^esub>  _ " [0,164]164)
translations "UnionPROB-1K1\<^bsub>(X)\<^esub> A1" \<rightharpoonup> "UnionCARD-3K3 A1"

mtheorem prob_1_add_1:
  mlet "X be setHIDDENM2", "A1 be SetSequencePROB-1M2-of X"
"cluster UnionCARD-3K3 A1 as-term-is SubsetSUBSET-1M2-of X"
proof
(*coherence*)
  show "UnionCARD-3K3 A1 be SubsetSUBSET-1M2-of X"
    using prob_1_th_11 sorry
qed "sorry"

mtheorem prob_1_th_12:
" for X be setHIDDENM2 holds  for x be setHIDDENM2 holds  for A1 be SetSequencePROB-1M2-of X holds x inTARSKIR2 UnionPROB-1K1\<^bsub>(X)\<^esub> A1 iff ( ex n be NatNAT-1M1 st x inTARSKIR2 A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)"
proof-
  have " for X be setHIDDENM2 holds  for x be setHIDDENM2 holds  for A1 be SetSequencePROB-1M2-of X holds  not (x inTARSKIR2 UnionPROB-1K1\<^bsub>(X)\<^esub> A1 & ( for n be NatNAT-1M1 holds  not x inTARSKIR2 A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)) &  not ( not ( for n be NatNAT-1M1 holds  not x inTARSKIR2 A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n) &  not x inTARSKIR2 UnionPROB-1K1\<^bsub>(X)\<^esub> A1)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be setHIDDENM2"
    fix A1 assume [ty]: "A1 be SetSequencePROB-1M2-of X"
    let ?DX = "unionTARSKIK3 (rngFUNCT-1K2 A1)"
    have " for x be setHIDDENM2 holds x inTARSKIR2 ?DX iff ( ex n be NatNAT-1M1 st x inTARSKIR2 A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)"
    proof-
      have " for x be setHIDDENM2 holds (x inTARSKIR2 unionTARSKIK3 (rngFUNCT-1K2 A1) implies ( ex n be NatNAT-1M1 st x inTARSKIR2 A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)) & (( ex n be NatNAT-1M1 st x inTARSKIR2 A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n) implies x inTARSKIR2 unionTARSKIK3 (rngFUNCT-1K2 A1))"
      proof(rule ballI,rule conjMI)
        fix x assume [ty]: "x be setHIDDENM2"
        show "x inTARSKIR2 unionTARSKIK3 (rngFUNCT-1K2 A1) implies ( ex n be NatNAT-1M1 st x inTARSKIR2 A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)"
        proof-
          have "x inTARSKIR2 unionTARSKIK3 (rngFUNCT-1K2 A1) implies  not ( for n be NatNAT-1M1 holds  not x inTARSKIR2 A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)"
          proof(rule impI)
            assume "x inTARSKIR2 ?DX"
            then obtain Y where
              [ty]:"Y be setHIDDENM2" and 
              A1: "x inTARSKIR2 Y"and A2: "Y inTARSKIR2 rngFUNCT-1K2 A1"
              using tarski_def_4 sorry
            obtain p where
              [ty]:"p be objectHIDDENM1" and 
              A3: "p inHIDDENR3 domRELAT-1K1 A1"and A4: "Y =XBOOLE-0R4 A1 .FUNCT-1K1 p"
              using A2 funct_1_def_3 sorry
            have "p inHIDDENR3 NATNUMBERSK1"
              using A3 funct_2_def_1 sorry
            thus " not ( for n be NatNAT-1M1 holds  not x inTARSKIR2 A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)"
              using A1 A4 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        show "( ex n be NatNAT-1M1 st x inTARSKIR2 A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n) implies x inTARSKIR2 unionTARSKIK3 (rngFUNCT-1K2 A1)"
        proof(rule impI)
          assume Given: " ex n be NatNAT-1M1 st x inTARSKIR2 A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n"
          then obtain n where
            [ty]:"n be NatNAT-1M1" and 
            A5: "x inTARSKIR2 A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n"
             sorry
          have "n inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          then have "n inTARSKIR2 domRELAT-1K1 A1"
            using funct_2_def_1 sorry
          then have "A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n inTARSKIR2 rngFUNCT-1K2 A1"
            using funct_1_def_3 sorry
          thus "x inTARSKIR2 unionTARSKIK3 (rngFUNCT-1K2 A1)"
            using A5 tarski_def_4 sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus " not (x inTARSKIR2 UnionPROB-1K1\<^bsub>(X)\<^esub> A1 & ( for n be NatNAT-1M1 holds  not x inTARSKIR2 A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)) &  not ( not ( for n be NatNAT-1M1 holds  not x inTARSKIR2 A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n) &  not x inTARSKIR2 UnionPROB-1K1\<^bsub>(X)\<^esub> A1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef prob_1_def_2 ("ComplementPROB-1K2\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "X be setHIDDENM2", "A1 be SetSequencePROB-1M2-of X"
"func ComplementPROB-1K2\<^bsub>(X)\<^esub> A1 \<rightarrow> SetSequencePROB-1M2-of X means
  \<lambda>it.  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n =XBOOLE-0R4 (A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)`SUBSET-1K3\<^bsub>(X)\<^esub>"
proof-
  (*existence*)
    show " ex it be SetSequencePROB-1M2-of X st  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n =XBOOLE-0R4 (A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)`SUBSET-1K3\<^bsub>(X)\<^esub>"
    proof-
      have " ex tVar3 be SetSequencePROB-1M2-of X st  for n be NatNAT-1M1 holds tVar3 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n =XBOOLE-0R4 (A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)`SUBSET-1K3\<^bsub>(X)\<^esub>"
      proof-
        let ?F = "\<lambda>Lamb1. (A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> Lamb1)`SUBSET-1K3\<^bsub>(X)\<^esub>"
        obtain f where
          [ty]:"f be sequenceNAT-1M2-of boolSETFAM-1K9 X" and 
          A1: " for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds f .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> x =XBOOLE-0R4 ?F(x)"
          using funct_2_sch_4 sorry
        have A2: " for x be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> x =XBOOLE-0R4 (A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> x)`SUBSET-1K3\<^bsub>(X)\<^esub>"
        proof(rule ballI)
          fix x assume [ty]: "x be NatNAT-1M1"
          have 
            [ty]:"x be ElementSUBSET-1M1-of NATNUMBERSK1"
            using ordinal1_def_12 sorry
          have "f .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> x =XBOOLE-0R4 ?F(x)"
            using A1 sorry
          thus "f .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> x =XBOOLE-0R4 (A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> x)`SUBSET-1K3\<^bsub>(X)\<^esub>"
             sorry
        qed "sorry"
        show " ex tVar3 be SetSequencePROB-1M2-of X st  for n be NatNAT-1M1 holds tVar3 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n =XBOOLE-0R4 (A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)`SUBSET-1K3\<^bsub>(X)\<^esub>"
        proof(rule bexI[of _ "f"])
          show " for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n =XBOOLE-0R4 (A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)`SUBSET-1K3\<^bsub>(X)\<^esub>"
            using A2 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be SetSequencePROB-1M2-of X holds  for it2 be SetSequencePROB-1M2-of X holds ( for n be NatNAT-1M1 holds it1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n =XBOOLE-0R4 (A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)`SUBSET-1K3\<^bsub>(X)\<^esub>) & ( for n be NatNAT-1M1 holds it2 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n =XBOOLE-0R4 (A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)`SUBSET-1K3\<^bsub>(X)\<^esub>) implies it1 =HIDDENR1 it2"
    proof-
      have " for BSeq be SetSequencePROB-1M2-of X holds  for CSeq be SetSequencePROB-1M2-of X holds ( for n be NatNAT-1M1 holds BSeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n =XBOOLE-0R4 (A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)`SUBSET-1K3\<^bsub>(X)\<^esub>) & ( for m be NatNAT-1M1 holds CSeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> m =XBOOLE-0R4 (A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> m)`SUBSET-1K3\<^bsub>(X)\<^esub>) implies BSeq =HIDDENR1 CSeq"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix BSeq assume [ty]: "BSeq be SetSequencePROB-1M2-of X"
        fix CSeq assume [ty]: "CSeq be SetSequencePROB-1M2-of X"
        assume A3: " for n be NatNAT-1M1 holds BSeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n =XBOOLE-0R4 (A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)`SUBSET-1K3\<^bsub>(X)\<^esub>"
          and A4: " for m be NatNAT-1M1 holds CSeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> m =XBOOLE-0R4 (A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> m)`SUBSET-1K3\<^bsub>(X)\<^esub>"
        have A5: " for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies BSeq .FUNCT-1K1 x =XBOOLE-0R4 CSeq .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 NATNUMBERSK1"
          then have 
            [ty]:"x be ElementSUBSET-1M1-of NATNUMBERSK1"
             sorry
          have "BSeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> x =HIDDENR1 (A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> x)`SUBSET-1K3\<^bsub>(X)\<^esub>"
            using A3 sorry
          also have "... = CSeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> x"
            using A4 sorry
          finally have "BSeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> x =HIDDENR1 CSeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> x"
             sorry
          thus "BSeq .FUNCT-1K1 x =XBOOLE-0R4 CSeq .FUNCT-1K1 x"
             sorry
        qed "sorry"
        show "BSeq =HIDDENR1 CSeq"
          using A5 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem PROB_1K2_involutiveness:
  mlet "X be setHIDDENM2"
" for A1 be SetSequencePROB-1M2-of X holds ComplementPROB-1K2\<^bsub>(X)\<^esub> (ComplementPROB-1K2\<^bsub>(X)\<^esub> A1) =HIDDENR1 A1"
proof-
  have " for it be SetSequencePROB-1M2-of X holds  for A1 be SetSequencePROB-1M2-of X holds it =HIDDENR1 ComplementPROB-1K2\<^bsub>(X)\<^esub> A1 implies A1 =HIDDENR1 ComplementPROB-1K2\<^bsub>(X)\<^esub> it"
  proof-
    have " for it be SetSequencePROB-1M2-of X holds  for A1 be SetSequencePROB-1M2-of X holds ( for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n =XBOOLE-0R4 (A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)`SUBSET-1K3\<^bsub>(X)\<^esub>) implies ( for n be NatNAT-1M1 holds A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n =XBOOLE-0R4 (it .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)`SUBSET-1K3\<^bsub>(X)\<^esub>)"
    proof-
      have " for IT be SetSequencePROB-1M2-of X holds  for A1 be SetSequencePROB-1M2-of X holds ( for n be NatNAT-1M1 holds IT .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n =XBOOLE-0R4 (A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)`SUBSET-1K3\<^bsub>(X)\<^esub>) implies ( for n be NatNAT-1M1 holds A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n =HIDDENR1 (IT .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)`SUBSET-1K3\<^bsub>(X)\<^esub>)"
      proof(rule ballI,rule ballI,rule impI,rule ballI)
        fix IT assume [ty]: "IT be SetSequencePROB-1M2-of X"
        fix A1 assume [ty]: "A1 be SetSequencePROB-1M2-of X"
        assume A6: " for n be NatNAT-1M1 holds IT .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n =XBOOLE-0R4 (A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)`SUBSET-1K3\<^bsub>(X)\<^esub>"
        fix n assume [ty]: "n be NatNAT-1M1"
        have "A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n =HIDDENR1 ((A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)`SUBSET-1K3\<^bsub>(X)\<^esub>)`SUBSET-1K3\<^bsub>(X)\<^esub>"
           sorry
        also have "... = (IT .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)`SUBSET-1K3\<^bsub>(X)\<^esub>"
          using A6 sorry
        finally show "A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n =HIDDENR1 (IT .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)`SUBSET-1K3\<^bsub>(X)\<^esub>"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus " ?thesis "
      using prob_1_def_2 sorry
  qed
  thus " ?thesis "
     sorry
qed

mdef prob_1_def_3 ("IntersectionPROB-1K3\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "X be setHIDDENM2", "A1 be SetSequencePROB-1M2-of X"
"func IntersectionPROB-1K3\<^bsub>(X)\<^esub> A1 \<rightarrow> SubsetSUBSET-1M2-of X equals
  (UnionPROB-1K1\<^bsub>(X)\<^esub> (ComplementPROB-1K2\<^bsub>(X)\<^esub> A1))`SUBSET-1K3\<^bsub>(X)\<^esub>"
proof-
  (*coherence*)
    show "(UnionPROB-1K1\<^bsub>(X)\<^esub> (ComplementPROB-1K2\<^bsub>(X)\<^esub> A1))`SUBSET-1K3\<^bsub>(X)\<^esub> be SubsetSUBSET-1M2-of X"
       sorry
qed "sorry"

mtheorem prob_1_th_13:
" for X be setHIDDENM2 holds  for A1 be SetSequencePROB-1M2-of X holds  for x be objectHIDDENM1 holds x inHIDDENR3 IntersectionPROB-1K3\<^bsub>(X)\<^esub> A1 iff ( for n be NatNAT-1M1 holds x inHIDDENR3 A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)"
proof-
  have " for X be setHIDDENM2 holds  for A1 be SetSequencePROB-1M2-of X holds  for x be objectHIDDENM1 holds  not (x inHIDDENR3 IntersectionPROB-1K3\<^bsub>(X)\<^esub> A1 &  not ( for n be NatNAT-1M1 holds x inHIDDENR3 A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)) &  not (( for n be NatNAT-1M1 holds x inHIDDENR3 A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n) &  not x inHIDDENR3 IntersectionPROB-1K3\<^bsub>(X)\<^esub> A1)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix A1 assume [ty]: "A1 be SetSequencePROB-1M2-of X"
    fix x assume [ty]: "x be objectHIDDENM1"
    have A1: " for n be NatNAT-1M1 holds X \\SUBSET-1K6 (ComplementPROB-1K2\<^bsub>(X)\<^esub> A1).NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n =XBOOLE-0R4 A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "X \\SUBSET-1K6 (ComplementPROB-1K2\<^bsub>(X)\<^esub> A1).NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n =HIDDENR1 ((A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)`SUBSET-1K3\<^bsub>(X)\<^esub>)`SUBSET-1K3\<^bsub>(X)\<^esub>"
        using prob_1_def_2 sorry
      also have "... = A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n"
         sorry
      finally have "X \\SUBSET-1K6 (ComplementPROB-1K2\<^bsub>(X)\<^esub> A1).NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n =HIDDENR1 A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n"
         sorry
      thus "X \\SUBSET-1K6 (ComplementPROB-1K2\<^bsub>(X)\<^esub> A1).NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n =XBOOLE-0R4 A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n"
         sorry
    qed "sorry"
    have A2: "( for n be NatNAT-1M1 holds x inHIDDENR3 X &  not x inHIDDENR3 (ComplementPROB-1K2\<^bsub>(X)\<^esub> A1).NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n) iff ( for n be NatNAT-1M1 holds x inHIDDENR3 A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)"
    proof-
      have "(( for n be NatNAT-1M1 holds x inHIDDENR3 X &  not x inHIDDENR3 (ComplementPROB-1K2\<^bsub>(X)\<^esub> A1).NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n) implies ( for n be NatNAT-1M1 holds x inHIDDENR3 A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)) & (( for n be NatNAT-1M1 holds x inHIDDENR3 A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n) implies ( for n be NatNAT-1M1 holds x inHIDDENR3 X &  not x inHIDDENR3 (ComplementPROB-1K2\<^bsub>(X)\<^esub> A1).NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n))"
      proof(rule conjMI,rule impI,rule ballI)
        show "( for n be NatNAT-1M1 holds x inHIDDENR3 X &  not x inHIDDENR3 (ComplementPROB-1K2\<^bsub>(X)\<^esub> A1).NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n) implies ( for n be NatNAT-1M1 holds x inHIDDENR3 A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)"
        proof(rule impI,rule ballI)
          assume A3: " for n be NatNAT-1M1 holds x inHIDDENR3 X &  not x inHIDDENR3 (ComplementPROB-1K2\<^bsub>(X)\<^esub> A1).NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n"
          fix n assume [ty]: "n be NatNAT-1M1"
          have " not x inHIDDENR3 (ComplementPROB-1K2\<^bsub>(X)\<^esub> A1).NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n"
            using A3 sorry
          then have "x inHIDDENR3 X \\SUBSET-1K6 (ComplementPROB-1K2\<^bsub>(X)\<^esub> A1).NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n"
            using A3 xboole_0_def_5 sorry
          thus "x inHIDDENR3 A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n"
            using A1 sorry
        qed "sorry"
        assume A4: " for n be NatNAT-1M1 holds x inHIDDENR3 A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n"
        fix n assume [ty]: "n be NatNAT-1M1"
        have "x inHIDDENR3 A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n"
          using A4 sorry
        then have "x inHIDDENR3 X \\SUBSET-1K6 (ComplementPROB-1K2\<^bsub>(X)\<^esub> A1).NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n"
          using A1 sorry
        thus "x inHIDDENR3 X &  not x inHIDDENR3 (ComplementPROB-1K2\<^bsub>(X)\<^esub> A1).NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n"
          using xboole_0_def_5 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "x inHIDDENR3 X &  not x inHIDDENR3 UnionPROB-1K1\<^bsub>(X)\<^esub> (ComplementPROB-1K2\<^bsub>(X)\<^esub> A1) iff x inHIDDENR3 X & ( for n be NatNAT-1M1 holds  not x inHIDDENR3 (ComplementPROB-1K2\<^bsub>(X)\<^esub> A1).NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)"
      using prob_1_th_12 sorry
    thus " not (x inHIDDENR3 IntersectionPROB-1K3\<^bsub>(X)\<^esub> A1 &  not ( for n be NatNAT-1M1 holds x inHIDDENR3 A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)) &  not (( for n be NatNAT-1M1 holds x inHIDDENR3 A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n) &  not x inHIDDENR3 IntersectionPROB-1K3\<^bsub>(X)\<^esub> A1)"
      using A2 xboole_0_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma prob_1_lm_1:
" for X be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of X holds  for B be SubsetSUBSET-1M2-of X holds ComplementPROB-1K2\<^bsub>(X)\<^esub> (A followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,boolZFMISC-1K1 X)\<^esub> A `SUBSET-1K3\<^bsub>(X)\<^esub> followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B `SUBSET-1K3\<^bsub>(X)\<^esub>"
proof-
  have " for X be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of X holds  for B be SubsetSUBSET-1M2-of X holds ComplementPROB-1K2\<^bsub>(X)\<^esub> (A followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,boolZFMISC-1K1 X)\<^esub> A `SUBSET-1K3\<^bsub>(X)\<^esub> followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B `SUBSET-1K3\<^bsub>(X)\<^esub>"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of X"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of X"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (ComplementPROB-1K2\<^bsub>(X)\<^esub> (A followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B)).NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n =HIDDENR1 (A `SUBSET-1K3\<^bsub>(X)\<^esub> followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B `SUBSET-1K3\<^bsub>(X)\<^esub>).NAT-1K8\<^bsub>(boolZFMISC-1K1 X)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      show "(ComplementPROB-1K2\<^bsub>(X)\<^esub> (A followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B)).NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n =HIDDENR1 (A `SUBSET-1K3\<^bsub>(X)\<^esub> followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B `SUBSET-1K3\<^bsub>(X)\<^esub>).NAT-1K8\<^bsub>(boolZFMISC-1K1 X)\<^esub> n"
      proof-
        have cases: "n =COMPLEX1R1 0NUMBERSK6 or n >XXREAL-0R4 0NUMBERSK6"
          using nat_1_th_3 sorry
        have case1: "n =COMPLEX1R1 0NUMBERSK6 implies (ComplementPROB-1K2\<^bsub>(X)\<^esub> (A followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B)).NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n =HIDDENR1 (A `SUBSET-1K3\<^bsub>(X)\<^esub> followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B `SUBSET-1K3\<^bsub>(X)\<^esub>).NAT-1K8\<^bsub>(boolZFMISC-1K1 X)\<^esub> n"
        proof(rule impI)
          assume A1: "n =COMPLEX1R1 0NUMBERSK6"
          have "(ComplementPROB-1K2\<^bsub>(X)\<^esub> (A followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B)).NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n =HIDDENR1 ((A followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B).NAT-1K8\<^bsub>(boolZFMISC-1K1 X)\<^esub> n)`SUBSET-1K3\<^bsub>(X)\<^esub>"
            using prob_1_def_2 sorry
          also have "... = A `SUBSET-1K3\<^bsub>(X)\<^esub>"
            using A1 funct_7_th_119 sorry
          also have "... = (A `SUBSET-1K3\<^bsub>(X)\<^esub> followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B `SUBSET-1K3\<^bsub>(X)\<^esub>).NAT-1K8\<^bsub>(boolZFMISC-1K1 X)\<^esub> n"
            using A1 funct_7_th_119 sorry
          finally show "(ComplementPROB-1K2\<^bsub>(X)\<^esub> (A followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B)).NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n =HIDDENR1 (A `SUBSET-1K3\<^bsub>(X)\<^esub> followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B `SUBSET-1K3\<^bsub>(X)\<^esub>).NAT-1K8\<^bsub>(boolZFMISC-1K1 X)\<^esub> n"
             sorry
        qed
        have case2: "n >XXREAL-0R4 0NUMBERSK6 implies (ComplementPROB-1K2\<^bsub>(X)\<^esub> (A followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B)).NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n =HIDDENR1 (A `SUBSET-1K3\<^bsub>(X)\<^esub> followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B `SUBSET-1K3\<^bsub>(X)\<^esub>).NAT-1K8\<^bsub>(boolZFMISC-1K1 X)\<^esub> n"
        proof(rule impI)
          assume A2: "n >XXREAL-0R4 0NUMBERSK6"
          have "(ComplementPROB-1K2\<^bsub>(X)\<^esub> (A followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B)).NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n =HIDDENR1 ((A followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B).NAT-1K8\<^bsub>(boolZFMISC-1K1 X)\<^esub> n)`SUBSET-1K3\<^bsub>(X)\<^esub>"
            using prob_1_def_2 sorry
          also have "... = B `SUBSET-1K3\<^bsub>(X)\<^esub>"
            using A2 funct_7_th_120 sorry
          also have "... = (A `SUBSET-1K3\<^bsub>(X)\<^esub> followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B `SUBSET-1K3\<^bsub>(X)\<^esub>).NAT-1K8\<^bsub>(boolZFMISC-1K1 X)\<^esub> n"
            using A2 funct_7_th_120 sorry
          finally show "(ComplementPROB-1K2\<^bsub>(X)\<^esub> (A followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B)).NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n =HIDDENR1 (A `SUBSET-1K3\<^bsub>(X)\<^esub> followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B `SUBSET-1K3\<^bsub>(X)\<^esub>).NAT-1K8\<^bsub>(boolZFMISC-1K1 X)\<^esub> n"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus "ComplementPROB-1K2\<^bsub>(X)\<^esub> (A followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,boolZFMISC-1K1 X)\<^esub> A `SUBSET-1K3\<^bsub>(X)\<^esub> followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B `SUBSET-1K3\<^bsub>(X)\<^esub>"
      using funct_2_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prob_1_th_14:
" for X be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of X holds  for B be SubsetSUBSET-1M2-of X holds IntersectionPROB-1K3\<^bsub>(X)\<^esub> (A followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B) =XBOOLE-0R4 A /\\SUBSET-1K9\<^bsub>(X)\<^esub> B"
proof-
  have " for X be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of X holds  for B be SubsetSUBSET-1M2-of X holds IntersectionPROB-1K3\<^bsub>(X)\<^esub> (A followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B) =XBOOLE-0R4 A /\\SUBSET-1K9\<^bsub>(X)\<^esub> B"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of X"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of X"
    let ?A1 = "A followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B"
    have "ComplementPROB-1K2\<^bsub>(X)\<^esub> ?A1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,boolZFMISC-1K1 X)\<^esub> A `SUBSET-1K3\<^bsub>(X)\<^esub> followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B `SUBSET-1K3\<^bsub>(X)\<^esub>"
      using prob_1_lm_1 sorry
    then have "rngFUNCT-1K2 (ComplementPROB-1K2\<^bsub>(X)\<^esub> ?A1) =XBOOLE-0R4 {TARSKIK2 A `SUBSET-1K3\<^bsub>(X)\<^esub>,B `SUBSET-1K3\<^bsub>(X)\<^esub> }"
      using funct_7_th_126 sorry
    then have "UnionPROB-1K1\<^bsub>(X)\<^esub> (ComplementPROB-1K2\<^bsub>(X)\<^esub> ?A1) =XBOOLE-0R4 A `SUBSET-1K3\<^bsub>(X)\<^esub> \\/SUBSET-1K4\<^bsub>(X)\<^esub> B `SUBSET-1K3\<^bsub>(X)\<^esub>"
      using zfmisc_1_th_75 sorry
    then have "(UnionPROB-1K1\<^bsub>(X)\<^esub> (ComplementPROB-1K2\<^bsub>(X)\<^esub> ?A1))`SUBSET-1K3\<^bsub>(X)\<^esub> =XBOOLE-0R4 (A `SUBSET-1K3\<^bsub>(X)\<^esub>)`SUBSET-1K3\<^bsub>(X)\<^esub> /\\SUBSET-1K9\<^bsub>(X)\<^esub> (B `SUBSET-1K3\<^bsub>(X)\<^esub>)`SUBSET-1K3\<^bsub>(X)\<^esub>"
      using xboole_1_th_53 sorry
    thus "IntersectionPROB-1K3\<^bsub>(X)\<^esub> (A followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B) =XBOOLE-0R4 A /\\SUBSET-1K9\<^bsub>(X)\<^esub> B"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef prob_1_def_4 ("non-ascendingPROB-1V2" 70 ) where
"attr non-ascendingPROB-1V2 for FunctionFUNCT-1M1 means
  (\<lambda>f.  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies f .FUNCT-1K1 m c=TARSKIR1 f .FUNCT-1K1 n)"..

mdef prob_1_def_5 ("non-descendingPROB-1V3" 70 ) where
"attr non-descendingPROB-1V3 for FunctionFUNCT-1M1 means
  (\<lambda>f.  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies f .FUNCT-1K1 n c=TARSKIR1 f .FUNCT-1K1 m)"..

mdef prob_1_def_6 ("sigma-multiplicativePROB-1V4\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "X be setHIDDENM2"
"attr sigma-multiplicativePROB-1V4\<^bsub>(X)\<^esub> for Subset-FamilySETFAM-1M1-of X means
  (\<lambda>F.  for A1 be SetSequencePROB-1M2-of X holds rngFUNCT-1K2 A1 c=TARSKIR1 F implies IntersectionPROB-1K3\<^bsub>(X)\<^esub> A1 inTARSKIR2 F)"..

mtheorem prob_1_cl_5:
  mlet "X be setHIDDENM2"
"cluster boolSETFAM-1K9 X as-term-is sigma-multiplicativePROB-1V4\<^bsub>(X)\<^esub> for Subset-FamilySETFAM-1M1-of X"
proof
(*coherence*)
  show " for it be Subset-FamilySETFAM-1M1-of X holds it =HIDDENR1 boolSETFAM-1K9 X implies it be sigma-multiplicativePROB-1V4\<^bsub>(X)\<^esub>"
     sorry
qed "sorry"

mtheorem prob_1_cl_6:
  mlet "X be setHIDDENM2"
"cluster compl-closedPROB-1V1\<^bsub>(X)\<^esub>\<bar>sigma-multiplicativePROB-1V4\<^bsub>(X)\<^esub>\<bar> non emptyXBOOLE-0V1 for Subset-FamilySETFAM-1M1-of X"
proof
(*existence*)
  show " ex it be Subset-FamilySETFAM-1M1-of X st it be compl-closedPROB-1V1\<^bsub>(X)\<^esub>\<bar>sigma-multiplicativePROB-1V4\<^bsub>(X)\<^esub>\<bar> non emptyXBOOLE-0V1"
  proof-
    have " ex tVar4 be Subset-FamilySETFAM-1M1-of X st (tVar4 be compl-closedPROB-1V1\<^bsub>(X)\<^esub> & tVar4 be sigma-multiplicativePROB-1V4\<^bsub>(X)\<^esub>) &  not tVar4 be emptyXBOOLE-0V1"
    proof-
      show " ex tVar4 be Subset-FamilySETFAM-1M1-of X st (tVar4 be compl-closedPROB-1V1\<^bsub>(X)\<^esub> & tVar4 be sigma-multiplicativePROB-1V4\<^bsub>(X)\<^esub>) &  not tVar4 be emptyXBOOLE-0V1"
      proof(rule bexI[of _ "boolSETFAM-1K9 X"])
        show "(boolSETFAM-1K9 X be compl-closedPROB-1V1\<^bsub>(X)\<^esub> & boolSETFAM-1K9 X be sigma-multiplicativePROB-1V4\<^bsub>(X)\<^esub>) &  not boolSETFAM-1K9 X be emptyXBOOLE-0V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax PROB_1M3 :: " Set \<Rightarrow> Ty" ("SigmaFieldPROB-1M3-of  _ " [70]70)
translations "SigmaFieldPROB-1M3-of X" \<rightharpoonup> "compl-closedPROB-1V1\<^bsub>(X)\<^esub>\<bar>sigma-multiplicativePROB-1V4\<^bsub>(X)\<^esub>\<bar> non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X"

mtheorem prob_1_th_15:
" for X be setHIDDENM2 holds  for S be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds S be SigmaFieldPROB-1M3-of X iff (S c=TARSKIR1 boolSETFAM-1K9 X & ( for A1 be SetSequencePROB-1M2-of X holds rngFUNCT-1K2 A1 c=TARSKIR1 S implies IntersectionPROB-1K3\<^bsub>(X)\<^esub> A1 inTARSKIR2 S)) & ( for A be SubsetSUBSET-1M2-of X holds A inTARSKIR2 S implies A `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 S)"
  using prob_1_def_1 prob_1_def_6 sorry

mtheorem prob_1_th_16:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds Y be SigmaFieldPROB-1M3-of X implies Y be Field-SubsetPROB-1M1-of X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds Y be SigmaFieldPROB-1M3-of X implies Y be Field-SubsetPROB-1M1-of X"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "Y be SigmaFieldPROB-1M3-of X"
    have "Y be cap-closedFINSUB-1V2"
    proof-
      have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds A inTARSKIR2 Y & B inTARSKIR2 Y implies A /\\XBOOLE-0K3 B inTARSKIR2 Y"
      proof(rule ballI,rule ballI,rule impI)
        fix A assume [ty]: "A be setHIDDENM2"
        fix B assume [ty]: "B be setHIDDENM2"
        assume A2: "A inTARSKIR2 Y & B inTARSKIR2 Y"
        then obtain A9 B9 where 
          [ty]:"A9 be SubsetSUBSET-1M2-of X" and A9Def:"A9 = A" and
          [ty]:"B9 be SubsetSUBSET-1M2-of X" and B9Def:"B9 = B"
          using A1 sorry
        let ?A1 = "A9 followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B9"
        have "rngFUNCT-1K2 ?A1 =XBOOLE-0R4 {TARSKIK2 A9,B9 }"
          using funct_7_th_126 sorry
        then have A3: "rngFUNCT-1K2 ?A1 c=TARSKIR1 Y"
          using A2 zfmisc_1_th_32 sorry
        have "IntersectionPROB-1K3\<^bsub>(X)\<^esub> ?A1 =XBOOLE-0R4 A /\\XBOOLE-0K3 B"
          using prob_1_th_14 sorry
        thus "A /\\XBOOLE-0K3 B inTARSKIR2 Y"
          using A1 A3 prob_1_def_6 sorry
      qed "sorry"
      thus "Y be cap-closedFINSUB-1V2"
        using finsub_1_def_2 sorry
    qed
    thus "Y be Field-SubsetPROB-1M1-of X"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prob_1_cl_7:
  mlet "X be setHIDDENM2"
"cluster note-that cap-closedFINSUB-1V2\<bar>compl-closedPROB-1V1\<^bsub>(X)\<^esub> for SigmaFieldPROB-1M3-of X"
proof
(*coherence*)
  show " for it be SigmaFieldPROB-1M3-of X holds it be cap-closedFINSUB-1V2\<bar>compl-closedPROB-1V1\<^bsub>(X)\<^esub>"
    using prob_1_th_16 sorry
qed "sorry"

reserve Sigma for "SigmaFieldPROB-1M3-of Omega"
reserve Si for "SigmaFieldPROB-1M3-of X"
mtheorem prob_1_cl_8:
  mlet "X be setHIDDENM2", "F be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X"
"cluster F -valuedRELAT-1V5 for SetSequencePROB-1M2-of X"
proof
(*existence*)
  show " ex it be SetSequencePROB-1M2-of X st it be F -valuedRELAT-1V5"
  proof-
    have " ex tVar5 be SetSequencePROB-1M2-of X st tVar5 be F -valuedRELAT-1V5"
    proof-
      let ?A1 = "NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(F)\<^esub> (the ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 X)\<^esub>-of F)"
      obtain A1 where 
        [ty]:"A1 be SetSequencePROB-1M2-of X" and A1Def:"A1 = ?A1"
        using funcop_1_th_45 sorry
      show " ex tVar5 be SetSequencePROB-1M2-of X st tVar5 be F -valuedRELAT-1V5"
      proof(rule bexI[of _ "A1"])
        show "A1 be F -valuedRELAT-1V5"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

abbreviation(input) PROB_1M4("SetSequencePROB-1M4\<^bsub>'( _ ')\<^esub>-of  _ " [0,70]70) where
  "SetSequencePROB-1M4\<^bsub>(X)\<^esub>-of F \<equiv> F -valuedRELAT-1V5\<bar>SetSequencePROB-1M2-of X"

mtheorem prob_1_th_17:
" for X be setHIDDENM2 holds  for Si be SigmaFieldPROB-1M3-of X holds  for ASeq be SetSequencePROB-1M4\<^bsub>(X)\<^esub>-of Si holds UnionPROB-1K1\<^bsub>(X)\<^esub> ASeq inTARSKIR2 Si"
proof-
  have " for X be setHIDDENM2 holds  for Si be SigmaFieldPROB-1M3-of X holds  for ASeq be SetSequencePROB-1M4\<^bsub>(X)\<^esub>-of Si holds UnionPROB-1K1\<^bsub>(X)\<^esub> ASeq inTARSKIR2 Si"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Si assume [ty]: "Si be SigmaFieldPROB-1M3-of X"
    fix ASeq assume [ty]: "ASeq be SetSequencePROB-1M4\<^bsub>(X)\<^esub>-of Si"
    have A1: " for A1 be SetSequencePROB-1M2-of X holds rngFUNCT-1K2 A1 c=TARSKIR1 Si implies ( for n be NatNAT-1M1 holds (ComplementPROB-1K2\<^bsub>(X)\<^esub> A1).NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n inTARSKIR2 Si)"
    proof-
      have " for A1 be SetSequencePROB-1M2-of X holds rngFUNCT-1K2 A1 c=TARSKIR1 Si implies ( for n be NatNAT-1M1 holds (ComplementPROB-1K2\<^bsub>(X)\<^esub> A1).NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n inTARSKIR2 Si)"
      proof(rule ballI,rule impI,rule ballI)
        fix A1 assume [ty]: "A1 be SetSequencePROB-1M2-of X"
        assume A2: "rngFUNCT-1K2 A1 c=TARSKIR1 Si"
        fix n assume [ty]: "n be NatNAT-1M1"
        have "A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n inTARSKIR2 rngFUNCT-1K2 A1"
          using nat_1_th_51 sorry
        then have "n inTARSKIR2 NATNUMBERSK1 & (A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)`SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 Si"
          using A2 prob_1_def_1 ordinal1_def_12 sorry
        thus "(ComplementPROB-1K2\<^bsub>(X)\<^esub> A1).NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n inTARSKIR2 Si"
          using prob_1_def_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A3: " for A1 be SetSequencePROB-1M2-of X holds rngFUNCT-1K2 A1 c=TARSKIR1 Si implies UnionPROB-1K1\<^bsub>(X)\<^esub> (ComplementPROB-1K2\<^bsub>(X)\<^esub> (ComplementPROB-1K2\<^bsub>(X)\<^esub> A1)) inTARSKIR2 Si"
    proof-
      have " for A1 be SetSequencePROB-1M2-of X holds rngFUNCT-1K2 A1 c=TARSKIR1 Si implies UnionPROB-1K1\<^bsub>(X)\<^esub> (ComplementPROB-1K2\<^bsub>(X)\<^esub> (ComplementPROB-1K2\<^bsub>(X)\<^esub> A1)) inTARSKIR2 Si"
      proof(rule ballI,rule impI)
        fix A1 assume [ty]: "A1 be SetSequencePROB-1M2-of X"
        assume "rngFUNCT-1K2 A1 c=TARSKIR1 Si"
        then have " for n be NatNAT-1M1 holds (ComplementPROB-1K2\<^bsub>(X)\<^esub> A1).NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n inTARSKIR2 Si"
          using A1 sorry
        then have "rngFUNCT-1K2 (ComplementPROB-1K2\<^bsub>(X)\<^esub> A1) c=TARSKIR1 Si"
          using nat_1_th_52 sorry
        then have "IntersectionPROB-1K3\<^bsub>(X)\<^esub> (ComplementPROB-1K2\<^bsub>(X)\<^esub> A1) inTARSKIR2 Si"
          using prob_1_def_6 sorry
        then have "((UnionPROB-1K1\<^bsub>(X)\<^esub> (ComplementPROB-1K2\<^bsub>(X)\<^esub> (ComplementPROB-1K2\<^bsub>(X)\<^esub> A1)))`SUBSET-1K3\<^bsub>(X)\<^esub>)`SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 Si"
          using prob_1_def_1 sorry
        thus "UnionPROB-1K1\<^bsub>(X)\<^esub> (ComplementPROB-1K2\<^bsub>(X)\<^esub> (ComplementPROB-1K2\<^bsub>(X)\<^esub> A1)) inTARSKIR2 Si"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A4: " for A1 be SetSequencePROB-1M2-of X holds rngFUNCT-1K2 A1 c=TARSKIR1 Si implies UnionPROB-1K1\<^bsub>(X)\<^esub> A1 inTARSKIR2 Si"
    proof(rule ballI,rule impI)
      fix A1 assume [ty]: "A1 be SetSequencePROB-1M2-of X"
      assume "rngFUNCT-1K2 A1 c=TARSKIR1 Si"
      then have "UnionPROB-1K1\<^bsub>(X)\<^esub> (ComplementPROB-1K2\<^bsub>(X)\<^esub> (ComplementPROB-1K2\<^bsub>(X)\<^esub> A1)) inTARSKIR2 Si"
        using A3 sorry
      thus "UnionPROB-1K1\<^bsub>(X)\<^esub> A1 inTARSKIR2 Si"
         sorry
    qed "sorry"
    have "rngFUNCT-1K2 ASeq c=TARSKIR1 Si"
      using relat_1_def_19 sorry
    thus "UnionPROB-1K1\<^bsub>(X)\<^esub> ASeq inTARSKIR2 Si"
      using A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) PROB_1M5("EventPROB-1M5-of  _ " [70]70) where
  "EventPROB-1M5-of F \<equiv> ElementSUBSET-1M1-of F"

syntax PROB_1M6 :: " Set \<Rightarrow>  Set \<Rightarrow> Ty" ("EventPROB-1M6\<^bsub>'( _ ')\<^esub>-of  _ " [0,70]70)
translations "EventPROB-1M6\<^bsub>(X)\<^esub>-of F" \<rightharpoonup> "ElementSUBSET-1M1-of F"

mtheorem prob_1_add_2:
  mlet "X be setHIDDENM2", "F be SigmaFieldPROB-1M3-of X"
"cluster note-that SubsetSUBSET-1M2-of X for ElementSUBSET-1M1-of F"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of F holds it be SubsetSUBSET-1M2-of X"
  proof-
    have " for E be EventPROB-1M5-of F holds E be SubsetSUBSET-1M2-of X"
    proof(rule ballI)
      fix E assume [ty]: "E be EventPROB-1M5-of F"
      have "E inTARSKIR2 F"
         sorry
      thus "E be SubsetSUBSET-1M2-of X"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem prob_1_th_18:
" for X be setHIDDENM2 holds  for x be setHIDDENM2 holds  for Si be SigmaFieldPROB-1M3-of X holds x inTARSKIR2 Si implies x be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
   sorry

mtheorem prob_1_th_19:
" for X be setHIDDENM2 holds  for Si be SigmaFieldPROB-1M3-of X holds  for A be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si holds  for B be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si holds A /\\SUBSET-1K9\<^bsub>(X)\<^esub> B be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
  using finsub_1_def_2 sorry

mtheorem prob_1_th_20:
" for X be setHIDDENM2 holds  for Si be SigmaFieldPROB-1M3-of X holds  for A be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si holds A `SUBSET-1K3\<^bsub>(X)\<^esub> be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
  using prob_1_def_1 sorry

mtheorem prob_1_th_21:
" for X be setHIDDENM2 holds  for Si be SigmaFieldPROB-1M3-of X holds  for A be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si holds  for B be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si holds A \\/SUBSET-1K4\<^bsub>(X)\<^esub> B be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
  using prob_1_th_3 sorry

mtheorem prob_1_th_22:
" for X be setHIDDENM2 holds  for Si be SigmaFieldPROB-1M3-of X holds {}XBOOLE-0K1 be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
  using prob_1_th_4 sorry

mtheorem prob_1_th_23:
" for X be setHIDDENM2 holds  for Si be SigmaFieldPROB-1M3-of X holds X be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
  using prob_1_th_5 sorry

mtheorem prob_1_th_24:
" for X be setHIDDENM2 holds  for Si be SigmaFieldPROB-1M3-of X holds  for A be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si holds  for B be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si holds A \\SUBSET-1K7\<^bsub>(X)\<^esub> B be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
  using prob_1_th_6 sorry

mtheorem prob_1_cl_9:
  mlet "X be setHIDDENM2", "Si be SigmaFieldPROB-1M3-of X"
"cluster emptyXBOOLE-0V1 for EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
proof
(*existence*)
  show " ex it be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si st it be emptyXBOOLE-0V1"
  proof-
    have " not ( for VarFor1 be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si holds  not VarFor1 be emptyXBOOLE-0V1)"
    proof-
      have "{}XBOOLE-0K1 be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
        using prob_1_th_4 sorry
      thus " not ( for VarFor1 be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si holds  not VarFor1 be emptyXBOOLE-0V1)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef prob_1_def_7 ("[#]PROB-1K4\<^bsub>'( _ ')\<^esub>  _ " [0,228]228 ) where
  mlet "X be setHIDDENM2", "Si be SigmaFieldPROB-1M3-of X"
"func [#]PROB-1K4\<^bsub>(X)\<^esub> Si \<rightarrow> EventPROB-1M6\<^bsub>(X)\<^esub>-of Si equals
  X"
proof-
  (*coherence*)
    show "X be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
      using prob_1_th_5 sorry
qed "sorry"

syntax PROB_1K5 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '/'\\PROB-1K5\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "A /\\PROB-1K5\<^bsub>(X,Si)\<^esub> B" \<rightharpoonup> "A /\\XBOOLE-0K3 B"

mtheorem prob_1_add_3:
  mlet "X be setHIDDENM2", "Si be SigmaFieldPROB-1M3-of X", "A be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si", "B be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
"cluster A /\\XBOOLE-0K3 B as-term-is EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
proof
(*coherence*)
  show "A /\\XBOOLE-0K3 B be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
    using finsub_1_def_2 sorry
qed "sorry"

syntax PROB_1K6 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '\\'/PROB-1K6\<^bsub>'( _ , _ ')\<^esub>  _ " [132,0,0,132]132)
translations "A \\/PROB-1K6\<^bsub>(X,Si)\<^esub> B" \<rightharpoonup> "A \\/XBOOLE-0K2 B"

mtheorem prob_1_add_4:
  mlet "X be setHIDDENM2", "Si be SigmaFieldPROB-1M3-of X", "A be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si", "B be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
"cluster A \\/XBOOLE-0K2 B as-term-is EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
proof
(*coherence*)
  show "A \\/XBOOLE-0K2 B be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
    using prob_1_th_3 sorry
qed "sorry"

syntax PROB_1K7 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '\\PROB-1K7\<^bsub>'( _ , _ ')\<^esub>  _ " [132,0,0,132]132)
translations "A \\PROB-1K7\<^bsub>(X,Si)\<^esub> B" \<rightharpoonup> "A \\XBOOLE-0K4 B"

mtheorem prob_1_add_5:
  mlet "X be setHIDDENM2", "Si be SigmaFieldPROB-1M3-of X", "A be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si", "B be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
"cluster A \\XBOOLE-0K4 B as-term-is EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
proof
(*coherence*)
  show "A \\XBOOLE-0K4 B be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
    using prob_1_th_6 sorry
qed "sorry"

mtheorem prob_1_th_25:
" for X be setHIDDENM2 holds  for A1 be SetSequencePROB-1M2-of X holds  for Si be SigmaFieldPROB-1M3-of X holds A1 be SetSequencePROB-1M4\<^bsub>(X)\<^esub>-of Si iff ( for n be NatNAT-1M1 holds A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si)"
proof-
  have " for X be setHIDDENM2 holds  for A1 be SetSequencePROB-1M2-of X holds  for Si be SigmaFieldPROB-1M3-of X holds (A1 be SetSequencePROB-1M4\<^bsub>(X)\<^esub>-of Si implies ( for n be NatNAT-1M1 holds A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si)) & (( for n be NatNAT-1M1 holds A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si) implies A1 be SetSequencePROB-1M4\<^bsub>(X)\<^esub>-of Si)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix A1 assume [ty]: "A1 be SetSequencePROB-1M2-of X"
    fix Si assume [ty]: "Si be SigmaFieldPROB-1M3-of X"
    show "A1 be SetSequencePROB-1M4\<^bsub>(X)\<^esub>-of Si implies ( for n be NatNAT-1M1 holds A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si)"
    proof-
      have "A1 be SetSequencePROB-1M4\<^bsub>(X)\<^esub>-of Si implies ( for n be NatNAT-1M1 holds A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si)"
      proof(rule impI)
        assume "A1 be SetSequencePROB-1M4\<^bsub>(X)\<^esub>-of Si"
        then have A1: "rngFUNCT-1K2 A1 c=TARSKIR1 Si"
          using relat_1_def_19 sorry
        have " for n be NatNAT-1M1 holds A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
          using nat_1_th_51 A1 sorry
        thus " for n be NatNAT-1M1 holds A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A2: " for n be NatNAT-1M1 holds A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
    have " for n be NatNAT-1M1 holds A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n inTARSKIR2 Si"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
        using A2 sorry
      thus "A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n inTARSKIR2 Si"
         sorry
    qed "sorry"
    then have "rngFUNCT-1K2 A1 c=TARSKIR1 Si"
      using nat_1_th_52 sorry
    thus "A1 be SetSequencePROB-1M4\<^bsub>(X)\<^esub>-of Si"
      using relat_1_def_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prob_1_th_26:
" for Omega be setHIDDENM2 holds  for ASeq be SetSequencePROB-1M2-of Omega holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds ASeq be SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma implies UnionPROB-1K1\<^bsub>(Omega)\<^esub> ASeq be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma"
  using prob_1_th_17 sorry

reserve ASeq for "SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma"
mtheorem prob_1_th_27:
" for Omega be setHIDDENM2 holds  for p be setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 Sigma & ( for D be SubsetSUBSET-1M2-of Omega holds D inTARSKIR2 Sigma implies (p inTARSKIR2 D implies f .FUNCT-1K1 D =XBOOLE-0R4 \<one>\<^sub>M) & ( not p inTARSKIR2 D implies f .FUNCT-1K1 D =XBOOLE-0R4 0NUMBERSK6))"
proof-
  have " for Omega be setHIDDENM2 holds  for p be setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  ex tVar6 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar6 =XBOOLE-0R4 Sigma & ( for D be SubsetSUBSET-1M2-of Omega holds D inTARSKIR2 Sigma implies (p inTARSKIR2 D implies tVar6 .FUNCT-1K1 D =XBOOLE-0R4 \<one>\<^sub>M) & ( not p inTARSKIR2 D implies tVar6 .FUNCT-1K1 D =XBOOLE-0R4 0NUMBERSK6))"
  proof(rule ballI,rule ballI,rule ballI)
    fix Omega assume [ty]: "Omega be setHIDDENM2"
    fix p assume [ty]: "p be setHIDDENM2"
    fix Sigma assume [ty]: "Sigma be SigmaFieldPROB-1M3-of Omega"
    let ?G = "\<lambda>Lamb1. 0NUMBERSK6"
    let ?F = "\<lambda>Lamb1. \<one>\<^sub>M"
    let ?C = "\<lambda>Lamb1. p inTARSKIR2 Lamb1"
    have " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 Sigma & ( for x be setHIDDENM2 holds x inTARSKIR2 Sigma implies (?C(x) implies f .FUNCT-1K1 x =XBOOLE-0R4 ?F(x)) & ( not ?C(x) implies f .FUNCT-1K1 x =XBOOLE-0R4 ?G(x)))"
      using partfun1_sch_5 sorry
    then obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A1: "domRELAT-1K1 f =XBOOLE-0R4 Sigma"and A2: " for x be setHIDDENM2 holds x inTARSKIR2 Sigma implies (?C(x) implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) & ( not ?C(x) implies f .FUNCT-1K1 x =XBOOLE-0R4 0NUMBERSK6)"
       sorry
    show " ex tVar6 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar6 =XBOOLE-0R4 Sigma & ( for D be SubsetSUBSET-1M2-of Omega holds D inTARSKIR2 Sigma implies (p inTARSKIR2 D implies tVar6 .FUNCT-1K1 D =XBOOLE-0R4 \<one>\<^sub>M) & ( not p inTARSKIR2 D implies tVar6 .FUNCT-1K1 D =XBOOLE-0R4 0NUMBERSK6))"
    proof(rule bexI[of _ "f"],rule conjMI,rule ballI,rule impI,rule conjMI,rule impI)
      show "domRELAT-1K1 f =XBOOLE-0R4 Sigma"
        using A1 sorry
      fix D assume [ty]: "D be SubsetSUBSET-1M2-of Omega"
      assume A3: "D inTARSKIR2 Sigma"
      thus "p inTARSKIR2 D implies f .FUNCT-1K1 D =XBOOLE-0R4 \<one>\<^sub>M"
        using A2 sorry
      assume " not p inTARSKIR2 D"
      thus "f .FUNCT-1K1 D =XBOOLE-0R4 0NUMBERSK6"
        using A2 A3 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve P for "FunctionFUNCT-2M1-of(Sigma,REALNUMBERSK2)"
mtheorem prob_1_th_28:
" for Omega be setHIDDENM2 holds  for p be setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  ex P be FunctionFUNCT-2M1-of(Sigma,REALNUMBERSK2) st  for D be SubsetSUBSET-1M2-of Omega holds D inTARSKIR2 Sigma implies (p inTARSKIR2 D implies P .FUNCT-1K1 D =COMPLEX1R1 \<one>\<^sub>M) & ( not p inTARSKIR2 D implies P .FUNCT-1K1 D =COMPLEX1R1 0NUMBERSK6)"
proof-
  have " for Omega be setHIDDENM2 holds  for p be setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  ex tVar7 be FunctionFUNCT-2M1-of(Sigma,REALNUMBERSK2) st  for D be SubsetSUBSET-1M2-of Omega holds  not (D inTARSKIR2 Sigma &  not ( not (p inTARSKIR2 D &  not tVar7 .FUNCT-1K1 D =COMPLEX1R1 \<one>\<^sub>M) &  not ( not p inTARSKIR2 D &  not tVar7 .FUNCT-1K1 D =COMPLEX1R1 0NUMBERSK6)))"
  proof(rule ballI,rule ballI,rule ballI)
    fix Omega assume [ty]: "Omega be setHIDDENM2"
    fix p assume [ty]: "p be setHIDDENM2"
    fix Sigma assume [ty]: "Sigma be SigmaFieldPROB-1M3-of Omega"
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A1: "domRELAT-1K1 f =XBOOLE-0R4 Sigma"and A2: " for D be SubsetSUBSET-1M2-of Omega holds D inTARSKIR2 Sigma implies (p inTARSKIR2 D implies f .FUNCT-1K1 D =XBOOLE-0R4 \<one>\<^sub>M) & ( not p inTARSKIR2 D implies f .FUNCT-1K1 D =XBOOLE-0R4 0NUMBERSK6)"
      using prob_1_th_27 sorry
    have A3: "0NUMBERSK6 inTARSKIR2 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    have "rngFUNCT-1K2 f c=TARSKIR1 REALNUMBERSK2"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies y inHIDDENR3 REALNUMBERSK2"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 rngFUNCT-1K2 f"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A4: "x inHIDDENR3 domRELAT-1K1 f"and A5: "y =HIDDENR1 f .FUNCT-1K1 x"
          using funct_1_def_3 sorry
        have 
          [ty]:"x be SubsetSUBSET-1M2-of Omega"
          using A1 A4 sorry
        obtain j where 
          [ty]:"j be RealXREAL-0M1" and jDef:"j = \<one>\<^sub>M"
           sorry
        have A6: "\<one>\<^sub>M inTARSKIR2 REALNUMBERSK2"
          using xreal_0_def_1 sorry
        have A7: " not p inTARSKIR2 x implies y =HIDDENR1 0NUMBERSK6"
          using A1 A2 A4 A5 sorry
        have "p inTARSKIR2 x implies y =HIDDENR1 j"
          using A1 A2 A4 A5 sorry
        thus "y inHIDDENR3 REALNUMBERSK2"
          using A7 A3 A6 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 f c=TARSKIR1 REALNUMBERSK2"
        using tarski_def_3 sorry
    qed
    then have 
      [ty]:"f be FunctionFUNCT-2M1-of(Sigma,REALNUMBERSK2)"
      using A1 funct_2_def_1 relset_1_th_4 sorry
    show " ex tVar7 be FunctionFUNCT-2M1-of(Sigma,REALNUMBERSK2) st  for D be SubsetSUBSET-1M2-of Omega holds  not (D inTARSKIR2 Sigma &  not ( not (p inTARSKIR2 D &  not tVar7 .FUNCT-1K1 D =COMPLEX1R1 \<one>\<^sub>M) &  not ( not p inTARSKIR2 D &  not tVar7 .FUNCT-1K1 D =COMPLEX1R1 0NUMBERSK6)))"
    proof(rule bexI[of _ "f"])
      show " for D be SubsetSUBSET-1M2-of Omega holds  not (D inTARSKIR2 Sigma &  not ( not (p inTARSKIR2 D &  not f .FUNCT-1K1 D =COMPLEX1R1 \<one>\<^sub>M) &  not ( not p inTARSKIR2 D &  not f .FUNCT-1K1 D =COMPLEX1R1 0NUMBERSK6)))"
        using A2 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prob_1_th_29:
" for Omega be setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for ASeq be SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be FunctionFUNCT-2M1-of(Sigma,REALNUMBERSK2) holds P *FUNCT-1K3 ASeq be Real-SequenceSEQ-1M1"
proof-
  have " for Omega be setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for ASeq be SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be FunctionFUNCT-2M1-of(Sigma,REALNUMBERSK2) holds P *FUNCT-1K3 ASeq be Real-SequenceSEQ-1M1"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix Omega assume [ty]: "Omega be setHIDDENM2"
    fix Sigma assume [ty]: "Sigma be SigmaFieldPROB-1M3-of Omega"
    fix ASeq assume [ty]: "ASeq be SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma"
    fix P assume [ty]: "P be FunctionFUNCT-2M1-of(Sigma,REALNUMBERSK2)"
    have "rngFUNCT-1K2 ASeq c=TARSKIR1 Sigma"
      using relat_1_def_19 sorry
    then have "rngFUNCT-1K2 ASeq c=TARSKIR1 domRELAT-1K1 P"
      using funct_2_def_1 sorry
    then have A1: "domRELAT-1K1 (P *FUNCT-1K3 ASeq) =HIDDENR1 domRELAT-1K1 ASeq"
      using relat_1_th_27 sorry
    also have "... = NATNUMBERSK1"
      using funct_2_def_1 sorry
    finally have "domRELAT-1K1 (P *FUNCT-1K3 ASeq) =HIDDENR1 NATNUMBERSK1"
       sorry
    have "rngFUNCT-1K2 (P *FUNCT-1K3 ASeq) c=TARSKIR1 REALNUMBERSK2"
      using relat_1_def_19 sorry
    thus "P *FUNCT-1K3 ASeq be Real-SequenceSEQ-1M1"
      using A1 funct_2_def_1 relset_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax PROB_1K8 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ *PROB-1K8\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq" \<rightharpoonup> "ASeq *RELAT-1K6 P"

mtheorem prob_1_add_6:
  mlet "Omega be setHIDDENM2", "Sigma be SigmaFieldPROB-1M3-of Omega", "ASeq be SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma", "P be FunctionFUNCT-2M1-of(Sigma,REALNUMBERSK2)"
"cluster ASeq *RELAT-1K6 P as-term-is Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show "ASeq *RELAT-1K6 P be Real-SequenceSEQ-1M1"
    using prob_1_th_29 sorry
qed "sorry"

reserve Omega for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve Sigma for "SigmaFieldPROB-1M3-of Omega"
reserve A, B for "EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma"
reserve ASeq for "SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma"
reserve P for "FunctionFUNCT-2M1-of(Sigma,REALNUMBERSK2)"
reserve D, E for "SubsetSUBSET-1M2-of Omega"
reserve BSeq for "SetSequencePROB-1M2-of Omega"
mdef prob_1_def_8 ("ProbabilityPROB-1M7\<^bsub>'( _ ')\<^esub>-of  _ " [0,70]70 ) where
  mlet "Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "Sigma be SigmaFieldPROB-1M3-of Omega"
"mode ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma \<rightarrow> FunctionFUNCT-2M1-of(Sigma,REALNUMBERSK2) means
  (\<lambda>it. ((( for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds 0NUMBERSK6 <=XXREAL-0R1 it .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A) & it .FUNCT-1K1 Omega =COMPLEX1R1 \<one>\<^sub>M) & ( for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds A missesXBOOLE-0R1 B implies it .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B) =COMPLEX1R1 it .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 it .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B)) & ( for ASeq be SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma holds ASeq be non-ascendingPROB-1V2 implies it *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq be convergentSEQ-2V5 & limSEQ-2K1 (it *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq) =COMPLEX1R1 it .FUNCT-1K1 (IntersectionPROB-1K3\<^bsub>(Omega)\<^esub> ASeq)))"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-2M1-of(Sigma,REALNUMBERSK2) st ((( for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds 0NUMBERSK6 <=XXREAL-0R1 it .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A) & it .FUNCT-1K1 Omega =COMPLEX1R1 \<one>\<^sub>M) & ( for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds A missesXBOOLE-0R1 B implies it .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B) =COMPLEX1R1 it .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 it .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B)) & ( for ASeq be SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma holds ASeq be non-ascendingPROB-1V2 implies it *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq be convergentSEQ-2V5 & limSEQ-2K1 (it *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq) =COMPLEX1R1 it .FUNCT-1K1 (IntersectionPROB-1K3\<^bsub>(Omega)\<^esub> ASeq))"
    proof-
      have " ex tVar8 be FunctionFUNCT-2M1-of(Sigma,REALNUMBERSK2) st ( for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds 0NUMBERSK6 <=XXREAL-0R1 tVar8 .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A) & (tVar8 .FUNCT-1K1 Omega =COMPLEX1R1 \<one>\<^sub>M & (( for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds A missesXBOOLE-0R1 B implies tVar8 .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B) =COMPLEX1R1 tVar8 .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 tVar8 .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B) & ( for ASeq be SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma holds ASeq be non-ascendingPROB-1V2 implies tVar8 *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq be convergentSEQ-2V5 & limSEQ-2K1 (tVar8 *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq) =COMPLEX1R1 tVar8 .FUNCT-1K1 (IntersectionPROB-1K3\<^bsub>(Omega)\<^esub> ASeq))))"
      proof-
        let ?p = "the ElementSUBSET-1M1-of Omega"
        obtain P where
          [ty]:"P be FunctionFUNCT-2M1-of(Sigma,REALNUMBERSK2)" and 
          A1: " for D be SubsetSUBSET-1M2-of Omega holds D inTARSKIR2 Sigma implies (?p inTARSKIR2 D implies P .FUNCT-1K1 D =COMPLEX1R1 \<one>\<^sub>M) & ( not ?p inTARSKIR2 D implies P .FUNCT-1K1 D =COMPLEX1R1 0NUMBERSK6)"
          using prob_1_th_28 sorry
        show " ex tVar8 be FunctionFUNCT-2M1-of(Sigma,REALNUMBERSK2) st ( for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds 0NUMBERSK6 <=XXREAL-0R1 tVar8 .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A) & (tVar8 .FUNCT-1K1 Omega =COMPLEX1R1 \<one>\<^sub>M & (( for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds A missesXBOOLE-0R1 B implies tVar8 .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B) =COMPLEX1R1 tVar8 .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 tVar8 .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B) & ( for ASeq be SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma holds ASeq be non-ascendingPROB-1V2 implies tVar8 *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq be convergentSEQ-2V5 & limSEQ-2K1 (tVar8 *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq) =COMPLEX1R1 tVar8 .FUNCT-1K1 (IntersectionPROB-1K3\<^bsub>(Omega)\<^esub> ASeq))))"
        proof(rule bexI[of _ "P"],rule conjMI,rule conjMI,rule conjMI,rule ballI,rule impI)
          show " for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds 0NUMBERSK6 <=XXREAL-0R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A"
            using A1 sorry
          have "[#]PROB-1K4\<^bsub>(Omega)\<^esub> Sigma inTARSKIR2 Sigma"
             sorry
          thus "P .FUNCT-1K1 Omega =COMPLEX1R1 \<one>\<^sub>M"
            using A1 sorry
          show " for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds A missesXBOOLE-0R1 B implies P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B) =COMPLEX1R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B"
          proof(rule ballI,rule ballI,rule impI)
            fix A assume [ty]: "A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma"
            fix B assume [ty]: "B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma"
            assume A2: "A missesXBOOLE-0R1 B"
            have A3: "?p inTARSKIR2 A &  not ?p inTARSKIR2 B implies ?p inTARSKIR2 A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B"
              using xboole_0_def_3 sorry
            have A4: " not ?p inTARSKIR2 A & ?p inTARSKIR2 B implies P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A =COMPLEX1R1 0NUMBERSK6 & P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B =COMPLEX1R1 \<one>\<^sub>M"
              using A1 sorry
            have A5: " not ?p inTARSKIR2 A & ?p inTARSKIR2 B implies ?p inTARSKIR2 A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B"
              using xboole_0_def_3 sorry
            have A6: " not ?p inTARSKIR2 A &  not ?p inTARSKIR2 B implies P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A =COMPLEX1R1 0NUMBERSK6 & P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B =COMPLEX1R1 0NUMBERSK6"
              using A1 sorry
            have A7: " not ?p inTARSKIR2 A &  not ?p inTARSKIR2 B implies  not ?p inTARSKIR2 A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B"
              using xboole_0_def_3 sorry
            have "?p inTARSKIR2 A &  not ?p inTARSKIR2 B implies P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A =COMPLEX1R1 \<one>\<^sub>M & P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B =COMPLEX1R1 0NUMBERSK6"
              using A1 sorry
            thus "P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B) =COMPLEX1R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B"
              using A1 A2 A3 A4 A5 A6 A7 xboole_0_th_3 sorry
          qed "sorry"
          fix ASeq assume [ty]: "ASeq be SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma"
          have A8: " for n be NatNAT-1M1 holds (P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 P .FUNCT-1K1 (ASeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 Omega)\<^esub> n)"
          proof(rule ballI)
            fix n assume [ty]: "n be NatNAT-1M1"
            have 
              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "domRELAT-1K1 (P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq) =XBOOLE-0R4 NATNUMBERSK1"
              using funct_2_def_1 sorry
            then have "(P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 P .FUNCT-1K1 (ASeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 Omega)\<^esub> n)"
              using funct_1_th_12 sorry
            thus "(P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 P .FUNCT-1K1 (ASeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 Omega)\<^esub> n)"
               sorry
          qed "sorry"
          have A9: "( for n be NatNAT-1M1 holds ?p inTARSKIR2 ASeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 Omega)\<^esub> n) implies ( for n be NatNAT-1M1 holds (P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M)"
          proof-
            have "( for n be NatNAT-1M1 holds the ElementSUBSET-1M1-of Omega inTARSKIR2 ASeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 Omega)\<^esub> n) implies ( for n be NatNAT-1M1 holds (P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M)"
            proof(rule impI)
              assume A10: " for n be NatNAT-1M1 holds ?p inTARSKIR2 ASeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 Omega)\<^esub> n"
              have " for n be NatNAT-1M1 holds (P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M"
              proof(rule ballI)
                fix n assume [ty]: "n be NatNAT-1M1"
                have A11: "rngFUNCT-1K2 ASeq c=TARSKIR1 Sigma & ASeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 Omega)\<^esub> n inTARSKIR2 rngFUNCT-1K2 ASeq"
                  using nat_1_th_51 relat_1_def_19 sorry
                have "?p inTARSKIR2 ASeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 Omega)\<^esub> n"
                  using A10 sorry
                then have "P .FUNCT-1K1 (ASeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 Omega)\<^esub> n) =COMPLEX1R1 \<one>\<^sub>M"
                  using A1 A11 sorry
                thus "(P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M"
                  using A8 sorry
              qed "sorry"
              thus " for n be NatNAT-1M1 holds (P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M"
                 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          assume A12: "ASeq be non-ascendingPROB-1V2"
          have A13: " not ( for n be NatNAT-1M1 holds ?p inTARSKIR2 ASeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 Omega)\<^esub> n) implies ( ex m be NatNAT-1M1 st  for n be NatNAT-1M1 holds m <=XXREAL-0R1 n implies (P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6)"
          proof-
            have " not ( for n be NatNAT-1M1 holds the ElementSUBSET-1M1-of Omega inTARSKIR2 ASeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 Omega)\<^esub> n) implies ( ex tVar9 be NatNAT-1M1 st  for n be NatNAT-1M1 holds  not (tVar9 <=XXREAL-0R1 n &  not (P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6))"
            proof(rule impI)
              assume " not ( for n be NatNAT-1M1 holds ?p inTARSKIR2 ASeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 Omega)\<^esub> n)"
              then obtain m where
                [ty]:"m be NatNAT-1M1" and 
                A14: " not ?p inTARSKIR2 ASeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 Omega)\<^esub> m"
                 sorry
              show " ex tVar9 be NatNAT-1M1 st  for n be NatNAT-1M1 holds  not (tVar9 <=XXREAL-0R1 n &  not (P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6)"
              proof(rule bexI[of _ "m"])
                have " for n be NatNAT-1M1 holds m <=XXREAL-0R1 n implies (P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6"
                proof(rule ballI,rule impI)
                  fix n assume [ty]: "n be NatNAT-1M1"
                  assume "m <=XXREAL-0R1 n"
                  then have "ASeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 Omega)\<^esub> n c=TARSKIR1 ASeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 Omega)\<^esub> m"
                    using A12 sorry
                  then have A15: " not ?p inTARSKIR2 ASeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 Omega)\<^esub> n"
                    using A14 sorry
                  have "rngFUNCT-1K2 ASeq c=TARSKIR1 Sigma & ASeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 Omega)\<^esub> n inTARSKIR2 rngFUNCT-1K2 ASeq"
                    using nat_1_th_51 relat_1_def_19 sorry
                  then have "P .FUNCT-1K1 (ASeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 Omega)\<^esub> n) =COMPLEX1R1 0NUMBERSK6"
                    using A1 A15 sorry
                  thus "(P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6"
                    using A8 sorry
                qed "sorry"
                thus " for n be NatNAT-1M1 holds  not (m <=XXREAL-0R1 n &  not (P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6)"
                   sorry
              qed "sorry"
            qed
            thus " ?thesis "
               sorry
          qed
          have A16: "( ex m be NatNAT-1M1 st  for n be NatNAT-1M1 holds m <=XXREAL-0R1 n implies (P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6) implies P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq be convergentSEQ-2V5 & limSEQ-2K1 (P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq) =COMPLEX1R1 0NUMBERSK6"
            using prob_1_th_1 sorry
          have "rngFUNCT-1K2 ASeq c=TARSKIR1 Sigma"
            using relat_1_def_19 sorry
          then have A17: "IntersectionPROB-1K3\<^bsub>(Omega)\<^esub> ASeq inTARSKIR2 Sigma"
            using prob_1_def_6 sorry
          obtain r where 
            [ty]:"r be RealXREAL-0M1" and rDef:"r = \<one>\<^sub>M"
             sorry
          have A18: "( for n be NatNAT-1M1 holds (P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M) implies P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq be convergentSEQ-2V5 & limSEQ-2K1 (P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq) =COMPLEX1R1 \<one>\<^sub>M"
          proof(rule impI)
            assume A19: " for n be NatNAT-1M1 holds (P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M"
            have " ex m be NatNAT-1M1 st  for n be NatNAT-1M1 holds m <=XXREAL-0R1 n implies (P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 r"
            proof-
              have " ex tVar10 be NatNAT-1M1 st  for n be NatNAT-1M1 holds  not (tVar10 <=XXREAL-0R1 n &  not (P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 r)"
              proof-
                show " ex tVar10 be NatNAT-1M1 st  for n be NatNAT-1M1 holds  not (tVar10 <=XXREAL-0R1 n &  not (P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 r)"
                proof(rule bexI[of _ "0NUMBERSK6"])
                  show " for n be NatNAT-1M1 holds  not (0NUMBERSK6 <=XXREAL-0R1 n &  not (P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 r)"
                    using A19 sorry
                qed "sorry"
              qed
              thus " ?thesis "
                 sorry
            qed
            thus "P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq be convergentSEQ-2V5 & limSEQ-2K1 (P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq) =COMPLEX1R1 \<one>\<^sub>M"
              using prob_1_th_1 sorry
          qed
          show "P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq be convergentSEQ-2V5 & limSEQ-2K1 (P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq) =COMPLEX1R1 P .FUNCT-1K1 (IntersectionPROB-1K3\<^bsub>(Omega)\<^esub> ASeq)"
          proof-
            have cases: " not ( for n be NatNAT-1M1 holds ?p inTARSKIR2 ASeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 Omega)\<^esub> n) or ( for n be NatNAT-1M1 holds ?p inTARSKIR2 ASeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 Omega)\<^esub> n)"
               sorry
            have case1: " not ( for n be NatNAT-1M1 holds the ElementSUBSET-1M1-of Omega inTARSKIR2 ASeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 Omega)\<^esub> n) implies P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq be convergentSEQ-2V5 & limSEQ-2K1 (P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq) =COMPLEX1R1 P .FUNCT-1K1 (IntersectionPROB-1K3\<^bsub>(Omega)\<^esub> ASeq)"
            proof(rule impI)
              assume A20: " not ( for n be NatNAT-1M1 holds ?p inTARSKIR2 ASeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 Omega)\<^esub> n)"
              then have " not ?p inTARSKIR2 IntersectionPROB-1K3\<^bsub>(Omega)\<^esub> ASeq"
                using prob_1_th_13 sorry
              thus "P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq be convergentSEQ-2V5 & limSEQ-2K1 (P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq) =COMPLEX1R1 P .FUNCT-1K1 (IntersectionPROB-1K3\<^bsub>(Omega)\<^esub> ASeq)"
                using A1 A13 A16 A20 A17 sorry
            qed
            have case2: "( for n be NatNAT-1M1 holds the ElementSUBSET-1M1-of Omega inTARSKIR2 ASeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 Omega)\<^esub> n) implies P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq be convergentSEQ-2V5 & limSEQ-2K1 (P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq) =COMPLEX1R1 P .FUNCT-1K1 (IntersectionPROB-1K3\<^bsub>(Omega)\<^esub> ASeq)"
            proof(rule impI)
              assume A21: " for n be NatNAT-1M1 holds ?p inTARSKIR2 ASeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 Omega)\<^esub> n"
              then have "?p inTARSKIR2 IntersectionPROB-1K3\<^bsub>(Omega)\<^esub> ASeq"
                using prob_1_th_13 sorry
              thus "P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq be convergentSEQ-2V5 & limSEQ-2K1 (P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq) =COMPLEX1R1 P .FUNCT-1K1 (IntersectionPROB-1K3\<^bsub>(Omega)\<^esub> ASeq)"
                using A1 A9 A18 A21 A17 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

reserve P for "ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma"
mtheorem prob_1_cl_10:
  mlet "Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "Sigma be SigmaFieldPROB-1M3-of Omega"
"cluster note-that zeroedVALUED-0V14 for ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma"
proof
(*coherence*)
  show " for it be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds it be zeroedVALUED-0V14"
  proof-
    have " for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds P be zeroedVALUED-0V14"
    proof(rule ballI)
      obtain E where 
        [ty]:"E be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma" and EDef:"E = {}XBOOLE-0K1"
        using prob_1_th_4 sorry
      fix P assume [ty]: "P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma"
      have A1: "{}XBOOLE-0K1 missesXBOOLE-0R1 [#]PROB-1K4\<^bsub>(Omega)\<^esub> Sigma & {}XBOOLE-0K1 \\/XBOOLE-0K2 [#]PROB-1K4\<^bsub>(Omega)\<^esub> Sigma =XBOOLE-0R4 [#]PROB-1K4\<^bsub>(Omega)\<^esub> Sigma"
        using xboole_1_th_65 sorry
      have "\<one>\<^sub>M =COMPLEX1R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> [#]PROB-1K4\<^bsub>(Omega)\<^esub> Sigma"
        using prob_1_def_8 sorry
      then have Cut839: "\<one>\<^sub>M =COMPLEX1R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> E +XCMPLX-0K2 \<one>\<^sub>M"
        using A1 prob_1_def_8 sorry
      have "P .FUNCT-1K1 {}XBOOLE-0K1 =COMPLEX1R1 0NUMBERSK6"
      proof-
        show "P .FUNCT-1K1 {}XBOOLE-0K1 =COMPLEX1R1 0NUMBERSK6"
          using Cut839 sorry
      qed
      thus "P be zeroedVALUED-0V14"
        using valued_0_def_19 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem prob_1_th_30:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> [#]PROB-1K4\<^bsub>(Omega)\<^esub> Sigma =COMPLEX1R1 \<one>\<^sub>M"
  using prob_1_def_8 sorry

mtheorem prob_1_th_31:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> ([#]PROB-1K4\<^bsub>(Omega)\<^esub> Sigma \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A) +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A =COMPLEX1R1 \<one>\<^sub>M"
proof-
  have " for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> ([#]PROB-1K4\<^bsub>(Omega)\<^esub> Sigma \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A) +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A =COMPLEX1R1 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix Omega assume [ty]: "Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Sigma assume [ty]: "Sigma be SigmaFieldPROB-1M3-of Omega"
    fix A assume [ty]: "A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma"
    fix P assume [ty]: "P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma"
    have A1: "([#]PROB-1K4\<^bsub>(Omega)\<^esub> Sigma \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A)\\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> A =HIDDENR1 A `SUBSET-1K3\<^bsub>(Omega)\<^esub> \\/SUBSET-1K4\<^bsub>(Omega)\<^esub> A"
       sorry
    also have "... = [#]SUBSET-1K2 Omega"
      using subset_1_th_10 sorry
    also have "... = Omega"
       sorry
    finally have "([#]PROB-1K4\<^bsub>(Omega)\<^esub> Sigma \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A)\\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> A =HIDDENR1 Omega"
       sorry
    have "[#]PROB-1K4\<^bsub>(Omega)\<^esub> Sigma \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A missesXBOOLE-0R1 A"
      using xboole_1_th_79 sorry
    then have "P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> ([#]PROB-1K4\<^bsub>(Omega)\<^esub> Sigma \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A) +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A =HIDDENR1 P .FUNCT-1K1 Omega"
      using A1 prob_1_def_8 sorry
    also have "... = \<one>\<^sub>M"
      using prob_1_def_8 sorry
    finally have "P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> ([#]PROB-1K4\<^bsub>(Omega)\<^esub> Sigma \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A) +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A =HIDDENR1 \<one>\<^sub>M"
       sorry
    thus "P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> ([#]PROB-1K4\<^bsub>(Omega)\<^esub> Sigma \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A) +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A =COMPLEX1R1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prob_1_th_32:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> ([#]PROB-1K4\<^bsub>(Omega)\<^esub> Sigma \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A) =COMPLEX1R1 \<one>\<^sub>M -XCMPLX-0K6 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A"
proof-
  have " for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> ([#]PROB-1K4\<^bsub>(Omega)\<^esub> Sigma \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A) =COMPLEX1R1 \<one>\<^sub>M -XCMPLX-0K6 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix Omega assume [ty]: "Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Sigma assume [ty]: "Sigma be SigmaFieldPROB-1M3-of Omega"
    fix A assume [ty]: "A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma"
    fix P assume [ty]: "P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma"
    have "P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> ([#]PROB-1K4\<^bsub>(Omega)\<^esub> Sigma \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A) +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A =COMPLEX1R1 \<one>\<^sub>M"
      using prob_1_th_31 sorry
    thus "P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> ([#]PROB-1K4\<^bsub>(Omega)\<^esub> Sigma \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A) =COMPLEX1R1 \<one>\<^sub>M -XCMPLX-0K6 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prob_1_th_33:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds A c=TARSKIR1 B implies P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (B \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A) =COMPLEX1R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B -REAL-1K5 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A"
proof-
  have " for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds A c=TARSKIR1 B implies P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (B \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A) =COMPLEX1R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B -REAL-1K5 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix Omega assume [ty]: "Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Sigma assume [ty]: "Sigma be SigmaFieldPROB-1M3-of Omega"
    fix A assume [ty]: "A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma"
    fix B assume [ty]: "B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma"
    fix P assume [ty]: "P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma"
    assume A1: "A c=TARSKIR1 B"
    have "A missesXBOOLE-0R1 B \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A"
      using xboole_1_th_79 sorry
    then have "P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (B \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A) =HIDDENR1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> (B \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A))"
      using prob_1_def_8 sorry
    also have "... = P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B"
      using A1 xboole_1_th_45 sorry
    finally have "P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (B \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A) =HIDDENR1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B"
       sorry
    thus "P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (B \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A) =COMPLEX1R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B -REAL-1K5 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prob_1_th_34:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds A c=TARSKIR1 B implies P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A <=XXREAL-0R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B"
proof-
  have " for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds A c=TARSKIR1 B implies P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A <=XXREAL-0R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix Omega assume [ty]: "Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Sigma assume [ty]: "Sigma be SigmaFieldPROB-1M3-of Omega"
    fix A assume [ty]: "A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma"
    fix B assume [ty]: "B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma"
    fix P assume [ty]: "P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma"
    assume "A c=TARSKIR1 B"
    then have "P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (B \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A) =COMPLEX1R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B -REAL-1K5 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A"
      using prob_1_th_33 sorry
    then have "0NUMBERSK6 <=XXREAL-0R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B -REAL-1K5 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A"
      using prob_1_def_8 sorry
    then have "0NUMBERSK6 +XCMPLX-0K2 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A <=XXREAL-0R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B"
      using xreal_1_th_19 sorry
    thus "P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A <=XXREAL-0R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prob_1_th_35:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A <=XXREAL-0R1 \<one>\<^sub>M"
proof-
  have " for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A <=XXREAL-0R1 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix Omega assume [ty]: "Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Sigma assume [ty]: "Sigma be SigmaFieldPROB-1M3-of Omega"
    fix A assume [ty]: "A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma"
    fix P assume [ty]: "P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma"
    have "P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> [#]PROB-1K4\<^bsub>(Omega)\<^esub> Sigma =COMPLEX1R1 \<one>\<^sub>M"
      using prob_1_def_8 sorry
    thus "P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A <=XXREAL-0R1 \<one>\<^sub>M"
      using prob_1_th_34 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prob_1_th_36:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B) =COMPLEX1R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (B \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A)"
proof-
  have " for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B) =COMPLEX1R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (B \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix Omega assume [ty]: "Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Sigma assume [ty]: "Sigma be SigmaFieldPROB-1M3-of Omega"
    fix A assume [ty]: "A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma"
    fix B assume [ty]: "B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma"
    fix P assume [ty]: "P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma"
    have A1: "A missesXBOOLE-0R1 B \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A"
      using xboole_1_th_79 sorry
    have "P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B) =HIDDENR1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> (B \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A))"
      using xboole_1_th_39 sorry
    also have "... = P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (B \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A)"
      using A1 prob_1_def_8 sorry
    finally have "P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B) =HIDDENR1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (B \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A)"
       sorry
    thus "P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B) =COMPLEX1R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (B \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prob_1_th_37:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B) =COMPLEX1R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (B \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B)"
proof-
  have " for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B) =HIDDENR1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (B \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix Omega assume [ty]: "Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Sigma assume [ty]: "Sigma be SigmaFieldPROB-1M3-of Omega"
    fix A assume [ty]: "A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma"
    fix B assume [ty]: "B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma"
    fix P assume [ty]: "P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma"
    have "P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B) =HIDDENR1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (B \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A)"
      using prob_1_th_36 sorry
    also have "... = P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (B \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B)"
      using xboole_1_th_47 sorry
    finally show "P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B) =HIDDENR1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (B \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prob_1_th_38:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B) =COMPLEX1R1 (P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B)-REAL-1K5 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B)"
proof-
  have " for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B) =COMPLEX1R1 (P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B)-REAL-1K5 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix Omega assume [ty]: "Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Sigma assume [ty]: "Sigma be SigmaFieldPROB-1M3-of Omega"
    fix A assume [ty]: "A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma"
    fix B assume [ty]: "B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma"
    fix P assume [ty]: "P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma"
    have "P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B) =HIDDENR1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (B \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B)"
      using prob_1_th_37 sorry
    also have "... = P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 (P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B -REAL-1K5 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B))"
      using prob_1_th_33 xboole_1_th_17 sorry
    finally have "P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B) =HIDDENR1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 (P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B -REAL-1K5 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B))"
       sorry
    thus "P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B) =COMPLEX1R1 (P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B)-REAL-1K5 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prob_1_th_39:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B) <=XXREAL-0R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B"
proof-
  have " for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B) <=XXREAL-0R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix Omega assume [ty]: "Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Sigma assume [ty]: "Sigma be SigmaFieldPROB-1M3-of Omega"
    fix A assume [ty]: "A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma"
    fix B assume [ty]: "B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma"
    fix P assume [ty]: "P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma"
    have "0NUMBERSK6 <=XXREAL-0R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B) & P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B) =COMPLEX1R1 (P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B)-REAL-1K5 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B)"
      using prob_1_def_8 prob_1_th_38 sorry
    thus "P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B) <=XXREAL-0R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B"
      using xreal_1_th_43 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve S for "Subset-FamilySETFAM-1M1-of Omega"
mtheorem prob_1_th_40:
" for X be setHIDDENM2 holds boolSETFAM-1K9 X be SigmaFieldPROB-1M3-of X"
   sorry

mdef prob_1_def_9 ("sigmaPROB-1K9\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X be Subset-FamilySETFAM-1M1-of Omega"
"func sigmaPROB-1K9\<^bsub>(Omega)\<^esub> X \<rightarrow> SigmaFieldPROB-1M3-of Omega means
  \<lambda>it. X c=TARSKIR1 it & ( for Z be setHIDDENM2 holds X c=TARSKIR1 Z & Z be SigmaFieldPROB-1M3-of Omega implies it c=TARSKIR1 Z)"
proof-
  (*existence*)
    show " ex it be SigmaFieldPROB-1M3-of Omega st X c=TARSKIR1 it & ( for Z be setHIDDENM2 holds X c=TARSKIR1 Z & Z be SigmaFieldPROB-1M3-of Omega implies it c=TARSKIR1 Z)"
    proof-
      have " ex tVar11 be SigmaFieldPROB-1M3-of Omega st X c=TARSKIR1 tVar11 & ( for Z be setHIDDENM2 holds  not ((X c=TARSKIR1 Z & Z be SigmaFieldPROB-1M3-of Omega) &  not tVar11 c=TARSKIR1 Z))"
      proof-
        let ?V = "{S where S be Subset-FamilySETFAM-1M1-of Omega : X c=TARSKIR1 S & S be SigmaFieldPROB-1M3-of Omega }"
        let ?Y = "meetSETFAM-1K1 ?V"
        have A1: " for Z be setHIDDENM2 holds Z inTARSKIR2 {S where S be Subset-FamilySETFAM-1M1-of Omega : X c=TARSKIR1 S & S be SigmaFieldPROB-1M3-of Omega } implies X c=TARSKIR1 Z"
        proof(rule ballI,rule impI)
          fix Z assume [ty]: "Z be setHIDDENM2"
          assume "Z inTARSKIR2 ?V"
          then have " ex S be Subset-FamilySETFAM-1M1-of Omega st (Z =XBOOLE-0R4 S & X c=TARSKIR1 S) & S be SigmaFieldPROB-1M3-of Omega"
             sorry
          thus "X c=TARSKIR1 Z"
             sorry
        qed "sorry"
        have A2: "boolSETFAM-1K9 Omega inTARSKIR2 ?V"
           sorry
        have A3: " for E be SubsetSUBSET-1M2-of Omega holds E inTARSKIR2 ?Y implies E `SUBSET-1K3\<^bsub>(Omega)\<^esub> inTARSKIR2 ?Y"
        proof-
          have " for E be SubsetSUBSET-1M2-of Omega holds E inTARSKIR2 meetSETFAM-1K1 ({S where S be Subset-FamilySETFAM-1M1-of Omega : X c=TARSKIR1 S & S be SigmaFieldPROB-1M3-of Omega }) implies E `SUBSET-1K3\<^bsub>(Omega)\<^esub> inTARSKIR2 meetSETFAM-1K1 ({S where S be Subset-FamilySETFAM-1M1-of Omega : X c=TARSKIR1 S & S be SigmaFieldPROB-1M3-of Omega })"
          proof(rule ballI,rule impI)
            fix E assume [ty]: "E be SubsetSUBSET-1M2-of Omega"
            assume A4: "E inTARSKIR2 ?Y"
            have " for Z be setHIDDENM2 holds Z inTARSKIR2 {S where S be Subset-FamilySETFAM-1M1-of Omega : X c=TARSKIR1 S & S be SigmaFieldPROB-1M3-of Omega } implies E `SUBSET-1K3\<^bsub>(Omega)\<^esub> inTARSKIR2 Z"
            proof(rule ballI,rule impI)
              fix Z assume [ty]: "Z be setHIDDENM2"
              assume "Z inTARSKIR2 ?V"
              then have "E inTARSKIR2 Z & ( ex S be Subset-FamilySETFAM-1M1-of Omega st (Z =XBOOLE-0R4 S & X c=TARSKIR1 S) & S be SigmaFieldPROB-1M3-of Omega)"
                using A4 setfam_1_def_1 sorry
              thus "E `SUBSET-1K3\<^bsub>(Omega)\<^esub> inTARSKIR2 Z"
                using prob_1_def_1 sorry
            qed "sorry"
            thus "E `SUBSET-1K3\<^bsub>(Omega)\<^esub> inTARSKIR2 meetSETFAM-1K1 ({S where S be Subset-FamilySETFAM-1M1-of Omega : X c=TARSKIR1 S & S be SigmaFieldPROB-1M3-of Omega })"
              using A2 setfam_1_def_1 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have A5: " for BSeq be SetSequencePROB-1M2-of Omega holds rngFUNCT-1K2 BSeq c=TARSKIR1 ?Y implies IntersectionPROB-1K3\<^bsub>(Omega)\<^esub> BSeq inTARSKIR2 ?Y"
        proof-
          have " for BSeq be SetSequencePROB-1M2-of Omega holds rngFUNCT-1K2 BSeq c=TARSKIR1 meetSETFAM-1K1 ({S where S be Subset-FamilySETFAM-1M1-of Omega : X c=TARSKIR1 S & S be SigmaFieldPROB-1M3-of Omega }) implies IntersectionPROB-1K3\<^bsub>(Omega)\<^esub> BSeq inTARSKIR2 meetSETFAM-1K1 ({S where S be Subset-FamilySETFAM-1M1-of Omega : X c=TARSKIR1 S & S be SigmaFieldPROB-1M3-of Omega })"
          proof(rule ballI,rule impI)
            fix BSeq assume [ty]: "BSeq be SetSequencePROB-1M2-of Omega"
            assume A6: "rngFUNCT-1K2 BSeq c=TARSKIR1 ?Y"
            have " for Z be setHIDDENM2 holds Z inTARSKIR2 {S where S be Subset-FamilySETFAM-1M1-of Omega : X c=TARSKIR1 S & S be SigmaFieldPROB-1M3-of Omega } implies IntersectionPROB-1K3\<^bsub>(Omega)\<^esub> BSeq inTARSKIR2 Z"
            proof(rule ballI,rule impI)
              fix Z assume [ty]: "Z be setHIDDENM2"
              assume A7: "Z inTARSKIR2 ?V"
              have " for n be NatNAT-1M1 holds BSeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 Omega)\<^esub> n inTARSKIR2 Z"
              proof(rule ballI)
                fix n assume [ty]: "n be NatNAT-1M1"
                have "BSeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 Omega)\<^esub> n inTARSKIR2 rngFUNCT-1K2 BSeq"
                  using nat_1_th_51 sorry
                thus "BSeq .NAT-1K8\<^bsub>(boolSETFAM-1K9 Omega)\<^esub> n inTARSKIR2 Z"
                  using A6 A7 setfam_1_def_1 sorry
              qed "sorry"
              then have A8: "rngFUNCT-1K2 BSeq c=TARSKIR1 Z"
                using nat_1_th_52 sorry
              have " ex S be Subset-FamilySETFAM-1M1-of Omega st (Z =XBOOLE-0R4 S & X c=TARSKIR1 S) & S be SigmaFieldPROB-1M3-of Omega"
                using A7 sorry
              thus "IntersectionPROB-1K3\<^bsub>(Omega)\<^esub> BSeq inTARSKIR2 Z"
                using A8 prob_1_def_6 sorry
            qed "sorry"
            thus "IntersectionPROB-1K3\<^bsub>(Omega)\<^esub> BSeq inTARSKIR2 meetSETFAM-1K1 ({S where S be Subset-FamilySETFAM-1M1-of Omega : X c=TARSKIR1 S & S be SigmaFieldPROB-1M3-of Omega })"
              using A2 setfam_1_def_1 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have " for Z be setHIDDENM2 holds Z inTARSKIR2 {S where S be Subset-FamilySETFAM-1M1-of Omega : X c=TARSKIR1 S & S be SigmaFieldPROB-1M3-of Omega } implies {}XBOOLE-0K1 inTARSKIR2 Z"
        proof(rule ballI,rule impI)
          fix Z assume [ty]: "Z be setHIDDENM2"
          assume "Z inTARSKIR2 ?V"
          then have " ex S be Subset-FamilySETFAM-1M1-of Omega st (Z =XBOOLE-0R4 S & X c=TARSKIR1 S) & S be SigmaFieldPROB-1M3-of Omega"
             sorry
          thus "{}XBOOLE-0K1 inTARSKIR2 Z"
            using prob_1_th_4 sorry
        qed "sorry"
        then obtain Y where 
          [ty]:"Y be SigmaFieldPROB-1M3-of Omega" and YDef:"Y = ?Y"
          using A2 A5 A3 prob_1_def_1 prob_1_def_6 setfam_1_th_3 setfam_1_def_1 sorry
        show " ex tVar11 be SigmaFieldPROB-1M3-of Omega st X c=TARSKIR1 tVar11 & ( for Z be setHIDDENM2 holds  not ((X c=TARSKIR1 Z & Z be SigmaFieldPROB-1M3-of Omega) &  not tVar11 c=TARSKIR1 Z))"
        proof(rule bexI[of _ "Y"])
          have " for Z be setHIDDENM2 holds X c=TARSKIR1 Z & Z be SigmaFieldPROB-1M3-of Omega implies Y c=TARSKIR1 Z"
          proof(rule ballI,rule impMI ,rule impI)
            fix Z assume [ty]: "Z be setHIDDENM2"
            assume A9: "X c=TARSKIR1 Z"
              and A10: "Z be SigmaFieldPROB-1M3-of Omega"
            have 
              [ty]:"Z be Subset-FamilySETFAM-1M1-of Omega"
              using A10 sorry
            have "Z inTARSKIR2 ?V"
              using A9 A10 sorry
            thus "Y c=TARSKIR1 Z"
              using setfam_1_th_3 sorry
          qed "sorry"
          thus "X c=TARSKIR1 Y & ( for Z be setHIDDENM2 holds  not ((X c=TARSKIR1 Z & Z be SigmaFieldPROB-1M3-of Omega) &  not Y c=TARSKIR1 Z))"
            using A2 A1 setfam_1_th_5 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be SigmaFieldPROB-1M3-of Omega holds  for it2 be SigmaFieldPROB-1M3-of Omega holds (X c=TARSKIR1 it1 & ( for Z be setHIDDENM2 holds X c=TARSKIR1 Z & Z be SigmaFieldPROB-1M3-of Omega implies it1 c=TARSKIR1 Z)) & (X c=TARSKIR1 it2 & ( for Z be setHIDDENM2 holds X c=TARSKIR1 Z & Z be SigmaFieldPROB-1M3-of Omega implies it2 c=TARSKIR1 Z)) implies it1 =HIDDENR1 it2"
    proof-
      have " for R1 be SigmaFieldPROB-1M3-of Omega holds  for R2 be SigmaFieldPROB-1M3-of Omega holds ((X c=TARSKIR1 R1 & ( for Z be setHIDDENM2 holds X c=TARSKIR1 Z & Z be SigmaFieldPROB-1M3-of Omega implies R1 c=TARSKIR1 Z)) & X c=TARSKIR1 R2) & ( for Z be setHIDDENM2 holds X c=TARSKIR1 Z & Z be SigmaFieldPROB-1M3-of Omega implies R2 c=TARSKIR1 Z) implies R1 =HIDDENR1 R2"
      proof(rule ballI,rule ballI,rule impI)
        fix R1 assume [ty]: "R1 be SigmaFieldPROB-1M3-of Omega"
        fix R2 assume [ty]: "R2 be SigmaFieldPROB-1M3-of Omega"
        assume "((X c=TARSKIR1 R1 & ( for Z be setHIDDENM2 holds X c=TARSKIR1 Z & Z be SigmaFieldPROB-1M3-of Omega implies R1 c=TARSKIR1 Z)) & X c=TARSKIR1 R2) & ( for Z be setHIDDENM2 holds X c=TARSKIR1 Z & Z be SigmaFieldPROB-1M3-of Omega implies R2 c=TARSKIR1 Z)"
        then have "R1 c=TARSKIR1 R2 & R2 c=TARSKIR1 R1"
           sorry
        thus "R1 =HIDDENR1 R2"
          using xboole_0_def_10 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef prob_1_def_10 ("halflinePROB-1K10  _ " [164]164 ) where
  mlet "r be ExtRealXXREAL-0M1"
"func halflinePROB-1K10 r \<rightarrow> SubsetSUBSET-1M2-of REALNUMBERSK2 equals
  ].XXREAL-1K4 -inftyXXREAL-0K2,r .["
proof-
  (*coherence*)
    show "].XXREAL-1K4 -inftyXXREAL-0K2,r .[ be SubsetSUBSET-1M2-of REALNUMBERSK2"
    proof-
      have "].XXREAL-1K4 -inftyXXREAL-0K2,r .[ c=TARSKIR1 REALNUMBERSK2"
      proof-
        have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].XXREAL-1K4 -inftyXXREAL-0K2,r .[ implies x inHIDDENR3 REALNUMBERSK2"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be RealXREAL-0M1"
          assume "x inHIDDENR3 ].XXREAL-1K4 -inftyXXREAL-0K2,r .["
          then have "-inftyXXREAL-0K2 <XXREAL-0R3 x & x <XXREAL-0R3 r"
            using xxreal_1_th_4 sorry
          thus "x inHIDDENR3 REALNUMBERSK2"
            using xxreal_0_th_48 sorry
        qed "sorry"
        thus "].XXREAL-1K4 -inftyXXREAL-0K2,r .[ c=TARSKIR1 REALNUMBERSK2"
          using membered_def_9 sorry
      qed
      thus "].XXREAL-1K4 -inftyXXREAL-0K2,r .[ be SubsetSUBSET-1M2-of REALNUMBERSK2"
         sorry
    qed
qed "sorry"

mdef prob_1_def_11 ("Family-of-halflinesPROB-1K11" 164 ) where
"func Family-of-halflinesPROB-1K11 \<rightarrow> Subset-FamilySETFAM-1M1-of REALNUMBERSK2 equals
  {halflinePROB-1K10 r where r be ElementSUBSET-1M1-of REALNUMBERSK2 :  True  }"
proof-
  (*coherence*)
    show "{halflinePROB-1K10 r where r be ElementSUBSET-1M1-of REALNUMBERSK2 :  True  } be Subset-FamilySETFAM-1M1-of REALNUMBERSK2"
    proof-
      have "{halflinePROB-1K10 r where r be ElementSUBSET-1M1-of REALNUMBERSK2 :  True  } c=TARSKIR1 boolSETFAM-1K9 REALNUMBERSK2"
      proof-
        have " for p be objectHIDDENM1 holds p inHIDDENR3 {halflinePROB-1K10 r where r be ElementSUBSET-1M1-of REALNUMBERSK2 :  True  } implies p inHIDDENR3 boolSETFAM-1K9 REALNUMBERSK2"
        proof(rule ballI,rule impI)
          fix p assume [ty]: "p be objectHIDDENM1"
          assume "p inHIDDENR3 {halflinePROB-1K10 r where r be ElementSUBSET-1M1-of REALNUMBERSK2 :  True  }"
          then have " ex r be ElementSUBSET-1M1-of REALNUMBERSK2 st p =HIDDENR1 halflinePROB-1K10 r"
             sorry
          thus "p inHIDDENR3 boolSETFAM-1K9 REALNUMBERSK2"
             sorry
        qed "sorry"
        thus "{halflinePROB-1K10 r where r be ElementSUBSET-1M1-of REALNUMBERSK2 :  True  } c=TARSKIR1 boolSETFAM-1K9 REALNUMBERSK2"
          using tarski_def_3 sorry
      qed
      thus "{halflinePROB-1K10 r where r be ElementSUBSET-1M1-of REALNUMBERSK2 :  True  } be Subset-FamilySETFAM-1M1-of REALNUMBERSK2"
         sorry
    qed
qed "sorry"

mdef prob_1_def_12 ("Borel-SetsPROB-1K12" 164 ) where
"func Borel-SetsPROB-1K12 \<rightarrow> SigmaFieldPROB-1M3-of REALNUMBERSK2 equals
  sigmaPROB-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (Family-of-halflinesPROB-1K11)"
proof-
  (*coherence*)
    show "sigmaPROB-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (Family-of-halflinesPROB-1K11) be SigmaFieldPROB-1M3-of REALNUMBERSK2"
       sorry
qed "sorry"

mtheorem prob_1_th_41:
" for X be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of X holds  for B be SubsetSUBSET-1M2-of X holds ComplementPROB-1K2\<^bsub>(X)\<^esub> (A followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,boolZFMISC-1K1 X)\<^esub> A `SUBSET-1K3\<^bsub>(X)\<^esub> followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B `SUBSET-1K3\<^bsub>(X)\<^esub>"
  using prob_1_lm_1 sorry

syntax PROB_1K13 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ .PROB-1K13\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [200,0,0,0,200]200)
translations "F .PROB-1K13\<^bsub>(X,Y,A)\<^esub> x" \<rightharpoonup> "F .FUNCT-1K1 x"

mtheorem prob_1_add_7:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2", "A be Subset-FamilySETFAM-1M1-of X", "F be FunctionFUNCT-2M1-of(Y,boolSETFAM-1K9 A)", "x be setHIDDENM2"
"cluster F .FUNCT-1K1 x as-term-is Subset-FamilySETFAM-1M1-of X"
proof
(*coherence*)
  show "F .FUNCT-1K1 x be Subset-FamilySETFAM-1M1-of X"
  proof-
    show "F .FUNCT-1K1 x be Subset-FamilySETFAM-1M1-of X"
    proof-
      have cases: "x inTARSKIR2 domRELAT-1K1 F or  not x inTARSKIR2 domRELAT-1K1 F"
         sorry
      have case1: "x inTARSKIR2 domRELAT-1K1 F implies F .FUNCT-1K1 x be Subset-FamilySETFAM-1M1-of X"
      proof(rule impI)
        assume A1: "x inTARSKIR2 domRELAT-1K1 F"
        have A2: "rngFUNCT-1K2 F c=TARSKIR1 boolSETFAM-1K9 A"
          using relat_1_def_19 sorry
        have A3: "boolSETFAM-1K9 A c=TARSKIR1 boolSETFAM-1K9 (boolSETFAM-1K9 X)"
          using zfmisc_1_th_67 sorry
        have "F .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 F"
          using A1 funct_1_def_3 sorry
        then have "F .FUNCT-1K1 x inTARSKIR2 boolSETFAM-1K9 A"
          using A2 sorry
        thus "F .FUNCT-1K1 x be Subset-FamilySETFAM-1M1-of X"
          using A3 sorry
      qed
      have case2: " not x inTARSKIR2 domRELAT-1K1 F implies F .FUNCT-1K1 x be Subset-FamilySETFAM-1M1-of X"
      proof(rule impI)
        assume " not x inTARSKIR2 domRELAT-1K1 F"
        then have "F .FUNCT-1K1 x =XBOOLE-0R4 {}XBOOLE-0K1"
          using funct_1_def_2 sorry
        thus "F .FUNCT-1K1 x be Subset-FamilySETFAM-1M1-of X"
          using xboole_1_th_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
qed "sorry"

end
