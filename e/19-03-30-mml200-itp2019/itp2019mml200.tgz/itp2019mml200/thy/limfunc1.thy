theory limfunc1
  imports prob_1 funct_3 rfunct_2
   "../mizar_extension/E_number"
begin
(*begin*)
reserve r, r1, g for "RealXREAL-0M1"
reserve n, m, k for "NatNAT-1M1"
reserve seq, seq1, seq2 for "Real-SequenceSEQ-1M1"
reserve f, f1, f2 for "PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
mlemma limfunc1_lm_1:
" for r be RealXREAL-0M1 holds  for r1 be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g & r <=XXREAL-0R1 r1 implies r -XCMPLX-0K6 g <XXREAL-0R3 r1 & r <XXREAL-0R3 r1 +XCMPLX-0K2 g"
proof-
  have " for r be RealXREAL-0M1 holds  for r1 be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g & r <=XXREAL-0R1 r1 implies r -XCMPLX-0K6 g <XXREAL-0R3 r1 &  not r <XXREAL-0R3 r1 +XCMPLX-0K2 g"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix r1 assume [ty]: "r1 be RealXREAL-0M1"
    fix g assume [ty]: "g be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 g & r <=XXREAL-0R1 r1"
    then have "r -XCMPLX-0K6 g <XXREAL-0R3 r1 -XCMPLX-0K6 0NUMBERSK6"
      using xreal_1_th_15 sorry
    thus "r -XCMPLX-0K6 g <XXREAL-0R3 r1"
       sorry
    have "r +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 r1 +XCMPLX-0K2 g"
      using A1 xreal_1_th_8 sorry
    thus " not r <XXREAL-0R3 r1 +XCMPLX-0K2 g"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma limfunc1_lm_2:
" for seq be Real-SequenceSEQ-1M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1) & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 & (rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
    show "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using valued_1_def_1 sorry
    then have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using xboole_1_th_17 sorry
    thus "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma limfunc1_lm_3:
" for seq be Real-SequenceSEQ-1M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1) & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 & (rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
    show "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using valued_1_def_4 sorry
    then have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using xboole_1_th_17 sorry
    thus "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) LIMFUNC1K1("left-open-halflineLIMFUNC1K1  _ " [164]164) where
  "left-open-halflineLIMFUNC1K1 r \<equiv> halflinePROB-1K10 r"

mdef limfunc1_def_1 ("left-closed-halflineLIMFUNC1K2  _ " [164]164 ) where
  mlet "r be RealXREAL-0M1"
"func left-closed-halflineLIMFUNC1K2 r \<rightarrow> SubsetSUBSET-1M2-of REALNUMBERSK2 equals
  ].XXREAL-1K3 -inftyXXREAL-0K2,r .]"
proof-
  (*coherence*)
    show "].XXREAL-1K3 -inftyXXREAL-0K2,r .] be SubsetSUBSET-1M2-of REALNUMBERSK2"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 ].XXREAL-1K3 -inftyXXREAL-0K2,r .] implies x inHIDDENR3 REALNUMBERSK2"
        using xreal_0_def_1 sorry
      thus "].XXREAL-1K3 -inftyXXREAL-0K2,r .] be SubsetSUBSET-1M2-of REALNUMBERSK2"
        using tarski_def_3 sorry
    qed
qed "sorry"

mdef limfunc1_def_2 ("right-closed-halflineLIMFUNC1K3  _ " [164]164 ) where
  mlet "r be RealXREAL-0M1"
"func right-closed-halflineLIMFUNC1K3 r \<rightarrow> SubsetSUBSET-1M2-of REALNUMBERSK2 equals
  [.XXREAL-1K2 r,+inftyXXREAL-0K1 .["
proof-
  (*coherence*)
    show "[.XXREAL-1K2 r,+inftyXXREAL-0K1 .[ be SubsetSUBSET-1M2-of REALNUMBERSK2"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 [.XXREAL-1K2 r,+inftyXXREAL-0K1 .[ implies x inHIDDENR3 REALNUMBERSK2"
        using xreal_0_def_1 sorry
      thus "[.XXREAL-1K2 r,+inftyXXREAL-0K1 .[ be SubsetSUBSET-1M2-of REALNUMBERSK2"
        using tarski_def_3 sorry
    qed
qed "sorry"

mdef limfunc1_def_3 ("right-open-halflineLIMFUNC1K4  _ " [164]164 ) where
  mlet "r be RealXREAL-0M1"
"func right-open-halflineLIMFUNC1K4 r \<rightarrow> SubsetSUBSET-1M2-of REALNUMBERSK2 equals
  ].XXREAL-1K4 r,+inftyXXREAL-0K1 .["
proof-
  (*coherence*)
    show "].XXREAL-1K4 r,+inftyXXREAL-0K1 .[ be SubsetSUBSET-1M2-of REALNUMBERSK2"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 ].XXREAL-1K4 r,+inftyXXREAL-0K1 .[ implies x inHIDDENR3 REALNUMBERSK2"
        using xreal_0_def_1 sorry
      thus "].XXREAL-1K4 r,+inftyXXREAL-0K1 .[ be SubsetSUBSET-1M2-of REALNUMBERSK2"
        using tarski_def_3 sorry
    qed
qed "sorry"

mtheorem limfunc1_th_1:
" for seq be Real-SequenceSEQ-1M1 holds (seq be non-decreasingSEQM-3V8 implies seq be bounded-belowSEQ-2V4) & (seq be non-increasingSEQM-3V9 implies seq be bounded-aboveSEQ-2V3)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds (seq be non-decreasingSEQM-3V8 implies seq be bounded-belowSEQ-2V4) & (seq be non-increasingSEQM-3V9 implies seq be bounded-aboveSEQ-2V3)"
  proof(rule ballI,rule conjMI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    show "seq be non-decreasingSEQM-3V8 implies seq be bounded-belowSEQ-2V4"
    proof(rule impI)
      assume A1: "seq be non-decreasingSEQM-3V8"
      have " for n be NatNAT-1M1 holds  not seq .FUNCT-1K1 n <=XXREAL-0R1 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) -XCMPLX-0K6 \<one>\<^sub>M"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) -XCMPLX-0K6 0NUMBERSK6 & seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) <=XXREAL-0R1 seq .FUNCT-1K1 n"
          using A1 seqm_3_th_11 xreal_1_th_15 sorry
        thus " not seq .FUNCT-1K1 n <=XXREAL-0R1 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) -XCMPLX-0K6 \<one>\<^sub>M"
          using xxreal_0_th_2 sorry
      qed "sorry"
      thus "seq be bounded-belowSEQ-2V4"
        using bexI[of _ "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) -XCMPLX-0K6 \<one>\<^sub>M"] seq_2_def_4 sorry
    qed
    assume A2: "seq be non-increasingSEQM-3V9"
    have " for n be NatNAT-1M1 holds  not seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 seq .FUNCT-1K1 n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 \<one>\<^sub>M & seq .FUNCT-1K1 n <=XXREAL-0R1 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
        using A2 seqm_3_th_12 xreal_1_th_8 sorry
      thus " not seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 seq .FUNCT-1K1 n"
        using xxreal_0_th_2 sorry
    qed "sorry"
    thus "seq be bounded-aboveSEQ-2V3"
      using bexI[of _ "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 \<one>\<^sub>M"] seq_2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_2:
" for seq be Real-SequenceSEQ-1M1 holds ((seq be non-zeroORDINAL1V9 & seq be convergentSEQ-2V5) & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6) & seq be non-decreasingSEQM-3V8 implies ( for n be NatNAT-1M1 holds seq .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds seq be non-zeroORDINAL1V9 & ((seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6) & (seq be non-decreasingSEQM-3V8 & ( ex n be NatNAT-1M1 st  not seq .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6))) implies  False "
  proof(rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq be non-zeroORDINAL1V9"
      and A2: "seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6"
      and A3: "seq be non-decreasingSEQM-3V8"
      and A4: " ex n be NatNAT-1M1 st  not seq .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6"
    obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A5: " not seq .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6"
      using A4 sorry
    have " False "
    proof-
      show " False "
      proof-
        have cases: "0NUMBERSK6 <XXREAL-0R3 seq .FUNCT-1K1 n or seq .FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6"
          using A5 sorry
        have case1: "0NUMBERSK6 <XXREAL-0R3 seq .FUNCT-1K1 n implies  False "
        proof(rule impI)
          assume A6: "0NUMBERSK6 <XXREAL-0R3 seq .FUNCT-1K1 n"
          then obtain n1 where
            [ty]:"n1 be NatNAT-1M1" and 
            A7: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 seq .FUNCT-1K1 n"
            using A2 seq_2_def_7 sorry
          have " |.COMPLEX1K10 seq .FUNCT-1K1 (n1 +XCMPLX-0K2 n) -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 seq .FUNCT-1K1 n"
            using A7 nat_1_th_12 sorry
          then have "n <=XXREAL-0R1 n1 +XCMPLX-0K2 n & seq .FUNCT-1K1 (n1 +XCMPLX-0K2 n) <XXREAL-0R3 seq .FUNCT-1K1 n"
            using A6 absvalue_def_1 nat_1_th_12 sorry
          thus " False "
            using A3 seqm_3_th_6 sorry
        qed
        have case2: "seq .FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6 implies  False "
        proof(rule impI)
          assume "seq .FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6"
          thus " False "
            using A1 seq_1_th_5 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " False "
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_3:
" for seq be Real-SequenceSEQ-1M1 holds ((seq be non-zeroORDINAL1V9 & seq be convergentSEQ-2V5) & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6) & seq be non-increasingSEQM-3V9 implies ( for n be NatNAT-1M1 holds 0NUMBERSK6 <XXREAL-0R3 seq .FUNCT-1K1 n)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds seq be non-zeroORDINAL1V9 & ((seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6) & (seq be non-increasingSEQM-3V9 & ( ex n be NatNAT-1M1 st  not 0NUMBERSK6 <XXREAL-0R3 seq .FUNCT-1K1 n))) implies  False "
  proof(rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq be non-zeroORDINAL1V9"
      and A2: "seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6"
      and A3: "seq be non-increasingSEQM-3V9"
      and A4: " ex n be NatNAT-1M1 st  not 0NUMBERSK6 <XXREAL-0R3 seq .FUNCT-1K1 n"
    obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A5: " not 0NUMBERSK6 <XXREAL-0R3 seq .FUNCT-1K1 n"
      using A4 sorry
    have " False "
    proof-
      show " False "
      proof-
        have cases: "seq .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6 or seq .FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6"
          using A5 sorry
        have case1: "seq .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6 implies  False "
        proof(rule impI)
          assume A6: "seq .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6"
          then have "-XCMPLX-0K4 0NUMBERSK6 <XXREAL-0R3 -XCMPLX-0K4 seq .FUNCT-1K1 n"
            using xreal_1_th_24 sorry
          then obtain n1 where
            [ty]:"n1 be NatNAT-1M1" and 
            A7: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 -XCMPLX-0K4 seq .FUNCT-1K1 n"
            using A2 seq_2_def_7 sorry
          have A8: " |.COMPLEX1K10 seq .FUNCT-1K1 (n1 +XCMPLX-0K2 n) -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 -XCMPLX-0K4 seq .FUNCT-1K1 n"
            using A7 nat_1_th_12 sorry
          have A9: "n <=XXREAL-0R1 n1 +XCMPLX-0K2 n"
            using nat_1_th_12 sorry
          then have "seq .FUNCT-1K1 (n1 +XCMPLX-0K2 n) <XXREAL-0R3 0NUMBERSK6"
            using A3 A6 seqm_3_th_8 sorry
          then have "-XCMPLX-0K4 seq .FUNCT-1K1 (n1 +XCMPLX-0K2 n) <XXREAL-0R3 -XCMPLX-0K4 seq .FUNCT-1K1 n"
            using A8 absvalue_def_1 sorry
          then have "seq .FUNCT-1K1 n <XXREAL-0R3 seq .FUNCT-1K1 (n1 +XCMPLX-0K2 n)"
            using xreal_1_th_24 sorry
          thus " False "
            using A3 A9 seqm_3_th_8 sorry
        qed
        have case2: "seq .FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6 implies  False "
        proof(rule impI)
          assume "seq .FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6"
          thus " False "
            using A1 seq_1_th_5 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " False "
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_4:
" for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & 0NUMBERSK6 <XXREAL-0R3 limSEQ-2K1 seq implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies 0NUMBERSK6 <XXREAL-0R3 seq .FUNCT-1K1 m)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & (0NUMBERSK6 <XXREAL-0R3 limSEQ-2K1 seq & ( for n be NatNAT-1M1 holds  ex m be NatNAT-1M1 st n <=XXREAL-0R1 m &  not 0NUMBERSK6 <XXREAL-0R3 seq .FUNCT-1K1 m)) implies  False "
  proof(rule ballI,rule impMI ,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq be convergentSEQ-2V5"
      and A2: "0NUMBERSK6 <XXREAL-0R3 limSEQ-2K1 seq"
      and A3: " for n be NatNAT-1M1 holds  ex m be NatNAT-1M1 st n <=XXREAL-0R1 m &  not 0NUMBERSK6 <XXREAL-0R3 seq .FUNCT-1K1 m"
    obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A4: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 limSEQ-2K1 seq"
      using A1 A2 seq_2_def_7 sorry
    obtain m where
      [ty]:"m be NatNAT-1M1" and 
      A5: "n <=XXREAL-0R1 m"and A6: " not 0NUMBERSK6 <XXREAL-0R3 seq .FUNCT-1K1 m"
      using A3 sorry
    have A7: " |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 limSEQ-2K1 seq"
      using A4 A5 sorry
    have " False "
    proof-
      show " False "
      proof-
        have cases: "seq .FUNCT-1K1 m <XXREAL-0R3 0NUMBERSK6 or seq .FUNCT-1K1 m =COMPLEX1R1 0NUMBERSK6"
          using A6 sorry
        have case1: "seq .FUNCT-1K1 m <XXREAL-0R3 0NUMBERSK6 implies  False "
        proof(rule impI)
          assume A8: "seq .FUNCT-1K1 m <XXREAL-0R3 0NUMBERSK6"
          then have "-XCMPLX-0K4 (seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq) <XXREAL-0R3 limSEQ-2K1 seq"
            using A2 A7 absvalue_def_1 sorry
          then have "limSEQ-2K1 seq -XCMPLX-0K6 seq .FUNCT-1K1 m <XXREAL-0R3 limSEQ-2K1 seq"
             sorry
          then have "limSEQ-2K1 seq <XXREAL-0R3 limSEQ-2K1 seq +XCMPLX-0K2 seq .FUNCT-1K1 m"
            using xreal_1_th_19 sorry
          then have "limSEQ-2K1 seq -XCMPLX-0K6 limSEQ-2K1 seq <XXREAL-0R3 seq .FUNCT-1K1 m"
            using xreal_1_th_19 sorry
          thus " False "
            using A8 sorry
        qed
        have case2: "seq .FUNCT-1K1 m =COMPLEX1R1 0NUMBERSK6 implies  False "
        proof(rule impI)
          assume "seq .FUNCT-1K1 m =COMPLEX1R1 0NUMBERSK6"
          then have " |.COMPLEX1K10 -XCMPLX-0K4 limSEQ-2K1 seq .| <XXREAL-0R3 limSEQ-2K1 seq"
            using A7 sorry
          then have " |.COMPLEX1K10 limSEQ-2K1 seq .| <XXREAL-0R3 limSEQ-2K1 seq"
            using complex1_th_52 sorry
          thus " False "
            using A2 absvalue_def_1 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " False "
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_5:
" for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & 0NUMBERSK6 <XXREAL-0R3 limSEQ-2K1 seq implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies (limSEQ-2K1 seq)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 seq .FUNCT-1K1 m)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & 0NUMBERSK6 <XXREAL-0R3 limSEQ-2K1 seq implies ( ex tVar3 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar3 <=XXREAL-0R1 m implies  not (limSEQ-2K1 seq)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 seq .FUNCT-1K1 m)"
  proof(rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq be convergentSEQ-2V5"
      and A2: "0NUMBERSK6 <XXREAL-0R3 limSEQ-2K1 seq"
    obtain ls where 
      [ty]:"ls be ElementSUBSET-1M1-of REALNUMBERSK2" and lsDef:"ls = (limSEQ-2K1 seq)/XCMPLX-0K7 \<two>\<^sub>M"
      using xreal_0_def_1 sorry
    let ?s1 = "seq-constSEQ-1K1 ((limSEQ-2K1 seq)/XCMPLX-0K7 \<two>\<^sub>M)"
    have A3: "seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s1 be convergentSEQ-2V5"
      using A1 sorry
    have "?s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 (limSEQ-2K1 seq)/XCMPLX-0K7 \<two>\<^sub>M"
      using seq_1_th_57 sorry
    then have "limSEQ-2K1 (seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s1) =HIDDENR1 ((limSEQ-2K1 seq)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (limSEQ-2K1 seq)/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 (limSEQ-2K1 seq)/XCMPLX-0K7 \<two>\<^sub>M"
      using A1 seq_4_th_42 sorry
    also have "... = (limSEQ-2K1 seq)/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    finally have "limSEQ-2K1 (seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s1) =HIDDENR1 (limSEQ-2K1 seq)/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    then obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A4: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies 0NUMBERSK6 <XXREAL-0R3 (seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s1).FUNCT-1K1 m"
      using A2 A3 limfunc1_th_4 xreal_1_th_215 sorry
    show " ex tVar3 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar3 <=XXREAL-0R1 m implies  not (limSEQ-2K1 seq)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 seq .FUNCT-1K1 m"
    proof(rule bexI[of _ "n"],rule ballI,rule impI)
      fix m assume [ty]: "m be NatNAT-1M1"
      assume "n <=XXREAL-0R1 m"
      then have "0NUMBERSK6 <XXREAL-0R3 (seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s1).FUNCT-1K1 m"
        using A4 sorry
      then have "0NUMBERSK6 <XXREAL-0R3 seq .FUNCT-1K1 m -XCMPLX-0K6 ?s1 .FUNCT-1K1 m"
        using rfunct_2_th_1 sorry
      then have "0NUMBERSK6 <XXREAL-0R3 seq .FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 seq)/XCMPLX-0K7 \<two>\<^sub>M"
        using seq_1_th_57 sorry
      then have "0NUMBERSK6 +XCMPLX-0K2 (limSEQ-2K1 seq)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 seq .FUNCT-1K1 m"
        using xreal_1_th_20 sorry
      thus " not (limSEQ-2K1 seq)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 seq .FUNCT-1K1 m"
         sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve r, r1, r2, g, g1, g2 for "RealXREAL-0M1"
mdef limfunc1_def_4 ("divergent-to+inftyLIMFUNC1V1" 70 ) where
"attr divergent-to+inftyLIMFUNC1V1 for Real-SequenceSEQ-1M1 means
  (\<lambda>seq.  for r be RealXREAL-0M1 holds  ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies r <XXREAL-0R3 seq .FUNCT-1K1 m)"..

mdef limfunc1_def_5 ("divergent-to-inftyLIMFUNC1V2" 70 ) where
"attr divergent-to-inftyLIMFUNC1V2 for Real-SequenceSEQ-1M1 means
  (\<lambda>seq.  for r be RealXREAL-0M1 holds  ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .FUNCT-1K1 m <XXREAL-0R3 r)"..

mtheorem limfunc1_th_6:
" for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 or seq be divergent-to-inftyLIMFUNC1V2 implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> m be non-zeroORDINAL1V9)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 or seq be divergent-to-inftyLIMFUNC1V2 implies  not ( for n be NatNAT-1M1 holds  not ( for m be NatNAT-1M1 holds  not (n <=XXREAL-0R1 m &  not seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> m be non-zeroORDINAL1V9)))"
  proof(rule ballI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq be divergent-to+inftyLIMFUNC1V1 or seq be divergent-to-inftyLIMFUNC1V2"
    have " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> m be non-zeroORDINAL1V9"
    proof-
      show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> m be non-zeroORDINAL1V9"
      proof-
        have cases: "seq be divergent-to+inftyLIMFUNC1V1 or seq be divergent-to-inftyLIMFUNC1V2"
          using A1 sorry
        have case1: "seq be divergent-to+inftyLIMFUNC1V1 implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> m be non-zeroORDINAL1V9)"
        proof(rule impI)
          assume "seq be divergent-to+inftyLIMFUNC1V1"
          then obtain n where
            [ty]:"n be NatNAT-1M1" and 
            A2: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies 0NUMBERSK6 <XXREAL-0R3 seq .FUNCT-1K1 m"
             sorry
          show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> m be non-zeroORDINAL1V9"
          proof(rule bexI[of _ "n"],rule ballI,rule impI)
            fix m assume [ty]: "m be NatNAT-1M1"
            assume A3: "n <=XXREAL-0R1 m"
            have " for k be NatNAT-1M1 holds 0NUMBERSK6 <>HIDDENR2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> m).FUNCT-1K1 k"
            proof(rule ballI)
              fix k assume [ty]: "k be NatNAT-1M1"
              have "0NUMBERSK6 <XXREAL-0R3 seq .FUNCT-1K1 (k +XCMPLX-0K2 m)"
                using A2 A3 nat_1_th_12 sorry
              thus "0NUMBERSK6 <>HIDDENR2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> m).FUNCT-1K1 k"
                using nat_1_def_3 sorry
            qed "sorry"
            thus "seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> m be non-zeroORDINAL1V9"
              using seq_1_th_5 sorry
          qed "sorry"
        qed
        have case2: "seq be divergent-to-inftyLIMFUNC1V2 implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> m be non-zeroORDINAL1V9)"
        proof(rule impI)
          assume "seq be divergent-to-inftyLIMFUNC1V2"
          then obtain n where
            [ty]:"n be NatNAT-1M1" and 
            A4: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .FUNCT-1K1 m <XXREAL-0R3 0NUMBERSK6"
             sorry
          show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> m be non-zeroORDINAL1V9"
          proof(rule bexI[of _ "n"],rule ballI,rule impI)
            fix m assume [ty]: "m be NatNAT-1M1"
            assume A5: "n <=XXREAL-0R1 m"
            have " for k be NatNAT-1M1 holds (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> m).FUNCT-1K1 k <>HIDDENR2 0NUMBERSK6"
            proof(rule ballI)
              fix k assume [ty]: "k be NatNAT-1M1"
              have "seq .FUNCT-1K1 (k +XCMPLX-0K2 m) <XXREAL-0R3 0NUMBERSK6"
                using A4 A5 nat_1_th_12 sorry
              thus "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> m).FUNCT-1K1 k <>HIDDENR2 0NUMBERSK6"
                using nat_1_def_3 sorry
            qed "sorry"
            thus "seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> m be non-zeroORDINAL1V9"
              using seq_1_th_5 sorry
          qed "sorry"
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not ( for n be NatNAT-1M1 holds  not ( for m be NatNAT-1M1 holds  not (n <=XXREAL-0R1 m &  not seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> m be non-zeroORDINAL1V9)))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_7:
" for k be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be divergent-to+inftyLIMFUNC1V1 implies seq be divergent-to+inftyLIMFUNC1V1) & (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be divergent-to-inftyLIMFUNC1V2 implies seq be divergent-to-inftyLIMFUNC1V2)"
proof-
  have " for k be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be divergent-to+inftyLIMFUNC1V1 implies seq be divergent-to+inftyLIMFUNC1V1) & (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be divergent-to-inftyLIMFUNC1V2 implies seq be divergent-to-inftyLIMFUNC1V2)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    show "seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be divergent-to+inftyLIMFUNC1V1 implies seq be divergent-to+inftyLIMFUNC1V1"
    proof(rule impI)
      assume A1: "seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be divergent-to+inftyLIMFUNC1V1"
      have " for r be RealXREAL-0M1 holds  ex n be setHIDDENM2 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  not r <XXREAL-0R3 seq .FUNCT-1K1 m"
      proof(rule ballI)
        fix r assume [ty]: "r be RealXREAL-0M1"
        obtain n1 where
          [ty]:"n1 be NatNAT-1M1" and 
          A2: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies r <XXREAL-0R3 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 m"
          using A1 sorry
        obtain n where 
          [ty]:"n be setHIDDENM2" and nDef:"n = n1 +XCMPLX-0K2 k"
           sorry
        show " ex n be setHIDDENM2 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  not r <XXREAL-0R3 seq .FUNCT-1K1 m"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          assume "n <=XXREAL-0R1 m"
          then obtain n2 where
            [ty]:"n2 be NatNAT-1M1" and 
            A3: "m =COMPLEX1R1 n +XCMPLX-0K2 n2"
            using nat_1_th_10 sorry
          have 
            [ty]:"n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
            using ordinal1_def_12 sorry
          have A4: "r <XXREAL-0R3 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n1 +NAT-1K1 n2)"
            using A2 nat_1_th_12 sorry
          have "(n1 +NAT-1K1 n2)+XCMPLX-0K2 k =COMPLEX1R1 m"
            using A3 sorry
          thus " not r <XXREAL-0R3 seq .FUNCT-1K1 m"
            using A4 nat_1_def_3 sorry
        qed "sorry"
      qed "sorry"
      thus "seq be divergent-to+inftyLIMFUNC1V1"
        using limfunc1_def_4 sorry
    qed
    assume A5: "seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be divergent-to-inftyLIMFUNC1V2"
    have " for r be RealXREAL-0M1 holds  ex n be setHIDDENM2 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  not seq .FUNCT-1K1 m <XXREAL-0R3 r"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain n1 where
        [ty]:"n1 be NatNAT-1M1" and 
        A6: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 m <XXREAL-0R3 r"
        using A5 sorry
      obtain n where 
        [ty]:"n be setHIDDENM2" and nDef:"n = n1 +XCMPLX-0K2 k"
         sorry
      show " ex n be setHIDDENM2 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  not seq .FUNCT-1K1 m <XXREAL-0R3 r"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "n <=XXREAL-0R1 m"
        then obtain n2 where
          [ty]:"n2 be NatNAT-1M1" and 
          A7: "m =COMPLEX1R1 n +XCMPLX-0K2 n2"
          using nat_1_th_10 sorry
        have 
          [ty]:"n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have A8: "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n1 +NAT-1K1 n2) <XXREAL-0R3 r"
          using A6 nat_1_th_12 sorry
        have "(n1 +NAT-1K1 n2)+XCMPLX-0K2 k =COMPLEX1R1 m"
          using A7 sorry
        thus " not seq .FUNCT-1K1 m <XXREAL-0R3 r"
          using A8 nat_1_def_3 sorry
      qed "sorry"
    qed "sorry"
    thus "seq be divergent-to-inftyLIMFUNC1V2"
      using limfunc1_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_8:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq1 be divergent-to+inftyLIMFUNC1V1 & seq2 be divergent-to+inftyLIMFUNC1V1 implies seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to+inftyLIMFUNC1V1"
proof-
  have " for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq1 be divergent-to+inftyLIMFUNC1V1 & seq2 be divergent-to+inftyLIMFUNC1V1 implies seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to+inftyLIMFUNC1V1"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Real-SequenceSEQ-1M1"
    assume A1: "seq1 be divergent-to+inftyLIMFUNC1V1"
      and A2: "seq2 be divergent-to+inftyLIMFUNC1V1"
    have " for r be RealXREAL-0M1 holds  ex tVar8 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar8 <=XXREAL-0R1 m implies  not r <XXREAL-0R3 (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2).FUNCT-1K1 m"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain n1 where
        [ty]:"n1 be NatNAT-1M1" and 
        A3: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 seq1 .FUNCT-1K1 m"
        using A1 sorry
      obtain n2 where
        [ty]:"n2 be NatNAT-1M1" and 
        A4: " for m be NatNAT-1M1 holds n2 <=XXREAL-0R1 m implies r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 seq2 .FUNCT-1K1 m"
        using A2 sorry
      obtain n where 
        [ty]:"n be NatNAT-1M1" and nDef:"n = maxXXREAL-0K5(n1,n2)"
        using tarski_th_1 sorry
      show " ex tVar8 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar8 <=XXREAL-0R1 m implies  not r <XXREAL-0R3 (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2).FUNCT-1K1 m"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume A5: "n <=XXREAL-0R1 m"
        have "n2 <=XXREAL-0R1 n"
          using xxreal_0_th_25 sorry
        then have "n2 <=XXREAL-0R1 m"
          using A5 xxreal_0_th_2 sorry
        then have A6: "r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 seq2 .FUNCT-1K1 m"
          using A4 sorry
        have "n1 <=XXREAL-0R1 n"
          using xxreal_0_th_25 sorry
        then have "n1 <=XXREAL-0R1 m"
          using A5 xxreal_0_th_2 sorry
        then have "r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 seq1 .FUNCT-1K1 m"
          using A3 sorry
        then have "r /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 seq1 .FUNCT-1K1 m +XCMPLX-0K2 seq2 .FUNCT-1K1 m"
          using A6 xreal_1_th_8 sorry
        thus " not r <XXREAL-0R3 (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2).FUNCT-1K1 m"
          using seq_1_th_7 sorry
      qed "sorry"
    qed "sorry"
    thus "seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to+inftyLIMFUNC1V1"
      using limfunc1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_9:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq1 be divergent-to+inftyLIMFUNC1V1 & seq2 be bounded-belowSEQ-2V4 implies seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to+inftyLIMFUNC1V1"
proof-
  have " for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq1 be divergent-to+inftyLIMFUNC1V1 & seq2 be bounded-belowSEQ-2V4 implies seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to+inftyLIMFUNC1V1"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Real-SequenceSEQ-1M1"
    assume A1: "seq1 be divergent-to+inftyLIMFUNC1V1"
      and A2: "seq2 be bounded-belowSEQ-2V4"
    have " for r be RealXREAL-0M1 holds  ex tVar9 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar9 <=XXREAL-0R1 m implies  not r <XXREAL-0R3 (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2).FUNCT-1K1 m"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain M where
        [ty]:"M be RealXREAL-0M1" and 
        A3: " for n be NatNAT-1M1 holds M <XXREAL-0R3 seq2 .FUNCT-1K1 n"
        using A2 sorry
      obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A4: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies r -XCMPLX-0K6 M <XXREAL-0R3 seq1 .FUNCT-1K1 m"
        using A1 sorry
      show " ex tVar9 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar9 <=XXREAL-0R1 m implies  not r <XXREAL-0R3 (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2).FUNCT-1K1 m"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "n <=XXREAL-0R1 m"
        then have "r -XCMPLX-0K6 M <XXREAL-0R3 seq1 .FUNCT-1K1 m"
          using A4 sorry
        then have "(r -XCMPLX-0K6 M)+XCMPLX-0K2 M <XXREAL-0R3 seq1 .FUNCT-1K1 m +XCMPLX-0K2 seq2 .FUNCT-1K1 m"
          using A3 xreal_1_th_8 sorry
        thus " not r <XXREAL-0R3 (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2).FUNCT-1K1 m"
          using seq_1_th_7 sorry
      qed "sorry"
    qed "sorry"
    thus "seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to+inftyLIMFUNC1V1"
      using limfunc1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_10:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq1 be divergent-to+inftyLIMFUNC1V1 & seq2 be divergent-to+inftyLIMFUNC1V1 implies seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to+inftyLIMFUNC1V1"
proof-
  have " for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq1 be divergent-to+inftyLIMFUNC1V1 & seq2 be divergent-to+inftyLIMFUNC1V1 implies seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to+inftyLIMFUNC1V1"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Real-SequenceSEQ-1M1"
    assume A1: "seq1 be divergent-to+inftyLIMFUNC1V1"
      and A2: "seq2 be divergent-to+inftyLIMFUNC1V1"
    have " for r be RealXREAL-0M1 holds  ex tVar10 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar10 <=XXREAL-0R1 m implies  not r <XXREAL-0R3 (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2).FUNCT-1K1 m"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain n1 where
        [ty]:"n1 be NatNAT-1M1" and 
        A3: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies sqrtSQUARE-1K3 ( |.COMPLEX1K10 r.|) <XXREAL-0R3 seq1 .FUNCT-1K1 m"
        using A1 sorry
      obtain n2 where
        [ty]:"n2 be NatNAT-1M1" and 
        A4: " for m be NatNAT-1M1 holds n2 <=XXREAL-0R1 m implies sqrtSQUARE-1K3 ( |.COMPLEX1K10 r.|) <XXREAL-0R3 seq2 .FUNCT-1K1 m"
        using A2 sorry
      obtain n where 
        [ty]:"n be NatNAT-1M1" and nDef:"n = maxXXREAL-0K5(n1,n2)"
        using tarski_th_1 sorry
      show " ex tVar10 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar10 <=XXREAL-0R1 m implies  not r <XXREAL-0R3 (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2).FUNCT-1K1 m"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume A5: "n <=XXREAL-0R1 m"
        have "n2 <=XXREAL-0R1 n"
          using xxreal_0_th_25 sorry
        then have "n2 <=XXREAL-0R1 m"
          using A5 xxreal_0_th_2 sorry
        then have A6: "sqrtSQUARE-1K3 ( |.COMPLEX1K10 r.|) <XXREAL-0R3 seq2 .FUNCT-1K1 m"
          using A4 sorry
        have "n1 <=XXREAL-0R1 n"
          using xxreal_0_th_25 sorry
        then have "n1 <=XXREAL-0R1 m"
          using A5 xxreal_0_th_2 sorry
        then have A7: "sqrtSQUARE-1K3 ( |.COMPLEX1K10 r.|) <XXREAL-0R3 seq1 .FUNCT-1K1 m"
          using A3 sorry
        have A8: " |.COMPLEX1K10 r.| >=XXREAL-0R2 0NUMBERSK6"
          using complex1_th_46 sorry
        then have "sqrtSQUARE-1K3 ( |.COMPLEX1K10 r.|) >=XXREAL-0R2 0NUMBERSK6"
          using square_1_def_2 sorry
        then have "(sqrtSQUARE-1K3 ( |.COMPLEX1K10 r.|))^2SQUARE-1K1 <XXREAL-0R3 seq1 .FUNCT-1K1 m *XCMPLX-0K3 seq2 .FUNCT-1K1 m"
          using A7 A6 xreal_1_th_96 sorry
        then have A9: " |.COMPLEX1K10 r.| <XXREAL-0R3 seq1 .FUNCT-1K1 m *XCMPLX-0K3 seq2 .FUNCT-1K1 m"
          using A8 square_1_def_2 sorry
        have "r <=XXREAL-0R1  |.COMPLEX1K10 r.|"
          using absvalue_th_4 sorry
        then have "r <XXREAL-0R3 seq1 .FUNCT-1K1 m *XCMPLX-0K3 seq2 .FUNCT-1K1 m"
          using A9 xxreal_0_th_2 sorry
        thus " not r <XXREAL-0R3 (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2).FUNCT-1K1 m"
          using seq_1_th_8 sorry
      qed "sorry"
    qed "sorry"
    thus "seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to+inftyLIMFUNC1V1"
      using limfunc1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_11:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq1 be divergent-to-inftyLIMFUNC1V2 & seq2 be divergent-to-inftyLIMFUNC1V2 implies seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to-inftyLIMFUNC1V2"
proof-
  have " for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq1 be divergent-to-inftyLIMFUNC1V2 & seq2 be divergent-to-inftyLIMFUNC1V2 implies seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to-inftyLIMFUNC1V2"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Real-SequenceSEQ-1M1"
    assume A1: "seq1 be divergent-to-inftyLIMFUNC1V2"
      and A2: "seq2 be divergent-to-inftyLIMFUNC1V2"
    have " for r be RealXREAL-0M1 holds  ex tVar11 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar11 <=XXREAL-0R1 m implies  not (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2).FUNCT-1K1 m <XXREAL-0R3 r"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain n1 where
        [ty]:"n1 be NatNAT-1M1" and 
        A3: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies seq1 .FUNCT-1K1 m <XXREAL-0R3 r /XCMPLX-0K7 \<two>\<^sub>M"
        using A1 sorry
      obtain n2 where
        [ty]:"n2 be NatNAT-1M1" and 
        A4: " for m be NatNAT-1M1 holds n2 <=XXREAL-0R1 m implies seq2 .FUNCT-1K1 m <XXREAL-0R3 r /XCMPLX-0K7 \<two>\<^sub>M"
        using A2 sorry
      obtain n where 
        [ty]:"n be NatNAT-1M1" and nDef:"n = maxXXREAL-0K5(n1,n2)"
        using tarski_th_1 sorry
      show " ex tVar11 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar11 <=XXREAL-0R1 m implies  not (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2).FUNCT-1K1 m <XXREAL-0R3 r"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume A5: "n <=XXREAL-0R1 m"
        have "n2 <=XXREAL-0R1 n"
          using xxreal_0_th_25 sorry
        then have "n2 <=XXREAL-0R1 m"
          using A5 xxreal_0_th_2 sorry
        then have A6: "seq2 .FUNCT-1K1 m <XXREAL-0R3 r /XCMPLX-0K7 \<two>\<^sub>M"
          using A4 sorry
        have "n1 <=XXREAL-0R1 n"
          using xxreal_0_th_25 sorry
        then have "n1 <=XXREAL-0R1 m"
          using A5 xxreal_0_th_2 sorry
        then have "seq1 .FUNCT-1K1 m <XXREAL-0R3 r /XCMPLX-0K7 \<two>\<^sub>M"
          using A3 sorry
        then have "seq1 .FUNCT-1K1 m +XCMPLX-0K2 seq2 .FUNCT-1K1 m <XXREAL-0R3 r /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
          using A6 xreal_1_th_8 sorry
        thus " not (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2).FUNCT-1K1 m <XXREAL-0R3 r"
          using seq_1_th_7 sorry
      qed "sorry"
    qed "sorry"
    thus "seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to-inftyLIMFUNC1V2"
      using limfunc1_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_12:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq1 be divergent-to-inftyLIMFUNC1V2 & seq2 be bounded-aboveSEQ-2V3 implies seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to-inftyLIMFUNC1V2"
proof-
  have " for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq1 be divergent-to-inftyLIMFUNC1V2 & seq2 be bounded-aboveSEQ-2V3 implies seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to-inftyLIMFUNC1V2"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Real-SequenceSEQ-1M1"
    assume A1: "seq1 be divergent-to-inftyLIMFUNC1V2"
      and A2: "seq2 be bounded-aboveSEQ-2V3"
    have " for r be RealXREAL-0M1 holds  ex tVar12 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar12 <=XXREAL-0R1 m implies  not (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2).FUNCT-1K1 m <XXREAL-0R3 r"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain M where
        [ty]:"M be RealXREAL-0M1" and 
        A3: " for n be NatNAT-1M1 holds seq2 .FUNCT-1K1 n <XXREAL-0R3 M"
        using A2 sorry
      obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A4: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq1 .FUNCT-1K1 m <XXREAL-0R3 r -XCMPLX-0K6 M"
        using A1 sorry
      show " ex tVar12 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar12 <=XXREAL-0R1 m implies  not (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2).FUNCT-1K1 m <XXREAL-0R3 r"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "n <=XXREAL-0R1 m"
        then have "seq1 .FUNCT-1K1 m <XXREAL-0R3 r -XCMPLX-0K6 M"
          using A4 sorry
        then have "seq1 .FUNCT-1K1 m +XCMPLX-0K2 seq2 .FUNCT-1K1 m <XXREAL-0R3 (r -XCMPLX-0K6 M)+XCMPLX-0K2 M"
          using A3 xreal_1_th_8 sorry
        thus " not (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2).FUNCT-1K1 m <XXREAL-0R3 r"
          using seq_1_th_7 sorry
      qed "sorry"
    qed "sorry"
    thus "seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to-inftyLIMFUNC1V2"
      using limfunc1_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma limfunc1_lm_4:
"0NUMBERSK6 inTARSKIR2 REALNUMBERSK2"
  using xreal_0_def_1 sorry

mtheorem limfunc1_th_13:
" for seq be Real-SequenceSEQ-1M1 holds  for r be RealXREAL-0M1 holds ((seq be divergent-to+inftyLIMFUNC1V1 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1) & (seq be divergent-to+inftyLIMFUNC1V1 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2)) & (r =COMPLEX1R1 0NUMBERSK6 implies rngFUNCT-1K2 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq) =XBOOLE-0R4 {TARSKIK1 0NUMBERSK6 } & r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be constantVALUED-0V15)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for r be RealXREAL-0M1 holds (seq be divergent-to+inftyLIMFUNC1V1 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1) & ((seq be divergent-to+inftyLIMFUNC1V1 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2) & (r =COMPLEX1R1 0NUMBERSK6 implies rngFUNCT-1K2 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq) =XBOOLE-0R4 {TARSKIK1 0NUMBERSK6 } & r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be constantVALUED-0V15))"
  proof(rule ballI,rule ballI,rule conjMI,rule conjMI,rule impI,rule conjMI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    show "seq be divergent-to+inftyLIMFUNC1V1 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
    proof(rule impMI ,rule impI)
      assume A1: "seq be divergent-to+inftyLIMFUNC1V1"
        and A2: "r >XXREAL-0R4 0NUMBERSK6"
      have " for g be RealXREAL-0M1 holds  ex tVar13 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar13 <=XXREAL-0R1 m implies  not g <XXREAL-0R3 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 m"
      proof(rule ballI)
        fix g assume [ty]: "g be RealXREAL-0M1"
        obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A3: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies g /XCMPLX-0K7 r <XXREAL-0R3 seq .FUNCT-1K1 m"
          using A1 sorry
        show " ex tVar13 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar13 <=XXREAL-0R1 m implies  not g <XXREAL-0R3 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 m"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          assume "n <=XXREAL-0R1 m"
          then have "g /XCMPLX-0K7 r <XXREAL-0R3 seq .FUNCT-1K1 m"
            using A3 sorry
          then have "(g /XCMPLX-0K7 r)*XCMPLX-0K3 r <XXREAL-0R3 r *XCMPLX-0K3 seq .FUNCT-1K1 m"
            using A2 xreal_1_th_68 sorry
          then have "g <XXREAL-0R3 r *XCMPLX-0K3 seq .FUNCT-1K1 m"
            using A2 xcmplx_1_th_87 sorry
          thus " not g <XXREAL-0R3 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 m"
            using seq_1_th_9 sorry
        qed "sorry"
      qed "sorry"
      thus "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
        using limfunc1_def_4 sorry
    qed
    show "seq be divergent-to+inftyLIMFUNC1V1 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
    proof(rule impMI ,rule impI)
      assume A4: "seq be divergent-to+inftyLIMFUNC1V1"
        and A5: "r <XXREAL-0R3 0NUMBERSK6"
      have " for g be RealXREAL-0M1 holds  ex tVar14 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar14 <=XXREAL-0R1 m implies  not (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 m <XXREAL-0R3 g"
      proof(rule ballI)
        fix g assume [ty]: "g be RealXREAL-0M1"
        obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A6: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies g /XCMPLX-0K7 r <XXREAL-0R3 seq .FUNCT-1K1 m"
          using A4 sorry
        show " ex tVar14 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar14 <=XXREAL-0R1 m implies  not (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 m <XXREAL-0R3 g"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          assume "n <=XXREAL-0R1 m"
          then have "g /XCMPLX-0K7 r <XXREAL-0R3 seq .FUNCT-1K1 m"
            using A6 sorry
          then have "r *XCMPLX-0K3 seq .FUNCT-1K1 m <XXREAL-0R3 (g /XCMPLX-0K7 r)*XCMPLX-0K3 r"
            using A5 xreal_1_th_69 sorry
          then have "r *XCMPLX-0K3 seq .FUNCT-1K1 m <XXREAL-0R3 g"
            using A5 xcmplx_1_th_87 sorry
          thus " not (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 m <XXREAL-0R3 g"
            using seq_1_th_9 sorry
        qed "sorry"
      qed "sorry"
      thus "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
        using limfunc1_def_5 sorry
    qed
    assume A7: "r =COMPLEX1R1 0NUMBERSK6"
    show "rngFUNCT-1K2 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq) =XBOOLE-0R4 {TARSKIK1 0NUMBERSK6 }"
    proof-
      have " for x be RealXREAL-0M1 holds (x inHIDDENR3 rngFUNCT-1K2 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq) implies x inHIDDENR3 {TARSKIK1 0NUMBERSK6 }) & (x inHIDDENR3 {TARSKIK1 0NUMBERSK6 } implies x inHIDDENR3 rngFUNCT-1K2 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq))"
      proof(rule ballI,rule conjMI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        show "x inHIDDENR3 rngFUNCT-1K2 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq) implies x inHIDDENR3 {TARSKIK1 0NUMBERSK6 }"
        proof(rule impI)
          assume "x inHIDDENR3 rngFUNCT-1K2 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)"
          then obtain n where
            [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
            A8: "x =COMPLEX1R1 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
            using funct_2_th_113 sorry
          have "x =HIDDENR1 r *XCMPLX-0K3 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
            using A8 seq_1_th_9 sorry
          also have "... = 0NUMBERSK6"
            using A7 sorry
          finally have "x =HIDDENR1 0NUMBERSK6"
             sorry
          thus "x inHIDDENR3 {TARSKIK1 0NUMBERSK6 }"
            using tarski_def_1 sorry
        qed
        assume "x inHIDDENR3 {TARSKIK1 0NUMBERSK6 }"
        then have A9: "x =COMPLEX1R1 0NUMBERSK6"
          using tarski_def_1 sorry
        have "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 r *XCMPLX-0K3 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
          using seq_1_th_9 sorry
        also have "... = 0NUMBERSK6"
          using A7 sorry
        finally have "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 0NUMBERSK6"
           sorry
        thus "x inHIDDENR3 rngFUNCT-1K2 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)"
          using A9 valued_0_th_28 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq) =XBOOLE-0R4 {TARSKIK1 0NUMBERSK6 }"
        using membered_def_15 sorry
    qed
    thus "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be constantVALUED-0V15"
      using funct_2_th_111 limfunc1_lm_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_14:
" for seq be Real-SequenceSEQ-1M1 holds  for r be RealXREAL-0M1 holds ((seq be divergent-to-inftyLIMFUNC1V2 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2) & (seq be divergent-to-inftyLIMFUNC1V2 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1)) & (r =COMPLEX1R1 0NUMBERSK6 implies rngFUNCT-1K2 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq) =XBOOLE-0R4 {TARSKIK1 0NUMBERSK6 } & r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be constantVALUED-0V15)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for r be RealXREAL-0M1 holds (seq be divergent-to-inftyLIMFUNC1V2 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2) & ((seq be divergent-to-inftyLIMFUNC1V2 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1) & (r =COMPLEX1R1 0NUMBERSK6 implies rngFUNCT-1K2 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq) =XBOOLE-0R4 {TARSKIK1 0NUMBERSK6 } & r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be constantVALUED-0V15))"
  proof(rule ballI,rule ballI,rule conjMI,rule conjMI,rule impI,rule conjMI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    show "seq be divergent-to-inftyLIMFUNC1V2 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
    proof(rule impMI ,rule impI)
      assume A1: "seq be divergent-to-inftyLIMFUNC1V2"
        and A2: "r >XXREAL-0R4 0NUMBERSK6"
      have " for g be RealXREAL-0M1 holds  ex tVar15 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar15 <=XXREAL-0R1 m implies  not (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 m <XXREAL-0R3 g"
      proof(rule ballI)
        fix g assume [ty]: "g be RealXREAL-0M1"
        obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A3: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .FUNCT-1K1 m <XXREAL-0R3 g /XCMPLX-0K7 r"
          using A1 sorry
        show " ex tVar15 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar15 <=XXREAL-0R1 m implies  not (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 m <XXREAL-0R3 g"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          assume "n <=XXREAL-0R1 m"
          then have "seq .FUNCT-1K1 m <XXREAL-0R3 g /XCMPLX-0K7 r"
            using A3 sorry
          then have "r *XCMPLX-0K3 seq .FUNCT-1K1 m <XXREAL-0R3 (g /XCMPLX-0K7 r)*XCMPLX-0K3 r"
            using A2 xreal_1_th_68 sorry
          then have "r *XCMPLX-0K3 seq .FUNCT-1K1 m <XXREAL-0R3 g"
            using A2 xcmplx_1_th_87 sorry
          thus " not (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 m <XXREAL-0R3 g"
            using seq_1_th_9 sorry
        qed "sorry"
      qed "sorry"
      thus "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
        using limfunc1_def_5 sorry
    qed
    show "seq be divergent-to-inftyLIMFUNC1V2 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
    proof(rule impMI ,rule impI)
      assume A4: "seq be divergent-to-inftyLIMFUNC1V2"
        and A5: "r <XXREAL-0R3 0NUMBERSK6"
      have " for g be RealXREAL-0M1 holds  ex tVar16 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar16 <=XXREAL-0R1 m implies  not g <XXREAL-0R3 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 m"
      proof(rule ballI)
        fix g assume [ty]: "g be RealXREAL-0M1"
        obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A6: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .FUNCT-1K1 m <XXREAL-0R3 g /XCMPLX-0K7 r"
          using A4 sorry
        show " ex tVar16 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar16 <=XXREAL-0R1 m implies  not g <XXREAL-0R3 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 m"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          assume "n <=XXREAL-0R1 m"
          then have "seq .FUNCT-1K1 m <XXREAL-0R3 g /XCMPLX-0K7 r"
            using A6 sorry
          then have "(g /XCMPLX-0K7 r)*XCMPLX-0K3 r <XXREAL-0R3 r *XCMPLX-0K3 seq .FUNCT-1K1 m"
            using A5 xreal_1_th_69 sorry
          then have "g <XXREAL-0R3 r *XCMPLX-0K3 seq .FUNCT-1K1 m"
            using A5 xcmplx_1_th_87 sorry
          thus " not g <XXREAL-0R3 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 m"
            using seq_1_th_9 sorry
        qed "sorry"
      qed "sorry"
      thus "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
        using limfunc1_def_4 sorry
    qed
    assume A7: "r =COMPLEX1R1 0NUMBERSK6"
    show "rngFUNCT-1K2 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq) =XBOOLE-0R4 {TARSKIK1 0NUMBERSK6 }"
    proof-
      have " for x be RealXREAL-0M1 holds (x inHIDDENR3 rngFUNCT-1K2 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq) implies x inHIDDENR3 {TARSKIK1 0NUMBERSK6 }) & (x inHIDDENR3 {TARSKIK1 0NUMBERSK6 } implies x inHIDDENR3 rngFUNCT-1K2 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq))"
      proof(rule ballI,rule conjMI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        show "x inHIDDENR3 rngFUNCT-1K2 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq) implies x inHIDDENR3 {TARSKIK1 0NUMBERSK6 }"
        proof(rule impI)
          assume "x inHIDDENR3 rngFUNCT-1K2 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)"
          then obtain n where
            [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
            A8: "x =COMPLEX1R1 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
            using funct_2_th_113 sorry
          have "x =HIDDENR1 r *XCMPLX-0K3 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
            using A8 seq_1_th_9 sorry
          also have "... = 0NUMBERSK6"
            using A7 sorry
          finally have "x =HIDDENR1 0NUMBERSK6"
             sorry
          thus "x inHIDDENR3 {TARSKIK1 0NUMBERSK6 }"
            using tarski_def_1 sorry
        qed
        assume "x inHIDDENR3 {TARSKIK1 0NUMBERSK6 }"
        then have A9: "x =COMPLEX1R1 0NUMBERSK6"
          using tarski_def_1 sorry
        have "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 r *XCMPLX-0K3 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
          using seq_1_th_9 sorry
        also have "... = 0NUMBERSK6"
          using A7 sorry
        finally have "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 0NUMBERSK6"
           sorry
        thus "x inHIDDENR3 rngFUNCT-1K2 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)"
          using A9 valued_0_th_28 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq) =XBOOLE-0R4 {TARSKIK1 0NUMBERSK6 }"
        using membered_def_15 sorry
    qed
    thus "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be constantVALUED-0V15"
      using funct_2_th_111 limfunc1_lm_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_15:
" for seq be Real-SequenceSEQ-1M1 holds (seq be divergent-to+inftyLIMFUNC1V1 implies -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2) & (seq be divergent-to-inftyLIMFUNC1V2 implies -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1)"
  using limfunc1_th_13 limfunc1_th_14 sorry

mtheorem limfunc1_th_16:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be bounded-belowSEQ-2V4 & seq1 be divergent-to-inftyLIMFUNC1V2 implies seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be divergent-to+inftyLIMFUNC1V1"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be bounded-belowSEQ-2V4 & seq1 be divergent-to-inftyLIMFUNC1V2 implies seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be divergent-to+inftyLIMFUNC1V1"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    assume A1: "seq be bounded-belowSEQ-2V4"
      and A2: "seq1 be divergent-to-inftyLIMFUNC1V2"
    have "(-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 be divergent-to+inftyLIMFUNC1V1"
      using A2 limfunc1_th_14 sorry
    thus "seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be divergent-to+inftyLIMFUNC1V1"
      using A1 limfunc1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_17:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be bounded-aboveSEQ-2V3 & seq1 be divergent-to+inftyLIMFUNC1V1 implies seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be divergent-to-inftyLIMFUNC1V2"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be bounded-aboveSEQ-2V3 & seq1 be divergent-to+inftyLIMFUNC1V1 implies seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be divergent-to-inftyLIMFUNC1V2"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    assume A1: "seq be bounded-aboveSEQ-2V3"
      and A2: "seq1 be divergent-to+inftyLIMFUNC1V1"
    have "(-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 be divergent-to-inftyLIMFUNC1V2"
      using A2 limfunc1_th_13 sorry
    thus "seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be divergent-to-inftyLIMFUNC1V2"
      using A1 limfunc1_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_18:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & seq1 be convergentSEQ-2V5 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be divergent-to+inftyLIMFUNC1V1"
  using limfunc1_th_9 sorry

mtheorem limfunc1_th_19:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & seq1 be convergentSEQ-2V5 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be divergent-to-inftyLIMFUNC1V2"
  using limfunc1_th_12 sorry

mtheorem limfunc1_th_20:
" for seq be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 n) implies seq be divergent-to+inftyLIMFUNC1V1"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 n) implies seq be divergent-to+inftyLIMFUNC1V1"
  proof(rule ballI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: " for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 n"
    have " for r be RealXREAL-0M1 holds  ex tVar17 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar17 <=XXREAL-0R1 m implies  not r <XXREAL-0R3 seq .FUNCT-1K1 m"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A2: "r <XXREAL-0R3 n"
        using seq_4_th_3 sorry
      show " ex tVar17 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar17 <=XXREAL-0R1 m implies  not r <XXREAL-0R3 seq .FUNCT-1K1 m"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "n <=XXREAL-0R1 m"
        then have "r <XXREAL-0R3 m"
          using A2 xxreal_0_th_2 sorry
        thus " not r <XXREAL-0R3 seq .FUNCT-1K1 m"
          using A1 sorry
      qed "sorry"
    qed "sorry"
    thus "seq be divergent-to+inftyLIMFUNC1V1"
      using limfunc1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma limfunc1_lm_5:
" for n be NatNAT-1M1 holds idPARTFUN1K6 NATNUMBERSK1 .RECDEF-1K1 n =COMPLEX1R1 n"
  using ordinal1_def_12 funct_1_th_18 sorry

mtheorem limfunc1_th_21:
" for seq be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 -XCMPLX-0K4 n) implies seq be divergent-to-inftyLIMFUNC1V2"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 -XCMPLX-0K4 n) implies seq be divergent-to-inftyLIMFUNC1V2"
  proof(rule ballI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: " for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 -XCMPLX-0K4 n"
    obtain s1 where 
      [ty]:"s1 be Real-SequenceSEQ-1M1" and s1Def:"s1 = idPARTFUN1K6 NATNUMBERSK1"
      using funct_2_th_7 numbers_th_19 sorry
    have A2: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> s1).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> s1).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 -REAL-1K1 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_10 sorry
      also have "... = -XCMPLX-0K4 n"
         sorry
      also have "... = seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using A1 sorry
      finally show "(-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> s1).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    have "s1 be divergent-to+inftyLIMFUNC1V1"
      using limfunc1_lm_5 limfunc1_th_20 sorry
    then have "(-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> s1 be divergent-to-inftyLIMFUNC1V2"
      using limfunc1_th_13 sorry
    thus "seq be divergent-to-inftyLIMFUNC1V2"
      using A2 funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_22:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq1 be divergent-to+inftyLIMFUNC1V1 & ( ex r be RealXREAL-0M1 st r >XXREAL-0R4 0NUMBERSK6 & ( for n be NatNAT-1M1 holds seq2 .FUNCT-1K1 n >=XXREAL-0R2 r)) implies seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to+inftyLIMFUNC1V1"
proof-
  have " for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq1 be divergent-to+inftyLIMFUNC1V1 & ( ex r be RealXREAL-0M1 st r >XXREAL-0R4 0NUMBERSK6 & ( for n be NatNAT-1M1 holds seq2 .FUNCT-1K1 n >=XXREAL-0R2 r)) implies seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to+inftyLIMFUNC1V1"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Real-SequenceSEQ-1M1"
    assume A1: "seq1 be divergent-to+inftyLIMFUNC1V1"
      and A2: " ex r be RealXREAL-0M1 st r >XXREAL-0R4 0NUMBERSK6 & ( for n be NatNAT-1M1 holds seq2 .FUNCT-1K1 n >=XXREAL-0R2 r)"
    obtain M where
      [ty]:"M be RealXREAL-0M1" and 
      A3: "M >XXREAL-0R4 0NUMBERSK6"and A4: " for n be NatNAT-1M1 holds seq2 .FUNCT-1K1 n >=XXREAL-0R2 M"
      using A2 sorry
    have " for r be RealXREAL-0M1 holds  ex tVar18 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar18 <=XXREAL-0R1 m implies  not r <XXREAL-0R3 (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2).FUNCT-1K1 m"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      have A5: "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r.|"
        using complex1_th_46 sorry
      obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A6: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies ( |.COMPLEX1K10 r.|)/XCMPLX-0K7 M <XXREAL-0R3 seq1 .FUNCT-1K1 m"
        using A1 sorry
      show " ex tVar18 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar18 <=XXREAL-0R1 m implies  not r <XXREAL-0R3 (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2).FUNCT-1K1 m"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "n <=XXREAL-0R1 m"
        then have "( |.COMPLEX1K10 r.|)/XCMPLX-0K7 M <XXREAL-0R3 seq1 .FUNCT-1K1 m"
          using A6 sorry
        then have "(( |.COMPLEX1K10 r.|)/XCMPLX-0K7 M)*XCMPLX-0K3 M <XXREAL-0R3 seq1 .FUNCT-1K1 m *XCMPLX-0K3 seq2 .FUNCT-1K1 m"
          using A3 A4 A5 xreal_1_th_97 sorry
        then have A7: " |.COMPLEX1K10 r.| <XXREAL-0R3 seq1 .FUNCT-1K1 m *XCMPLX-0K3 seq2 .FUNCT-1K1 m"
          using A3 xcmplx_1_th_87 sorry
        have "r <=XXREAL-0R1  |.COMPLEX1K10 r.|"
          using absvalue_th_4 sorry
        then have "r <XXREAL-0R3 seq1 .FUNCT-1K1 m *XCMPLX-0K3 seq2 .FUNCT-1K1 m"
          using A7 xxreal_0_th_2 sorry
        thus " not r <XXREAL-0R3 (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2).FUNCT-1K1 m"
          using seq_1_th_8 sorry
      qed "sorry"
    qed "sorry"
    thus "seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to+inftyLIMFUNC1V1"
      using limfunc1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_23:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq1 be divergent-to-inftyLIMFUNC1V2 & ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for n be NatNAT-1M1 holds seq2 .FUNCT-1K1 n >=XXREAL-0R2 r)) implies seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to-inftyLIMFUNC1V2"
proof-
  have " for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq1 be divergent-to-inftyLIMFUNC1V2 & ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for n be NatNAT-1M1 holds seq2 .FUNCT-1K1 n >=XXREAL-0R2 r)) implies seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to-inftyLIMFUNC1V2"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Real-SequenceSEQ-1M1"
    assume A1: "seq1 be divergent-to-inftyLIMFUNC1V2"
      and A2: " ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for n be NatNAT-1M1 holds seq2 .FUNCT-1K1 n >=XXREAL-0R2 r)"
    have "(-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 be divergent-to+inftyLIMFUNC1V1"
      using A1 limfunc1_th_14 sorry
    then have A3: "((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to+inftyLIMFUNC1V1"
      using A2 limfunc1_th_22 sorry
    have "(-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2) =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2))"
      using seq_1_th_18 sorry
    also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M))(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)"
      using seq_1_th_23 sorry
    also have "... = seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2"
      using seq_1_th_27 sorry
    finally have "(-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2) =HIDDENR1 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2"
       sorry
    thus "seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to-inftyLIMFUNC1V2"
      using A3 limfunc1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_24:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq1 be divergent-to-inftyLIMFUNC1V2 & seq2 be divergent-to-inftyLIMFUNC1V2 implies seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to+inftyLIMFUNC1V1"
proof-
  have " for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq1 be divergent-to-inftyLIMFUNC1V2 & seq2 be divergent-to-inftyLIMFUNC1V2 implies seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to+inftyLIMFUNC1V1"
  proof(rule ballI,rule ballI,rule impI)
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Real-SequenceSEQ-1M1"
    assume "seq1 be divergent-to-inftyLIMFUNC1V2 & seq2 be divergent-to-inftyLIMFUNC1V2"
    then have A1: "(-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 be divergent-to+inftyLIMFUNC1V1 & (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2 be divergent-to+inftyLIMFUNC1V1"
      using limfunc1_th_14 sorry
    have "((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2) =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2))"
      using seq_1_th_18 sorry
    also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2))"
      using seq_1_th_19 sorry
    also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M))(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)"
      using seq_1_th_23 sorry
    also have "... = seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2"
      using seq_1_th_27 sorry
    finally have "((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2) =HIDDENR1 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2"
       sorry
    thus "seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to+inftyLIMFUNC1V1"
      using A1 limfunc1_th_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_25:
" for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 or seq be divergent-to-inftyLIMFUNC1V2 implies absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 or seq be divergent-to-inftyLIMFUNC1V2 implies absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
  proof(rule ballI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq be divergent-to+inftyLIMFUNC1V1 or seq be divergent-to-inftyLIMFUNC1V2"
    have " for r be RealXREAL-0M1 holds  not ( for n be NatNAT-1M1 holds  not ( for m be NatNAT-1M1 holds  not (n <=XXREAL-0R1 m & r <XXREAL-0R3 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq .FUNCT-1K1 m)))"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      have " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies r <XXREAL-0R3 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq .FUNCT-1K1 m"
      proof-
        show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies r <XXREAL-0R3 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq .FUNCT-1K1 m"
        proof-
          have cases: "seq be divergent-to+inftyLIMFUNC1V1 or seq be divergent-to-inftyLIMFUNC1V2"
            using A1 sorry
          have case1: "seq be divergent-to+inftyLIMFUNC1V1 implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies r <XXREAL-0R3 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq .FUNCT-1K1 m)"
          proof(rule impI)
            assume "seq be divergent-to+inftyLIMFUNC1V1"
            then obtain n where
              [ty]:"n be NatNAT-1M1" and 
              A2: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 r.| <XXREAL-0R3 seq .FUNCT-1K1 m"
               sorry
            show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies r <XXREAL-0R3 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq .FUNCT-1K1 m"
            proof(rule bexI[of _ "n"],rule ballI,rule impI)
              fix m assume [ty]: "m be NatNAT-1M1"
              assume "n <=XXREAL-0R1 m"
              then have "r <=XXREAL-0R1  |.COMPLEX1K10 r.| &  |.COMPLEX1K10 r.| <XXREAL-0R3 seq .FUNCT-1K1 m"
                using A2 absvalue_th_4 sorry
              then have A3: "r <XXREAL-0R3 seq .FUNCT-1K1 m"
                using xxreal_0_th_2 sorry
              have "seq .FUNCT-1K1 m <=XXREAL-0R1  |.COMPLEX1K10 seq .FUNCT-1K1 m.|"
                using absvalue_th_4 sorry
              then have "seq .FUNCT-1K1 m <=XXREAL-0R1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq .FUNCT-1K1 m"
                using seq_1_th_12 sorry
              thus "r <XXREAL-0R3 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq .FUNCT-1K1 m"
                using A3 xxreal_0_th_2 sorry
            qed "sorry"
          qed
          have case2: "seq be divergent-to-inftyLIMFUNC1V2 implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies r <XXREAL-0R3 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq .FUNCT-1K1 m)"
          proof(rule impI)
            assume "seq be divergent-to-inftyLIMFUNC1V2"
            then obtain n where
              [ty]:"n be NatNAT-1M1" and 
              A4: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .FUNCT-1K1 m <XXREAL-0R3 -XCMPLX-0K4 r"
               sorry
            show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies r <XXREAL-0R3 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq .FUNCT-1K1 m"
            proof(rule bexI[of _ "n"],rule ballI,rule impI)
              fix m assume [ty]: "m be NatNAT-1M1"
              have "-XCMPLX-0K4  |.COMPLEX1K10 seq .FUNCT-1K1 m.| <=XXREAL-0R1 seq .FUNCT-1K1 m"
                using absvalue_th_4 sorry
              then have A5: "-XCMPLX-0K4 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq .FUNCT-1K1 m <=XXREAL-0R1 seq .FUNCT-1K1 m"
                using seq_1_th_12 sorry
              assume "n <=XXREAL-0R1 m"
              then have "seq .FUNCT-1K1 m <XXREAL-0R3 -XCMPLX-0K4 r"
                using A4 sorry
              then have "-XCMPLX-0K4 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq .FUNCT-1K1 m <XXREAL-0R3 -XCMPLX-0K4 r"
                using A5 xxreal_0_th_2 sorry
              thus "r <XXREAL-0R3 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq .FUNCT-1K1 m"
                using xreal_1_th_24 sorry
            qed "sorry"
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus " not ( for n be NatNAT-1M1 holds  not ( for m be NatNAT-1M1 holds  not (n <=XXREAL-0R1 m & r <XXREAL-0R3 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq .FUNCT-1K1 m)))"
         sorry
    qed "sorry"
    thus "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
      using limfunc1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_26:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq implies seq1 be divergent-to+inftyLIMFUNC1V1"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq implies seq1 be divergent-to+inftyLIMFUNC1V1"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    assume A1: "seq be divergent-to+inftyLIMFUNC1V1"
      and A2: "seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq"
    obtain Ns where
      [ty]:"Ns be increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1" and 
      A3: "seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns"
      using A2 valued_0_def_17 sorry
    have " for r be RealXREAL-0M1 holds  ex tVar21 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar21 <=XXREAL-0R1 m implies  not r <XXREAL-0R3 seq1 .FUNCT-1K1 m"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A4: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies r <XXREAL-0R3 seq .FUNCT-1K1 m"
        using A1 sorry
      show " ex tVar21 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar21 <=XXREAL-0R1 m implies  not r <XXREAL-0R3 seq1 .FUNCT-1K1 m"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume A5: "n <=XXREAL-0R1 m"
        have A6: "m inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "m <=XXREAL-0R1 Ns .RECDEF-1K1 m"
          using seqm_3_th_14 sorry
        then have "n <=XXREAL-0R1 Ns .RECDEF-1K1 m"
          using A5 xxreal_0_th_2 sorry
        then have "r <XXREAL-0R3 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (Ns .RECDEF-1K1 m)"
          using A4 sorry
        thus " not r <XXREAL-0R3 seq1 .FUNCT-1K1 m"
          using A3 funct_2_th_15 A6 sorry
      qed "sorry"
    qed "sorry"
    thus "seq1 be divergent-to+inftyLIMFUNC1V1"
      using limfunc1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_27:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq implies seq1 be divergent-to-inftyLIMFUNC1V2"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq implies seq1 be divergent-to-inftyLIMFUNC1V2"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    assume A1: "seq be divergent-to-inftyLIMFUNC1V2"
      and A2: "seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq"
    obtain Ns where
      [ty]:"Ns be increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1" and 
      A3: "seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns"
      using A2 valued_0_def_17 sorry
    have " for r be RealXREAL-0M1 holds  ex tVar22 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar22 <=XXREAL-0R1 m implies  not seq1 .FUNCT-1K1 m <XXREAL-0R3 r"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A4: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .FUNCT-1K1 m <XXREAL-0R3 r"
        using A1 sorry
      show " ex tVar22 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar22 <=XXREAL-0R1 m implies  not seq1 .FUNCT-1K1 m <XXREAL-0R3 r"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume A5: "n <=XXREAL-0R1 m"
        have A6: "m inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "m <=XXREAL-0R1 Ns .RECDEF-1K1 m"
          using seqm_3_th_14 sorry
        then have "n <=XXREAL-0R1 Ns .RECDEF-1K1 m"
          using A5 xxreal_0_th_2 sorry
        then have "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (Ns .RECDEF-1K1 m) <XXREAL-0R3 r"
          using A4 sorry
        thus " not seq1 .FUNCT-1K1 m <XXREAL-0R3 r"
          using A3 funct_2_th_15 A6 sorry
      qed "sorry"
    qed "sorry"
    thus "seq1 be divergent-to-inftyLIMFUNC1V2"
      using limfunc1_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_28:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds (seq1 be divergent-to+inftyLIMFUNC1V1 & seq2 be convergentSEQ-2V5) & 0NUMBERSK6 <XXREAL-0R3 limSEQ-2K1 seq2 implies seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to+inftyLIMFUNC1V1"
proof-
  have " for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq1 be divergent-to+inftyLIMFUNC1V1 & (seq2 be convergentSEQ-2V5 & 0NUMBERSK6 <XXREAL-0R3 limSEQ-2K1 seq2) implies seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to+inftyLIMFUNC1V1"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Real-SequenceSEQ-1M1"
    assume A1: "seq1 be divergent-to+inftyLIMFUNC1V1"
      and A2: "seq2 be convergentSEQ-2V5"
      and A3: "0NUMBERSK6 <XXREAL-0R3 limSEQ-2K1 seq2"
    obtain n1 where
      [ty]:"n1 be NatNAT-1M1" and 
      A4: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies (limSEQ-2K1 seq2)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 seq2 .FUNCT-1K1 m"
      using A2 A3 limfunc1_th_5 sorry
    have "0NUMBERSK6 <XXREAL-0R3 (limSEQ-2K1 seq2)/XCMPLX-0K7 \<two>\<^sub>M & ( for n be NatNAT-1M1 holds (limSEQ-2K1 seq2)/XCMPLX-0K7 \<two>\<^sub>M <=XXREAL-0R1 (seq2 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n1).FUNCT-1K1 n)"
    proof(rule conjMI,rule ballI)
      show "0NUMBERSK6 <XXREAL-0R3 (limSEQ-2K1 seq2)/XCMPLX-0K7 \<two>\<^sub>M"
        using A3 xreal_1_th_215 sorry
      fix n assume [ty]: "n be NatNAT-1M1"
      have "(limSEQ-2K1 seq2)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 seq2 .FUNCT-1K1 (n +XCMPLX-0K2 n1)"
        using A4 nat_1_th_12 sorry
      thus "(limSEQ-2K1 seq2)/XCMPLX-0K7 \<two>\<^sub>M <=XXREAL-0R1 (seq2 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n1).FUNCT-1K1 n"
        using nat_1_def_3 sorry
    qed "sorry"
    then have "(seq1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n1)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq2 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n1) be divergent-to+inftyLIMFUNC1V1"
      using A1 limfunc1_th_22 limfunc1_th_26 sorry
    then have "(seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n1 be divergent-to+inftyLIMFUNC1V1"
      using seqm_3_th_19 sorry
    thus "seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to+inftyLIMFUNC1V1"
      using limfunc1_th_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_29:
" for seq be Real-SequenceSEQ-1M1 holds seq be non-decreasingSEQM-3V8 &  not seq be bounded-aboveSEQ-2V3 implies seq be divergent-to+inftyLIMFUNC1V1"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds seq be non-decreasingSEQM-3V8 &  not seq be bounded-aboveSEQ-2V3 implies seq be divergent-to+inftyLIMFUNC1V1"
  proof(rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq be non-decreasingSEQM-3V8"
      and A2: " not seq be bounded-aboveSEQ-2V3"
    have " for r be RealXREAL-0M1 holds  ex tVar23 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar23 <=XXREAL-0R1 m implies  not r <XXREAL-0R3 seq .FUNCT-1K1 m"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A3: "r +XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 seq .FUNCT-1K1 n"
        using A2 sorry
      show " ex tVar23 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar23 <=XXREAL-0R1 m implies  not r <XXREAL-0R3 seq .FUNCT-1K1 m"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "n <=XXREAL-0R1 m"
        then have "seq .FUNCT-1K1 n <=XXREAL-0R1 seq .FUNCT-1K1 m"
          using A1 seqm_3_th_6 sorry
        then have "r +XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 seq .FUNCT-1K1 m"
          using A3 xxreal_0_th_2 sorry
        thus " not r <XXREAL-0R3 seq .FUNCT-1K1 m"
          using limfunc1_lm_1 sorry
      qed "sorry"
    qed "sorry"
    thus "seq be divergent-to+inftyLIMFUNC1V1"
      using limfunc1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_30:
" for seq be Real-SequenceSEQ-1M1 holds seq be non-increasingSEQM-3V9 &  not seq be bounded-belowSEQ-2V4 implies seq be divergent-to-inftyLIMFUNC1V2"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds seq be non-increasingSEQM-3V9 &  not seq be bounded-belowSEQ-2V4 implies seq be divergent-to-inftyLIMFUNC1V2"
  proof(rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq be non-increasingSEQM-3V9"
      and A2: " not seq be bounded-belowSEQ-2V4"
    have " for r be RealXREAL-0M1 holds  ex tVar24 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar24 <=XXREAL-0R1 m implies  not seq .FUNCT-1K1 m <XXREAL-0R3 r"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A3: "seq .FUNCT-1K1 n <=XXREAL-0R1 r -XCMPLX-0K6 \<one>\<^sub>M"
        using A2 sorry
      show " ex tVar24 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar24 <=XXREAL-0R1 m implies  not seq .FUNCT-1K1 m <XXREAL-0R3 r"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "n <=XXREAL-0R1 m"
        then have "seq .FUNCT-1K1 m <=XXREAL-0R1 seq .FUNCT-1K1 n"
          using A1 seqm_3_th_8 sorry
        then have "seq .FUNCT-1K1 m <=XXREAL-0R1 r -XCMPLX-0K6 \<one>\<^sub>M"
          using A3 xxreal_0_th_2 sorry
        thus " not seq .FUNCT-1K1 m <XXREAL-0R3 r"
          using limfunc1_lm_1 sorry
      qed "sorry"
    qed "sorry"
    thus "seq be divergent-to-inftyLIMFUNC1V2"
      using limfunc1_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_31:
" for seq be Real-SequenceSEQ-1M1 holds seq be increasingSEQM-3V6 &  not seq be bounded-aboveSEQ-2V3 implies seq be divergent-to+inftyLIMFUNC1V1"
  using limfunc1_th_29 sorry

mtheorem limfunc1_th_32:
" for seq be Real-SequenceSEQ-1M1 holds seq be decreasingSEQM-3V7 &  not seq be bounded-belowSEQ-2V4 implies seq be divergent-to-inftyLIMFUNC1V2"
  using limfunc1_th_30 sorry

mtheorem limfunc1_th_33:
" for seq be Real-SequenceSEQ-1M1 holds seq be monotoneSEQM-3V5 implies (seq be convergentSEQ-2V5 or seq be divergent-to+inftyLIMFUNC1V1) or seq be divergent-to-inftyLIMFUNC1V2"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds seq be monotoneSEQM-3V5 implies  not (( not seq be convergentSEQ-2V5 &  not seq be divergent-to+inftyLIMFUNC1V1) &  not seq be divergent-to-inftyLIMFUNC1V2)"
  proof(rule ballI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq be monotoneSEQM-3V5"
    have " not (( not seq be convergentSEQ-2V5 &  not seq be divergent-to+inftyLIMFUNC1V1) &  not seq be divergent-to-inftyLIMFUNC1V2)"
    proof-
      show " not (( not seq be convergentSEQ-2V5 &  not seq be divergent-to+inftyLIMFUNC1V1) &  not seq be divergent-to-inftyLIMFUNC1V2)"
      proof-
        have cases: "seq be non-decreasingSEQM-3V8 or seq be non-increasingSEQM-3V9"
          using A1 seqm_3_def_5 sorry
        have case1: "seq be non-decreasingSEQM-3V8 implies  not (( not seq be convergentSEQ-2V5 &  not seq be divergent-to+inftyLIMFUNC1V1) &  not seq be divergent-to-inftyLIMFUNC1V2)"
        proof(rule impI)
          assume A2: "seq be non-decreasingSEQM-3V8"
          have " not (( not seq be convergentSEQ-2V5 &  not seq be divergent-to+inftyLIMFUNC1V1) &  not seq be divergent-to-inftyLIMFUNC1V2)"
          proof-
            show " not (( not seq be convergentSEQ-2V5 &  not seq be divergent-to+inftyLIMFUNC1V1) &  not seq be divergent-to-inftyLIMFUNC1V2)"
            proof-
              have cases: "seq be bounded-aboveSEQ-2V3 or  not seq be bounded-aboveSEQ-2V3"
                 sorry
              have case1: "seq be bounded-aboveSEQ-2V3 implies  not (( not seq be convergentSEQ-2V5 &  not seq be divergent-to+inftyLIMFUNC1V1) &  not seq be divergent-to-inftyLIMFUNC1V2)"
              proof(rule impI)
                assume "seq be bounded-aboveSEQ-2V3"
                thus " not (( not seq be convergentSEQ-2V5 &  not seq be divergent-to+inftyLIMFUNC1V1) &  not seq be divergent-to-inftyLIMFUNC1V2)"
                  using A2 sorry
              qed
              have case2: " not seq be bounded-aboveSEQ-2V3 implies  not (( not seq be convergentSEQ-2V5 &  not seq be divergent-to+inftyLIMFUNC1V1) &  not seq be divergent-to-inftyLIMFUNC1V2)"
              proof(rule impI)
                assume " not seq be bounded-aboveSEQ-2V3"
                thus " not (( not seq be convergentSEQ-2V5 &  not seq be divergent-to+inftyLIMFUNC1V1) &  not seq be divergent-to-inftyLIMFUNC1V2)"
                  using A2 limfunc1_th_29 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus " not (( not seq be convergentSEQ-2V5 &  not seq be divergent-to+inftyLIMFUNC1V1) &  not seq be divergent-to-inftyLIMFUNC1V2)"
             sorry
        qed
        have case2: "seq be non-increasingSEQM-3V9 implies  not (( not seq be convergentSEQ-2V5 &  not seq be divergent-to+inftyLIMFUNC1V1) &  not seq be divergent-to-inftyLIMFUNC1V2)"
        proof(rule impI)
          assume A3: "seq be non-increasingSEQM-3V9"
          have " not (( not seq be convergentSEQ-2V5 &  not seq be divergent-to+inftyLIMFUNC1V1) &  not seq be divergent-to-inftyLIMFUNC1V2)"
          proof-
            show " not (( not seq be convergentSEQ-2V5 &  not seq be divergent-to+inftyLIMFUNC1V1) &  not seq be divergent-to-inftyLIMFUNC1V2)"
            proof-
              have cases: "seq be bounded-belowSEQ-2V4 or  not seq be bounded-belowSEQ-2V4"
                 sorry
              have case1: "seq be bounded-belowSEQ-2V4 implies  not (( not seq be convergentSEQ-2V5 &  not seq be divergent-to+inftyLIMFUNC1V1) &  not seq be divergent-to-inftyLIMFUNC1V2)"
              proof(rule impI)
                assume "seq be bounded-belowSEQ-2V4"
                thus " not (( not seq be convergentSEQ-2V5 &  not seq be divergent-to+inftyLIMFUNC1V1) &  not seq be divergent-to-inftyLIMFUNC1V2)"
                  using A3 sorry
              qed
              have case2: " not seq be bounded-belowSEQ-2V4 implies  not (( not seq be convergentSEQ-2V5 &  not seq be divergent-to+inftyLIMFUNC1V1) &  not seq be divergent-to-inftyLIMFUNC1V2)"
              proof(rule impI)
                assume " not seq be bounded-belowSEQ-2V4"
                thus " not (( not seq be convergentSEQ-2V5 &  not seq be divergent-to+inftyLIMFUNC1V1) &  not seq be divergent-to-inftyLIMFUNC1V2)"
                  using A3 limfunc1_th_30 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus " not (( not seq be convergentSEQ-2V5 &  not seq be divergent-to+inftyLIMFUNC1V1) &  not seq be divergent-to-inftyLIMFUNC1V2)"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not (( not seq be convergentSEQ-2V5 &  not seq be divergent-to+inftyLIMFUNC1V1) &  not seq be divergent-to-inftyLIMFUNC1V2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_34:
" for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 or seq be divergent-to-inftyLIMFUNC1V2 implies seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5 & limSEQ-2K1 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 or seq be divergent-to-inftyLIMFUNC1V2 implies seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5 & limSEQ-2K1 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =COMPLEX1R1 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq be divergent-to+inftyLIMFUNC1V1 or seq be divergent-to-inftyLIMFUNC1V2"
    have "seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5 & (seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5 & limSEQ-2K1 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =COMPLEX1R1 0NUMBERSK6)"
    proof-
      show "seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5 & (seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5 & limSEQ-2K1 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =COMPLEX1R1 0NUMBERSK6)"
      proof-
        have cases: "seq be divergent-to+inftyLIMFUNC1V1 or seq be divergent-to-inftyLIMFUNC1V2"
          using A1 sorry
        have case1: "seq be divergent-to+inftyLIMFUNC1V1 implies seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5 & (seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5 & limSEQ-2K1 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =COMPLEX1R1 0NUMBERSK6)"
        proof(rule impI,rule conjMI)
          assume A2: "seq be divergent-to+inftyLIMFUNC1V1"
          have A3: " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 r)"
          proof(rule ballI,rule impI)
            fix r assume [ty]: "r be RealXREAL-0M1"
            assume A4: "0NUMBERSK6 <XXREAL-0R3 r"
            obtain n where
              [ty]:"n be NatNAT-1M1" and 
              A5: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies r \<inverse>XCMPLX-0K5 <XXREAL-0R3 seq .FUNCT-1K1 m"
              using A2 sorry
            show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 r"
            proof(rule bexI[of _ "n"],rule ballI,rule impI)
              fix m assume [ty]: "m be NatNAT-1M1"
              assume "n <=XXREAL-0R1 m"
              then have A6: "r \<inverse>XCMPLX-0K5 <XXREAL-0R3 seq .FUNCT-1K1 m"
                using A5 sorry
              then have "\<one>\<^sub>M /XCMPLX-0K7 seq .FUNCT-1K1 m <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 r \<inverse>XCMPLX-0K5"
                using A4 xreal_1_th_76 sorry
              then have A7: "\<one>\<^sub>M /XCMPLX-0K7 seq .FUNCT-1K1 m <XXREAL-0R3 r"
                using xcmplx_1_th_216 sorry
              have A8: "\<one>\<^sub>M /XCMPLX-0K7 seq .FUNCT-1K1 m =COMPLEX1R1 (seq .FUNCT-1K1 m)\<inverse>XCMPLX-0K5 & (seq .FUNCT-1K1 m)\<inverse>XCMPLX-0K5 =COMPLEX1R1 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m"
                using valued_1_th_10 xcmplx_1_th_215 sorry
              have "0NUMBERSK6 <XXREAL-0R3 r \<inverse>XCMPLX-0K5"
                using A4 sorry
              thus " |.COMPLEX1K10 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 r"
                using A6 A7 A8 absvalue_def_1 sorry
            qed "sorry"
          qed "sorry"
          thus "seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5"
             sorry
          thus "seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5 & limSEQ-2K1 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =COMPLEX1R1 0NUMBERSK6"
            using A3 seq_2_def_7 sorry
        qed
        have case2: "seq be divergent-to-inftyLIMFUNC1V2 implies seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5 & (seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5 & limSEQ-2K1 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =COMPLEX1R1 0NUMBERSK6)"
        proof(rule impI,rule conjMI)
          assume A9: "seq be divergent-to-inftyLIMFUNC1V2"
          have A10: " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 r)"
          proof(rule ballI,rule impI)
            fix r assume [ty]: "r be RealXREAL-0M1"
            assume A11: "0NUMBERSK6 <XXREAL-0R3 r"
            have A12: "-XCMPLX-0K4 r \<inverse>XCMPLX-0K5 <XXREAL-0R3 -XCMPLX-0K4 0NUMBERSK6"
              using A11 xreal_1_th_24 sorry
            obtain n where
              [ty]:"n be NatNAT-1M1" and 
              A13: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .FUNCT-1K1 m <XXREAL-0R3 -XCMPLX-0K4 r \<inverse>XCMPLX-0K5"
              using A9 sorry
            show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 r"
            proof(rule bexI[of _ "n"],rule ballI,rule impI)
              fix m assume [ty]: "m be NatNAT-1M1"
              assume A14: "n <=XXREAL-0R1 m"
              then have "seq .FUNCT-1K1 m <XXREAL-0R3 -XCMPLX-0K4 r \<inverse>XCMPLX-0K5"
                using A13 sorry
              then have "\<one>\<^sub>M /XCMPLX-0K7 (-XCMPLX-0K4 r \<inverse>XCMPLX-0K5) <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 seq .FUNCT-1K1 m"
                using A12 xreal_1_th_99 sorry
              then have "((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 r \<inverse>XCMPLX-0K5)\<inverse>XCMPLX-0K5 <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 seq .FUNCT-1K1 m"
                using xcmplx_1_th_215 sorry
              then have A15: "(-XCMPLX-0K4 \<one>\<^sub>M)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (r \<inverse>XCMPLX-0K5)\<inverse>XCMPLX-0K5 <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 seq .FUNCT-1K1 m"
                using xcmplx_1_th_204 sorry
              have "seq .FUNCT-1K1 m <XXREAL-0R3 -XCMPLX-0K4 0NUMBERSK6"
                using A11 A13 A14 sorry
              then have "\<one>\<^sub>M /XCMPLX-0K7 seq .FUNCT-1K1 m <XXREAL-0R3 (0NUMBERSK6)/XCMPLX-0K7 seq .FUNCT-1K1 m"
                using xreal_1_th_75 sorry
              then have " |.COMPLEX1K10 \<one>\<^sub>M /XCMPLX-0K7 seq .FUNCT-1K1 m .| =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 seq .FUNCT-1K1 m"
                using absvalue_def_1 sorry
              then have "-XCMPLX-0K4 \<one>\<^sub>M *XCMPLX-0K3 r <XXREAL-0R3 -XCMPLX-0K4  |.COMPLEX1K10 \<one>\<^sub>M /XCMPLX-0K7 seq .FUNCT-1K1 m .|"
                using A15 sorry
              then have " |.COMPLEX1K10 \<one>\<^sub>M /XCMPLX-0K7 seq .FUNCT-1K1 m .| <XXREAL-0R3 r"
                using xreal_1_th_24 sorry
              then have " |.COMPLEX1K10 (seq .FUNCT-1K1 m)\<inverse>XCMPLX-0K5.| <XXREAL-0R3 r"
                using xcmplx_1_th_215 sorry
              thus " |.COMPLEX1K10 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 r"
                using valued_1_th_10 sorry
            qed "sorry"
          qed "sorry"
          thus "seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5"
             sorry
          thus "seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5 & limSEQ-2K1 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =COMPLEX1R1 0NUMBERSK6"
            using A10 seq_2_def_7 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5 & limSEQ-2K1 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =COMPLEX1R1 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_35:
" for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6) & ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies 0NUMBERSK6 <XXREAL-0R3 seq .FUNCT-1K1 n) implies seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be divergent-to+inftyLIMFUNC1V1"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6 implies (( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies 0NUMBERSK6 <XXREAL-0R3 seq .FUNCT-1K1 n) implies seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be divergent-to+inftyLIMFUNC1V1)"
  proof(rule ballI,rule impI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6"
    assume Given: " ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies 0NUMBERSK6 <XXREAL-0R3 seq .FUNCT-1K1 n"
    then obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A2: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies 0NUMBERSK6 <XXREAL-0R3 seq .FUNCT-1K1 n"
       sorry
    have " for r be RealXREAL-0M1 holds  ex tVar27 be NatNAT-1M1 st  for n be NatNAT-1M1 holds tVar27 <=XXREAL-0R1 n implies  not r <XXREAL-0R3 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      let ?l = " |.COMPLEX1K10 r.| +XCMPLX-0K2 \<one>\<^sub>M"
      have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r.|"
        using complex1_th_46 sorry
      then obtain o where
        [ty]:"o be NatNAT-1M1" and 
        A3: " for n be NatNAT-1M1 holds o <=XXREAL-0R1 n implies  |.COMPLEX1K10 seq .FUNCT-1K1 n -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 ?l \<inverse>XCMPLX-0K5"
        using A1 seq_2_def_7 sorry
      obtain m where 
        [ty]:"m be NatNAT-1M1" and mDef:"m = maxXXREAL-0K5(k,o)"
        using tarski_th_1 sorry
      show " ex tVar27 be NatNAT-1M1 st  for n be NatNAT-1M1 holds tVar27 <=XXREAL-0R1 n implies  not r <XXREAL-0R3 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n"
      proof(rule bexI[of _ "m"],rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A4: "m <=XXREAL-0R1 n"
        have "k <=XXREAL-0R1 m"
          using xxreal_0_th_25 sorry
        then have "k <=XXREAL-0R1 n"
          using A4 xxreal_0_th_2 sorry
        then have A5: "0NUMBERSK6 <XXREAL-0R3 seq .FUNCT-1K1 n"
          using A2 sorry
        have "o <=XXREAL-0R1 m"
          using xxreal_0_th_25 sorry
        then have "o <=XXREAL-0R1 n"
          using A4 xxreal_0_th_2 sorry
        then have " |.COMPLEX1K10 seq .FUNCT-1K1 n -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 ?l \<inverse>XCMPLX-0K5"
          using A3 sorry
        then have "seq .FUNCT-1K1 n <XXREAL-0R3 ?l \<inverse>XCMPLX-0K5"
          using A5 absvalue_def_1 sorry
        then have "\<one>\<^sub>M /XCMPLX-0K7 ?l \<inverse>XCMPLX-0K5 <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 seq .FUNCT-1K1 n"
          using A5 xreal_1_th_76 sorry
        then have A6: "?l <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 seq .FUNCT-1K1 n"
          using xcmplx_1_th_216 sorry
        have "r <=XXREAL-0R1  |.COMPLEX1K10 r.|"
          using absvalue_th_4 sorry
        then have "r <XXREAL-0R3 ?l"
          using limfunc1_lm_1 sorry
        then have "r <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 seq .FUNCT-1K1 n"
          using A6 xxreal_0_th_2 sorry
        then have "r <XXREAL-0R3 (seq .FUNCT-1K1 n)\<inverse>XCMPLX-0K5"
          using xcmplx_1_th_215 sorry
        thus " not r <XXREAL-0R3 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n"
          using valued_1_th_10 sorry
      qed "sorry"
    qed "sorry"
    thus "seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be divergent-to+inftyLIMFUNC1V1"
      using limfunc1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_36:
" for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6) & ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies seq .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6) implies seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be divergent-to-inftyLIMFUNC1V2"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6 implies (( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies seq .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6) implies seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be divergent-to-inftyLIMFUNC1V2)"
  proof(rule ballI,rule impI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6"
    assume Given: " ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies seq .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6"
    then obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A2: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies seq .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6"
       sorry
    have " for r be RealXREAL-0M1 holds  ex tVar28 be NatNAT-1M1 st  for n be NatNAT-1M1 holds tVar28 <=XXREAL-0R1 n implies  not seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n <XXREAL-0R3 r"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      let ?l = " |.COMPLEX1K10 r.| +XCMPLX-0K2 \<one>\<^sub>M"
      have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r.|"
        using complex1_th_46 sorry
      then obtain o where
        [ty]:"o be NatNAT-1M1" and 
        A3: " for n be NatNAT-1M1 holds o <=XXREAL-0R1 n implies  |.COMPLEX1K10 seq .FUNCT-1K1 n -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 ?l \<inverse>XCMPLX-0K5"
        using A1 seq_2_def_7 sorry
      obtain m where 
        [ty]:"m be NatNAT-1M1" and mDef:"m = maxXXREAL-0K5(k,o)"
        using tarski_th_1 sorry
      show " ex tVar28 be NatNAT-1M1 st  for n be NatNAT-1M1 holds tVar28 <=XXREAL-0R1 n implies  not seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n <XXREAL-0R3 r"
      proof(rule bexI[of _ "m"],rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A4: "m <=XXREAL-0R1 n"
        have "k <=XXREAL-0R1 m"
          using xxreal_0_th_25 sorry
        then have "k <=XXREAL-0R1 n"
          using A4 xxreal_0_th_2 sorry
        then have A5: "seq .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6"
          using A2 sorry
        then have A6: "0NUMBERSK6 <XXREAL-0R3 -XCMPLX-0K4 seq .FUNCT-1K1 n"
          using xreal_1_th_58 sorry
        have "o <=XXREAL-0R1 m"
          using xxreal_0_th_25 sorry
        then have "o <=XXREAL-0R1 n"
          using A4 xxreal_0_th_2 sorry
        then have " |.COMPLEX1K10 seq .FUNCT-1K1 n -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 ?l \<inverse>XCMPLX-0K5"
          using A3 sorry
        then have "-XCMPLX-0K4 seq .FUNCT-1K1 n <XXREAL-0R3 ?l \<inverse>XCMPLX-0K5"
          using A5 absvalue_def_1 sorry
        then have "\<one>\<^sub>M /XCMPLX-0K7 ?l \<inverse>XCMPLX-0K5 <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (-XCMPLX-0K4 seq .FUNCT-1K1 n)"
          using A6 xreal_1_th_76 sorry
        then have "?l <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (-XCMPLX-0K4 seq .FUNCT-1K1 n)"
          using xcmplx_1_th_216 sorry
        then have "?l <XXREAL-0R3 (-XCMPLX-0K4 seq .FUNCT-1K1 n)\<inverse>XCMPLX-0K5"
          using xcmplx_1_th_215 sorry
        then have "?l <XXREAL-0R3 -XCMPLX-0K4 (seq .FUNCT-1K1 n)\<inverse>XCMPLX-0K5"
          using xcmplx_1_th_222 sorry
        then have A7: "-XCMPLX-0K4 (-XCMPLX-0K4 (seq .FUNCT-1K1 n)\<inverse>XCMPLX-0K5) <XXREAL-0R3 -XCMPLX-0K4 ?l"
          using xreal_1_th_24 sorry
        have "-XCMPLX-0K4  |.COMPLEX1K10 r.| <=XXREAL-0R1 r"
          using absvalue_th_4 sorry
        then have "(-XCMPLX-0K4  |.COMPLEX1K10 r.|)-XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 r"
          using limfunc1_lm_1 sorry
        then have "(seq .FUNCT-1K1 n)\<inverse>XCMPLX-0K5 <XXREAL-0R3 r"
          using A7 xxreal_0_th_2 sorry
        thus " not seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n <XXREAL-0R3 r"
          using valued_1_th_10 sorry
      qed "sorry"
    qed "sorry"
    thus "seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be divergent-to-inftyLIMFUNC1V2"
      using limfunc1_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_37:
" for seq be Real-SequenceSEQ-1M1 holds ((seq be non-zeroORDINAL1V9 & seq be convergentSEQ-2V5) & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6) & seq be non-decreasingSEQM-3V8 implies seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be divergent-to-inftyLIMFUNC1V2"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds seq be non-zeroORDINAL1V9 & ((seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6) & seq be non-decreasingSEQM-3V8) implies seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be divergent-to-inftyLIMFUNC1V2"
  proof(rule ballI,rule impMI ,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq be non-zeroORDINAL1V9"
      and A2: "seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6"
      and A3: "seq be non-decreasingSEQM-3V8"
    have " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 n implies seq .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6"
      using A1 A2 A3 limfunc1_th_2 sorry
    thus "seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be divergent-to-inftyLIMFUNC1V2"
      using A2 limfunc1_th_36 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_38:
" for seq be Real-SequenceSEQ-1M1 holds ((seq be non-zeroORDINAL1V9 & seq be convergentSEQ-2V5) & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6) & seq be non-increasingSEQM-3V9 implies seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be divergent-to+inftyLIMFUNC1V1"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds seq be non-zeroORDINAL1V9 & ((seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6) & seq be non-increasingSEQM-3V9) implies seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be divergent-to+inftyLIMFUNC1V1"
  proof(rule ballI,rule impMI ,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq be non-zeroORDINAL1V9"
      and A2: "seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6"
      and A3: "seq be non-increasingSEQM-3V9"
    have " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 n implies 0NUMBERSK6 <XXREAL-0R3 seq .FUNCT-1K1 n"
      using A1 A2 A3 limfunc1_th_3 sorry
    thus "seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be divergent-to+inftyLIMFUNC1V1"
      using A2 limfunc1_th_35 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_39:
" for seq be Real-SequenceSEQ-1M1 holds ((seq be non-zeroORDINAL1V9 & seq be convergentSEQ-2V5) & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6) & seq be increasingSEQM-3V6 implies seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be divergent-to-inftyLIMFUNC1V2"
  using limfunc1_th_37 sorry

mtheorem limfunc1_th_40:
" for seq be Real-SequenceSEQ-1M1 holds ((seq be non-zeroORDINAL1V9 & seq be convergentSEQ-2V5) & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6) & seq be decreasingSEQM-3V7 implies seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be divergent-to+inftyLIMFUNC1V1"
  using limfunc1_th_38 sorry

mtheorem limfunc1_th_41:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq1 be boundedSEQ-2V6 & (seq2 be divergent-to+inftyLIMFUNC1V1 or seq2 be divergent-to-inftyLIMFUNC1V2) implies seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be convergentSEQ-2V5 & limSEQ-2K1 (seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2) =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq1 be boundedSEQ-2V6 & (seq2 be divergent-to+inftyLIMFUNC1V1 or seq2 be divergent-to-inftyLIMFUNC1V2) implies seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be convergentSEQ-2V5 & limSEQ-2K1 (seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2) =COMPLEX1R1 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Real-SequenceSEQ-1M1"
    assume A1: "seq1 be boundedSEQ-2V6"
      and A2: "seq2 be divergent-to+inftyLIMFUNC1V1 or seq2 be divergent-to-inftyLIMFUNC1V2"
    have "seq2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5 & limSEQ-2K1 seq2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =COMPLEX1R1 0NUMBERSK6"
      using A2 limfunc1_th_34 sorry
    thus "seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be convergentSEQ-2V5 & limSEQ-2K1 (seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2) =COMPLEX1R1 0NUMBERSK6"
      using A1 seq_2_th_25 seq_2_th_26 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_42:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & ( for n be NatNAT-1M1 holds seq .FUNCT-1K1 n <=XXREAL-0R1 seq1 .FUNCT-1K1 n) implies seq1 be divergent-to+inftyLIMFUNC1V1"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & ( for n be NatNAT-1M1 holds seq .FUNCT-1K1 n <=XXREAL-0R1 seq1 .FUNCT-1K1 n) implies seq1 be divergent-to+inftyLIMFUNC1V1"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    assume A1: "seq be divergent-to+inftyLIMFUNC1V1"
      and A2: " for n be NatNAT-1M1 holds seq .FUNCT-1K1 n <=XXREAL-0R1 seq1 .FUNCT-1K1 n"
    have " for r be RealXREAL-0M1 holds  ex tVar29 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar29 <=XXREAL-0R1 m implies  not r <XXREAL-0R3 seq1 .FUNCT-1K1 m"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A3: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies r <XXREAL-0R3 seq .FUNCT-1K1 m"
        using A1 sorry
      show " ex tVar29 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar29 <=XXREAL-0R1 m implies  not r <XXREAL-0R3 seq1 .FUNCT-1K1 m"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "n <=XXREAL-0R1 m"
        then have A4: "r <XXREAL-0R3 seq .FUNCT-1K1 m"
          using A3 sorry
        have "seq .FUNCT-1K1 m <=XXREAL-0R1 seq1 .FUNCT-1K1 m"
          using A2 sorry
        thus " not r <XXREAL-0R3 seq1 .FUNCT-1K1 m"
          using A4 xxreal_0_th_2 sorry
      qed "sorry"
    qed "sorry"
    thus "seq1 be divergent-to+inftyLIMFUNC1V1"
      using limfunc1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_43:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & ( for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n <=XXREAL-0R1 seq .FUNCT-1K1 n) implies seq1 be divergent-to-inftyLIMFUNC1V2"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & ( for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n <=XXREAL-0R1 seq .FUNCT-1K1 n) implies seq1 be divergent-to-inftyLIMFUNC1V2"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    assume A1: "seq be divergent-to-inftyLIMFUNC1V2"
      and A2: " for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n <=XXREAL-0R1 seq .FUNCT-1K1 n"
    have " for r be RealXREAL-0M1 holds  ex tVar30 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar30 <=XXREAL-0R1 m implies  not seq1 .FUNCT-1K1 m <XXREAL-0R3 r"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A3: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .FUNCT-1K1 m <XXREAL-0R3 r"
        using A1 sorry
      show " ex tVar30 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar30 <=XXREAL-0R1 m implies  not seq1 .FUNCT-1K1 m <XXREAL-0R3 r"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "n <=XXREAL-0R1 m"
        then have A4: "seq .FUNCT-1K1 m <XXREAL-0R3 r"
          using A3 sorry
        have "seq1 .FUNCT-1K1 m <=XXREAL-0R1 seq .FUNCT-1K1 m"
          using A2 sorry
        thus " not seq1 .FUNCT-1K1 m <XXREAL-0R3 r"
          using A4 xxreal_0_th_2 sorry
      qed "sorry"
    qed "sorry"
    thus "seq1 be divergent-to-inftyLIMFUNC1V2"
      using limfunc1_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef limfunc1_def_6 ("convergent-in+inftyLIMFUNC1V3" 70 ) where
"attr convergent-in+inftyLIMFUNC1V3 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  (\<lambda>f. ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( ex g be RealXREAL-0M1 st  for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 g))"..

mdef limfunc1_def_7 ("divergent-in+infty-to+inftyLIMFUNC1V4" 70 ) where
"attr divergent-in+infty-to+inftyLIMFUNC1V4 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  (\<lambda>f. ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1))"..

mdef limfunc1_def_8 ("divergent-in+infty-to-inftyLIMFUNC1V5" 70 ) where
"attr divergent-in+infty-to-inftyLIMFUNC1V5 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  (\<lambda>f. ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2))"..

mdef limfunc1_def_9 ("convergent-in-inftyLIMFUNC1V6" 70 ) where
"attr convergent-in-inftyLIMFUNC1V6 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  (\<lambda>f. ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( ex g be RealXREAL-0M1 st  for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 g))"..

mdef limfunc1_def_10 ("divergent-in-infty-to+inftyLIMFUNC1V7" 70 ) where
"attr divergent-in-infty-to+inftyLIMFUNC1V7 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  (\<lambda>f. ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1))"..

mdef limfunc1_def_11 ("divergent-in-infty-to-inftyLIMFUNC1V8" 70 ) where
"attr divergent-in-infty-to-inftyLIMFUNC1V8 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  (\<lambda>f. ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2))"..

mtheorem limfunc1_th_44:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be convergent-in+inftyLIMFUNC1V3 iff ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( ex g be RealXREAL-0M1 st  for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1))"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f be convergent-in+inftyLIMFUNC1V3 implies ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( ex g be RealXREAL-0M1 st  for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1))) & (( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies (( ex g be RealXREAL-0M1 st  for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1)) implies f be convergent-in+inftyLIMFUNC1V3))"
  proof(rule ballI,rule conjMI,rule impI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "f be convergent-in+inftyLIMFUNC1V3 implies ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( ex g be RealXREAL-0M1 st  for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1))"
    proof-
      have "f be convergent-in+inftyLIMFUNC1V3 implies ( not ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) or ( for g be RealXREAL-0M1 holds  ex g1 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g1 & ( for r be RealXREAL-0M1 holds  ex r1 be RealXREAL-0M1 st (r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) &  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| >=XXREAL-0R2 g1)) implies  False )"
      proof(rule impI,rule impI)
        assume A1: "f be convergent-in+inftyLIMFUNC1V3"
        then obtain g2 where
          [ty]:"g2 be RealXREAL-0M1" and 
          A2: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 g2"
           sorry
        assume " not ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) or ( for g be RealXREAL-0M1 holds  ex g1 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g1 & ( for r be RealXREAL-0M1 holds  ex r1 be RealXREAL-0M1 st (r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) &  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| >=XXREAL-0R2 g1))"
        then obtain g where
          [ty]:"g be RealXREAL-0M1" and 
          A3: "0NUMBERSK6 <XXREAL-0R3 g"and A4: " for r be RealXREAL-0M1 holds  ex r1 be RealXREAL-0M1 st (r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) &  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g2 .| >=XXREAL-0R2 g"
          using A1 sorry
        let ?X = "\<lambda>Lamb1. \<lambda>Lamb2. (Lamb1 <XXREAL-0R3 Lamb2 & Lamb2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) &  |.COMPLEX1K10 f .FUNCT-1K1 Lamb2 -XCMPLX-0K6 g2 .| >=XXREAL-0R2 g"
        have A5: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex r be ElementSUBSET-1M1-of REALNUMBERSK2 st ?X(n,r)"
        proof-
          have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not ( for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not ((n <XXREAL-0R3 r & r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) &  |.COMPLEX1K10 f .FUNCT-1K1 r -XCMPLX-0K6 g2 .| >=XXREAL-0R2 g))"
          proof(rule ballI)
            fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
            obtain r where
              [ty]:"r be RealXREAL-0M1" and 
              A6: "?X(n,r)"
              using A4 sorry
            have 
              [ty]:"r be RealXREAL-0M1"
               sorry
            have "?X(n,r)"
              using A6 sorry
            thus " not ( for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not ((n <XXREAL-0R3 r & r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) &  |.COMPLEX1K10 f .FUNCT-1K1 r -XCMPLX-0K6 g2 .| >=XXREAL-0R2 g))"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain s where
          [ty]:"s be Real-SequenceSEQ-1M1" and 
          A7: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?X(n,s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
          using funct_2_sch_3 A5 sorry
        have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 s implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 rngFUNCT-1K2 s"
          then have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
            using funct_2_th_113 sorry
          thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using A7 sorry
        qed "sorry"
        then have A8: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
           sorry
        obtain s1 where 
          [ty]:"s1 be Real-SequenceSEQ-1M1" and s1Def:"s1 = idPARTFUN1K6 NATNUMBERSK1"
          using funct_2_th_7 numbers_th_19 sorry
        have " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n <=XXREAL-0R1 s .FUNCT-1K1 n"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have A9: "n inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          then have "n <XXREAL-0R3 s .FUNCT-1K1 n"
            using A7 sorry
          thus "s1 .FUNCT-1K1 n <=XXREAL-0R1 s .FUNCT-1K1 n"
            using funct_1_th_18 A9 sorry
        qed "sorry"
        then have "s be divergent-to+inftyLIMFUNC1V1"
          using limfunc1_lm_5 limfunc1_th_20 limfunc1_th_42 sorry
        then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 g2"
          using A2 A8 sorry
        then obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A10: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 m -XCMPLX-0K6 g2 .| <XXREAL-0R3 g"
          using A3 seq_2_def_7 sorry
        have A11: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 n -XCMPLX-0K6 g2 .| <XXREAL-0R3 g"
          using A10 sorry
        then have " |.COMPLEX1K10 f .FUNCT-1K1 (s .FUNCT-1K1 n) -XCMPLX-0K6 g2 .| <XXREAL-0R3 g"
          using A8 funct_2_th_108 A11 sorry
        thus " False "
          using A7 A11 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A12: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    assume Given: " ex g be RealXREAL-0M1 st  for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1)"
    then obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A13: " for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1)"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds s be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 g"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A14: "s be divergent-to+inftyLIMFUNC1V1"
        and A15: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      have A16: " for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 g1)"
      proof(rule ballI,rule impI)
        fix g1 assume [ty]: "g1 be RealXREAL-0M1"
        assume A17: "0NUMBERSK6 <XXREAL-0R3 g1"
        obtain r where
          [ty]:"r be RealXREAL-0M1" and 
          A18: " for r1 be RealXREAL-0M1 holds r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
          using A13 A17 sorry
        obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A19: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies r <XXREAL-0R3 s .FUNCT-1K1 m"
          using A14 sorry
        show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          have A20: "s .FUNCT-1K1 m inTARSKIR2 rngFUNCT-1K2 s"
            using valued_0_th_28 sorry
          have A21: "m inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          assume "n <=XXREAL-0R1 m"
          then have " |.COMPLEX1K10 f .FUNCT-1K1 (s .FUNCT-1K1 m) -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
            using A15 A18 A19 A20 sorry
          thus " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
            using A15 funct_2_th_108 A21 sorry
        qed "sorry"
      qed "sorry"
      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
         sorry
      thus "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 g"
        using A16 seq_2_def_7 sorry
    qed "sorry"
    thus "f be convergent-in+inftyLIMFUNC1V3"
      using A12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_45:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be convergent-in-inftyLIMFUNC1V6 iff ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( ex g be RealXREAL-0M1 st  for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1))"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f be convergent-in-inftyLIMFUNC1V6 implies ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( ex g be RealXREAL-0M1 st  for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1))) & (( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies (( ex g be RealXREAL-0M1 st  for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1)) implies f be convergent-in-inftyLIMFUNC1V6))"
  proof(rule ballI,rule conjMI,rule impI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "f be convergent-in-inftyLIMFUNC1V6 implies ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( ex g be RealXREAL-0M1 st  for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1))"
    proof-
      have "f be convergent-in-inftyLIMFUNC1V6 implies ( not ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) or ( for g be RealXREAL-0M1 holds  ex g1 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g1 & ( for r be RealXREAL-0M1 holds  ex r1 be RealXREAL-0M1 st (r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) &  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| >=XXREAL-0R2 g1)) implies  False )"
      proof(rule impI,rule impI)
        assume A1: "f be convergent-in-inftyLIMFUNC1V6"
        then obtain g2 where
          [ty]:"g2 be RealXREAL-0M1" and 
          A2: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 g2"
           sorry
        assume " not ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) or ( for g be RealXREAL-0M1 holds  ex g1 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g1 & ( for r be RealXREAL-0M1 holds  ex r1 be RealXREAL-0M1 st (r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) &  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| >=XXREAL-0R2 g1))"
        then obtain g where
          [ty]:"g be RealXREAL-0M1" and 
          A3: "0NUMBERSK6 <XXREAL-0R3 g"and A4: " for r be RealXREAL-0M1 holds  ex r1 be RealXREAL-0M1 st (r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) &  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g2 .| >=XXREAL-0R2 g"
          using A1 sorry
        let ?X = "\<lambda>Lamb1. \<lambda>Lamb2. (Lamb2 <XXREAL-0R3 -XCMPLX-0K4 Lamb1 & Lamb2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) &  |.COMPLEX1K10 f .FUNCT-1K1 Lamb2 -XCMPLX-0K6 g2 .| >=XXREAL-0R2 g"
        have A5: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex r be ElementSUBSET-1M1-of REALNUMBERSK2 st ?X(n,r)"
        proof-
          have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not ( for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not ((r <XXREAL-0R3 -XCMPLX-0K4 n & r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) &  |.COMPLEX1K10 f .FUNCT-1K1 r -XCMPLX-0K6 g2 .| >=XXREAL-0R2 g))"
          proof(rule ballI)
            fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
            obtain r where
              [ty]:"r be RealXREAL-0M1" and 
              A6: "?X(n,r)"
              using A4 sorry
            have 
              [ty]:"r be RealXREAL-0M1"
               sorry
            have "?X(n,r)"
              using A6 sorry
            thus " not ( for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not ((r <XXREAL-0R3 -XCMPLX-0K4 n & r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) &  |.COMPLEX1K10 f .FUNCT-1K1 r -XCMPLX-0K6 g2 .| >=XXREAL-0R2 g))"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain s where
          [ty]:"s be Real-SequenceSEQ-1M1" and 
          A7: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?X(n,s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
          using funct_2_sch_3 A5 sorry
        have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 s implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 rngFUNCT-1K2 s"
          then have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
            using funct_2_th_113 sorry
          thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using A7 sorry
        qed "sorry"
        then have A8: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
           sorry
        let ?U = "\<lambda>Lamb1. -XCMPLX-0K4 Lamb1"
        obtain s1 where
          [ty]:"s1 be Real-SequenceSEQ-1M1" and 
          A9: " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n =COMPLEX1R1 ?U(n)"
          using seq_1_sch_1 sorry
        have " for n be NatNAT-1M1 holds s .FUNCT-1K1 n <=XXREAL-0R1 s1 .FUNCT-1K1 n"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have "n inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          then have "s .FUNCT-1K1 n <XXREAL-0R3 -XCMPLX-0K4 n"
            using A7 sorry
          thus "s .FUNCT-1K1 n <=XXREAL-0R1 s1 .FUNCT-1K1 n"
            using A9 sorry
        qed "sorry"
        then have "s be divergent-to-inftyLIMFUNC1V2"
          using A9 limfunc1_th_21 limfunc1_th_43 sorry
        then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 g2"
          using A2 A8 sorry
        then obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A10: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 m -XCMPLX-0K6 g2 .| <XXREAL-0R3 g"
          using A3 seq_2_def_7 sorry
        have A11: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 n -XCMPLX-0K6 g2 .| <XXREAL-0R3 g"
          using A10 sorry
        then have " |.COMPLEX1K10 f .FUNCT-1K1 (s .FUNCT-1K1 n) -XCMPLX-0K6 g2 .| <XXREAL-0R3 g"
          using A8 funct_2_th_108 A11 sorry
        thus " False "
          using A7 A11 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A12: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    assume Given: " ex g be RealXREAL-0M1 st  for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1)"
    then obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A13: " for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1)"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds s be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 g"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A14: "s be divergent-to-inftyLIMFUNC1V2"
        and A15: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      have A16: " for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 g1)"
      proof(rule ballI,rule impI)
        fix g1 assume [ty]: "g1 be RealXREAL-0M1"
        assume A17: "0NUMBERSK6 <XXREAL-0R3 g1"
        obtain r where
          [ty]:"r be RealXREAL-0M1" and 
          A18: " for r1 be RealXREAL-0M1 holds r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
          using A13 A17 sorry
        obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A19: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies s .FUNCT-1K1 m <XXREAL-0R3 r"
          using A14 sorry
        show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          have A20: "s .FUNCT-1K1 m inTARSKIR2 rngFUNCT-1K2 s"
            using valued_0_th_28 sorry
          have A21: "m inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          assume "n <=XXREAL-0R1 m"
          then have " |.COMPLEX1K10 f .FUNCT-1K1 (s .FUNCT-1K1 m) -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
            using A15 A18 A19 A20 sorry
          thus " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
            using A15 funct_2_th_108 A21 sorry
        qed "sorry"
      qed "sorry"
      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
         sorry
      thus "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 g"
        using A16 seq_2_def_7 sorry
    qed "sorry"
    thus "f be convergent-in-inftyLIMFUNC1V6"
      using A12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_46:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be divergent-in+infty-to+inftyLIMFUNC1V4 iff ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for g be RealXREAL-0M1 holds  ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies g <XXREAL-0R3 f .FUNCT-1K1 r1)"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f be divergent-in+infty-to+inftyLIMFUNC1V4 implies ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for g be RealXREAL-0M1 holds  ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies g <XXREAL-0R3 f .FUNCT-1K1 r1)) & (( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for g be RealXREAL-0M1 holds  ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies g <XXREAL-0R3 f .FUNCT-1K1 r1) implies f be divergent-in+infty-to+inftyLIMFUNC1V4)"
  proof(rule ballI,rule conjMI,rule impMI ,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "f be divergent-in+infty-to+inftyLIMFUNC1V4 implies ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for g be RealXREAL-0M1 holds  ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies g <XXREAL-0R3 f .FUNCT-1K1 r1)"
    proof-
      have "f be divergent-in+infty-to+inftyLIMFUNC1V4 implies ( not ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) or ( ex g be RealXREAL-0M1 st  for r be RealXREAL-0M1 holds  ex r1 be RealXREAL-0M1 st (r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & g >=XXREAL-0R2 f .FUNCT-1K1 r1) implies  False )"
      proof(rule impI,rule impI)
        assume A1: "f be divergent-in+infty-to+inftyLIMFUNC1V4"
        assume " not ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) or ( ex g be RealXREAL-0M1 st  for r be RealXREAL-0M1 holds  ex r1 be RealXREAL-0M1 st (r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & g >=XXREAL-0R2 f .FUNCT-1K1 r1)"
        then obtain g where
          [ty]:"g be RealXREAL-0M1" and 
          A2: " for r be RealXREAL-0M1 holds  ex r1 be RealXREAL-0M1 st (r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & g >=XXREAL-0R2 f .FUNCT-1K1 r1"
          using A1 sorry
        let ?X = "\<lambda>Lamb1. \<lambda>Lamb2. (Lamb1 <XXREAL-0R3 Lamb2 & Lamb2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & g >=XXREAL-0R2 f .FUNCT-1K1 Lamb2"
        have A3: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex r be ElementSUBSET-1M1-of REALNUMBERSK2 st ?X(n,r)"
        proof-
          have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not ( for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not ((n <XXREAL-0R3 r & r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & g >=XXREAL-0R2 f .FUNCT-1K1 r))"
          proof(rule ballI)
            fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
            obtain r where
              [ty]:"r be RealXREAL-0M1" and 
              A4: "?X(n,r)"
              using A2 sorry
            have 
              [ty]:"r be RealXREAL-0M1"
               sorry
            have "?X(n,r)"
              using A4 sorry
            thus " not ( for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not ((n <XXREAL-0R3 r & r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & g >=XXREAL-0R2 f .FUNCT-1K1 r))"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain s where
          [ty]:"s be Real-SequenceSEQ-1M1" and 
          A5: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?X(n,s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
          using funct_2_sch_3 A3 sorry
        have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 s implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 rngFUNCT-1K2 s"
          then have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
            using funct_2_th_113 sorry
          thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using A5 sorry
        qed "sorry"
        then have A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
           sorry
        obtain s1 where 
          [ty]:"s1 be Real-SequenceSEQ-1M1" and s1Def:"s1 = idPARTFUN1K6 NATNUMBERSK1"
          using funct_2_th_7 numbers_th_19 sorry
        have " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n <=XXREAL-0R1 s .FUNCT-1K1 n"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have A7: "n inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          have "n <XXREAL-0R3 s .FUNCT-1K1 n"
            using A5 A7 sorry
          thus "s1 .FUNCT-1K1 n <=XXREAL-0R1 s .FUNCT-1K1 n"
            using funct_1_th_18 A7 sorry
        qed "sorry"
        then have "s be divergent-to+inftyLIMFUNC1V1"
          using limfunc1_lm_5 limfunc1_th_20 limfunc1_th_42 sorry
        then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
          using A1 A6 sorry
        then obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A8: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies g <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 m"
           sorry
        have A9: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "g <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 n"
          using A8 sorry
        then have "g <XXREAL-0R3 f .FUNCT-1K1 (s .FUNCT-1K1 n)"
          using A6 funct_2_th_108 A9 sorry
        thus " False "
          using A5 A9 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A10: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A11: " for g be RealXREAL-0M1 holds  ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies g <XXREAL-0R3 f .FUNCT-1K1 r1"
    have " for s be Real-SequenceSEQ-1M1 holds s be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A12: "s be divergent-to+inftyLIMFUNC1V1"
        and A13: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      have " for g be RealXREAL-0M1 holds  ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies g <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 m"
      proof(rule ballI)
        fix g assume [ty]: "g be RealXREAL-0M1"
        obtain r where
          [ty]:"r be RealXREAL-0M1" and 
          A14: " for r1 be RealXREAL-0M1 holds r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies g <XXREAL-0R3 f .FUNCT-1K1 r1"
          using A11 sorry
        obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A15: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies r <XXREAL-0R3 s .FUNCT-1K1 m"
          using A12 sorry
        show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies g <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 m"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          have A16: "s .FUNCT-1K1 m inTARSKIR2 rngFUNCT-1K2 s"
            using valued_0_th_28 sorry
          have A17: "m inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          assume "n <=XXREAL-0R1 m"
          then have "g <XXREAL-0R3 f .FUNCT-1K1 (s .FUNCT-1K1 m)"
            using A13 A14 A15 A16 sorry
          thus "g <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 m"
            using A13 funct_2_th_108 A17 sorry
        qed "sorry"
      qed "sorry"
      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
         sorry
    qed "sorry"
    thus "f be divergent-in+infty-to+inftyLIMFUNC1V4"
      using A10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_47:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be divergent-in+infty-to-inftyLIMFUNC1V5 iff ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for g be RealXREAL-0M1 holds  ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 r1 <XXREAL-0R3 g)"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f be divergent-in+infty-to-inftyLIMFUNC1V5 implies ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for g be RealXREAL-0M1 holds  ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 r1 <XXREAL-0R3 g)) & (( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for g be RealXREAL-0M1 holds  ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 r1 <XXREAL-0R3 g) implies f be divergent-in+infty-to-inftyLIMFUNC1V5)"
  proof(rule ballI,rule conjMI,rule impMI ,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "f be divergent-in+infty-to-inftyLIMFUNC1V5 implies ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for g be RealXREAL-0M1 holds  ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 r1 <XXREAL-0R3 g)"
    proof-
      have "f be divergent-in+infty-to-inftyLIMFUNC1V5 implies ( not ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) or ( ex g be RealXREAL-0M1 st  for r be RealXREAL-0M1 holds  ex r1 be RealXREAL-0M1 st (r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 r1 >=XXREAL-0R2 g) implies  False )"
      proof(rule impI,rule impI)
        assume A1: "f be divergent-in+infty-to-inftyLIMFUNC1V5"
        assume " not ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) or ( ex g be RealXREAL-0M1 st  for r be RealXREAL-0M1 holds  ex r1 be RealXREAL-0M1 st (r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 r1 >=XXREAL-0R2 g)"
        then obtain g where
          [ty]:"g be RealXREAL-0M1" and 
          A2: " for r be RealXREAL-0M1 holds  ex r1 be RealXREAL-0M1 st (r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 r1 >=XXREAL-0R2 g"
          using A1 sorry
        let ?X = "\<lambda>Lamb1. \<lambda>Lamb2. (Lamb1 <XXREAL-0R3 Lamb2 & Lamb2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & g <=XXREAL-0R1 f .FUNCT-1K1 Lamb2"
        have A3: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex r be ElementSUBSET-1M1-of REALNUMBERSK2 st ?X(n,r)"
        proof-
          have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not ( for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not ((n <XXREAL-0R3 r & r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & g <=XXREAL-0R1 f .FUNCT-1K1 r))"
          proof(rule ballI)
            fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
            obtain r where
              [ty]:"r be RealXREAL-0M1" and 
              A4: "?X(n,r)"
              using A2 sorry
            have 
              [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2"
              using xreal_0_def_1 sorry
            have "?X(n,r)"
              using A4 sorry
            thus " not ( for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not ((n <XXREAL-0R3 r & r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & g <=XXREAL-0R1 f .FUNCT-1K1 r))"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain s where
          [ty]:"s be Real-SequenceSEQ-1M1" and 
          A5: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?X(n,s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
          using funct_2_sch_3 A3 sorry
        have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 s implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 rngFUNCT-1K2 s"
          then have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
            using funct_2_th_113 sorry
          thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using A5 sorry
        qed "sorry"
        then have A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
           sorry
        obtain s1 where 
          [ty]:"s1 be Real-SequenceSEQ-1M1" and s1Def:"s1 = idPARTFUN1K6 NATNUMBERSK1"
          using funct_2_th_7 numbers_th_19 sorry
        have " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n <=XXREAL-0R1 s .FUNCT-1K1 n"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have A7: "n inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          have "n <XXREAL-0R3 s .FUNCT-1K1 n"
            using A5 A7 sorry
          thus "s1 .FUNCT-1K1 n <=XXREAL-0R1 s .FUNCT-1K1 n"
            using funct_1_th_18 A7 sorry
        qed "sorry"
        then have "s be divergent-to+inftyLIMFUNC1V1"
          using limfunc1_lm_5 limfunc1_th_20 limfunc1_th_42 sorry
        then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
          using A1 A6 sorry
        then obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A8: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 m <XXREAL-0R3 g"
           sorry
        have A9: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 n <XXREAL-0R3 g"
          using A8 sorry
        then have "f .FUNCT-1K1 (s .FUNCT-1K1 n) <XXREAL-0R3 g"
          using A6 funct_2_th_108 A9 sorry
        thus " False "
          using A5 A9 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A10: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A11: " for g be RealXREAL-0M1 holds  ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 r1 <XXREAL-0R3 g"
    have " for s be Real-SequenceSEQ-1M1 holds s be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A12: "s be divergent-to+inftyLIMFUNC1V1"
        and A13: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      have " for g be RealXREAL-0M1 holds  ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 m <XXREAL-0R3 g"
      proof(rule ballI)
        fix g assume [ty]: "g be RealXREAL-0M1"
        obtain r where
          [ty]:"r be RealXREAL-0M1" and 
          A14: " for r1 be RealXREAL-0M1 holds r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 r1 <XXREAL-0R3 g"
          using A11 sorry
        obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A15: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies r <XXREAL-0R3 s .FUNCT-1K1 m"
          using A12 sorry
        show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 m <XXREAL-0R3 g"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          have A16: "s .FUNCT-1K1 m inTARSKIR2 rngFUNCT-1K2 s"
            using valued_0_th_28 sorry
          have A17: "m inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          assume "n <=XXREAL-0R1 m"
          then have "f .FUNCT-1K1 (s .FUNCT-1K1 m) <XXREAL-0R3 g"
            using A13 A14 A15 A16 sorry
          thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 m <XXREAL-0R3 g"
            using A13 funct_2_th_108 A17 sorry
        qed "sorry"
      qed "sorry"
      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
         sorry
    qed "sorry"
    thus "f be divergent-in+infty-to-inftyLIMFUNC1V5"
      using A10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_48:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be divergent-in-infty-to+inftyLIMFUNC1V7 iff ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for g be RealXREAL-0M1 holds  ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies g <XXREAL-0R3 f .FUNCT-1K1 r1)"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f be divergent-in-infty-to+inftyLIMFUNC1V7 implies ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for g be RealXREAL-0M1 holds  ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies g <XXREAL-0R3 f .FUNCT-1K1 r1)) & (( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for g be RealXREAL-0M1 holds  ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies g <XXREAL-0R3 f .FUNCT-1K1 r1) implies f be divergent-in-infty-to+inftyLIMFUNC1V7)"
  proof(rule ballI,rule conjMI,rule impMI ,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "f be divergent-in-infty-to+inftyLIMFUNC1V7 implies ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for g be RealXREAL-0M1 holds  ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies g <XXREAL-0R3 f .FUNCT-1K1 r1)"
    proof-
      have "f be divergent-in-infty-to+inftyLIMFUNC1V7 implies ( not ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) or ( ex g be RealXREAL-0M1 st  for r be RealXREAL-0M1 holds  ex r1 be RealXREAL-0M1 st (r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & g >=XXREAL-0R2 f .FUNCT-1K1 r1) implies  False )"
      proof(rule impI,rule impI)
        let ?U = "\<lambda>Lamb1. -XCMPLX-0K4 Lamb1"
        assume A1: "f be divergent-in-infty-to+inftyLIMFUNC1V7"
        assume " not ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) or ( ex g be RealXREAL-0M1 st  for r be RealXREAL-0M1 holds  ex r1 be RealXREAL-0M1 st (r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & g >=XXREAL-0R2 f .FUNCT-1K1 r1)"
        then obtain g where
          [ty]:"g be RealXREAL-0M1" and 
          A2: " for r be RealXREAL-0M1 holds  ex r1 be RealXREAL-0M1 st (r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & g >=XXREAL-0R2 f .FUNCT-1K1 r1"
          using A1 sorry
        let ?X = "\<lambda>Lamb1. \<lambda>Lamb2. (Lamb2 <XXREAL-0R3 -XCMPLX-0K4 Lamb1 & Lamb2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & g >=XXREAL-0R2 f .FUNCT-1K1 Lamb2"
        have A3: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex r be ElementSUBSET-1M1-of REALNUMBERSK2 st ?X(n,r)"
        proof-
          have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not ( for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not ((r <XXREAL-0R3 -XCMPLX-0K4 n & r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & g >=XXREAL-0R2 f .FUNCT-1K1 r))"
          proof(rule ballI)
            fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
            obtain r where
              [ty]:"r be RealXREAL-0M1" and 
              A4: "?X(n,r)"
              using A2 sorry
            have 
              [ty]:"r be RealXREAL-0M1"
               sorry
            have "?X(n,r)"
              using A4 sorry
            thus " not ( for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not ((r <XXREAL-0R3 -XCMPLX-0K4 n & r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & g >=XXREAL-0R2 f .FUNCT-1K1 r))"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain s where
          [ty]:"s be Real-SequenceSEQ-1M1" and 
          A5: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?X(n,s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
          using funct_2_sch_3 A3 sorry
        have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 s implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 rngFUNCT-1K2 s"
          then have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
            using funct_2_th_113 sorry
          thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using A5 sorry
        qed "sorry"
        then have A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
           sorry
        obtain s1 where
          [ty]:"s1 be Real-SequenceSEQ-1M1" and 
          A7: " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n =COMPLEX1R1 ?U(n)"
          using seq_1_sch_1 sorry
        have " for n be NatNAT-1M1 holds s .FUNCT-1K1 n <=XXREAL-0R1 s1 .FUNCT-1K1 n"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have A8: "n inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          have "s .FUNCT-1K1 n <XXREAL-0R3 -XCMPLX-0K4 n"
            using A5 A8 sorry
          thus "s .FUNCT-1K1 n <=XXREAL-0R1 s1 .FUNCT-1K1 n"
            using A7 sorry
        qed "sorry"
        then have "s be divergent-to-inftyLIMFUNC1V2"
          using A7 limfunc1_th_21 limfunc1_th_43 sorry
        then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
          using A1 A6 sorry
        then obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A9: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies g <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 m"
           sorry
        have A10: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "g <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 n"
          using A9 sorry
        then have "g <XXREAL-0R3 f .FUNCT-1K1 (s .FUNCT-1K1 n)"
          using A6 funct_2_th_108 A10 sorry
        thus " False "
          using A5 A10 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A11: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A12: " for g be RealXREAL-0M1 holds  ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies g <XXREAL-0R3 f .FUNCT-1K1 r1"
    have " for s be Real-SequenceSEQ-1M1 holds s be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A13: "s be divergent-to-inftyLIMFUNC1V2"
        and A14: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      have " for g be RealXREAL-0M1 holds  ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies g <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 m"
      proof(rule ballI)
        fix g assume [ty]: "g be RealXREAL-0M1"
        obtain r where
          [ty]:"r be RealXREAL-0M1" and 
          A15: " for r1 be RealXREAL-0M1 holds r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies g <XXREAL-0R3 f .FUNCT-1K1 r1"
          using A12 sorry
        obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A16: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies s .FUNCT-1K1 m <XXREAL-0R3 r"
          using A13 sorry
        show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies g <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 m"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          have A17: "s .FUNCT-1K1 m inTARSKIR2 rngFUNCT-1K2 s"
            using valued_0_th_28 sorry
          have A18: "m inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          assume "n <=XXREAL-0R1 m"
          then have "g <XXREAL-0R3 f .FUNCT-1K1 (s .FUNCT-1K1 m)"
            using A14 A15 A16 A17 sorry
          thus "g <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 m"
            using A14 funct_2_th_108 A18 sorry
        qed "sorry"
      qed "sorry"
      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
         sorry
    qed "sorry"
    thus "f be divergent-in-infty-to+inftyLIMFUNC1V7"
      using A11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_49:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be divergent-in-infty-to-inftyLIMFUNC1V8 iff ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for g be RealXREAL-0M1 holds  ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 r1 <XXREAL-0R3 g)"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f be divergent-in-infty-to-inftyLIMFUNC1V8 implies ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for g be RealXREAL-0M1 holds  ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 r1 <XXREAL-0R3 g)) & (( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for g be RealXREAL-0M1 holds  ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 r1 <XXREAL-0R3 g) implies f be divergent-in-infty-to-inftyLIMFUNC1V8)"
  proof(rule ballI,rule conjMI,rule impMI ,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "f be divergent-in-infty-to-inftyLIMFUNC1V8 implies ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for g be RealXREAL-0M1 holds  ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 r1 <XXREAL-0R3 g)"
    proof-
      have "f be divergent-in-infty-to-inftyLIMFUNC1V8 implies ( not ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) or ( ex g be RealXREAL-0M1 st  for r be RealXREAL-0M1 holds  ex r1 be RealXREAL-0M1 st (r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 r1 >=XXREAL-0R2 g) implies  False )"
      proof(rule impI,rule impI)
        let ?U = "\<lambda>Lamb1. -XCMPLX-0K4 Lamb1"
        assume A1: "f be divergent-in-infty-to-inftyLIMFUNC1V8"
        assume " not ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) or ( ex g be RealXREAL-0M1 st  for r be RealXREAL-0M1 holds  ex r1 be RealXREAL-0M1 st (r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 r1 >=XXREAL-0R2 g)"
        then obtain g where
          [ty]:"g be RealXREAL-0M1" and 
          A2: " for r be RealXREAL-0M1 holds  ex r1 be RealXREAL-0M1 st (r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 r1 >=XXREAL-0R2 g"
          using A1 sorry
        let ?X = "\<lambda>Lamb1. \<lambda>Lamb2. (Lamb2 <XXREAL-0R3 -XCMPLX-0K4 Lamb1 & Lamb2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & g <=XXREAL-0R1 f .FUNCT-1K1 Lamb2"
        have A3: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex r be ElementSUBSET-1M1-of REALNUMBERSK2 st ?X(n,r)"
        proof-
          have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not ( for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not ((r <XXREAL-0R3 -XCMPLX-0K4 n & r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & g <=XXREAL-0R1 f .FUNCT-1K1 r))"
          proof(rule ballI)
            fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
            obtain r where
              [ty]:"r be RealXREAL-0M1" and 
              A4: "?X(n,r)"
              using A2 sorry
            have 
              [ty]:"r be RealXREAL-0M1"
               sorry
            have "?X(n,r)"
              using A4 sorry
            thus " not ( for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not ((r <XXREAL-0R3 -XCMPLX-0K4 n & r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & g <=XXREAL-0R1 f .FUNCT-1K1 r))"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain s where
          [ty]:"s be Real-SequenceSEQ-1M1" and 
          A5: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?X(n,s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
          using funct_2_sch_3 A3 sorry
        have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 s implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 rngFUNCT-1K2 s"
          then have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
            using funct_2_th_113 sorry
          thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using A5 sorry
        qed "sorry"
        then have A6: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
           sorry
        obtain s1 where
          [ty]:"s1 be Real-SequenceSEQ-1M1" and 
          A7: " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n =COMPLEX1R1 ?U(n)"
          using seq_1_sch_1 sorry
        have " for n be NatNAT-1M1 holds s .FUNCT-1K1 n <=XXREAL-0R1 s1 .FUNCT-1K1 n"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have A8: "n inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          have "s .FUNCT-1K1 n <XXREAL-0R3 -XCMPLX-0K4 n"
            using A5 A8 sorry
          thus "s .FUNCT-1K1 n <=XXREAL-0R1 s1 .FUNCT-1K1 n"
            using A7 sorry
        qed "sorry"
        then have "s be divergent-to-inftyLIMFUNC1V2"
          using A7 limfunc1_th_21 limfunc1_th_43 sorry
        then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
          using A1 A6 sorry
        then obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A9: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 m <XXREAL-0R3 g"
           sorry
        have A10: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 n <XXREAL-0R3 g"
          using A9 sorry
        then have "f .FUNCT-1K1 (s .FUNCT-1K1 n) <XXREAL-0R3 g"
          using A6 funct_2_th_108 A10 sorry
        thus " False "
          using A5 A10 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A11: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A12: " for g be RealXREAL-0M1 holds  ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 r1 <XXREAL-0R3 g"
    have " for s be Real-SequenceSEQ-1M1 holds s be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A13: "s be divergent-to-inftyLIMFUNC1V2"
        and A14: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      have " for g be RealXREAL-0M1 holds  ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 m <XXREAL-0R3 g"
      proof(rule ballI)
        fix g assume [ty]: "g be RealXREAL-0M1"
        obtain r where
          [ty]:"r be RealXREAL-0M1" and 
          A15: " for r1 be RealXREAL-0M1 holds r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 r1 <XXREAL-0R3 g"
          using A12 sorry
        obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A16: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies s .FUNCT-1K1 m <XXREAL-0R3 r"
          using A13 sorry
        show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 m <XXREAL-0R3 g"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          have A17: "s .FUNCT-1K1 m inTARSKIR2 rngFUNCT-1K2 s"
            using valued_0_th_28 sorry
          have A18: "m inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          assume "n <=XXREAL-0R1 m"
          then have "f .FUNCT-1K1 (s .FUNCT-1K1 m) <XXREAL-0R3 g"
            using A14 A15 A16 A17 sorry
          thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 m <XXREAL-0R3 g"
            using A14 funct_2_th_108 A18 sorry
        qed "sorry"
      qed "sorry"
      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
         sorry
    qed "sorry"
    thus "f be divergent-in-infty-to-inftyLIMFUNC1V8"
      using A11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_50:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in+infty-to+inftyLIMFUNC1V4 & f2 be divergent-in+infty-to+inftyLIMFUNC1V4) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in+infty-to+inftyLIMFUNC1V4 & f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in+infty-to+inftyLIMFUNC1V4"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in+infty-to+inftyLIMFUNC1V4 & (f2 be divergent-in+infty-to+inftyLIMFUNC1V4 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in+infty-to+inftyLIMFUNC1V4 & f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in+infty-to+inftyLIMFUNC1V4"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be divergent-in+infty-to+inftyLIMFUNC1V4"
      and A2: "f2 be divergent-in+infty-to+inftyLIMFUNC1V4"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
    have A4: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A5: "seq be divergent-to+inftyLIMFUNC1V1"
        and A6: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      have A7: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc1_lm_2 sorry
      have "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc1_lm_2 sorry
      then have A8: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
        using A2 A5 sorry
      have "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A6 limfunc1_lm_2 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
        using A1 A5 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
        using A8 limfunc1_th_8 sorry
      thus "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
        using A6 A7 rfunct_2_th_8 sorry
    qed "sorry"
    have A9: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A10: "seq be divergent-to+inftyLIMFUNC1V1"
        and A11: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      have A12: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A11 limfunc1_lm_3 sorry
      have "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A11 limfunc1_lm_3 sorry
      then have A13: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
        using A2 A10 sorry
      have "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A11 limfunc1_lm_3 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
        using A1 A10 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
        using A13 limfunc1_th_10 sorry
      thus "(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
        using A11 A12 rfunct_2_th_8 sorry
    qed "sorry"
    have " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain g where
        [ty]:"g be RealXREAL-0M1" and 
        A14: "r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A3 sorry
      show " ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      proof(rule bexI[of _ "g"])
        show "r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
          using A14 valued_1_def_1 sorry
      qed "sorry"
    qed "sorry"
    thus "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in+infty-to+inftyLIMFUNC1V4"
      using A4 sorry
    have " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain g where
        [ty]:"g be RealXREAL-0M1" and 
        A15: "r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A3 sorry
      show " ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      proof(rule bexI[of _ "g"])
        show "r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
          using A15 valued_1_def_4 sorry
      qed "sorry"
    qed "sorry"
    thus "f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in+infty-to+inftyLIMFUNC1V4"
      using A9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_51:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in+infty-to-inftyLIMFUNC1V5 & f2 be divergent-in+infty-to-inftyLIMFUNC1V5) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in+infty-to-inftyLIMFUNC1V5 & f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in+infty-to+inftyLIMFUNC1V4"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in+infty-to-inftyLIMFUNC1V5 & (f2 be divergent-in+infty-to-inftyLIMFUNC1V5 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in+infty-to-inftyLIMFUNC1V5 & f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in+infty-to+inftyLIMFUNC1V4"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be divergent-in+infty-to-inftyLIMFUNC1V5"
      and A2: "f2 be divergent-in+infty-to-inftyLIMFUNC1V5"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
    have A4: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A5: "seq be divergent-to+inftyLIMFUNC1V1"
        and A6: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      have A7: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc1_lm_2 sorry
      have "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc1_lm_2 sorry
      then have A8: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
        using A2 A5 sorry
      have "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A6 limfunc1_lm_2 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
        using A1 A5 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
        using A8 limfunc1_th_11 sorry
      thus "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
        using A6 A7 rfunct_2_th_8 sorry
    qed "sorry"
    have A9: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A10: "seq be divergent-to+inftyLIMFUNC1V1"
        and A11: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      have A12: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A11 limfunc1_lm_3 sorry
      have "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A11 limfunc1_lm_3 sorry
      then have A13: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
        using A2 A10 sorry
      have "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A11 limfunc1_lm_3 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
        using A1 A10 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
        using A13 limfunc1_th_24 sorry
      thus "(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
        using A11 A12 rfunct_2_th_8 sorry
    qed "sorry"
    have " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain g where
        [ty]:"g be RealXREAL-0M1" and 
        A14: "r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A3 sorry
      show " ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      proof(rule bexI[of _ "g"])
        show "r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
          using A14 valued_1_def_1 sorry
      qed "sorry"
    qed "sorry"
    thus "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in+infty-to-inftyLIMFUNC1V5"
      using A4 sorry
    have " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain g where
        [ty]:"g be RealXREAL-0M1" and 
        A15: "r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A3 sorry
      show " ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      proof(rule bexI[of _ "g"])
        show "r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
          using A15 valued_1_def_4 sorry
      qed "sorry"
    qed "sorry"
    thus "f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in+infty-to+inftyLIMFUNC1V4"
      using A9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_52:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in-infty-to+inftyLIMFUNC1V7 & f2 be divergent-in-infty-to+inftyLIMFUNC1V7) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in-infty-to+inftyLIMFUNC1V7 & f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in-infty-to+inftyLIMFUNC1V7"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in-infty-to+inftyLIMFUNC1V7 & (f2 be divergent-in-infty-to+inftyLIMFUNC1V7 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in-infty-to+inftyLIMFUNC1V7 & f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in-infty-to+inftyLIMFUNC1V7"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be divergent-in-infty-to+inftyLIMFUNC1V7"
      and A2: "f2 be divergent-in-infty-to+inftyLIMFUNC1V7"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
    have A4: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A5: "seq be divergent-to-inftyLIMFUNC1V2"
        and A6: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      have A7: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc1_lm_2 sorry
      have "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc1_lm_2 sorry
      then have A8: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
        using A2 A5 sorry
      have "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A6 limfunc1_lm_2 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
        using A1 A5 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
        using A8 limfunc1_th_8 sorry
      thus "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
        using A6 A7 rfunct_2_th_8 sorry
    qed "sorry"
    have A9: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A10: "seq be divergent-to-inftyLIMFUNC1V2"
        and A11: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      have A12: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A11 limfunc1_lm_3 sorry
      have "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A11 limfunc1_lm_3 sorry
      then have A13: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
        using A2 A10 sorry
      have "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A11 limfunc1_lm_3 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
        using A1 A10 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
        using A13 limfunc1_th_10 sorry
      thus "(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
        using A11 A12 rfunct_2_th_8 sorry
    qed "sorry"
    have " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain g where
        [ty]:"g be RealXREAL-0M1" and 
        A14: "g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A3 sorry
      show " ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      proof(rule bexI[of _ "g"])
        show "g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
          using A14 valued_1_def_1 sorry
      qed "sorry"
    qed "sorry"
    thus "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in-infty-to+inftyLIMFUNC1V7"
      using A4 sorry
    have " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain g where
        [ty]:"g be RealXREAL-0M1" and 
        A15: "g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A3 sorry
      show " ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      proof(rule bexI[of _ "g"])
        show "g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
          using A15 valued_1_def_4 sorry
      qed "sorry"
    qed "sorry"
    thus "f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in-infty-to+inftyLIMFUNC1V7"
      using A9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_53:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in-infty-to-inftyLIMFUNC1V8 & f2 be divergent-in-infty-to-inftyLIMFUNC1V8) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in-infty-to-inftyLIMFUNC1V8 & f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in-infty-to+inftyLIMFUNC1V7"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in-infty-to-inftyLIMFUNC1V8 & (f2 be divergent-in-infty-to-inftyLIMFUNC1V8 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in-infty-to-inftyLIMFUNC1V8 & f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in-infty-to+inftyLIMFUNC1V7"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be divergent-in-infty-to-inftyLIMFUNC1V8"
      and A2: "f2 be divergent-in-infty-to-inftyLIMFUNC1V8"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
    have A4: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A5: "seq be divergent-to-inftyLIMFUNC1V2"
        and A6: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      have A7: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc1_lm_2 sorry
      have "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc1_lm_2 sorry
      then have A8: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
        using A2 A5 sorry
      have "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A6 limfunc1_lm_2 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
        using A1 A5 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
        using A8 limfunc1_th_11 sorry
      thus "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
        using A6 A7 rfunct_2_th_8 sorry
    qed "sorry"
    have A9: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A10: "seq be divergent-to-inftyLIMFUNC1V2"
        and A11: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      have A12: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A11 limfunc1_lm_3 sorry
      have "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A11 limfunc1_lm_3 sorry
      then have A13: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
        using A2 A10 sorry
      have "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A11 limfunc1_lm_3 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
        using A1 A10 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
        using A13 limfunc1_th_24 sorry
      thus "(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
        using A11 A12 rfunct_2_th_8 sorry
    qed "sorry"
    have " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain g where
        [ty]:"g be RealXREAL-0M1" and 
        A14: "g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A3 sorry
      show " ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      proof(rule bexI[of _ "g"])
        show "g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
          using A14 valued_1_def_1 sorry
      qed "sorry"
    qed "sorry"
    thus "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in-infty-to-inftyLIMFUNC1V8"
      using A4 sorry
    have " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain g where
        [ty]:"g be RealXREAL-0M1" and 
        A15: "g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A3 sorry
      show " ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      proof(rule bexI[of _ "g"])
        show "g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
          using A15 valued_1_def_4 sorry
      qed "sorry"
    qed "sorry"
    thus "f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in-infty-to+inftyLIMFUNC1V7"
      using A9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_54:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in+infty-to+inftyLIMFUNC1V4 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) & ( ex r be RealXREAL-0M1 st f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be bounded-belowSEQ-2V2) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in+infty-to+inftyLIMFUNC1V4"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in+infty-to+inftyLIMFUNC1V4 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) implies (( ex r1 be RealXREAL-0M1 st f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) be bounded-belowSEQ-2V2) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in+infty-to+inftyLIMFUNC1V4)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be divergent-in+infty-to+inftyLIMFUNC1V4"
      and A2: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
    assume Given: " ex r1 be RealXREAL-0M1 st f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) be bounded-belowSEQ-2V2"
    then obtain r1 where
      [ty]:"r1 be RealXREAL-0M1" and 
      A3: "f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) be bounded-belowSEQ-2V2"
       sorry
    have " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A4: "seq be divergent-to+inftyLIMFUNC1V1"
        and A5: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A6: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies r1 <XXREAL-0R3 seq .FUNCT-1K1 n"
        using A4 sorry
      have A7: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngFUNCT-1K2 seq"
        using valued_0_th_21 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A5 limfunc1_lm_2 sorry
      then have "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A5 A7 sorry
      then have A8: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =HIDDENR1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        using rfunct_2_th_8 sorry
      also have "... = (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A5 valued_0_th_27 sorry
      finally have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =HIDDENR1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      obtain r2 where
        [ty]:"r2 be RealXREAL-0M1" and 
        A9: " for g be objectHIDDENM1 holds g inHIDDENR3 (right-open-halflineLIMFUNC1K4 r1)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 implies r2 <=XXREAL-0R1 f2 .FUNCT-1K1 g"
        using A3 rfunct_1_th_71 sorry
      have A10: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A5 limfunc1_lm_2 sorry
      then have A11: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 sorry
      have " for n be NatNAT-1M1 holds (-XCMPLX-0K4  |.COMPLEX1K10 r2.|)-XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A12: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        obtain nk nn where 
          [ty]:"nk be ElementSUBSET-1M1-of NATNUMBERSK1" and nkDef:"nk = n +XCMPLX-0K2 k" and
          [ty]:"nn be ElementSUBSET-1M1-of NATNUMBERSK1" and nnDef:"nn = n"
          using ordinal1_def_12 sorry
        have "r1 <XXREAL-0R3 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> nk"
          using A6 nat_1_th_12 sorry
        then have "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> nn <XXREAL-0R3 +inftyXXREAL-0K1 & r1 <XXREAL-0R3 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> nn"
          using nat_1_def_3 xxreal_0_th_9 sorry
        then have "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) & (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 right-open-halflineLIMFUNC1K4 r1"
          using valued_0_th_28 xxreal_1_th_4 sorry
        then have "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 (right-open-halflineLIMFUNC1K4 r1)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A11 xboole_0_def_4 sorry
        then have "r2 <=XXREAL-0R1 f2 .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
          using A9 sorry
        then have A13: "r2 <=XXREAL-0R1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
          using A10 A7 funct_2_th_108 xboole_1_th_1 A12 sorry
        have "-XCMPLX-0K4  |.COMPLEX1K10 r2.| <=XXREAL-0R1 r2"
          using absvalue_th_4 sorry
        then have "(-XCMPLX-0K4  |.COMPLEX1K10 r2.|)-XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 r2 -XCMPLX-0K6 0NUMBERSK6"
          using xreal_1_th_15 sorry
        thus "(-XCMPLX-0K4  |.COMPLEX1K10 r2.|)-XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
          using A13 xxreal_0_th_2 sorry
      qed "sorry"
      then have A14: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be bounded-belowSEQ-2V4"
         sorry
      have "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A5 limfunc1_lm_2 sorry
      then have A15: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A7 sorry
      have "seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be divergent-to+inftyLIMFUNC1V1"
        using A4 limfunc1_th_26 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be divergent-to+inftyLIMFUNC1V1"
        using A1 A15 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be divergent-to+inftyLIMFUNC1V1"
        using A14 limfunc1_th_9 sorry
      thus "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
        using A8 limfunc1_th_7 sorry
    qed "sorry"
    thus "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in+infty-to+inftyLIMFUNC1V4"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_55:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in+infty-to+inftyLIMFUNC1V4 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) & ( ex r be RealXREAL-0M1 st  ex r1 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) implies r <=XXREAL-0R1 f2 .FUNCT-1K1 g)) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in+infty-to+inftyLIMFUNC1V4"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in+infty-to+inftyLIMFUNC1V4 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) implies (( ex r2 be RealXREAL-0M1 st  ex r1 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r2 & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) implies r2 <=XXREAL-0R1 f2 .FUNCT-1K1 g)) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in+infty-to+inftyLIMFUNC1V4)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be divergent-in+infty-to+inftyLIMFUNC1V4"
      and A2: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
    assume Given: " ex r2 be RealXREAL-0M1 st  ex r1 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r2 & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) implies r2 <=XXREAL-0R1 f2 .FUNCT-1K1 g)"
    then obtain r2 r1 where
      [ty]:"r2 be RealXREAL-0M1" "r1 be RealXREAL-0M1" and 
      A3: "0NUMBERSK6 <XXREAL-0R3 r2"and A4: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) implies r2 <=XXREAL-0R1 f2 .FUNCT-1K1 g"
       sorry
    have " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A5: "seq be divergent-to+inftyLIMFUNC1V1"
        and A6: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A7: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies r1 <XXREAL-0R3 seq .FUNCT-1K1 n"
        using A5 sorry
      have A8: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngFUNCT-1K2 seq"
        using valued_0_th_21 sorry
      have A9: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc1_lm_3 sorry
      then have A10: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A8 sorry
      have A11: "0NUMBERSK6 <XXREAL-0R3 r2 & ( for n be NatNAT-1M1 holds r2 <=XXREAL-0R1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n)"
      proof(rule conjMI,rule ballI)
        show "0NUMBERSK6 <XXREAL-0R3 r2"
          using A3 sorry
        fix n assume [ty]: "n be NatNAT-1M1"
        have A12: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "r1 <XXREAL-0R3 seq .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A7 nat_1_th_12 sorry
        then have "r1 <XXREAL-0R3 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n"
          using nat_1_def_3 sorry
        then have "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : r1 <XXREAL-0R3 g2 }"
           sorry
        then have "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) & (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 right-open-halflineLIMFUNC1K4 r1"
          using valued_0_th_28 xxreal_1_th_230 sorry
        then have "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1)"
          using A10 xboole_0_def_4 sorry
        then have "r2 <=XXREAL-0R1 f2 .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
          using A4 sorry
        thus "r2 <=XXREAL-0R1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
          using A9 A8 funct_2_th_108 xboole_1_th_1 A12 sorry
      qed "sorry"
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc1_lm_3 sorry
      then have "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 A8 sorry
      then have A13: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =HIDDENR1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        using rfunct_2_th_8 sorry
      also have "... = (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A6 valued_0_th_27 sorry
      finally have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =HIDDENR1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A6 limfunc1_lm_3 sorry
      then have A14: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A8 sorry
      have "seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be divergent-to+inftyLIMFUNC1V1"
        using A5 limfunc1_th_26 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be divergent-to+inftyLIMFUNC1V1"
        using A1 A14 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be divergent-to+inftyLIMFUNC1V1"
        using A11 limfunc1_th_22 sorry
      thus "(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
        using A13 limfunc1_th_7 sorry
    qed "sorry"
    thus "f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in+infty-to+inftyLIMFUNC1V4"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_56:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in-infty-to+inftyLIMFUNC1V7 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) & ( ex r be RealXREAL-0M1 st f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be bounded-belowSEQ-2V2) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in-infty-to+inftyLIMFUNC1V7"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in-infty-to+inftyLIMFUNC1V7 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) implies (( ex r1 be RealXREAL-0M1 st f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) be bounded-belowSEQ-2V2) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in-infty-to+inftyLIMFUNC1V7)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be divergent-in-infty-to+inftyLIMFUNC1V7"
      and A2: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
    assume Given: " ex r1 be RealXREAL-0M1 st f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) be bounded-belowSEQ-2V2"
    then obtain r1 where
      [ty]:"r1 be RealXREAL-0M1" and 
      A3: "f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) be bounded-belowSEQ-2V2"
       sorry
    have " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A4: "seq be divergent-to-inftyLIMFUNC1V2"
        and A5: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A6: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies seq .FUNCT-1K1 n <XXREAL-0R3 r1"
        using A4 sorry
      have A7: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngFUNCT-1K2 seq"
        using valued_0_th_21 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A5 limfunc1_lm_2 sorry
      then have "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A5 A7 sorry
      then have A8: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =HIDDENR1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        using rfunct_2_th_8 sorry
      also have "... = (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A5 valued_0_th_27 sorry
      finally have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =HIDDENR1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      obtain r2 where
        [ty]:"r2 be RealXREAL-0M1" and 
        A9: " for g be objectHIDDENM1 holds g inHIDDENR3 (left-open-halflineLIMFUNC1K1 r1)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 implies r2 <=XXREAL-0R1 f2 .FUNCT-1K1 g"
        using A3 rfunct_1_th_71 sorry
      have A10: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A5 limfunc1_lm_2 sorry
      then have A11: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 sorry
      have " for n be NatNAT-1M1 holds (-XCMPLX-0K4  |.COMPLEX1K10 r2.|)-XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A12: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "seq .FUNCT-1K1 (n +XCMPLX-0K2 k) <XXREAL-0R3 r1"
          using A6 nat_1_th_12 sorry
        then have "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n <XXREAL-0R3 r1"
          using nat_1_def_3 sorry
        then have "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : g2 <XXREAL-0R3 r1 }"
           sorry
        then have "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) & (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 left-open-halflineLIMFUNC1K1 r1"
          using valued_0_th_28 xxreal_1_th_229 sorry
        then have "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 (left-open-halflineLIMFUNC1K1 r1)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A11 xboole_0_def_4 sorry
        then have "r2 <=XXREAL-0R1 f2 .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
          using A9 sorry
        then have A13: "r2 <=XXREAL-0R1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
          using A10 A7 funct_2_th_108 xboole_1_th_1 A12 sorry
        have "-XCMPLX-0K4  |.COMPLEX1K10 r2.| <=XXREAL-0R1 r2"
          using absvalue_th_4 sorry
        then have "(-XCMPLX-0K4  |.COMPLEX1K10 r2.|)-XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 r2 -XCMPLX-0K6 0NUMBERSK6"
          using xreal_1_th_15 sorry
        thus "(-XCMPLX-0K4  |.COMPLEX1K10 r2.|)-XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
          using A13 xxreal_0_th_2 sorry
      qed "sorry"
      then have A14: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be bounded-belowSEQ-2V4"
         sorry
      have "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A5 limfunc1_lm_2 sorry
      then have A15: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A7 sorry
      have "seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be divergent-to-inftyLIMFUNC1V2"
        using A4 limfunc1_th_27 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be divergent-to+inftyLIMFUNC1V1"
        using A1 A15 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be divergent-to+inftyLIMFUNC1V1"
        using A14 limfunc1_th_9 sorry
      thus "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
        using A8 limfunc1_th_7 sorry
    qed "sorry"
    thus "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in-infty-to+inftyLIMFUNC1V7"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_57:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in-infty-to+inftyLIMFUNC1V7 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) & ( ex r be RealXREAL-0M1 st  ex r1 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) implies r <=XXREAL-0R1 f2 .FUNCT-1K1 g)) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in-infty-to+inftyLIMFUNC1V7"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in-infty-to+inftyLIMFUNC1V7 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) implies (( ex r2 be RealXREAL-0M1 st  ex r1 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r2 & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) implies r2 <=XXREAL-0R1 f2 .FUNCT-1K1 g)) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in-infty-to+inftyLIMFUNC1V7)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be divergent-in-infty-to+inftyLIMFUNC1V7"
      and A2: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
    assume Given: " ex r2 be RealXREAL-0M1 st  ex r1 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r2 & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) implies r2 <=XXREAL-0R1 f2 .FUNCT-1K1 g)"
    then obtain r2 r1 where
      [ty]:"r2 be RealXREAL-0M1" "r1 be RealXREAL-0M1" and 
      A3: "0NUMBERSK6 <XXREAL-0R3 r2"and A4: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) implies r2 <=XXREAL-0R1 f2 .FUNCT-1K1 g"
       sorry
    have " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A5: "seq be divergent-to-inftyLIMFUNC1V2"
        and A6: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A7: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies seq .FUNCT-1K1 n <XXREAL-0R3 r1"
        using A5 sorry
      have A8: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngFUNCT-1K2 seq"
        using valued_0_th_21 sorry
      have A9: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc1_lm_3 sorry
      then have A10: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A8 sorry
      have A11: "0NUMBERSK6 <XXREAL-0R3 r2 & ( for n be NatNAT-1M1 holds r2 <=XXREAL-0R1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n)"
      proof(rule conjMI,rule ballI)
        show "0NUMBERSK6 <XXREAL-0R3 r2"
          using A3 sorry
        fix n assume [ty]: "n be NatNAT-1M1"
        have A12: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "seq .FUNCT-1K1 (n +XCMPLX-0K2 k) <XXREAL-0R3 r1"
          using A7 nat_1_th_12 sorry
        then have "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n <XXREAL-0R3 r1"
          using nat_1_def_3 sorry
        then have "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : g2 <XXREAL-0R3 r1 }"
           sorry
        then have "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) & (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 left-open-halflineLIMFUNC1K1 r1"
          using valued_0_th_28 xxreal_1_th_229 sorry
        then have "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1)"
          using A10 xboole_0_def_4 sorry
        then have "r2 <=XXREAL-0R1 f2 .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
          using A4 sorry
        thus "r2 <=XXREAL-0R1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
          using A9 A8 funct_2_th_108 xboole_1_th_1 A12 sorry
      qed "sorry"
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc1_lm_3 sorry
      then have "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 A8 sorry
      then have A13: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =HIDDENR1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        using rfunct_2_th_8 sorry
      also have "... = (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A6 valued_0_th_27 sorry
      finally have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =HIDDENR1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A6 limfunc1_lm_3 sorry
      then have A14: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A8 sorry
      have "seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be divergent-to-inftyLIMFUNC1V2"
        using A5 limfunc1_th_27 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be divergent-to+inftyLIMFUNC1V1"
        using A1 A14 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be divergent-to+inftyLIMFUNC1V1"
        using A11 limfunc1_th_22 sorry
      thus "(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
        using A13 limfunc1_th_7 sorry
    qed "sorry"
    thus "f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in-infty-to+inftyLIMFUNC1V7"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_58:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds (((f be divergent-in+infty-to+inftyLIMFUNC1V4 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in+infty-to+inftyLIMFUNC1V4) & (f be divergent-in+infty-to+inftyLIMFUNC1V4 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in+infty-to-inftyLIMFUNC1V5)) & (f be divergent-in+infty-to-inftyLIMFUNC1V5 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in+infty-to-inftyLIMFUNC1V5)) & (f be divergent-in+infty-to-inftyLIMFUNC1V5 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in+infty-to+inftyLIMFUNC1V4)"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds (f be divergent-in+infty-to+inftyLIMFUNC1V4 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in+infty-to+inftyLIMFUNC1V4) & ((f be divergent-in+infty-to+inftyLIMFUNC1V4 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in+infty-to-inftyLIMFUNC1V5) & ((f be divergent-in+infty-to-inftyLIMFUNC1V5 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in+infty-to-inftyLIMFUNC1V5) & (f be divergent-in+infty-to-inftyLIMFUNC1V5 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in+infty-to+inftyLIMFUNC1V4)))"
  proof(rule ballI,rule ballI,rule conjMI,rule conjMI,rule conjMI,rule impMI ,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix r assume [ty]: "r be RealXREAL-0M1"
    show "f be divergent-in+infty-to+inftyLIMFUNC1V4 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in+infty-to+inftyLIMFUNC1V4"
    proof(rule impMI ,rule impI)
      assume A1: "f be divergent-in+infty-to+inftyLIMFUNC1V4"
        and A2: "r >XXREAL-0R4 0NUMBERSK6"
      have A3: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
      proof(rule ballI,rule impMI ,rule impI)
        fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
        assume A4: "seq be divergent-to+inftyLIMFUNC1V1"
          and A5: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
        have A6: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A5 valued_1_def_5 sorry
        then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
          using A1 A4 sorry
        then have "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
          using A2 limfunc1_th_13 sorry
        thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
          using A6 rfunct_2_th_9 sorry
      qed "sorry"
      have " for r1 be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r1 <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      proof(rule ballI)
        fix r1 assume [ty]: "r1 be RealXREAL-0M1"
        obtain g where
          [ty]:"g be RealXREAL-0M1" and 
          A7: "r1 <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A1 sorry
        show " ex g be RealXREAL-0M1 st r1 <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
        proof(rule bexI[of _ "g"])
          show "r1 <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
            using A7 valued_1_def_5 sorry
        qed "sorry"
      qed "sorry"
      thus "r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in+infty-to+inftyLIMFUNC1V4"
        using A3 sorry
    qed
    show "f be divergent-in+infty-to+inftyLIMFUNC1V4 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in+infty-to-inftyLIMFUNC1V5"
    proof(rule impMI ,rule impI)
      assume A8: "f be divergent-in+infty-to+inftyLIMFUNC1V4"
        and A9: "r <XXREAL-0R3 0NUMBERSK6"
      have A10: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
      proof(rule ballI,rule impMI ,rule impI)
        fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
        assume A11: "seq be divergent-to+inftyLIMFUNC1V1"
          and A12: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
        have A13: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A12 valued_1_def_5 sorry
        then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
          using A8 A11 sorry
        then have "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
          using A9 limfunc1_th_13 sorry
        thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
          using A13 rfunct_2_th_9 sorry
      qed "sorry"
      have " for r1 be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r1 <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      proof(rule ballI)
        fix r1 assume [ty]: "r1 be RealXREAL-0M1"
        obtain g where
          [ty]:"g be RealXREAL-0M1" and 
          A14: "r1 <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A8 sorry
        show " ex g be RealXREAL-0M1 st r1 <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
        proof(rule bexI[of _ "g"])
          show "r1 <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
            using A14 valued_1_def_5 sorry
        qed "sorry"
      qed "sorry"
      thus "r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in+infty-to-inftyLIMFUNC1V5"
        using A10 sorry
    qed
    show "f be divergent-in+infty-to-inftyLIMFUNC1V5 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in+infty-to-inftyLIMFUNC1V5"
    proof(rule impMI ,rule impI)
      assume A15: "f be divergent-in+infty-to-inftyLIMFUNC1V5"
        and A16: "r >XXREAL-0R4 0NUMBERSK6"
      have A17: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
      proof(rule ballI,rule impMI ,rule impI)
        fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
        assume A18: "seq be divergent-to+inftyLIMFUNC1V1"
          and A19: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
        have A20: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A19 valued_1_def_5 sorry
        then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
          using A15 A18 sorry
        then have "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
          using A16 limfunc1_th_14 sorry
        thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
          using A20 rfunct_2_th_9 sorry
      qed "sorry"
      have " for r1 be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r1 <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      proof(rule ballI)
        fix r1 assume [ty]: "r1 be RealXREAL-0M1"
        obtain g where
          [ty]:"g be RealXREAL-0M1" and 
          A21: "r1 <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A15 sorry
        show " ex g be RealXREAL-0M1 st r1 <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
        proof(rule bexI[of _ "g"])
          show "r1 <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
            using A21 valued_1_def_5 sorry
        qed "sorry"
      qed "sorry"
      thus "r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in+infty-to-inftyLIMFUNC1V5"
        using A17 sorry
    qed
    assume A22: "f be divergent-in+infty-to-inftyLIMFUNC1V5"
      and A23: "r <XXREAL-0R3 0NUMBERSK6"
    have A24: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A25: "seq be divergent-to+inftyLIMFUNC1V1"
        and A26: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      have A27: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A26 valued_1_def_5 sorry
      then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
        using A22 A25 sorry
      then have "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
        using A23 limfunc1_th_14 sorry
      thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
        using A27 rfunct_2_th_9 sorry
    qed "sorry"
    have " for r1 be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r1 <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
    proof(rule ballI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      obtain g where
        [ty]:"g be RealXREAL-0M1" and 
        A28: "r1 <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A22 sorry
      show " ex g be RealXREAL-0M1 st r1 <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      proof(rule bexI[of _ "g"])
        show "r1 <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
          using A28 valued_1_def_5 sorry
      qed "sorry"
    qed "sorry"
    thus "r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in+infty-to+inftyLIMFUNC1V4"
      using A24 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_59:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds (((f be divergent-in-infty-to+inftyLIMFUNC1V7 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in-infty-to+inftyLIMFUNC1V7) & (f be divergent-in-infty-to+inftyLIMFUNC1V7 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in-infty-to-inftyLIMFUNC1V8)) & (f be divergent-in-infty-to-inftyLIMFUNC1V8 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in-infty-to-inftyLIMFUNC1V8)) & (f be divergent-in-infty-to-inftyLIMFUNC1V8 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in-infty-to+inftyLIMFUNC1V7)"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds (f be divergent-in-infty-to+inftyLIMFUNC1V7 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in-infty-to+inftyLIMFUNC1V7) & ((f be divergent-in-infty-to+inftyLIMFUNC1V7 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in-infty-to-inftyLIMFUNC1V8) & ((f be divergent-in-infty-to-inftyLIMFUNC1V8 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in-infty-to-inftyLIMFUNC1V8) & (f be divergent-in-infty-to-inftyLIMFUNC1V8 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in-infty-to+inftyLIMFUNC1V7)))"
  proof(rule ballI,rule ballI,rule conjMI,rule conjMI,rule conjMI,rule impMI ,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix r assume [ty]: "r be RealXREAL-0M1"
    show "f be divergent-in-infty-to+inftyLIMFUNC1V7 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in-infty-to+inftyLIMFUNC1V7"
    proof(rule impMI ,rule impI)
      assume A1: "f be divergent-in-infty-to+inftyLIMFUNC1V7"
        and A2: "r >XXREAL-0R4 0NUMBERSK6"
      have A3: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
      proof(rule ballI,rule impMI ,rule impI)
        fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
        assume A4: "seq be divergent-to-inftyLIMFUNC1V2"
          and A5: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
        have A6: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A5 valued_1_def_5 sorry
        then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
          using A1 A4 sorry
        then have "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
          using A2 limfunc1_th_13 sorry
        thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
          using A6 rfunct_2_th_9 sorry
      qed "sorry"
      have " for r1 be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r1 & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      proof(rule ballI)
        fix r1 assume [ty]: "r1 be RealXREAL-0M1"
        obtain g where
          [ty]:"g be RealXREAL-0M1" and 
          A7: "g <XXREAL-0R3 r1 & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A1 sorry
        show " ex g be RealXREAL-0M1 st g <XXREAL-0R3 r1 & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
        proof(rule bexI[of _ "g"])
          show "g <XXREAL-0R3 r1 & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
            using A7 valued_1_def_5 sorry
        qed "sorry"
      qed "sorry"
      thus "r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in-infty-to+inftyLIMFUNC1V7"
        using A3 sorry
    qed
    show "f be divergent-in-infty-to+inftyLIMFUNC1V7 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in-infty-to-inftyLIMFUNC1V8"
    proof(rule impMI ,rule impI)
      assume A8: "f be divergent-in-infty-to+inftyLIMFUNC1V7"
        and A9: "r <XXREAL-0R3 0NUMBERSK6"
      have A10: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
      proof(rule ballI,rule impMI ,rule impI)
        fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
        assume A11: "seq be divergent-to-inftyLIMFUNC1V2"
          and A12: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
        have A13: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A12 valued_1_def_5 sorry
        then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
          using A8 A11 sorry
        then have "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
          using A9 limfunc1_th_13 sorry
        thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
          using A13 rfunct_2_th_9 sorry
      qed "sorry"
      have " for r1 be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r1 & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      proof(rule ballI)
        fix r1 assume [ty]: "r1 be RealXREAL-0M1"
        obtain g where
          [ty]:"g be RealXREAL-0M1" and 
          A14: "g <XXREAL-0R3 r1 & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A8 sorry
        show " ex g be RealXREAL-0M1 st g <XXREAL-0R3 r1 & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
        proof(rule bexI[of _ "g"])
          show "g <XXREAL-0R3 r1 & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
            using A14 valued_1_def_5 sorry
        qed "sorry"
      qed "sorry"
      thus "r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in-infty-to-inftyLIMFUNC1V8"
        using A10 sorry
    qed
    show "f be divergent-in-infty-to-inftyLIMFUNC1V8 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in-infty-to-inftyLIMFUNC1V8"
    proof(rule impMI ,rule impI)
      assume A15: "f be divergent-in-infty-to-inftyLIMFUNC1V8"
        and A16: "r >XXREAL-0R4 0NUMBERSK6"
      have A17: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
      proof(rule ballI,rule impMI ,rule impI)
        fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
        assume A18: "seq be divergent-to-inftyLIMFUNC1V2"
          and A19: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
        have A20: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A19 valued_1_def_5 sorry
        then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
          using A15 A18 sorry
        then have "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
          using A16 limfunc1_th_14 sorry
        thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
          using A20 rfunct_2_th_9 sorry
      qed "sorry"
      have " for r1 be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r1 & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      proof(rule ballI)
        fix r1 assume [ty]: "r1 be RealXREAL-0M1"
        obtain g where
          [ty]:"g be RealXREAL-0M1" and 
          A21: "g <XXREAL-0R3 r1 & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A15 sorry
        show " ex g be RealXREAL-0M1 st g <XXREAL-0R3 r1 & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
        proof(rule bexI[of _ "g"])
          show "g <XXREAL-0R3 r1 & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
            using A21 valued_1_def_5 sorry
        qed "sorry"
      qed "sorry"
      thus "r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in-infty-to-inftyLIMFUNC1V8"
        using A17 sorry
    qed
    assume A22: "f be divergent-in-infty-to-inftyLIMFUNC1V8"
      and A23: "r <XXREAL-0R3 0NUMBERSK6"
    have A24: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A25: "seq be divergent-to-inftyLIMFUNC1V2"
        and A26: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      have A27: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A26 valued_1_def_5 sorry
      then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
        using A22 A25 sorry
      then have "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
        using A23 limfunc1_th_14 sorry
      thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
        using A27 rfunct_2_th_9 sorry
    qed "sorry"
    have " for r1 be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r1 & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
    proof(rule ballI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      obtain g where
        [ty]:"g be RealXREAL-0M1" and 
        A28: "g <XXREAL-0R3 r1 & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A22 sorry
      show " ex g be RealXREAL-0M1 st g <XXREAL-0R3 r1 & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      proof(rule bexI[of _ "g"])
        show "g <XXREAL-0R3 r1 & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
          using A28 valued_1_def_5 sorry
      qed "sorry"
    qed "sorry"
    thus "r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in-infty-to+inftyLIMFUNC1V7"
      using A24 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_60:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be divergent-in+infty-to+inftyLIMFUNC1V4 or f be divergent-in+infty-to-inftyLIMFUNC1V5 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in+infty-to+inftyLIMFUNC1V4"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be divergent-in+infty-to+inftyLIMFUNC1V4 or f be divergent-in+infty-to-inftyLIMFUNC1V5 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in+infty-to+inftyLIMFUNC1V4"
  proof(rule ballI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f be divergent-in+infty-to+inftyLIMFUNC1V4 or f be divergent-in+infty-to-inftyLIMFUNC1V5"
    have "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in+infty-to+inftyLIMFUNC1V4"
    proof-
      show "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in+infty-to+inftyLIMFUNC1V4"
      proof-
        have cases: "f be divergent-in+infty-to+inftyLIMFUNC1V4 or f be divergent-in+infty-to-inftyLIMFUNC1V5"
          using A1 sorry
        have case1: "f be divergent-in+infty-to+inftyLIMFUNC1V4 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in+infty-to+inftyLIMFUNC1V4"
        proof(rule impI)
          assume A2: "f be divergent-in+infty-to+inftyLIMFUNC1V4"
          have A3: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
          proof(rule ballI,rule impMI ,rule impI)
            fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
            assume A4: "seq be divergent-to+inftyLIMFUNC1V1"
              and A5: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
            have A6: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using A5 valued_1_def_11 sorry
            then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
              using A2 A4 sorry
            then have " |.VALUED-1K58\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq.| be divergent-to+inftyLIMFUNC1V1"
              using limfunc1_th_25 sorry
            thus "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
              using A6 rfunct_2_th_10 sorry
          qed "sorry"
          have " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
          proof(rule ballI)
            fix r assume [ty]: "r be RealXREAL-0M1"
            obtain g where
              [ty]:"g be RealXREAL-0M1" and 
              A7: "r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using A2 sorry
            show " ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
            proof(rule bexI[of _ "g"])
              show "r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
                using A7 valued_1_def_11 sorry
            qed "sorry"
          qed "sorry"
          thus "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in+infty-to+inftyLIMFUNC1V4"
            using A3 sorry
        qed
        have case2: "f be divergent-in+infty-to-inftyLIMFUNC1V5 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in+infty-to+inftyLIMFUNC1V4"
        proof(rule impI)
          assume A8: "f be divergent-in+infty-to-inftyLIMFUNC1V5"
          have A9: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
          proof(rule ballI,rule impMI ,rule impI)
            fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
            assume A10: "seq be divergent-to+inftyLIMFUNC1V1"
              and A11: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
            have A12: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using A11 valued_1_def_11 sorry
            then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
              using A8 A10 sorry
            then have " |.VALUED-1K58\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq.| be divergent-to+inftyLIMFUNC1V1"
              using limfunc1_th_25 sorry
            thus "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
              using A12 rfunct_2_th_10 sorry
          qed "sorry"
          have " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
          proof(rule ballI)
            fix r assume [ty]: "r be RealXREAL-0M1"
            obtain g where
              [ty]:"g be RealXREAL-0M1" and 
              A13: "r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using A8 sorry
            show " ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
            proof(rule bexI[of _ "g"])
              show "r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
                using A13 valued_1_def_11 sorry
            qed "sorry"
          qed "sorry"
          thus "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in+infty-to+inftyLIMFUNC1V4"
            using A9 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in+infty-to+inftyLIMFUNC1V4"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_61:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be divergent-in-infty-to+inftyLIMFUNC1V7 or f be divergent-in-infty-to-inftyLIMFUNC1V8 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in-infty-to+inftyLIMFUNC1V7"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be divergent-in-infty-to+inftyLIMFUNC1V7 or f be divergent-in-infty-to-inftyLIMFUNC1V8 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in-infty-to+inftyLIMFUNC1V7"
  proof(rule ballI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f be divergent-in-infty-to+inftyLIMFUNC1V7 or f be divergent-in-infty-to-inftyLIMFUNC1V8"
    have "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in-infty-to+inftyLIMFUNC1V7"
    proof-
      show "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in-infty-to+inftyLIMFUNC1V7"
      proof-
        have cases: "f be divergent-in-infty-to+inftyLIMFUNC1V7 or f be divergent-in-infty-to-inftyLIMFUNC1V8"
          using A1 sorry
        have case1: "f be divergent-in-infty-to+inftyLIMFUNC1V7 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in-infty-to+inftyLIMFUNC1V7"
        proof(rule impI)
          assume A2: "f be divergent-in-infty-to+inftyLIMFUNC1V7"
          have A3: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
          proof(rule ballI,rule impMI ,rule impI)
            fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
            assume A4: "seq be divergent-to-inftyLIMFUNC1V2"
              and A5: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
            have A6: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using A5 valued_1_def_11 sorry
            then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
              using A2 A4 sorry
            then have "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq) be divergent-to+inftyLIMFUNC1V1"
              using limfunc1_th_25 sorry
            thus "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
              using A6 rfunct_2_th_10 sorry
          qed "sorry"
          have " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
          proof(rule ballI)
            fix r assume [ty]: "r be RealXREAL-0M1"
            obtain g where
              [ty]:"g be RealXREAL-0M1" and 
              A7: "g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using A2 sorry
            show " ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
            proof(rule bexI[of _ "g"])
              show "g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
                using A7 valued_1_def_11 sorry
            qed "sorry"
          qed "sorry"
          thus "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in-infty-to+inftyLIMFUNC1V7"
            using A3 sorry
        qed
        have case2: "f be divergent-in-infty-to-inftyLIMFUNC1V8 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in-infty-to+inftyLIMFUNC1V7"
        proof(rule impI)
          assume A8: "f be divergent-in-infty-to-inftyLIMFUNC1V8"
          have A9: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
          proof(rule ballI,rule impMI ,rule impI)
            fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
            assume A10: "seq be divergent-to-inftyLIMFUNC1V2"
              and A11: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
            have A12: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using A11 valued_1_def_11 sorry
            then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
              using A8 A10 sorry
            then have "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq) be divergent-to+inftyLIMFUNC1V1"
              using limfunc1_th_25 sorry
            thus "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
              using A12 rfunct_2_th_10 sorry
          qed "sorry"
          have " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
          proof(rule ballI)
            fix r assume [ty]: "r be RealXREAL-0M1"
            obtain g where
              [ty]:"g be RealXREAL-0M1" and 
              A13: "g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using A8 sorry
            show " ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
            proof(rule bexI[of _ "g"])
              show "g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
                using A13 valued_1_def_11 sorry
            qed "sorry"
          qed "sorry"
          thus "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in-infty-to+inftyLIMFUNC1V7"
            using A9 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in-infty-to+inftyLIMFUNC1V7"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_62:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be non-decreasingVALUED-0V11 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be bounded-aboveSEQ-2V1) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies f be divergent-in+infty-to+inftyLIMFUNC1V4"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r1 be RealXREAL-0M1 st f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) be non-decreasingVALUED-0V11 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) be bounded-aboveSEQ-2V1) implies (( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies f be divergent-in+infty-to+inftyLIMFUNC1V4)"
  proof(rule ballI,rule impI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume Given: " ex r1 be RealXREAL-0M1 st f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) be non-decreasingVALUED-0V11 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) be bounded-aboveSEQ-2V1"
    then obtain r1 where
      [ty]:"r1 be RealXREAL-0M1" and 
      A1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) be non-decreasingVALUED-0V11"and A2: " not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) be bounded-aboveSEQ-2V1"
       sorry
    have A3: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A4: "seq be divergent-to+inftyLIMFUNC1V1"
        and A5: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      have " for r be RealXREAL-0M1 holds  ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies r <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq .FUNCT-1K1 m"
      proof(rule ballI)
        fix r assume [ty]: "r be RealXREAL-0M1"
        obtain g1 where
          [ty]:"g1 be objectHIDDENM1" and 
          A6: "g1 inHIDDENR3 (right-open-halflineLIMFUNC1K4 r1)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and A7: "r <XXREAL-0R3 f .FUNCT-1K1 g1"
          using A2 rfunct_1_th_70 sorry
        have 
          [ty]:"g1 be RealXREAL-0M1"
          using A6 sorry
        obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A8: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 g1.| +XCMPLX-0K2  |.COMPLEX1K10 r1.| <XXREAL-0R3 seq .FUNCT-1K1 m"
          using A4 sorry
        show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies r <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq .FUNCT-1K1 m"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          have A9: "m inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          assume "n <=XXREAL-0R1 m"
          then have A10: " |.COMPLEX1K10 g1.| +XCMPLX-0K2  |.COMPLEX1K10 r1.| <XXREAL-0R3 seq .FUNCT-1K1 m"
            using A8 sorry
          have "r1 <=XXREAL-0R1  |.COMPLEX1K10 r1.| & 0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 g1.|"
            using absvalue_th_4 complex1_th_46 sorry
          then have "0NUMBERSK6 +XCMPLX-0K2 r1 <=XXREAL-0R1  |.COMPLEX1K10 g1.| +XCMPLX-0K2  |.COMPLEX1K10 r1.|"
            using xreal_1_th_7 sorry
          then have "r1 <XXREAL-0R3 seq .FUNCT-1K1 m"
            using A10 xxreal_0_th_2 sorry
          then have "seq .FUNCT-1K1 m inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : r1 <XXREAL-0R3 g2 }"
             sorry
          then have "seq .FUNCT-1K1 m inTARSKIR2 rngFUNCT-1K2 seq & seq .FUNCT-1K1 m inTARSKIR2 right-open-halflineLIMFUNC1K4 r1"
            using valued_0_th_28 xxreal_1_th_230 sorry
          then have A11: "seq .FUNCT-1K1 m inTARSKIR2 (right-open-halflineLIMFUNC1K4 r1)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using A5 xboole_0_def_4 sorry
          have "g1 <=XXREAL-0R1  |.COMPLEX1K10 g1.| & 0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r1.|"
            using absvalue_th_4 complex1_th_46 sorry
          then have "g1 +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 g1.| +XCMPLX-0K2  |.COMPLEX1K10 r1.|"
            using xreal_1_th_7 sorry
          then have "g1 <XXREAL-0R3 seq .FUNCT-1K1 m"
            using A10 xxreal_0_th_2 sorry
          then have "f .FUNCT-1K1 g1 <=XXREAL-0R1 f .FUNCT-1K1 (seq .FUNCT-1K1 m)"
            using A1 A6 A11 rfunct_2_th_22 sorry
          then have "r <XXREAL-0R3 f .FUNCT-1K1 (seq .FUNCT-1K1 m)"
            using A7 xxreal_0_th_2 sorry
          thus "r <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq .FUNCT-1K1 m"
            using A5 funct_2_th_108 A9 sorry
        qed "sorry"
      qed "sorry"
      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
         sorry
    qed "sorry"
    assume " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    thus "f be divergent-in+infty-to+inftyLIMFUNC1V4"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_63:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be increasingVALUED-0V9 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be bounded-aboveSEQ-2V1) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies f be divergent-in+infty-to+inftyLIMFUNC1V4"
  using limfunc1_th_62 sorry

mtheorem limfunc1_th_64:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be non-increasingVALUED-0V12 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be bounded-belowSEQ-2V2) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies f be divergent-in+infty-to-inftyLIMFUNC1V5"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r1 be RealXREAL-0M1 st f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) be non-increasingVALUED-0V12 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) be bounded-belowSEQ-2V2) implies (( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies f be divergent-in+infty-to-inftyLIMFUNC1V5)"
  proof(rule ballI,rule impI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume Given: " ex r1 be RealXREAL-0M1 st f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) be non-increasingVALUED-0V12 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) be bounded-belowSEQ-2V2"
    then obtain r1 where
      [ty]:"r1 be RealXREAL-0M1" and 
      A1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) be non-increasingVALUED-0V12"and A2: " not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) be bounded-belowSEQ-2V2"
       sorry
    have A3: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A4: "seq be divergent-to+inftyLIMFUNC1V1"
        and A5: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      have " for r be RealXREAL-0M1 holds  ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq .FUNCT-1K1 m <XXREAL-0R3 r"
      proof(rule ballI)
        fix r assume [ty]: "r be RealXREAL-0M1"
        obtain g1 where
          [ty]:"g1 be objectHIDDENM1" and 
          A6: "g1 inHIDDENR3 (right-open-halflineLIMFUNC1K4 r1)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and A7: "f .FUNCT-1K1 g1 <XXREAL-0R3 r"
          using A2 rfunct_1_th_71 sorry
        have 
          [ty]:"g1 be RealXREAL-0M1"
          using A6 sorry
        obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A8: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 g1.| +XCMPLX-0K2  |.COMPLEX1K10 r1.| <XXREAL-0R3 seq .FUNCT-1K1 m"
          using A4 sorry
        show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq .FUNCT-1K1 m <XXREAL-0R3 r"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          have A9: "m inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          assume "n <=XXREAL-0R1 m"
          then have A10: " |.COMPLEX1K10 g1.| +XCMPLX-0K2  |.COMPLEX1K10 r1.| <XXREAL-0R3 seq .FUNCT-1K1 m"
            using A8 sorry
          have "r1 <=XXREAL-0R1  |.COMPLEX1K10 r1.| & 0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 g1.|"
            using absvalue_th_4 complex1_th_46 sorry
          then have "0NUMBERSK6 +XCMPLX-0K2 r1 <=XXREAL-0R1  |.COMPLEX1K10 g1.| +XCMPLX-0K2  |.COMPLEX1K10 r1.|"
            using xreal_1_th_7 sorry
          then have "r1 <XXREAL-0R3 seq .FUNCT-1K1 m"
            using A10 xxreal_0_th_2 sorry
          then have "seq .FUNCT-1K1 m inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : r1 <XXREAL-0R3 g2 }"
             sorry
          then have "seq .FUNCT-1K1 m inTARSKIR2 rngFUNCT-1K2 seq & seq .FUNCT-1K1 m inTARSKIR2 right-open-halflineLIMFUNC1K4 r1"
            using valued_0_th_28 xxreal_1_th_230 sorry
          then have A11: "seq .FUNCT-1K1 m inTARSKIR2 (right-open-halflineLIMFUNC1K4 r1)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using A5 xboole_0_def_4 sorry
          have "g1 <=XXREAL-0R1  |.COMPLEX1K10 g1.| & 0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r1.|"
            using absvalue_th_4 complex1_th_46 sorry
          then have "g1 +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 g1.| +XCMPLX-0K2  |.COMPLEX1K10 r1.|"
            using xreal_1_th_7 sorry
          then have "g1 <XXREAL-0R3 seq .FUNCT-1K1 m"
            using A10 xxreal_0_th_2 sorry
          then have "f .FUNCT-1K1 (seq .FUNCT-1K1 m) <=XXREAL-0R1 f .FUNCT-1K1 g1"
            using A1 A6 A11 rfunct_2_th_23 sorry
          then have "f .FUNCT-1K1 (seq .FUNCT-1K1 m) <XXREAL-0R3 r"
            using A7 xxreal_0_th_2 sorry
          thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq .FUNCT-1K1 m <XXREAL-0R3 r"
            using A5 funct_2_th_108 A9 sorry
        qed "sorry"
      qed "sorry"
      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
         sorry
    qed "sorry"
    assume " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    thus "f be divergent-in+infty-to-inftyLIMFUNC1V5"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_65:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be decreasingVALUED-0V10 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be bounded-belowSEQ-2V2) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies f be divergent-in+infty-to-inftyLIMFUNC1V5"
  using limfunc1_th_64 sorry

mtheorem limfunc1_th_66:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be non-increasingVALUED-0V12 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be bounded-aboveSEQ-2V1) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies f be divergent-in-infty-to+inftyLIMFUNC1V7"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r1 be RealXREAL-0M1 st f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) be non-increasingVALUED-0V12 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) be bounded-aboveSEQ-2V1) implies (( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies f be divergent-in-infty-to+inftyLIMFUNC1V7)"
  proof(rule ballI,rule impI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume Given: " ex r1 be RealXREAL-0M1 st f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) be non-increasingVALUED-0V12 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) be bounded-aboveSEQ-2V1"
    then obtain r1 where
      [ty]:"r1 be RealXREAL-0M1" and 
      A1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) be non-increasingVALUED-0V12"and A2: " not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) be bounded-aboveSEQ-2V1"
       sorry
    have A3: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A4: "seq be divergent-to-inftyLIMFUNC1V2"
        and A5: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      have " for r be RealXREAL-0M1 holds  ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies r <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq .FUNCT-1K1 m"
      proof(rule ballI)
        fix r assume [ty]: "r be RealXREAL-0M1"
        obtain g1 where
          [ty]:"g1 be objectHIDDENM1" and 
          A6: "g1 inHIDDENR3 (left-open-halflineLIMFUNC1K1 r1)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and A7: "r <XXREAL-0R3 f .FUNCT-1K1 g1"
          using A2 rfunct_1_th_70 sorry
        have 
          [ty]:"g1 be RealXREAL-0M1"
          using A6 sorry
        obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A8: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .FUNCT-1K1 m <XXREAL-0R3 (-XCMPLX-0K4  |.COMPLEX1K10 r1.|)-XCMPLX-0K6  |.COMPLEX1K10 g1.|"
          using A4 sorry
        show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies r <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq .FUNCT-1K1 m"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          have A9: "m inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          assume "n <=XXREAL-0R1 m"
          then have A10: "seq .FUNCT-1K1 m <XXREAL-0R3 (-XCMPLX-0K4  |.COMPLEX1K10 r1.|)-XCMPLX-0K6  |.COMPLEX1K10 g1.|"
            using A8 sorry
          have "-XCMPLX-0K4  |.COMPLEX1K10 r1.| <=XXREAL-0R1 r1 & 0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 g1.|"
            using absvalue_th_4 complex1_th_46 sorry
          then have "(-XCMPLX-0K4  |.COMPLEX1K10 r1.|)-XCMPLX-0K6  |.COMPLEX1K10 g1.| <=XXREAL-0R1 r1 -XCMPLX-0K6 0NUMBERSK6"
            using xreal_1_th_13 sorry
          then have "seq .FUNCT-1K1 m <XXREAL-0R3 r1"
            using A10 xxreal_0_th_2 sorry
          then have "seq .FUNCT-1K1 m inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : g2 <XXREAL-0R3 r1 }"
             sorry
          then have "seq .FUNCT-1K1 m inTARSKIR2 rngFUNCT-1K2 seq & seq .FUNCT-1K1 m inTARSKIR2 left-open-halflineLIMFUNC1K1 r1"
            using valued_0_th_28 xxreal_1_th_229 sorry
          then have A11: "seq .FUNCT-1K1 m inTARSKIR2 (left-open-halflineLIMFUNC1K1 r1)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using A5 xboole_0_def_4 sorry
          have "-XCMPLX-0K4  |.COMPLEX1K10 g1.| <=XXREAL-0R1 g1 & 0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r1.|"
            using absvalue_th_4 complex1_th_46 sorry
          then have "(-XCMPLX-0K4  |.COMPLEX1K10 g1.|)-XCMPLX-0K6  |.COMPLEX1K10 r1.| <=XXREAL-0R1 g1 -XCMPLX-0K6 0NUMBERSK6"
            using xreal_1_th_13 sorry
          then have "seq .FUNCT-1K1 m <XXREAL-0R3 g1"
            using A10 xxreal_0_th_2 sorry
          then have "f .FUNCT-1K1 g1 <=XXREAL-0R1 f .FUNCT-1K1 (seq .FUNCT-1K1 m)"
            using A1 A6 A11 rfunct_2_th_23 sorry
          then have "r <XXREAL-0R3 f .FUNCT-1K1 (seq .FUNCT-1K1 m)"
            using A7 xxreal_0_th_2 sorry
          thus "r <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq .FUNCT-1K1 m"
            using A5 funct_2_th_108 A9 sorry
        qed "sorry"
      qed "sorry"
      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
         sorry
    qed "sorry"
    assume " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    thus "f be divergent-in-infty-to+inftyLIMFUNC1V7"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_67:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be decreasingVALUED-0V10 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be bounded-aboveSEQ-2V1) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies f be divergent-in-infty-to+inftyLIMFUNC1V7"
  using limfunc1_th_66 sorry

mtheorem limfunc1_th_68:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be non-decreasingVALUED-0V11 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be bounded-belowSEQ-2V2) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies f be divergent-in-infty-to-inftyLIMFUNC1V8"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r1 be RealXREAL-0M1 st f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) be non-decreasingVALUED-0V11 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) be bounded-belowSEQ-2V2) implies (( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies f be divergent-in-infty-to-inftyLIMFUNC1V8)"
  proof(rule ballI,rule impI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume Given: " ex r1 be RealXREAL-0M1 st f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) be non-decreasingVALUED-0V11 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) be bounded-belowSEQ-2V2"
    then obtain r1 where
      [ty]:"r1 be RealXREAL-0M1" and 
      A1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) be non-decreasingVALUED-0V11"and A2: " not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) be bounded-belowSEQ-2V2"
       sorry
    have A3: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A4: "seq be divergent-to-inftyLIMFUNC1V2"
        and A5: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      have " for r be RealXREAL-0M1 holds  ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq .FUNCT-1K1 m <XXREAL-0R3 r"
      proof(rule ballI)
        fix r assume [ty]: "r be RealXREAL-0M1"
        obtain g1 where
          [ty]:"g1 be objectHIDDENM1" and 
          A6: "g1 inHIDDENR3 (left-open-halflineLIMFUNC1K1 r1)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and A7: "f .FUNCT-1K1 g1 <XXREAL-0R3 r"
          using A2 rfunct_1_th_71 sorry
        have 
          [ty]:"g1 be RealXREAL-0M1"
          using A6 sorry
        obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A8: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .FUNCT-1K1 m <XXREAL-0R3 (-XCMPLX-0K4  |.COMPLEX1K10 r1.|)-XCMPLX-0K6  |.COMPLEX1K10 g1.|"
          using A4 sorry
        show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq .FUNCT-1K1 m <XXREAL-0R3 r"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          have A9: "m inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          assume "n <=XXREAL-0R1 m"
          then have A10: "seq .FUNCT-1K1 m <XXREAL-0R3 (-XCMPLX-0K4  |.COMPLEX1K10 r1.|)-XCMPLX-0K6  |.COMPLEX1K10 g1.|"
            using A8 sorry
          have "-XCMPLX-0K4  |.COMPLEX1K10 r1.| <=XXREAL-0R1 r1 & 0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 g1.|"
            using absvalue_th_4 complex1_th_46 sorry
          then have "(-XCMPLX-0K4  |.COMPLEX1K10 r1.|)-XCMPLX-0K6  |.COMPLEX1K10 g1.| <=XXREAL-0R1 r1 -XCMPLX-0K6 0NUMBERSK6"
            using xreal_1_th_13 sorry
          then have "seq .FUNCT-1K1 m <XXREAL-0R3 r1"
            using A10 xxreal_0_th_2 sorry
          then have "seq .FUNCT-1K1 m inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : g2 <XXREAL-0R3 r1 }"
             sorry
          then have "seq .FUNCT-1K1 m inTARSKIR2 rngFUNCT-1K2 seq & seq .FUNCT-1K1 m inTARSKIR2 left-open-halflineLIMFUNC1K1 r1"
            using valued_0_th_28 xxreal_1_th_229 sorry
          then have A11: "seq .FUNCT-1K1 m inTARSKIR2 (left-open-halflineLIMFUNC1K1 r1)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using A5 xboole_0_def_4 sorry
          have "-XCMPLX-0K4  |.COMPLEX1K10 g1.| <=XXREAL-0R1 g1 & 0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r1.|"
            using absvalue_th_4 complex1_th_46 sorry
          then have "(-XCMPLX-0K4  |.COMPLEX1K10 g1.|)-XCMPLX-0K6  |.COMPLEX1K10 r1.| <=XXREAL-0R1 g1 -XCMPLX-0K6 0NUMBERSK6"
            using xreal_1_th_13 sorry
          then have "seq .FUNCT-1K1 m <XXREAL-0R3 g1"
            using A10 xxreal_0_th_2 sorry
          then have "f .FUNCT-1K1 (seq .FUNCT-1K1 m) <=XXREAL-0R1 f .FUNCT-1K1 g1"
            using A1 A6 A11 rfunct_2_th_22 sorry
          then have "f .FUNCT-1K1 (seq .FUNCT-1K1 m) <XXREAL-0R3 r"
            using A7 xxreal_0_th_2 sorry
          thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq .FUNCT-1K1 m <XXREAL-0R3 r"
            using A5 funct_2_th_108 A9 sorry
        qed "sorry"
      qed "sorry"
      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
         sorry
    qed "sorry"
    assume " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    thus "f be divergent-in-infty-to-inftyLIMFUNC1V8"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_69:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be increasingVALUED-0V9 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be bounded-belowSEQ-2V2) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies f be divergent-in-infty-to-inftyLIMFUNC1V8"
  using limfunc1_th_68 sorry

mtheorem limfunc1_th_70:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in+infty-to+inftyLIMFUNC1V4 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)) & ( ex r be RealXREAL-0M1 st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g)) implies f be divergent-in+infty-to+inftyLIMFUNC1V4"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in+infty-to+inftyLIMFUNC1V4 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies (( ex r1 be RealXREAL-0M1 st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g)) implies f be divergent-in+infty-to+inftyLIMFUNC1V4)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be divergent-in+infty-to+inftyLIMFUNC1V4"
      and A2: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    assume Given: " ex r1 be RealXREAL-0M1 st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g)"
    then obtain r1 where
      [ty]:"r1 be RealXREAL-0M1" and 
      A3: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1)"and A4: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g"
       sorry
    have " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A5: "seq be divergent-to+inftyLIMFUNC1V1"
        and A6: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A7: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies r1 <XXREAL-0R3 seq .FUNCT-1K1 n"
        using A5 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 right-open-halflineLIMFUNC1K4 r1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A8: "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
          using funct_2_th_113 sorry
        have "r1 <XXREAL-0R3 seq .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A7 nat_1_th_12 sorry
        then have "r1 <XXREAL-0R3 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
          using nat_1_def_3 sorry
        then have "x inHIDDENR3 {g2 where g2 be RealXREAL-0M1 : r1 <XXREAL-0R3 g2 }"
          using A8 sorry
        thus "x inHIDDENR3 right-open-halflineLIMFUNC1K4 r1"
          using xxreal_1_th_230 sorry
      qed "sorry"
      then have A9: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 right-open-halflineLIMFUNC1K4 r1"
         sorry
      have A10: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngFUNCT-1K2 seq"
        using valued_0_th_21 sorry
      then have "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A6 sorry
      then have A11: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1)"
        using A9 xboole_1_th_19 sorry
      then have A12: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1)"
        using A3 sorry
      have A13: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using xboole_1_th_17 sorry
      have A14: " for n be NatNAT-1M1 holds f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A15: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
          using valued_0_th_28 sorry
        then have "f1 .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n) <=XXREAL-0R1 f .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
          using A4 A11 sorry
        then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
          using A12 A13 funct_2_th_108 xboole_1_th_1 A15 sorry
        thus "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
          using A6 A10 funct_2_th_108 xboole_1_th_1 A15 sorry
      qed "sorry"
      have A16: "seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be divergent-to+inftyLIMFUNC1V1"
        using A5 limfunc1_th_26 sorry
      have "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A12 A13 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be divergent-to+inftyLIMFUNC1V1"
        using A1 A16 sorry
      then have A17: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be divergent-to+inftyLIMFUNC1V1"
        using A14 limfunc1_th_42 sorry
      have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A6 valued_0_th_27 sorry
      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
        using A17 limfunc1_th_7 sorry
    qed "sorry"
    thus "f be divergent-in+infty-to+inftyLIMFUNC1V4"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_71:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in+infty-to-inftyLIMFUNC1V5 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)) & ( ex r be RealXREAL-0M1 st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g)) implies f be divergent-in+infty-to-inftyLIMFUNC1V5"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in+infty-to-inftyLIMFUNC1V5 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies (( ex r1 be RealXREAL-0M1 st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g)) implies f be divergent-in+infty-to-inftyLIMFUNC1V5)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be divergent-in+infty-to-inftyLIMFUNC1V5"
      and A2: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    assume Given: " ex r1 be RealXREAL-0M1 st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g)"
    then obtain r1 where
      [ty]:"r1 be RealXREAL-0M1" and 
      A3: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1)"and A4: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g"
       sorry
    have " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A5: "seq be divergent-to+inftyLIMFUNC1V1"
        and A6: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A7: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies r1 <XXREAL-0R3 seq .FUNCT-1K1 n"
        using A5 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 right-open-halflineLIMFUNC1K4 r1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A8: "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
          using funct_2_th_113 sorry
        have "r1 <XXREAL-0R3 seq .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A7 nat_1_th_12 sorry
        then have "r1 <XXREAL-0R3 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
          using nat_1_def_3 sorry
        then have "x inHIDDENR3 {g2 where g2 be RealXREAL-0M1 : r1 <XXREAL-0R3 g2 }"
          using A8 sorry
        thus "x inHIDDENR3 right-open-halflineLIMFUNC1K4 r1"
          using xxreal_1_th_230 sorry
      qed "sorry"
      then have A9: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 right-open-halflineLIMFUNC1K4 r1"
         sorry
      have A10: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngFUNCT-1K2 seq"
        using valued_0_th_21 sorry
      then have "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A6 sorry
      then have A11: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1)"
        using A9 xboole_1_th_19 sorry
      then have A12: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1)"
        using A3 sorry
      have A13: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using xboole_1_th_17 sorry
      have A14: " for n be NatNAT-1M1 holds f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A15: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
          using valued_0_th_28 sorry
        then have "f .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n) <=XXREAL-0R1 f1 .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
          using A4 A11 sorry
        then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f1 .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
          using A6 A10 funct_2_th_108 xboole_1_th_1 A15 sorry
        thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
          using A12 A13 funct_2_th_108 xboole_1_th_1 A15 sorry
      qed "sorry"
      have A16: "seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be divergent-to+inftyLIMFUNC1V1"
        using A5 limfunc1_th_26 sorry
      have "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A12 A13 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be divergent-to-inftyLIMFUNC1V2"
        using A1 A16 sorry
      then have A17: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be divergent-to-inftyLIMFUNC1V2"
        using A14 limfunc1_th_43 sorry
      have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A6 valued_0_th_27 sorry
      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
        using A17 limfunc1_th_7 sorry
    qed "sorry"
    thus "f be divergent-in+infty-to-inftyLIMFUNC1V5"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_72:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in-infty-to+inftyLIMFUNC1V7 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)) & ( ex r be RealXREAL-0M1 st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g)) implies f be divergent-in-infty-to+inftyLIMFUNC1V7"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in-infty-to+inftyLIMFUNC1V7 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies (( ex r1 be RealXREAL-0M1 st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g)) implies f be divergent-in-infty-to+inftyLIMFUNC1V7)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be divergent-in-infty-to+inftyLIMFUNC1V7"
      and A2: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    assume Given: " ex r1 be RealXREAL-0M1 st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g)"
    then obtain r1 where
      [ty]:"r1 be RealXREAL-0M1" and 
      A3: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1)"and A4: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g"
       sorry
    have " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A5: "seq be divergent-to-inftyLIMFUNC1V2"
        and A6: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A7: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies seq .FUNCT-1K1 n <XXREAL-0R3 r1"
        using A5 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 left-open-halflineLIMFUNC1K1 r1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A8: "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
          using funct_2_th_113 sorry
        have "seq .FUNCT-1K1 (n +XCMPLX-0K2 k) <XXREAL-0R3 r1"
          using A7 nat_1_th_12 sorry
        then have "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 r1"
          using nat_1_def_3 sorry
        then have "x inHIDDENR3 {g2 where g2 be RealXREAL-0M1 : g2 <XXREAL-0R3 r1 }"
          using A8 sorry
        thus "x inHIDDENR3 left-open-halflineLIMFUNC1K1 r1"
          using xxreal_1_th_229 sorry
      qed "sorry"
      then have A9: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 left-open-halflineLIMFUNC1K1 r1"
         sorry
      have A10: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngFUNCT-1K2 seq"
        using valued_0_th_21 sorry
      then have "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A6 sorry
      then have A11: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1)"
        using A9 xboole_1_th_19 sorry
      then have A12: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1)"
        using A3 sorry
      have A13: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using xboole_1_th_17 sorry
      have A14: " for n be NatNAT-1M1 holds f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A15: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
          using valued_0_th_28 sorry
        then have "f1 .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n) <=XXREAL-0R1 f .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
          using A4 A11 sorry
        then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
          using A12 A13 funct_2_th_108 xboole_1_th_1 A15 sorry
        thus "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
          using A6 A10 funct_2_th_108 xboole_1_th_1 A15 sorry
      qed "sorry"
      have A16: "seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be divergent-to-inftyLIMFUNC1V2"
        using A5 limfunc1_th_27 sorry
      have "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A12 A13 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be divergent-to+inftyLIMFUNC1V1"
        using A1 A16 sorry
      then have A17: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be divergent-to+inftyLIMFUNC1V1"
        using A14 limfunc1_th_42 sorry
      have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A6 valued_0_th_27 sorry
      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
        using A17 limfunc1_th_7 sorry
    qed "sorry"
    thus "f be divergent-in-infty-to+inftyLIMFUNC1V7"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_73:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in-infty-to-inftyLIMFUNC1V8 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)) & ( ex r be RealXREAL-0M1 st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g)) implies f be divergent-in-infty-to-inftyLIMFUNC1V8"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in-infty-to-inftyLIMFUNC1V8 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies (( ex r1 be RealXREAL-0M1 st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g)) implies f be divergent-in-infty-to-inftyLIMFUNC1V8)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be divergent-in-infty-to-inftyLIMFUNC1V8"
      and A2: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    assume Given: " ex r1 be RealXREAL-0M1 st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g)"
    then obtain r1 where
      [ty]:"r1 be RealXREAL-0M1" and 
      A3: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1)"and A4: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g"
       sorry
    have " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A5: "seq be divergent-to-inftyLIMFUNC1V2"
        and A6: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A7: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies seq .FUNCT-1K1 n <XXREAL-0R3 r1"
        using A5 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 left-open-halflineLIMFUNC1K1 r1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A8: "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
          using funct_2_th_113 sorry
        have "seq .FUNCT-1K1 (n +XCMPLX-0K2 k) <XXREAL-0R3 r1"
          using A7 nat_1_th_12 sorry
        then have "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 r1"
          using nat_1_def_3 sorry
        then have "x inHIDDENR3 {g2 where g2 be RealXREAL-0M1 : g2 <XXREAL-0R3 r1 }"
          using A8 sorry
        thus "x inHIDDENR3 left-open-halflineLIMFUNC1K1 r1"
          using xxreal_1_th_229 sorry
      qed "sorry"
      then have A9: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 left-open-halflineLIMFUNC1K1 r1"
         sorry
      have A10: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngFUNCT-1K2 seq"
        using valued_0_th_21 sorry
      then have "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A6 sorry
      then have A11: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1)"
        using A9 xboole_1_th_19 sorry
      then have A12: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1)"
        using A3 sorry
      have A13: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using xboole_1_th_17 sorry
      have A14: " for n be NatNAT-1M1 holds f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A15: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
          using valued_0_th_28 sorry
        then have "f .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n) <=XXREAL-0R1 f1 .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
          using A4 A11 sorry
        then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f1 .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
          using A6 A10 funct_2_th_108 xboole_1_th_1 A15 sorry
        thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
          using A12 A13 funct_2_th_108 xboole_1_th_1 A15 sorry
      qed "sorry"
      have A16: "seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be divergent-to-inftyLIMFUNC1V2"
        using A5 limfunc1_th_27 sorry
      have "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A12 A13 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be divergent-to-inftyLIMFUNC1V2"
        using A1 A16 sorry
      then have A17: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be divergent-to-inftyLIMFUNC1V2"
        using A14 limfunc1_th_43 sorry
      have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A6 valued_0_th_27 sorry
      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
        using A17 limfunc1_th_7 sorry
    qed "sorry"
    thus "f be divergent-in-infty-to-inftyLIMFUNC1V8"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_74:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in+infty-to+inftyLIMFUNC1V4 & ( ex r be RealXREAL-0M1 st right-open-halflineLIMFUNC1K4 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & ( for g be RealXREAL-0M1 holds g inHIDDENR3 right-open-halflineLIMFUNC1K4 r implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g)) implies f be divergent-in+infty-to+inftyLIMFUNC1V4"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in+infty-to+inftyLIMFUNC1V4 implies (( ex r1 be RealXREAL-0M1 st right-open-halflineLIMFUNC1K4 r1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & ( for g be RealXREAL-0M1 holds g inHIDDENR3 right-open-halflineLIMFUNC1K4 r1 implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g)) implies f be divergent-in+infty-to+inftyLIMFUNC1V4)"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be divergent-in+infty-to+inftyLIMFUNC1V4"
    assume Given: " ex r1 be RealXREAL-0M1 st right-open-halflineLIMFUNC1K4 r1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & ( for g be RealXREAL-0M1 holds g inHIDDENR3 right-open-halflineLIMFUNC1K4 r1 implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g)"
    then obtain r1 where
      [ty]:"r1 be RealXREAL-0M1" and 
      A2: "right-open-halflineLIMFUNC1K4 r1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"and A3: " for g be RealXREAL-0M1 holds g inHIDDENR3 right-open-halflineLIMFUNC1K4 r1 implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g"
       sorry
    have A4: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain g where
        [ty]:"g be RealXREAL-0M1" and 
        A5: " |.COMPLEX1K10 r.| +XCMPLX-0K2  |.COMPLEX1K10 r1.| <XXREAL-0R3 g"
        using xreal_1_th_1 sorry
      show " ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      proof(rule bexI[of _ "g"],rule conjMI)
        have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r1.| & r <=XXREAL-0R1  |.COMPLEX1K10 r.|"
          using absvalue_th_4 complex1_th_46 sorry
        then have "0NUMBERSK6 +XCMPLX-0K2 r <=XXREAL-0R1  |.COMPLEX1K10 r.| +XCMPLX-0K2  |.COMPLEX1K10 r1.|"
          using xreal_1_th_7 sorry
        thus "r <XXREAL-0R3 g"
          using A5 xxreal_0_th_2 sorry
        have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r.| & r1 <=XXREAL-0R1  |.COMPLEX1K10 r1.|"
          using absvalue_th_4 complex1_th_46 sorry
        then have "0NUMBERSK6 +XCMPLX-0K2 r1 <=XXREAL-0R1  |.COMPLEX1K10 r.| +XCMPLX-0K2  |.COMPLEX1K10 r1.|"
          using xreal_1_th_7 sorry
        then have "r1 <XXREAL-0R3 g"
          using A5 xxreal_0_th_2 sorry
        then have "g inHIDDENR3 {g2 where g2 be RealXREAL-0M1 : r1 <XXREAL-0R3 g2 }"
           sorry
        then have "g inHIDDENR3 right-open-halflineLIMFUNC1K4 r1"
          using xxreal_1_th_230 sorry
        thus "g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A2 xboole_0_def_4 sorry
      qed "sorry"
    qed "sorry"
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g)"
    proof(rule conjMI,rule ballI,rule impI)
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using xboole_1_th_17 sorry
      then have A6: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 r1"
        using A2 xboole_1_th_1 xboole_1_th_28 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using xboole_1_th_17 sorry
      thus "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1)"
        using A2 A6 xboole_1_th_1 xboole_1_th_28 sorry
      fix g assume [ty]: "g be RealXREAL-0M1"
      assume "g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1)"
      thus "f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g"
        using A3 A6 sorry
    qed "sorry"
    thus "f be divergent-in+infty-to+inftyLIMFUNC1V4"
      using A1 A4 limfunc1_th_70 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_75:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in+infty-to-inftyLIMFUNC1V5 & ( ex r be RealXREAL-0M1 st right-open-halflineLIMFUNC1K4 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & ( for g be RealXREAL-0M1 holds g inHIDDENR3 right-open-halflineLIMFUNC1K4 r implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g)) implies f be divergent-in+infty-to-inftyLIMFUNC1V5"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in+infty-to-inftyLIMFUNC1V5 implies (( ex r1 be RealXREAL-0M1 st right-open-halflineLIMFUNC1K4 r1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & ( for g be RealXREAL-0M1 holds g inHIDDENR3 right-open-halflineLIMFUNC1K4 r1 implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g)) implies f be divergent-in+infty-to-inftyLIMFUNC1V5)"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be divergent-in+infty-to-inftyLIMFUNC1V5"
    assume Given: " ex r1 be RealXREAL-0M1 st right-open-halflineLIMFUNC1K4 r1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & ( for g be RealXREAL-0M1 holds g inHIDDENR3 right-open-halflineLIMFUNC1K4 r1 implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g)"
    then obtain r1 where
      [ty]:"r1 be RealXREAL-0M1" and 
      A2: "right-open-halflineLIMFUNC1K4 r1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"and A3: " for g be RealXREAL-0M1 holds g inHIDDENR3 right-open-halflineLIMFUNC1K4 r1 implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g"
       sorry
    have A4: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain g where
        [ty]:"g be RealXREAL-0M1" and 
        A5: " |.COMPLEX1K10 r.| +XCMPLX-0K2  |.COMPLEX1K10 r1.| <XXREAL-0R3 g"
        using xreal_1_th_1 sorry
      show " ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      proof(rule bexI[of _ "g"],rule conjMI)
        have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r1.| & r <=XXREAL-0R1  |.COMPLEX1K10 r.|"
          using absvalue_th_4 complex1_th_46 sorry
        then have "0NUMBERSK6 +XCMPLX-0K2 r <=XXREAL-0R1  |.COMPLEX1K10 r.| +XCMPLX-0K2  |.COMPLEX1K10 r1.|"
          using xreal_1_th_7 sorry
        thus "r <XXREAL-0R3 g"
          using A5 xxreal_0_th_2 sorry
        have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r.| & r1 <=XXREAL-0R1  |.COMPLEX1K10 r1.|"
          using absvalue_th_4 complex1_th_46 sorry
        then have "0NUMBERSK6 +XCMPLX-0K2 r1 <=XXREAL-0R1  |.COMPLEX1K10 r.| +XCMPLX-0K2  |.COMPLEX1K10 r1.|"
          using xreal_1_th_7 sorry
        then have "r1 <XXREAL-0R3 g"
          using A5 xxreal_0_th_2 sorry
        then have "g inHIDDENR3 {g2 where g2 be RealXREAL-0M1 : r1 <XXREAL-0R3 g2 }"
           sorry
        then have "g inHIDDENR3 right-open-halflineLIMFUNC1K4 r1"
          using xxreal_1_th_230 sorry
        thus "g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A2 xboole_0_def_4 sorry
      qed "sorry"
    qed "sorry"
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g)"
    proof(rule conjMI,rule ballI,rule impI)
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using xboole_1_th_17 sorry
      then have A6: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 r1"
        using A2 xboole_1_th_1 xboole_1_th_28 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using xboole_1_th_17 sorry
      thus "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1)"
        using A2 A6 xboole_1_th_1 xboole_1_th_28 sorry
      fix g assume [ty]: "g be RealXREAL-0M1"
      assume "g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1)"
      thus "f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g"
        using A3 A6 sorry
    qed "sorry"
    thus "f be divergent-in+infty-to-inftyLIMFUNC1V5"
      using A1 A4 limfunc1_th_71 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_76:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in-infty-to+inftyLIMFUNC1V7 & ( ex r be RealXREAL-0M1 st left-open-halflineLIMFUNC1K1 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & ( for g be RealXREAL-0M1 holds g inHIDDENR3 left-open-halflineLIMFUNC1K1 r implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g)) implies f be divergent-in-infty-to+inftyLIMFUNC1V7"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in-infty-to+inftyLIMFUNC1V7 implies (( ex r1 be RealXREAL-0M1 st left-open-halflineLIMFUNC1K1 r1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & ( for g be RealXREAL-0M1 holds g inHIDDENR3 left-open-halflineLIMFUNC1K1 r1 implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g)) implies f be divergent-in-infty-to+inftyLIMFUNC1V7)"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be divergent-in-infty-to+inftyLIMFUNC1V7"
    assume Given: " ex r1 be RealXREAL-0M1 st left-open-halflineLIMFUNC1K1 r1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & ( for g be RealXREAL-0M1 holds g inHIDDENR3 left-open-halflineLIMFUNC1K1 r1 implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g)"
    then obtain r1 where
      [ty]:"r1 be RealXREAL-0M1" and 
      A2: "left-open-halflineLIMFUNC1K1 r1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"and A3: " for g be RealXREAL-0M1 holds g inHIDDENR3 left-open-halflineLIMFUNC1K1 r1 implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g"
       sorry
    have A4: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain g where
        [ty]:"g be RealXREAL-0M1" and 
        A5: "g <XXREAL-0R3 (-XCMPLX-0K4  |.COMPLEX1K10 r.|)-XCMPLX-0K6  |.COMPLEX1K10 r1.|"
        using xreal_1_th_2 sorry
      show " ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      proof(rule bexI[of _ "g"],rule conjMI)
        have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r1.| & -XCMPLX-0K4  |.COMPLEX1K10 r.| <=XXREAL-0R1 r"
          using absvalue_th_4 complex1_th_46 sorry
        then have "(-XCMPLX-0K4  |.COMPLEX1K10 r.|)-XCMPLX-0K6  |.COMPLEX1K10 r1.| <=XXREAL-0R1 r -XCMPLX-0K6 0NUMBERSK6"
          using xreal_1_th_13 sorry
        thus "g <XXREAL-0R3 r"
          using A5 xxreal_0_th_2 sorry
        have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r.| & -XCMPLX-0K4  |.COMPLEX1K10 r1.| <=XXREAL-0R1 r1"
          using absvalue_th_4 complex1_th_46 sorry
        then have "(-XCMPLX-0K4  |.COMPLEX1K10 r1.|)-XCMPLX-0K6  |.COMPLEX1K10 r.| <=XXREAL-0R1 r1 -XCMPLX-0K6 0NUMBERSK6"
          using xreal_1_th_13 sorry
        then have "g <XXREAL-0R3 r1"
          using A5 xxreal_0_th_2 sorry
        then have "g inHIDDENR3 {g2 where g2 be RealXREAL-0M1 : g2 <XXREAL-0R3 r1 }"
           sorry
        then have "g inHIDDENR3 left-open-halflineLIMFUNC1K1 r1"
          using xxreal_1_th_229 sorry
        thus "g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A2 xboole_0_def_4 sorry
      qed "sorry"
    qed "sorry"
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g)"
    proof(rule conjMI,rule ballI,rule impI)
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using xboole_1_th_17 sorry
      then have A6: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) =XBOOLE-0R4 left-open-halflineLIMFUNC1K1 r1"
        using A2 xboole_1_th_1 xboole_1_th_28 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using xboole_1_th_17 sorry
      thus "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1)"
        using A2 A6 xboole_1_th_1 xboole_1_th_28 sorry
      fix g assume [ty]: "g be RealXREAL-0M1"
      assume "g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1)"
      thus "f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g"
        using A3 A6 sorry
    qed "sorry"
    thus "f be divergent-in-infty-to+inftyLIMFUNC1V7"
      using A1 A4 limfunc1_th_72 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_77:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in-infty-to-inftyLIMFUNC1V8 & ( ex r be RealXREAL-0M1 st left-open-halflineLIMFUNC1K1 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & ( for g be RealXREAL-0M1 holds g inHIDDENR3 left-open-halflineLIMFUNC1K1 r implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g)) implies f be divergent-in-infty-to-inftyLIMFUNC1V8"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in-infty-to-inftyLIMFUNC1V8 implies (( ex r1 be RealXREAL-0M1 st left-open-halflineLIMFUNC1K1 r1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & ( for g be RealXREAL-0M1 holds g inHIDDENR3 left-open-halflineLIMFUNC1K1 r1 implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g)) implies f be divergent-in-infty-to-inftyLIMFUNC1V8)"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be divergent-in-infty-to-inftyLIMFUNC1V8"
    assume Given: " ex r1 be RealXREAL-0M1 st left-open-halflineLIMFUNC1K1 r1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & ( for g be RealXREAL-0M1 holds g inHIDDENR3 left-open-halflineLIMFUNC1K1 r1 implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g)"
    then obtain r1 where
      [ty]:"r1 be RealXREAL-0M1" and 
      A2: "left-open-halflineLIMFUNC1K1 r1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"and A3: " for g be RealXREAL-0M1 holds g inHIDDENR3 left-open-halflineLIMFUNC1K1 r1 implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g"
       sorry
    have A4: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain g where
        [ty]:"g be RealXREAL-0M1" and 
        A5: "g <XXREAL-0R3 (-XCMPLX-0K4  |.COMPLEX1K10 r.|)-XCMPLX-0K6  |.COMPLEX1K10 r1.|"
        using xreal_1_th_2 sorry
      show " ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      proof(rule bexI[of _ "g"],rule conjMI)
        have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r1.| & -XCMPLX-0K4  |.COMPLEX1K10 r.| <=XXREAL-0R1 r"
          using absvalue_th_4 complex1_th_46 sorry
        then have "(-XCMPLX-0K4  |.COMPLEX1K10 r.|)-XCMPLX-0K6  |.COMPLEX1K10 r1.| <=XXREAL-0R1 r -XCMPLX-0K6 0NUMBERSK6"
          using xreal_1_th_13 sorry
        thus "g <XXREAL-0R3 r"
          using A5 xxreal_0_th_2 sorry
        have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r.| & -XCMPLX-0K4  |.COMPLEX1K10 r1.| <=XXREAL-0R1 r1"
          using absvalue_th_4 complex1_th_46 sorry
        then have "(-XCMPLX-0K4  |.COMPLEX1K10 r1.|)-XCMPLX-0K6  |.COMPLEX1K10 r.| <=XXREAL-0R1 r1 -XCMPLX-0K6 0NUMBERSK6"
          using xreal_1_th_13 sorry
        then have "g <XXREAL-0R3 r1"
          using A5 xxreal_0_th_2 sorry
        then have "g inHIDDENR3 {g2 where g2 be RealXREAL-0M1 : g2 <XXREAL-0R3 r1 }"
           sorry
        then have "g inHIDDENR3 left-open-halflineLIMFUNC1K1 r1"
          using xxreal_1_th_229 sorry
        thus "g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A2 xboole_0_def_4 sorry
      qed "sorry"
    qed "sorry"
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g)"
    proof(rule conjMI,rule ballI,rule impI)
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using xboole_1_th_17 sorry
      then have A6: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) =XBOOLE-0R4 left-open-halflineLIMFUNC1K1 r1"
        using A2 xboole_1_th_1 xboole_1_th_28 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using xboole_1_th_17 sorry
      thus "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1)"
        using A2 A6 xboole_1_th_1 xboole_1_th_28 sorry
      fix g assume [ty]: "g be RealXREAL-0M1"
      assume "g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1)"
      thus "f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g"
        using A3 A6 sorry
    qed "sorry"
    thus "f be divergent-in-infty-to-inftyLIMFUNC1V8"
      using A1 A4 limfunc1_th_73 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef limfunc1_def_12 ("lim-in+inftyLIMFUNC1K5  _ " [164]164 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
"assume f be convergent-in+inftyLIMFUNC1V3 func lim-in+inftyLIMFUNC1K5 f \<rightarrow> RealXREAL-0M1 means
  \<lambda>it.  for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it"
proof-
  (*existence*)
    show "f be convergent-in+inftyLIMFUNC1V3 implies ( ex it be RealXREAL-0M1 st  for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it)"
    proof(rule impI)
      assume Assume: "f be convergent-in+inftyLIMFUNC1V3"
      have A1: "f be convergent-in+inftyLIMFUNC1V3"
        using Assume sorry
      show " ex it be RealXREAL-0M1 st  for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it"
        using A1 sorry
    qed
  (*uniqueness*)
    show "f be convergent-in+inftyLIMFUNC1V3 implies ( for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds ( for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it1) & ( for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it2) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "f be convergent-in+inftyLIMFUNC1V3"
      have A1: "f be convergent-in+inftyLIMFUNC1V3"
        using Assume sorry
      show " for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds ( for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it1) & ( for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it2) implies it1 =HIDDENR1 it2"
      proof-
        have " for g1 be RealXREAL-0M1 holds  for g2 be RealXREAL-0M1 holds ( for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 g1) & ( for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 g2) implies g1 =HIDDENR1 g2"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          let ?X = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb1 <XXREAL-0R3 Lamb2 & Lamb2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          fix g1 assume [ty]: "g1 be RealXREAL-0M1"
          fix g2 assume [ty]: "g2 be RealXREAL-0M1"
          assume A2: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 g1"
            and A3: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 g2"
          have A4: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex r be ElementSUBSET-1M1-of REALNUMBERSK2 st ?X(n,r)"
          proof-
            have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not ( for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not (n <XXREAL-0R3 r & r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f))"
            proof(rule ballI)
              fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
              obtain r where
                [ty]:"r be RealXREAL-0M1" and 
                A5: "?X(n,r)"
                using A1 sorry
              have 
                [ty]:"r be RealXREAL-0M1"
                 sorry
              have "?X(n,r)"
                using A5 sorry
              thus " not ( for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not (n <XXREAL-0R3 r & r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f))"
                 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          obtain s2 where
            [ty]:"s2 be Real-SequenceSEQ-1M1" and 
            A6: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?X(n,s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
            using funct_2_sch_3 A4 sorry
          have A7: "rngFUNCT-1K2 s2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          proof-
            have " for x be RealXREAL-0M1 holds x inHIDDENR3 rngFUNCT-1K2 s2 implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be RealXREAL-0M1"
              assume "x inHIDDENR3 rngFUNCT-1K2 s2"
              then have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st x =COMPLEX1R1 s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using funct_2_th_113 sorry
              thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
                using A6 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 s2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using membered_def_9 sorry
          qed
          obtain s1 where 
            [ty]:"s1 be Real-SequenceSEQ-1M1" and s1Def:"s1 = idPARTFUN1K6 NATNUMBERSK1"
            using funct_2_th_7 numbers_th_19 sorry
          have " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n <=XXREAL-0R1 s2 .FUNCT-1K1 n"
          proof(rule ballI)
            fix n assume [ty]: "n be NatNAT-1M1"
            have A8: "n inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            then have "n <XXREAL-0R3 s2 .FUNCT-1K1 n"
              using A6 sorry
            thus "s1 .FUNCT-1K1 n <=XXREAL-0R1 s2 .FUNCT-1K1 n"
              using funct_1_th_18 A8 sorry
          qed "sorry"
          then have A9: "s2 be divergent-to+inftyLIMFUNC1V1"
            using limfunc1_lm_5 limfunc1_th_20 limfunc1_th_42 sorry
          then have "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 =COMPLEX1R1 g1"
            using A2 A7 sorry
          thus "g1 =HIDDENR1 g2"
            using A3 A9 A7 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mdef limfunc1_def_13 ("lim-in-inftyLIMFUNC1K6  _ " [164]164 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
"assume f be convergent-in-inftyLIMFUNC1V6 func lim-in-inftyLIMFUNC1K6 f \<rightarrow> RealXREAL-0M1 means
  \<lambda>it.  for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it"
proof-
  (*existence*)
    show "f be convergent-in-inftyLIMFUNC1V6 implies ( ex it be RealXREAL-0M1 st  for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it)"
    proof(rule impI)
      assume Assume: "f be convergent-in-inftyLIMFUNC1V6"
      have A1: "f be convergent-in-inftyLIMFUNC1V6"
        using Assume sorry
      show " ex it be RealXREAL-0M1 st  for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it"
        using A1 sorry
    qed
  (*uniqueness*)
    show "f be convergent-in-inftyLIMFUNC1V6 implies ( for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds ( for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it1) & ( for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it2) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "f be convergent-in-inftyLIMFUNC1V6"
      have A1: "f be convergent-in-inftyLIMFUNC1V6"
        using Assume sorry
      show " for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds ( for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it1) & ( for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it2) implies it1 =HIDDENR1 it2"
      proof-
        have " for g1 be RealXREAL-0M1 holds  for g2 be RealXREAL-0M1 holds ( for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 g1) & ( for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 g2) implies g1 =HIDDENR1 g2"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          let ?U = "\<lambda>Lamb1. -XCMPLX-0K4 Lamb1"
          let ?X = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 <XXREAL-0R3 -XCMPLX-0K4 Lamb1 & Lamb2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          fix g1 assume [ty]: "g1 be RealXREAL-0M1"
          fix g2 assume [ty]: "g2 be RealXREAL-0M1"
          assume A2: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 g1"
            and A3: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 g2"
          obtain s2 where
            [ty]:"s2 be Real-SequenceSEQ-1M1" and 
            A4: " for n be NatNAT-1M1 holds s2 .FUNCT-1K1 n =COMPLEX1R1 ?U(n)"
            using seq_1_sch_1 sorry
          have A5: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex r be ElementSUBSET-1M1-of REALNUMBERSK2 st ?X(n,r)"
          proof-
            have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not ( for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not (r <XXREAL-0R3 -XCMPLX-0K4 n & r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f))"
            proof(rule ballI)
              fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
              obtain r where
                [ty]:"r be RealXREAL-0M1" and 
                A6: "?X(n,r)"
                using A1 sorry
              have 
                [ty]:"r be RealXREAL-0M1"
                 sorry
              have "?X(n,r)"
                using A6 sorry
              thus " not ( for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not (r <XXREAL-0R3 -XCMPLX-0K4 n & r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f))"
                 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          obtain s1 where
            [ty]:"s1 be Real-SequenceSEQ-1M1" and 
            A7: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?X(n,s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
            using funct_2_sch_3 A5 sorry
          have A8: "rngFUNCT-1K2 s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          proof-
            have " for x be RealXREAL-0M1 holds x inHIDDENR3 rngFUNCT-1K2 s1 implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be RealXREAL-0M1"
              assume "x inHIDDENR3 rngFUNCT-1K2 s1"
              then have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st x =COMPLEX1R1 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using funct_2_th_113 sorry
              thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
                using A7 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using membered_def_9 sorry
          qed
          have " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n <=XXREAL-0R1 s2 .FUNCT-1K1 n"
          proof(rule ballI)
            fix n assume [ty]: "n be NatNAT-1M1"
            have "n inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            then have "s1 .FUNCT-1K1 n <XXREAL-0R3 -XCMPLX-0K4 n"
              using A7 sorry
            thus "s1 .FUNCT-1K1 n <=XXREAL-0R1 s2 .FUNCT-1K1 n"
              using A4 sorry
          qed "sorry"
          then have A9: "s1 be divergent-to-inftyLIMFUNC1V2"
            using A4 limfunc1_th_21 limfunc1_th_43 sorry
          then have "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 =COMPLEX1R1 g1"
            using A2 A8 sorry
          thus "g1 =HIDDENR1 g2"
            using A3 A9 A8 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem limfunc1_th_78:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for g be RealXREAL-0M1 holds f be convergent-in-inftyLIMFUNC1V6 implies (lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 g iff ( for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1)))"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for g be RealXREAL-0M1 holds f be convergent-in-inftyLIMFUNC1V6 implies (lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 g implies ( for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1))) & (( for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1)) implies lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 g)"
  proof(rule ballI,rule ballI,rule impI,rule conjMI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix g assume [ty]: "g be RealXREAL-0M1"
    assume A1: "f be convergent-in-inftyLIMFUNC1V6"
    show "lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 g implies ( for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1))"
    proof-
      have "lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 g implies (( ex g1 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g1 & ( for r be RealXREAL-0M1 holds  ex r1 be RealXREAL-0M1 st (r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) &  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| >=XXREAL-0R2 g1)) implies  False )"
      proof(rule impI,rule impI)
        let ?U = "\<lambda>Lamb1. -XCMPLX-0K4 Lamb1"
        assume A2: "lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 g"
        obtain s1 where
          [ty]:"s1 be Real-SequenceSEQ-1M1" and 
          A3: " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n =COMPLEX1R1 ?U(n)"
          using seq_1_sch_1 sorry
        assume Given: " ex g1 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g1 & ( for r be RealXREAL-0M1 holds  ex r1 be RealXREAL-0M1 st (r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) &  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| >=XXREAL-0R2 g1)"
        then obtain g1 where
          [ty]:"g1 be RealXREAL-0M1" and 
          A4: "0NUMBERSK6 <XXREAL-0R3 g1"and A5: " for r be RealXREAL-0M1 holds  ex r1 be RealXREAL-0M1 st (r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) &  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| >=XXREAL-0R2 g1"
           sorry
        let ?X = "\<lambda>Lamb1. \<lambda>Lamb2. (Lamb2 <XXREAL-0R3 -XCMPLX-0K4 Lamb1 & Lamb2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) &  |.COMPLEX1K10 f .FUNCT-1K1 Lamb2 -XCMPLX-0K6 g .| >=XXREAL-0R2 g1"
        have A6: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex r be ElementSUBSET-1M1-of REALNUMBERSK2 st ?X(n,r)"
        proof-
          have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not ( for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not ((r <XXREAL-0R3 -XCMPLX-0K4 n & r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) &  |.COMPLEX1K10 f .FUNCT-1K1 r -XCMPLX-0K6 g .| >=XXREAL-0R2 g1))"
          proof(rule ballI)
            fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
            obtain r where
              [ty]:"r be RealXREAL-0M1" and 
              A7: "?X(n,r)"
              using A5 sorry
            have 
              [ty]:"r be RealXREAL-0M1"
               sorry
            have "?X(n,r)"
              using A7 sorry
            thus " not ( for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not ((r <XXREAL-0R3 -XCMPLX-0K4 n & r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) &  |.COMPLEX1K10 f .FUNCT-1K1 r -XCMPLX-0K6 g .| >=XXREAL-0R2 g1))"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain s where
          [ty]:"s be Real-SequenceSEQ-1M1" and 
          A8: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?X(n,s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
          using funct_2_sch_3 A6 sorry
        have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 s implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 rngFUNCT-1K2 s"
          then have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
            using funct_2_th_113 sorry
          thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using A8 sorry
        qed "sorry"
        then have A9: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
           sorry
        have " for n be NatNAT-1M1 holds s .FUNCT-1K1 n <=XXREAL-0R1 s1 .FUNCT-1K1 n"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have "n inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          then have "s .FUNCT-1K1 n <XXREAL-0R3 -XCMPLX-0K4 n"
            using A8 sorry
          thus "s .FUNCT-1K1 n <=XXREAL-0R1 s1 .FUNCT-1K1 n"
            using A3 sorry
        qed "sorry"
        then have "s be divergent-to-inftyLIMFUNC1V2"
          using A3 limfunc1_th_21 limfunc1_th_43 sorry
        then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 g"
          using A1 A2 A9 limfunc1_def_13 sorry
        then obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A10: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
          using A4 seq_2_def_7 sorry
        have A11: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 n -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
          using A10 sorry
        then have " |.COMPLEX1K10 f .FUNCT-1K1 (s .FUNCT-1K1 n) -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
          using A9 funct_2_th_108 A11 sorry
        thus " False "
          using A8 A11 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A12: " for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1)"
    have 
      [ty]:"g be RealXREAL-0M1"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds s be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 g"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A13: "s be divergent-to-inftyLIMFUNC1V2"
        and A14: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      have A15: " for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 g1)"
      proof(rule ballI,rule impI)
        fix g1 assume [ty]: "g1 be RealXREAL-0M1"
        assume A16: "0NUMBERSK6 <XXREAL-0R3 g1"
        obtain r where
          [ty]:"r be RealXREAL-0M1" and 
          A17: " for r1 be RealXREAL-0M1 holds r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
          using A12 A16 sorry
        obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A18: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies s .FUNCT-1K1 m <XXREAL-0R3 r"
          using A13 sorry
        show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          have A19: "s .FUNCT-1K1 m inTARSKIR2 rngFUNCT-1K2 s"
            using valued_0_th_28 sorry
          have A20: "m inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          assume "n <=XXREAL-0R1 m"
          then have " |.COMPLEX1K10 f .FUNCT-1K1 (s .FUNCT-1K1 m) -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
            using A14 A17 A18 A19 sorry
          thus " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
            using A14 funct_2_th_108 A20 sorry
        qed "sorry"
      qed "sorry"
      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
         sorry
      thus "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 g"
        using A15 seq_2_def_7 sorry
    qed "sorry"
    thus "lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 g"
      using A1 limfunc1_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_79:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for g be RealXREAL-0M1 holds f be convergent-in+inftyLIMFUNC1V3 implies (lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 g iff ( for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1)))"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for g be RealXREAL-0M1 holds f be convergent-in+inftyLIMFUNC1V3 implies (lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 g implies ( for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1))) & (( for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1)) implies lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 g)"
  proof(rule ballI,rule ballI,rule impI,rule conjMI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix g assume [ty]: "g be RealXREAL-0M1"
    assume A1: "f be convergent-in+inftyLIMFUNC1V3"
    show "lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 g implies ( for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1))"
    proof-
      have "lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 g implies (( ex g1 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g1 & ( for r be RealXREAL-0M1 holds  ex r1 be RealXREAL-0M1 st (r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) &  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| >=XXREAL-0R2 g1)) implies  False )"
      proof(rule impI,rule impI)
        assume A2: "lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 g"
        assume Given: " ex g1 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g1 & ( for r be RealXREAL-0M1 holds  ex r1 be RealXREAL-0M1 st (r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) &  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| >=XXREAL-0R2 g1)"
        then obtain g1 where
          [ty]:"g1 be RealXREAL-0M1" and 
          A3: "0NUMBERSK6 <XXREAL-0R3 g1"and A4: " for r be RealXREAL-0M1 holds  ex r1 be RealXREAL-0M1 st (r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) &  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| >=XXREAL-0R2 g1"
           sorry
        let ?X = "\<lambda>Lamb1. \<lambda>Lamb2. (Lamb1 <XXREAL-0R3 Lamb2 & Lamb2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) &  |.COMPLEX1K10 f .FUNCT-1K1 Lamb2 -XCMPLX-0K6 g .| >=XXREAL-0R2 g1"
        have A5: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex r be ElementSUBSET-1M1-of REALNUMBERSK2 st ?X(n,r)"
        proof-
          have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not ( for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not ((n <XXREAL-0R3 r & r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) &  |.COMPLEX1K10 f .FUNCT-1K1 r -XCMPLX-0K6 g .| >=XXREAL-0R2 g1))"
          proof(rule ballI)
            fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
            obtain r where
              [ty]:"r be RealXREAL-0M1" and 
              A6: "?X(n,r)"
              using A4 sorry
            have 
              [ty]:"r be RealXREAL-0M1"
               sorry
            have "?X(n,r)"
              using A6 sorry
            thus " not ( for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not ((n <XXREAL-0R3 r & r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) &  |.COMPLEX1K10 f .FUNCT-1K1 r -XCMPLX-0K6 g .| >=XXREAL-0R2 g1))"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain s where
          [ty]:"s be Real-SequenceSEQ-1M1" and 
          A7: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?X(n,s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
          using funct_2_sch_3 A5 sorry
        have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 s implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 rngFUNCT-1K2 s"
          then have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
            using funct_2_th_113 sorry
          thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using A7 sorry
        qed "sorry"
        then have A8: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
           sorry
        obtain s1 where 
          [ty]:"s1 be Real-SequenceSEQ-1M1" and s1Def:"s1 = idPARTFUN1K6 NATNUMBERSK1"
          using funct_2_th_7 numbers_th_19 sorry
        have " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n <=XXREAL-0R1 s .FUNCT-1K1 n"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have A9: "n inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          then have "n <XXREAL-0R3 s .FUNCT-1K1 n"
            using A7 sorry
          thus "s1 .FUNCT-1K1 n <=XXREAL-0R1 s .FUNCT-1K1 n"
            using funct_1_th_18 A9 sorry
        qed "sorry"
        then have "s be divergent-to+inftyLIMFUNC1V1"
          using limfunc1_lm_5 limfunc1_th_20 limfunc1_th_42 sorry
        then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 g"
          using A1 A2 A8 limfunc1_def_12 sorry
        then obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A10: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
          using A3 seq_2_def_7 sorry
        have A11: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 n -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
          using A10 sorry
        then have " |.COMPLEX1K10 f .FUNCT-1K1 (s .FUNCT-1K1 n) -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
          using A8 funct_2_th_108 A11 sorry
        thus " False "
          using A7 A11 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A12: " for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1)"
    have 
      [ty]:"g be RealXREAL-0M1"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds s be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 g"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A13: "s be divergent-to+inftyLIMFUNC1V1"
        and A14: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      have A15: " for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 g1)"
      proof(rule ballI,rule impI)
        fix g1 assume [ty]: "g1 be RealXREAL-0M1"
        assume A16: "0NUMBERSK6 <XXREAL-0R3 g1"
        obtain r where
          [ty]:"r be RealXREAL-0M1" and 
          A17: " for r1 be RealXREAL-0M1 holds r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
          using A12 A16 sorry
        obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A18: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies r <XXREAL-0R3 s .FUNCT-1K1 m"
          using A13 sorry
        show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          have A19: "s .FUNCT-1K1 m inTARSKIR2 rngFUNCT-1K2 s"
            using valued_0_th_28 sorry
          have A20: "m inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          assume "n <=XXREAL-0R1 m"
          then have " |.COMPLEX1K10 f .FUNCT-1K1 (s .FUNCT-1K1 m) -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
            using A14 A17 A18 A19 sorry
          thus " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
            using A14 funct_2_th_108 A20 sorry
        qed "sorry"
      qed "sorry"
      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
         sorry
      thus "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 g"
        using A15 seq_2_def_7 sorry
    qed "sorry"
    thus "lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 g"
      using A1 limfunc1_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_80:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds f be convergent-in+inftyLIMFUNC1V3 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) =COMPLEX1R1 r *XCMPLX-0K3 (lim-in+inftyLIMFUNC1K5 f)"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds f be convergent-in+inftyLIMFUNC1V3 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) =COMPLEX1R1 r *XCMPLX-0K3 (lim-in+inftyLIMFUNC1K5 f)"
  proof(rule ballI,rule ballI,rule impI,rule conjMI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "f be convergent-in+inftyLIMFUNC1V3"
    have A2: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 r *XCMPLX-0K3 (lim-in+inftyLIMFUNC1K5 f)"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A3: "seq be divergent-to+inftyLIMFUNC1V1"
        and A4: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      have A5: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A4 valued_1_def_5 sorry
      then have A6: "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f"
        using A1 A3 limfunc1_def_12 sorry
      have A7: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A1 A3 A5 sorry
      then have "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
         sorry
      thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A5 rfunct_2_th_9 sorry
      have "limSEQ-2K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 limSEQ-2K1 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)"
        using A5 rfunct_2_th_9 sorry
      also have "... = r *XCMPLX-0K3 (lim-in+inftyLIMFUNC1K5 f)"
        using A7 A6 seq_2_th_8 sorry
      finally show "limSEQ-2K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 r *XCMPLX-0K3 (lim-in+inftyLIMFUNC1K5 f)"
         sorry
    qed "sorry"
    have " for r1 be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r1 <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
    proof-
      have " for r1 be RealXREAL-0M1 holds  ex tVar67 be RealXREAL-0M1 st  not r1 <XXREAL-0R3 tVar67 & tVar67 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      proof(rule ballI)
        fix r1 assume [ty]: "r1 be RealXREAL-0M1"
        obtain g where
          [ty]:"g be RealXREAL-0M1" and 
          A8: "r1 <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A1 sorry
        show " ex tVar67 be RealXREAL-0M1 st  not r1 <XXREAL-0R3 tVar67 & tVar67 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
        proof(rule bexI[of _ "g"])
          show " not r1 <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
            using A8 valued_1_def_5 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be convergent-in+inftyLIMFUNC1V3"
      using A2 sorry
    thus "lim-in+inftyLIMFUNC1K5 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) =COMPLEX1R1 r *XCMPLX-0K3 (lim-in+inftyLIMFUNC1K5 f)"
      using A2 limfunc1_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_81:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be convergent-in+inftyLIMFUNC1V3 implies -VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) =COMPLEX1R1 -XCMPLX-0K4 lim-in+inftyLIMFUNC1K5 f"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be convergent-in+inftyLIMFUNC1V3 implies -VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) =HIDDENR1 -XCMPLX-0K4 lim-in+inftyLIMFUNC1K5 f"
  proof(rule ballI,rule impI,rule conjMI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f be convergent-in+inftyLIMFUNC1V3"
    show "-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be convergent-in+inftyLIMFUNC1V3"
      using A1 limfunc1_th_80 sorry
    have "lim-in+inftyLIMFUNC1K5 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (lim-in+inftyLIMFUNC1K5 f)"
      using A1 limfunc1_th_80 sorry
    also have "... = -XCMPLX-0K4 lim-in+inftyLIMFUNC1K5 f"
       sorry
    finally show "lim-in+inftyLIMFUNC1K5 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) =HIDDENR1 -XCMPLX-0K4 lim-in+inftyLIMFUNC1K5 f"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_82:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be convergent-in+inftyLIMFUNC1V3 & f2 be convergent-in+inftyLIMFUNC1V3) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f1 +XCMPLX-0K2 lim-in+inftyLIMFUNC1K5 f2"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be convergent-in+inftyLIMFUNC1V3 & (f2 be convergent-in+inftyLIMFUNC1V3 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f1 +XCMPLX-0K2 lim-in+inftyLIMFUNC1K5 f2"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be convergent-in+inftyLIMFUNC1V3"
      and A2: "f2 be convergent-in+inftyLIMFUNC1V3"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
    have A4: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 lim-in+inftyLIMFUNC1K5 f1 +XCMPLX-0K2 lim-in+inftyLIMFUNC1K5 f2"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A5: "seq be divergent-to+inftyLIMFUNC1V1"
        and A6: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      have A7: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc1_lm_2 sorry
      have A8: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc1_lm_2 sorry
      then have A9: "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f2"
        using A2 A5 limfunc1_def_12 sorry
      have A10: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A2 A5 A8 sorry
      have A11: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A6 limfunc1_lm_2 sorry
      then have A12: "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f1"
        using A1 A5 limfunc1_def_12 sorry
      have A13: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A1 A5 A11 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A10 sorry
      thus "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A6 A7 rfunct_2_th_8 sorry
      have "limSEQ-2K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 limSEQ-2K1 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)"
        using A6 A7 rfunct_2_th_8 sorry
      also have "... = lim-in+inftyLIMFUNC1K5 f1 +XCMPLX-0K2 lim-in+inftyLIMFUNC1K5 f2"
        using A13 A12 A10 A9 seq_2_th_6 sorry
      finally show "limSEQ-2K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 lim-in+inftyLIMFUNC1K5 f1 +XCMPLX-0K2 lim-in+inftyLIMFUNC1K5 f2"
         sorry
    qed "sorry"
    thus "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in+inftyLIMFUNC1V3"
      using A3 sorry
    thus "lim-in+inftyLIMFUNC1K5 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f1 +XCMPLX-0K2 lim-in+inftyLIMFUNC1K5 f2"
      using A4 limfunc1_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_83:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be convergent-in+inftyLIMFUNC1V3 & f2 be convergent-in+inftyLIMFUNC1V3) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) implies f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f1 -XCMPLX-0K6 lim-in+inftyLIMFUNC1K5 f2"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be convergent-in+inftyLIMFUNC1V3 & (f2 be convergent-in+inftyLIMFUNC1V3 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) implies f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =HIDDENR1 lim-in+inftyLIMFUNC1K5 f1 -XCMPLX-0K6 lim-in+inftyLIMFUNC1K5 f2"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be convergent-in+inftyLIMFUNC1V3"
      and A2: "f2 be convergent-in+inftyLIMFUNC1V3"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
    have A4: "-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in+inftyLIMFUNC1V3"
      using A2 limfunc1_th_81 sorry
    thus "f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in+inftyLIMFUNC1V3"
      using A1 A3 limfunc1_th_82 sorry
    have "lim-in+inftyLIMFUNC1K5 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =COMPLEX1R1 -XCMPLX-0K4 lim-in+inftyLIMFUNC1K5 f2"
      using A2 limfunc1_th_81 sorry
    then have "lim-in+inftyLIMFUNC1K5 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =HIDDENR1 lim-in+inftyLIMFUNC1K5 f1 +XCMPLX-0K2 (-XCMPLX-0K4 lim-in+inftyLIMFUNC1K5 f2)"
      using A1 A3 A4 limfunc1_th_82 sorry
    also have "... = lim-in+inftyLIMFUNC1K5 f1 -XCMPLX-0K6 lim-in+inftyLIMFUNC1K5 f2"
       sorry
    finally show "lim-in+inftyLIMFUNC1K5 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =HIDDENR1 lim-in+inftyLIMFUNC1K5 f1 -XCMPLX-0K6 lim-in+inftyLIMFUNC1K5 f2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_84:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f be convergent-in+inftyLIMFUNC1V3 & f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1) & lim-in+inftyLIMFUNC1K5 f <>HIDDENR2 0NUMBERSK6 implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 (lim-in+inftyLIMFUNC1K5 f)\<inverse>XCMPLX-0K5"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be convergent-in+inftyLIMFUNC1V3 & (f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 & lim-in+inftyLIMFUNC1K5 f <>HIDDENR2 0NUMBERSK6) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 (lim-in+inftyLIMFUNC1K5 f)\<inverse>XCMPLX-0K5"
  proof(rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f be convergent-in+inftyLIMFUNC1V3"
      and A2: "f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1"
      and A3: "lim-in+inftyLIMFUNC1K5 f <>HIDDENR2 0NUMBERSK6"
    have A4: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      using A2 sorry
    also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using rfunct_1_def_2 sorry
    finally have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
       sorry
    have A5: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 (lim-in+inftyLIMFUNC1K5 f)\<inverse>XCMPLX-0K5"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A6: "seq be divergent-to+inftyLIMFUNC1V1"
        and A7: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      have A8: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f"
        using A1 A4 A6 A7 limfunc1_def_12 sorry
      then have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5"
        using A3 A7 rfunct_2_th_11 seq_2_th_21 sorry
      thus "(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A7 rfunct_2_th_12 sorry
      have "limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 limSEQ-2K1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
        using A7 rfunct_2_th_12 sorry
      also have "... = (lim-in+inftyLIMFUNC1K5 f)\<inverse>XCMPLX-0K5"
        using A3 A7 A8 rfunct_2_th_11 seq_2_th_22 sorry
      finally show "limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 (lim-in+inftyLIMFUNC1K5 f)\<inverse>XCMPLX-0K5"
         sorry
    qed "sorry"
    have " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using A1 A4 sorry
    thus "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in+inftyLIMFUNC1V3"
      using A5 sorry
    thus "lim-in+inftyLIMFUNC1K5 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 (lim-in+inftyLIMFUNC1K5 f)\<inverse>XCMPLX-0K5"
      using A5 limfunc1_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_85:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be convergent-in+inftyLIMFUNC1V3 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f =COMPLEX1R1  |.COMPLEX1K10 lim-in+inftyLIMFUNC1K5 f .|"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be convergent-in+inftyLIMFUNC1V3 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f =COMPLEX1R1  |.COMPLEX1K10 lim-in+inftyLIMFUNC1K5 f .|"
  proof(rule ballI,rule impI,rule conjMI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f be convergent-in+inftyLIMFUNC1V3"
    have A2: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1  |.COMPLEX1K10 lim-in+inftyLIMFUNC1K5 f .|"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A3: "seq be divergent-to+inftyLIMFUNC1V1"
        and A4: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
      have A5: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A4 valued_1_def_11 sorry
      then have A6: "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f"
        using A1 A3 limfunc1_def_12 sorry
      have A7: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A1 A3 A5 sorry
      then have "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq) be convergentSEQ-2V5"
         sorry
      thus "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A5 rfunct_2_th_10 sorry
      have "limSEQ-2K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 limSEQ-2K1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)"
        using A5 rfunct_2_th_10 sorry
      also have "... =  |.COMPLEX1K10 lim-in+inftyLIMFUNC1K5 f .|"
        using A7 A6 seq_4_th_14 sorry
      finally show "limSEQ-2K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1  |.COMPLEX1K10 lim-in+inftyLIMFUNC1K5 f .|"
         sorry
    qed "sorry"
    have " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain g where
        [ty]:"g be RealXREAL-0M1" and 
        A8: "r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A1 sorry
      show " ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
      proof(rule bexI[of _ "g"])
        show "r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
          using A8 valued_1_def_11 sorry
      qed "sorry"
    qed "sorry"
    thus "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be convergent-in+inftyLIMFUNC1V3"
      using A2 sorry
    thus "lim-in+inftyLIMFUNC1K5 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f =COMPLEX1R1  |.COMPLEX1K10 lim-in+inftyLIMFUNC1K5 f .|"
      using A2 limfunc1_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_86:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f <>HIDDENR2 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 (lim-in+inftyLIMFUNC1K5 f)\<inverse>XCMPLX-0K5"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be convergent-in+inftyLIMFUNC1V3 & (lim-in+inftyLIMFUNC1K5 f <>HIDDENR2 0NUMBERSK6 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6)) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 (lim-in+inftyLIMFUNC1K5 f)\<inverse>XCMPLX-0K5"
  proof(rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f be convergent-in+inftyLIMFUNC1V3"
      and A2: "lim-in+inftyLIMFUNC1K5 f <>HIDDENR2 0NUMBERSK6"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6"
    have A4: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 (lim-in+inftyLIMFUNC1K5 f)\<inverse>XCMPLX-0K5"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A5: "seq be divergent-to+inftyLIMFUNC1V1"
        and A6: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using rfunct_1_def_2 xboole_1_th_36 sorry
      then have "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A6 sorry
      then have A7: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f"
        using A1 A5 limfunc1_def_12 sorry
      then have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5"
        using A2 A6 rfunct_2_th_11 seq_2_th_21 sorry
      thus "(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A6 rfunct_2_th_12 sorry
      have "limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 limSEQ-2K1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
        using A6 rfunct_2_th_12 sorry
      also have "... = (lim-in+inftyLIMFUNC1K5 f)\<inverse>XCMPLX-0K5"
        using A2 A6 A7 rfunct_2_th_11 seq_2_th_22 sorry
      finally show "limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 (lim-in+inftyLIMFUNC1K5 f)\<inverse>XCMPLX-0K5"
         sorry
    qed "sorry"
    have " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain g where
        [ty]:"g be RealXREAL-0M1" and 
        A8: "r <XXREAL-0R3 g"and A9: "g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and A10: "f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6"
        using A3 sorry
      show " ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      proof(rule bexI[of _ "g"])
        have " not f .FUNCT-1K1 g inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
          using A10 tarski_def_1 sorry
        then have " not g inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
          using funct_1_def_7 sorry
        then have "g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
          using A9 xboole_0_def_5 sorry
        thus "r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          using A8 rfunct_1_def_2 sorry
      qed "sorry"
    qed "sorry"
    thus "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in+inftyLIMFUNC1V3"
      using A4 sorry
    thus "lim-in+inftyLIMFUNC1K5 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 (lim-in+inftyLIMFUNC1K5 f)\<inverse>XCMPLX-0K5"
      using A4 limfunc1_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_87:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be convergent-in+inftyLIMFUNC1V3 & f2 be convergent-in+inftyLIMFUNC1V3) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =COMPLEX1R1 (lim-in+inftyLIMFUNC1K5 f1)*XCMPLX-0K3 (lim-in+inftyLIMFUNC1K5 f2)"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be convergent-in+inftyLIMFUNC1V3 & (f2 be convergent-in+inftyLIMFUNC1V3 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =COMPLEX1R1 (lim-in+inftyLIMFUNC1K5 f1)*XCMPLX-0K3 (lim-in+inftyLIMFUNC1K5 f2)"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be convergent-in+inftyLIMFUNC1V3"
      and A2: "f2 be convergent-in+inftyLIMFUNC1V3"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
    have A4: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 (lim-in+inftyLIMFUNC1K5 f1)*XCMPLX-0K3 (lim-in+inftyLIMFUNC1K5 f2)"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A5: "seq be divergent-to+inftyLIMFUNC1V1"
        and A6: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      have A7: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc1_lm_3 sorry
      have A8: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 limfunc1_lm_3 sorry
      then have A9: "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f2"
        using A2 A5 limfunc1_def_12 sorry
      have A10: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A2 A5 A8 sorry
      have A11: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A6 limfunc1_lm_3 sorry
      then have A12: "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f1"
        using A1 A5 limfunc1_def_12 sorry
      have A13: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A1 A5 A11 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A10 sorry
      thus "(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A6 A7 rfunct_2_th_8 sorry
      have "limSEQ-2K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 limSEQ-2K1 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)"
        using A6 A7 rfunct_2_th_8 sorry
      also have "... = (lim-in+inftyLIMFUNC1K5 f1)*XCMPLX-0K3 (lim-in+inftyLIMFUNC1K5 f2)"
        using A13 A12 A10 A9 seq_2_th_15 sorry
      finally show "limSEQ-2K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 (lim-in+inftyLIMFUNC1K5 f1)*XCMPLX-0K3 (lim-in+inftyLIMFUNC1K5 f2)"
         sorry
    qed "sorry"
    thus "f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in+inftyLIMFUNC1V3"
      using A3 sorry
    thus "lim-in+inftyLIMFUNC1K5 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =COMPLEX1R1 (lim-in+inftyLIMFUNC1K5 f1)*XCMPLX-0K3 (lim-in+inftyLIMFUNC1K5 f2)"
      using A4 limfunc1_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_88:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 be convergent-in+inftyLIMFUNC1V3 & f2 be convergent-in+inftyLIMFUNC1V3) & lim-in+inftyLIMFUNC1K5 f2 <>HIDDENR2 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) implies f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =COMPLEX1R1 (lim-in+inftyLIMFUNC1K5 f1)/XCMPLX-0K7 (lim-in+inftyLIMFUNC1K5 f2)"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be convergent-in+inftyLIMFUNC1V3 & ((f2 be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f2 <>HIDDENR2 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) implies f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =HIDDENR1 (lim-in+inftyLIMFUNC1K5 f1)/XCMPLX-0K7 (lim-in+inftyLIMFUNC1K5 f2)"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be convergent-in+inftyLIMFUNC1V3"
      and A2: "f2 be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f2 <>HIDDENR2 0NUMBERSK6"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      using rfunct_1_def_1 sorry
    then have A4: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using rfunct_1_def_2 sorry
    have A5: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using xboole_1_th_17 sorry
    have A6: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2) & f2 .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain g where
        [ty]:"g be RealXREAL-0M1" and 
        A7: "r <XXREAL-0R3 g"and A8: "g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A3 sorry
      show " ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2) & f2 .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6"
      proof(rule bexI[of _ "g"])
        have "g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          using A4 A5 A8 sorry
        then have A9: "g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
          using rfunct_1_def_2 sorry
        then have "g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 &  not g inHIDDENR3 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
          using xboole_0_def_5 sorry
        then have " not f2 .FUNCT-1K1 g inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
          using funct_1_def_7 sorry
        thus "(r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2) & f2 .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6"
          using A7 A9 tarski_def_1 xboole_0_def_5 sorry
      qed "sorry"
    qed "sorry"
    then have A10: "f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in+inftyLIMFUNC1V3"
      using A2 limfunc1_th_86 sorry
    have A11: "lim-in+inftyLIMFUNC1K5 (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 (lim-in+inftyLIMFUNC1K5 f2)\<inverse>XCMPLX-0K5"
      using A2 A6 limfunc1_th_86 sorry
    have A12: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain g where
        [ty]:"g be RealXREAL-0M1" and 
        A13: "r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A3 sorry
      show " ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
      proof(rule bexI[of _ "g"])
        show "r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
          using A4 A13 valued_1_def_4 sorry
      qed "sorry"
    qed "sorry"
    then have "f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) be convergent-in+inftyLIMFUNC1V3"
      using A1 A10 limfunc1_th_87 sorry
    thus "f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in+inftyLIMFUNC1V3"
      using rfunct_1_th_31 sorry
    have "lim-in+inftyLIMFUNC1K5 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =HIDDENR1 lim-in+inftyLIMFUNC1K5 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
      using rfunct_1_th_31 sorry
    also have "... = (lim-in+inftyLIMFUNC1K5 f1)*XCMPLX-0K3 (lim-in+inftyLIMFUNC1K5 f2)\<inverse>XCMPLX-0K5"
      using A1 A12 A10 A11 limfunc1_th_87 sorry
    also have "... = (lim-in+inftyLIMFUNC1K5 f1)/XCMPLX-0K7 (lim-in+inftyLIMFUNC1K5 f2)"
      using xcmplx_0_def_9 sorry
    finally show "lim-in+inftyLIMFUNC1K5 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =HIDDENR1 (lim-in+inftyLIMFUNC1K5 f1)/XCMPLX-0K7 (lim-in+inftyLIMFUNC1K5 f2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_89:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds f be convergent-in-inftyLIMFUNC1V6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) =COMPLEX1R1 r *XCMPLX-0K3 (lim-in-inftyLIMFUNC1K6 f)"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds f be convergent-in-inftyLIMFUNC1V6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) =COMPLEX1R1 r *XCMPLX-0K3 (lim-in-inftyLIMFUNC1K6 f)"
  proof(rule ballI,rule ballI,rule impI,rule conjMI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "f be convergent-in-inftyLIMFUNC1V6"
    have A2: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 r *XCMPLX-0K3 (lim-in-inftyLIMFUNC1K6 f)"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A3: "seq be divergent-to-inftyLIMFUNC1V2"
        and A4: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      have A5: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A4 valued_1_def_5 sorry
      then have A6: "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f"
        using A1 A3 limfunc1_def_13 sorry
      have A7: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A1 A3 A5 sorry
      then have "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
         sorry
      thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A5 rfunct_2_th_9 sorry
      have "limSEQ-2K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 limSEQ-2K1 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)"
        using A5 rfunct_2_th_9 sorry
      also have "... = r *XCMPLX-0K3 (lim-in-inftyLIMFUNC1K6 f)"
        using A7 A6 seq_2_th_8 sorry
      finally show "limSEQ-2K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 r *XCMPLX-0K3 (lim-in-inftyLIMFUNC1K6 f)"
         sorry
    qed "sorry"
    have " for r1 be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r1 & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
    proof-
      have " for r1 be RealXREAL-0M1 holds  ex tVar72 be RealXREAL-0M1 st  not tVar72 <XXREAL-0R3 r1 & tVar72 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      proof(rule ballI)
        fix r1 assume [ty]: "r1 be RealXREAL-0M1"
        obtain g where
          [ty]:"g be RealXREAL-0M1" and 
          A8: "g <XXREAL-0R3 r1 & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A1 sorry
        show " ex tVar72 be RealXREAL-0M1 st  not tVar72 <XXREAL-0R3 r1 & tVar72 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
        proof(rule bexI[of _ "g"])
          show " not g <XXREAL-0R3 r1 & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
            using A8 valued_1_def_5 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be convergent-in-inftyLIMFUNC1V6"
      using A2 sorry
    thus "lim-in-inftyLIMFUNC1K6 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) =COMPLEX1R1 r *XCMPLX-0K3 (lim-in-inftyLIMFUNC1K6 f)"
      using A2 limfunc1_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_90:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be convergent-in-inftyLIMFUNC1V6 implies -VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) =COMPLEX1R1 -XCMPLX-0K4 lim-in-inftyLIMFUNC1K6 f"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be convergent-in-inftyLIMFUNC1V6 implies -VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) =HIDDENR1 -XCMPLX-0K4 lim-in-inftyLIMFUNC1K6 f"
  proof(rule ballI,rule impI,rule conjMI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f be convergent-in-inftyLIMFUNC1V6"
    show "-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be convergent-in-inftyLIMFUNC1V6"
      using A1 limfunc1_th_89 sorry
    have "lim-in-inftyLIMFUNC1K6 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (lim-in-inftyLIMFUNC1K6 f)"
      using A1 limfunc1_th_89 sorry
    also have "... = -XCMPLX-0K4 lim-in-inftyLIMFUNC1K6 f"
       sorry
    finally show "lim-in-inftyLIMFUNC1K6 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) =HIDDENR1 -XCMPLX-0K4 lim-in-inftyLIMFUNC1K6 f"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_91:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be convergent-in-inftyLIMFUNC1V6 & f2 be convergent-in-inftyLIMFUNC1V6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f1 +XCMPLX-0K2 lim-in-inftyLIMFUNC1K6 f2"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be convergent-in-inftyLIMFUNC1V6 & (f2 be convergent-in-inftyLIMFUNC1V6 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f1 +XCMPLX-0K2 lim-in-inftyLIMFUNC1K6 f2"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be convergent-in-inftyLIMFUNC1V6"
      and A2: "f2 be convergent-in-inftyLIMFUNC1V6"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
    have A4: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 lim-in-inftyLIMFUNC1K6 f1 +XCMPLX-0K2 lim-in-inftyLIMFUNC1K6 f2"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A5: "seq be divergent-to-inftyLIMFUNC1V2"
        and A6: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      have A7: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 valued_1_def_1 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using xboole_1_th_17 sorry
      then have A8: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 sorry
      then have A9: "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f2"
        using A2 A5 limfunc1_def_13 sorry
      have A10: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A2 A5 A8 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using xboole_1_th_17 sorry
      then have A11: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A7 sorry
      then have A12: "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f1"
        using A1 A5 limfunc1_def_13 sorry
      have A13: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A1 A5 A11 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A10 sorry
      thus "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A7 rfunct_2_th_8 sorry
      have "limSEQ-2K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 limSEQ-2K1 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)"
        using A7 rfunct_2_th_8 sorry
      also have "... = lim-in-inftyLIMFUNC1K6 f1 +XCMPLX-0K2 lim-in-inftyLIMFUNC1K6 f2"
        using A13 A12 A10 A9 seq_2_th_6 sorry
      finally show "limSEQ-2K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 lim-in-inftyLIMFUNC1K6 f1 +XCMPLX-0K2 lim-in-inftyLIMFUNC1K6 f2"
         sorry
    qed "sorry"
    thus "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in-inftyLIMFUNC1V6"
      using A3 sorry
    thus "lim-in-inftyLIMFUNC1K6 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f1 +XCMPLX-0K2 lim-in-inftyLIMFUNC1K6 f2"
      using A4 limfunc1_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_92:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be convergent-in-inftyLIMFUNC1V6 & f2 be convergent-in-inftyLIMFUNC1V6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) implies f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f1 -XCMPLX-0K6 lim-in-inftyLIMFUNC1K6 f2"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be convergent-in-inftyLIMFUNC1V6 & (f2 be convergent-in-inftyLIMFUNC1V6 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) implies f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =HIDDENR1 lim-in-inftyLIMFUNC1K6 f1 -XCMPLX-0K6 lim-in-inftyLIMFUNC1K6 f2"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be convergent-in-inftyLIMFUNC1V6"
      and A2: "f2 be convergent-in-inftyLIMFUNC1V6"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
    have A4: "-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in-inftyLIMFUNC1V6"
      using A2 limfunc1_th_90 sorry
    thus "f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in-inftyLIMFUNC1V6"
      using A1 A3 limfunc1_th_91 sorry
    have "lim-in-inftyLIMFUNC1K6 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =COMPLEX1R1 -XCMPLX-0K4 lim-in-inftyLIMFUNC1K6 f2"
      using A2 limfunc1_th_90 sorry
    then have "lim-in-inftyLIMFUNC1K6 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =HIDDENR1 lim-in-inftyLIMFUNC1K6 f1 +XCMPLX-0K2 (-XCMPLX-0K4 lim-in-inftyLIMFUNC1K6 f2)"
      using A1 A3 A4 limfunc1_th_91 sorry
    also have "... = lim-in-inftyLIMFUNC1K6 f1 -XCMPLX-0K6 lim-in-inftyLIMFUNC1K6 f2"
       sorry
    finally show "lim-in-inftyLIMFUNC1K6 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =HIDDENR1 lim-in-inftyLIMFUNC1K6 f1 -XCMPLX-0K6 lim-in-inftyLIMFUNC1K6 f2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_93:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f be convergent-in-inftyLIMFUNC1V6 & f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1) & lim-in-inftyLIMFUNC1K6 f <>HIDDENR2 0NUMBERSK6 implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 (lim-in-inftyLIMFUNC1K6 f)\<inverse>XCMPLX-0K5"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be convergent-in-inftyLIMFUNC1V6 & (f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 & lim-in-inftyLIMFUNC1K6 f <>HIDDENR2 0NUMBERSK6) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 (lim-in-inftyLIMFUNC1K6 f)\<inverse>XCMPLX-0K5"
  proof(rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f be convergent-in-inftyLIMFUNC1V6"
      and A2: "f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1"
      and A3: "lim-in-inftyLIMFUNC1K6 f <>HIDDENR2 0NUMBERSK6"
    have A4: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      using A2 sorry
    also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using rfunct_1_def_2 sorry
    finally have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
       sorry
    have A5: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 (lim-in-inftyLIMFUNC1K6 f)\<inverse>XCMPLX-0K5"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A6: "seq be divergent-to-inftyLIMFUNC1V2"
        and A7: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      have A8: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f"
        using A1 A4 A6 A7 limfunc1_def_13 sorry
      then have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5"
        using A3 A7 rfunct_2_th_11 seq_2_th_21 sorry
      thus "(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A7 rfunct_2_th_12 sorry
      have "limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 limSEQ-2K1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
        using A7 rfunct_2_th_12 sorry
      also have "... = (lim-in-inftyLIMFUNC1K6 f)\<inverse>XCMPLX-0K5"
        using A3 A7 A8 rfunct_2_th_11 seq_2_th_22 sorry
      finally show "limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 (lim-in-inftyLIMFUNC1K6 f)\<inverse>XCMPLX-0K5"
         sorry
    qed "sorry"
    have " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using A1 A4 sorry
    thus "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in-inftyLIMFUNC1V6"
      using A5 sorry
    thus "lim-in-inftyLIMFUNC1K6 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 (lim-in-inftyLIMFUNC1K6 f)\<inverse>XCMPLX-0K5"
      using A5 limfunc1_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_94:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be convergent-in-inftyLIMFUNC1V6 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f =COMPLEX1R1  |.COMPLEX1K10 lim-in-inftyLIMFUNC1K6 f .|"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be convergent-in-inftyLIMFUNC1V6 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f =COMPLEX1R1  |.COMPLEX1K10 lim-in-inftyLIMFUNC1K6 f .|"
  proof(rule ballI,rule impI,rule conjMI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f be convergent-in-inftyLIMFUNC1V6"
    have A2: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1  |.COMPLEX1K10 lim-in-inftyLIMFUNC1K6 f .|"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A3: "seq be divergent-to-inftyLIMFUNC1V2"
        and A4: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
      have A5: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A4 valued_1_def_11 sorry
      then have A6: "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f"
        using A1 A3 limfunc1_def_13 sorry
      have A7: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A1 A3 A5 sorry
      then have "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq) be convergentSEQ-2V5"
         sorry
      thus "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A5 rfunct_2_th_10 sorry
      have "limSEQ-2K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 limSEQ-2K1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)"
        using A5 rfunct_2_th_10 sorry
      also have "... =  |.COMPLEX1K10 lim-in-inftyLIMFUNC1K6 f .|"
        using A7 A6 seq_4_th_14 sorry
      finally show "limSEQ-2K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1  |.COMPLEX1K10 lim-in-inftyLIMFUNC1K6 f .|"
         sorry
    qed "sorry"
    have " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain g where
        [ty]:"g be RealXREAL-0M1" and 
        A8: "g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A1 sorry
      show " ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
      proof(rule bexI[of _ "g"])
        show "g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
          using A8 valued_1_def_11 sorry
      qed "sorry"
    qed "sorry"
    thus "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be convergent-in-inftyLIMFUNC1V6"
      using A2 sorry
    thus "lim-in-inftyLIMFUNC1K6 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f =COMPLEX1R1  |.COMPLEX1K10 lim-in-inftyLIMFUNC1K6 f .|"
      using A2 limfunc1_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_95:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f <>HIDDENR2 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 (lim-in-inftyLIMFUNC1K6 f)\<inverse>XCMPLX-0K5"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be convergent-in-inftyLIMFUNC1V6 & (lim-in-inftyLIMFUNC1K6 f <>HIDDENR2 0NUMBERSK6 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6)) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 (lim-in-inftyLIMFUNC1K6 f)\<inverse>XCMPLX-0K5"
  proof(rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f be convergent-in-inftyLIMFUNC1V6"
      and A2: "lim-in-inftyLIMFUNC1K6 f <>HIDDENR2 0NUMBERSK6"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6"
    have A4: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 (lim-in-inftyLIMFUNC1K6 f)\<inverse>XCMPLX-0K5"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A5: "seq be divergent-to-inftyLIMFUNC1V2"
        and A6: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using rfunct_1_def_2 xboole_1_th_36 sorry
      then have "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A6 sorry
      then have A7: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f"
        using A1 A5 limfunc1_def_13 sorry
      then have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5"
        using A2 A6 rfunct_2_th_11 seq_2_th_21 sorry
      thus "(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A6 rfunct_2_th_12 sorry
      have "limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 limSEQ-2K1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
        using A6 rfunct_2_th_12 sorry
      also have "... = (lim-in-inftyLIMFUNC1K6 f)\<inverse>XCMPLX-0K5"
        using A2 A6 A7 rfunct_2_th_11 seq_2_th_22 sorry
      finally show "limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 (lim-in-inftyLIMFUNC1K6 f)\<inverse>XCMPLX-0K5"
         sorry
    qed "sorry"
    have " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain g where
        [ty]:"g be RealXREAL-0M1" and 
        A8: "g <XXREAL-0R3 r"and A9: "g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and A10: "f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6"
        using A3 sorry
      show " ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      proof(rule bexI[of _ "g"])
        have " not f .FUNCT-1K1 g inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
          using A10 tarski_def_1 sorry
        then have " not g inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
          using funct_1_def_7 sorry
        then have "g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
          using A9 xboole_0_def_5 sorry
        thus "g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          using A8 rfunct_1_def_2 sorry
      qed "sorry"
    qed "sorry"
    thus "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in-inftyLIMFUNC1V6"
      using A4 sorry
    thus "lim-in-inftyLIMFUNC1K6 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 (lim-in-inftyLIMFUNC1K6 f)\<inverse>XCMPLX-0K5"
      using A4 limfunc1_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_96:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be convergent-in-inftyLIMFUNC1V6 & f2 be convergent-in-inftyLIMFUNC1V6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =COMPLEX1R1 (lim-in-inftyLIMFUNC1K6 f1)*XCMPLX-0K3 (lim-in-inftyLIMFUNC1K6 f2)"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be convergent-in-inftyLIMFUNC1V6 & (f2 be convergent-in-inftyLIMFUNC1V6 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =COMPLEX1R1 (lim-in-inftyLIMFUNC1K6 f1)*XCMPLX-0K3 (lim-in-inftyLIMFUNC1K6 f2)"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be convergent-in-inftyLIMFUNC1V6"
      and A2: "f2 be convergent-in-inftyLIMFUNC1V6"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
    have A4: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 (lim-in-inftyLIMFUNC1K6 f1)*XCMPLX-0K3 (lim-in-inftyLIMFUNC1K6 f2)"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A5: "seq be divergent-to-inftyLIMFUNC1V2"
        and A6: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      have A7: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using valued_1_def_4 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using xboole_1_th_17 sorry
      then have A8: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A6 A7 sorry
      then have A9: "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f2"
        using A2 A5 limfunc1_def_13 sorry
      have A10: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A2 A5 A8 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using xboole_1_th_17 sorry
      then have A11: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A6 A7 sorry
      then have A12: "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f1"
        using A1 A5 limfunc1_def_13 sorry
      have A13: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A1 A5 A11 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A10 sorry
      thus "(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A6 A7 rfunct_2_th_8 sorry
      have "limSEQ-2K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 limSEQ-2K1 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)"
        using A6 A7 rfunct_2_th_8 sorry
      also have "... = (lim-in-inftyLIMFUNC1K6 f1)*XCMPLX-0K3 (lim-in-inftyLIMFUNC1K6 f2)"
        using A13 A12 A10 A9 seq_2_th_15 sorry
      finally show "limSEQ-2K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 (lim-in-inftyLIMFUNC1K6 f1)*XCMPLX-0K3 (lim-in-inftyLIMFUNC1K6 f2)"
         sorry
    qed "sorry"
    thus "f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in-inftyLIMFUNC1V6"
      using A3 sorry
    thus "lim-in-inftyLIMFUNC1K6 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =COMPLEX1R1 (lim-in-inftyLIMFUNC1K6 f1)*XCMPLX-0K3 (lim-in-inftyLIMFUNC1K6 f2)"
      using A4 limfunc1_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_97:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 be convergent-in-inftyLIMFUNC1V6 & f2 be convergent-in-inftyLIMFUNC1V6) & lim-in-inftyLIMFUNC1K6 f2 <>HIDDENR2 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) implies f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =COMPLEX1R1 (lim-in-inftyLIMFUNC1K6 f1)/XCMPLX-0K7 (lim-in-inftyLIMFUNC1K6 f2)"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be convergent-in-inftyLIMFUNC1V6 & ((f2 be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f2 <>HIDDENR2 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) implies f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =HIDDENR1 (lim-in-inftyLIMFUNC1K6 f1)/XCMPLX-0K7 (lim-in-inftyLIMFUNC1K6 f2)"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be convergent-in-inftyLIMFUNC1V6"
      and A2: "f2 be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f2 <>HIDDENR2 0NUMBERSK6"
      and A3: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      using rfunct_1_def_1 sorry
    then have A4: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using rfunct_1_def_2 sorry
    have A5: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using xboole_1_th_17 sorry
    have A6: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2) & f2 .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain g where
        [ty]:"g be RealXREAL-0M1" and 
        A7: "g <XXREAL-0R3 r"and A8: "g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A3 sorry
      show " ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2) & f2 .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6"
      proof(rule bexI[of _ "g"])
        have "g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          using A4 A5 A8 sorry
        then have A9: "g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
          using rfunct_1_def_2 sorry
        then have "g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 &  not g inHIDDENR3 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
          using xboole_0_def_5 sorry
        then have " not f2 .FUNCT-1K1 g inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
          using funct_1_def_7 sorry
        thus "(g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2) & f2 .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6"
          using A7 A9 tarski_def_1 xboole_0_def_5 sorry
      qed "sorry"
    qed "sorry"
    then have A10: "f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in-inftyLIMFUNC1V6"
      using A2 limfunc1_th_95 sorry
    have A11: "lim-in-inftyLIMFUNC1K6 (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 (lim-in-inftyLIMFUNC1K6 f2)\<inverse>XCMPLX-0K5"
      using A2 A6 limfunc1_th_95 sorry
    have A12: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain g where
        [ty]:"g be RealXREAL-0M1" and 
        A13: "g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A3 sorry
      show " ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
      proof(rule bexI[of _ "g"])
        show "g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
          using A4 A13 valued_1_def_4 sorry
      qed "sorry"
    qed "sorry"
    then have "f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) be convergent-in-inftyLIMFUNC1V6"
      using A1 A10 limfunc1_th_96 sorry
    thus "f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in-inftyLIMFUNC1V6"
      using rfunct_1_th_31 sorry
    have "lim-in-inftyLIMFUNC1K6 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =HIDDENR1 lim-in-inftyLIMFUNC1K6 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
      using rfunct_1_th_31 sorry
    also have "... = (lim-in-inftyLIMFUNC1K6 f1)*XCMPLX-0K3 (lim-in-inftyLIMFUNC1K6 f2)\<inverse>XCMPLX-0K5"
      using A1 A12 A10 A11 limfunc1_th_96 sorry
    also have "... = (lim-in-inftyLIMFUNC1K6 f1)/XCMPLX-0K7 (lim-in-inftyLIMFUNC1K6 f2)"
      using xcmplx_0_def_9 sorry
    finally show "lim-in-inftyLIMFUNC1K6 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =HIDDENR1 (lim-in-inftyLIMFUNC1K6 f1)/XCMPLX-0K7 (lim-in-inftyLIMFUNC1K6 f2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_98:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f1 =COMPLEX1R1 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) & ( ex r be RealXREAL-0M1 st f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be boundedSEQ-2V6) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f1 =COMPLEX1R1 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) implies (( ex r be RealXREAL-0M1 st f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be boundedSEQ-2V6) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =COMPLEX1R1 0NUMBERSK6)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI,rule conjMI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f1 =COMPLEX1R1 0NUMBERSK6"
      and A2: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
    assume Given: " ex r be RealXREAL-0M1 st f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be boundedSEQ-2V6"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A3: "f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be boundedSEQ-2V6"
       sorry
    obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A4: " for r1 be objectHIDDENM1 holds r1 inHIDDENR3 (right-open-halflineLIMFUNC1K4 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 implies  |.COMPLEX1K10 f2 .FUNCT-1K1 r1.| <=XXREAL-0R1 g"
      using A3 rfunct_1_th_73 sorry
    have A5: " for s be Real-SequenceSEQ-1M1 holds s be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 0NUMBERSK6"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A6: "s be divergent-to+inftyLIMFUNC1V1"
        and A7: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A8: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies r <XXREAL-0R3 s .FUNCT-1K1 n"
        using A6 sorry
      have A9: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 limfunc1_lm_3 sorry
      then have A11: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A9 sorry
      have "0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 g.| +XCMPLX-0K2 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds  |.COMPLEX1K10 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n.| <XXREAL-0R3  |.COMPLEX1K10 g.| +XCMPLX-0K2 \<one>\<^sub>M)"
      proof(rule conjMI,rule ballI)
        let ?t = " |.COMPLEX1K10 g.| +XCMPLX-0K2 \<one>\<^sub>M"
        have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 g.|"
          using complex1_th_46 sorry
        thus "0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 g.| +XCMPLX-0K2 \<one>\<^sub>M"
           sorry
        fix n assume [ty]: "n be NatNAT-1M1"
        have A12: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "r <XXREAL-0R3 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A8 nat_1_th_12 sorry
        then have "r <XXREAL-0R3 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n"
          using nat_1_def_3 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : r <XXREAL-0R3 g1 }"
           sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) & (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 right-open-halflineLIMFUNC1K4 r"
          using valued_0_th_28 xxreal_1_th_230 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 (right-open-halflineLIMFUNC1K4 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A11 xboole_0_def_4 sorry
        then have " |.COMPLEX1K10 f2 .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n).| <=XXREAL-0R1 g"
          using A4 sorry
        then have A13: " |.COMPLEX1K10 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n.| <=XXREAL-0R1 g"
          using A10 A9 funct_2_th_108 xboole_1_th_1 A12 sorry
        have "g <=XXREAL-0R1  |.COMPLEX1K10 g.|"
          using absvalue_th_4 sorry
        then have "g <XXREAL-0R3 ?t"
          using limfunc1_lm_1 sorry
        thus " |.COMPLEX1K10 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n.| <XXREAL-0R3  |.COMPLEX1K10 g.| +XCMPLX-0K2 \<one>\<^sub>M"
          using A13 xxreal_0_th_2 sorry
      qed "sorry"
      then have A14: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be boundedSEQ-2V6"
        using seq_2_th_3 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 limfunc1_lm_3 sorry
      then have "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 A9 sorry
      then have A15: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =HIDDENR1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        using rfunct_2_th_8 sorry
      also have "... = (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A7 valued_0_th_27 sorry
      finally have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =HIDDENR1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A7 limfunc1_lm_3 sorry
      then have A16: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A9 sorry
      have "s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be divergent-to+inftyLIMFUNC1V1"
        using A6 limfunc1_th_26 sorry
      then have A17: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5 & limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 0NUMBERSK6"
        using A1 A16 limfunc1_def_12 sorry
      then have A18: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5"
        using A14 seq_2_th_25 sorry
      thus "(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A15 seq_4_th_21 sorry
      have "limSEQ-2K1 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) =COMPLEX1R1 0NUMBERSK6"
        using A17 A14 seq_2_th_26 sorry
      thus "limSEQ-2K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 0NUMBERSK6"
        using A18 A15 seq_4_th_22 sorry
    qed "sorry"
    thus "f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in+inftyLIMFUNC1V3"
      using A2 sorry
    thus "lim-in+inftyLIMFUNC1K5 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =COMPLEX1R1 0NUMBERSK6"
      using A5 limfunc1_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_99:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f1 =COMPLEX1R1 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) & ( ex r be RealXREAL-0M1 st f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be boundedSEQ-2V6) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f1 =COMPLEX1R1 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) implies (( ex r be RealXREAL-0M1 st f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be boundedSEQ-2V6) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =COMPLEX1R1 0NUMBERSK6)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI,rule conjMI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f1 =COMPLEX1R1 0NUMBERSK6"
      and A2: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
    assume Given: " ex r be RealXREAL-0M1 st f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be boundedSEQ-2V6"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A3: "f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be boundedSEQ-2V6"
       sorry
    obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A4: " for r1 be objectHIDDENM1 holds r1 inHIDDENR3 (left-open-halflineLIMFUNC1K1 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 implies  |.COMPLEX1K10 f2 .FUNCT-1K1 r1.| <=XXREAL-0R1 g"
      using A3 rfunct_1_th_73 sorry
    have A5: " for s be Real-SequenceSEQ-1M1 holds s be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 0NUMBERSK6"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A6: "s be divergent-to-inftyLIMFUNC1V2"
        and A7: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A8: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies s .FUNCT-1K1 n <XXREAL-0R3 r"
        using A6 sorry
      have A9: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 limfunc1_lm_3 sorry
      then have A11: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A9 sorry
      have "0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 g.| +XCMPLX-0K2 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds  |.COMPLEX1K10 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n.| <XXREAL-0R3  |.COMPLEX1K10 g.| +XCMPLX-0K2 \<one>\<^sub>M)"
      proof(rule conjMI,rule ballI)
        let ?t = " |.COMPLEX1K10 g.| +XCMPLX-0K2 \<one>\<^sub>M"
        have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 g.|"
          using complex1_th_46 sorry
        thus "0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 g.| +XCMPLX-0K2 \<one>\<^sub>M"
           sorry
        fix n assume [ty]: "n be NatNAT-1M1"
        have A12: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) <XXREAL-0R3 r"
          using A8 nat_1_th_12 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n <XXREAL-0R3 r"
          using nat_1_def_3 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : g1 <XXREAL-0R3 r }"
           sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) & (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 left-open-halflineLIMFUNC1K1 r"
          using valued_0_th_28 xxreal_1_th_229 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 (left-open-halflineLIMFUNC1K1 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A11 xboole_0_def_4 sorry
        then have " |.COMPLEX1K10 f2 .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n).| <=XXREAL-0R1 g"
          using A4 sorry
        then have A13: " |.COMPLEX1K10 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n.| <=XXREAL-0R1 g"
          using A10 A9 funct_2_th_108 xboole_1_th_1 A12 sorry
        have "g <=XXREAL-0R1  |.COMPLEX1K10 g.|"
          using absvalue_th_4 sorry
        then have "g <XXREAL-0R3 ?t"
          using limfunc1_lm_1 sorry
        thus " |.COMPLEX1K10 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n.| <XXREAL-0R3  |.COMPLEX1K10 g.| +XCMPLX-0K2 \<one>\<^sub>M"
          using A13 xxreal_0_th_2 sorry
      qed "sorry"
      then have A14: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be boundedSEQ-2V6"
        using seq_2_th_3 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 limfunc1_lm_3 sorry
      then have "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 A9 sorry
      then have A15: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =HIDDENR1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        using rfunct_2_th_8 sorry
      also have "... = (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A7 valued_0_th_27 sorry
      finally have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =HIDDENR1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A7 limfunc1_lm_3 sorry
      then have A16: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A9 sorry
      have "s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be divergent-to-inftyLIMFUNC1V2"
        using A6 limfunc1_th_27 sorry
      then have A17: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5 & limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 0NUMBERSK6"
        using A1 A16 limfunc1_def_13 sorry
      then have A18: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5"
        using A14 seq_2_th_25 sorry
      thus "(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A15 seq_4_th_21 sorry
      have "limSEQ-2K1 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) =COMPLEX1R1 0NUMBERSK6"
        using A17 A14 seq_2_th_26 sorry
      thus "limSEQ-2K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 0NUMBERSK6"
        using A18 A15 seq_4_th_22 sorry
    qed "sorry"
    thus "f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in-inftyLIMFUNC1V6"
      using A2 sorry
    thus "lim-in-inftyLIMFUNC1K6 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =COMPLEX1R1 0NUMBERSK6"
      using A5 limfunc1_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_100:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (((f1 be convergent-in+inftyLIMFUNC1V3 & f2 be convergent-in+inftyLIMFUNC1V3) & lim-in+inftyLIMFUNC1K5 f1 =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f2) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)) & ( ex r be RealXREAL-0M1 st (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) or domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r)) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)) implies f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f1"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be convergent-in+inftyLIMFUNC1V3 & (f2 be convergent-in+inftyLIMFUNC1V3 & (lim-in+inftyLIMFUNC1K5 f1 =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f2 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f))) implies (( ex r1 be RealXREAL-0M1 st (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) or domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1)) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)) implies f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f1)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be convergent-in+inftyLIMFUNC1V3"
      and A2: "f2 be convergent-in+inftyLIMFUNC1V3"
      and A3: "lim-in+inftyLIMFUNC1K5 f1 =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f2"
      and A4: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    assume Given: " ex r1 be RealXREAL-0M1 st (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) or domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1)) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)"
    then obtain r1 where
      [ty]:"r1 be RealXREAL-0M1" and 
      A5: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) or domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1)"and A6: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g"
       sorry
    have "f be convergent-in+inftyLIMFUNC1V3 & (f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f1)"
    proof-
      show "f be convergent-in+inftyLIMFUNC1V3 & (f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f1)"
      proof-
        have cases: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) or domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1)"
          using A5 sorry
        have case1: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) implies f be convergent-in+inftyLIMFUNC1V3 & (f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f1)"
        proof(rule impI,rule conjMI)
          assume A7: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1)"
          have A8: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f1"
          proof(rule ballI,rule impMI ,rule impI,rule conjMI)
            fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
            assume A9: "seq be divergent-to+inftyLIMFUNC1V1"
              and A10: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            obtain k where
              [ty]:"k be NatNAT-1M1" and 
              A11: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies r1 <XXREAL-0R3 seq .FUNCT-1K1 n"
              using A9 sorry
            have A12: "seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be divergent-to+inftyLIMFUNC1V1"
              using A9 limfunc1_th_26 sorry
            have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 right-open-halflineLIMFUNC1K4 r1"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
              then obtain n where
                [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                A13: "x =HIDDENR1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using funct_2_th_113 sorry
              have "r1 <XXREAL-0R3 seq .FUNCT-1K1 (n +XCMPLX-0K2 k)"
                using A11 nat_1_th_12 sorry
              then have "r1 <XXREAL-0R3 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using nat_1_def_3 sorry
              then have "x inHIDDENR3 {g where g be RealXREAL-0M1 : r1 <XXREAL-0R3 g }"
                using A13 sorry
              thus "x inHIDDENR3 right-open-halflineLIMFUNC1K4 r1"
                using xxreal_1_th_230 sorry
            qed "sorry"
            then have A14: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 right-open-halflineLIMFUNC1K4 r1"
               sorry
            have A15: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngFUNCT-1K2 seq"
              using valued_0_th_21 sorry
            then have "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using A10 sorry
            then have A16: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1)"
              using A14 xboole_1_th_19 sorry
            then have A17: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1)"
              using A7 sorry
            then have A18: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1)"
              using A7 sorry
            have A19: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using xboole_1_th_17 sorry
            then have "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A18 sorry
            then have A20: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5 & limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f1"
              using A2 A3 A12 limfunc1_def_12 sorry
            have A21: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
              using xboole_1_th_17 sorry
            then have "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
              using A17 sorry
            then have A22: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5 & limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f1"
              using A1 A12 limfunc1_def_12 sorry
            have A23: " for n be NatNAT-1M1 holds f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n & f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
            proof(rule ballI)
              fix n assume [ty]: "n be NatNAT-1M1"
              have A24: "n inTARSKIR2 NATNUMBERSK1"
                using ordinal1_def_12 sorry
              have A25: "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
                using valued_0_th_28 sorry
              then have "f .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n) <=XXREAL-0R1 f2 .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
                using A6 A16 sorry
              then have A26: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f2 .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
                using A10 A15 funct_2_th_108 xboole_1_th_1 A24 sorry
              have "f1 .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n) <=XXREAL-0R1 f .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
                using A6 A16 A25 sorry
              then have "f1 .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n) <=XXREAL-0R1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
                using A10 A15 funct_2_th_108 A24 xboole_1_th_1 sorry
              thus "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n & f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
                using A17 A21 A18 A19 A26 funct_2_th_108 xboole_1_th_1 A24 sorry
            qed "sorry"
            have A27: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
              using A10 valued_0_th_27 sorry
            then have A28: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be convergentSEQ-2V5"
              using A22 A20 A23 seq_2_th_19 sorry
            thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
              using seq_4_th_21 sorry
            have "limSEQ-2K1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f1"
              using A22 A20 A23 A27 seq_2_th_20 sorry
            thus "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f1"
              using A28 seq_4_th_20 seq_4_th_21 sorry
          qed "sorry"
          thus "f be convergent-in+inftyLIMFUNC1V3"
            using A4 sorry
          thus "f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f1"
            using A8 limfunc1_def_12 sorry
        qed
        have case2: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) implies f be convergent-in+inftyLIMFUNC1V3 & (f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f1)"
        proof(rule impI,rule conjMI)
          assume A29: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1)"
          have A30: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f1"
          proof(rule ballI,rule impMI ,rule impI,rule conjMI)
            fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
            assume A31: "seq be divergent-to+inftyLIMFUNC1V1"
              and A32: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            obtain k where
              [ty]:"k be NatNAT-1M1" and 
              A33: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies r1 <XXREAL-0R3 seq .FUNCT-1K1 n"
              using A31 sorry
            have A34: "seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be divergent-to+inftyLIMFUNC1V1"
              using A31 limfunc1_th_26 sorry
            have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 right-open-halflineLIMFUNC1K4 r1"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
              then obtain n where
                [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                A35: "x =HIDDENR1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using funct_2_th_113 sorry
              have "r1 <XXREAL-0R3 seq .FUNCT-1K1 (n +XCMPLX-0K2 k)"
                using A33 nat_1_th_12 sorry
              then have "r1 <XXREAL-0R3 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using nat_1_def_3 sorry
              then have "x inHIDDENR3 {g where g be RealXREAL-0M1 : r1 <XXREAL-0R3 g }"
                using A35 sorry
              thus "x inHIDDENR3 right-open-halflineLIMFUNC1K4 r1"
                using xxreal_1_th_230 sorry
            qed "sorry"
            then have A36: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 right-open-halflineLIMFUNC1K4 r1"
               sorry
            have A37: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngFUNCT-1K2 seq"
              using valued_0_th_21 sorry
            then have "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using A32 sorry
            then have A38: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1)"
              using A36 xboole_1_th_19 sorry
            then have A39: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1)"
              using A29 sorry
            then have A40: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1)"
              using A29 sorry
            have A41: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
              using xboole_1_th_17 sorry
            then have "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
              using A40 sorry
            then have A42: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5 & limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f1"
              using A1 A34 limfunc1_def_12 sorry
            have A43: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using xboole_1_th_17 sorry
            then have "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A39 sorry
            then have A44: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5 & limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f1"
              using A2 A3 A34 limfunc1_def_12 sorry
            have A45: " for n be NatNAT-1M1 holds f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n & f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
            proof(rule ballI)
              fix n assume [ty]: "n be NatNAT-1M1"
              have A46: "n inTARSKIR2 NATNUMBERSK1"
                using ordinal1_def_12 sorry
              have A47: "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
                using valued_0_th_28 sorry
              then have "f .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n) <=XXREAL-0R1 f2 .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
                using A6 A38 sorry
              then have A48: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f2 .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
                using A32 A37 funct_2_th_108 xboole_1_th_1 A46 sorry
              have "f1 .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n) <=XXREAL-0R1 f .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
                using A6 A38 A47 sorry
              then have "f1 .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n) <=XXREAL-0R1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
                using A32 A37 funct_2_th_108 A46 xboole_1_th_1 sorry
              thus "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n & f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
                using A39 A43 A40 A41 A48 funct_2_th_108 xboole_1_th_1 A46 sorry
            qed "sorry"
            have A49: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
              using A32 valued_0_th_27 sorry
            then have A50: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be convergentSEQ-2V5"
              using A44 A42 A45 seq_2_th_19 sorry
            thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
              using seq_4_th_21 sorry
            have "limSEQ-2K1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f1"
              using A44 A42 A45 A49 seq_2_th_20 sorry
            thus "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f1"
              using A50 seq_4_th_20 seq_4_th_21 sorry
          qed "sorry"
          thus "f be convergent-in+inftyLIMFUNC1V3"
            using A4 sorry
          thus "f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f1"
            using A30 limfunc1_def_12 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_101:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 be convergent-in+inftyLIMFUNC1V3 & f2 be convergent-in+inftyLIMFUNC1V3) & lim-in+inftyLIMFUNC1K5 f1 =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f2) & ( ex r be RealXREAL-0M1 st right-open-halflineLIMFUNC1K4 r c=TARSKIR1 (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for g be RealXREAL-0M1 holds g inHIDDENR3 right-open-halflineLIMFUNC1K4 r implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)) implies f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f1"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be convergent-in+inftyLIMFUNC1V3 & f2 be convergent-in+inftyLIMFUNC1V3) & lim-in+inftyLIMFUNC1K5 f1 =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f2 implies (( ex r1 be RealXREAL-0M1 st right-open-halflineLIMFUNC1K4 r1 c=TARSKIR1 (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for g be RealXREAL-0M1 holds g inHIDDENR3 right-open-halflineLIMFUNC1K4 r1 implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)) implies f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f1)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "(f1 be convergent-in+inftyLIMFUNC1V3 & f2 be convergent-in+inftyLIMFUNC1V3) & lim-in+inftyLIMFUNC1K5 f1 =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f2"
    assume Given: " ex r1 be RealXREAL-0M1 st right-open-halflineLIMFUNC1K4 r1 c=TARSKIR1 (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for g be RealXREAL-0M1 holds g inHIDDENR3 right-open-halflineLIMFUNC1K4 r1 implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)"
    then obtain r1 where
      [ty]:"r1 be RealXREAL-0M1" and 
      A2: "right-open-halflineLIMFUNC1K4 r1 c=TARSKIR1 (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and A3: " for g be RealXREAL-0M1 holds g inHIDDENR3 right-open-halflineLIMFUNC1K4 r1 implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g"
       sorry
    have "(domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using xboole_1_th_17 sorry
    then have A4: "right-open-halflineLIMFUNC1K4 r1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A2 sorry
    have A5: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain g where
        [ty]:"g be RealXREAL-0M1" and 
        A6: " |.COMPLEX1K10 r.| +XCMPLX-0K2  |.COMPLEX1K10 r1.| <XXREAL-0R3 g"
        using xreal_1_th_1 sorry
      show " ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      proof(rule bexI[of _ "g"],rule conjMI)
        have "r <=XXREAL-0R1  |.COMPLEX1K10 r.| & 0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r1.|"
          using absvalue_th_4 complex1_th_46 sorry
        then have "r +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r.| +XCMPLX-0K2  |.COMPLEX1K10 r1.|"
          using xreal_1_th_7 sorry
        thus "r <XXREAL-0R3 g"
          using A6 xxreal_0_th_2 sorry
        have "r1 <=XXREAL-0R1  |.COMPLEX1K10 r1.| & 0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r.|"
          using absvalue_th_4 complex1_th_46 sorry
        then have "0NUMBERSK6 +XCMPLX-0K2 r1 <=XXREAL-0R1  |.COMPLEX1K10 r.| +XCMPLX-0K2  |.COMPLEX1K10 r1.|"
          using xreal_1_th_7 sorry
        then have "r1 <XXREAL-0R3 g"
          using A6 xxreal_0_th_2 sorry
        then have "g inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : r1 <XXREAL-0R3 g1 }"
           sorry
        then have "g inHIDDENR3 right-open-halflineLIMFUNC1K4 r1"
          using xxreal_1_th_230 sorry
        thus "g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A4 sorry
      qed "sorry"
    qed "sorry"
    have A7: "(domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using xboole_1_th_17 sorry
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) & (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g))"
    proof(rule conjMI,rule conjMI,rule ballI,rule impI)
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using xboole_1_th_17 sorry
      then have "(domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A7 sorry
      then have A8: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 r1"
        using A2 xboole_1_th_1 xboole_1_th_28 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using xboole_1_th_17 sorry
      then have "(domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 sorry
      thus "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1)"
        using A2 A8 xboole_1_th_1 xboole_1_th_28 sorry
      show "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1)"
        using A8 xboole_1_th_17 sorry
      fix g assume [ty]: "g be RealXREAL-0M1"
      assume "g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1)"
      then have "g inHIDDENR3 right-open-halflineLIMFUNC1K4 r1"
        using xboole_0_def_4 sorry
      thus "f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g"
        using A3 sorry
    qed "sorry"
    thus "f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f1"
      using A1 A5 limfunc1_th_100 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_102:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (((f1 be convergent-in-inftyLIMFUNC1V6 & f2 be convergent-in-inftyLIMFUNC1V6) & lim-in-inftyLIMFUNC1K6 f1 =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f2) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)) & ( ex r be RealXREAL-0M1 st (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) or domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r)) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)) implies f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f1"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be convergent-in-inftyLIMFUNC1V6 & (f2 be convergent-in-inftyLIMFUNC1V6 & (lim-in-inftyLIMFUNC1K6 f1 =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f2 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f))) implies (( ex r1 be RealXREAL-0M1 st (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) or domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1)) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)) implies f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f1)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be convergent-in-inftyLIMFUNC1V6"
      and A2: "f2 be convergent-in-inftyLIMFUNC1V6"
      and A3: "lim-in-inftyLIMFUNC1K6 f1 =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f2"
      and A4: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    assume Given: " ex r1 be RealXREAL-0M1 st (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) or domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1)) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)"
    then obtain r1 where
      [ty]:"r1 be RealXREAL-0M1" and 
      A5: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) or domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1)"and A6: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g"
       sorry
    have "f be convergent-in-inftyLIMFUNC1V6 & (f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f1)"
    proof-
      show "f be convergent-in-inftyLIMFUNC1V6 & (f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f1)"
      proof-
        have cases: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) or domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1)"
          using A5 sorry
        have case1: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) implies f be convergent-in-inftyLIMFUNC1V6 & (f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f1)"
        proof(rule impI,rule conjMI)
          assume A7: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1)"
          have A8: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f1"
          proof(rule ballI,rule impMI ,rule impI,rule conjMI)
            fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
            assume A9: "seq be divergent-to-inftyLIMFUNC1V2"
              and A10: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            obtain k where
              [ty]:"k be NatNAT-1M1" and 
              A11: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies seq .FUNCT-1K1 n <XXREAL-0R3 r1"
              using A9 sorry
            have A12: "seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be divergent-to-inftyLIMFUNC1V2"
              using A9 limfunc1_th_27 sorry
            have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 left-open-halflineLIMFUNC1K1 r1"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
              then obtain n where
                [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                A13: "x =HIDDENR1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using funct_2_th_113 sorry
              have "seq .FUNCT-1K1 (n +XCMPLX-0K2 k) <XXREAL-0R3 r1"
                using A11 nat_1_th_12 sorry
              then have "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 r1"
                using nat_1_def_3 sorry
              then have "x inHIDDENR3 {g where g be RealXREAL-0M1 : g <XXREAL-0R3 r1 }"
                using A13 sorry
              thus "x inHIDDENR3 left-open-halflineLIMFUNC1K1 r1"
                using xxreal_1_th_229 sorry
            qed "sorry"
            then have A14: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 left-open-halflineLIMFUNC1K1 r1"
               sorry
            have A15: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngFUNCT-1K2 seq"
              using valued_0_th_21 sorry
            then have "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using A10 sorry
            then have A16: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1)"
              using A14 xboole_1_th_19 sorry
            then have A17: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1)"
              using A7 sorry
            then have A18: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1)"
              using A7 sorry
            have A19: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using xboole_1_th_17 sorry
            then have "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A18 sorry
            then have A20: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5 & limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f1"
              using A2 A3 A12 limfunc1_def_13 sorry
            have A21: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
              using xboole_1_th_17 sorry
            then have "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
              using A17 sorry
            then have A22: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5 & limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f1"
              using A1 A12 limfunc1_def_13 sorry
            have A23: " for n be NatNAT-1M1 holds f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n & f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
            proof(rule ballI)
              fix n assume [ty]: "n be NatNAT-1M1"
              have A24: "n inTARSKIR2 NATNUMBERSK1"
                using ordinal1_def_12 sorry
              have A25: "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
                using valued_0_th_28 sorry
              then have "f .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n) <=XXREAL-0R1 f2 .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
                using A6 A16 sorry
              then have A26: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f2 .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
                using A10 A15 funct_2_th_108 xboole_1_th_1 A24 sorry
              have "f1 .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n) <=XXREAL-0R1 f .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
                using A6 A16 A25 sorry
              then have "f1 .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n) <=XXREAL-0R1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
                using A10 A15 funct_2_th_108 A24 xboole_1_th_1 sorry
              thus "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n & f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
                using A17 A21 A18 A19 A26 funct_2_th_108 xboole_1_th_1 A24 sorry
            qed "sorry"
            have A27: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
              using A10 valued_0_th_27 sorry
            then have A28: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be convergentSEQ-2V5"
              using A22 A20 A23 seq_2_th_19 sorry
            thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
              using seq_4_th_21 sorry
            have "limSEQ-2K1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f1"
              using A22 A20 A23 A27 seq_2_th_20 sorry
            thus "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f1"
              using A28 seq_4_th_20 seq_4_th_21 sorry
          qed "sorry"
          thus "f be convergent-in-inftyLIMFUNC1V6"
            using A4 sorry
          thus "f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f1"
            using A8 limfunc1_def_13 sorry
        qed
        have case2: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) implies f be convergent-in-inftyLIMFUNC1V6 & (f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f1)"
        proof(rule impI,rule conjMI)
          assume A29: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1)"
          have A30: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f1"
          proof(rule ballI,rule impMI ,rule impI,rule conjMI)
            fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
            assume A31: "seq be divergent-to-inftyLIMFUNC1V2"
              and A32: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            obtain k where
              [ty]:"k be NatNAT-1M1" and 
              A33: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies seq .FUNCT-1K1 n <XXREAL-0R3 r1"
              using A31 sorry
            have A34: "seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be divergent-to-inftyLIMFUNC1V2"
              using A31 limfunc1_th_27 sorry
            have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 left-open-halflineLIMFUNC1K1 r1"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
              then obtain n where
                [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                A35: "x =HIDDENR1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using funct_2_th_113 sorry
              have "seq .FUNCT-1K1 (n +XCMPLX-0K2 k) <XXREAL-0R3 r1"
                using A33 nat_1_th_12 sorry
              then have "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 r1"
                using nat_1_def_3 sorry
              then have "x inHIDDENR3 {g where g be RealXREAL-0M1 : g <XXREAL-0R3 r1 }"
                using A35 sorry
              thus "x inHIDDENR3 left-open-halflineLIMFUNC1K1 r1"
                using xxreal_1_th_229 sorry
            qed "sorry"
            then have A36: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 left-open-halflineLIMFUNC1K1 r1"
               sorry
            have A37: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngFUNCT-1K2 seq"
              using valued_0_th_21 sorry
            then have "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using A32 sorry
            then have A38: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1)"
              using A36 xboole_1_th_19 sorry
            then have A39: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1)"
              using A29 sorry
            then have A40: "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1)"
              using A29 sorry
            have A41: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
              using xboole_1_th_17 sorry
            then have "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
              using A40 sorry
            then have A42: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5 & limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f1"
              using A1 A34 limfunc1_def_13 sorry
            have A43: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using xboole_1_th_17 sorry
            then have "rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A39 sorry
            then have A44: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5 & limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f1"
              using A2 A3 A34 limfunc1_def_13 sorry
            have A45: " for n be NatNAT-1M1 holds f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n & f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
            proof(rule ballI)
              fix n assume [ty]: "n be NatNAT-1M1"
              have A46: "n inTARSKIR2 NATNUMBERSK1"
                using ordinal1_def_12 sorry
              have A47: "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
                using valued_0_th_28 sorry
              then have "f .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n) <=XXREAL-0R1 f2 .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
                using A6 A38 sorry
              then have A48: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f2 .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
                using A32 A37 funct_2_th_108 xboole_1_th_1 A46 sorry
              have "f1 .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n) <=XXREAL-0R1 f .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
                using A6 A38 A47 sorry
              then have "f1 .FUNCT-1K1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n) <=XXREAL-0R1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
                using A32 A37 funct_2_th_108 A46 xboole_1_th_1 sorry
              thus "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n & f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
                using A39 A43 A40 A41 A48 funct_2_th_108 xboole_1_th_1 A46 sorry
            qed "sorry"
            have A49: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
              using A32 valued_0_th_27 sorry
            then have A50: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be convergentSEQ-2V5"
              using A44 A42 A45 seq_2_th_19 sorry
            thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
              using seq_4_th_21 sorry
            have "limSEQ-2K1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f1"
              using A44 A42 A45 A49 seq_2_th_20 sorry
            thus "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f1"
              using A50 seq_4_th_20 seq_4_th_21 sorry
          qed "sorry"
          thus "f be convergent-in-inftyLIMFUNC1V6"
            using A4 sorry
          thus "f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f1"
            using A30 limfunc1_def_13 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_103:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 be convergent-in-inftyLIMFUNC1V6 & f2 be convergent-in-inftyLIMFUNC1V6) & lim-in-inftyLIMFUNC1K6 f1 =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f2) & ( ex r be RealXREAL-0M1 st left-open-halflineLIMFUNC1K1 r c=TARSKIR1 (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for g be RealXREAL-0M1 holds g inHIDDENR3 left-open-halflineLIMFUNC1K1 r implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)) implies f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f1"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be convergent-in-inftyLIMFUNC1V6 & f2 be convergent-in-inftyLIMFUNC1V6) & lim-in-inftyLIMFUNC1K6 f1 =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f2 implies (( ex r1 be RealXREAL-0M1 st left-open-halflineLIMFUNC1K1 r1 c=TARSKIR1 (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for g be RealXREAL-0M1 holds g inHIDDENR3 left-open-halflineLIMFUNC1K1 r1 implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)) implies f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f1)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "(f1 be convergent-in-inftyLIMFUNC1V6 & f2 be convergent-in-inftyLIMFUNC1V6) & lim-in-inftyLIMFUNC1K6 f1 =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f2"
    assume Given: " ex r1 be RealXREAL-0M1 st left-open-halflineLIMFUNC1K1 r1 c=TARSKIR1 (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for g be RealXREAL-0M1 holds g inHIDDENR3 left-open-halflineLIMFUNC1K1 r1 implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)"
    then obtain r1 where
      [ty]:"r1 be RealXREAL-0M1" and 
      A2: "left-open-halflineLIMFUNC1K1 r1 c=TARSKIR1 (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and A3: " for g be RealXREAL-0M1 holds g inHIDDENR3 left-open-halflineLIMFUNC1K1 r1 implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g"
       sorry
    have "(domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using xboole_1_th_17 sorry
    then have A4: "left-open-halflineLIMFUNC1K1 r1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A2 sorry
    have A5: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain g where
        [ty]:"g be RealXREAL-0M1" and 
        A6: "g <XXREAL-0R3 (-XCMPLX-0K4  |.COMPLEX1K10 r.|)-XCMPLX-0K6  |.COMPLEX1K10 r1.|"
        using xreal_1_th_2 sorry
      show " ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      proof(rule bexI[of _ "g"],rule conjMI)
        have "-XCMPLX-0K4  |.COMPLEX1K10 r.| <=XXREAL-0R1 r & 0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r1.|"
          using absvalue_th_4 complex1_th_46 sorry
        then have "(-XCMPLX-0K4  |.COMPLEX1K10 r.|)-XCMPLX-0K6  |.COMPLEX1K10 r1.| <=XXREAL-0R1 r -XCMPLX-0K6 0NUMBERSK6"
          using xreal_1_th_13 sorry
        thus "g <XXREAL-0R3 r"
          using A6 xxreal_0_th_2 sorry
        have "-XCMPLX-0K4  |.COMPLEX1K10 r1.| <=XXREAL-0R1 r1 & 0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r.|"
          using absvalue_th_4 complex1_th_46 sorry
        then have "(-XCMPLX-0K4  |.COMPLEX1K10 r1.|)-XCMPLX-0K6  |.COMPLEX1K10 r.| <=XXREAL-0R1 r1 -XCMPLX-0K6 0NUMBERSK6"
          using xreal_1_th_13 sorry
        then have "g <XXREAL-0R3 r1"
          using A6 xxreal_0_th_2 sorry
        then have "g inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : g1 <XXREAL-0R3 r1 }"
           sorry
        then have "g inHIDDENR3 left-open-halflineLIMFUNC1K1 r1"
          using xxreal_1_th_229 sorry
        thus "g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A4 sorry
      qed "sorry"
    qed "sorry"
    have A7: "(domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using xboole_1_th_17 sorry
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) & (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g))"
    proof(rule conjMI,rule conjMI,rule ballI,rule impI)
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using xboole_1_th_17 sorry
      then have "(domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A7 sorry
      then have A8: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) =XBOOLE-0R4 left-open-halflineLIMFUNC1K1 r1"
        using A2 xboole_1_th_1 xboole_1_th_28 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using xboole_1_th_17 sorry
      then have "(domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A7 sorry
      thus "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1)"
        using A2 A8 xboole_1_th_1 xboole_1_th_28 sorry
      show "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1)"
        using A8 xboole_1_th_17 sorry
      fix g assume [ty]: "g be RealXREAL-0M1"
      assume "g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1)"
      then have "g inHIDDENR3 left-open-halflineLIMFUNC1K1 r1"
        using xboole_0_def_4 sorry
      thus "f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g"
        using A3 sorry
    qed "sorry"
    thus "f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f1"
      using A1 A5 limfunc1_th_102 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_104:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be convergent-in+inftyLIMFUNC1V3 & f2 be convergent-in+inftyLIMFUNC1V3) & ( ex r be RealXREAL-0M1 st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g) or domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)) implies lim-in+inftyLIMFUNC1K5 f1 <=XXREAL-0R1 lim-in+inftyLIMFUNC1K5 f2"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be convergent-in+inftyLIMFUNC1V3 & f2 be convergent-in+inftyLIMFUNC1V3 implies (( ex r be RealXREAL-0M1 st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g) or domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)) implies lim-in+inftyLIMFUNC1K5 f1 <=XXREAL-0R1 lim-in+inftyLIMFUNC1K5 f2)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be convergent-in+inftyLIMFUNC1V3"
      and A2: "f2 be convergent-in+inftyLIMFUNC1V3"
    assume Given: " ex r be RealXREAL-0M1 st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g) or domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A3: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g) or domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)"
       sorry
    have "lim-in+inftyLIMFUNC1K5 f1 <=XXREAL-0R1 lim-in+inftyLIMFUNC1K5 f2"
    proof-
      show "lim-in+inftyLIMFUNC1K5 f1 <=XXREAL-0R1 lim-in+inftyLIMFUNC1K5 f2"
      proof-
        have cases: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g) or domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)"
          using A3 sorry
        have case1: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g) implies lim-in+inftyLIMFUNC1K5 f1 <=XXREAL-0R1 lim-in+inftyLIMFUNC1K5 f2"
        proof(rule impI)
          assume A4: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)"
          let ?X = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb1 <XXREAL-0R3 Lamb2 & Lamb2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r)"
          have A5: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex g be ElementSUBSET-1M1-of REALNUMBERSK2 st n <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r)"
          proof(rule ballI)
            fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
            have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r.|"
              using complex1_th_46 sorry
            then have A6: "n +NAT-1K1 0NUMBERSK6 <=XXREAL-0R1 n +XCMPLX-0K2  |.COMPLEX1K10 r.|"
              using xreal_1_th_7 sorry
            obtain g where
              [ty]:"g be RealXREAL-0M1" and 
              A7: "n +XCMPLX-0K2  |.COMPLEX1K10 r.| <XXREAL-0R3 g"and A8: "g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
              using A1 sorry
            have 
              [ty]:"g be ElementSUBSET-1M1-of REALNUMBERSK2"
              using xreal_0_def_1 sorry
            show " ex g be ElementSUBSET-1M1-of REALNUMBERSK2 st n <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r)"
            proof(rule bexI[of _ "g"])
              have "0NUMBERSK6 <=XXREAL-0R1 n & r <=XXREAL-0R1  |.COMPLEX1K10 r.|"
                using absvalue_th_4 sorry
              then have "0NUMBERSK6 +XCMPLX-0K2 r <=XXREAL-0R1 n +XCMPLX-0K2  |.COMPLEX1K10 r.|"
                using xreal_1_th_7 sorry
              then have "r <XXREAL-0R3 g"
                using A7 xxreal_0_th_2 sorry
              then have "g inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : r <XXREAL-0R3 g2 }"
                 sorry
              then have "g inTARSKIR2 right-open-halflineLIMFUNC1K4 r"
                using xxreal_1_th_230 sorry
              thus "n <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r)"
                using A7 A8 A6 xboole_0_def_4 xxreal_0_th_2 sorry
            qed "sorry"
          qed "sorry"
          obtain s2 where
            [ty]:"s2 be Real-SequenceSEQ-1M1" and 
            A9: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?X(n,s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
            using funct_2_sch_3 A5 sorry
          obtain s1 where 
            [ty]:"s1 be Real-SequenceSEQ-1M1" and s1Def:"s1 = idPARTFUN1K6 NATNUMBERSK1"
            using funct_2_th_7 numbers_th_19 sorry
          have " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n <=XXREAL-0R1 s2 .FUNCT-1K1 n"
          proof(rule ballI)
            fix n assume [ty]: "n be NatNAT-1M1"
            have A10: "n inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            then have "n <XXREAL-0R3 s2 .FUNCT-1K1 n"
              using A9 sorry
            thus "s1 .FUNCT-1K1 n <=XXREAL-0R1 s2 .FUNCT-1K1 n"
              using funct_1_th_18 A10 sorry
          qed "sorry"
          then have A11: "s2 be divergent-to+inftyLIMFUNC1V1"
            using limfunc1_lm_5 limfunc1_th_20 limfunc1_th_42 sorry
          have A12: "rngFUNCT-1K2 s2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          proof-
            have " for x be RealXREAL-0M1 holds x inHIDDENR3 rngFUNCT-1K2 s2 implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be RealXREAL-0M1"
              assume "x inHIDDENR3 rngFUNCT-1K2 s2"
              then have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st x =COMPLEX1R1 s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using funct_2_th_113 sorry
              then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r)"
                using A9 sorry
              thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
                using A4 xboole_0_def_4 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 s2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using membered_def_9 sorry
          qed
          then have A13: "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f2"
            using A2 A11 limfunc1_def_12 sorry
          have A14: "rngFUNCT-1K2 s2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
          proof-
            have " for x be RealXREAL-0M1 holds x inHIDDENR3 rngFUNCT-1K2 s2 implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be RealXREAL-0M1"
              assume "x inHIDDENR3 rngFUNCT-1K2 s2"
              then have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st x =COMPLEX1R1 s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using funct_2_th_113 sorry
              then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r)"
                using A9 sorry
              thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
                using xboole_0_def_4 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 s2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
              using membered_def_9 sorry
          qed
          have A15: " for n be NatNAT-1M1 holds f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 .FUNCT-1K1 n <=XXREAL-0R1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 .FUNCT-1K1 n"
          proof(rule ballI)
            fix n assume [ty]: "n be NatNAT-1M1"
            have A16: "n inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "f1 .FUNCT-1K1 (s2 .FUNCT-1K1 n) <=XXREAL-0R1 f2 .FUNCT-1K1 (s2 .FUNCT-1K1 n)"
              using A4 A9 A16 sorry
            then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 .FUNCT-1K1 n <=XXREAL-0R1 f2 .FUNCT-1K1 (s2 .FUNCT-1K1 n)"
              using A14 funct_2_th_108 A16 sorry
            thus "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 .FUNCT-1K1 n <=XXREAL-0R1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 .FUNCT-1K1 n"
              using A12 funct_2_th_108 A16 sorry
          qed "sorry"
          have A17: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 be convergentSEQ-2V5"
            using A2 A11 A12 sorry
          have A18: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 be convergentSEQ-2V5"
            using A1 A11 A14 sorry
          have "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f1"
            using A1 A11 A14 limfunc1_def_12 sorry
          thus "lim-in+inftyLIMFUNC1K5 f1 <=XXREAL-0R1 lim-in+inftyLIMFUNC1K5 f2"
            using A18 A17 A13 A15 seq_2_th_18 sorry
        qed
        have case2: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g) implies lim-in+inftyLIMFUNC1K5 f1 <=XXREAL-0R1 lim-in+inftyLIMFUNC1K5 f2"
        proof(rule impI)
          assume A19: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)"
          let ?X = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb1 <XXREAL-0R3 Lamb2 & Lamb2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r)"
          have A20: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex g be ElementSUBSET-1M1-of REALNUMBERSK2 st n <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r)"
          proof(rule ballI)
            fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
            have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r.|"
              using complex1_th_46 sorry
            then have A21: "n +NAT-1K1 0NUMBERSK6 <=XXREAL-0R1 n +XCMPLX-0K2  |.COMPLEX1K10 r.|"
              using xreal_1_th_7 sorry
            obtain g where
              [ty]:"g be RealXREAL-0M1" and 
              A22: "n +XCMPLX-0K2  |.COMPLEX1K10 r.| <XXREAL-0R3 g"and A23: "g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A2 sorry
            have 
              [ty]:"g be ElementSUBSET-1M1-of REALNUMBERSK2"
              using xreal_0_def_1 sorry
            show " ex g be ElementSUBSET-1M1-of REALNUMBERSK2 st n <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r)"
            proof(rule bexI[of _ "g"])
              have "0NUMBERSK6 <=XXREAL-0R1 n & r <=XXREAL-0R1  |.COMPLEX1K10 r.|"
                using absvalue_th_4 sorry
              then have "0NUMBERSK6 +XCMPLX-0K2 r <=XXREAL-0R1 n +XCMPLX-0K2  |.COMPLEX1K10 r.|"
                using xreal_1_th_7 sorry
              then have "r <XXREAL-0R3 g"
                using A22 xxreal_0_th_2 sorry
              then have "g inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : r <XXREAL-0R3 g2 }"
                 sorry
              then have "g inTARSKIR2 right-open-halflineLIMFUNC1K4 r"
                using xxreal_1_th_230 sorry
              thus "n <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r)"
                using A22 A23 A21 xboole_0_def_4 xxreal_0_th_2 sorry
            qed "sorry"
          qed "sorry"
          obtain s2 where
            [ty]:"s2 be Real-SequenceSEQ-1M1" and 
            A24: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?X(n,s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
            using funct_2_sch_3 A20 sorry
          obtain s1 where 
            [ty]:"s1 be Real-SequenceSEQ-1M1" and s1Def:"s1 = idPARTFUN1K6 NATNUMBERSK1"
            using funct_2_th_7 numbers_th_19 sorry
          have " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n <=XXREAL-0R1 s2 .FUNCT-1K1 n"
          proof(rule ballI)
            fix n assume [ty]: "n be NatNAT-1M1"
            have A25: "n inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            then have "n <XXREAL-0R3 s2 .FUNCT-1K1 n"
              using A24 sorry
            thus "s1 .FUNCT-1K1 n <=XXREAL-0R1 s2 .FUNCT-1K1 n"
              using funct_1_th_18 A25 sorry
          qed "sorry"
          then have A26: "s2 be divergent-to+inftyLIMFUNC1V1"
            using limfunc1_lm_5 limfunc1_th_20 limfunc1_th_42 sorry
          have A27: "rngFUNCT-1K2 s2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
          proof-
            have " for x be RealXREAL-0M1 holds x inHIDDENR3 rngFUNCT-1K2 s2 implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be RealXREAL-0M1"
              assume "x inHIDDENR3 rngFUNCT-1K2 s2"
              then have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st x =COMPLEX1R1 s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using funct_2_th_113 sorry
              then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r)"
                using A24 sorry
              thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
                using A19 xboole_0_def_4 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 s2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
              using membered_def_9 sorry
          qed
          then have A28: "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f1"
            using A1 A26 limfunc1_def_12 sorry
          have A29: "rngFUNCT-1K2 s2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          proof-
            have " for x be RealXREAL-0M1 holds x inHIDDENR3 rngFUNCT-1K2 s2 implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be RealXREAL-0M1"
              assume "x inHIDDENR3 rngFUNCT-1K2 s2"
              then have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st x =COMPLEX1R1 s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using funct_2_th_113 sorry
              then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r)"
                using A24 sorry
              thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
                using xboole_0_def_4 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 s2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using membered_def_9 sorry
          qed
          have A30: " for n be NatNAT-1M1 holds f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 .FUNCT-1K1 n <=XXREAL-0R1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 .FUNCT-1K1 n"
          proof(rule ballI)
            fix n assume [ty]: "n be NatNAT-1M1"
            have A31: "n inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "f1 .FUNCT-1K1 (s2 .FUNCT-1K1 n) <=XXREAL-0R1 f2 .FUNCT-1K1 (s2 .FUNCT-1K1 n)"
              using A19 A24 A31 sorry
            then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 .FUNCT-1K1 n <=XXREAL-0R1 f2 .FUNCT-1K1 (s2 .FUNCT-1K1 n)"
              using A27 funct_2_th_108 A31 sorry
            thus "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 .FUNCT-1K1 n <=XXREAL-0R1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 .FUNCT-1K1 n"
              using A29 funct_2_th_108 A31 sorry
          qed "sorry"
          have A32: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 be convergentSEQ-2V5"
            using A1 A26 A27 sorry
          have A33: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 be convergentSEQ-2V5"
            using A2 A26 A29 sorry
          have "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f2"
            using A2 A26 A29 limfunc1_def_12 sorry
          thus "lim-in+inftyLIMFUNC1K5 f1 <=XXREAL-0R1 lim-in+inftyLIMFUNC1K5 f2"
            using A33 A32 A28 A30 seq_2_th_18 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "lim-in+inftyLIMFUNC1K5 f1 <=XXREAL-0R1 lim-in+inftyLIMFUNC1K5 f2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_105:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be convergent-in-inftyLIMFUNC1V6 & f2 be convergent-in-inftyLIMFUNC1V6) & ( ex r be RealXREAL-0M1 st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g) or domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)) implies lim-in-inftyLIMFUNC1K6 f1 <=XXREAL-0R1 lim-in-inftyLIMFUNC1K6 f2"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be convergent-in-inftyLIMFUNC1V6 & f2 be convergent-in-inftyLIMFUNC1V6 implies (( ex r be RealXREAL-0M1 st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g) or domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)) implies lim-in-inftyLIMFUNC1K6 f1 <=XXREAL-0R1 lim-in-inftyLIMFUNC1K6 f2)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 be convergent-in-inftyLIMFUNC1V6"
      and A2: "f2 be convergent-in-inftyLIMFUNC1V6"
    assume Given: " ex r be RealXREAL-0M1 st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g) or domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A3: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g) or domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)"
       sorry
    have "lim-in-inftyLIMFUNC1K6 f1 <=XXREAL-0R1 lim-in-inftyLIMFUNC1K6 f2"
    proof-
      show "lim-in-inftyLIMFUNC1K6 f1 <=XXREAL-0R1 lim-in-inftyLIMFUNC1K6 f2"
      proof-
        have cases: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g) or domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)"
          using A3 sorry
        have case1: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g) implies lim-in-inftyLIMFUNC1K6 f1 <=XXREAL-0R1 lim-in-inftyLIMFUNC1K6 f2"
        proof(rule impI)
          assume A4: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)"
          let ?U = "\<lambda>Lamb1. -XCMPLX-0K4 Lamb1"
          let ?X = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 <XXREAL-0R3 -XCMPLX-0K4 Lamb1 & Lamb2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r)"
          obtain s1 where
            [ty]:"s1 be Real-SequenceSEQ-1M1" and 
            A5: " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n =COMPLEX1R1 ?U(n)"
            using seq_1_sch_1 sorry
          have A6: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex g be ElementSUBSET-1M1-of REALNUMBERSK2 st g <XXREAL-0R3 -XCMPLX-0K4 n & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r)"
          proof(rule ballI)
            fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
            have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r.|"
              using complex1_th_46 sorry
            then have A7: "(-XCMPLX-0K4 n)-XCMPLX-0K6  |.COMPLEX1K10 r.| <=XXREAL-0R1 (-XCMPLX-0K4 n)-XCMPLX-0K6 0NUMBERSK6"
              using xreal_1_th_13 sorry
            obtain g where
              [ty]:"g be RealXREAL-0M1" and 
              A8: "g <XXREAL-0R3 (-XCMPLX-0K4 n)-XCMPLX-0K6  |.COMPLEX1K10 r.|"and A9: "g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
              using A1 sorry
            have 
              [ty]:"g be ElementSUBSET-1M1-of REALNUMBERSK2"
              using xreal_0_def_1 sorry
            show " ex g be ElementSUBSET-1M1-of REALNUMBERSK2 st g <XXREAL-0R3 -XCMPLX-0K4 n & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r)"
            proof(rule bexI[of _ "g"])
              have "0NUMBERSK6 <=XXREAL-0R1 n & -XCMPLX-0K4  |.COMPLEX1K10 r.| <=XXREAL-0R1 r"
                using absvalue_th_4 sorry
              then have "(-XCMPLX-0K4  |.COMPLEX1K10 r.|)-XCMPLX-0K6 n <=XXREAL-0R1 r -XCMPLX-0K6 0NUMBERSK6"
                using xreal_1_th_13 sorry
              then have "g <XXREAL-0R3 r"
                using A8 xxreal_0_th_2 sorry
              then have "g inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : g2 <XXREAL-0R3 r }"
                 sorry
              then have "g inTARSKIR2 left-open-halflineLIMFUNC1K1 r"
                using xxreal_1_th_229 sorry
              thus "g <XXREAL-0R3 -XCMPLX-0K4 n & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r)"
                using A8 A9 A7 xboole_0_def_4 xxreal_0_th_2 sorry
            qed "sorry"
          qed "sorry"
          obtain s2 where
            [ty]:"s2 be Real-SequenceSEQ-1M1" and 
            A10: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?X(n,s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
            using funct_2_sch_3 A6 sorry
          have " for n be NatNAT-1M1 holds s2 .FUNCT-1K1 n <=XXREAL-0R1 s1 .FUNCT-1K1 n"
          proof(rule ballI)
            fix n assume [ty]: "n be NatNAT-1M1"
            have "n inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            then have "s2 .FUNCT-1K1 n <XXREAL-0R3 -XCMPLX-0K4 n"
              using A10 sorry
            thus "s2 .FUNCT-1K1 n <=XXREAL-0R1 s1 .FUNCT-1K1 n"
              using A5 sorry
          qed "sorry"
          then have A11: "s2 be divergent-to-inftyLIMFUNC1V2"
            using A5 limfunc1_th_21 limfunc1_th_43 sorry
          have A12: "rngFUNCT-1K2 s2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          proof-
            have " for x be RealXREAL-0M1 holds x inHIDDENR3 rngFUNCT-1K2 s2 implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be RealXREAL-0M1"
              assume "x inHIDDENR3 rngFUNCT-1K2 s2"
              then have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st x =COMPLEX1R1 s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using funct_2_th_113 sorry
              then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r)"
                using A10 sorry
              thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
                using A4 xboole_0_def_4 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 s2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using membered_def_9 sorry
          qed
          then have A13: "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f2"
            using A2 A11 limfunc1_def_13 sorry
          have A14: "rngFUNCT-1K2 s2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
          proof-
            have " for x be RealXREAL-0M1 holds x inHIDDENR3 rngFUNCT-1K2 s2 implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be RealXREAL-0M1"
              assume "x inHIDDENR3 rngFUNCT-1K2 s2"
              then have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st x =COMPLEX1R1 s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using funct_2_th_113 sorry
              then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r)"
                using A10 sorry
              thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
                using xboole_0_def_4 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 s2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
              using membered_def_9 sorry
          qed
          have A15: " for n be NatNAT-1M1 holds f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 .FUNCT-1K1 n <=XXREAL-0R1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 .FUNCT-1K1 n"
          proof(rule ballI)
            fix n assume [ty]: "n be NatNAT-1M1"
            have A16: "n inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "f1 .FUNCT-1K1 (s2 .FUNCT-1K1 n) <=XXREAL-0R1 f2 .FUNCT-1K1 (s2 .FUNCT-1K1 n)"
              using A4 A10 A16 sorry
            then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 .FUNCT-1K1 n <=XXREAL-0R1 f2 .FUNCT-1K1 (s2 .FUNCT-1K1 n)"
              using A14 funct_2_th_108 A16 sorry
            thus "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 .FUNCT-1K1 n <=XXREAL-0R1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 .FUNCT-1K1 n"
              using A12 funct_2_th_108 A16 sorry
          qed "sorry"
          have A17: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 be convergentSEQ-2V5"
            using A2 A11 A12 sorry
          have A18: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 be convergentSEQ-2V5"
            using A1 A11 A14 sorry
          have "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f1"
            using A1 A11 A14 limfunc1_def_13 sorry
          thus "lim-in-inftyLIMFUNC1K6 f1 <=XXREAL-0R1 lim-in-inftyLIMFUNC1K6 f2"
            using A18 A17 A13 A15 seq_2_th_18 sorry
        qed
        have case2: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g) implies lim-in-inftyLIMFUNC1K6 f1 <=XXREAL-0R1 lim-in-inftyLIMFUNC1K6 f2"
        proof(rule impI)
          assume A19: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)"
          let ?U = "\<lambda>Lamb1. -XCMPLX-0K4 Lamb1"
          let ?X = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 <XXREAL-0R3 -XCMPLX-0K4 Lamb1 & Lamb2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r)"
          obtain s1 where
            [ty]:"s1 be Real-SequenceSEQ-1M1" and 
            A20: " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n =COMPLEX1R1 ?U(n)"
            using seq_1_sch_1 sorry
          have A21: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex g be ElementSUBSET-1M1-of REALNUMBERSK2 st g <XXREAL-0R3 -XCMPLX-0K4 n & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r)"
          proof(rule ballI)
            fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
            have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r.|"
              using complex1_th_46 sorry
            then have A22: "(-XCMPLX-0K4 n)-XCMPLX-0K6  |.COMPLEX1K10 r.| <=XXREAL-0R1 (-XCMPLX-0K4 n)-XCMPLX-0K6 0NUMBERSK6"
              using xreal_1_th_13 sorry
            obtain g where
              [ty]:"g be RealXREAL-0M1" and 
              A23: "g <XXREAL-0R3 (-XCMPLX-0K4 n)-XCMPLX-0K6  |.COMPLEX1K10 r.|"and A24: "g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A2 sorry
            have 
              [ty]:"g be ElementSUBSET-1M1-of REALNUMBERSK2"
              using xreal_0_def_1 sorry
            show " ex g be ElementSUBSET-1M1-of REALNUMBERSK2 st g <XXREAL-0R3 -XCMPLX-0K4 n & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r)"
            proof(rule bexI[of _ "g"])
              have "0NUMBERSK6 <=XXREAL-0R1 n & -XCMPLX-0K4  |.COMPLEX1K10 r.| <=XXREAL-0R1 r"
                using absvalue_th_4 sorry
              then have "(-XCMPLX-0K4  |.COMPLEX1K10 r.|)-XCMPLX-0K6 n <=XXREAL-0R1 r -XCMPLX-0K6 0NUMBERSK6"
                using xreal_1_th_13 sorry
              then have "g <XXREAL-0R3 r"
                using A23 xxreal_0_th_2 sorry
              then have "g inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : g2 <XXREAL-0R3 r }"
                 sorry
              then have "g inTARSKIR2 left-open-halflineLIMFUNC1K1 r"
                using xxreal_1_th_229 sorry
              thus "g <XXREAL-0R3 -XCMPLX-0K4 n & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r)"
                using A23 A24 A22 xboole_0_def_4 xxreal_0_th_2 sorry
            qed "sorry"
          qed "sorry"
          obtain s2 where
            [ty]:"s2 be Real-SequenceSEQ-1M1" and 
            A25: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?X(n,s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
            using funct_2_sch_3 A21 sorry
          have " for n be NatNAT-1M1 holds s2 .FUNCT-1K1 n <=XXREAL-0R1 s1 .FUNCT-1K1 n"
          proof(rule ballI)
            fix n assume [ty]: "n be NatNAT-1M1"
            have "n inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            then have "s2 .FUNCT-1K1 n <XXREAL-0R3 -XCMPLX-0K4 n"
              using A25 sorry
            thus "s2 .FUNCT-1K1 n <=XXREAL-0R1 s1 .FUNCT-1K1 n"
              using A20 sorry
          qed "sorry"
          then have A26: "s2 be divergent-to-inftyLIMFUNC1V2"
            using A20 limfunc1_th_21 limfunc1_th_43 sorry
          have A27: "rngFUNCT-1K2 s2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
          proof-
            have " for x be RealXREAL-0M1 holds x inHIDDENR3 rngFUNCT-1K2 s2 implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be RealXREAL-0M1"
              assume "x inHIDDENR3 rngFUNCT-1K2 s2"
              then have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st x =COMPLEX1R1 s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using funct_2_th_113 sorry
              then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r)"
                using A25 sorry
              thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
                using A19 xboole_0_def_4 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 s2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
              using membered_def_9 sorry
          qed
          then have A28: "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f1"
            using A1 A26 limfunc1_def_13 sorry
          have A29: "rngFUNCT-1K2 s2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          proof-
            have " for x be RealXREAL-0M1 holds x inHIDDENR3 rngFUNCT-1K2 s2 implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be RealXREAL-0M1"
              assume "x inHIDDENR3 rngFUNCT-1K2 s2"
              then have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st x =COMPLEX1R1 s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using funct_2_th_113 sorry
              then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r)"
                using A25 sorry
              thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
                using xboole_0_def_4 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 s2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using membered_def_9 sorry
          qed
          have A30: " for n be NatNAT-1M1 holds f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 .FUNCT-1K1 n <=XXREAL-0R1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 .FUNCT-1K1 n"
          proof(rule ballI)
            fix n assume [ty]: "n be NatNAT-1M1"
            have A31: "n inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "f1 .FUNCT-1K1 (s2 .FUNCT-1K1 n) <=XXREAL-0R1 f2 .FUNCT-1K1 (s2 .FUNCT-1K1 n)"
              using A19 A25 A31 sorry
            then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 .FUNCT-1K1 n <=XXREAL-0R1 f2 .FUNCT-1K1 (s2 .FUNCT-1K1 n)"
              using A27 funct_2_th_108 A31 sorry
            thus "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 .FUNCT-1K1 n <=XXREAL-0R1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 .FUNCT-1K1 n"
              using A29 funct_2_th_108 A31 sorry
          qed "sorry"
          have A32: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 be convergentSEQ-2V5"
            using A1 A26 A27 sorry
          have A33: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 be convergentSEQ-2V5"
            using A2 A26 A29 sorry
          have "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f2"
            using A2 A26 A29 limfunc1_def_13 sorry
          thus "lim-in-inftyLIMFUNC1K6 f1 <=XXREAL-0R1 lim-in-inftyLIMFUNC1K6 f2"
            using A33 A32 A28 A30 seq_2_th_18 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "lim-in-inftyLIMFUNC1K6 f1 <=XXREAL-0R1 lim-in-inftyLIMFUNC1K6 f2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_106:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f be divergent-in+infty-to+inftyLIMFUNC1V4 or f be divergent-in+infty-to-inftyLIMFUNC1V5) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f be divergent-in+infty-to+inftyLIMFUNC1V4 or f be divergent-in+infty-to-inftyLIMFUNC1V5) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 0NUMBERSK6"
  proof(rule ballI,rule impMI ,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f be divergent-in+infty-to+inftyLIMFUNC1V4 or f be divergent-in+infty-to-inftyLIMFUNC1V5"
      and A2: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6"
    have A3: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      using rfunct_1_def_2 sorry
    have A4: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain g where
        [ty]:"g be RealXREAL-0M1" and 
        A5: "r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and A6: "f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6"
        using A2 sorry
      show " ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      proof(rule bexI[of _ "g"])
        have " not f .FUNCT-1K1 g inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
          using A6 tarski_def_1 sorry
        then have " not g inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
          using funct_1_def_7 sorry
        thus "r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          using A3 A5 xboole_0_def_5 sorry
      qed "sorry"
    qed "sorry"
    have "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in+inftyLIMFUNC1V3 & (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 0NUMBERSK6)"
    proof-
      show "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in+inftyLIMFUNC1V3 & (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 0NUMBERSK6)"
      proof-
        have cases: "f be divergent-in+infty-to+inftyLIMFUNC1V4 or f be divergent-in+infty-to-inftyLIMFUNC1V5"
          using A1 sorry
        have case1: "f be divergent-in+infty-to+inftyLIMFUNC1V4 implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in+inftyLIMFUNC1V3 & (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 0NUMBERSK6)"
        proof(rule impI,rule conjMI)
          assume A7: "f be divergent-in+infty-to+inftyLIMFUNC1V4"
          have A8: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 0NUMBERSK6"
          proof(rule ballI,rule impMI ,rule impI)
            fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
            assume A9: "seq be divergent-to+inftyLIMFUNC1V1"
              and A10: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using A3 xboole_1_th_36 sorry
            then have "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using A10 sorry
            then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
              using A7 A9 sorry
            then have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5 & limSEQ-2K1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =COMPLEX1R1 0NUMBERSK6"
              using limfunc1_th_34 sorry
            thus "(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 0NUMBERSK6"
              using A10 rfunct_2_th_12 sorry
          qed "sorry"
          thus "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in+inftyLIMFUNC1V3"
            using A4 sorry
          thus "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 0NUMBERSK6"
            using A8 limfunc1_def_12 sorry
        qed
        have case2: "f be divergent-in+infty-to-inftyLIMFUNC1V5 implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in+inftyLIMFUNC1V3 & (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 0NUMBERSK6)"
        proof(rule impI,rule conjMI)
          assume A11: "f be divergent-in+infty-to-inftyLIMFUNC1V5"
          have A12: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 0NUMBERSK6"
          proof(rule ballI,rule impMI ,rule impI)
            fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
            assume A13: "seq be divergent-to+inftyLIMFUNC1V1"
              and A14: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using A3 xboole_1_th_36 sorry
            then have "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using A14 sorry
            then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
              using A11 A13 sorry
            then have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5 & limSEQ-2K1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =COMPLEX1R1 0NUMBERSK6"
              using limfunc1_th_34 sorry
            thus "(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 0NUMBERSK6"
              using A14 rfunct_2_th_12 sorry
          qed "sorry"
          thus "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in+inftyLIMFUNC1V3"
            using A4 sorry
          thus "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 0NUMBERSK6"
            using A12 limfunc1_def_12 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_107:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f be divergent-in-infty-to+inftyLIMFUNC1V7 or f be divergent-in-infty-to-inftyLIMFUNC1V8) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f be divergent-in-infty-to+inftyLIMFUNC1V7 or f be divergent-in-infty-to-inftyLIMFUNC1V8) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 0NUMBERSK6"
  proof(rule ballI,rule impMI ,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f be divergent-in-infty-to+inftyLIMFUNC1V7 or f be divergent-in-infty-to-inftyLIMFUNC1V8"
      and A2: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6"
    have A3: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      using rfunct_1_def_2 sorry
    have A4: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      obtain g where
        [ty]:"g be RealXREAL-0M1" and 
        A5: "g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and A6: "f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6"
        using A2 sorry
      show " ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      proof(rule bexI[of _ "g"])
        have " not f .FUNCT-1K1 g inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
          using A6 tarski_def_1 sorry
        then have " not g inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
          using funct_1_def_7 sorry
        thus "g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          using A3 A5 xboole_0_def_5 sorry
      qed "sorry"
    qed "sorry"
    have "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in-inftyLIMFUNC1V6 & (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 0NUMBERSK6)"
    proof-
      show "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in-inftyLIMFUNC1V6 & (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 0NUMBERSK6)"
      proof-
        have cases: "f be divergent-in-infty-to+inftyLIMFUNC1V7 or f be divergent-in-infty-to-inftyLIMFUNC1V8"
          using A1 sorry
        have case1: "f be divergent-in-infty-to+inftyLIMFUNC1V7 implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in-inftyLIMFUNC1V6 & (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 0NUMBERSK6)"
        proof(rule impI,rule conjMI)
          assume A7: "f be divergent-in-infty-to+inftyLIMFUNC1V7"
          have A8: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 0NUMBERSK6"
          proof(rule ballI,rule impMI ,rule impI)
            fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
            assume A9: "seq be divergent-to-inftyLIMFUNC1V2"
              and A10: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using A3 xboole_1_th_36 sorry
            then have "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using A10 sorry
            then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
              using A7 A9 sorry
            then have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5 & limSEQ-2K1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =COMPLEX1R1 0NUMBERSK6"
              using limfunc1_th_34 sorry
            thus "(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 0NUMBERSK6"
              using A10 rfunct_2_th_12 sorry
          qed "sorry"
          thus "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in-inftyLIMFUNC1V6"
            using A4 sorry
          thus "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 0NUMBERSK6"
            using A8 limfunc1_def_13 sorry
        qed
        have case2: "f be divergent-in-infty-to-inftyLIMFUNC1V8 implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in-inftyLIMFUNC1V6 & (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 0NUMBERSK6)"
        proof(rule impI,rule conjMI)
          assume A11: "f be divergent-in-infty-to-inftyLIMFUNC1V8"
          have A12: " for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 0NUMBERSK6"
          proof(rule ballI,rule impMI ,rule impI)
            fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
            assume A13: "seq be divergent-to-inftyLIMFUNC1V2"
              and A14: "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using A3 xboole_1_th_36 sorry
            then have "rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using A14 sorry
            then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
              using A11 A13 sorry
            then have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5 & limSEQ-2K1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =COMPLEX1R1 0NUMBERSK6"
              using limfunc1_th_34 sorry
            thus "(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 0NUMBERSK6"
              using A14 rfunct_2_th_12 sorry
          qed "sorry"
          thus "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in-inftyLIMFUNC1V6"
            using A4 sorry
          thus "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 0NUMBERSK6"
            using A12 limfunc1_def_13 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_108:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6)) & ( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies 0NUMBERSK6 <=XXREAL-0R1 f .FUNCT-1K1 g) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be divergent-in+infty-to+inftyLIMFUNC1V4"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6) implies (( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies 0NUMBERSK6 <=XXREAL-0R1 f .FUNCT-1K1 g) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be divergent-in+infty-to+inftyLIMFUNC1V4)"
  proof(rule ballI,rule impMI ,rule impI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 0NUMBERSK6"
      and A2: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6"
    assume Given: " ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies 0NUMBERSK6 <=XXREAL-0R1 f .FUNCT-1K1 g"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A3: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies 0NUMBERSK6 <=XXREAL-0R1 f .FUNCT-1K1 g"
       sorry
    have "( for r1 be RealXREAL-0M1 holds  ex g1 be RealXREAL-0M1 st r1 <XXREAL-0R3 g1 & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) & ( for s be Real-SequenceSEQ-1M1 holds s be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1)"
    proof(rule conjMI,rule ballI,rule impMI ,rule impI)
      show " for r1 be RealXREAL-0M1 holds  ex g1 be RealXREAL-0M1 st r1 <XXREAL-0R3 g1 & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      proof-
        have " for r1 be RealXREAL-0M1 holds  ex tVar85 be RealXREAL-0M1 st r1 <XXREAL-0R3 tVar85 & tVar85 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
        proof(rule ballI)
          fix r1 assume [ty]: "r1 be RealXREAL-0M1"
          obtain g1 where
            [ty]:"g1 be RealXREAL-0M1" and 
            A4: "r1 <XXREAL-0R3 g1"and A5: "g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and A6: "f .FUNCT-1K1 g1 <>HIDDENR2 0NUMBERSK6"
            using A2 sorry
          show " ex tVar85 be RealXREAL-0M1 st r1 <XXREAL-0R3 tVar85 & tVar85 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          proof(rule bexI[of _ "g1"],rule conjMI)
            show "r1 <XXREAL-0R3 g1"
              using A4 sorry
            have " not f .FUNCT-1K1 g1 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
              using A6 tarski_def_1 sorry
            then have " not g1 inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
              using funct_1_def_7 sorry
            then have "g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
              using A5 xboole_0_def_5 sorry
            thus "g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
              using rfunct_1_def_2 sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A7: "s be divergent-to+inftyLIMFUNC1V1"
        and A8: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A9: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies r <XXREAL-0R3 s .FUNCT-1K1 n"
        using A7 sorry
      have A10: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
        using rfunct_1_def_2 sorry
      then have A11: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using xboole_1_th_36 sorry
      then have A12: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A8 sorry
      then have A13: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A10 sorry
      have A14: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be non-zeroORDINAL1V9"
        using A8 A10 rfunct_2_th_11 xboole_1_th_1 sorry
      have " for n be NatNAT-1M1 holds 0NUMBERSK6 <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A15: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "r <XXREAL-0R3 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A9 nat_1_th_12 sorry
        then have "r <XXREAL-0R3 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n"
          using nat_1_def_3 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : r <XXREAL-0R3 g2 }"
           sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) & (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 right-open-halflineLIMFUNC1K4 r"
          using valued_0_th_28 xxreal_1_th_230 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r)"
          using A13 xboole_0_def_4 sorry
        then have A16: "0NUMBERSK6 <=XXREAL-0R1 f .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
          using A3 sorry
        have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <>HIDDENR2 0NUMBERSK6"
          using A14 seq_1_th_5 sorry
        thus "0NUMBERSK6 <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
          using A12 A10 A16 funct_2_th_108 xboole_1_th_1 A15 sorry
      qed "sorry"
      then have A17: " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 n implies 0NUMBERSK6 <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
         sorry
      have "s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be divergent-to+inftyLIMFUNC1V1"
        using A7 limfunc1_th_26 sorry
      then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 0NUMBERSK6"
        using A1 A13 limfunc1_def_12 sorry
      then have A18: "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be divergent-to+inftyLIMFUNC1V1"
        using A17 limfunc1_th_35 sorry
      have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =HIDDENR1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
        using A8 A11 valued_0_th_27 xboole_1_th_1 sorry
      also have "... = (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using seqm_3_th_18 sorry
      also have "... = (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A8 rfunct_2_th_12 sorry
      finally have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =HIDDENR1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      thus "(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A18 limfunc1_th_7 sorry
    qed "sorry"
    thus "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be divergent-in+infty-to+inftyLIMFUNC1V4"
      using limfunc1_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_109:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6)) & ( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f .FUNCT-1K1 g <=XXREAL-0R1 0NUMBERSK6) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be divergent-in+infty-to-inftyLIMFUNC1V5"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6) implies (( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f .FUNCT-1K1 g <=XXREAL-0R1 0NUMBERSK6) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be divergent-in+infty-to-inftyLIMFUNC1V5)"
  proof(rule ballI,rule impMI ,rule impI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 0NUMBERSK6"
      and A2: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6"
    assume Given: " ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f .FUNCT-1K1 g <=XXREAL-0R1 0NUMBERSK6"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A3: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f .FUNCT-1K1 g <=XXREAL-0R1 0NUMBERSK6"
       sorry
    have "( for r1 be RealXREAL-0M1 holds  ex g1 be RealXREAL-0M1 st r1 <XXREAL-0R3 g1 & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) & ( for s be Real-SequenceSEQ-1M1 holds s be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2)"
    proof(rule conjMI,rule ballI,rule impMI ,rule impI)
      show " for r1 be RealXREAL-0M1 holds  ex g1 be RealXREAL-0M1 st r1 <XXREAL-0R3 g1 & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      proof-
        have " for r1 be RealXREAL-0M1 holds  ex tVar86 be RealXREAL-0M1 st r1 <XXREAL-0R3 tVar86 & tVar86 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
        proof(rule ballI)
          fix r1 assume [ty]: "r1 be RealXREAL-0M1"
          obtain g1 where
            [ty]:"g1 be RealXREAL-0M1" and 
            A4: "r1 <XXREAL-0R3 g1"and A5: "g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and A6: "f .FUNCT-1K1 g1 <>HIDDENR2 0NUMBERSK6"
            using A2 sorry
          show " ex tVar86 be RealXREAL-0M1 st r1 <XXREAL-0R3 tVar86 & tVar86 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          proof(rule bexI[of _ "g1"],rule conjMI)
            show "r1 <XXREAL-0R3 g1"
              using A4 sorry
            have " not f .FUNCT-1K1 g1 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
              using A6 tarski_def_1 sorry
            then have " not g1 inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
              using funct_1_def_7 sorry
            then have "g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
              using A5 xboole_0_def_5 sorry
            thus "g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
              using rfunct_1_def_2 sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A7: "s be divergent-to+inftyLIMFUNC1V1"
        and A8: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A9: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies r <XXREAL-0R3 s .FUNCT-1K1 n"
        using A7 sorry
      have A10: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
        using rfunct_1_def_2 sorry
      then have A11: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using xboole_1_th_36 sorry
      then have A12: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A8 sorry
      then have A13: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A10 sorry
      have A14: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be non-zeroORDINAL1V9"
        using A8 A10 rfunct_2_th_11 xboole_1_th_1 sorry
      have " for n be NatNAT-1M1 holds f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A15: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "r <XXREAL-0R3 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A9 nat_1_th_12 sorry
        then have "r <XXREAL-0R3 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n"
          using nat_1_def_3 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : r <XXREAL-0R3 g2 }"
           sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) & (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 right-open-halflineLIMFUNC1K4 r"
          using valued_0_th_28 xxreal_1_th_230 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r)"
          using A13 xboole_0_def_4 sorry
        then have A16: "f .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n) <=XXREAL-0R1 0NUMBERSK6"
          using A3 sorry
        have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <>HIDDENR2 0NUMBERSK6"
          using A14 seq_1_th_5 sorry
        thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6"
          using A12 A10 A16 funct_2_th_108 xboole_1_th_1 A15 sorry
      qed "sorry"
      then have A17: " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 n implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6"
         sorry
      have "s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be divergent-to+inftyLIMFUNC1V1"
        using A7 limfunc1_th_26 sorry
      then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 0NUMBERSK6"
        using A1 A13 limfunc1_def_12 sorry
      then have A18: "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be divergent-to-inftyLIMFUNC1V2"
        using A17 limfunc1_th_36 sorry
      have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =HIDDENR1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
        using A8 A11 valued_0_th_27 xboole_1_th_1 sorry
      also have "... = (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using seqm_3_th_18 sorry
      also have "... = (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A8 rfunct_2_th_12 sorry
      finally have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =HIDDENR1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      thus "(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A18 limfunc1_th_7 sorry
    qed "sorry"
    thus "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be divergent-in+infty-to-inftyLIMFUNC1V5"
      using limfunc1_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_110:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6)) & ( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies 0NUMBERSK6 <=XXREAL-0R1 f .FUNCT-1K1 g) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be divergent-in-infty-to+inftyLIMFUNC1V7"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6) implies (( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies 0NUMBERSK6 <=XXREAL-0R1 f .FUNCT-1K1 g) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be divergent-in-infty-to+inftyLIMFUNC1V7)"
  proof(rule ballI,rule impMI ,rule impI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 0NUMBERSK6"
      and A2: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6"
    assume Given: " ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies 0NUMBERSK6 <=XXREAL-0R1 f .FUNCT-1K1 g"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A3: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies 0NUMBERSK6 <=XXREAL-0R1 f .FUNCT-1K1 g"
       sorry
    have "( for r1 be RealXREAL-0M1 holds  ex g1 be RealXREAL-0M1 st g1 <XXREAL-0R3 r1 & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) & ( for s be Real-SequenceSEQ-1M1 holds s be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1)"
    proof(rule conjMI,rule ballI,rule impMI ,rule impI)
      show " for r1 be RealXREAL-0M1 holds  ex g1 be RealXREAL-0M1 st g1 <XXREAL-0R3 r1 & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      proof-
        have " for r1 be RealXREAL-0M1 holds  ex tVar87 be RealXREAL-0M1 st tVar87 <XXREAL-0R3 r1 & tVar87 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
        proof(rule ballI)
          fix r1 assume [ty]: "r1 be RealXREAL-0M1"
          obtain g1 where
            [ty]:"g1 be RealXREAL-0M1" and 
            A4: "g1 <XXREAL-0R3 r1"and A5: "g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and A6: "f .FUNCT-1K1 g1 <>HIDDENR2 0NUMBERSK6"
            using A2 sorry
          show " ex tVar87 be RealXREAL-0M1 st tVar87 <XXREAL-0R3 r1 & tVar87 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          proof(rule bexI[of _ "g1"],rule conjMI)
            show "g1 <XXREAL-0R3 r1"
              using A4 sorry
            have " not f .FUNCT-1K1 g1 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
              using A6 tarski_def_1 sorry
            then have " not g1 inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
              using funct_1_def_7 sorry
            then have "g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
              using A5 xboole_0_def_5 sorry
            thus "g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
              using rfunct_1_def_2 sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A7: "s be divergent-to-inftyLIMFUNC1V2"
        and A8: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A9: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies s .FUNCT-1K1 n <XXREAL-0R3 r"
        using A7 sorry
      have A10: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
        using rfunct_1_def_2 sorry
      then have A11: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using xboole_1_th_36 sorry
      then have A12: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A8 sorry
      then have A13: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A10 sorry
      have A14: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be non-zeroORDINAL1V9"
        using A8 A10 rfunct_2_th_11 xboole_1_th_1 sorry
      have " for n be NatNAT-1M1 holds 0NUMBERSK6 <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A15: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) <XXREAL-0R3 r"
          using A9 nat_1_th_12 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n <XXREAL-0R3 r"
          using nat_1_def_3 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : g2 <XXREAL-0R3 r }"
           sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) & (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 left-open-halflineLIMFUNC1K1 r"
          using valued_0_th_28 xxreal_1_th_229 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r)"
          using A13 xboole_0_def_4 sorry
        then have A16: "0NUMBERSK6 <=XXREAL-0R1 f .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
          using A3 sorry
        have "0NUMBERSK6 <>HIDDENR2 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
          using A14 seq_1_th_5 sorry
        thus "0NUMBERSK6 <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
          using A12 A10 A16 funct_2_th_108 xboole_1_th_1 A15 sorry
      qed "sorry"
      then have A17: " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 n implies 0NUMBERSK6 <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
         sorry
      have "s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be divergent-to-inftyLIMFUNC1V2"
        using A7 limfunc1_th_27 sorry
      then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 0NUMBERSK6"
        using A1 A13 limfunc1_def_13 sorry
      then have A18: "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be divergent-to+inftyLIMFUNC1V1"
        using A17 limfunc1_th_35 sorry
      have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =HIDDENR1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
        using A8 A11 valued_0_th_27 xboole_1_th_1 sorry
      also have "... = (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using seqm_3_th_18 sorry
      also have "... = (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A8 rfunct_2_th_12 sorry
      finally have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =HIDDENR1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      thus "(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A18 limfunc1_th_7 sorry
    qed "sorry"
    thus "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be divergent-in-infty-to+inftyLIMFUNC1V7"
      using limfunc1_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_111:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6)) & ( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f .FUNCT-1K1 g <=XXREAL-0R1 0NUMBERSK6) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be divergent-in-infty-to-inftyLIMFUNC1V8"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6) implies (( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f .FUNCT-1K1 g <=XXREAL-0R1 0NUMBERSK6) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be divergent-in-infty-to-inftyLIMFUNC1V8)"
  proof(rule ballI,rule impMI ,rule impI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 0NUMBERSK6"
      and A2: " for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6"
    assume Given: " ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f .FUNCT-1K1 g <=XXREAL-0R1 0NUMBERSK6"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A3: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f .FUNCT-1K1 g <=XXREAL-0R1 0NUMBERSK6"
       sorry
    have "( for r1 be RealXREAL-0M1 holds  ex g1 be RealXREAL-0M1 st g1 <XXREAL-0R3 r1 & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) & ( for s be Real-SequenceSEQ-1M1 holds s be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2)"
    proof(rule conjMI,rule ballI,rule impMI ,rule impI)
      show " for r1 be RealXREAL-0M1 holds  ex g1 be RealXREAL-0M1 st g1 <XXREAL-0R3 r1 & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      proof-
        have " for r1 be RealXREAL-0M1 holds  ex tVar88 be RealXREAL-0M1 st tVar88 <XXREAL-0R3 r1 & tVar88 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
        proof(rule ballI)
          fix r1 assume [ty]: "r1 be RealXREAL-0M1"
          obtain g1 where
            [ty]:"g1 be RealXREAL-0M1" and 
            A4: "g1 <XXREAL-0R3 r1"and A5: "g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and A6: "f .FUNCT-1K1 g1 <>HIDDENR2 0NUMBERSK6"
            using A2 sorry
          show " ex tVar88 be RealXREAL-0M1 st tVar88 <XXREAL-0R3 r1 & tVar88 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          proof(rule bexI[of _ "g1"],rule conjMI)
            show "g1 <XXREAL-0R3 r1"
              using A4 sorry
            have " not f .FUNCT-1K1 g1 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
              using A6 tarski_def_1 sorry
            then have " not g1 inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
              using funct_1_def_7 sorry
            then have "g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
              using A5 xboole_0_def_5 sorry
            thus "g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
              using rfunct_1_def_2 sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A7: "s be divergent-to-inftyLIMFUNC1V2"
        and A8: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A9: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies s .FUNCT-1K1 n <XXREAL-0R3 r"
        using A7 sorry
      have A10: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
        using rfunct_1_def_2 sorry
      then have A11: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using xboole_1_th_36 sorry
      then have A12: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A8 sorry
      then have A13: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A10 sorry
      have A14: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be non-zeroORDINAL1V9"
        using A8 A10 rfunct_2_th_11 xboole_1_th_1 sorry
      have " for n be NatNAT-1M1 holds f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A15: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) <XXREAL-0R3 r"
          using A9 nat_1_th_12 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n <XXREAL-0R3 r"
          using nat_1_def_3 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : g2 <XXREAL-0R3 r }"
           sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) & (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 left-open-halflineLIMFUNC1K1 r"
          using valued_0_th_28 xxreal_1_th_229 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r)"
          using A13 xboole_0_def_4 sorry
        then have A16: "f .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n) <=XXREAL-0R1 0NUMBERSK6"
          using A3 sorry
        have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <>HIDDENR2 0NUMBERSK6"
          using A14 seq_1_th_5 sorry
        thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6"
          using A12 A10 A16 funct_2_th_108 xboole_1_th_1 A15 sorry
      qed "sorry"
      then have A17: " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 n implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6"
         sorry
      have "s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be divergent-to-inftyLIMFUNC1V2"
        using A7 limfunc1_th_27 sorry
      then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 0NUMBERSK6"
        using A1 A13 limfunc1_def_13 sorry
      then have A18: "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be divergent-to-inftyLIMFUNC1V2"
        using A17 limfunc1_th_36 sorry
      have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =HIDDENR1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
        using A8 A11 valued_0_th_27 xboole_1_th_1 sorry
      also have "... = (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using seqm_3_th_18 sorry
      also have "... = (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A8 rfunct_2_th_12 sorry
      finally have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =HIDDENR1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      thus "(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A18 limfunc1_th_7 sorry
    qed "sorry"
    thus "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be divergent-in-infty-to-inftyLIMFUNC1V8"
      using limfunc1_def_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_112:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 0NUMBERSK6) & ( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies 0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 g) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be divergent-in+infty-to+inftyLIMFUNC1V4"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 0NUMBERSK6 implies (( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies 0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 g) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be divergent-in+infty-to+inftyLIMFUNC1V4)"
  proof(rule ballI,rule impMI ,rule impI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f be convergent-in+inftyLIMFUNC1V3"
      and A2: "lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 0NUMBERSK6"
    assume Given: " ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies 0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 g"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A3: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies 0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 g"
       sorry
    have "( for r1 be RealXREAL-0M1 holds  ex g1 be RealXREAL-0M1 st r1 <XXREAL-0R3 g1 & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) & ( for s be Real-SequenceSEQ-1M1 holds s be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1)"
    proof(rule conjMI,rule ballI,rule impMI ,rule impI)
      show " for r1 be RealXREAL-0M1 holds  ex g1 be RealXREAL-0M1 st r1 <XXREAL-0R3 g1 & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      proof-
        have " for r1 be RealXREAL-0M1 holds  not ( for g1 be RealXREAL-0M1 holds  not ( not r1 <XXREAL-0R3 g1 & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))"
        proof(rule ballI)
          fix r1 assume [ty]: "r1 be RealXREAL-0M1"
          obtain g1 where
            [ty]:"g1 be RealXREAL-0M1" and 
            A4: "r1 <XXREAL-0R3 g1"and "g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using A1 sorry
          have " ex g2 be RealXREAL-0M1 st r1 <XXREAL-0R3 g2 & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          proof-
            show " ex g2 be RealXREAL-0M1 st r1 <XXREAL-0R3 g2 & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            proof-
              have cases: "g1 <=XXREAL-0R1 r or r <=XXREAL-0R1 g1"
                 sorry
              have case1: "g1 <=XXREAL-0R1 r implies ( ex g2 be RealXREAL-0M1 st r1 <XXREAL-0R3 g2 & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
              proof(rule impI)
                assume A5: "g1 <=XXREAL-0R1 r"
                obtain g2 where
                  [ty]:"g2 be RealXREAL-0M1" and 
                  A6: "r <XXREAL-0R3 g2"and A7: "g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
                  using A1 sorry
                show " ex g2 be RealXREAL-0M1 st r1 <XXREAL-0R3 g2 & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
                proof(rule bexI[of _ "g2"],rule conjMI)
                  have "g1 <XXREAL-0R3 g2"
                    using A5 A6 xxreal_0_th_2 sorry
                  thus "r1 <XXREAL-0R3 g2"
                    using A4 xxreal_0_th_2 sorry
                  have "g2 inHIDDENR3 {r2 where r2 be RealXREAL-0M1 : r <XXREAL-0R3 r2 }"
                    using A6 sorry
                  then have "g2 inHIDDENR3 right-open-halflineLIMFUNC1K4 r"
                    using xxreal_1_th_230 sorry
                  then have "g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r)"
                    using A7 xboole_0_def_4 sorry
                  then have "0NUMBERSK6 <>HIDDENR2 f .FUNCT-1K1 g2"
                    using A3 sorry
                  then have " not f .FUNCT-1K1 g2 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
                    using tarski_def_1 sorry
                  then have " not g2 inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
                    using funct_1_def_7 sorry
                  then have "g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
                    using A7 xboole_0_def_5 sorry
                  thus "g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
                    using rfunct_1_def_2 sorry
                qed "sorry"
              qed
              have case2: "r <=XXREAL-0R1 g1 implies ( ex g2 be RealXREAL-0M1 st r1 <XXREAL-0R3 g2 & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
              proof(rule impI)
                assume A8: "r <=XXREAL-0R1 g1"
                obtain g2 where
                  [ty]:"g2 be RealXREAL-0M1" and 
                  A9: "g1 <XXREAL-0R3 g2"and A10: "g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
                  using A1 sorry
                show " ex g2 be RealXREAL-0M1 st r1 <XXREAL-0R3 g2 & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
                proof(rule bexI[of _ "g2"],rule conjMI)
                  show "r1 <XXREAL-0R3 g2"
                    using A4 A9 xxreal_0_th_2 sorry
                  have "r <XXREAL-0R3 g2"
                    using A8 A9 xxreal_0_th_2 sorry
                  then have "g2 inHIDDENR3 {r2 where r2 be RealXREAL-0M1 : r <XXREAL-0R3 r2 }"
                     sorry
                  then have "g2 inHIDDENR3 right-open-halflineLIMFUNC1K4 r"
                    using xxreal_1_th_230 sorry
                  then have "g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r)"
                    using A10 xboole_0_def_4 sorry
                  then have "0NUMBERSK6 <>HIDDENR2 f .FUNCT-1K1 g2"
                    using A3 sorry
                  then have " not f .FUNCT-1K1 g2 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
                    using tarski_def_1 sorry
                  then have " not g2 inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
                    using funct_1_def_7 sorry
                  then have "g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
                    using A10 xboole_0_def_5 sorry
                  thus "g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
                    using rfunct_1_def_2 sorry
                qed "sorry"
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus " not ( for g1 be RealXREAL-0M1 holds  not ( not r1 <XXREAL-0R3 g1 & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A11: "s be divergent-to+inftyLIMFUNC1V1"
        and A12: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A13: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies r <XXREAL-0R3 s .FUNCT-1K1 n"
        using A11 sorry
      have A14: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
        using rfunct_1_def_2 sorry
      then have A15: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using xboole_1_th_36 sorry
      then have A16: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A12 sorry
      then have A17: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A14 sorry
      have " for n be NatNAT-1M1 holds 0NUMBERSK6 <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A18: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "r <XXREAL-0R3 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A13 nat_1_th_12 sorry
        then have "r <XXREAL-0R3 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n"
          using nat_1_def_3 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : r <XXREAL-0R3 g2 }"
           sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) & (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 right-open-halflineLIMFUNC1K4 r"
          using valued_0_th_28 xxreal_1_th_230 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r)"
          using A17 xboole_0_def_4 sorry
        then have "0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
          using A3 sorry
        thus "0NUMBERSK6 <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
          using A16 A14 funct_2_th_108 xboole_1_th_1 A18 sorry
      qed "sorry"
      then have A19: " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 n implies 0NUMBERSK6 <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
         sorry
      have "s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be divergent-to+inftyLIMFUNC1V1"
        using A11 limfunc1_th_26 sorry
      then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 0NUMBERSK6"
        using A1 A2 A17 limfunc1_def_12 sorry
      then have A20: "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be divergent-to+inftyLIMFUNC1V1"
        using A19 limfunc1_th_35 sorry
      have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =HIDDENR1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
        using A12 A15 valued_0_th_27 xboole_1_th_1 sorry
      also have "... = (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using seqm_3_th_18 sorry
      also have "... = (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A12 rfunct_2_th_12 sorry
      finally have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =HIDDENR1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      thus "(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A20 limfunc1_th_7 sorry
    qed "sorry"
    thus "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be divergent-in+infty-to+inftyLIMFUNC1V4"
      using limfunc1_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_113:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 0NUMBERSK6) & ( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f .FUNCT-1K1 g <XXREAL-0R3 0NUMBERSK6) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be divergent-in+infty-to-inftyLIMFUNC1V5"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 0NUMBERSK6 implies (( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f .FUNCT-1K1 g <XXREAL-0R3 0NUMBERSK6) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be divergent-in+infty-to-inftyLIMFUNC1V5)"
  proof(rule ballI,rule impMI ,rule impI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f be convergent-in+inftyLIMFUNC1V3"
      and A2: "lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 0NUMBERSK6"
    assume Given: " ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f .FUNCT-1K1 g <XXREAL-0R3 0NUMBERSK6"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A3: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f .FUNCT-1K1 g <XXREAL-0R3 0NUMBERSK6"
       sorry
    have "( for r1 be RealXREAL-0M1 holds  ex g1 be RealXREAL-0M1 st r1 <XXREAL-0R3 g1 & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) & ( for s be Real-SequenceSEQ-1M1 holds s be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2)"
    proof(rule conjMI,rule ballI,rule impMI ,rule impI)
      show " for r1 be RealXREAL-0M1 holds  ex g1 be RealXREAL-0M1 st r1 <XXREAL-0R3 g1 & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      proof-
        have " for r1 be RealXREAL-0M1 holds  not ( for g1 be RealXREAL-0M1 holds  not ( not r1 <XXREAL-0R3 g1 & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))"
        proof(rule ballI)
          fix r1 assume [ty]: "r1 be RealXREAL-0M1"
          obtain g1 where
            [ty]:"g1 be RealXREAL-0M1" and 
            A4: "r1 <XXREAL-0R3 g1"and "g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using A1 sorry
          have " ex g2 be RealXREAL-0M1 st r1 <XXREAL-0R3 g2 & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          proof-
            show " ex g2 be RealXREAL-0M1 st r1 <XXREAL-0R3 g2 & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            proof-
              have cases: "g1 <=XXREAL-0R1 r or r <=XXREAL-0R1 g1"
                 sorry
              have case1: "g1 <=XXREAL-0R1 r implies ( ex g2 be RealXREAL-0M1 st r1 <XXREAL-0R3 g2 & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
              proof(rule impI)
                assume A5: "g1 <=XXREAL-0R1 r"
                obtain g2 where
                  [ty]:"g2 be RealXREAL-0M1" and 
                  A6: "r <XXREAL-0R3 g2"and A7: "g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
                  using A1 sorry
                show " ex g2 be RealXREAL-0M1 st r1 <XXREAL-0R3 g2 & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
                proof(rule bexI[of _ "g2"],rule conjMI)
                  have "g1 <XXREAL-0R3 g2"
                    using A5 A6 xxreal_0_th_2 sorry
                  thus "r1 <XXREAL-0R3 g2"
                    using A4 xxreal_0_th_2 sorry
                  have "g2 inHIDDENR3 {r2 where r2 be RealXREAL-0M1 : r <XXREAL-0R3 r2 }"
                    using A6 sorry
                  then have "g2 inHIDDENR3 right-open-halflineLIMFUNC1K4 r"
                    using xxreal_1_th_230 sorry
                  then have "g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r)"
                    using A7 xboole_0_def_4 sorry
                  then have "0NUMBERSK6 <>HIDDENR2 f .FUNCT-1K1 g2"
                    using A3 sorry
                  then have " not f .FUNCT-1K1 g2 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
                    using tarski_def_1 sorry
                  then have " not g2 inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
                    using funct_1_def_7 sorry
                  then have "g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
                    using A7 xboole_0_def_5 sorry
                  thus "g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
                    using rfunct_1_def_2 sorry
                qed "sorry"
              qed
              have case2: "r <=XXREAL-0R1 g1 implies ( ex g2 be RealXREAL-0M1 st r1 <XXREAL-0R3 g2 & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
              proof(rule impI)
                assume A8: "r <=XXREAL-0R1 g1"
                obtain g2 where
                  [ty]:"g2 be RealXREAL-0M1" and 
                  A9: "g1 <XXREAL-0R3 g2"and A10: "g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
                  using A1 sorry
                show " ex g2 be RealXREAL-0M1 st r1 <XXREAL-0R3 g2 & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
                proof(rule bexI[of _ "g2"],rule conjMI)
                  show "r1 <XXREAL-0R3 g2"
                    using A4 A9 xxreal_0_th_2 sorry
                  have "r <XXREAL-0R3 g2"
                    using A8 A9 xxreal_0_th_2 sorry
                  then have "g2 inHIDDENR3 {r2 where r2 be RealXREAL-0M1 : r <XXREAL-0R3 r2 }"
                     sorry
                  then have "g2 inHIDDENR3 right-open-halflineLIMFUNC1K4 r"
                    using xxreal_1_th_230 sorry
                  then have "g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r)"
                    using A10 xboole_0_def_4 sorry
                  then have "0NUMBERSK6 <>HIDDENR2 f .FUNCT-1K1 g2"
                    using A3 sorry
                  then have " not f .FUNCT-1K1 g2 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
                    using tarski_def_1 sorry
                  then have " not g2 inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
                    using funct_1_def_7 sorry
                  then have "g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
                    using A10 xboole_0_def_5 sorry
                  thus "g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
                    using rfunct_1_def_2 sorry
                qed "sorry"
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus " not ( for g1 be RealXREAL-0M1 holds  not ( not r1 <XXREAL-0R3 g1 & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A11: "s be divergent-to+inftyLIMFUNC1V1"
        and A12: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A13: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies r <XXREAL-0R3 s .FUNCT-1K1 n"
        using A11 sorry
      have A14: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
        using rfunct_1_def_2 sorry
      then have A15: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using xboole_1_th_36 sorry
      then have A16: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A12 sorry
      then have A17: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A14 sorry
      have " for n be NatNAT-1M1 holds f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A18: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "r <XXREAL-0R3 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
          using A13 nat_1_th_12 sorry
        then have "r <XXREAL-0R3 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n"
          using nat_1_def_3 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : r <XXREAL-0R3 g2 }"
           sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) & (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 right-open-halflineLIMFUNC1K4 r"
          using valued_0_th_28 xxreal_1_th_230 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r)"
          using A17 xboole_0_def_4 sorry
        then have "f .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n) <XXREAL-0R3 0NUMBERSK6"
          using A3 sorry
        thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6"
          using A16 A14 funct_2_th_108 xboole_1_th_1 A18 sorry
      qed "sorry"
      then have A19: " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 n implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6"
         sorry
      have "s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be divergent-to+inftyLIMFUNC1V1"
        using A11 limfunc1_th_26 sorry
      then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 0NUMBERSK6"
        using A1 A2 A17 limfunc1_def_12 sorry
      then have A20: "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be divergent-to-inftyLIMFUNC1V2"
        using A19 limfunc1_th_36 sorry
      have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =HIDDENR1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
        using A12 A15 valued_0_th_27 xboole_1_th_1 sorry
      also have "... = (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using seqm_3_th_18 sorry
      also have "... = (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A12 rfunct_2_th_12 sorry
      finally have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =HIDDENR1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      thus "(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A20 limfunc1_th_7 sorry
    qed "sorry"
    thus "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be divergent-in+infty-to-inftyLIMFUNC1V5"
      using limfunc1_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_114:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 0NUMBERSK6) & ( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies 0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 g) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be divergent-in-infty-to+inftyLIMFUNC1V7"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 0NUMBERSK6 implies (( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies 0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 g) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be divergent-in-infty-to+inftyLIMFUNC1V7)"
  proof(rule ballI,rule impMI ,rule impI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f be convergent-in-inftyLIMFUNC1V6"
      and A2: "lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 0NUMBERSK6"
    assume Given: " ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies 0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 g"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A3: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies 0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 g"
       sorry
    have "( for r1 be RealXREAL-0M1 holds  ex g1 be RealXREAL-0M1 st g1 <XXREAL-0R3 r1 & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) & ( for s be Real-SequenceSEQ-1M1 holds s be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1)"
    proof(rule conjMI,rule ballI,rule impMI ,rule impI)
      show " for r1 be RealXREAL-0M1 holds  ex g1 be RealXREAL-0M1 st g1 <XXREAL-0R3 r1 & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      proof-
        have " for r1 be RealXREAL-0M1 holds  not ( for g1 be RealXREAL-0M1 holds  not ( not g1 <XXREAL-0R3 r1 & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))"
        proof(rule ballI)
          fix r1 assume [ty]: "r1 be RealXREAL-0M1"
          obtain g1 where
            [ty]:"g1 be RealXREAL-0M1" and 
            A4: "g1 <XXREAL-0R3 r1"and "g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using A1 sorry
          have " ex g2 be RealXREAL-0M1 st g2 <XXREAL-0R3 r1 & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          proof-
            show " ex g2 be RealXREAL-0M1 st g2 <XXREAL-0R3 r1 & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            proof-
              have cases: "g1 <=XXREAL-0R1 r or r <=XXREAL-0R1 g1"
                 sorry
              have case1: "g1 <=XXREAL-0R1 r implies ( ex g2 be RealXREAL-0M1 st g2 <XXREAL-0R3 r1 & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
              proof(rule impI)
                assume A5: "g1 <=XXREAL-0R1 r"
                obtain g2 where
                  [ty]:"g2 be RealXREAL-0M1" and 
                  A6: "g2 <XXREAL-0R3 g1"and A7: "g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
                  using A1 sorry
                show " ex g2 be RealXREAL-0M1 st g2 <XXREAL-0R3 r1 & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
                proof(rule bexI[of _ "g2"],rule conjMI)
                  show "g2 <XXREAL-0R3 r1"
                    using A4 A6 xxreal_0_th_2 sorry
                  have "g2 <XXREAL-0R3 r"
                    using A5 A6 xxreal_0_th_2 sorry
                  then have "g2 inHIDDENR3 {r2 where r2 be RealXREAL-0M1 : r2 <XXREAL-0R3 r }"
                     sorry
                  then have "g2 inHIDDENR3 left-open-halflineLIMFUNC1K1 r"
                    using xxreal_1_th_229 sorry
                  then have "g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r)"
                    using A7 xboole_0_def_4 sorry
                  then have "0NUMBERSK6 <>HIDDENR2 f .FUNCT-1K1 g2"
                    using A3 sorry
                  then have " not f .FUNCT-1K1 g2 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
                    using tarski_def_1 sorry
                  then have " not g2 inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
                    using funct_1_def_7 sorry
                  then have "g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
                    using A7 xboole_0_def_5 sorry
                  thus "g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
                    using rfunct_1_def_2 sorry
                qed "sorry"
              qed
              have case2: "r <=XXREAL-0R1 g1 implies ( ex g2 be RealXREAL-0M1 st g2 <XXREAL-0R3 r1 & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
              proof(rule impI)
                assume A8: "r <=XXREAL-0R1 g1"
                obtain g2 where
                  [ty]:"g2 be RealXREAL-0M1" and 
                  A9: "g2 <XXREAL-0R3 r"and A10: "g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
                  using A1 sorry
                show " ex g2 be RealXREAL-0M1 st g2 <XXREAL-0R3 r1 & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
                proof(rule bexI[of _ "g2"],rule conjMI)
                  have "g2 <XXREAL-0R3 g1"
                    using A8 A9 xxreal_0_th_2 sorry
                  thus "g2 <XXREAL-0R3 r1"
                    using A4 xxreal_0_th_2 sorry
                  have "g2 inHIDDENR3 {r2 where r2 be RealXREAL-0M1 : r2 <XXREAL-0R3 r }"
                    using A9 sorry
                  then have "g2 inHIDDENR3 left-open-halflineLIMFUNC1K1 r"
                    using xxreal_1_th_229 sorry
                  then have "g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r)"
                    using A10 xboole_0_def_4 sorry
                  then have "0NUMBERSK6 <>HIDDENR2 f .FUNCT-1K1 g2"
                    using A3 sorry
                  then have " not f .FUNCT-1K1 g2 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
                    using tarski_def_1 sorry
                  then have " not g2 inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
                    using funct_1_def_7 sorry
                  then have "g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
                    using A10 xboole_0_def_5 sorry
                  thus "g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
                    using rfunct_1_def_2 sorry
                qed "sorry"
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus " not ( for g1 be RealXREAL-0M1 holds  not ( not g1 <XXREAL-0R3 r1 & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A11: "s be divergent-to-inftyLIMFUNC1V2"
        and A12: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A13: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies s .FUNCT-1K1 n <XXREAL-0R3 r"
        using A11 sorry
      have A14: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
        using rfunct_1_def_2 sorry
      then have A15: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using xboole_1_th_36 sorry
      then have A16: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A12 sorry
      then have A17: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A14 sorry
      have " for n be NatNAT-1M1 holds 0NUMBERSK6 <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A18: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) <XXREAL-0R3 r"
          using A13 nat_1_th_12 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n <XXREAL-0R3 r"
          using nat_1_def_3 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : g2 <XXREAL-0R3 r }"
           sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) & (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 left-open-halflineLIMFUNC1K1 r"
          using valued_0_th_28 xxreal_1_th_229 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r)"
          using A17 xboole_0_def_4 sorry
        then have "0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
          using A3 sorry
        thus "0NUMBERSK6 <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
          using A16 A14 funct_2_th_108 xboole_1_th_1 A18 sorry
      qed "sorry"
      then have A19: " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 n implies 0NUMBERSK6 <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
         sorry
      have "s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be divergent-to-inftyLIMFUNC1V2"
        using A11 limfunc1_th_27 sorry
      then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 0NUMBERSK6"
        using A1 A2 A17 limfunc1_def_13 sorry
      then have A20: "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be divergent-to+inftyLIMFUNC1V1"
        using A19 limfunc1_th_35 sorry
      have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =HIDDENR1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
        using A12 A15 valued_0_th_27 xboole_1_th_1 sorry
      also have "... = (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using seqm_3_th_18 sorry
      also have "... = (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A12 rfunct_2_th_12 sorry
      finally have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =HIDDENR1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      thus "(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A20 limfunc1_th_7 sorry
    qed "sorry"
    thus "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be divergent-in-infty-to+inftyLIMFUNC1V7"
      using limfunc1_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc1_th_115:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 0NUMBERSK6) & ( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f .FUNCT-1K1 g <XXREAL-0R3 0NUMBERSK6) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be divergent-in-infty-to-inftyLIMFUNC1V8"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 0NUMBERSK6 implies (( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f .FUNCT-1K1 g <XXREAL-0R3 0NUMBERSK6) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be divergent-in-infty-to-inftyLIMFUNC1V8)"
  proof(rule ballI,rule impMI ,rule impI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f be convergent-in-inftyLIMFUNC1V6"
      and A2: "lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 0NUMBERSK6"
    assume Given: " ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f .FUNCT-1K1 g <XXREAL-0R3 0NUMBERSK6"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A3: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f .FUNCT-1K1 g <XXREAL-0R3 0NUMBERSK6"
       sorry
    have "( for r1 be RealXREAL-0M1 holds  ex g1 be RealXREAL-0M1 st g1 <XXREAL-0R3 r1 & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) & ( for s be Real-SequenceSEQ-1M1 holds s be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2)"
    proof(rule conjMI,rule ballI,rule impMI ,rule impI)
      show " for r1 be RealXREAL-0M1 holds  ex g1 be RealXREAL-0M1 st g1 <XXREAL-0R3 r1 & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      proof-
        have " for r1 be RealXREAL-0M1 holds  not ( for g1 be RealXREAL-0M1 holds  not ( not g1 <XXREAL-0R3 r1 & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))"
        proof(rule ballI)
          fix r1 assume [ty]: "r1 be RealXREAL-0M1"
          obtain g1 where
            [ty]:"g1 be RealXREAL-0M1" and 
            A4: "g1 <XXREAL-0R3 r1"and "g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using A1 sorry
          have " ex g2 be RealXREAL-0M1 st g2 <XXREAL-0R3 r1 & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          proof-
            show " ex g2 be RealXREAL-0M1 st g2 <XXREAL-0R3 r1 & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            proof-
              have cases: "g1 <=XXREAL-0R1 r or r <=XXREAL-0R1 g1"
                 sorry
              have case1: "g1 <=XXREAL-0R1 r implies ( ex g2 be RealXREAL-0M1 st g2 <XXREAL-0R3 r1 & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
              proof(rule impI)
                assume A5: "g1 <=XXREAL-0R1 r"
                obtain g2 where
                  [ty]:"g2 be RealXREAL-0M1" and 
                  A6: "g2 <XXREAL-0R3 g1"and A7: "g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
                  using A1 sorry
                show " ex g2 be RealXREAL-0M1 st g2 <XXREAL-0R3 r1 & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
                proof(rule bexI[of _ "g2"],rule conjMI)
                  show "g2 <XXREAL-0R3 r1"
                    using A4 A6 xxreal_0_th_2 sorry
                  have "g2 <XXREAL-0R3 r"
                    using A5 A6 xxreal_0_th_2 sorry
                  then have "g2 inHIDDENR3 {r2 where r2 be RealXREAL-0M1 : r2 <XXREAL-0R3 r }"
                     sorry
                  then have "g2 inHIDDENR3 left-open-halflineLIMFUNC1K1 r"
                    using xxreal_1_th_229 sorry
                  then have "g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r)"
                    using A7 xboole_0_def_4 sorry
                  then have "0NUMBERSK6 <>HIDDENR2 f .FUNCT-1K1 g2"
                    using A3 sorry
                  then have " not f .FUNCT-1K1 g2 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
                    using tarski_def_1 sorry
                  then have " not g2 inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
                    using funct_1_def_7 sorry
                  then have "g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
                    using A7 xboole_0_def_5 sorry
                  thus "g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
                    using rfunct_1_def_2 sorry
                qed "sorry"
              qed
              have case2: "r <=XXREAL-0R1 g1 implies ( ex g2 be RealXREAL-0M1 st g2 <XXREAL-0R3 r1 & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
              proof(rule impI)
                assume A8: "r <=XXREAL-0R1 g1"
                obtain g2 where
                  [ty]:"g2 be RealXREAL-0M1" and 
                  A9: "g2 <XXREAL-0R3 r"and A10: "g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
                  using A1 sorry
                show " ex g2 be RealXREAL-0M1 st g2 <XXREAL-0R3 r1 & g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
                proof(rule bexI[of _ "g2"],rule conjMI)
                  have "g2 <XXREAL-0R3 g1"
                    using A8 A9 xxreal_0_th_2 sorry
                  thus "g2 <XXREAL-0R3 r1"
                    using A4 xxreal_0_th_2 sorry
                  have "g2 inHIDDENR3 {r2 where r2 be RealXREAL-0M1 : r2 <XXREAL-0R3 r }"
                    using A9 sorry
                  then have "g2 inHIDDENR3 left-open-halflineLIMFUNC1K1 r"
                    using xxreal_1_th_229 sorry
                  then have "g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r)"
                    using A10 xboole_0_def_4 sorry
                  then have "0NUMBERSK6 <>HIDDENR2 f .FUNCT-1K1 g2"
                    using A3 sorry
                  then have " not f .FUNCT-1K1 g2 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
                    using tarski_def_1 sorry
                  then have " not g2 inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
                    using funct_1_def_7 sorry
                  then have "g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
                    using A10 xboole_0_def_5 sorry
                  thus "g2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
                    using rfunct_1_def_2 sorry
                qed "sorry"
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus " not ( for g1 be RealXREAL-0M1 holds  not ( not g1 <XXREAL-0R3 r1 & g1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A11: "s be divergent-to-inftyLIMFUNC1V2"
        and A12: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A13: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies s .FUNCT-1K1 n <XXREAL-0R3 r"
        using A11 sorry
      have A14: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
        using rfunct_1_def_2 sorry
      then have A15: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using xboole_1_th_36 sorry
      then have A16: "rngFUNCT-1K2 s c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A12 sorry
      then have A17: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A14 sorry
      have " for n be NatNAT-1M1 holds f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A18: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) <XXREAL-0R3 r"
          using A13 nat_1_th_12 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n <XXREAL-0R3 r"
          using nat_1_def_3 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : g2 <XXREAL-0R3 r }"
           sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) & (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 left-open-halflineLIMFUNC1K1 r"
          using valued_0_th_28 xxreal_1_th_229 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r)"
          using A17 xboole_0_def_4 sorry
        then have "f .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n) <XXREAL-0R3 0NUMBERSK6"
          using A3 sorry
        thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6"
          using A16 A14 funct_2_th_108 xboole_1_th_1 A18 sorry
      qed "sorry"
      then have A19: " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 n implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6"
         sorry
      have "s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be divergent-to-inftyLIMFUNC1V2"
        using A11 limfunc1_th_27 sorry
      then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 0NUMBERSK6"
        using A1 A2 A17 limfunc1_def_13 sorry
      then have A20: "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be divergent-to-inftyLIMFUNC1V2"
        using A19 limfunc1_th_36 sorry
      have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =HIDDENR1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
        using A12 A15 valued_0_th_27 xboole_1_th_1 sorry
      also have "... = (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using seqm_3_th_18 sorry
      also have "... = (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A12 rfunct_2_th_12 sorry
      finally have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =HIDDENR1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      thus "(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A20 limfunc1_th_7 sorry
    qed "sorry"
    thus "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be divergent-in-infty-to-inftyLIMFUNC1V8"
      using limfunc1_def_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
