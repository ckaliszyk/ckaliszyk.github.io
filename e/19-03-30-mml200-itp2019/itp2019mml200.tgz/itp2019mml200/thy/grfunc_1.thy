theory grfunc_1
  imports funct_1
begin
(*begin*)
reserve X, Y for "setHIDDENM2"
reserve p, x, x1, x2, y, y1, y2, z, z1, z2 for "objectHIDDENM1"
reserve f, g, h for "FunctionFUNCT-1M1"
mtheorem grfunc_1_th_1:
" for f be FunctionFUNCT-1M1 holds  for G be setHIDDENM2 holds G c=TARSKIR1 f implies G be FunctionFUNCT-1M1"
   sorry

mtheorem grfunc_1_th_2:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds f c=RELAT-1R2 g iff domRELAT-1K1 f c=TARSKIR1 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x)"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds (f c=RELAT-1R2 g implies domRELAT-1K1 f c=TARSKIR1 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x)) & (domRELAT-1K1 f c=TARSKIR1 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x) implies f c=RELAT-1R2 g)"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    show "f c=RELAT-1R2 g implies domRELAT-1K1 f c=TARSKIR1 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x)"
    proof(rule impI,rule conjMI,rule ballI,rule impI)
      assume A1: "f c=RELAT-1R2 g"
      thus "domRELAT-1K1 f c=TARSKIR1 domRELAT-1K1 g"
        using relat_1_th_11 sorry
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 domRELAT-1K1 f"
      then have "[TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 f"
        using funct_1_def_2 sorry
      thus "f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
        using A1 funct_1_th_1 sorry
    qed "sorry"
    assume A2: "domRELAT-1K1 f c=TARSKIR1 domRELAT-1K1 g"
      and A3: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 f implies [TARSKIK4 x,y ] inHIDDENR3 g"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A4: "[TARSKIK4 x,y ] inHIDDENR3 f"
      then have A5: "x inHIDDENR3 domRELAT-1K1 f"
        using funct_1_th_1 sorry
      have "y =HIDDENR1 f .FUNCT-1K1 x"
        using A4 funct_1_th_1 sorry
      then have "y =HIDDENR1 g .FUNCT-1K1 x"
        using A3 A5 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 g"
        using A2 A5 funct_1_def_2 sorry
    qed "sorry"
    thus "f c=RELAT-1R2 g"
      using relat_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem grfunc_1_th_3:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g & f c=RELAT-1R2 g implies f =FUNCT-1R1 g"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g & f c=RELAT-1R2 g implies f =FUNCT-1R1 g"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g"
      and A2: "f c=RELAT-1R2 g"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 f iff [TARSKIK4 x,y ] inHIDDENR3 g"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 f implies [TARSKIK4 x,y ] inHIDDENR3 g) & ([TARSKIK4 x,y ] inHIDDENR3 g implies [TARSKIK4 x,y ] inHIDDENR3 f)"
      proof(rule ballI,rule ballI,rule conjMI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        show "[TARSKIK4 x,y ] inHIDDENR3 f implies [TARSKIK4 x,y ] inHIDDENR3 g"
          using A2 sorry
        assume A3: "[TARSKIK4 x,y ] inHIDDENR3 g"
        then have "x inHIDDENR3 domRELAT-1K1 f"
          using A1 xtuple_0_def_12 sorry
        then have "[TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 f"
          using funct_1_th_1 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 f"
          using A2 A3 funct_1_def_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "f =FUNCT-1R1 g"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma grfunc_1_lm_1:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds (rngFUNCT-1K2 f /\\XBOOLE-0K3 rngFUNCT-1K2 h =XBOOLE-0R4 {}XBOOLE-0K1 & x inHIDDENR3 domRELAT-1K1 f) & y inHIDDENR3 domRELAT-1K1 h implies f .FUNCT-1K1 x <>HIDDENR2 h .FUNCT-1K1 y"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds rngFUNCT-1K2 f /\\XBOOLE-0K3 rngFUNCT-1K2 h =XBOOLE-0R4 {}XBOOLE-0K1 implies (x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 h implies  not f .FUNCT-1K1 x <>HIDDENR2 h .FUNCT-1K1 y)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix h assume [ty]: "h be FunctionFUNCT-1M1"
    assume A1: "rngFUNCT-1K2 f /\\XBOOLE-0K3 rngFUNCT-1K2 h =XBOOLE-0R4 {}XBOOLE-0K1"
    assume "x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 h"
    then have "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f & h .FUNCT-1K1 y inTARSKIR2 rngFUNCT-1K2 h"
      using funct_1_def_3 sorry
    thus " not f .FUNCT-1K1 x <>HIDDENR2 h .FUNCT-1K1 y"
      using A1 xboole_0_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem grfunc_1_th_4:
" for x be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds [TARSKIK4 x,z ] inHIDDENR3 g *FUNCT-1K3 f implies [TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 f & [TARSKIK4 f .FUNCT-1K1 x,z ] inHIDDENR3 g"
proof-
  have " for x be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds [TARSKIK4 x,z ] inHIDDENR3 g *FUNCT-1K3 f implies [TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 f & [TARSKIK4 f .FUNCT-1K1 x,z ] inHIDDENR3 g"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix z assume [ty]: "z be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume "[TARSKIK4 x,z ] inHIDDENR3 g *FUNCT-1K3 f"
    then have " ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 f & [TARSKIK4 y,z ] inHIDDENR3 g"
      using relat_1_def_8 sorry
    thus "[TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 f & [TARSKIK4 f .FUNCT-1K1 x,z ] inHIDDENR3 g"
      using funct_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem grfunc_1_th_5:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds {TARSKIK1 [TARSKIK4 x,y ] } be FunctionFUNCT-1M1"
   sorry

mlemma grfunc_1_lm_2:
" for x be objectHIDDENM1 holds  for x1 be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 {TARSKIK1 [TARSKIK4 x1,y1 ] } implies x =HIDDENR1 x1 & y =HIDDENR1 y1"
proof-
  have " for x be objectHIDDENM1 holds  for x1 be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 {TARSKIK1 [TARSKIK4 x1,y1 ] } implies x =HIDDENR1 x1 & y =HIDDENR1 y1"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix y1 assume [ty]: "y1 be objectHIDDENM1"
    assume "[TARSKIK4 x,y ] inHIDDENR3 {TARSKIK1 [TARSKIK4 x1,y1 ] }"
    then have "[TARSKIK4 x,y ] =HIDDENR1 [TARSKIK4 x1,y1 ]"
      using tarski_def_1 sorry
    thus "x =HIDDENR1 x1 & y =HIDDENR1 y1"
      using xtuple_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem grfunc_1_th_6:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds f =FUNCT-1R1 {TARSKIK1 [TARSKIK4 x,y ] } implies f .FUNCT-1K1 x =HIDDENR1 y"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds f =FUNCT-1R1 {TARSKIK1 [TARSKIK4 x,y ] } implies f .FUNCT-1K1 x =HIDDENR1 y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume "f =FUNCT-1R1 {TARSKIK1 [TARSKIK4 x,y ] }"
    then have "[TARSKIK4 x,y ] inHIDDENR3 f"
      using tarski_def_1 sorry
    thus "f .FUNCT-1K1 x =HIDDENR1 y"
      using funct_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem grfunc_1_th_7:
" for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 {TARSKIK1 x} implies f =FUNCT-1R1 {TARSKIK1 [TARSKIK4 x,f .FUNCT-1K1 x ] }"
proof-
  have " for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 {TARSKIK1 x} implies f =FUNCT-1R1 {TARSKIK1 [TARSKIK4 x,f .FUNCT-1K1 x ] }"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    obtain g where 
      [ty]:"g be FunctionFUNCT-1M1" and gDef:"g = {TARSKIK1 [TARSKIK4 x,f .FUNCT-1K1 x ] }"
       sorry
    assume A1: "domRELAT-1K1 f =XBOOLE-0R4 {TARSKIK1 x}"
    have " for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds [TARSKIK4 y,z ] inHIDDENR3 f iff [TARSKIK4 y,z ] inHIDDENR3 g"
    proof-
      have " for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds ([TARSKIK4 y,z ] inHIDDENR3 f implies [TARSKIK4 y,z ] inHIDDENR3 g) & ([TARSKIK4 y,z ] inHIDDENR3 g implies [TARSKIK4 y,z ] inHIDDENR3 f)"
      proof(rule ballI,rule ballI,rule conjMI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        fix z assume [ty]: "z be objectHIDDENM1"
        show "[TARSKIK4 y,z ] inHIDDENR3 f implies [TARSKIK4 y,z ] inHIDDENR3 g"
        proof(rule impI)
          assume A2: "[TARSKIK4 y,z ] inHIDDENR3 f"
          then have "y inHIDDENR3 {TARSKIK1 x}"
            using A1 xtuple_0_def_12 sorry
          then have A3: "y =HIDDENR1 x"
            using tarski_def_1 sorry
          have A4: "rngFUNCT-1K2 f =XBOOLE-0R4 {TARSKIK1 f .FUNCT-1K1 x }"
            using A1 funct_1_th_4 sorry
          have "z inHIDDENR3 rngFUNCT-1K2 f"
            using A2 xtuple_0_def_13 sorry
          then have "z =HIDDENR1 f .FUNCT-1K1 x"
            using A4 tarski_def_1 sorry
          thus "[TARSKIK4 y,z ] inHIDDENR3 g"
            using A3 tarski_def_1 sorry
        qed
        assume "[TARSKIK4 y,z ] inHIDDENR3 g"
        then have A5: "y =HIDDENR1 x & z =HIDDENR1 f .FUNCT-1K1 x"
          using grfunc_1_lm_2 sorry
        have "x inHIDDENR3 domRELAT-1K1 f"
          using A1 tarski_def_1 sorry
        thus "[TARSKIK4 y,z ] inHIDDENR3 f"
          using A5 funct_1_def_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "f =FUNCT-1R1 {TARSKIK1 [TARSKIK4 x,f .FUNCT-1K1 x ] }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem grfunc_1_th_8:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds {TARSKIK2 [TARSKIK4 x1,y1 ],[TARSKIK4 x2,y2 ] } be FunctionFUNCT-1M1 iff (x1 =HIDDENR1 x2 implies y1 =HIDDENR1 y2)"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds ({TARSKIK2 [TARSKIK4 x1,y1 ],[TARSKIK4 x2,y2 ] } be FunctionFUNCT-1M1 & x1 =HIDDENR1 x2 implies y1 =HIDDENR1 y2) & ((x1 =HIDDENR1 x2 implies y1 =HIDDENR1 y2) implies {TARSKIK2 [TARSKIK4 x1,y1 ],[TARSKIK4 x2,y2 ] } be FunctionFUNCT-1M1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix y1 assume [ty]: "y1 be objectHIDDENM1"
    fix y2 assume [ty]: "y2 be objectHIDDENM1"
    show "{TARSKIK2 [TARSKIK4 x1,y1 ],[TARSKIK4 x2,y2 ] } be FunctionFUNCT-1M1 & x1 =HIDDENR1 x2 implies y1 =HIDDENR1 y2"
    proof-
      have "{TARSKIK2 [TARSKIK4 x1,y1 ],[TARSKIK4 x2,y2 ] } be FunctionFUNCT-1M1 implies  not (x1 =HIDDENR1 x2 &  not y1 =HIDDENR1 y2)"
      proof(rule impI)
        have A1: "[TARSKIK4 x1,y1 ] inHIDDENR3 {TARSKIK2 [TARSKIK4 x1,y1 ],[TARSKIK4 x2,y2 ] } & [TARSKIK4 x2,y2 ] inHIDDENR3 {TARSKIK2 [TARSKIK4 x1,y1 ],[TARSKIK4 x2,y2 ] }"
          using tarski_def_2 sorry
        assume "{TARSKIK2 [TARSKIK4 x1,y1 ],[TARSKIK4 x2,y2 ] } be FunctionFUNCT-1M1"
        thus " not (x1 =HIDDENR1 x2 &  not y1 =HIDDENR1 y2)"
          using A1 funct_1_def_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A2: "x1 =HIDDENR1 x2 implies y1 =HIDDENR1 y2"
    have "( for p be objectHIDDENM1 holds p inHIDDENR3 {TARSKIK2 [TARSKIK4 x1,y1 ],[TARSKIK4 x2,y2 ] } implies ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st [TARSKIK4 x,y ] =HIDDENR1 p)) & ( for x be objectHIDDENM1 holds  for z1 be objectHIDDENM1 holds  for z2 be objectHIDDENM1 holds [TARSKIK4 x,z1 ] inHIDDENR3 {TARSKIK2 [TARSKIK4 x1,y1 ],[TARSKIK4 x2,y2 ] } & [TARSKIK4 x,z2 ] inHIDDENR3 {TARSKIK2 [TARSKIK4 x1,y1 ],[TARSKIK4 x2,y2 ] } implies z1 =HIDDENR1 z2)"
    proof(rule conjMI,rule ballI,rule ballI,rule ballI,rule impI)
      show " for p be objectHIDDENM1 holds p inHIDDENR3 {TARSKIK2 [TARSKIK4 x1,y1 ],[TARSKIK4 x2,y2 ] } implies ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st [TARSKIK4 x,y ] =HIDDENR1 p)"
      proof-
        have " for p be objectHIDDENM1 holds p inHIDDENR3 {TARSKIK2 [TARSKIK4 x1,y1 ],[TARSKIK4 x2,y2 ] } implies  not ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not [TARSKIK4 x,y ] =HIDDENR1 p)"
        proof(rule ballI,rule impI)
          fix p assume [ty]: "p be objectHIDDENM1"
          assume "p inHIDDENR3 {TARSKIK2 [TARSKIK4 x1,y1 ],[TARSKIK4 x2,y2 ] }"
          then have "p =HIDDENR1 [TARSKIK4 x1,y1 ] or p =HIDDENR1 [TARSKIK4 x2,y2 ]"
            using tarski_def_2 sorry
          thus " not ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not [TARSKIK4 x,y ] =HIDDENR1 p)"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      fix x assume [ty]: "x be objectHIDDENM1"
      fix z1 assume [ty]: "z1 be objectHIDDENM1"
      fix z2 assume [ty]: "z2 be objectHIDDENM1"
      have A3: "[TARSKIK4 x,z1 ] =HIDDENR1 [TARSKIK4 x1,y1 ] & [TARSKIK4 x,z2 ] =HIDDENR1 [TARSKIK4 x1,y1 ] or [TARSKIK4 x,z1 ] =HIDDENR1 [TARSKIK4 x2,y2 ] & [TARSKIK4 x,z2 ] =HIDDENR1 [TARSKIK4 x2,y2 ] implies z1 =HIDDENR1 y1 & z2 =HIDDENR1 y1 or z1 =HIDDENR1 y2 & z2 =HIDDENR1 y2"
        using xtuple_0_th_1 sorry
      have A4: "[TARSKIK4 x,z1 ] =HIDDENR1 [TARSKIK4 x1,y1 ] & [TARSKIK4 x,z2 ] =HIDDENR1 [TARSKIK4 x2,y2 ] or [TARSKIK4 x,z1 ] =HIDDENR1 [TARSKIK4 x2,y2 ] & [TARSKIK4 x,z2 ] =HIDDENR1 [TARSKIK4 x1,y1 ] implies z1 =HIDDENR1 z2"
      proof(rule impI)
        assume A5: "[TARSKIK4 x,z1 ] =HIDDENR1 [TARSKIK4 x1,y1 ] & [TARSKIK4 x,z2 ] =HIDDENR1 [TARSKIK4 x2,y2 ] or [TARSKIK4 x,z1 ] =HIDDENR1 [TARSKIK4 x2,y2 ] & [TARSKIK4 x,z2 ] =HIDDENR1 [TARSKIK4 x1,y1 ]"
        then have "x =HIDDENR1 x1 & x =HIDDENR1 x2"
          using xtuple_0_th_1 sorry
        thus "z1 =HIDDENR1 z2"
          using A2 A5 xtuple_0_th_1 sorry
      qed
      assume "[TARSKIK4 x,z1 ] inHIDDENR3 {TARSKIK2 [TARSKIK4 x1,y1 ],[TARSKIK4 x2,y2 ] } & [TARSKIK4 x,z2 ] inHIDDENR3 {TARSKIK2 [TARSKIK4 x1,y1 ],[TARSKIK4 x2,y2 ] }"
      thus "z1 =HIDDENR1 z2"
        using A3 A4 tarski_def_2 sorry
    qed "sorry"
    thus "{TARSKIK2 [TARSKIK4 x1,y1 ],[TARSKIK4 x2,y2 ] } be FunctionFUNCT-1M1"
      using funct_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem grfunc_1_th_9:
" for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 iff ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x1,y ] inHIDDENR3 f & [TARSKIK4 x2,y ] inHIDDENR3 f implies x1 =HIDDENR1 x2)"
proof-
  have " for f be FunctionFUNCT-1M1 holds (f be one-to-oneFUNCT-1V2 implies ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x1,y ] inHIDDENR3 f & [TARSKIK4 x2,y ] inHIDDENR3 f implies x1 =HIDDENR1 x2)) & (( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x1,y ] inHIDDENR3 f & [TARSKIK4 x2,y ] inHIDDENR3 f implies x1 =HIDDENR1 x2) implies f be one-to-oneFUNCT-1V2)"
  proof(rule ballI,rule conjMI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    show "f be one-to-oneFUNCT-1V2 implies ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x1,y ] inHIDDENR3 f & [TARSKIK4 x2,y ] inHIDDENR3 f implies x1 =HIDDENR1 x2)"
    proof(rule impI,rule ballI,rule ballI,rule ballI,rule impI)
      assume A1: "f be one-to-oneFUNCT-1V2"
      fix x1 assume [ty]: "x1 be objectHIDDENM1"
      fix x2 assume [ty]: "x2 be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A2: "[TARSKIK4 x1,y ] inHIDDENR3 f & [TARSKIK4 x2,y ] inHIDDENR3 f"
      then have A3: "f .FUNCT-1K1 x1 =HIDDENR1 y & f .FUNCT-1K1 x2 =HIDDENR1 y"
        using funct_1_th_1 sorry
      have "x1 inHIDDENR3 domRELAT-1K1 f & x2 inHIDDENR3 domRELAT-1K1 f"
        using A2 funct_1_th_1 sorry
      thus "x1 =HIDDENR1 x2"
        using A1 A3 sorry
    qed "sorry"
    assume A4: " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x1,y ] inHIDDENR3 f & [TARSKIK4 x2,y ] inHIDDENR3 f implies x1 =HIDDENR1 x2"
    have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds (x1 inHIDDENR3 domRELAT-1K1 f & x2 inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2 implies x1 =HIDDENR1 x2"
    proof(rule ballI,rule ballI,rule impI)
      fix x1 assume [ty]: "x1 be objectHIDDENM1"
      fix x2 assume [ty]: "x2 be objectHIDDENM1"
      assume "(x1 inHIDDENR3 domRELAT-1K1 f & x2 inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2"
      then have "[TARSKIK4 x1,f .FUNCT-1K1 x1 ] inHIDDENR3 f & [TARSKIK4 x2,f .FUNCT-1K1 x1 ] inHIDDENR3 f"
        using funct_1_th_1 sorry
      thus "x1 =HIDDENR1 x2"
        using A4 sorry
    qed "sorry"
    thus "f be one-to-oneFUNCT-1V2"
      using funct_1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem grfunc_1_th_10:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds g c=RELAT-1R2 f & f be one-to-oneFUNCT-1V2 implies g be one-to-oneFUNCT-1V2"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds g c=RELAT-1R2 f & f be one-to-oneFUNCT-1V2 implies g be one-to-oneFUNCT-1V2"
  proof(rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume "g c=RELAT-1R2 f & f be one-to-oneFUNCT-1V2"
    then have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x1,y ] inHIDDENR3 g & [TARSKIK4 x2,y ] inHIDDENR3 g implies x1 =HIDDENR1 x2"
      using grfunc_1_th_9 sorry
    thus "g be one-to-oneFUNCT-1V2"
      using grfunc_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem grfunc_1_cl_1:
  mlet "f be FunctionFUNCT-1M1", "X be setHIDDENM2"
"cluster f /\\XBOOLE-0K3 X as-term-is Function-likeFUNCT-1V1"
proof
(*coherence*)
  show "f /\\XBOOLE-0K3 X be Function-likeFUNCT-1V1"
    using grfunc_1_th_1 xboole_1_th_17 sorry
qed "sorry"

mtheorem grfunc_1_th_11:
" for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 (f /\\XBOOLE-0K3 g) implies (f /\\XBOOLE-0K3 g).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
proof-
  have " for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 (f /\\XBOOLE-0K3 g) implies (f /\\XBOOLE-0K3 g).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    let ?y = "(f /\\XBOOLE-0K3 g).FUNCT-1K1 x"
    assume "x inHIDDENR3 domRELAT-1K1 (f /\\XBOOLE-0K3 g)"
    then have "[TARSKIK4 x,?y ] inHIDDENR3 f /\\XBOOLE-0K3 g"
      using funct_1_def_2 sorry
    then have "[TARSKIK4 x,?y ] inHIDDENR3 f"
      using xboole_0_def_4 sorry
    thus "(f /\\XBOOLE-0K3 g).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
      using funct_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem grfunc_1_th_12:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies f /\\XBOOLE-0K3 g be one-to-oneFUNCT-1V2"
  using grfunc_1_th_10 xboole_1_th_17 sorry

mtheorem grfunc_1_th_13:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds domRELAT-1K1 f missesXBOOLE-0R1 domRELAT-1K1 g implies f \\/XBOOLE-0K2 g be FunctionFUNCT-1M1"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 f missesXBOOLE-0R1 domRELAT-1K1 g &  not f \\/XBOOLE-0K2 g be FunctionFUNCT-1M1)"
  proof(rule ballI,rule ballI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    have "domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g =XBOOLE-0R4 {}XBOOLE-0K1 implies f \\/XBOOLE-0K2 g be FunctionFUNCT-1M1"
    proof(rule impI)
      assume A1: "domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g =XBOOLE-0R4 {}XBOOLE-0K1"
      have "( for p be objectHIDDENM1 holds p inHIDDENR3 f \\/XBOOLE-0K2 g implies ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st [TARSKIK4 x,y ] =HIDDENR1 p)) & ( for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds [TARSKIK4 x,y1 ] inHIDDENR3 f \\/XBOOLE-0K2 g implies ([TARSKIK4 x,y2 ] inHIDDENR3 f \\/XBOOLE-0K2 g implies y1 =HIDDENR1 y2))"
      proof(rule conjMI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
        show " for p be objectHIDDENM1 holds p inHIDDENR3 f \\/XBOOLE-0K2 g implies ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st [TARSKIK4 x,y ] =HIDDENR1 p)"
          using relat_1_def_1 sorry
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y1 assume [ty]: "y1 be objectHIDDENM1"
        fix y2 assume [ty]: "y2 be objectHIDDENM1"
        assume "[TARSKIK4 x,y1 ] inHIDDENR3 f \\/XBOOLE-0K2 g"
        then have A2: "[TARSKIK4 x,y1 ] inHIDDENR3 f or [TARSKIK4 x,y1 ] inHIDDENR3 g"
          using xboole_0_def_3 sorry
        assume "[TARSKIK4 x,y2 ] inHIDDENR3 f \\/XBOOLE-0K2 g"
        then have A3: "[TARSKIK4 x,y2 ] inHIDDENR3 f or [TARSKIK4 x,y2 ] inHIDDENR3 g"
          using xboole_0_def_3 sorry
        have " not (x inHIDDENR3 domRELAT-1K1 f & x inHIDDENR3 domRELAT-1K1 g)"
          using A1 xboole_0_def_4 sorry
        thus "y1 =HIDDENR1 y2"
          using A2 A3 funct_1_def_1 xtuple_0_def_12 sorry
      qed "sorry"
      thus "f \\/XBOOLE-0K2 g be FunctionFUNCT-1M1"
        using funct_1_def_1 sorry
    qed
    thus " not (domRELAT-1K1 f missesXBOOLE-0R1 domRELAT-1K1 g &  not f \\/XBOOLE-0K2 g be FunctionFUNCT-1M1)"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem grfunc_1_th_14:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds f c=RELAT-1R2 h & g c=RELAT-1R2 h implies f \\/XBOOLE-0K2 g be FunctionFUNCT-1M1"
  using grfunc_1_th_1 xboole_1_th_8 sorry

mlemma grfunc_1_lm_3:
" for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds h =RELAT-1R1 f \\/XBOOLE-0K2 g implies (x inHIDDENR3 domRELAT-1K1 h iff x inHIDDENR3 domRELAT-1K1 f or x inHIDDENR3 domRELAT-1K1 g)"
proof-
  have " for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds h =RELAT-1R1 f \\/XBOOLE-0K2 g implies (x inHIDDENR3 domRELAT-1K1 h implies x inHIDDENR3 domRELAT-1K1 f or x inHIDDENR3 domRELAT-1K1 g) & (x inHIDDENR3 domRELAT-1K1 f or x inHIDDENR3 domRELAT-1K1 g implies x inHIDDENR3 domRELAT-1K1 h)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix h assume [ty]: "h be FunctionFUNCT-1M1"
    assume A1: "h =RELAT-1R1 f \\/XBOOLE-0K2 g"
    show "x inHIDDENR3 domRELAT-1K1 h implies x inHIDDENR3 domRELAT-1K1 f or x inHIDDENR3 domRELAT-1K1 g"
    proof-
      have "x inHIDDENR3 domRELAT-1K1 h implies  not ( not x inHIDDENR3 domRELAT-1K1 f &  not x inHIDDENR3 domRELAT-1K1 g)"
      proof(rule impI)
        assume "x inHIDDENR3 domRELAT-1K1 h"
        then have "[TARSKIK4 x,h .FUNCT-1K1 x ] inHIDDENR3 h"
          using funct_1_def_2 sorry
        then have "[TARSKIK4 x,h .FUNCT-1K1 x ] inHIDDENR3 f or [TARSKIK4 x,h .FUNCT-1K1 x ] inHIDDENR3 g"
          using A1 xboole_0_def_3 sorry
        thus " not ( not x inHIDDENR3 domRELAT-1K1 f &  not x inHIDDENR3 domRELAT-1K1 g)"
          using xtuple_0_def_12 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume "x inHIDDENR3 domRELAT-1K1 f or x inHIDDENR3 domRELAT-1K1 g"
    then have "[TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 f or [TARSKIK4 x,g .FUNCT-1K1 x ] inHIDDENR3 g"
      using funct_1_def_2 sorry
    then have "[TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 h or [TARSKIK4 x,g .FUNCT-1K1 x ] inHIDDENR3 h"
      using A1 xboole_0_def_3 sorry
    thus "x inHIDDENR3 domRELAT-1K1 h"
      using xtuple_0_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem grfunc_1_th_15:
" for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 g & h =RELAT-1R1 f \\/XBOOLE-0K2 g implies h .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
proof-
  have " for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 g implies  not (h =RELAT-1R1 f \\/XBOOLE-0K2 g &  not h .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix h assume [ty]: "h be FunctionFUNCT-1M1"
    assume "x inHIDDENR3 domRELAT-1K1 g"
    then have "[TARSKIK4 x,g .FUNCT-1K1 x ] inHIDDENR3 g"
      using funct_1_def_2 sorry
    then have "h =RELAT-1R1 f \\/XBOOLE-0K2 g implies [TARSKIK4 x,g .FUNCT-1K1 x ] inHIDDENR3 h"
      using xboole_0_def_3 sorry
    thus " not (h =RELAT-1R1 f \\/XBOOLE-0K2 g &  not h .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x)"
      using funct_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem grfunc_1_th_16:
" for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 h & h =RELAT-1R1 f \\/XBOOLE-0K2 g implies h .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x or h .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
proof-
  have " for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 h implies  not ((h =RELAT-1R1 f \\/XBOOLE-0K2 g &  not h .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x) &  not h .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix h assume [ty]: "h be FunctionFUNCT-1M1"
    assume "x inHIDDENR3 domRELAT-1K1 h"
    then have "[TARSKIK4 x,h .FUNCT-1K1 x ] inHIDDENR3 h"
      using funct_1_def_2 sorry
    then have "h =RELAT-1R1 f \\/XBOOLE-0K2 g implies [TARSKIK4 x,h .FUNCT-1K1 x ] inHIDDENR3 f or [TARSKIK4 x,h .FUNCT-1K1 x ] inHIDDENR3 g"
      using xboole_0_def_3 sorry
    thus " not ((h =RELAT-1R1 f \\/XBOOLE-0K2 g &  not h .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x) &  not h .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x)"
      using funct_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem grfunc_1_th_17:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds ((f be one-to-oneFUNCT-1V2 & g be one-to-oneFUNCT-1V2) & h =RELAT-1R1 f \\/XBOOLE-0K2 g) & rngFUNCT-1K2 f missesXBOOLE-0R1 rngFUNCT-1K2 g implies h be one-to-oneFUNCT-1V2"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds  not ((((f be one-to-oneFUNCT-1V2 & g be one-to-oneFUNCT-1V2) & h =RELAT-1R1 f \\/XBOOLE-0K2 g) & rngFUNCT-1K2 f missesXBOOLE-0R1 rngFUNCT-1K2 g) &  not h be one-to-oneFUNCT-1V2)"
  proof(rule ballI,rule ballI,rule ballI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix h assume [ty]: "h be FunctionFUNCT-1M1"
    have "(f be one-to-oneFUNCT-1V2 & g be one-to-oneFUNCT-1V2) & (h =RELAT-1R1 f \\/XBOOLE-0K2 g & rngFUNCT-1K2 f /\\XBOOLE-0K3 rngFUNCT-1K2 g =XBOOLE-0R4 {}XBOOLE-0K1) implies h be one-to-oneFUNCT-1V2"
    proof(rule impMI ,rule impMI ,rule impI)
      assume A1: "f be one-to-oneFUNCT-1V2 & g be one-to-oneFUNCT-1V2"
        and A2: "h =RELAT-1R1 f \\/XBOOLE-0K2 g"
        and A3: "rngFUNCT-1K2 f /\\XBOOLE-0K3 rngFUNCT-1K2 g =XBOOLE-0R4 {}XBOOLE-0K1"
      have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds (x1 inHIDDENR3 domRELAT-1K1 h & x2 inHIDDENR3 domRELAT-1K1 h) & h .FUNCT-1K1 x1 =XBOOLE-0R4 h .FUNCT-1K1 x2 implies x1 =HIDDENR1 x2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix x1 assume [ty]: "x1 be objectHIDDENM1"
        fix x2 assume [ty]: "x2 be objectHIDDENM1"
        assume A4: "x1 inHIDDENR3 domRELAT-1K1 h & x2 inHIDDENR3 domRELAT-1K1 h"
          and A5: "h .FUNCT-1K1 x1 =XBOOLE-0R4 h .FUNCT-1K1 x2"
        have A6: "x1 inHIDDENR3 domRELAT-1K1 f & x2 inHIDDENR3 domRELAT-1K1 g or x1 inHIDDENR3 domRELAT-1K1 g & x2 inHIDDENR3 domRELAT-1K1 f implies x1 =HIDDENR1 x2"
        proof(rule impI)
          assume "x1 inHIDDENR3 domRELAT-1K1 f & x2 inHIDDENR3 domRELAT-1K1 g or x1 inHIDDENR3 domRELAT-1K1 g & x2 inHIDDENR3 domRELAT-1K1 f"
          then have "(h .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x1 & h .FUNCT-1K1 x2 =XBOOLE-0R4 g .FUNCT-1K1 x2) & f .FUNCT-1K1 x1 <>HIDDENR2 g .FUNCT-1K1 x2 or (h .FUNCT-1K1 x1 =XBOOLE-0R4 g .FUNCT-1K1 x1 & h .FUNCT-1K1 x2 =XBOOLE-0R4 f .FUNCT-1K1 x2) & f .FUNCT-1K1 x2 <>HIDDENR2 g .FUNCT-1K1 x1"
            using A2 A3 grfunc_1_lm_1 grfunc_1_th_15 sorry
          thus "x1 =HIDDENR1 x2"
            using A5 sorry
        qed
        have A7: "x1 inHIDDENR3 domRELAT-1K1 g & x2 inHIDDENR3 domRELAT-1K1 g implies h .FUNCT-1K1 x1 =XBOOLE-0R4 g .FUNCT-1K1 x1 & h .FUNCT-1K1 x2 =XBOOLE-0R4 g .FUNCT-1K1 x2"
          using A2 grfunc_1_th_15 sorry
        have "x1 inHIDDENR3 domRELAT-1K1 f & x2 inHIDDENR3 domRELAT-1K1 f implies h .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x1 & h .FUNCT-1K1 x2 =XBOOLE-0R4 f .FUNCT-1K1 x2"
          using A2 grfunc_1_th_15 sorry
        then have "x1 inHIDDENR3 domRELAT-1K1 f & x2 inHIDDENR3 domRELAT-1K1 f or x1 inHIDDENR3 domRELAT-1K1 g & x2 inHIDDENR3 domRELAT-1K1 g implies x1 =HIDDENR1 x2"
          using A1 A5 A7 sorry
        thus "x1 =HIDDENR1 x2"
          using A2 A4 A6 grfunc_1_lm_3 sorry
      qed "sorry"
      thus "h be one-to-oneFUNCT-1V2"
         sorry
    qed
    thus " not ((((f be one-to-oneFUNCT-1V2 & g be one-to-oneFUNCT-1V2) & h =RELAT-1R1 f \\/XBOOLE-0K2 g) & rngFUNCT-1K2 f missesXBOOLE-0R1 rngFUNCT-1K2 g) &  not h be one-to-oneFUNCT-1V2)"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CT 2*)
mtheorem grfunc_1_th_20:
" for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 y,x ] inHIDDENR3 f \<inverse>FUNCT-1K4 iff [TARSKIK4 x,y ] inHIDDENR3 f)"
proof-
  have " for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 y,x ] inHIDDENR3 f \<inverse>FUNCT-1K4 &  not [TARSKIK4 x,y ] inHIDDENR3 f) &  not ([TARSKIK4 x,y ] inHIDDENR3 f &  not [TARSKIK4 y,x ] inHIDDENR3 f \<inverse>FUNCT-1K4))"
  proof(rule ballI,rule impI,rule ballI,rule ballI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "f be one-to-oneFUNCT-1V2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    have "domRELAT-1K1 (f \<inverse>FUNCT-1K4) =XBOOLE-0R4 rngFUNCT-1K2 f"
      using A1 funct_1_th_33 sorry
    then have "y inHIDDENR3 domRELAT-1K1 (f \<inverse>FUNCT-1K4) & x =HIDDENR1 f \<inverse>FUNCT-1K4 .FUNCT-1K1 y iff x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x"
      using A1 funct_1_th_32 sorry
    thus " not ([TARSKIK4 y,x ] inHIDDENR3 f \<inverse>FUNCT-1K4 &  not [TARSKIK4 x,y ] inHIDDENR3 f) &  not ([TARSKIK4 x,y ] inHIDDENR3 f &  not [TARSKIK4 y,x ] inHIDDENR3 f \<inverse>FUNCT-1K4)"
      using funct_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem grfunc_1_th_21:
" for f be FunctionFUNCT-1M1 holds f =XBOOLE-0R4 {}XBOOLE-0K1 implies f \<inverse>FUNCT-1K4 =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for f be FunctionFUNCT-1M1 holds f =XBOOLE-0R4 {}XBOOLE-0K1 implies f \<inverse>FUNCT-1K4 =XBOOLE-0R4 {}XBOOLE-0K1"
  proof(rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume "f =XBOOLE-0R4 {}XBOOLE-0K1"
    then have "domRELAT-1K1 (f \<inverse>FUNCT-1K4) =XBOOLE-0R4 {}XBOOLE-0K1"
      using funct_1_th_33 relat_1_th_38 sorry
    thus "f \<inverse>FUNCT-1K4 =XBOOLE-0R4 {}XBOOLE-0K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem grfunc_1_th_22:
" for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f & x inHIDDENR3 X iff [TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 f  |RELAT-1K8 X"
proof-
  have " for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  not ((x inHIDDENR3 domRELAT-1K1 f & x inHIDDENR3 X) &  not [TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 f  |RELAT-1K8 X) &  not ([TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 f  |RELAT-1K8 X &  not (x inHIDDENR3 domRELAT-1K1 f & x inHIDDENR3 X))"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have "x inHIDDENR3 domRELAT-1K1 f iff [TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 f"
      using funct_1_def_2 xtuple_0_def_12 sorry
    thus " not ((x inHIDDENR3 domRELAT-1K1 f & x inHIDDENR3 X) &  not [TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 f  |RELAT-1K8 X) &  not ([TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 f  |RELAT-1K8 X &  not (x inHIDDENR3 domRELAT-1K1 f & x inHIDDENR3 X))"
      using relat_1_def_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem grfunc_1_th_23:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds g c=RELAT-1R2 f implies f  |RELAT-1K8 domRELAT-1K1 g =FUNCT-1R1 g"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds g c=RELAT-1R2 f implies f  |RELAT-1K8 domRELAT-1K1 g =FUNCT-1R1 g"
  proof(rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "g c=RELAT-1R2 f"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 f  |RELAT-1K8 domRELAT-1K1 g implies [TARSKIK4 x,y ] inHIDDENR3 g"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A2: "[TARSKIK4 x,y ] inHIDDENR3 f  |RELAT-1K8 domRELAT-1K1 g"
      then have "x inHIDDENR3 domRELAT-1K1 g"
        using relat_1_def_11 sorry
      then have A3: "[TARSKIK4 x,g .FUNCT-1K1 x ] inHIDDENR3 g"
        using funct_1_def_2 sorry
      have "[TARSKIK4 x,y ] inHIDDENR3 f"
        using A2 relat_1_def_11 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 g"
        using A1 A3 funct_1_def_1 sorry
    qed "sorry"
    then have A4: "f  |RELAT-1K8 domRELAT-1K1 g c=RELAT-1R2 g"
       sorry
    have "g  |RELAT-1K8 domRELAT-1K1 g c=RELAT-1R2 f  |RELAT-1K8 domRELAT-1K1 g"
      using A1 relat_1_th_76 sorry
    then have "g c=RELAT-1R2 f  |RELAT-1K8 domRELAT-1K1 g"
       sorry
    thus "f  |RELAT-1K8 domRELAT-1K1 g =FUNCT-1R1 g"
      using A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem grfunc_1_th_24:
" for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 Y iff [TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 Y  |`RELAT-1K9 f"
proof-
  have " for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  not ((x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 Y) &  not [TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 Y  |`RELAT-1K9 f) &  not ([TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 Y  |`RELAT-1K9 f &  not (x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 Y))"
  proof(rule ballI,rule ballI,rule ballI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have "x inHIDDENR3 domRELAT-1K1 f iff [TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 f"
      using funct_1_def_2 xtuple_0_def_12 sorry
    thus " not ((x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 Y) &  not [TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 Y  |`RELAT-1K9 f) &  not ([TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 Y  |`RELAT-1K9 f &  not (x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 Y))"
      using relat_1_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem grfunc_1_th_25:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds g c=RELAT-1R2 f & f be one-to-oneFUNCT-1V2 implies rngFUNCT-1K2 g  |`RELAT-1K9 f =FUNCT-1R1 g"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds g c=RELAT-1R2 f implies (f be one-to-oneFUNCT-1V2 implies rngFUNCT-1K2 g  |`RELAT-1K9 f =FUNCT-1R1 g)"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "g c=RELAT-1R2 f"
    assume A2: "f be one-to-oneFUNCT-1V2"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 rngFUNCT-1K2 g  |`RELAT-1K9 f implies [TARSKIK4 x,y ] inHIDDENR3 g"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A3: "[TARSKIK4 x,y ] inHIDDENR3 rngFUNCT-1K2 g  |`RELAT-1K9 f"
      then have "y inHIDDENR3 rngFUNCT-1K2 g"
        using relat_1_def_12 sorry
      then have A4: " ex x1 be objectHIDDENM1 st [TARSKIK4 x1,y ] inHIDDENR3 g"
        using xtuple_0_def_13 sorry
      have "[TARSKIK4 x,y ] inHIDDENR3 f"
        using A3 relat_1_def_12 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 g"
        using A1 A2 A4 grfunc_1_th_9 sorry
    qed "sorry"
    then have A5: "rngFUNCT-1K2 g  |`RELAT-1K9 f c=RELAT-1R2 g"
       sorry
    have "rngFUNCT-1K2 g  |`RELAT-1K9 g c=RELAT-1R2 rngFUNCT-1K2 g  |`RELAT-1K9 f"
      using A1 relat_1_th_101 sorry
    then have "g c=RELAT-1R2 rngFUNCT-1K2 g  |`RELAT-1K9 f"
       sorry
    thus "rngFUNCT-1K2 g  |`RELAT-1K9 f =FUNCT-1R1 g"
      using A5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem grfunc_1_th_26:
" for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 f \<inverse>FUNCT-1K6 Y iff [TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 f & f .FUNCT-1K1 x inTARSKIR2 Y"
proof-
  have " for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds (x inHIDDENR3 f \<inverse>FUNCT-1K6 Y implies [TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 f & f .FUNCT-1K1 x inTARSKIR2 Y) &  not (([TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 f & f .FUNCT-1K1 x inTARSKIR2 Y) &  not x inHIDDENR3 f \<inverse>FUNCT-1K6 Y)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    show "x inHIDDENR3 f \<inverse>FUNCT-1K6 Y implies [TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 f & f .FUNCT-1K1 x inTARSKIR2 Y"
    proof(rule impI)
      assume "x inHIDDENR3 f \<inverse>FUNCT-1K6 Y"
      then have " ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 f & y inHIDDENR3 Y"
        using relat_1_def_14 sorry
      thus "[TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 f & f .FUNCT-1K1 x inTARSKIR2 Y"
        using funct_1_th_1 sorry
    qed
    show " not (([TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 f & f .FUNCT-1K1 x inTARSKIR2 Y) &  not x inHIDDENR3 f \<inverse>FUNCT-1K6 Y)"
      using relat_1_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem grfunc_1_th_27:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds X c=TARSKIR1 domRELAT-1K1 f & f c=RELAT-1R2 g implies f  |RELAT-1K8 X =FUNCT-1R1 g  |RELAT-1K8 X"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds X c=TARSKIR1 domRELAT-1K1 f implies (f c=RELAT-1R2 g implies f  |RELAT-1K8 X =HIDDENR1 g  |RELAT-1K8 X)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "X c=TARSKIR1 domRELAT-1K1 f"
    assume "f c=RELAT-1R2 g"
    then have "f  |RELAT-1K8 X =HIDDENR1 (g  |RELAT-1K8 domRELAT-1K1 f) |RELAT-1K8 X"
      using grfunc_1_th_23 sorry
    also have "... = g  |RELAT-1K8 (domRELAT-1K1 f /\\XBOOLE-0K3 X)"
      using relat_1_th_71 sorry
    also have "... = g  |RELAT-1K8 X"
      using A1 xboole_1_th_28 sorry
    finally show "f  |RELAT-1K8 X =HIDDENR1 g  |RELAT-1K8 X"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem grfunc_1_th_28:
" for f be FunctionFUNCT-1M1 holds  for x be setHIDDENM2 holds x inTARSKIR2 domRELAT-1K1 f implies f  |RELAT-1K8 {TARSKIK1 x} =FUNCT-1R1 {TARSKIK1 [TARSKIK4 x,f .FUNCT-1K1 x ] }"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for x be setHIDDENM2 holds x inTARSKIR2 domRELAT-1K1 f implies f  |RELAT-1K8 {TARSKIK1 x} =HIDDENR1 {TARSKIK1 [TARSKIK4 x,f .FUNCT-1K1 x ] }"
  proof(rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix x assume [ty]: "x be setHIDDENM2"
    assume A1: "x inTARSKIR2 domRELAT-1K1 f"
    have A2: "x inTARSKIR2 {TARSKIK1 x}"
      using tarski_def_1 sorry
    have "domRELAT-1K1 (f  |RELAT-1K8 {TARSKIK1 x}) =HIDDENR1 domRELAT-1K1 f /\\XBOOLE-0K3 {TARSKIK1 x}"
      using relat_1_th_61 sorry
    also have "... = {TARSKIK1 x}"
      using A1 zfmisc_1_th_46 sorry
    finally have "domRELAT-1K1 (f  |RELAT-1K8 {TARSKIK1 x}) =HIDDENR1 {TARSKIK1 x}"
       sorry
    then have "f  |RELAT-1K8 {TARSKIK1 x} =HIDDENR1 {TARSKIK1 [TARSKIK4 x,(f  |RELAT-1K8 {TARSKIK1 x}).FUNCT-1K1 x ] }"
      using grfunc_1_th_7 sorry
    also have "... = {TARSKIK1 [TARSKIK4 x,f .FUNCT-1K1 x ] }"
      using A2 funct_1_th_49 sorry
    finally show "f  |RELAT-1K8 {TARSKIK1 x} =HIDDENR1 {TARSKIK1 [TARSKIK4 x,f .FUNCT-1K1 x ] }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem grfunc_1_th_29:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for x be setHIDDENM2 holds domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g & f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x implies f  |RELAT-1K8 {TARSKIK1 x} =FUNCT-1R1 g  |RELAT-1K8 {TARSKIK1 x}"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for x be setHIDDENM2 holds domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g & f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x implies f  |RELAT-1K8 {TARSKIK1 x} =HIDDENR1 g  |RELAT-1K8 {TARSKIK1 x}"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix x assume [ty]: "x be setHIDDENM2"
    assume A1: "domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g"
      and A2: "f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
    show "f  |RELAT-1K8 {TARSKIK1 x} =HIDDENR1 g  |RELAT-1K8 {TARSKIK1 x}"
    proof-
      have cases: "x inTARSKIR2 domRELAT-1K1 f or  not x inTARSKIR2 domRELAT-1K1 f"
         sorry
      have case1: "x inTARSKIR2 domRELAT-1K1 f implies f  |RELAT-1K8 {TARSKIK1 x} =HIDDENR1 g  |RELAT-1K8 {TARSKIK1 x}"
      proof(rule impI)
        assume A3: "x inTARSKIR2 domRELAT-1K1 f"
        then have "f  |RELAT-1K8 {TARSKIK1 x} =HIDDENR1 {TARSKIK1 [TARSKIK4 x,g .FUNCT-1K1 x ] }"
          using A2 grfunc_1_th_28 sorry
        also have "... = g  |RELAT-1K8 {TARSKIK1 x}"
          using A1 A3 grfunc_1_th_28 sorry
        finally show "f  |RELAT-1K8 {TARSKIK1 x} =HIDDENR1 g  |RELAT-1K8 {TARSKIK1 x}"
           sorry
      qed
      have case2: " not x inTARSKIR2 domRELAT-1K1 f implies f  |RELAT-1K8 {TARSKIK1 x} =HIDDENR1 g  |RELAT-1K8 {TARSKIK1 x}"
      proof(rule impI)
        assume " not x inTARSKIR2 domRELAT-1K1 f"
        then have A4: "{TARSKIK1 x} missesXBOOLE-0R1 domRELAT-1K1 f"
          using zfmisc_1_th_50 sorry
        then have "f  |RELAT-1K8 {TARSKIK1 x} =HIDDENR1 {}XBOOLE-0K1"
          using relat_1_th_66 sorry
        also have "... = g  |RELAT-1K8 {TARSKIK1 x}"
          using A1 A4 relat_1_th_66 sorry
        finally show "f  |RELAT-1K8 {TARSKIK1 x} =HIDDENR1 g  |RELAT-1K8 {TARSKIK1 x}"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem grfunc_1_th_30:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds (domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g & f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x) & f .FUNCT-1K1 y =XBOOLE-0R4 g .FUNCT-1K1 y implies f  |RELAT-1K8 {TARSKIK2 x,y } =FUNCT-1R1 g  |RELAT-1K8 {TARSKIK2 x,y }"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  fix g assume [ty]: "g be FunctionFUNCT-1M1"
  fix x assume [ty]: "x be setHIDDENM2"
  fix y assume [ty]: "y be setHIDDENM2"
  assume "(domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g & f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x) & f .FUNCT-1K1 y =XBOOLE-0R4 g .FUNCT-1K1 y"
  then have A1: "f  |RELAT-1K8 {TARSKIK1 x} =FUNCT-1R1 g  |RELAT-1K8 {TARSKIK1 x} & f  |RELAT-1K8 {TARSKIK1 y} =FUNCT-1R1 g  |RELAT-1K8 {TARSKIK1 y}"
    using grfunc_1_th_29 sorry
  have "{TARSKIK2 x,y } =XBOOLE-0R4 {TARSKIK1 x} \\/XBOOLE-0K2 {TARSKIK1 y}"
    using enumset1_th_1 sorry
  thus "f  |RELAT-1K8 {TARSKIK2 x,y } =FUNCT-1R1 g  |RELAT-1K8 {TARSKIK2 x,y }"
    using A1 relat_1_th_150 sorry
qed "sorry"

mtheorem grfunc_1_th_31:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds ((domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g & f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x) & f .FUNCT-1K1 y =XBOOLE-0R4 g .FUNCT-1K1 y) & f .FUNCT-1K1 z =XBOOLE-0R4 g .FUNCT-1K1 z implies f  |RELAT-1K8 {ENUMSET1K1 x,y,z } =FUNCT-1R1 g  |RELAT-1K8 {ENUMSET1K1 x,y,z }"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  fix g assume [ty]: "g be FunctionFUNCT-1M1"
  fix x assume [ty]: "x be setHIDDENM2"
  fix y assume [ty]: "y be setHIDDENM2"
  fix z assume [ty]: "z be setHIDDENM2"
  assume "((domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g & f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x) & f .FUNCT-1K1 y =XBOOLE-0R4 g .FUNCT-1K1 y) & f .FUNCT-1K1 z =XBOOLE-0R4 g .FUNCT-1K1 z"
  then have A1: "f  |RELAT-1K8 {TARSKIK2 x,y } =FUNCT-1R1 g  |RELAT-1K8 {TARSKIK2 x,y } & f  |RELAT-1K8 {TARSKIK1 z} =FUNCT-1R1 g  |RELAT-1K8 {TARSKIK1 z}"
    using grfunc_1_th_29 grfunc_1_th_30 sorry
  have "{ENUMSET1K1 x,y,z } =XBOOLE-0R4 {TARSKIK2 x,y } \\/XBOOLE-0K2 {TARSKIK1 z}"
    using enumset1_th_3 sorry
  thus "f  |RELAT-1K8 {ENUMSET1K1 x,y,z } =FUNCT-1R1 g  |RELAT-1K8 {ENUMSET1K1 x,y,z }"
    using A1 relat_1_th_150 sorry
qed "sorry"

mtheorem grfunc_1_cl_2:
  mlet "f be FunctionFUNCT-1M1", "A be setHIDDENM2"
"cluster f \\SUBSET-1K6 A as-term-is Function-likeFUNCT-1V1"
proof
(*coherence*)
  show "f \\SUBSET-1K6 A be Function-likeFUNCT-1V1"
     sorry
qed "sorry"

mtheorem grfunc_1_th_32:
" for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f \\SUBSET-1K6 domRELAT-1K1 g implies (f \\SUBSET-1K6 g).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
proof-
  have " for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f \\SUBSET-1K6 domRELAT-1K1 g implies (f \\SUBSET-1K6 g).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "x inHIDDENR3 domRELAT-1K1 f \\SUBSET-1K6 domRELAT-1K1 g"
    have "f \\SUBSET-1K6 g c=RELAT-1R2 f & domRELAT-1K1 f \\SUBSET-1K6 domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 (f \\SUBSET-1K6 g)"
      using xtuple_0_th_25 sorry
    thus "(f \\SUBSET-1K6 g).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
      using A1 grfunc_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem grfunc_1_th_33:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds f c=RELAT-1R2 g & f c=RELAT-1R2 h implies g  |RELAT-1K8 domRELAT-1K1 f =FUNCT-1R1 h  |RELAT-1K8 domRELAT-1K1 f"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds f c=RELAT-1R2 g & f c=RELAT-1R2 h implies g  |RELAT-1K8 domRELAT-1K1 f =HIDDENR1 h  |RELAT-1K8 domRELAT-1K1 f"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix h assume [ty]: "h be FunctionFUNCT-1M1"
    assume A1: "f c=RELAT-1R2 g"
      and A2: "f c=RELAT-1R2 h"
    have "g  |RELAT-1K8 domRELAT-1K1 f =HIDDENR1 f"
      using A1 grfunc_1_th_23 sorry
    also have "... = h  |RELAT-1K8 domRELAT-1K1 f"
      using A2 grfunc_1_th_23 sorry
    finally show "g  |RELAT-1K8 domRELAT-1K1 f =HIDDENR1 h  |RELAT-1K8 domRELAT-1K1 f"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem grfunc_1_cl_3:
  mlet "f be FunctionFUNCT-1M1", "g be SubsetSUBSET-1M2-of f"
"cluster g -compatibleFUNCT-1V7 also-is f -compatibleFUNCT-1V7 for FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be FunctionFUNCT-1M1 holds it be g -compatibleFUNCT-1V7 implies it be f -compatibleFUNCT-1V7"
  proof-
    have " for F be FunctionFUNCT-1M1 holds F be g -compatibleFUNCT-1V7 implies F be f -compatibleFUNCT-1V7"
    proof(rule ballI,rule impI)
      fix F assume [ty]: "F be FunctionFUNCT-1M1"
      assume A1: "F be g -compatibleFUNCT-1V7"
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 F implies F .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 domRELAT-1K1 F"
        then have A2: "F .FUNCT-1K1 x inTARSKIR2 g .FUNCT-1K1 x"
          using A1 sorry
        then have "x inHIDDENR3 domRELAT-1K1 g"
          using funct_1_def_2 sorry
        thus "F .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
          using A2 grfunc_1_th_2 sorry
      qed "sorry"
      thus "F be f -compatibleFUNCT-1V7"
        using funct_1_def_14 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem grfunc_1_th_34:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds g c=RELAT-1R2 f implies g =FUNCT-1R1 f  |RELAT-1K8 domRELAT-1K1 g"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds g c=RELAT-1R2 f implies g =FUNCT-1R1 f  |RELAT-1K8 domRELAT-1K1 g"
  proof(rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "g c=RELAT-1R2 f"
    then have Cut541: "domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f"
      using relat_1_th_11 sorry
    have "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 (f  |RELAT-1K8 domRELAT-1K1 g) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x =HIDDENR1 (f  |RELAT-1K8 domRELAT-1K1 g).FUNCT-1K1 x)"
    proof(rule conjMI,rule ballI,rule impI)
      show "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 (f  |RELAT-1K8 domRELAT-1K1 g)"
        using relat_1_th_62 Cut541 sorry
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A2: "x inHIDDENR3 domRELAT-1K1 g"
      then have "g .FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 x"
        using A1 grfunc_1_th_2 sorry
      also have "... = (f  |RELAT-1K8 domRELAT-1K1 g).FUNCT-1K1 x"
        using A2 funct_1_th_49 sorry
      finally show "g .FUNCT-1K1 x =HIDDENR1 (f  |RELAT-1K8 domRELAT-1K1 g).FUNCT-1K1 x"
         sorry
    qed "sorry"
    thus "g =FUNCT-1R1 f  |RELAT-1K8 domRELAT-1K1 g"
      using funct_1_def_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem grfunc_1_cl_4:
  mlet "f be FunctionFUNCT-1M1", "g be f -compatibleFUNCT-1V7\<bar>FunctionFUNCT-1M1"
"cluster note-that f -compatibleFUNCT-1V7 for SubsetSUBSET-1M2-of g"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of g holds it be f -compatibleFUNCT-1V7"
  proof-
    have " for h be SubsetSUBSET-1M2-of g holds h be f -compatibleFUNCT-1V7"
    proof(rule ballI)
      fix h assume [ty]: "h be SubsetSUBSET-1M2-of g"
      have "h =FUNCT-1R1 g  |RELAT-1K8 domRELAT-1K1 h"
        using grfunc_1_th_34 sorry
      thus "h be f -compatibleFUNCT-1V7"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem grfunc_1_th_35:
" for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds (g c=RELAT-1R2 f & x inHIDDENR3 X) & X /\\XBOOLE-0K3 domRELAT-1K1 f c=TARSKIR1 domRELAT-1K1 g implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
proof-
  have " for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds g c=RELAT-1R2 f & (x inHIDDENR3 X & X /\\XBOOLE-0K3 domRELAT-1K1 f c=TARSKIR1 domRELAT-1K1 g) implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "g c=RELAT-1R2 f"
      and A2: "x inHIDDENR3 X"
      and A3: "X /\\XBOOLE-0K3 domRELAT-1K1 f c=TARSKIR1 domRELAT-1K1 g"
    show "f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
    proof-
      have cases: "x inHIDDENR3 domRELAT-1K1 g or  not x inHIDDENR3 domRELAT-1K1 g"
         sorry
      have case1: "x inHIDDENR3 domRELAT-1K1 g implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
      proof(rule impI)
        assume "x inHIDDENR3 domRELAT-1K1 g"
        thus "f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
          using A1 grfunc_1_th_2 sorry
      qed
      have case2: " not x inHIDDENR3 domRELAT-1K1 g implies f .FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x"
      proof(rule impI)
        assume A4: " not x inHIDDENR3 domRELAT-1K1 g"
        then have " not x inHIDDENR3 X /\\XBOOLE-0K3 domRELAT-1K1 f"
          using A3 sorry
        then have " not x inHIDDENR3 domRELAT-1K1 f"
          using A2 xboole_0_def_4 sorry
        then have "f .FUNCT-1K1 x =HIDDENR1 {}XBOOLE-0K1"
          using funct_1_def_2 sorry
        also have "... = g .FUNCT-1K1 x"
          using A4 funct_1_def_2 sorry
        finally show "f .FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
