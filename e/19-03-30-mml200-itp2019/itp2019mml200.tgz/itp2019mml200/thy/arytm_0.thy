theory arytm_0
  imports arytm_1 numbers
   "../mizar_extension/E_number"
begin
(*begin*)
mlemma arytm_0_lm_1:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds [TARSKIK4 0NUMBERSK6,x ] inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
proof-
  have "0NUMBERSK6 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
    using tarski_def_1 sorry
  thus " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds [TARSKIK4 0NUMBERSK6,x ] inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
    using zfmisc_1_th_87 sorry
qed

mtheorem arytm_0_th_1:
"REAL+ARYTM-2K2 c=TARSKIR1 REALNUMBERSK2"
proof-
  have "REAL+ARYTM-2K2 c=TARSKIR1 REAL+ARYTM-2K2 \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 {}ARYTM-3K12 },REAL+ARYTM-2K2 :]"
    using xboole_1_th_7 sorry
  thus "REAL+ARYTM-2K2 c=TARSKIR1 REALNUMBERSK2"
    using arytm_2_th_3 zfmisc_1_th_34 sorry
qed

mtheorem arytm_0_th_2:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x <>HIDDENR2 {}ARYTM-3K12 implies [TARSKIK4 {}ARYTM-3K12,x ] inHIDDENR3 REALNUMBERSK2"
proof(rule ballI,rule impI)
  fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
  assume A1: "x <>HIDDENR2 {}ARYTM-3K12"
  have A2: "[TARSKIK4 {}ARYTM-3K12,x ] inHIDDENR3 {TARSKIK1 [TARSKIK4 {}ARYTM-3K12,{}ARYTM-3K12 ] } implies  False "
  proof(rule impI)
    assume "[TARSKIK4 {}ARYTM-3K12,x ] inHIDDENR3 {TARSKIK1 [TARSKIK4 {}ARYTM-3K12,{}ARYTM-3K12 ] }"
    then have "[TARSKIK4 {}ARYTM-3K12,x ] =HIDDENR1 [TARSKIK4 {}ARYTM-3K12,{}ARYTM-3K12 ]"
      using tarski_def_1 sorry
    thus " False "
      using A1 xtuple_0_th_1 sorry
  qed
  have "{}ARYTM-3K12 inTARSKIR2 {TARSKIK1 {}ARYTM-3K12 }"
    using tarski_def_1 sorry
  then have "[TARSKIK4 {}ARYTM-3K12,x ] inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 {}ARYTM-3K12 },REAL+ARYTM-2K2 :]"
    using zfmisc_1_th_87 sorry
  then have "[TARSKIK4 {}ARYTM-3K12,x ] inHIDDENR3 REAL+ARYTM-2K2 \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 {}ARYTM-3K12 },REAL+ARYTM-2K2 :]"
    using xboole_0_def_3 sorry
  thus "[TARSKIK4 {}ARYTM-3K12,x ] inHIDDENR3 REALNUMBERSK2"
    using A2 xboole_0_def_5 sorry
qed "sorry"

mtheorem arytm_0_th_3:
" for y be setHIDDENM2 holds [TARSKIK4 {}ARYTM-3K12,y ] inHIDDENR3 REALNUMBERSK2 implies y <>HIDDENR2 {}ARYTM-3K12"
proof-
  have " for y be setHIDDENM2 holds [TARSKIK4 {}ARYTM-3K12,y ] inHIDDENR3 REALNUMBERSK2 & y =XBOOLE-0R4 {}ARYTM-3K12 implies  False "
  proof(rule ballI,rule impMI ,rule impI)
    fix y assume [ty]: "y be setHIDDENM2"
    assume A1: "[TARSKIK4 {}ARYTM-3K12,y ] inHIDDENR3 REALNUMBERSK2"
      and A2: "y =XBOOLE-0R4 {}ARYTM-3K12"
    have "[TARSKIK4 {}ARYTM-3K12,y ] inHIDDENR3 {TARSKIK1 [TARSKIK4 {}ARYTM-3K12,{}ARYTM-3K12 ] }"
      using A2 tarski_def_1 sorry
    thus " False "
      using A1 xboole_0_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_0_th_4:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x -ARYTM-1K2 y inTARSKIR2 REALNUMBERSK2"
proof(rule ballI,rule ballI)
  fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
  fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
  show "x -ARYTM-1K2 y inTARSKIR2 REALNUMBERSK2"
  proof-
    have cases: "y <='ARYTM-2R1 x or  not y <='ARYTM-2R1 x"
       sorry
    have case1: "y <='ARYTM-2R1 x implies x -ARYTM-1K2 y inTARSKIR2 REALNUMBERSK2"
    proof(rule impI)
      assume "y <='ARYTM-2R1 x"
      then have "x -ARYTM-1K2 y =XBOOLE-0R4 x -'ARYTM-1K1 y"
        using arytm_1_def_2 sorry
      then have "x -ARYTM-1K2 y inTARSKIR2 REAL+ARYTM-2K2"
         sorry
      thus "x -ARYTM-1K2 y inTARSKIR2 REALNUMBERSK2"
        using arytm_0_th_1 sorry
    qed
    have case2: " not y <='ARYTM-2R1 x implies x -ARYTM-1K2 y inTARSKIR2 REALNUMBERSK2"
    proof(rule impI)
      assume A1: " not y <='ARYTM-2R1 x"
      then have "x -ARYTM-1K2 y =HIDDENR1 [TARSKIK4 {}ARYTM-3K12,y -'ARYTM-1K1 x ]"
        using arytm_1_def_2 sorry
      thus "x -ARYTM-1K2 y inTARSKIR2 REALNUMBERSK2"
        using A1 arytm_0_th_2 arytm_1_th_9 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem arytm_0_th_5:
"REAL+ARYTM-2K2 missesXBOOLE-0R1 [:ZFMISC-1K2 {TARSKIK1 {}ARYTM-3K12 },REAL+ARYTM-2K2 :]"
proof-
  have "REAL+ARYTM-2K2 meetsXBOOLE-0R5 [:ZFMISC-1K2 {TARSKIK1 {}ARYTM-3K12 },REAL+ARYTM-2K2 :] implies  False "
  proof(rule impI)
    assume "REAL+ARYTM-2K2 meetsXBOOLE-0R5 [:ZFMISC-1K2 {TARSKIK1 {}ARYTM-3K12 },REAL+ARYTM-2K2 :]"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A1: "x inHIDDENR3 REAL+ARYTM-2K2"and A2: "x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 {}ARYTM-3K12 },REAL+ARYTM-2K2 :]"
      using xboole_0_th_3 sorry
    obtain x1 x2 where
      [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" and 
      A3: "x1 inHIDDENR3 {TARSKIK1 {}ARYTM-3K12 }"and "x2 inHIDDENR3 REAL+ARYTM-2K2"and A4: "x =HIDDENR1 [TARSKIK4 x1,x2 ]"
      using A2 zfmisc_1_th_84 sorry
    have "x1 =HIDDENR1 {}ARYTM-3K12"
      using A3 tarski_def_1 sorry
    thus " False "
      using A1 A4 arytm_2_th_3 sorry
  qed
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem arytm_0_cl_1:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1"
"cluster [TARSKIK4 x,y ] as-term-is  non zeroORDINAL1V8"
proof
(*coherence*)
  show "[TARSKIK4 x,y ] be  non zeroORDINAL1V8"
     sorry
qed "sorry"

mtheorem arytm_0_th_6:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x -ARYTM-1K2 y =XBOOLE-0R4 {}ARYTM-3K12 implies x =XBOOLE-0R4 y"
proof(rule ballI,rule ballI,rule impI)
  fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
  fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
  assume A1: "x -ARYTM-1K2 y =XBOOLE-0R4 {}ARYTM-3K12"
  have "0NUMBERSK6 <>HIDDENR2 [TARSKIK4 {}ARYTM-3K12,y -'ARYTM-1K1 x ]"
     sorry
  then have "y <='ARYTM-2R1 x & x -'ARYTM-1K1 y =XBOOLE-0R4 {}ARYTM-3K12"
    using A1 arytm_1_def_2 sorry
  thus "x =XBOOLE-0R4 y"
    using arytm_1_th_10 sorry
qed "sorry"

mlemma arytm_0_lm_2:
" not ( ex a be setHIDDENM2 st  ex b be setHIDDENM2 st \<one>\<^sub>M =HIDDENR1 [TARSKIK4 a,b ])"
proof-
  have " for a be setHIDDENM2 holds  for b be setHIDDENM2 holds \<one>\<^sub>M =HIDDENR1 [TARSKIK4 a,b ] implies  False "
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be setHIDDENM2"
    fix b assume [ty]: "b be setHIDDENM2"
    assume A1: "\<one>\<^sub>M =HIDDENR1 [TARSKIK4 a,b ]"
    have "{TARSKIK1 a} inTARSKIR2 {TARSKIK2 {TARSKIK2 a,b },{TARSKIK1 a} }"
      using tarski_def_2 sorry
    thus " False "
      using A1 ordinal3_th_15 tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_0_th_7:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x <>HIDDENR2 {}ARYTM-3K12 & x *'ARYTM-2K8 y =XBOOLE-0R4 x *'ARYTM-2K8 z implies y =XBOOLE-0R4 z"
proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
  fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
  fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
  assume A1: "x <>HIDDENR2 {}ARYTM-3K12"
    and A2: "x *'ARYTM-2K8 y =XBOOLE-0R4 x *'ARYTM-2K8 z"
  show "y =XBOOLE-0R4 z"
  proof-
    have cases: "z <='ARYTM-2R1 y or y <='ARYTM-2R1 z"
       sorry
    have case1: "z <='ARYTM-2R1 y implies y =XBOOLE-0R4 z"
    proof(rule impI)
      assume A3: "z <='ARYTM-2R1 y"
      then have "x *'ARYTM-2K8 (y -'ARYTM-1K1 z) =HIDDENR1 x *'ARYTM-2K8 y -ARYTM-1K2 x *'ARYTM-2K8 z"
        using arytm_1_th_26 sorry
      also have "... = {}ARYTM-3K12"
        using A2 arytm_1_th_18 sorry
      finally have "x *'ARYTM-2K8 (y -'ARYTM-1K1 z) =HIDDENR1 {}ARYTM-3K12"
         sorry
      then have "{}ARYTM-3K12 =HIDDENR1 y -'ARYTM-1K1 z"
        using A1 arytm_1_th_2 sorry
      also have "... = y -ARYTM-1K2 z"
        using A3 arytm_1_def_2 sorry
      finally have "{}ARYTM-3K12 =HIDDENR1 y -ARYTM-1K2 z"
         sorry
      thus "y =XBOOLE-0R4 z"
        using arytm_0_th_6 sorry
    qed
    have case2: "y <='ARYTM-2R1 z implies y =XBOOLE-0R4 z"
    proof(rule impI)
      assume A4: "y <='ARYTM-2R1 z"
      then have "x *'ARYTM-2K8 (z -'ARYTM-1K1 y) =HIDDENR1 x *'ARYTM-2K8 z -ARYTM-1K2 x *'ARYTM-2K8 y"
        using arytm_1_th_26 sorry
      also have "... = {}ARYTM-3K12"
        using A2 arytm_1_th_18 sorry
      finally have "x *'ARYTM-2K8 (z -'ARYTM-1K1 y) =HIDDENR1 {}ARYTM-3K12"
         sorry
      then have "{}ARYTM-3K12 =HIDDENR1 z -'ARYTM-1K1 y"
        using A1 arytm_1_th_2 sorry
      also have "... = z -ARYTM-1K2 y"
        using A4 arytm_1_def_2 sorry
      finally have "{}ARYTM-3K12 =HIDDENR1 z -ARYTM-1K2 y"
         sorry
      thus "y =XBOOLE-0R4 z"
        using arytm_0_th_6 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

(*begin*)
mlemma arytm_0_lm_3:
"0NUMBERSK6 inTARSKIR2 REALNUMBERSK2"
  using numbers_th_19 sorry

mdef arytm_0_def_1 ("+ARYTM-0K1'( _ , _ ')" [0,0]132 ) where
  mlet "x be ElementSUBSET-1M1-of REALNUMBERSK2", "y be ElementSUBSET-1M1-of REALNUMBERSK2"
"func +ARYTM-0K1(x,y) \<rightarrow> ElementSUBSET-1M1-of REALNUMBERSK2 means
  \<lambda>it.  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & it =XBOOLE-0R4 x9 +ARYTM-2K7 y9 if x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2,
  \<lambda>it.  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & it =XBOOLE-0R4 x9 -ARYTM-1K2 y9 if x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :],
  \<lambda>it.  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =XBOOLE-0R4 y9) & it =XBOOLE-0R4 y9 -ARYTM-1K2 x9 if y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] otherwise \<lambda>it.  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & it =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 +ARYTM-2K7 y9 ]"
proof-
  (*existence*)
    show "(x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2 implies ( ex it be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & it =XBOOLE-0R4 x9 +ARYTM-2K7 y9)) & ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ( ex it be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & it =XBOOLE-0R4 x9 -ARYTM-1K2 y9)) & ((y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ( ex it be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =XBOOLE-0R4 y9) & it =XBOOLE-0R4 y9 -ARYTM-1K2 x9)) & ( not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & ( not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) &  not (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) implies ( ex it be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & it =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 +ARYTM-2K7 y9 ]))))"
    proof-
      have "(x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2 implies ( ex IT be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & IT =XBOOLE-0R4 x9 +ARYTM-2K7 y9)) & ((x inTARSKIR2 REAL+ARYTM-2K2 implies (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ( ex IT be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & IT =XBOOLE-0R4 x9 -ARYTM-1K2 y9))) & ((y inTARSKIR2 REAL+ARYTM-2K2 implies (x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ( ex IT be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =XBOOLE-0R4 y9) & IT =XBOOLE-0R4 y9 -ARYTM-1K2 x9))) & ( not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & ( not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) &  not (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) implies ( ex tVar10 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex tVar11 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex tVar12 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,tVar11 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,tVar12 ]) & tVar10 =HIDDENR1 [TARSKIK4 0NUMBERSK6,tVar11 +ARYTM-2K7 tVar12 ]))))"
      proof(rule conjMI,rule conjMI,rule conjMI,rule impMI ,rule impMI ,rule impI)
        show "x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2 implies ( ex IT be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & IT =XBOOLE-0R4 x9 +ARYTM-2K7 y9)"
        proof(rule impI)
          assume "x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2"
          then obtain x9 y9 where 
            [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and x9Def:"x9 = x" and
            [ty]:"y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and y9Def:"y9 = y"
             sorry
          obtain IT where 
            [ty]:"IT be ElementSUBSET-1M1-of REALNUMBERSK2" and ITDef:"IT = x9 +ARYTM-2K7 y9"
            using arytm_0_th_1 sorry
          show " ex IT be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & IT =XBOOLE-0R4 x9 +ARYTM-2K7 y9"
          proof(rule bexI[of _ "IT"])
            show " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & IT =XBOOLE-0R4 x9 +ARYTM-2K7 y9"
            proof(rule bexI[of _ "x9"])
              show " ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & IT =XBOOLE-0R4 x9 +ARYTM-2K7 y9"
              proof(rule bexI[of _ "y9"])
                show "(x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & IT =XBOOLE-0R4 x9 +ARYTM-2K7 y9"
                   sorry
              qed "sorry"
            qed "sorry"
          qed "sorry"
        qed
        have A1: "y inTARSKIR2 REAL+ARYTM-2K2 \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          using xboole_0_def_5 sorry
        show "x inTARSKIR2 REAL+ARYTM-2K2 implies (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ( ex IT be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & IT =XBOOLE-0R4 x9 -ARYTM-1K2 y9))"
        proof(rule impI,rule impI)
          assume "x inTARSKIR2 REAL+ARYTM-2K2"
          then obtain x9 where 
            [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and x9Def:"x9 = x"
             sorry
          assume "y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          then obtain z y9 where
            [ty]:"z be objectHIDDENM1" "y9 be objectHIDDENM1" and 
            A2: "z inHIDDENR3 {TARSKIK1 0NUMBERSK6 }"and A3: "y9 inHIDDENR3 REAL+ARYTM-2K2"and A4: "y =HIDDENR1 [TARSKIK4 z,y9 ]"
            using zfmisc_1_th_84 sorry
          have 
            [ty]:"y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
            using A3 sorry
          obtain IT where 
            [ty]:"IT be ElementSUBSET-1M1-of REALNUMBERSK2" and ITDef:"IT = x9 -ARYTM-1K2 y9"
            using arytm_0_th_4 sorry
          show " ex IT be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & IT =XBOOLE-0R4 x9 -ARYTM-1K2 y9"
          proof(rule bexI[of _ "IT"])
            show " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & IT =XBOOLE-0R4 x9 -ARYTM-1K2 y9"
            proof(rule bexI[of _ "x9"])
              show " ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & IT =XBOOLE-0R4 x9 -ARYTM-1K2 y9"
              proof(rule bexI[of _ "y9"])
                show "(x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & IT =XBOOLE-0R4 x9 -ARYTM-1K2 y9"
                  using A2 A4 tarski_def_1 sorry
              qed "sorry"
            qed "sorry"
          qed "sorry"
        qed
        show "y inTARSKIR2 REAL+ARYTM-2K2 implies (x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ( ex IT be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =XBOOLE-0R4 y9) & IT =XBOOLE-0R4 y9 -ARYTM-1K2 x9))"
        proof(rule impI,rule impI)
          assume "y inTARSKIR2 REAL+ARYTM-2K2"
          then obtain y9 where 
            [ty]:"y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and y9Def:"y9 = y"
             sorry
          assume "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          then obtain z x9 where
            [ty]:"z be objectHIDDENM1" "x9 be objectHIDDENM1" and 
            A5: "z inHIDDENR3 {TARSKIK1 0NUMBERSK6 }"and A6: "x9 inHIDDENR3 REAL+ARYTM-2K2"and A7: "x =HIDDENR1 [TARSKIK4 z,x9 ]"
            using zfmisc_1_th_84 sorry
          have 
            [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
            using A6 sorry
          obtain IT where 
            [ty]:"IT be ElementSUBSET-1M1-of REALNUMBERSK2" and ITDef:"IT = y9 -ARYTM-1K2 x9"
            using arytm_0_th_4 sorry
          show " ex IT be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =XBOOLE-0R4 y9) & IT =XBOOLE-0R4 y9 -ARYTM-1K2 x9"
          proof(rule bexI[of _ "IT"])
            show " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =XBOOLE-0R4 y9) & IT =XBOOLE-0R4 y9 -ARYTM-1K2 x9"
            proof(rule bexI[of _ "x9"])
              show " ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =XBOOLE-0R4 y9) & IT =XBOOLE-0R4 y9 -ARYTM-1K2 x9"
              proof(rule bexI[of _ "y9"])
                show "(x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =XBOOLE-0R4 y9) & IT =XBOOLE-0R4 y9 -ARYTM-1K2 x9"
                  using A5 A7 tarski_def_1 sorry
              qed "sorry"
            qed "sorry"
          qed "sorry"
        qed
        assume A8: " not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2)"
          and A9: " not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
          and A10: " not (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
        have A11: "x inTARSKIR2 REAL+ARYTM-2K2 \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          using xboole_0_def_5 sorry
        then have "x inTARSKIR2 REAL+ARYTM-2K2 or x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          using xboole_0_def_3 sorry
        then obtain z1 x9 where
          [ty]:"z1 be objectHIDDENM1" "x9 be objectHIDDENM1" and 
          A12: "z1 inHIDDENR3 {TARSKIK1 0NUMBERSK6 }"and A13: "x9 inHIDDENR3 REAL+ARYTM-2K2"and A14: "x =HIDDENR1 [TARSKIK4 z1,x9 ]"
          using A1 A8 A9 xboole_0_def_3 zfmisc_1_th_84 sorry
        have "y inTARSKIR2 REAL+ARYTM-2K2 or y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          using A1 xboole_0_def_3 sorry
        then obtain z2 y9 where
          [ty]:"z2 be objectHIDDENM1" "y9 be objectHIDDENM1" and 
          A15: "z2 inHIDDENR3 {TARSKIK1 0NUMBERSK6 }"and A16: "y9 inHIDDENR3 REAL+ARYTM-2K2"and A17: "y =HIDDENR1 [TARSKIK4 z2,y9 ]"
          using A11 A8 A10 xboole_0_def_3 zfmisc_1_th_84 sorry
        have 
          [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
          using A13 sorry
        have 
          [ty]:"y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
          using A16 sorry
        have "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]"
          using A12 A14 tarski_def_1 sorry
        then have "x9 +ARYTM-2K7 y9 <>HIDDENR2 0NUMBERSK6"
          using arytm_0_th_3 arytm_2_th_5 sorry
        then obtain IT where 
          [ty]:"IT be ElementSUBSET-1M1-of REALNUMBERSK2" and ITDef:"IT = [TARSKIK4 0NUMBERSK6,y9 +ARYTM-2K7 x9 ]"
          using arytm_0_th_2 sorry
        show " ex tVar10 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex tVar11 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex tVar12 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,tVar11 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,tVar12 ]) & tVar10 =HIDDENR1 [TARSKIK4 0NUMBERSK6,tVar11 +ARYTM-2K7 tVar12 ]"
        proof(rule bexI[of _ "IT"])
          show " ex tVar11 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex tVar12 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,tVar11 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,tVar12 ]) & IT =HIDDENR1 [TARSKIK4 0NUMBERSK6,tVar11 +ARYTM-2K7 tVar12 ]"
          proof(rule bexI[of _ "x9"])
            show " ex tVar12 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,tVar12 ]) & IT =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 +ARYTM-2K7 tVar12 ]"
            proof(rule bexI[of _ "y9"])
              show "(x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & IT =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 +ARYTM-2K7 y9 ]"
                using A12 A14 A15 A17 tarski_def_1 sorry
            qed "sorry"
          qed "sorry"
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for it2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2 implies (( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & it1 =XBOOLE-0R4 x9 +ARYTM-2K7 y9) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & it2 =XBOOLE-0R4 x9 +ARYTM-2K7 y9) implies it1 =HIDDENR1 it2)) & ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies (( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & it1 =XBOOLE-0R4 x9 -ARYTM-1K2 y9) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & it2 =XBOOLE-0R4 x9 -ARYTM-1K2 y9) implies it1 =HIDDENR1 it2)) & ((y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies (( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =XBOOLE-0R4 y9) & it1 =XBOOLE-0R4 y9 -ARYTM-1K2 x9) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =XBOOLE-0R4 y9) & it2 =XBOOLE-0R4 y9 -ARYTM-1K2 x9) implies it1 =HIDDENR1 it2)) & ( not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & ( not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) &  not (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) implies (( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & it1 =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 +ARYTM-2K7 y9 ]) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & it2 =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 +ARYTM-2K7 y9 ]) implies it1 =HIDDENR1 it2))))"
    proof-
      have " for IT1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for IT2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds (((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & IT1 =XBOOLE-0R4 x9 +ARYTM-2K7 y9)) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & IT2 =XBOOLE-0R4 x9 +ARYTM-2K7 y9) implies IT1 =XBOOLE-0R4 IT2) & ((((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & IT1 =XBOOLE-0R4 x9 -ARYTM-1K2 y9)) & ( ex x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x99 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 ]) & IT2 =XBOOLE-0R4 x99 -ARYTM-1K2 y99) implies IT1 =XBOOLE-0R4 IT2) & ((((y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =XBOOLE-0R4 y9) & IT1 =XBOOLE-0R4 y9 -ARYTM-1K2 x9)) & ( ex x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 ] & y =XBOOLE-0R4 y99) & IT2 =XBOOLE-0R4 y99 -ARYTM-1K2 x99) implies IT1 =XBOOLE-0R4 IT2) & ( not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & ( not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) &  not (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) implies (( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & (y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ] & IT1 =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 +ARYTM-2K7 y9 ])) implies (( ex x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 ] & (y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 ] & IT2 =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 +ARYTM-2K7 y99 ])) implies IT1 =HIDDENR1 IT2)))))"
      proof(rule ballI,rule ballI,rule conjMI,rule conjMI,rule conjMI,rule impMI ,rule impMI ,rule impI,rule impI,rule impI)
        fix IT1 assume [ty]: "IT1 be ElementSUBSET-1M1-of REALNUMBERSK2"
        fix IT2 assume [ty]: "IT2 be ElementSUBSET-1M1-of REALNUMBERSK2"
        show "((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & IT1 =XBOOLE-0R4 x9 +ARYTM-2K7 y9)) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & IT2 =XBOOLE-0R4 x9 +ARYTM-2K7 y9) implies IT1 =XBOOLE-0R4 IT2"
           sorry
        show "((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & IT1 =XBOOLE-0R4 x9 -ARYTM-1K2 y9)) & ( ex x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x99 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 ]) & IT2 =XBOOLE-0R4 x99 -ARYTM-1K2 y99) implies IT1 =XBOOLE-0R4 IT2"
          using xtuple_0_th_1 sorry
        show "((y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =XBOOLE-0R4 y9) & IT1 =XBOOLE-0R4 y9 -ARYTM-1K2 x9)) & ( ex x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 ] & y =XBOOLE-0R4 y99) & IT2 =XBOOLE-0R4 y99 -ARYTM-1K2 x99) implies IT1 =XBOOLE-0R4 IT2"
          using xtuple_0_th_1 sorry
        assume " not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2)"
          and " not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
          and " not (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
        assume Given: " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & (y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ] & IT1 =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 +ARYTM-2K7 y9 ])"
        then obtain x9 y9 where
          [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A18: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]"and A19: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ] & IT1 =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 +ARYTM-2K7 y9 ]"
           sorry
        assume Given: " ex x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 ] & (y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 ] & IT2 =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 +ARYTM-2K7 y99 ])"
        then obtain x99 y99 where
          [ty]:"x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A20: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 ]"and A21: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 ] & IT2 =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 +ARYTM-2K7 y99 ]"
           sorry
        have "x9 =XBOOLE-0R4 x99"
          using A18 A20 xtuple_0_th_1 sorry
        thus "IT1 =HIDDENR1 IT2"
          using A19 A21 xtuple_0_th_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
  (*consistency*)
    show " for it be ElementSUBSET-1M1-of REALNUMBERSK2 holds (((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies (( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & it =XBOOLE-0R4 x9 +ARYTM-2K7 y9) iff ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & it =XBOOLE-0R4 x9 -ARYTM-1K2 y9))) & ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies (( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & it =XBOOLE-0R4 x9 +ARYTM-2K7 y9) iff ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =XBOOLE-0R4 y9) & it =XBOOLE-0R4 y9 -ARYTM-1K2 x9)))) & ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies (( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & it =XBOOLE-0R4 x9 -ARYTM-1K2 y9) iff ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =XBOOLE-0R4 y9) & it =XBOOLE-0R4 y9 -ARYTM-1K2 x9)))"
      using arytm_0_th_5 xboole_0_th_3 sorry
qed "sorry"

mtheorem ARYTM_0K1_commutativity:
" for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds +ARYTM-0K1(x,y) =HIDDENR1 +ARYTM-0K1(y,x)"
proof-
  have " for it be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds it =HIDDENR1 +ARYTM-0K1(x,y) implies it =HIDDENR1 +ARYTM-0K1(y,x)"
  proof-
    have " for it be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2 implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & it =XBOOLE-0R4 x9 +ARYTM-2K7 y9)) & ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & it =XBOOLE-0R4 x9 -ARYTM-1K2 y9)) & ((y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =XBOOLE-0R4 y9) & it =XBOOLE-0R4 y9 -ARYTM-1K2 x9)) & ( not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & ( not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) &  not (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & it =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 +ARYTM-2K7 y9 ])))) implies (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 REAL+ARYTM-2K2 implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (y =XBOOLE-0R4 x9 & x =XBOOLE-0R4 y9) & it =XBOOLE-0R4 x9 +ARYTM-2K7 y9)) & ((y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (y =XBOOLE-0R4 x9 & x =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & it =XBOOLE-0R4 x9 -ARYTM-1K2 y9)) & ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (y =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & x =XBOOLE-0R4 y9) & it =XBOOLE-0R4 y9 -ARYTM-1K2 x9)) & ( not (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 REAL+ARYTM-2K2) & ( not (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) &  not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (y =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & x =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & it =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 +ARYTM-2K7 y9 ]))))"
       sorry
    thus " ?thesis "
      using arytm_0_def_1 sorry
  qed
  thus " ?thesis "
     sorry
qed

mdef arytm_0_def_2 (" *ARYTM-0K2'( _ , _ ')" [0,0]164 ) where
  mlet "x be ElementSUBSET-1M1-of REALNUMBERSK2", "y be ElementSUBSET-1M1-of REALNUMBERSK2"
"func  *ARYTM-0K2(x,y) \<rightarrow> ElementSUBSET-1M1-of REALNUMBERSK2 means
  \<lambda>it.  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & it =XBOOLE-0R4 x9 *'ARYTM-2K8 y9 if x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2,
  \<lambda>it.  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & it =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 *'ARYTM-2K8 y9 ] if (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & x <>HIDDENR2 0NUMBERSK6,
  \<lambda>it.  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =XBOOLE-0R4 y9) & it =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 *'ARYTM-2K8 x9 ] if (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & y <>HIDDENR2 0NUMBERSK6,
  \<lambda>it.  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & it =XBOOLE-0R4 y9 *'ARYTM-2K8 x9 if x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] otherwise \<lambda>it. it =XBOOLE-0R4 0NUMBERSK6"
proof-
  (*existence*)
    show "(x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2 implies ( ex it be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & it =XBOOLE-0R4 x9 *'ARYTM-2K8 y9)) & (((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & x <>HIDDENR2 0NUMBERSK6 implies ( ex it be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & it =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 *'ARYTM-2K8 y9 ])) & (((y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & y <>HIDDENR2 0NUMBERSK6 implies ( ex it be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =XBOOLE-0R4 y9) & it =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 *'ARYTM-2K8 x9 ])) & ((x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ( ex it be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & it =XBOOLE-0R4 y9 *'ARYTM-2K8 x9)) & ( not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & ( not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & x <>HIDDENR2 0NUMBERSK6) & ( not ((y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & y <>HIDDENR2 0NUMBERSK6) &  not (x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]))) implies ( ex it be ElementSUBSET-1M1-of REALNUMBERSK2 st it =XBOOLE-0R4 0NUMBERSK6)))))"
    proof-
      have "(x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2 implies ( ex IT be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & IT =XBOOLE-0R4 x9 *'ARYTM-2K8 y9)) & ((x inTARSKIR2 REAL+ARYTM-2K2 implies (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies (x <>HIDDENR2 0NUMBERSK6 implies ( ex IT be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & IT =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 *'ARYTM-2K8 y9 ])))) & ((y inTARSKIR2 REAL+ARYTM-2K2 implies (x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies (y <>HIDDENR2 0NUMBERSK6 implies ( ex IT be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =XBOOLE-0R4 y9) & IT =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 *'ARYTM-2K8 x9 ])))) & ((x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ( ex IT be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & IT =XBOOLE-0R4 y9 *'ARYTM-2K8 x9))) &  not (((( not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) &  not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) &  not x <>HIDDENR2 0NUMBERSK6)) &  not ((y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) &  not y <>HIDDENR2 0NUMBERSK6)) &  not (x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) & ( for VarFor1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not VarFor1 =XBOOLE-0R4 0NUMBERSK6)))))"
      proof(rule conjMI,rule conjMI,rule conjMI,rule conjMI)
        show "x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2 implies ( ex IT be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & IT =XBOOLE-0R4 x9 *'ARYTM-2K8 y9)"
        proof(rule impI)
          assume "x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2"
          then obtain x9 y9 where 
            [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and x9Def:"x9 = x" and
            [ty]:"y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and y9Def:"y9 = y"
             sorry
          obtain IT where 
            [ty]:"IT be ElementSUBSET-1M1-of REALNUMBERSK2" and ITDef:"IT = x9 *'ARYTM-2K8 y9"
            using arytm_0_th_1 sorry
          show " ex IT be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & IT =XBOOLE-0R4 x9 *'ARYTM-2K8 y9"
          proof(rule bexI[of _ "IT"])
            show " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & IT =XBOOLE-0R4 x9 *'ARYTM-2K8 y9"
            proof(rule bexI[of _ "x9"])
              show " ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & IT =XBOOLE-0R4 x9 *'ARYTM-2K8 y9"
              proof(rule bexI[of _ "y9"])
                show "(x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & IT =XBOOLE-0R4 x9 *'ARYTM-2K8 y9"
                   sorry
              qed "sorry"
            qed "sorry"
          qed "sorry"
        qed
        show "x inTARSKIR2 REAL+ARYTM-2K2 implies (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies (x <>HIDDENR2 0NUMBERSK6 implies ( ex IT be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & IT =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 *'ARYTM-2K8 y9 ])))"
        proof(rule impI,rule impI,rule impI)
          assume "x inTARSKIR2 REAL+ARYTM-2K2"
          then obtain x9 where 
            [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and x9Def:"x9 = x"
             sorry
          assume "y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          then obtain z y9 where
            [ty]:"z be objectHIDDENM1" "y9 be objectHIDDENM1" and 
            A22: "z inHIDDENR3 {TARSKIK1 0NUMBERSK6 }"and A23: "y9 inHIDDENR3 REAL+ARYTM-2K2"and A24: "y =HIDDENR1 [TARSKIK4 z,y9 ]"
            using zfmisc_1_th_84 sorry
          have 
            [ty]:"y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
            using A23 sorry
          have "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]"
            using A22 A24 tarski_def_1 sorry
          then have A25: "y9 <>HIDDENR2 0NUMBERSK6"
            using arytm_0_th_3 sorry
          assume "x <>HIDDENR2 0NUMBERSK6"
          then obtain IT where 
            [ty]:"IT be ElementSUBSET-1M1-of REALNUMBERSK2" and ITDef:"IT = [TARSKIK4 0NUMBERSK6,x9 *'ARYTM-2K8 y9 ]"
            using A25 arytm_0_th_2 arytm_1_th_2 sorry
          show " ex IT be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & IT =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 *'ARYTM-2K8 y9 ]"
          proof(rule bexI[of _ "IT"])
            show " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & IT =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 *'ARYTM-2K8 y9 ]"
            proof(rule bexI[of _ "x9"])
              show " ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & IT =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 *'ARYTM-2K8 y9 ]"
              proof(rule bexI[of _ "y9"])
                show "(x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & IT =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 *'ARYTM-2K8 y9 ]"
                  using A22 A24 tarski_def_1 sorry
              qed "sorry"
            qed "sorry"
          qed "sorry"
        qed
        show "y inTARSKIR2 REAL+ARYTM-2K2 implies (x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies (y <>HIDDENR2 0NUMBERSK6 implies ( ex IT be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =XBOOLE-0R4 y9) & IT =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 *'ARYTM-2K8 x9 ])))"
        proof(rule impI,rule impI,rule impI)
          assume "y inTARSKIR2 REAL+ARYTM-2K2"
          then obtain y9 where 
            [ty]:"y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and y9Def:"y9 = y"
             sorry
          assume "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          then obtain z x9 where
            [ty]:"z be objectHIDDENM1" "x9 be objectHIDDENM1" and 
            A26: "z inHIDDENR3 {TARSKIK1 0NUMBERSK6 }"and A27: "x9 inHIDDENR3 REAL+ARYTM-2K2"and A28: "x =HIDDENR1 [TARSKIK4 z,x9 ]"
            using zfmisc_1_th_84 sorry
          have 
            [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
            using A27 sorry
          have "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]"
            using A26 A28 tarski_def_1 sorry
          then have A29: "x9 <>HIDDENR2 0NUMBERSK6"
            using arytm_0_th_3 sorry
          assume "y <>HIDDENR2 0NUMBERSK6"
          then obtain IT where 
            [ty]:"IT be ElementSUBSET-1M1-of REALNUMBERSK2" and ITDef:"IT = [TARSKIK4 0NUMBERSK6,y9 *'ARYTM-2K8 x9 ]"
            using A29 arytm_0_th_2 arytm_1_th_2 sorry
          show " ex IT be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =XBOOLE-0R4 y9) & IT =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 *'ARYTM-2K8 x9 ]"
          proof(rule bexI[of _ "IT"])
            show " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =XBOOLE-0R4 y9) & IT =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 *'ARYTM-2K8 x9 ]"
            proof(rule bexI[of _ "x9"])
              show " ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =XBOOLE-0R4 y9) & IT =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 *'ARYTM-2K8 x9 ]"
              proof(rule bexI[of _ "y9"])
                show "(x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =XBOOLE-0R4 y9) & IT =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 *'ARYTM-2K8 x9 ]"
                  using A26 A28 tarski_def_1 sorry
              qed "sorry"
            qed "sorry"
          qed "sorry"
        qed
        show "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ( ex IT be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & IT =XBOOLE-0R4 y9 *'ARYTM-2K8 x9))"
        proof(rule impI,rule impI)
          assume "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          then obtain z1 x9 where
            [ty]:"z1 be objectHIDDENM1" "x9 be objectHIDDENM1" and 
            A30: "z1 inHIDDENR3 {TARSKIK1 0NUMBERSK6 }"and A31: "x9 inHIDDENR3 REAL+ARYTM-2K2"and A32: "x =HIDDENR1 [TARSKIK4 z1,x9 ]"
            using zfmisc_1_th_84 sorry
          have 
            [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
            using A31 sorry
          assume "y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          then obtain z2 y9 where
            [ty]:"z2 be objectHIDDENM1" "y9 be objectHIDDENM1" and 
            A33: "z2 inHIDDENR3 {TARSKIK1 0NUMBERSK6 }"and A34: "y9 inHIDDENR3 REAL+ARYTM-2K2"and A35: "y =HIDDENR1 [TARSKIK4 z2,y9 ]"
            using zfmisc_1_th_84 sorry
          have 
            [ty]:"y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
            using A34 sorry
          obtain IT where 
            [ty]:"IT be ElementSUBSET-1M1-of REALNUMBERSK2" and ITDef:"IT = y9 *'ARYTM-2K8 x9"
            using arytm_0_th_1 sorry
          show " ex IT be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & IT =XBOOLE-0R4 y9 *'ARYTM-2K8 x9"
          proof(rule bexI[of _ "IT"])
            show " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & IT =XBOOLE-0R4 y9 *'ARYTM-2K8 x9"
            proof(rule bexI[of _ "x9"])
              show " ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & IT =XBOOLE-0R4 y9 *'ARYTM-2K8 x9"
              proof(rule bexI[of _ "y9"])
                show "(x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & IT =XBOOLE-0R4 y9 *'ARYTM-2K8 x9"
                  using A30 A32 A33 A35 tarski_def_1 sorry
              qed "sorry"
            qed "sorry"
          qed "sorry"
        qed
        show " not (((( not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) &  not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) &  not x <>HIDDENR2 0NUMBERSK6)) &  not ((y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) &  not y <>HIDDENR2 0NUMBERSK6)) &  not (x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) & ( for VarFor1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not VarFor1 =XBOOLE-0R4 0NUMBERSK6))"
          using arytm_0_lm_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for it2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2 implies (( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & it1 =XBOOLE-0R4 x9 *'ARYTM-2K8 y9) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & it2 =XBOOLE-0R4 x9 *'ARYTM-2K8 y9) implies it1 =HIDDENR1 it2)) & (((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & x <>HIDDENR2 0NUMBERSK6 implies (( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & it1 =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 *'ARYTM-2K8 y9 ]) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & it2 =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 *'ARYTM-2K8 y9 ]) implies it1 =HIDDENR1 it2)) & (((y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & y <>HIDDENR2 0NUMBERSK6 implies (( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =XBOOLE-0R4 y9) & it1 =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 *'ARYTM-2K8 x9 ]) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =XBOOLE-0R4 y9) & it2 =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 *'ARYTM-2K8 x9 ]) implies it1 =HIDDENR1 it2)) & ((x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies (( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & it1 =XBOOLE-0R4 y9 *'ARYTM-2K8 x9) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & it2 =XBOOLE-0R4 y9 *'ARYTM-2K8 x9) implies it1 =HIDDENR1 it2)) & ( not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & ( not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & x <>HIDDENR2 0NUMBERSK6) & ( not ((y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & y <>HIDDENR2 0NUMBERSK6) &  not (x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]))) implies (it1 =XBOOLE-0R4 0NUMBERSK6 & it2 =XBOOLE-0R4 0NUMBERSK6 implies it1 =HIDDENR1 it2)))))"
    proof-
      have " for IT1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for IT2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds (((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & IT1 =XBOOLE-0R4 x9 *'ARYTM-2K8 y9)) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & IT2 =XBOOLE-0R4 x9 *'ARYTM-2K8 y9) implies IT1 =XBOOLE-0R4 IT2) & (((((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & x <>HIDDENR2 0NUMBERSK6) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & IT1 =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 *'ARYTM-2K8 y9 ])) & ( ex x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x99 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 ]) & IT2 =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 *'ARYTM-2K8 y99 ]) implies IT1 =XBOOLE-0R4 IT2) & (((((y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & y <>HIDDENR2 0NUMBERSK6) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =XBOOLE-0R4 y9) & IT1 =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 *'ARYTM-2K8 x9 ])) & ( ex x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 ] & y =XBOOLE-0R4 y99) & IT2 =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 *'ARYTM-2K8 x99 ]) implies IT1 =XBOOLE-0R4 IT2) & ((x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies (( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & (y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ] & IT1 =XBOOLE-0R4 y9 *'ARYTM-2K8 x9)) implies (( ex x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 ] & (y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 ] & IT2 =XBOOLE-0R4 y99 *'ARYTM-2K8 x99)) implies IT1 =XBOOLE-0R4 IT2))) &  not (((((( not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) &  not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) &  not x <>HIDDENR2 0NUMBERSK6)) &  not ((y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) &  not y <>HIDDENR2 0NUMBERSK6)) &  not (x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) & IT1 =XBOOLE-0R4 0NUMBERSK6) & IT2 =XBOOLE-0R4 0NUMBERSK6) &  not IT1 =HIDDENR1 IT2))))"
      proof(rule ballI,rule ballI,rule conjMI,rule conjMI,rule conjMI,rule conjMI)
        fix IT1 assume [ty]: "IT1 be ElementSUBSET-1M1-of REALNUMBERSK2"
        fix IT2 assume [ty]: "IT2 be ElementSUBSET-1M1-of REALNUMBERSK2"
        show "((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & IT1 =XBOOLE-0R4 x9 *'ARYTM-2K8 y9)) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & IT2 =XBOOLE-0R4 x9 *'ARYTM-2K8 y9) implies IT1 =XBOOLE-0R4 IT2"
           sorry
        show "(((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & x <>HIDDENR2 0NUMBERSK6) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & IT1 =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 *'ARYTM-2K8 y9 ])) & ( ex x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x99 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 ]) & IT2 =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 *'ARYTM-2K8 y99 ]) implies IT1 =XBOOLE-0R4 IT2"
          using xtuple_0_th_1 sorry
        show "(((y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & y <>HIDDENR2 0NUMBERSK6) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =XBOOLE-0R4 y9) & IT1 =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 *'ARYTM-2K8 x9 ])) & ( ex x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 ] & y =XBOOLE-0R4 y99) & IT2 =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 *'ARYTM-2K8 x99 ]) implies IT1 =XBOOLE-0R4 IT2"
          using xtuple_0_th_1 sorry
        show "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies (( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & (y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ] & IT1 =XBOOLE-0R4 y9 *'ARYTM-2K8 x9)) implies (( ex x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 ] & (y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 ] & IT2 =XBOOLE-0R4 y99 *'ARYTM-2K8 x99)) implies IT1 =XBOOLE-0R4 IT2))"
        proof(rule impMI ,rule impI,rule impI,rule impI)
          assume "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
            and "y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          assume Given: " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & (y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ] & IT1 =XBOOLE-0R4 y9 *'ARYTM-2K8 x9)"
          then obtain x9 y9 where
            [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
            A36: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]"and A37: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ] & IT1 =XBOOLE-0R4 y9 *'ARYTM-2K8 x9"
             sorry
          assume Given: " ex x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 ] & (y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 ] & IT2 =XBOOLE-0R4 y99 *'ARYTM-2K8 x99)"
          then obtain x99 y99 where
            [ty]:"x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
            A38: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 ]"and A39: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 ] & IT2 =XBOOLE-0R4 y99 *'ARYTM-2K8 x99"
             sorry
          have "x9 =XBOOLE-0R4 x99"
            using A36 A38 xtuple_0_th_1 sorry
          thus "IT1 =XBOOLE-0R4 IT2"
            using A37 A39 xtuple_0_th_1 sorry
        qed
        show " not (((((( not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) &  not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) &  not x <>HIDDENR2 0NUMBERSK6)) &  not ((y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) &  not y <>HIDDENR2 0NUMBERSK6)) &  not (x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) & IT1 =XBOOLE-0R4 0NUMBERSK6) & IT2 =XBOOLE-0R4 0NUMBERSK6) &  not IT1 =HIDDENR1 IT2)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
  (*consistency*)
    show " for it be ElementSUBSET-1M1-of REALNUMBERSK2 holds ((((((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & x <>HIDDENR2 0NUMBERSK6) implies (( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & it =XBOOLE-0R4 x9 *'ARYTM-2K8 y9) iff ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & it =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 *'ARYTM-2K8 y9 ]))) & ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & ((y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & y <>HIDDENR2 0NUMBERSK6) implies (( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & it =XBOOLE-0R4 x9 *'ARYTM-2K8 y9) iff ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =XBOOLE-0R4 y9) & it =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 *'ARYTM-2K8 x9 ])))) & ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & (x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies (( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & it =XBOOLE-0R4 x9 *'ARYTM-2K8 y9) iff ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & it =XBOOLE-0R4 y9 *'ARYTM-2K8 x9)))) & (((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & x <>HIDDENR2 0NUMBERSK6) & ((y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & y <>HIDDENR2 0NUMBERSK6) implies (( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & it =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 *'ARYTM-2K8 y9 ]) iff ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =XBOOLE-0R4 y9) & it =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 *'ARYTM-2K8 x9 ])))) & (((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & x <>HIDDENR2 0NUMBERSK6) & (x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies (( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & it =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 *'ARYTM-2K8 y9 ]) iff ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & it =XBOOLE-0R4 y9 *'ARYTM-2K8 x9)))) & (((y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & y <>HIDDENR2 0NUMBERSK6) & (x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies (( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =XBOOLE-0R4 y9) & it =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 *'ARYTM-2K8 x9 ]) iff ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & it =XBOOLE-0R4 y9 *'ARYTM-2K8 x9)))"
      using arytm_0_th_5 xboole_0_th_3 sorry
qed "sorry"

mtheorem ARYTM_0K2_commutativity:
" for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds  *ARYTM-0K2(x,y) =HIDDENR1  *ARYTM-0K2(y,x)"
proof-
  have " for it be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds it =HIDDENR1  *ARYTM-0K2(x,y) implies it =HIDDENR1  *ARYTM-0K2(y,x)"
  proof-
    have " for it be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2 implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & it =XBOOLE-0R4 x9 *'ARYTM-2K8 y9)) & (((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & x <>HIDDENR2 0NUMBERSK6 implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & it =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 *'ARYTM-2K8 y9 ])) & (((y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & y <>HIDDENR2 0NUMBERSK6 implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =XBOOLE-0R4 y9) & it =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 *'ARYTM-2K8 x9 ])) & ((x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & it =XBOOLE-0R4 y9 *'ARYTM-2K8 x9)) & ( not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & ( not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & x <>HIDDENR2 0NUMBERSK6) & ( not ((y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & y <>HIDDENR2 0NUMBERSK6) &  not (x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]))) implies it =XBOOLE-0R4 0NUMBERSK6)))) implies (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 REAL+ARYTM-2K2 implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (y =XBOOLE-0R4 x9 & x =XBOOLE-0R4 y9) & it =XBOOLE-0R4 x9 *'ARYTM-2K8 y9)) & (((y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & y <>HIDDENR2 0NUMBERSK6 implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (y =XBOOLE-0R4 x9 & x =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & it =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 *'ARYTM-2K8 y9 ])) & (((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & x <>HIDDENR2 0NUMBERSK6 implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (y =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & x =XBOOLE-0R4 y9) & it =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 *'ARYTM-2K8 x9 ])) & ((y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (y =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & x =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & it =XBOOLE-0R4 y9 *'ARYTM-2K8 x9)) & ( not (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 REAL+ARYTM-2K2) & ( not ((y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & y <>HIDDENR2 0NUMBERSK6) & ( not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & x <>HIDDENR2 0NUMBERSK6) &  not (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]))) implies it =XBOOLE-0R4 0NUMBERSK6))))"
       sorry
    thus " ?thesis "
      using arytm_0_def_2 sorry
  qed
  thus " ?thesis "
     sorry
qed

reserve x, y for "ElementSUBSET-1M1-of REALNUMBERSK2"
mdef arytm_0_def_3 ("oppARYTM-0K3  _ " [228]228 ) where
  mlet "x be ElementSUBSET-1M1-of REALNUMBERSK2"
"func oppARYTM-0K3 x \<rightarrow> ElementSUBSET-1M1-of REALNUMBERSK2 means
  \<lambda>it. +ARYTM-0K1(x,it) =XBOOLE-0R4 0NUMBERSK6"
proof-
  (*existence*)
    show " ex it be ElementSUBSET-1M1-of REALNUMBERSK2 st +ARYTM-0K1(x,it) =XBOOLE-0R4 0NUMBERSK6"
    proof-
      have " ex tVar25 be ElementSUBSET-1M1-of REALNUMBERSK2 st +ARYTM-0K1(tVar25,tVar25) =XBOOLE-0R4 0NUMBERSK6"
      proof-
        obtain z9 where 
          [ty]:"z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and z9Def:"z9 = 0NUMBERSK6"
          using arytm_2_th_20 sorry
        have A1: "x inTARSKIR2 REAL+ARYTM-2K2 \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          using xboole_0_def_5 sorry
        show " ex tVar25 be ElementSUBSET-1M1-of REALNUMBERSK2 st +ARYTM-0K1(tVar25,tVar25) =XBOOLE-0R4 0NUMBERSK6"
        proof-
          have cases: "(x =XBOOLE-0R4 0NUMBERSK6 or x inTARSKIR2 REAL+ARYTM-2K2 & x <>HIDDENR2 0NUMBERSK6) or x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
            using A1 xboole_0_def_3 sorry
          have case1: "x =XBOOLE-0R4 0NUMBERSK6 implies ( ex tVar25 be ElementSUBSET-1M1-of REALNUMBERSK2 st +ARYTM-0K1(tVar25,tVar25) =XBOOLE-0R4 0NUMBERSK6)"
          proof(rule impI)
            assume A2: "x =XBOOLE-0R4 0NUMBERSK6"
            then obtain x9 where 
              [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and x9Def:"x9 = x"
              using arytm_2_th_20 sorry
            show " ex tVar25 be ElementSUBSET-1M1-of REALNUMBERSK2 st +ARYTM-0K1(tVar25,tVar25) =XBOOLE-0R4 0NUMBERSK6"
            proof(rule bexI[of _ "x"])
              have "x9 +ARYTM-2K7 x9 =XBOOLE-0R4 0NUMBERSK6"
                using A2 arytm_2_def_8 sorry
              thus "+ARYTM-0K1(x,x) =XBOOLE-0R4 0NUMBERSK6"
                using arytm_0_def_1 arytm_0_lm_3 sorry
            qed "sorry"
          qed
          have case2: "x inTARSKIR2 REAL+ARYTM-2K2 & x <>HIDDENR2 0NUMBERSK6 implies ( ex tVar26 be ElementSUBSET-1M1-of REALNUMBERSK2 st +ARYTM-0K1(x,tVar26) =XBOOLE-0R4 0NUMBERSK6)"
          proof(rule impMI ,rule impI)
            assume A3: "x inTARSKIR2 REAL+ARYTM-2K2"
              and A4: "x <>HIDDENR2 0NUMBERSK6"
            have A5: "[TARSKIK4 0NUMBERSK6,x ] <>HIDDENR2 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ]"
              using A4 xtuple_0_th_1 sorry
            have "0NUMBERSK6 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
              using tarski_def_1 sorry
            then have A6: "[TARSKIK4 0NUMBERSK6,x ] inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
              using A3 zfmisc_1_th_87 sorry
            then have "[TARSKIK4 0NUMBERSK6,x ] inHIDDENR3 REAL+ARYTM-2K2 \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
              using xboole_0_def_3 sorry
            then obtain y where 
              [ty]:"y be ElementSUBSET-1M1-of REALNUMBERSK2" and yDef:"y = [TARSKIK4 0NUMBERSK6,x ]"
              using A5 zfmisc_1_th_56 sorry
            obtain x9 where 
              [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and x9Def:"x9 = x"
              using A3 sorry
            have A7: "x9 <='ARYTM-2R1 x9"
               sorry
            show " ex tVar26 be ElementSUBSET-1M1-of REALNUMBERSK2 st +ARYTM-0K1(x,tVar26) =XBOOLE-0R4 0NUMBERSK6"
            proof(rule bexI[of _ "y"])
              have "z9 +ARYTM-2K7 x9 =XBOOLE-0R4 x9"
                using arytm_2_def_8 sorry
              then have "z9 =XBOOLE-0R4 x9 -'ARYTM-1K1 x9"
                using A7 arytm_1_def_1 sorry
              then have "0NUMBERSK6 =XBOOLE-0R4 x9 -ARYTM-1K2 x9"
                using A7 arytm_1_def_2 sorry
              thus "+ARYTM-0K1(x,y) =XBOOLE-0R4 0NUMBERSK6"
                using A6 arytm_0_def_1 arytm_0_lm_3 sorry
            qed "sorry"
          qed
          have case3: "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ( ex tVar27 be ElementSUBSET-1M1-of REALNUMBERSK2 st +ARYTM-0K1(x,tVar27) =XBOOLE-0R4 0NUMBERSK6)"
          proof(rule impI)
            assume A8: "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
            then obtain a b where
              [ty]:"a be objectHIDDENM1" "b be objectHIDDENM1" and 
              A9: "a inHIDDENR3 {TARSKIK1 0NUMBERSK6 }"and A10: "b inHIDDENR3 REAL+ARYTM-2K2"and A11: "x =HIDDENR1 [TARSKIK4 a,b ]"
              using zfmisc_1_th_84 sorry
            obtain y where 
              [ty]:"y be ElementSUBSET-1M1-of REALNUMBERSK2" and yDef:"y = b"
              using A10 arytm_0_th_1 sorry
            show " ex tVar27 be ElementSUBSET-1M1-of REALNUMBERSK2 st +ARYTM-0K1(x,tVar27) =XBOOLE-0R4 0NUMBERSK6"
            proof(rule bexI[of _ "y"])
              have "(((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & 0NUMBERSK6 =XBOOLE-0R4 x9 +ARYTM-2K7 y9) or (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & 0NUMBERSK6 =XBOOLE-0R4 x9 -ARYTM-1K2 y9))) or (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & (y =XBOOLE-0R4 y9 & 0NUMBERSK6 =XBOOLE-0R4 y9 -ARYTM-1K2 x9)))) or (( not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) &  not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) & (( not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) &  not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & 0NUMBERSK6 =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 +ARYTM-2K7 x9 ]))"
              proof-
                show "(((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & 0NUMBERSK6 =XBOOLE-0R4 x9 +ARYTM-2K7 y9) or (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & 0NUMBERSK6 =XBOOLE-0R4 x9 -ARYTM-1K2 y9))) or (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & (y =XBOOLE-0R4 y9 & 0NUMBERSK6 =XBOOLE-0R4 y9 -ARYTM-1K2 x9)))) or (( not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) &  not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) & (( not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) &  not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & 0NUMBERSK6 =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 +ARYTM-2K7 x9 ]))"
                proof-
                  have cases: "((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2 or x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) or y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) or ( not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) &  not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
                     sorry
                  have case1: "x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2 implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & 0NUMBERSK6 =XBOOLE-0R4 x9 +ARYTM-2K7 y9)"
                  proof(rule impI)
                    assume "x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2"
                    thus " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & 0NUMBERSK6 =XBOOLE-0R4 x9 +ARYTM-2K7 y9"
                      using A8 arytm_0_th_5 xboole_0_th_3 sorry
                  qed
                  have case2: "x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & 0NUMBERSK6 =XBOOLE-0R4 x9 -ARYTM-1K2 y9)"
                  proof(rule impI)
                    assume "x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                    thus " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & 0NUMBERSK6 =XBOOLE-0R4 x9 -ARYTM-1K2 y9"
                      using A10 arytm_0_th_5 xboole_0_th_3 sorry
                  qed
                  have case3: "y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & (y =XBOOLE-0R4 y9 & 0NUMBERSK6 =XBOOLE-0R4 y9 -ARYTM-1K2 x9))"
                  proof(rule impI)
                    assume "y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                    obtain x9 y9 where 
                      [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and x9Def:"x9 = b" and
                      [ty]:"y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and y9Def:"y9 = y"
                      using A10 sorry
                    show " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & (y =XBOOLE-0R4 y9 & 0NUMBERSK6 =XBOOLE-0R4 y9 -ARYTM-1K2 x9)"
                    proof(rule bexI[of _ "x9"])
                      show " ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & (y =XBOOLE-0R4 y9 & 0NUMBERSK6 =XBOOLE-0R4 y9 -ARYTM-1K2 x9)"
                      proof(rule bexI[of _ "y9"],rule conjMI,rule conjMI)
                        show "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]"
                          using A9 A11 tarski_def_1 sorry
                        show "y =XBOOLE-0R4 y9"
                           sorry
                        show "0NUMBERSK6 =XBOOLE-0R4 y9 -ARYTM-1K2 x9"
                          using arytm_1_th_18 sorry
                      qed "sorry"
                    qed "sorry"
                  qed
                  have case4: "( not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) &  not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & 0NUMBERSK6 =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 +ARYTM-2K7 x9 ])"
                  proof(rule impI)
                    assume "( not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) &  not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
                    thus " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & 0NUMBERSK6 =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 +ARYTM-2K7 x9 ]"
                      using A8 A10 sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 case3 case4 sorry
                qed
              qed
              thus "+ARYTM-0K1(x,y) =XBOOLE-0R4 0NUMBERSK6"
                using arytm_0_def_1 arytm_0_lm_3 sorry
            qed "sorry"
          qed
          show " ?thesis "
            using cases case1 case2 case3 sorry
        qed
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for it2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds +ARYTM-0K1(x,it1) =XBOOLE-0R4 0NUMBERSK6 & +ARYTM-0K1(x,it2) =XBOOLE-0R4 0NUMBERSK6 implies it1 =HIDDENR1 it2"
    proof-
      have " for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for z be ElementSUBSET-1M1-of REALNUMBERSK2 holds +ARYTM-0K1(x,y) =XBOOLE-0R4 0NUMBERSK6 & +ARYTM-0K1(x,z) =XBOOLE-0R4 0NUMBERSK6 implies y =HIDDENR1 z"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix y assume [ty]: "y be ElementSUBSET-1M1-of REALNUMBERSK2"
        fix z assume [ty]: "z be ElementSUBSET-1M1-of REALNUMBERSK2"
        assume A12: "+ARYTM-0K1(x,y) =XBOOLE-0R4 0NUMBERSK6"
          and A13: "+ARYTM-0K1(x,z) =XBOOLE-0R4 0NUMBERSK6"
        show "y =HIDDENR1 z"
        proof-
          have cases: "((((((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & z inTARSKIR2 REAL+ARYTM-2K2 or x inTARSKIR2 REAL+ARYTM-2K2 & (y inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) or x inTARSKIR2 REAL+ARYTM-2K2 & (z inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) or x inTARSKIR2 REAL+ARYTM-2K2 & (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) or z inTARSKIR2 REAL+ARYTM-2K2 & (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) or ( not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) &  not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) or ( not (x inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 REAL+ARYTM-2K2) &  not (x inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not (z inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
             sorry
          have case1: "(x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & z inTARSKIR2 REAL+ARYTM-2K2 implies y =HIDDENR1 z"
          proof(rule impI)
            assume "(x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & z inTARSKIR2 REAL+ARYTM-2K2"
            then have "( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & 0NUMBERSK6 =XBOOLE-0R4 x9 +ARYTM-2K7 y9) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & z =XBOOLE-0R4 y9) & 0NUMBERSK6 =XBOOLE-0R4 x9 +ARYTM-2K7 y9)"
              using A12 A13 arytm_0_def_1 sorry
            thus "y =HIDDENR1 z"
              using arytm_2_th_11 sorry
          qed
          have case2: "x inTARSKIR2 REAL+ARYTM-2K2 & (y inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies y =HIDDENR1 z"
          proof(rule impMI ,rule impMI ,rule impI)
            assume A14: "x inTARSKIR2 REAL+ARYTM-2K2"
              and A15: "y inTARSKIR2 REAL+ARYTM-2K2"
              and A16: "z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
            obtain x99 y99 where
              [ty]:"x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
              A17: "x =XBOOLE-0R4 x99"and A18: "z =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 ] & 0NUMBERSK6 =XBOOLE-0R4 x99 -ARYTM-1K2 y99"
              using A13 A14 A16 arytm_0_def_1 sorry
            have " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & 0NUMBERSK6 =XBOOLE-0R4 x9 +ARYTM-2K7 y9"
              using A12 A14 A15 arytm_0_def_1 sorry
            then have A19: "x99 =XBOOLE-0R4 0NUMBERSK6"
              using A17 arytm_2_th_5 sorry
            have "[TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] inHIDDENR3 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
              using tarski_def_1 sorry
            then have A20: " not [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] inHIDDENR3 REALNUMBERSK2"
              using xboole_0_def_5 sorry
            have "z inTARSKIR2 REALNUMBERSK2"
               sorry
            thus "y =HIDDENR1 z"
              using A18 A19 A20 arytm_1_th_19 sorry
          qed
          have case3: "x inTARSKIR2 REAL+ARYTM-2K2 & (z inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies y =HIDDENR1 z"
          proof(rule impMI ,rule impMI ,rule impI)
            assume A21: "x inTARSKIR2 REAL+ARYTM-2K2"
              and A22: "z inTARSKIR2 REAL+ARYTM-2K2"
              and A23: "y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
            obtain x99 y9 where
              [ty]:"x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
              A24: "x =XBOOLE-0R4 x99"and A25: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ] & 0NUMBERSK6 =XBOOLE-0R4 x99 -ARYTM-1K2 y9"
              using A12 A21 A23 arytm_0_def_1 sorry
            have " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & z =XBOOLE-0R4 z9) & 0NUMBERSK6 =XBOOLE-0R4 x9 +ARYTM-2K7 z9"
              using A13 A21 A22 arytm_0_def_1 sorry
            then have A26: "x99 =XBOOLE-0R4 0NUMBERSK6"
              using A24 arytm_2_th_5 sorry
            have "[TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] inHIDDENR3 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
              using tarski_def_1 sorry
            then have A27: " not [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] inHIDDENR3 REALNUMBERSK2"
              using xboole_0_def_5 sorry
            have "y inTARSKIR2 REALNUMBERSK2"
               sorry
            thus "y =HIDDENR1 z"
              using A25 A26 A27 arytm_1_th_19 sorry
          qed
          have case4: "x inTARSKIR2 REAL+ARYTM-2K2 & (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies y =HIDDENR1 z"
          proof(rule impMI ,rule impMI ,rule impI)
            assume A28: "x inTARSKIR2 REAL+ARYTM-2K2"
              and A29: "y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
              and A30: "z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
            obtain x99 z9 where
              [ty]:"x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
              A31: "x =XBOOLE-0R4 x99"and A32: "z =HIDDENR1 [TARSKIK4 0NUMBERSK6,z9 ]"and A33: "0NUMBERSK6 =XBOOLE-0R4 x99 -ARYTM-1K2 z9"
              using A13 A28 A30 arytm_0_def_1 sorry
            obtain x9 y9 where
              [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
              A34: "x =XBOOLE-0R4 x9"and A35: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]"and A36: "0NUMBERSK6 =XBOOLE-0R4 x9 -ARYTM-1K2 y9"
              using A12 A28 A29 arytm_0_def_1 sorry
            have "y9 =HIDDENR1 x9"
              using A36 arytm_0_th_6 sorry
            also have "... = z9"
              using A34 A31 A33 arytm_0_th_6 sorry
            finally have "y9 =HIDDENR1 z9"
               sorry
            thus "y =HIDDENR1 z"
              using A35 A32 sorry
          qed
          have case5: "z inTARSKIR2 REAL+ARYTM-2K2 & (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies y =HIDDENR1 z"
          proof(rule impMI ,rule impMI ,rule impI)
            assume A37: "z inTARSKIR2 REAL+ARYTM-2K2"
              and A38: "y inTARSKIR2 REAL+ARYTM-2K2"
              and A39: "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
            obtain x99 z9 where
              [ty]:"x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
              A40: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 ]"and A41: "z =XBOOLE-0R4 z9"and A42: "0NUMBERSK6 =XBOOLE-0R4 z9 -ARYTM-1K2 x99"
              using A13 A37 A39 arytm_0_def_1 sorry
            obtain x9 y9 where
              [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
              A43: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]"and A44: "y =XBOOLE-0R4 y9"and A45: "0NUMBERSK6 =XBOOLE-0R4 y9 -ARYTM-1K2 x9"
              using A12 A38 A39 arytm_0_def_1 sorry
            have "x9 =XBOOLE-0R4 x99"
              using A43 A40 xtuple_0_th_1 sorry
            then have "z9 =HIDDENR1 x9"
              using A42 arytm_0_th_6 sorry
            also have "... = y9"
              using A45 arytm_0_th_6 sorry
            finally have "z9 =HIDDENR1 y9"
               sorry
            thus "y =HIDDENR1 z"
              using A44 A41 sorry
          qed
          have case6: "( not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) &  not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies y =HIDDENR1 z"
          proof(rule impI)
            assume "( not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) &  not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
            then have " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & 0NUMBERSK6 =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 +ARYTM-2K7 y9 ]"
              using A12 arytm_0_def_1 sorry
            thus "y =HIDDENR1 z"
               sorry
          qed
          have case7: "( not (x inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 REAL+ARYTM-2K2) &  not (x inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not (z inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies y =HIDDENR1 z"
          proof(rule impI)
            assume "( not (x inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 REAL+ARYTM-2K2) &  not (x inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not (z inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
            then have " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & z =HIDDENR1 [TARSKIK4 0NUMBERSK6,z9 ]) & 0NUMBERSK6 =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 +ARYTM-2K7 z9 ]"
              using A13 arytm_0_def_1 sorry
            thus "y =HIDDENR1 z"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 case4 case5 case6 case7 sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem ARYTM_0K3_involutiveness:
" for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds oppARYTM-0K3 (oppARYTM-0K3 x) =HIDDENR1 x"
proof-
  have " for it be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds it =HIDDENR1 oppARYTM-0K3 x implies x =HIDDENR1 oppARYTM-0K3 it"
  proof-
    have " for it be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds +ARYTM-0K1(x,it) =XBOOLE-0R4 0NUMBERSK6 implies +ARYTM-0K1(it,x) =XBOOLE-0R4 0NUMBERSK6"
       sorry
    thus " ?thesis "
      using arytm_0_def_3 sorry
  qed
  thus " ?thesis "
     sorry
qed

mdef arytm_0_def_4 ("invARYTM-0K4  _ " [164]164 ) where
  mlet "x be ElementSUBSET-1M1-of REALNUMBERSK2"
"func invARYTM-0K4 x \<rightarrow> ElementSUBSET-1M1-of REALNUMBERSK2 means
  \<lambda>it.  *ARYTM-0K2(x,it) =XBOOLE-0R4 \<one>\<^sub>M if x <>HIDDENR2 0NUMBERSK6 otherwise \<lambda>it. it =XBOOLE-0R4 0NUMBERSK6"
proof-
  (*existence*)
    show "(x <>HIDDENR2 0NUMBERSK6 implies ( ex it be ElementSUBSET-1M1-of REALNUMBERSK2 st  *ARYTM-0K2(x,it) =XBOOLE-0R4 \<one>\<^sub>M)) & ( not x <>HIDDENR2 0NUMBERSK6 implies ( ex it be ElementSUBSET-1M1-of REALNUMBERSK2 st it =XBOOLE-0R4 0NUMBERSK6))"
    proof-
      have "(x <>HIDDENR2 0NUMBERSK6 implies ( ex y be ElementSUBSET-1M1-of REALNUMBERSK2 st  *ARYTM-0K2(x,y) =XBOOLE-0R4 \<one>\<^sub>M)) &  not (x <>HIDDENR2 0NUMBERSK6 & ( for VarFor1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not VarFor1 =XBOOLE-0R4 0NUMBERSK6))"
      proof(rule conjMI)
        show "x <>HIDDENR2 0NUMBERSK6 implies ( ex y be ElementSUBSET-1M1-of REALNUMBERSK2 st  *ARYTM-0K2(x,y) =XBOOLE-0R4 \<one>\<^sub>M)"
        proof-
          have "x <>HIDDENR2 0NUMBERSK6 implies ( ex tVar30 be ElementSUBSET-1M1-of REALNUMBERSK2 st  *ARYTM-0K2(x,tVar30) =XBOOLE-0R4 \<one>\<^sub>M)"
          proof(rule impI)
            have A46: "x inTARSKIR2 REAL+ARYTM-2K2 \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
              using xboole_0_def_5 sorry
            assume A47: "x <>HIDDENR2 0NUMBERSK6"
            show " ex tVar30 be ElementSUBSET-1M1-of REALNUMBERSK2 st  *ARYTM-0K2(x,tVar30) =XBOOLE-0R4 \<one>\<^sub>M"
            proof-
              have cases: "x inTARSKIR2 REAL+ARYTM-2K2 or x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                using A46 xboole_0_def_3 sorry
              have case1: "x inTARSKIR2 REAL+ARYTM-2K2 implies ( ex tVar30 be ElementSUBSET-1M1-of REALNUMBERSK2 st  *ARYTM-0K2(x,tVar30) =XBOOLE-0R4 \<one>\<^sub>M)"
              proof(rule impI)
                assume "x inTARSKIR2 REAL+ARYTM-2K2"
                then obtain x9 where 
                  [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and x9Def:"x9 = x"
                   sorry
                obtain jj where 
                  [ty]:"jj be ElementSUBSET-1M1-of REALNUMBERSK2" and jjDef:"jj = \<one>\<^sub>M"
                  using numbers_th_19 sorry
                obtain y9 where
                  [ty]:"y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
                  A48: "x9 *'ARYTM-2K8 y9 =XBOOLE-0R4 jj"
                  using A47 arytm_2_th_14 sorry
                obtain y where 
                  [ty]:"y be ElementSUBSET-1M1-of REALNUMBERSK2" and yDef:"y = y9"
                  using arytm_0_th_1 sorry
                show " ex tVar30 be ElementSUBSET-1M1-of REALNUMBERSK2 st  *ARYTM-0K2(x,tVar30) =XBOOLE-0R4 \<one>\<^sub>M"
                proof(rule bexI[of _ "y"])
                  show " *ARYTM-0K2(x,y) =XBOOLE-0R4 \<one>\<^sub>M"
                    using A48 arytm_0_def_2 sorry
                qed "sorry"
              qed
              have case2: "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ( ex tVar31 be ElementSUBSET-1M1-of REALNUMBERSK2 st  *ARYTM-0K2(x,tVar31) =XBOOLE-0R4 \<one>\<^sub>M)"
              proof(rule impI)
                assume A49: "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                have " not x inTARSKIR2 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
                  using xboole_0_def_5 sorry
                then have A50: "x <>HIDDENR2 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ]"
                  using tarski_def_1 sorry
                obtain x1 x2 where
                  [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" and 
                  "x1 inHIDDENR3 {TARSKIK1 0NUMBERSK6 }"and A51: "x2 inHIDDENR3 REAL+ARYTM-2K2"and A52: "x =HIDDENR1 [TARSKIK4 x1,x2 ]"
                  using A49 zfmisc_1_th_84 sorry
                have 
                  [ty]:"x2 be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
                  using A51 sorry
                have "x1 inHIDDENR3 {TARSKIK1 0NUMBERSK6 }"
                  using A49 A52 zfmisc_1_th_87 sorry
                then have "x2 <>HIDDENR2 0NUMBERSK6"
                  using A52 A50 tarski_def_1 sorry
                then obtain y2 where
                  [ty]:"y2 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
                  A53: "x2 *'ARYTM-2K8 y2 =XBOOLE-0R4 \<one>\<^sub>M"
                  using arytm_2_th_14 sorry
                have A54: "[TARSKIK4 0NUMBERSK6,y2 ] inHIDDENR3 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } implies  False "
                proof(rule impI)
                  assume "[TARSKIK4 0NUMBERSK6,y2 ] inHIDDENR3 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
                  then have "[TARSKIK4 0NUMBERSK6,y2 ] =HIDDENR1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ]"
                    using tarski_def_1 sorry
                  then have "y2 =XBOOLE-0R4 0NUMBERSK6"
                    using xtuple_0_th_1 sorry
                  thus " False "
                    using A53 arytm_2_th_4 sorry
                qed
                have A55: "[TARSKIK4 0NUMBERSK6,y2 ] inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                  using arytm_0_lm_1 sorry
                then have "[TARSKIK4 0NUMBERSK6,y2 ] inHIDDENR3 REAL+ARYTM-2K2 \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                  using xboole_0_def_3 sorry
                then obtain y where 
                  [ty]:"y be ElementSUBSET-1M1-of REALNUMBERSK2" and yDef:"y = [TARSKIK4 0NUMBERSK6,y2 ]"
                  using A54 xboole_0_def_5 sorry
                show " ex tVar31 be ElementSUBSET-1M1-of REALNUMBERSK2 st  *ARYTM-0K2(x,tVar31) =XBOOLE-0R4 \<one>\<^sub>M"
                proof(rule bexI[of _ "y"])
                  obtain x9 y9 where
                    [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
                    A56: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]"and A57: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]"and A58: " *ARYTM-0K2(x,y) =XBOOLE-0R4 y9 *'ARYTM-2K8 x9"
                    using A49 A55 arytm_0_def_2 sorry
                  have "y9 =XBOOLE-0R4 y2"
                    using A57 xtuple_0_th_1 sorry
                  thus " *ARYTM-0K2(x,y) =XBOOLE-0R4 \<one>\<^sub>M"
                    using A52 A53 A56 A58 xtuple_0_th_1 sorry
                qed "sorry"
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus " ?thesis "
             sorry
        qed
        show " not (x <>HIDDENR2 0NUMBERSK6 & ( for VarFor1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not VarFor1 =XBOOLE-0R4 0NUMBERSK6))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for it2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds (x <>HIDDENR2 0NUMBERSK6 implies ( *ARYTM-0K2(x,it1) =XBOOLE-0R4 \<one>\<^sub>M &  *ARYTM-0K2(x,it2) =XBOOLE-0R4 \<one>\<^sub>M implies it1 =HIDDENR1 it2)) & ( not x <>HIDDENR2 0NUMBERSK6 implies (it1 =XBOOLE-0R4 0NUMBERSK6 & it2 =XBOOLE-0R4 0NUMBERSK6 implies it1 =HIDDENR1 it2))"
    proof-
      have " for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for z be ElementSUBSET-1M1-of REALNUMBERSK2 holds ((x <>HIDDENR2 0NUMBERSK6 &  *ARYTM-0K2(x,y) =XBOOLE-0R4 \<one>\<^sub>M) &  *ARYTM-0K2(x,z) =XBOOLE-0R4 \<one>\<^sub>M implies y =XBOOLE-0R4 z) &  not (((x <>HIDDENR2 0NUMBERSK6 & y =XBOOLE-0R4 0NUMBERSK6) & z =XBOOLE-0R4 0NUMBERSK6) &  not y =HIDDENR1 z)"
      proof(rule ballI,rule ballI,rule conjMI)
        fix y assume [ty]: "y be ElementSUBSET-1M1-of REALNUMBERSK2"
        fix z assume [ty]: "z be ElementSUBSET-1M1-of REALNUMBERSK2"
        show "(x <>HIDDENR2 0NUMBERSK6 &  *ARYTM-0K2(x,y) =XBOOLE-0R4 \<one>\<^sub>M) &  *ARYTM-0K2(x,z) =XBOOLE-0R4 \<one>\<^sub>M implies y =XBOOLE-0R4 z"
        proof-
          have "x <>HIDDENR2 0NUMBERSK6 & ( *ARYTM-0K2(x,y) =XBOOLE-0R4 \<one>\<^sub>M &  *ARYTM-0K2(x,z) =XBOOLE-0R4 \<one>\<^sub>M) implies y =XBOOLE-0R4 z"
          proof(rule impMI ,rule impMI ,rule impI)
            assume A59: "x <>HIDDENR2 0NUMBERSK6"
              and A60: " *ARYTM-0K2(x,y) =XBOOLE-0R4 \<one>\<^sub>M"
              and A61: " *ARYTM-0K2(x,z) =XBOOLE-0R4 \<one>\<^sub>M"
            have A62: " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds  *ARYTM-0K2(x,y) =XBOOLE-0R4 \<one>\<^sub>M implies x <>HIDDENR2 0NUMBERSK6"
            proof-
              have " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds  *ARYTM-0K2(x,y) =XBOOLE-0R4 \<one>\<^sub>M & x =XBOOLE-0R4 0NUMBERSK6 implies  False "
              proof(rule ballI,rule ballI,rule impMI ,rule impI)
                fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
                fix y assume [ty]: "y be ElementSUBSET-1M1-of REALNUMBERSK2"
                assume A63: " *ARYTM-0K2(x,y) =XBOOLE-0R4 \<one>\<^sub>M"
                  and A64: "x =XBOOLE-0R4 0NUMBERSK6"
                have A65: " not x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                  using A64 arytm_0_th_5 arytm_2_th_20 xboole_0_th_3 sorry
                have A66: "y inTARSKIR2 REAL+ARYTM-2K2 \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                  using xboole_0_def_5 sorry
                show " False "
                proof-
                  have cases: "y inTARSKIR2 REAL+ARYTM-2K2 or y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                    using A66 xboole_0_def_3 sorry
                  have case1: "y inTARSKIR2 REAL+ARYTM-2K2 implies  False "
                  proof(rule impI)
                    assume "y inTARSKIR2 REAL+ARYTM-2K2"
                    then have " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & \<one>\<^sub>M =XBOOLE-0R4 x9 *'ARYTM-2K8 y9"
                      using A63 A64 arytm_0_def_2 arytm_2_th_20 sorry
                    thus " False "
                      using A64 arytm_2_th_4 sorry
                  qed
                  have case2: "y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies  False "
                  proof(rule impI)
                    assume "y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                    then have " not y inTARSKIR2 REAL+ARYTM-2K2"
                      using arytm_0_th_5 xboole_0_th_3 sorry
                    thus " False "
                      using A63 A64 A65 arytm_0_def_2 sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            then have A67: "y <>HIDDENR2 0NUMBERSK6"
              using A60 sorry
            have A68: "z <>HIDDENR2 0NUMBERSK6"
              using A61 A62 sorry
            show "y =XBOOLE-0R4 z"
            proof-
              have cases: "(((((((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & z inTARSKIR2 REAL+ARYTM-2K2 or x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) or x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) or x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inTARSKIR2 REAL+ARYTM-2K2) or x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & z inTARSKIR2 REAL+ARYTM-2K2) or x inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) or (( not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) &  not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & x <>HIDDENR2 0NUMBERSK6)) &  not ((y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & y <>HIDDENR2 0NUMBERSK6)) &  not (x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) or (( not (x inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 REAL+ARYTM-2K2) &  not ((x inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & x <>HIDDENR2 0NUMBERSK6)) &  not ((z inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & z <>HIDDENR2 0NUMBERSK6)) &  not (x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
                 sorry
              have case1: "(x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & z inTARSKIR2 REAL+ARYTM-2K2 implies y =XBOOLE-0R4 z"
              proof(rule impI)
                assume "(x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & z inTARSKIR2 REAL+ARYTM-2K2"
                then have "( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & \<one>\<^sub>M =XBOOLE-0R4 x9 *'ARYTM-2K8 y9) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & z =XBOOLE-0R4 y9) & \<one>\<^sub>M =XBOOLE-0R4 x9 *'ARYTM-2K8 y9)"
                  using A60 A61 arytm_0_def_2 sorry
                thus "y =XBOOLE-0R4 z"
                  using A59 arytm_0_th_7 sorry
              qed
              have case2: "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies y =XBOOLE-0R4 z"
              proof(rule impMI ,rule impMI ,rule impI)
                assume A69: "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                  and A70: "y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                  and A71: "z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                obtain x9 y9 where
                  [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
                  A72: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]"and A73: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ] & \<one>\<^sub>M =XBOOLE-0R4 y9 *'ARYTM-2K8 x9"
                  using A60 A69 A70 arytm_0_def_2 sorry
                obtain x99 z9 where
                  [ty]:"x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
                  A74: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 ]"and A75: "z =HIDDENR1 [TARSKIK4 0NUMBERSK6,z9 ] & \<one>\<^sub>M =XBOOLE-0R4 z9 *'ARYTM-2K8 x99"
                  using A61 A69 A71 arytm_0_def_2 sorry
                have "x9 =XBOOLE-0R4 x99"
                  using A72 A74 xtuple_0_th_1 sorry
                thus "y =XBOOLE-0R4 z"
                  using A72 A73 A75 arytm_0_th_3 arytm_0_th_7 sorry
              qed
              have case3: "x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies y =XBOOLE-0R4 z"
              proof(rule impI)
                assume "x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                then have " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & \<one>\<^sub>M =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 *'ARYTM-2K8 y9 ]"
                  using A59 A60 arytm_0_def_2 sorry
                thus "y =XBOOLE-0R4 z"
                  using arytm_0_lm_2 sorry
              qed
              have case4: "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inTARSKIR2 REAL+ARYTM-2K2 implies y =XBOOLE-0R4 z"
              proof(rule impI)
                assume "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inTARSKIR2 REAL+ARYTM-2K2"
                then have " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =XBOOLE-0R4 y9) & \<one>\<^sub>M =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 *'ARYTM-2K8 x9 ]"
                  using A60 A67 arytm_0_def_2 sorry
                thus "y =XBOOLE-0R4 z"
                  using arytm_0_lm_2 sorry
              qed
              have case5: "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & z inTARSKIR2 REAL+ARYTM-2K2 implies y =XBOOLE-0R4 z"
              proof(rule impI)
                assume "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & z inTARSKIR2 REAL+ARYTM-2K2"
                then have " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & z =XBOOLE-0R4 z9) & \<one>\<^sub>M =HIDDENR1 [TARSKIK4 0NUMBERSK6,z9 *'ARYTM-2K8 x9 ]"
                  using A61 A68 arytm_0_def_2 sorry
                thus "y =XBOOLE-0R4 z"
                  using arytm_0_lm_2 sorry
              qed
              have case6: "x inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies y =XBOOLE-0R4 z"
              proof(rule impI)
                assume "x inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                then have " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & z =HIDDENR1 [TARSKIK4 0NUMBERSK6,z9 ]) & \<one>\<^sub>M =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 *'ARYTM-2K8 z9 ]"
                  using A59 A61 arytm_0_def_2 sorry
                thus "y =XBOOLE-0R4 z"
                  using arytm_0_lm_2 sorry
              qed
              have case7: "(( not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) &  not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & x <>HIDDENR2 0NUMBERSK6)) &  not ((y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & y <>HIDDENR2 0NUMBERSK6)) &  not (x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies y =XBOOLE-0R4 z"
              proof(rule impI)
                assume "(( not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) &  not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & x <>HIDDENR2 0NUMBERSK6)) &  not ((y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & y <>HIDDENR2 0NUMBERSK6)) &  not (x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
                thus "y =XBOOLE-0R4 z"
                  using A60 arytm_0_def_2 sorry
              qed
              have case8: "(( not (x inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 REAL+ARYTM-2K2) &  not ((x inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & x <>HIDDENR2 0NUMBERSK6)) &  not ((z inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & z <>HIDDENR2 0NUMBERSK6)) &  not (x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies y =XBOOLE-0R4 z"
              proof(rule impI)
                assume "(( not (x inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 REAL+ARYTM-2K2) &  not ((x inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & x <>HIDDENR2 0NUMBERSK6)) &  not ((z inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & z <>HIDDENR2 0NUMBERSK6)) &  not (x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
                thus "y =XBOOLE-0R4 z"
                  using A61 arytm_0_def_2 sorry
              qed
              show " ?thesis "
                using cases case1 case2 case3 case4 case5 case6 case7 case8 sorry
            qed
          qed
          thus " ?thesis "
             sorry
        qed
        show " not (((x <>HIDDENR2 0NUMBERSK6 & y =XBOOLE-0R4 0NUMBERSK6) & z =XBOOLE-0R4 0NUMBERSK6) &  not y =HIDDENR1 z)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
  (*consistency*)
    show " for it be ElementSUBSET-1M1-of REALNUMBERSK2 holds  True "
       sorry
qed "sorry"

mtheorem ARYTM_0K4_involutiveness:
" for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds invARYTM-0K4 (invARYTM-0K4 x) =HIDDENR1 x"
proof-
  have " for it be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds it =HIDDENR1 invARYTM-0K4 x implies x =HIDDENR1 invARYTM-0K4 it"
  proof-
    have " for it be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds (x <>HIDDENR2 0NUMBERSK6 implies  *ARYTM-0K2(x,it) =XBOOLE-0R4 \<one>\<^sub>M) & ( not x <>HIDDENR2 0NUMBERSK6 implies it =XBOOLE-0R4 0NUMBERSK6) implies (it <>HIDDENR2 0NUMBERSK6 implies  *ARYTM-0K2(it,x) =XBOOLE-0R4 \<one>\<^sub>M) & ( not it <>HIDDENR2 0NUMBERSK6 implies x =XBOOLE-0R4 0NUMBERSK6)"
    proof-
      have " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds (y <>HIDDENR2 0NUMBERSK6 implies  *ARYTM-0K2(y,x) =XBOOLE-0R4 \<one>\<^sub>M) & (y =XBOOLE-0R4 0NUMBERSK6 implies x =XBOOLE-0R4 0NUMBERSK6) implies (x <>HIDDENR2 0NUMBERSK6 implies  *ARYTM-0K2(x,y) =XBOOLE-0R4 \<one>\<^sub>M) & (x =XBOOLE-0R4 0NUMBERSK6 implies (y <>HIDDENR2 0NUMBERSK6 implies  False ))"
      proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule impI,rule impI)
        fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
        fix y assume [ty]: "y be ElementSUBSET-1M1-of REALNUMBERSK2"
        assume A76: "y <>HIDDENR2 0NUMBERSK6 implies  *ARYTM-0K2(y,x) =XBOOLE-0R4 \<one>\<^sub>M"
          and A77: "y =XBOOLE-0R4 0NUMBERSK6 implies x =XBOOLE-0R4 0NUMBERSK6"
        show "x <>HIDDENR2 0NUMBERSK6 implies  *ARYTM-0K2(x,y) =XBOOLE-0R4 \<one>\<^sub>M"
          using A76 A77 sorry
        assume A78: "x =XBOOLE-0R4 0NUMBERSK6"
        have A79: "y inTARSKIR2 REAL+ARYTM-2K2 \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          using xboole_0_def_5 sorry
        assume A80: "y <>HIDDENR2 0NUMBERSK6"
        show " False "
        proof-
          have cases: "y inTARSKIR2 REAL+ARYTM-2K2 or y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
            using A79 xboole_0_def_3 sorry
          have case1: "y inTARSKIR2 REAL+ARYTM-2K2 implies  False "
          proof(rule impI)
            assume "y inTARSKIR2 REAL+ARYTM-2K2"
            then have " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & \<one>\<^sub>M =XBOOLE-0R4 x9 *'ARYTM-2K8 y9"
              using A76 A78 A80 arytm_0_def_2 arytm_2_th_20 sorry
            thus " False "
              using A78 arytm_2_th_4 sorry
          qed
          have case2: "y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies  False "
          proof(rule impI)
            assume A81: "y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
            have A82: " not x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
              using A78 arytm_0_th_5 arytm_2_th_20 xboole_0_th_3 sorry
            have " not y inTARSKIR2 REAL+ARYTM-2K2"
              using A81 arytm_0_th_5 xboole_0_th_3 sorry
            thus " False "
              using A76 A78 A80 A82 arytm_0_def_2 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus " ?thesis "
      using arytm_0_def_4 sorry
  qed
  thus " ?thesis "
     sorry
qed

(*begin*)
mlemma arytm_0_lm_4:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds [TARSKIK4 x,y ] =HIDDENR1 {TARSKIK1 z} implies z =XBOOLE-0R4 {TARSKIK1 x} & x =XBOOLE-0R4 y"
proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
  fix x assume [ty]: "x be setHIDDENM2"
  fix y assume [ty]: "y be setHIDDENM2"
  fix z assume [ty]: "z be setHIDDENM2"
  assume A1: "[TARSKIK4 x,y ] =HIDDENR1 {TARSKIK1 z}"
  then have "{TARSKIK1 x} inTARSKIR2 {TARSKIK1 z}"
    using tarski_def_2 sorry
  thus A2: "z =XBOOLE-0R4 {TARSKIK1 x}"
    using tarski_def_1 sorry
  have "{TARSKIK2 x,y } inTARSKIR2 {TARSKIK1 z}"
    using A1 tarski_def_2 sorry
  then have "{TARSKIK2 x,y } =XBOOLE-0R4 z"
    using tarski_def_1 sorry
  thus "x =XBOOLE-0R4 y"
    using A2 zfmisc_1_th_5 sorry
qed "sorry"

reserve i, j, k for "ElementSUBSET-1M1-of NATNUMBERSK1"
reserve a, b for "ElementSUBSET-1M1-of REALNUMBERSK2"
mtheorem arytm_0_th_8:
" for a be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for b be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not (0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K7\<^bsub>(REALNUMBERSK2)\<^esub>(a,b) inTARSKIR2 REALNUMBERSK2"
proof-
  have " for a be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for b be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not (0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K7\<^bsub>(REALNUMBERSK2)\<^esub>(a,b) inTARSKIR2 REALNUMBERSK2"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be ElementSUBSET-1M1-of REALNUMBERSK2"
    fix b assume [ty]: "b be ElementSUBSET-1M1-of REALNUMBERSK2"
    let ?IR = "{A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
    let ?f = "(0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K7\<^bsub>(REALNUMBERSK2)\<^esub>(a,b)"
    have A1: "?f inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 {}ARYTM-3K12 },REAL+ARYTM-2K2 :] implies  False "
    proof(rule impI)
      have "?f =XBOOLE-0R4 {TARSKIK2 [TARSKIK4 0NUMBERSK6,a ],[TARSKIK4 \<one>\<^sub>M,b ] }"
        using funct_4_th_67 sorry
      then have A2: "[TARSKIK4 \<one>\<^sub>M,b ] inHIDDENR3 ?f"
        using tarski_def_2 sorry
      assume "?f inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 {}ARYTM-3K12 },REAL+ARYTM-2K2 :]"
      then obtain x y where
        [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
        A3: "x inHIDDENR3 {TARSKIK1 {}ARYTM-3K12 }"and "y inHIDDENR3 REAL+ARYTM-2K2"and A4: "?f =HIDDENR1 [TARSKIK4 x,y ]"
        using zfmisc_1_th_84 sorry
      have Cut752: "x =HIDDENR1 0NUMBERSK6"
        using A3 tarski_def_1 sorry
      show " False "
      proof-
        have cases: "{TARSKIK2 {TARSKIK2 \<one>\<^sub>M,b },{TARSKIK1 \<one>\<^sub>M} } =XBOOLE-0R4 {TARSKIK1 0NUMBERSK6 } or {TARSKIK2 {TARSKIK2 \<one>\<^sub>M,b },{TARSKIK1 \<one>\<^sub>M} } =XBOOLE-0R4 {TARSKIK2 0NUMBERSK6,y }"
          using A4 A2 tarski_def_2 Cut752 sorry
        have case1: "{TARSKIK2 {TARSKIK2 \<one>\<^sub>M,b },{TARSKIK1 \<one>\<^sub>M} } =XBOOLE-0R4 {TARSKIK1 0NUMBERSK6 } implies  False "
        proof(rule impI)
          assume "{TARSKIK2 {TARSKIK2 \<one>\<^sub>M,b },{TARSKIK1 \<one>\<^sub>M} } =XBOOLE-0R4 {TARSKIK1 0NUMBERSK6 }"
          then have "0NUMBERSK6 inTARSKIR2 {TARSKIK2 {TARSKIK2 \<one>\<^sub>M,b },{TARSKIK1 \<one>\<^sub>M} }"
            using tarski_def_1 sorry
          thus " False "
            using tarski_def_2 sorry
        qed
        have case2: "{TARSKIK2 {TARSKIK2 \<one>\<^sub>M,b },{TARSKIK1 \<one>\<^sub>M} } =XBOOLE-0R4 {TARSKIK2 0NUMBERSK6,y } implies  False "
        proof(rule impI)
          assume "{TARSKIK2 {TARSKIK2 \<one>\<^sub>M,b },{TARSKIK1 \<one>\<^sub>M} } =XBOOLE-0R4 {TARSKIK2 0NUMBERSK6,y }"
          then have "0NUMBERSK6 inTARSKIR2 {TARSKIK2 {TARSKIK2 \<one>\<^sub>M,b },{TARSKIK1 \<one>\<^sub>M} }"
            using tarski_def_2 sorry
          thus " False "
            using tarski_def_2 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    have A5: "?f =XBOOLE-0R4 {TARSKIK2 [TARSKIK4 0NUMBERSK6,a ],[TARSKIK4 \<one>\<^sub>M,b ] }"
      using funct_4_th_67 sorry
    have "?f inTARSKIR2 {[TARSKIK4 i,j ] where i be ElementSUBSET-1M1-of NATNUMBERSK1, j be ElementSUBSET-1M1-of NATNUMBERSK1 : (i,j)are-coprimeARYTM-3R1 & j <>HIDDENR2 {}ARYTM-3K12 } implies  False "
    proof(rule impI)
      assume "?f inTARSKIR2 {[TARSKIK4 i,j ] where i be ElementSUBSET-1M1-of NATNUMBERSK1, j be ElementSUBSET-1M1-of NATNUMBERSK1 : (i,j)are-coprimeARYTM-3R1 & j <>HIDDENR2 {}ARYTM-3K12 }"
      then obtain i j where
        [ty]:"i be ElementSUBSET-1M1-of NATNUMBERSK1" "j be ElementSUBSET-1M1-of NATNUMBERSK1" and 
        A6: "?f =HIDDENR1 [TARSKIK4 i,j ]"and "(i,j)are-coprimeARYTM-3R1"and "j <>HIDDENR2 {}ARYTM-3K12"
         sorry
      have A7: "{TARSKIK1 i} inTARSKIR2 ?f & {TARSKIK2 i,j } inTARSKIR2 ?f"
        using A6 tarski_def_2 sorry
      have A8: "i =XBOOLE-0R4 j implies  False "
      proof(rule impI)
        assume "i =XBOOLE-0R4 j"
        then have "{TARSKIK1 i} =XBOOLE-0R4 {TARSKIK2 i,j }"
          using enumset1_th_29 sorry
        then have A9: "[TARSKIK4 i,j ] =HIDDENR1 {TARSKIK1 {TARSKIK1 i} }"
          using enumset1_th_29 sorry
        then have "[TARSKIK4 \<one>\<^sub>M,b ] inHIDDENR3 {TARSKIK1 {TARSKIK1 i} }"
          using A5 A6 tarski_def_2 sorry
        then have A10: "[TARSKIK4 \<one>\<^sub>M,b ] =HIDDENR1 {TARSKIK1 i}"
          using tarski_def_1 sorry
        have "[TARSKIK4 0NUMBERSK6,a ] inHIDDENR3 {TARSKIK1 {TARSKIK1 i} }"
          using A5 A6 A9 tarski_def_2 sorry
        then have "[TARSKIK4 0NUMBERSK6,a ] =HIDDENR1 {TARSKIK1 i}"
          using tarski_def_1 sorry
        thus " False "
          using A10 xtuple_0_th_1 sorry
      qed
      show " False "
      proof-
        have cases: "(({TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ] & {TARSKIK1 i} =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ] or {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ] & {TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ]) or {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ] & {TARSKIK1 i} =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ]) or {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ] & {TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ]"
          using A5 A7 tarski_def_2 sorry
        have case1: "{TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ] & {TARSKIK1 i} =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ] implies  False "
        proof(rule impI)
          assume "{TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ] & {TARSKIK1 i} =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ]"
          thus " False "
            using A8 zfmisc_1_th_5 sorry
        qed
        have case2: "{TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ] & {TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ] implies  False "
        proof(rule impMI ,rule impI)
          assume A11: "{TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ]"
            and A12: "{TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ]"
          have "i inTARSKIR2 {TARSKIK2 i,j }"
            using tarski_def_2 sorry
          then have "i =XBOOLE-0R4 {TARSKIK2 0NUMBERSK6,a } or i =XBOOLE-0R4 {TARSKIK1 0NUMBERSK6 }"
            using A11 tarski_def_2 sorry
          then have A13: "0NUMBERSK6 inTARSKIR2 i"
            using tarski_def_1 tarski_def_2 sorry
          have "i =XBOOLE-0R4 {TARSKIK1 \<one>\<^sub>M}"
            using A12 arytm_0_lm_4 sorry
          thus " False "
            using A13 tarski_def_1 sorry
        qed
        have case3: "{TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ] & {TARSKIK1 i} =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ] implies  False "
        proof(rule impMI ,rule impI)
          assume A14: "{TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ]"
            and A15: "{TARSKIK1 i} =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ]"
          have "i inTARSKIR2 {TARSKIK2 i,j }"
            using tarski_def_2 sorry
          then have "i =XBOOLE-0R4 {TARSKIK2 \<one>\<^sub>M,b } or i =XBOOLE-0R4 {TARSKIK1 \<one>\<^sub>M}"
            using A14 tarski_def_2 sorry
          then have A16: "\<one>\<^sub>M inTARSKIR2 i"
            using tarski_def_1 tarski_def_2 sorry
          have "i =XBOOLE-0R4 {TARSKIK1 0NUMBERSK6 }"
            using A15 arytm_0_lm_4 sorry
          thus " False "
            using A16 tarski_def_1 sorry
        qed
        have case4: "{TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ] & {TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ] implies  False "
        proof(rule impI)
          assume "{TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ] & {TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ]"
          thus " False "
            using A8 zfmisc_1_th_5 sorry
        qed
        show " ?thesis "
          using cases case1 case2 case3 case4 sorry
      qed
    qed
    then have A17: " not ?f inTARSKIR2 ({[TARSKIK4 i,j ] where i be ElementSUBSET-1M1-of NATNUMBERSK1, j be ElementSUBSET-1M1-of NATNUMBERSK1 : (i,j)are-coprimeARYTM-3R1 & j <>HIDDENR2 {}ARYTM-3K12 })\\SUBSET-1K6 ({[TARSKIK4 k,\<one>\<^sub>M ] where k be ElementSUBSET-1M1-of NATNUMBERSK1 :  True  })"
       sorry
    have " not ( ex x be setHIDDENM2 st  ex y be setHIDDENM2 st {TARSKIK2 [TARSKIK4 0NUMBERSK6,x ],[TARSKIK4 \<one>\<^sub>M,y ] } inTARSKIR2 ?IR)"
    proof-
      have "( ex x be setHIDDENM2 st  ex y be setHIDDENM2 st {TARSKIK2 [TARSKIK4 0NUMBERSK6,x ],[TARSKIK4 \<one>\<^sub>M,y ] } inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }) implies  False "
      proof(rule impI)
        assume Given: " ex x be setHIDDENM2 st  ex y be setHIDDENM2 st {TARSKIK2 [TARSKIK4 0NUMBERSK6,x ],[TARSKIK4 \<one>\<^sub>M,y ] } inTARSKIR2 ?IR"
        then obtain x y where
          [ty]:"x be setHIDDENM2" "y be setHIDDENM2" and 
          A18: "{TARSKIK2 [TARSKIK4 0NUMBERSK6,x ],[TARSKIK4 \<one>\<^sub>M,y ] } inTARSKIR2 ?IR"
           sorry
        obtain A where
          [ty]:"A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5" and 
          A19: "{TARSKIK2 [TARSKIK4 0NUMBERSK6,x ],[TARSKIK4 \<one>\<^sub>M,y ] } =XBOOLE-0R4 A"and A20: " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s)"
          using A18 sorry
        have "[TARSKIK4 0NUMBERSK6,x ] inHIDDENR3 A & ( for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A & s <='ARYTM-3R3 r implies s inTARSKIR2 A)"
          using A19 A20 tarski_def_2 sorry
        then obtain r1 r2 r3 where
          [ty]:"r1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "r2 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "r3 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A21: "r1 inTARSKIR2 A"and A22: "r2 inTARSKIR2 A"and A23: "((r3 inTARSKIR2 A & r1 <>HIDDENR2 r2) & r2 <>HIDDENR2 r3) & r3 <>HIDDENR2 r1"
          using arytm_3_th_75 sorry
        have A24: "r2 =HIDDENR1 [TARSKIK4 0NUMBERSK6,x ] or r2 =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,y ]"
          using A19 A22 tarski_def_2 sorry
        have "r1 =HIDDENR1 [TARSKIK4 0NUMBERSK6,x ] or r1 =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,y ]"
          using A19 A21 tarski_def_2 sorry
        thus " False "
          using A19 A23 A24 tarski_def_2 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    then have A25: " not ?f inTARSKIR2 DEDEKIND-CUTSARYTM-2K1"
      using A5 arytm_2_def_1 sorry
    have "(0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K7\<^bsub>(REALNUMBERSK2)\<^esub>(a,b) inTARSKIR2 omegaORDINAL1K4 implies  False "
    proof(rule impI)
      assume "?f inTARSKIR2 omegaORDINAL1K4"
      then have "{}ARYTM-3K12 inTARSKIR2 ?f"
        using ordinal3_th_8 sorry
      thus " False "
        using A5 tarski_def_2 sorry
    qed
    then have " not ?f inTARSKIR2 RAT+ARYTM-3K5"
      using A17 xboole_0_def_3 sorry
    then have " not ?f inTARSKIR2 REAL+ARYTM-2K2"
      using A25 arytm_2_def_2 xboole_0_def_3 sorry
    thus " not (0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K7\<^bsub>(REALNUMBERSK2)\<^esub>(a,b) inTARSKIR2 REALNUMBERSK2"
      using A1 xboole_0_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef arytm_0_def_5 ("[*ARYTM-0K5 _ , _ *]" [0,0]164 ) where
  mlet "x be ElementSUBSET-1M1-of REALNUMBERSK2", "y be ElementSUBSET-1M1-of REALNUMBERSK2"
"func [*ARYTM-0K5 x,y *] \<rightarrow> ElementSUBSET-1M1-of COMPLEXNUMBERSK3 equals
  x if y =XBOOLE-0R4 0NUMBERSK6 otherwise (0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K7\<^bsub>(REALNUMBERSK2)\<^esub>(x,y)"
proof-
  (*consistency*)
    show " for it be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  True "
       sorry
  (*coherence*)
    show "(y =XBOOLE-0R4 0NUMBERSK6 implies x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3) & ( not y =XBOOLE-0R4 0NUMBERSK6 implies (0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K7\<^bsub>(REALNUMBERSK2)\<^esub>(x,y) be ElementSUBSET-1M1-of COMPLEXNUMBERSK3)"
    proof-
      have "(y =XBOOLE-0R4 0NUMBERSK6 implies x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3) & (y <>HIDDENR2 0NUMBERSK6 implies (0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K7\<^bsub>(REALNUMBERSK2)\<^esub>(x,y) be ElementSUBSET-1M1-of COMPLEXNUMBERSK3)"
      proof(rule conjMI,rule impI)
        let ?z = "(0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K7\<^bsub>(REALNUMBERSK2)\<^esub>(x,y)"
        show "y =XBOOLE-0R4 0NUMBERSK6 implies x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
          using xboole_0_def_3 sorry
        assume A1: "y <>HIDDENR2 0NUMBERSK6"
        have A2: "(0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K7\<^bsub>(REALNUMBERSK2)\<^esub>(x,y) inTARSKIR2 {r where r be ElementFUNCT-2M4\<^bsub>({TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9({TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2) : r .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6 } implies  False "
        proof(rule impI)
          assume "?z inTARSKIR2 {r where r be ElementFUNCT-2M4\<^bsub>({TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9({TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2) : r .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6 }"
          then have " ex r be ElementFUNCT-2M4\<^bsub>({TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9({TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2) st ?z =FUNCT-2R2\<^bsub>({TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2)\<^esub> r & r .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
             sorry
          thus " False "
            using A1 funct_4_th_63 sorry
        qed
        have "?z inTARSKIR2 FuncsFUNCT-2K9({TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2)"
          using funct_2_th_8 sorry
        then have "?z inTARSKIR2 FuncsFUNCT-2K9({TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2) \\SUBSET-1K6 ({r where r be ElementFUNCT-2M4\<^bsub>({TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9({TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2) : r .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6 })"
          using A2 xboole_0_def_5 sorry
        thus "(0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K7\<^bsub>(REALNUMBERSK2)\<^esub>(x,y) be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
          using xboole_0_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem arytm_0_th_9:
" for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  ex r be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex s be ElementSUBSET-1M1-of REALNUMBERSK2 st c =XBOOLE-0R4 [*ARYTM-0K5 r,s *]"
proof-
  have " for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  ex tVar32 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex tVar33 be ElementSUBSET-1M1-of REALNUMBERSK2 st c =XBOOLE-0R4 [*ARYTM-0K5 tVar32,tVar33 *]"
  proof(rule ballI)
    fix c assume [ty]: "c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    show " ex tVar32 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex tVar33 be ElementSUBSET-1M1-of REALNUMBERSK2 st c =XBOOLE-0R4 [*ARYTM-0K5 tVar32,tVar33 *]"
    proof-
      have cases: "c inTARSKIR2 REALNUMBERSK2 or  not c inTARSKIR2 REALNUMBERSK2"
         sorry
      have case1: "c inTARSKIR2 REALNUMBERSK2 implies ( ex tVar32 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex tVar33 be ElementSUBSET-1M1-of REALNUMBERSK2 st c =XBOOLE-0R4 [*ARYTM-0K5 tVar32,tVar33 *])"
      proof(rule impI)
        assume "c inTARSKIR2 REALNUMBERSK2"
        then obtain r z where 
          [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2" and rDef:"r = c" and
          [ty]:"z be ElementSUBSET-1M1-of REALNUMBERSK2" and zDef:"z = 0NUMBERSK6"
          using arytm_0_lm_3 sorry
        show " ex tVar32 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex tVar33 be ElementSUBSET-1M1-of REALNUMBERSK2 st c =XBOOLE-0R4 [*ARYTM-0K5 tVar32,tVar33 *]"
        proof(rule bexI[of _ "r"])
          show " ex tVar33 be ElementSUBSET-1M1-of REALNUMBERSK2 st c =XBOOLE-0R4 [*ARYTM-0K5 r,tVar33 *]"
          proof(rule bexI[of _ "z"])
            show "c =XBOOLE-0R4 [*ARYTM-0K5 r,z *]"
              using arytm_0_def_5 sorry
          qed "sorry"
        qed "sorry"
      qed
      have case2: " not c inTARSKIR2 REALNUMBERSK2 implies ( ex tVar34 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex tVar35 be ElementSUBSET-1M1-of REALNUMBERSK2 st c =XBOOLE-0R4 [*ARYTM-0K5 tVar34,tVar35 *])"
      proof(rule impI)
        assume " not c inTARSKIR2 REALNUMBERSK2"
        then have A1: "c inTARSKIR2 FuncsFUNCT-2K9({TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2) \\SUBSET-1K6 ({x where x be ElementFUNCT-2M4\<^bsub>({TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9({TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2) : x .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6 })"
          using xboole_0_def_3 sorry
        then obtain f where
          [ty]:"f be FunctionFUNCT-1M1" and 
          A2: "c =XBOOLE-0R4 f"and A3: "domRELAT-1K1 f =XBOOLE-0R4 {TARSKIK2 0NUMBERSK6,\<one>\<^sub>M }"and A4: "rngFUNCT-1K2 f c=TARSKIR1 REALNUMBERSK2"
          using funct_2_def_2 sorry
        have "\<one>\<^sub>M inTARSKIR2 {TARSKIK2 0NUMBERSK6,\<one>\<^sub>M }"
          using tarski_def_2 sorry
        then have A5: "f .FUNCT-1K1 \<one>\<^sub>M inTARSKIR2 rngFUNCT-1K2 f"
          using A3 funct_1_th_3 sorry
        have "0NUMBERSK6 inTARSKIR2 {TARSKIK2 0NUMBERSK6,\<one>\<^sub>M }"
          using tarski_def_2 sorry
        then have "f .FUNCT-1K1 (0NUMBERSK6) inTARSKIR2 rngFUNCT-1K2 f"
          using A3 funct_1_th_3 sorry
        then obtain r s where 
          [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2" and rDef:"r = f .FUNCT-1K1 (0NUMBERSK6)" and
          [ty]:"s be ElementSUBSET-1M1-of REALNUMBERSK2" and sDef:"s = f .FUNCT-1K1 \<one>\<^sub>M"
          using A4 A5 sorry
        show " ex tVar34 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex tVar35 be ElementSUBSET-1M1-of REALNUMBERSK2 st c =XBOOLE-0R4 [*ARYTM-0K5 tVar34,tVar35 *]"
        proof(rule bexI[of _ "r"])
          show " ex tVar35 be ElementSUBSET-1M1-of REALNUMBERSK2 st c =XBOOLE-0R4 [*ARYTM-0K5 r,tVar35 *]"
          proof(rule bexI[of _ "s"])
            have A6: "c =XBOOLE-0R4 (0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K7\<^bsub>(REALNUMBERSK2)\<^esub>(r,s)"
              using A2 A3 funct_4_th_66 sorry
            have "s =XBOOLE-0R4 0NUMBERSK6 implies  False "
            proof(rule impI)
              assume "s =XBOOLE-0R4 0NUMBERSK6"
              then have "((0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K7\<^bsub>(REALNUMBERSK2)\<^esub>(r,s)).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
                using funct_4_th_63 sorry
              then have "c inTARSKIR2 {x where x be ElementFUNCT-2M4\<^bsub>({TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9({TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2) : x .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6 }"
                using A1 A6 sorry
              thus " False "
                using A1 xboole_0_def_5 sorry
            qed
            thus "c =XBOOLE-0R4 [*ARYTM-0K5 r,s *]"
              using A6 arytm_0_def_5 sorry
          qed "sorry"
        qed "sorry"
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_0_th_10:
" for x1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for x2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds [*ARYTM-0K5 x1,x2 *] =XBOOLE-0R4 [*ARYTM-0K5 y1,y2 *] implies x1 =XBOOLE-0R4 y1 & x2 =XBOOLE-0R4 y2"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix x1 assume [ty]: "x1 be ElementSUBSET-1M1-of REALNUMBERSK2"
  fix x2 assume [ty]: "x2 be ElementSUBSET-1M1-of REALNUMBERSK2"
  fix y1 assume [ty]: "y1 be ElementSUBSET-1M1-of REALNUMBERSK2"
  fix y2 assume [ty]: "y2 be ElementSUBSET-1M1-of REALNUMBERSK2"
  assume A1: "[*ARYTM-0K5 x1,x2 *] =XBOOLE-0R4 [*ARYTM-0K5 y1,y2 *]"
  show "x1 =XBOOLE-0R4 y1 & x2 =XBOOLE-0R4 y2"
  proof-
    have cases: "x2 =XBOOLE-0R4 0NUMBERSK6 or x2 <>HIDDENR2 0NUMBERSK6"
       sorry
    have case1: "x2 =XBOOLE-0R4 0NUMBERSK6 implies x1 =XBOOLE-0R4 y1 & x2 =XBOOLE-0R4 y2"
    proof(rule impI,rule conjMI)
      assume A2: "x2 =XBOOLE-0R4 0NUMBERSK6"
      then have A3: "[*ARYTM-0K5 x1,x2 *] =XBOOLE-0R4 x1"
        using arytm_0_def_5 sorry
      have A4: "y2 <>HIDDENR2 0NUMBERSK6 implies  False "
      proof(rule impI)
        assume "y2 <>HIDDENR2 0NUMBERSK6"
        then have "x1 =XBOOLE-0R4 (0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K7\<^bsub>(REALNUMBERSK2)\<^esub>(y1,y2)"
          using A1 A3 arytm_0_def_5 sorry
        thus " False "
          using arytm_0_th_8 sorry
      qed
      thus "x1 =XBOOLE-0R4 y1"
        using A1 A3 arytm_0_def_5 sorry
      show "x2 =XBOOLE-0R4 y2"
        using A2 A4 sorry
    qed
    have case2: "x2 <>HIDDENR2 0NUMBERSK6 implies x1 =XBOOLE-0R4 y1 & x2 =XBOOLE-0R4 y2"
    proof(rule impI)
      assume "x2 <>HIDDENR2 0NUMBERSK6"
      then have A5: "[*ARYTM-0K5 y1,y2 *] =XBOOLE-0R4 (0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K7\<^bsub>(REALNUMBERSK2)\<^esub>(x1,x2)"
        using A1 arytm_0_def_5 sorry
      have "y2 =XBOOLE-0R4 0NUMBERSK6 implies  False "
      proof(rule impI)
        assume "y2 =XBOOLE-0R4 0NUMBERSK6"
        then have "[*ARYTM-0K5 y1,y2 *] =XBOOLE-0R4 y1"
          using arytm_0_def_5 sorry
        thus " False "
          using A5 arytm_0_th_8 sorry
      qed
      then have "[*ARYTM-0K5 y1,y2 *] =XBOOLE-0R4 (0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K7\<^bsub>(REALNUMBERSK2)\<^esub>(y1,y2)"
        using arytm_0_def_5 sorry
      thus "x1 =XBOOLE-0R4 y1 & x2 =XBOOLE-0R4 y2"
        using A5 funct_4_th_68 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem arytm_0_th_11:
" for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for o be ElementSUBSET-1M1-of REALNUMBERSK2 holds o =XBOOLE-0R4 0NUMBERSK6 implies +ARYTM-0K1(x,o) =XBOOLE-0R4 x"
proof(rule ballI,rule ballI,rule impI)
  obtain y9 where 
    [ty]:"y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and y9Def:"y9 = 0NUMBERSK6"
    using arytm_2_th_20 sorry
  fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
  fix o assume [ty]: "o be ElementSUBSET-1M1-of REALNUMBERSK2"
  assume A1: "o =XBOOLE-0R4 0NUMBERSK6"
  show "+ARYTM-0K1(x,o) =XBOOLE-0R4 x"
  proof-
    have cases: "x inTARSKIR2 REAL+ARYTM-2K2 or  not x inTARSKIR2 REAL+ARYTM-2K2"
       sorry
    have case1: "x inTARSKIR2 REAL+ARYTM-2K2 implies +ARYTM-0K1(x,o) =XBOOLE-0R4 x"
    proof(rule impI)
      assume "x inTARSKIR2 REAL+ARYTM-2K2"
      then obtain x9 where 
        [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and x9Def:"x9 = x"
         sorry
      have "x9 =XBOOLE-0R4 x9 +ARYTM-2K7 y9"
        using arytm_2_def_8 sorry
      thus "+ARYTM-0K1(x,o) =XBOOLE-0R4 x"
        using A1 arytm_0_def_1 sorry
    qed
    have case2: " not x inTARSKIR2 REAL+ARYTM-2K2 implies +ARYTM-0K1(x,o) =XBOOLE-0R4 x"
    proof(rule impI)
      assume A2: " not x inTARSKIR2 REAL+ARYTM-2K2"
      have "x inTARSKIR2 REAL+ARYTM-2K2 \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 {}ARYTM-3K12 },REAL+ARYTM-2K2 :]"
        using xboole_0_def_5 sorry
      then have A3: "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 {}ARYTM-3K12 },REAL+ARYTM-2K2 :]"
        using A2 xboole_0_def_3 sorry
      then obtain x1 x2 where
        [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" and 
        A4: "x1 inHIDDENR3 {TARSKIK1 {}ARYTM-3K12 }"and A5: "x2 inHIDDENR3 REAL+ARYTM-2K2"and A6: "x =HIDDENR1 [TARSKIK4 x1,x2 ]"
        using zfmisc_1_th_84 sorry
      obtain x9 where 
        [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and x9Def:"x9 = x2"
        using A5 sorry
      have A7: "x1 =HIDDENR1 0NUMBERSK6"
        using A4 tarski_def_1 sorry
      then have "x =XBOOLE-0R4 y9 -ARYTM-1K2 x9"
        using A6 arytm_0_th_3 arytm_1_th_19 sorry
      thus "+ARYTM-0K1(x,o) =XBOOLE-0R4 x"
        using A1 A3 A6 A7 arytm_0_def_1 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem arytm_0_th_12:
" for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for o be ElementSUBSET-1M1-of REALNUMBERSK2 holds o =XBOOLE-0R4 0NUMBERSK6 implies  *ARYTM-0K2(x,o) =XBOOLE-0R4 0NUMBERSK6"
proof(rule ballI,rule ballI,rule impI)
  fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
  fix o assume [ty]: "o be ElementSUBSET-1M1-of REALNUMBERSK2"
  assume A1: "o =XBOOLE-0R4 0NUMBERSK6"
  show " *ARYTM-0K2(x,o) =XBOOLE-0R4 0NUMBERSK6"
  proof-
    have cases: "x inTARSKIR2 REAL+ARYTM-2K2 or  not x inTARSKIR2 REAL+ARYTM-2K2"
       sorry
    have case1: "x inTARSKIR2 REAL+ARYTM-2K2 implies  *ARYTM-0K2(x,o) =XBOOLE-0R4 0NUMBERSK6"
    proof(rule impI)
      assume "x inTARSKIR2 REAL+ARYTM-2K2"
      then obtain x9 y9 where 
        [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and x9Def:"x9 = x" and
        [ty]:"y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and y9Def:"y9 = 0NUMBERSK6"
        using arytm_2_th_20 sorry
      have "0NUMBERSK6 =XBOOLE-0R4 x9 *'ARYTM-2K8 y9"
        using arytm_2_th_4 sorry
      thus " *ARYTM-0K2(x,o) =XBOOLE-0R4 0NUMBERSK6"
        using A1 arytm_0_def_2 sorry
    qed
    have case2: " not x inTARSKIR2 REAL+ARYTM-2K2 implies  *ARYTM-0K2(x,o) =XBOOLE-0R4 0NUMBERSK6"
    proof(rule impI)
      assume A2: " not x inTARSKIR2 REAL+ARYTM-2K2"
      have " not o inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 {}ARYTM-3K12 },REAL+ARYTM-2K2 :]"
        using A1 arytm_0_th_5 arytm_2_th_20 xboole_0_th_3 sorry
      thus " *ARYTM-0K2(x,o) =XBOOLE-0R4 0NUMBERSK6"
        using A1 A2 arytm_0_def_2 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem arytm_0_th_13:
" for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for z be ElementSUBSET-1M1-of REALNUMBERSK2 holds  *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =XBOOLE-0R4  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
proof(rule ballI,rule ballI,rule ballI)
  fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
  fix y assume [ty]: "y be ElementSUBSET-1M1-of REALNUMBERSK2"
  fix z assume [ty]: "z be ElementSUBSET-1M1-of REALNUMBERSK2"
  obtain o where 
    [ty]:"o be ElementSUBSET-1M1-of REALNUMBERSK2" and oDef:"o = 0NUMBERSK6"
    using arytm_0_lm_3 sorry
  show " *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =XBOOLE-0R4  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
  proof-
    have cases: "((((((((((x inTARSKIR2 REAL+ARYTM-2K2 & (y inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 REAL+ARYTM-2K2) or (x inTARSKIR2 REAL+ARYTM-2K2 & x <>HIDDENR2 0NUMBERSK6) & (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & (z inTARSKIR2 REAL+ARYTM-2K2 & z <>HIDDENR2 0NUMBERSK6))) or x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & ((y inTARSKIR2 REAL+ARYTM-2K2 & y <>HIDDENR2 0NUMBERSK6) & (z inTARSKIR2 REAL+ARYTM-2K2 & z <>HIDDENR2 0NUMBERSK6))) or x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & (z inTARSKIR2 REAL+ARYTM-2K2 & z <>HIDDENR2 0NUMBERSK6))) or (x inTARSKIR2 REAL+ARYTM-2K2 & x <>HIDDENR2 0NUMBERSK6) & ((y inTARSKIR2 REAL+ARYTM-2K2 & y <>HIDDENR2 0NUMBERSK6) & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })) or (x inTARSKIR2 REAL+ARYTM-2K2 & x <>HIDDENR2 0NUMBERSK6) & (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })) or (y inTARSKIR2 REAL+ARYTM-2K2 & y <>HIDDENR2 0NUMBERSK6) & (x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })) or x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })) or x =XBOOLE-0R4 0NUMBERSK6) or y =XBOOLE-0R4 0NUMBERSK6) or z =XBOOLE-0R4 0NUMBERSK6) or (((((( not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & z inTARSKIR2 REAL+ARYTM-2K2) &  not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) & z inTARSKIR2 REAL+ARYTM-2K2)) &  not ((y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) & z inTARSKIR2 REAL+ARYTM-2K2)) &  not ((x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) & z inTARSKIR2 REAL+ARYTM-2K2)) &  not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })) &  not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })) &  not ((y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })) &  not ((x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })"
       sorry
    have case1: "x inTARSKIR2 REAL+ARYTM-2K2 & (y inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 REAL+ARYTM-2K2) implies  *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =XBOOLE-0R4  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
    proof(rule impMI ,rule impMI ,rule impI)
      assume A1: "x inTARSKIR2 REAL+ARYTM-2K2"
        and A2: "y inTARSKIR2 REAL+ARYTM-2K2"
        and A3: "z inTARSKIR2 REAL+ARYTM-2K2"
      have A4: " ex x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x99 & y =XBOOLE-0R4 y99) &  *ARYTM-0K2(x,y) =XBOOLE-0R4 x99 *'ARYTM-2K8 y99"
        using A1 A2 arytm_0_def_2 sorry
      then have A5: " ex xy99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex z99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st ( *ARYTM-0K2(x,y) =XBOOLE-0R4 xy99 & z =XBOOLE-0R4 z99) &  *ARYTM-0K2( *ARYTM-0K2(x,y),z) =XBOOLE-0R4 xy99 *'ARYTM-2K8 z99"
        using A3 arytm_0_def_2 sorry
      have A6: " ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (y =XBOOLE-0R4 y9 & z =XBOOLE-0R4 z9) &  *ARYTM-0K2(y,z) =XBOOLE-0R4 y9 *'ARYTM-2K8 z9"
        using A2 A3 arytm_0_def_2 sorry
      then have " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex yz9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 &  *ARYTM-0K2(y,z) =XBOOLE-0R4 yz9) &  *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =XBOOLE-0R4 x9 *'ARYTM-2K8 yz9"
        using A1 arytm_0_def_2 sorry
      thus " *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =XBOOLE-0R4  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
        using A6 A4 A5 arytm_2_th_12 sorry
    qed
    have case2: "(x inTARSKIR2 REAL+ARYTM-2K2 & x <>HIDDENR2 0NUMBERSK6) & (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & (z inTARSKIR2 REAL+ARYTM-2K2 & z <>HIDDENR2 0NUMBERSK6)) implies  *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =HIDDENR1  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
    proof(rule impMI ,rule impMI ,rule impI)
      assume A7: "x inTARSKIR2 REAL+ARYTM-2K2 & x <>HIDDENR2 0NUMBERSK6"
        and A8: "y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
        and A9: "z inTARSKIR2 REAL+ARYTM-2K2 & z <>HIDDENR2 0NUMBERSK6"
      obtain y9 z9 where
        [ty]:"y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A10: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]"and A11: "z =XBOOLE-0R4 z9"and A12: " *ARYTM-0K2(y,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,z9 *'ARYTM-2K8 y9 ]"
        using A8 A9 arytm_0_def_2 sorry
      have " *ARYTM-0K2(y,z) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
        using A12 arytm_0_lm_1 sorry
      then obtain x9 yz9 where
        [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "yz9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A13: "x =XBOOLE-0R4 x9"and A14: " *ARYTM-0K2(y,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,yz9 ] &  *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 *'ARYTM-2K8 yz9 ]"
        using A7 arytm_0_def_2 sorry
      obtain x99 y99 where
        [ty]:"x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A15: "x =XBOOLE-0R4 x99"and A16: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 ]"and A17: " *ARYTM-0K2(x,y) =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 *'ARYTM-2K8 y99 ]"
        using A7 A8 arytm_0_def_2 sorry
      have A18: "y9 =XBOOLE-0R4 y99"
        using A10 A16 xtuple_0_th_1 sorry
      have " *ARYTM-0K2(x,y) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
        using A17 arytm_0_lm_1 sorry
      then obtain xy99 z99 where
        [ty]:"xy99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A19: " *ARYTM-0K2(x,y) =HIDDENR1 [TARSKIK4 0NUMBERSK6,xy99 ]"and A20: "z =XBOOLE-0R4 z99"and A21: " *ARYTM-0K2( *ARYTM-0K2(x,y),z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,z99 *'ARYTM-2K8 xy99 ]"
        using A9 arytm_0_def_2 sorry
      have " *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 *'ARYTM-2K8 (y9 *'ARYTM-2K8 z9) ]"
        using A12 A14 xtuple_0_th_1 sorry
      also have "... = [TARSKIK4 0NUMBERSK6,(x99 *'ARYTM-2K8 y99)*'ARYTM-2K8 z99 ]"
        using A11 A13 A15 A20 A18 arytm_2_th_12 sorry
      also have "... =  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
        using A17 A19 A21 xtuple_0_th_1 sorry
      finally show " *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =HIDDENR1  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
         sorry
    qed
    have case3: "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & ((y inTARSKIR2 REAL+ARYTM-2K2 & y <>HIDDENR2 0NUMBERSK6) & (z inTARSKIR2 REAL+ARYTM-2K2 & z <>HIDDENR2 0NUMBERSK6)) implies  *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =HIDDENR1  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
    proof(rule impMI ,rule impMI ,rule impI)
      assume A22: "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
        and A23: "y inTARSKIR2 REAL+ARYTM-2K2 & y <>HIDDENR2 0NUMBERSK6"
        and A24: "z inTARSKIR2 REAL+ARYTM-2K2 & z <>HIDDENR2 0NUMBERSK6"
      obtain y9 z9 where
        [ty]:"y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A25: "y =XBOOLE-0R4 y9 & z =XBOOLE-0R4 z9"and A26: " *ARYTM-0K2(y,z) =XBOOLE-0R4 y9 *'ARYTM-2K8 z9"
        using A23 A24 arytm_0_def_2 sorry
      have "y9 *'ARYTM-2K8 z9 <>HIDDENR2 0NUMBERSK6"
        using A23 A24 A25 arytm_1_th_2 sorry
      then obtain x9 yz9 where
        [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "yz9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A27: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]"and A28: " *ARYTM-0K2(y,z) =XBOOLE-0R4 yz9 &  *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =HIDDENR1 [TARSKIK4 0NUMBERSK6,yz9 *'ARYTM-2K8 x9 ]"
        using A22 A26 arytm_0_def_2 sorry
      obtain x99 y99 where
        [ty]:"x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A29: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 ]"and A30: "y =XBOOLE-0R4 y99"and A31: " *ARYTM-0K2(x,y) =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 *'ARYTM-2K8 x99 ]"
        using A22 A23 arytm_0_def_2 sorry
      have " *ARYTM-0K2(x,y) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
        using A31 arytm_0_lm_1 sorry
      then obtain xy99 z99 where
        [ty]:"xy99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A32: " *ARYTM-0K2(x,y) =HIDDENR1 [TARSKIK4 0NUMBERSK6,xy99 ]"and A33: "z =XBOOLE-0R4 z99"and A34: " *ARYTM-0K2( *ARYTM-0K2(x,y),z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,z99 *'ARYTM-2K8 xy99 ]"
        using A24 arytm_0_def_2 sorry
      have "x9 =XBOOLE-0R4 x99"
        using A27 A29 xtuple_0_th_1 sorry
      then have " *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =HIDDENR1 [TARSKIK4 0NUMBERSK6,(x99 *'ARYTM-2K8 y99)*'ARYTM-2K8 z99 ]"
        using A25 A26 A28 A30 A33 arytm_2_th_12 sorry
      also have "... =  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
        using A31 A32 A34 xtuple_0_th_1 sorry
      finally show " *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =HIDDENR1  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
         sorry
    qed
    have case4: "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & (z inTARSKIR2 REAL+ARYTM-2K2 & z <>HIDDENR2 0NUMBERSK6)) implies  *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =HIDDENR1  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
    proof(rule impMI ,rule impMI ,rule impI)
      assume A35: "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
        and A36: "y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
        and A37: "z inTARSKIR2 REAL+ARYTM-2K2 & z <>HIDDENR2 0NUMBERSK6"
      obtain x99 y99 where
        [ty]:"x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A38: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 ]"and A39: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 ]"and A40: " *ARYTM-0K2(x,y) =XBOOLE-0R4 y99 *'ARYTM-2K8 x99"
        using A35 A36 arytm_0_def_2 sorry
      obtain y9 z9 where
        [ty]:"y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A41: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]"and A42: "z =XBOOLE-0R4 z9"and A43: " *ARYTM-0K2(y,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,z9 *'ARYTM-2K8 y9 ]"
        using A36 A37 arytm_0_def_2 sorry
      have A44: "y9 =XBOOLE-0R4 y99"
        using A41 A39 xtuple_0_th_1 sorry
      have " *ARYTM-0K2(y,z) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
        using A43 arytm_0_lm_1 sorry
      then obtain x9 yz9 where
        [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "yz9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A45: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]"and A46: " *ARYTM-0K2(y,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,yz9 ] &  *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =XBOOLE-0R4 yz9 *'ARYTM-2K8 x9"
        using A35 arytm_0_def_2 sorry
      have A47: "x9 =XBOOLE-0R4 x99"
        using A45 A38 xtuple_0_th_1 sorry
      have A48: " ex xy99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex z99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st ( *ARYTM-0K2(x,y) =XBOOLE-0R4 xy99 & z =XBOOLE-0R4 z99) &  *ARYTM-0K2( *ARYTM-0K2(x,y),z) =XBOOLE-0R4 xy99 *'ARYTM-2K8 z99"
        using A37 A40 arytm_0_def_2 sorry
      have " *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =HIDDENR1 x9 *'ARYTM-2K8 (y9 *'ARYTM-2K8 z9)"
        using A43 A46 xtuple_0_th_1 sorry
      also have "... =  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
        using A42 A40 A48 A47 A44 arytm_2_th_12 sorry
      finally show " *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =HIDDENR1  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
         sorry
    qed
    have case5: "(x inTARSKIR2 REAL+ARYTM-2K2 & x <>HIDDENR2 0NUMBERSK6) & ((y inTARSKIR2 REAL+ARYTM-2K2 & y <>HIDDENR2 0NUMBERSK6) & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) implies  *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =HIDDENR1  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
    proof(rule impMI ,rule impMI ,rule impI)
      assume A49: "x inTARSKIR2 REAL+ARYTM-2K2 & x <>HIDDENR2 0NUMBERSK6"
        and A50: "y inTARSKIR2 REAL+ARYTM-2K2 & y <>HIDDENR2 0NUMBERSK6"
        and A51: "z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
      have A52: " ex x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x99 & y =XBOOLE-0R4 y99) &  *ARYTM-0K2(x,y) =XBOOLE-0R4 x99 *'ARYTM-2K8 y99"
        using A49 A50 arytm_0_def_2 sorry
      then have " *ARYTM-0K2(x,y) <>HIDDENR2 0NUMBERSK6"
        using A49 A50 arytm_1_th_2 sorry
      then obtain xy99 z99 where
        [ty]:"xy99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A53: " *ARYTM-0K2(x,y) =XBOOLE-0R4 xy99"and A54: "z =HIDDENR1 [TARSKIK4 0NUMBERSK6,z99 ]"and A55: " *ARYTM-0K2( *ARYTM-0K2(x,y),z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,xy99 *'ARYTM-2K8 z99 ]"
        using A51 A52 arytm_0_def_2 sorry
      obtain y9 z9 where
        [ty]:"y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A56: "y =XBOOLE-0R4 y9"and A57: "z =HIDDENR1 [TARSKIK4 0NUMBERSK6,z9 ]"and A58: " *ARYTM-0K2(y,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 *'ARYTM-2K8 z9 ]"
        using A50 A51 arytm_0_def_2 sorry
      have A59: "z9 =XBOOLE-0R4 z99"
        using A57 A54 xtuple_0_th_1 sorry
      have " *ARYTM-0K2(y,z) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
        using A58 arytm_0_lm_1 sorry
      then obtain x9 yz9 where
        [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "yz9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A60: "x =XBOOLE-0R4 x9"and A61: " *ARYTM-0K2(y,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,yz9 ] &  *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 *'ARYTM-2K8 yz9 ]"
        using A49 arytm_0_def_2 sorry
      have " *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 *'ARYTM-2K8 (y9 *'ARYTM-2K8 z9) ]"
        using A58 A61 xtuple_0_th_1 sorry
      also have "... =  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
        using A56 A60 A52 A53 A55 A59 arytm_2_th_12 sorry
      finally show " *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =HIDDENR1  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
         sorry
    qed
    have case6: "(x inTARSKIR2 REAL+ARYTM-2K2 & x <>HIDDENR2 0NUMBERSK6) & (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) implies  *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =HIDDENR1  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
    proof(rule impMI ,rule impMI ,rule impI)
      assume A62: "x inTARSKIR2 REAL+ARYTM-2K2 & x <>HIDDENR2 0NUMBERSK6"
        and A63: "y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
        and A64: "z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
      obtain y9 z9 where
        [ty]:"y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A65: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]"and A66: "z =HIDDENR1 [TARSKIK4 0NUMBERSK6,z9 ]"and A67: " *ARYTM-0K2(y,z) =XBOOLE-0R4 z9 *'ARYTM-2K8 y9"
        using A63 A64 arytm_0_def_2 sorry
      have A68: " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex yz9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 &  *ARYTM-0K2(y,z) =XBOOLE-0R4 yz9) &  *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =XBOOLE-0R4 x9 *'ARYTM-2K8 yz9"
        using A62 A67 arytm_0_def_2 sorry
      obtain x99 y99 where
        [ty]:"x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A69: "x =XBOOLE-0R4 x99"and A70: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 ]"and A71: " *ARYTM-0K2(x,y) =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 *'ARYTM-2K8 y99 ]"
        using A62 A63 arytm_0_def_2 sorry
      have A72: "y9 =XBOOLE-0R4 y99"
        using A65 A70 xtuple_0_th_1 sorry
      have " *ARYTM-0K2(x,y) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
        using A71 arytm_0_lm_1 sorry
      then obtain xy99 z99 where
        [ty]:"xy99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A73: " *ARYTM-0K2(x,y) =HIDDENR1 [TARSKIK4 0NUMBERSK6,xy99 ]"and A74: "z =HIDDENR1 [TARSKIK4 0NUMBERSK6,z99 ]"and A75: " *ARYTM-0K2( *ARYTM-0K2(x,y),z) =XBOOLE-0R4 z99 *'ARYTM-2K8 xy99"
        using A64 arytm_0_def_2 sorry
      have "z9 =XBOOLE-0R4 z99"
        using A66 A74 xtuple_0_th_1 sorry
      then have " *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =HIDDENR1 (x99 *'ARYTM-2K8 y99)*'ARYTM-2K8 z99"
        using A67 A68 A69 A72 arytm_2_th_12 sorry
      also have "... =  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
        using A71 A73 A75 xtuple_0_th_1 sorry
      finally show " *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =HIDDENR1  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
         sorry
    qed
    have case7: "(y inTARSKIR2 REAL+ARYTM-2K2 & y <>HIDDENR2 0NUMBERSK6) & (x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) implies  *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =HIDDENR1  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
    proof(rule impMI ,rule impMI ,rule impI)
      assume A76: "y inTARSKIR2 REAL+ARYTM-2K2 & y <>HIDDENR2 0NUMBERSK6"
        and A77: "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
        and A78: "z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
      obtain x99 y99 where
        [ty]:"x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A79: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 ]"and A80: "y =XBOOLE-0R4 y99"and A81: " *ARYTM-0K2(x,y) =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 *'ARYTM-2K8 x99 ]"
        using A76 A77 arytm_0_def_2 sorry
      obtain y9 z9 where
        [ty]:"y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A82: "y =XBOOLE-0R4 y9"and A83: "z =HIDDENR1 [TARSKIK4 0NUMBERSK6,z9 ]"and A84: " *ARYTM-0K2(y,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 *'ARYTM-2K8 z9 ]"
        using A76 A78 arytm_0_def_2 sorry
      have "[TARSKIK4 0NUMBERSK6,y9 *'ARYTM-2K8 z9 ] inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
        using arytm_0_lm_1 sorry
      then obtain x9 yz9 where
        [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "yz9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A85: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]"and A86: " *ARYTM-0K2(y,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,yz9 ] &  *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =XBOOLE-0R4 yz9 *'ARYTM-2K8 x9"
        using A77 A84 arytm_0_def_2 sorry
      have A87: "x9 =XBOOLE-0R4 x99"
        using A85 A79 xtuple_0_th_1 sorry
      have " *ARYTM-0K2(x,y) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
        using A81 arytm_0_lm_1 sorry
      then obtain xy99 z99 where
        [ty]:"xy99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A88: " *ARYTM-0K2(x,y) =HIDDENR1 [TARSKIK4 0NUMBERSK6,xy99 ]"and A89: "z =HIDDENR1 [TARSKIK4 0NUMBERSK6,z99 ]"and A90: " *ARYTM-0K2( *ARYTM-0K2(x,y),z) =XBOOLE-0R4 z99 *'ARYTM-2K8 xy99"
        using A78 arytm_0_def_2 sorry
      have A91: "z9 =XBOOLE-0R4 z99"
        using A83 A89 xtuple_0_th_1 sorry
      have " *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =HIDDENR1 x9 *'ARYTM-2K8 (y9 *'ARYTM-2K8 z9)"
        using A84 A86 xtuple_0_th_1 sorry
      also have "... = (x99 *'ARYTM-2K8 y99)*'ARYTM-2K8 z99"
        using A82 A80 A87 A91 arytm_2_th_12 sorry
      also have "... =  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
        using A81 A88 A90 xtuple_0_th_1 sorry
      finally show " *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =HIDDENR1  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
         sorry
    qed
    have case8: "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) implies  *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =XBOOLE-0R4  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
    proof(rule impMI ,rule impMI ,rule impI)
      assume A92: "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
        and A93: "y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
        and A94: "z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
      obtain y9 z9 where
        [ty]:"y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A95: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]"and A96: "z =HIDDENR1 [TARSKIK4 0NUMBERSK6,z9 ]"and A97: " *ARYTM-0K2(y,z) =XBOOLE-0R4 z9 *'ARYTM-2K8 y9"
        using A93 A94 arytm_0_def_2 sorry
      have " not y inTARSKIR2 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
        using xboole_0_def_5 sorry
      then have A98: "y9 <>HIDDENR2 0NUMBERSK6"
        using A95 tarski_def_1 sorry
      have " not z inTARSKIR2 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
        using xboole_0_def_5 sorry
      then have "z9 <>HIDDENR2 0NUMBERSK6"
        using A96 tarski_def_1 sorry
      then have " *ARYTM-0K2(z,y) <>HIDDENR2 0NUMBERSK6"
        using A97 A98 arytm_1_th_2 sorry
      then obtain x9 yz9 where
        [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "yz9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A99: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]"and A100: " *ARYTM-0K2(y,z) =XBOOLE-0R4 yz9 &  *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =HIDDENR1 [TARSKIK4 0NUMBERSK6,yz9 *'ARYTM-2K8 x9 ]"
        using A92 A97 arytm_0_def_2 sorry
      obtain x99 y99 where
        [ty]:"x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A101: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 ]"and A102: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 ]"and A103: " *ARYTM-0K2(x,y) =XBOOLE-0R4 y99 *'ARYTM-2K8 x99"
        using A92 A93 arytm_0_def_2 sorry
      have A104: "x9 =XBOOLE-0R4 x99"
        using A99 A101 xtuple_0_th_1 sorry
      have A105: "y9 =XBOOLE-0R4 y99"
        using A95 A102 xtuple_0_th_1 sorry
      have " not y inTARSKIR2 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
        using xboole_0_def_5 sorry
      then have A106: "y9 <>HIDDENR2 0NUMBERSK6"
        using A95 tarski_def_1 sorry
      have " not x inTARSKIR2 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
        using xboole_0_def_5 sorry
      then have "x9 <>HIDDENR2 0NUMBERSK6"
        using A99 tarski_def_1 sorry
      then have " *ARYTM-0K2(x,y) <>HIDDENR2 0NUMBERSK6"
        using A103 A104 A105 A106 arytm_1_th_2 sorry
      then obtain xy99 z99 where
        [ty]:"xy99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A107: " *ARYTM-0K2(x,y) =XBOOLE-0R4 xy99"and A108: "z =HIDDENR1 [TARSKIK4 0NUMBERSK6,z99 ]"and A109: " *ARYTM-0K2( *ARYTM-0K2(x,y),z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,xy99 *'ARYTM-2K8 z99 ]"
        using A94 A103 arytm_0_def_2 sorry
      have "z9 =XBOOLE-0R4 z99"
        using A96 A108 xtuple_0_th_1 sorry
      thus " *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =XBOOLE-0R4  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
        using A97 A100 A103 A104 A105 A107 A109 arytm_2_th_12 sorry
    qed
    have case9: "x =XBOOLE-0R4 0NUMBERSK6 implies  *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =HIDDENR1  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
    proof(rule impI)
      assume A110: "x =XBOOLE-0R4 0NUMBERSK6"
      then have " *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =HIDDENR1 0NUMBERSK6"
        using arytm_0_th_12 sorry
      also have "... =  *ARYTM-0K2(o,z)"
        using arytm_0_th_12 sorry
      also have "... =  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
        using A110 arytm_0_th_12 sorry
      finally show " *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =HIDDENR1  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
         sorry
    qed
    have case10: "y =XBOOLE-0R4 0NUMBERSK6 implies  *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =HIDDENR1  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
    proof(rule impI)
      assume A111: "y =XBOOLE-0R4 0NUMBERSK6"
      then have " *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =HIDDENR1  *ARYTM-0K2(x,o)"
        using arytm_0_th_12 sorry
      also have "... = 0NUMBERSK6"
        using arytm_0_th_12 sorry
      also have "... =  *ARYTM-0K2(o,z)"
        using arytm_0_th_12 sorry
      also have "... =  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
        using A111 arytm_0_th_12 sorry
      finally show " *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =HIDDENR1  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
         sorry
    qed
    have case11: "z =XBOOLE-0R4 0NUMBERSK6 implies  *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =HIDDENR1  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
    proof(rule impI)
      assume A112: "z =XBOOLE-0R4 0NUMBERSK6"
      then have " *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =HIDDENR1  *ARYTM-0K2(x,o)"
        using arytm_0_th_12 sorry
      also have "... = 0NUMBERSK6"
        using arytm_0_th_12 sorry
      also have "... =  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
        using A112 arytm_0_th_12 sorry
      finally show " *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =HIDDENR1  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
         sorry
    qed
    have case12: "(((((( not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & z inTARSKIR2 REAL+ARYTM-2K2) &  not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) & z inTARSKIR2 REAL+ARYTM-2K2)) &  not ((y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) & z inTARSKIR2 REAL+ARYTM-2K2)) &  not ((x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) & z inTARSKIR2 REAL+ARYTM-2K2)) &  not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })) &  not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })) &  not ((y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })) &  not ((x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) implies  *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =XBOOLE-0R4  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
    proof(rule impI)
      assume A113: "(((((( not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & z inTARSKIR2 REAL+ARYTM-2K2) &  not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) & z inTARSKIR2 REAL+ARYTM-2K2)) &  not ((y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) & z inTARSKIR2 REAL+ARYTM-2K2)) &  not ((x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) & z inTARSKIR2 REAL+ARYTM-2K2)) &  not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })) &  not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })) &  not ((y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })) &  not ((x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })"
      have "REALNUMBERSK2 =HIDDENR1 (REAL+ARYTM-2K2 \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 {}ARYTM-3K12,{}ARYTM-3K12 ] })\\/XBOOLE-0K2 ([:ZFMISC-1K2 {TARSKIK1 {}ARYTM-3K12 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 {}ARYTM-3K12,{}ARYTM-3K12 ] })"
        using xboole_1_th_42 sorry
      also have "... = REAL+ARYTM-2K2 \\/XBOOLE-0K2 ([:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })"
        using arytm_2_th_3 zfmisc_1_th_57 sorry
      finally have "REALNUMBERSK2 =HIDDENR1 REAL+ARYTM-2K2 \\/XBOOLE-0K2 ([:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })"
         sorry
      thus " *ARYTM-0K2(x, *ARYTM-0K2(y,z)) =XBOOLE-0R4  *ARYTM-0K2( *ARYTM-0K2(x,y),z)"
        using A113 xboole_0_def_3 sorry
    qed
    show " ?thesis "
      using cases case1 case2 case3 case4 case5 case6 case7 case8 case9 case10 case11 case12 sorry
  qed
qed "sorry"

mtheorem arytm_0_th_14:
" for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for z be ElementSUBSET-1M1-of REALNUMBERSK2 holds  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
proof-
  have " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for z be ElementSUBSET-1M1-of REALNUMBERSK2 holds  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REALNUMBERSK2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REALNUMBERSK2"
    obtain o where 
      [ty]:"o be ElementSUBSET-1M1-of REALNUMBERSK2" and oDef:"o = 0NUMBERSK6"
      using arytm_0_lm_3 sorry
    show " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
    proof-
      have cases: "((((((((x =XBOOLE-0R4 0NUMBERSK6 or x inTARSKIR2 REAL+ARYTM-2K2 & (y inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 REAL+ARYTM-2K2)) or (x inTARSKIR2 REAL+ARYTM-2K2 & x <>HIDDENR2 0NUMBERSK6) & (y inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })) or (x inTARSKIR2 REAL+ARYTM-2K2 & x <>HIDDENR2 0NUMBERSK6) & (z inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })) or (x inTARSKIR2 REAL+ARYTM-2K2 & x <>HIDDENR2 0NUMBERSK6) & (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })) or x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & (y inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 REAL+ARYTM-2K2)) or x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & (y inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })) or x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & (z inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })) or x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })) or (((((( not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & z inTARSKIR2 REAL+ARYTM-2K2) &  not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })) &  not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) & z inTARSKIR2 REAL+ARYTM-2K2)) &  not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })) &  not ((x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & y inTARSKIR2 REAL+ARYTM-2K2) & z inTARSKIR2 REAL+ARYTM-2K2)) &  not ((x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & y inTARSKIR2 REAL+ARYTM-2K2) & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })) &  not ((x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) & z inTARSKIR2 REAL+ARYTM-2K2)) &  not ((x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })"
         sorry
      have case1: "x =XBOOLE-0R4 0NUMBERSK6 implies  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
      proof(rule impI)
        assume A1: "x =XBOOLE-0R4 0NUMBERSK6"
        then have " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 0NUMBERSK6"
          using arytm_0_th_12 sorry
        also have "... = +ARYTM-0K1(o,o)"
          using arytm_0_th_11 sorry
        also have "... = +ARYTM-0K1( *ARYTM-0K2(x,y),o)"
          using A1 arytm_0_th_12 sorry
        also have "... = +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
          using A1 arytm_0_th_12 sorry
        finally show " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
           sorry
      qed
      have case2: "x inTARSKIR2 REAL+ARYTM-2K2 & (y inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 REAL+ARYTM-2K2) implies  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
      proof(rule impMI ,rule impI)
        assume A2: "x inTARSKIR2 REAL+ARYTM-2K2"
          and A3: "y inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 REAL+ARYTM-2K2"
        have A4: "( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) &  *ARYTM-0K2(x,y) =XBOOLE-0R4 x9 *'ARYTM-2K8 y9) & ( ex x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x99 & z =XBOOLE-0R4 z9) &  *ARYTM-0K2(x,z) =XBOOLE-0R4 x99 *'ARYTM-2K8 z9)"
          using A2 A3 arytm_0_def_2 sorry
        then have A5: " ex xy9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex xz9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st ( *ARYTM-0K2(x,y) =XBOOLE-0R4 xy9 &  *ARYTM-0K2(x,z) =XBOOLE-0R4 xz9) & +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z)) =XBOOLE-0R4 xy9 +ARYTM-2K7 xz9"
          using arytm_0_def_1 sorry
        have A6: " ex y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex z99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (y =XBOOLE-0R4 y99 & z =XBOOLE-0R4 z99) & +ARYTM-0K1(y,z) =XBOOLE-0R4 y99 +ARYTM-2K7 z99"
          using A3 arytm_0_def_1 sorry
        then have " ex x999 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex yz9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x999 & +ARYTM-0K1(y,z) =XBOOLE-0R4 yz9) &  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 x999 *'ARYTM-2K8 yz9"
          using A2 arytm_0_def_2 sorry
        thus " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
          using A4 A5 A6 arytm_2_th_13 sorry
      qed
      have case3: "(x inTARSKIR2 REAL+ARYTM-2K2 & x <>HIDDENR2 0NUMBERSK6) & (y inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) implies  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A7: "x inTARSKIR2 REAL+ARYTM-2K2 & x <>HIDDENR2 0NUMBERSK6"
          and A8: "y inTARSKIR2 REAL+ARYTM-2K2"
          and A9: "z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
        obtain y99 z99 where
          [ty]:"y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A10: "y =XBOOLE-0R4 y99"and A11: "z =HIDDENR1 [TARSKIK4 0NUMBERSK6,z99 ]"and A12: "+ARYTM-0K1(y,z) =XBOOLE-0R4 y99 -ARYTM-1K2 z99"
          using A8 A9 arytm_0_def_1 sorry
        obtain x9 y9 where
          [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A13: "x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9"and A14: " *ARYTM-0K2(x,y) =XBOOLE-0R4 x9 *'ARYTM-2K8 y9"
          using A7 A8 arytm_0_def_2 sorry
        obtain x99 z9 where
          [ty]:"x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A15: "x =XBOOLE-0R4 x99"and A16: "z =HIDDENR1 [TARSKIK4 0NUMBERSK6,z9 ]"and A17: " *ARYTM-0K2(x,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 *'ARYTM-2K8 z9 ]"
          using A7 A9 arytm_0_def_2 sorry
        have " *ARYTM-0K2(x,z) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          using A17 arytm_0_lm_1 sorry
        then have A18: " ex xy9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex xz9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st ( *ARYTM-0K2(x,y) =XBOOLE-0R4 xy9 &  *ARYTM-0K2(x,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,xz9 ]) & +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z)) =XBOOLE-0R4 xy9 -ARYTM-1K2 xz9"
          using A14 arytm_0_def_1 sorry
        have A19: "z9 =XBOOLE-0R4 z99"
          using A16 A11 xtuple_0_th_1 sorry
        have " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
        proof-
          show " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
          proof-
            have cases: "z99 <='ARYTM-2R1 y99 or  not z99 <='ARYTM-2R1 y99"
               sorry
            have case1: "z99 <='ARYTM-2R1 y99 implies  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
            proof(rule impI)
              assume A20: "z99 <='ARYTM-2R1 y99"
              then have A21: "+ARYTM-0K1(y,z) =XBOOLE-0R4 y99 -'ARYTM-1K1 z99"
                using A12 arytm_1_def_2 sorry
              then have " ex x999 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex yz9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x999 & +ARYTM-0K1(y,z) =XBOOLE-0R4 yz9) &  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 x999 *'ARYTM-2K8 yz9"
                using A7 arytm_0_def_2 sorry
              then have " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 x9 *'ARYTM-2K8 y9 -ARYTM-1K2 x99 *'ARYTM-2K8 z9"
                using A13 A15 A10 A19 A20 A21 arytm_1_th_26 sorry
              also have "... = +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                using A14 A17 A18 xtuple_0_th_1 sorry
              finally show " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                 sorry
            qed
            have case2: " not z99 <='ARYTM-2R1 y99 implies  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
            proof(rule impI)
              assume A22: " not z99 <='ARYTM-2R1 y99"
              then have A23: "+ARYTM-0K1(y,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,z99 -'ARYTM-1K1 y99 ]"
                using A12 arytm_1_def_2 sorry
              then have "+ARYTM-0K1(y,z) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                using arytm_0_lm_1 sorry
              then obtain x999 yz9 where
                [ty]:"x999 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "yz9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
                A24: "x =XBOOLE-0R4 x999"and A25: "+ARYTM-0K1(y,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,yz9 ] &  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 [TARSKIK4 0NUMBERSK6,x999 *'ARYTM-2K8 yz9 ]"
                using A7 arytm_0_def_2 sorry
              have " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 [TARSKIK4 0NUMBERSK6,x999 *'ARYTM-2K8 (z99 -'ARYTM-1K1 y99) ]"
                using A23 A25 xtuple_0_th_1 sorry
              also have "... = x9 *'ARYTM-2K8 y9 -ARYTM-1K2 x99 *'ARYTM-2K8 z9"
                using A7 A13 A15 A10 A19 A22 A24 arytm_1_th_27 sorry
              also have "... = +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                using A14 A17 A18 xtuple_0_th_1 sorry
              finally show " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
           sorry
      qed
      have case4: "(x inTARSKIR2 REAL+ARYTM-2K2 & x <>HIDDENR2 0NUMBERSK6) & (z inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) implies  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A26: "x inTARSKIR2 REAL+ARYTM-2K2 & x <>HIDDENR2 0NUMBERSK6"
          and A27: "z inTARSKIR2 REAL+ARYTM-2K2"
          and A28: "y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
        obtain z99 y99 where
          [ty]:"z99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A29: "z =XBOOLE-0R4 z99"and A30: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 ]"and A31: "+ARYTM-0K1(z,y) =XBOOLE-0R4 z99 -ARYTM-1K2 y99"
          using A27 A28 arytm_0_def_1 sorry
        obtain x9 z9 where
          [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A32: "x =XBOOLE-0R4 x9 & z =XBOOLE-0R4 z9"and A33: " *ARYTM-0K2(x,z) =XBOOLE-0R4 x9 *'ARYTM-2K8 z9"
          using A26 A27 arytm_0_def_2 sorry
        obtain x99 y9 where
          [ty]:"x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A34: "x =XBOOLE-0R4 x99"and A35: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]"and A36: " *ARYTM-0K2(x,y) =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 *'ARYTM-2K8 y9 ]"
          using A26 A28 arytm_0_def_2 sorry
        have " *ARYTM-0K2(x,y) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          using A36 arytm_0_lm_1 sorry
        then have A37: " ex xz9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex xy9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st ( *ARYTM-0K2(x,z) =XBOOLE-0R4 xz9 &  *ARYTM-0K2(x,y) =HIDDENR1 [TARSKIK4 0NUMBERSK6,xy9 ]) & +ARYTM-0K1( *ARYTM-0K2(x,z), *ARYTM-0K2(x,y)) =XBOOLE-0R4 xz9 -ARYTM-1K2 xy9"
          using A33 arytm_0_def_1 sorry
        have A38: "y9 =XBOOLE-0R4 y99"
          using A35 A30 xtuple_0_th_1 sorry
        have " *ARYTM-0K2(x,+ARYTM-0K1(z,y)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,z), *ARYTM-0K2(x,y))"
        proof-
          show " *ARYTM-0K2(x,+ARYTM-0K1(z,y)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,z), *ARYTM-0K2(x,y))"
          proof-
            have cases: "y99 <='ARYTM-2R1 z99 or  not y99 <='ARYTM-2R1 z99"
               sorry
            have case1: "y99 <='ARYTM-2R1 z99 implies  *ARYTM-0K2(x,+ARYTM-0K1(z,y)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,z), *ARYTM-0K2(x,y))"
            proof(rule impI)
              assume A39: "y99 <='ARYTM-2R1 z99"
              then have A40: "+ARYTM-0K1(z,y) =XBOOLE-0R4 z99 -'ARYTM-1K1 y99"
                using A31 arytm_1_def_2 sorry
              then have " ex x999 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex zy9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x999 & +ARYTM-0K1(z,y) =XBOOLE-0R4 zy9) &  *ARYTM-0K2(x,+ARYTM-0K1(z,y)) =XBOOLE-0R4 x999 *'ARYTM-2K8 zy9"
                using A26 arytm_0_def_2 sorry
              then have " *ARYTM-0K2(x,+ARYTM-0K1(z,y)) =HIDDENR1 x9 *'ARYTM-2K8 z9 -ARYTM-1K2 x99 *'ARYTM-2K8 y9"
                using A32 A34 A29 A38 A39 A40 arytm_1_th_26 sorry
              also have "... = +ARYTM-0K1( *ARYTM-0K2(x,z), *ARYTM-0K2(x,y))"
                using A33 A36 A37 xtuple_0_th_1 sorry
              finally show " *ARYTM-0K2(x,+ARYTM-0K1(z,y)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,z), *ARYTM-0K2(x,y))"
                 sorry
            qed
            have case2: " not y99 <='ARYTM-2R1 z99 implies  *ARYTM-0K2(x,+ARYTM-0K1(z,y)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,z), *ARYTM-0K2(x,y))"
            proof(rule impI)
              assume A41: " not y99 <='ARYTM-2R1 z99"
              then have A42: "+ARYTM-0K1(z,y) =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 -'ARYTM-1K1 z99 ]"
                using A31 arytm_1_def_2 sorry
              then have "+ARYTM-0K1(z,y) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                using arytm_0_lm_1 sorry
              then obtain x999 zy9 where
                [ty]:"x999 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "zy9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
                A43: "x =XBOOLE-0R4 x999"and A44: "+ARYTM-0K1(z,y) =HIDDENR1 [TARSKIK4 0NUMBERSK6,zy9 ] &  *ARYTM-0K2(x,+ARYTM-0K1(z,y)) =HIDDENR1 [TARSKIK4 0NUMBERSK6,x999 *'ARYTM-2K8 zy9 ]"
                using A26 arytm_0_def_2 sorry
              have " *ARYTM-0K2(x,+ARYTM-0K1(z,y)) =HIDDENR1 [TARSKIK4 0NUMBERSK6,x999 *'ARYTM-2K8 (y99 -'ARYTM-1K1 z99) ]"
                using A42 A44 xtuple_0_th_1 sorry
              also have "... = x9 *'ARYTM-2K8 z9 -ARYTM-1K2 x99 *'ARYTM-2K8 y9"
                using A26 A32 A34 A29 A38 A41 A43 arytm_1_th_27 sorry
              also have "... = +ARYTM-0K1( *ARYTM-0K2(x,z), *ARYTM-0K2(x,y))"
                using A33 A36 A37 xtuple_0_th_1 sorry
              finally show " *ARYTM-0K2(x,+ARYTM-0K1(z,y)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,z), *ARYTM-0K2(x,y))"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
           sorry
      qed
      have case5: "(x inTARSKIR2 REAL+ARYTM-2K2 & x <>HIDDENR2 0NUMBERSK6) & (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) implies  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A45: "x inTARSKIR2 REAL+ARYTM-2K2 & x <>HIDDENR2 0NUMBERSK6"
          and A46: "y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
          and A47: "z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
        have " not (y inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) &  not (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & z inTARSKIR2 REAL+ARYTM-2K2)"
          using A46 A47 arytm_0_th_5 xboole_0_th_3 sorry
        then obtain y99 z99 where
          [ty]:"y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A48: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 ]"and A49: "z =HIDDENR1 [TARSKIK4 0NUMBERSK6,z99 ]"and A50: "+ARYTM-0K1(y,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 +ARYTM-2K7 z99 ]"
          using A46 arytm_0_def_1 sorry
        have "+ARYTM-0K1(y,z) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          using A50 arytm_0_lm_1 sorry
        then obtain x999 yz9 where
          [ty]:"x999 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "yz9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A51: "x =XBOOLE-0R4 x999"and A52: "+ARYTM-0K1(y,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,yz9 ] &  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 [TARSKIK4 0NUMBERSK6,x999 *'ARYTM-2K8 yz9 ]"
          using A45 arytm_0_def_2 sorry
        obtain x9 y9 where
          [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A53: "x =XBOOLE-0R4 x9"and A54: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]"and A55: " *ARYTM-0K2(x,y) =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 *'ARYTM-2K8 y9 ]"
          using A45 A46 arytm_0_def_2 sorry
        have A56: "y9 =XBOOLE-0R4 y99"
          using A54 A48 xtuple_0_th_1 sorry
        obtain x99 z9 where
          [ty]:"x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A57: "x =XBOOLE-0R4 x99"and A58: "z =HIDDENR1 [TARSKIK4 0NUMBERSK6,z9 ]"and A59: " *ARYTM-0K2(x,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 *'ARYTM-2K8 z9 ]"
          using A45 A47 arytm_0_def_2 sorry
        have " *ARYTM-0K2(x,z) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          using A59 arytm_0_lm_1 sorry
        then have A60: " not ( *ARYTM-0K2(x,y) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] &  *ARYTM-0K2(x,z) inTARSKIR2 REAL+ARYTM-2K2)"
          using arytm_0_th_5 xboole_0_th_3 sorry
        have " *ARYTM-0K2(x,y) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          using A55 arytm_0_lm_1 sorry
        then have " not ( *ARYTM-0K2(x,y) inTARSKIR2 REAL+ARYTM-2K2 &  *ARYTM-0K2(x,z) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
          using arytm_0_th_5 xboole_0_th_3 sorry
        then obtain xy9 xz9 where
          [ty]:"xy9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "xz9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A61: " *ARYTM-0K2(x,y) =HIDDENR1 [TARSKIK4 0NUMBERSK6,xy9 ]"and A62: " *ARYTM-0K2(x,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,xz9 ] & +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z)) =HIDDENR1 [TARSKIK4 0NUMBERSK6,xy9 +ARYTM-2K7 xz9 ]"
          using A55 A60 arytm_0_def_1 arytm_0_lm_1 sorry
        have A63: "xy9 =XBOOLE-0R4 x9 *'ARYTM-2K8 y9"
          using A55 A61 xtuple_0_th_1 sorry
        have A64: "z9 =XBOOLE-0R4 z99"
          using A58 A49 xtuple_0_th_1 sorry
        have " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 [TARSKIK4 0NUMBERSK6,x999 *'ARYTM-2K8 (y99 +ARYTM-2K7 z99) ]"
          using A50 A52 xtuple_0_th_1 sorry
        also have "... = [TARSKIK4 0NUMBERSK6,x9 *'ARYTM-2K8 y9 +ARYTM-2K7 x9 *'ARYTM-2K8 z9 ]"
          using A53 A51 A56 A64 arytm_2_th_13 sorry
        also have "... = +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
          using A53 A57 A59 A62 A63 xtuple_0_th_1 sorry
        finally show " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
           sorry
      qed
      have case6: "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & (y inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 REAL+ARYTM-2K2) implies  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A65: "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
          and A66: "y inTARSKIR2 REAL+ARYTM-2K2"
          and A67: "z inTARSKIR2 REAL+ARYTM-2K2"
        obtain y99 z99 where
          [ty]:"y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A68: "y =XBOOLE-0R4 y99"and A69: "z =XBOOLE-0R4 z99"and A70: "+ARYTM-0K1(y,z) =XBOOLE-0R4 y99 +ARYTM-2K7 z99"
          using A66 A67 arytm_0_def_1 sorry
        have " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
        proof-
          show " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
          proof-
            have cases: "((y <>HIDDENR2 0NUMBERSK6 & z <>HIDDENR2 0NUMBERSK6 or x =XBOOLE-0R4 0NUMBERSK6) or z =XBOOLE-0R4 0NUMBERSK6) or y =XBOOLE-0R4 0NUMBERSK6"
               sorry
            have case1: "y <>HIDDENR2 0NUMBERSK6 & z <>HIDDENR2 0NUMBERSK6 implies  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
            proof(rule impMI ,rule impI)
              assume A71: "y <>HIDDENR2 0NUMBERSK6"
                and A72: "z <>HIDDENR2 0NUMBERSK6"
              obtain x99 z9 where
                [ty]:"x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
                A73: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 ]"and A74: "z =XBOOLE-0R4 z9"and A75: " *ARYTM-0K2(x,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,z9 *'ARYTM-2K8 x99 ]"
                using A65 A67 A72 arytm_0_def_2 sorry
              have "y99 +ARYTM-2K7 z99 <>HIDDENR2 0NUMBERSK6"
                using A69 A72 arytm_2_th_5 sorry
              then obtain x999 yz9 where
                [ty]:"x999 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "yz9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
                A76: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x999 ]"and A77: "+ARYTM-0K1(y,z) =XBOOLE-0R4 yz9 &  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 [TARSKIK4 0NUMBERSK6,yz9 *'ARYTM-2K8 x999 ]"
                using A65 A70 arytm_0_def_2 sorry
              obtain x9 y9 where
                [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
                A78: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]"and A79: "y =XBOOLE-0R4 y9"and A80: " *ARYTM-0K2(x,y) =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 *'ARYTM-2K8 x9 ]"
                using A65 A66 A71 arytm_0_def_2 sorry
              have A81: "x99 =XBOOLE-0R4 x999"
                using A73 A76 xtuple_0_th_1 sorry
              have " *ARYTM-0K2(x,z) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                using A75 arytm_0_lm_1 sorry
              then have A82: " not ( *ARYTM-0K2(x,y) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] &  *ARYTM-0K2(x,z) inTARSKIR2 REAL+ARYTM-2K2)"
                using arytm_0_th_5 xboole_0_th_3 sorry
              have " *ARYTM-0K2(x,y) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                using A80 arytm_0_lm_1 sorry
              then have " not ( *ARYTM-0K2(x,y) inTARSKIR2 REAL+ARYTM-2K2 &  *ARYTM-0K2(x,z) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
                using arytm_0_th_5 xboole_0_th_3 sorry
              then obtain xy9 xz9 where
                [ty]:"xy9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "xz9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
                A83: " *ARYTM-0K2(x,y) =HIDDENR1 [TARSKIK4 0NUMBERSK6,xy9 ]"and A84: " *ARYTM-0K2(x,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,xz9 ] & +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z)) =HIDDENR1 [TARSKIK4 0NUMBERSK6,xy9 +ARYTM-2K7 xz9 ]"
                using A80 A82 arytm_0_def_1 arytm_0_lm_1 sorry
              have A85: "xy9 =XBOOLE-0R4 x9 *'ARYTM-2K8 y9"
                using A80 A83 xtuple_0_th_1 sorry
              have "x9 =XBOOLE-0R4 x99"
                using A78 A73 xtuple_0_th_1 sorry
              then have " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 *'ARYTM-2K8 y9 +ARYTM-2K7 x99 *'ARYTM-2K8 z9 ]"
                using A68 A69 A70 A79 A74 A77 A81 arytm_2_th_13 sorry
              also have "... = +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                using A75 A84 A85 xtuple_0_th_1 sorry
              finally show " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                 sorry
            qed
            have case2: "x =XBOOLE-0R4 0NUMBERSK6 implies  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
            proof(rule impI)
              assume A86: "x =XBOOLE-0R4 0NUMBERSK6"
              then have " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 0NUMBERSK6"
                using arytm_0_th_12 sorry
              also have "... = +ARYTM-0K1(o,o)"
                using arytm_0_th_11 sorry
              also have "... = +ARYTM-0K1( *ARYTM-0K2(x,y),o)"
                using A86 arytm_0_th_12 sorry
              also have "... = +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                using A86 arytm_0_th_12 sorry
              finally show " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                 sorry
            qed
            have case3: "z =XBOOLE-0R4 0NUMBERSK6 implies  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
            proof(rule impI)
              assume A87: "z =XBOOLE-0R4 0NUMBERSK6"
              then have " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1  *ARYTM-0K2(x,y)"
                using arytm_0_th_11 sorry
              also have "... = +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                using A87 arytm_0_th_11 arytm_0_th_12 sorry
              finally show " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                 sorry
            qed
            have case4: "y =XBOOLE-0R4 0NUMBERSK6 implies  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
            proof(rule impI)
              assume A88: "y =XBOOLE-0R4 0NUMBERSK6"
              then have " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1  *ARYTM-0K2(x,z)"
                using arytm_0_th_11 sorry
              also have "... = +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                using A88 arytm_0_th_11 arytm_0_th_12 sorry
              finally show " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 case3 case4 sorry
          qed
        qed
        thus " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
           sorry
      qed
      have case7: "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & (y inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) implies  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A89: "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
          and A90: "y inTARSKIR2 REAL+ARYTM-2K2"
          and A91: "z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
        obtain x99 z9 where
          [ty]:"x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A92: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 ]"and A93: "z =HIDDENR1 [TARSKIK4 0NUMBERSK6,z9 ]"and A94: " *ARYTM-0K2(x,z) =XBOOLE-0R4 z9 *'ARYTM-2K8 x99"
          using A89 A91 arytm_0_def_2 sorry
        have " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
        proof-
          show " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
          proof-
            have cases: "y <>HIDDENR2 0NUMBERSK6 or y =XBOOLE-0R4 0NUMBERSK6"
               sorry
            have case1: "y <>HIDDENR2 0NUMBERSK6 implies  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
            proof(rule impI)
              assume "y <>HIDDENR2 0NUMBERSK6"
              then obtain x9 y9 where
                [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
                A95: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]"and A96: "y =XBOOLE-0R4 y9"and A97: " *ARYTM-0K2(x,y) =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 *'ARYTM-2K8 x9 ]"
                using A89 A90 arytm_0_def_2 sorry
              have " *ARYTM-0K2(x,y) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                using A97 arytm_0_lm_1 sorry
              then obtain xy9 xz9 where
                [ty]:"xy9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "xz9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
                A98: " *ARYTM-0K2(x,y) =HIDDENR1 [TARSKIK4 0NUMBERSK6,xy9 ]"and A99: " *ARYTM-0K2(x,z) =XBOOLE-0R4 xz9 & +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z)) =XBOOLE-0R4 xz9 -ARYTM-1K2 xy9"
                using A94 arytm_0_def_1 sorry
              obtain y99 z99 where
                [ty]:"y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
                A100: "y =XBOOLE-0R4 y99"and A101: "z =HIDDENR1 [TARSKIK4 0NUMBERSK6,z99 ]"and A102: "+ARYTM-0K1(y,z) =XBOOLE-0R4 y99 -ARYTM-1K2 z99"
                using A91 A96 arytm_0_def_1 sorry
              have A103: "z9 =XBOOLE-0R4 z99"
                using A93 A101 xtuple_0_th_1 sorry
              have " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
              proof-
                show " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                proof-
                  have cases: "z99 <='ARYTM-2R1 y99 or  not z99 <='ARYTM-2R1 y99"
                     sorry
                  have case1: "z99 <='ARYTM-2R1 y99 implies  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                  proof(rule impI)
                    assume A104: "z99 <='ARYTM-2R1 y99"
                    then have A105: "+ARYTM-0K1(y,z) =XBOOLE-0R4 y99 -'ARYTM-1K1 z99"
                      using A102 arytm_1_def_2 sorry
                    have " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                    proof-
                      show " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                      proof-
                        have cases: "+ARYTM-0K1(y,z) <>HIDDENR2 0NUMBERSK6 or +ARYTM-0K1(y,z) =XBOOLE-0R4 0NUMBERSK6"
                           sorry
                        have case1: "+ARYTM-0K1(y,z) <>HIDDENR2 0NUMBERSK6 implies  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                        proof(rule impI)
                          assume A106: "+ARYTM-0K1(y,z) <>HIDDENR2 0NUMBERSK6"
                          then obtain x999 yz9 where
                            [ty]:"x999 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "yz9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
                            A107: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x999 ]"and A108: "+ARYTM-0K1(y,z) =XBOOLE-0R4 yz9 &  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 [TARSKIK4 0NUMBERSK6,yz9 *'ARYTM-2K8 x999 ]"
                            using A89 A105 arytm_0_def_2 sorry
                          have " not x inTARSKIR2 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
                            using xboole_0_def_5 sorry
                          then have A109: "x999 <>HIDDENR2 0NUMBERSK6"
                            using A107 tarski_def_1 sorry
                          have A110: "z9 =XBOOLE-0R4 z99"
                            using A93 A101 xtuple_0_th_1 sorry
                          have A111: "x9 =XBOOLE-0R4 x99"
                            using A92 A95 xtuple_0_th_1 sorry
                          have "x99 =XBOOLE-0R4 x999"
                            using A92 A107 xtuple_0_th_1 sorry
                          then have " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 x9 *'ARYTM-2K8 z9 -ARYTM-1K2 x9 *'ARYTM-2K8 y9"
                            using A96 A100 A104 A105 A106 A108 A111 A110 A109 arytm_1_th_28 sorry
                          also have "... = +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                            using A94 A97 A98 A99 A111 xtuple_0_th_1 sorry
                          finally show " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                             sorry
                        qed
                        have case2: "+ARYTM-0K1(y,z) =XBOOLE-0R4 0NUMBERSK6 implies  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                        proof(rule impI)
                          assume A112: "+ARYTM-0K1(y,z) =XBOOLE-0R4 0NUMBERSK6"
                          then have A113: "y99 =XBOOLE-0R4 z99"
                            using A104 A105 arytm_1_th_10 sorry
                          have A114: "xy9 =XBOOLE-0R4 x9 *'ARYTM-2K8 y9 & x9 =XBOOLE-0R4 x99"
                            using A92 A95 A97 A98 xtuple_0_th_1 sorry
                          have " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 0NUMBERSK6"
                            using A112 arytm_0_th_12 sorry
                          also have "... = +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                            using A94 A96 A100 A99 A103 A113 A114 arytm_1_th_18 sorry
                          finally show " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                             sorry
                        qed
                        show " ?thesis "
                          using cases case1 case2 sorry
                      qed
                    qed
                    thus " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                       sorry
                  qed
                  have case2: " not z99 <='ARYTM-2R1 y99 implies  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                  proof(rule impI)
                    assume A115: " not z99 <='ARYTM-2R1 y99"
                    then have A116: "+ARYTM-0K1(y,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,z99 -'ARYTM-1K1 y99 ]"
                      using A102 arytm_1_def_2 sorry
                    then have "+ARYTM-0K1(y,z) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                      using arytm_0_lm_1 sorry
                    then obtain x999 yz9 where
                      [ty]:"x999 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "yz9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
                      A117: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x999 ]"and A118: "+ARYTM-0K1(y,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,yz9 ] &  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 yz9 *'ARYTM-2K8 x999"
                      using A89 arytm_0_def_2 sorry
                    have A119: "x99 =XBOOLE-0R4 x999"
                      using A92 A117 xtuple_0_th_1 sorry
                    have A120: "x9 =XBOOLE-0R4 x99"
                      using A92 A95 xtuple_0_th_1 sorry
                    have " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 x999 *'ARYTM-2K8 (z99 -'ARYTM-1K1 y99)"
                      using A116 A118 xtuple_0_th_1 sorry
                    also have "... = x99 *'ARYTM-2K8 z9 -ARYTM-1K2 x9 *'ARYTM-2K8 y9"
                      using A96 A100 A103 A115 A120 A119 arytm_1_th_26 sorry
                    also have "... = +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                      using A94 A97 A98 A99 xtuple_0_th_1 sorry
                    finally show " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                       sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed
              thus " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                 sorry
            qed
            have case2: "y =XBOOLE-0R4 0NUMBERSK6 implies  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
            proof(rule impI)
              assume A121: "y =XBOOLE-0R4 0NUMBERSK6"
              then have " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1  *ARYTM-0K2(x,z)"
                using arytm_0_th_11 sorry
              also have "... = +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                using A121 arytm_0_th_11 arytm_0_th_12 sorry
              finally show " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
           sorry
      qed
      have case8: "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & (z inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) implies  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A122: "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
          and A123: "z inTARSKIR2 REAL+ARYTM-2K2"
          and A124: "y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
        obtain x99 y9 where
          [ty]:"x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A125: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 ]"and A126: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]"and A127: " *ARYTM-0K2(x,y) =XBOOLE-0R4 y9 *'ARYTM-2K8 x99"
          using A122 A124 arytm_0_def_2 sorry
        have " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
        proof-
          show " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
          proof-
            have cases: "z <>HIDDENR2 0NUMBERSK6 or z =XBOOLE-0R4 0NUMBERSK6"
               sorry
            have case1: "z <>HIDDENR2 0NUMBERSK6 implies  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
            proof(rule impI)
              assume "z <>HIDDENR2 0NUMBERSK6"
              then obtain x9 z9 where
                [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
                A128: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]"and A129: "z =XBOOLE-0R4 z9"and A130: " *ARYTM-0K2(x,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,z9 *'ARYTM-2K8 x9 ]"
                using A122 A123 arytm_0_def_2 sorry
              have " *ARYTM-0K2(x,z) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                using A130 arytm_0_lm_1 sorry
              then obtain xz9 xy9 where
                [ty]:"xz9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "xy9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
                A131: " *ARYTM-0K2(x,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,xz9 ]"and A132: " *ARYTM-0K2(x,y) =XBOOLE-0R4 xy9 & +ARYTM-0K1( *ARYTM-0K2(x,z), *ARYTM-0K2(x,y)) =XBOOLE-0R4 xy9 -ARYTM-1K2 xz9"
                using A127 arytm_0_def_1 sorry
              obtain z99 y99 where
                [ty]:"z99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
                A133: "z =XBOOLE-0R4 z99"and A134: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 ]"and A135: "+ARYTM-0K1(z,y) =XBOOLE-0R4 z99 -ARYTM-1K2 y99"
                using A124 A129 arytm_0_def_1 sorry
              have A136: "y9 =XBOOLE-0R4 y99"
                using A126 A134 xtuple_0_th_1 sorry
              have " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
              proof-
                show " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                proof-
                  have cases: "y99 <='ARYTM-2R1 z99 or  not y99 <='ARYTM-2R1 z99"
                     sorry
                  have case1: "y99 <='ARYTM-2R1 z99 implies  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                  proof(rule impI)
                    assume A137: "y99 <='ARYTM-2R1 z99"
                    then have A138: "+ARYTM-0K1(z,y) =XBOOLE-0R4 z99 -'ARYTM-1K1 y99"
                      using A135 arytm_1_def_2 sorry
                    have " *ARYTM-0K2(x,+ARYTM-0K1(z,y)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,z), *ARYTM-0K2(x,y))"
                    proof-
                      show " *ARYTM-0K2(x,+ARYTM-0K1(z,y)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,z), *ARYTM-0K2(x,y))"
                      proof-
                        have cases: "+ARYTM-0K1(z,y) <>HIDDENR2 0NUMBERSK6 or +ARYTM-0K1(z,y) =XBOOLE-0R4 0NUMBERSK6"
                           sorry
                        have case1: "+ARYTM-0K1(z,y) <>HIDDENR2 0NUMBERSK6 implies  *ARYTM-0K2(x,+ARYTM-0K1(z,y)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,z), *ARYTM-0K2(x,y))"
                        proof(rule impI)
                          assume A139: "+ARYTM-0K1(z,y) <>HIDDENR2 0NUMBERSK6"
                          then obtain x999 zy9 where
                            [ty]:"x999 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "zy9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
                            A140: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x999 ]"and A141: "+ARYTM-0K1(z,y) =XBOOLE-0R4 zy9 &  *ARYTM-0K2(x,+ARYTM-0K1(z,y)) =HIDDENR1 [TARSKIK4 0NUMBERSK6,zy9 *'ARYTM-2K8 x999 ]"
                            using A122 A138 arytm_0_def_2 sorry
                          have " not x inTARSKIR2 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
                            using xboole_0_def_5 sorry
                          then have A142: "x999 <>HIDDENR2 0NUMBERSK6"
                            using A140 tarski_def_1 sorry
                          have A143: "y9 =XBOOLE-0R4 y99"
                            using A126 A134 xtuple_0_th_1 sorry
                          have A144: "x9 =XBOOLE-0R4 x99"
                            using A125 A128 xtuple_0_th_1 sorry
                          have "x99 =XBOOLE-0R4 x999"
                            using A125 A140 xtuple_0_th_1 sorry
                          then have " *ARYTM-0K2(x,+ARYTM-0K1(z,y)) =HIDDENR1 x9 *'ARYTM-2K8 y9 -ARYTM-1K2 x9 *'ARYTM-2K8 z9"
                            using A129 A133 A137 A138 A139 A141 A144 A143 A142 arytm_1_th_28 sorry
                          also have "... = +ARYTM-0K1( *ARYTM-0K2(x,z), *ARYTM-0K2(x,y))"
                            using A127 A130 A131 A132 A144 xtuple_0_th_1 sorry
                          finally show " *ARYTM-0K2(x,+ARYTM-0K1(z,y)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,z), *ARYTM-0K2(x,y))"
                             sorry
                        qed
                        have case2: "+ARYTM-0K1(z,y) =XBOOLE-0R4 0NUMBERSK6 implies  *ARYTM-0K2(x,+ARYTM-0K1(z,y)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,z), *ARYTM-0K2(x,y))"
                        proof(rule impI)
                          assume A145: "+ARYTM-0K1(z,y) =XBOOLE-0R4 0NUMBERSK6"
                          then have A146: "z99 =XBOOLE-0R4 y99"
                            using A137 A138 arytm_1_th_10 sorry
                          have A147: "xz9 =XBOOLE-0R4 x9 *'ARYTM-2K8 z9 & x9 =XBOOLE-0R4 x99"
                            using A125 A128 A130 A131 xtuple_0_th_1 sorry
                          have " *ARYTM-0K2(x,+ARYTM-0K1(z,y)) =HIDDENR1 0NUMBERSK6"
                            using A145 arytm_0_th_12 sorry
                          also have "... = +ARYTM-0K1( *ARYTM-0K2(x,z), *ARYTM-0K2(x,y))"
                            using A127 A129 A133 A132 A136 A146 A147 arytm_1_th_18 sorry
                          finally show " *ARYTM-0K2(x,+ARYTM-0K1(z,y)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,z), *ARYTM-0K2(x,y))"
                             sorry
                        qed
                        show " ?thesis "
                          using cases case1 case2 sorry
                      qed
                    qed
                    thus " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                       sorry
                  qed
                  have case2: " not y99 <='ARYTM-2R1 z99 implies  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                  proof(rule impI)
                    assume A148: " not y99 <='ARYTM-2R1 z99"
                    then have A149: "+ARYTM-0K1(z,y) =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 -'ARYTM-1K1 z99 ]"
                      using A135 arytm_1_def_2 sorry
                    then have "+ARYTM-0K1(z,y) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                      using arytm_0_lm_1 sorry
                    then obtain x999 zy9 where
                      [ty]:"x999 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "zy9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
                      A150: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x999 ]"and A151: "+ARYTM-0K1(z,y) =HIDDENR1 [TARSKIK4 0NUMBERSK6,zy9 ] &  *ARYTM-0K2(x,+ARYTM-0K1(z,y)) =XBOOLE-0R4 zy9 *'ARYTM-2K8 x999"
                      using A122 arytm_0_def_2 sorry
                    have A152: "x99 =XBOOLE-0R4 x999"
                      using A125 A150 xtuple_0_th_1 sorry
                    have A153: "x9 =XBOOLE-0R4 x99"
                      using A125 A128 xtuple_0_th_1 sorry
                    have " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 x999 *'ARYTM-2K8 (y99 -'ARYTM-1K1 z99)"
                      using A149 A151 xtuple_0_th_1 sorry
                    also have "... = x99 *'ARYTM-2K8 y9 -ARYTM-1K2 x9 *'ARYTM-2K8 z9"
                      using A129 A133 A136 A148 A153 A152 arytm_1_th_26 sorry
                    also have "... = +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                      using A127 A130 A131 A132 xtuple_0_th_1 sorry
                    finally show " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                       sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed
              thus " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                 sorry
            qed
            have case2: "z =XBOOLE-0R4 0NUMBERSK6 implies  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
            proof(rule impI)
              assume A154: "z =XBOOLE-0R4 0NUMBERSK6"
              then have " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1  *ARYTM-0K2(x,y)"
                using arytm_0_th_11 sorry
              also have "... = +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                using A154 arytm_0_th_11 arytm_0_th_12 sorry
              finally show " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
           sorry
      qed
      have case9: "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) implies  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A155: "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
          and A156: "y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
          and A157: "z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
        have " not (y inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) &  not (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & z inTARSKIR2 REAL+ARYTM-2K2)"
          using A156 A157 arytm_0_th_5 xboole_0_th_3 sorry
        then obtain y99 z99 where
          [ty]:"y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A158: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 ]"and A159: "z =HIDDENR1 [TARSKIK4 0NUMBERSK6,z99 ]"and A160: "+ARYTM-0K1(y,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 +ARYTM-2K7 z99 ]"
          using A156 arytm_0_def_1 sorry
        obtain x99 z9 where
          [ty]:"x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A161: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 ]"and A162: "z =HIDDENR1 [TARSKIK4 0NUMBERSK6,z9 ]"and A163: " *ARYTM-0K2(x,z) =XBOOLE-0R4 z9 *'ARYTM-2K8 x99"
          using A155 A157 arytm_0_def_2 sorry
        have A164: "z9 =XBOOLE-0R4 z99"
          using A162 A159 xtuple_0_th_1 sorry
        obtain x9 y9 where
          [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A165: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]"and A166: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]"and A167: " *ARYTM-0K2(x,y) =XBOOLE-0R4 y9 *'ARYTM-2K8 x9"
          using A155 A156 arytm_0_def_2 sorry
        have A168: "y9 =XBOOLE-0R4 y99"
          using A166 A158 xtuple_0_th_1 sorry
        have "+ARYTM-0K1(y,z) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          using A160 arytm_0_lm_1 sorry
        then obtain x999 yz9 where
          [ty]:"x999 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "yz9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A169: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x999 ]"and A170: "+ARYTM-0K1(y,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,yz9 ] &  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 yz9 *'ARYTM-2K8 x999"
          using A155 arytm_0_def_2 sorry
        have A171: "x9 =XBOOLE-0R4 x999"
          using A165 A169 xtuple_0_th_1 sorry
        have A172: "( ex xy9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex xz9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st ( *ARYTM-0K2(x,y) =XBOOLE-0R4 xy9 &  *ARYTM-0K2(x,z) =XBOOLE-0R4 xz9) & +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z)) =XBOOLE-0R4 xy9 +ARYTM-2K7 xz9) & x9 =XBOOLE-0R4 x99"
          using A165 A167 A161 A163 arytm_0_def_1 xtuple_0_th_1 sorry
        have " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 x999 *'ARYTM-2K8 (y99 +ARYTM-2K7 z99)"
          using A160 A170 xtuple_0_th_1 sorry
        also have "... = +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
          using A167 A163 A172 A171 A168 A164 arytm_2_th_13 sorry
        finally show " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
           sorry
      qed
      have case10: "(((((( not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & z inTARSKIR2 REAL+ARYTM-2K2) &  not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })) &  not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) & z inTARSKIR2 REAL+ARYTM-2K2)) &  not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })) &  not ((x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & y inTARSKIR2 REAL+ARYTM-2K2) & z inTARSKIR2 REAL+ARYTM-2K2)) &  not ((x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & y inTARSKIR2 REAL+ARYTM-2K2) & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })) &  not ((x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) & z inTARSKIR2 REAL+ARYTM-2K2)) &  not ((x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) implies  *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
      proof(rule impI)
        assume A173: "(((((( not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & z inTARSKIR2 REAL+ARYTM-2K2) &  not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })) &  not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) & z inTARSKIR2 REAL+ARYTM-2K2)) &  not ((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })) &  not ((x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & y inTARSKIR2 REAL+ARYTM-2K2) & z inTARSKIR2 REAL+ARYTM-2K2)) &  not ((x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & y inTARSKIR2 REAL+ARYTM-2K2) & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })) &  not ((x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) & z inTARSKIR2 REAL+ARYTM-2K2)) &  not ((x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }) & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })"
        have "REALNUMBERSK2 =HIDDENR1 (REAL+ARYTM-2K2 \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })\\/XBOOLE-0K2 ([:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })"
          using xboole_1_th_42 sorry
        also have "... = REAL+ARYTM-2K2 \\/XBOOLE-0K2 ([:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })"
          using arytm_2_th_3 zfmisc_1_th_57 sorry
        finally have "REALNUMBERSK2 =HIDDENR1 REAL+ARYTM-2K2 \\/XBOOLE-0K2 ([:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] })"
           sorry
        thus " *ARYTM-0K2(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(x,y), *ARYTM-0K2(x,z))"
          using A173 xboole_0_def_3 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 case4 case5 case6 case7 case8 case9 case10 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_0_th_15:
" for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds  *ARYTM-0K2(oppARYTM-0K3 x,y) =XBOOLE-0R4 oppARYTM-0K3 ( *ARYTM-0K2(x,y))"
proof(rule ballI,rule ballI)
  fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
  fix y assume [ty]: "y be ElementSUBSET-1M1-of REALNUMBERSK2"
  have "+ARYTM-0K1( *ARYTM-0K2(oppARYTM-0K3 x,y), *ARYTM-0K2(x,y)) =HIDDENR1  *ARYTM-0K2(+ARYTM-0K1(oppARYTM-0K3 x,x),y)"
    using arytm_0_th_14 sorry
  also have "... = 0NUMBERSK6"
    using arytm_0_th_12 arytm_0_def_3 sorry
  finally have "+ARYTM-0K1( *ARYTM-0K2(oppARYTM-0K3 x,y), *ARYTM-0K2(x,y)) =HIDDENR1 0NUMBERSK6"
     sorry
  thus " *ARYTM-0K2(oppARYTM-0K3 x,y) =XBOOLE-0R4 oppARYTM-0K3 ( *ARYTM-0K2(x,y))"
    using arytm_0_def_3 sorry
qed "sorry"

mtheorem arytm_0_th_16:
" for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  *ARYTM-0K2(x,x) inTARSKIR2 REAL+ARYTM-2K2"
proof(rule ballI)
  fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
  have A1: "x inTARSKIR2 REAL+ARYTM-2K2 \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 {}ARYTM-3K12 },REAL+ARYTM-2K2 :]"
    using xboole_0_def_5 sorry
  show " *ARYTM-0K2(x,x) inTARSKIR2 REAL+ARYTM-2K2"
  proof-
    have cases: "x inTARSKIR2 REAL+ARYTM-2K2 or x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
      using A1 xboole_0_def_3 sorry
    have case1: "x inTARSKIR2 REAL+ARYTM-2K2 implies  *ARYTM-0K2(x,x) inTARSKIR2 REAL+ARYTM-2K2"
    proof(rule impI)
      assume "x inTARSKIR2 REAL+ARYTM-2K2"
      then have " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & x =XBOOLE-0R4 y9) &  *ARYTM-0K2(x,x) =XBOOLE-0R4 x9 *'ARYTM-2K8 y9"
        using arytm_0_def_2 sorry
      thus " *ARYTM-0K2(x,x) inTARSKIR2 REAL+ARYTM-2K2"
         sorry
    qed
    have case2: "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies  *ARYTM-0K2(x,x) inTARSKIR2 REAL+ARYTM-2K2"
    proof(rule impI)
      assume "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
      then have " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & x =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) &  *ARYTM-0K2(x,x) =XBOOLE-0R4 y9 *'ARYTM-2K8 x9"
        using arytm_0_def_2 sorry
      thus " *ARYTM-0K2(x,x) inTARSKIR2 REAL+ARYTM-2K2"
         sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem arytm_0_th_17:
" for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds +ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y)) =XBOOLE-0R4 0NUMBERSK6 implies x =XBOOLE-0R4 0NUMBERSK6"
proof(rule ballI,rule ballI,rule impI)
  fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
  fix y assume [ty]: "y be ElementSUBSET-1M1-of REALNUMBERSK2"
  assume A1: "+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y)) =XBOOLE-0R4 0NUMBERSK6"
  have " *ARYTM-0K2(x,x) inTARSKIR2 REAL+ARYTM-2K2 &  *ARYTM-0K2(y,y) inTARSKIR2 REAL+ARYTM-2K2"
    using arytm_0_th_16 sorry
  then obtain x9 y9 where
    [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
    A2: " *ARYTM-0K2(x,x) =XBOOLE-0R4 x9"and " *ARYTM-0K2(y,y) =XBOOLE-0R4 y9"and A3: "0NUMBERSK6 =XBOOLE-0R4 x9 +ARYTM-2K7 y9"
    using A1 arytm_0_def_1 sorry
  have A4: "x9 =XBOOLE-0R4 0NUMBERSK6"
    using A3 arytm_2_th_5 sorry
  have A5: "x inTARSKIR2 REAL+ARYTM-2K2 \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 {}ARYTM-3K12 },REAL+ARYTM-2K2 :]"
    using xboole_0_def_5 sorry
  show "x =XBOOLE-0R4 0NUMBERSK6"
  proof-
    have cases: "x inTARSKIR2 REAL+ARYTM-2K2 or x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
      using A5 xboole_0_def_3 sorry
    have case1: "x inTARSKIR2 REAL+ARYTM-2K2 implies x =XBOOLE-0R4 0NUMBERSK6"
    proof(rule impI)
      assume "x inTARSKIR2 REAL+ARYTM-2K2"
      then have " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & x =XBOOLE-0R4 y9) & 0NUMBERSK6 =XBOOLE-0R4 x9 *'ARYTM-2K8 y9"
        using A2 A4 arytm_0_def_2 sorry
      thus "x =XBOOLE-0R4 0NUMBERSK6"
        using arytm_1_th_2 sorry
    qed
    have case2: "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies x =XBOOLE-0R4 0NUMBERSK6"
    proof(rule impI)
      assume "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
      then obtain x9 y9 where
        [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A6: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]"and A7: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]"and A8: "0NUMBERSK6 =XBOOLE-0R4 y9 *'ARYTM-2K8 x9"
        using A2 A4 arytm_0_def_2 sorry
      have "x9 =XBOOLE-0R4 y9"
        using A6 A7 xtuple_0_th_1 sorry
      then have "x9 =XBOOLE-0R4 0NUMBERSK6"
        using A8 arytm_1_th_2 sorry
      then have "x inTARSKIR2 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
        using A6 tarski_def_1 sorry
      thus "x =XBOOLE-0R4 0NUMBERSK6"
        using xboole_0_def_5 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem arytm_0_th_18:
" for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for z be ElementSUBSET-1M1-of REALNUMBERSK2 holds (x <>HIDDENR2 0NUMBERSK6 &  *ARYTM-0K2(x,y) =XBOOLE-0R4 \<one>\<^sub>M) &  *ARYTM-0K2(x,z) =XBOOLE-0R4 \<one>\<^sub>M implies y =XBOOLE-0R4 z"
proof-
  have " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for z be ElementSUBSET-1M1-of REALNUMBERSK2 holds x <>HIDDENR2 0NUMBERSK6 & ( *ARYTM-0K2(x,y) =XBOOLE-0R4 \<one>\<^sub>M &  *ARYTM-0K2(x,z) =XBOOLE-0R4 \<one>\<^sub>M) implies y =HIDDENR1 z"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REALNUMBERSK2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REALNUMBERSK2"
    assume A1: "x <>HIDDENR2 0NUMBERSK6"
      and A2: " *ARYTM-0K2(x,y) =XBOOLE-0R4 \<one>\<^sub>M"
      and A3: " *ARYTM-0K2(x,z) =XBOOLE-0R4 \<one>\<^sub>M"
    have "y =HIDDENR1 invARYTM-0K4 x"
      using A1 A2 arytm_0_def_4 sorry
    also have "... = z"
      using A1 A3 arytm_0_def_4 sorry
    finally show "y =HIDDENR1 z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_0_th_19:
" for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds y =XBOOLE-0R4 \<one>\<^sub>M implies  *ARYTM-0K2(x,y) =XBOOLE-0R4 x"
proof(rule ballI,rule ballI,rule impI)
  fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
  fix y assume [ty]: "y be ElementSUBSET-1M1-of REALNUMBERSK2"
  assume A1: "y =XBOOLE-0R4 \<one>\<^sub>M"
  show " *ARYTM-0K2(x,y) =XBOOLE-0R4 x"
  proof-
    have cases: "x =XBOOLE-0R4 0NUMBERSK6 or x <>HIDDENR2 0NUMBERSK6"
       sorry
    have case1: "x =XBOOLE-0R4 0NUMBERSK6 implies  *ARYTM-0K2(x,y) =XBOOLE-0R4 x"
    proof(rule impI)
      assume "x =XBOOLE-0R4 0NUMBERSK6"
      thus " *ARYTM-0K2(x,y) =XBOOLE-0R4 x"
        using arytm_0_th_12 sorry
    qed
    have case2: "x <>HIDDENR2 0NUMBERSK6 implies  *ARYTM-0K2(x,y) =XBOOLE-0R4 x"
    proof(rule impI)
      assume A2: "x <>HIDDENR2 0NUMBERSK6"
      have A3: "invARYTM-0K4 x =XBOOLE-0R4 0NUMBERSK6 implies \<one>\<^sub>M =HIDDENR1 0NUMBERSK6"
      proof(rule impI)
        assume A4: "invARYTM-0K4 x =XBOOLE-0R4 0NUMBERSK6"
        have "\<one>\<^sub>M =HIDDENR1  *ARYTM-0K2(x,invARYTM-0K4 x)"
          using A2 arytm_0_def_4 sorry
        also have "... = 0NUMBERSK6"
          using A4 arytm_0_th_12 sorry
        finally show "\<one>\<^sub>M =HIDDENR1 0NUMBERSK6"
           sorry
      qed
      have A5: " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (y =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) &  *ARYTM-0K2(y,y) =XBOOLE-0R4 x9 *'ARYTM-2K8 y9"
        using A1 arytm_0_def_2 arytm_2_th_20 sorry
      have A6: " *ARYTM-0K2(x,invARYTM-0K4 x) =XBOOLE-0R4 \<one>\<^sub>M"
        using A2 arytm_0_def_4 sorry
      have " *ARYTM-0K2( *ARYTM-0K2(x,y),invARYTM-0K4 x) =HIDDENR1  *ARYTM-0K2( *ARYTM-0K2(x,invARYTM-0K4 x),y)"
        using arytm_0_th_13 sorry
      also have "... =  *ARYTM-0K2(y,y)"
        using A1 A2 arytm_0_def_4 sorry
      also have "... = \<one>\<^sub>M"
        using A1 A5 arytm_2_th_15 sorry
      finally have " *ARYTM-0K2( *ARYTM-0K2(x,y),invARYTM-0K4 x) =HIDDENR1 \<one>\<^sub>M"
         sorry
      thus " *ARYTM-0K2(x,y) =XBOOLE-0R4 x"
        using A3 A6 arytm_0_th_18 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem arytm_0_th_20:
" for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds y <>HIDDENR2 0NUMBERSK6 implies  *ARYTM-0K2( *ARYTM-0K2(x,y),invARYTM-0K4 y) =XBOOLE-0R4 x"
proof-
  have " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds y <>HIDDENR2 0NUMBERSK6 implies  *ARYTM-0K2( *ARYTM-0K2(x,y),invARYTM-0K4 y) =HIDDENR1 x"
  proof(rule ballI,rule ballI,rule impI)
    obtain jj where 
      [ty]:"jj be ElementSUBSET-1M1-of REALNUMBERSK2" and jjDef:"jj = \<one>\<^sub>M"
      using numbers_th_19 sorry
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REALNUMBERSK2"
    assume A1: "y <>HIDDENR2 0NUMBERSK6"
    have " *ARYTM-0K2( *ARYTM-0K2(x,y),invARYTM-0K4 y) =HIDDENR1  *ARYTM-0K2(x, *ARYTM-0K2(y,invARYTM-0K4 y))"
      using arytm_0_th_13 sorry
    also have "... =  *ARYTM-0K2(x,jj)"
      using A1 arytm_0_def_4 sorry
    also have "... = x"
      using arytm_0_th_19 sorry
    finally show " *ARYTM-0K2( *ARYTM-0K2(x,y),invARYTM-0K4 y) =HIDDENR1 x"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_0_th_21:
" for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds  *ARYTM-0K2(x,y) =XBOOLE-0R4 0NUMBERSK6 implies x =XBOOLE-0R4 0NUMBERSK6 or y =XBOOLE-0R4 0NUMBERSK6"
proof-
  have " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds  *ARYTM-0K2(x,y) =XBOOLE-0R4 0NUMBERSK6 & x <>HIDDENR2 0NUMBERSK6 implies y =HIDDENR1 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    obtain jj where 
      [ty]:"jj be ElementSUBSET-1M1-of REALNUMBERSK2" and jjDef:"jj = \<one>\<^sub>M"
      using numbers_th_19 sorry
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REALNUMBERSK2"
    assume A1: " *ARYTM-0K2(x,y) =XBOOLE-0R4 0NUMBERSK6"
      and A2: "x <>HIDDENR2 0NUMBERSK6"
    have A3: " *ARYTM-0K2(x,invARYTM-0K4 x) =XBOOLE-0R4 \<one>\<^sub>M"
      using A2 arytm_0_def_4 sorry
    have "y =HIDDENR1  *ARYTM-0K2(jj,y)"
      using arytm_0_th_19 sorry
    also have "... =  *ARYTM-0K2( *ARYTM-0K2(x,y),invARYTM-0K4 x)"
      using A3 arytm_0_th_13 sorry
    also have "... = 0NUMBERSK6"
      using A1 arytm_0_th_12 sorry
    finally show "y =HIDDENR1 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_0_th_22:
" for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds invARYTM-0K4 ( *ARYTM-0K2(x,y)) =XBOOLE-0R4  *ARYTM-0K2(invARYTM-0K4 x,invARYTM-0K4 y)"
proof-
  have " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds invARYTM-0K4 ( *ARYTM-0K2(x,y)) =HIDDENR1  *ARYTM-0K2(invARYTM-0K4 x,invARYTM-0K4 y)"
  proof(rule ballI,rule ballI)
    obtain jj where 
      [ty]:"jj be ElementSUBSET-1M1-of REALNUMBERSK2" and jjDef:"jj = \<one>\<^sub>M"
      using numbers_th_19 sorry
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REALNUMBERSK2"
    show "invARYTM-0K4 ( *ARYTM-0K2(x,y)) =HIDDENR1  *ARYTM-0K2(invARYTM-0K4 x,invARYTM-0K4 y)"
    proof-
      have cases: "(x =XBOOLE-0R4 0NUMBERSK6 or y =XBOOLE-0R4 0NUMBERSK6) or x <>HIDDENR2 0NUMBERSK6 & y <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "x =XBOOLE-0R4 0NUMBERSK6 or y =XBOOLE-0R4 0NUMBERSK6 implies invARYTM-0K4 ( *ARYTM-0K2(x,y)) =HIDDENR1  *ARYTM-0K2(invARYTM-0K4 x,invARYTM-0K4 y)"
      proof(rule impI)
        assume A1: "x =XBOOLE-0R4 0NUMBERSK6 or y =XBOOLE-0R4 0NUMBERSK6"
        then have A2: "invARYTM-0K4 x =XBOOLE-0R4 0NUMBERSK6 or invARYTM-0K4 y =XBOOLE-0R4 0NUMBERSK6"
          using arytm_0_def_4 sorry
        have " *ARYTM-0K2(x,y) =XBOOLE-0R4 0NUMBERSK6"
          using A1 arytm_0_th_12 sorry
        then have "invARYTM-0K4 ( *ARYTM-0K2(x,y)) =HIDDENR1 0NUMBERSK6"
          using arytm_0_def_4 sorry
        also have "... =  *ARYTM-0K2(invARYTM-0K4 x,invARYTM-0K4 y)"
          using A2 arytm_0_th_12 sorry
        finally show "invARYTM-0K4 ( *ARYTM-0K2(x,y)) =HIDDENR1  *ARYTM-0K2(invARYTM-0K4 x,invARYTM-0K4 y)"
           sorry
      qed
      have case2: "x <>HIDDENR2 0NUMBERSK6 & y <>HIDDENR2 0NUMBERSK6 implies invARYTM-0K4 ( *ARYTM-0K2(x,y)) =XBOOLE-0R4  *ARYTM-0K2(invARYTM-0K4 x,invARYTM-0K4 y)"
      proof(rule impMI ,rule impI)
        assume A3: "x <>HIDDENR2 0NUMBERSK6"
          and A4: "y <>HIDDENR2 0NUMBERSK6"
        have A5: " *ARYTM-0K2(x,y) <>HIDDENR2 0NUMBERSK6"
          using A3 A4 arytm_0_th_21 sorry
        have A6: " *ARYTM-0K2(x,invARYTM-0K4 x) =XBOOLE-0R4 \<one>\<^sub>M"
          using A3 arytm_0_def_4 sorry
        have A7: " *ARYTM-0K2(y,invARYTM-0K4 y) =XBOOLE-0R4 \<one>\<^sub>M"
          using A4 arytm_0_def_4 sorry
        have " *ARYTM-0K2( *ARYTM-0K2(x,y), *ARYTM-0K2(invARYTM-0K4 x,invARYTM-0K4 y)) =HIDDENR1  *ARYTM-0K2( *ARYTM-0K2( *ARYTM-0K2(x,y),invARYTM-0K4 x),invARYTM-0K4 y)"
          using arytm_0_th_13 sorry
        also have "... =  *ARYTM-0K2( *ARYTM-0K2(jj,y),invARYTM-0K4 y)"
          using A6 arytm_0_th_13 sorry
        also have "... = \<one>\<^sub>M"
          using A7 arytm_0_th_19 sorry
        finally have " *ARYTM-0K2( *ARYTM-0K2(x,y), *ARYTM-0K2(invARYTM-0K4 x,invARYTM-0K4 y)) =HIDDENR1 \<one>\<^sub>M"
           sorry
        thus "invARYTM-0K4 ( *ARYTM-0K2(x,y)) =XBOOLE-0R4  *ARYTM-0K2(invARYTM-0K4 x,invARYTM-0K4 y)"
          using A5 arytm_0_def_4 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_0_th_23:
" for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for z be ElementSUBSET-1M1-of REALNUMBERSK2 holds +ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
proof(rule ballI,rule ballI,rule ballI)
  fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
  fix y assume [ty]: "y be ElementSUBSET-1M1-of REALNUMBERSK2"
  fix z assume [ty]: "z be ElementSUBSET-1M1-of REALNUMBERSK2"
  have A1: "x inTARSKIR2 REAL+ARYTM-2K2 \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inTARSKIR2 REAL+ARYTM-2K2 \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
    using xboole_0_def_5 sorry
  have A2: "z inTARSKIR2 REAL+ARYTM-2K2 \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
    using xboole_0_def_5 sorry
  show "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
  proof-
    have cases: "((((((x inTARSKIR2 REAL+ARYTM-2K2 & (y inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 REAL+ARYTM-2K2) or x inTARSKIR2 REAL+ARYTM-2K2 & (y inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) or x inTARSKIR2 REAL+ARYTM-2K2 & (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & z inTARSKIR2 REAL+ARYTM-2K2)) or x inTARSKIR2 REAL+ARYTM-2K2 & (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) or z inTARSKIR2 REAL+ARYTM-2K2 & (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) or x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & (y inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) or z inTARSKIR2 REAL+ARYTM-2K2 & (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) or x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
      using A1 A2 xboole_0_def_3 sorry
    have case1: "x inTARSKIR2 REAL+ARYTM-2K2 & (y inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 REAL+ARYTM-2K2) implies +ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
    proof(rule impMI ,rule impMI ,rule impI)
      assume A3: "x inTARSKIR2 REAL+ARYTM-2K2"
        and A4: "y inTARSKIR2 REAL+ARYTM-2K2"
        and A5: "z inTARSKIR2 REAL+ARYTM-2K2"
      have A6: " ex x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x99 & y =XBOOLE-0R4 y99) & +ARYTM-0K1(x,y) =XBOOLE-0R4 x99 +ARYTM-2K7 y99"
        using A3 A4 arytm_0_def_1 sorry
      then have A7: " ex xy99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex z99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (+ARYTM-0K1(x,y) =XBOOLE-0R4 xy99 & z =XBOOLE-0R4 z99) & +ARYTM-0K1(+ARYTM-0K1(x,y),z) =XBOOLE-0R4 xy99 +ARYTM-2K7 z99"
        using A5 arytm_0_def_1 sorry
      have A8: " ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (y =XBOOLE-0R4 y9 & z =XBOOLE-0R4 z9) & +ARYTM-0K1(y,z) =XBOOLE-0R4 y9 +ARYTM-2K7 z9"
        using A4 A5 arytm_0_def_1 sorry
      then have " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex yz9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & +ARYTM-0K1(y,z) =XBOOLE-0R4 yz9) & +ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 x9 +ARYTM-2K7 yz9"
        using A3 arytm_0_def_1 sorry
      thus "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
        using A8 A6 A7 arytm_2_th_6 sorry
    qed
    have case2: "x inTARSKIR2 REAL+ARYTM-2K2 & (y inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies +ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
    proof(rule impMI ,rule impMI ,rule impI)
      assume A9: "x inTARSKIR2 REAL+ARYTM-2K2"
        and A10: "y inTARSKIR2 REAL+ARYTM-2K2"
        and A11: "z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
      have A12: " ex x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x99 & y =XBOOLE-0R4 y99) & +ARYTM-0K1(x,y) =XBOOLE-0R4 x99 +ARYTM-2K7 y99"
        using A9 A10 arytm_0_def_1 sorry
      then obtain xy99 z99 where
        [ty]:"xy99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A13: "+ARYTM-0K1(x,y) =XBOOLE-0R4 xy99"and A14: "z =HIDDENR1 [TARSKIK4 0NUMBERSK6,z99 ]"and A15: "+ARYTM-0K1(+ARYTM-0K1(x,y),z) =XBOOLE-0R4 xy99 -ARYTM-1K2 z99"
        using A11 arytm_0_def_1 sorry
      obtain y9 z9 where
        [ty]:"y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A16: "y =XBOOLE-0R4 y9"and A17: "z =HIDDENR1 [TARSKIK4 0NUMBERSK6,z9 ]"and A18: "+ARYTM-0K1(y,z) =XBOOLE-0R4 y9 -ARYTM-1K2 z9"
        using A10 A11 arytm_0_def_1 sorry
      have A19: "z9 =XBOOLE-0R4 z99"
        using A17 A14 xtuple_0_th_1 sorry
      have "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
      proof-
        show "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
        proof-
          have cases: "z9 <='ARYTM-2R1 y9 or  not z9 <='ARYTM-2R1 y9"
             sorry
          have case1: "z9 <='ARYTM-2R1 y9 implies +ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
          proof(rule impI)
            assume A20: "z9 <='ARYTM-2R1 y9"
            then have A21: "+ARYTM-0K1(y,z) =XBOOLE-0R4 y9 -'ARYTM-1K1 z9"
              using A18 arytm_1_def_2 sorry
            then have " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex yz9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & +ARYTM-0K1(y,z) =XBOOLE-0R4 yz9) & +ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 x9 +ARYTM-2K7 yz9"
              using A9 arytm_0_def_1 sorry
            thus "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
              using A16 A12 A13 A15 A19 A20 A21 arytm_1_th_20 sorry
          qed
          have case2: " not z9 <='ARYTM-2R1 y9 implies +ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
          proof(rule impI)
            assume A22: " not z9 <='ARYTM-2R1 y9"
            then have A23: "+ARYTM-0K1(y,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,z9 -'ARYTM-1K1 y9 ]"
              using A18 arytm_1_def_2 sorry
            then have "+ARYTM-0K1(y,z) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
              using arytm_0_lm_1 sorry
            then obtain x9 yz9 where
              [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "yz9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
              A24: "x =XBOOLE-0R4 x9"and A25: "+ARYTM-0K1(y,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,yz9 ] & +ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 x9 -ARYTM-1K2 yz9"
              using A9 arytm_0_def_1 sorry
            have "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 x9 -ARYTM-1K2 (z9 -'ARYTM-1K1 y9)"
              using A23 A25 xtuple_0_th_1 sorry
            also have "... = +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
              using A16 A12 A13 A15 A19 A22 A24 arytm_1_th_21 sorry
            finally show "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
         sorry
    qed
    have case3: "x inTARSKIR2 REAL+ARYTM-2K2 & (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & z inTARSKIR2 REAL+ARYTM-2K2) implies +ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
    proof(rule impMI ,rule impMI ,rule impI)
      assume A26: "x inTARSKIR2 REAL+ARYTM-2K2"
        and A27: "y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
        and A28: "z inTARSKIR2 REAL+ARYTM-2K2"
      obtain x99 y99 where
        [ty]:"x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A29: "x =XBOOLE-0R4 x99"and A30: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 ]"and A31: "+ARYTM-0K1(x,y) =XBOOLE-0R4 x99 -ARYTM-1K2 y99"
        using A26 A27 arytm_0_def_1 sorry
      obtain z9 y9 where
        [ty]:"z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A32: "z =XBOOLE-0R4 z9"and A33: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]"and A34: "+ARYTM-0K1(y,z) =XBOOLE-0R4 z9 -ARYTM-1K2 y9"
        using A27 A28 arytm_0_def_1 sorry
      have A35: "y9 =XBOOLE-0R4 y99"
        using A33 A30 xtuple_0_th_1 sorry
      have "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
      proof-
        show "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
        proof-
          have cases: "((y9 <='ARYTM-2R1 x99 & y9 <='ARYTM-2R1 z9 or y9 <='ARYTM-2R1 x99 &  not y9 <='ARYTM-2R1 z9) or  not y9 <='ARYTM-2R1 x99 & y9 <='ARYTM-2R1 z9) or  not y9 <='ARYTM-2R1 x99 &  not y9 <='ARYTM-2R1 z9"
             sorry
          have case1: "y9 <='ARYTM-2R1 x99 & y9 <='ARYTM-2R1 z9 implies +ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
          proof(rule impMI ,rule impI)
            assume A36: "y9 <='ARYTM-2R1 x99"
              and A37: "y9 <='ARYTM-2R1 z9"
            have A38: "+ARYTM-0K1(y,z) =XBOOLE-0R4 z9 -'ARYTM-1K1 y9"
              using A34 A37 arytm_1_def_2 sorry
            then obtain x9 yz9 where
              [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "yz9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
              A39: "x =XBOOLE-0R4 x9"and A40: "+ARYTM-0K1(y,z) =XBOOLE-0R4 yz9 & +ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 x9 +ARYTM-2K7 yz9"
              using A26 arytm_0_def_1 sorry
            have A41: "+ARYTM-0K1(x,y) =XBOOLE-0R4 x9 -'ARYTM-1K1 y9"
              using A29 A31 A35 A36 A39 arytm_1_def_2 sorry
            then have " ex z99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex xy99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (z =XBOOLE-0R4 z99 & +ARYTM-0K1(x,y) =XBOOLE-0R4 xy99) & +ARYTM-0K1(z,+ARYTM-0K1(x,y)) =XBOOLE-0R4 z99 +ARYTM-2K7 xy99"
              using A28 arytm_0_def_1 sorry
            thus "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
              using A32 A29 A36 A37 A38 A39 A40 A41 arytm_1_th_12 sorry
          qed
          have case2: "y9 <='ARYTM-2R1 x99 &  not y9 <='ARYTM-2R1 z9 implies +ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
          proof(rule impMI ,rule impI)
            assume A42: "y9 <='ARYTM-2R1 x99"
              and A43: " not y9 <='ARYTM-2R1 z9"
            have A44: "+ARYTM-0K1(x,y) =XBOOLE-0R4 x99 -'ARYTM-1K1 y9"
              using A31 A35 A42 arytm_1_def_2 sorry
            then have A45: " ex z99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex xy99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (z =XBOOLE-0R4 z99 & +ARYTM-0K1(x,y) =XBOOLE-0R4 xy99) & +ARYTM-0K1(z,+ARYTM-0K1(x,y)) =XBOOLE-0R4 z99 +ARYTM-2K7 xy99"
              using A28 arytm_0_def_1 sorry
            have A46: "+ARYTM-0K1(y,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 -'ARYTM-1K1 z9 ]"
              using A34 A43 arytm_1_def_2 sorry
            then have "+ARYTM-0K1(y,z) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
              using arytm_0_lm_1 sorry
            then obtain x9 yz9 where
              [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "yz9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
              A47: "x =XBOOLE-0R4 x9"and A48: "+ARYTM-0K1(y,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,yz9 ] & +ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 x9 -ARYTM-1K2 yz9"
              using A26 arytm_0_def_1 sorry
            have "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 x9 -ARYTM-1K2 (y9 -'ARYTM-1K1 z9)"
              using A46 A48 xtuple_0_th_1 sorry
            also have "... = +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
              using A32 A29 A42 A43 A47 A44 A45 arytm_1_th_22 sorry
            finally show "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
               sorry
          qed
          have case3: " not y9 <='ARYTM-2R1 x99 & y9 <='ARYTM-2R1 z9 implies +ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
          proof(rule impMI ,rule impI)
            assume A49: " not y9 <='ARYTM-2R1 x99"
              and A50: "y9 <='ARYTM-2R1 z9"
            have A51: "+ARYTM-0K1(y,x) =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 -'ARYTM-1K1 x99 ]"
              using A31 A35 A49 arytm_1_def_2 sorry
            then have "+ARYTM-0K1(y,x) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
              using arytm_0_lm_1 sorry
            then obtain z99 yx99 where
              [ty]:"z99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "yx99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
              A52: "z =XBOOLE-0R4 z99"and A53: "+ARYTM-0K1(y,x) =HIDDENR1 [TARSKIK4 0NUMBERSK6,yx99 ] & +ARYTM-0K1(z,+ARYTM-0K1(y,x)) =XBOOLE-0R4 z99 -ARYTM-1K2 yx99"
              using A28 arytm_0_def_1 sorry
            have A54: "+ARYTM-0K1(z,y) =XBOOLE-0R4 z9 -'ARYTM-1K1 y9"
              using A34 A50 arytm_1_def_2 sorry
            then have " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex zy99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & +ARYTM-0K1(z,y) =XBOOLE-0R4 zy99) & +ARYTM-0K1(x,+ARYTM-0K1(z,y)) =XBOOLE-0R4 x9 +ARYTM-2K7 zy99"
              using A26 arytm_0_def_1 sorry
            then have "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 z99 -ARYTM-1K2 (y9 -'ARYTM-1K1 x99)"
              using A32 A29 A49 A50 A52 A54 arytm_1_th_22 sorry
            also have "... = +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
              using A51 A53 xtuple_0_th_1 sorry
            finally show "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
               sorry
          qed
          have case4: " not y9 <='ARYTM-2R1 x99 &  not y9 <='ARYTM-2R1 z9 implies +ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
          proof(rule impMI ,rule impI)
            assume A55: " not y9 <='ARYTM-2R1 x99"
              and A56: " not y9 <='ARYTM-2R1 z9"
            have A57: "+ARYTM-0K1(y,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 -'ARYTM-1K1 z9 ]"
              using A34 A56 arytm_1_def_2 sorry
            then have "+ARYTM-0K1(y,z) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
              using arytm_0_lm_1 sorry
            then obtain x9 yz9 where
              [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "yz9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
              A58: "x =XBOOLE-0R4 x9"and A59: "+ARYTM-0K1(y,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,yz9 ] & +ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 x9 -ARYTM-1K2 yz9"
              using A26 arytm_0_def_1 sorry
            have A60: "+ARYTM-0K1(y,x) =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 -'ARYTM-1K1 x99 ]"
              using A31 A35 A55 arytm_1_def_2 sorry
            then have "+ARYTM-0K1(y,x) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
              using arytm_0_lm_1 sorry
            then obtain z99 yx99 where
              [ty]:"z99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "yx99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
              A61: "z =XBOOLE-0R4 z99"and A62: "+ARYTM-0K1(y,x) =HIDDENR1 [TARSKIK4 0NUMBERSK6,yx99 ] & +ARYTM-0K1(z,+ARYTM-0K1(y,x)) =XBOOLE-0R4 z99 -ARYTM-1K2 yx99"
              using A28 arytm_0_def_1 sorry
            have "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 x9 -ARYTM-1K2 (y9 -'ARYTM-1K1 z9)"
              using A57 A59 xtuple_0_th_1 sorry
            also have "... = z99 -ARYTM-1K2 (y9 -'ARYTM-1K1 x99)"
              using A32 A29 A55 A56 A61 A58 arytm_1_th_23 sorry
            also have "... = +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
              using A60 A62 xtuple_0_th_1 sorry
            finally show "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 case4 sorry
        qed
      qed
      thus "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
         sorry
    qed
    have case4: "x inTARSKIR2 REAL+ARYTM-2K2 & (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies +ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
    proof(rule impMI ,rule impMI ,rule impI)
      assume A63: "x inTARSKIR2 REAL+ARYTM-2K2"
        and A64: "y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
        and A65: "z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
      have " not (z inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) &  not (y inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
        using A64 A65 arytm_0_th_5 xboole_0_th_3 sorry
      then obtain y9 z9 where
        [ty]:"y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A66: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]"and A67: "z =HIDDENR1 [TARSKIK4 0NUMBERSK6,z9 ]"and A68: "+ARYTM-0K1(y,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 +ARYTM-2K7 z9 ]"
        using A64 arytm_0_def_1 sorry
      have "+ARYTM-0K1(y,z) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
        using A68 arytm_0_lm_1 sorry
      then obtain x9 yz9 where
        [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "yz9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A69: "x =XBOOLE-0R4 x9"and A70: "+ARYTM-0K1(y,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,yz9 ]"and A71: "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 x9 -ARYTM-1K2 yz9"
        using A63 arytm_0_def_1 sorry
      obtain x99 y99 where
        [ty]:"x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A72: "x =XBOOLE-0R4 x99"and A73: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 ]"and A74: "+ARYTM-0K1(x,y) =XBOOLE-0R4 x99 -ARYTM-1K2 y99"
        using A63 A64 arytm_0_def_1 sorry
      have A75: "y9 =XBOOLE-0R4 y99"
        using A66 A73 xtuple_0_th_1 sorry
      have "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
      proof-
        show "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
        proof-
          have cases: "y99 <='ARYTM-2R1 x99 or  not y99 <='ARYTM-2R1 x99"
             sorry
          have case1: "y99 <='ARYTM-2R1 x99 implies +ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
          proof(rule impI)
            assume A76: "y99 <='ARYTM-2R1 x99"
            then have A77: "+ARYTM-0K1(x,y) =XBOOLE-0R4 x99 -'ARYTM-1K1 y99"
              using A74 arytm_1_def_2 sorry
            then obtain xy99 z99 where
              [ty]:"xy99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
              A78: "+ARYTM-0K1(x,y) =XBOOLE-0R4 xy99"and A79: "z =HIDDENR1 [TARSKIK4 0NUMBERSK6,z99 ]"and A80: "+ARYTM-0K1(+ARYTM-0K1(x,y),z) =XBOOLE-0R4 xy99 -ARYTM-1K2 z99"
              using A65 arytm_0_def_1 sorry
            have A81: "z9 =XBOOLE-0R4 z99"
              using A67 A79 xtuple_0_th_1 sorry
            have "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 x9 -ARYTM-1K2 (y9 +ARYTM-2K7 z9)"
              using A68 A70 A71 xtuple_0_th_1 sorry
            also have "... = +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
              using A72 A69 A75 A76 A77 A78 A80 A81 arytm_1_th_24 sorry
            finally show "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
               sorry
          qed
          have case2: " not y99 <='ARYTM-2R1 x99 implies +ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
          proof(rule impI)
            assume A82: " not y99 <='ARYTM-2R1 x99"
            have A83: " not (z inTARSKIR2 REAL+ARYTM-2K2 & +ARYTM-0K1(x,y) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
              using A65 arytm_0_th_5 xboole_0_th_3 sorry
            have A84: "+ARYTM-0K1(x,y) =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 -'ARYTM-1K1 x99 ]"
              using A74 A82 arytm_1_def_2 sorry
            then have "+ARYTM-0K1(x,y) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
              using arytm_0_lm_1 sorry
            then have " not (+ARYTM-0K1(x,y) inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
              using arytm_0_th_5 xboole_0_th_3 sorry
            then obtain xy99 z99 where
              [ty]:"xy99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
              A85: "+ARYTM-0K1(x,y) =HIDDENR1 [TARSKIK4 0NUMBERSK6,xy99 ]"and A86: "z =HIDDENR1 [TARSKIK4 0NUMBERSK6,z99 ]"and A87: "+ARYTM-0K1(+ARYTM-0K1(x,y),z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,xy99 +ARYTM-2K7 z99 ]"
              using A84 A83 arytm_0_def_1 arytm_0_lm_1 sorry
            have A88: "z9 =XBOOLE-0R4 z99"
              using A67 A86 xtuple_0_th_1 sorry
            have A89: "yz9 =XBOOLE-0R4 z9 +ARYTM-2K7 y9"
              using A68 A70 xtuple_0_th_1 sorry
            then have "y99 <='ARYTM-2R1 yz9"
              using A75 arytm_2_th_19 sorry
            then have " not yz9 <='ARYTM-2R1 x9"
              using A72 A69 A82 arytm_1_th_3 sorry
            then have "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 [TARSKIK4 0NUMBERSK6,(z9 +ARYTM-2K7 y9)-'ARYTM-1K1 x9 ]"
              using A71 A89 arytm_1_def_2 sorry
            also have "... = [TARSKIK4 0NUMBERSK6,z99 +ARYTM-2K7 (y99 -'ARYTM-1K1 x99) ]"
              using A72 A69 A75 A82 A88 arytm_1_th_13 sorry
            also have "... = +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
              using A84 A85 A87 xtuple_0_th_1 sorry
            finally show "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
         sorry
    qed
    have case5: "z inTARSKIR2 REAL+ARYTM-2K2 & (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies +ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
    proof(rule impMI ,rule impMI ,rule impI)
      assume A90: "z inTARSKIR2 REAL+ARYTM-2K2"
        and A91: "y inTARSKIR2 REAL+ARYTM-2K2"
        and A92: "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
      have A93: " ex z99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (z =XBOOLE-0R4 z99 & y =XBOOLE-0R4 y99) & +ARYTM-0K1(z,y) =XBOOLE-0R4 z99 +ARYTM-2K7 y99"
        using A90 A91 arytm_0_def_1 sorry
      then obtain zy99 x99 where
        [ty]:"zy99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A94: "+ARYTM-0K1(z,y) =XBOOLE-0R4 zy99"and A95: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 ]"and A96: "+ARYTM-0K1(+ARYTM-0K1(z,y),x) =XBOOLE-0R4 zy99 -ARYTM-1K2 x99"
        using A92 arytm_0_def_1 sorry
      obtain y9 x9 where
        [ty]:"y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A97: "y =XBOOLE-0R4 y9"and A98: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]"and A99: "+ARYTM-0K1(y,x) =XBOOLE-0R4 y9 -ARYTM-1K2 x9"
        using A91 A92 arytm_0_def_1 sorry
      have A100: "x9 =XBOOLE-0R4 x99"
        using A98 A95 xtuple_0_th_1 sorry
      have "+ARYTM-0K1(z,+ARYTM-0K1(y,x)) =XBOOLE-0R4 +ARYTM-0K1(+ARYTM-0K1(z,y),x)"
      proof-
        show "+ARYTM-0K1(z,+ARYTM-0K1(y,x)) =XBOOLE-0R4 +ARYTM-0K1(+ARYTM-0K1(z,y),x)"
        proof-
          have cases: "x9 <='ARYTM-2R1 y9 or  not x9 <='ARYTM-2R1 y9"
             sorry
          have case1: "x9 <='ARYTM-2R1 y9 implies +ARYTM-0K1(z,+ARYTM-0K1(y,x)) =XBOOLE-0R4 +ARYTM-0K1(+ARYTM-0K1(z,y),x)"
          proof(rule impI)
            assume A101: "x9 <='ARYTM-2R1 y9"
            then have A102: "+ARYTM-0K1(y,x) =XBOOLE-0R4 y9 -'ARYTM-1K1 x9"
              using A99 arytm_1_def_2 sorry
            then have " ex z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex yx9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (z =XBOOLE-0R4 z9 & +ARYTM-0K1(y,x) =XBOOLE-0R4 yx9) & +ARYTM-0K1(z,+ARYTM-0K1(y,x)) =XBOOLE-0R4 z9 +ARYTM-2K7 yx9"
              using A90 arytm_0_def_1 sorry
            thus "+ARYTM-0K1(z,+ARYTM-0K1(y,x)) =XBOOLE-0R4 +ARYTM-0K1(+ARYTM-0K1(z,y),x)"
              using A97 A93 A94 A96 A100 A101 A102 arytm_1_th_20 sorry
          qed
          have case2: " not x9 <='ARYTM-2R1 y9 implies +ARYTM-0K1(z,+ARYTM-0K1(y,x)) =HIDDENR1 +ARYTM-0K1(+ARYTM-0K1(z,y),x)"
          proof(rule impI)
            assume A103: " not x9 <='ARYTM-2R1 y9"
            then have A104: "+ARYTM-0K1(y,x) =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 -'ARYTM-1K1 y9 ]"
              using A99 arytm_1_def_2 sorry
            then have "+ARYTM-0K1(y,x) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
              using arytm_0_lm_1 sorry
            then obtain z9 yx9 where
              [ty]:"z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "yx9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
              A105: "z =XBOOLE-0R4 z9"and A106: "+ARYTM-0K1(y,x) =HIDDENR1 [TARSKIK4 0NUMBERSK6,yx9 ] & +ARYTM-0K1(z,+ARYTM-0K1(y,x)) =XBOOLE-0R4 z9 -ARYTM-1K2 yx9"
              using A90 arytm_0_def_1 sorry
            have "+ARYTM-0K1(z,+ARYTM-0K1(y,x)) =HIDDENR1 z9 -ARYTM-1K2 (x9 -'ARYTM-1K1 y9)"
              using A104 A106 xtuple_0_th_1 sorry
            also have "... = +ARYTM-0K1(+ARYTM-0K1(z,y),x)"
              using A97 A93 A94 A96 A100 A103 A105 arytm_1_th_21 sorry
            finally show "+ARYTM-0K1(z,+ARYTM-0K1(y,x)) =HIDDENR1 +ARYTM-0K1(+ARYTM-0K1(z,y),x)"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
         sorry
    qed
    have case6: "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & (y inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies +ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
    proof(rule impMI ,rule impMI ,rule impI)
      assume A107: "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
        and A108: "y inTARSKIR2 REAL+ARYTM-2K2"
        and A109: "z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
      obtain y9 z9 where
        [ty]:"y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A110: "y =XBOOLE-0R4 y9"and A111: "z =HIDDENR1 [TARSKIK4 0NUMBERSK6,z9 ]"and A112: "+ARYTM-0K1(y,z) =XBOOLE-0R4 y9 -ARYTM-1K2 z9"
        using A108 A109 arytm_0_def_1 sorry
      obtain x99 y99 where
        [ty]:"x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A113: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 ]"and A114: "y =XBOOLE-0R4 y99"and A115: "+ARYTM-0K1(x,y) =XBOOLE-0R4 y99 -ARYTM-1K2 x99"
        using A107 A108 arytm_0_def_1 sorry
      have "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
      proof-
        show "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
        proof-
          have cases: "((x99 <='ARYTM-2R1 y99 & z9 <='ARYTM-2R1 y9 or  not x99 <='ARYTM-2R1 y99 & z9 <='ARYTM-2R1 y9) or  not z9 <='ARYTM-2R1 y9 & x99 <='ARYTM-2R1 y99) or  not x99 <='ARYTM-2R1 y99 &  not z9 <='ARYTM-2R1 y9"
             sorry
          have case1: "x99 <='ARYTM-2R1 y99 & z9 <='ARYTM-2R1 y9 implies +ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
          proof(rule impMI ,rule impI)
            assume A116: "x99 <='ARYTM-2R1 y99"
              and A117: "z9 <='ARYTM-2R1 y9"
            have A118: "+ARYTM-0K1(y,z) =XBOOLE-0R4 y9 -'ARYTM-1K1 z9"
              using A112 A117 arytm_1_def_2 sorry
            then obtain x9 yz9 where
              [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "yz9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
              A119: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]"and A120: "+ARYTM-0K1(y,z) =XBOOLE-0R4 yz9 & +ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 yz9 -ARYTM-1K2 x9"
              using A107 arytm_0_def_1 sorry
            have A121: "x9 =XBOOLE-0R4 x99"
              using A113 A119 xtuple_0_th_1 sorry
            then have A122: "+ARYTM-0K1(x,y) =XBOOLE-0R4 y9 -'ARYTM-1K1 x9"
              using A110 A114 A115 A116 arytm_1_def_2 sorry
            then obtain z99 xy99 where
              [ty]:"z99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "xy99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
              A123: "z =HIDDENR1 [TARSKIK4 0NUMBERSK6,z99 ]"and A124: "+ARYTM-0K1(x,y) =XBOOLE-0R4 xy99 & +ARYTM-0K1(z,+ARYTM-0K1(x,y)) =XBOOLE-0R4 xy99 -ARYTM-1K2 z99"
              using A109 arytm_0_def_1 sorry
            have "z9 =XBOOLE-0R4 z99"
              using A111 A123 xtuple_0_th_1 sorry
            thus "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
              using A110 A114 A116 A117 A118 A120 A121 A122 A124 arytm_1_th_25 sorry
          qed
          have case2: " not x99 <='ARYTM-2R1 y99 & z9 <='ARYTM-2R1 y9 implies +ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
          proof(rule impMI ,rule impI)
            assume A125: " not x99 <='ARYTM-2R1 y99"
              and A126: "z9 <='ARYTM-2R1 y9"
            have A127: " not (z inTARSKIR2 REAL+ARYTM-2K2 & +ARYTM-0K1(x,y) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
              using A109 arytm_0_th_5 xboole_0_th_3 sorry
            have A128: "+ARYTM-0K1(y,x) =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 -'ARYTM-1K1 y99 ]"
              using A115 A125 arytm_1_def_2 sorry
            then have "+ARYTM-0K1(y,x) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
              using arytm_0_lm_1 sorry
            then have " not (+ARYTM-0K1(x,y) inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
              using arytm_0_th_5 xboole_0_th_3 sorry
            then obtain z99 yx9 where
              [ty]:"z99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "yx9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
              A129: "z =HIDDENR1 [TARSKIK4 0NUMBERSK6,z99 ]"and A130: "+ARYTM-0K1(y,x) =HIDDENR1 [TARSKIK4 0NUMBERSK6,yx9 ] & +ARYTM-0K1(z,+ARYTM-0K1(y,x)) =HIDDENR1 [TARSKIK4 0NUMBERSK6,z99 +ARYTM-2K7 yx9 ]"
              using A128 A127 arytm_0_def_1 arytm_0_lm_1 sorry
            have A131: "z9 =XBOOLE-0R4 z99"
              using A111 A129 xtuple_0_th_1 sorry
            have A132: "+ARYTM-0K1(y,z) =XBOOLE-0R4 y9 -'ARYTM-1K1 z9"
              using A112 A126 arytm_1_def_2 sorry
            then obtain x9 yz9 where
              [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "yz9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
              A133: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]"and A134: "+ARYTM-0K1(y,z) =XBOOLE-0R4 yz9"and A135: "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 yz9 -ARYTM-1K2 x9"
              using A107 arytm_0_def_1 sorry
            have A136: "x9 =XBOOLE-0R4 x99"
              using A113 A133 xtuple_0_th_1 sorry
            have "yz9 <='ARYTM-2R1 y9"
              using A132 A134 arytm_1_th_11 sorry
            then have " not x9 <='ARYTM-2R1 yz9"
              using A110 A114 A125 A136 arytm_1_th_3 sorry
            then have "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 -'ARYTM-1K1 (y9 -'ARYTM-1K1 z9) ]"
              using A132 A134 A135 arytm_1_def_2 sorry
            also have "... = [TARSKIK4 0NUMBERSK6,(x99 -'ARYTM-1K1 y99)+ARYTM-2K7 z99 ]"
              using A110 A114 A125 A126 A136 A131 arytm_1_th_14 sorry
            also have "... = +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
              using A128 A130 xtuple_0_th_1 sorry
            finally show "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
               sorry
          qed
          have case3: " not z9 <='ARYTM-2R1 y9 & x99 <='ARYTM-2R1 y99 implies +ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
          proof(rule impMI ,rule impI)
            assume A137: " not z9 <='ARYTM-2R1 y9"
              and A138: "x99 <='ARYTM-2R1 y99"
            have A139: " not (x inTARSKIR2 REAL+ARYTM-2K2 & +ARYTM-0K1(z,y) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
              using A107 arytm_0_th_5 xboole_0_th_3 sorry
            have A140: "+ARYTM-0K1(y,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,z9 -'ARYTM-1K1 y9 ]"
              using A112 A137 arytm_1_def_2 sorry
            then have "+ARYTM-0K1(y,z) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
              using arytm_0_lm_1 sorry
            then have " not (+ARYTM-0K1(z,y) inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
              using arytm_0_th_5 xboole_0_th_3 sorry
            then obtain x9 yz99 where
              [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "yz99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
              A141: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]"and A142: "+ARYTM-0K1(y,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,yz99 ] & +ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 +ARYTM-2K7 yz99 ]"
              using A140 A139 arytm_0_def_1 arytm_0_lm_1 sorry
            have A143: "x99 =XBOOLE-0R4 x9"
              using A113 A141 xtuple_0_th_1 sorry
            have A144: "+ARYTM-0K1(y,x) =XBOOLE-0R4 y99 -'ARYTM-1K1 x99"
              using A115 A138 arytm_1_def_2 sorry
            then obtain z99 yx99 where
              [ty]:"z99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "yx99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
              A145: "z =HIDDENR1 [TARSKIK4 0NUMBERSK6,z99 ]"and A146: "+ARYTM-0K1(y,x) =XBOOLE-0R4 yx99"and A147: "+ARYTM-0K1(z,+ARYTM-0K1(y,x)) =XBOOLE-0R4 yx99 -ARYTM-1K2 z99"
              using A109 arytm_0_def_1 sorry
            have A148: "z99 =XBOOLE-0R4 z9"
              using A111 A145 xtuple_0_th_1 sorry
            have "yx99 <='ARYTM-2R1 y99"
              using A144 A146 arytm_1_th_11 sorry
            then have A149: " not z99 <='ARYTM-2R1 yx99"
              using A110 A114 A137 A148 arytm_1_th_3 sorry
            have "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 [TARSKIK4 0NUMBERSK6,(z9 -'ARYTM-1K1 y9)+ARYTM-2K7 x9 ]"
              using A140 A142 xtuple_0_th_1 sorry
            also have "... = [TARSKIK4 0NUMBERSK6,z99 -'ARYTM-1K1 (y99 -'ARYTM-1K1 x99) ]"
              using A110 A114 A137 A138 A148 A143 arytm_1_th_14 sorry
            also have "... = +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
              using A144 A146 A147 A149 arytm_1_def_2 sorry
            finally show "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
               sorry
          qed
          have case4: " not x99 <='ARYTM-2R1 y99 &  not z9 <='ARYTM-2R1 y9 implies +ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
          proof(rule impMI ,rule impI)
            assume A150: " not x99 <='ARYTM-2R1 y99"
              and A151: " not z9 <='ARYTM-2R1 y9"
            have A152: " not (x inTARSKIR2 REAL+ARYTM-2K2 & +ARYTM-0K1(z,y) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
              using A107 arytm_0_th_5 xboole_0_th_3 sorry
            have A153: " not (z inTARSKIR2 REAL+ARYTM-2K2 & +ARYTM-0K1(x,y) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
              using A109 arytm_0_th_5 xboole_0_th_3 sorry
            have A154: "+ARYTM-0K1(y,x) =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 -'ARYTM-1K1 y99 ]"
              using A115 A150 arytm_1_def_2 sorry
            then have "+ARYTM-0K1(y,x) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
              using arytm_0_lm_1 sorry
            then have " not (+ARYTM-0K1(x,y) inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
              using arytm_0_th_5 xboole_0_th_3 sorry
            then obtain z99 yx9 where
              [ty]:"z99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "yx9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
              A155: "z =HIDDENR1 [TARSKIK4 0NUMBERSK6,z99 ]"and A156: "+ARYTM-0K1(y,x) =HIDDENR1 [TARSKIK4 0NUMBERSK6,yx9 ] & +ARYTM-0K1(z,+ARYTM-0K1(y,x)) =HIDDENR1 [TARSKIK4 0NUMBERSK6,z99 +ARYTM-2K7 yx9 ]"
              using A154 A153 arytm_0_def_1 arytm_0_lm_1 sorry
            have A157: "z9 =XBOOLE-0R4 z99"
              using A111 A155 xtuple_0_th_1 sorry
            have A158: "+ARYTM-0K1(y,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,z9 -'ARYTM-1K1 y9 ]"
              using A112 A151 arytm_1_def_2 sorry
            then have "+ARYTM-0K1(y,z) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
              using arytm_0_lm_1 sorry
            then have " not (+ARYTM-0K1(z,y) inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
              using arytm_0_th_5 xboole_0_th_3 sorry
            then obtain x9 yz99 where
              [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "yz99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
              A159: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]"and A160: "+ARYTM-0K1(y,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,yz99 ] & +ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 +ARYTM-2K7 yz99 ]"
              using A158 A152 arytm_0_def_1 arytm_0_lm_1 sorry
            have A161: "x9 =XBOOLE-0R4 x99"
              using A113 A159 xtuple_0_th_1 sorry
            have "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 [TARSKIK4 0NUMBERSK6,(z9 -'ARYTM-1K1 y9)+ARYTM-2K7 x9 ]"
              using A158 A160 xtuple_0_th_1 sorry
            also have "... = [TARSKIK4 0NUMBERSK6,(x99 -'ARYTM-1K1 y99)+ARYTM-2K7 z99 ]"
              using A110 A114 A150 A151 A157 A161 arytm_1_th_15 sorry
            also have "... = +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
              using A154 A156 xtuple_0_th_1 sorry
            finally show "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 case4 sorry
        qed
      qed
      thus "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
         sorry
    qed
    have case7: "z inTARSKIR2 REAL+ARYTM-2K2 & (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies +ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
    proof(rule impMI ,rule impMI ,rule impI)
      assume A162: "z inTARSKIR2 REAL+ARYTM-2K2"
        and A163: "y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
        and A164: "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
      have " not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) &  not (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
        using A163 A164 arytm_0_th_5 xboole_0_th_3 sorry
      then obtain y9 x9 where
        [ty]:"y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A165: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]"and A166: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]"and A167: "+ARYTM-0K1(y,x) =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 +ARYTM-2K7 x9 ]"
        using A163 arytm_0_def_1 sorry
      have "+ARYTM-0K1(y,x) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
        using A167 arytm_0_lm_1 sorry
      then obtain z9 yx9 where
        [ty]:"z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "yx9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A168: "z =XBOOLE-0R4 z9"and A169: "+ARYTM-0K1(y,x) =HIDDENR1 [TARSKIK4 0NUMBERSK6,yx9 ]"and A170: "+ARYTM-0K1(z,+ARYTM-0K1(y,x)) =XBOOLE-0R4 z9 -ARYTM-1K2 yx9"
        using A162 arytm_0_def_1 sorry
      obtain z99 y99 where
        [ty]:"z99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A171: "z =XBOOLE-0R4 z99"and A172: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 ]"and A173: "+ARYTM-0K1(z,y) =XBOOLE-0R4 z99 -ARYTM-1K2 y99"
        using A162 A163 arytm_0_def_1 sorry
      have A174: "y9 =XBOOLE-0R4 y99"
        using A165 A172 xtuple_0_th_1 sorry
      have "+ARYTM-0K1(z,+ARYTM-0K1(y,x)) =HIDDENR1 +ARYTM-0K1(+ARYTM-0K1(z,y),x)"
      proof-
        show "+ARYTM-0K1(z,+ARYTM-0K1(y,x)) =HIDDENR1 +ARYTM-0K1(+ARYTM-0K1(z,y),x)"
        proof-
          have cases: "y99 <='ARYTM-2R1 z99 or  not y99 <='ARYTM-2R1 z99"
             sorry
          have case1: "y99 <='ARYTM-2R1 z99 implies +ARYTM-0K1(z,+ARYTM-0K1(y,x)) =HIDDENR1 +ARYTM-0K1(+ARYTM-0K1(z,y),x)"
          proof(rule impI)
            assume A175: "y99 <='ARYTM-2R1 z99"
            then have A176: "+ARYTM-0K1(z,y) =XBOOLE-0R4 z99 -'ARYTM-1K1 y99"
              using A173 arytm_1_def_2 sorry
            then obtain zy99 x99 where
              [ty]:"zy99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
              A177: "+ARYTM-0K1(z,y) =XBOOLE-0R4 zy99"and A178: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 ]"and A179: "+ARYTM-0K1(+ARYTM-0K1(z,y),x) =XBOOLE-0R4 zy99 -ARYTM-1K2 x99"
              using A164 arytm_0_def_1 sorry
            have A180: "x9 =XBOOLE-0R4 x99"
              using A166 A178 xtuple_0_th_1 sorry
            have "+ARYTM-0K1(z,+ARYTM-0K1(y,x)) =HIDDENR1 z9 -ARYTM-1K2 (y9 +ARYTM-2K7 x9)"
              using A167 A169 A170 xtuple_0_th_1 sorry
            also have "... = +ARYTM-0K1(+ARYTM-0K1(z,y),x)"
              using A171 A168 A174 A175 A176 A177 A179 A180 arytm_1_th_24 sorry
            finally show "+ARYTM-0K1(z,+ARYTM-0K1(y,x)) =HIDDENR1 +ARYTM-0K1(+ARYTM-0K1(z,y),x)"
               sorry
          qed
          have case2: " not y99 <='ARYTM-2R1 z99 implies +ARYTM-0K1(z,+ARYTM-0K1(y,x)) =HIDDENR1 +ARYTM-0K1(+ARYTM-0K1(z,y),x)"
          proof(rule impI)
            assume A181: " not y99 <='ARYTM-2R1 z99"
            have A182: " not (x inTARSKIR2 REAL+ARYTM-2K2 & +ARYTM-0K1(z,y) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
              using A164 arytm_0_th_5 xboole_0_th_3 sorry
            have A183: "+ARYTM-0K1(z,y) =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 -'ARYTM-1K1 z99 ]"
              using A173 A181 arytm_1_def_2 sorry
            then have "+ARYTM-0K1(z,y) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
              using arytm_0_lm_1 sorry
            then have " not (+ARYTM-0K1(z,y) inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
              using arytm_0_th_5 xboole_0_th_3 sorry
            then obtain zy99 x99 where
              [ty]:"zy99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
              A184: "+ARYTM-0K1(z,y) =HIDDENR1 [TARSKIK4 0NUMBERSK6,zy99 ]"and A185: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 ]"and A186: "+ARYTM-0K1(+ARYTM-0K1(z,y),x) =HIDDENR1 [TARSKIK4 0NUMBERSK6,zy99 +ARYTM-2K7 x99 ]"
              using A183 A182 arytm_0_def_1 arytm_0_lm_1 sorry
            have A187: "x9 =XBOOLE-0R4 x99"
              using A166 A185 xtuple_0_th_1 sorry
            have A188: "yx9 =XBOOLE-0R4 x9 +ARYTM-2K7 y9"
              using A167 A169 xtuple_0_th_1 sorry
            then have "y99 <='ARYTM-2R1 yx9"
              using A174 arytm_2_th_19 sorry
            then have " not yx9 <='ARYTM-2R1 z9"
              using A171 A168 A181 arytm_1_th_3 sorry
            then have "+ARYTM-0K1(z,+ARYTM-0K1(y,x)) =HIDDENR1 [TARSKIK4 0NUMBERSK6,(x9 +ARYTM-2K7 y9)-'ARYTM-1K1 z9 ]"
              using A170 A188 arytm_1_def_2 sorry
            also have "... = [TARSKIK4 0NUMBERSK6,x99 +ARYTM-2K7 (y99 -'ARYTM-1K1 z99) ]"
              using A171 A168 A174 A181 A187 arytm_1_th_13 sorry
            also have "... = +ARYTM-0K1(+ARYTM-0K1(z,y),x)"
              using A183 A184 A186 xtuple_0_th_1 sorry
            finally show "+ARYTM-0K1(z,+ARYTM-0K1(y,x)) =HIDDENR1 +ARYTM-0K1(+ARYTM-0K1(z,y),x)"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =XBOOLE-0R4 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
         sorry
    qed
    have case8: "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies +ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
    proof(rule impMI ,rule impMI ,rule impI)
      assume A189: "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
        and A190: "y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
        and A191: "z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
      have A192: " not (x inTARSKIR2 REAL+ARYTM-2K2 & +ARYTM-0K1(z,y) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
        using A189 arytm_0_th_5 xboole_0_th_3 sorry
      have " not (z inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) &  not (y inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
        using A190 A191 arytm_0_th_5 xboole_0_th_3 sorry
      then obtain y9 z9 where
        [ty]:"y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A193: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]"and A194: "z =HIDDENR1 [TARSKIK4 0NUMBERSK6,z9 ]"and A195: "+ARYTM-0K1(y,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 +ARYTM-2K7 z9 ]"
        using A190 arytm_0_def_1 sorry
      have "+ARYTM-0K1(z,y) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
        using A195 arytm_0_lm_1 sorry
      then have " not (+ARYTM-0K1(z,y) inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
        using arytm_0_th_5 xboole_0_th_3 sorry
      then obtain x9 yz9 where
        [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "yz9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A196: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]"and A197: "+ARYTM-0K1(y,z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,yz9 ] & +ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 +ARYTM-2K7 yz9 ]"
        using A195 A192 arytm_0_def_1 arytm_0_lm_1 sorry
      have A198: " not (z inTARSKIR2 REAL+ARYTM-2K2 & +ARYTM-0K1(x,y) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
        using A191 arytm_0_th_5 xboole_0_th_3 sorry
      have " not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) &  not (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
        using A189 A190 arytm_0_th_5 xboole_0_th_3 sorry
      then obtain x99 y99 where
        [ty]:"x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A199: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 ]"and A200: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 ]"and A201: "+ARYTM-0K1(x,y) =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 +ARYTM-2K7 y99 ]"
        using A189 arytm_0_def_1 sorry
      have A202: "x9 =XBOOLE-0R4 x99"
        using A199 A196 xtuple_0_th_1 sorry
      have "+ARYTM-0K1(x,y) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
        using A201 arytm_0_lm_1 sorry
      then have " not (+ARYTM-0K1(x,y) inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
        using arytm_0_th_5 xboole_0_th_3 sorry
      then obtain xy99 z99 where
        [ty]:"xy99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A203: "+ARYTM-0K1(x,y) =HIDDENR1 [TARSKIK4 0NUMBERSK6,xy99 ]"and A204: "z =HIDDENR1 [TARSKIK4 0NUMBERSK6,z99 ]"and A205: "+ARYTM-0K1(+ARYTM-0K1(x,y),z) =HIDDENR1 [TARSKIK4 0NUMBERSK6,xy99 +ARYTM-2K7 z99 ]"
        using A201 A198 arytm_0_def_1 arytm_0_lm_1 sorry
      have A206: "z9 =XBOOLE-0R4 z99"
        using A194 A204 xtuple_0_th_1 sorry
      have A207: "y9 =XBOOLE-0R4 y99"
        using A193 A200 xtuple_0_th_1 sorry
      have "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 [TARSKIK4 0NUMBERSK6,(z9 +ARYTM-2K7 y9)+ARYTM-2K7 x9 ]"
        using A195 A197 xtuple_0_th_1 sorry
      also have "... = [TARSKIK4 0NUMBERSK6,z99 +ARYTM-2K7 (y99 +ARYTM-2K7 x99) ]"
        using A206 A202 A207 arytm_2_th_6 sorry
      also have "... = +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
        using A201 A203 A205 xtuple_0_th_1 sorry
      finally show "+ARYTM-0K1(x,+ARYTM-0K1(y,z)) =HIDDENR1 +ARYTM-0K1(+ARYTM-0K1(x,y),z)"
         sorry
    qed
    show " ?thesis "
      using cases case1 case2 case3 case4 case5 case6 case7 case8 sorry
  qed
qed "sorry"

mtheorem arytm_0_th_24:
" for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds [*ARYTM-0K5 x,y *] inTARSKIR2 REALNUMBERSK2 implies y =XBOOLE-0R4 0NUMBERSK6"
proof-
  have " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds [*ARYTM-0K5 x,y *] inTARSKIR2 REALNUMBERSK2 implies (y <>HIDDENR2 0NUMBERSK6 implies  False )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REALNUMBERSK2"
    assume A1: "[*ARYTM-0K5 x,y *] inTARSKIR2 REALNUMBERSK2"
    assume "y <>HIDDENR2 0NUMBERSK6"
    then have "[*ARYTM-0K5 x,y *] =XBOOLE-0R4 (0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K7\<^bsub>(REALNUMBERSK2)\<^esub>(x,y)"
      using arytm_0_def_5 sorry
    thus " False "
      using A1 arytm_0_th_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_0_th_25:
" for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds oppARYTM-0K3 (+ARYTM-0K1(x,y)) =XBOOLE-0R4 +ARYTM-0K1(oppARYTM-0K3 x,oppARYTM-0K3 y)"
proof(rule ballI,rule ballI)
  obtain o where 
    [ty]:"o be ElementSUBSET-1M1-of REALNUMBERSK2" and oDef:"o = 0NUMBERSK6"
    using arytm_0_lm_3 sorry
  fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
  fix y assume [ty]: "y be ElementSUBSET-1M1-of REALNUMBERSK2"
  have "+ARYTM-0K1(+ARYTM-0K1(x,y),+ARYTM-0K1(oppARYTM-0K3 x,oppARYTM-0K3 y)) =HIDDENR1 +ARYTM-0K1(x,+ARYTM-0K1(y,+ARYTM-0K1(oppARYTM-0K3 x,oppARYTM-0K3 y)))"
    using arytm_0_th_23 sorry
  also have "... = +ARYTM-0K1(x,+ARYTM-0K1(oppARYTM-0K3 x,+ARYTM-0K1(y,oppARYTM-0K3 y)))"
    using arytm_0_th_23 sorry
  also have "... = +ARYTM-0K1(x,+ARYTM-0K1(oppARYTM-0K3 x,o))"
    using arytm_0_def_3 sorry
  also have "... = +ARYTM-0K1(x,oppARYTM-0K3 x)"
    using arytm_0_th_11 sorry
  also have "... = 0NUMBERSK6"
    using arytm_0_def_3 sorry
  finally have "+ARYTM-0K1(+ARYTM-0K1(x,y),+ARYTM-0K1(oppARYTM-0K3 x,oppARYTM-0K3 y)) =HIDDENR1 0NUMBERSK6"
     sorry
  thus "oppARYTM-0K3 (+ARYTM-0K1(x,y)) =XBOOLE-0R4 +ARYTM-0K1(oppARYTM-0K3 x,oppARYTM-0K3 y)"
    using arytm_0_def_3 sorry
qed "sorry"

end
