theory rolle
  imports fdiff_1 xxreal_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve g, r, s, p, t, x, x0, x1, x2 for "RealXREAL-0M1"
reserve n, n1 for "NatORDINAL1M6"
reserve s1, s2, s3 for "Real-SequenceSEQ-1M1"
reserve f, f1, f2 for "PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
mtheorem rolle_th_1:
" for p be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds p <XXREAL-0R3 g implies ( for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (([.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1) & f .FUNCT-1K1 p =XBOOLE-0R4 f .FUNCT-1K1 g) & f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[ implies ( ex x0 be RealXREAL-0M1 st x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ & diffFDIFF-1K1(f,x0) =HIDDENR1 0NUMBERSK6))"
proof-
  have " for p be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds p <XXREAL-0R3 g implies ( for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds [.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1 & (f .FUNCT-1K1 p =XBOOLE-0R4 f .FUNCT-1K1 g & f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[)) implies  not ( for x0 be RealXREAL-0M1 holds  not (x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ & diffFDIFF-1K1(f,x0) =HIDDENR1 0NUMBERSK6)))"
  proof(rule ballI,rule ballI,rule impI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix g assume [ty]: "g be RealXREAL-0M1"
    assume A1: "p <XXREAL-0R3 g"
    obtain Z where 
      [ty]:"Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2" and ZDef:"Z = ].RCOMP-1K2 p,g .["
       sorry
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A2: "[.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A3: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1"
      and A4: "f .FUNCT-1K1 p =XBOOLE-0R4 f .FUNCT-1K1 g"
      and A5: "f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .["
    have A6: "f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be compactRCOMP-1V1"
      using A2 A3 fcont_1_th_29 rcomp_1_th_6 sorry
    have "[.RCOMP-1K1 p,g .] be compactRCOMP-1V1"
      using rcomp_1_th_6 sorry
    then have A7: "f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be real-boundedXXREAL-2V5"
      using A2 A3 fcont_1_th_29 rcomp_1_th_10 sorry
    have "p inHIDDENR3 [.RCOMP-1K1 p,g .]"
      using A1 xxreal_1_th_1 sorry
    then obtain x1 x2 where
      [ty]:"x1 be RealXREAL-0M1" "x2 be RealXREAL-0M1" and 
      A8: "x1 inHIDDENR3 [.RCOMP-1K1 p,g .]"and A9: "x2 inHIDDENR3 [.RCOMP-1K1 p,g .]"and A10: "f .FUNCT-1K1 x1 =HIDDENR1 upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"and A11: "f .FUNCT-1K1 x2 =HIDDENR1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
      using A2 A3 fcont_1_th_31 rcomp_1_th_6 sorry
    have 
      [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" and
      [ty]:"x2 be ElementSUBSET-1M1-of REALNUMBERSK2"
      using xreal_0_def_1 sorry
    have "p inHIDDENR3 {r where r be RealXREAL-0M1 : p <=XXREAL-0R1 r & r <=XXREAL-0R1 g }"
      using A1 sorry
    then have "p inHIDDENR3 [.RCOMP-1K1 p,g .]"
      using rcomp_1_def_1 sorry
    then have "f .FUNCT-1K1 p inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])"
      using A2 funct_1_def_6 sorry
    then have A12: " not f .FUNCT-1K1 x1 <XXREAL-0R3 f .FUNCT-1K1 x2"
      using A10 A11 A6 rcomp_1_th_10 seq_4_th_11 sorry
    have A13: "].RCOMP-1K2 p,g .[ c=TARSKIR1 [.RCOMP-1K1 p,g .]"
      using xxreal_1_th_25 sorry
    then have A14: "].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A2 sorry
    show " not ( for x0 be RealXREAL-0M1 holds  not (x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ & diffFDIFF-1K1(f,x0) =HIDDENR1 0NUMBERSK6))"
    proof-
      have cases: "f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2 or f .FUNCT-1K1 x2 <XXREAL-0R3 f .FUNCT-1K1 x1"
        using A12 xxreal_0_th_1 sorry
      have case1: "f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2 implies  not ( for x0 be RealXREAL-0M1 holds  not (x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ & diffFDIFF-1K1(f,x0) =HIDDENR1 0NUMBERSK6))"
      proof(rule impI)
        assume A15: "f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2"
        have "p /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 g /XCMPLX-0K7 \<two>\<^sub>M"
          using A1 xreal_1_th_74 sorry
        then have "p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 g /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 g /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 g /XCMPLX-0K7 \<two>\<^sub>M & p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 p /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 g /XCMPLX-0K7 \<two>\<^sub>M"
          using xreal_1_th_8 sorry
        then have "p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 g /XCMPLX-0K7 \<two>\<^sub>M inTARSKIR2 {r where r be RealXREAL-0M1 : p <XXREAL-0R3 r & r <XXREAL-0R3 g }"
           sorry
        then have A16: "p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 g /XCMPLX-0K7 \<two>\<^sub>M inTARSKIR2 Z"
          using rcomp_1_def_2 sorry
        have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be constantFUNCT-1V5"
          using A10 A11 A7 A15 rfunct_2_th_19 sorry
        then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z be constantFUNCT-1V5"
          using partfun2_th_38 xxreal_1_th_25 sorry
        then have "(f `|FDIFF-1K2 Z).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 g /XCMPLX-0K7 \<two>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6"
          using A14 A16 fdiff_1_th_22 sorry
        then have "diffFDIFF-1K1(f,p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 g /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 0NUMBERSK6"
          using A5 A16 fdiff_1_def_7 sorry
        thus " not ( for x0 be RealXREAL-0M1 holds  not (x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ & diffFDIFF-1K1(f,x0) =HIDDENR1 0NUMBERSK6))"
          using A16 sorry
      qed
      have case2: "f .FUNCT-1K1 x2 <XXREAL-0R3 f .FUNCT-1K1 x1 implies  not ( for x0 be RealXREAL-0M1 holds  not (x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ & diffFDIFF-1K1(f,x0) =HIDDENR1 0NUMBERSK6))"
      proof(rule impI)
        assume A17: "f .FUNCT-1K1 x2 <XXREAL-0R3 f .FUNCT-1K1 x1"
        have A18: "x2 inTARSKIR2 ].RCOMP-1K2 p,g .[ or x1 inTARSKIR2 ].RCOMP-1K2 p,g .["
        proof-
          have " not x2 inTARSKIR2 ].RCOMP-1K2 p,g .[ &  not x1 inTARSKIR2 ].RCOMP-1K2 p,g .[ implies  False "
          proof(rule impMI ,rule impI)
            assume A19: " not x2 inTARSKIR2 ].RCOMP-1K2 p,g .["
              and A20: " not x1 inTARSKIR2 ].RCOMP-1K2 p,g .["
            have "x1 inTARSKIR2 ].RCOMP-1K2 p,g .[ \\/XBOOLE-0K2 {TARSKIK2 p,g }"
              using A1 A8 xxreal_1_th_128 sorry
            then have "x1 inTARSKIR2 {TARSKIK2 p,g }"
              using A20 xboole_0_def_3 sorry
            then have A21: "x1 =HIDDENR1 p or x1 =HIDDENR1 g"
              using tarski_def_2 sorry
            have "x2 inTARSKIR2 ].RCOMP-1K2 p,g .[ \\/XBOOLE-0K2 {TARSKIK2 p,g }"
              using A1 A9 xxreal_1_th_128 sorry
            then have "x2 inTARSKIR2 {TARSKIK2 p,g }"
              using A19 xboole_0_def_3 sorry
            thus " False "
              using A4 A17 A21 tarski_def_2 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have "x2 inTARSKIR2 ].RCOMP-1K2 p,g .[ & (x2 inTARSKIR2 ].RCOMP-1K2 p,g .[ & diffFDIFF-1K1(f,x2) =HIDDENR1 0NUMBERSK6) or x1 inTARSKIR2 ].RCOMP-1K2 p,g .[ & (x1 inTARSKIR2 ].RCOMP-1K2 p,g .[ implies x1 inTARSKIR2 ].RCOMP-1K2 p,g .[ & diffFDIFF-1K1(f,x1) =HIDDENR1 0NUMBERSK6)"
        proof-
          show "x2 inTARSKIR2 ].RCOMP-1K2 p,g .[ & (x2 inTARSKIR2 ].RCOMP-1K2 p,g .[ & diffFDIFF-1K1(f,x2) =HIDDENR1 0NUMBERSK6) or x1 inTARSKIR2 ].RCOMP-1K2 p,g .[ & (x1 inTARSKIR2 ].RCOMP-1K2 p,g .[ implies x1 inTARSKIR2 ].RCOMP-1K2 p,g .[ & diffFDIFF-1K1(f,x1) =HIDDENR1 0NUMBERSK6)"
          proof-
            have cases: "x2 inTARSKIR2 ].RCOMP-1K2 p,g .[ or x1 inTARSKIR2 ].RCOMP-1K2 p,g .["
              using A18 sorry
            have case1: "x2 inTARSKIR2 ].RCOMP-1K2 p,g .[ implies x2 inTARSKIR2 ].RCOMP-1K2 p,g .[ & diffFDIFF-1K1(f,x2) =HIDDENR1 0NUMBERSK6"
            proof(rule impI)
              assume A22: "x2 inTARSKIR2 ].RCOMP-1K2 p,g .["
              then obtain N1 where
                [ty]:"N1 be NeighbourhoodRCOMP-1M1-of x2" and 
                A23: "N1 c=TARSKIR1 Z"
                using rcomp_1_th_18 sorry
              obtain r where
                [ty]:"r be RealXREAL-0M1" and 
                A24: "0NUMBERSK6 <XXREAL-0R3 r"and A25: "N1 =XBOOLE-0R4 ].RCOMP-1K2 x2 -XCMPLX-0K6 r,x2 +XCMPLX-0K2 r .["
                using rcomp_1_def_6 sorry
              have 
                [ty]:"r be RealXREAL-0M1"
                 sorry
              let ?F = "\<lambda>Lamb1. r /XCMPLX-0K7 (Lamb1 +XCMPLX-0K2 \<two>\<^sub>M)"
              obtain s2 where
                [ty]:"s2 be Real-SequenceSEQ-1M1" and 
                A26: " for n be NatORDINAL1M6 holds s2 .FUNCT-1K1 n =XBOOLE-0R4 ?F(n)"
                using seq_1_sch_1 sorry
              have " for n be NatORDINAL1M6 holds 0NUMBERSK6 <>HIDDENR2 s2 .FUNCT-1K1 n"
              proof(rule ballI)
                fix n assume [ty]: "n be NatORDINAL1M6"
                have "0NUMBERSK6 <>HIDDENR2 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M)"
                  using A24 xreal_1_th_139 sorry
                thus "0NUMBERSK6 <>HIDDENR2 s2 .FUNCT-1K1 n"
                  using A26 sorry
              qed "sorry"
              then have A27: "s2 be non-zeroORDINAL1V9"
                using seq_1_th_5 sorry
              have "s2 be convergentSEQ-2V5 & limSEQ-2K1 s2 =HIDDENR1 0NUMBERSK6"
                using A26 seq_4_th_31 sorry
              then obtain h1 where 
                [ty]:"h1 be 0NUMBERSK6 -convergentFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Real-SequenceSEQ-1M1" and h1Def:"h1 = s2"
                using A27 fdiff_1_def_1 sorry
              obtain s1 where
                [ty]:"s1 be Real-SequenceSEQ-1M1" and 
                A28: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 =XBOOLE-0R4 {SEQ-4K1 x2}"
                using seq_1_th_6 sorry
              obtain c where 
                [ty]:"c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1" and cDef:"c = s1"
                using A28 funct_2_th_111 sorry
              have A29: " for n be NatORDINAL1M6 holds c .FUNCT-1K1 n =XBOOLE-0R4 x2"
              proof(rule ballI)
                fix n assume [ty]: "n be NatORDINAL1M6"
                have "c .FUNCT-1K1 n inTARSKIR2 {SEQ-4K1 x2}"
                  using A28 valued_0_th_28 sorry
                thus "c .FUNCT-1K1 n =XBOOLE-0R4 x2"
                  using tarski_def_1 sorry
              qed "sorry"
              let ?G = "\<lambda>Lamb1. -XCMPLX-0K4 r /XCMPLX-0K7 (Lamb1 +XCMPLX-0K2 \<two>\<^sub>M)"
              obtain s3 where
                [ty]:"s3 be Real-SequenceSEQ-1M1" and 
                A30: " for n be NatORDINAL1M6 holds s3 .FUNCT-1K1 n =HIDDENR1 ?G(n)"
                using seq_1_sch_1 sorry
              have " for n be NatORDINAL1M6 holds s3 .FUNCT-1K1 n =XBOOLE-0R4 (-XCMPLX-0K4 r)/XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M)"
              proof(rule ballI)
                fix n assume [ty]: "n be NatORDINAL1M6"
                have "s3 .FUNCT-1K1 n =HIDDENR1 -XCMPLX-0K4 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M)"
                  using A30 sorry
                thus "s3 .FUNCT-1K1 n =XBOOLE-0R4 (-XCMPLX-0K4 r)/XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M)"
                   sorry
              qed "sorry"
              then have A31: "s3 be convergentSEQ-2V5 & limSEQ-2K1 s3 =HIDDENR1 0NUMBERSK6"
                using seq_4_th_31 sorry
              have " for n be NatORDINAL1M6 holds 0NUMBERSK6 <>HIDDENR2 s3 .FUNCT-1K1 n"
              proof(rule ballI)
                fix n assume [ty]: "n be NatORDINAL1M6"
                have "-XCMPLX-0K4 0NUMBERSK6 <>HIDDENR2 -XCMPLX-0K4 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M)"
                  using A24 xreal_1_th_139 sorry
                thus "0NUMBERSK6 <>HIDDENR2 s3 .FUNCT-1K1 n"
                  using A30 sorry
              qed "sorry"
              then have "s3 be non-zeroORDINAL1V9"
                using seq_1_th_5 sorry
              then obtain h2 where 
                [ty]:"h2 be 0NUMBERSK6 -convergentFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Real-SequenceSEQ-1M1" and h2Def:"h2 = s3"
                using A31 fdiff_1_def_1 sorry
              have A32: "N1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
                using A14 A23 sorry
              have A33: " for n be NatORDINAL1M6 holds x2 -XCMPLX-0K6 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M) inTARSKIR2 N1"
              proof(rule ballI)
                fix n assume [ty]: "n be NatORDINAL1M6"
                have "0NUMBERSK6 +XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 n +XCMPLX-0K2 \<one>\<^sub>M"
                  using xreal_1_th_6 sorry
                then have "\<one>\<^sub>M <XXREAL-0R3 (n +XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M"
                  using nat_1_th_13 sorry
                then have "r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M) <XXREAL-0R3 r /XCMPLX-0K7 \<one>\<^sub>M"
                  using A24 xreal_1_th_76 sorry
                then have A34: "x2 -XCMPLX-0K6 r <XXREAL-0R3 x2 -XCMPLX-0K6 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M)"
                  using xreal_1_th_15 sorry
                have "x2 -XCMPLX-0K6 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M) <XXREAL-0R3 x2 +XCMPLX-0K2 r"
                  using A24 xreal_1_th_6 sorry
                then have "x2 -XCMPLX-0K6 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M) inTARSKIR2 {s where s be RealXREAL-0M1 : x2 -XCMPLX-0K6 r <XXREAL-0R3 s & s <XXREAL-0R3 x2 +XCMPLX-0K2 r }"
                  using A34 sorry
                thus "x2 -XCMPLX-0K6 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M) inTARSKIR2 N1"
                  using A25 rcomp_1_def_2 sorry
              qed "sorry"
              have A35: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 N1"
              proof-
                have " for y be objectHIDDENM1 holds y inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) implies y inHIDDENR3 N1"
                proof(rule ballI,rule impI)
                  fix y assume [ty]: "y be objectHIDDENM1"
                  assume "y inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
                  then obtain n where
                    [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                    A36: "(h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 y"
                    using funct_2_th_113 sorry
                  have "y =HIDDENR1 h2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                    using A36 seq_1_th_7 sorry
                  also have "... = (-XCMPLX-0K4 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M))+XCMPLX-0K2 c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                    using A30 sorry
                  also have "... = x2 -XCMPLX-0K6 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M)"
                    using A29 sorry
                  finally have "y =HIDDENR1 x2 -XCMPLX-0K6 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M)"
                     sorry
                  thus "y inHIDDENR3 N1"
                    using A33 sorry
                qed "sorry"
                thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 N1"
                  using tarski_def_3 sorry
              qed
              have A37: " for n be NatORDINAL1M6 holds x2 +XCMPLX-0K2 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M) inTARSKIR2 N1"
              proof(rule ballI)
                fix n assume [ty]: "n be NatORDINAL1M6"
                have "0NUMBERSK6 +XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 n +XCMPLX-0K2 \<one>\<^sub>M"
                  using xreal_1_th_6 sorry
                then have "\<one>\<^sub>M <XXREAL-0R3 (n +XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M"
                  using nat_1_th_13 sorry
                then have "r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M) <XXREAL-0R3 r /XCMPLX-0K7 \<one>\<^sub>M"
                  using A24 xreal_1_th_76 sorry
                then have A38: "x2 +XCMPLX-0K2 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M) <XXREAL-0R3 x2 +XCMPLX-0K2 r"
                  using xreal_1_th_6 sorry
                have "0NUMBERSK6 <XXREAL-0R3 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M)"
                  using A24 xreal_1_th_139 sorry
                then have "x2 -XCMPLX-0K6 r <XXREAL-0R3 x2 +XCMPLX-0K2 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M)"
                  using A24 xreal_1_th_6 sorry
                then have "x2 +XCMPLX-0K2 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M) inTARSKIR2 {s where s be RealXREAL-0M1 : x2 -XCMPLX-0K6 r <XXREAL-0R3 s & s <XXREAL-0R3 x2 +XCMPLX-0K2 r }"
                  using A38 sorry
                thus "x2 +XCMPLX-0K2 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M) inTARSKIR2 N1"
                  using A25 rcomp_1_def_2 sorry
              qed "sorry"
              have A39: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 N1"
              proof-
                have " for y be objectHIDDENM1 holds y inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) implies y inHIDDENR3 N1"
                proof(rule ballI,rule impI)
                  fix y assume [ty]: "y be objectHIDDENM1"
                  assume "y inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
                  then obtain n where
                    [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                    A40: "(h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 y"
                    using funct_2_th_113 sorry
                  have "y =HIDDENR1 h1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                    using A40 seq_1_th_7 sorry
                  also have "... = r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M) +XCMPLX-0K2 c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                    using A26 sorry
                  also have "... = x2 +XCMPLX-0K2 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M)"
                    using A29 sorry
                  finally have "y =HIDDENR1 x2 +XCMPLX-0K2 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M)"
                     sorry
                  thus "y inHIDDENR3 N1"
                    using A37 sorry
                qed "sorry"
                thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 N1"
                  using tarski_def_3 sorry
              qed
              have A41: " for n be NatORDINAL1M6 holds 0NUMBERSK6 <XXREAL-0R3 s2 .FUNCT-1K1 n"
              proof(rule ballI)
                fix n assume [ty]: "n be NatORDINAL1M6"
                have "0NUMBERSK6 <XXREAL-0R3 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M)"
                  using A24 xreal_1_th_139 sorry
                thus "0NUMBERSK6 <XXREAL-0R3 s2 .FUNCT-1K1 n"
                  using A26 sorry
              qed "sorry"
              have A42: " for n be NatORDINAL1M6 holds 0NUMBERSK6 <=XXREAL-0R1 (h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-1K1 n"
              proof(rule ballI)
                fix n assume [ty]: "n be NatORDINAL1M6"
                have A43: "0NUMBERSK6 <XXREAL-0R3 h1 .FUNCT-1K1 n & h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n =HIDDENR1 (h1 .FUNCT-1K1 n)\<inverse>XCMPLX-0K5"
                  using A41 valued_1_th_10 sorry
                have "(h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-1K1 n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
                  using valued_0_th_28 sorry
                then have "(h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-1K1 n inTARSKIR2 N1"
                  using A39 sorry
                then have "(h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-1K1 n inTARSKIR2 Z"
                  using A23 sorry
                then have "f .FUNCT-1K1 ((h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-1K1 n) inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])"
                  using A13 A14 funct_1_def_6 sorry
                then have "f .FUNCT-1K1 x2 <=XXREAL-0R1 f .FUNCT-1K1 ((h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-1K1 n)"
                  using A11 A7 seq_4_def_2 sorry
                then have A44: "0NUMBERSK6 <=XXREAL-0R1 f .FUNCT-1K1 ((h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-1K1 n) -XCMPLX-0K6 f .FUNCT-1K1 x2"
                  using xreal_1_th_48 sorry
                have 
                  [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
                  using ordinal1_def_12 sorry
                have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n1 inTARSKIR2 ].RCOMP-1K2 p,g .["
                proof(rule ballI)
                  fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
                  have "(h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n1 inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
                    using valued_0_th_28 sorry
                  then have "(h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n1 inTARSKIR2 N1"
                    using A39 sorry
                  thus "(h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n1 inTARSKIR2 ].RCOMP-1K2 p,g .["
                    using A23 sorry
                qed "sorry"
                then have A45: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 ].RCOMP-1K2 p,g .["
                  using funct_2_th_114 sorry
                have A46: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
                  using A2 A9 A28 zfmisc_1_th_31 sorry
                have "(h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                  using seq_1_th_8 sorry
                also have "... = h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                  using rfunct_2_th_1 sorry
                also have "... = h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (f .FUNCT-1K1 ((h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                  using A14 A45 funct_2_th_108 xboole_1_th_1 sorry
                also have "... = h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (f .FUNCT-1K1 ((h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 f .FUNCT-1K1 (c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n))"
                  using A46 funct_2_th_108 sorry
                also have "... = h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (f .FUNCT-1K1 ((h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 f .FUNCT-1K1 x2)"
                  using A29 sorry
                finally have "(h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (f .FUNCT-1K1 ((h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 f .FUNCT-1K1 x2)"
                   sorry
                thus "0NUMBERSK6 <=XXREAL-0R1 (h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-1K1 n"
                  using A44 A43 sorry
              qed "sorry"
              have A47: "f is-differentiable-inFDIFF-1R1 x2"
                using A5 A22 fdiff_1_th_9 sorry
              then have "h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & diffFDIFF-1K1(f,x2) =HIDDENR1 limSEQ-2K1 (h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))"
                using A32 A28 A39 fdiff_1_th_12 sorry
              then have A48: "0NUMBERSK6 <=XXREAL-0R1 diffFDIFF-1K1(f,x2)"
                using A42 seq_2_th_17 sorry
              have A49: " for n be NatORDINAL1M6 holds s3 .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6"
              proof(rule ballI)
                fix n assume [ty]: "n be NatORDINAL1M6"
                have "0NUMBERSK6 <XXREAL-0R3 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M)"
                  using A24 xreal_1_th_139 sorry
                then have "-XCMPLX-0K4 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M) <XXREAL-0R3 -XCMPLX-0K4 0NUMBERSK6"
                  using xreal_1_th_24 sorry
                thus "s3 .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6"
                  using A30 sorry
              qed "sorry"
              have A50: " for n be NatORDINAL1M6 holds (h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-1K1 n <=XXREAL-0R1 0NUMBERSK6"
              proof(rule ballI)
                fix n assume [ty]: "n be NatORDINAL1M6"
                have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n1 inTARSKIR2 ].RCOMP-1K2 p,g .["
                proof(rule ballI)
                  fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
                  have "(h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n1 inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
                    using valued_0_th_28 sorry
                  then have "(h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n1 inTARSKIR2 N1"
                    using A35 sorry
                  thus "(h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n1 inTARSKIR2 ].RCOMP-1K2 p,g .["
                    using A23 sorry
                qed "sorry"
                then have A51: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 ].RCOMP-1K2 p,g .["
                  using funct_2_th_114 sorry
                have "h2 .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6"
                  using A49 sorry
                then have "-XCMPLX-0K4 0NUMBERSK6 <XXREAL-0R3 -XCMPLX-0K4 h2 .FUNCT-1K1 n"
                  using xreal_1_th_24 sorry
                then have "0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (-XCMPLX-0K4 h2 .FUNCT-1K1 n)"
                   sorry
                then have "h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n =HIDDENR1 (h2 .FUNCT-1K1 n)\<inverse>XCMPLX-0K5 & 0NUMBERSK6 <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 h2 .FUNCT-1K1 n"
                  using valued_1_th_10 xcmplx_1_th_188 sorry
                then have A52: "h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n <=XXREAL-0R1 0NUMBERSK6"
                   sorry
                have "(h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-1K1 n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
                  using valued_0_th_28 sorry
                then have "(h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-1K1 n inTARSKIR2 N1"
                  using A35 sorry
                then have "(h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-1K1 n inTARSKIR2 Z"
                  using A23 sorry
                then have "f .FUNCT-1K1 ((h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-1K1 n) inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])"
                  using A13 A14 funct_1_def_6 sorry
                then have "f .FUNCT-1K1 x2 <=XXREAL-0R1 f .FUNCT-1K1 ((h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-1K1 n)"
                  using A11 A7 seq_4_def_2 sorry
                then have A53: "0NUMBERSK6 <=XXREAL-0R1 f .FUNCT-1K1 ((h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-1K1 n) -XCMPLX-0K6 f .FUNCT-1K1 x2"
                  using xreal_1_th_48 sorry
                have 
                  [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
                  using ordinal1_def_12 sorry
                have A54: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
                  using A2 A9 A28 zfmisc_1_th_31 sorry
                have "(h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                  using seq_1_th_8 sorry
                also have "... = h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                  using rfunct_2_th_1 sorry
                also have "... = h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (f .FUNCT-1K1 ((h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                  using A14 A51 funct_2_th_108 xboole_1_th_1 sorry
                also have "... = h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (f .FUNCT-1K1 ((h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 f .FUNCT-1K1 (c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n))"
                  using A54 funct_2_th_108 sorry
                also have "... = h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (f .FUNCT-1K1 ((h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 f .FUNCT-1K1 x2)"
                  using A29 sorry
                finally have "(h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (f .FUNCT-1K1 ((h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 f .FUNCT-1K1 x2)"
                   sorry
                thus "(h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-1K1 n <=XXREAL-0R1 0NUMBERSK6"
                  using A53 A52 sorry
              qed "sorry"
              have "h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & diffFDIFF-1K1(f,x2) =HIDDENR1 limSEQ-2K1 (h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))"
                using A47 A32 A28 A35 fdiff_1_th_12 sorry
              thus "x2 inTARSKIR2 ].RCOMP-1K2 p,g .[ & diffFDIFF-1K1(f,x2) =HIDDENR1 0NUMBERSK6"
                using A22 A48 A50 rfunct_2_th_7 sorry
            qed
            have case2: "x1 inTARSKIR2 ].RCOMP-1K2 p,g .[ implies x1 inTARSKIR2 ].RCOMP-1K2 p,g .[ & diffFDIFF-1K1(f,x1) =HIDDENR1 0NUMBERSK6"
            proof(rule impI)
              assume A55: "x1 inTARSKIR2 ].RCOMP-1K2 p,g .["
              then obtain N1 where
                [ty]:"N1 be NeighbourhoodRCOMP-1M1-of x1" and 
                A56: "N1 c=TARSKIR1 ].RCOMP-1K2 p,g .["
                using rcomp_1_th_18 sorry
              obtain r where
                [ty]:"r be RealXREAL-0M1" and 
                A57: "0NUMBERSK6 <XXREAL-0R3 r"and A58: "N1 =XBOOLE-0R4 ].RCOMP-1K2 x1 -XCMPLX-0K6 r,x1 +XCMPLX-0K2 r .["
                using rcomp_1_def_6 sorry
              have 
                [ty]:"r be RealXREAL-0M1"
                 sorry
              let ?F = "\<lambda>Lamb1. r /XCMPLX-0K7 (Lamb1 +XCMPLX-0K2 \<two>\<^sub>M)"
              obtain s2 where
                [ty]:"s2 be Real-SequenceSEQ-1M1" and 
                A59: " for n be NatORDINAL1M6 holds s2 .FUNCT-1K1 n =XBOOLE-0R4 ?F(n)"
                using seq_1_sch_1 sorry
              have " for n be NatORDINAL1M6 holds 0NUMBERSK6 <>HIDDENR2 s2 .FUNCT-1K1 n"
              proof(rule ballI)
                fix n assume [ty]: "n be NatORDINAL1M6"
                have "0NUMBERSK6 <>HIDDENR2 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M)"
                  using A57 xreal_1_th_139 sorry
                thus "0NUMBERSK6 <>HIDDENR2 s2 .FUNCT-1K1 n"
                  using A59 sorry
              qed "sorry"
              then have A60: "s2 be non-zeroORDINAL1V9"
                using seq_1_th_5 sorry
              have "s2 be convergentSEQ-2V5 & limSEQ-2K1 s2 =HIDDENR1 0NUMBERSK6"
                using A59 seq_4_th_31 sorry
              then obtain h1 where 
                [ty]:"h1 be 0NUMBERSK6 -convergentFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Real-SequenceSEQ-1M1" and h1Def:"h1 = s2"
                using A60 fdiff_1_def_1 sorry
              obtain s1 where
                [ty]:"s1 be Real-SequenceSEQ-1M1" and 
                A61: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 =XBOOLE-0R4 {SEQ-4K1 x1}"
                using seq_1_th_6 sorry
              obtain c where 
                [ty]:"c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1" and cDef:"c = s1"
                using A61 funct_2_th_111 sorry
              have A62: " for n be NatORDINAL1M6 holds c .FUNCT-1K1 n =XBOOLE-0R4 x1"
              proof(rule ballI)
                fix n assume [ty]: "n be NatORDINAL1M6"
                have "c .FUNCT-1K1 n inTARSKIR2 {SEQ-4K1 x1}"
                  using A61 valued_0_th_28 sorry
                thus "c .FUNCT-1K1 n =XBOOLE-0R4 x1"
                  using tarski_def_1 sorry
              qed "sorry"
              let ?G = "\<lambda>Lamb1. -XCMPLX-0K4 r /XCMPLX-0K7 (Lamb1 +XCMPLX-0K2 \<two>\<^sub>M)"
              obtain s3 where
                [ty]:"s3 be Real-SequenceSEQ-1M1" and 
                A63: " for n be NatORDINAL1M6 holds s3 .FUNCT-1K1 n =HIDDENR1 ?G(n)"
                using seq_1_sch_1 sorry
              have " for n be NatORDINAL1M6 holds s3 .FUNCT-1K1 n =XBOOLE-0R4 (-XCMPLX-0K4 r)/XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M)"
              proof(rule ballI)
                fix n assume [ty]: "n be NatORDINAL1M6"
                have "s3 .FUNCT-1K1 n =HIDDENR1 -XCMPLX-0K4 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M)"
                  using A63 sorry
                thus "s3 .FUNCT-1K1 n =XBOOLE-0R4 (-XCMPLX-0K4 r)/XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M)"
                   sorry
              qed "sorry"
              then have A64: "s3 be convergentSEQ-2V5 & limSEQ-2K1 s3 =HIDDENR1 0NUMBERSK6"
                using seq_4_th_31 sorry
              have " for n be NatORDINAL1M6 holds 0NUMBERSK6 <>HIDDENR2 s3 .FUNCT-1K1 n"
              proof(rule ballI)
                fix n assume [ty]: "n be NatORDINAL1M6"
                have "-XCMPLX-0K4 0NUMBERSK6 <>HIDDENR2 -XCMPLX-0K4 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M)"
                  using A57 xreal_1_th_139 sorry
                thus "0NUMBERSK6 <>HIDDENR2 s3 .FUNCT-1K1 n"
                  using A63 sorry
              qed "sorry"
              then have "s3 be non-zeroORDINAL1V9"
                using seq_1_th_5 sorry
              then obtain h2 where 
                [ty]:"h2 be 0NUMBERSK6 -convergentFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Real-SequenceSEQ-1M1" and h2Def:"h2 = s3"
                using A64 fdiff_1_def_1 sorry
              have A65: "N1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
                using A14 A56 sorry
              have A66: " for n be NatORDINAL1M6 holds x1 -XCMPLX-0K6 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M) inTARSKIR2 N1"
              proof(rule ballI)
                fix n assume [ty]: "n be NatORDINAL1M6"
                have "0NUMBERSK6 +XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 n +XCMPLX-0K2 \<one>\<^sub>M"
                  using xreal_1_th_6 sorry
                then have "\<one>\<^sub>M <XXREAL-0R3 (n +XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M"
                  using nat_1_th_13 sorry
                then have "r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M) <XXREAL-0R3 r /XCMPLX-0K7 \<one>\<^sub>M"
                  using A57 xreal_1_th_76 sorry
                then have A67: "x1 -XCMPLX-0K6 r <XXREAL-0R3 x1 -XCMPLX-0K6 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M)"
                  using xreal_1_th_15 sorry
                have "x1 -XCMPLX-0K6 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M) <XXREAL-0R3 x1 +XCMPLX-0K2 r"
                  using A57 xreal_1_th_6 sorry
                then have "x1 -XCMPLX-0K6 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M) inTARSKIR2 {s where s be RealXREAL-0M1 : x1 -XCMPLX-0K6 r <XXREAL-0R3 s & s <XXREAL-0R3 x1 +XCMPLX-0K2 r }"
                  using A67 sorry
                thus "x1 -XCMPLX-0K6 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M) inTARSKIR2 N1"
                  using A58 rcomp_1_def_2 sorry
              qed "sorry"
              have A68: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 N1"
              proof-
                have " for y be objectHIDDENM1 holds y inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) implies y inHIDDENR3 N1"
                proof(rule ballI,rule impI)
                  fix y assume [ty]: "y be objectHIDDENM1"
                  assume "y inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
                  then obtain n where
                    [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                    A69: "(h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 y"
                    using funct_2_th_113 sorry
                  have "y =HIDDENR1 h2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                    using A69 seq_1_th_7 sorry
                  also have "... = (-XCMPLX-0K4 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M))+XCMPLX-0K2 c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                    using A63 sorry
                  also have "... = x1 -XCMPLX-0K6 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M)"
                    using A62 sorry
                  finally have "y =HIDDENR1 x1 -XCMPLX-0K6 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M)"
                     sorry
                  thus "y inHIDDENR3 N1"
                    using A66 sorry
                qed "sorry"
                thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 N1"
                  using tarski_def_3 sorry
              qed
              have A70: " for n be NatORDINAL1M6 holds x1 +XCMPLX-0K2 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M) inTARSKIR2 N1"
              proof(rule ballI)
                fix n assume [ty]: "n be NatORDINAL1M6"
                have "0NUMBERSK6 +XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 n +XCMPLX-0K2 \<one>\<^sub>M"
                  using xreal_1_th_6 sorry
                then have "\<one>\<^sub>M <XXREAL-0R3 (n +XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M"
                  using nat_1_th_13 sorry
                then have "r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M) <XXREAL-0R3 r /XCMPLX-0K7 \<one>\<^sub>M"
                  using A57 xreal_1_th_76 sorry
                then have A71: "x1 +XCMPLX-0K2 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M) <XXREAL-0R3 x1 +XCMPLX-0K2 r"
                  using xreal_1_th_6 sorry
                have "0NUMBERSK6 <XXREAL-0R3 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M)"
                  using A57 xreal_1_th_139 sorry
                then have "x1 -XCMPLX-0K6 r <XXREAL-0R3 x1 +XCMPLX-0K2 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M)"
                  using A57 xreal_1_th_6 sorry
                then have "x1 +XCMPLX-0K2 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M) inTARSKIR2 {s where s be RealXREAL-0M1 : x1 -XCMPLX-0K6 r <XXREAL-0R3 s & s <XXREAL-0R3 x1 +XCMPLX-0K2 r }"
                  using A71 sorry
                thus "x1 +XCMPLX-0K2 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M) inTARSKIR2 N1"
                  using A58 rcomp_1_def_2 sorry
              qed "sorry"
              have A72: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 N1"
              proof-
                have " for y be objectHIDDENM1 holds y inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) implies y inHIDDENR3 N1"
                proof(rule ballI,rule impI)
                  fix y assume [ty]: "y be objectHIDDENM1"
                  assume "y inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
                  then obtain n where
                    [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                    A73: "(h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 y"
                    using funct_2_th_113 sorry
                  have "y =HIDDENR1 h1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                    using A73 seq_1_th_7 sorry
                  also have "... = r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M) +XCMPLX-0K2 c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                    using A59 sorry
                  also have "... = x1 +XCMPLX-0K2 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M)"
                    using A62 sorry
                  finally have "y =HIDDENR1 x1 +XCMPLX-0K2 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M)"
                     sorry
                  thus "y inHIDDENR3 N1"
                    using A70 sorry
                qed "sorry"
                thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 N1"
                  using tarski_def_3 sorry
              qed
              have A74: " for n be NatORDINAL1M6 holds 0NUMBERSK6 <XXREAL-0R3 s2 .FUNCT-1K1 n"
              proof(rule ballI)
                fix n assume [ty]: "n be NatORDINAL1M6"
                have "0NUMBERSK6 <XXREAL-0R3 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M)"
                  using A57 xreal_1_th_139 sorry
                thus "0NUMBERSK6 <XXREAL-0R3 s2 .FUNCT-1K1 n"
                  using A59 sorry
              qed "sorry"
              have A75: " for n be NatORDINAL1M6 holds (h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-1K1 n <=XXREAL-0R1 0NUMBERSK6"
              proof(rule ballI)
                fix n assume [ty]: "n be NatORDINAL1M6"
                have A76: "0NUMBERSK6 <XXREAL-0R3 h1 .FUNCT-1K1 n & h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n =HIDDENR1 (h1 .FUNCT-1K1 n)\<inverse>XCMPLX-0K5"
                  using A74 valued_1_th_10 sorry
                have "(h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-1K1 n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
                  using valued_0_th_28 sorry
                then have "(h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-1K1 n inTARSKIR2 N1"
                  using A72 sorry
                then have "(h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-1K1 n inTARSKIR2 Z"
                  using A56 sorry
                then have "f .FUNCT-1K1 ((h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-1K1 n) inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])"
                  using A13 A14 funct_1_def_6 sorry
                then have "f .FUNCT-1K1 ((h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-1K1 n) <=XXREAL-0R1 f .FUNCT-1K1 x1"
                  using A10 A7 seq_4_def_1 sorry
                then have "0NUMBERSK6 <=XXREAL-0R1 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 ((h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-1K1 n)"
                  using xreal_1_th_48 sorry
                then have A77: "-XCMPLX-0K4 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 ((h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-1K1 n)) <=XXREAL-0R1 -XCMPLX-0K4 0NUMBERSK6"
                   sorry
                have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n1 inTARSKIR2 ].RCOMP-1K2 p,g .["
                proof(rule ballI)
                  fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
                  have "(h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n1 inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
                    using valued_0_th_28 sorry
                  then have "(h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n1 inTARSKIR2 N1"
                    using A72 sorry
                  thus "(h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n1 inTARSKIR2 ].RCOMP-1K2 p,g .["
                    using A56 sorry
                qed "sorry"
                then have A78: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 ].RCOMP-1K2 p,g .["
                  using funct_2_th_114 sorry
                have 
                  [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
                  using ordinal1_def_12 sorry
                have A79: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
                  using A2 A8 A61 zfmisc_1_th_31 sorry
                have "(h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                  using seq_1_th_8 sorry
                also have "... = h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                  using rfunct_2_th_1 sorry
                also have "... = h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (f .FUNCT-1K1 ((h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                  using A14 A78 funct_2_th_108 xboole_1_th_1 sorry
                also have "... = h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (f .FUNCT-1K1 ((h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 f .FUNCT-1K1 (c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n))"
                  using A79 funct_2_th_108 sorry
                also have "... = h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (f .FUNCT-1K1 ((h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 f .FUNCT-1K1 x1)"
                  using A62 sorry
                finally have "(h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (f .FUNCT-1K1 ((h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 f .FUNCT-1K1 x1)"
                   sorry
                thus "(h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-1K1 n <=XXREAL-0R1 0NUMBERSK6"
                  using A77 A76 sorry
              qed "sorry"
              have A80: "f is-differentiable-inFDIFF-1R1 x1"
                using A5 A55 fdiff_1_th_9 sorry
              then have "h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & diffFDIFF-1K1(f,x1) =HIDDENR1 limSEQ-2K1 (h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))"
                using A65 A61 A72 fdiff_1_th_12 sorry
              then have A81: "diffFDIFF-1K1(f,x1) <=XXREAL-0R1 0NUMBERSK6"
                using A75 rfunct_2_th_7 sorry
              have A82: " for n be NatORDINAL1M6 holds s3 .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6"
              proof(rule ballI)
                fix n assume [ty]: "n be NatORDINAL1M6"
                have "0NUMBERSK6 <XXREAL-0R3 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M)"
                  using A57 xreal_1_th_139 sorry
                then have "-XCMPLX-0K4 r /XCMPLX-0K7 (n +XCMPLX-0K2 \<two>\<^sub>M) <XXREAL-0R3 -XCMPLX-0K4 0NUMBERSK6"
                  using xreal_1_th_24 sorry
                thus "s3 .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6"
                  using A63 sorry
              qed "sorry"
              have A83: " for n be NatORDINAL1M6 holds 0NUMBERSK6 <=XXREAL-0R1 (h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-1K1 n"
              proof(rule ballI)
                fix n assume [ty]: "n be NatORDINAL1M6"
                have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n1 inTARSKIR2 ].RCOMP-1K2 p,g .["
                proof(rule ballI)
                  fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
                  have "(h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n1 inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
                    using valued_0_th_28 sorry
                  then have "(h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n1 inTARSKIR2 N1"
                    using A68 sorry
                  thus "(h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n1 inTARSKIR2 ].RCOMP-1K2 p,g .["
                    using A56 sorry
                qed "sorry"
                then have A84: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 ].RCOMP-1K2 p,g .["
                  using funct_2_th_114 sorry
                have "h2 .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6"
                  using A82 sorry
                then have "-XCMPLX-0K4 0NUMBERSK6 <XXREAL-0R3 -XCMPLX-0K4 h2 .FUNCT-1K1 n"
                  using xreal_1_th_24 sorry
                then have "0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (-XCMPLX-0K4 h2 .FUNCT-1K1 n)"
                   sorry
                then have "h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n =HIDDENR1 (h2 .FUNCT-1K1 n)\<inverse>XCMPLX-0K5 & 0NUMBERSK6 <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 h2 .FUNCT-1K1 n"
                  using valued_1_th_10 xcmplx_1_th_188 sorry
                then have A85: "h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n <=XXREAL-0R1 0NUMBERSK6"
                   sorry
                have 
                  [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
                  using ordinal1_def_12 sorry
                have "(h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
                  using valued_0_th_28 sorry
                then have "(h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 N1"
                  using A68 sorry
                then have "(h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 Z"
                  using A56 sorry
                then have "f .FUNCT-1K1 ((h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])"
                  using A13 A14 funct_1_def_6 sorry
                then have "f .FUNCT-1K1 ((h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) <=XXREAL-0R1 f .FUNCT-1K1 x1"
                  using A10 A7 seq_4_def_1 sorry
                then have "0NUMBERSK6 <=XXREAL-0R1 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 ((h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                  using xreal_1_th_48 sorry
                then have A86: "-XCMPLX-0K4 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 ((h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)) <=XXREAL-0R1 -XCMPLX-0K4 0NUMBERSK6"
                   sorry
                have A87: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
                  using A2 A8 A61 zfmisc_1_th_31 sorry
                have "(h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                  using seq_1_th_8 sorry
                also have "... = h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                  using rfunct_2_th_1 sorry
                also have "... = h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (f .FUNCT-1K1 ((h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                  using A14 A84 funct_2_th_108 xboole_1_th_1 sorry
                also have "... = h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (f .FUNCT-1K1 ((h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 f .FUNCT-1K1 (c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n))"
                  using A87 funct_2_th_108 sorry
                also have "... = h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (f .FUNCT-1K1 ((h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 f .FUNCT-1K1 x1)"
                  using A62 sorry
                finally have "(h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (f .FUNCT-1K1 ((h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 f .FUNCT-1K1 x1)"
                   sorry
                thus "0NUMBERSK6 <=XXREAL-0R1 (h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-1K1 n"
                  using A86 A85 sorry
              qed "sorry"
              have "h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & diffFDIFF-1K1(f,x1) =HIDDENR1 limSEQ-2K1 (h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))"
                using A80 A65 A61 A68 fdiff_1_th_12 sorry
              thus "x1 inTARSKIR2 ].RCOMP-1K2 p,g .[ & diffFDIFF-1K1(f,x1) =HIDDENR1 0NUMBERSK6"
                using A55 A81 A83 seq_2_th_17 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus " not ( for x0 be RealXREAL-0M1 holds  not (x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ & diffFDIFF-1K1(f,x0) =HIDDENR1 0NUMBERSK6))"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$N Rolle Theorem*)
mtheorem rolle_th_2:
" for x be RealXREAL-0M1 holds  for t be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 t implies ( for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (([.RCOMP-1K1 x,x +XCMPLX-0K2 t .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x,x +XCMPLX-0K2 t .]) be continuousFCONT-1V1) & f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 (x +XCMPLX-0K2 t)) & f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 x,x +XCMPLX-0K2 t .[ implies ( ex s be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 s & s <XXREAL-0R3 \<one>\<^sub>M) & diffFDIFF-1K1(f,x +XCMPLX-0K2 s *XCMPLX-0K3 t) =HIDDENR1 0NUMBERSK6))"
proof-
  have " for x be RealXREAL-0M1 holds  for t be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 t implies ( for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (([.RCOMP-1K1 x,x +XCMPLX-0K2 t .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x,x +XCMPLX-0K2 t .]) be continuousFCONT-1V1) & f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 (x +XCMPLX-0K2 t)) & f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 x,x +XCMPLX-0K2 t .[ implies ( ex s be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 s & (s <XXREAL-0R3 \<one>\<^sub>M & diffFDIFF-1K1(f,x +XCMPLX-0K2 s *XCMPLX-0K3 t) =HIDDENR1 0NUMBERSK6)))"
  proof(rule ballI,rule ballI,rule impI,rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix t assume [ty]: "t be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 t"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume "(([.RCOMP-1K1 x,x +XCMPLX-0K2 t .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x,x +XCMPLX-0K2 t .]) be continuousFCONT-1V1) & f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 (x +XCMPLX-0K2 t)) & f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 x,x +XCMPLX-0K2 t .["
    then obtain x0 where
      [ty]:"x0 be RealXREAL-0M1" and 
      A2: "x0 inHIDDENR3 ].RCOMP-1K2 x,x +XCMPLX-0K2 t .["and A3: "diffFDIFF-1K1(f,x0) =HIDDENR1 0NUMBERSK6"
      using A1 rolle_th_1 xreal_1_th_29 sorry
    obtain s where 
      [ty]:"s be setHIDDENM2" and sDef:"s = (x0 -XCMPLX-0K6 x)/XCMPLX-0K7 t"
       sorry
    show " ex s be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 s & (s <XXREAL-0R3 \<one>\<^sub>M & diffFDIFF-1K1(f,x +XCMPLX-0K2 s *XCMPLX-0K3 t) =HIDDENR1 0NUMBERSK6)"
    proof(rule bexI[of _ "s"],rule conjMI,rule conjMI)
      have "x0 inHIDDENR3 {r where r be RealXREAL-0M1 : x <XXREAL-0R3 r & r <XXREAL-0R3 x +XCMPLX-0K2 t }"
        using A2 rcomp_1_def_2 sorry
      then have A4: " ex g be RealXREAL-0M1 st (g =HIDDENR1 x0 & x <XXREAL-0R3 g) & g <XXREAL-0R3 x +XCMPLX-0K2 t"
         sorry
      then have "0NUMBERSK6 <XXREAL-0R3 x0 -XCMPLX-0K6 x"
        using xreal_1_th_50 sorry
      then have "(0NUMBERSK6)/XCMPLX-0K7 t <XXREAL-0R3 (x0 -XCMPLX-0K6 x)/XCMPLX-0K7 t"
        using A1 xreal_1_th_74 sorry
      thus "0NUMBERSK6 <XXREAL-0R3 s"
         sorry
      have "x0 -XCMPLX-0K6 x <XXREAL-0R3 t"
        using A4 xreal_1_th_19 sorry
      then have "(x0 -XCMPLX-0K6 x)/XCMPLX-0K7 t <XXREAL-0R3 t /XCMPLX-0K7 t"
        using A1 xreal_1_th_74 sorry
      thus "s <XXREAL-0R3 \<one>\<^sub>M"
        using A1 xcmplx_1_th_60 sorry
      have "s *XCMPLX-0K3 t +XCMPLX-0K2 x =XBOOLE-0R4 (x0 -XCMPLX-0K6 x)+XCMPLX-0K2 x"
        using A1 xcmplx_1_th_87 sorry
      thus "diffFDIFF-1K1(f,x +XCMPLX-0K2 s *XCMPLX-0K3 t) =HIDDENR1 0NUMBERSK6"
        using A3 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$N The Mean Value Theorem*)
mtheorem rolle_th_3:
" for p be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds p <XXREAL-0R3 g implies ( for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ([.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1) & f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[ implies ( ex x0 be RealXREAL-0M1 st x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ & diffFDIFF-1K1(f,x0) =HIDDENR1 (f .FUNCT-1K1 g -XCMPLX-0K6 f .FUNCT-1K1 p)/XCMPLX-0K7 (g -XCMPLX-0K6 p)))"
proof-
  have " for p be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds p <XXREAL-0R3 g implies ( for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds [.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1 & f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[) implies ( ex tVar2 be RealXREAL-0M1 st tVar2 inHIDDENR3 ].RCOMP-1K2 p,g .[ & diffFDIFF-1K1(f,tVar2) =HIDDENR1 (f .FUNCT-1K1 g -XCMPLX-0K6 f .FUNCT-1K1 p)/XCMPLX-0K7 (g -XCMPLX-0K6 p)))"
  proof(rule ballI,rule ballI,rule impI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix g assume [ty]: "g be RealXREAL-0M1"
    assume A1: "p <XXREAL-0R3 g"
    have A2: "0NUMBERSK6 <>HIDDENR2 g -XCMPLX-0K6 p"
      using A1 sorry
    obtain Z where 
      [ty]:"Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2" and ZDef:"Z = ].RCOMP-1K2 p,g .["
       sorry
    let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 [.RCOMP-1K1 p,g .]"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A3: "[.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A4: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1"
      and A5: "f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .["
    let ?r = "(f .FUNCT-1K1 g -XCMPLX-0K6 f .FUNCT-1K1 p)/XCMPLX-0K7 (g -XCMPLX-0K6 p)"
    let ?F = "\<lambda>Lamb1. InSUBSET-1K10(?r *XCMPLX-0K3 (Lamb1 -XCMPLX-0K6 p),REALNUMBERSK2)"
    obtain f1 where
      [ty]:"f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
      A6: "( for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds x inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 iff ?P(x)) & ( for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds x inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 implies f1 .FUNCT-1K1 x =XBOOLE-0R4 ?F(x))"
      using seq_1_sch_3 sorry
    have A7: " for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 implies f1 .FUNCT-1K1 x =XBOOLE-0R4 ?r *XCMPLX-0K3 (x -XCMPLX-0K6 p)"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 implies f1 .FUNCT-1K1 x =XBOOLE-0R4 ((f .FUNCT-1K1 g -XCMPLX-0K6 f .FUNCT-1K1 p)/XCMPLX-0K7 (g -XCMPLX-0K6 p))*XCMPLX-0K3 (x -XCMPLX-0K6 p)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A8: "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        have 
          [ty]:"x be RealXREAL-0M1"
           sorry
        have "f1 .FUNCT-1K1 x =XBOOLE-0R4 ?F(x)"
          using A6 A8 sorry
        thus "f1 .FUNCT-1K1 x =XBOOLE-0R4 ((f .FUNCT-1K1 g -XCMPLX-0K6 f .FUNCT-1K1 p)/XCMPLX-0K7 (g -XCMPLX-0K6 p))*XCMPLX-0K3 (x -XCMPLX-0K6 p)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    let ?f2 = "f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1"
    have A9: "[.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      using A6 sorry
    then have A10: "[.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      using A3 xboole_1_th_19 sorry
    then have A11: "[.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f2"
      using valued_1_th_12 sorry
    have "[.RCOMP-1K1 p,g .] =XBOOLE-0R4 ].RCOMP-1K2 p,g .[ \\/XBOOLE-0K2 {TARSKIK2 p,g }"
      using A1 xxreal_1_th_128 sorry
    then have A12: "{TARSKIK2 p,g } c=TARSKIR1 [.RCOMP-1K1 p,g .]"
      using xboole_1_th_7 sorry
    then have A13: "p inHIDDENR3 [.RCOMP-1K1 p,g .]"
      using zfmisc_1_th_32 sorry
    then have A14: "p inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      using A6 sorry
    have "[.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      using A3 A9 xboole_1_th_19 sorry
    then have A15: "[.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f2"
      using valued_1_th_12 sorry
    then have A16: "?f2 .FUNCT-1K1 p =HIDDENR1 f .FUNCT-1K1 p -XCMPLX-0K6 f1 .FUNCT-1K1 p"
      using A13 valued_1_th_13 sorry
    also have "... = f .FUNCT-1K1 p -XCMPLX-0K6 ?r *XCMPLX-0K3 (p -XCMPLX-0K6 p)"
      using A14 A7 sorry
    also have "... = f .FUNCT-1K1 p"
       sorry
    finally have "?f2 .FUNCT-1K1 p =HIDDENR1 f .FUNCT-1K1 p"
       sorry
    have A17: "].RCOMP-1K2 p,g .[ c=TARSKIR1 [.RCOMP-1K1 p,g .]"
      using xxreal_1_th_25 sorry
    then have A18: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      using A9 sorry
    have A19: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 ((f .FUNCT-1K1 g -XCMPLX-0K6 f .FUNCT-1K1 p)/XCMPLX-0K7 (g -XCMPLX-0K6 p))*XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 ((f .FUNCT-1K1 g -XCMPLX-0K6 f .FUNCT-1K1 p)/XCMPLX-0K7 (g -XCMPLX-0K6 p))*XCMPLX-0K3 p)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A17 A6 sorry
      then have "f1 .FUNCT-1K1 x =HIDDENR1 ((f .FUNCT-1K1 g -XCMPLX-0K6 f .FUNCT-1K1 p)/XCMPLX-0K7 (g -XCMPLX-0K6 p))*XCMPLX-0K3 (x -XCMPLX-0K6 p)"
        using A7 sorry
      also have "... = ((f .FUNCT-1K1 g -XCMPLX-0K6 f .FUNCT-1K1 p)/XCMPLX-0K7 (g -XCMPLX-0K6 p))*XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 ((f .FUNCT-1K1 g -XCMPLX-0K6 f .FUNCT-1K1 p)/XCMPLX-0K7 (g -XCMPLX-0K6 p))*XCMPLX-0K3 p)"
         sorry
      finally show "f1 .FUNCT-1K1 x =HIDDENR1 ((f .FUNCT-1K1 g -XCMPLX-0K6 f .FUNCT-1K1 p)/XCMPLX-0K7 (g -XCMPLX-0K6 p))*XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 ((f .FUNCT-1K1 g -XCMPLX-0K6 f .FUNCT-1K1 p)/XCMPLX-0K7 (g -XCMPLX-0K6 p))*XCMPLX-0K3 p)"
         sorry
    qed "sorry"
    then have A20: "f1 is-differentiable-onFDIFF-1R2 Z"
      using A18 fdiff_1_th_23 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 [.RCOMP-1K1 p,g .] implies f1 .FUNCT-1K1 x =HIDDENR1 ((f .FUNCT-1K1 g -XCMPLX-0K6 f .FUNCT-1K1 p)/XCMPLX-0K7 (g -XCMPLX-0K6 p))*XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 ((f .FUNCT-1K1 g -XCMPLX-0K6 f .FUNCT-1K1 p)/XCMPLX-0K7 (g -XCMPLX-0K6 p))*XCMPLX-0K3 p)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 [.RCOMP-1K1 p,g .]"
      then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A6 sorry
      then have "f1 .FUNCT-1K1 x =HIDDENR1 ((f .FUNCT-1K1 g -XCMPLX-0K6 f .FUNCT-1K1 p)/XCMPLX-0K7 (g -XCMPLX-0K6 p))*XCMPLX-0K3 (x -XCMPLX-0K6 p)"
        using A7 sorry
      also have "... = ((f .FUNCT-1K1 g -XCMPLX-0K6 f .FUNCT-1K1 p)/XCMPLX-0K7 (g -XCMPLX-0K6 p))*XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 ((f .FUNCT-1K1 g -XCMPLX-0K6 f .FUNCT-1K1 p)/XCMPLX-0K7 (g -XCMPLX-0K6 p))*XCMPLX-0K3 p)"
         sorry
      finally show "f1 .FUNCT-1K1 x =HIDDENR1 ((f .FUNCT-1K1 g -XCMPLX-0K6 f .FUNCT-1K1 p)/XCMPLX-0K7 (g -XCMPLX-0K6 p))*XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 ((f .FUNCT-1K1 g -XCMPLX-0K6 f .FUNCT-1K1 p)/XCMPLX-0K7 (g -XCMPLX-0K6 p))*XCMPLX-0K3 p)"
         sorry
    qed "sorry"
    then have "f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1"
      using fcont_1_th_41 sorry
    then have A21: "?f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1"
      using A4 A10 fcont_1_th_18 sorry
    have A22: "g inHIDDENR3 [.RCOMP-1K1 p,g .]"
      using A12 zfmisc_1_th_32 sorry
    then have A23: "g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      using A6 sorry
    have "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A3 A17 sorry
    then have "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      using A18 xboole_1_th_19 sorry
    then have A24: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f2"
      using valued_1_th_12 sorry
    have "?f2 .FUNCT-1K1 g =HIDDENR1 f .FUNCT-1K1 g -XCMPLX-0K6 f1 .FUNCT-1K1 g"
      using A22 A15 valued_1_th_13 sorry
    also have "... = f .FUNCT-1K1 g -XCMPLX-0K6 ((f .FUNCT-1K1 g -XCMPLX-0K6 f .FUNCT-1K1 p)/XCMPLX-0K7 (g -XCMPLX-0K6 p))*XCMPLX-0K3 (g -XCMPLX-0K6 p)"
      using A7 A23 sorry
    also have "... = f .FUNCT-1K1 g -XCMPLX-0K6 (f .FUNCT-1K1 g -XCMPLX-0K6 f .FUNCT-1K1 p)"
      using A2 xcmplx_1_th_87 sorry
    also have "... = ?f2 .FUNCT-1K1 p"
      using A16 sorry
    finally have "?f2 .FUNCT-1K1 g =HIDDENR1 ?f2 .FUNCT-1K1 p"
       sorry
    then obtain x0 where
      [ty]:"x0 be RealXREAL-0M1" and 
      A25: "x0 inHIDDENR3 ].RCOMP-1K2 p,g .["and A26: "diffFDIFF-1K1(?f2,x0) =HIDDENR1 0NUMBERSK6"
      using A1 A5 A20 A11 A21 A24 rolle_th_1 fdiff_1_th_19 sorry
    show " ex tVar2 be RealXREAL-0M1 st tVar2 inHIDDENR3 ].RCOMP-1K2 p,g .[ & diffFDIFF-1K1(f,tVar2) =HIDDENR1 (f .FUNCT-1K1 g -XCMPLX-0K6 f .FUNCT-1K1 p)/XCMPLX-0K7 (g -XCMPLX-0K6 p)"
    proof(rule bexI[of _ "x0"])
      have "?f2 is-differentiable-onFDIFF-1R2 Z"
        using A5 A20 A24 fdiff_1_th_19 sorry
      then have "diffFDIFF-1K1(?f2,x0) =HIDDENR1 (?f2 `|FDIFF-1K2 Z).FUNCT-1K1 x0"
        using A25 fdiff_1_def_7 sorry
      also have "... = diffFDIFF-1K1(f,x0) -XCMPLX-0K6 diffFDIFF-1K1(f1,x0)"
        using A5 A20 A24 A25 fdiff_1_th_19 sorry
      also have "... = diffFDIFF-1K1(f,x0) -XCMPLX-0K6 (f1 `|FDIFF-1K2 Z).FUNCT-1K1 x0"
        using A20 A25 fdiff_1_def_7 sorry
      finally have "diffFDIFF-1K1(?f2,x0) =HIDDENR1 diffFDIFF-1K1(f,x0) -XCMPLX-0K6 (f1 `|FDIFF-1K2 Z).FUNCT-1K1 x0"
         sorry
      thus "x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ & diffFDIFF-1K1(f,x0) =HIDDENR1 (f .FUNCT-1K1 g -XCMPLX-0K6 f .FUNCT-1K1 p)/XCMPLX-0K7 (g -XCMPLX-0K6 p)"
        using A18 A19 A25 A26 fdiff_1_th_23 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$N Lagrange Theorem*)
mtheorem rolle_th_4:
" for x be RealXREAL-0M1 holds  for t be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 t implies ( for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ([.RCOMP-1K1 x,x +XCMPLX-0K2 t .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x,x +XCMPLX-0K2 t .]) be continuousFCONT-1V1) & f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 x,x +XCMPLX-0K2 t .[ implies ( ex s be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 s & s <XXREAL-0R3 \<one>\<^sub>M) & f .FUNCT-1K1 (x +XCMPLX-0K2 t) =XBOOLE-0R4 f .FUNCT-1K1 x +XCMPLX-0K2 t *XCMPLX-0K3 (diffFDIFF-1K1(f,x +XCMPLX-0K2 s *XCMPLX-0K3 t))))"
proof-
  have " for x be RealXREAL-0M1 holds  for t be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 t implies ( for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ([.RCOMP-1K1 x,x +XCMPLX-0K2 t .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x,x +XCMPLX-0K2 t .]) be continuousFCONT-1V1) & f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 x,x +XCMPLX-0K2 t .[ implies ( ex s be  RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & (s <XXREAL-0R3 \<one>\<^sub>M & f .FUNCT-1K1 (x +XCMPLX-0K2 t) =XBOOLE-0R4 f .FUNCT-1K1 x +XCMPLX-0K2 t *XCMPLX-0K3 (diffFDIFF-1K1(f,x +XCMPLX-0K2 s *XCMPLX-0K3 t)))))"
  proof(rule ballI,rule ballI,rule impI,rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix t assume [ty]: "t be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 t"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume "([.RCOMP-1K1 x,x +XCMPLX-0K2 t .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x,x +XCMPLX-0K2 t .]) be continuousFCONT-1V1) & f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 x,x +XCMPLX-0K2 t .["
    then obtain x0 where
      [ty]:"x0 be RealXREAL-0M1" and 
      A2: "x0 inHIDDENR3 ].RCOMP-1K2 x,x +XCMPLX-0K2 t .["and A3: "diffFDIFF-1K1(f,x0) =HIDDENR1 (f .FUNCT-1K1 (x +XCMPLX-0K2 t) -XCMPLX-0K6 f .FUNCT-1K1 x)/XCMPLX-0K7 ((x +XCMPLX-0K2 t)-XCMPLX-0K6 x)"
      using A1 rolle_th_3 xreal_1_th_29 sorry
    obtain s where 
      [ty]:"s be setHIDDENM2" and sDef:"s = (x0 -XCMPLX-0K6 x)/XCMPLX-0K7 t"
       sorry
    show " ex s be  RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & (s <XXREAL-0R3 \<one>\<^sub>M & f .FUNCT-1K1 (x +XCMPLX-0K2 t) =XBOOLE-0R4 f .FUNCT-1K1 x +XCMPLX-0K2 t *XCMPLX-0K3 (diffFDIFF-1K1(f,x +XCMPLX-0K2 s *XCMPLX-0K3 t)))"
    proof(rule bexI[of _ "s"],rule conjMI,rule conjMI)
      have "x0 inHIDDENR3 {r where r be RealXREAL-0M1 : x <XXREAL-0R3 r & r <XXREAL-0R3 x +XCMPLX-0K2 t }"
        using A2 rcomp_1_def_2 sorry
      then have A4: " ex g be RealXREAL-0M1 st (g =HIDDENR1 x0 & x <XXREAL-0R3 g) & g <XXREAL-0R3 x +XCMPLX-0K2 t"
         sorry
      then have "0NUMBERSK6 <XXREAL-0R3 x0 -XCMPLX-0K6 x"
        using xreal_1_th_50 sorry
      then have "(0NUMBERSK6)/XCMPLX-0K7 t <XXREAL-0R3 (x0 -XCMPLX-0K6 x)/XCMPLX-0K7 t"
        using A1 xreal_1_th_74 sorry
      thus "0NUMBERSK6 <XXREAL-0R3 s"
         sorry
      have "x0 -XCMPLX-0K6 x <XXREAL-0R3 t"
        using A4 xreal_1_th_19 sorry
      then have "(x0 -XCMPLX-0K6 x)/XCMPLX-0K7 t <XXREAL-0R3 t /XCMPLX-0K7 t"
        using A1 xreal_1_th_74 sorry
      thus "s <XXREAL-0R3 \<one>\<^sub>M"
        using A1 xcmplx_1_th_60 sorry
      have A5: "s *XCMPLX-0K3 t +XCMPLX-0K2 x =XBOOLE-0R4 (x0 -XCMPLX-0K6 x)+XCMPLX-0K2 x"
        using A1 xcmplx_1_th_87 sorry
      have "f .FUNCT-1K1 x +XCMPLX-0K2 t *XCMPLX-0K3 (diffFDIFF-1K1(f,x0)) =XBOOLE-0R4 f .FUNCT-1K1 x +XCMPLX-0K2 (f .FUNCT-1K1 (x +XCMPLX-0K2 t) -XCMPLX-0K6 f .FUNCT-1K1 x)"
        using A1 A3 xcmplx_1_th_87 sorry
      thus "f .FUNCT-1K1 (x +XCMPLX-0K2 t) =XBOOLE-0R4 f .FUNCT-1K1 x +XCMPLX-0K2 t *XCMPLX-0K3 (diffFDIFF-1K1(f,x +XCMPLX-0K2 s *XCMPLX-0K3 t))"
        using A5 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rolle_th_5:
" for p be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds p <XXREAL-0R3 g implies ( for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (((([.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & [.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2) & f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1) & f1 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[) & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1) & f2 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[ implies ( ex x0 be RealXREAL-0M1 st x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ & (f1 .FUNCT-1K1 g -XCMPLX-0K6 f1 .FUNCT-1K1 p)*XCMPLX-0K3 (diffFDIFF-1K1(f2,x0)) =XBOOLE-0R4 (f2 .FUNCT-1K1 g -XCMPLX-0K6 f2 .FUNCT-1K1 p)*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))))"
proof-
  have " for p be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds p <XXREAL-0R3 g implies ( for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds [.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & ([.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 & (f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1 & (f1 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[ & (f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1 & f2 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[)))) implies  not ( for x0 be RealXREAL-0M1 holds  not (x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ & (f1 .FUNCT-1K1 g -XCMPLX-0K6 f1 .FUNCT-1K1 p)*XCMPLX-0K3 (diffFDIFF-1K1(f2,x0)) =XBOOLE-0R4 (f2 .FUNCT-1K1 g -XCMPLX-0K6 f2 .FUNCT-1K1 p)*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0)))))"
  proof(rule ballI,rule ballI,rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix g assume [ty]: "g be RealXREAL-0M1"
    assume A1: "p <XXREAL-0R3 g"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A2: "[.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      and A3: "[.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      and A4: "f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1"
      and A5: "f1 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .["
      and A6: "f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1"
      and A7: "f2 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .["
    have A8: "].RCOMP-1K2 p,g .[ c=TARSKIR1 [.RCOMP-1K1 p,g .]"
      using xxreal_1_th_25 sorry
    have " ex x0 be RealXREAL-0M1 st x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ & (f1 .FUNCT-1K1 g -XCMPLX-0K6 f1 .FUNCT-1K1 p)*XCMPLX-0K3 (diffFDIFF-1K1(f2,x0)) =XBOOLE-0R4 (f2 .FUNCT-1K1 g -XCMPLX-0K6 f2 .FUNCT-1K1 p)*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))"
    proof-
      show " ex x0 be RealXREAL-0M1 st x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ & (f1 .FUNCT-1K1 g -XCMPLX-0K6 f1 .FUNCT-1K1 p)*XCMPLX-0K3 (diffFDIFF-1K1(f2,x0)) =XBOOLE-0R4 (f2 .FUNCT-1K1 g -XCMPLX-0K6 f2 .FUNCT-1K1 p)*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))"
      proof-
        have cases: "f2 .FUNCT-1K1 p =XBOOLE-0R4 f2 .FUNCT-1K1 g or f2 .FUNCT-1K1 p <>HIDDENR2 f2 .FUNCT-1K1 g"
           sorry
        have case1: "f2 .FUNCT-1K1 p =XBOOLE-0R4 f2 .FUNCT-1K1 g implies ( ex x0 be RealXREAL-0M1 st x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ & (f1 .FUNCT-1K1 g -XCMPLX-0K6 f1 .FUNCT-1K1 p)*XCMPLX-0K3 (diffFDIFF-1K1(f2,x0)) =XBOOLE-0R4 (f2 .FUNCT-1K1 g -XCMPLX-0K6 f2 .FUNCT-1K1 p)*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0)))"
        proof(rule impI)
          assume A9: "f2 .FUNCT-1K1 p =XBOOLE-0R4 f2 .FUNCT-1K1 g"
          then obtain x0 where
            [ty]:"x0 be RealXREAL-0M1" and 
            A10: "x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ & diffFDIFF-1K1(f2,x0) =HIDDENR1 0NUMBERSK6"
            using A1 A3 A6 A7 rolle_th_1 sorry
          show " ex x0 be RealXREAL-0M1 st x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ & (f1 .FUNCT-1K1 g -XCMPLX-0K6 f1 .FUNCT-1K1 p)*XCMPLX-0K3 (diffFDIFF-1K1(f2,x0)) =XBOOLE-0R4 (f2 .FUNCT-1K1 g -XCMPLX-0K6 f2 .FUNCT-1K1 p)*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))"
          proof(rule bexI[of _ "x0"])
            show "x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ & (f1 .FUNCT-1K1 g -XCMPLX-0K6 f1 .FUNCT-1K1 p)*XCMPLX-0K3 (diffFDIFF-1K1(f2,x0)) =XBOOLE-0R4 (f2 .FUNCT-1K1 g -XCMPLX-0K6 f2 .FUNCT-1K1 p)*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))"
              using A9 A10 sorry
          qed "sorry"
        qed
        have case2: "f2 .FUNCT-1K1 p <>HIDDENR2 f2 .FUNCT-1K1 g implies ( ex x0 be RealXREAL-0M1 st x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ & (f1 .FUNCT-1K1 g -XCMPLX-0K6 f1 .FUNCT-1K1 p)*XCMPLX-0K3 (diffFDIFF-1K1(f2,x0)) =XBOOLE-0R4 (f2 .FUNCT-1K1 g -XCMPLX-0K6 f2 .FUNCT-1K1 p)*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0)))"
        proof(rule impI)
          assume "f2 .FUNCT-1K1 p <>HIDDENR2 f2 .FUNCT-1K1 g"
          then have A11: "f2 .FUNCT-1K1 g -XCMPLX-0K6 f2 .FUNCT-1K1 p <>HIDDENR2 0NUMBERSK6"
             sorry
          obtain Z where 
            [ty]:"Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2" and ZDef:"Z = ].RCOMP-1K2 p,g .["
             sorry
          let ?s = "(f1 .FUNCT-1K1 g -XCMPLX-0K6 f1 .FUNCT-1K1 p)/XCMPLX-0K7 (f2 .FUNCT-1K1 g -XCMPLX-0K6 f2 .FUNCT-1K1 p)"
          obtain fp where 
            [ty]:"fp be ElementSUBSET-1M1-of REALNUMBERSK2" and fpDef:"fp = f1 .FUNCT-1K1 p -XCMPLX-0K6 f2 .FUNCT-1K1 p *XCMPLX-0K3 ?s"
            using xreal_0_def_1 sorry
          obtain f3 where 
            [ty]:"f3 be PartFuncPARTFUN1M1-of([.RCOMP-1K1 p,g .],REALNUMBERSK2)" and f3Def:"f3 = [.RCOMP-1K1 p,g .] -->PARTFUN2K4\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> fp"
            using funcop_1_th_45 sorry
          have 
            [ty]:"f3 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
             sorry
          let ?f4 = "?s (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2"
          let ?f5 = "f3 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?f4"
          let ?f = "?f5 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1"
          have A12: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f3"
            using A8 funcop_1_th_13 sorry
          have A13: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f4 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
            using valued_1_def_5 sorry
          then have A14: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f4"
            using A3 A8 sorry
          then have "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f3 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f4"
            using A12 xboole_1_th_19 sorry
          then have A15: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f5"
            using valued_1_def_1 sorry
          obtain f1pf2p where 
            [ty]:"f1pf2p be ElementSUBSET-1M1-of REALNUMBERSK2" and f1pf2pDef:"f1pf2p = f1 .FUNCT-1K1 p -XCMPLX-0K6 f2 .FUNCT-1K1 p *XCMPLX-0K3 ?s"
            using xreal_0_def_1 sorry
          have A16: "[.RCOMP-1K1 p,g .] =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f3"
            using funcop_1_th_13 sorry
          then have " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds x inTARSKIR2 ([.RCOMP-1K1 p,g .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f3 implies f3 .FUNCT-1K1 x =XBOOLE-0R4 f1pf2p"
            using funcop_1_th_7 sorry
          then have A17: "f3  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be constantFUNCT-1V5"
            using partfun2_th_57 sorry
          then have A18: "f3  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be constantFUNCT-1V5"
            using partfun2_th_38 xxreal_1_th_25 sorry
          then have A19: "f3 is-differentiable-onFDIFF-1R2 Z"
            using A12 fdiff_1_th_22 sorry
          have A20: "p inHIDDENR3 [.RCOMP-1K1 p,g .]"
            using A1 xxreal_1_th_1 sorry
          then have "p inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f3 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f4"
            using A3 A16 A13 xboole_0_def_4 sorry
          then have A21: "p inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f5"
            using valued_1_def_1 sorry
          then have "p inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f5 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
            using A2 A20 xboole_0_def_4 sorry
          then have "p inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f"
            using valued_1_th_12 sorry
          then have A22: "?f .FUNCT-1K1 p =HIDDENR1 ?f5 .FUNCT-1K1 p -XCMPLX-0K6 f1 .FUNCT-1K1 p"
            using valued_1_th_13 sorry
          also have "... = (f3 .FUNCT-1K1 p +XCMPLX-0K2 ?f4 .FUNCT-1K1 p)-XCMPLX-0K6 f1 .FUNCT-1K1 p"
            using A21 valued_1_def_1 sorry
          also have "... = (f3 .FUNCT-1K1 p +XCMPLX-0K2 ?s *XCMPLX-0K3 f2 .FUNCT-1K1 p)-XCMPLX-0K6 f1 .FUNCT-1K1 p"
            using A3 A13 A20 valued_1_def_5 sorry
          also have "... = ((f1 .FUNCT-1K1 p -XCMPLX-0K6 ?s *XCMPLX-0K3 f2 .FUNCT-1K1 p)+XCMPLX-0K2 ?s *XCMPLX-0K3 f2 .FUNCT-1K1 p)-XCMPLX-0K6 f1 .FUNCT-1K1 p"
            using A20 funcop_1_th_7 sorry
          also have "... = 0NUMBERSK6"
             sorry
          finally have "?f .FUNCT-1K1 p =HIDDENR1 0NUMBERSK6"
             sorry
          have A23: "g inHIDDENR3 [.RCOMP-1K1 p,g .]"
            using A1 xxreal_1_th_1 sorry
          then have "g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f3 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f4"
            using A3 A16 A13 xboole_0_def_4 sorry
          then have A24: "g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f5"
            using valued_1_def_1 sorry
          then have "g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f5 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
            using A2 A23 xboole_0_def_4 sorry
          then have "g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f"
            using valued_1_th_12 sorry
          then have A25: "?f .FUNCT-1K1 g =HIDDENR1 ?f5 .FUNCT-1K1 g -XCMPLX-0K6 f1 .FUNCT-1K1 g"
            using valued_1_th_13 sorry
          also have "... = (f3 .FUNCT-1K1 g +XCMPLX-0K2 ?f4 .FUNCT-1K1 g)-XCMPLX-0K6 f1 .FUNCT-1K1 g"
            using A24 valued_1_def_1 sorry
          also have "... = (f3 .FUNCT-1K1 g +XCMPLX-0K2 ?s *XCMPLX-0K3 f2 .FUNCT-1K1 g)-XCMPLX-0K6 f1 .FUNCT-1K1 g"
            using A3 A13 A23 valued_1_def_5 sorry
          also have "... = ((f1 .FUNCT-1K1 p -XCMPLX-0K6 ?s *XCMPLX-0K3 f2 .FUNCT-1K1 p)+XCMPLX-0K2 ?s *XCMPLX-0K3 f2 .FUNCT-1K1 g)-XCMPLX-0K6 f1 .FUNCT-1K1 g"
            using A23 funcop_1_th_7 sorry
          also have "... = (-XCMPLX-0K4 f1 .FUNCT-1K1 g)+XCMPLX-0K2 (f1 .FUNCT-1K1 p -XCMPLX-0K6 ((-XCMPLX-0K4 (f1 .FUNCT-1K1 g -XCMPLX-0K6 f1 .FUNCT-1K1 p))/XCMPLX-0K7 (f2 .FUNCT-1K1 g -XCMPLX-0K6 f2 .FUNCT-1K1 p))*XCMPLX-0K3 (f2 .FUNCT-1K1 g -XCMPLX-0K6 f2 .FUNCT-1K1 p))"
             sorry
          also have "... = (-XCMPLX-0K4 f1 .FUNCT-1K1 g)+XCMPLX-0K2 (f1 .FUNCT-1K1 p -XCMPLX-0K6 (f1 .FUNCT-1K1 p -XCMPLX-0K6 f1 .FUNCT-1K1 g))"
            using A11 xcmplx_1_th_87 sorry
          also have "... = ?f .FUNCT-1K1 p"
            using A22 sorry
          finally have "?f .FUNCT-1K1 g =HIDDENR1 ?f .FUNCT-1K1 p"
             sorry
          have "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
            using A2 A8 sorry
          then have "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f5 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
            using A15 xboole_1_th_19 sorry
          then have A26: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f"
            using valued_1_th_12 sorry
          have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f4 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
            using valued_1_def_5 sorry
          then have A27: "[.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f3 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f4"
            using A3 A16 xboole_1_th_19 sorry
          then have "[.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f5"
            using valued_1_def_1 sorry
          then have A28: "[.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f5 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
            using A2 xboole_1_th_19 sorry
          have "?f4  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1"
            using A3 A6 fcont_1_th_20 sorry
          then have "?f5  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1"
            using A17 A27 fcont_1_th_18 sorry
          then have A29: "?f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1"
            using A4 A28 fcont_1_th_18 sorry
          have A30: "?f4 is-differentiable-onFDIFF-1R2 Z"
            using A7 A14 fdiff_1_th_20 sorry
          then have A31: "?f5 is-differentiable-onFDIFF-1R2 Z"
            using A19 A15 fdiff_1_th_18 sorry
          have "[.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f"
            using A28 valued_1_th_12 sorry
          then obtain x0 where
            [ty]:"x0 be RealXREAL-0M1" and 
            A32: "x0 inHIDDENR3 ].RCOMP-1K2 p,g .["and A33: "diffFDIFF-1K1(?f,x0) =HIDDENR1 0NUMBERSK6"
            using A1 A5 A29 A31 A26 A25 rolle_th_1 fdiff_1_th_19 sorry
          show " ex x0 be RealXREAL-0M1 st x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ & (f1 .FUNCT-1K1 g -XCMPLX-0K6 f1 .FUNCT-1K1 p)*XCMPLX-0K3 (diffFDIFF-1K1(f2,x0)) =XBOOLE-0R4 (f2 .FUNCT-1K1 g -XCMPLX-0K6 f2 .FUNCT-1K1 p)*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))"
          proof(rule bexI[of _ "x0"])
            have "?f is-differentiable-onFDIFF-1R2 Z"
              using A5 A31 A26 fdiff_1_th_19 sorry
            then have "diffFDIFF-1K1(?f,x0) =HIDDENR1 (?f `|FDIFF-1K2 Z).FUNCT-1K1 x0"
              using A32 fdiff_1_def_7 sorry
            also have "... = diffFDIFF-1K1(?f5,x0) -XCMPLX-0K6 diffFDIFF-1K1(f1,x0)"
              using A5 A31 A26 A32 fdiff_1_th_19 sorry
            also have "... = (?f5 `|FDIFF-1K2 Z).FUNCT-1K1 x0 -XCMPLX-0K6 diffFDIFF-1K1(f1,x0)"
              using A31 A32 fdiff_1_def_7 sorry
            also have "... = (diffFDIFF-1K1(f3,x0) +XCMPLX-0K2 diffFDIFF-1K1(?f4,x0))-XCMPLX-0K6 diffFDIFF-1K1(f1,x0)"
              using A19 A30 A15 A32 fdiff_1_th_18 sorry
            also have "... = ((f3 `|FDIFF-1K2 Z).FUNCT-1K1 x0 +XCMPLX-0K2 diffFDIFF-1K1(?f4,x0))-XCMPLX-0K6 diffFDIFF-1K1(f1,x0)"
              using A19 A32 fdiff_1_def_7 sorry
            also have "... = (0NUMBERSK6 +XCMPLX-0K2 diffFDIFF-1K1(?f4,x0))-XCMPLX-0K6 diffFDIFF-1K1(f1,x0)"
              using A18 A12 A32 fdiff_1_th_22 sorry
            also have "... = (?f4 `|FDIFF-1K2 Z).FUNCT-1K1 x0 -XCMPLX-0K6 diffFDIFF-1K1(f1,x0)"
              using A30 A32 fdiff_1_def_7 sorry
            also have "... = ?s *XCMPLX-0K3 (diffFDIFF-1K1(f2,x0)) -XCMPLX-0K6 diffFDIFF-1K1(f1,x0)"
              using A7 A14 A32 fdiff_1_th_20 sorry
            finally have "diffFDIFF-1K1(?f,x0) =HIDDENR1 ?s *XCMPLX-0K3 (diffFDIFF-1K1(f2,x0)) -XCMPLX-0K6 diffFDIFF-1K1(f1,x0)"
               sorry
            then have "(((diffFDIFF-1K1(f2,x0))*XCMPLX-0K3 (f1 .FUNCT-1K1 g -XCMPLX-0K6 f1 .FUNCT-1K1 p))/XCMPLX-0K7 (f2 .FUNCT-1K1 g -XCMPLX-0K6 f2 .FUNCT-1K1 p))*XCMPLX-0K3 (f2 .FUNCT-1K1 g -XCMPLX-0K6 f2 .FUNCT-1K1 p) =XBOOLE-0R4 (diffFDIFF-1K1(f1,x0))*XCMPLX-0K3 (f2 .FUNCT-1K1 g -XCMPLX-0K6 f2 .FUNCT-1K1 p)"
              using A33 xcmplx_1_th_15 sorry
            thus "x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ & (f1 .FUNCT-1K1 g -XCMPLX-0K6 f1 .FUNCT-1K1 p)*XCMPLX-0K3 (diffFDIFF-1K1(f2,x0)) =XBOOLE-0R4 (f2 .FUNCT-1K1 g -XCMPLX-0K6 f2 .FUNCT-1K1 p)*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))"
              using A11 A32 xcmplx_1_th_87 sorry
          qed "sorry"
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not ( for x0 be RealXREAL-0M1 holds  not (x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ & (f1 .FUNCT-1K1 g -XCMPLX-0K6 f1 .FUNCT-1K1 p)*XCMPLX-0K3 (diffFDIFF-1K1(f2,x0)) =XBOOLE-0R4 (f2 .FUNCT-1K1 g -XCMPLX-0K6 f2 .FUNCT-1K1 p)*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$N Cauchy Theorem*)
mtheorem rolle_th_6:
" for x be RealXREAL-0M1 holds  for t be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 t implies ( for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((((([.RCOMP-1K1 x,x +XCMPLX-0K2 t .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & [.RCOMP-1K1 x,x +XCMPLX-0K2 t .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2) & f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x,x +XCMPLX-0K2 t .]) be continuousFCONT-1V1) & f1 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 x,x +XCMPLX-0K2 t .[) & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x,x +XCMPLX-0K2 t .]) be continuousFCONT-1V1) & f2 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 x,x +XCMPLX-0K2 t .[) & ( for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 ].RCOMP-1K2 x,x +XCMPLX-0K2 t .[ implies diffFDIFF-1K1(f2,x1) <>HIDDENR2 0NUMBERSK6) implies ( ex s be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 s & s <XXREAL-0R3 \<one>\<^sub>M) & (f1 .FUNCT-1K1 (x +XCMPLX-0K2 t) -XCMPLX-0K6 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 (x +XCMPLX-0K2 t) -XCMPLX-0K6 f2 .FUNCT-1K1 x) =XBOOLE-0R4 (diffFDIFF-1K1(f1,x +XCMPLX-0K2 s *XCMPLX-0K3 t))/XCMPLX-0K7 (diffFDIFF-1K1(f2,x +XCMPLX-0K2 s *XCMPLX-0K3 t))))"
proof-
  have " for x be RealXREAL-0M1 holds  for t be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 t implies ( for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds [.RCOMP-1K1 x,x +XCMPLX-0K2 t .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & ([.RCOMP-1K1 x,x +XCMPLX-0K2 t .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 & ((f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x,x +XCMPLX-0K2 t .]) be continuousFCONT-1V1 & f1 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 x,x +XCMPLX-0K2 t .[) & ((f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x,x +XCMPLX-0K2 t .]) be continuousFCONT-1V1 & f2 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 x,x +XCMPLX-0K2 t .[) & ( for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 ].RCOMP-1K2 x,x +XCMPLX-0K2 t .[ implies diffFDIFF-1K1(f2,x1) <>HIDDENR2 0NUMBERSK6)))) implies ( ex s be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 s & (s <XXREAL-0R3 \<one>\<^sub>M & (f1 .FUNCT-1K1 (x +XCMPLX-0K2 t) -XCMPLX-0K6 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 (x +XCMPLX-0K2 t) -XCMPLX-0K6 f2 .FUNCT-1K1 x) =XBOOLE-0R4 (diffFDIFF-1K1(f1,x +XCMPLX-0K2 s *XCMPLX-0K3 t))/XCMPLX-0K7 (diffFDIFF-1K1(f2,x +XCMPLX-0K2 s *XCMPLX-0K3 t)))))"
  proof(rule ballI,rule ballI,rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix t assume [ty]: "t be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 t"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A2: "[.RCOMP-1K1 x,x +XCMPLX-0K2 t .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      and A3: "[.RCOMP-1K1 x,x +XCMPLX-0K2 t .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      and A4: "f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x,x +XCMPLX-0K2 t .]) be continuousFCONT-1V1 & f1 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 x,x +XCMPLX-0K2 t .["
      and A5: "f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x,x +XCMPLX-0K2 t .]) be continuousFCONT-1V1 & f2 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 x,x +XCMPLX-0K2 t .["
      and A6: " for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 ].RCOMP-1K2 x,x +XCMPLX-0K2 t .[ implies diffFDIFF-1K1(f2,x1) <>HIDDENR2 0NUMBERSK6"
    obtain x0 where
      [ty]:"x0 be RealXREAL-0M1" and 
      A7: "x0 inHIDDENR3 ].RCOMP-1K2 x,x +XCMPLX-0K2 t .["and A8: "(f1 .FUNCT-1K1 (x +XCMPLX-0K2 t) -XCMPLX-0K6 f1 .FUNCT-1K1 x)*XCMPLX-0K3 (diffFDIFF-1K1(f2,x0)) =XBOOLE-0R4 (f2 .FUNCT-1K1 (x +XCMPLX-0K2 t) -XCMPLX-0K6 f2 .FUNCT-1K1 x)*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))"
      using A1 A2 A3 A4 A5 rolle_th_5 xreal_1_th_29 sorry
    have "(diffFDIFF-1K1(f2,x0))*XCMPLX-0K3 ((f1 .FUNCT-1K1 (x +XCMPLX-0K2 t) -XCMPLX-0K6 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (diffFDIFF-1K1(f2,x0))) =XBOOLE-0R4 ((f2 .FUNCT-1K1 (x +XCMPLX-0K2 t) -XCMPLX-0K6 f2 .FUNCT-1K1 x)*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0)))/XCMPLX-0K7 (diffFDIFF-1K1(f2,x0))"
      using A8 xcmplx_1_th_74 sorry
    then have "(f1 .FUNCT-1K1 (x +XCMPLX-0K2 t) -XCMPLX-0K6 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 (x +XCMPLX-0K2 t) -XCMPLX-0K6 f2 .FUNCT-1K1 x) =XBOOLE-0R4 ((f2 .FUNCT-1K1 (x +XCMPLX-0K2 t) -XCMPLX-0K6 f2 .FUNCT-1K1 x)*XCMPLX-0K3 ((diffFDIFF-1K1(f1,x0))/XCMPLX-0K7 (diffFDIFF-1K1(f2,x0))))/XCMPLX-0K7 (f2 .FUNCT-1K1 (x +XCMPLX-0K2 t) -XCMPLX-0K6 f2 .FUNCT-1K1 x)"
      using A6 A7 xcmplx_1_th_87 sorry
    then have A9: "(f1 .FUNCT-1K1 (x +XCMPLX-0K2 t) -XCMPLX-0K6 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 (x +XCMPLX-0K2 t) -XCMPLX-0K6 f2 .FUNCT-1K1 x) =XBOOLE-0R4 (((diffFDIFF-1K1(f1,x0))/XCMPLX-0K7 (diffFDIFF-1K1(f2,x0)))/XCMPLX-0K7 (f2 .FUNCT-1K1 (x +XCMPLX-0K2 t) -XCMPLX-0K6 f2 .FUNCT-1K1 x))*XCMPLX-0K3 (f2 .FUNCT-1K1 (x +XCMPLX-0K2 t) -XCMPLX-0K6 f2 .FUNCT-1K1 x)"
       sorry
    obtain s where 
      [ty]:"s be setHIDDENM2" and sDef:"s = (x0 -XCMPLX-0K6 x)/XCMPLX-0K7 t"
       sorry
    show " ex s be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 s & (s <XXREAL-0R3 \<one>\<^sub>M & (f1 .FUNCT-1K1 (x +XCMPLX-0K2 t) -XCMPLX-0K6 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 (x +XCMPLX-0K2 t) -XCMPLX-0K6 f2 .FUNCT-1K1 x) =XBOOLE-0R4 (diffFDIFF-1K1(f1,x +XCMPLX-0K2 s *XCMPLX-0K3 t))/XCMPLX-0K7 (diffFDIFF-1K1(f2,x +XCMPLX-0K2 s *XCMPLX-0K3 t)))"
    proof(rule bexI[of _ "s"],rule conjMI,rule conjMI)
      have "x0 inHIDDENR3 {r where r be RealXREAL-0M1 : x <XXREAL-0R3 r & r <XXREAL-0R3 x +XCMPLX-0K2 t }"
        using A7 rcomp_1_def_2 sorry
      then have A10: " ex g be RealXREAL-0M1 st (g =HIDDENR1 x0 & x <XXREAL-0R3 g) & g <XXREAL-0R3 x +XCMPLX-0K2 t"
         sorry
      then have "0NUMBERSK6 <XXREAL-0R3 x0 -XCMPLX-0K6 x"
        using xreal_1_th_50 sorry
      then have "(0NUMBERSK6)/XCMPLX-0K7 t <XXREAL-0R3 (x0 -XCMPLX-0K6 x)/XCMPLX-0K7 t"
        using A1 xreal_1_th_74 sorry
      thus "0NUMBERSK6 <XXREAL-0R3 s"
         sorry
      have "x0 -XCMPLX-0K6 x <XXREAL-0R3 t"
        using A10 xreal_1_th_19 sorry
      then have "(x0 -XCMPLX-0K6 x)/XCMPLX-0K7 t <XXREAL-0R3 t /XCMPLX-0K7 t"
        using A1 xreal_1_th_74 sorry
      thus "s <XXREAL-0R3 \<one>\<^sub>M"
        using A1 xcmplx_1_th_60 sorry
      have A11: "s *XCMPLX-0K3 t +XCMPLX-0K2 x =XBOOLE-0R4 (x0 -XCMPLX-0K6 x)+XCMPLX-0K2 x"
        using A1 xcmplx_1_th_87 sorry
      have "0NUMBERSK6 <>HIDDENR2 f2 .FUNCT-1K1 (x +XCMPLX-0K2 t) -XCMPLX-0K6 f2 .FUNCT-1K1 x"
        using A1 A3 A5 A6 rolle_th_1 xreal_1_th_29 sorry
      thus "(f1 .FUNCT-1K1 (x +XCMPLX-0K2 t) -XCMPLX-0K6 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 (x +XCMPLX-0K2 t) -XCMPLX-0K6 f2 .FUNCT-1K1 x) =XBOOLE-0R4 (diffFDIFF-1K1(f1,x +XCMPLX-0K2 s *XCMPLX-0K3 t))/XCMPLX-0K7 (diffFDIFF-1K1(f2,x +XCMPLX-0K2 s *XCMPLX-0K3 t))"
        using A9 A11 xcmplx_1_th_87 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rolle_th_7:
" for p be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 p,g .[ implies diffFDIFF-1K1(f,x) =HIDDENR1 0NUMBERSK6) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be constantFUNCT-1V5"
proof-
  have " for p be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[ & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 p,g .[ implies diffFDIFF-1K1(f,x) =HIDDENR1 0NUMBERSK6)) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be constantFUNCT-1V5"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A2: "f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .["
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 p,g .[ implies diffFDIFF-1K1(f,x) =HIDDENR1 0NUMBERSK6"
    have " for x1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for x2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds x1 inTARSKIR2 (].RCOMP-1K2 p,g .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x2 inTARSKIR2 (].RCOMP-1K2 p,g .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2"
    proof(rule ballI,rule ballI,rule impI)
      fix x1 assume [ty]: "x1 be ElementSUBSET-1M1-of REALNUMBERSK2"
      fix x2 assume [ty]: "x2 be ElementSUBSET-1M1-of REALNUMBERSK2"
      assume "x1 inTARSKIR2 (].RCOMP-1K2 p,g .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x2 inTARSKIR2 (].RCOMP-1K2 p,g .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      then have A4: "x1 inTARSKIR2 ].RCOMP-1K2 p,g .[ & x2 inTARSKIR2 ].RCOMP-1K2 p,g .["
        using xboole_0_def_4 sorry
      have "f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2"
      proof-
        show "f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2"
        proof-
          have cases: "x1 =XBOOLE-0R4 x2 or  not x1 =XBOOLE-0R4 x2"
             sorry
          have case1: "x1 =XBOOLE-0R4 x2 implies f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2"
          proof(rule impI)
            assume "x1 =XBOOLE-0R4 x2"
            thus "f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2"
               sorry
          qed
          have case2: " not x1 =XBOOLE-0R4 x2 implies f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2"
          proof(rule impI)
            assume A5: " not x1 =XBOOLE-0R4 x2"
            have "f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2"
            proof-
              show "f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2"
              proof-
                have cases: "x1 <XXREAL-0R3 x2 or x2 <XXREAL-0R3 x1"
                  using A5 xxreal_0_th_1 sorry
                have case1: "x1 <XXREAL-0R3 x2 implies f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2"
                proof(rule impI)
                  assume A6: "x1 <XXREAL-0R3 x2"
                  then have "0NUMBERSK6 <>HIDDENR2 x2 -REAL-1K5 x1"
                     sorry
                  then have A7: "0NUMBERSK6 <>HIDDENR2 (x2 -REAL-1K5 x1)\<inverse>REAL-1K2"
                    using xcmplx_1_th_202 sorry
                  obtain Z where 
                    [ty]:"Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2" and ZDef:"Z = ].RCOMP-1K2 x1,x2 .["
                     sorry
                  have A8: "[.RCOMP-1K1 x1,x2 .] c=TARSKIR1 ].RCOMP-1K2 p,g .["
                    using A4 xxreal_2_def_12 sorry
                  have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be continuousFCONT-1V1"
                    using A2 fdiff_1_th_25 sorry
                  then have A9: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x1,x2 .]) be continuousFCONT-1V1"
                    using A8 fcont_1_th_16 sorry
                  have A10: "Z c=TARSKIR1 [.RCOMP-1K1 x1,x2 .]"
                    using xxreal_1_th_25 sorry
                  then have "f is-differentiable-onFDIFF-1R2 Z"
                    using A2 A8 fdiff_1_th_26 xboole_1_th_1 sorry
                  then have A11: " ex x0 be RealXREAL-0M1 st x0 inHIDDENR3 ].RCOMP-1K2 x1,x2 .[ & diffFDIFF-1K1(f,x0) =HIDDENR1 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x1)/XCMPLX-0K7 (x2 -REAL-1K5 x1)"
                    using A1 A6 A8 A9 rolle_th_3 xboole_1_th_1 sorry
                  have "Z c=TARSKIR1 ].RCOMP-1K2 p,g .["
                    using A8 A10 sorry
                  then have "0NUMBERSK6 =XBOOLE-0R4 f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x1"
                    using A3 A7 A11 xcmplx_1_th_6 sorry
                  thus "f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2"
                     sorry
                qed
                have case2: "x2 <XXREAL-0R3 x1 implies f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2"
                proof(rule impI)
                  assume A12: "x2 <XXREAL-0R3 x1"
                  then have "0NUMBERSK6 <>HIDDENR2 x1 -REAL-1K5 x2"
                     sorry
                  then have A13: "0NUMBERSK6 <>HIDDENR2 (x1 -REAL-1K5 x2)\<inverse>REAL-1K2"
                    using xcmplx_1_th_202 sorry
                  obtain Z where 
                    [ty]:"Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2" and ZDef:"Z = ].RCOMP-1K2 x2,x1 .["
                     sorry
                  have A14: "[.RCOMP-1K1 x2,x1 .] c=TARSKIR1 ].RCOMP-1K2 p,g .["
                    using A4 xxreal_2_def_12 sorry
                  have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be continuousFCONT-1V1"
                    using A2 fdiff_1_th_25 sorry
                  then have A15: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x2,x1 .]) be continuousFCONT-1V1"
                    using A14 fcont_1_th_16 sorry
                  have A16: "Z c=TARSKIR1 [.RCOMP-1K1 x2,x1 .]"
                    using xxreal_1_th_25 sorry
                  then have "f is-differentiable-onFDIFF-1R2 Z"
                    using A2 A14 fdiff_1_th_26 xboole_1_th_1 sorry
                  then have A17: " ex x0 be RealXREAL-0M1 st x0 inHIDDENR3 ].RCOMP-1K2 x2,x1 .[ & diffFDIFF-1K1(f,x0) =HIDDENR1 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2)/XCMPLX-0K7 (x1 -REAL-1K5 x2)"
                    using A1 A12 A14 A15 rolle_th_3 xboole_1_th_1 sorry
                  have "Z c=TARSKIR1 ].RCOMP-1K2 p,g .["
                    using A14 A16 sorry
                  then have "0NUMBERSK6 =XBOOLE-0R4 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2"
                    using A3 A13 A17 xcmplx_1_th_6 sorry
                  thus "f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2"
                     sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2"
         sorry
    qed "sorry"
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be constantFUNCT-1V5"
      using partfun2_th_58 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rolle_th_8:
" for p be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[ & f2 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 p,g .[ implies diffFDIFF-1K1(f1,x) =HIDDENR1 diffFDIFF-1K1(f2,x)) implies (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be constantFUNCT-1V5 & ( ex r be RealXREAL-0M1 st  for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 p,g .[ implies f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x +XCMPLX-0K2 r)"
proof-
  have " for p be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[ & f2 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 p,g .[ implies diffFDIFF-1K1(f1,x) =HIDDENR1 diffFDIFF-1K1(f2,x)) implies (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be constantFUNCT-1V5 & ( ex tVar7 be RealXREAL-0M1 st  for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 p,g .[ implies f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x +XCMPLX-0K2 tVar7)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[ & f2 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .["
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 p,g .[ implies diffFDIFF-1K1(f1,x) =HIDDENR1 diffFDIFF-1K1(f2,x)"
    obtain Z where 
      [ty]:"Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2" and ZDef:"Z = ].RCOMP-1K2 p,g .["
       sorry
    have "].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & ].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using A1 fdiff_1_def_6 sorry
    then have "].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using xboole_1_th_19 sorry
    then have A3: "].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using valued_1_th_12 sorry
    then have A4: "f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_19 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 p,g .[ implies diffFDIFF-1K1(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x) =HIDDENR1 0NUMBERSK6"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A5: "x inHIDDENR3 ].RCOMP-1K2 p,g .["
      then have "diffFDIFF-1K1(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x) =HIDDENR1 ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A4 fdiff_1_def_7 sorry
      also have "... = diffFDIFF-1K1(f1,x) -XCMPLX-0K6 diffFDIFF-1K1(f2,x)"
        using A1 A3 A5 fdiff_1_th_19 sorry
      also have "... = diffFDIFF-1K1(f1,x) -XCMPLX-0K6 diffFDIFF-1K1(f1,x)"
        using A2 A5 sorry
      also have "... = 0NUMBERSK6"
         sorry
      finally show "diffFDIFF-1K1(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x) =HIDDENR1 0NUMBERSK6"
         sorry
    qed "sorry"
    thus "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be constantFUNCT-1V5"
      using A1 A3 rolle_th_7 fdiff_1_th_19 sorry
    then obtain r where
      [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2" and 
      A6: " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds x inTARSKIR2 (].RCOMP-1K2 p,g .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =XBOOLE-0R4 r"
      using partfun2_th_57 sorry
    show " ex tVar7 be RealXREAL-0M1 st  for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 p,g .[ implies f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x +XCMPLX-0K2 tVar7"
    proof(rule bexI[of _ "r"],rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A7: "x inHIDDENR3 ].RCOMP-1K2 p,g .["
      then have "x inHIDDENR3 (].RCOMP-1K2 p,g .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A3 xboole_1_th_28 sorry
      then have "r =HIDDENR1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x"
        using A6 sorry
      also have "... = f1 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x"
        using A3 A7 valued_1_th_13 sorry
      finally have "r =HIDDENR1 f1 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x"
         sorry
      thus "f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x +XCMPLX-0K2 r"
         sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rolle_th_9:
" for p be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 p,g .[ implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x)) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be increasingVALUED-0V9"
proof-
  have " for p be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[ & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 p,g .[ implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x))) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be increasingVALUED-0V9"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A2: "f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .["
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 p,g .[ implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x)"
    have " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds (x1 inHIDDENR3 (].RCOMP-1K2 p,g .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x2 inHIDDENR3 (].RCOMP-1K2 p,g .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & x1 <XXREAL-0R3 x2 implies f .FUNCT-1K1 x1 <XXREAL-0R3 f .FUNCT-1K1 x2"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix x1 assume [ty]: "x1 be RealXREAL-0M1"
      fix x2 assume [ty]: "x2 be RealXREAL-0M1"
      assume A4: "x1 inHIDDENR3 (].RCOMP-1K2 p,g .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x2 inHIDDENR3 (].RCOMP-1K2 p,g .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        and A5: "x1 <XXREAL-0R3 x2"
      have A6: "0NUMBERSK6 <XXREAL-0R3 x2 -XCMPLX-0K6 x1"
        using A5 xreal_1_th_50 sorry
      obtain Z where 
        [ty]:"Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2" and ZDef:"Z = ].RCOMP-1K2 x1,x2 .["
         sorry
      have "x1 inHIDDENR3 ].RCOMP-1K2 p,g .[ & x2 inHIDDENR3 ].RCOMP-1K2 p,g .["
        using A4 xboole_0_def_4 sorry
      then have A7: "[.RCOMP-1K1 x1,x2 .] c=TARSKIR1 ].RCOMP-1K2 p,g .["
        using xxreal_2_def_12 sorry
      have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be continuousFCONT-1V1"
        using A2 fdiff_1_th_25 sorry
      then have A8: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x1,x2 .]) be continuousFCONT-1V1"
        using A7 fcont_1_th_16 sorry
      have A9: "Z c=TARSKIR1 [.RCOMP-1K1 x1,x2 .]"
        using xxreal_1_th_25 sorry
      then have "f is-differentiable-onFDIFF-1R2 Z"
        using A2 A7 fdiff_1_th_26 xboole_1_th_1 sorry
      then have A10: " ex x0 be RealXREAL-0M1 st x0 inHIDDENR3 ].RCOMP-1K2 x1,x2 .[ & diffFDIFF-1K1(f,x0) =HIDDENR1 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x1)/XCMPLX-0K7 (x2 -XCMPLX-0K6 x1)"
        using A1 A5 A7 A8 rolle_th_3 xboole_1_th_1 sorry
      have "Z c=TARSKIR1 ].RCOMP-1K2 p,g .["
        using A7 A9 sorry
      then have "0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x1"
        using A3 A6 A10 sorry
      then have "f .FUNCT-1K1 x1 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 x2"
        using xreal_1_th_20 sorry
      thus "f .FUNCT-1K1 x1 <XXREAL-0R3 f .FUNCT-1K1 x2"
         sorry
    qed "sorry"
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be increasingVALUED-0V9"
      using rfunct_2_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rolle_th_10:
" for p be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 p,g .[ implies diffFDIFF-1K1(f,x) <XXREAL-0R3 0NUMBERSK6) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be decreasingVALUED-0V10"
proof-
  have " for p be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[ & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 p,g .[ implies diffFDIFF-1K1(f,x) <XXREAL-0R3 0NUMBERSK6)) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be decreasingVALUED-0V10"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A2: "f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .["
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 p,g .[ implies diffFDIFF-1K1(f,x) <XXREAL-0R3 0NUMBERSK6"
    have " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds (x1 inHIDDENR3 (].RCOMP-1K2 p,g .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x2 inHIDDENR3 (].RCOMP-1K2 p,g .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & x1 <XXREAL-0R3 x2 implies f .FUNCT-1K1 x2 <XXREAL-0R3 f .FUNCT-1K1 x1"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix x1 assume [ty]: "x1 be RealXREAL-0M1"
      fix x2 assume [ty]: "x2 be RealXREAL-0M1"
      assume A4: "x1 inHIDDENR3 (].RCOMP-1K2 p,g .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x2 inHIDDENR3 (].RCOMP-1K2 p,g .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        and A5: "x1 <XXREAL-0R3 x2"
      have A6: "0NUMBERSK6 <XXREAL-0R3 x2 -XCMPLX-0K6 x1"
        using A5 xreal_1_th_50 sorry
      obtain Z where 
        [ty]:"Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2" and ZDef:"Z = ].RCOMP-1K2 x1,x2 .["
         sorry
      have "x1 inHIDDENR3 ].RCOMP-1K2 p,g .[ & x2 inHIDDENR3 ].RCOMP-1K2 p,g .["
        using A4 xboole_0_def_4 sorry
      then have A7: "[.RCOMP-1K1 x1,x2 .] c=TARSKIR1 ].RCOMP-1K2 p,g .["
        using xxreal_2_def_12 sorry
      have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be continuousFCONT-1V1"
        using A2 fdiff_1_th_25 sorry
      then have A8: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x1,x2 .]) be continuousFCONT-1V1"
        using A7 fcont_1_th_16 sorry
      have A9: "Z c=TARSKIR1 [.RCOMP-1K1 x1,x2 .]"
        using xxreal_1_th_25 sorry
      then have "f is-differentiable-onFDIFF-1R2 Z"
        using A2 A7 fdiff_1_th_26 xboole_1_th_1 sorry
      then have A10: " ex x0 be RealXREAL-0M1 st x0 inHIDDENR3 ].RCOMP-1K2 x1,x2 .[ & diffFDIFF-1K1(f,x0) =HIDDENR1 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x1)/XCMPLX-0K7 (x2 -XCMPLX-0K6 x1)"
        using A1 A5 A7 A8 rolle_th_3 xboole_1_th_1 sorry
      have "Z c=TARSKIR1 ].RCOMP-1K2 p,g .["
        using A7 A9 sorry
      then have "f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x1 <XXREAL-0R3 0NUMBERSK6"
        using A3 A6 A10 sorry
      then have "f .FUNCT-1K1 x2 <XXREAL-0R3 f .FUNCT-1K1 x1 +XCMPLX-0K2 0NUMBERSK6"
        using xreal_1_th_19 sorry
      thus "f .FUNCT-1K1 x2 <XXREAL-0R3 f .FUNCT-1K1 x1"
         sorry
    qed "sorry"
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be decreasingVALUED-0V10"
      using rfunct_2_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rolle_th_11:
" for p be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 p,g .[ implies 0NUMBERSK6 <=XXREAL-0R1 diffFDIFF-1K1(f,x)) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be non-decreasingVALUED-0V11"
proof-
  have " for p be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[ & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 p,g .[ implies 0NUMBERSK6 <=XXREAL-0R1 diffFDIFF-1K1(f,x))) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be non-decreasingVALUED-0V11"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A2: "f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .["
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 p,g .[ implies 0NUMBERSK6 <=XXREAL-0R1 diffFDIFF-1K1(f,x)"
    have " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds (x1 inHIDDENR3 (].RCOMP-1K2 p,g .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x2 inHIDDENR3 (].RCOMP-1K2 p,g .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & x1 <XXREAL-0R3 x2 implies f .FUNCT-1K1 x1 <=XXREAL-0R1 f .FUNCT-1K1 x2"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix x1 assume [ty]: "x1 be RealXREAL-0M1"
      fix x2 assume [ty]: "x2 be RealXREAL-0M1"
      assume A4: "x1 inHIDDENR3 (].RCOMP-1K2 p,g .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x2 inHIDDENR3 (].RCOMP-1K2 p,g .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        and A5: "x1 <XXREAL-0R3 x2"
      have A6: "0NUMBERSK6 <>HIDDENR2 x2 -XCMPLX-0K6 x1"
        using A5 sorry
      obtain Z where 
        [ty]:"Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2" and ZDef:"Z = ].RCOMP-1K2 x1,x2 .["
         sorry
      have "x1 inHIDDENR3 ].RCOMP-1K2 p,g .[ & x2 inHIDDENR3 ].RCOMP-1K2 p,g .["
        using A4 xboole_0_def_4 sorry
      then have A7: "[.RCOMP-1K1 x1,x2 .] c=TARSKIR1 ].RCOMP-1K2 p,g .["
        using xxreal_2_def_12 sorry
      have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be continuousFCONT-1V1"
        using A2 fdiff_1_th_25 sorry
      then have A8: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x1,x2 .]) be continuousFCONT-1V1"
        using A7 fcont_1_th_16 sorry
      have A9: "Z c=TARSKIR1 [.RCOMP-1K1 x1,x2 .]"
        using xxreal_1_th_25 sorry
      then have A10: "Z c=TARSKIR1 ].RCOMP-1K2 p,g .["
        using A7 sorry
      have "f is-differentiable-onFDIFF-1R2 Z"
        using A2 A7 A9 fdiff_1_th_26 xboole_1_th_1 sorry
      then have " ex x0 be RealXREAL-0M1 st x0 inHIDDENR3 ].RCOMP-1K2 x1,x2 .[ & diffFDIFF-1K1(f,x0) =HIDDENR1 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x1)/XCMPLX-0K7 (x2 -XCMPLX-0K6 x1)"
        using A1 A5 A7 A8 rolle_th_3 xboole_1_th_1 sorry
      then have A11: "0NUMBERSK6 <=XXREAL-0R1 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x1)/XCMPLX-0K7 (x2 -XCMPLX-0K6 x1)"
        using A3 A10 sorry
      have "0NUMBERSK6 <=XXREAL-0R1 x2 -XCMPLX-0K6 x1"
        using A5 xreal_1_th_50 sorry
      then have "(0NUMBERSK6)*XCMPLX-0K3 (x2 -XCMPLX-0K6 x1) <=XXREAL-0R1 ((f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x1)/XCMPLX-0K7 (x2 -XCMPLX-0K6 x1))*XCMPLX-0K3 (x2 -XCMPLX-0K6 x1)"
        using A11 sorry
      then have "0NUMBERSK6 <=XXREAL-0R1 f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x1"
        using A6 xcmplx_1_th_87 sorry
      then have "f .FUNCT-1K1 x1 +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 f .FUNCT-1K1 x2"
        using xreal_1_th_19 sorry
      thus "f .FUNCT-1K1 x1 <=XXREAL-0R1 f .FUNCT-1K1 x2"
         sorry
    qed "sorry"
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be non-decreasingVALUED-0V11"
      using rfunct_2_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rolle_th_12:
" for p be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 p,g .[ implies diffFDIFF-1K1(f,x) <=XXREAL-0R1 0NUMBERSK6) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be non-increasingVALUED-0V12"
proof-
  have " for p be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[ & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 p,g .[ implies diffFDIFF-1K1(f,x) <=XXREAL-0R1 0NUMBERSK6)) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be non-increasingVALUED-0V12"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A2: "f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .["
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 p,g .[ implies diffFDIFF-1K1(f,x) <=XXREAL-0R1 0NUMBERSK6"
    have " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds (x1 inHIDDENR3 (].RCOMP-1K2 p,g .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x2 inHIDDENR3 (].RCOMP-1K2 p,g .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & x1 <XXREAL-0R3 x2 implies f .FUNCT-1K1 x2 <=XXREAL-0R1 f .FUNCT-1K1 x1"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix x1 assume [ty]: "x1 be RealXREAL-0M1"
      fix x2 assume [ty]: "x2 be RealXREAL-0M1"
      assume A4: "x1 inHIDDENR3 (].RCOMP-1K2 p,g .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x2 inHIDDENR3 (].RCOMP-1K2 p,g .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        and A5: "x1 <XXREAL-0R3 x2"
      have A6: "0NUMBERSK6 <=XXREAL-0R1 x2 -XCMPLX-0K6 x1"
        using A5 xreal_1_th_50 sorry
      obtain Z where 
        [ty]:"Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2" and ZDef:"Z = ].RCOMP-1K2 x1,x2 .["
         sorry
      have "x1 inHIDDENR3 ].RCOMP-1K2 p,g .[ & x2 inHIDDENR3 ].RCOMP-1K2 p,g .["
        using A4 xboole_0_def_4 sorry
      then have A7: "[.RCOMP-1K1 x1,x2 .] c=TARSKIR1 ].RCOMP-1K2 p,g .["
        using xxreal_2_def_12 sorry
      have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be continuousFCONT-1V1"
        using A2 fdiff_1_th_25 sorry
      then have A8: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x1,x2 .]) be continuousFCONT-1V1"
        using A7 fcont_1_th_16 sorry
      have A9: "Z c=TARSKIR1 [.RCOMP-1K1 x1,x2 .]"
        using xxreal_1_th_25 sorry
      then have "f is-differentiable-onFDIFF-1R2 Z"
        using A2 A7 fdiff_1_th_26 xboole_1_th_1 sorry
      then have A10: " ex x0 be RealXREAL-0M1 st x0 inHIDDENR3 ].RCOMP-1K2 x1,x2 .[ & diffFDIFF-1K1(f,x0) =HIDDENR1 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x1)/XCMPLX-0K7 (x2 -XCMPLX-0K6 x1)"
        using A1 A5 A7 A8 rolle_th_3 xboole_1_th_1 sorry
      have A11: "0NUMBERSK6 <>HIDDENR2 x2 -XCMPLX-0K6 x1"
        using A5 sorry
      have "Z c=TARSKIR1 ].RCOMP-1K2 p,g .["
        using A7 A9 sorry
      then have "((f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x1)/XCMPLX-0K7 (x2 -XCMPLX-0K6 x1))*XCMPLX-0K3 (x2 -XCMPLX-0K6 x1) <=XXREAL-0R1 (0NUMBERSK6)*XCMPLX-0K3 (x2 -XCMPLX-0K6 x1)"
        using A3 A6 A10 xreal_1_th_64 sorry
      then have "f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x1 <=XXREAL-0R1 0NUMBERSK6"
        using A11 xcmplx_1_th_87 sorry
      then have "f .FUNCT-1K1 x2 <=XXREAL-0R1 f .FUNCT-1K1 x1 +XCMPLX-0K2 0NUMBERSK6"
        using xreal_1_th_20 sorry
      thus "f .FUNCT-1K1 x2 <=XXREAL-0R1 f .FUNCT-1K1 x1"
         sorry
    qed "sorry"
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be non-increasingVALUED-0V12"
      using rfunct_2_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
