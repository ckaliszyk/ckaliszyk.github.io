theory funct_3
  imports binop_1 domain_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve p, q, x, x1, x2, y, y1, y2, z, z1, z2 for "setHIDDENM2"
reserve A, B, V, X, X1, X2, Y, Y1, Y2, Z for "setHIDDENM2"
reserve C, C1, C2, D, D1, D2 for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
mtheorem funct_3_th_1:
" for A be setHIDDENM2 holds  for Y be setHIDDENM2 holds A c=TARSKIR1 Y implies idRELAT-1K7 A =FUNCT-1R1 idRELAT-1K7 Y  |RELAT-1K8 A"
proof-
  have " for A be setHIDDENM2 holds  for Y be setHIDDENM2 holds A c=TARSKIR1 Y implies idRELAT-1K7 A =HIDDENR1 idRELAT-1K7 Y  |RELAT-1K8 A"
  proof(rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume "A c=TARSKIR1 Y"
    then have "idRELAT-1K7 A =HIDDENR1 idRELAT-1K7 (Y /\\XBOOLE-0K3 A)"
      using xboole_1_th_28 sorry
    also have "... = idRELAT-1K7 Y *FUNCT-1K3 idRELAT-1K7 A"
      using funct_1_th_22 sorry
    also have "... = idRELAT-1K7 Y  |RELAT-1K8 A"
      using relat_1_th_65 sorry
    finally show "idRELAT-1K7 A =HIDDENR1 idRELAT-1K7 Y  |RELAT-1K8 A"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_2:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds X c=TARSKIR1 domRELAT-1K1 (g *FUNCT-1K3 f) implies f .:FUNCT-1K5 X c=TARSKIR1 domRELAT-1K1 g"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds X c=TARSKIR1 domRELAT-1K1 (g *FUNCT-1K3 f) implies f .:FUNCT-1K5 X c=TARSKIR1 domRELAT-1K1 g"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "X c=TARSKIR1 domRELAT-1K1 (g *FUNCT-1K3 f)"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 f .:FUNCT-1K5 X implies y inHIDDENR3 domRELAT-1K1 g"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 f .:FUNCT-1K5 X"
      then have " ex x be objectHIDDENM1 st (x inHIDDENR3 domRELAT-1K1 f & x inHIDDENR3 X) & y =HIDDENR1 f .FUNCT-1K1 x"
        using funct_1_def_6 sorry
      thus "y inHIDDENR3 domRELAT-1K1 g"
        using A1 funct_1_th_11 sorry
    qed "sorry"
    thus "f .:FUNCT-1K5 X c=TARSKIR1 domRELAT-1K1 g"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_3:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds X c=TARSKIR1 domRELAT-1K1 f & f .:FUNCT-1K5 X c=TARSKIR1 domRELAT-1K1 g implies X c=TARSKIR1 domRELAT-1K1 (g *FUNCT-1K3 f)"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds X c=TARSKIR1 domRELAT-1K1 f & f .:FUNCT-1K5 X c=TARSKIR1 domRELAT-1K1 g implies X c=TARSKIR1 domRELAT-1K1 (g *FUNCT-1K3 f)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "X c=TARSKIR1 domRELAT-1K1 f"
      and A2: "f .:FUNCT-1K5 X c=TARSKIR1 domRELAT-1K1 g"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A3: "x inHIDDENR3 X"
      then have "f .FUNCT-1K1 x inTARSKIR2 f .:FUNCT-1K5 X"
        using A1 funct_1_def_6 sorry
      thus "x inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f)"
        using A1 A2 A3 funct_1_th_11 sorry
    qed "sorry"
    thus "X c=TARSKIR1 domRELAT-1K1 (g *FUNCT-1K3 f)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_4:
" for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds Y c=TARSKIR1 rngFUNCT-1K2 (g *FUNCT-1K3 f) & g be one-to-oneFUNCT-1V2 implies g \<inverse>FUNCT-1K6 Y c=TARSKIR1 rngFUNCT-1K2 f"
proof-
  have " for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds Y c=TARSKIR1 rngFUNCT-1K2 (g *FUNCT-1K3 f) & g be one-to-oneFUNCT-1V2 implies g \<inverse>FUNCT-1K6 Y c=TARSKIR1 rngFUNCT-1K2 f"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "Y c=TARSKIR1 rngFUNCT-1K2 (g *FUNCT-1K3 f)"
      and A2: "g be one-to-oneFUNCT-1V2"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 g \<inverse>FUNCT-1K6 Y implies y inHIDDENR3 rngFUNCT-1K2 f"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A3: "y inHIDDENR3 g \<inverse>FUNCT-1K6 Y"
      then have A4: "y inHIDDENR3 domRELAT-1K1 g"
        using funct_1_def_7 sorry
      have "g .FUNCT-1K1 y inTARSKIR2 Y"
        using A3 funct_1_def_7 sorry
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A5: "x inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f)"and A6: "g .FUNCT-1K1 y =XBOOLE-0R4 (g *FUNCT-1K3 f).FUNCT-1K1 x"
        using A1 funct_1_def_3 sorry
      have A7: "x inHIDDENR3 domRELAT-1K1 f"
        using A5 funct_1_th_11 sorry
      have "g .FUNCT-1K1 y =XBOOLE-0R4 g .FUNCT-1K1 (f .FUNCT-1K1 x) & f .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 g"
        using A5 A6 funct_1_th_11 funct_1_th_12 sorry
      then have "y =HIDDENR1 f .FUNCT-1K1 x"
        using A2 A4 sorry
      thus "y inHIDDENR3 rngFUNCT-1K2 f"
        using A7 funct_1_def_3 sorry
    qed "sorry"
    thus "g \<inverse>FUNCT-1K6 Y c=TARSKIR1 rngFUNCT-1K2 f"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_5:
" for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds Y c=TARSKIR1 rngFUNCT-1K2 g & g \<inverse>FUNCT-1K6 Y c=TARSKIR1 rngFUNCT-1K2 f implies Y c=TARSKIR1 rngFUNCT-1K2 (g *FUNCT-1K3 f)"
proof-
  have " for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds Y c=TARSKIR1 rngFUNCT-1K2 g & g \<inverse>FUNCT-1K6 Y c=TARSKIR1 rngFUNCT-1K2 f implies Y c=TARSKIR1 rngFUNCT-1K2 (g *FUNCT-1K3 f)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "Y c=TARSKIR1 rngFUNCT-1K2 g"
      and A2: "g \<inverse>FUNCT-1K6 Y c=TARSKIR1 rngFUNCT-1K2 f"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Y implies y inHIDDENR3 rngFUNCT-1K2 (g *FUNCT-1K3 f)"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A3: "y inHIDDENR3 Y"
      then obtain z where
        [ty]:"z be objectHIDDENM1" and 
        A4: "z inHIDDENR3 domRELAT-1K1 g & y =HIDDENR1 g .FUNCT-1K1 z"
        using A1 funct_1_def_3 sorry
      have "z inHIDDENR3 g \<inverse>FUNCT-1K6 Y"
        using A3 A4 funct_1_def_7 sorry
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A5: "x inHIDDENR3 domRELAT-1K1 f & z =HIDDENR1 f .FUNCT-1K1 x"
        using A2 funct_1_def_3 sorry
      have "x inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f) & (g *FUNCT-1K3 f).FUNCT-1K1 x =HIDDENR1 y"
        using A4 A5 funct_1_th_11 funct_1_th_13 sorry
      thus "y inHIDDENR3 rngFUNCT-1K2 (g *FUNCT-1K3 f)"
        using funct_1_def_3 sorry
    qed "sorry"
    thus "Y c=TARSKIR1 rngFUNCT-1K2 (g *FUNCT-1K3 f)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem funct_3_sch_1:
  fixes Af0 Bf0 Pp3 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "Bf0 be setHIDDENM2" and
   A1: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z1 be objectHIDDENM1 holds  for z2 be objectHIDDENM1 holds ((x inHIDDENR3 Af0 & y inHIDDENR3 Bf0) & Pp3(x,y,z1)) & Pp3(x,y,z2) implies z1 =HIDDENR1 z2" and
   A2: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 Af0 & y inHIDDENR3 Bf0 implies ( ex z be objectHIDDENM1 st Pp3(x,y,z))"
  shows " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 Af0,Bf0 :] & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 Af0 & y inHIDDENR3 Bf0 implies Pp3(x,y,f .BINOP-1K1(x,y)))"
  proof-
    have " ex tVar2 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar2 =XBOOLE-0R4 [:ZFMISC-1K2 Af0,Bf0 :] & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 Af0 & y inHIDDENR3 Bf0 implies Pp3(x,y,tVar2 .BINOP-1K1(x,y)))"
    proof-
      let ?R = "\<lambda>Lamb1. \<lambda>Lamb2.  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds Lamb1 =HIDDENR1 [TARSKIK4 x,y ] implies Pp3(x,y,Lamb2)"
      let ?D = "[:ZFMISC-1K2 Af0,Bf0 :]"
      have A3: " for p be objectHIDDENM1 holds p inHIDDENR3 ?D implies ( ex z be objectHIDDENM1 st ?R(p,z))"
      proof-
        have " for p be objectHIDDENM1 holds p inHIDDENR3 [:ZFMISC-1K2 Af0,Bf0 :] implies ( ex tVar1 be objectHIDDENM1 st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds p =HIDDENR1 [TARSKIK4 x,y ] implies Pp3(x,y,tVar1))"
        proof(rule ballI,rule impI)
          fix p assume [ty]: "p be objectHIDDENM1"
          assume "p inHIDDENR3 ?D"
          then obtain x1 y1 where
            [ty]:"x1 be objectHIDDENM1" "y1 be objectHIDDENM1" and 
            A4: "x1 inHIDDENR3 Af0 & y1 inHIDDENR3 Bf0"and A5: "p =HIDDENR1 [TARSKIK4 x1,y1 ]"
            using zfmisc_1_def_2 sorry
          obtain z where
            [ty]:"z be objectHIDDENM1" and 
            A6: "Pp3(x1,y1,z)"
            using A2 A4 sorry
          show " ex tVar1 be objectHIDDENM1 st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds p =HIDDENR1 [TARSKIK4 x,y ] implies Pp3(x,y,tVar1)"
          proof(rule bexI[of _ "z"],rule ballI,rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            fix y assume [ty]: "y be objectHIDDENM1"
            assume A7: "p =HIDDENR1 [TARSKIK4 x,y ]"
            then have "x =HIDDENR1 x1"
              using A5 xtuple_0_th_1 sorry
            thus "Pp3(x,y,z)"
              using A5 A6 A7 xtuple_0_th_1 sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have A8: " for p be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds (p inHIDDENR3 ?D & ?R(p,y1)) & ?R(p,y2) implies y1 =HIDDENR1 y2"
      proof-
        have " for p be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds p inHIDDENR3 [:ZFMISC-1K2 Af0,Bf0 :] implies (( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds p =HIDDENR1 [TARSKIK4 x,y ] implies Pp3(x,y,y1)) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds p =HIDDENR1 [TARSKIK4 x,y ] implies Pp3(x,y,y2)) implies y1 =HIDDENR1 y2)"
        proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
          fix p assume [ty]: "p be objectHIDDENM1"
          fix y1 assume [ty]: "y1 be objectHIDDENM1"
          fix y2 assume [ty]: "y2 be objectHIDDENM1"
          assume "p inHIDDENR3 ?D"
          then obtain x1 x2 where
            [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" and 
            A9: "x1 inHIDDENR3 Af0 & x2 inHIDDENR3 Bf0"and A10: "p =HIDDENR1 [TARSKIK4 x1,x2 ]"
            using zfmisc_1_def_2 sorry
          assume "( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds p =HIDDENR1 [TARSKIK4 x,y ] implies Pp3(x,y,y1)) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds p =HIDDENR1 [TARSKIK4 x,y ] implies Pp3(x,y,y2))"
          then have "Pp3(x1,x2,y1) & Pp3(x1,x2,y2)"
            using A10 sorry
          thus "y1 =HIDDENR1 y2"
            using A1 A9 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A11: "domRELAT-1K1 f =XBOOLE-0R4 ?D"and A12: " for p be objectHIDDENM1 holds p inHIDDENR3 ?D implies ?R(p,f .FUNCT-1K1 p)"
        using funct_1_sch_2 A8 A3 sorry
      show " ex tVar2 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar2 =XBOOLE-0R4 [:ZFMISC-1K2 Af0,Bf0 :] & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 Af0 & y inHIDDENR3 Bf0 implies Pp3(x,y,tVar2 .BINOP-1K1(x,y)))"
      proof(rule bexI[of _ "f"],rule conjMI,rule ballI,rule ballI,rule impI)
        show "domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 Af0,Bf0 :]"
          using A11 sorry
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "x inHIDDENR3 Af0 & y inHIDDENR3 Bf0"
        then have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Af0,Bf0 :]"
          using zfmisc_1_def_2 sorry
        thus "Pp3(x,y,f .BINOP-1K1(x,y))"
          using A12 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem funct_3_sch_2:
  fixes Af0 Bf0 Ff2 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "Bf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> Ff2(x1,x2) be objectHIDDENM1"
  shows " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 Af0,Bf0 :] & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 Af0 & y inHIDDENR3 Bf0 implies f .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y))"
  proof-
    have " not ( for f be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 Af0,Bf0 :] & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ((x inHIDDENR3 Af0 & y inHIDDENR3 Bf0) &  not f .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y)))))"
    proof-
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3. Lamb3 =HIDDENR1 Ff2(Lamb1,Lamb2)"
      have A1: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 Af0 & y inHIDDENR3 Bf0 implies ( ex z be objectHIDDENM1 st ?P(x,y,z))"
         sorry
      have A2: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z1 be objectHIDDENM1 holds  for z2 be objectHIDDENM1 holds ((x inHIDDENR3 Af0 & y inHIDDENR3 Bf0) & ?P(x,y,z1)) & ?P(x,y,z2) implies z1 =HIDDENR1 z2"
         sorry
      have " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 Af0,Bf0 :] & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 Af0 & y inHIDDENR3 Bf0 implies ?P(x,y,f .BINOP-1K1(x,y)))"
        using funct_3_sch_1 A2 A1 sorry
      thus " not ( for f be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 Af0,Bf0 :] & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ((x inHIDDENR3 Af0 & y inHIDDENR3 Bf0) &  not f .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y)))))"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem funct_3_th_6:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds (domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & domRELAT-1K1 g =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies f .BINOP-1K1(x,y) =XBOOLE-0R4 g .BINOP-1K1(x,y)) implies f =FUNCT-1R1 g"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds (domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & domRELAT-1K1 g =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies f .BINOP-1K1(x,y) =XBOOLE-0R4 g .BINOP-1K1(x,y)) implies f =FUNCT-1R1 g"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & domRELAT-1K1 g =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]"
      and A2: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies f .BINOP-1K1(x,y) =XBOOLE-0R4 g .BINOP-1K1(x,y)"
    have " for p be objectHIDDENM1 holds p inHIDDENR3 [:ZFMISC-1K2 X,Y :] implies f .FUNCT-1K1 p =XBOOLE-0R4 g .FUNCT-1K1 p"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be objectHIDDENM1"
      assume "p inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
      then obtain x y where
        [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
        A3: "x inHIDDENR3 X & y inHIDDENR3 Y"and A4: "p =HIDDENR1 [TARSKIK4 x,y ]"
        using zfmisc_1_def_2 sorry
      have "f .BINOP-1K1(x,y) =XBOOLE-0R4 g .BINOP-1K1(x,y)"
        using A2 A3 sorry
      thus "f .FUNCT-1K1 p =XBOOLE-0R4 g .FUNCT-1K1 p"
        using A4 sorry
    qed "sorry"
    thus "f =FUNCT-1R1 g"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef funct_3_def_1 (".:FUNCT-3K1  _ " [200]200 ) where
  mlet "f be FunctionFUNCT-1M1"
"func .:FUNCT-3K1 f \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 boolZFMISC-1K1 (domRELAT-1K1 f) & ( for X be setHIDDENM2 holds X c=TARSKIR1 domRELAT-1K1 f implies it .FUNCT-1K1 X =XBOOLE-0R4 f .:FUNCT-1K5 X)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 boolZFMISC-1K1 (domRELAT-1K1 f) & ( for X be setHIDDENM2 holds X c=TARSKIR1 domRELAT-1K1 f implies it .FUNCT-1K1 X =XBOOLE-0R4 f .:FUNCT-1K5 X)"
    proof-
      have " ex tVar4 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar4 =XBOOLE-0R4 boolZFMISC-1K1 (domRELAT-1K1 f) & ( for X be setHIDDENM2 holds  not (X c=TARSKIR1 domRELAT-1K1 f &  not tVar4 .FUNCT-1K1 X =XBOOLE-0R4 f .:FUNCT-1K5 X))"
      proof-
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  for X be setHIDDENM2 holds Lamb1 =HIDDENR1 X implies Lamb2 =HIDDENR1 f .:FUNCT-1K5 X"
        have A1: " for x be objectHIDDENM1 holds x inHIDDENR3 boolZFMISC-1K1 (domRELAT-1K1 f) implies ( ex y be objectHIDDENM1 st ?P(x,y))"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 boolZFMISC-1K1 (domRELAT-1K1 f) implies ( ex tVar3 be objectHIDDENM1 st  for X be setHIDDENM2 holds x =HIDDENR1 X implies tVar3 =HIDDENR1 f .:FUNCT-1K5 X)"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 boolZFMISC-1K1 (domRELAT-1K1 f)"
            have 
              [ty]:"x be setHIDDENM2"
              using tarski_th_1 sorry
            show " ex tVar3 be objectHIDDENM1 st  for X be setHIDDENM2 holds x =HIDDENR1 X implies tVar3 =HIDDENR1 f .:FUNCT-1K5 X"
            proof(rule bexI[of _ "f .:FUNCT-1K5 x"])
              show " for X be setHIDDENM2 holds x =HIDDENR1 X implies f .:FUNCT-1K5 x =HIDDENR1 f .:FUNCT-1K5 X"
                 sorry
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have A2: " for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds (x inHIDDENR3 boolZFMISC-1K1 (domRELAT-1K1 f) & ?P(x,y1)) & ?P(x,y2) implies y1 =HIDDENR1 y2"
        proof-
          have " for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds x inHIDDENR3 boolZFMISC-1K1 (domRELAT-1K1 f) & (( for X be setHIDDENM2 holds x =HIDDENR1 X implies y1 =HIDDENR1 f .:FUNCT-1K5 X) & ( for X be setHIDDENM2 holds x =HIDDENR1 X implies y2 =HIDDENR1 f .:FUNCT-1K5 X)) implies y1 =HIDDENR1 y2"
          proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            fix y1 assume [ty]: "y1 be objectHIDDENM1"
            fix y2 assume [ty]: "y2 be objectHIDDENM1"
            assume "x inHIDDENR3 boolZFMISC-1K1 (domRELAT-1K1 f)"
              and A3: " for X be setHIDDENM2 holds x =HIDDENR1 X implies y1 =HIDDENR1 f .:FUNCT-1K5 X"
              and A4: " for X be setHIDDENM2 holds x =HIDDENR1 X implies y2 =HIDDENR1 f .:FUNCT-1K5 X"
            have 
              [ty]:"x be setHIDDENM2"
              using tarski_th_1 sorry
            have "y1 =HIDDENR1 f .:FUNCT-1K5 x"
              using A3 sorry
            also have "... = y2"
              using A4 sorry
            finally show "y1 =HIDDENR1 y2"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain g where
          [ty]:"g be FunctionFUNCT-1M1" and 
          A5: "domRELAT-1K1 g =XBOOLE-0R4 boolZFMISC-1K1 (domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 boolZFMISC-1K1 (domRELAT-1K1 f) implies ?P(x,g .FUNCT-1K1 x))"
          using funct_1_sch_2 A2 A1 sorry
        show " ex tVar4 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar4 =XBOOLE-0R4 boolZFMISC-1K1 (domRELAT-1K1 f) & ( for X be setHIDDENM2 holds  not (X c=TARSKIR1 domRELAT-1K1 f &  not tVar4 .FUNCT-1K1 X =XBOOLE-0R4 f .:FUNCT-1K5 X))"
        proof(rule bexI[of _ "g"])
          show "domRELAT-1K1 g =XBOOLE-0R4 boolZFMISC-1K1 (domRELAT-1K1 f) & ( for X be setHIDDENM2 holds  not (X c=TARSKIR1 domRELAT-1K1 f &  not g .FUNCT-1K1 X =XBOOLE-0R4 f .:FUNCT-1K5 X))"
            using A5 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 boolZFMISC-1K1 (domRELAT-1K1 f) & ( for X be setHIDDENM2 holds X c=TARSKIR1 domRELAT-1K1 f implies it1 .FUNCT-1K1 X =XBOOLE-0R4 f .:FUNCT-1K5 X)) & (domRELAT-1K1 it2 =XBOOLE-0R4 boolZFMISC-1K1 (domRELAT-1K1 f) & ( for X be setHIDDENM2 holds X c=TARSKIR1 domRELAT-1K1 f implies it2 .FUNCT-1K1 X =XBOOLE-0R4 f .:FUNCT-1K5 X)) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be FunctionFUNCT-1M1 holds  for f2 be FunctionFUNCT-1M1 holds domRELAT-1K1 f1 =XBOOLE-0R4 boolZFMISC-1K1 (domRELAT-1K1 f) & (( for X be setHIDDENM2 holds X c=TARSKIR1 domRELAT-1K1 f implies f1 .FUNCT-1K1 X =XBOOLE-0R4 f .:FUNCT-1K5 X) & (domRELAT-1K1 f2 =XBOOLE-0R4 boolZFMISC-1K1 (domRELAT-1K1 f) & ( for X be setHIDDENM2 holds X c=TARSKIR1 domRELAT-1K1 f implies f2 .FUNCT-1K1 X =XBOOLE-0R4 f .:FUNCT-1K5 X))) implies f1 =HIDDENR1 f2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix f1 assume [ty]: "f1 be FunctionFUNCT-1M1"
        fix f2 assume [ty]: "f2 be FunctionFUNCT-1M1"
        assume A6: "domRELAT-1K1 f1 =XBOOLE-0R4 boolZFMISC-1K1 (domRELAT-1K1 f)"
          and A7: " for X be setHIDDENM2 holds X c=TARSKIR1 domRELAT-1K1 f implies f1 .FUNCT-1K1 X =XBOOLE-0R4 f .:FUNCT-1K5 X"
          and A8: "domRELAT-1K1 f2 =XBOOLE-0R4 boolZFMISC-1K1 (domRELAT-1K1 f)"
          and A9: " for X be setHIDDENM2 holds X c=TARSKIR1 domRELAT-1K1 f implies f2 .FUNCT-1K1 X =XBOOLE-0R4 f .:FUNCT-1K5 X"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 boolZFMISC-1K1 (domRELAT-1K1 f) implies f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A10: "x inHIDDENR3 boolZFMISC-1K1 (domRELAT-1K1 f)"
          have 
            [ty]:"x be setHIDDENM2"
            using tarski_th_1 sorry
          have "f1 .FUNCT-1K1 x =XBOOLE-0R4 f .:FUNCT-1K5 x"
            using A7 A10 sorry
          thus "f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x"
            using A9 A10 sorry
        qed "sorry"
        thus "f1 =HIDDENR1 f2"
          using A6 A8 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem funct_3_th_7:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds X inTARSKIR2 domRELAT-1K1 (.:FUNCT-3K1 f) implies (.:FUNCT-3K1 f).FUNCT-1K1 X =XBOOLE-0R4 f .:FUNCT-1K5 X"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds X inTARSKIR2 domRELAT-1K1 (.:FUNCT-3K1 f) implies (.:FUNCT-3K1 f).FUNCT-1K1 X =XBOOLE-0R4 f .:FUNCT-1K5 X"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume "X inTARSKIR2 domRELAT-1K1 (.:FUNCT-3K1 f)"
    then have "X inTARSKIR2 boolZFMISC-1K1 (domRELAT-1K1 f)"
      using funct_3_def_1 sorry
    thus "(.:FUNCT-3K1 f).FUNCT-1K1 X =XBOOLE-0R4 f .:FUNCT-1K5 X"
      using funct_3_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_8:
" for f be FunctionFUNCT-1M1 holds (.:FUNCT-3K1 f).FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 {}XBOOLE-0K1"
proof(rule ballI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  have "{}XBOOLE-0K1 c=RELAT-1R2 domRELAT-1K1 f"
     sorry
  then have "(.:FUNCT-3K1 f).FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 f .:FUNCT-1K5 {}XBOOLE-0K1"
    using funct_3_def_1 sorry
  thus "(.:FUNCT-3K1 f).FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 {}XBOOLE-0K1"
     sorry
qed "sorry"

mtheorem funct_3_th_9:
" for f be FunctionFUNCT-1M1 holds rngFUNCT-1K2 (.:FUNCT-3K1 f) c=TARSKIR1 boolZFMISC-1K1 (rngFUNCT-1K2 f)"
proof(rule ballI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 (.:FUNCT-3K1 f) implies y inHIDDENR3 boolZFMISC-1K1 (rngFUNCT-1K2 f)"
  proof(rule ballI,rule impI)
    fix y assume [ty]: "y be objectHIDDENM1"
    obtain yy where 
      [ty]:"yy be setHIDDENM2" and yyDef:"yy = y"
      using tarski_th_1 sorry
    assume "y inHIDDENR3 rngFUNCT-1K2 (.:FUNCT-3K1 f)"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A1: "x inHIDDENR3 domRELAT-1K1 (.:FUNCT-3K1 f) & y =HIDDENR1 (.:FUNCT-3K1 f).FUNCT-1K1 x"
      using funct_1_def_3 sorry
    have 
      [ty]:"x be setHIDDENM2"
      using tarski_th_1 sorry
    have "y =HIDDENR1 f .:FUNCT-1K5 x"
      using A1 funct_3_th_7 sorry
    then have "yy c=TARSKIR1 rngFUNCT-1K2 f"
      using relat_1_th_111 sorry
    thus "y inHIDDENR3 boolZFMISC-1K1 (rngFUNCT-1K2 f)"
       sorry
  qed "sorry"
  thus "rngFUNCT-1K2 (.:FUNCT-3K1 f) c=TARSKIR1 boolZFMISC-1K1 (rngFUNCT-1K2 f)"
    using tarski_def_3 sorry
qed "sorry"

mtheorem funct_3_th_10:
" for A be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (.:FUNCT-3K1 f).:FUNCT-1K5 A c=TARSKIR1 boolZFMISC-1K1 (rngFUNCT-1K2 f)"
proof-
  have " for A be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (.:FUNCT-3K1 f).:FUNCT-1K5 A c=TARSKIR1 boolZFMISC-1K1 (rngFUNCT-1K2 f)"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have "(.:FUNCT-3K1 f).:FUNCT-1K5 A c=TARSKIR1 rngFUNCT-1K2 (.:FUNCT-3K1 f) & rngFUNCT-1K2 (.:FUNCT-3K1 f) c=TARSKIR1 boolZFMISC-1K1 (rngFUNCT-1K2 f)"
      using funct_3_th_9 relat_1_th_111 sorry
    thus "(.:FUNCT-3K1 f).:FUNCT-1K5 A c=TARSKIR1 boolZFMISC-1K1 (rngFUNCT-1K2 f)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_11:
" for B be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (.:FUNCT-3K1 f)\<inverse>FUNCT-1K6 B c=TARSKIR1 boolZFMISC-1K1 (domRELAT-1K1 f)"
proof-
  have " for B be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (.:FUNCT-3K1 f)\<inverse>FUNCT-1K6 B c=TARSKIR1 boolZFMISC-1K1 (domRELAT-1K1 f)"
  proof(rule ballI,rule ballI)
    fix B assume [ty]: "B be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have "domRELAT-1K1 (.:FUNCT-3K1 f) =XBOOLE-0R4 boolZFMISC-1K1 (domRELAT-1K1 f)"
      using funct_3_def_1 sorry
    thus "(.:FUNCT-3K1 f)\<inverse>FUNCT-1K6 B c=TARSKIR1 boolZFMISC-1K1 (domRELAT-1K1 f)"
      using relat_1_th_132 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_12:
" for B be setHIDDENM2 holds  for X be setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,D) holds (.:FUNCT-3K1 f)\<inverse>FUNCT-1K6 B c=TARSKIR1 boolZFMISC-1K1 X"
proof-
  have " for B be setHIDDENM2 holds  for X be setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,D) holds (.:FUNCT-3K1 f)\<inverse>FUNCT-1K6 B c=TARSKIR1 boolZFMISC-1K1 X"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix B assume [ty]: "B be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,D)"
    have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
      using funct_2_def_1 sorry
    thus "(.:FUNCT-3K1 f)\<inverse>FUNCT-1K6 B c=TARSKIR1 boolZFMISC-1K1 X"
      using funct_3_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_13:
" for A be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds unionTARSKIK3 ((.:FUNCT-3K1 f).:FUNCT-1K5 A) c=TARSKIR1 f .:FUNCT-1K5 unionTARSKIK3 A"
proof-
  have " for A be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds unionTARSKIK3 ((.:FUNCT-3K1 f).:FUNCT-1K5 A) c=TARSKIR1 f .:FUNCT-1K5 unionTARSKIK3 A"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 unionTARSKIK3 ((.:FUNCT-3K1 f).:FUNCT-1K5 A) implies y inHIDDENR3 f .:FUNCT-1K5 unionTARSKIK3 A"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 unionTARSKIK3 ((.:FUNCT-3K1 f).:FUNCT-1K5 A)"
      then obtain Z where
        [ty]:"Z be setHIDDENM2" and 
        A1: "y inHIDDENR3 Z"and A2: "Z inTARSKIR2 (.:FUNCT-3K1 f).:FUNCT-1K5 A"
        using tarski_def_4 sorry
      obtain X where
        [ty]:"X be objectHIDDENM1" and 
        A3: "X inHIDDENR3 domRELAT-1K1 (.:FUNCT-3K1 f)"and A4: "X inHIDDENR3 A"and A5: "Z =XBOOLE-0R4 (.:FUNCT-3K1 f).FUNCT-1K1 X"
        using A2 funct_1_def_6 sorry
      have 
        [ty]:"X be setHIDDENM2"
        using tarski_th_1 sorry
      have "y inHIDDENR3 f .:FUNCT-1K5 X"
        using A1 A3 A5 funct_3_th_7 sorry
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A6: "x inHIDDENR3 domRELAT-1K1 f"and A7: "x inHIDDENR3 X"and A8: "y =HIDDENR1 f .FUNCT-1K1 x"
        using funct_1_def_6 sorry
      have "x inHIDDENR3 unionTARSKIK3 A"
        using A4 A7 tarski_def_4 sorry
      thus "y inHIDDENR3 f .:FUNCT-1K5 unionTARSKIK3 A"
        using A6 A8 funct_1_def_6 sorry
    qed "sorry"
    thus "unionTARSKIK3 ((.:FUNCT-3K1 f).:FUNCT-1K5 A) c=TARSKIR1 f .:FUNCT-1K5 unionTARSKIK3 A"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_14:
" for A be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds A c=TARSKIR1 boolZFMISC-1K1 (domRELAT-1K1 f) implies f .:FUNCT-1K5 unionTARSKIK3 A =XBOOLE-0R4 unionTARSKIK3 ((.:FUNCT-3K1 f).:FUNCT-1K5 A)"
proof-
  have " for A be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds A c=TARSKIR1 boolZFMISC-1K1 (domRELAT-1K1 f) implies f .:FUNCT-1K5 unionTARSKIK3 A =XBOOLE-0R4 unionTARSKIK3 ((.:FUNCT-3K1 f).:FUNCT-1K5 A)"
  proof(rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "A c=TARSKIR1 boolZFMISC-1K1 (domRELAT-1K1 f)"
    have A2: "f .:FUNCT-1K5 unionTARSKIK3 A c=TARSKIR1 unionTARSKIK3 ((.:FUNCT-3K1 f).:FUNCT-1K5 A)"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 f .:FUNCT-1K5 unionTARSKIK3 A implies y inHIDDENR3 unionTARSKIK3 ((.:FUNCT-3K1 f).:FUNCT-1K5 A)"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 f .:FUNCT-1K5 unionTARSKIK3 A"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          "x inHIDDENR3 domRELAT-1K1 f"and A3: "x inHIDDENR3 unionTARSKIK3 A"and A4: "y =HIDDENR1 f .FUNCT-1K1 x"
          using funct_1_def_6 sorry
        obtain X where
          [ty]:"X be setHIDDENM2" and 
          A5: "x inHIDDENR3 X"and A6: "X inTARSKIR2 A"
          using A3 tarski_def_4 sorry
        have "X inTARSKIR2 boolZFMISC-1K1 (domRELAT-1K1 f)"
          using A1 A6 sorry
        then have "X inTARSKIR2 domRELAT-1K1 (.:FUNCT-3K1 f)"
          using funct_3_def_1 sorry
        then have A7: "(.:FUNCT-3K1 f).FUNCT-1K1 X inTARSKIR2 (.:FUNCT-3K1 f).:FUNCT-1K5 A"
          using A6 funct_1_def_6 sorry
        have "y inHIDDENR3 f .:FUNCT-1K5 X"
          using A1 A4 A5 A6 funct_1_def_6 sorry
        then have "y inHIDDENR3 (.:FUNCT-3K1 f).FUNCT-1K1 X"
          using A1 A6 funct_3_def_1 sorry
        thus "y inHIDDENR3 unionTARSKIK3 ((.:FUNCT-3K1 f).:FUNCT-1K5 A)"
          using A7 tarski_def_4 sorry
      qed "sorry"
      thus "f .:FUNCT-1K5 unionTARSKIK3 A c=TARSKIR1 unionTARSKIK3 ((.:FUNCT-3K1 f).:FUNCT-1K5 A)"
        using tarski_def_3 sorry
    qed
    have "unionTARSKIK3 ((.:FUNCT-3K1 f).:FUNCT-1K5 A) c=TARSKIR1 f .:FUNCT-1K5 unionTARSKIK3 A"
      using funct_3_th_13 sorry
    thus "f .:FUNCT-1K5 unionTARSKIK3 A =XBOOLE-0R4 unionTARSKIK3 ((.:FUNCT-3K1 f).:FUNCT-1K5 A)"
      using A2 xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_15:
" for A be setHIDDENM2 holds  for X be setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,D) holds A c=TARSKIR1 boolZFMISC-1K1 X implies f .:FUNCT-1K5 unionTARSKIK3 A =XBOOLE-0R4 unionTARSKIK3 ((.:FUNCT-3K1 f).:FUNCT-1K5 A)"
proof-
  have " for A be setHIDDENM2 holds  for X be setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,D) holds  not (A c=TARSKIR1 boolZFMISC-1K1 X &  not f .:FUNCT-1K5 unionTARSKIK3 A =XBOOLE-0R4 unionTARSKIK3 ((.:FUNCT-3K1 f).:FUNCT-1K5 A))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,D)"
    have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
      using funct_2_def_1 sorry
    thus " not (A c=TARSKIR1 boolZFMISC-1K1 X &  not f .:FUNCT-1K5 unionTARSKIK3 A =XBOOLE-0R4 unionTARSKIK3 ((.:FUNCT-3K1 f).:FUNCT-1K5 A))"
      using funct_3_th_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_16:
" for B be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds unionTARSKIK3 ((.:FUNCT-3K1 f)\<inverse>FUNCT-1K6 B) c=TARSKIR1 f \<inverse>FUNCT-1K6 (unionTARSKIK3 B)"
proof-
  have " for B be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds unionTARSKIK3 ((.:FUNCT-3K1 f)\<inverse>FUNCT-1K6 B) c=TARSKIR1 f \<inverse>FUNCT-1K6 (unionTARSKIK3 B)"
  proof(rule ballI,rule ballI)
    fix B assume [ty]: "B be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 ((.:FUNCT-3K1 f)\<inverse>FUNCT-1K6 B) implies x inHIDDENR3 f \<inverse>FUNCT-1K6 (unionTARSKIK3 B)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 unionTARSKIK3 ((.:FUNCT-3K1 f)\<inverse>FUNCT-1K6 B)"
      then obtain X where
        [ty]:"X be setHIDDENM2" and 
        A1: "x inHIDDENR3 X"and A2: "X inTARSKIR2 (.:FUNCT-3K1 f)\<inverse>FUNCT-1K6 B"
        using tarski_def_4 sorry
      have "domRELAT-1K1 (.:FUNCT-3K1 f) =XBOOLE-0R4 boolZFMISC-1K1 (domRELAT-1K1 f)"
        using funct_3_def_1 sorry
      then have A3: "X inTARSKIR2 boolZFMISC-1K1 (domRELAT-1K1 f)"
        using A2 funct_1_def_7 sorry
      then have A4: "f .FUNCT-1K1 x inTARSKIR2 f .:FUNCT-1K5 X"
        using A1 funct_1_def_6 sorry
      have "(.:FUNCT-3K1 f).FUNCT-1K1 X inTARSKIR2 B"
        using A2 funct_1_def_7 sorry
      then have "f .:FUNCT-1K5 X inTARSKIR2 B"
        using A3 funct_3_def_1 sorry
      then have "f .FUNCT-1K1 x inTARSKIR2 unionTARSKIK3 B"
        using A4 tarski_def_4 sorry
      thus "x inHIDDENR3 f \<inverse>FUNCT-1K6 (unionTARSKIK3 B)"
        using A1 A3 funct_1_def_7 sorry
    qed "sorry"
    thus "unionTARSKIK3 ((.:FUNCT-3K1 f)\<inverse>FUNCT-1K6 B) c=TARSKIR1 f \<inverse>FUNCT-1K6 (unionTARSKIK3 B)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_17:
" for B be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds B c=TARSKIR1 boolZFMISC-1K1 (rngFUNCT-1K2 f) implies f \<inverse>FUNCT-1K6 (unionTARSKIK3 B) =XBOOLE-0R4 unionTARSKIK3 ((.:FUNCT-3K1 f)\<inverse>FUNCT-1K6 B)"
proof-
  have " for B be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds B c=TARSKIR1 boolZFMISC-1K1 (rngFUNCT-1K2 f) implies f \<inverse>FUNCT-1K6 (unionTARSKIK3 B) =XBOOLE-0R4 unionTARSKIK3 ((.:FUNCT-3K1 f)\<inverse>FUNCT-1K6 B)"
  proof(rule ballI,rule ballI,rule impI)
    fix B assume [ty]: "B be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "B c=TARSKIR1 boolZFMISC-1K1 (rngFUNCT-1K2 f)"
    have A2: "f \<inverse>FUNCT-1K6 (unionTARSKIK3 B) c=TARSKIR1 unionTARSKIK3 ((.:FUNCT-3K1 f)\<inverse>FUNCT-1K6 B)"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 f \<inverse>FUNCT-1K6 (unionTARSKIK3 B) implies x inHIDDENR3 unionTARSKIK3 ((.:FUNCT-3K1 f)\<inverse>FUNCT-1K6 B)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A3: "x inHIDDENR3 f \<inverse>FUNCT-1K6 (unionTARSKIK3 B)"
        then have "f .FUNCT-1K1 x inTARSKIR2 unionTARSKIK3 B"
          using funct_1_def_7 sorry
        then obtain Y where
          [ty]:"Y be setHIDDENM2" and 
          A4: "f .FUNCT-1K1 x inTARSKIR2 Y"and A5: "Y inTARSKIR2 B"
          using tarski_def_4 sorry
        have A6: "f \<inverse>FUNCT-1K6 Y c=TARSKIR1 domRELAT-1K1 f"
          using relat_1_th_132 sorry
        then have "f \<inverse>FUNCT-1K6 Y inTARSKIR2 boolZFMISC-1K1 (domRELAT-1K1 f)"
           sorry
        then have A7: "f \<inverse>FUNCT-1K6 Y inTARSKIR2 domRELAT-1K1 (.:FUNCT-3K1 f)"
          using funct_3_def_1 sorry
        have "f .:FUNCT-1K5 f \<inverse>FUNCT-1K6 Y =XBOOLE-0R4 Y"
          using A1 A5 funct_1_th_77 sorry
        then have "(.:FUNCT-3K1 f).FUNCT-1K1 f \<inverse>FUNCT-1K6 Y inTARSKIR2 B"
          using A5 A6 funct_3_def_1 sorry
        then have A8: "f \<inverse>FUNCT-1K6 Y inTARSKIR2 (.:FUNCT-3K1 f)\<inverse>FUNCT-1K6 B"
          using A7 funct_1_def_7 sorry
        have "x inHIDDENR3 domRELAT-1K1 f"
          using A3 funct_1_def_7 sorry
        then have "x inHIDDENR3 f \<inverse>FUNCT-1K6 Y"
          using A4 funct_1_def_7 sorry
        thus "x inHIDDENR3 unionTARSKIK3 ((.:FUNCT-3K1 f)\<inverse>FUNCT-1K6 B)"
          using A8 tarski_def_4 sorry
      qed "sorry"
      thus "f \<inverse>FUNCT-1K6 (unionTARSKIK3 B) c=TARSKIR1 unionTARSKIK3 ((.:FUNCT-3K1 f)\<inverse>FUNCT-1K6 B)"
        using tarski_def_3 sorry
    qed
    have "unionTARSKIK3 ((.:FUNCT-3K1 f)\<inverse>FUNCT-1K6 B) c=TARSKIR1 f \<inverse>FUNCT-1K6 (unionTARSKIK3 B)"
      using funct_3_th_16 sorry
    thus "f \<inverse>FUNCT-1K6 (unionTARSKIK3 B) =XBOOLE-0R4 unionTARSKIK3 ((.:FUNCT-3K1 f)\<inverse>FUNCT-1K6 B)"
      using A2 xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_18:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds .:FUNCT-3K1 (g *FUNCT-1K3 f) =FUNCT-1R1 .:FUNCT-3K1 g *FUNCT-1K3 .:FUNCT-3K1 f"
proof(rule ballI,rule ballI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  fix g assume [ty]: "g be FunctionFUNCT-1M1"
  have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (.:FUNCT-3K1 (g *FUNCT-1K3 f)) iff x inHIDDENR3 domRELAT-1K1 (.:FUNCT-3K1 g *FUNCT-1K3 .:FUNCT-3K1 f)"
  proof-
    have " for x be objectHIDDENM1 holds (x inHIDDENR3 domRELAT-1K1 (.:FUNCT-3K1 (g *FUNCT-1K3 f)) implies x inHIDDENR3 domRELAT-1K1 (.:FUNCT-3K1 g *FUNCT-1K3 .:FUNCT-3K1 f)) & (x inHIDDENR3 domRELAT-1K1 (.:FUNCT-3K1 g *FUNCT-1K3 .:FUNCT-3K1 f) implies x inHIDDENR3 domRELAT-1K1 (.:FUNCT-3K1 (g *FUNCT-1K3 f)))"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      obtain xx where 
        [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
        using tarski_th_1 sorry
      show "x inHIDDENR3 domRELAT-1K1 (.:FUNCT-3K1 (g *FUNCT-1K3 f)) implies x inHIDDENR3 domRELAT-1K1 (.:FUNCT-3K1 g *FUNCT-1K3 .:FUNCT-3K1 f)"
      proof(rule impI)
        assume "x inHIDDENR3 domRELAT-1K1 (.:FUNCT-3K1 (g *FUNCT-1K3 f))"
        then have A1: "x inHIDDENR3 boolZFMISC-1K1 (domRELAT-1K1 (g *FUNCT-1K3 f))"
          using funct_3_def_1 sorry
        have "domRELAT-1K1 (g *FUNCT-1K3 f) c=TARSKIR1 domRELAT-1K1 f"
          using relat_1_th_25 sorry
        then have A2: "xx c=TARSKIR1 domRELAT-1K1 f"
          using A1 sorry
        then have "x inHIDDENR3 boolZFMISC-1K1 (domRELAT-1K1 f)"
           sorry
        then have A3: "x inHIDDENR3 domRELAT-1K1 (.:FUNCT-3K1 f)"
          using funct_3_def_1 sorry
        have "f .:FUNCT-1K5 xx c=TARSKIR1 domRELAT-1K1 g"
          using A1 funct_3_th_2 sorry
        then have "f .:FUNCT-1K5 xx inTARSKIR2 boolZFMISC-1K1 (domRELAT-1K1 g)"
           sorry
        then have "f .:FUNCT-1K5 xx inTARSKIR2 domRELAT-1K1 (.:FUNCT-3K1 g)"
          using funct_3_def_1 sorry
        then have "(.:FUNCT-3K1 f).FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 (.:FUNCT-3K1 g)"
          using A2 funct_3_def_1 sorry
        thus "x inHIDDENR3 domRELAT-1K1 (.:FUNCT-3K1 g *FUNCT-1K3 .:FUNCT-3K1 f)"
          using A3 funct_1_th_11 sorry
      qed
      assume A4: "x inHIDDENR3 domRELAT-1K1 (.:FUNCT-3K1 g *FUNCT-1K3 .:FUNCT-3K1 f)"
      then have A5: "x inHIDDENR3 domRELAT-1K1 (.:FUNCT-3K1 f)"
        using funct_1_th_11 sorry
      have "(.:FUNCT-3K1 f).FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 (.:FUNCT-3K1 g)"
        using A4 funct_1_th_11 sorry
      then have "f .:FUNCT-1K5 xx inTARSKIR2 domRELAT-1K1 (.:FUNCT-3K1 g)"
        using A5 funct_3_th_7 sorry
      then have A6: "f .:FUNCT-1K5 xx inTARSKIR2 boolZFMISC-1K1 (domRELAT-1K1 g)"
        using funct_3_def_1 sorry
      have "x inHIDDENR3 boolZFMISC-1K1 (domRELAT-1K1 f)"
        using A5 funct_3_def_1 sorry
      then have "xx c=TARSKIR1 domRELAT-1K1 (g *FUNCT-1K3 f)"
        using A6 funct_3_th_3 sorry
      then have "x inHIDDENR3 boolZFMISC-1K1 (domRELAT-1K1 (g *FUNCT-1K3 f))"
         sorry
      thus "x inHIDDENR3 domRELAT-1K1 (.:FUNCT-3K1 (g *FUNCT-1K3 f))"
        using funct_3_def_1 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  then have A7: "domRELAT-1K1 (.:FUNCT-3K1 (g *FUNCT-1K3 f)) =XBOOLE-0R4 domRELAT-1K1 (.:FUNCT-3K1 g *FUNCT-1K3 .:FUNCT-3K1 f)"
    using tarski_th_2 sorry
  have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (.:FUNCT-3K1 (g *FUNCT-1K3 f)) implies (.:FUNCT-3K1 (g *FUNCT-1K3 f)).FUNCT-1K1 x =XBOOLE-0R4 (.:FUNCT-3K1 g *FUNCT-1K3 .:FUNCT-3K1 f).FUNCT-1K1 x"
  proof-
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (.:FUNCT-3K1 (g *FUNCT-1K3 f)) implies (.:FUNCT-3K1 (g *FUNCT-1K3 f)).FUNCT-1K1 x =HIDDENR1 (.:FUNCT-3K1 g *FUNCT-1K3 .:FUNCT-3K1 f).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A8: "x inHIDDENR3 domRELAT-1K1 (.:FUNCT-3K1 (g *FUNCT-1K3 f))"
      then have A9: "x inHIDDENR3 boolZFMISC-1K1 (domRELAT-1K1 (g *FUNCT-1K3 f))"
        using funct_3_def_1 sorry
      obtain xx where 
        [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
        using tarski_th_1 sorry
      have A10: "f .:FUNCT-1K5 xx c=TARSKIR1 domRELAT-1K1 g"
        using funct_3_th_2 A9 sorry
      have "domRELAT-1K1 (g *FUNCT-1K3 f) c=TARSKIR1 domRELAT-1K1 f"
        using relat_1_th_25 sorry
      then have A11: "xx c=TARSKIR1 domRELAT-1K1 f"
        using A9 sorry
      then have "x inHIDDENR3 boolZFMISC-1K1 (domRELAT-1K1 f)"
         sorry
      then have A12: "x inHIDDENR3 domRELAT-1K1 (.:FUNCT-3K1 f)"
        using funct_3_def_1 sorry
      have "(.:FUNCT-3K1 (g *FUNCT-1K3 f)).FUNCT-1K1 x =HIDDENR1 (g *FUNCT-1K3 f).:FUNCT-1K5 xx"
        using A8 funct_3_th_7 sorry
      also have "... = g .:FUNCT-1K5 (f .:FUNCT-1K5 xx)"
        using relat_1_th_126 sorry
      also have "... = (.:FUNCT-3K1 g).FUNCT-1K1 (f .:FUNCT-1K5 xx)"
        using A10 funct_3_def_1 sorry
      also have "... = (.:FUNCT-3K1 g).FUNCT-1K1 ((.:FUNCT-3K1 f).FUNCT-1K1 x)"
        using A11 funct_3_def_1 sorry
      also have "... = (.:FUNCT-3K1 g *FUNCT-1K3 .:FUNCT-3K1 f).FUNCT-1K1 x"
        using A12 funct_1_th_13 sorry
      finally show "(.:FUNCT-3K1 (g *FUNCT-1K3 f)).FUNCT-1K1 x =HIDDENR1 (.:FUNCT-3K1 g *FUNCT-1K3 .:FUNCT-3K1 f).FUNCT-1K1 x"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus ".:FUNCT-3K1 (g *FUNCT-1K3 f) =FUNCT-1R1 .:FUNCT-3K1 g *FUNCT-1K3 .:FUNCT-3K1 f"
    using A7 sorry
qed "sorry"

mtheorem funct_3_th_19:
" for f be FunctionFUNCT-1M1 holds .:FUNCT-3K1 f be FunctionFUNCT-2M1-of(boolZFMISC-1K1 (domRELAT-1K1 f),boolZFMISC-1K1 (rngFUNCT-1K2 f))"
proof(rule ballI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  have "domRELAT-1K1 (.:FUNCT-3K1 f) =XBOOLE-0R4 boolZFMISC-1K1 (domRELAT-1K1 f) & rngFUNCT-1K2 (.:FUNCT-3K1 f) c=TARSKIR1 boolZFMISC-1K1 (rngFUNCT-1K2 f)"
    using funct_3_def_1 funct_3_th_9 sorry
  thus ".:FUNCT-3K1 f be FunctionFUNCT-2M1-of(boolZFMISC-1K1 (domRELAT-1K1 f),boolZFMISC-1K1 (rngFUNCT-1K2 f))"
    using funct_2_def_1 relset_1_th_4 sorry
qed "sorry"

mtheorem funct_3_th_20:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) implies .:FUNCT-3K1 f be FunctionFUNCT-2M1-of(boolZFMISC-1K1 X,boolZFMISC-1K1 Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) implies .:FUNCT-3K1 f be FunctionFUNCT-2M1-of(boolZFMISC-1K1 X,boolZFMISC-1K1 Y)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    assume "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1"
    then have A1: "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
      using funct_2_def_1 sorry
    have "rngFUNCT-1K2 f c=TARSKIR1 Y"
      using relat_1_def_19 sorry
    then have A2: "boolZFMISC-1K1 (rngFUNCT-1K2 f) c=TARSKIR1 boolZFMISC-1K1 Y"
      using zfmisc_1_th_67 sorry
    have A3: ".:FUNCT-3K1 f be FunctionFUNCT-2M1-of(boolZFMISC-1K1 (domRELSET-1K1\<^bsub>(X)\<^esub> f),boolZFMISC-1K1 (rngFUNCT-1K2 f))"
      using funct_3_th_19 sorry
    then have "rngFUNCT-1K2 (.:FUNCT-3K1 f) c=TARSKIR1 boolZFMISC-1K1 (rngFUNCT-1K2 f)"
      using relat_1_def_19 sorry
    then have A4: "rngFUNCT-1K2 (.:FUNCT-3K1 f) c=TARSKIR1 boolZFMISC-1K1 Y"
      using A2 sorry
    have "domRELAT-1K1 (.:FUNCT-3K1 f) =XBOOLE-0R4 boolZFMISC-1K1 (domRELSET-1K1\<^bsub>(X)\<^esub> f)"
      using A3 funct_2_def_1 sorry
    thus ".:FUNCT-3K1 f be FunctionFUNCT-2M1-of(boolZFMISC-1K1 X,boolZFMISC-1K1 Y)"
      using A1 A4 funct_2_def_1 relset_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax FUNCT_3K2 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (".:FUNCT-3K2\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,200]200)
translations ".:FUNCT-3K2\<^bsub>(X,D)\<^esub> f" \<rightharpoonup> ".:FUNCT-3K1 f"

mtheorem funct_3_add_1:
  mlet "X be setHIDDENM2", "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(X,D)"
"cluster .:FUNCT-3K1 f as-term-is FunctionFUNCT-2M1-of(boolZFMISC-1K1 X,boolZFMISC-1K1 D)"
proof
(*coherence*)
  show ".:FUNCT-3K1 f be FunctionFUNCT-2M1-of(boolZFMISC-1K1 X,boolZFMISC-1K1 D)"
    using funct_3_th_20 sorry
qed "sorry"

mdef funct_3_def_2 ("\<inverse>FUNCT-3K3  _ " [228]228 ) where
  mlet "f be FunctionFUNCT-1M1"
"func \<inverse>FUNCT-3K3 f \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 boolZFMISC-1K1 (rngFUNCT-1K2 f) & ( for Y be setHIDDENM2 holds Y c=TARSKIR1 rngFUNCT-1K2 f implies it .FUNCT-1K1 Y =XBOOLE-0R4 f \<inverse>FUNCT-1K6 Y)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 boolZFMISC-1K1 (rngFUNCT-1K2 f) & ( for Y be setHIDDENM2 holds Y c=TARSKIR1 rngFUNCT-1K2 f implies it .FUNCT-1K1 Y =XBOOLE-0R4 f \<inverse>FUNCT-1K6 Y)"
    proof-
      have " ex tVar6 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar6 =XBOOLE-0R4 boolZFMISC-1K1 (rngFUNCT-1K2 f) & ( for Y be setHIDDENM2 holds  not (Y c=TARSKIR1 rngFUNCT-1K2 f &  not tVar6 .FUNCT-1K1 Y =XBOOLE-0R4 f \<inverse>FUNCT-1K6 Y))"
      proof-
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  for Y be setHIDDENM2 holds Lamb1 =HIDDENR1 Y implies Lamb2 =HIDDENR1 f \<inverse>FUNCT-1K6 Y"
        have A1: " for y be objectHIDDENM1 holds y inHIDDENR3 boolZFMISC-1K1 (rngFUNCT-1K2 f) implies ( ex x be objectHIDDENM1 st ?P(y,x))"
        proof-
          have " for y be objectHIDDENM1 holds y inHIDDENR3 boolZFMISC-1K1 (rngFUNCT-1K2 f) implies ( ex tVar5 be objectHIDDENM1 st  for Y be setHIDDENM2 holds y =HIDDENR1 Y implies tVar5 =HIDDENR1 f \<inverse>FUNCT-1K6 Y)"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            assume "y inHIDDENR3 boolZFMISC-1K1 (rngFUNCT-1K2 f)"
            have 
              [ty]:"y be setHIDDENM2"
              using tarski_th_1 sorry
            show " ex tVar5 be objectHIDDENM1 st  for Y be setHIDDENM2 holds y =HIDDENR1 Y implies tVar5 =HIDDENR1 f \<inverse>FUNCT-1K6 Y"
            proof(rule bexI[of _ "f \<inverse>FUNCT-1K6 y"])
              show " for Y be setHIDDENM2 holds y =HIDDENR1 Y implies f \<inverse>FUNCT-1K6 y =HIDDENR1 f \<inverse>FUNCT-1K6 Y"
                 sorry
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have A2: " for y be objectHIDDENM1 holds  for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds (y inHIDDENR3 boolZFMISC-1K1 (rngFUNCT-1K2 f) & ?P(y,x1)) & ?P(y,x2) implies x1 =HIDDENR1 x2"
        proof-
          have " for y be objectHIDDENM1 holds  for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds y inHIDDENR3 boolZFMISC-1K1 (rngFUNCT-1K2 f) & (( for Y be setHIDDENM2 holds y =HIDDENR1 Y implies x1 =HIDDENR1 f \<inverse>FUNCT-1K6 Y) & ( for Y be setHIDDENM2 holds y =HIDDENR1 Y implies x2 =HIDDENR1 f \<inverse>FUNCT-1K6 Y)) implies x1 =HIDDENR1 x2"
          proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            fix x1 assume [ty]: "x1 be objectHIDDENM1"
            fix x2 assume [ty]: "x2 be objectHIDDENM1"
            assume "y inHIDDENR3 boolZFMISC-1K1 (rngFUNCT-1K2 f)"
              and A3: " for Y be setHIDDENM2 holds y =HIDDENR1 Y implies x1 =HIDDENR1 f \<inverse>FUNCT-1K6 Y"
              and A4: " for Y be setHIDDENM2 holds y =HIDDENR1 Y implies x2 =HIDDENR1 f \<inverse>FUNCT-1K6 Y"
            have 
              [ty]:"y be setHIDDENM2"
              using tarski_th_1 sorry
            have "x1 =HIDDENR1 f \<inverse>FUNCT-1K6 y"
              using A3 sorry
            also have "... = x2"
              using A4 sorry
            finally show "x1 =HIDDENR1 x2"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain g where
          [ty]:"g be FunctionFUNCT-1M1" and 
          A5: "domRELAT-1K1 g =XBOOLE-0R4 boolZFMISC-1K1 (rngFUNCT-1K2 f) & ( for y be objectHIDDENM1 holds y inHIDDENR3 boolZFMISC-1K1 (rngFUNCT-1K2 f) implies ?P(y,g .FUNCT-1K1 y))"
          using funct_1_sch_2 A2 A1 sorry
        show " ex tVar6 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar6 =XBOOLE-0R4 boolZFMISC-1K1 (rngFUNCT-1K2 f) & ( for Y be setHIDDENM2 holds  not (Y c=TARSKIR1 rngFUNCT-1K2 f &  not tVar6 .FUNCT-1K1 Y =XBOOLE-0R4 f \<inverse>FUNCT-1K6 Y))"
        proof(rule bexI[of _ "g"])
          show "domRELAT-1K1 g =XBOOLE-0R4 boolZFMISC-1K1 (rngFUNCT-1K2 f) & ( for Y be setHIDDENM2 holds  not (Y c=TARSKIR1 rngFUNCT-1K2 f &  not g .FUNCT-1K1 Y =XBOOLE-0R4 f \<inverse>FUNCT-1K6 Y))"
            using A5 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 boolZFMISC-1K1 (rngFUNCT-1K2 f) & ( for Y be setHIDDENM2 holds Y c=TARSKIR1 rngFUNCT-1K2 f implies it1 .FUNCT-1K1 Y =XBOOLE-0R4 f \<inverse>FUNCT-1K6 Y)) & (domRELAT-1K1 it2 =XBOOLE-0R4 boolZFMISC-1K1 (rngFUNCT-1K2 f) & ( for Y be setHIDDENM2 holds Y c=TARSKIR1 rngFUNCT-1K2 f implies it2 .FUNCT-1K1 Y =XBOOLE-0R4 f \<inverse>FUNCT-1K6 Y)) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be FunctionFUNCT-1M1 holds  for f2 be FunctionFUNCT-1M1 holds domRELAT-1K1 f1 =XBOOLE-0R4 boolZFMISC-1K1 (rngFUNCT-1K2 f) & (( for Y be setHIDDENM2 holds Y c=TARSKIR1 rngFUNCT-1K2 f implies f1 .FUNCT-1K1 Y =XBOOLE-0R4 f \<inverse>FUNCT-1K6 Y) & (domRELAT-1K1 f2 =XBOOLE-0R4 boolZFMISC-1K1 (rngFUNCT-1K2 f) & ( for Y be setHIDDENM2 holds Y c=TARSKIR1 rngFUNCT-1K2 f implies f2 .FUNCT-1K1 Y =XBOOLE-0R4 f \<inverse>FUNCT-1K6 Y))) implies f1 =HIDDENR1 f2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix f1 assume [ty]: "f1 be FunctionFUNCT-1M1"
        fix f2 assume [ty]: "f2 be FunctionFUNCT-1M1"
        assume A6: "domRELAT-1K1 f1 =XBOOLE-0R4 boolZFMISC-1K1 (rngFUNCT-1K2 f)"
          and A7: " for Y be setHIDDENM2 holds Y c=TARSKIR1 rngFUNCT-1K2 f implies f1 .FUNCT-1K1 Y =XBOOLE-0R4 f \<inverse>FUNCT-1K6 Y"
          and A8: "domRELAT-1K1 f2 =XBOOLE-0R4 boolZFMISC-1K1 (rngFUNCT-1K2 f)"
          and A9: " for Y be setHIDDENM2 holds Y c=TARSKIR1 rngFUNCT-1K2 f implies f2 .FUNCT-1K1 Y =XBOOLE-0R4 f \<inverse>FUNCT-1K6 Y"
        have " for y be objectHIDDENM1 holds y inHIDDENR3 boolZFMISC-1K1 (rngFUNCT-1K2 f) implies f1 .FUNCT-1K1 y =XBOOLE-0R4 f2 .FUNCT-1K1 y"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume A10: "y inHIDDENR3 boolZFMISC-1K1 (rngFUNCT-1K2 f)"
          have 
            [ty]:"y be setHIDDENM2"
            using tarski_th_1 sorry
          have "f1 .FUNCT-1K1 y =XBOOLE-0R4 f \<inverse>FUNCT-1K6 y"
            using A7 A10 sorry
          thus "f1 .FUNCT-1K1 y =XBOOLE-0R4 f2 .FUNCT-1K1 y"
            using A9 A10 sorry
        qed "sorry"
        thus "f1 =HIDDENR1 f2"
          using A6 A8 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem funct_3_th_21:
" for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds Y inTARSKIR2 domRELAT-1K1 (\<inverse>FUNCT-3K3 f) implies \<inverse>FUNCT-3K3 f .FUNCT-1K1 Y =XBOOLE-0R4 f \<inverse>FUNCT-1K6 Y"
proof-
  have " for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  not (Y inTARSKIR2 domRELAT-1K1 (\<inverse>FUNCT-3K3 f) &  not \<inverse>FUNCT-3K3 f .FUNCT-1K1 Y =XBOOLE-0R4 f \<inverse>FUNCT-1K6 Y)"
  proof(rule ballI,rule ballI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have "domRELAT-1K1 (\<inverse>FUNCT-3K3 f) =XBOOLE-0R4 boolZFMISC-1K1 (rngFUNCT-1K2 f)"
      using funct_3_def_2 sorry
    thus " not (Y inTARSKIR2 domRELAT-1K1 (\<inverse>FUNCT-3K3 f) &  not \<inverse>FUNCT-3K3 f .FUNCT-1K1 Y =XBOOLE-0R4 f \<inverse>FUNCT-1K6 Y)"
      using funct_3_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_22:
" for f be FunctionFUNCT-1M1 holds rngFUNCT-1K2 (\<inverse>FUNCT-3K3 f) c=TARSKIR1 boolZFMISC-1K1 (domRELAT-1K1 f)"
proof(rule ballI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (\<inverse>FUNCT-3K3 f) implies x inHIDDENR3 boolZFMISC-1K1 (domRELAT-1K1 f)"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    obtain xx where 
      [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
      using tarski_th_1 sorry
    assume "x inHIDDENR3 rngFUNCT-1K2 (\<inverse>FUNCT-3K3 f)"
    then obtain y where
      [ty]:"y be objectHIDDENM1" and 
      A1: "y inHIDDENR3 domRELAT-1K1 (\<inverse>FUNCT-3K3 f) & x =HIDDENR1 \<inverse>FUNCT-3K3 f .FUNCT-1K1 y"
      using funct_1_def_3 sorry
    have 
      [ty]:"y be setHIDDENM2"
      using tarski_th_1 sorry
    have "x =HIDDENR1 f \<inverse>FUNCT-1K6 y"
      using A1 funct_3_th_21 sorry
    then have "xx c=TARSKIR1 domRELAT-1K1 f"
      using relat_1_th_132 sorry
    thus "x inHIDDENR3 boolZFMISC-1K1 (domRELAT-1K1 f)"
       sorry
  qed "sorry"
  thus "rngFUNCT-1K2 (\<inverse>FUNCT-3K3 f) c=TARSKIR1 boolZFMISC-1K1 (domRELAT-1K1 f)"
    using tarski_def_3 sorry
qed "sorry"

mtheorem funct_3_th_23:
" for B be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds \<inverse>FUNCT-3K3 f .:FUNCT-1K5 B c=TARSKIR1 boolZFMISC-1K1 (domRELAT-1K1 f)"
proof-
  have " for B be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds \<inverse>FUNCT-3K3 f .:FUNCT-1K5 B c=TARSKIR1 boolZFMISC-1K1 (domRELAT-1K1 f)"
  proof(rule ballI,rule ballI)
    fix B assume [ty]: "B be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have "rngFUNCT-1K2 (\<inverse>FUNCT-3K3 f) c=TARSKIR1 boolZFMISC-1K1 (domRELAT-1K1 f) & \<inverse>FUNCT-3K3 f .:FUNCT-1K5 B c=TARSKIR1 rngFUNCT-1K2 (\<inverse>FUNCT-3K3 f)"
      using funct_3_th_22 relat_1_th_111 sorry
    thus "\<inverse>FUNCT-3K3 f .:FUNCT-1K5 B c=TARSKIR1 boolZFMISC-1K1 (domRELAT-1K1 f)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_24:
" for A be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (\<inverse>FUNCT-3K3 f)\<inverse>FUNCT-1K6 A c=TARSKIR1 boolZFMISC-1K1 (rngFUNCT-1K2 f)"
proof-
  have " for A be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (\<inverse>FUNCT-3K3 f)\<inverse>FUNCT-1K6 A c=TARSKIR1 boolZFMISC-1K1 (rngFUNCT-1K2 f)"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have "domRELAT-1K1 (\<inverse>FUNCT-3K3 f) =XBOOLE-0R4 boolZFMISC-1K1 (rngFUNCT-1K2 f)"
      using funct_3_def_2 sorry
    thus "(\<inverse>FUNCT-3K3 f)\<inverse>FUNCT-1K6 A c=TARSKIR1 boolZFMISC-1K1 (rngFUNCT-1K2 f)"
      using relat_1_th_132 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_25:
" for B be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds unionTARSKIK3 (\<inverse>FUNCT-3K3 f .:FUNCT-1K5 B) c=TARSKIR1 f \<inverse>FUNCT-1K6 (unionTARSKIK3 B)"
proof-
  have " for B be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds unionTARSKIK3 (\<inverse>FUNCT-3K3 f .:FUNCT-1K5 B) c=TARSKIR1 f \<inverse>FUNCT-1K6 (unionTARSKIK3 B)"
  proof(rule ballI,rule ballI)
    fix B assume [ty]: "B be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 (\<inverse>FUNCT-3K3 f .:FUNCT-1K5 B) implies x inHIDDENR3 f \<inverse>FUNCT-1K6 (unionTARSKIK3 B)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 unionTARSKIK3 (\<inverse>FUNCT-3K3 f .:FUNCT-1K5 B)"
      then obtain X where
        [ty]:"X be setHIDDENM2" and 
        A1: "x inHIDDENR3 X"and A2: "X inTARSKIR2 \<inverse>FUNCT-3K3 f .:FUNCT-1K5 B"
        using tarski_def_4 sorry
      obtain Y where
        [ty]:"Y be objectHIDDENM1" and 
        A3: "Y inHIDDENR3 domRELAT-1K1 (\<inverse>FUNCT-3K3 f)"and A4: "Y inHIDDENR3 B"and A5: "X =XBOOLE-0R4 \<inverse>FUNCT-3K3 f .FUNCT-1K1 Y"
        using A2 funct_1_def_6 sorry
      have 
        [ty]:"Y be setHIDDENM2"
        using tarski_th_1 sorry
      have A6: "\<inverse>FUNCT-3K3 f .FUNCT-1K1 Y =XBOOLE-0R4 f \<inverse>FUNCT-1K6 Y"
        using A3 funct_3_th_21 sorry
      have "Y inTARSKIR2 boolZFMISC-1K1 (rngFUNCT-1K2 f)"
        using A3 funct_3_def_2 sorry
      then have A7: "f .:FUNCT-1K5 X inTARSKIR2 B"
        using A4 A5 A6 funct_1_th_77 sorry
      have A8: "f \<inverse>FUNCT-1K6 Y c=TARSKIR1 domRELAT-1K1 f"
        using relat_1_th_132 sorry
      then have "f .FUNCT-1K1 x inTARSKIR2 f .:FUNCT-1K5 X"
        using A1 A5 A6 funct_1_def_6 sorry
      then have "f .FUNCT-1K1 x inTARSKIR2 unionTARSKIK3 B"
        using A7 tarski_def_4 sorry
      thus "x inHIDDENR3 f \<inverse>FUNCT-1K6 (unionTARSKIK3 B)"
        using A1 A5 A6 A8 funct_1_def_7 sorry
    qed "sorry"
    thus "unionTARSKIK3 (\<inverse>FUNCT-3K3 f .:FUNCT-1K5 B) c=TARSKIR1 f \<inverse>FUNCT-1K6 (unionTARSKIK3 B)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_26:
" for B be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds B c=TARSKIR1 boolZFMISC-1K1 (rngFUNCT-1K2 f) implies unionTARSKIK3 (\<inverse>FUNCT-3K3 f .:FUNCT-1K5 B) =XBOOLE-0R4 f \<inverse>FUNCT-1K6 (unionTARSKIK3 B)"
proof-
  have " for B be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds B c=TARSKIR1 boolZFMISC-1K1 (rngFUNCT-1K2 f) implies unionTARSKIK3 (\<inverse>FUNCT-3K3 f .:FUNCT-1K5 B) =XBOOLE-0R4 f \<inverse>FUNCT-1K6 (unionTARSKIK3 B)"
  proof(rule ballI,rule ballI,rule impI)
    fix B assume [ty]: "B be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "B c=TARSKIR1 boolZFMISC-1K1 (rngFUNCT-1K2 f)"
    have A2: "f \<inverse>FUNCT-1K6 (unionTARSKIK3 B) c=TARSKIR1 unionTARSKIK3 (\<inverse>FUNCT-3K3 f .:FUNCT-1K5 B)"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 f \<inverse>FUNCT-1K6 (unionTARSKIK3 B) implies x inHIDDENR3 unionTARSKIK3 (\<inverse>FUNCT-3K3 f .:FUNCT-1K5 B)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A3: "x inHIDDENR3 f \<inverse>FUNCT-1K6 (unionTARSKIK3 B)"
        then have "f .FUNCT-1K1 x inTARSKIR2 unionTARSKIK3 B"
          using funct_1_def_7 sorry
        then obtain Y where
          [ty]:"Y be setHIDDENM2" and 
          A4: "f .FUNCT-1K1 x inTARSKIR2 Y"and A5: "Y inTARSKIR2 B"
          using tarski_def_4 sorry
        have "x inHIDDENR3 domRELAT-1K1 f"
          using A3 funct_1_def_7 sorry
        then have A6: "x inHIDDENR3 f \<inverse>FUNCT-1K6 Y"
          using A4 funct_1_def_7 sorry
        have "Y inTARSKIR2 boolZFMISC-1K1 (rngFUNCT-1K2 f)"
          using A1 A5 sorry
        then have A7: "Y inTARSKIR2 domRELAT-1K1 (\<inverse>FUNCT-3K3 f)"
          using funct_3_def_2 sorry
        have "\<inverse>FUNCT-3K3 f .FUNCT-1K1 Y =XBOOLE-0R4 f \<inverse>FUNCT-1K6 Y"
          using A1 A5 funct_3_def_2 sorry
        then have "f \<inverse>FUNCT-1K6 Y inTARSKIR2 \<inverse>FUNCT-3K3 f .:FUNCT-1K5 B"
          using A5 A7 funct_1_def_6 sorry
        thus "x inHIDDENR3 unionTARSKIK3 (\<inverse>FUNCT-3K3 f .:FUNCT-1K5 B)"
          using A6 tarski_def_4 sorry
      qed "sorry"
      thus "f \<inverse>FUNCT-1K6 (unionTARSKIK3 B) c=TARSKIR1 unionTARSKIK3 (\<inverse>FUNCT-3K3 f .:FUNCT-1K5 B)"
        using tarski_def_3 sorry
    qed
    have "unionTARSKIK3 (\<inverse>FUNCT-3K3 f .:FUNCT-1K5 B) c=TARSKIR1 f \<inverse>FUNCT-1K6 (unionTARSKIK3 B)"
      using funct_3_th_25 sorry
    thus "unionTARSKIK3 (\<inverse>FUNCT-3K3 f .:FUNCT-1K5 B) =XBOOLE-0R4 f \<inverse>FUNCT-1K6 (unionTARSKIK3 B)"
      using A2 xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_27:
" for A be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds unionTARSKIK3 ((\<inverse>FUNCT-3K3 f)\<inverse>FUNCT-1K6 A) c=TARSKIR1 f .:FUNCT-1K5 unionTARSKIK3 A"
proof-
  have " for A be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds unionTARSKIK3 ((\<inverse>FUNCT-3K3 f)\<inverse>FUNCT-1K6 A) c=TARSKIR1 f .:FUNCT-1K5 unionTARSKIK3 A"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 unionTARSKIK3 ((\<inverse>FUNCT-3K3 f)\<inverse>FUNCT-1K6 A) implies y inHIDDENR3 f .:FUNCT-1K5 unionTARSKIK3 A"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 unionTARSKIK3 ((\<inverse>FUNCT-3K3 f)\<inverse>FUNCT-1K6 A)"
      then obtain Y where
        [ty]:"Y be setHIDDENM2" and 
        A1: "y inHIDDENR3 Y"and A2: "Y inTARSKIR2 (\<inverse>FUNCT-3K3 f)\<inverse>FUNCT-1K6 A"
        using tarski_def_4 sorry
      have "domRELAT-1K1 (\<inverse>FUNCT-3K3 f) =XBOOLE-0R4 boolZFMISC-1K1 (rngFUNCT-1K2 f)"
        using funct_3_def_2 sorry
      then have A3: "Y inTARSKIR2 boolZFMISC-1K1 (rngFUNCT-1K2 f)"
        using A2 funct_1_def_7 sorry
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A4: "x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x"
        using A1 funct_1_def_3 sorry
      have "\<inverse>FUNCT-3K3 f .FUNCT-1K1 Y inTARSKIR2 A"
        using A2 funct_1_def_7 sorry
      then have A5: "f \<inverse>FUNCT-1K6 Y inTARSKIR2 A"
        using A3 funct_3_def_2 sorry
      have "x inHIDDENR3 f \<inverse>FUNCT-1K6 Y"
        using A1 A4 funct_1_def_7 sorry
      then have "x inHIDDENR3 unionTARSKIK3 A"
        using A5 tarski_def_4 sorry
      thus "y inHIDDENR3 f .:FUNCT-1K5 unionTARSKIK3 A"
        using A4 funct_1_def_6 sorry
    qed "sorry"
    thus "unionTARSKIK3 ((\<inverse>FUNCT-3K3 f)\<inverse>FUNCT-1K6 A) c=TARSKIR1 f .:FUNCT-1K5 unionTARSKIK3 A"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_28:
" for A be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds A c=TARSKIR1 boolZFMISC-1K1 (domRELAT-1K1 f) & f be one-to-oneFUNCT-1V2 implies unionTARSKIK3 ((\<inverse>FUNCT-3K3 f)\<inverse>FUNCT-1K6 A) =XBOOLE-0R4 f .:FUNCT-1K5 unionTARSKIK3 A"
proof-
  have " for A be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds A c=TARSKIR1 boolZFMISC-1K1 (domRELAT-1K1 f) & f be one-to-oneFUNCT-1V2 implies unionTARSKIK3 ((\<inverse>FUNCT-3K3 f)\<inverse>FUNCT-1K6 A) =XBOOLE-0R4 f .:FUNCT-1K5 unionTARSKIK3 A"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "A c=TARSKIR1 boolZFMISC-1K1 (domRELAT-1K1 f)"
      and A2: "f be one-to-oneFUNCT-1V2"
    have A3: "f .:FUNCT-1K5 unionTARSKIK3 A c=TARSKIR1 unionTARSKIK3 ((\<inverse>FUNCT-3K3 f)\<inverse>FUNCT-1K6 A)"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 f .:FUNCT-1K5 unionTARSKIK3 A implies y inHIDDENR3 unionTARSKIK3 ((\<inverse>FUNCT-3K3 f)\<inverse>FUNCT-1K6 A)"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 f .:FUNCT-1K5 unionTARSKIK3 A"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A4: "x inHIDDENR3 domRELAT-1K1 f"and A5: "x inHIDDENR3 unionTARSKIK3 A"and A6: "y =HIDDENR1 f .FUNCT-1K1 x"
          using funct_1_def_6 sorry
        obtain X where
          [ty]:"X be setHIDDENM2" and 
          A7: "x inHIDDENR3 X"and A8: "X inTARSKIR2 A"
          using A5 tarski_def_4 sorry
        have A9: "f \<inverse>FUNCT-1K6 (f .:FUNCT-1K5 X) c=TARSKIR1 X"
          using A2 funct_1_th_82 sorry
        have A10: "f .:FUNCT-1K5 X c=TARSKIR1 rngFUNCT-1K2 f"
          using relat_1_th_111 sorry
        then have "f .:FUNCT-1K5 X inTARSKIR2 boolZFMISC-1K1 (rngFUNCT-1K2 f)"
           sorry
        then have A11: "f .:FUNCT-1K5 X inTARSKIR2 domRELAT-1K1 (\<inverse>FUNCT-3K3 f)"
          using funct_3_def_2 sorry
        have "X c=TARSKIR1 f \<inverse>FUNCT-1K6 (f .:FUNCT-1K5 X)"
          using A1 A8 funct_1_th_76 sorry
        then have "f \<inverse>FUNCT-1K6 (f .:FUNCT-1K5 X) =XBOOLE-0R4 X"
          using A9 xboole_0_def_10 sorry
        then have "\<inverse>FUNCT-3K3 f .FUNCT-1K1 (f .:FUNCT-1K5 X) inTARSKIR2 A"
          using A8 A10 funct_3_def_2 sorry
        then have A12: "f .:FUNCT-1K5 X inTARSKIR2 (\<inverse>FUNCT-3K3 f)\<inverse>FUNCT-1K6 A"
          using A11 funct_1_def_7 sorry
        have "y inHIDDENR3 f .:FUNCT-1K5 X"
          using A4 A6 A7 funct_1_def_6 sorry
        thus "y inHIDDENR3 unionTARSKIK3 ((\<inverse>FUNCT-3K3 f)\<inverse>FUNCT-1K6 A)"
          using A12 tarski_def_4 sorry
      qed "sorry"
      thus "f .:FUNCT-1K5 unionTARSKIK3 A c=TARSKIR1 unionTARSKIK3 ((\<inverse>FUNCT-3K3 f)\<inverse>FUNCT-1K6 A)"
        using tarski_def_3 sorry
    qed
    have "unionTARSKIK3 ((\<inverse>FUNCT-3K3 f)\<inverse>FUNCT-1K6 A) c=TARSKIR1 f .:FUNCT-1K5 unionTARSKIK3 A"
      using funct_3_th_27 sorry
    thus "unionTARSKIK3 ((\<inverse>FUNCT-3K3 f)\<inverse>FUNCT-1K6 A) =XBOOLE-0R4 f .:FUNCT-1K5 unionTARSKIK3 A"
      using A3 xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_29:
" for B be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds \<inverse>FUNCT-3K3 f .:FUNCT-1K5 B c=TARSKIR1 (.:FUNCT-3K1 f)\<inverse>FUNCT-1K6 B"
proof-
  have " for B be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds \<inverse>FUNCT-3K3 f .:FUNCT-1K5 B c=TARSKIR1 (.:FUNCT-3K1 f)\<inverse>FUNCT-1K6 B"
  proof(rule ballI,rule ballI)
    fix B assume [ty]: "B be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 \<inverse>FUNCT-3K3 f .:FUNCT-1K5 B implies x inHIDDENR3 (.:FUNCT-3K1 f)\<inverse>FUNCT-1K6 B"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      obtain xx where 
        [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
        using tarski_th_1 sorry
      assume "x inHIDDENR3 \<inverse>FUNCT-3K3 f .:FUNCT-1K5 B"
      then obtain Y where
        [ty]:"Y be objectHIDDENM1" and 
        A1: "Y inHIDDENR3 domRELAT-1K1 (\<inverse>FUNCT-3K3 f)"and A2: "Y inHIDDENR3 B"and A3: "x =HIDDENR1 \<inverse>FUNCT-3K3 f .FUNCT-1K1 Y"
        using funct_1_def_6 sorry
      have 
        [ty]:"Y be setHIDDENM2"
        using tarski_th_1 sorry
      have A4: "\<inverse>FUNCT-3K3 f .FUNCT-1K1 Y =XBOOLE-0R4 f \<inverse>FUNCT-1K6 Y"
        using A1 funct_3_th_21 sorry
      then have A5: "xx c=TARSKIR1 domRELAT-1K1 f"
        using A3 relat_1_th_132 sorry
      then have "x inHIDDENR3 boolZFMISC-1K1 (domRELAT-1K1 f)"
         sorry
      then have A6: "x inHIDDENR3 domRELAT-1K1 (.:FUNCT-3K1 f)"
        using funct_3_def_1 sorry
      have "Y inTARSKIR2 boolZFMISC-1K1 (rngFUNCT-1K2 f)"
        using A1 funct_3_def_2 sorry
      then have "f .:FUNCT-1K5 xx inTARSKIR2 B"
        using A2 A3 A4 funct_1_th_77 sorry
      then have "(.:FUNCT-3K1 f).FUNCT-1K1 x inTARSKIR2 B"
        using A5 funct_3_def_1 sorry
      thus "x inHIDDENR3 (.:FUNCT-3K1 f)\<inverse>FUNCT-1K6 B"
        using A6 funct_1_def_7 sorry
    qed "sorry"
    thus "\<inverse>FUNCT-3K3 f .:FUNCT-1K5 B c=TARSKIR1 (.:FUNCT-3K1 f)\<inverse>FUNCT-1K6 B"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_30:
" for B be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies \<inverse>FUNCT-3K3 f .:FUNCT-1K5 B =XBOOLE-0R4 (.:FUNCT-3K1 f)\<inverse>FUNCT-1K6 B"
proof-
  have " for B be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies \<inverse>FUNCT-3K3 f .:FUNCT-1K5 B =XBOOLE-0R4 (.:FUNCT-3K1 f)\<inverse>FUNCT-1K6 B"
  proof(rule ballI,rule ballI,rule impI)
    fix B assume [ty]: "B be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "f be one-to-oneFUNCT-1V2"
    have A2: "(.:FUNCT-3K1 f)\<inverse>FUNCT-1K6 B c=TARSKIR1 \<inverse>FUNCT-3K3 f .:FUNCT-1K5 B"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 (.:FUNCT-3K1 f)\<inverse>FUNCT-1K6 B implies x inHIDDENR3 \<inverse>FUNCT-3K3 f .:FUNCT-1K5 B"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        obtain xx where 
          [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
          using tarski_th_1 sorry
        have A3: "f .:FUNCT-1K5 xx c=TARSKIR1 rngFUNCT-1K2 f"
          using relat_1_th_111 sorry
        then have "f .:FUNCT-1K5 xx inTARSKIR2 boolZFMISC-1K1 (rngFUNCT-1K2 f)"
           sorry
        then have A4: "f .:FUNCT-1K5 xx inTARSKIR2 domRELAT-1K1 (\<inverse>FUNCT-3K3 f)"
          using funct_3_def_2 sorry
        assume A5: "x inHIDDENR3 (.:FUNCT-3K1 f)\<inverse>FUNCT-1K6 B"
        then have A6: "x inHIDDENR3 domRELAT-1K1 (.:FUNCT-3K1 f)"
          using funct_1_def_7 sorry
        then have "x inHIDDENR3 boolZFMISC-1K1 (domRELAT-1K1 f)"
          using funct_3_def_1 sorry
        then have A7: "xx c=TARSKIR1 f \<inverse>FUNCT-1K6 (f .:FUNCT-1K5 xx)"
          using funct_1_th_76 sorry
        have "f \<inverse>FUNCT-1K6 (f .:FUNCT-1K5 xx) c=TARSKIR1 xx"
          using A1 funct_1_th_82 sorry
        then have "x =HIDDENR1 f \<inverse>FUNCT-1K6 (f .:FUNCT-1K5 xx)"
          using A7 xboole_0_def_10 sorry
        then have A8: "x =HIDDENR1 \<inverse>FUNCT-3K3 f .FUNCT-1K1 (f .:FUNCT-1K5 xx)"
          using A3 funct_3_def_2 sorry
        have "(.:FUNCT-3K1 f).FUNCT-1K1 x inTARSKIR2 B"
          using A5 funct_1_def_7 sorry
        then have "f .:FUNCT-1K5 xx inTARSKIR2 B"
          using A6 funct_3_th_7 sorry
        thus "x inHIDDENR3 \<inverse>FUNCT-3K3 f .:FUNCT-1K5 B"
          using A8 A4 funct_1_def_6 sorry
      qed "sorry"
      thus "(.:FUNCT-3K1 f)\<inverse>FUNCT-1K6 B c=TARSKIR1 \<inverse>FUNCT-3K3 f .:FUNCT-1K5 B"
        using tarski_def_3 sorry
    qed
    have "\<inverse>FUNCT-3K3 f .:FUNCT-1K5 B c=TARSKIR1 (.:FUNCT-3K1 f)\<inverse>FUNCT-1K6 B"
      using funct_3_th_29 sorry
    thus "\<inverse>FUNCT-3K3 f .:FUNCT-1K5 B =XBOOLE-0R4 (.:FUNCT-3K1 f)\<inverse>FUNCT-1K6 B"
      using A2 xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_31:
" for f be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds A c=TARSKIR1 boolZFMISC-1K1 (domRELAT-1K1 f) implies (\<inverse>FUNCT-3K3 f)\<inverse>FUNCT-1K6 A c=TARSKIR1 (.:FUNCT-3K1 f).:FUNCT-1K5 A"
proof(rule ballI,rule ballI,rule impI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  fix A assume [ty]: "A be setHIDDENM2"
  assume A1: "A c=TARSKIR1 boolZFMISC-1K1 (domRELAT-1K1 f)"
  have " for y be objectHIDDENM1 holds y inHIDDENR3 (\<inverse>FUNCT-3K3 f)\<inverse>FUNCT-1K6 A implies y inHIDDENR3 (.:FUNCT-3K1 f).:FUNCT-1K5 A"
  proof(rule ballI,rule impI)
    fix y assume [ty]: "y be objectHIDDENM1"
    obtain yy where 
      [ty]:"yy be setHIDDENM2" and yyDef:"yy = y"
      using tarski_th_1 sorry
    assume A2: "y inHIDDENR3 (\<inverse>FUNCT-3K3 f)\<inverse>FUNCT-1K6 A"
    then have A3: "\<inverse>FUNCT-3K3 f .FUNCT-1K1 y inTARSKIR2 A"
      using funct_1_def_7 sorry
    have "y inHIDDENR3 domRELAT-1K1 (\<inverse>FUNCT-3K3 f)"
      using A2 funct_1_def_7 sorry
    then have A4: "y inHIDDENR3 boolZFMISC-1K1 (rngFUNCT-1K2 f)"
      using funct_3_def_2 sorry
    then have A5: "f \<inverse>FUNCT-1K6 yy inTARSKIR2 A"
      using A3 funct_3_def_2 sorry
    then have "f \<inverse>FUNCT-1K6 yy inTARSKIR2 boolZFMISC-1K1 (domRELAT-1K1 f)"
      using A1 sorry
    then have A6: "f \<inverse>FUNCT-1K6 yy inTARSKIR2 domRELAT-1K1 (.:FUNCT-3K1 f)"
      using funct_3_def_1 sorry
    have "f .:FUNCT-1K5 f \<inverse>FUNCT-1K6 yy =HIDDENR1 y"
      using A4 funct_1_th_77 sorry
    then have A7: "(.:FUNCT-3K1 f).FUNCT-1K1 f \<inverse>FUNCT-1K6 yy =HIDDENR1 y"
      using A1 A5 funct_3_def_1 sorry
    have "f \<inverse>FUNCT-1K6 yy inTARSKIR2 A"
      using A3 A4 funct_3_def_2 sorry
    thus "y inHIDDENR3 (.:FUNCT-3K1 f).:FUNCT-1K5 A"
      using A7 A6 funct_1_def_6 sorry
  qed "sorry"
  thus "(\<inverse>FUNCT-3K3 f)\<inverse>FUNCT-1K6 A c=TARSKIR1 (.:FUNCT-3K1 f).:FUNCT-1K5 A"
    using tarski_def_3 sorry
qed "sorry"

mtheorem funct_3_th_32:
" for f be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds f be one-to-oneFUNCT-1V2 implies (.:FUNCT-3K1 f).:FUNCT-1K5 A c=TARSKIR1 (\<inverse>FUNCT-3K3 f)\<inverse>FUNCT-1K6 A"
proof(rule ballI,rule ballI,rule impI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  fix A assume [ty]: "A be setHIDDENM2"
  assume A1: "f be one-to-oneFUNCT-1V2"
  have " for y be objectHIDDENM1 holds y inHIDDENR3 (.:FUNCT-3K1 f).:FUNCT-1K5 A implies y inHIDDENR3 (\<inverse>FUNCT-3K3 f)\<inverse>FUNCT-1K6 A"
  proof(rule ballI,rule impI)
    fix y assume [ty]: "y be objectHIDDENM1"
    obtain yy where 
      [ty]:"yy be setHIDDENM2" and yyDef:"yy = y"
      using tarski_th_1 sorry
    assume "y inHIDDENR3 (.:FUNCT-3K1 f).:FUNCT-1K5 A"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A2: "x inHIDDENR3 domRELAT-1K1 (.:FUNCT-3K1 f)"and A3: "x inHIDDENR3 A"and A4: "y =HIDDENR1 (.:FUNCT-3K1 f).FUNCT-1K1 x"
      using funct_1_def_6 sorry
    have 
      [ty]:"x be setHIDDENM2"
      using tarski_th_1 sorry
    have A5: "x inTARSKIR2 boolZFMISC-1K1 (domRELAT-1K1 f)"
      using A2 funct_3_def_1 sorry
    then have A6: "y =HIDDENR1 f .:FUNCT-1K5 x"
      using A4 funct_3_def_1 sorry
    then have A7: "x c=TARSKIR1 f \<inverse>FUNCT-1K6 yy"
      using A5 funct_1_th_76 sorry
    have A8: "yy c=TARSKIR1 rngFUNCT-1K2 f"
      using A6 relat_1_th_111 sorry
    then have "y inHIDDENR3 boolZFMISC-1K1 (rngFUNCT-1K2 f)"
       sorry
    then have A9: "y inHIDDENR3 domRELAT-1K1 (\<inverse>FUNCT-3K3 f)"
      using funct_3_def_2 sorry
    have "f \<inverse>FUNCT-1K6 yy c=TARSKIR1 x"
      using A1 A6 funct_1_th_82 sorry
    then have "f \<inverse>FUNCT-1K6 yy inTARSKIR2 A"
      using A3 A7 xboole_0_def_10 sorry
    then have "\<inverse>FUNCT-3K3 f .FUNCT-1K1 y inTARSKIR2 A"
      using A8 funct_3_def_2 sorry
    thus "y inHIDDENR3 (\<inverse>FUNCT-3K3 f)\<inverse>FUNCT-1K6 A"
      using A9 funct_1_def_7 sorry
  qed "sorry"
  thus "(.:FUNCT-3K1 f).:FUNCT-1K5 A c=TARSKIR1 (\<inverse>FUNCT-3K3 f)\<inverse>FUNCT-1K6 A"
    using tarski_def_3 sorry
qed "sorry"

mtheorem funct_3_th_33:
" for f be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds f be one-to-oneFUNCT-1V2 & A c=TARSKIR1 boolZFMISC-1K1 (domRELAT-1K1 f) implies (\<inverse>FUNCT-3K3 f)\<inverse>FUNCT-1K6 A =XBOOLE-0R4 (.:FUNCT-3K1 f).:FUNCT-1K5 A"
proof(rule ballI,rule ballI,rule impI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  fix A assume [ty]: "A be setHIDDENM2"
  assume "f be one-to-oneFUNCT-1V2 & A c=TARSKIR1 boolZFMISC-1K1 (domRELAT-1K1 f)"
  then have "(\<inverse>FUNCT-3K3 f)\<inverse>FUNCT-1K6 A c=TARSKIR1 (.:FUNCT-3K1 f).:FUNCT-1K5 A & (.:FUNCT-3K1 f).:FUNCT-1K5 A c=TARSKIR1 (\<inverse>FUNCT-3K3 f)\<inverse>FUNCT-1K6 A"
    using funct_3_th_31 funct_3_th_32 sorry
  thus "(\<inverse>FUNCT-3K3 f)\<inverse>FUNCT-1K6 A =XBOOLE-0R4 (.:FUNCT-3K1 f).:FUNCT-1K5 A"
    using xboole_0_def_10 sorry
qed "sorry"

mtheorem funct_3_th_34:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds g be one-to-oneFUNCT-1V2 implies \<inverse>FUNCT-3K3 (g *FUNCT-1K3 f) =FUNCT-1R1 \<inverse>FUNCT-3K3 f *FUNCT-1K3 \<inverse>FUNCT-3K3 g"
proof(rule ballI,rule ballI,rule impI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  fix g assume [ty]: "g be FunctionFUNCT-1M1"
  assume A1: "g be one-to-oneFUNCT-1V2"
  have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 (\<inverse>FUNCT-3K3 (g *FUNCT-1K3 f)) iff y inHIDDENR3 domRELAT-1K1 (\<inverse>FUNCT-3K3 f *FUNCT-1K3 \<inverse>FUNCT-3K3 g)"
  proof-
    have " for y be objectHIDDENM1 holds (y inHIDDENR3 domRELAT-1K1 (\<inverse>FUNCT-3K3 (g *FUNCT-1K3 f)) implies y inHIDDENR3 domRELAT-1K1 (\<inverse>FUNCT-3K3 f *FUNCT-1K3 \<inverse>FUNCT-3K3 g)) & (y inHIDDENR3 domRELAT-1K1 (\<inverse>FUNCT-3K3 f *FUNCT-1K3 \<inverse>FUNCT-3K3 g) implies y inHIDDENR3 domRELAT-1K1 (\<inverse>FUNCT-3K3 (g *FUNCT-1K3 f)))"
    proof(rule ballI,rule conjMI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      obtain yy where 
        [ty]:"yy be setHIDDENM2" and yyDef:"yy = y"
        using tarski_th_1 sorry
      show "y inHIDDENR3 domRELAT-1K1 (\<inverse>FUNCT-3K3 (g *FUNCT-1K3 f)) implies y inHIDDENR3 domRELAT-1K1 (\<inverse>FUNCT-3K3 f *FUNCT-1K3 \<inverse>FUNCT-3K3 g)"
      proof(rule impI)
        assume "y inHIDDENR3 domRELAT-1K1 (\<inverse>FUNCT-3K3 (g *FUNCT-1K3 f))"
        then have A2: "y inHIDDENR3 boolZFMISC-1K1 (rngFUNCT-1K2 (g *FUNCT-1K3 f))"
          using funct_3_def_2 sorry
        have "rngFUNCT-1K2 (g *FUNCT-1K3 f) c=TARSKIR1 rngFUNCT-1K2 g"
          using relat_1_th_26 sorry
        then have A3: "yy c=TARSKIR1 rngFUNCT-1K2 g"
          using A2 sorry
        then have "y inHIDDENR3 boolZFMISC-1K1 (rngFUNCT-1K2 g)"
           sorry
        then have A4: "y inHIDDENR3 domRELAT-1K1 (\<inverse>FUNCT-3K3 g)"
          using funct_3_def_2 sorry
        have "g \<inverse>FUNCT-1K6 yy c=TARSKIR1 rngFUNCT-1K2 f"
          using A1 A2 funct_3_th_4 sorry
        then have "g \<inverse>FUNCT-1K6 yy inTARSKIR2 boolZFMISC-1K1 (rngFUNCT-1K2 f)"
           sorry
        then have "g \<inverse>FUNCT-1K6 yy inTARSKIR2 domRELAT-1K1 (\<inverse>FUNCT-3K3 f)"
          using funct_3_def_2 sorry
        then have "\<inverse>FUNCT-3K3 g .FUNCT-1K1 y inTARSKIR2 domRELAT-1K1 (\<inverse>FUNCT-3K3 f)"
          using A3 funct_3_def_2 sorry
        thus "y inHIDDENR3 domRELAT-1K1 (\<inverse>FUNCT-3K3 f *FUNCT-1K3 \<inverse>FUNCT-3K3 g)"
          using A4 funct_1_th_11 sorry
      qed
      assume A5: "y inHIDDENR3 domRELAT-1K1 (\<inverse>FUNCT-3K3 f *FUNCT-1K3 \<inverse>FUNCT-3K3 g)"
      then have A6: "y inHIDDENR3 domRELAT-1K1 (\<inverse>FUNCT-3K3 g)"
        using funct_1_th_11 sorry
      have "\<inverse>FUNCT-3K3 g .FUNCT-1K1 y inTARSKIR2 domRELAT-1K1 (\<inverse>FUNCT-3K3 f)"
        using A5 funct_1_th_11 sorry
      then have "g \<inverse>FUNCT-1K6 yy inTARSKIR2 domRELAT-1K1 (\<inverse>FUNCT-3K3 f)"
        using A6 funct_3_th_21 sorry
      then have A7: "g \<inverse>FUNCT-1K6 yy inTARSKIR2 boolZFMISC-1K1 (rngFUNCT-1K2 f)"
        using funct_3_def_2 sorry
      have "y inHIDDENR3 boolZFMISC-1K1 (rngFUNCT-1K2 g)"
        using A6 funct_3_def_2 sorry
      then have "yy c=TARSKIR1 rngFUNCT-1K2 (g *FUNCT-1K3 f)"
        using A7 funct_3_th_5 sorry
      then have "y inHIDDENR3 boolZFMISC-1K1 (rngFUNCT-1K2 (g *FUNCT-1K3 f))"
         sorry
      thus "y inHIDDENR3 domRELAT-1K1 (\<inverse>FUNCT-3K3 (g *FUNCT-1K3 f))"
        using funct_3_def_2 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  then have A8: "domRELAT-1K1 (\<inverse>FUNCT-3K3 (g *FUNCT-1K3 f)) =XBOOLE-0R4 domRELAT-1K1 (\<inverse>FUNCT-3K3 f *FUNCT-1K3 \<inverse>FUNCT-3K3 g)"
    using tarski_th_2 sorry
  have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 (\<inverse>FUNCT-3K3 (g *FUNCT-1K3 f)) implies \<inverse>FUNCT-3K3 (g *FUNCT-1K3 f) .FUNCT-1K1 y =XBOOLE-0R4 (\<inverse>FUNCT-3K3 f *FUNCT-1K3 \<inverse>FUNCT-3K3 g).FUNCT-1K1 y"
  proof-
    have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 (\<inverse>FUNCT-3K3 (g *FUNCT-1K3 f)) implies \<inverse>FUNCT-3K3 (g *FUNCT-1K3 f) .FUNCT-1K1 y =HIDDENR1 (\<inverse>FUNCT-3K3 f *FUNCT-1K3 \<inverse>FUNCT-3K3 g).FUNCT-1K1 y"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A9: "y inHIDDENR3 domRELAT-1K1 (\<inverse>FUNCT-3K3 (g *FUNCT-1K3 f))"
      then have A10: "y inHIDDENR3 boolZFMISC-1K1 (rngFUNCT-1K2 (g *FUNCT-1K3 f))"
        using funct_3_def_2 sorry
      obtain yy where 
        [ty]:"yy be setHIDDENM2" and yyDef:"yy = y"
        using tarski_th_1 sorry
      have A11: "g \<inverse>FUNCT-1K6 yy c=TARSKIR1 rngFUNCT-1K2 f"
        using A1 funct_3_th_4 A10 sorry
      have "rngFUNCT-1K2 (g *FUNCT-1K3 f) c=TARSKIR1 rngFUNCT-1K2 g"
        using relat_1_th_26 sorry
      then have A12: "yy c=TARSKIR1 rngFUNCT-1K2 g"
        using A10 sorry
      then have "y inHIDDENR3 boolZFMISC-1K1 (rngFUNCT-1K2 g)"
         sorry
      then have A13: "y inHIDDENR3 domRELAT-1K1 (\<inverse>FUNCT-3K3 g)"
        using funct_3_def_2 sorry
      have "\<inverse>FUNCT-3K3 (g *FUNCT-1K3 f) .FUNCT-1K1 y =HIDDENR1 (g *FUNCT-1K3 f)\<inverse>FUNCT-1K6 yy"
        using A9 funct_3_th_21 sorry
      also have "... = f \<inverse>FUNCT-1K6 (g \<inverse>FUNCT-1K6 yy)"
        using relat_1_th_146 sorry
      also have "... = \<inverse>FUNCT-3K3 f .FUNCT-1K1 g \<inverse>FUNCT-1K6 yy"
        using A11 funct_3_def_2 sorry
      also have "... = \<inverse>FUNCT-3K3 f .FUNCT-1K1 (\<inverse>FUNCT-3K3 g .FUNCT-1K1 y)"
        using A12 funct_3_def_2 sorry
      also have "... = (\<inverse>FUNCT-3K3 f *FUNCT-1K3 \<inverse>FUNCT-3K3 g).FUNCT-1K1 y"
        using A13 funct_1_th_13 sorry
      finally show "\<inverse>FUNCT-3K3 (g *FUNCT-1K3 f) .FUNCT-1K1 y =HIDDENR1 (\<inverse>FUNCT-3K3 f *FUNCT-1K3 \<inverse>FUNCT-3K3 g).FUNCT-1K1 y"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus "\<inverse>FUNCT-3K3 (g *FUNCT-1K3 f) =FUNCT-1R1 \<inverse>FUNCT-3K3 f *FUNCT-1K3 \<inverse>FUNCT-3K3 g"
    using A8 sorry
qed "sorry"

mtheorem funct_3_th_35:
" for f be FunctionFUNCT-1M1 holds \<inverse>FUNCT-3K3 f be FunctionFUNCT-2M1-of(boolZFMISC-1K1 (rngFUNCT-1K2 f),boolZFMISC-1K1 (domRELAT-1K1 f))"
proof(rule ballI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  have "domRELAT-1K1 (\<inverse>FUNCT-3K3 f) =XBOOLE-0R4 boolZFMISC-1K1 (rngFUNCT-1K2 f) & rngFUNCT-1K2 (\<inverse>FUNCT-3K3 f) c=TARSKIR1 boolZFMISC-1K1 (domRELAT-1K1 f)"
    using funct_3_def_2 funct_3_th_22 sorry
  thus "\<inverse>FUNCT-3K3 f be FunctionFUNCT-2M1-of(boolZFMISC-1K1 (rngFUNCT-1K2 f),boolZFMISC-1K1 (domRELAT-1K1 f))"
    using funct_2_def_1 relset_1_th_4 sorry
qed "sorry"

mdef funct_3_def_3 ("chiFUNCT-3K4'( _ , _ ')" [0,0]228 ) where
  mlet "A be setHIDDENM2", "X be setHIDDENM2"
"func chiFUNCT-3K4(A,X) \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 X & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies (x inHIDDENR3 A implies it .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) & ( not x inHIDDENR3 A implies it .FUNCT-1K1 x =XBOOLE-0R4 0ORDINAL1K5))"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 X & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies (x inHIDDENR3 A implies it .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) & ( not x inHIDDENR3 A implies it .FUNCT-1K1 x =XBOOLE-0R4 0ORDINAL1K5))"
    proof-
      have " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 X & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X &  not ( not (x inHIDDENR3 A &  not VarFor1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) &  not ( not x inHIDDENR3 A &  not VarFor1 .FUNCT-1K1 x =XBOOLE-0R4 0ORDINAL1K5))))))"
      proof-
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. (Lamb1 inHIDDENR3 A implies Lamb2 =HIDDENR1 \<one>\<^sub>M) & ( not Lamb1 inHIDDENR3 A implies Lamb2 =HIDDENR1 0ORDINAL1K5)"
        have A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies ( ex y be objectHIDDENM1 st ?P(x,y))"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies  not ( for y be objectHIDDENM1 holds  not ((x inHIDDENR3 A implies y =HIDDENR1 \<one>\<^sub>M) & ( not x inHIDDENR3 A implies y =HIDDENR1 0ORDINAL1K5)))"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 X"
            have " not x inHIDDENR3 A implies ( ex y be setHIDDENM2 st (y =XBOOLE-0R4 {}XBOOLE-0K1 & (x inHIDDENR3 A implies y =XBOOLE-0R4 \<one>\<^sub>M)) & ( not x inHIDDENR3 A implies y =XBOOLE-0R4 {}XBOOLE-0K1))"
               sorry
            thus " not ( for y be objectHIDDENM1 holds  not ((x inHIDDENR3 A implies y =HIDDENR1 \<one>\<^sub>M) & ( not x inHIDDENR3 A implies y =HIDDENR1 0ORDINAL1K5)))"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have A2: " for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds (x inHIDDENR3 X & ?P(x,y1)) & ?P(x,y2) implies y1 =HIDDENR1 y2"
           sorry
        have " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 X & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies ?P(x,f .FUNCT-1K1 x))"
          using funct_1_sch_2 A2 A1 sorry
        thus " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 X & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X &  not ( not (x inHIDDENR3 A &  not VarFor1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) &  not ( not x inHIDDENR3 A &  not VarFor1 .FUNCT-1K1 x =XBOOLE-0R4 0ORDINAL1K5))))))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 X & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies (x inHIDDENR3 A implies it1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) & ( not x inHIDDENR3 A implies it1 .FUNCT-1K1 x =XBOOLE-0R4 0ORDINAL1K5))) & (domRELAT-1K1 it2 =XBOOLE-0R4 X & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies (x inHIDDENR3 A implies it2 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) & ( not x inHIDDENR3 A implies it2 .FUNCT-1K1 x =XBOOLE-0R4 0ORDINAL1K5))) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be FunctionFUNCT-1M1 holds  for f2 be FunctionFUNCT-1M1 holds domRELAT-1K1 f1 =XBOOLE-0R4 X & (( for x be objectHIDDENM1 holds x inHIDDENR3 X implies (x inHIDDENR3 A implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) & ( not x inHIDDENR3 A implies f1 .FUNCT-1K1 x =XBOOLE-0R4 0ORDINAL1K5)) & (domRELAT-1K1 f2 =XBOOLE-0R4 X & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies (x inHIDDENR3 A implies f2 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) & ( not x inHIDDENR3 A implies f2 .FUNCT-1K1 x =XBOOLE-0R4 0ORDINAL1K5)))) implies f1 =HIDDENR1 f2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix f1 assume [ty]: "f1 be FunctionFUNCT-1M1"
        fix f2 assume [ty]: "f2 be FunctionFUNCT-1M1"
        assume A3: "domRELAT-1K1 f1 =XBOOLE-0R4 X"
          and A4: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies (x inHIDDENR3 A implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) & ( not x inHIDDENR3 A implies f1 .FUNCT-1K1 x =XBOOLE-0R4 0ORDINAL1K5)"
          and A5: "domRELAT-1K1 f2 =XBOOLE-0R4 X"
          and A6: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies (x inHIDDENR3 A implies f2 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) & ( not x inHIDDENR3 A implies f2 .FUNCT-1K1 x =XBOOLE-0R4 0ORDINAL1K5)"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A7: "x inHIDDENR3 X"
          then have A8: " not x inHIDDENR3 A implies f1 .FUNCT-1K1 x =XBOOLE-0R4 0ORDINAL1K5 & f2 .FUNCT-1K1 x =XBOOLE-0R4 0ORDINAL1K5"
            using A4 A6 sorry
          have "x inHIDDENR3 A implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & f2 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M"
            using A4 A6 A7 sorry
          thus "f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x"
            using A8 sorry
        qed "sorry"
        thus "f1 =HIDDENR1 f2"
          using A3 A5 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem funct_3_th_36:
" for A be setHIDDENM2 holds  for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds chiFUNCT-3K4(A,X) .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M implies x inHIDDENR3 A"
proof-
  have " for A be setHIDDENM2 holds  for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds chiFUNCT-3K4(A,X) .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M implies x inHIDDENR3 A"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "chiFUNCT-3K4(A,X) .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M"
    have A2: "\<one>\<^sub>M =HIDDENR1 succORDINAL1K1 (0ORDINAL1K5)"
       sorry
    also have "... = {TARSKIK1 0ORDINAL1K5 }"
       sorry
    finally have "\<one>\<^sub>M =HIDDENR1 {TARSKIK1 0ORDINAL1K5 }"
       sorry
    show "x inHIDDENR3 A"
    proof-
      have cases: "x inHIDDENR3 X or  not x inHIDDENR3 X"
         sorry
      have case1: "x inHIDDENR3 X implies x inHIDDENR3 A"
      proof(rule impI)
        assume "x inHIDDENR3 X"
        thus "x inHIDDENR3 A"
          using A1 funct_3_def_3 sorry
      qed
      have case2: " not x inHIDDENR3 X implies x inHIDDENR3 A"
      proof(rule impI)
        assume " not x inHIDDENR3 X"
        then have " not x inHIDDENR3 domRELAT-1K1 (chiFUNCT-3K4(A,X))"
          using funct_3_def_3 sorry
        thus "x inHIDDENR3 A"
          using A1 funct_1_def_2 A2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_37:
" for x be setHIDDENM2 holds  for A be setHIDDENM2 holds  for X be setHIDDENM2 holds x inTARSKIR2 X \\SUBSET-1K6 A implies chiFUNCT-3K4(A,X) .FUNCT-1K1 x =XBOOLE-0R4 0ORDINAL1K5"
proof-
  have " for x be setHIDDENM2 holds  for A be setHIDDENM2 holds  for X be setHIDDENM2 holds x inTARSKIR2 X \\SUBSET-1K6 A implies chiFUNCT-3K4(A,X) .FUNCT-1K1 x =XBOOLE-0R4 0ORDINAL1K5"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix A assume [ty]: "A be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "x inTARSKIR2 X \\SUBSET-1K6 A"
    then have " not x inTARSKIR2 A"
      using xboole_0_def_5 sorry
    thus "chiFUNCT-3K4(A,X) .FUNCT-1K1 x =XBOOLE-0R4 0ORDINAL1K5"
      using A1 funct_3_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_38:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be setHIDDENM2 holds (A c=TARSKIR1 X & B c=TARSKIR1 X) & chiFUNCT-3K4(A,X) =FUNCT-1R1 chiFUNCT-3K4(B,X) implies A =XBOOLE-0R4 B"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be setHIDDENM2 holds A c=TARSKIR1 X & (B c=TARSKIR1 X & chiFUNCT-3K4(A,X) =FUNCT-1R1 chiFUNCT-3K4(B,X)) implies A =XBOOLE-0R4 B"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "A c=TARSKIR1 X"
      and A2: "B c=TARSKIR1 X"
      and A3: "chiFUNCT-3K4(A,X) =FUNCT-1R1 chiFUNCT-3K4(B,X)"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 A iff x inHIDDENR3 B"
    proof-
      have " for x be objectHIDDENM1 holds (x inHIDDENR3 A implies x inHIDDENR3 B) & (x inHIDDENR3 B implies x inHIDDENR3 A)"
      proof(rule ballI,rule conjMI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        show "x inHIDDENR3 A implies x inHIDDENR3 B"
        proof(rule impI)
          assume "x inHIDDENR3 A"
          then have "chiFUNCT-3K4(A,X) .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M"
            using A1 funct_3_def_3 sorry
          thus "x inHIDDENR3 B"
            using A3 funct_3_th_36 sorry
        qed
        assume "x inHIDDENR3 B"
        then have "chiFUNCT-3K4(B,X) .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M"
          using A2 funct_3_def_3 sorry
        thus "x inHIDDENR3 A"
          using A3 funct_3_th_36 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "A =XBOOLE-0R4 B"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_39:
" for A be setHIDDENM2 holds  for X be setHIDDENM2 holds rngFUNCT-1K2 (chiFUNCT-3K4(A,X)) c=TARSKIR1 {TARSKIK2 0ORDINAL1K5,\<one>\<^sub>M }"
proof-
  have " for A be setHIDDENM2 holds  for X be setHIDDENM2 holds rngFUNCT-1K2 (chiFUNCT-3K4(A,X)) c=TARSKIR1 {TARSKIK2 0ORDINAL1K5,\<one>\<^sub>M }"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 (chiFUNCT-3K4(A,X)) implies y inHIDDENR3 {TARSKIK2 0ORDINAL1K5,\<one>\<^sub>M }"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 rngFUNCT-1K2 (chiFUNCT-3K4(A,X))"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A1: "x inHIDDENR3 domRELAT-1K1 (chiFUNCT-3K4(A,X))"and A2: "y =HIDDENR1 chiFUNCT-3K4(A,X) .FUNCT-1K1 x"
        using funct_1_def_3 sorry
      have A3: "x inHIDDENR3 A or  not x inHIDDENR3 A"
         sorry
      have "x inHIDDENR3 X"
        using A1 funct_3_def_3 sorry
      then have "y =HIDDENR1 {}XBOOLE-0K1 or y =HIDDENR1 \<one>\<^sub>M"
        using A2 A3 funct_3_def_3 sorry
      thus "y inHIDDENR3 {TARSKIK2 0ORDINAL1K5,\<one>\<^sub>M }"
        using tarski_def_2 sorry
    qed "sorry"
    thus "rngFUNCT-1K2 (chiFUNCT-3K4(A,X)) c=TARSKIR1 {TARSKIK2 0ORDINAL1K5,\<one>\<^sub>M }"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_40:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,{TARSKIK2 0ORDINAL1K5,\<one>\<^sub>M }) holds f =FUNCT-1R1 chiFUNCT-3K4(f \<inverse>FUNCT-1K6 {TARSKIK1 \<one>\<^sub>M},X)"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,{TARSKIK2 0ORDINAL1K5,\<one>\<^sub>M }) holds f =FUNCT-1R1 chiFUNCT-3K4(f \<inverse>FUNCT-1K6 {TARSKIK1 \<one>\<^sub>M},X)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,{TARSKIK2 0ORDINAL1K5,\<one>\<^sub>M })"
    have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies (x inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 \<one>\<^sub>M} implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) & ( not x inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 \<one>\<^sub>M} implies f .FUNCT-1K1 x =XBOOLE-0R4 {}XBOOLE-0K1))"
    proof(rule conjMI,rule ballI,rule impI,rule conjMI,rule impI)
      show A1: "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
        using funct_2_def_1 sorry
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A2: "x inHIDDENR3 X"
      show "x inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 \<one>\<^sub>M} implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M"
      proof(rule impI)
        assume "x inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 \<one>\<^sub>M}"
        then have "f .FUNCT-1K1 x inTARSKIR2 {TARSKIK1 \<one>\<^sub>M}"
          using funct_1_def_7 sorry
        thus "f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M"
          using tarski_def_1 sorry
      qed
      assume " not x inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 \<one>\<^sub>M}"
      then have " not f .FUNCT-1K1 x inTARSKIR2 {TARSKIK1 \<one>\<^sub>M}"
        using A1 A2 funct_1_def_7 sorry
      then have A3: "rngFUNCT-1K2 f c=TARSKIR1 {TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M } & f .FUNCT-1K1 x <>HIDDENR2 \<one>\<^sub>M"
        using relat_1_def_19 tarski_def_1 sorry
      have "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f"
        using A1 A2 funct_1_def_3 sorry
      thus "f .FUNCT-1K1 x =XBOOLE-0R4 {}XBOOLE-0K1"
        using A3 tarski_def_2 sorry
    qed "sorry"
    thus "f =FUNCT-1R1 chiFUNCT-3K4(f \<inverse>FUNCT-1K6 {TARSKIK1 \<one>\<^sub>M},X)"
      using funct_3_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) FUNCT_3K5("chiFUNCT-3K5'( _ , _ ')" [0,0]228) where
  "chiFUNCT-3K5(A,X) \<equiv> chiFUNCT-3K4(A,X)"

mtheorem funct_3_add_2:
  mlet "A be setHIDDENM2", "X be setHIDDENM2"
"cluster chiFUNCT-3K4(A,X) as-term-is FunctionFUNCT-2M1-of(X,{TARSKIK2 0ORDINAL1K5,\<one>\<^sub>M })"
proof
(*coherence*)
  show "chiFUNCT-3K4(A,X) be FunctionFUNCT-2M1-of(X,{TARSKIK2 0ORDINAL1K5,\<one>\<^sub>M })"
  proof-
    have "domRELAT-1K1 (chiFUNCT-3K4(A,X)) =XBOOLE-0R4 X & rngFUNCT-1K2 (chiFUNCT-3K4(A,X)) c=TARSKIR1 {TARSKIK2 0ORDINAL1K5,\<one>\<^sub>M }"
      using funct_3_def_3 funct_3_th_39 sorry
    thus "chiFUNCT-3K4(A,X) be FunctionFUNCT-2M1-of(X,{TARSKIK2 0ORDINAL1K5,\<one>\<^sub>M })"
      using funct_2_def_1 relset_1_th_4 sorry
  qed
qed "sorry"

syntax FUNCT_3K6 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("inclFUNCT-3K6\<^bsub>'( _ ')\<^esub>  _ " [0,228]228)
translations "inclFUNCT-3K6\<^bsub>(Y)\<^esub> A" \<rightharpoonup> "idRELAT-1K7 A"

syntax FUNCT_3K7 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("inclFUNCT-3K7\<^bsub>'( _ ')\<^esub>  _ " [0,228]228)
translations "inclFUNCT-3K7\<^bsub>(Y)\<^esub> A" \<rightharpoonup> "idRELAT-1K7 A"

mtheorem funct_3_add_3:
  mlet "Y be setHIDDENM2", "A be SubsetSUBSET-1M2-of Y"
"cluster idRELAT-1K7 A as-term-is FunctionFUNCT-2M1-of(A,Y)"
proof
(*coherence*)
  show "idRELAT-1K7 A be FunctionFUNCT-2M1-of(A,Y)"
  proof-
    have A1: "rngFUNCT-1K2 (idRELAT-1K7 A) =XBOOLE-0R4 A & domRELSET-1K1\<^bsub>(A)\<^esub> (idRELAT-1K7 A) =XBOOLE-0R4 A"
       sorry
    show "idRELAT-1K7 A be FunctionFUNCT-2M1-of(A,Y)"
      using A1 funct_2_th_2 sorry
  qed
qed "sorry"

mtheorem funct_3_th_41:
" for Y be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of Y holds inclFUNCT-3K7\<^bsub>(Y)\<^esub> A =FUNCT-1R1 idRELAT-1K7 Y  |RELAT-1K8 A"
  using funct_3_th_1 sorry

mtheorem funct_3_th_42:
" for x be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of Y holds x inTARSKIR2 A implies inclFUNCT-3K7\<^bsub>(Y)\<^esub> A .FUNCT-1K1 x inTARSKIR2 Y"
proof-
  have " for x be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of Y holds x inTARSKIR2 A implies inclFUNCT-3K7\<^bsub>(Y)\<^esub> A .FUNCT-1K1 x inTARSKIR2 Y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of Y"
    assume A1: "x inTARSKIR2 A"
    have "domRELSET-1K1\<^bsub>(A)\<^esub> (inclFUNCT-3K7\<^bsub>(Y)\<^esub> A) =XBOOLE-0R4 A & rngFUNCT-1K2 (inclFUNCT-3K7\<^bsub>(Y)\<^esub> A) =XBOOLE-0R4 A"
       sorry
    then have "inclFUNCT-3K7\<^bsub>(Y)\<^esub> A .FUNCT-1K1 x inTARSKIR2 A"
      using A1 funct_1_def_3 sorry
    thus "inclFUNCT-3K7\<^bsub>(Y)\<^esub> A .FUNCT-1K1 x inTARSKIR2 Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef funct_3_def_4 ("pr1FUNCT-3K8'( _ , _ ')" [0,0]228 ) where
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"func pr1FUNCT-3K8(X,Y) \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies it .BINOP-1K1(x,y) =HIDDENR1 x)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies it .BINOP-1K1(x,y) =HIDDENR1 x)"
    proof-
      have " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ((x inHIDDENR3 X & y inHIDDENR3 Y) &  not VarFor1 .BINOP-1K1(x,y) =HIDDENR1 x))))"
      proof-
        let ?F = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb1"
        have " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies f .BINOP-1K1(x,y) =HIDDENR1 ?F(x,y))"
          using funct_3_sch_2 sorry
        thus " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ((x inHIDDENR3 X & y inHIDDENR3 Y) &  not VarFor1 .BINOP-1K1(x,y) =HIDDENR1 x))))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies it1 .BINOP-1K1(x,y) =HIDDENR1 x)) & (domRELAT-1K1 it2 =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies it2 .BINOP-1K1(x,y) =HIDDENR1 x)) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be FunctionFUNCT-1M1 holds  for f2 be FunctionFUNCT-1M1 holds domRELAT-1K1 f1 =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & (( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies f1 .BINOP-1K1(x,y) =HIDDENR1 x) & (domRELAT-1K1 f2 =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies f2 .BINOP-1K1(x,y) =HIDDENR1 x))) implies f1 =HIDDENR1 f2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix f1 assume [ty]: "f1 be FunctionFUNCT-1M1"
        fix f2 assume [ty]: "f2 be FunctionFUNCT-1M1"
        assume A1: "domRELAT-1K1 f1 =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]"
          and A2: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies f1 .BINOP-1K1(x,y) =HIDDENR1 x"
          and A3: "domRELAT-1K1 f2 =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]"
          and A4: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies f2 .BINOP-1K1(x,y) =HIDDENR1 x"
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies f1 .BINOP-1K1(x,y) =XBOOLE-0R4 f2 .BINOP-1K1(x,y)"
        proof(rule ballI,rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          assume A5: "x inHIDDENR3 X & y inHIDDENR3 Y"
          then have "f1 .BINOP-1K1(x,y) =HIDDENR1 x"
            using A2 sorry
          thus "f1 .BINOP-1K1(x,y) =XBOOLE-0R4 f2 .BINOP-1K1(x,y)"
            using A4 A5 sorry
        qed "sorry"
        thus "f1 =HIDDENR1 f2"
          using A1 A3 funct_3_th_6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef funct_3_def_5 ("pr2FUNCT-3K9'( _ , _ ')" [0,0]228 ) where
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"func pr2FUNCT-3K9(X,Y) \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies it .BINOP-1K1(x,y) =HIDDENR1 y)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies it .BINOP-1K1(x,y) =HIDDENR1 y)"
    proof-
      have " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ((x inHIDDENR3 X & y inHIDDENR3 Y) &  not VarFor1 .BINOP-1K1(x,y) =HIDDENR1 y))))"
      proof-
        let ?F = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2"
        have " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies f .BINOP-1K1(x,y) =HIDDENR1 ?F(x,y))"
          using funct_3_sch_2 sorry
        thus " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ((x inHIDDENR3 X & y inHIDDENR3 Y) &  not VarFor1 .BINOP-1K1(x,y) =HIDDENR1 y))))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies it1 .BINOP-1K1(x,y) =HIDDENR1 y)) & (domRELAT-1K1 it2 =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies it2 .BINOP-1K1(x,y) =HIDDENR1 y)) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be FunctionFUNCT-1M1 holds  for f2 be FunctionFUNCT-1M1 holds domRELAT-1K1 f1 =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & (( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies f1 .BINOP-1K1(x,y) =HIDDENR1 y) & (domRELAT-1K1 f2 =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies f2 .BINOP-1K1(x,y) =HIDDENR1 y))) implies f1 =HIDDENR1 f2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix f1 assume [ty]: "f1 be FunctionFUNCT-1M1"
        fix f2 assume [ty]: "f2 be FunctionFUNCT-1M1"
        assume A6: "domRELAT-1K1 f1 =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]"
          and A7: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies f1 .BINOP-1K1(x,y) =HIDDENR1 y"
          and A8: "domRELAT-1K1 f2 =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]"
          and A9: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies f2 .BINOP-1K1(x,y) =HIDDENR1 y"
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies f1 .BINOP-1K1(x,y) =XBOOLE-0R4 f2 .BINOP-1K1(x,y)"
        proof(rule ballI,rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          assume A10: "x inHIDDENR3 X & y inHIDDENR3 Y"
          then have "f1 .BINOP-1K1(x,y) =HIDDENR1 y"
            using A7 sorry
          thus "f1 .BINOP-1K1(x,y) =XBOOLE-0R4 f2 .BINOP-1K1(x,y)"
            using A9 A10 sorry
        qed "sorry"
        thus "f1 =HIDDENR1 f2"
          using A6 A8 funct_3_th_6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem funct_3_th_43:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds rngFUNCT-1K2 (pr1FUNCT-3K8(X,Y)) c=TARSKIR1 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds rngFUNCT-1K2 (pr1FUNCT-3K8(X,Y)) c=TARSKIR1 X"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (pr1FUNCT-3K8(X,Y)) implies x inHIDDENR3 X"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 rngFUNCT-1K2 (pr1FUNCT-3K8(X,Y))"
      then obtain p where
        [ty]:"p be objectHIDDENM1" and 
        A1: "p inHIDDENR3 domRELAT-1K1 (pr1FUNCT-3K8(X,Y))"and A2: "x =HIDDENR1 pr1FUNCT-3K8(X,Y) .FUNCT-1K1 p"
        using funct_1_def_3 sorry
      have "p inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
        using A1 funct_3_def_4 sorry
      then obtain x1 y1 where
        [ty]:"x1 be objectHIDDENM1" "y1 be objectHIDDENM1" and 
        A3: "x1 inHIDDENR3 X & y1 inHIDDENR3 Y"and A4: "p =HIDDENR1 [TARSKIK4 x1,y1 ]"
        using zfmisc_1_def_2 sorry
      have "x =HIDDENR1 pr1FUNCT-3K8(X,Y) .BINOP-1K1(x1,y1)"
        using A2 A4 sorry
      thus "x inHIDDENR3 X"
        using A3 funct_3_def_4 sorry
    qed "sorry"
    thus "rngFUNCT-1K2 (pr1FUNCT-3K8(X,Y)) c=TARSKIR1 X"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_44:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds Y <>HIDDENR2 {}XBOOLE-0K1 implies rngFUNCT-1K2 (pr1FUNCT-3K8(X,Y)) =XBOOLE-0R4 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds Y <>HIDDENR2 {}XBOOLE-0K1 implies rngFUNCT-1K2 (pr1FUNCT-3K8(X,Y)) =XBOOLE-0R4 X"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    let ?y = "the ElementSUBSET-1M1-of Y"
    assume A1: "Y <>HIDDENR2 {}XBOOLE-0K1"
    have A2: "X c=TARSKIR1 rngFUNCT-1K2 (pr1FUNCT-3K8(X,Y))"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 rngFUNCT-1K2 (pr1FUNCT-3K8(X,Y))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A3: "x inHIDDENR3 X"
        then have "[TARSKIK4 x,?y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
          using A1 zfmisc_1_th_87 sorry
        then have A4: "[TARSKIK4 x,?y ] inHIDDENR3 domRELAT-1K1 (pr1FUNCT-3K8(X,Y))"
          using funct_3_def_4 sorry
        have "pr1FUNCT-3K8(X,Y) .BINOP-1K1(x,?y) =HIDDENR1 x"
          using A1 A3 funct_3_def_4 sorry
        thus "x inHIDDENR3 rngFUNCT-1K2 (pr1FUNCT-3K8(X,Y))"
          using A4 funct_1_def_3 sorry
      qed "sorry"
      thus "X c=TARSKIR1 rngFUNCT-1K2 (pr1FUNCT-3K8(X,Y))"
        using tarski_def_3 sorry
    qed
    have "rngFUNCT-1K2 (pr1FUNCT-3K8(X,Y)) c=TARSKIR1 X"
      using funct_3_th_43 sorry
    thus "rngFUNCT-1K2 (pr1FUNCT-3K8(X,Y)) =XBOOLE-0R4 X"
      using A2 xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_45:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds rngFUNCT-1K2 (pr2FUNCT-3K9(X,Y)) c=TARSKIR1 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds rngFUNCT-1K2 (pr2FUNCT-3K9(X,Y)) c=TARSKIR1 Y"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 (pr2FUNCT-3K9(X,Y)) implies y inHIDDENR3 Y"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 rngFUNCT-1K2 (pr2FUNCT-3K9(X,Y))"
      then obtain p where
        [ty]:"p be objectHIDDENM1" and 
        A1: "p inHIDDENR3 domRELAT-1K1 (pr2FUNCT-3K9(X,Y))"and A2: "y =HIDDENR1 pr2FUNCT-3K9(X,Y) .FUNCT-1K1 p"
        using funct_1_def_3 sorry
      have "p inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
        using A1 funct_3_def_5 sorry
      then obtain x1 y1 where
        [ty]:"x1 be objectHIDDENM1" "y1 be objectHIDDENM1" and 
        A3: "x1 inHIDDENR3 X & y1 inHIDDENR3 Y"and A4: "p =HIDDENR1 [TARSKIK4 x1,y1 ]"
        using zfmisc_1_def_2 sorry
      have "y =HIDDENR1 pr2FUNCT-3K9(X,Y) .BINOP-1K1(x1,y1)"
        using A2 A4 sorry
      thus "y inHIDDENR3 Y"
        using A3 funct_3_def_5 sorry
    qed "sorry"
    thus "rngFUNCT-1K2 (pr2FUNCT-3K9(X,Y)) c=TARSKIR1 Y"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_46:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X <>HIDDENR2 {}XBOOLE-0K1 implies rngFUNCT-1K2 (pr2FUNCT-3K9(X,Y)) =XBOOLE-0R4 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X <>HIDDENR2 {}XBOOLE-0K1 implies rngFUNCT-1K2 (pr2FUNCT-3K9(X,Y)) =XBOOLE-0R4 Y"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    let ?x = "the ElementSUBSET-1M1-of X"
    assume A1: "X <>HIDDENR2 {}XBOOLE-0K1"
    have A2: "Y c=TARSKIR1 rngFUNCT-1K2 (pr2FUNCT-3K9(X,Y))"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 Y implies y inHIDDENR3 rngFUNCT-1K2 (pr2FUNCT-3K9(X,Y))"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A3: "y inHIDDENR3 Y"
        then have "[TARSKIK4 ?x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
          using A1 zfmisc_1_th_87 sorry
        then have A4: "[TARSKIK4 ?x,y ] inHIDDENR3 domRELAT-1K1 (pr2FUNCT-3K9(X,Y))"
          using funct_3_def_5 sorry
        have "pr2FUNCT-3K9(X,Y) .BINOP-1K1(?x,y) =HIDDENR1 y"
          using A1 A3 funct_3_def_5 sorry
        thus "y inHIDDENR3 rngFUNCT-1K2 (pr2FUNCT-3K9(X,Y))"
          using A4 funct_1_def_3 sorry
      qed "sorry"
      thus "Y c=TARSKIR1 rngFUNCT-1K2 (pr2FUNCT-3K9(X,Y))"
        using tarski_def_3 sorry
    qed
    have "rngFUNCT-1K2 (pr2FUNCT-3K9(X,Y)) c=TARSKIR1 Y"
      using funct_3_th_45 sorry
    thus "rngFUNCT-1K2 (pr2FUNCT-3K9(X,Y)) =XBOOLE-0R4 Y"
      using A2 xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) FUNCT_3K10("pr1FUNCT-3K10'( _ , _ ')" [0,0]228) where
  "pr1FUNCT-3K10(X,Y) \<equiv> pr1FUNCT-3K8(X,Y)"

mtheorem funct_3_add_4:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"cluster pr1FUNCT-3K8(X,Y) as-term-is FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,Y :],X)"
proof
(*coherence*)
  show "pr1FUNCT-3K8(X,Y) be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,Y :],X)"
  proof-
    show "pr1FUNCT-3K8(X,Y) be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,Y :],X)"
    proof-
      have cases: "(X =XBOOLE-0R4 {}XBOOLE-0K1 implies [:ZFMISC-1K2 X,Y :] =RELAT-1R1 {}XBOOLE-0K1) or X =XBOOLE-0R4 {}XBOOLE-0K1 & [:ZFMISC-1K2 X,Y :] <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "(X =XBOOLE-0R4 {}XBOOLE-0K1 implies [:ZFMISC-1K2 X,Y :] =RELAT-1R1 {}XBOOLE-0K1) implies pr1FUNCT-3K8(X,Y) be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,Y :],X)"
      proof(rule impI)
        assume "X =XBOOLE-0R4 {}XBOOLE-0K1 implies [:ZFMISC-1K2 X,Y :] =RELAT-1R1 {}XBOOLE-0K1"
        have "domRELAT-1K1 (pr1FUNCT-3K8(X,Y)) =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & rngFUNCT-1K2 (pr1FUNCT-3K8(X,Y)) c=TARSKIR1 X"
          using funct_3_def_4 funct_3_th_43 sorry
        thus "pr1FUNCT-3K8(X,Y) be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,Y :],X)"
          using funct_2_th_2 sorry
      qed
      have case2: "X =XBOOLE-0R4 {}XBOOLE-0K1 & [:ZFMISC-1K2 X,Y :] <>HIDDENR2 {}XBOOLE-0K1 implies pr1FUNCT-3K8(X,Y) be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,Y :],X)"
      proof(rule impI)
        assume "X =XBOOLE-0R4 {}XBOOLE-0K1 & [:ZFMISC-1K2 X,Y :] <>HIDDENR2 {}XBOOLE-0K1"
        thus "pr1FUNCT-3K8(X,Y) be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,Y :],X)"
          using zfmisc_1_th_90 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
qed "sorry"

abbreviation(input) FUNCT_3K11("pr2FUNCT-3K11'( _ , _ ')" [0,0]228) where
  "pr2FUNCT-3K11(X,Y) \<equiv> pr2FUNCT-3K9(X,Y)"

mtheorem funct_3_add_5:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"cluster pr2FUNCT-3K9(X,Y) as-term-is FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,Y :],Y)"
proof
(*coherence*)
  show "pr2FUNCT-3K9(X,Y) be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,Y :],Y)"
  proof-
    show "pr2FUNCT-3K9(X,Y) be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,Y :],Y)"
    proof-
      have cases: "(Y =XBOOLE-0R4 {}XBOOLE-0K1 implies [:ZFMISC-1K2 X,Y :] =RELAT-1R1 {}XBOOLE-0K1) or Y =XBOOLE-0R4 {}XBOOLE-0K1 & [:ZFMISC-1K2 X,Y :] <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "(Y =XBOOLE-0R4 {}XBOOLE-0K1 implies [:ZFMISC-1K2 X,Y :] =RELAT-1R1 {}XBOOLE-0K1) implies pr2FUNCT-3K9(X,Y) be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,Y :],Y)"
      proof(rule impI)
        assume "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies [:ZFMISC-1K2 X,Y :] =RELAT-1R1 {}XBOOLE-0K1"
        have "domRELAT-1K1 (pr2FUNCT-3K9(X,Y)) =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & rngFUNCT-1K2 (pr2FUNCT-3K9(X,Y)) c=TARSKIR1 Y"
          using funct_3_def_5 funct_3_th_45 sorry
        thus "pr2FUNCT-3K9(X,Y) be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,Y :],Y)"
          using funct_2_th_2 sorry
      qed
      have case2: "Y =XBOOLE-0R4 {}XBOOLE-0K1 & [:ZFMISC-1K2 X,Y :] <>HIDDENR2 {}XBOOLE-0K1 implies pr2FUNCT-3K9(X,Y) be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,Y :],Y)"
      proof(rule impI)
        assume "Y =XBOOLE-0R4 {}XBOOLE-0K1 & [:ZFMISC-1K2 X,Y :] <>HIDDENR2 {}XBOOLE-0K1"
        thus "pr2FUNCT-3K9(X,Y) be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,Y :],Y)"
          using zfmisc_1_th_90 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
qed "sorry"

mdef funct_3_def_6 ("deltaFUNCT-3K12  _ " [228]228 ) where
  mlet "X be setHIDDENM2"
"func deltaFUNCT-3K12 X \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 X & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies it .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 x,x ])"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 X & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies it .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 x,x ])"
    proof-
      have " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 X & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X &  not VarFor1 .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 x,x ]))))"
      proof-
        let ?F = "\<lambda>Lamb1. [TARSKIK4 Lamb1,Lamb1 ]"
        have " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 X & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies f .FUNCT-1K1 x =HIDDENR1 ?F(x))"
          using funct_1_sch_3 sorry
        thus " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 X & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X &  not VarFor1 .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 x,x ]))))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 X & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies it1 .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 x,x ])) & (domRELAT-1K1 it2 =XBOOLE-0R4 X & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies it2 .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 x,x ])) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be FunctionFUNCT-1M1 holds  for f2 be FunctionFUNCT-1M1 holds domRELAT-1K1 f1 =XBOOLE-0R4 X & (( for x be objectHIDDENM1 holds x inHIDDENR3 X implies f1 .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 x,x ]) & (domRELAT-1K1 f2 =XBOOLE-0R4 X & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies f2 .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 x,x ]))) implies f1 =HIDDENR1 f2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix f1 assume [ty]: "f1 be FunctionFUNCT-1M1"
        fix f2 assume [ty]: "f2 be FunctionFUNCT-1M1"
        assume A1: "domRELAT-1K1 f1 =XBOOLE-0R4 X"
          and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies f1 .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 x,x ]"
          and A3: "domRELAT-1K1 f2 =XBOOLE-0R4 X"
          and A4: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies f2 .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 x,x ]"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A5: "x inHIDDENR3 X"
          then have "f1 .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 x,x ]"
            using A2 sorry
          thus "f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x"
            using A4 A5 sorry
        qed "sorry"
        thus "f1 =HIDDENR1 f2"
          using A1 A3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem funct_3_th_47:
" for X be setHIDDENM2 holds rngFUNCT-1K2 (deltaFUNCT-3K12 X) c=TARSKIR1 [:ZFMISC-1K2 X,X :]"
proof-
  have " for X be setHIDDENM2 holds rngFUNCT-1K2 (deltaFUNCT-3K12 X) c=TARSKIR1 [:ZFMISC-1K2 X,X :]"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 (deltaFUNCT-3K12 X) implies y inHIDDENR3 [:ZFMISC-1K2 X,X :]"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 rngFUNCT-1K2 (deltaFUNCT-3K12 X)"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A1: "x inHIDDENR3 domRELAT-1K1 (deltaFUNCT-3K12 X)"and A2: "y =HIDDENR1 deltaFUNCT-3K12 X .FUNCT-1K1 x"
        using funct_1_def_3 sorry
      have A3: "x inHIDDENR3 X"
        using A1 funct_3_def_6 sorry
      then have "y =HIDDENR1 [TARSKIK4 x,x ]"
        using A2 funct_3_def_6 sorry
      thus "y inHIDDENR3 [:ZFMISC-1K2 X,X :]"
        using A3 zfmisc_1_th_87 sorry
    qed "sorry"
    thus "rngFUNCT-1K2 (deltaFUNCT-3K12 X) c=TARSKIR1 [:ZFMISC-1K2 X,X :]"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) FUNCT_3K13("deltaFUNCT-3K13  _ " [228]228) where
  "deltaFUNCT-3K13 X \<equiv> deltaFUNCT-3K12 X"

mtheorem funct_3_add_6:
  mlet "X be setHIDDENM2"
"cluster deltaFUNCT-3K12 X as-term-is FunctionFUNCT-2M1-of(X,[:ZFMISC-1K2 X,X :])"
proof
(*coherence*)
  show "deltaFUNCT-3K12 X be FunctionFUNCT-2M1-of(X,[:ZFMISC-1K2 X,X :])"
  proof-
    have "domRELAT-1K1 (deltaFUNCT-3K12 X) =XBOOLE-0R4 X & rngFUNCT-1K2 (deltaFUNCT-3K12 X) c=TARSKIR1 [:ZFMISC-1K2 X,X :]"
      using funct_3_def_6 funct_3_th_47 sorry
    thus "deltaFUNCT-3K12 X be FunctionFUNCT-2M1-of(X,[:ZFMISC-1K2 X,X :])"
      using funct_2_th_2 sorry
  qed
qed "sorry"

mdef funct_3_def_7 ("<:FUNCT-3K14 _ , _ :>" [0,0]164 ) where
  mlet "f be FunctionFUNCT-1M1", "g be FunctionFUNCT-1M1"
"func <:FUNCT-3K14 f,g :> \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 x ])"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 x ])"
    proof-
      have " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 VarFor1 &  not VarFor1 .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 x ]))))"
      proof-
        let ?F = "\<lambda>Lamb1. [TARSKIK4 f .FUNCT-1K1 Lamb1,g .FUNCT-1K1 Lamb1 ]"
        have " ex fg be FunctionFUNCT-1M1 st domRELAT-1K1 fg =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g implies fg .FUNCT-1K1 x =HIDDENR1 ?F(x))"
          using funct_1_sch_3 sorry
        thus " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 VarFor1 &  not VarFor1 .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 x ]))))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 x ])) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 x ])) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be FunctionFUNCT-1M1 holds  for f2 be FunctionFUNCT-1M1 holds domRELAT-1K1 f1 =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g & (( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f1 implies f1 .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 x ]) & (domRELAT-1K1 f2 =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f2 implies f2 .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 x ]))) implies f1 =HIDDENR1 f2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix f1 assume [ty]: "f1 be FunctionFUNCT-1M1"
        fix f2 assume [ty]: "f2 be FunctionFUNCT-1M1"
        assume A1: "domRELAT-1K1 f1 =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g"
          and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f1 implies f1 .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 x ]"
          and A3: "domRELAT-1K1 f2 =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g"
          and A4: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f2 implies f2 .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 x ]"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g implies f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A5: "x inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g"
          then have "f1 .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 x ]"
            using A1 A2 sorry
          thus "f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x"
            using A3 A4 A5 sorry
        qed "sorry"
        thus "f1 =HIDDENR1 f2"
          using A1 A3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem funct_3_cl_1:
  mlet "f be emptyXBOOLE-0V1\<bar>FunctionFUNCT-1M1", "g be FunctionFUNCT-1M1"
"cluster <:FUNCT-3K14 f,g :> as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "<:FUNCT-3K14 f,g :> be emptyXBOOLE-0V1"
  proof-
    have "domRELAT-1K1 f =FUNCT-1R1 {}XBOOLE-0K1"
       sorry
    then have "domRELAT-1K1 (<:FUNCT-3K14 f,g :>) =XBOOLE-0R4 {}XBOOLE-0K1 /\\XBOOLE-0K3 domRELAT-1K1 g"
      using funct_3_def_7 sorry
    thus "<:FUNCT-3K14 f,g :> be emptyXBOOLE-0V1"
       sorry
  qed
qed "sorry"

mtheorem funct_3_cl_2:
  mlet "f be emptyXBOOLE-0V1\<bar>FunctionFUNCT-1M1", "g be FunctionFUNCT-1M1"
"cluster <:FUNCT-3K14 g,f :> as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "<:FUNCT-3K14 g,f :> be emptyXBOOLE-0V1"
  proof-
    have "domRELAT-1K1 f =FUNCT-1R1 {}XBOOLE-0K1"
       sorry
    then have "domRELAT-1K1 (<:FUNCT-3K14 g,f :>) =XBOOLE-0R4 {}XBOOLE-0K1 /\\XBOOLE-0K3 domRELAT-1K1 g"
      using funct_3_def_7 sorry
    thus "<:FUNCT-3K14 g,f :> be emptyXBOOLE-0V1"
       sorry
  qed
qed "sorry"

mtheorem funct_3_th_48:
" for x be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds x inTARSKIR2 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g implies (<:FUNCT-3K14 f,g :>).FUNCT-1K1 x =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 x ]"
proof-
  have " for x be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds x inTARSKIR2 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g implies (<:FUNCT-3K14 f,g :>).FUNCT-1K1 x =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 x ]"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume "x inTARSKIR2 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g"
    then have "x inTARSKIR2 domRELAT-1K1 (<:FUNCT-3K14 f,g :>)"
      using funct_3_def_7 sorry
    thus "(<:FUNCT-3K14 f,g :>).FUNCT-1K1 x =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 x ]"
      using funct_3_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_49:
" for x be setHIDDENM2 holds  for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds (domRELAT-1K1 f =XBOOLE-0R4 X & domRELAT-1K1 g =XBOOLE-0R4 X) & x inTARSKIR2 X implies (<:FUNCT-3K14 f,g :>).FUNCT-1K1 x =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 x ]"
proof-
  have " for x be setHIDDENM2 holds  for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds (domRELAT-1K1 f =XBOOLE-0R4 X & domRELAT-1K1 g =XBOOLE-0R4 X) & x inTARSKIR2 X implies (<:FUNCT-3K14 f,g :>).FUNCT-1K1 x =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 x ]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume "(domRELAT-1K1 f =XBOOLE-0R4 X & domRELAT-1K1 g =XBOOLE-0R4 X) & x inTARSKIR2 X"
    then have "x inTARSKIR2 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g"
       sorry
    then have "x inTARSKIR2 domRELAT-1K1 (<:FUNCT-3K14 f,g :>)"
      using funct_3_def_7 sorry
    thus "(<:FUNCT-3K14 f,g :>).FUNCT-1K1 x =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 x ]"
      using funct_3_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_50:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 X & domRELAT-1K1 g =XBOOLE-0R4 X implies domRELAT-1K1 (<:FUNCT-3K14 f,g :>) =XBOOLE-0R4 X"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  not ((domRELAT-1K1 f =XBOOLE-0R4 X & domRELAT-1K1 g =XBOOLE-0R4 X) &  not domRELAT-1K1 (<:FUNCT-3K14 f,g :>) =XBOOLE-0R4 X)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    have "domRELAT-1K1 (<:FUNCT-3K14 f,g :>) =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g"
      using funct_3_def_7 sorry
    thus " not ((domRELAT-1K1 f =XBOOLE-0R4 X & domRELAT-1K1 g =XBOOLE-0R4 X) &  not domRELAT-1K1 (<:FUNCT-3K14 f,g :>) =XBOOLE-0R4 X)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_51:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds rngFUNCT-1K2 (<:FUNCT-3K14 f,g :>) c=TARSKIR1 [:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 g :]"
proof(rule ballI,rule ballI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  fix g assume [ty]: "g be FunctionFUNCT-1M1"
  have " for q be objectHIDDENM1 holds q inHIDDENR3 rngFUNCT-1K2 (<:FUNCT-3K14 f,g :>) implies q inHIDDENR3 [:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 g :]"
  proof(rule ballI,rule impI)
    fix q assume [ty]: "q be objectHIDDENM1"
    assume "q inHIDDENR3 rngFUNCT-1K2 (<:FUNCT-3K14 f,g :>)"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A1: "x inHIDDENR3 domRELAT-1K1 (<:FUNCT-3K14 f,g :>)"and A2: "q =HIDDENR1 (<:FUNCT-3K14 f,g :>).FUNCT-1K1 x"
      using funct_1_def_3 sorry
    have A3: "x inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g"
      using A1 funct_3_def_7 sorry
    then have "x inHIDDENR3 domRELAT-1K1 f"
      using xboole_0_def_4 sorry
    then have A4: "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f"
      using funct_1_def_3 sorry
    have "x inHIDDENR3 domRELAT-1K1 g"
      using A3 xboole_0_def_4 sorry
    then have A5: "g .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 g"
      using funct_1_def_3 sorry
    have "q =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 x ]"
      using A1 A2 funct_3_def_7 sorry
    thus "q inHIDDENR3 [:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 g :]"
      using A4 A5 zfmisc_1_th_87 sorry
  qed "sorry"
  thus "rngFUNCT-1K2 (<:FUNCT-3K14 f,g :>) c=TARSKIR1 [:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 g :]"
    using tarski_def_3 sorry
qed "sorry"

mtheorem funct_3_th_52:
" for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds (domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g & rngFUNCT-1K2 f c=TARSKIR1 Y) & rngFUNCT-1K2 g c=TARSKIR1 Z implies pr1FUNCT-3K10(Y,Z) *FUNCT-1K3 (<:FUNCT-3K14 f,g :>) =FUNCT-1R1 f & pr2FUNCT-3K11(Y,Z) *FUNCT-1K3 (<:FUNCT-3K14 f,g :>) =FUNCT-1R1 g"
proof-
  have " for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g & (rngFUNCT-1K2 f c=TARSKIR1 Y & rngFUNCT-1K2 g c=TARSKIR1 Z) implies pr1FUNCT-3K10(Y,Z) *FUNCT-1K3 (<:FUNCT-3K14 f,g :>) =FUNCT-1R1 f & pr2FUNCT-3K11(Y,Z) *FUNCT-1K3 (<:FUNCT-3K14 f,g :>) =FUNCT-1R1 g"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g"
      and A2: "rngFUNCT-1K2 f c=TARSKIR1 Y & rngFUNCT-1K2 g c=TARSKIR1 Z"
    have A3: "[:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 g :] c=RELAT-1R2 [:ZFMISC-1K2 Y,Z :]"
      using A2 zfmisc_1_th_96 sorry
    have A4: "rngFUNCT-1K2 (<:FUNCT-3K14 f,g :>) c=TARSKIR1 [:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 g :]"
      using funct_3_th_51 sorry
    have "domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Y,Z :])\<^esub> (pr1FUNCT-3K10(Y,Z)) =RELAT-1R1 [:ZFMISC-1K2 Y,Z :]"
      using funct_3_def_4 sorry
    then have A5: "domRELAT-1K1 (pr1FUNCT-3K10(Y,Z) *FUNCT-1K3 (<:FUNCT-3K14 f,g :>)) =XBOOLE-0R4 domRELAT-1K1 (<:FUNCT-3K14 f,g :>)"
      using A3 A4 relat_1_th_27 xboole_1_th_1 sorry
    then have A6: "domRELAT-1K1 (pr1FUNCT-3K10(Y,Z) *FUNCT-1K3 (<:FUNCT-3K14 f,g :>)) =XBOOLE-0R4 domRELAT-1K1 f"
      using A1 funct_3_th_50 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies (pr1FUNCT-3K10(Y,Z) *FUNCT-1K3 (<:FUNCT-3K14 f,g :>)).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies (pr1FUNCT-3K10(Y,Z) *FUNCT-1K3 (<:FUNCT-3K14 f,g :>)).FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A7: "x inHIDDENR3 domRELAT-1K1 f"
        then have A8: "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f & g .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 g"
          using A1 funct_1_def_3 sorry
        have "(pr1FUNCT-3K10(Y,Z) *FUNCT-1K3 (<:FUNCT-3K14 f,g :>)).FUNCT-1K1 x =HIDDENR1 pr1FUNCT-3K10(Y,Z) .FUNCT-1K1 ((<:FUNCT-3K14 f,g :>).FUNCT-1K1 x)"
          using A6 A7 funct_1_th_12 sorry
        also have "... = pr1FUNCT-3K10(Y,Z) .BINOP-1K1(f .FUNCT-1K1 x,g .FUNCT-1K1 x)"
          using A5 A6 A7 funct_3_def_7 sorry
        also have "... = f .FUNCT-1K1 x"
          using A2 A8 funct_3_def_4 sorry
        finally show "(pr1FUNCT-3K10(Y,Z) *FUNCT-1K3 (<:FUNCT-3K14 f,g :>)).FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 x"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "pr1FUNCT-3K10(Y,Z) *FUNCT-1K3 (<:FUNCT-3K14 f,g :>) =FUNCT-1R1 f"
      using A6 sorry
    have "domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Y,Z :])\<^esub> (pr2FUNCT-3K11(Y,Z)) =RELAT-1R1 [:ZFMISC-1K2 Y,Z :]"
      using funct_3_def_5 sorry
    then have A9: "domRELAT-1K1 (pr2FUNCT-3K11(Y,Z) *FUNCT-1K3 (<:FUNCT-3K14 f,g :>)) =XBOOLE-0R4 domRELAT-1K1 (<:FUNCT-3K14 f,g :>)"
      using A3 A4 relat_1_th_27 xboole_1_th_1 sorry
    then have A10: "domRELAT-1K1 (pr2FUNCT-3K11(Y,Z) *FUNCT-1K3 (<:FUNCT-3K14 f,g :>)) =XBOOLE-0R4 domRELAT-1K1 g"
      using A1 funct_3_th_50 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies (pr2FUNCT-3K11(Y,Z) *FUNCT-1K3 (<:FUNCT-3K14 f,g :>)).FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies (pr2FUNCT-3K11(Y,Z) *FUNCT-1K3 (<:FUNCT-3K14 f,g :>)).FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A11: "x inHIDDENR3 domRELAT-1K1 g"
        then have A12: "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f & g .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 g"
          using A1 funct_1_def_3 sorry
        have "(pr2FUNCT-3K11(Y,Z) *FUNCT-1K3 (<:FUNCT-3K14 f,g :>)).FUNCT-1K1 x =HIDDENR1 pr2FUNCT-3K11(Y,Z) .FUNCT-1K1 ((<:FUNCT-3K14 f,g :>).FUNCT-1K1 x)"
          using A10 A11 funct_1_th_12 sorry
        also have "... = pr2FUNCT-3K11(Y,Z) .BINOP-1K1(f .FUNCT-1K1 x,g .FUNCT-1K1 x)"
          using A9 A10 A11 funct_3_def_7 sorry
        also have "... = g .FUNCT-1K1 x"
          using A2 A12 funct_3_def_5 sorry
        finally show "(pr2FUNCT-3K11(Y,Z) *FUNCT-1K3 (<:FUNCT-3K14 f,g :>)).FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "pr2FUNCT-3K11(Y,Z) *FUNCT-1K3 (<:FUNCT-3K14 f,g :>) =FUNCT-1R1 g"
      using A10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_53:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds <:FUNCT-3K14 pr1FUNCT-3K10(X,Y),pr2FUNCT-3K11(X,Y) :> =FUNCT-1R1 idRELAT-1K7 ([:ZFMISC-1K2 X,Y :])"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds <:FUNCT-3K14 pr1FUNCT-3K10(X,Y),pr2FUNCT-3K11(X,Y) :> =FUNCT-1R1 idRELAT-1K7 ([:ZFMISC-1K2 X,Y :])"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "domRELSET-1K1\<^bsub>([:ZFMISC-1K2 X,Y :])\<^esub> (pr1FUNCT-3K10(X,Y)) =RELAT-1R1 [:ZFMISC-1K2 X,Y :] & domRELSET-1K1\<^bsub>([:ZFMISC-1K2 X,Y :])\<^esub> (pr2FUNCT-3K11(X,Y)) =RELAT-1R1 [:ZFMISC-1K2 X,Y :]"
      using funct_3_def_4 funct_3_def_5 sorry
    then have A1: "domRELAT-1K1 (<:FUNCT-3K14 pr1FUNCT-3K10(X,Y),pr2FUNCT-3K11(X,Y) :>) =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]"
      using funct_3_th_50 sorry
    have A2: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies (<:FUNCT-3K14 pr1FUNCT-3K10(X,Y),pr2FUNCT-3K11(X,Y) :>).BINOP-1K1(x,y) =XBOOLE-0R4 idRELAT-1K7 ([:ZFMISC-1K2 X,Y :]) .BINOP-1K1(x,y)"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies (<:FUNCT-3K14 pr1FUNCT-3K10(X,Y),pr2FUNCT-3K11(X,Y) :>).BINOP-1K1(x,y) =HIDDENR1 idRELAT-1K7 ([:ZFMISC-1K2 X,Y :]) .BINOP-1K1(x,y)"
      proof(rule ballI,rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A3: "x inHIDDENR3 X & y inHIDDENR3 Y"
        then have A4: "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
          using zfmisc_1_th_87 sorry
        then have "(<:FUNCT-3K14 pr1FUNCT-3K10(X,Y),pr2FUNCT-3K11(X,Y) :>).BINOP-1K1(x,y) =HIDDENR1 [TARSKIK4 pr1FUNCT-3K10(X,Y) .BINOP-1K1(x,y),pr2FUNCT-3K11(X,Y) .BINOP-1K1(x,y) ]"
          using A1 funct_3_def_7 sorry
        also have "... = [TARSKIK4 x,pr2FUNCT-3K11(X,Y) .BINOP-1K1(x,y) ]"
          using A3 funct_3_def_4 sorry
        also have "... = [TARSKIK4 x,y ]"
          using A3 funct_3_def_5 sorry
        also have "... = idRELAT-1K7 ([:ZFMISC-1K2 X,Y :]) .BINOP-1K1(x,y)"
          using A4 funct_1_th_18 sorry
        finally show "(<:FUNCT-3K14 pr1FUNCT-3K10(X,Y),pr2FUNCT-3K11(X,Y) :>).BINOP-1K1(x,y) =HIDDENR1 idRELAT-1K7 ([:ZFMISC-1K2 X,Y :]) .BINOP-1K1(x,y)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "domRELSET-1K1\<^bsub>([:ZFMISC-1K2 X,Y :])\<^esub> (idRELAT-1K7 ([:ZFMISC-1K2 X,Y :])) =RELAT-1R1 [:ZFMISC-1K2 X,Y :]"
       sorry
    thus "<:FUNCT-3K14 pr1FUNCT-3K10(X,Y),pr2FUNCT-3K11(X,Y) :> =FUNCT-1R1 idRELAT-1K7 ([:ZFMISC-1K2 X,Y :])"
      using A1 A2 funct_3_th_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_54:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds  for k be FunctionFUNCT-1M1 holds (domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g & domRELAT-1K1 k =XBOOLE-0R4 domRELAT-1K1 h) & <:FUNCT-3K14 f,g :> =FUNCT-1R1 <:FUNCT-3K14 k,h :> implies f =FUNCT-1R1 k & g =FUNCT-1R1 h"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds  for k be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g & (domRELAT-1K1 k =XBOOLE-0R4 domRELAT-1K1 h & <:FUNCT-3K14 f,g :> =FUNCT-1R1 <:FUNCT-3K14 k,h :>) implies f =FUNCT-1R1 k & g =FUNCT-1R1 h"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix h assume [ty]: "h be FunctionFUNCT-1M1"
    fix k assume [ty]: "k be FunctionFUNCT-1M1"
    assume A1: "domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g"
      and A2: "domRELAT-1K1 k =XBOOLE-0R4 domRELAT-1K1 h"
      and A3: "<:FUNCT-3K14 f,g :> =FUNCT-1R1 <:FUNCT-3K14 k,h :>"
    have A4: "domRELAT-1K1 (<:FUNCT-3K14 f,g :>) =XBOOLE-0R4 domRELAT-1K1 f"
      using A1 funct_3_th_50 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =XBOOLE-0R4 k .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 domRELAT-1K1 f"
      then have "(<:FUNCT-3K14 f,g :>).FUNCT-1K1 x =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 x ] & (<:FUNCT-3K14 k,h :>).FUNCT-1K1 x =HIDDENR1 [TARSKIK4 k .FUNCT-1K1 x,h .FUNCT-1K1 x ]"
        using A3 A4 funct_3_def_7 sorry
      thus "f .FUNCT-1K1 x =XBOOLE-0R4 k .FUNCT-1K1 x"
        using A3 xtuple_0_th_1 sorry
    qed "sorry"
    thus "f =FUNCT-1R1 k"
      using A2 A3 A4 funct_3_th_50 sorry
    have A5: "domRELAT-1K1 (<:FUNCT-3K14 f,g :>) =XBOOLE-0R4 domRELAT-1K1 g"
      using A1 funct_3_th_50 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x =XBOOLE-0R4 h .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 domRELAT-1K1 g"
      then have "(<:FUNCT-3K14 f,g :>).FUNCT-1K1 x =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 x ] & (<:FUNCT-3K14 k,h :>).FUNCT-1K1 x =HIDDENR1 [TARSKIK4 k .FUNCT-1K1 x,h .FUNCT-1K1 x ]"
        using A3 A5 funct_3_def_7 sorry
      thus "g .FUNCT-1K1 x =XBOOLE-0R4 h .FUNCT-1K1 x"
        using A3 xtuple_0_th_1 sorry
    qed "sorry"
    thus "g =FUNCT-1R1 h"
      using A2 A3 A5 funct_3_th_50 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_55:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds <:FUNCT-3K14 f *FUNCT-1K3 h,g *FUNCT-1K3 h :> =FUNCT-1R1 (<:FUNCT-3K14 f,g :>)*FUNCT-1K3 h"
proof(rule ballI,rule ballI,rule ballI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  fix g assume [ty]: "g be FunctionFUNCT-1M1"
  fix h assume [ty]: "h be FunctionFUNCT-1M1"
  have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (<:FUNCT-3K14 f *FUNCT-1K3 h,g *FUNCT-1K3 h :>) iff x inHIDDENR3 domRELAT-1K1 ((<:FUNCT-3K14 f,g :>)*FUNCT-1K3 h)"
  proof-
    have " for x be objectHIDDENM1 holds (x inHIDDENR3 domRELAT-1K1 (<:FUNCT-3K14 f *FUNCT-1K3 h,g *FUNCT-1K3 h :>) implies x inHIDDENR3 domRELAT-1K1 ((<:FUNCT-3K14 f,g :>)*FUNCT-1K3 h)) & (x inHIDDENR3 domRELAT-1K1 ((<:FUNCT-3K14 f,g :>)*FUNCT-1K3 h) implies x inHIDDENR3 domRELAT-1K1 (<:FUNCT-3K14 f *FUNCT-1K3 h,g *FUNCT-1K3 h :>))"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      show "x inHIDDENR3 domRELAT-1K1 (<:FUNCT-3K14 f *FUNCT-1K3 h,g *FUNCT-1K3 h :>) implies x inHIDDENR3 domRELAT-1K1 ((<:FUNCT-3K14 f,g :>)*FUNCT-1K3 h)"
      proof(rule impI)
        assume "x inHIDDENR3 domRELAT-1K1 (<:FUNCT-3K14 f *FUNCT-1K3 h,g *FUNCT-1K3 h :>)"
        then have A1: "x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 h) /\\XBOOLE-0K3 domRELAT-1K1 (g *FUNCT-1K3 h)"
          using funct_3_def_7 sorry
        then have A2: "x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 h)"
          using xboole_0_def_4 sorry
        have "x inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 h)"
          using A1 xboole_0_def_4 sorry
        then have A3: "h .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 g"
          using funct_1_th_11 sorry
        have "h .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 f"
          using A2 funct_1_th_11 sorry
        then have "h .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g"
          using A3 xboole_0_def_4 sorry
        then have A4: "h .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 (<:FUNCT-3K14 f,g :>)"
          using funct_3_def_7 sorry
        have "x inHIDDENR3 domRELAT-1K1 h"
          using A2 funct_1_th_11 sorry
        thus "x inHIDDENR3 domRELAT-1K1 ((<:FUNCT-3K14 f,g :>)*FUNCT-1K3 h)"
          using A4 funct_1_th_11 sorry
      qed
      assume A5: "x inHIDDENR3 domRELAT-1K1 ((<:FUNCT-3K14 f,g :>)*FUNCT-1K3 h)"
      then have A6: "x inHIDDENR3 domRELAT-1K1 h"
        using funct_1_th_11 sorry
      have "h .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 (<:FUNCT-3K14 f,g :>)"
        using A5 funct_1_th_11 sorry
      then have A7: "h .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g"
        using funct_3_def_7 sorry
      then have "h .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 g"
        using xboole_0_def_4 sorry
      then have A8: "x inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 h)"
        using A6 funct_1_th_11 sorry
      have "h .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 f"
        using A7 xboole_0_def_4 sorry
      then have "x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 h)"
        using A6 funct_1_th_11 sorry
      then have "x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 h) /\\XBOOLE-0K3 domRELAT-1K1 (g *FUNCT-1K3 h)"
        using A8 xboole_0_def_4 sorry
      thus "x inHIDDENR3 domRELAT-1K1 (<:FUNCT-3K14 f *FUNCT-1K3 h,g *FUNCT-1K3 h :>)"
        using funct_3_def_7 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  then have A9: "domRELAT-1K1 (<:FUNCT-3K14 f *FUNCT-1K3 h,g *FUNCT-1K3 h :>) =XBOOLE-0R4 domRELAT-1K1 ((<:FUNCT-3K14 f,g :>)*FUNCT-1K3 h)"
    using tarski_th_2 sorry
  have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (<:FUNCT-3K14 f *FUNCT-1K3 h,g *FUNCT-1K3 h :>) implies (<:FUNCT-3K14 f *FUNCT-1K3 h,g *FUNCT-1K3 h :>).FUNCT-1K1 x =XBOOLE-0R4 ((<:FUNCT-3K14 f,g :>)*FUNCT-1K3 h).FUNCT-1K1 x"
  proof-
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (<:FUNCT-3K14 f *FUNCT-1K3 h,g *FUNCT-1K3 h :>) implies (<:FUNCT-3K14 f *FUNCT-1K3 h,g *FUNCT-1K3 h :>).FUNCT-1K1 x =HIDDENR1 ((<:FUNCT-3K14 f,g :>)*FUNCT-1K3 h).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A10: "x inHIDDENR3 domRELAT-1K1 (<:FUNCT-3K14 f *FUNCT-1K3 h,g *FUNCT-1K3 h :>)"
      then have A11: "x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 h) /\\XBOOLE-0K3 domRELAT-1K1 (g *FUNCT-1K3 h)"
        using funct_3_def_7 sorry
      then have A12: "x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 h)"
        using xboole_0_def_4 sorry
      then have A13: "x inHIDDENR3 domRELAT-1K1 h"
        using funct_1_th_11 sorry
      have A14: "x inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 h)"
        using A11 xboole_0_def_4 sorry
      then have A15: "h .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 g"
        using funct_1_th_11 sorry
      have "h .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 f"
        using A12 funct_1_th_11 sorry
      then have A16: "h .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g"
        using A15 xboole_0_def_4 sorry
      have "(<:FUNCT-3K14 f *FUNCT-1K3 h,g *FUNCT-1K3 h :>).FUNCT-1K1 x =HIDDENR1 [TARSKIK4 (f *FUNCT-1K3 h).FUNCT-1K1 x,(g *FUNCT-1K3 h).FUNCT-1K1 x ]"
        using A10 funct_3_def_7 sorry
      also have "... = [TARSKIK4 f .FUNCT-1K1 (h .FUNCT-1K1 x),(g *FUNCT-1K3 h).FUNCT-1K1 x ]"
        using A12 funct_1_th_12 sorry
      also have "... = [TARSKIK4 f .FUNCT-1K1 (h .FUNCT-1K1 x),g .FUNCT-1K1 (h .FUNCT-1K1 x) ]"
        using A14 funct_1_th_12 sorry
      also have "... = (<:FUNCT-3K14 f,g :>).FUNCT-1K1 (h .FUNCT-1K1 x)"
        using A16 funct_3_th_48 sorry
      also have "... = ((<:FUNCT-3K14 f,g :>)*FUNCT-1K3 h).FUNCT-1K1 x"
        using A13 funct_1_th_13 sorry
      finally show "(<:FUNCT-3K14 f *FUNCT-1K3 h,g *FUNCT-1K3 h :>).FUNCT-1K1 x =HIDDENR1 ((<:FUNCT-3K14 f,g :>)*FUNCT-1K3 h).FUNCT-1K1 x"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus "<:FUNCT-3K14 f *FUNCT-1K3 h,g *FUNCT-1K3 h :> =FUNCT-1R1 (<:FUNCT-3K14 f,g :>)*FUNCT-1K3 h"
    using A9 sorry
qed "sorry"

mtheorem funct_3_th_56:
" for A be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds (<:FUNCT-3K14 f,g :>).:FUNCT-1K5 A c=TARSKIR1 [:ZFMISC-1K2 f .:FUNCT-1K5 A,g .:FUNCT-1K5 A :]"
proof-
  have " for A be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds (<:FUNCT-3K14 f,g :>).:FUNCT-1K5 A c=TARSKIR1 [:ZFMISC-1K2 f .:FUNCT-1K5 A,g .:FUNCT-1K5 A :]"
  proof(rule ballI,rule ballI,rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 (<:FUNCT-3K14 f,g :>).:FUNCT-1K5 A implies y inHIDDENR3 [:ZFMISC-1K2 f .:FUNCT-1K5 A,g .:FUNCT-1K5 A :]"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 (<:FUNCT-3K14 f,g :>).:FUNCT-1K5 A"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A1: "x inHIDDENR3 domRELAT-1K1 (<:FUNCT-3K14 f,g :>)"and A2: "x inHIDDENR3 A"and A3: "y =HIDDENR1 (<:FUNCT-3K14 f,g :>).FUNCT-1K1 x"
        using funct_1_def_6 sorry
      have A4: "x inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g"
        using A1 funct_3_def_7 sorry
      then have "x inHIDDENR3 domRELAT-1K1 f"
        using xboole_0_def_4 sorry
      then have A5: "f .FUNCT-1K1 x inTARSKIR2 f .:FUNCT-1K5 A"
        using A2 funct_1_def_6 sorry
      have "x inHIDDENR3 domRELAT-1K1 g"
        using A4 xboole_0_def_4 sorry
      then have A6: "g .FUNCT-1K1 x inTARSKIR2 g .:FUNCT-1K5 A"
        using A2 funct_1_def_6 sorry
      have "y =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 x ]"
        using A1 A3 funct_3_def_7 sorry
      thus "y inHIDDENR3 [:ZFMISC-1K2 f .:FUNCT-1K5 A,g .:FUNCT-1K5 A :]"
        using A5 A6 zfmisc_1_def_2 sorry
    qed "sorry"
    thus "(<:FUNCT-3K14 f,g :>).:FUNCT-1K5 A c=TARSKIR1 [:ZFMISC-1K2 f .:FUNCT-1K5 A,g .:FUNCT-1K5 A :]"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_57:
" for B be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds (<:FUNCT-3K14 f,g :>)\<inverse>FUNCT-1K6 ([:ZFMISC-1K2 B,C :]) =XBOOLE-0R4 f \<inverse>FUNCT-1K6 B /\\XBOOLE-0K3 g \<inverse>FUNCT-1K6 C"
proof-
  have " for B be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds (<:FUNCT-3K14 f,g :>)\<inverse>FUNCT-1K6 ([:ZFMISC-1K2 B,C :]) =XBOOLE-0R4 f \<inverse>FUNCT-1K6 B /\\XBOOLE-0K3 g \<inverse>FUNCT-1K6 C"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix B assume [ty]: "B be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 (<:FUNCT-3K14 f,g :>)\<inverse>FUNCT-1K6 ([:ZFMISC-1K2 B,C :]) iff x inHIDDENR3 f \<inverse>FUNCT-1K6 B /\\XBOOLE-0K3 g \<inverse>FUNCT-1K6 C"
    proof-
      have " for x be objectHIDDENM1 holds (x inHIDDENR3 (<:FUNCT-3K14 f,g :>)\<inverse>FUNCT-1K6 ([:ZFMISC-1K2 B,C :]) implies x inHIDDENR3 f \<inverse>FUNCT-1K6 B /\\XBOOLE-0K3 g \<inverse>FUNCT-1K6 C) & (x inHIDDENR3 f \<inverse>FUNCT-1K6 B /\\XBOOLE-0K3 g \<inverse>FUNCT-1K6 C implies x inHIDDENR3 (<:FUNCT-3K14 f,g :>)\<inverse>FUNCT-1K6 ([:ZFMISC-1K2 B,C :]))"
      proof(rule ballI,rule conjMI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        show "x inHIDDENR3 (<:FUNCT-3K14 f,g :>)\<inverse>FUNCT-1K6 ([:ZFMISC-1K2 B,C :]) implies x inHIDDENR3 f \<inverse>FUNCT-1K6 B /\\XBOOLE-0K3 g \<inverse>FUNCT-1K6 C"
        proof(rule impI)
          assume A1: "x inHIDDENR3 (<:FUNCT-3K14 f,g :>)\<inverse>FUNCT-1K6 ([:ZFMISC-1K2 B,C :])"
          then have "(<:FUNCT-3K14 f,g :>).FUNCT-1K1 x inTARSKIR2 [:ZFMISC-1K2 B,C :]"
            using funct_1_def_7 sorry
          then obtain y1 y2 where
            [ty]:"y1 be objectHIDDENM1" "y2 be objectHIDDENM1" and 
            A2: "y1 inHIDDENR3 B"and A3: "y2 inHIDDENR3 C"and A4: "(<:FUNCT-3K14 f,g :>).FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y1,y2 ]"
            using zfmisc_1_def_2 sorry
          have A5: "x inHIDDENR3 domRELAT-1K1 (<:FUNCT-3K14 f,g :>)"
            using A1 funct_1_def_7 sorry
          then have A6: "x inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g"
            using funct_3_def_7 sorry
          then have A7: "x inHIDDENR3 domRELAT-1K1 g"
            using xboole_0_def_4 sorry
          have A8: "[TARSKIK4 y1,y2 ] =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 x ]"
            using A4 A5 funct_3_def_7 sorry
          then have "y2 =HIDDENR1 g .FUNCT-1K1 x"
            using xtuple_0_th_1 sorry
          then have A9: "x inHIDDENR3 g \<inverse>FUNCT-1K6 C"
            using A3 A7 funct_1_def_7 sorry
          have A10: "x inHIDDENR3 domRELAT-1K1 f"
            using A6 xboole_0_def_4 sorry
          have "y1 =HIDDENR1 f .FUNCT-1K1 x"
            using A8 xtuple_0_th_1 sorry
          then have "x inHIDDENR3 f \<inverse>FUNCT-1K6 B"
            using A2 A10 funct_1_def_7 sorry
          thus "x inHIDDENR3 f \<inverse>FUNCT-1K6 B /\\XBOOLE-0K3 g \<inverse>FUNCT-1K6 C"
            using A9 xboole_0_def_4 sorry
        qed
        assume A11: "x inHIDDENR3 f \<inverse>FUNCT-1K6 B /\\XBOOLE-0K3 g \<inverse>FUNCT-1K6 C"
        then have A12: "x inHIDDENR3 g \<inverse>FUNCT-1K6 C"
          using xboole_0_def_4 sorry
        then have A13: "x inHIDDENR3 domRELAT-1K1 g"
          using funct_1_def_7 sorry
        have A14: "x inHIDDENR3 f \<inverse>FUNCT-1K6 B"
          using A11 xboole_0_def_4 sorry
        then have "x inHIDDENR3 domRELAT-1K1 f"
          using funct_1_def_7 sorry
        then have A15: "x inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g"
          using A13 xboole_0_def_4 sorry
        then have A16: "x inHIDDENR3 domRELAT-1K1 (<:FUNCT-3K14 f,g :>)"
          using funct_3_def_7 sorry
        have A17: "g .FUNCT-1K1 x inTARSKIR2 C"
          using A12 funct_1_def_7 sorry
        have "f .FUNCT-1K1 x inTARSKIR2 B"
          using A14 funct_1_def_7 sorry
        then have "[TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 x ] inHIDDENR3 [:ZFMISC-1K2 B,C :]"
          using A17 zfmisc_1_def_2 sorry
        then have "(<:FUNCT-3K14 f,g :>).FUNCT-1K1 x inTARSKIR2 [:ZFMISC-1K2 B,C :]"
          using A15 funct_3_th_48 sorry
        thus "x inHIDDENR3 (<:FUNCT-3K14 f,g :>)\<inverse>FUNCT-1K6 ([:ZFMISC-1K2 B,C :])"
          using A16 funct_1_def_7 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "(<:FUNCT-3K14 f,g :>)\<inverse>FUNCT-1K6 ([:ZFMISC-1K2 B,C :]) =XBOOLE-0R4 f \<inverse>FUNCT-1K6 B /\\XBOOLE-0K3 g \<inverse>FUNCT-1K6 C"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_58:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(X,Z) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) & (Z =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) implies <:FUNCT-3K14 f,g :> be FunctionFUNCT-2M1-of(X,[:ZFMISC-1K2 Y,Z :])"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(X,Z) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) & (Z =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) implies <:FUNCT-3K14 f,g :> be FunctionFUNCT-2M1-of(X,[:ZFMISC-1K2 Y,Z :])"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(X,Z)"
    assume A1: "(Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) & (Z =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1)"
    show "<:FUNCT-3K14 f,g :> be FunctionFUNCT-2M1-of(X,[:ZFMISC-1K2 Y,Z :])"
    proof-
      have cases: "([:ZFMISC-1K2 Y,Z :] =RELAT-1R1 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) or [:ZFMISC-1K2 Y,Z :] =RELAT-1R1 {}XBOOLE-0K1 & X <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "([:ZFMISC-1K2 Y,Z :] =RELAT-1R1 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) implies <:FUNCT-3K14 f,g :> be FunctionFUNCT-2M1-of(X,[:ZFMISC-1K2 Y,Z :])"
      proof(rule impI)
        assume "[:ZFMISC-1K2 Y,Z :] =RELAT-1R1 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1"
        have "rngFUNCT-1K2 f c=TARSKIR1 Y & rngFUNCT-1K2 g c=TARSKIR1 Z"
          using relat_1_def_19 sorry
        then have A2: "[:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 g :] c=RELAT-1R2 [:ZFMISC-1K2 Y,Z :]"
          using zfmisc_1_th_96 sorry
        have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X & domRELSET-1K1\<^bsub>(X)\<^esub> g =XBOOLE-0R4 X"
          using A1 funct_2_def_1 sorry
        then have A3: "domRELAT-1K1 (<:FUNCT-3K14 f,g :>) =XBOOLE-0R4 X"
          using funct_3_th_50 sorry
        have "rngFUNCT-1K2 (<:FUNCT-3K14 f,g :>) c=TARSKIR1 [:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 g :]"
          using funct_3_th_51 sorry
        then have "rngFUNCT-1K2 (<:FUNCT-3K14 f,g :>) c=TARSKIR1 [:ZFMISC-1K2 Y,Z :]"
          using A2 sorry
        thus "<:FUNCT-3K14 f,g :> be FunctionFUNCT-2M1-of(X,[:ZFMISC-1K2 Y,Z :])"
          using A3 funct_2_th_2 sorry
      qed
      have case2: "[:ZFMISC-1K2 Y,Z :] =RELAT-1R1 {}XBOOLE-0K1 & X <>HIDDENR2 {}XBOOLE-0K1 implies <:FUNCT-3K14 f,g :> be FunctionFUNCT-2M1-of(X,[:ZFMISC-1K2 Y,Z :])"
      proof(rule impI)
        assume "[:ZFMISC-1K2 Y,Z :] =RELAT-1R1 {}XBOOLE-0K1 & X <>HIDDENR2 {}XBOOLE-0K1"
        thus "<:FUNCT-3K14 f,g :> be FunctionFUNCT-2M1-of(X,[:ZFMISC-1K2 Y,Z :])"
          using A1 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax FUNCT_3K15 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("<:FUNCT-3K15\<^bsub>'( _ , _ , _ ')\<^esub> _ , _ :>" [0,0,0,0,0]164)
translations "<:FUNCT-3K15\<^bsub>(X,D1,D2)\<^esub> f1,f2 :>" \<rightharpoonup> "<:FUNCT-3K14 f1,f2 :>"

mtheorem funct_3_add_7:
  mlet "X be setHIDDENM2", "D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f1 be FunctionFUNCT-2M1-of(X,D1)", "f2 be FunctionFUNCT-2M1-of(X,D2)"
"cluster <:FUNCT-3K14 f1,f2 :> as-term-is FunctionFUNCT-2M1-of(X,[:ZFMISC-1K2 D1,D2 :])"
proof
(*coherence*)
  show "<:FUNCT-3K14 f1,f2 :> be FunctionFUNCT-2M1-of(X,[:ZFMISC-1K2 D1,D2 :])"
    using funct_3_th_58 sorry
qed "sorry"

mtheorem funct_3_th_59:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be FunctionFUNCT-2M1-of(C,D1) holds  for f2 be FunctionFUNCT-2M1-of(C,D2) holds  for c be ElementSUBSET-1M1-of C holds (<:FUNCT-3K15\<^bsub>(C,D1,D2)\<^esub> f1,f2 :>).FUNCT-2K3\<^bsub>(C,[:ZFMISC-1K2 D1,D2 :])\<^esub> c =HIDDENR1 [TARSKIK4 f1 .FUNCT-2K3\<^bsub>(C,D1)\<^esub> c,f2 .FUNCT-2K3\<^bsub>(C,D2)\<^esub> c ]"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be FunctionFUNCT-2M1-of(C,D1) holds  for f2 be FunctionFUNCT-2M1-of(C,D2) holds  for c be ElementSUBSET-1M1-of C holds (<:FUNCT-3K15\<^bsub>(C,D1,D2)\<^esub> f1,f2 :>).FUNCT-2K3\<^bsub>(C,[:ZFMISC-1K2 D1,D2 :])\<^esub> c =HIDDENR1 [TARSKIK4 f1 .FUNCT-2K3\<^bsub>(C,D1)\<^esub> c,f2 .FUNCT-2K3\<^bsub>(C,D2)\<^esub> c ]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D1 assume [ty]: "D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D2 assume [ty]: "D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be FunctionFUNCT-2M1-of(C,D1)"
    fix f2 assume [ty]: "f2 be FunctionFUNCT-2M1-of(C,D2)"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    have "domRELSET-1K1\<^bsub>(C)\<^esub> f1 =XBOOLE-0R4 C & domRELSET-1K1\<^bsub>(C)\<^esub> f2 =XBOOLE-0R4 C"
      using funct_2_def_1 sorry
    thus "(<:FUNCT-3K15\<^bsub>(C,D1,D2)\<^esub> f1,f2 :>).FUNCT-2K3\<^bsub>(C,[:ZFMISC-1K2 D1,D2 :])\<^esub> c =HIDDENR1 [TARSKIK4 f1 .FUNCT-2K3\<^bsub>(C,D1)\<^esub> c,f2 .FUNCT-2K3\<^bsub>(C,D2)\<^esub> c ]"
      using funct_3_th_49 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_60:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(X,Z) holds rngFUNCT-1K2 (<:FUNCT-3K14 f,g :>) c=TARSKIR1 [:ZFMISC-1K2 Y,Z :]"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(X,Z) holds rngFUNCT-1K2 (<:FUNCT-3K14 f,g :>) c=TARSKIR1 [:ZFMISC-1K2 Y,Z :]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(X,Z)"
    have "rngFUNCT-1K2 f c=TARSKIR1 Y & rngFUNCT-1K2 g c=TARSKIR1 Z"
      using relat_1_def_19 sorry
    then have A1: "[:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 g :] c=RELAT-1R2 [:ZFMISC-1K2 Y,Z :]"
      using zfmisc_1_th_96 sorry
    have "rngFUNCT-1K2 (<:FUNCT-3K14 f,g :>) c=TARSKIR1 [:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 g :]"
      using funct_3_th_51 sorry
    thus "rngFUNCT-1K2 (<:FUNCT-3K14 f,g :>) c=TARSKIR1 [:ZFMISC-1K2 Y,Z :]"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_61:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(X,Z) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) & (Z =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) implies pr1FUNCT-3K10(Y,Z) *FUNCT-1K3 (<:FUNCT-3K14 f,g :>) =FUNCT-1R1 f & pr2FUNCT-3K11(Y,Z) *FUNCT-1K3 (<:FUNCT-3K14 f,g :>) =FUNCT-1R1 g"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(X,Z) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) & (Z =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) implies pr1FUNCT-3K10(Y,Z) *FUNCT-1K3 (<:FUNCT-3K14 f,g :>) =FUNCT-1R1 f & pr2FUNCT-3K11(Y,Z) *FUNCT-1K3 (<:FUNCT-3K14 f,g :>) =FUNCT-1R1 g"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(X,Z)"
    assume "(Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) & (Z =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1)"
    then have A1: "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X & domRELSET-1K1\<^bsub>(X)\<^esub> g =XBOOLE-0R4 X"
      using funct_2_def_1 sorry
    have "rngFUNCT-1K2 f c=TARSKIR1 Y & rngFUNCT-1K2 g c=TARSKIR1 Z"
      using relat_1_def_19 sorry
    thus "pr1FUNCT-3K10(Y,Z) *FUNCT-1K3 (<:FUNCT-3K14 f,g :>) =FUNCT-1R1 f & pr2FUNCT-3K11(Y,Z) *FUNCT-1K3 (<:FUNCT-3K14 f,g :>) =FUNCT-1R1 g"
      using A1 funct_3_th_52 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_62:
" for X be setHIDDENM2 holds  for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,D1) holds  for g be FunctionFUNCT-2M1-of(X,D2) holds pr1FUNCT-3K10(D1,D2) *FUNCT-1K3 (<:FUNCT-3K15\<^bsub>(X,D1,D2)\<^esub> f,g :>) =FUNCT-1R1 f & pr2FUNCT-3K11(D1,D2) *FUNCT-1K3 (<:FUNCT-3K15\<^bsub>(X,D1,D2)\<^esub> f,g :>) =FUNCT-1R1 g"
  using funct_3_th_61 sorry

mtheorem funct_3_th_63:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f1 be FunctionFUNCT-2M1-of(X,Y) holds  for f2 be FunctionFUNCT-2M1-of(X,Y) holds  for g1 be FunctionFUNCT-2M1-of(X,Z) holds  for g2 be FunctionFUNCT-2M1-of(X,Z) holds ((Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) & (Z =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1)) & <:FUNCT-3K14 f1,g1 :> =FUNCT-1R1 <:FUNCT-3K14 f2,g2 :> implies f1 =FUNCT-2R2\<^bsub>(X,Y)\<^esub> f2 & g1 =FUNCT-2R2\<^bsub>(X,Z)\<^esub> g2"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f1 be FunctionFUNCT-2M1-of(X,Y) holds  for f2 be FunctionFUNCT-2M1-of(X,Y) holds  for g1 be FunctionFUNCT-2M1-of(X,Z) holds  for g2 be FunctionFUNCT-2M1-of(X,Z) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) & (Z =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) implies  not (<:FUNCT-3K14 f1,g1 :> =FUNCT-1R1 <:FUNCT-3K14 f2,g2 :> &  not (f1 =FUNCT-2R2\<^bsub>(X,Y)\<^esub> f2 & g1 =FUNCT-2R2\<^bsub>(X,Z)\<^esub> g2))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix f1 assume [ty]: "f1 be FunctionFUNCT-2M1-of(X,Y)"
    fix f2 assume [ty]: "f2 be FunctionFUNCT-2M1-of(X,Y)"
    fix g1 assume [ty]: "g1 be FunctionFUNCT-2M1-of(X,Z)"
    fix g2 assume [ty]: "g2 be FunctionFUNCT-2M1-of(X,Z)"
    assume A1: "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1"
      and A2: "Z =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1"
    have A3: "domRELSET-1K1\<^bsub>(X)\<^esub> g1 =XBOOLE-0R4 X & domRELSET-1K1\<^bsub>(X)\<^esub> g2 =XBOOLE-0R4 X"
      using A2 funct_2_def_1 sorry
    have "domRELSET-1K1\<^bsub>(X)\<^esub> f1 =XBOOLE-0R4 X & domRELSET-1K1\<^bsub>(X)\<^esub> f2 =XBOOLE-0R4 X"
      using A1 funct_2_def_1 sorry
    thus " not (<:FUNCT-3K14 f1,g1 :> =FUNCT-1R1 <:FUNCT-3K14 f2,g2 :> &  not (f1 =FUNCT-2R2\<^bsub>(X,Y)\<^esub> f2 & g1 =FUNCT-2R2\<^bsub>(X,Z)\<^esub> g2))"
      using A3 funct_3_th_54 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_64:
" for X be setHIDDENM2 holds  for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be FunctionFUNCT-2M1-of(X,D1) holds  for f2 be FunctionFUNCT-2M1-of(X,D1) holds  for g1 be FunctionFUNCT-2M1-of(X,D2) holds  for g2 be FunctionFUNCT-2M1-of(X,D2) holds <:FUNCT-3K15\<^bsub>(X,D1,D2)\<^esub> f1,g1 :> =FUNCT-2R2\<^bsub>(X,[:ZFMISC-1K2 D1,D2 :])\<^esub> <:FUNCT-3K15\<^bsub>(X,D1,D2)\<^esub> f2,g2 :> implies f1 =FUNCT-2R2\<^bsub>(X,D1)\<^esub> f2 & g1 =FUNCT-2R2\<^bsub>(X,D2)\<^esub> g2"
proof-
  have " for X be setHIDDENM2 holds  for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be FunctionFUNCT-2M1-of(X,D1) holds  for f2 be FunctionFUNCT-2M1-of(X,D1) holds  for g1 be FunctionFUNCT-2M1-of(X,D2) holds  for g2 be FunctionFUNCT-2M1-of(X,D2) holds  not (<:FUNCT-3K15\<^bsub>(X,D1,D2)\<^esub> f1,g1 :> =FUNCT-2R2\<^bsub>(X,[:ZFMISC-1K2 D1,D2 :])\<^esub> <:FUNCT-3K15\<^bsub>(X,D1,D2)\<^esub> f2,g2 :> &  not (f1 =FUNCT-2R2\<^bsub>(X,D1)\<^esub> f2 & g1 =FUNCT-2R2\<^bsub>(X,D2)\<^esub> g2))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix D1 assume [ty]: "D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D2 assume [ty]: "D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be FunctionFUNCT-2M1-of(X,D1)"
    fix f2 assume [ty]: "f2 be FunctionFUNCT-2M1-of(X,D1)"
    fix g1 assume [ty]: "g1 be FunctionFUNCT-2M1-of(X,D2)"
    fix g2 assume [ty]: "g2 be FunctionFUNCT-2M1-of(X,D2)"
    have A1: "domRELSET-1K1\<^bsub>(X)\<^esub> g1 =XBOOLE-0R4 X & domRELSET-1K1\<^bsub>(X)\<^esub> g2 =XBOOLE-0R4 X"
      using funct_2_def_1 sorry
    have "domRELSET-1K1\<^bsub>(X)\<^esub> f1 =XBOOLE-0R4 X & domRELSET-1K1\<^bsub>(X)\<^esub> f2 =XBOOLE-0R4 X"
      using funct_2_def_1 sorry
    thus " not (<:FUNCT-3K15\<^bsub>(X,D1,D2)\<^esub> f1,g1 :> =FUNCT-2R2\<^bsub>(X,[:ZFMISC-1K2 D1,D2 :])\<^esub> <:FUNCT-3K15\<^bsub>(X,D1,D2)\<^esub> f2,g2 :> &  not (f1 =FUNCT-2R2\<^bsub>(X,D1)\<^esub> f2 & g1 =FUNCT-2R2\<^bsub>(X,D2)\<^esub> g2))"
      using A1 funct_3_th_54 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef funct_3_def_8 ("[:FUNCT-3K16 _ , _ :]" [0,0]164 ) where
  mlet "f be FunctionFUNCT-1M1", "g be FunctionFUNCT-1M1"
"func [:FUNCT-3K16 f,g :] \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :] & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 g implies it .BINOP-1K1(x,y) =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 y ])"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :] & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 g implies it .BINOP-1K1(x,y) =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 y ])"
    proof-
      have " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :] & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ((x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 g) &  not VarFor1 .BINOP-1K1(x,y) =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 y ]))))"
      proof-
        let ?F = "\<lambda>Lamb1. \<lambda>Lamb2. [TARSKIK4 f .FUNCT-1K1 Lamb1,g .FUNCT-1K1 Lamb2 ]"
        have " ex F be FunctionFUNCT-1M1 st domRELAT-1K1 F =XBOOLE-0R4 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :] & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 g implies F .BINOP-1K1(x,y) =HIDDENR1 ?F(x,y))"
          using funct_3_sch_2 sorry
        thus " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :] & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ((x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 g) &  not VarFor1 .BINOP-1K1(x,y) =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 y ]))))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :] & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 g implies it1 .BINOP-1K1(x,y) =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 y ])) & (domRELAT-1K1 it2 =XBOOLE-0R4 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :] & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 g implies it2 .BINOP-1K1(x,y) =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 y ])) implies it1 =HIDDENR1 it2"
    proof-
      have " for fg1 be FunctionFUNCT-1M1 holds  for fg2 be FunctionFUNCT-1M1 holds domRELAT-1K1 fg1 =XBOOLE-0R4 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :] & (( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 g implies fg1 .BINOP-1K1(x,y) =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 y ]) & (domRELAT-1K1 fg2 =XBOOLE-0R4 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :] & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 g implies fg2 .BINOP-1K1(x,y) =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 y ]))) implies fg1 =HIDDENR1 fg2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix fg1 assume [ty]: "fg1 be FunctionFUNCT-1M1"
        fix fg2 assume [ty]: "fg2 be FunctionFUNCT-1M1"
        assume A1: "domRELAT-1K1 fg1 =XBOOLE-0R4 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :]"
          and A2: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 g implies fg1 .BINOP-1K1(x,y) =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 y ]"
          and A3: "domRELAT-1K1 fg2 =XBOOLE-0R4 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :]"
          and A4: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 g implies fg2 .BINOP-1K1(x,y) =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 y ]"
        have " for p be objectHIDDENM1 holds p inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :] implies fg1 .FUNCT-1K1 p =XBOOLE-0R4 fg2 .FUNCT-1K1 p"
        proof(rule ballI,rule impI)
          fix p assume [ty]: "p be objectHIDDENM1"
          assume "p inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :]"
          then obtain x y where
            [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
            A5: "x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 g"and A6: "p =HIDDENR1 [TARSKIK4 x,y ]"
            using zfmisc_1_def_2 sorry
          have "fg1 .BINOP-1K1(x,y) =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 y ] & fg2 .BINOP-1K1(x,y) =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 y ]"
            using A2 A4 A5 sorry
          thus "fg1 .FUNCT-1K1 p =XBOOLE-0R4 fg2 .FUNCT-1K1 p"
            using A6 sorry
        qed "sorry"
        thus "fg1 =HIDDENR1 fg2"
          using A1 A3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem funct_3_th_65:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :] implies ([:FUNCT-3K16 f,g :]).BINOP-1K1(x,y) =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 y ]"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  fix g assume [ty]: "g be FunctionFUNCT-1M1"
  fix x assume [ty]: "x be objectHIDDENM1"
  fix y assume [ty]: "y be objectHIDDENM1"
  assume "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :]"
  then have "x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 g"
    using zfmisc_1_th_87 sorry
  thus "([:FUNCT-3K16 f,g :]).BINOP-1K1(x,y) =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 y ]"
    using funct_3_def_8 sorry
qed "sorry"

mtheorem funct_3_th_66:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds [:FUNCT-3K16 f,g :] =FUNCT-1R1 <:FUNCT-3K14 f *FUNCT-1K3 pr1FUNCT-3K10(domRELAT-1K1 f,domRELAT-1K1 g),g *FUNCT-1K3 pr2FUNCT-3K11(domRELAT-1K1 f,domRELAT-1K1 g) :>"
proof(rule ballI,rule ballI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  fix g assume [ty]: "g be FunctionFUNCT-1M1"
  have A1: "domRELSET-1K1\<^bsub>([:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :])\<^esub> (pr1FUNCT-3K10(domRELAT-1K1 f,domRELAT-1K1 g)) =RELAT-1R1 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :]"
    using funct_3_def_4 sorry
  have A2: "domRELSET-1K1\<^bsub>([:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :])\<^esub> (pr2FUNCT-3K11(domRELAT-1K1 f,domRELAT-1K1 g)) =RELAT-1R1 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :]"
    using funct_3_def_5 sorry
  have "rngFUNCT-1K2 (pr2FUNCT-3K11(domRELAT-1K1 f,domRELAT-1K1 g)) c=TARSKIR1 domRELAT-1K1 g"
    using funct_3_th_45 sorry
  then have A3: "domRELSET-1K1\<^bsub>([:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :])\<^esub> (g *FUNCT-1K3 pr2FUNCT-3K11(domRELAT-1K1 f,domRELAT-1K1 g)) =RELAT-1R1 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :]"
    using A2 relat_1_th_27 sorry
  have "rngFUNCT-1K2 (pr1FUNCT-3K10(domRELAT-1K1 f,domRELAT-1K1 g)) c=TARSKIR1 domRELAT-1K1 f"
    using funct_3_th_43 sorry
  then have "domRELSET-1K1\<^bsub>([:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :])\<^esub> (f *FUNCT-1K3 pr1FUNCT-3K10(domRELAT-1K1 f,domRELAT-1K1 g)) =RELAT-1R1 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :]"
    using A1 relat_1_th_27 sorry
  then have A4: "domRELAT-1K1 (<:FUNCT-3K14 f *FUNCT-1K3 pr1FUNCT-3K10(domRELAT-1K1 f,domRELAT-1K1 g),g *FUNCT-1K3 pr2FUNCT-3K11(domRELAT-1K1 f,domRELAT-1K1 g) :>) =XBOOLE-0R4 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :]"
    using A3 funct_3_th_50 sorry
  have A5: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 g implies ([:FUNCT-3K16 f,g :]).BINOP-1K1(x,y) =XBOOLE-0R4 (<:FUNCT-3K14 f *FUNCT-1K3 pr1FUNCT-3K10(domRELAT-1K1 f,domRELAT-1K1 g),g *FUNCT-1K3 pr2FUNCT-3K11(domRELAT-1K1 f,domRELAT-1K1 g) :>).BINOP-1K1(x,y)"
  proof-
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 g implies ([:FUNCT-3K16 f,g :]).BINOP-1K1(x,y) =HIDDENR1 (<:FUNCT-3K14 f *FUNCT-1K3 pr1FUNCT-3K10(domRELAT-1K1 f,domRELAT-1K1 g),g *FUNCT-1K3 pr2FUNCT-3K11(domRELAT-1K1 f,domRELAT-1K1 g) :>).BINOP-1K1(x,y)"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A6: "x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 g"
      then have A7: "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :]"
        using zfmisc_1_th_87 sorry
      have "([:FUNCT-3K16 f,g :]).BINOP-1K1(x,y) =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 y ]"
        using A6 funct_3_def_8 sorry
      also have "... = [TARSKIK4 f .FUNCT-1K1 (pr1FUNCT-3K10(domRELAT-1K1 f,domRELAT-1K1 g) .BINOP-1K1(x,y)),g .FUNCT-1K1 y ]"
        using A6 funct_3_def_4 sorry
      also have "... = [TARSKIK4 f .FUNCT-1K1 (pr1FUNCT-3K10(domRELAT-1K1 f,domRELAT-1K1 g) .BINOP-1K1(x,y)),g .FUNCT-1K1 (pr2FUNCT-3K11(domRELAT-1K1 f,domRELAT-1K1 g) .BINOP-1K1(x,y)) ]"
        using A6 funct_3_def_5 sorry
      also have "... = [TARSKIK4 (f *FUNCT-1K3 pr1FUNCT-3K10(domRELAT-1K1 f,domRELAT-1K1 g)).BINOP-1K1(x,y),g .FUNCT-1K1 (pr2FUNCT-3K11(domRELAT-1K1 f,domRELAT-1K1 g) .BINOP-1K1(x,y)) ]"
        using A1 A7 funct_1_th_13 sorry
      also have "... = [TARSKIK4 (f *FUNCT-1K3 pr1FUNCT-3K10(domRELAT-1K1 f,domRELAT-1K1 g)).BINOP-1K1(x,y),(g *FUNCT-1K3 pr2FUNCT-3K11(domRELAT-1K1 f,domRELAT-1K1 g)).BINOP-1K1(x,y) ]"
        using A2 A7 funct_1_th_13 sorry
      also have "... = (<:FUNCT-3K14 f *FUNCT-1K3 pr1FUNCT-3K10(domRELAT-1K1 f,domRELAT-1K1 g),g *FUNCT-1K3 pr2FUNCT-3K11(domRELAT-1K1 f,domRELAT-1K1 g) :>).BINOP-1K1(x,y)"
        using A4 A7 funct_3_def_7 sorry
      finally show "([:FUNCT-3K16 f,g :]).BINOP-1K1(x,y) =HIDDENR1 (<:FUNCT-3K14 f *FUNCT-1K3 pr1FUNCT-3K10(domRELAT-1K1 f,domRELAT-1K1 g),g *FUNCT-1K3 pr2FUNCT-3K11(domRELAT-1K1 f,domRELAT-1K1 g) :>).BINOP-1K1(x,y)"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have "domRELAT-1K1 ([:FUNCT-3K16 f,g :]) =XBOOLE-0R4 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :]"
    using funct_3_def_8 sorry
  thus "[:FUNCT-3K16 f,g :] =FUNCT-1R1 <:FUNCT-3K14 f *FUNCT-1K3 pr1FUNCT-3K10(domRELAT-1K1 f,domRELAT-1K1 g),g *FUNCT-1K3 pr2FUNCT-3K11(domRELAT-1K1 f,domRELAT-1K1 g) :>"
    using A4 A5 funct_3_th_6 sorry
qed "sorry"

mtheorem funct_3_th_67:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds rngFUNCT-1K2 ([:FUNCT-3K16 f,g :]) =XBOOLE-0R4 [:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 g :]"
proof(rule ballI,rule ballI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  fix g assume [ty]: "g be FunctionFUNCT-1M1"
  have " for q be objectHIDDENM1 holds q inHIDDENR3 rngFUNCT-1K2 ([:FUNCT-3K16 f,g :]) iff q inHIDDENR3 [:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 g :]"
  proof-
    have " for q be objectHIDDENM1 holds (q inHIDDENR3 rngFUNCT-1K2 ([:FUNCT-3K16 f,g :]) implies q inHIDDENR3 [:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 g :]) & (q inHIDDENR3 [:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 g :] implies q inHIDDENR3 rngFUNCT-1K2 ([:FUNCT-3K16 f,g :]))"
    proof(rule ballI,rule conjMI,rule impI)
      fix q assume [ty]: "q be objectHIDDENM1"
      have A1: "domRELAT-1K1 ([:FUNCT-3K16 f,g :]) =XBOOLE-0R4 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :]"
        using funct_3_def_8 sorry
      show "q inHIDDENR3 rngFUNCT-1K2 ([:FUNCT-3K16 f,g :]) implies q inHIDDENR3 [:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 g :]"
      proof(rule impI)
        assume "q inHIDDENR3 rngFUNCT-1K2 ([:FUNCT-3K16 f,g :])"
        then obtain p where
          [ty]:"p be objectHIDDENM1" and 
          A2: "p inHIDDENR3 domRELAT-1K1 ([:FUNCT-3K16 f,g :])"and A3: "q =HIDDENR1 ([:FUNCT-3K16 f,g :]).FUNCT-1K1 p"
          using funct_1_def_3 sorry
        have "p inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :]"
          using A2 funct_3_def_8 sorry
        then obtain x y where
          [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
          A4: "x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 g"and A5: "p =HIDDENR1 [TARSKIK4 x,y ]"
          using zfmisc_1_def_2 sorry
        have A6: "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f & g .FUNCT-1K1 y inTARSKIR2 rngFUNCT-1K2 g"
          using A4 funct_1_def_3 sorry
        have "q =HIDDENR1 ([:FUNCT-3K16 f,g :]).BINOP-1K1(x,y)"
          using A3 A5 sorry
        also have "... = [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 y ]"
          using A4 funct_3_def_8 sorry
        finally have "q =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 y ]"
           sorry
        thus "q inHIDDENR3 [:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 g :]"
          using A6 zfmisc_1_th_87 sorry
      qed
      assume "q inHIDDENR3 [:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 g :]"
      then obtain y1 y2 where
        [ty]:"y1 be objectHIDDENM1" "y2 be objectHIDDENM1" and 
        A7: "y1 inHIDDENR3 rngFUNCT-1K2 f"and A8: "y2 inHIDDENR3 rngFUNCT-1K2 g"and A9: "q =HIDDENR1 [TARSKIK4 y1,y2 ]"
        using zfmisc_1_def_2 sorry
      obtain x2 where
        [ty]:"x2 be objectHIDDENM1" and 
        A10: "x2 inHIDDENR3 domRELAT-1K1 g"and A11: "y2 =HIDDENR1 g .FUNCT-1K1 x2"
        using A8 funct_1_def_3 sorry
      obtain x1 where
        [ty]:"x1 be objectHIDDENM1" and 
        A12: "x1 inHIDDENR3 domRELAT-1K1 f"and A13: "y1 =HIDDENR1 f .FUNCT-1K1 x1"
        using A7 funct_1_def_3 sorry
      have A14: "[TARSKIK4 x1,x2 ] inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :]"
        using A12 A10 zfmisc_1_th_87 sorry
      have "([:FUNCT-3K16 f,g :]).BINOP-1K1(x1,x2) =HIDDENR1 q"
        using A9 A12 A13 A10 A11 funct_3_def_8 sorry
      thus "q inHIDDENR3 rngFUNCT-1K2 ([:FUNCT-3K16 f,g :])"
        using A14 A1 funct_1_def_3 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus "rngFUNCT-1K2 ([:FUNCT-3K16 f,g :]) =XBOOLE-0R4 [:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 g :]"
    using tarski_th_2 sorry
qed "sorry"

mtheorem funct_3_th_68:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 X & domRELAT-1K1 g =XBOOLE-0R4 X implies <:FUNCT-3K14 f,g :> =FUNCT-1R1 ([:FUNCT-3K16 f,g :])*FUNCT-1K3 deltaFUNCT-3K13 X"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 X & domRELAT-1K1 g =XBOOLE-0R4 X implies <:FUNCT-3K14 f,g :> =FUNCT-1R1 ([:FUNCT-3K16 f,g :])*FUNCT-1K3 deltaFUNCT-3K13 X"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "domRELAT-1K1 f =XBOOLE-0R4 X & domRELAT-1K1 g =XBOOLE-0R4 X"
    have A2: "domRELSET-1K1\<^bsub>(X)\<^esub> (deltaFUNCT-3K13 X) =XBOOLE-0R4 X"
      using funct_3_def_6 sorry
    have "rngFUNCT-1K2 (deltaFUNCT-3K13 X) c=RELAT-1R2 [:ZFMISC-1K2 X,X :]"
      using funct_3_th_47 sorry
    then have "rngFUNCT-1K2 (deltaFUNCT-3K13 X) c=RELAT-1R2 domRELAT-1K1 ([:FUNCT-3K16 f,g :])"
      using A1 funct_3_def_8 sorry
    then have A3: "domRELSET-1K1\<^bsub>(X)\<^esub> (([:FUNCT-3K16 f,g :])*FUNCT-1K3 deltaFUNCT-3K13 X) =XBOOLE-0R4 X"
      using A2 relat_1_th_27 sorry
    have "domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g =XBOOLE-0R4 X"
      using A1 sorry
    then have A4: "domRELAT-1K1 (<:FUNCT-3K14 f,g :>) =XBOOLE-0R4 X"
      using funct_3_def_7 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies (<:FUNCT-3K14 f,g :>).FUNCT-1K1 x =XBOOLE-0R4 (([:FUNCT-3K16 f,g :])*FUNCT-1K3 deltaFUNCT-3K13 X).FUNCT-1K1 x"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies (<:FUNCT-3K14 f,g :>).FUNCT-1K1 x =HIDDENR1 (([:FUNCT-3K16 f,g :])*FUNCT-1K3 deltaFUNCT-3K13 X).FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A5: "x inHIDDENR3 X"
        then have "(<:FUNCT-3K14 f,g :>).FUNCT-1K1 x =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 x ]"
          using A4 funct_3_def_7 sorry
        also have "... = ([:FUNCT-3K16 f,g :]).BINOP-1K1(x,x)"
          using A1 A5 funct_3_def_8 sorry
        also have "... = ([:FUNCT-3K16 f,g :]).FUNCT-1K1 (deltaFUNCT-3K13 X .FUNCT-1K1 x)"
          using A5 funct_3_def_6 sorry
        also have "... = (([:FUNCT-3K16 f,g :])*FUNCT-1K3 deltaFUNCT-3K13 X).FUNCT-1K1 x"
          using A3 A5 funct_1_th_12 sorry
        finally show "(<:FUNCT-3K14 f,g :>).FUNCT-1K1 x =HIDDENR1 (([:FUNCT-3K16 f,g :])*FUNCT-1K3 deltaFUNCT-3K13 X).FUNCT-1K1 x"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "<:FUNCT-3K14 f,g :> =FUNCT-1R1 ([:FUNCT-3K16 f,g :])*FUNCT-1K3 deltaFUNCT-3K13 X"
      using A4 A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_69:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds [:FUNCT-3K16 idRELAT-1K7 X,idRELAT-1K7 Y :] =FUNCT-1R1 idRELAT-1K7 ([:ZFMISC-1K2 X,Y :])"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds [:FUNCT-3K16 idRELAT-1K7 X,idRELAT-1K7 Y :] =HIDDENR1 idRELAT-1K7 ([:ZFMISC-1K2 X,Y :])"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "rngFUNCT-1K2 (pr1FUNCT-3K10(X,Y)) c=TARSKIR1 X"
      using funct_3_th_43 sorry
    then have A1: "idRELAT-1K7 X *FUNCT-1K3 pr1FUNCT-3K10(X,Y) =FUNCT-1R1 pr1FUNCT-3K10(X,Y)"
      using relat_1_th_53 sorry
    have "rngFUNCT-1K2 (pr2FUNCT-3K11(X,Y)) c=TARSKIR1 Y"
      using funct_3_th_45 sorry
    then have A2: "idRELAT-1K7 Y *FUNCT-1K3 pr2FUNCT-3K11(X,Y) =FUNCT-1R1 pr2FUNCT-3K11(X,Y)"
      using relat_1_th_53 sorry
    have "domRELSET-1K1\<^bsub>(X)\<^esub> (idRELAT-1K7 X) =XBOOLE-0R4 X & domRELSET-1K1\<^bsub>(Y)\<^esub> (idRELAT-1K7 Y) =XBOOLE-0R4 Y"
       sorry
    then have "[:FUNCT-3K16 idRELAT-1K7 X,idRELAT-1K7 Y :] =HIDDENR1 <:FUNCT-3K14 pr1FUNCT-3K10(X,Y),pr2FUNCT-3K11(X,Y) :>"
      using A1 A2 funct_3_th_66 sorry
    also have "... = idRELAT-1K7 ([:ZFMISC-1K2 X,Y :])"
      using funct_3_th_53 sorry
    finally show "[:FUNCT-3K16 idRELAT-1K7 X,idRELAT-1K7 Y :] =HIDDENR1 idRELAT-1K7 ([:ZFMISC-1K2 X,Y :])"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_70:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds  for k be FunctionFUNCT-1M1 holds ([:FUNCT-3K16 f,h :])*FUNCT-1K3 (<:FUNCT-3K14 g,k :>) =FUNCT-1R1 <:FUNCT-3K14 f *FUNCT-1K3 g,h *FUNCT-1K3 k :>"
proof(rule ballI,rule ballI,rule ballI,rule ballI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  fix g assume [ty]: "g be FunctionFUNCT-1M1"
  fix h assume [ty]: "h be FunctionFUNCT-1M1"
  fix k assume [ty]: "k be FunctionFUNCT-1M1"
  have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (([:FUNCT-3K16 f,h :])*FUNCT-1K3 (<:FUNCT-3K14 g,k :>)) iff x inHIDDENR3 domRELAT-1K1 (<:FUNCT-3K14 f *FUNCT-1K3 g,h *FUNCT-1K3 k :>)"
  proof-
    have " for x be objectHIDDENM1 holds (x inHIDDENR3 domRELAT-1K1 (([:FUNCT-3K16 f,h :])*FUNCT-1K3 (<:FUNCT-3K14 g,k :>)) implies x inHIDDENR3 domRELAT-1K1 (<:FUNCT-3K14 f *FUNCT-1K3 g,h *FUNCT-1K3 k :>)) & (x inHIDDENR3 domRELAT-1K1 (<:FUNCT-3K14 f *FUNCT-1K3 g,h *FUNCT-1K3 k :>) implies x inHIDDENR3 domRELAT-1K1 (([:FUNCT-3K16 f,h :])*FUNCT-1K3 (<:FUNCT-3K14 g,k :>)))"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      show "x inHIDDENR3 domRELAT-1K1 (([:FUNCT-3K16 f,h :])*FUNCT-1K3 (<:FUNCT-3K14 g,k :>)) implies x inHIDDENR3 domRELAT-1K1 (<:FUNCT-3K14 f *FUNCT-1K3 g,h *FUNCT-1K3 k :>)"
      proof(rule impI)
        assume A1: "x inHIDDENR3 domRELAT-1K1 (([:FUNCT-3K16 f,h :])*FUNCT-1K3 (<:FUNCT-3K14 g,k :>))"
        then have A2: "x inHIDDENR3 domRELAT-1K1 (<:FUNCT-3K14 g,k :>)"
          using funct_1_th_11 sorry
        then have A3: "x inHIDDENR3 domRELAT-1K1 g /\\XBOOLE-0K3 domRELAT-1K1 k"
          using funct_3_def_7 sorry
        then have A4: "x inHIDDENR3 domRELAT-1K1 g"
          using xboole_0_def_4 sorry
        have A5: "x inHIDDENR3 domRELAT-1K1 k"
          using A3 xboole_0_def_4 sorry
        have "(<:FUNCT-3K14 g,k :>).FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 ([:FUNCT-3K16 f,h :])"
          using A1 funct_1_th_11 sorry
        then have "[TARSKIK4 g .FUNCT-1K1 x,k .FUNCT-1K1 x ] inHIDDENR3 domRELAT-1K1 ([:FUNCT-3K16 f,h :])"
          using A2 funct_3_def_7 sorry
        then have A6: "[TARSKIK4 g .FUNCT-1K1 x,k .FUNCT-1K1 x ] inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 h :]"
          using funct_3_def_8 sorry
        then have "k .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 h"
          using zfmisc_1_th_87 sorry
        then have A7: "x inHIDDENR3 domRELAT-1K1 (h *FUNCT-1K3 k)"
          using A5 funct_1_th_11 sorry
        have "g .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 f"
          using A6 zfmisc_1_th_87 sorry
        then have "x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 g)"
          using A4 funct_1_th_11 sorry
        then have "x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 g) /\\XBOOLE-0K3 domRELAT-1K1 (h *FUNCT-1K3 k)"
          using A7 xboole_0_def_4 sorry
        thus "x inHIDDENR3 domRELAT-1K1 (<:FUNCT-3K14 f *FUNCT-1K3 g,h *FUNCT-1K3 k :>)"
          using funct_3_def_7 sorry
      qed
      assume "x inHIDDENR3 domRELAT-1K1 (<:FUNCT-3K14 f *FUNCT-1K3 g,h *FUNCT-1K3 k :>)"
      then have A8: "x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 g) /\\XBOOLE-0K3 domRELAT-1K1 (h *FUNCT-1K3 k)"
        using funct_3_def_7 sorry
      then have A9: "x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 g)"
        using xboole_0_def_4 sorry
      have A10: "x inHIDDENR3 domRELAT-1K1 (h *FUNCT-1K3 k)"
        using A8 xboole_0_def_4 sorry
      then have A11: "x inHIDDENR3 domRELAT-1K1 k"
        using funct_1_th_11 sorry
      have "x inHIDDENR3 domRELAT-1K1 g"
        using A9 funct_1_th_11 sorry
      then have "x inHIDDENR3 domRELAT-1K1 g /\\XBOOLE-0K3 domRELAT-1K1 k"
        using A11 xboole_0_def_4 sorry
      then have A12: "x inHIDDENR3 domRELAT-1K1 (<:FUNCT-3K14 g,k :>)"
        using funct_3_def_7 sorry
      have A13: "k .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 h"
        using A10 funct_1_th_11 sorry
      have "g .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 f"
        using A9 funct_1_th_11 sorry
      then have "[TARSKIK4 g .FUNCT-1K1 x,k .FUNCT-1K1 x ] inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 h :]"
        using A13 zfmisc_1_th_87 sorry
      then have "[TARSKIK4 g .FUNCT-1K1 x,k .FUNCT-1K1 x ] inHIDDENR3 domRELAT-1K1 ([:FUNCT-3K16 f,h :])"
        using funct_3_def_8 sorry
      then have "(<:FUNCT-3K14 g,k :>).FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 ([:FUNCT-3K16 f,h :])"
        using A12 funct_3_def_7 sorry
      thus "x inHIDDENR3 domRELAT-1K1 (([:FUNCT-3K16 f,h :])*FUNCT-1K3 (<:FUNCT-3K14 g,k :>))"
        using A12 funct_1_th_11 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  then have A14: "domRELAT-1K1 (([:FUNCT-3K16 f,h :])*FUNCT-1K3 (<:FUNCT-3K14 g,k :>)) =XBOOLE-0R4 domRELAT-1K1 (<:FUNCT-3K14 f *FUNCT-1K3 g,h *FUNCT-1K3 k :>)"
    using tarski_th_2 sorry
  have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (([:FUNCT-3K16 f,h :])*FUNCT-1K3 (<:FUNCT-3K14 g,k :>)) implies (([:FUNCT-3K16 f,h :])*FUNCT-1K3 (<:FUNCT-3K14 g,k :>)).FUNCT-1K1 x =XBOOLE-0R4 (<:FUNCT-3K14 f *FUNCT-1K3 g,h *FUNCT-1K3 k :>).FUNCT-1K1 x"
  proof-
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (([:FUNCT-3K16 f,h :])*FUNCT-1K3 (<:FUNCT-3K14 g,k :>)) implies (([:FUNCT-3K16 f,h :])*FUNCT-1K3 (<:FUNCT-3K14 g,k :>)).FUNCT-1K1 x =HIDDENR1 (<:FUNCT-3K14 f *FUNCT-1K3 g,h *FUNCT-1K3 k :>).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A15: "x inHIDDENR3 domRELAT-1K1 (([:FUNCT-3K16 f,h :])*FUNCT-1K3 (<:FUNCT-3K14 g,k :>))"
      then have A16: "x inHIDDENR3 domRELAT-1K1 (<:FUNCT-3K14 g,k :>)"
        using funct_1_th_11 sorry
      then have A17: "x inHIDDENR3 domRELAT-1K1 g /\\XBOOLE-0K3 domRELAT-1K1 k"
        using funct_3_def_7 sorry
      then have A18: "x inHIDDENR3 domRELAT-1K1 g"
        using xboole_0_def_4 sorry
      have "(<:FUNCT-3K14 g,k :>).FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 ([:FUNCT-3K16 f,h :])"
        using A15 funct_1_th_11 sorry
      then have "[TARSKIK4 g .FUNCT-1K1 x,k .FUNCT-1K1 x ] inHIDDENR3 domRELAT-1K1 ([:FUNCT-3K16 f,h :])"
        using A16 funct_3_def_7 sorry
      then have A19: "[TARSKIK4 g .FUNCT-1K1 x,k .FUNCT-1K1 x ] inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 h :]"
        using funct_3_def_8 sorry
      then have A20: "g .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 f"
        using zfmisc_1_th_87 sorry
      have A21: "x inHIDDENR3 domRELAT-1K1 k"
        using A17 xboole_0_def_4 sorry
      have A22: "k .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 h"
        using A19 zfmisc_1_th_87 sorry
      then have A23: "x inHIDDENR3 domRELAT-1K1 (h *FUNCT-1K3 k)"
        using A21 funct_1_th_11 sorry
      have "x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 g)"
        using A20 A18 funct_1_th_11 sorry
      then have A24: "x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 g) /\\XBOOLE-0K3 domRELAT-1K1 (h *FUNCT-1K3 k)"
        using A23 xboole_0_def_4 sorry
      have "(([:FUNCT-3K16 f,h :])*FUNCT-1K3 (<:FUNCT-3K14 g,k :>)).FUNCT-1K1 x =HIDDENR1 ([:FUNCT-3K16 f,h :]).FUNCT-1K1 ((<:FUNCT-3K14 g,k :>).FUNCT-1K1 x)"
        using A15 funct_1_th_12 sorry
      also have "... = ([:FUNCT-3K16 f,h :]).BINOP-1K1(g .FUNCT-1K1 x,k .FUNCT-1K1 x)"
        using A16 funct_3_def_7 sorry
      also have "... = [TARSKIK4 f .FUNCT-1K1 (g .FUNCT-1K1 x),h .FUNCT-1K1 (k .FUNCT-1K1 x) ]"
        using A20 A22 funct_3_def_8 sorry
      also have "... = [TARSKIK4 (f *FUNCT-1K3 g).FUNCT-1K1 x,h .FUNCT-1K1 (k .FUNCT-1K1 x) ]"
        using A18 funct_1_th_13 sorry
      also have "... = [TARSKIK4 (f *FUNCT-1K3 g).FUNCT-1K1 x,(h *FUNCT-1K3 k).FUNCT-1K1 x ]"
        using A21 funct_1_th_13 sorry
      also have "... = (<:FUNCT-3K14 f *FUNCT-1K3 g,h *FUNCT-1K3 k :>).FUNCT-1K1 x"
        using A24 funct_3_th_48 sorry
      finally show "(([:FUNCT-3K16 f,h :])*FUNCT-1K3 (<:FUNCT-3K14 g,k :>)).FUNCT-1K1 x =HIDDENR1 (<:FUNCT-3K14 f *FUNCT-1K3 g,h *FUNCT-1K3 k :>).FUNCT-1K1 x"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus "([:FUNCT-3K16 f,h :])*FUNCT-1K3 (<:FUNCT-3K14 g,k :>) =FUNCT-1R1 <:FUNCT-3K14 f *FUNCT-1K3 g,h *FUNCT-1K3 k :>"
    using A14 sorry
qed "sorry"

mtheorem funct_3_th_71:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds  for k be FunctionFUNCT-1M1 holds ([:FUNCT-3K16 f,h :])*FUNCT-1K3 ([:FUNCT-3K16 g,k :]) =FUNCT-1R1 [:FUNCT-3K16 f *FUNCT-1K3 g,h *FUNCT-1K3 k :]"
proof(rule ballI,rule ballI,rule ballI,rule ballI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  fix g assume [ty]: "g be FunctionFUNCT-1M1"
  fix h assume [ty]: "h be FunctionFUNCT-1M1"
  fix k assume [ty]: "k be FunctionFUNCT-1M1"
  have A1: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 g) & y inHIDDENR3 domRELAT-1K1 (h *FUNCT-1K3 k) implies (([:FUNCT-3K16 f,h :])*FUNCT-1K3 ([:FUNCT-3K16 g,k :])).BINOP-1K1(x,y) =XBOOLE-0R4 ([:FUNCT-3K16 f *FUNCT-1K3 g,h *FUNCT-1K3 k :]).BINOP-1K1(x,y)"
  proof-
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 g) & y inHIDDENR3 domRELAT-1K1 (h *FUNCT-1K3 k) implies (([:FUNCT-3K16 f,h :])*FUNCT-1K3 ([:FUNCT-3K16 g,k :])).BINOP-1K1(x,y) =HIDDENR1 ([:FUNCT-3K16 f *FUNCT-1K3 g,h *FUNCT-1K3 k :]).BINOP-1K1(x,y)"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A2: "x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 g)"
        and A3: "y inHIDDENR3 domRELAT-1K1 (h *FUNCT-1K3 k)"
      have A4: "g .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 f & k .FUNCT-1K1 y inTARSKIR2 domRELAT-1K1 h"
        using A2 A3 funct_1_th_11 sorry
      have A5: "x inHIDDENR3 domRELAT-1K1 g & y inHIDDENR3 domRELAT-1K1 k"
        using A2 A3 funct_1_th_11 sorry
      then have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 g,domRELAT-1K1 k :]"
        using zfmisc_1_th_87 sorry
      then have "[TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 ([:FUNCT-3K16 g,k :])"
        using funct_3_def_8 sorry
      then have "(([:FUNCT-3K16 f,h :])*FUNCT-1K3 ([:FUNCT-3K16 g,k :])).BINOP-1K1(x,y) =HIDDENR1 ([:FUNCT-3K16 f,h :]).FUNCT-1K1 (([:FUNCT-3K16 g,k :]).BINOP-1K1(x,y))"
        using funct_1_th_13 sorry
      also have "... = ([:FUNCT-3K16 f,h :]).BINOP-1K1(g .FUNCT-1K1 x,k .FUNCT-1K1 y)"
        using A5 funct_3_def_8 sorry
      also have "... = [TARSKIK4 f .FUNCT-1K1 (g .FUNCT-1K1 x),h .FUNCT-1K1 (k .FUNCT-1K1 y) ]"
        using A4 funct_3_def_8 sorry
      also have "... = [TARSKIK4 (f *FUNCT-1K3 g).FUNCT-1K1 x,h .FUNCT-1K1 (k .FUNCT-1K1 y) ]"
        using A2 funct_1_th_12 sorry
      also have "... = [TARSKIK4 (f *FUNCT-1K3 g).FUNCT-1K1 x,(h *FUNCT-1K3 k).FUNCT-1K1 y ]"
        using A3 funct_1_th_12 sorry
      also have "... = ([:FUNCT-3K16 f *FUNCT-1K3 g,h *FUNCT-1K3 k :]).BINOP-1K1(x,y)"
        using A2 A3 funct_3_def_8 sorry
      finally show "(([:FUNCT-3K16 f,h :])*FUNCT-1K3 ([:FUNCT-3K16 g,k :])).BINOP-1K1(x,y) =HIDDENR1 ([:FUNCT-3K16 f *FUNCT-1K3 g,h *FUNCT-1K3 k :]).BINOP-1K1(x,y)"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have " for p be objectHIDDENM1 holds p inHIDDENR3 domRELAT-1K1 (([:FUNCT-3K16 f,h :])*FUNCT-1K3 ([:FUNCT-3K16 g,k :])) iff p inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 (f *FUNCT-1K3 g),domRELAT-1K1 (h *FUNCT-1K3 k) :]"
  proof-
    have " for p be objectHIDDENM1 holds (p inHIDDENR3 domRELAT-1K1 (([:FUNCT-3K16 f,h :])*FUNCT-1K3 ([:FUNCT-3K16 g,k :])) implies p inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 (f *FUNCT-1K3 g),domRELAT-1K1 (h *FUNCT-1K3 k) :]) & (p inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 (f *FUNCT-1K3 g),domRELAT-1K1 (h *FUNCT-1K3 k) :] implies p inHIDDENR3 domRELAT-1K1 (([:FUNCT-3K16 f,h :])*FUNCT-1K3 ([:FUNCT-3K16 g,k :])))"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be objectHIDDENM1"
      have A6: "domRELAT-1K1 ([:FUNCT-3K16 g,k :]) =XBOOLE-0R4 [:ZFMISC-1K2 domRELAT-1K1 g,domRELAT-1K1 k :]"
        using funct_3_def_8 sorry
      have A7: "domRELAT-1K1 ([:FUNCT-3K16 f,h :]) =XBOOLE-0R4 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 h :]"
        using funct_3_def_8 sorry
      show "p inHIDDENR3 domRELAT-1K1 (([:FUNCT-3K16 f,h :])*FUNCT-1K3 ([:FUNCT-3K16 g,k :])) implies p inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 (f *FUNCT-1K3 g),domRELAT-1K1 (h *FUNCT-1K3 k) :]"
      proof(rule impI)
        assume A8: "p inHIDDENR3 domRELAT-1K1 (([:FUNCT-3K16 f,h :])*FUNCT-1K3 ([:FUNCT-3K16 g,k :]))"
        then have A9: "([:FUNCT-3K16 g,k :]).FUNCT-1K1 p inTARSKIR2 domRELAT-1K1 ([:FUNCT-3K16 f,h :])"
          using funct_1_th_11 sorry
        have A10: "p inHIDDENR3 domRELAT-1K1 ([:FUNCT-3K16 g,k :])"
          using A8 funct_1_th_11 sorry
        then obtain x1 x2 where
          [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" and 
          A11: "x1 inHIDDENR3 domRELAT-1K1 g"and A12: "x2 inHIDDENR3 domRELAT-1K1 k"and A13: "p =HIDDENR1 [TARSKIK4 x1,x2 ]"
          using A6 zfmisc_1_def_2 sorry
        have "([:FUNCT-3K16 g,k :]).BINOP-1K1(x1,x2) =XBOOLE-0R4 ([:FUNCT-3K16 g,k :]).FUNCT-1K1 p"
          using A13 sorry
        then have A14: "[TARSKIK4 g .FUNCT-1K1 x1,k .FUNCT-1K1 x2 ] inHIDDENR3 domRELAT-1K1 ([:FUNCT-3K16 f,h :])"
          using A6 A10 A9 A13 funct_3_th_65 sorry
        then have "k .FUNCT-1K1 x2 inTARSKIR2 domRELAT-1K1 h"
          using A7 zfmisc_1_th_87 sorry
        then have A15: "x2 inHIDDENR3 domRELAT-1K1 (h *FUNCT-1K3 k)"
          using A12 funct_1_th_11 sorry
        have "g .FUNCT-1K1 x1 inTARSKIR2 domRELAT-1K1 f"
          using A7 A14 zfmisc_1_th_87 sorry
        then have "x1 inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 g)"
          using A11 funct_1_th_11 sorry
        thus "p inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 (f *FUNCT-1K3 g),domRELAT-1K1 (h *FUNCT-1K3 k) :]"
          using A13 A15 zfmisc_1_th_87 sorry
      qed
      assume "p inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 (f *FUNCT-1K3 g),domRELAT-1K1 (h *FUNCT-1K3 k) :]"
      then obtain x1 x2 where
        [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" and 
        A16: "x1 inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 g) & x2 inHIDDENR3 domRELAT-1K1 (h *FUNCT-1K3 k)"and A17: "p =HIDDENR1 [TARSKIK4 x1,x2 ]"
        using zfmisc_1_def_2 sorry
      have "x1 inHIDDENR3 domRELAT-1K1 g & x2 inHIDDENR3 domRELAT-1K1 k"
        using A16 funct_1_th_11 sorry
      then have A18: "[TARSKIK4 x1,x2 ] inHIDDENR3 domRELAT-1K1 ([:FUNCT-3K16 g,k :])"
        using A6 zfmisc_1_th_87 sorry
      have "g .FUNCT-1K1 x1 inTARSKIR2 domRELAT-1K1 f & k .FUNCT-1K1 x2 inTARSKIR2 domRELAT-1K1 h"
        using A16 funct_1_th_11 sorry
      then have "[TARSKIK4 g .FUNCT-1K1 x1,k .FUNCT-1K1 x2 ] inHIDDENR3 domRELAT-1K1 ([:FUNCT-3K16 f,h :])"
        using A7 zfmisc_1_th_87 sorry
      then have "([:FUNCT-3K16 g,k :]).BINOP-1K1(x1,x2) inTARSKIR2 domRELAT-1K1 ([:FUNCT-3K16 f,h :])"
        using A6 A18 funct_3_th_65 sorry
      thus "p inHIDDENR3 domRELAT-1K1 (([:FUNCT-3K16 f,h :])*FUNCT-1K3 ([:FUNCT-3K16 g,k :]))"
        using A17 A18 funct_1_th_11 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  then have A19: "domRELAT-1K1 (([:FUNCT-3K16 f,h :])*FUNCT-1K3 ([:FUNCT-3K16 g,k :])) =XBOOLE-0R4 [:ZFMISC-1K2 domRELAT-1K1 (f *FUNCT-1K3 g),domRELAT-1K1 (h *FUNCT-1K3 k) :]"
    using tarski_th_2 sorry
  have "[:ZFMISC-1K2 domRELAT-1K1 (f *FUNCT-1K3 g),domRELAT-1K1 (h *FUNCT-1K3 k) :] =XBOOLE-0R4 domRELAT-1K1 ([:FUNCT-3K16 f *FUNCT-1K3 g,h *FUNCT-1K3 k :])"
    using funct_3_def_8 sorry
  thus "([:FUNCT-3K16 f,h :])*FUNCT-1K3 ([:FUNCT-3K16 g,k :]) =FUNCT-1R1 [:FUNCT-3K16 f *FUNCT-1K3 g,h *FUNCT-1K3 k :]"
    using A19 A1 funct_3_th_6 sorry
qed "sorry"

mtheorem funct_3_th_72:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds ([:FUNCT-3K16 f,g :]).:FUNCT-1K5 ([:ZFMISC-1K2 B,A :]) =XBOOLE-0R4 [:ZFMISC-1K2 f .:FUNCT-1K5 B,g .:FUNCT-1K5 A :]"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds ([:FUNCT-3K16 f,g :]).:FUNCT-1K5 ([:ZFMISC-1K2 B,A :]) =XBOOLE-0R4 [:ZFMISC-1K2 f .:FUNCT-1K5 B,g .:FUNCT-1K5 A :]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    have " for q be objectHIDDENM1 holds q inHIDDENR3 ([:FUNCT-3K16 f,g :]).:FUNCT-1K5 ([:ZFMISC-1K2 B,A :]) iff q inHIDDENR3 [:ZFMISC-1K2 f .:FUNCT-1K5 B,g .:FUNCT-1K5 A :]"
    proof-
      have " for q be objectHIDDENM1 holds (q inHIDDENR3 ([:FUNCT-3K16 f,g :]).:FUNCT-1K5 ([:ZFMISC-1K2 B,A :]) implies q inHIDDENR3 [:ZFMISC-1K2 f .:FUNCT-1K5 B,g .:FUNCT-1K5 A :]) & (q inHIDDENR3 [:ZFMISC-1K2 f .:FUNCT-1K5 B,g .:FUNCT-1K5 A :] implies q inHIDDENR3 ([:FUNCT-3K16 f,g :]).:FUNCT-1K5 ([:ZFMISC-1K2 B,A :]))"
      proof(rule ballI,rule conjMI,rule impI)
        fix q assume [ty]: "q be objectHIDDENM1"
        have A1: "[:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :] =XBOOLE-0R4 domRELAT-1K1 ([:FUNCT-3K16 f,g :])"
          using funct_3_def_8 sorry
        show "q inHIDDENR3 ([:FUNCT-3K16 f,g :]).:FUNCT-1K5 ([:ZFMISC-1K2 B,A :]) implies q inHIDDENR3 [:ZFMISC-1K2 f .:FUNCT-1K5 B,g .:FUNCT-1K5 A :]"
        proof(rule impI)
          assume "q inHIDDENR3 ([:FUNCT-3K16 f,g :]).:FUNCT-1K5 ([:ZFMISC-1K2 B,A :])"
          then obtain p where
            [ty]:"p be objectHIDDENM1" and 
            A2: "p inHIDDENR3 domRELAT-1K1 ([:FUNCT-3K16 f,g :])"and A3: "p inHIDDENR3 [:ZFMISC-1K2 B,A :]"and A4: "q =HIDDENR1 ([:FUNCT-3K16 f,g :]).FUNCT-1K1 p"
            using funct_1_def_6 sorry
          have "domRELAT-1K1 ([:FUNCT-3K16 f,g :]) =XBOOLE-0R4 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :]"
            using funct_3_def_8 sorry
          then obtain x y where
            [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
            A5: "x inHIDDENR3 domRELAT-1K1 f"and A6: "y inHIDDENR3 domRELAT-1K1 g"and A7: "p =HIDDENR1 [TARSKIK4 x,y ]"
            using A2 zfmisc_1_def_2 sorry
          have "x inHIDDENR3 B"
            using A3 A7 zfmisc_1_th_87 sorry
          then have A8: "f .FUNCT-1K1 x inTARSKIR2 f .:FUNCT-1K5 B"
            using A5 funct_1_def_6 sorry
          have "y inHIDDENR3 A"
            using A3 A7 zfmisc_1_th_87 sorry
          then have A9: "g .FUNCT-1K1 y inTARSKIR2 g .:FUNCT-1K5 A"
            using A6 funct_1_def_6 sorry
          have "q =HIDDENR1 ([:FUNCT-3K16 f,g :]).BINOP-1K1(x,y)"
            using A4 A7 sorry
          then have "q =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 y ]"
            using A5 A6 funct_3_def_8 sorry
          thus "q inHIDDENR3 [:ZFMISC-1K2 f .:FUNCT-1K5 B,g .:FUNCT-1K5 A :]"
            using A8 A9 zfmisc_1_th_87 sorry
        qed
        assume "q inHIDDENR3 [:ZFMISC-1K2 f .:FUNCT-1K5 B,g .:FUNCT-1K5 A :]"
        then obtain y1 y2 where
          [ty]:"y1 be objectHIDDENM1" "y2 be objectHIDDENM1" and 
          A10: "y1 inHIDDENR3 f .:FUNCT-1K5 B"and A11: "y2 inHIDDENR3 g .:FUNCT-1K5 A"and A12: "q =HIDDENR1 [TARSKIK4 y1,y2 ]"
          using zfmisc_1_def_2 sorry
        obtain x1 where
          [ty]:"x1 be objectHIDDENM1" and 
          A13: "x1 inHIDDENR3 domRELAT-1K1 f"and A14: "x1 inHIDDENR3 B"and A15: "y1 =HIDDENR1 f .FUNCT-1K1 x1"
          using A10 funct_1_def_6 sorry
        obtain x2 where
          [ty]:"x2 be objectHIDDENM1" and 
          A16: "x2 inHIDDENR3 domRELAT-1K1 g"and A17: "x2 inHIDDENR3 A"and A18: "y2 =HIDDENR1 g .FUNCT-1K1 x2"
          using A11 funct_1_def_6 sorry
        have A19: "([:FUNCT-3K16 f,g :]).BINOP-1K1(x1,x2) =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x1,g .FUNCT-1K1 x2 ]"
          using A13 A16 funct_3_def_8 sorry
        have "[TARSKIK4 x1,x2 ] inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :] & [TARSKIK4 x1,x2 ] inHIDDENR3 [:ZFMISC-1K2 B,A :]"
          using A13 A14 A16 A17 zfmisc_1_th_87 sorry
        thus "q inHIDDENR3 ([:FUNCT-3K16 f,g :]).:FUNCT-1K5 ([:ZFMISC-1K2 B,A :])"
          using A12 A15 A18 A1 A19 funct_1_def_6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "([:FUNCT-3K16 f,g :]).:FUNCT-1K5 ([:ZFMISC-1K2 B,A :]) =XBOOLE-0R4 [:ZFMISC-1K2 f .:FUNCT-1K5 B,g .:FUNCT-1K5 A :]"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_73:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds ([:FUNCT-3K16 f,g :])\<inverse>FUNCT-1K6 ([:ZFMISC-1K2 B,A :]) =XBOOLE-0R4 [:ZFMISC-1K2 f \<inverse>FUNCT-1K6 B,g \<inverse>FUNCT-1K6 A :]"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds ([:FUNCT-3K16 f,g :])\<inverse>FUNCT-1K6 ([:ZFMISC-1K2 B,A :]) =XBOOLE-0R4 [:ZFMISC-1K2 f \<inverse>FUNCT-1K6 B,g \<inverse>FUNCT-1K6 A :]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    have " for q be objectHIDDENM1 holds q inHIDDENR3 ([:FUNCT-3K16 f,g :])\<inverse>FUNCT-1K6 ([:ZFMISC-1K2 B,A :]) iff q inHIDDENR3 [:ZFMISC-1K2 f \<inverse>FUNCT-1K6 B,g \<inverse>FUNCT-1K6 A :]"
    proof-
      have " for q be objectHIDDENM1 holds (q inHIDDENR3 ([:FUNCT-3K16 f,g :])\<inverse>FUNCT-1K6 ([:ZFMISC-1K2 B,A :]) implies q inHIDDENR3 [:ZFMISC-1K2 f \<inverse>FUNCT-1K6 B,g \<inverse>FUNCT-1K6 A :]) & (q inHIDDENR3 [:ZFMISC-1K2 f \<inverse>FUNCT-1K6 B,g \<inverse>FUNCT-1K6 A :] implies q inHIDDENR3 ([:FUNCT-3K16 f,g :])\<inverse>FUNCT-1K6 ([:ZFMISC-1K2 B,A :]))"
      proof(rule ballI,rule conjMI,rule impI)
        fix q assume [ty]: "q be objectHIDDENM1"
        show "q inHIDDENR3 ([:FUNCT-3K16 f,g :])\<inverse>FUNCT-1K6 ([:ZFMISC-1K2 B,A :]) implies q inHIDDENR3 [:ZFMISC-1K2 f \<inverse>FUNCT-1K6 B,g \<inverse>FUNCT-1K6 A :]"
        proof(rule impI)
          assume A1: "q inHIDDENR3 ([:FUNCT-3K16 f,g :])\<inverse>FUNCT-1K6 ([:ZFMISC-1K2 B,A :])"
          then have A2: "([:FUNCT-3K16 f,g :]).FUNCT-1K1 q inTARSKIR2 [:ZFMISC-1K2 B,A :]"
            using funct_1_def_7 sorry
          have "q inHIDDENR3 domRELAT-1K1 ([:FUNCT-3K16 f,g :])"
            using A1 funct_1_def_7 sorry
          then have "q inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :]"
            using funct_3_def_8 sorry
          then obtain x1 x2 where
            [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" and 
            A3: "x1 inHIDDENR3 domRELAT-1K1 f"and A4: "x2 inHIDDENR3 domRELAT-1K1 g"and A5: "q =HIDDENR1 [TARSKIK4 x1,x2 ]"
            using zfmisc_1_def_2 sorry
          have "([:FUNCT-3K16 f,g :]).FUNCT-1K1 q =XBOOLE-0R4 ([:FUNCT-3K16 f,g :]).BINOP-1K1(x1,x2)"
            using A5 sorry
          then have A6: "[TARSKIK4 f .FUNCT-1K1 x1,g .FUNCT-1K1 x2 ] inHIDDENR3 [:ZFMISC-1K2 B,A :]"
            using A3 A4 A2 funct_3_def_8 sorry
          then have "g .FUNCT-1K1 x2 inTARSKIR2 A"
            using zfmisc_1_th_87 sorry
          then have A7: "x2 inHIDDENR3 g \<inverse>FUNCT-1K6 A"
            using A4 funct_1_def_7 sorry
          have "f .FUNCT-1K1 x1 inTARSKIR2 B"
            using A6 zfmisc_1_th_87 sorry
          then have "x1 inHIDDENR3 f \<inverse>FUNCT-1K6 B"
            using A3 funct_1_def_7 sorry
          thus "q inHIDDENR3 [:ZFMISC-1K2 f \<inverse>FUNCT-1K6 B,g \<inverse>FUNCT-1K6 A :]"
            using A5 A7 zfmisc_1_th_87 sorry
        qed
        assume "q inHIDDENR3 [:ZFMISC-1K2 f \<inverse>FUNCT-1K6 B,g \<inverse>FUNCT-1K6 A :]"
        then obtain x1 x2 where
          [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" and 
          A8: "x1 inHIDDENR3 f \<inverse>FUNCT-1K6 B & x2 inHIDDENR3 g \<inverse>FUNCT-1K6 A"and A9: "q =HIDDENR1 [TARSKIK4 x1,x2 ]"
          using zfmisc_1_def_2 sorry
        have "f .FUNCT-1K1 x1 inTARSKIR2 B & g .FUNCT-1K1 x2 inTARSKIR2 A"
          using A8 funct_1_def_7 sorry
        then have A10: "[TARSKIK4 f .FUNCT-1K1 x1,g .FUNCT-1K1 x2 ] inHIDDENR3 [:ZFMISC-1K2 B,A :]"
          using zfmisc_1_th_87 sorry
        have "x1 inHIDDENR3 domRELAT-1K1 f & x2 inHIDDENR3 domRELAT-1K1 g"
          using A8 funct_1_def_7 sorry
        then have A11: "[TARSKIK4 x1,x2 ] inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :] & ([:FUNCT-3K16 f,g :]).BINOP-1K1(x1,x2) =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x1,g .FUNCT-1K1 x2 ]"
          using funct_3_def_8 zfmisc_1_th_87 sorry
        have "[:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 g :] =XBOOLE-0R4 domRELAT-1K1 ([:FUNCT-3K16 f,g :])"
          using funct_3_def_8 sorry
        thus "q inHIDDENR3 ([:FUNCT-3K16 f,g :])\<inverse>FUNCT-1K6 ([:ZFMISC-1K2 B,A :])"
          using A9 A11 A10 funct_1_def_7 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "([:FUNCT-3K16 f,g :])\<inverse>FUNCT-1K6 ([:ZFMISC-1K2 B,A :]) =XBOOLE-0R4 [:ZFMISC-1K2 f \<inverse>FUNCT-1K6 B,g \<inverse>FUNCT-1K6 A :]"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_74:
" for V be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(V,Z) holds [:FUNCT-3K16 f,g :] be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,V :],[:ZFMISC-1K2 Y,Z :])"
proof-
  have " for V be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(V,Z) holds [:FUNCT-3K16 f,g :] be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,V :],[:ZFMISC-1K2 Y,Z :])"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix V assume [ty]: "V be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(V,Z)"
    show "[:FUNCT-3K16 f,g :] be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,V :],[:ZFMISC-1K2 Y,Z :])"
    proof-
      have cases: "([:ZFMISC-1K2 Y,Z :] =RELAT-1R1 {}XBOOLE-0K1 implies [:ZFMISC-1K2 X,V :] =RELAT-1R1 {}XBOOLE-0K1) or [:ZFMISC-1K2 Y,Z :] =RELAT-1R1 {}XBOOLE-0K1 & [:ZFMISC-1K2 X,V :] <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "([:ZFMISC-1K2 Y,Z :] =RELAT-1R1 {}XBOOLE-0K1 implies [:ZFMISC-1K2 X,V :] =RELAT-1R1 {}XBOOLE-0K1) implies [:FUNCT-3K16 f,g :] be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,V :],[:ZFMISC-1K2 Y,Z :])"
      proof(rule impI)
        assume A1: "[:ZFMISC-1K2 Y,Z :] =RELAT-1R1 {}XBOOLE-0K1 implies [:ZFMISC-1K2 X,V :] =RELAT-1R1 {}XBOOLE-0K1"
        have "[:FUNCT-3K16 f,g :] be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,V :],[:ZFMISC-1K2 Y,Z :])"
        proof-
          show "[:FUNCT-3K16 f,g :] be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,V :],[:ZFMISC-1K2 Y,Z :])"
          proof-
            have cases: "[:ZFMISC-1K2 Y,Z :] <>HIDDENR2 {}XBOOLE-0K1 or [:ZFMISC-1K2 X,V :] =RELAT-1R1 {}XBOOLE-0K1"
              using A1 sorry
            have case1: "[:ZFMISC-1K2 Y,Z :] <>HIDDENR2 {}XBOOLE-0K1 implies [:FUNCT-3K16 f,g :] be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,V :],[:ZFMISC-1K2 Y,Z :])"
            proof(rule impI)
              assume A2: "[:ZFMISC-1K2 Y,Z :] <>HIDDENR2 {}XBOOLE-0K1"
              have "rngFUNCT-1K2 f c=TARSKIR1 Y & rngFUNCT-1K2 g c=TARSKIR1 Z"
                using relat_1_def_19 sorry
              then have "[:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 g :] c=RELAT-1R2 [:ZFMISC-1K2 Y,Z :]"
                using zfmisc_1_th_96 sorry
              then have A3: "rngFUNCT-1K2 ([:FUNCT-3K16 f,g :]) c=TARSKIR1 [:ZFMISC-1K2 Y,Z :]"
                using funct_3_th_67 sorry
              have "Z =XBOOLE-0R4 {}XBOOLE-0K1 implies V =XBOOLE-0R4 {}XBOOLE-0K1"
                using A2 zfmisc_1_th_90 sorry
              then have A4: "domRELSET-1K1\<^bsub>(V)\<^esub> g =XBOOLE-0R4 V"
                using funct_2_def_1 sorry
              have "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1"
                using A2 zfmisc_1_th_90 sorry
              then have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
                using funct_2_def_1 sorry
              then have "domRELAT-1K1 ([:FUNCT-3K16 f,g :]) =XBOOLE-0R4 [:ZFMISC-1K2 X,V :]"
                using A4 funct_3_def_8 sorry
              thus "[:FUNCT-3K16 f,g :] be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,V :],[:ZFMISC-1K2 Y,Z :])"
                using A3 funct_2_th_2 sorry
            qed
            have case2: "[:ZFMISC-1K2 X,V :] =RELAT-1R1 {}XBOOLE-0K1 implies [:FUNCT-3K16 f,g :] be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,V :],[:ZFMISC-1K2 Y,Z :])"
            proof(rule impI)
              assume A5: "[:ZFMISC-1K2 X,V :] =RELAT-1R1 {}XBOOLE-0K1"
              then have "X =XBOOLE-0R4 {}XBOOLE-0K1 or V =XBOOLE-0R4 {}XBOOLE-0K1"
                 sorry
              then have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 {}XBOOLE-0K1 or domRELSET-1K1\<^bsub>(V)\<^esub> g =XBOOLE-0R4 {}XBOOLE-0K1"
                 sorry
              then have "[:MCART-1K8\<^bsub>(X,V)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> f,domRELSET-1K1\<^bsub>(V)\<^esub> g :] =RELAT-1R1 {}XBOOLE-0K1"
                using zfmisc_1_th_90 sorry
              then have A6: "domRELAT-1K1 ([:FUNCT-3K16 f,g :]) =XBOOLE-0R4 [:ZFMISC-1K2 X,V :]"
                using A5 funct_3_def_8 sorry
              have "rngFUNCT-1K2 f c=TARSKIR1 Y & rngFUNCT-1K2 g c=TARSKIR1 Z"
                using relat_1_def_19 sorry
              then have "[:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 g :] c=RELAT-1R2 [:ZFMISC-1K2 Y,Z :]"
                using zfmisc_1_th_96 sorry
              then have "rngFUNCT-1K2 ([:FUNCT-3K16 f,g :]) c=TARSKIR1 [:ZFMISC-1K2 Y,Z :]"
                using funct_3_th_67 sorry
              thus "[:FUNCT-3K16 f,g :] be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,V :],[:ZFMISC-1K2 Y,Z :])"
                using A6 funct_2_th_2 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "[:FUNCT-3K16 f,g :] be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,V :],[:ZFMISC-1K2 Y,Z :])"
           sorry
      qed
      have case2: "[:ZFMISC-1K2 Y,Z :] =RELAT-1R1 {}XBOOLE-0K1 & [:ZFMISC-1K2 X,V :] <>HIDDENR2 {}XBOOLE-0K1 implies [:FUNCT-3K16 f,g :] be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,V :],[:ZFMISC-1K2 Y,Z :])"
      proof(rule impI)
        assume A7: "[:ZFMISC-1K2 Y,Z :] =RELAT-1R1 {}XBOOLE-0K1 & [:ZFMISC-1K2 X,V :] <>HIDDENR2 {}XBOOLE-0K1"
        then have "Y =XBOOLE-0R4 {}XBOOLE-0K1 or Z =XBOOLE-0R4 {}XBOOLE-0K1"
           sorry
        then have "f =FUNCT-1R1 {}XBOOLE-0K1 or g =FUNCT-1R1 {}XBOOLE-0K1"
           sorry
        then have "[:MCART-1K8\<^bsub>(X,V)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> f,domRELSET-1K1\<^bsub>(V)\<^esub> g :] =RELAT-1R1 {}XBOOLE-0K1"
          using zfmisc_1_th_90 sorry
        then have A8: "domRELAT-1K1 ([:FUNCT-3K16 f,g :]) =XBOOLE-0R4 {}XBOOLE-0K1"
          using funct_3_def_8 sorry
        then have "rngFUNCT-1K2 ([:FUNCT-3K16 f,g :]) =XBOOLE-0R4 {}XBOOLE-0K1 & domRELAT-1K1 ([:FUNCT-3K16 f,g :]) c=TARSKIR1 [:ZFMISC-1K2 X,V :]"
          using relat_1_th_42 sorry
        then obtain R where 
          [ty]:"R be RelationRELSET-1M1-of([:ZFMISC-1K2 X,V :],[:ZFMISC-1K2 Y,Z :])" and RDef:"R = [:FUNCT-3K16 f,g :]"
          using relset_1_th_4 xboole_1_th_2 sorry
        have "[:FUNCT-3K16 f,g :] =FUNCT-1R1 {}XBOOLE-0K1"
          using A8 sorry
        then have "R be quasi-totalFUNCT-2V1\<^bsub>([:ZFMISC-1K2 X,V :],[:ZFMISC-1K2 Y,Z :])\<^esub>"
          using A7 funct_2_def_1 sorry
        thus "[:FUNCT-3K16 f,g :] be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,V :],[:ZFMISC-1K2 Y,Z :])"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax FUNCT_3K17 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("[:FUNCT-3K17\<^bsub>'( _ , _ , _ , _ ')\<^esub> _ , _ :]" [0,0,0,0,0,0]164)
translations "[:FUNCT-3K17\<^bsub>(X1,X2,Y1,Y2)\<^esub> f1,f2 :]" \<rightharpoonup> "[:FUNCT-3K16 f1,f2 :]"

mtheorem funct_3_add_8:
  mlet "X1 be setHIDDENM2", "X2 be setHIDDENM2", "Y1 be setHIDDENM2", "Y2 be setHIDDENM2", "f1 be FunctionFUNCT-2M1-of(X1,Y1)", "f2 be FunctionFUNCT-2M1-of(X2,Y2)"
"cluster [:FUNCT-3K16 f1,f2 :] as-term-is FunctionFUNCT-2M1-of([:ZFMISC-1K2 X1,X2 :],[:ZFMISC-1K2 Y1,Y2 :])"
proof
(*coherence*)
  show "[:FUNCT-3K16 f1,f2 :] be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X1,X2 :],[:ZFMISC-1K2 Y1,Y2 :])"
    using funct_3_th_74 sorry
qed "sorry"

mtheorem funct_3_th_75:
" for C1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be FunctionFUNCT-2M1-of(C1,D1) holds  for f2 be FunctionFUNCT-2M1-of(C2,D2) holds  for c1 be ElementSUBSET-1M1-of C1 holds  for c2 be ElementSUBSET-1M1-of C2 holds ([:FUNCT-3K17\<^bsub>(C1,C2,D1,D2)\<^esub> f1,f2 :]).BINOP-1K2\<^bsub>(C1,C2,[:ZFMISC-1K2 D1,D2 :])\<^esub>(c1,c2) =HIDDENR1 [TARSKIK4 f1 .FUNCT-2K3\<^bsub>(C1,D1)\<^esub> c1,f2 .FUNCT-2K3\<^bsub>(C2,D2)\<^esub> c2 ]"
proof-
  have " for C1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be FunctionFUNCT-2M1-of(C1,D1) holds  for f2 be FunctionFUNCT-2M1-of(C2,D2) holds  for c1 be ElementSUBSET-1M1-of C1 holds  for c2 be ElementSUBSET-1M1-of C2 holds ([:FUNCT-3K17\<^bsub>(C1,C2,D1,D2)\<^esub> f1,f2 :]).BINOP-1K2\<^bsub>(C1,C2,[:ZFMISC-1K2 D1,D2 :])\<^esub>(c1,c2) =HIDDENR1 [TARSKIK4 f1 .FUNCT-2K3\<^bsub>(C1,D1)\<^esub> c1,f2 .FUNCT-2K3\<^bsub>(C2,D2)\<^esub> c2 ]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix C1 assume [ty]: "C1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix C2 assume [ty]: "C2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D1 assume [ty]: "D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D2 assume [ty]: "D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be FunctionFUNCT-2M1-of(C1,D1)"
    fix f2 assume [ty]: "f2 be FunctionFUNCT-2M1-of(C2,D2)"
    fix c1 assume [ty]: "c1 be ElementSUBSET-1M1-of C1"
    fix c2 assume [ty]: "c2 be ElementSUBSET-1M1-of C2"
    have "domRELSET-1K1\<^bsub>(C1)\<^esub> f1 =XBOOLE-0R4 C1 & domRELSET-1K1\<^bsub>(C2)\<^esub> f2 =XBOOLE-0R4 C2"
      using funct_2_def_1 sorry
    thus "([:FUNCT-3K17\<^bsub>(C1,C2,D1,D2)\<^esub> f1,f2 :]).BINOP-1K2\<^bsub>(C1,C2,[:ZFMISC-1K2 D1,D2 :])\<^esub>(c1,c2) =HIDDENR1 [TARSKIK4 f1 .FUNCT-2K3\<^bsub>(C1,D1)\<^esub> c1,f2 .FUNCT-2K3\<^bsub>(C2,D2)\<^esub> c2 ]"
      using funct_3_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_76:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for f1 be FunctionFUNCT-2M1-of(X1,Y1) holds  for f2 be FunctionFUNCT-2M1-of(X2,Y2) holds (Y1 =XBOOLE-0R4 {}XBOOLE-0K1 implies X1 =XBOOLE-0R4 {}XBOOLE-0K1) & (Y2 =XBOOLE-0R4 {}XBOOLE-0K1 implies X2 =XBOOLE-0R4 {}XBOOLE-0K1) implies [:FUNCT-3K17\<^bsub>(X1,X2,Y1,Y2)\<^esub> f1,f2 :] =FUNCT-1R1 <:FUNCT-3K14 f1 *FUNCT-1K3 pr1FUNCT-3K10(X1,X2),f2 *FUNCT-1K3 pr2FUNCT-3K11(X1,X2) :>"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for f1 be FunctionFUNCT-2M1-of(X1,Y1) holds  for f2 be FunctionFUNCT-2M1-of(X2,Y2) holds (Y1 =XBOOLE-0R4 {}XBOOLE-0K1 implies X1 =XBOOLE-0R4 {}XBOOLE-0K1) & (Y2 =XBOOLE-0R4 {}XBOOLE-0K1 implies X2 =XBOOLE-0R4 {}XBOOLE-0K1) implies [:FUNCT-3K17\<^bsub>(X1,X2,Y1,Y2)\<^esub> f1,f2 :] =FUNCT-1R1 <:FUNCT-3K14 f1 *FUNCT-1K3 pr1FUNCT-3K10(X1,X2),f2 *FUNCT-1K3 pr2FUNCT-3K11(X1,X2) :>"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix Y2 assume [ty]: "Y2 be setHIDDENM2"
    fix f1 assume [ty]: "f1 be FunctionFUNCT-2M1-of(X1,Y1)"
    fix f2 assume [ty]: "f2 be FunctionFUNCT-2M1-of(X2,Y2)"
    assume "(Y1 =XBOOLE-0R4 {}XBOOLE-0K1 implies X1 =XBOOLE-0R4 {}XBOOLE-0K1) & (Y2 =XBOOLE-0R4 {}XBOOLE-0K1 implies X2 =XBOOLE-0R4 {}XBOOLE-0K1)"
    then have "domRELSET-1K1\<^bsub>(X1)\<^esub> f1 =XBOOLE-0R4 X1 & domRELSET-1K1\<^bsub>(X2)\<^esub> f2 =XBOOLE-0R4 X2"
      using funct_2_def_1 sorry
    thus "[:FUNCT-3K17\<^bsub>(X1,X2,Y1,Y2)\<^esub> f1,f2 :] =FUNCT-1R1 <:FUNCT-3K14 f1 *FUNCT-1K3 pr1FUNCT-3K10(X1,X2),f2 *FUNCT-1K3 pr2FUNCT-3K11(X1,X2) :>"
      using funct_3_th_66 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_77:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be FunctionFUNCT-2M1-of(X1,D1) holds  for f2 be FunctionFUNCT-2M1-of(X2,D2) holds [:FUNCT-3K17\<^bsub>(X1,X2,D1,D2)\<^esub> f1,f2 :] =FUNCT-1R1 <:FUNCT-3K14 f1 *FUNCT-1K3 pr1FUNCT-3K10(X1,X2),f2 *FUNCT-1K3 pr2FUNCT-3K11(X1,X2) :>"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be FunctionFUNCT-2M1-of(X1,D1) holds  for f2 be FunctionFUNCT-2M1-of(X2,D2) holds [:FUNCT-3K17\<^bsub>(X1,X2,D1,D2)\<^esub> f1,f2 :] =FUNCT-1R1 <:FUNCT-3K14 f1 *FUNCT-1K3 pr1FUNCT-3K10(X1,X2),f2 *FUNCT-1K3 pr2FUNCT-3K11(X1,X2) :>"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix D1 assume [ty]: "D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D2 assume [ty]: "D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be FunctionFUNCT-2M1-of(X1,D1)"
    fix f2 assume [ty]: "f2 be FunctionFUNCT-2M1-of(X2,D2)"
    have "domRELSET-1K1\<^bsub>(X1)\<^esub> f1 =XBOOLE-0R4 X1 & domRELSET-1K1\<^bsub>(X2)\<^esub> f2 =XBOOLE-0R4 X2"
      using funct_2_def_1 sorry
    thus "[:FUNCT-3K17\<^bsub>(X1,X2,D1,D2)\<^esub> f1,f2 :] =FUNCT-1R1 <:FUNCT-3K14 f1 *FUNCT-1K3 pr1FUNCT-3K10(X1,X2),f2 *FUNCT-1K3 pr2FUNCT-3K11(X1,X2) :>"
      using funct_3_th_66 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_3_th_78:
" for X be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for f1 be FunctionFUNCT-2M1-of(X,Y1) holds  for f2 be FunctionFUNCT-2M1-of(X,Y2) holds <:FUNCT-3K14 f1,f2 :> =FUNCT-1R1 ([:FUNCT-3K17\<^bsub>(X,X,Y1,Y2)\<^esub> f1,f2 :])*FUNCT-1K3 deltaFUNCT-3K13 X"
proof-
  have " for X be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for f1 be FunctionFUNCT-2M1-of(X,Y1) holds  for f2 be FunctionFUNCT-2M1-of(X,Y2) holds <:FUNCT-3K14 f1,f2 :> =HIDDENR1 ([:FUNCT-3K17\<^bsub>(X,X,Y1,Y2)\<^esub> f1,f2 :])*FUNCT-1K3 deltaFUNCT-3K13 X"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix Y2 assume [ty]: "Y2 be setHIDDENM2"
    fix f1 assume [ty]: "f1 be FunctionFUNCT-2M1-of(X,Y1)"
    fix f2 assume [ty]: "f2 be FunctionFUNCT-2M1-of(X,Y2)"
    show "<:FUNCT-3K14 f1,f2 :> =HIDDENR1 ([:FUNCT-3K17\<^bsub>(X,X,Y1,Y2)\<^esub> f1,f2 :])*FUNCT-1K3 deltaFUNCT-3K13 X"
    proof-
      have cases: "(Y1 =XBOOLE-0R4 {}XBOOLE-0K1 or Y2 =XBOOLE-0R4 {}XBOOLE-0K1) or Y1 <>HIDDENR2 {}XBOOLE-0K1 & Y2 <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "Y1 =XBOOLE-0R4 {}XBOOLE-0K1 or Y2 =XBOOLE-0R4 {}XBOOLE-0K1 implies <:FUNCT-3K14 f1,f2 :> =HIDDENR1 ([:FUNCT-3K17\<^bsub>(X,X,Y1,Y2)\<^esub> f1,f2 :])*FUNCT-1K3 deltaFUNCT-3K13 X"
      proof(rule impI)
        assume "Y1 =XBOOLE-0R4 {}XBOOLE-0K1 or Y2 =XBOOLE-0R4 {}XBOOLE-0K1"
        then have A1: "domRELSET-1K1\<^bsub>(X)\<^esub> f1 =XBOOLE-0R4 {}XBOOLE-0K1 or domRELSET-1K1\<^bsub>(X)\<^esub> f2 =XBOOLE-0R4 {}XBOOLE-0K1"
           sorry
        have A2: "domRELSET-1K1\<^bsub>([:ZFMISC-1K2 X,X :])\<^esub> ([:FUNCT-3K17\<^bsub>(X,X,Y1,Y2)\<^esub> f1,f2 :]) =HIDDENR1 [:MCART-1K8\<^bsub>(X,X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> f1,domRELSET-1K1\<^bsub>(X)\<^esub> f2 :]"
          using funct_3_def_8 sorry
        also have "... = {}XBOOLE-0K1"
          using A1 zfmisc_1_th_90 sorry
        finally have "domRELSET-1K1\<^bsub>([:ZFMISC-1K2 X,X :])\<^esub> ([:FUNCT-3K17\<^bsub>(X,X,Y1,Y2)\<^esub> f1,f2 :]) =HIDDENR1 {}XBOOLE-0K1"
           sorry
        have "domRELAT-1K1 (<:FUNCT-3K14 f1,f2 :>) =HIDDENR1 domRELSET-1K1\<^bsub>(X)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> f2"
          using funct_3_def_7 sorry
        also have "... = {}XBOOLE-0K1"
          using A1 sorry
        finally have "domRELAT-1K1 (<:FUNCT-3K14 f1,f2 :>) =HIDDENR1 {}XBOOLE-0K1"
           sorry
        then have "<:FUNCT-3K14 f1,f2 :> =HIDDENR1 {}XBOOLE-0K1 *FUNCT-1K3 deltaFUNCT-3K13 X"
           sorry
        also have "... = ([:FUNCT-3K17\<^bsub>(X,X,Y1,Y2)\<^esub> f1,f2 :])*FUNCT-1K3 deltaFUNCT-3K13 X"
          using A2 relat_1_th_41 sorry
        finally show "<:FUNCT-3K14 f1,f2 :> =HIDDENR1 ([:FUNCT-3K17\<^bsub>(X,X,Y1,Y2)\<^esub> f1,f2 :])*FUNCT-1K3 deltaFUNCT-3K13 X"
           sorry
      qed
      have case2: "Y1 <>HIDDENR2 {}XBOOLE-0K1 & Y2 <>HIDDENR2 {}XBOOLE-0K1 implies <:FUNCT-3K14 f1,f2 :> =FUNCT-1R1 ([:FUNCT-3K17\<^bsub>(X,X,Y1,Y2)\<^esub> f1,f2 :])*FUNCT-1K3 deltaFUNCT-3K13 X"
      proof(rule impI)
        assume "Y1 <>HIDDENR2 {}XBOOLE-0K1 & Y2 <>HIDDENR2 {}XBOOLE-0K1"
        then have "domRELSET-1K1\<^bsub>(X)\<^esub> f1 =XBOOLE-0R4 X & domRELSET-1K1\<^bsub>(X)\<^esub> f2 =XBOOLE-0R4 X"
          using funct_2_def_1 sorry
        thus "<:FUNCT-3K14 f1,f2 :> =FUNCT-1R1 ([:FUNCT-3K17\<^bsub>(X,X,Y1,Y2)\<^esub> f1,f2 :])*FUNCT-1K3 deltaFUNCT-3K13 X"
          using funct_3_th_68 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem funct_3_th_79:
" for f be FunctionFUNCT-1M1 holds pr1FUNCT-3K10(domRELAT-1K1 f,rngFUNCT-1K2 f) .:FUNCT-1K5 f =XBOOLE-0R4 domRELAT-1K1 f"
proof(rule ballI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  have " for y be objectHIDDENM1 holds (y inHIDDENR3 domRELAT-1K1 f implies ( ex x be objectHIDDENM1 st (x inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 domRELAT-1K1 f,rngFUNCT-1K2 f :])\<^esub> (pr1FUNCT-3K10(domRELAT-1K1 f,rngFUNCT-1K2 f)) & x inHIDDENR3 f) & y =HIDDENR1 pr1FUNCT-3K10(domRELAT-1K1 f,rngFUNCT-1K2 f) .FUNCT-1K1 x)) & (( ex x be objectHIDDENM1 st (x inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 domRELAT-1K1 f,rngFUNCT-1K2 f :])\<^esub> (pr1FUNCT-3K10(domRELAT-1K1 f,rngFUNCT-1K2 f)) & x inHIDDENR3 f) & y =HIDDENR1 pr1FUNCT-3K10(domRELAT-1K1 f,rngFUNCT-1K2 f) .FUNCT-1K1 x) implies y inHIDDENR3 domRELAT-1K1 f)"
  proof(rule ballI,rule conjMI,rule impI)
    fix y assume [ty]: "y be objectHIDDENM1"
    show "y inHIDDENR3 domRELAT-1K1 f implies ( ex x be objectHIDDENM1 st (x inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 domRELAT-1K1 f,rngFUNCT-1K2 f :])\<^esub> (pr1FUNCT-3K10(domRELAT-1K1 f,rngFUNCT-1K2 f)) & x inHIDDENR3 f) & y =HIDDENR1 pr1FUNCT-3K10(domRELAT-1K1 f,rngFUNCT-1K2 f) .FUNCT-1K1 x)"
    proof-
      have "y inHIDDENR3 domRELAT-1K1 f implies ( ex tVar7 be objectHIDDENM1 st tVar7 inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 domRELAT-1K1 f,rngFUNCT-1K2 f :])\<^esub> (pr1FUNCT-3K10(domRELAT-1K1 f,rngFUNCT-1K2 f)) & (tVar7 inHIDDENR3 f & y =HIDDENR1 pr1FUNCT-3K10(domRELAT-1K1 f,rngFUNCT-1K2 f) .FUNCT-1K1 tVar7))"
      proof(rule impI)
        assume A1: "y inHIDDENR3 domRELAT-1K1 f"
        show " ex tVar7 be objectHIDDENM1 st tVar7 inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 domRELAT-1K1 f,rngFUNCT-1K2 f :])\<^esub> (pr1FUNCT-3K10(domRELAT-1K1 f,rngFUNCT-1K2 f)) & (tVar7 inHIDDENR3 f & y =HIDDENR1 pr1FUNCT-3K10(domRELAT-1K1 f,rngFUNCT-1K2 f) .FUNCT-1K1 tVar7)"
        proof(rule bexI[of _ "[TARSKIK4 y,f .FUNCT-1K1 y ]"],rule conjMI,rule conjMI)
          have A2: "f .FUNCT-1K1 y inTARSKIR2 rngFUNCT-1K2 f"
            using A1 funct_1_def_3 sorry
          then have "[TARSKIK4 y,f .FUNCT-1K1 y ] inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 f,rngFUNCT-1K2 f :]"
            using A1 zfmisc_1_th_87 sorry
          thus "[TARSKIK4 y,f .FUNCT-1K1 y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 domRELAT-1K1 f,rngFUNCT-1K2 f :])\<^esub> (pr1FUNCT-3K10(domRELAT-1K1 f,rngFUNCT-1K2 f))"
            using funct_3_def_4 sorry
          show "[TARSKIK4 y,f .FUNCT-1K1 y ] inHIDDENR3 f"
            using A1 funct_1_def_2 sorry
          have "y =HIDDENR1 pr1FUNCT-3K10(domRELAT-1K1 f,rngFUNCT-1K2 f) .BINOP-1K1(y,f .FUNCT-1K1 y)"
            using A1 A2 funct_3_def_4 sorry
          also have "... = pr1FUNCT-3K10(domRELAT-1K1 f,rngFUNCT-1K2 f) .FUNCT-1K1 [TARSKIK4 y,f .FUNCT-1K1 y ]"
             sorry
          finally show "y =HIDDENR1 pr1FUNCT-3K10(domRELAT-1K1 f,rngFUNCT-1K2 f) .FUNCT-1K1 [TARSKIK4 y,f .FUNCT-1K1 y ]"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex x be objectHIDDENM1 st (x inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 domRELAT-1K1 f,rngFUNCT-1K2 f :])\<^esub> (pr1FUNCT-3K10(domRELAT-1K1 f,rngFUNCT-1K2 f)) & x inHIDDENR3 f) & y =HIDDENR1 pr1FUNCT-3K10(domRELAT-1K1 f,rngFUNCT-1K2 f) .FUNCT-1K1 x"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A3: "x inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 domRELAT-1K1 f,rngFUNCT-1K2 f :])\<^esub> (pr1FUNCT-3K10(domRELAT-1K1 f,rngFUNCT-1K2 f))"and "x inHIDDENR3 f"and A4: "y =HIDDENR1 pr1FUNCT-3K10(domRELAT-1K1 f,rngFUNCT-1K2 f) .FUNCT-1K1 x"
       sorry
    obtain x1 x2 where
      [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" and 
      A5: "x1 inHIDDENR3 domRELAT-1K1 f & x2 inHIDDENR3 rngFUNCT-1K2 f"and A6: "x =HIDDENR1 [TARSKIK4 x1,x2 ]"
      using A3 zfmisc_1_th_84 sorry
    have "y =HIDDENR1 pr1FUNCT-3K10(domRELAT-1K1 f,rngFUNCT-1K2 f) .BINOP-1K1(x1,x2)"
      using A4 A6 sorry
    thus "y inHIDDENR3 domRELAT-1K1 f"
      using A5 funct_3_def_4 sorry
  qed "sorry"
  thus "pr1FUNCT-3K10(domRELAT-1K1 f,rngFUNCT-1K2 f) .:FUNCT-1K5 f =XBOOLE-0R4 domRELAT-1K1 f"
    using funct_1_def_6 sorry
qed "sorry"

mtheorem funct_3_th_80:
" for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(A,[:ZFMISC-1K2 B,C :]) holds  for g be FunctionFUNCT-2M1-of(A,[:ZFMISC-1K2 B,C :]) holds pr1FUNCT-3K10(B,C) *FUNCT-1K3 f =FUNCT-1R1 pr1FUNCT-3K10(B,C) *FUNCT-1K3 g & pr2FUNCT-3K11(B,C) *FUNCT-1K3 f =FUNCT-1R1 pr2FUNCT-3K11(B,C) *FUNCT-1K3 g implies f =FUNCT-2R2\<^bsub>(A,[:ZFMISC-1K2 B,C :])\<^esub> g"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix B assume [ty]: "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix f assume [ty]: "f be FunctionFUNCT-2M1-of(A,[:ZFMISC-1K2 B,C :])"
  fix g assume [ty]: "g be FunctionFUNCT-2M1-of(A,[:ZFMISC-1K2 B,C :])"
  assume A1: "pr1FUNCT-3K10(B,C) *FUNCT-1K3 f =FUNCT-1R1 pr1FUNCT-3K10(B,C) *FUNCT-1K3 g & pr2FUNCT-3K11(B,C) *FUNCT-1K3 f =FUNCT-1R1 pr2FUNCT-3K11(B,C) *FUNCT-1K3 g"
  have " for a be ElementSUBSET-1M1-of A holds f .FUNCT-2K3\<^bsub>(A,[:ZFMISC-1K2 B,C :])\<^esub> a =XBOOLE-0R4 g .FUNCT-2K3\<^bsub>(A,[:ZFMISC-1K2 B,C :])\<^esub> a"
  proof(rule ballI)
    fix a assume [ty]: "a be ElementSUBSET-1M1-of A"
    obtain b1 c1 where
      [ty]:"b1 be ElementSUBSET-1M1-of B" "c1 be ElementSUBSET-1M1-of C" and 
      A2: "f .FUNCT-2K3\<^bsub>(A,[:ZFMISC-1K2 B,C :])\<^esub> a =HIDDENR1 [TARSKIK4 b1,c1 ]"
      using domain_1_th_1 sorry
    obtain b2 c2 where
      [ty]:"b2 be ElementSUBSET-1M1-of B" "c2 be ElementSUBSET-1M1-of C" and 
      A3: "g .FUNCT-2K3\<^bsub>(A,[:ZFMISC-1K2 B,C :])\<^esub> a =HIDDENR1 [TARSKIK4 b2,c2 ]"
      using domain_1_th_1 sorry
    have A4: "pr1FUNCT-3K10(B,C) .FUNCT-2K3\<^bsub>([:ZFMISC-1K2 B,C :],B)\<^esub> (g .FUNCT-2K3\<^bsub>(A,[:ZFMISC-1K2 B,C :])\<^esub> a) =XBOOLE-0R4 (pr1FUNCT-3K10(B,C) *FUNCT-1K3 g).FUNCT-1K1 a"
      using funct_2_th_15 sorry
    have A5: "pr1FUNCT-3K10(B,C) .FUNCT-2K3\<^bsub>([:ZFMISC-1K2 B,C :],B)\<^esub> (f .FUNCT-2K3\<^bsub>(A,[:ZFMISC-1K2 B,C :])\<^esub> a) =XBOOLE-0R4 (pr1FUNCT-3K10(B,C) *FUNCT-1K3 f).FUNCT-1K1 a & pr2FUNCT-3K11(B,C) .FUNCT-2K3\<^bsub>([:ZFMISC-1K2 B,C :],C)\<^esub> (f .FUNCT-2K3\<^bsub>(A,[:ZFMISC-1K2 B,C :])\<^esub> a) =XBOOLE-0R4 (pr2FUNCT-3K11(B,C) *FUNCT-1K3 f).FUNCT-1K1 a"
      using funct_2_th_15 sorry
    have A6: "pr2FUNCT-3K11(B,C) .BINOP-1K2\<^bsub>(B,C,C)\<^esub>(b1,c1) =XBOOLE-0R4 c1 & pr2FUNCT-3K11(B,C) .BINOP-1K2\<^bsub>(B,C,C)\<^esub>(b2,c2) =XBOOLE-0R4 c2"
      using funct_3_def_5 sorry
    have "pr1FUNCT-3K10(B,C) .BINOP-1K2\<^bsub>(B,C,B)\<^esub>(b1,c1) =XBOOLE-0R4 b1 & pr1FUNCT-3K10(B,C) .BINOP-1K2\<^bsub>(B,C,B)\<^esub>(b2,c2) =XBOOLE-0R4 b2"
      using funct_3_def_4 sorry
    thus "f .FUNCT-2K3\<^bsub>(A,[:ZFMISC-1K2 B,C :])\<^esub> a =XBOOLE-0R4 g .FUNCT-2K3\<^bsub>(A,[:ZFMISC-1K2 B,C :])\<^esub> a"
      using A1 A2 A3 A6 A5 A4 funct_2_th_15 sorry
  qed "sorry"
  thus "f =FUNCT-2R2\<^bsub>(A,[:ZFMISC-1K2 B,C :])\<^esub> g"
     sorry
qed "sorry"

mtheorem funct_3_cl_3:
  mlet "F be one-to-oneFUNCT-1V2\<bar>FunctionFUNCT-1M1", "G be one-to-oneFUNCT-1V2\<bar>FunctionFUNCT-1M1"
"cluster [:FUNCT-3K16 F,G :] as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "[:FUNCT-3K16 F,G :] be one-to-oneFUNCT-1V2"
  proof-
    have " for z1 be objectHIDDENM1 holds  for z2 be objectHIDDENM1 holds z1 inHIDDENR3 domRELAT-1K1 ([:FUNCT-3K16 F,G :]) & (z2 inHIDDENR3 domRELAT-1K1 ([:FUNCT-3K16 F,G :]) & ([:FUNCT-3K16 F,G :]).FUNCT-1K1 z1 =XBOOLE-0R4 ([:FUNCT-3K16 F,G :]).FUNCT-1K1 z2) implies z1 =HIDDENR1 z2"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix z1 assume [ty]: "z1 be objectHIDDENM1"
      fix z2 assume [ty]: "z2 be objectHIDDENM1"
      assume A1: "z1 inHIDDENR3 domRELAT-1K1 ([:FUNCT-3K16 F,G :])"
        and A2: "z2 inHIDDENR3 domRELAT-1K1 ([:FUNCT-3K16 F,G :])"
        and A3: "([:FUNCT-3K16 F,G :]).FUNCT-1K1 z1 =XBOOLE-0R4 ([:FUNCT-3K16 F,G :]).FUNCT-1K1 z2"
      have A4: "domRELAT-1K1 ([:FUNCT-3K16 F,G :]) =XBOOLE-0R4 [:ZFMISC-1K2 domRELAT-1K1 F,domRELAT-1K1 G :]"
        using funct_3_def_8 sorry
      then obtain x1 y1 where
        [ty]:"x1 be objectHIDDENM1" "y1 be objectHIDDENM1" and 
        A5: "x1 inHIDDENR3 domRELAT-1K1 F"and A6: "y1 inHIDDENR3 domRELAT-1K1 G"and A7: "z1 =HIDDENR1 [TARSKIK4 x1,y1 ]"
        using A1 zfmisc_1_th_84 sorry
      have A8: "([:FUNCT-3K16 F,G :]).BINOP-1K1(x1,y1) =HIDDENR1 [TARSKIK4 F .FUNCT-1K1 x1,G .FUNCT-1K1 y1 ]"
        using A5 A6 funct_3_def_8 sorry
      obtain x2 y2 where
        [ty]:"x2 be objectHIDDENM1" "y2 be objectHIDDENM1" and 
        A9: "x2 inHIDDENR3 domRELAT-1K1 F"and A10: "y2 inHIDDENR3 domRELAT-1K1 G"and A11: "z2 =HIDDENR1 [TARSKIK4 x2,y2 ]"
        using A2 A4 zfmisc_1_th_84 sorry
      have A12: "([:FUNCT-3K16 F,G :]).BINOP-1K1(x2,y2) =HIDDENR1 [TARSKIK4 F .FUNCT-1K1 x2,G .FUNCT-1K1 y2 ]"
        using A9 A10 funct_3_def_8 sorry
      then have "F .FUNCT-1K1 x1 =XBOOLE-0R4 F .FUNCT-1K1 x2"
        using A3 A7 A11 A8 xtuple_0_th_1 sorry
      then have A13: "x1 =HIDDENR1 x2"
        using A5 A9 funct_1_def_4 sorry
      have "G .FUNCT-1K1 y1 =XBOOLE-0R4 G .FUNCT-1K1 y2"
        using A3 A7 A11 A8 A12 xtuple_0_th_1 sorry
      thus "z1 =HIDDENR1 z2"
        using A6 A7 A10 A11 A13 funct_1_def_4 sorry
    qed "sorry"
    thus "[:FUNCT-3K16 F,G :] be one-to-oneFUNCT-1V2"
      using funct_1_def_4 sorry
  qed
qed "sorry"

mtheorem funct_3_cl_4:
  mlet "A be setHIDDENM2"
"cluster idempotentBINOP-1V3\<^bsub>(A)\<^esub> for BinOpBINOP-1M2-of A"
proof
(*existence*)
  show " ex it be BinOpBINOP-1M2-of A st it be idempotentBINOP-1V3\<^bsub>(A)\<^esub>"
  proof-
    have " ex tVar8 be BinOpBINOP-1M2-of A st tVar8 be idempotentBINOP-1V3\<^bsub>(A)\<^esub>"
    proof-
      show " ex tVar8 be BinOpBINOP-1M2-of A st tVar8 be idempotentBINOP-1V3\<^bsub>(A)\<^esub>"
      proof(rule bexI[of _ "pr1FUNCT-3K10(A,A)"])
        show "pr1FUNCT-3K10(A,A) be idempotentBINOP-1V3\<^bsub>(A)\<^esub>"
        proof-
          have cases: "A <>HIDDENR2 {}XBOOLE-0K1 or A =XBOOLE-0R4 {}XBOOLE-0K1"
             sorry
          have case1: "A <>HIDDENR2 {}XBOOLE-0K1 implies pr1FUNCT-3K10(A,A) be idempotentBINOP-1V3\<^bsub>(A)\<^esub>"
          proof(rule impI)
            assume A1: "A <>HIDDENR2 {}XBOOLE-0K1"
            have " for a be ElementSUBSET-1M1-of A holds pr1FUNCT-3K10(A,A) .BINOP-1K4\<^bsub>(A)\<^esub>(a,a) =XBOOLE-0R4 a"
            proof(rule ballI)
              fix a assume [ty]: "a be ElementSUBSET-1M1-of A"
              have "a inTARSKIR2 A"
                using A1 sorry
              thus "pr1FUNCT-3K10(A,A) .BINOP-1K4\<^bsub>(A)\<^esub>(a,a) =XBOOLE-0R4 a"
                using funct_3_def_4 sorry
            qed "sorry"
            thus "pr1FUNCT-3K10(A,A) be idempotentBINOP-1V3\<^bsub>(A)\<^esub>"
              using binop_1_def_4 sorry
          qed
          have case2: "A =XBOOLE-0R4 {}XBOOLE-0K1 implies pr1FUNCT-3K10(A,A) be idempotentBINOP-1V3\<^bsub>(A)\<^esub>"
          proof(rule impI)
            assume A2: "A =XBOOLE-0R4 {}XBOOLE-0K1"
            have " for a be ElementSUBSET-1M1-of A holds pr1FUNCT-3K10(A,A) .BINOP-1K4\<^bsub>(A)\<^esub>(a,a) =HIDDENR1 a"
            proof(rule ballI)
              fix a assume [ty]: "a be ElementSUBSET-1M1-of A"
              have " not [TARSKIK4 a,a ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 A,A :])\<^esub> (pr1FUNCT-3K10(A,A))"
                using A2 sorry
              then have "pr1FUNCT-3K10(A,A) .BINOP-1K4\<^bsub>(A)\<^esub>(a,a) =HIDDENR1 {}XBOOLE-0K1"
                using funct_1_def_2 sorry
              also have "... = a"
                using A2 subset_1_def_1 sorry
              finally show "pr1FUNCT-3K10(A,A) .BINOP-1K4\<^bsub>(A)\<^esub>(a,a) =HIDDENR1 a"
                 sorry
            qed "sorry"
            thus "pr1FUNCT-3K10(A,A) be idempotentBINOP-1V3\<^bsub>(A)\<^esub>"
              using binop_1_def_4 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funct_3_reduce_1:
  mlet "A be setHIDDENM2", "b be idempotentBINOP-1V3\<^bsub>(A)\<^esub>\<bar>BinOpBINOP-1M2-of A", "a be ElementSUBSET-1M1-of A"
"reduce b .BINOP-1K4\<^bsub>(A)\<^esub>(a,a) to a"
proof
(*reducibility*)
  show "b .BINOP-1K4\<^bsub>(A)\<^esub>(a,a) =HIDDENR1 a"
    using binop_1_def_4 sorry
qed "sorry"

reserve A1, A2, B1, B2 for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve f for "FunctionFUNCT-2M1-of(A1,B1)"
reserve g for "FunctionFUNCT-2M1-of(A2,B2)"
reserve Y1 for " non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of A1"
reserve Y2 for " non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of A2"
syntax FUNCT_3K18 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _  |FUNCT-3K18\<^bsub>'( _ , _ ')\<^esub>  _ " [200,0,0,200]200)
translations "f  |FUNCT-3K18\<^bsub>(A1,B1)\<^esub> Y1" \<rightharpoonup> "f  |RELAT-1K8 Y1"

mtheorem funct_3_add_9:
  mlet "A1 be setHIDDENM2", "B1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(A1,B1)", "Y1 be SubsetSUBSET-1M2-of A1"
"cluster f  |RELAT-1K8 Y1 as-term-is FunctionFUNCT-2M1-of(Y1,B1)"
proof
(*coherence*)
  show "f  |RELAT-1K8 Y1 be FunctionFUNCT-2M1-of(Y1,B1)"
    using funct_2_th_32 sorry
qed "sorry"

mtheorem funct_3_th_81:
" for A1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(A1,B1) holds  for g be FunctionFUNCT-2M1-of(A2,B2) holds  for Y1 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of A1 holds  for Y2 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of A2 holds ([:FUNCT-3K17\<^bsub>(A1,A2,B1,B2)\<^esub> f,g :]) |FUNCT-3K18\<^bsub>([:ZFMISC-1K2 A1,A2 :],[:ZFMISC-1K2 B1,B2 :])\<^esub> ([:MCART-1K8\<^bsub>(A1,A2)\<^esub> Y1,Y2 :]) =BINOP-1R13\<^bsub>(Y1,Y2,[:ZFMISC-1K2 B1,B2 :])\<^esub> [:FUNCT-3K17\<^bsub>(Y1,Y2,B1,B2)\<^esub> f  |FUNCT-3K18\<^bsub>(A1,B1)\<^esub> Y1,g  |FUNCT-3K18\<^bsub>(A2,B2)\<^esub> Y2 :]"
proof-
  have " for A1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(A1,B1) holds  for g be FunctionFUNCT-2M1-of(A2,B2) holds  for Y1 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of A1 holds  for Y2 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of A2 holds ([:FUNCT-3K17\<^bsub>(A1,A2,B1,B2)\<^esub> f,g :]) |FUNCT-3K18\<^bsub>([:ZFMISC-1K2 A1,A2 :],[:ZFMISC-1K2 B1,B2 :])\<^esub> ([:MCART-1K8\<^bsub>(A1,A2)\<^esub> Y1,Y2 :]) =BINOP-1R13\<^bsub>(Y1,Y2,[:ZFMISC-1K2 B1,B2 :])\<^esub> [:FUNCT-3K17\<^bsub>(Y1,Y2,B1,B2)\<^esub> f  |FUNCT-3K18\<^bsub>(A1,B1)\<^esub> Y1,g  |FUNCT-3K18\<^bsub>(A2,B2)\<^esub> Y2 :]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix A1 assume [ty]: "A1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A2 assume [ty]: "A2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix B1 assume [ty]: "B1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix B2 assume [ty]: "B2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(A1,B1)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(A2,B2)"
    fix Y1 assume [ty]: "Y1 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of A1"
    fix Y2 assume [ty]: "Y2 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of A2"
    have " for a be ElementSUBSET-1M3\<^bsub>([:ZFMISC-1K2 A1,A2 :])\<^esub>-of [:MCART-1K8\<^bsub>(A1,A2)\<^esub> Y1,Y2 :] holds ([:FUNCT-3K17\<^bsub>(Y1,Y2,B1,B2)\<^esub> f  |FUNCT-3K18\<^bsub>(A1,B1)\<^esub> Y1,g  |FUNCT-3K18\<^bsub>(A2,B2)\<^esub> Y2 :]).FUNCT-2K3\<^bsub>([:MCART-1K8\<^bsub>(A1,A2)\<^esub> Y1,Y2 :],[:ZFMISC-1K2 B1,B2 :])\<^esub> a =HIDDENR1 (([:FUNCT-3K17\<^bsub>(A1,A2,B1,B2)\<^esub> f,g :]) |FUNCT-3K18\<^bsub>([:ZFMISC-1K2 A1,A2 :],[:ZFMISC-1K2 B1,B2 :])\<^esub> ([:MCART-1K8\<^bsub>(A1,A2)\<^esub> Y1,Y2 :])).FUNCT-2K3\<^bsub>([:MCART-1K8\<^bsub>(A1,A2)\<^esub> Y1,Y2 :],[:ZFMISC-1K2 B1,B2 :])\<^esub> a"
    proof(rule ballI)
      fix a assume [ty]: "a be ElementSUBSET-1M3\<^bsub>([:ZFMISC-1K2 A1,A2 :])\<^esub>-of [:MCART-1K8\<^bsub>(A1,A2)\<^esub> Y1,Y2 :]"
      obtain a1 a2 where
        [ty]:"a1 be ElementSUBSET-1M3\<^bsub>(A1)\<^esub>-of Y1" "a2 be ElementSUBSET-1M3\<^bsub>(A2)\<^esub>-of Y2" and 
        A1: "a =HIDDENR1 [TARSKIK4 a1,a2 ]"
        using domain_1_th_1 sorry
      have A2: "(g  |FUNCT-3K18\<^bsub>(A2,B2)\<^esub> Y2).FUNCT-2K3\<^bsub>(Y2,B2)\<^esub> a2 =XBOOLE-0R4 g .FUNCT-2K3\<^bsub>(A2,B2)\<^esub> a2"
        using funct_1_th_49 sorry
      have A3: "(f  |FUNCT-3K18\<^bsub>(A1,B1)\<^esub> Y1).FUNCT-2K3\<^bsub>(Y1,B1)\<^esub> a1 =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(A1,B1)\<^esub> a1"
        using funct_1_th_49 sorry
      have "([:FUNCT-3K17\<^bsub>(Y1,Y2,B1,B2)\<^esub> f  |FUNCT-3K18\<^bsub>(A1,B1)\<^esub> Y1,g  |FUNCT-3K18\<^bsub>(A2,B2)\<^esub> Y2 :]).FUNCT-2K3\<^bsub>([:MCART-1K8\<^bsub>(A1,A2)\<^esub> Y1,Y2 :],[:ZFMISC-1K2 B1,B2 :])\<^esub> a =HIDDENR1 ([:FUNCT-3K17\<^bsub>(Y1,Y2,B1,B2)\<^esub> f  |FUNCT-3K18\<^bsub>(A1,B1)\<^esub> Y1,g  |FUNCT-3K18\<^bsub>(A2,B2)\<^esub> Y2 :]).BINOP-1K2\<^bsub>(Y1,Y2,[:ZFMISC-1K2 B1,B2 :])\<^esub>(a1,a2)"
        using A1 sorry
      also have "... = [TARSKIK4 f .FUNCT-2K3\<^bsub>(A1,B1)\<^esub> a1,g .FUNCT-2K3\<^bsub>(A2,B2)\<^esub> a2 ]"
        using A3 A2 funct_3_th_75 sorry
      also have "... = ([:FUNCT-3K17\<^bsub>(A1,A2,B1,B2)\<^esub> f,g :]).BINOP-1K2\<^bsub>(A1,A2,[:ZFMISC-1K2 B1,B2 :])\<^esub>(a1,a2)"
        using funct_3_th_75 sorry
      also have "... = (([:FUNCT-3K17\<^bsub>(A1,A2,B1,B2)\<^esub> f,g :]) |FUNCT-3K18\<^bsub>([:ZFMISC-1K2 A1,A2 :],[:ZFMISC-1K2 B1,B2 :])\<^esub> ([:MCART-1K8\<^bsub>(A1,A2)\<^esub> Y1,Y2 :])).FUNCT-2K3\<^bsub>([:MCART-1K8\<^bsub>(A1,A2)\<^esub> Y1,Y2 :],[:ZFMISC-1K2 B1,B2 :])\<^esub> a"
        using A1 funct_1_th_49 sorry
      finally show "([:FUNCT-3K17\<^bsub>(Y1,Y2,B1,B2)\<^esub> f  |FUNCT-3K18\<^bsub>(A1,B1)\<^esub> Y1,g  |FUNCT-3K18\<^bsub>(A2,B2)\<^esub> Y2 :]).FUNCT-2K3\<^bsub>([:MCART-1K8\<^bsub>(A1,A2)\<^esub> Y1,Y2 :],[:ZFMISC-1K2 B1,B2 :])\<^esub> a =HIDDENR1 (([:FUNCT-3K17\<^bsub>(A1,A2,B1,B2)\<^esub> f,g :]) |FUNCT-3K18\<^bsub>([:ZFMISC-1K2 A1,A2 :],[:ZFMISC-1K2 B1,B2 :])\<^esub> ([:MCART-1K8\<^bsub>(A1,A2)\<^esub> Y1,Y2 :])).FUNCT-2K3\<^bsub>([:MCART-1K8\<^bsub>(A1,A2)\<^esub> Y1,Y2 :],[:ZFMISC-1K2 B1,B2 :])\<^esub> a"
         sorry
    qed "sorry"
    thus "([:FUNCT-3K17\<^bsub>(A1,A2,B1,B2)\<^esub> f,g :]) |FUNCT-3K18\<^bsub>([:ZFMISC-1K2 A1,A2 :],[:ZFMISC-1K2 B1,B2 :])\<^esub> ([:MCART-1K8\<^bsub>(A1,A2)\<^esub> Y1,Y2 :]) =BINOP-1R13\<^bsub>(Y1,Y2,[:ZFMISC-1K2 B1,B2 :])\<^esub> [:FUNCT-3K17\<^bsub>(Y1,Y2,B1,B2)\<^esub> f  |FUNCT-3K18\<^bsub>(A1,B1)\<^esub> Y1,g  |FUNCT-3K18\<^bsub>(A2,B2)\<^esub> Y2 :]"
      using funct_2_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
