theory newton
  imports rvsum_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve i, j, k, n, m, l, s, t for "NatNAT-1M1"
reserve a, b for "RealXREAL-0M1"
reserve F, G, H for "FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
mtheorem newton_th_1:
" for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies SegFINSEQ-1K2 n =XBOOLE-0R4 ({TARSKIK1 \<one>\<^sub>M} \\/XBOOLE-0K2 ({k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : \<one>\<^sub>M <XXREAL-0R3 k & k <XXREAL-0R3 n }))\\/XBOOLE-0K2 {TARSKIK1 n}"
proof-
  have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies SegFINSEQ-1K2 n =XBOOLE-0R4 ({TARSKIK1 \<one>\<^sub>M} \\/XBOOLE-0K2 ({k where k be ElementSUBSET-1M1-of NATNUMBERSK1 :  not \<one>\<^sub>M <XXREAL-0R3 k &  not k <XXREAL-0R3 n }))\\/XBOOLE-0K2 {TARSKIK1 n}"
  proof(rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "n >=XXREAL-0R2 \<one>\<^sub>M"
    have A2: "({TARSKIK1 \<one>\<^sub>M} \\/XBOOLE-0K2 ({k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : \<one>\<^sub>M <XXREAL-0R3 k & k <XXREAL-0R3 n }))\\/XBOOLE-0K2 {TARSKIK1 n} c=TARSKIR1 SegFINSEQ-1K2 n"
    proof-
      have "({TARSKIK1 \<one>\<^sub>M} \\/XBOOLE-0K2 ({k where k be ElementSUBSET-1M1-of NATNUMBERSK1 :  not \<one>\<^sub>M <XXREAL-0R3 k &  not k <XXREAL-0R3 n }))\\/XBOOLE-0K2 {TARSKIK1 n} c=TARSKIR1 SegFINSEQ-1K2 n"
      proof-
        have " for d be objectHIDDENM1 holds  not (d inHIDDENR3 ({TARSKIK1 \<one>\<^sub>M} \\/XBOOLE-0K2 ({k where k be ElementSUBSET-1M1-of NATNUMBERSK1 :  not \<one>\<^sub>M <XXREAL-0R3 k &  not k <XXREAL-0R3 n }))\\/XBOOLE-0K2 {TARSKIK1 n} &  not d inHIDDENR3 SegFINSEQ-1K2 n)"
        proof(rule ballI)
          fix d assume [ty]: "d be objectHIDDENM1"
          have A3: "{k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : \<one>\<^sub>M <XXREAL-0R3 k & k <XXREAL-0R3 n } c=TARSKIR1 SegFINSEQ-1K2 n"
          proof-
            have "{k where k be ElementSUBSET-1M1-of NATNUMBERSK1 :  not \<one>\<^sub>M <XXREAL-0R3 k &  not k <XXREAL-0R3 n } c=TARSKIR1 SegFINSEQ-1K2 n"
            proof-
              have " for d be objectHIDDENM1 holds d inHIDDENR3 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : \<one>\<^sub>M <XXREAL-0R3 k & k <XXREAL-0R3 n } implies d inHIDDENR3 SegFINSEQ-1K2 n"
              proof(rule ballI,rule impI)
                fix d assume [ty]: "d be objectHIDDENM1"
                assume "d inHIDDENR3 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : \<one>\<^sub>M <XXREAL-0R3 k & k <XXREAL-0R3 n }"
                then have " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st (d =HIDDENR1 k & \<one>\<^sub>M <XXREAL-0R3 k) & k <XXREAL-0R3 n"
                   sorry
                thus "d inHIDDENR3 SegFINSEQ-1K2 n"
                   sorry
              qed "sorry"
              thus "{k where k be ElementSUBSET-1M1-of NATNUMBERSK1 :  not \<one>\<^sub>M <XXREAL-0R3 k &  not k <XXREAL-0R3 n } c=TARSKIR1 SegFINSEQ-1K2 n"
                using tarski_def_3 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          have "\<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 n"
            using A1 sorry
          then have "{TARSKIK1 \<one>\<^sub>M} c=MEMBEREDR6 SegFINSEQ-1K2 n"
            using zfmisc_1_th_31 sorry
          then have A4: "{TARSKIK1 \<one>\<^sub>M} \\/XBOOLE-0K2 ({k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : \<one>\<^sub>M <XXREAL-0R3 k & k <XXREAL-0R3 n }) c=TARSKIR1 SegFINSEQ-1K2 n"
            using A3 xboole_1_th_8 sorry
          have "n inTARSKIR2 SegFINSEQ-1K2 n"
            using A1 sorry
          then have "{TARSKIK1 n} c=MEMBEREDR6 SegFINSEQ-1K2 n"
            using zfmisc_1_th_31 sorry
          then have "({TARSKIK1 \<one>\<^sub>M} \\/XBOOLE-0K2 ({k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : \<one>\<^sub>M <XXREAL-0R3 k & k <XXREAL-0R3 n }))\\/XBOOLE-0K2 {TARSKIK1 n} c=TARSKIR1 SegFINSEQ-1K2 n"
            using A4 xboole_1_th_8 sorry
          thus " not (d inHIDDENR3 ({TARSKIK1 \<one>\<^sub>M} \\/XBOOLE-0K2 ({k where k be ElementSUBSET-1M1-of NATNUMBERSK1 :  not \<one>\<^sub>M <XXREAL-0R3 k &  not k <XXREAL-0R3 n }))\\/XBOOLE-0K2 {TARSKIK1 n} &  not d inHIDDENR3 SegFINSEQ-1K2 n)"
             sorry
        qed "sorry"
        thus "({TARSKIK1 \<one>\<^sub>M} \\/XBOOLE-0K2 ({k where k be ElementSUBSET-1M1-of NATNUMBERSK1 :  not \<one>\<^sub>M <XXREAL-0R3 k &  not k <XXREAL-0R3 n }))\\/XBOOLE-0K2 {TARSKIK1 n} c=TARSKIR1 SegFINSEQ-1K2 n"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "SegFINSEQ-1K2 n c=MEMBEREDR6 ({TARSKIK1 \<one>\<^sub>M} \\/XBOOLE-0K2 ({k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : \<one>\<^sub>M <XXREAL-0R3 k & k <XXREAL-0R3 n }))\\/XBOOLE-0K2 {TARSKIK1 n}"
    proof-
      have "SegFINSEQ-1K2 n c=MEMBEREDR6 ({TARSKIK1 \<one>\<^sub>M} \\/XBOOLE-0K2 ({k where k be ElementSUBSET-1M1-of NATNUMBERSK1 :  not \<one>\<^sub>M <XXREAL-0R3 k &  not k <XXREAL-0R3 n }))\\/XBOOLE-0K2 {TARSKIK1 n}"
      proof-
        have " for d be objectHIDDENM1 holds d inHIDDENR3 SegFINSEQ-1K2 n implies d inHIDDENR3 ({TARSKIK1 \<one>\<^sub>M} \\/XBOOLE-0K2 ({k where k be ElementSUBSET-1M1-of NATNUMBERSK1 :  not \<one>\<^sub>M <XXREAL-0R3 k &  not k <XXREAL-0R3 n }))\\/XBOOLE-0K2 {TARSKIK1 n}"
        proof(rule ballI,rule impI)
          fix d assume [ty]: "d be objectHIDDENM1"
          assume A5: "d inHIDDENR3 SegFINSEQ-1K2 n"
          show "d inHIDDENR3 ({TARSKIK1 \<one>\<^sub>M} \\/XBOOLE-0K2 ({k where k be ElementSUBSET-1M1-of NATNUMBERSK1 :  not \<one>\<^sub>M <XXREAL-0R3 k &  not k <XXREAL-0R3 n }))\\/XBOOLE-0K2 {TARSKIK1 n}"
          proof-
            have cases: "n >XXREAL-0R4 \<one>\<^sub>M or n =XBOOLE-0R4 \<one>\<^sub>M"
              using A1 xxreal_0_th_1 sorry
            have case1: "n >XXREAL-0R4 \<one>\<^sub>M implies d inHIDDENR3 ({TARSKIK1 \<one>\<^sub>M} \\/XBOOLE-0K2 ({k where k be ElementSUBSET-1M1-of NATNUMBERSK1 :  not \<one>\<^sub>M <XXREAL-0R3 k &  not k <XXREAL-0R3 n }))\\/XBOOLE-0K2 {TARSKIK1 n}"
            proof(rule impI)
              assume A6: "n >XXREAL-0R4 \<one>\<^sub>M"
              obtain l where 
                [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1" and lDef:"l = d"
                using A5 sorry
              have A7: "l <=XXREAL-0R1 n"
                using A5 finseq_1_th_1 sorry
              have "\<one>\<^sub>M <=XXREAL-0R1 l"
                using A5 finseq_1_th_1 sorry
              then have "((\<one>\<^sub>M =XBOOLE-0R4 l or \<one>\<^sub>M <XXREAL-0R3 l & l <XXREAL-0R3 n) or l =XBOOLE-0R4 n) or \<one>\<^sub>M =XBOOLE-0R4 n"
                using A7 xxreal_0_th_1 sorry
              then have "(d inHIDDENR3 {TARSKIK1 \<one>\<^sub>M} or d inHIDDENR3 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : \<one>\<^sub>M <XXREAL-0R3 k & k <XXREAL-0R3 n }) or d inHIDDENR3 {TARSKIK1 n}"
                using A6 tarski_def_1 sorry
              then have "d inHIDDENR3 {TARSKIK1 \<one>\<^sub>M} \\/XBOOLE-0K2 ({k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : \<one>\<^sub>M <XXREAL-0R3 k & k <XXREAL-0R3 n }) or d inHIDDENR3 {TARSKIK1 n}"
                using xboole_0_def_3 sorry
              thus "d inHIDDENR3 ({TARSKIK1 \<one>\<^sub>M} \\/XBOOLE-0K2 ({k where k be ElementSUBSET-1M1-of NATNUMBERSK1 :  not \<one>\<^sub>M <XXREAL-0R3 k &  not k <XXREAL-0R3 n }))\\/XBOOLE-0K2 {TARSKIK1 n}"
                using xboole_0_def_3 sorry
            qed
            have case2: "n =XBOOLE-0R4 \<one>\<^sub>M implies d inHIDDENR3 ({TARSKIK1 \<one>\<^sub>M} \\/XBOOLE-0K2 ({k where k be ElementSUBSET-1M1-of NATNUMBERSK1 :  not \<one>\<^sub>M <XXREAL-0R3 k &  not k <XXREAL-0R3 n }))\\/XBOOLE-0K2 {TARSKIK1 n}"
            proof(rule impI)
              assume "n =XBOOLE-0R4 \<one>\<^sub>M"
              thus "d inHIDDENR3 ({TARSKIK1 \<one>\<^sub>M} \\/XBOOLE-0K2 ({k where k be ElementSUBSET-1M1-of NATNUMBERSK1 :  not \<one>\<^sub>M <XXREAL-0R3 k &  not k <XXREAL-0R3 n }))\\/XBOOLE-0K2 {TARSKIK1 n}"
                using A5 finseq_1_th_2 xboole_0_def_3 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed "sorry"
        thus "SegFINSEQ-1K2 n c=MEMBEREDR6 ({TARSKIK1 \<one>\<^sub>M} \\/XBOOLE-0K2 ({k where k be ElementSUBSET-1M1-of NATNUMBERSK1 :  not \<one>\<^sub>M <XXREAL-0R3 k &  not k <XXREAL-0R3 n }))\\/XBOOLE-0K2 {TARSKIK1 n}"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus "SegFINSEQ-1K2 n =XBOOLE-0R4 ({TARSKIK1 \<one>\<^sub>M} \\/XBOOLE-0K2 ({k where k be ElementSUBSET-1M1-of NATNUMBERSK1 :  not \<one>\<^sub>M <XXREAL-0R3 k &  not k <XXREAL-0R3 n }))\\/XBOOLE-0K2 {TARSKIK1 n}"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_2:
" for a be RealXREAL-0M1 holds  for F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds lenFINSEQ-1K4 (a *RVSUM-1K12 F) =XBOOLE-0R4 lenFINSEQ-1K4 F"
proof-
  have " for a be RealXREAL-0M1 holds  for F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds lenFINSEQ-1K4 (a *RVSUM-1K12 F) =XBOOLE-0R4 lenFINSEQ-1K4 F"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix F assume [ty]: "F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    obtain G where 
      [ty]:"G be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of (lenFINSEQ-1K4 F)-tuples-onFINSEQ-2K4 REALNUMBERSK2" and GDef:"G = F"
      using finseq_2_th_92 sorry
    have "lenFINSEQ-1K4 (a *RVSUM-1K13\<^bsub>(lenFINSEQ-1K4 F)\<^esub> G) =XBOOLE-0R4 lenFINSEQ-1K4 G"
      using card_1_def_7 sorry
    thus "lenFINSEQ-1K4 (a *RVSUM-1K12 F) =XBOOLE-0R4 lenFINSEQ-1K4 F"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_3:
" for a be RealXREAL-0M1 holds  for G be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds domFINSEQ-1K5 G =MEMBEREDR12 domFINSEQ-1K5 (a *RVSUM-1K12 G)"
  using valued_1_def_5 sorry

mtheorem newton_cl_1:
  mlet "x be ComplexXCMPLX-0M1", "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster n  |->FINSEQ-2K2 x as-term-is complex-valuedVALUED-0V5"
proof
(*coherence*)
  show "n  |->FINSEQ-2K2 x be complex-valuedVALUED-0V5"
     sorry
qed "sorry"

mdef newton_def_1 (" _  |^NEWTONK1  _ " [190,190]190 ) where
  mlet "x be ComplexXCMPLX-0M1", "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"func x  |^NEWTONK1 n \<rightarrow> numberORDINAL1M2 equals
  ProductRVSUM-1K23 (n  |->FINSEQ-2K2 x)"
proof-
  (*coherence*)
    show "ProductRVSUM-1K23 (n  |->FINSEQ-2K2 x) be numberORDINAL1M2"
      using tarski_th_1 sorry
qed "sorry"

mtheorem newton_cl_2:
  mlet "x be RealXREAL-0M1", "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster x  |^NEWTONK1 n as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "x  |^NEWTONK1 n be realXREAL-0V1"
     sorry
qed "sorry"

reserve z for "ComplexXCMPLX-0M1"
mtheorem newton_cl_3:
  mlet "z be ComplexXCMPLX-0M1", "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster z  |^NEWTONK1 n as-term-is complexXCMPLX-0V1"
proof
(*coherence*)
  show "z  |^NEWTONK1 n be complexXCMPLX-0V1"
     sorry
qed "sorry"

mtheorem newton_th_4:
" for z be ComplexXCMPLX-0M1 holds z  |^NEWTONK1 (0NUMBERSK6) =XBOOLE-0R4 \<one>\<^sub>M"
  using rvsum_1_th_94 sorry

mtheorem newton_th_5:
" for z be ComplexXCMPLX-0M1 holds z  |^NEWTONK1 \<one>\<^sub>M =HIDDENR1 z"
proof-
  have " for z be ComplexXCMPLX-0M1 holds z  |^NEWTONK1 \<one>\<^sub>M =HIDDENR1 z"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "z  |^NEWTONK1 \<one>\<^sub>M =HIDDENR1 ProductRVSUM-1K23 (<*FINSEQ-1K10 z*>)"
      using finseq_2_th_59 sorry
    also have "... = z"
      using rvsum_1_th_95 sorry
    finally show "z  |^NEWTONK1 \<one>\<^sub>M =HIDDENR1 z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_reduce_1:
  mlet "a be ComplexXCMPLX-0M1"
"reduce a  |^NEWTONK1 \<one>\<^sub>M to a"
proof
(*reducibility*)
  show "a  |^NEWTONK1 \<one>\<^sub>M =HIDDENR1 a"
    using newton_th_5 sorry
qed "sorry"

mtheorem newton_th_6:
" for s be NatNAT-1M1 holds  for z be ComplexXCMPLX-0M1 holds z  |^NEWTONK1 (s +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 z  |^NEWTONK1 s *XCMPLX-0K3 z"
proof-
  have " for s be NatNAT-1M1 holds  for z be ComplexXCMPLX-0M1 holds z  |^NEWTONK1 (s +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 z  |^NEWTONK1 s *XCMPLX-0K3 z"
  proof(rule ballI,rule ballI)
    fix s assume [ty]: "s be NatNAT-1M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "z  |^NEWTONK1 (s +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ProductRVSUM-1K23 ((s  |->FINSEQ-2K2 z)^FINSEQ-1K8 (<*FINSEQ-1K10 z*>))"
      using finseq_2_th_60 sorry
    also have "... = z  |^NEWTONK1 s *XCMPLX-0K3 z"
      using rvsum_1_th_96 sorry
    finally show "z  |^NEWTONK1 (s +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 z  |^NEWTONK1 s *XCMPLX-0K3 z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_cl_4:
  mlet "x be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster x  |^NEWTONK1 n as-term-is naturalORDINAL1V7"
proof
(*coherence*)
  show "x  |^NEWTONK1 n be naturalORDINAL1V7"
  proof-
    have A0: "n be NatNAT-1M1"
      using tarski_th_1 sorry
    let ?P = "\<lambda>Lamb1. x  |^NEWTONK1 Lamb1 be naturalORDINAL1V7"
    have A1: " for a be NatNAT-1M1 holds ?P(a) implies ?P(a +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for a be NatNAT-1M1 holds x  |^NEWTONK1 a be naturalORDINAL1V7 implies x  |^NEWTONK1 (a +NAT-1K1 \<one>\<^sub>M) be naturalORDINAL1V7"
      proof(rule ballI,rule impI)
        fix a assume [ty]: "a be NatNAT-1M1"
        assume "?P(a)"
        then obtain b where 
          [ty]:"b be NatNAT-1M1" and bDef:"b = x  |^NEWTONK1 a"
           sorry
        have "x  |^NEWTONK1 (a +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 b *XCMPLX-0K3 x"
          using newton_th_6 sorry
        thus "x  |^NEWTONK1 (a +NAT-1K1 \<one>\<^sub>M) be naturalORDINAL1V7"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A2: "?P(0NUMBERSK6)"
      using rvsum_1_th_94 sorry
    have " for a be NatNAT-1M1 holds ?P(a)"
      using nat_1_sch_2 A2 A1 sorry
    thus "x  |^NEWTONK1 n be naturalORDINAL1V7"
      using A0 sorry
  qed
qed "sorry"

reserve x, y for "ComplexXCMPLX-0M1"
reserve r, s, t for "naturalORDINAL1V7\<bar>NumberORDINAL1M1"
mtheorem newton_th_7:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (x *XCMPLX-0K3 y) |^NEWTONK1 s =XBOOLE-0R4 x  |^NEWTONK1 s *XCMPLX-0K3 y  |^NEWTONK1 s"
proof-
  have " for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (x *XCMPLX-0K3 y) |^NEWTONK1 s =XBOOLE-0R4 x  |^NEWTONK1 s *XCMPLX-0K3 y  |^NEWTONK1 s"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    fix y assume [ty]: "y be ComplexXCMPLX-0M1"
    fix s assume [ty]: "s be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have 
      [ty]:"x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and
      [ty]:"y be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
      using xcmplx_0_def_2 sorry
    have "x  |^NEWTONK1 s *XCMPLX-0K3 y  |^NEWTONK1 s =HIDDENR1 ProductRVSUM-1K23 (s  |->FINSEQ-2K2 (x *XCMPLX-0K3 y))"
      using rvsum_1_th_113 sorry
    thus "(x *XCMPLX-0K3 y) |^NEWTONK1 s =XBOOLE-0R4 x  |^NEWTONK1 s *XCMPLX-0K3 y  |^NEWTONK1 s"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_8:
" for x be ComplexXCMPLX-0M1 holds  for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for t be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds x  |^NEWTONK1 (s +XCMPLX-0K2 t) =XBOOLE-0R4 x  |^NEWTONK1 s *XCMPLX-0K3 x  |^NEWTONK1 t"
proof-
  have " for x be ComplexXCMPLX-0M1 holds  for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for t be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds x  |^NEWTONK1 (s +XCMPLX-0K2 t) =XBOOLE-0R4 x  |^NEWTONK1 s *XCMPLX-0K3 x  |^NEWTONK1 t"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    fix s assume [ty]: "s be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix t assume [ty]: "t be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have 
      [ty]:"x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
      using xcmplx_0_def_2 sorry
    have "x  |^NEWTONK1 s *XCMPLX-0K3 x  |^NEWTONK1 t =XBOOLE-0R4 ProductRVSUM-1K24 ((s +XCMPLX-0K2 t) |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x)"
      using rvsum_1_th_111 sorry
    thus "x  |^NEWTONK1 (s +XCMPLX-0K2 t) =XBOOLE-0R4 x  |^NEWTONK1 s *XCMPLX-0K3 x  |^NEWTONK1 t"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_9:
" for x be ComplexXCMPLX-0M1 holds  for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for t be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (x  |^NEWTONK1 s) |^NEWTONK1 t =XBOOLE-0R4 x  |^NEWTONK1 (s *XCMPLX-0K3 t)"
proof-
  have " for x be ComplexXCMPLX-0M1 holds  for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for t be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (x  |^NEWTONK1 s) |^NEWTONK1 t =XBOOLE-0R4 x  |^NEWTONK1 (s *XCMPLX-0K3 t)"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    fix s assume [ty]: "s be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix t assume [ty]: "t be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have 
      [ty]:"x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
      using xcmplx_0_def_2 sorry
    have "x  |^NEWTONK1 (s *XCMPLX-0K3 t) =HIDDENR1 ProductRVSUM-1K23 (t  |->FINSEQ-2K2 x  |^NEWTONK1 s)"
      using rvsum_1_th_112 sorry
    thus "(x  |^NEWTONK1 s) |^NEWTONK1 t =XBOOLE-0R4 x  |^NEWTONK1 (s *XCMPLX-0K3 t)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_10:
" for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds \<one>\<^sub>M  |^NEWTONK1 s =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds \<one>\<^sub>M  |^NEWTONK1 s =XBOOLE-0R4 \<one>\<^sub>M"
  proof(rule ballI)
    fix s assume [ty]: "s be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have A0: "s be NatNAT-1M1"
      using tarski_th_1 sorry
    let ?P = "\<lambda>Lamb1. \<one>\<^sub>M  |^NEWTONK1 Lamb1 =XBOOLE-0R4 \<one>\<^sub>M"
    have A1: " for s be NatNAT-1M1 holds \<one>\<^sub>M  |^NEWTONK1 s =XBOOLE-0R4 \<one>\<^sub>M implies \<one>\<^sub>M  |^NEWTONK1 (s +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<one>\<^sub>M"
    proof(rule ballI,rule impI)
      fix s assume [ty]: "s be NatNAT-1M1"
      assume "?P(s)"
      then have "\<one>\<^sub>M  |^NEWTONK1 (s +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<one>\<^sub>M *NAT-1K2 \<one>\<^sub>M"
        using newton_th_6 sorry
      thus "\<one>\<^sub>M  |^NEWTONK1 (s +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<one>\<^sub>M"
         sorry
    qed "sorry"
    have A2: "?P(0NUMBERSK6)"
      using rvsum_1_th_94 sorry
    have " for s be NatNAT-1M1 holds ?P(s)"
      using nat_1_sch_2 A2 A1 sorry
    thus "\<one>\<^sub>M  |^NEWTONK1 s =XBOOLE-0R4 \<one>\<^sub>M"
      using A0 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_reduce_2:
  mlet "n be NatNAT-1M1"
"reduce \<one>\<^sub>M  |^NEWTONK1 n to \<one>\<^sub>M"
proof
(*reducibility*)
  show "\<one>\<^sub>M  |^NEWTONK1 n =HIDDENR1 \<one>\<^sub>M"
    using newton_th_10 sorry
qed "sorry"

mtheorem newton_th_11:
" for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds s >=XXREAL-0R2 \<one>\<^sub>M implies (0NUMBERSK6) |^NEWTONK1 s =XBOOLE-0R4 0NUMBERSK6"
proof-
  have " for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  not (s >=XXREAL-0R2 \<one>\<^sub>M &  not (0NUMBERSK6) |^NEWTONK1 s =XBOOLE-0R4 0NUMBERSK6)"
  proof(rule ballI)
    fix s assume [ty]: "s be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have A0: "s be NatNAT-1M1"
      using tarski_th_1 sorry
    let ?P = "\<lambda>Lamb1. (0NUMBERSK6) |^NEWTONK1 Lamb1 =XBOOLE-0R4 0NUMBERSK6"
    have A1: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M & (0NUMBERSK6) |^NEWTONK1 n =XBOOLE-0R4 0NUMBERSK6 implies (0NUMBERSK6) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6"
    proof(rule ballI,rule impI)
      fix n assume [ty]: "n be NatNAT-1M1"
      assume "n >=XXREAL-0R2 \<one>\<^sub>M & ?P(n)"
      have "(0NUMBERSK6) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (0NUMBERSK6) |^NEWTONK1 n *XCMPLX-0K3 (0NUMBERSK6)"
        using newton_th_6 sorry
      also have "... = 0NUMBERSK6"
         sorry
      finally have "(0NUMBERSK6) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 0NUMBERSK6"
         sorry
      thus "(0NUMBERSK6) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6"
         sorry
    qed "sorry"
    have A2: "?P(\<one>\<^sub>M)"
       sorry
    have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies ?P(n)"
      using nat_1_sch_8 A2 A1 sorry
    thus " not (s >=XXREAL-0R2 \<one>\<^sub>M &  not (0NUMBERSK6) |^NEWTONK1 s =XBOOLE-0R4 0NUMBERSK6)"
      using A0 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_cl_5:
  mlet "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster idseqFINSEQ-2K1 n as-term-is natural-valuedVALUED-0V8"
proof
(*coherence*)
  show "idseqFINSEQ-2K1 n be natural-valuedVALUED-0V8"
  proof-
    have "idseqFINSEQ-2K1 n be natural-valuedVALUED-0V4"
    proof-
      have 
        [ty]:"n be NatNAT-1M1"
        using tarski_th_1 sorry
      have "SegFINSEQ-1K2 n be natural-memberedMEMBEREDV6"
         sorry
      thus "idseqFINSEQ-2K1 n be natural-valuedVALUED-0V4"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef newton_def_2 (" _ !NEWTONK2" [164]164 ) where
  mlet "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"func n !NEWTONK2 \<rightarrow> numberORDINAL1M2 equals
  ProductRVSUM-1K23 (idseqFINSEQ-2K1 n)"
proof-
  (*coherence*)
    show "ProductRVSUM-1K23 (idseqFINSEQ-2K1 n) be numberORDINAL1M2"
      using tarski_th_1 sorry
qed "sorry"

mtheorem newton_cl_6:
  mlet "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster n !NEWTONK2 as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "n !NEWTONK2 be realXREAL-0V1"
     sorry
qed "sorry"

mtheorem newton_th_12:
"(0NUMBERSK6)!NEWTONK2 =XBOOLE-0R4 \<one>\<^sub>M"
  using rvsum_1_th_94 sorry

mtheorem newton_th_13:
"\<one>\<^sub>M !NEWTONK2 =XBOOLE-0R4 \<one>\<^sub>M"
  using finseq_2_th_50 rvsum_1_th_95 sorry

mtheorem newton_th_14:
"\<two>\<^sub>M !NEWTONK2 =XBOOLE-0R4 \<two>\<^sub>M"
proof-
  have "\<two>\<^sub>M !NEWTONK2 =HIDDENR1 \<two>\<^sub>M"
  proof-
    have "\<two>\<^sub>M !NEWTONK2 =HIDDENR1 \<one>\<^sub>M *NAT-1K2 \<two>\<^sub>M"
      using finseq_2_th_52 rvsum_1_th_99 sorry
    also have "... = \<two>\<^sub>M"
       sorry
    finally show "\<two>\<^sub>M !NEWTONK2 =HIDDENR1 \<two>\<^sub>M"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_15:
" for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (s +NAT-1K1 \<one>\<^sub>M)!NEWTONK2 =XBOOLE-0R4 (s !NEWTONK2)*XCMPLX-0K3 (s +NAT-1K1 \<one>\<^sub>M)"
proof-
  have " for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (s +NAT-1K1 \<one>\<^sub>M)!NEWTONK2 =XBOOLE-0R4 (s !NEWTONK2)*XCMPLX-0K3 (s +NAT-1K1 \<one>\<^sub>M)"
  proof(rule ballI)
    fix s assume [ty]: "s be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have "idseqFINSEQ-2K1 (s +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 idseqFINSEQ-2K1 s ^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> s +NAT-1K1 \<one>\<^sub>M *>)"
      using finseq_2_th_51 sorry
    thus "(s +NAT-1K1 \<one>\<^sub>M)!NEWTONK2 =XBOOLE-0R4 (s !NEWTONK2)*XCMPLX-0K3 (s +NAT-1K1 \<one>\<^sub>M)"
      using rvsum_1_th_96 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_16:
" for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds s !NEWTONK2 be ElementSUBSET-1M1-of NATNUMBERSK1"
proof-
  have " for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds s !NEWTONK2 be ElementSUBSET-1M1-of NATNUMBERSK1"
  proof(rule ballI)
    fix s assume [ty]: "s be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have A0: "s be NatNAT-1M1"
      using tarski_th_1 sorry
    let ?P = "\<lambda>Lamb1. Lamb1 !NEWTONK2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    have A1: " for s be NatNAT-1M1 holds s !NEWTONK2 be ElementSUBSET-1M1-of NATNUMBERSK1 implies (s +NAT-1K1 \<one>\<^sub>M)!NEWTONK2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    proof(rule ballI,rule impI)
      fix s assume [ty]: "s be NatNAT-1M1"
      assume "?P(s)"
      then obtain k where 
        [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = s !NEWTONK2"
         sorry
      have "(s +NAT-1K1 \<one>\<^sub>M)!NEWTONK2 =XBOOLE-0R4 (s +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 k"
        using newton_th_15 sorry
      thus "(s +NAT-1K1 \<one>\<^sub>M)!NEWTONK2 be ElementSUBSET-1M1-of NATNUMBERSK1"
         sorry
    qed "sorry"
    have A2: "?P(0NUMBERSK6)"
      using rvsum_1_th_94 sorry
    have " for s be NatNAT-1M1 holds ?P(s)"
      using nat_1_sch_2 A2 A1 sorry
    thus "s !NEWTONK2 be ElementSUBSET-1M1-of NATNUMBERSK1"
      using A0 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_cl_7:
  mlet "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster n !NEWTONK2 as-term-is naturalORDINAL1V7"
proof
(*coherence*)
  show "n !NEWTONK2 be naturalORDINAL1V7"
    using newton_th_16 sorry
qed "sorry"

mtheorem newton_th_17:
" for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds s !NEWTONK2 >XXREAL-0R4 0NUMBERSK6"
proof-
  have " for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  not s !NEWTONK2 >XXREAL-0R4 0NUMBERSK6"
  proof(rule ballI)
    fix s assume [ty]: "s be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have A0: "s be NatNAT-1M1"
      using tarski_th_1 sorry
    let ?P = "\<lambda>Lamb1. Lamb1 !NEWTONK2 >XXREAL-0R4 0NUMBERSK6"
    have A1: " for s be NatNAT-1M1 holds s !NEWTONK2 >XXREAL-0R4 0NUMBERSK6 implies (s +NAT-1K1 \<one>\<^sub>M)!NEWTONK2 >XXREAL-0R4 0NUMBERSK6"
    proof(rule ballI,rule impI)
      fix s assume [ty]: "s be NatNAT-1M1"
      assume "?P(s)"
      then have "(s +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (s !NEWTONK2) >XXREAL-0R4 (s +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 (0NUMBERSK6)"
         sorry
      thus "(s +NAT-1K1 \<one>\<^sub>M)!NEWTONK2 >XXREAL-0R4 0NUMBERSK6"
        using newton_th_15 sorry
    qed "sorry"
    have A2: "?P(0NUMBERSK6)"
      using rvsum_1_th_94 sorry
    have " for s be NatNAT-1M1 holds ?P(s)"
      using nat_1_sch_2 A2 A1 sorry
    thus " not s !NEWTONK2 >XXREAL-0R4 0NUMBERSK6"
      using A0 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_cl_8:
  mlet "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster n !NEWTONK2 as-term-is positiveXXREAL-0V2"
proof
(*coherence*)
  show "n !NEWTONK2 be positiveXXREAL-0V2"
    using newton_th_17 sorry
qed "sorry"

mtheorem newton_th_18:
" for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for t be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (s !NEWTONK2)*XCMPLX-0K3 (t !NEWTONK2) <>HIDDENR2 0NUMBERSK6"
   sorry

mdef newton_def_3 (" _ chooseNEWTONK3  _ " [164,164]164 ) where
  mlet "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"func n chooseNEWTONK3 k \<rightarrow> numberORDINAL1M2 means
  \<lambda>it.  for l be NatNAT-1M1 holds l =XBOOLE-0R4 n -XCMPLX-0K6 k implies it =XBOOLE-0R4 (n !NEWTONK2)/XCMPLX-0K7 ((k !NEWTONK2)*XCMPLX-0K3 (l !NEWTONK2)) if n >=XXREAL-0R2 k otherwise \<lambda>it. it =XBOOLE-0R4 0NUMBERSK6"
proof-
  (*consistency*)
    show " for it be numberORDINAL1M2 holds  True "
       sorry
  (*existence*)
    show "(n >=XXREAL-0R2 k implies ( ex it be numberORDINAL1M2 st  for l be NatNAT-1M1 holds l =XBOOLE-0R4 n -XCMPLX-0K6 k implies it =XBOOLE-0R4 (n !NEWTONK2)/XCMPLX-0K7 ((k !NEWTONK2)*XCMPLX-0K3 (l !NEWTONK2)))) & ( not n >=XXREAL-0R2 k implies ( ex it be numberORDINAL1M2 st it =XBOOLE-0R4 0NUMBERSK6))"
    proof-
      have "(n >=XXREAL-0R2 k implies ( ex r1 be setHIDDENM2 st  for l be NatNAT-1M1 holds l =XBOOLE-0R4 n -XCMPLX-0K6 k implies r1 =XBOOLE-0R4 (n !NEWTONK2)/XCMPLX-0K7 ((k !NEWTONK2)*XCMPLX-0K3 (l !NEWTONK2)))) &  not ( not n >=XXREAL-0R2 k & ( for VarFor1 be numberORDINAL1M2 holds  not VarFor1 =XBOOLE-0R4 0NUMBERSK6))"
      proof(rule conjMI)
        show "n >=XXREAL-0R2 k implies ( ex r1 be setHIDDENM2 st  for l be NatNAT-1M1 holds l =XBOOLE-0R4 n -XCMPLX-0K6 k implies r1 =XBOOLE-0R4 (n !NEWTONK2)/XCMPLX-0K7 ((k !NEWTONK2)*XCMPLX-0K3 (l !NEWTONK2)))"
        proof-
          have "n >=XXREAL-0R2 k implies ( ex tVar1 be setHIDDENM2 st  for l be NatNAT-1M1 holds  not (l =XBOOLE-0R4 n -XCMPLX-0K6 k &  not tVar1 =XBOOLE-0R4 (n !NEWTONK2)/XCMPLX-0K7 ((k !NEWTONK2)*XCMPLX-0K3 (l !NEWTONK2))))"
          proof(rule impI)
            assume "n >=XXREAL-0R2 k"
            then obtain m where 
              [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and mDef:"m = n -XCMPLX-0K6 k"
              using int_1_th_5 sorry
            show " ex tVar1 be setHIDDENM2 st  for l be NatNAT-1M1 holds  not (l =XBOOLE-0R4 n -XCMPLX-0K6 k &  not tVar1 =XBOOLE-0R4 (n !NEWTONK2)/XCMPLX-0K7 ((k !NEWTONK2)*XCMPLX-0K3 (l !NEWTONK2)))"
            proof(rule bexI[of _ "(n !NEWTONK2)/XCMPLX-0K7 ((k !NEWTONK2)*XCMPLX-0K3 (m !NEWTONK2))"])
              show " for l be NatNAT-1M1 holds  not (l =XBOOLE-0R4 n -XCMPLX-0K6 k &  not (n !NEWTONK2)/XCMPLX-0K7 ((k !NEWTONK2)*XCMPLX-0K3 (m !NEWTONK2)) =XBOOLE-0R4 (n !NEWTONK2)/XCMPLX-0K7 ((k !NEWTONK2)*XCMPLX-0K3 (l !NEWTONK2)))"
                 sorry
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
        show " not ( not n >=XXREAL-0R2 k & ( for VarFor1 be numberORDINAL1M2 holds  not VarFor1 =XBOOLE-0R4 0NUMBERSK6))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be numberORDINAL1M2 holds  for it2 be numberORDINAL1M2 holds (n >=XXREAL-0R2 k implies (( for l be NatNAT-1M1 holds l =XBOOLE-0R4 n -XCMPLX-0K6 k implies it1 =XBOOLE-0R4 (n !NEWTONK2)/XCMPLX-0K7 ((k !NEWTONK2)*XCMPLX-0K3 (l !NEWTONK2))) & ( for l be NatNAT-1M1 holds l =XBOOLE-0R4 n -XCMPLX-0K6 k implies it2 =XBOOLE-0R4 (n !NEWTONK2)/XCMPLX-0K7 ((k !NEWTONK2)*XCMPLX-0K3 (l !NEWTONK2))) implies it1 =HIDDENR1 it2)) & ( not n >=XXREAL-0R2 k implies (it1 =XBOOLE-0R4 0NUMBERSK6 & it2 =XBOOLE-0R4 0NUMBERSK6 implies it1 =HIDDENR1 it2))"
    proof-
      have " for r1 be setHIDDENM2 holds  for r2 be setHIDDENM2 holds ((n >=XXREAL-0R2 k & ( for l be NatNAT-1M1 holds l =XBOOLE-0R4 n -XCMPLX-0K6 k implies r1 =XBOOLE-0R4 (n !NEWTONK2)/XCMPLX-0K7 ((k !NEWTONK2)*XCMPLX-0K3 (l !NEWTONK2)))) & ( for l be NatNAT-1M1 holds l =XBOOLE-0R4 n -XCMPLX-0K6 k implies r2 =XBOOLE-0R4 (n !NEWTONK2)/XCMPLX-0K7 ((k !NEWTONK2)*XCMPLX-0K3 (l !NEWTONK2))) implies r1 =XBOOLE-0R4 r2) &  not ((( not n >=XXREAL-0R2 k & r1 =XBOOLE-0R4 0NUMBERSK6) & r2 =XBOOLE-0R4 0NUMBERSK6) &  not r1 =HIDDENR1 r2)"
      proof(rule ballI,rule ballI,rule conjMI)
        fix r1 assume [ty]: "r1 be setHIDDENM2"
        fix r2 assume [ty]: "r2 be setHIDDENM2"
        show "(n >=XXREAL-0R2 k & ( for l be NatNAT-1M1 holds l =XBOOLE-0R4 n -XCMPLX-0K6 k implies r1 =XBOOLE-0R4 (n !NEWTONK2)/XCMPLX-0K7 ((k !NEWTONK2)*XCMPLX-0K3 (l !NEWTONK2)))) & ( for l be NatNAT-1M1 holds l =XBOOLE-0R4 n -XCMPLX-0K6 k implies r2 =XBOOLE-0R4 (n !NEWTONK2)/XCMPLX-0K7 ((k !NEWTONK2)*XCMPLX-0K3 (l !NEWTONK2))) implies r1 =XBOOLE-0R4 r2"
        proof-
          have "n >=XXREAL-0R2 k implies (( for l be NatNAT-1M1 holds l =XBOOLE-0R4 n -XCMPLX-0K6 k implies r1 =XBOOLE-0R4 (n !NEWTONK2)/XCMPLX-0K7 ((k !NEWTONK2)*XCMPLX-0K3 (l !NEWTONK2))) & ( for l be NatNAT-1M1 holds l =XBOOLE-0R4 n -XCMPLX-0K6 k implies r2 =XBOOLE-0R4 (n !NEWTONK2)/XCMPLX-0K7 ((k !NEWTONK2)*XCMPLX-0K3 (l !NEWTONK2))) implies r1 =XBOOLE-0R4 r2)"
          proof(rule impI,rule impMI ,rule impI)
            assume "n >=XXREAL-0R2 k"
            then obtain m where 
              [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and mDef:"m = n -XCMPLX-0K6 k"
              using int_1_th_5 sorry
            assume A1: " for l be NatNAT-1M1 holds l =XBOOLE-0R4 n -XCMPLX-0K6 k implies r1 =XBOOLE-0R4 (n !NEWTONK2)/XCMPLX-0K7 ((k !NEWTONK2)*XCMPLX-0K3 (l !NEWTONK2))"
              and A2: " for l be NatNAT-1M1 holds l =XBOOLE-0R4 n -XCMPLX-0K6 k implies r2 =XBOOLE-0R4 (n !NEWTONK2)/XCMPLX-0K7 ((k !NEWTONK2)*XCMPLX-0K3 (l !NEWTONK2))"
            have "r1 =XBOOLE-0R4 (n !NEWTONK2)/XCMPLX-0K7 ((k !NEWTONK2)*XCMPLX-0K3 (m !NEWTONK2))"
              using A1 sorry
            thus "r1 =XBOOLE-0R4 r2"
              using A2 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        show " not ((( not n >=XXREAL-0R2 k & r1 =XBOOLE-0R4 0NUMBERSK6) & r2 =XBOOLE-0R4 0NUMBERSK6) &  not r1 =HIDDENR1 r2)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem newton_cl_9:
  mlet "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster n chooseNEWTONK3 k as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "n chooseNEWTONK3 k be realXREAL-0V1"
  proof-
    show "n chooseNEWTONK3 k be realXREAL-0V1"
    proof-
      have cases: "n >=XXREAL-0R2 k or n <XXREAL-0R3 k"
         sorry
      have case1: "n >=XXREAL-0R2 k implies n chooseNEWTONK3 k be realXREAL-0V1"
      proof(rule impI)
        assume A1: "n >=XXREAL-0R2 k"
        then obtain l where 
          [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1" and lDef:"l = n -XCMPLX-0K6 k"
          using int_1_th_5 sorry
        have "n chooseNEWTONK3 k =XBOOLE-0R4 (n !NEWTONK2)/XCMPLX-0K7 ((k !NEWTONK2)*XCMPLX-0K3 (l !NEWTONK2))"
          using A1 newton_def_3 sorry
        thus "n chooseNEWTONK3 k be realXREAL-0V1"
           sorry
      qed
      have case2: "n <XXREAL-0R3 k implies n chooseNEWTONK3 k be realXREAL-0V1"
      proof(rule impI)
        assume "n <XXREAL-0R3 k"
        thus "n chooseNEWTONK3 k be realXREAL-0V1"
          using newton_def_3 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
qed "sorry"

mtheorem newton_th_19:
" for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds s chooseNEWTONK3 (0NUMBERSK6) =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds s chooseNEWTONK3 (0NUMBERSK6) =XBOOLE-0R4 \<one>\<^sub>M"
  proof(rule ballI)
    fix s assume [ty]: "s be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    obtain m where 
      [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and mDef:"m = s -XCMPLX-0K6 0NUMBERSK6"
      using ordinal1_def_12 sorry
    have "m =HIDDENR1 s"
       sorry
    then have "s chooseNEWTONK3 (0NUMBERSK6) =HIDDENR1 (s !NEWTONK2)/XCMPLX-0K7 (\<one>\<^sub>M *XCMPLX-0K3 (s !NEWTONK2))"
      using newton_def_3 newton_th_12 sorry
    also have "... = \<one>\<^sub>M"
      using xcmplx_1_th_60 sorry
    finally have "s chooseNEWTONK3 (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
       sorry
    thus "s chooseNEWTONK3 (0NUMBERSK6) =XBOOLE-0R4 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_20:
" for r be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for t be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds s >=XXREAL-0R2 t & r =HIDDENR1 s -XCMPLX-0K6 t implies s chooseNEWTONK3 t =XBOOLE-0R4 s chooseNEWTONK3 r"
proof-
  have " for r be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for t be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds s >=XXREAL-0R2 t implies (r =HIDDENR1 s -XCMPLX-0K6 t implies s chooseNEWTONK3 t =XBOOLE-0R4 s chooseNEWTONK3 r)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix r assume [ty]: "r be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix s assume [ty]: "s be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix t assume [ty]: "t be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "s >=XXREAL-0R2 t"
    have "t -XCMPLX-0K6 s >=XXREAL-0R2 0NUMBERSK6 -XCMPLX-0K6 s"
      using xreal_1_th_9 sorry
    then have A2: "-XCMPLX-0K4 (-XCMPLX-0K4 s) >=XXREAL-0R2 -XCMPLX-0K4 (t -XCMPLX-0K6 s)"
      using xreal_1_th_24 sorry
    assume A3: "r =HIDDENR1 s -XCMPLX-0K6 t"
    then have "t =HIDDENR1 s -XCMPLX-0K6 r"
       sorry
    then have "s chooseNEWTONK3 r =XBOOLE-0R4 (s !NEWTONK2)/XCMPLX-0K7 ((r !NEWTONK2)*XCMPLX-0K3 (t !NEWTONK2))"
      using A2 newton_def_3 sorry
    thus "s chooseNEWTONK3 t =XBOOLE-0R4 s chooseNEWTONK3 r"
      using A1 A3 newton_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_21:
" for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds s chooseNEWTONK3 s =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds s chooseNEWTONK3 s =XBOOLE-0R4 \<one>\<^sub>M"
  proof(rule ballI)
    fix s assume [ty]: "s be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    obtain m where 
      [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and mDef:"m = s -XCMPLX-0K6 s"
      using int_1_th_5 sorry
    have "m =XBOOLE-0R4 0NUMBERSK6"
       sorry
    then have "s chooseNEWTONK3 s =XBOOLE-0R4 s chooseNEWTONK3 (0NUMBERSK6)"
      using newton_th_20 sorry
    thus "s chooseNEWTONK3 s =XBOOLE-0R4 \<one>\<^sub>M"
      using newton_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_22:
" for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for t be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (t +NAT-1K1 \<one>\<^sub>M)chooseNEWTONK3 (s +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 t chooseNEWTONK3 (s +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 t chooseNEWTONK3 s"
proof-
  have " for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for t be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (t +NAT-1K1 \<one>\<^sub>M)chooseNEWTONK3 (s +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 t chooseNEWTONK3 (s +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 t chooseNEWTONK3 s"
  proof(rule ballI,rule ballI)
    fix s assume [ty]: "s be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix t assume [ty]: "t be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    show "(t +NAT-1K1 \<one>\<^sub>M)chooseNEWTONK3 (s +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 t chooseNEWTONK3 (s +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 t chooseNEWTONK3 s"
    proof-
      have cases: "(s <XXREAL-0R3 t or s =HIDDENR1 t) or s >XXREAL-0R4 t"
        using xxreal_0_th_1 sorry
      have case1: "s <XXREAL-0R3 t implies (t +NAT-1K1 \<one>\<^sub>M)chooseNEWTONK3 (s +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 t chooseNEWTONK3 (s +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 t chooseNEWTONK3 s"
      proof(rule impI)
        assume A1: "s <XXREAL-0R3 t"
        show "(t +NAT-1K1 \<one>\<^sub>M)chooseNEWTONK3 (s +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 t chooseNEWTONK3 (s +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 t chooseNEWTONK3 s"
        proof-
          obtain m1 where 
            [ty]:"m1 be ElementSUBSET-1M1-of NATNUMBERSK1" and m1Def:"m1 = t -XCMPLX-0K6 s"
            using A1 int_1_th_5 sorry
          have A2: "s +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 t"
            using A1 nat_1_th_13 sorry
          then obtain m2 where 
            [ty]:"m2 be ElementSUBSET-1M1-of NATNUMBERSK1" and m2Def:"m2 = t -XCMPLX-0K6 (s +NAT-1K1 \<one>\<^sub>M)"
            using int_1_th_5 sorry
          have A3: "s +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 t +NAT-1K1 \<one>\<^sub>M"
            using A1 xreal_1_th_6 sorry
          then obtain m where 
            [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and mDef:"m = (t +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 (s +NAT-1K1 \<one>\<^sub>M)"
            using int_1_th_5 sorry
          have "t chooseNEWTONK3 (s +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 (t !NEWTONK2)/XCMPLX-0K7 (((s +NAT-1K1 \<one>\<^sub>M)!NEWTONK2)*XCMPLX-0K3 (m2 !NEWTONK2))"
            using A2 newton_def_3 sorry
          then have A4: "t chooseNEWTONK3 (s +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 t chooseNEWTONK3 s =HIDDENR1 (t !NEWTONK2)/XCMPLX-0K7 (((s +NAT-1K1 \<one>\<^sub>M)!NEWTONK2)*XCMPLX-0K3 (m2 !NEWTONK2)) +XCMPLX-0K2 (t !NEWTONK2)/XCMPLX-0K7 ((s !NEWTONK2)*XCMPLX-0K3 (m1 !NEWTONK2))"
            using A1 newton_def_3 sorry
          also have "... = ((t !NEWTONK2)*XCMPLX-0K3 ((s !NEWTONK2)*XCMPLX-0K3 (m1 !NEWTONK2)) +XCMPLX-0K2 (t !NEWTONK2)*XCMPLX-0K3 (((s +NAT-1K1 \<one>\<^sub>M)!NEWTONK2)*XCMPLX-0K3 (m2 !NEWTONK2)))/XCMPLX-0K7 ((((s +NAT-1K1 \<one>\<^sub>M)!NEWTONK2)*XCMPLX-0K3 (m2 !NEWTONK2))*XCMPLX-0K3 ((s !NEWTONK2)*XCMPLX-0K3 (m1 !NEWTONK2)))"
            using xcmplx_1_th_116 sorry
          also have "... = ((t !NEWTONK2)*XCMPLX-0K3 ((s !NEWTONK2)*XCMPLX-0K3 (m1 !NEWTONK2)) +XCMPLX-0K2 (t !NEWTONK2)*XCMPLX-0K3 (((s !NEWTONK2)*XCMPLX-0K3 (s +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (m2 !NEWTONK2)))/XCMPLX-0K7 ((((s +NAT-1K1 \<one>\<^sub>M)!NEWTONK2)*XCMPLX-0K3 (m2 !NEWTONK2))*XCMPLX-0K3 ((s !NEWTONK2)*XCMPLX-0K3 (m1 !NEWTONK2)))"
            using newton_th_15 sorry
          also have "... = ((s !NEWTONK2)*XCMPLX-0K3 ((t !NEWTONK2)*XCMPLX-0K3 (m1 !NEWTONK2 +XCMPLX-0K2 (s +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (m2 !NEWTONK2))))/XCMPLX-0K7 ((s !NEWTONK2)*XCMPLX-0K3 ((m1 !NEWTONK2)*XCMPLX-0K3 (((s +NAT-1K1 \<one>\<^sub>M)!NEWTONK2)*XCMPLX-0K3 (m2 !NEWTONK2))))"
             sorry
          also have "... = ((t !NEWTONK2)*XCMPLX-0K3 ((m2 +NAT-1K1 \<one>\<^sub>M)!NEWTONK2 +XCMPLX-0K2 (s +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (m2 !NEWTONK2)))/XCMPLX-0K7 ((m1 !NEWTONK2)*XCMPLX-0K3 (((s +NAT-1K1 \<one>\<^sub>M)!NEWTONK2)*XCMPLX-0K3 (m2 !NEWTONK2)))"
            using xcmplx_1_th_91 sorry
          also have "... = ((t !NEWTONK2)*XCMPLX-0K3 ((m2 !NEWTONK2)*XCMPLX-0K3 (m2 +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 (m2 !NEWTONK2)*XCMPLX-0K3 (s +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 ((m1 !NEWTONK2)*XCMPLX-0K3 (((s +NAT-1K1 \<one>\<^sub>M)!NEWTONK2)*XCMPLX-0K3 (m2 !NEWTONK2)))"
            using newton_th_15 sorry
          also have "... = ((m2 !NEWTONK2)*XCMPLX-0K3 ((t !NEWTONK2)*XCMPLX-0K3 ((m2 +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 (s +NAT-1K1 \<one>\<^sub>M))))/XCMPLX-0K7 ((m2 !NEWTONK2)*XCMPLX-0K3 (((s +NAT-1K1 \<one>\<^sub>M)!NEWTONK2)*XCMPLX-0K3 (m1 !NEWTONK2)))"
             sorry
          also have "... = ((t !NEWTONK2)*XCMPLX-0K3 (t -XCMPLX-0K6 (s -XCMPLX-0K6 (s +NAT-1K1 \<one>\<^sub>M))))/XCMPLX-0K7 (((s +NAT-1K1 \<one>\<^sub>M)!NEWTONK2)*XCMPLX-0K3 (m1 !NEWTONK2))"
            using xcmplx_1_th_91 sorry
          also have "... = ((t +NAT-1K1 \<one>\<^sub>M)!NEWTONK2)/XCMPLX-0K7 (((s +NAT-1K1 \<one>\<^sub>M)!NEWTONK2)*XCMPLX-0K3 (m1 !NEWTONK2))"
            using newton_th_15 sorry
          finally have "t chooseNEWTONK3 (s +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 t chooseNEWTONK3 s =HIDDENR1 ((t +NAT-1K1 \<one>\<^sub>M)!NEWTONK2)/XCMPLX-0K7 (((s +NAT-1K1 \<one>\<^sub>M)!NEWTONK2)*XCMPLX-0K3 (m1 !NEWTONK2))"
             sorry
          have "m =XBOOLE-0R4 m1"
             sorry
          thus "(t +NAT-1K1 \<one>\<^sub>M)chooseNEWTONK3 (s +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 t chooseNEWTONK3 (s +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 t chooseNEWTONK3 s"
            using A4 A3 newton_def_3 sorry
        qed
      qed
      have case2: "s =HIDDENR1 t implies (t +NAT-1K1 \<one>\<^sub>M)chooseNEWTONK3 (s +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 t chooseNEWTONK3 (s +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 t chooseNEWTONK3 s"
      proof(rule impI)
        assume A5: "s =HIDDENR1 t"
        then have "s <XXREAL-0R3 t +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_13 sorry
        then have A6: "t chooseNEWTONK3 (s +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6"
          using A5 newton_def_3 sorry
        have "(t +NAT-1K1 \<one>\<^sub>M)chooseNEWTONK3 (s +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<one>\<^sub>M"
          using A5 newton_th_21 sorry
        thus "(t +NAT-1K1 \<one>\<^sub>M)chooseNEWTONK3 (s +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 t chooseNEWTONK3 (s +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 t chooseNEWTONK3 s"
          using A5 A6 newton_th_21 sorry
      qed
      have case3: "s >XXREAL-0R4 t implies (t +NAT-1K1 \<one>\<^sub>M)chooseNEWTONK3 (s +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 t chooseNEWTONK3 (s +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 t chooseNEWTONK3 s"
      proof(rule impI)
        assume A7: "s >XXREAL-0R4 t"
        then have "s +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 t +NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_8 sorry
        then have A8: "(t +NAT-1K1 \<one>\<^sub>M)chooseNEWTONK3 (s +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6"
          using newton_def_3 sorry
        have A9: "s +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 t +NAT-1K1 0NUMBERSK6"
          using A7 xreal_1_th_8 sorry
        have "t chooseNEWTONK3 s =XBOOLE-0R4 0NUMBERSK6"
          using A7 newton_def_3 sorry
        thus "(t +NAT-1K1 \<one>\<^sub>M)chooseNEWTONK3 (s +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 t chooseNEWTONK3 (s +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 t chooseNEWTONK3 s"
          using A9 A8 newton_def_3 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_23:
" for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds s >=XXREAL-0R2 \<one>\<^sub>M implies s chooseNEWTONK3 \<one>\<^sub>M =HIDDENR1 s"
proof-
  have " for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  not (s >=XXREAL-0R2 \<one>\<^sub>M &  not s chooseNEWTONK3 \<one>\<^sub>M =HIDDENR1 s)"
  proof(rule ballI)
    fix s assume [ty]: "s be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have A0: "s be NatNAT-1M1"
      using tarski_th_1 sorry
    let ?P = "\<lambda>Lamb1. Lamb1 chooseNEWTONK3 \<one>\<^sub>M =XBOOLE-0R4 Lamb1"
    have A1: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M & n chooseNEWTONK3 \<one>\<^sub>M =XBOOLE-0R4 n implies (n +NAT-1K1 \<one>\<^sub>M)chooseNEWTONK3 \<one>\<^sub>M =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
    proof(rule ballI,rule impMI ,rule impI)
      fix n assume [ty]: "n be NatNAT-1M1"
      assume "n >=XXREAL-0R2 \<one>\<^sub>M"
        and A2: "?P(n)"
      have "(n +NAT-1K1 \<one>\<^sub>M)chooseNEWTONK3 \<one>\<^sub>M =HIDDENR1 (n +NAT-1K1 \<one>\<^sub>M)chooseNEWTONK3 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)"
         sorry
      also have "... = n +XCMPLX-0K2 n chooseNEWTONK3 (0NUMBERSK6)"
        using A2 newton_th_22 sorry
      also have "... = n +NAT-1K1 \<one>\<^sub>M"
        using newton_th_19 sorry
      finally have "(n +NAT-1K1 \<one>\<^sub>M)chooseNEWTONK3 \<one>\<^sub>M =HIDDENR1 n +NAT-1K1 \<one>\<^sub>M"
         sorry
      thus "(n +NAT-1K1 \<one>\<^sub>M)chooseNEWTONK3 \<one>\<^sub>M =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
         sorry
    qed "sorry"
    have A3: "?P(\<one>\<^sub>M)"
      using newton_th_21 sorry
    have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies ?P(n)"
      using nat_1_sch_8 A3 A1 sorry
    thus " not (s >=XXREAL-0R2 \<one>\<^sub>M &  not s chooseNEWTONK3 \<one>\<^sub>M =HIDDENR1 s)"
      using A0 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_24:
" for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for t be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds s >=XXREAL-0R2 \<one>\<^sub>M & t =HIDDENR1 s -XCMPLX-0K6 \<one>\<^sub>M implies s chooseNEWTONK3 t =HIDDENR1 s"
proof-
  have " for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for t be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds s >=XXREAL-0R2 \<one>\<^sub>M & t =HIDDENR1 s -XCMPLX-0K6 \<one>\<^sub>M implies s chooseNEWTONK3 t =HIDDENR1 s"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix s assume [ty]: "s be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix t assume [ty]: "t be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "s >=XXREAL-0R2 \<one>\<^sub>M"
      and A2: "t =HIDDENR1 s -XCMPLX-0K6 \<one>\<^sub>M"
    have "s chooseNEWTONK3 t =XBOOLE-0R4 s chooseNEWTONK3 \<one>\<^sub>M"
      using A1 A2 newton_th_20 sorry
    thus "s chooseNEWTONK3 t =HIDDENR1 s"
      using A1 newton_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_25:
" for r be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds s chooseNEWTONK3 r be ElementSUBSET-1M1-of NATNUMBERSK1"
proof-
  have " for r be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds s chooseNEWTONK3 r be ElementSUBSET-1M1-of NATNUMBERSK1"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix s assume [ty]: "s be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have A0: "s be NatNAT-1M1"
      using tarski_th_1 sorry
    let ?P = "\<lambda>Lamb1.  for r be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds Lamb1 chooseNEWTONK3 r be ElementSUBSET-1M1-of NATNUMBERSK1"
    have A1: " for s be NatNAT-1M1 holds ?P(s) implies ?P(s +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for s be NatNAT-1M1 holds ( for r be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds s chooseNEWTONK3 r be ElementSUBSET-1M1-of NATNUMBERSK1) implies ( for r be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (s +NAT-1K1 \<one>\<^sub>M)chooseNEWTONK3 r be ElementSUBSET-1M1-of NATNUMBERSK1)"
      proof(rule ballI,rule impI,rule ballI)
        fix s assume [ty]: "s be NatNAT-1M1"
        assume A2: "?P(s)"
        have A3: " for r be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds r <>HIDDENR2 0NUMBERSK6 implies (s +NAT-1K1 \<one>\<^sub>M)chooseNEWTONK3 r be ElementSUBSET-1M1-of NATNUMBERSK1"
        proof(rule ballI,rule impI)
          fix r assume [ty]: "r be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
          assume A4: "r <>HIDDENR2 0NUMBERSK6"
          have "(s +NAT-1K1 \<one>\<^sub>M)chooseNEWTONK3 r be ElementSUBSET-1M1-of NATNUMBERSK1"
          proof-
            obtain t where
              [ty]:"t be NatNAT-1M1" and 
              A5: "r =HIDDENR1 t +NAT-1K1 \<one>\<^sub>M"
              using A4 nat_1_th_6 sorry
            have 
              [ty]:"t be ElementSUBSET-1M1-of NATNUMBERSK1"
              using ordinal1_def_12 sorry
            obtain m1 m2 where 
              [ty]:"m1 be ElementSUBSET-1M1-of NATNUMBERSK1" and m1Def:"m1 = s chooseNEWTONK3 t" and
              [ty]:"m2 be ElementSUBSET-1M1-of NATNUMBERSK1" and m2Def:"m2 = s chooseNEWTONK3 (t +NAT-1K1 \<one>\<^sub>M)"
              using A2 sorry
            have "m1 +NAT-1K1 m2 =XBOOLE-0R4 s chooseNEWTONK3 t +XCMPLX-0K2 s chooseNEWTONK3 (t +NAT-1K1 \<one>\<^sub>M)"
               sorry
            thus "(s +NAT-1K1 \<one>\<^sub>M)chooseNEWTONK3 r be ElementSUBSET-1M1-of NATNUMBERSK1"
              using A5 newton_th_22 sorry
          qed
          thus "(s +NAT-1K1 \<one>\<^sub>M)chooseNEWTONK3 r be ElementSUBSET-1M1-of NATNUMBERSK1"
             sorry
        qed "sorry"
        fix r assume [ty]: "r be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
        have "r =HIDDENR1 0NUMBERSK6 or r <>HIDDENR2 0NUMBERSK6"
           sorry
        thus "(s +NAT-1K1 \<one>\<^sub>M)chooseNEWTONK3 r be ElementSUBSET-1M1-of NATNUMBERSK1"
          using A3 newton_th_19 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A6: "?P(0NUMBERSK6)"
    proof-
      have " for r be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (0NUMBERSK6)chooseNEWTONK3 r be ElementSUBSET-1M1-of NATNUMBERSK1"
      proof(rule ballI)
        fix r assume [ty]: "r be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
        have "r =HIDDENR1 0NUMBERSK6 or r >XXREAL-0R4 0NUMBERSK6"
           sorry
        thus "(0NUMBERSK6)chooseNEWTONK3 r be ElementSUBSET-1M1-of NATNUMBERSK1"
          using newton_def_3 newton_th_19 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for s be NatNAT-1M1 holds ?P(s)"
      using nat_1_sch_2 A6 A1 sorry
    thus "s chooseNEWTONK3 r be ElementSUBSET-1M1-of NATNUMBERSK1"
      using A0 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_26:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (m <>HIDDENR2 0NUMBERSK6 & lenFINSEQ-1K4 F =XBOOLE-0R4 m) & ( for i be NatNAT-1M1 holds  for l be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 F & l =XBOOLE-0R4 (n +XCMPLX-0K2 i)-XCMPLX-0K6 \<one>\<^sub>M implies F .FUNCT-1K1 i =XBOOLE-0R4 l chooseNEWTONK3 n) implies SumRVSUM-1K22 F =HIDDENR1 (n +XCMPLX-0K2 m)chooseNEWTONK3 (n +NAT-1K1 \<one>\<^sub>M)"
proof-
  have " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (m <>HIDDENR2 0NUMBERSK6 & lenFINSEQ-1K4 F =XBOOLE-0R4 m) & ( for i be NatNAT-1M1 holds  for l be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 F & l =XBOOLE-0R4 (n +XCMPLX-0K2 i)-XCMPLX-0K6 \<one>\<^sub>M implies F .FUNCT-1K1 i =XBOOLE-0R4 l chooseNEWTONK3 n) implies SumRVSUM-1K22 F =HIDDENR1 (n +XCMPLX-0K2 m)chooseNEWTONK3 (n +NAT-1K1 \<one>\<^sub>M)"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?P = "\<lambda>Lamb1.  for F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (Lamb1 <>HIDDENR2 0NUMBERSK6 & lenFINSEQ-1K4 F =XBOOLE-0R4 Lamb1) & ( for i be NatNAT-1M1 holds  for l be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 F & l =XBOOLE-0R4 (n +XCMPLX-0K2 i)-XCMPLX-0K6 \<one>\<^sub>M implies F .FUNCT-1K1 i =XBOOLE-0R4 l chooseNEWTONK3 n) implies SumRVSUM-1K22 F =HIDDENR1 (n +XCMPLX-0K2 Lamb1)chooseNEWTONK3 (n +NAT-1K1 \<one>\<^sub>M)"
    have A1: " for m be NatNAT-1M1 holds ?P(m) implies ?P(m +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for m be NatNAT-1M1 holds ?P(m) implies ( for F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds m +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 0NUMBERSK6 & (lenFINSEQ-1K4 F =XBOOLE-0R4 m +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds  for l be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 F & l =XBOOLE-0R4 (n +XCMPLX-0K2 i)-XCMPLX-0K6 \<one>\<^sub>M implies F .FUNCT-1K1 i =XBOOLE-0R4 l chooseNEWTONK3 n)) implies SumRVSUM-1K22 F =HIDDENR1 (n +NAT-1K1 (m +NAT-1K1 \<one>\<^sub>M))chooseNEWTONK3 (n +NAT-1K1 \<one>\<^sub>M))"
      proof(rule ballI,rule impI,rule ballI,rule impMI ,rule impMI ,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume A2: "?P(m)"
        fix F assume [ty]: "F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
        assume "m +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 0NUMBERSK6"
          and A3: "lenFINSEQ-1K4 F =XBOOLE-0R4 m +NAT-1K1 \<one>\<^sub>M"
          and A4: " for i be NatNAT-1M1 holds  for l be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 F & l =XBOOLE-0R4 (n +XCMPLX-0K2 i)-XCMPLX-0K6 \<one>\<^sub>M implies F .FUNCT-1K1 i =XBOOLE-0R4 l chooseNEWTONK3 n"
        obtain G x where
          [ty]:"G be FinSequenceFINSEQ-1M3-of REALNUMBERSK2" "x be ElementSUBSET-1M1-of REALNUMBERSK2" and 
          A5: "F =FINSEQ-1R1 G ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> x*>)"
          using A3 finseq_2_th_19 sorry
        have A6: "m +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 G +NAT-1K1 \<one>\<^sub>M"
          using A3 A5 finseq_2_th_16 sorry
        show "SumRVSUM-1K22 F =HIDDENR1 (n +NAT-1K1 (m +NAT-1K1 \<one>\<^sub>M))chooseNEWTONK3 (n +NAT-1K1 \<one>\<^sub>M)"
        proof-
          have cases: "m =XBOOLE-0R4 0NUMBERSK6 or m <>HIDDENR2 0NUMBERSK6"
             sorry
          have case1: "m =XBOOLE-0R4 0NUMBERSK6 implies SumRVSUM-1K22 F =HIDDENR1 (n +NAT-1K1 (m +NAT-1K1 \<one>\<^sub>M))chooseNEWTONK3 (n +NAT-1K1 \<one>\<^sub>M)"
          proof(rule impI)
            assume A7: "m =XBOOLE-0R4 0NUMBERSK6"
            have A8: "n =XBOOLE-0R4 (n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
               sorry
            obtain c where 
              [ty]:"c be ElementSUBSET-1M1-of REALNUMBERSK2" and cDef:"c = n chooseNEWTONK3 n"
              using xreal_0_def_1 sorry
            have A9: "domFINSEQ-1K5 F =MEMBEREDR12 SegFINSEQ-1K2 \<one>\<^sub>M"
              using A3 A7 finseq_1_def_3 sorry
            then have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 F"
               sorry
            then have "F .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 n chooseNEWTONK3 n"
              using A4 A8 sorry
            then have "SumRVSUM-1K22 F =HIDDENR1 SumRVSUM-1K22 (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> c*>)"
              using A9 finseq_1_def_8 sorry
            also have "... = n chooseNEWTONK3 n"
              using finsop_1_th_11 sorry
            also have "... = \<one>\<^sub>M"
              using newton_th_21 sorry
            also have "... = (n +NAT-1K1 (m +NAT-1K1 \<one>\<^sub>M))chooseNEWTONK3 (n +NAT-1K1 \<one>\<^sub>M)"
              using A7 newton_th_21 sorry
            finally show "SumRVSUM-1K22 F =HIDDENR1 (n +NAT-1K1 (m +NAT-1K1 \<one>\<^sub>M))chooseNEWTONK3 (n +NAT-1K1 \<one>\<^sub>M)"
               sorry
          qed
          have case2: "m <>HIDDENR2 0NUMBERSK6 implies SumRVSUM-1K22 F =HIDDENR1 (n +NAT-1K1 (m +NAT-1K1 \<one>\<^sub>M))chooseNEWTONK3 (n +NAT-1K1 \<one>\<^sub>M)"
          proof(rule impI)
            assume A10: "m <>HIDDENR2 0NUMBERSK6"
            have A11: "n +XCMPLX-0K2 m =XBOOLE-0R4 (n +NAT-1K1 (m +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 \<one>\<^sub>M"
               sorry
            have A12: " for i be NatNAT-1M1 holds  for l be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 G & l =XBOOLE-0R4 (n +XCMPLX-0K2 i)-XCMPLX-0K6 \<one>\<^sub>M implies G .FUNCT-1K1 i =XBOOLE-0R4 l chooseNEWTONK3 n"
            proof(rule ballI,rule ballI,rule impMI ,rule impI)
              have A13: "domFINSEQ-1K5 G c=MEMBEREDR6 domFINSEQ-1K5 F"
                using A5 finseq_1_th_26 sorry
              fix i assume [ty]: "i be NatNAT-1M1"
              fix l assume [ty]: "l be NatNAT-1M1"
              assume A14: "i inTARSKIR2 domFINSEQ-1K5 G"
                and A15: "l =XBOOLE-0R4 (n +XCMPLX-0K2 i)-XCMPLX-0K6 \<one>\<^sub>M"
              have "G .FUNCT-1K1 i =XBOOLE-0R4 F .FUNCT-1K1 i"
                using A5 A14 finseq_1_def_7 sorry
              thus "G .FUNCT-1K1 i =XBOOLE-0R4 l chooseNEWTONK3 n"
                using A4 A14 A15 A13 sorry
            qed "sorry"
            have "domFINSEQ-1K5 F =MEMBEREDR12 SegFINSEQ-1K2 (m +NAT-1K1 \<one>\<^sub>M)"
              using A3 finseq_1_def_3 sorry
            then have A16: "(n +XCMPLX-0K2 m)chooseNEWTONK3 n =HIDDENR1 (G ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> x*>)).FUNCT-1K1 (lenFINSEQ-1K4 G +NAT-1K1 \<one>\<^sub>M)"
              using A4 A5 A6 A11 finseq_1_th_4 sorry
            also have "... = x"
              using finseq_1_th_42 sorry
            finally have "(n +XCMPLX-0K2 m)chooseNEWTONK3 n =HIDDENR1 x"
               sorry
            have "SumRVSUM-1K22 F =HIDDENR1 SumRVSUM-1K22 G +XCMPLX-0K2 x"
              using A5 rvsum_1_th_74 sorry
            also have "... = (n +XCMPLX-0K2 m)chooseNEWTONK3 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 (n +XCMPLX-0K2 m)chooseNEWTONK3 n"
              using A2 A6 A10 A12 A16 sorry
            also have "... = ((n +XCMPLX-0K2 m)+NAT-1K1 \<one>\<^sub>M)chooseNEWTONK3 (n +NAT-1K1 \<one>\<^sub>M)"
              using newton_th_22 sorry
            also have "... = (n +NAT-1K1 (m +NAT-1K1 \<one>\<^sub>M))chooseNEWTONK3 (n +NAT-1K1 \<one>\<^sub>M)"
               sorry
            finally show "SumRVSUM-1K22 F =HIDDENR1 (n +NAT-1K1 (m +NAT-1K1 \<one>\<^sub>M))chooseNEWTONK3 (n +NAT-1K1 \<one>\<^sub>M)"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A17: "?P(0NUMBERSK6)"
       sorry
    show " for m be NatNAT-1M1 holds  for F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (m <>HIDDENR2 0NUMBERSK6 & lenFINSEQ-1K4 F =XBOOLE-0R4 m) & ( for i be NatNAT-1M1 holds  for l be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 F & l =XBOOLE-0R4 (n +XCMPLX-0K2 i)-XCMPLX-0K6 \<one>\<^sub>M implies F .FUNCT-1K1 i =XBOOLE-0R4 l chooseNEWTONK3 n) implies SumRVSUM-1K22 F =HIDDENR1 (n +XCMPLX-0K2 m)chooseNEWTONK3 (n +NAT-1K1 \<one>\<^sub>M)"
      using nat_1_sch_2 A17 A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_cl_10:
  mlet "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster n chooseNEWTONK3 k as-term-is naturalORDINAL1V7"
proof
(*coherence*)
  show "n chooseNEWTONK3 k be naturalORDINAL1V7"
    using newton_th_25 sorry
qed "sorry"

abbreviation(input) NEWTONK4(" _ chooseNEWTONK4  _ " [164,164]164) where
  "n chooseNEWTONK4 k \<equiv> n chooseNEWTONK3 k"

mtheorem newton_add_1:
  mlet "k be NatNAT-1M1", "n be NatNAT-1M1"
"cluster n chooseNEWTONK3 k as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "n chooseNEWTONK3 k be ElementSUBSET-1M1-of NATNUMBERSK1"
    using ordinal1_def_12 sorry
qed "sorry"

mdef newton_def_4 ("'( _ , _ ')In-PowerNEWTONK5  _ " [0,0,164]164 ) where
  mlet "a be RealXREAL-0M1", "b be RealXREAL-0M1", "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"func (a,b)In-PowerNEWTONK5 n \<rightarrow> FinSequenceFINSEQ-1M3-of REALNUMBERSK2 means
  \<lambda>it. lenFINSEQ-1K4 it =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds  for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (i inTARSKIR2 domFINSEQ-1K5 it & m =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M) & l =XBOOLE-0R4 n -XCMPLX-0K6 m implies it .FUNCT-1K1 i =XBOOLE-0R4 ((n chooseNEWTONK3 m)*XCMPLX-0K3 a  |^NEWTONK1 l)*XCMPLX-0K3 b  |^NEWTONK1 m)"
proof-
  (*existence*)
    show " ex it be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st lenFINSEQ-1K4 it =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds  for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (i inTARSKIR2 domFINSEQ-1K5 it & m =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M) & l =XBOOLE-0R4 n -XCMPLX-0K6 m implies it .FUNCT-1K1 i =XBOOLE-0R4 ((n chooseNEWTONK3 m)*XCMPLX-0K3 a  |^NEWTONK1 l)*XCMPLX-0K3 b  |^NEWTONK1 m)"
    proof-
      have " ex tVar3 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st lenFINSEQ-1K4 tVar3 =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds  for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  not (((i inTARSKIR2 domFINSEQ-1K5 tVar3 & m =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M) & l =XBOOLE-0R4 n -XCMPLX-0K6 m) &  not tVar3 .FUNCT-1K1 i =XBOOLE-0R4 ((n chooseNEWTONK3 m)*XCMPLX-0K3 a  |^NEWTONK1 l)*XCMPLX-0K3 b  |^NEWTONK1 m))"
      proof-
        have 
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
          using ordinal1_def_12 sorry
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m =XBOOLE-0R4 Lamb1 -XCMPLX-0K6 \<one>\<^sub>M & l =XBOOLE-0R4 n -XCMPLX-0K6 m implies Lamb2 =HIDDENR1 ((n chooseNEWTONK4 m)*XCMPLX-0K3 a  |^NEWTONK1 l)*XCMPLX-0K3 b  |^NEWTONK1 m"
        have A1: " for k be NatNAT-1M1 holds k inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies ( ex x be objectHIDDENM1 st ?P(k,x))"
        proof-
          have " for k be NatNAT-1M1 holds k inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies ( ex tVar2 be objectHIDDENM1 st  for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m =XBOOLE-0R4 k -XCMPLX-0K6 \<one>\<^sub>M & l =XBOOLE-0R4 n -XCMPLX-0K6 m implies tVar2 =HIDDENR1 ((n chooseNEWTONK4 m)*XCMPLX-0K3 a  |^NEWTONK1 l)*XCMPLX-0K3 b  |^NEWTONK1 m)"
          proof(rule ballI,rule impI)
            fix k assume [ty]: "k be NatNAT-1M1"
            assume A2: "k inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
            then have "k >=XXREAL-0R2 \<one>\<^sub>M"
              using finseq_1_th_1 sorry
            then obtain m1 where 
              [ty]:"m1 be ElementSUBSET-1M1-of NATNUMBERSK1" and m1Def:"m1 = k -XCMPLX-0K6 \<one>\<^sub>M"
              using int_1_th_5 sorry
            have "k <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
              using A2 finseq_1_th_1 sorry
            then have "k -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 (n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
              using xreal_1_th_9 sorry
            then obtain l1 where 
              [ty]:"l1 be ElementSUBSET-1M1-of NATNUMBERSK1" and l1Def:"l1 = n -XCMPLX-0K6 m1"
              using int_1_th_5 sorry
            show " ex tVar2 be objectHIDDENM1 st  for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m =XBOOLE-0R4 k -XCMPLX-0K6 \<one>\<^sub>M & l =XBOOLE-0R4 n -XCMPLX-0K6 m implies tVar2 =HIDDENR1 ((n chooseNEWTONK4 m)*XCMPLX-0K3 a  |^NEWTONK1 l)*XCMPLX-0K3 b  |^NEWTONK1 m"
            proof(rule bexI[of _ "((n chooseNEWTONK4 m1)*XCMPLX-0K3 a  |^NEWTONK1 l1)*XCMPLX-0K3 b  |^NEWTONK1 m1"])
              show " for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m =XBOOLE-0R4 k -XCMPLX-0K6 \<one>\<^sub>M & l =XBOOLE-0R4 n -XCMPLX-0K6 m implies ((n chooseNEWTONK4 m1)*XCMPLX-0K3 a  |^NEWTONK1 l1)*XCMPLX-0K3 b  |^NEWTONK1 m1 =HIDDENR1 ((n chooseNEWTONK4 m)*XCMPLX-0K3 a  |^NEWTONK1 l)*XCMPLX-0K3 b  |^NEWTONK1 m"
                 sorry
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain p where
          [ty]:"p be FinSequenceFINSEQ-1M1" and 
          A3: "domFINSEQ-1K5 p =MEMBEREDR12 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"and A4: " for k be NatNAT-1M1 holds k inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies ?P(k,p .FUNCT-1K1 k)"
          using finseq_1_sch_1 A1 sorry
        have "rngFUNCT-1K2 p c=TARSKIR1 REALNUMBERSK2"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p implies x inHIDDENR3 REALNUMBERSK2"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 p"
            then obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A5: "y inHIDDENR3 domFINSEQ-1K5 p"and A6: "x =HIDDENR1 p .FUNCT-1K1 y"
              using funct_1_def_3 sorry
            have 
              [ty]:"y be ElementSUBSET-1M1-of NATNUMBERSK1"
              using A5 sorry
            have "y >=XXREAL-0R2 \<one>\<^sub>M"
              using A3 A5 finseq_1_th_1 sorry
            then obtain m1 where 
              [ty]:"m1 be ElementSUBSET-1M1-of NATNUMBERSK1" and m1Def:"m1 = y -XCMPLX-0K6 \<one>\<^sub>M"
              using int_1_th_5 sorry
            have "y <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
              using A3 A5 finseq_1_th_1 sorry
            then have "y -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 (n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
              using xreal_1_th_9 sorry
            then obtain l1 where 
              [ty]:"l1 be ElementSUBSET-1M1-of NATNUMBERSK1" and l1Def:"l1 = n -XCMPLX-0K6 m1"
              using int_1_th_5 sorry
            have "p .FUNCT-1K1 y =XBOOLE-0R4 ((n chooseNEWTONK4 m1)*XCMPLX-0K3 a  |^NEWTONK1 l1)*XCMPLX-0K3 b  |^NEWTONK1 m1"
              using A3 A4 A5 sorry
            then have 
              [ty]:"x be RealXREAL-0M1"
              using A6 sorry
            have "x inHIDDENR3 REALNUMBERSK2"
              using xreal_0_def_1 sorry
            thus "x inHIDDENR3 REALNUMBERSK2"
               sorry
          qed "sorry"
          thus "rngFUNCT-1K2 p c=TARSKIR1 REALNUMBERSK2"
            using tarski_def_3 sorry
        qed
        then have 
          [ty]:"p be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
          using finseq_1_def_4 sorry
        show " ex tVar3 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st lenFINSEQ-1K4 tVar3 =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds  for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  not (((i inTARSKIR2 domFINSEQ-1K5 tVar3 & m =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M) & l =XBOOLE-0R4 n -XCMPLX-0K6 m) &  not tVar3 .FUNCT-1K1 i =XBOOLE-0R4 ((n chooseNEWTONK3 m)*XCMPLX-0K3 a  |^NEWTONK1 l)*XCMPLX-0K3 b  |^NEWTONK1 m))"
        proof(rule bexI[of _ "p"])
          show "lenFINSEQ-1K4 p =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds  for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  not (((i inTARSKIR2 domFINSEQ-1K5 p & m =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M) & l =XBOOLE-0R4 n -XCMPLX-0K6 m) &  not p .FUNCT-1K1 i =XBOOLE-0R4 ((n chooseNEWTONK3 m)*XCMPLX-0K3 a  |^NEWTONK1 l)*XCMPLX-0K3 b  |^NEWTONK1 m))"
            using A3 A4 finseq_1_def_3 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for it2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (lenFINSEQ-1K4 it1 =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds  for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (i inTARSKIR2 domFINSEQ-1K5 it1 & m =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M) & l =XBOOLE-0R4 n -XCMPLX-0K6 m implies it1 .FUNCT-1K1 i =XBOOLE-0R4 ((n chooseNEWTONK3 m)*XCMPLX-0K3 a  |^NEWTONK1 l)*XCMPLX-0K3 b  |^NEWTONK1 m)) & (lenFINSEQ-1K4 it2 =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds  for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (i inTARSKIR2 domFINSEQ-1K5 it2 & m =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M) & l =XBOOLE-0R4 n -XCMPLX-0K6 m implies it2 .FUNCT-1K1 i =XBOOLE-0R4 ((n chooseNEWTONK3 m)*XCMPLX-0K3 a  |^NEWTONK1 l)*XCMPLX-0K3 b  |^NEWTONK1 m)) implies it1 =HIDDENR1 it2"
    proof-
      have " for G be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for H be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds lenFINSEQ-1K4 G =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds  for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (i inTARSKIR2 domFINSEQ-1K5 G & m =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M) & l =XBOOLE-0R4 n -XCMPLX-0K6 m implies G .FUNCT-1K1 i =XBOOLE-0R4 ((n chooseNEWTONK3 m)*XCMPLX-0K3 a  |^NEWTONK1 l)*XCMPLX-0K3 b  |^NEWTONK1 m) implies (lenFINSEQ-1K4 H =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds  for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (i inTARSKIR2 domFINSEQ-1K5 H & m =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M) & l =XBOOLE-0R4 n -XCMPLX-0K6 m implies H .FUNCT-1K1 i =XBOOLE-0R4 ((n chooseNEWTONK3 m)*XCMPLX-0K3 a  |^NEWTONK1 l)*XCMPLX-0K3 b  |^NEWTONK1 m) implies G =HIDDENR1 H)"
      proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impMI ,rule impI)
        fix G assume [ty]: "G be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
        fix H assume [ty]: "H be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
        assume A7: "lenFINSEQ-1K4 G =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
          and A8: " for i be NatNAT-1M1 holds  for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (i inTARSKIR2 domFINSEQ-1K5 G & m =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M) & l =XBOOLE-0R4 n -XCMPLX-0K6 m implies G .FUNCT-1K1 i =XBOOLE-0R4 ((n chooseNEWTONK3 m)*XCMPLX-0K3 a  |^NEWTONK1 l)*XCMPLX-0K3 b  |^NEWTONK1 m"
        assume A9: "lenFINSEQ-1K4 H =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
          and A10: " for i be NatNAT-1M1 holds  for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (i inTARSKIR2 domFINSEQ-1K5 H & m =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M) & l =XBOOLE-0R4 n -XCMPLX-0K6 m implies H .FUNCT-1K1 i =XBOOLE-0R4 ((n chooseNEWTONK3 m)*XCMPLX-0K3 a  |^NEWTONK1 l)*XCMPLX-0K3 b  |^NEWTONK1 m"
        have " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 G implies G .FUNCT-1K1 i =XBOOLE-0R4 H .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be NatNAT-1M1"
          assume A11: "i inTARSKIR2 domFINSEQ-1K5 G"
          then have A12: "i inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
            using A7 finseq_1_def_3 sorry
          then have "i >=XXREAL-0R2 \<one>\<^sub>M"
            using finseq_1_th_1 sorry
          then obtain m where 
            [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and mDef:"m = i -XCMPLX-0K6 \<one>\<^sub>M"
            using int_1_th_5 sorry
          have "i <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
            using A12 finseq_1_th_1 sorry
          then have "i -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 (n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
            using xreal_1_th_9 sorry
          then obtain l where 
            [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1" and lDef:"l = n -XCMPLX-0K6 m"
            using int_1_th_5 sorry
          have "i inTARSKIR2 domFINSEQ-1K5 H"
            using A9 A12 finseq_1_def_3 sorry
          then have "H .FUNCT-1K1 i =XBOOLE-0R4 ((n chooseNEWTONK3 m)*XCMPLX-0K3 a  |^NEWTONK1 l)*XCMPLX-0K3 b  |^NEWTONK1 m"
            using A10 sorry
          thus "G .FUNCT-1K1 i =XBOOLE-0R4 H .FUNCT-1K1 i"
            using A8 A11 sorry
        qed "sorry"
        thus "G =HIDDENR1 H"
          using A7 A9 finseq_2_th_9 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem newton_th_27:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (a,b)In-PowerNEWTONK5 (0NUMBERSK6) =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M*>"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (a,b)In-PowerNEWTONK5 (0NUMBERSK6) =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M*>"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    let ?F = "(a,b)In-PowerNEWTONK5 (0NUMBERSK6)"
    have A1: "lenFINSEQ-1K4 ?F =HIDDENR1 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
      using newton_def_4 sorry
    also have "... = \<one>\<^sub>M"
       sorry
    finally have "lenFINSEQ-1K4 ?F =HIDDENR1 \<one>\<^sub>M"
       sorry
    then have A2: "domFINSEQ-1K5 ?F =MEMBEREDR12 {TARSKIK1 \<one>\<^sub>M}"
      using finseq_1_th_2 finseq_1_def_3 sorry
    then have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ?F"
      using tarski_def_1 sorry
    then obtain i where
      [ty]:"i be setHIDDENM2" and 
      A3: "i inTARSKIR2 domFINSEQ-1K5 ?F"
       sorry
    have 
      [ty]:"i be ElementSUBSET-1M1-of NATNUMBERSK1"
      using A3 sorry
    have A4: "i =XBOOLE-0R4 \<one>\<^sub>M"
      using A2 A3 tarski_def_1 sorry
    then obtain m1 where 
      [ty]:"m1 be ElementSUBSET-1M1-of NATNUMBERSK1" and m1Def:"m1 = i -XCMPLX-0K6 \<one>\<^sub>M"
      using int_1_th_5 sorry
    obtain l1 where 
      [ty]:"l1 be ElementSUBSET-1M1-of NATNUMBERSK1" and l1Def:"l1 = 0NUMBERSK6 -XCMPLX-0K6 m1"
      using A4 sorry
    have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ((a,b)In-PowerNEWTONK5 (0NUMBERSK6))"
      using A2 tarski_def_1 sorry
    then have "?F .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 (((0NUMBERSK6)chooseNEWTONK4 (0NUMBERSK6))*XCMPLX-0K3 a  |^NEWTONK1 l1)*XCMPLX-0K3 b  |^NEWTONK1 m1"
      using A4 newton_def_4 sorry
    also have "... = (\<one>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 (0NUMBERSK6))*XCMPLX-0K3 b  |^NEWTONK1 (0NUMBERSK6)"
      using A4 newton_th_21 sorry
    also have "... = \<one>\<^sub>M"
      using rvsum_1_th_94 sorry
    finally have "?F .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 \<one>\<^sub>M"
       sorry
    thus "(a,b)In-PowerNEWTONK5 (0NUMBERSK6) =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M*>"
      using A1 finseq_1_th_40 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_28:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds ((a,b)In-PowerNEWTONK5 s).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 a  |^NEWTONK1 s"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds ((a,b)In-PowerNEWTONK5 s).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 a  |^NEWTONK1 s"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix s assume [ty]: "s be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    obtain m1 where 
      [ty]:"m1 be ElementSUBSET-1M1-of NATNUMBERSK1" and m1Def:"m1 = \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
      using int_1_th_5 sorry
    obtain l1 where 
      [ty]:"l1 be NatNAT-1M1" and l1Def:"l1 = s -XCMPLX-0K6 m1"
       sorry
    have "lenFINSEQ-1K4 ((a,b)In-PowerNEWTONK5 s) =XBOOLE-0R4 s +NAT-1K1 \<one>\<^sub>M"
      using newton_def_4 sorry
    then have A1: "domFINSEQ-1K5 ((a,b)In-PowerNEWTONK5 s) =MEMBEREDR12 SegFINSEQ-1K2 (s +NAT-1K1 \<one>\<^sub>M)"
      using finseq_1_def_3 sorry
    have "s +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
      using xreal_1_th_6 sorry
    then have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ((a,b)In-PowerNEWTONK5 s)"
      using A1 sorry
    then have "((a,b)In-PowerNEWTONK5 s).FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 ((s chooseNEWTONK3 (0NUMBERSK6))*XCMPLX-0K3 a  |^NEWTONK1 l1)*XCMPLX-0K3 b  |^NEWTONK1 m1"
      using newton_def_4 sorry
    also have "... = (\<one>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 l1)*XCMPLX-0K3 b  |^NEWTONK1 m1"
      using newton_th_19 sorry
    also have "... = a  |^NEWTONK1 s"
      using rvsum_1_th_94 sorry
    finally have "((a,b)In-PowerNEWTONK5 s).FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a  |^NEWTONK1 s"
       sorry
    thus "((a,b)In-PowerNEWTONK5 s).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 a  |^NEWTONK1 s"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_29:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds ((a,b)In-PowerNEWTONK5 s).FUNCT-1K1 (s +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 b  |^NEWTONK1 s"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds ((a,b)In-PowerNEWTONK5 s).FUNCT-1K1 (s +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 b  |^NEWTONK1 s"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix s assume [ty]: "s be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    obtain m1 where 
      [ty]:"m1 be ElementSUBSET-1M1-of NATNUMBERSK1" and m1Def:"m1 = (s +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
      using int_1_th_5 nat_1_th_12 sorry
    obtain l1 where 
      [ty]:"l1 be ElementSUBSET-1M1-of NATNUMBERSK1" and l1Def:"l1 = s -XCMPLX-0K6 m1"
      using int_1_th_5 sorry
    have "lenFINSEQ-1K4 ((a,b)In-PowerNEWTONK5 s) =XBOOLE-0R4 s +NAT-1K1 \<one>\<^sub>M"
      using newton_def_4 sorry
    then have "domFINSEQ-1K5 ((a,b)In-PowerNEWTONK5 s) =MEMBEREDR12 SegFINSEQ-1K2 (s +NAT-1K1 \<one>\<^sub>M)"
      using finseq_1_def_3 sorry
    then have "s +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ((a,b)In-PowerNEWTONK5 s)"
      using finseq_1_th_4 sorry
    then have "((a,b)In-PowerNEWTONK5 s).FUNCT-1K1 (s +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((s chooseNEWTONK3 s)*XCMPLX-0K3 a  |^NEWTONK1 l1)*XCMPLX-0K3 b  |^NEWTONK1 m1"
      using newton_def_4 sorry
    also have "... = (\<one>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 l1)*XCMPLX-0K3 b  |^NEWTONK1 m1"
      using newton_th_21 sorry
    also have "... = \<one>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 m1"
      using rvsum_1_th_94 sorry
    also have "... = b  |^NEWTONK1 s"
       sorry
    finally have "((a,b)In-PowerNEWTONK5 s).FUNCT-1K1 (s +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 b  |^NEWTONK1 s"
       sorry
    thus "((a,b)In-PowerNEWTONK5 s).FUNCT-1K1 (s +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 b  |^NEWTONK1 s"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_30:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (a +XCMPLX-0K2 b) |^NEWTONK1 s =HIDDENR1 SumRVSUM-1K22 ((a,b)In-PowerNEWTONK5 s)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (a +XCMPLX-0K2 b) |^NEWTONK1 s =HIDDENR1 SumRVSUM-1K22 ((a,b)In-PowerNEWTONK5 s)"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix s assume [ty]: "s be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have A0: "s be NatNAT-1M1"
      using tarski_th_1 sorry
    let ?P = "\<lambda>Lamb1. (a +XCMPLX-0K2 b) |^NEWTONK1 Lamb1 =HIDDENR1 SumRVSUM-1K22 ((a,b)In-PowerNEWTONK5 Lamb1)"
    have A1: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds (a +XCMPLX-0K2 b) |^NEWTONK1 n =HIDDENR1 SumRVSUM-1K22 ((a,b)In-PowerNEWTONK5 n) implies (a +XCMPLX-0K2 b) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 SumRVSUM-1K22 ((a,b)In-PowerNEWTONK5 (n +NAT-1K1 \<one>\<^sub>M))"
      proof(rule ballI,rule impI)
        have 
          [ty]:"a be ElementSUBSET-1M1-of REALNUMBERSK2" and
          [ty]:"b be ElementSUBSET-1M1-of REALNUMBERSK2"
          using xreal_0_def_1 sorry
        fix n assume [ty]: "n be NatNAT-1M1"
        obtain G1 where 
          [ty]:"G1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2" and G1Def:"G1 = (a *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n))^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2) *>)"
           sorry
        let ?G2 = "(<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2) *>)^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (b *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n))"
        assume "?P(n)"
        then have A2: "(a +REAL-1K3 b) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (a +REAL-1K3 b)*XCMPLX-0K3 SumRVSUM-1K22 ((a,b)In-PowerNEWTONK5 n)"
          using newton_th_6 sorry
        also have "... = a *XCMPLX-0K3 SumRVSUM-1K22 ((a,b)In-PowerNEWTONK5 n) +XCMPLX-0K2 b *XCMPLX-0K3 SumRVSUM-1K22 ((a,b)In-PowerNEWTONK5 n)"
           sorry
        also have "... = SumRVSUM-1K22 (a *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n)) +XCMPLX-0K2 b *XCMPLX-0K3 SumRVSUM-1K22 ((a,b)In-PowerNEWTONK5 n)"
          using rvsum_1_th_87 sorry
        also have "... = SumRVSUM-1K22 (a *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n)) +XCMPLX-0K2 SumRVSUM-1K22 (b *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n))"
          using rvsum_1_th_87 sorry
        finally have "(a +REAL-1K3 b) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 SumRVSUM-1K22 (a *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n)) +XCMPLX-0K2 SumRVSUM-1K22 (b *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n))"
           sorry
        have "lenFINSEQ-1K4 ?G2 =HIDDENR1 lenFINSEQ-1K4 (<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>) +NAT-1K1 lenFINSEQ-1K4 (b *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n))"
          using finseq_1_th_22 sorry
        also have "... = \<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 (b *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n))"
          using finseq_1_th_40 sorry
        also have "... = \<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 ((a,b)In-PowerNEWTONK5 n)"
          using newton_th_2 sorry
        also have "... = (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
          using newton_def_4 sorry
        finally have "lenFINSEQ-1K4 ?G2 =HIDDENR1 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
           sorry
        then obtain F2 where 
          [ty]:"F2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)-tuples-onFINSEQ-2K4 REALNUMBERSK2" and F2Def:"F2 = ?G2"
          using finseq_2_th_92 sorry
        have "lenFINSEQ-1K4 G1 =HIDDENR1 lenFINSEQ-1K4 (a *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n)) +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>)"
          using finseq_1_th_22 sorry
        also have "... = lenFINSEQ-1K4 (a *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n)) +NAT-1K1 \<one>\<^sub>M"
          using finseq_1_th_40 sorry
        also have "... = lenFINSEQ-1K4 ((a,b)In-PowerNEWTONK5 n) +NAT-1K1 \<one>\<^sub>M"
          using newton_th_2 sorry
        also have "... = (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
          using newton_def_4 sorry
        finally have "lenFINSEQ-1K4 G1 =HIDDENR1 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
           sorry
        then obtain F1 where 
          [ty]:"F1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)-tuples-onFINSEQ-2K4 REALNUMBERSK2" and F1Def:"F1 = G1"
          using finseq_2_th_92 sorry
        have A3: "SumRVSUM-1K22 F2 =HIDDENR1 0NUMBERSK6 +XCMPLX-0K2 SumRVSUM-1K22 (b *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n))"
          using rvsum_1_th_76 sorry
        also have "... = SumRVSUM-1K22 (b *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n))"
           sorry
        finally have "SumRVSUM-1K22 F2 =HIDDENR1 SumRVSUM-1K22 (b *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n))"
           sorry
        have "SumRVSUM-1K22 F1 =HIDDENR1 SumRVSUM-1K22 (a *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n)) +XCMPLX-0K2 0NUMBERSK6"
          using rvsum_1_th_74 sorry
        also have "... = SumRVSUM-1K22 (a *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n))"
           sorry
        finally have "SumRVSUM-1K22 F1 =HIDDENR1 SumRVSUM-1K22 (a *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n))"
           sorry
        then have A4: "SumRVSUM-1K22 (G1 +RVSUM-1K5 ?G2) =HIDDENR1 SumRVSUM-1K22 (a *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n)) +XCMPLX-0K2 SumRVSUM-1K22 (b *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n))"
          using A3 rvsum_1_th_89 sorry
        let ?F = "F1 +RVSUM-1K6\<^bsub>((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)\<^esub> F2"
        have A5: "lenFINSEQ-1K4 F2 =XBOOLE-0R4 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
          using card_1_def_7 sorry
        have A6: "lenFINSEQ-1K4 ?F =XBOOLE-0R4 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
          using card_1_def_7 sorry
        have A7: "lenFINSEQ-1K4 F1 =XBOOLE-0R4 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
          using card_1_def_7 sorry
        have A8: " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 ((a,b)In-PowerNEWTONK5 (n +NAT-1K1 \<one>\<^sub>M)) implies ?F .FUNCT-1K1 i =XBOOLE-0R4 ((a,b)In-PowerNEWTONK5 (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 i"
        proof-
          have " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 ((a,b)In-PowerNEWTONK5 (n +NAT-1K1 \<one>\<^sub>M)) implies (F1 +RVSUM-1K6\<^bsub>((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)\<^esub> F2).FUNCT-1K1 i =XBOOLE-0R4 ((a,b)In-PowerNEWTONK5 (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 i"
          proof(rule ballI,rule impI)
            fix i assume [ty]: "i be NatNAT-1M1"
            assume A9: "i inTARSKIR2 domFINSEQ-1K5 ((a,b)In-PowerNEWTONK5 (n +NAT-1K1 \<one>\<^sub>M))"
            let ?r2 = "F2 /.PARTFUN1K7\<^bsub>(REALNUMBERSK2)\<^esub> i"
            let ?r1 = "F1 /.PARTFUN1K7\<^bsub>(REALNUMBERSK2)\<^esub> i"
            let ?r = "((a,b)In-PowerNEWTONK5 n)/.PARTFUN1K7\<^bsub>(REALNUMBERSK2)\<^esub> i"
            have A10: "lenFINSEQ-1K4 ((a,b)In-PowerNEWTONK5 (n +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
              using newton_def_4 sorry
            then have A11: "i inTARSKIR2 SegFINSEQ-1K2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
              using A9 finseq_1_def_3 sorry
            then have A12: "i inTARSKIR2 domFINSEQ-1K5 F1"
              using A7 finseq_1_def_3 sorry
            have A13: "i inTARSKIR2 domFINSEQ-1K5 F2"
              using A5 A11 finseq_1_def_3 sorry
            have A14: "i inTARSKIR2 {TARSKIK1 \<one>\<^sub>M} implies ?F .FUNCT-1K1 i =XBOOLE-0R4 ((a,b)In-PowerNEWTONK5 (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 i"
            proof-
              have "i inTARSKIR2 {TARSKIK1 \<one>\<^sub>M} implies (F1 +RVSUM-1K6\<^bsub>((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)\<^esub> F2).FUNCT-1K1 i =XBOOLE-0R4 ((a,b)In-PowerNEWTONK5 (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 i"
              proof(rule impI)
                have "n +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
                  using xreal_1_th_6 sorry
                then have "\<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
                   sorry
                then have "\<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 ((a,b)In-PowerNEWTONK5 n))"
                  using newton_def_4 sorry
                then have A15: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ((a,b)In-PowerNEWTONK5 n)"
                  using finseq_1_def_3 sorry
                then have A16: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (a *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n))"
                  using valued_1_def_5 sorry
                assume "i inTARSKIR2 {TARSKIK1 \<one>\<^sub>M}"
                then have A17: "i =XBOOLE-0R4 \<one>\<^sub>M"
                  using tarski_def_1 sorry
                then have A18: "?r =XBOOLE-0R4 ((a,b)In-PowerNEWTONK5 n).FUNCT-1K1 \<one>\<^sub>M"
                  using A15 partfun1_def_6 sorry
                have "?r =XBOOLE-0R4 ((a,b)In-PowerNEWTONK5 n).FUNCT-1K1 i"
                  using A17 A15 partfun1_def_6 sorry
                then have A19: "?r =XBOOLE-0R4 a  |^NEWTONK1 n"
                  using A17 newton_th_28 sorry
                have A20: "?r1 =HIDDENR1 ((a *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n))^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>)).FUNCT-1K1 \<one>\<^sub>M"
                  using A12 A17 partfun1_def_6 sorry
                also have "... = (a *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n)).FUNCT-1K1 \<one>\<^sub>M"
                  using A16 finseq_1_def_7 sorry
                also have "... = a *XCMPLX-0K3 a  |^NEWTONK1 n"
                  using A18 A19 rvsum_1_th_44 sorry
                also have "... = a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
                  using newton_th_6 sorry
                finally have "?r1 =HIDDENR1 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
                   sorry
                have A21: "?r2 =XBOOLE-0R4 F2 .FUNCT-1K1 i"
                  using A13 partfun1_def_6 sorry
                have A22: "?r1 =XBOOLE-0R4 F1 .FUNCT-1K1 i"
                  using A12 partfun1_def_6 sorry
                have "?r2 =HIDDENR1 ((<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>)^FINSEQ-1K8 (b *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n))).FUNCT-1K1 \<one>\<^sub>M"
                  using A13 A17 partfun1_def_6 sorry
                also have "... = 0NUMBERSK6"
                  using finseq_1_th_41 sorry
                finally have "?r2 =HIDDENR1 0NUMBERSK6"
                   sorry
                then have "?F .FUNCT-1K1 i =HIDDENR1 ?r1 +XCMPLX-0K2 0NUMBERSK6"
                  using A22 A21 rvsum_1_th_11 sorry
                also have "... = ((a,b)In-PowerNEWTONK5 (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 i"
                  using A17 A20 newton_th_28 sorry
                finally have "?F .FUNCT-1K1 i =HIDDENR1 ((a,b)In-PowerNEWTONK5 (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 i"
                   sorry
                thus "(F1 +RVSUM-1K6\<^bsub>((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)\<^esub> F2).FUNCT-1K1 i =XBOOLE-0R4 ((a,b)In-PowerNEWTONK5 (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 i"
                   sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            have "i >=XXREAL-0R2 \<one>\<^sub>M"
              using A11 finseq_1_th_1 sorry
            then obtain j where 
              [ty]:"j be ElementSUBSET-1M1-of NATNUMBERSK1" and jDef:"j = i -XCMPLX-0K6 \<one>\<^sub>M"
              using int_1_th_5 sorry
            let ?x = "((a,b)In-PowerNEWTONK5 n)/.PARTFUN1K7\<^bsub>(REALNUMBERSK2)\<^esub> j"
            have A23: "i =XBOOLE-0R4 j +NAT-1K1 \<one>\<^sub>M"
               sorry
            have A24: "i inTARSKIR2 domFINSEQ-1K5 ?F"
              using A6 A11 finseq_1_def_3 sorry
            have A25: "i inTARSKIR2 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : k >XXREAL-0R4 \<one>\<^sub>M & k <XXREAL-0R3 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M } implies ?F .FUNCT-1K1 i =XBOOLE-0R4 ((a,b)In-PowerNEWTONK5 (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 i"
            proof-
              have "i inTARSKIR2 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : \<one>\<^sub>M <XXREAL-0R3 k & k <XXREAL-0R3 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M } implies (F1 +RVSUM-1K6\<^bsub>((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)\<^esub> F2).FUNCT-1K1 i =XBOOLE-0R4 ((a,b)In-PowerNEWTONK5 (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 i"
              proof(rule impI)
                assume "i inTARSKIR2 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : \<one>\<^sub>M <XXREAL-0R3 k & k <XXREAL-0R3 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M }"
                then have A26: " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st (k =XBOOLE-0R4 i & \<one>\<^sub>M <XXREAL-0R3 k) & k <XXREAL-0R3 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
                   sorry
                then obtain m1 where 
                  [ty]:"m1 be ElementSUBSET-1M1-of NATNUMBERSK1" and m1Def:"m1 = i -XCMPLX-0K6 \<one>\<^sub>M"
                  using int_1_th_5 sorry
                have A27: "?r1 =XBOOLE-0R4 ((a *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n))^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>)).FUNCT-1K1 i"
                  using A12 partfun1_def_6 sorry
                have "\<one>\<^sub>M <=XXREAL-0R1 j"
                  using A23 A26 nat_1_th_13 sorry
                then obtain m2 where 
                  [ty]:"m2 be ElementSUBSET-1M1-of NATNUMBERSK1" and m2Def:"m2 = j -XCMPLX-0K6 \<one>\<^sub>M"
                  using int_1_th_5 sorry
                have A28: "j <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
                  using A23 A26 xreal_1_th_6 sorry
                then have "j -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 (n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
                  using xreal_1_th_9 sorry
                then obtain l2 where 
                  [ty]:"l2 be ElementSUBSET-1M1-of NATNUMBERSK1" and l2Def:"l2 = n -XCMPLX-0K6 m2"
                  using int_1_th_5 sorry
                have "\<one>\<^sub>M <=XXREAL-0R1 j"
                  using A23 A26 nat_1_th_13 sorry
                then have "j inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
                  using A28 sorry
                then have "j inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 ((a,b)In-PowerNEWTONK5 n))"
                  using newton_def_4 sorry
                then have A29: "j inTARSKIR2 domFINSEQ-1K5 ((a,b)In-PowerNEWTONK5 n)"
                  using finseq_1_def_3 sorry
                then have A30: "?x =XBOOLE-0R4 ((a,b)In-PowerNEWTONK5 n).FUNCT-1K1 j"
                  using partfun1_def_6 sorry
                have A31: "i <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
                  using A26 nat_1_th_13 sorry
                then have "i inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
                  using A26 sorry
                then have "i inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 ((a,b)In-PowerNEWTONK5 n))"
                  using newton_def_4 sorry
                then have A32: "i inTARSKIR2 domFINSEQ-1K5 ((a,b)In-PowerNEWTONK5 n)"
                  using finseq_1_def_3 sorry
                then have A33: "?r =XBOOLE-0R4 ((a,b)In-PowerNEWTONK5 n).FUNCT-1K1 i"
                  using partfun1_def_6 sorry
                have "i inTARSKIR2 domFINSEQ-1K5 (a *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n))"
                  using A32 valued_1_def_5 sorry
                then have A34: "?r1 =HIDDENR1 (a *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n)).FUNCT-1K1 i"
                  using A27 finseq_1_def_7 sorry
                also have "... = a *REAL-1K4 ?r"
                  using A33 rvsum_1_th_44 sorry
                finally have "?r1 =HIDDENR1 a *REAL-1K4 ?r"
                   sorry
                have "i -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 (n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
                  using A31 xreal_1_th_9 sorry
                then obtain l1 where 
                  [ty]:"l1 be ElementSUBSET-1M1-of NATNUMBERSK1" and l1Def:"l1 = n -XCMPLX-0K6 m1"
                  using int_1_th_5 sorry
                have A35: "l1 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 (n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 (m2 +NAT-1K1 \<one>\<^sub>M)"
                   sorry
                have A36: "j inTARSKIR2 domFINSEQ-1K5 (b *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n))"
                  using A29 valued_1_def_5 sorry
                have A37: "?r2 =XBOOLE-0R4 ((<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>)^FINSEQ-1K8 (b *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n))).FUNCT-1K1 i"
                  using A13 partfun1_def_6 sorry
                then have "?r2 =HIDDENR1 ((<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>)^FINSEQ-1K8 (b *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n))).FUNCT-1K1 (lenFINSEQ-1K4 (<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>) +NAT-1K1 j)"
                  using A23 finseq_1_th_40 sorry
                also have "... = (b *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n)).FUNCT-1K1 j"
                  using A36 finseq_1_def_7 sorry
                also have "... = b *REAL-1K4 ?x"
                  using A30 rvsum_1_th_44 sorry
                finally have "?r2 =HIDDENR1 b *REAL-1K4 ?x"
                   sorry
                then have "?F .FUNCT-1K1 i =HIDDENR1 a *REAL-1K4 ?r +REAL-1K3 b *REAL-1K4 ?x"
                  using A24 A27 A37 A34 valued_1_def_1 sorry
                also have "... = a *XCMPLX-0K3 ((a  |^NEWTONK1 l1 *XCMPLX-0K3 (n chooseNEWTONK4 m1))*XCMPLX-0K3 b  |^NEWTONK1 m1) +XCMPLX-0K2 b *REAL-1K4 ?x"
                  using A32 A33 newton_def_4 sorry
                also have "... = (a *XCMPLX-0K3 a  |^NEWTONK1 l1)*XCMPLX-0K3 ((n chooseNEWTONK4 m1)*XCMPLX-0K3 b  |^NEWTONK1 m1) +XCMPLX-0K2 b *REAL-1K4 ?x"
                   sorry
                also have "... = a  |^NEWTONK1 (l1 +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 ((n chooseNEWTONK4 m1)*XCMPLX-0K3 b  |^NEWTONK1 m1) +XCMPLX-0K2 b *REAL-1K4 ?x"
                  using newton_th_6 sorry
                also have "... = a  |^NEWTONK1 (l1 +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 ((n chooseNEWTONK4 m1)*XCMPLX-0K3 b  |^NEWTONK1 m1) +XCMPLX-0K2 b *XCMPLX-0K3 (b  |^NEWTONK1 m2 *XCMPLX-0K3 ((n chooseNEWTONK4 m2)*XCMPLX-0K3 a  |^NEWTONK1 l2))"
                  using A29 A30 newton_def_4 sorry
                also have "... = a  |^NEWTONK1 (l1 +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 ((n chooseNEWTONK4 m1)*XCMPLX-0K3 b  |^NEWTONK1 m1) +XCMPLX-0K2 (b *XCMPLX-0K3 b  |^NEWTONK1 m2)*XCMPLX-0K3 ((n chooseNEWTONK4 m2)*XCMPLX-0K3 a  |^NEWTONK1 l2)"
                   sorry
                also have "... = a  |^NEWTONK1 (l1 +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 ((n chooseNEWTONK4 (m2 +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 b  |^NEWTONK1 (m2 +NAT-1K1 \<one>\<^sub>M)) +XCMPLX-0K2 b  |^NEWTONK1 (m2 +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 ((n chooseNEWTONK4 m2)*XCMPLX-0K3 a  |^NEWTONK1 l2)"
                  using newton_th_6 sorry
                also have "... = ((n chooseNEWTONK4 (m2 +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 n chooseNEWTONK4 m2)*XCMPLX-0K3 a  |^NEWTONK1 (l1 +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 b  |^NEWTONK1 (m2 +NAT-1K1 \<one>\<^sub>M)"
                   sorry
                also have "... = (((n +NAT-1K1 \<one>\<^sub>M)chooseNEWTONK4 (m2 +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 a  |^NEWTONK1 (l1 +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 b  |^NEWTONK1 (m2 +NAT-1K1 \<one>\<^sub>M)"
                  using newton_th_22 sorry
                also have "... = ((a,b)In-PowerNEWTONK5 (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 i"
                  using A9 A35 newton_def_4 sorry
                finally have "?F .FUNCT-1K1 i =HIDDENR1 ((a,b)In-PowerNEWTONK5 (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 i"
                   sorry
                thus "(F1 +RVSUM-1K6\<^bsub>((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)\<^esub> F2).FUNCT-1K1 i =XBOOLE-0R4 ((a,b)In-PowerNEWTONK5 (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 i"
                   sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            have A38: "i inTARSKIR2 {TARSKIK1 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M } implies ?F .FUNCT-1K1 i =XBOOLE-0R4 ((a,b)In-PowerNEWTONK5 (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 i"
            proof-
              have "i inTARSKIR2 {TARSKIK1 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M } implies (F1 +RVSUM-1K6\<^bsub>((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)\<^esub> F2).FUNCT-1K1 i =XBOOLE-0R4 ((a,b)In-PowerNEWTONK5 (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 i"
              proof(rule impI)
                assume A39: "i inTARSKIR2 {TARSKIK1 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M }"
                then have A40: "i =XBOOLE-0R4 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
                  using tarski_def_1 sorry
                have A41: "j =HIDDENR1 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
                  using A39 tarski_def_1 sorry
                also have "... = n +NAT-1K1 \<one>\<^sub>M"
                   sorry
                finally have "j =HIDDENR1 n +NAT-1K1 \<one>\<^sub>M"
                   sorry
                have "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
                  using finseq_1_th_4 sorry
                then have "j inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 ((a,b)In-PowerNEWTONK5 n))"
                  using A41 newton_def_4 sorry
                then have A42: "j inTARSKIR2 domFINSEQ-1K5 ((a,b)In-PowerNEWTONK5 n)"
                  using finseq_1_def_3 sorry
                then have A43: "?x =HIDDENR1 ((a,b)In-PowerNEWTONK5 n).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
                  using A41 partfun1_def_6 sorry
                also have "... = b  |^NEWTONK1 n"
                  using newton_th_29 sorry
                finally have "?x =HIDDENR1 b  |^NEWTONK1 n"
                   sorry
                have A44: "?x =XBOOLE-0R4 ((a,b)In-PowerNEWTONK5 n).FUNCT-1K1 j"
                  using A42 partfun1_def_6 sorry
                have A45: "j inTARSKIR2 domFINSEQ-1K5 (b *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n))"
                  using A42 valued_1_def_5 sorry
                have A46: "?r2 =HIDDENR1 ((<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>)^FINSEQ-1K8 (b *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n))).FUNCT-1K1 ((\<one>\<^sub>M +XCMPLX-0K2 n)+NAT-1K1 \<one>\<^sub>M)"
                  using A13 A40 partfun1_def_6 sorry
                also have "... = ((<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>)^FINSEQ-1K8 (b *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n))).FUNCT-1K1 (lenFINSEQ-1K4 (<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>) +NAT-1K1 j)"
                  using A41 finseq_1_th_39 sorry
                also have "... = (b *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n)).FUNCT-1K1 j"
                  using A45 finseq_1_def_7 sorry
                also have "... = b *XCMPLX-0K3 b  |^NEWTONK1 n"
                  using A44 A43 rvsum_1_th_44 sorry
                also have "... = b  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
                  using newton_th_6 sorry
                finally have "?r2 =HIDDENR1 b  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
                   sorry
                have A47: "?r2 =XBOOLE-0R4 F2 .FUNCT-1K1 i"
                  using A13 partfun1_def_6 sorry
                have "n +NAT-1K1 \<one>\<^sub>M =HIDDENR1 lenFINSEQ-1K4 ((a,b)In-PowerNEWTONK5 n)"
                  using newton_def_4 sorry
                also have "... = lenFINSEQ-1K4 (a *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n))"
                  using newton_th_2 sorry
                finally have "n +NAT-1K1 \<one>\<^sub>M =HIDDENR1 lenFINSEQ-1K4 (a *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n))"
                   sorry
                then have A48: "?r1 =HIDDENR1 ((a *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n))^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>)).FUNCT-1K1 (lenFINSEQ-1K4 (a *RVSUM-1K12 ((a,b)In-PowerNEWTONK5 n)) +NAT-1K1 \<one>\<^sub>M)"
                  using A12 A40 partfun1_def_6 sorry
                also have "... = 0NUMBERSK6"
                  using finseq_1_th_42 sorry
                finally have "?r1 =HIDDENR1 0NUMBERSK6"
                   sorry
                have "?r1 =XBOOLE-0R4 F1 .FUNCT-1K1 i"
                  using A12 partfun1_def_6 sorry
                then have "?F .FUNCT-1K1 i =HIDDENR1 0NUMBERSK6 +XCMPLX-0K2 ?r2"
                  using A48 A47 rvsum_1_th_11 sorry
                also have "... = ((a,b)In-PowerNEWTONK5 (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 i"
                  using A40 A46 newton_th_29 sorry
                finally have "?F .FUNCT-1K1 i =HIDDENR1 ((a,b)In-PowerNEWTONK5 (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 i"
                   sorry
                thus "(F1 +RVSUM-1K6\<^bsub>((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)\<^esub> F2).FUNCT-1K1 i =XBOOLE-0R4 ((a,b)In-PowerNEWTONK5 (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 i"
                   sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            have A49: "i inTARSKIR2 ({TARSKIK1 \<one>\<^sub>M} \\/XBOOLE-0K2 ({k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : \<one>\<^sub>M <XXREAL-0R3 k & k <XXREAL-0R3 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M }))\\/XBOOLE-0K2 {TARSKIK1 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M } implies (F1 +RVSUM-1K6\<^bsub>((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)\<^esub> F2).FUNCT-1K1 i =XBOOLE-0R4 ((a,b)In-PowerNEWTONK5 (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 i"
            proof(rule impI)
              assume "i inTARSKIR2 ({TARSKIK1 \<one>\<^sub>M} \\/XBOOLE-0K2 ({k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : \<one>\<^sub>M <XXREAL-0R3 k & k <XXREAL-0R3 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M }))\\/XBOOLE-0K2 {TARSKIK1 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M }"
              then have "i inTARSKIR2 {TARSKIK1 \<one>\<^sub>M} \\/XBOOLE-0K2 ({k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : \<one>\<^sub>M <XXREAL-0R3 k & k <XXREAL-0R3 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M }) or i inTARSKIR2 {TARSKIK1 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M }"
                using xboole_0_def_3 sorry
              thus "(F1 +RVSUM-1K6\<^bsub>((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)\<^esub> F2).FUNCT-1K1 i =XBOOLE-0R4 ((a,b)In-PowerNEWTONK5 (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 i"
                using A14 A25 A38 xboole_0_def_3 sorry
            qed
            have "domFINSEQ-1K5 ((a,b)In-PowerNEWTONK5 (n +NAT-1K1 \<one>\<^sub>M)) =MEMBEREDR12 SegFINSEQ-1K2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
              using A10 finseq_1_def_3 sorry
            thus "(F1 +RVSUM-1K6\<^bsub>((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)\<^esub> F2).FUNCT-1K1 i =XBOOLE-0R4 ((a,b)In-PowerNEWTONK5 (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 i"
              using A9 A49 newton_th_1 nat_1_th_12 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have "lenFINSEQ-1K4 ((a,b)In-PowerNEWTONK5 (n +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 lenFINSEQ-1K4 ?F"
          using A6 newton_def_4 sorry
        thus "(a +XCMPLX-0K2 b) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 SumRVSUM-1K22 ((a,b)In-PowerNEWTONK5 (n +NAT-1K1 \<one>\<^sub>M))"
          using A2 A4 A8 finseq_2_th_9 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "(a +XCMPLX-0K2 b) |^NEWTONK1 (0NUMBERSK6) =HIDDENR1 SumRVSUM-1K22 (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> InSUBSET-1K10(\<one>\<^sub>M,REALNUMBERSK2) *>)"
      using finsop_1_th_11 rvsum_1_th_94 sorry
    also have "... = SumRVSUM-1K22 ((a,b)In-PowerNEWTONK5 (0NUMBERSK6))"
      using newton_th_27 sorry
    finally have "(a +XCMPLX-0K2 b) |^NEWTONK1 (0NUMBERSK6) =HIDDENR1 SumRVSUM-1K22 ((a,b)In-PowerNEWTONK5 (0NUMBERSK6))"
       sorry
    then have A50: "?P(0NUMBERSK6)"
       sorry
    have " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A50 A1 sorry
    thus "(a +XCMPLX-0K2 b) |^NEWTONK1 s =HIDDENR1 SumRVSUM-1K22 ((a,b)In-PowerNEWTONK5 s)"
      using A0 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef newton_def_5 ("Newton-CoeffNEWTONK6  _ " [164]164 ) where
  mlet "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"func Newton-CoeffNEWTONK6 n \<rightarrow> FinSequenceFINSEQ-1M3-of REALNUMBERSK2 means
  \<lambda>it. lenFINSEQ-1K4 it =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds  for k be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 it & k =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M implies it .FUNCT-1K1 i =XBOOLE-0R4 n chooseNEWTONK3 k)"
proof-
  (*existence*)
    show " ex it be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st lenFINSEQ-1K4 it =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds  for k be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 it & k =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M implies it .FUNCT-1K1 i =XBOOLE-0R4 n chooseNEWTONK3 k)"
    proof-
      have " ex tVar5 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st lenFINSEQ-1K4 tVar5 =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  not ((i inTARSKIR2 domFINSEQ-1K5 tVar5 & k =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M) &  not tVar5 .FUNCT-1K1 i =XBOOLE-0R4 n chooseNEWTONK3 k))"
      proof-
        have 
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
          using ordinal1_def_12 sorry
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds s =HIDDENR1 Lamb1 -XCMPLX-0K6 \<one>\<^sub>M implies Lamb2 =HIDDENR1 n chooseNEWTONK3 s"
        have A1: " for l be NatNAT-1M1 holds l inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies ( ex x be objectHIDDENM1 st ?P(l,x))"
        proof-
          have " for l be NatNAT-1M1 holds l inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies ( ex tVar4 be objectHIDDENM1 st  for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds s =HIDDENR1 l -XCMPLX-0K6 \<one>\<^sub>M implies tVar4 =HIDDENR1 n chooseNEWTONK3 s)"
          proof(rule ballI,rule impI)
            fix l assume [ty]: "l be NatNAT-1M1"
            assume "l inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
            then have "l >=XXREAL-0R2 \<one>\<^sub>M"
              using finseq_1_th_1 sorry
            then obtain k where 
              [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = l -XCMPLX-0K6 \<one>\<^sub>M"
              using int_1_th_5 sorry
            let ?x = "n chooseNEWTONK4 k"
            show " ex tVar4 be objectHIDDENM1 st  for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds s =HIDDENR1 l -XCMPLX-0K6 \<one>\<^sub>M implies tVar4 =HIDDENR1 n chooseNEWTONK3 s"
            proof(rule bexI[of _ "?x"])
              show " for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds s =HIDDENR1 l -XCMPLX-0K6 \<one>\<^sub>M implies n chooseNEWTONK4 k =HIDDENR1 n chooseNEWTONK3 s"
                 sorry
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain F where
          [ty]:"F be FinSequenceFINSEQ-1M1" and 
          A2: "domFINSEQ-1K5 F =MEMBEREDR12 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) & ( for l be NatNAT-1M1 holds l inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies ?P(l,F .FUNCT-1K1 l))"
          using finseq_1_sch_1 A1 sorry
        have "rngFUNCT-1K2 F c=TARSKIR1 REALNUMBERSK2"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 F implies x inHIDDENR3 REALNUMBERSK2"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 F"
            then obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A3: "y inHIDDENR3 domFINSEQ-1K5 F"and A4: "x =HIDDENR1 F .FUNCT-1K1 y"
              using funct_1_def_3 sorry
            have 
              [ty]:"y be ElementSUBSET-1M1-of NATNUMBERSK1"
              using A3 sorry
            have "y >=XXREAL-0R2 \<one>\<^sub>M"
              using A2 A3 finseq_1_th_1 sorry
            then obtain m1 where 
              [ty]:"m1 be ElementSUBSET-1M1-of NATNUMBERSK1" and m1Def:"m1 = y -XCMPLX-0K6 \<one>\<^sub>M"
              using int_1_th_5 sorry
            have "F .FUNCT-1K1 y =XBOOLE-0R4 n chooseNEWTONK4 m1"
              using A2 A3 sorry
            then have 
              [ty]:"x be RealXREAL-0M1"
              using A4 sorry
            have "x inHIDDENR3 REALNUMBERSK2"
              using xreal_0_def_1 sorry
            thus "x inHIDDENR3 REALNUMBERSK2"
               sorry
          qed "sorry"
          thus "rngFUNCT-1K2 F c=TARSKIR1 REALNUMBERSK2"
            using tarski_def_3 sorry
        qed
        then have 
          [ty]:"F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
          using finseq_1_def_4 sorry
        show " ex tVar5 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st lenFINSEQ-1K4 tVar5 =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  not ((i inTARSKIR2 domFINSEQ-1K5 tVar5 & k =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M) &  not tVar5 .FUNCT-1K1 i =XBOOLE-0R4 n chooseNEWTONK3 k))"
        proof(rule bexI[of _ "F"])
          show "lenFINSEQ-1K4 F =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  not ((i inTARSKIR2 domFINSEQ-1K5 F & k =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M) &  not F .FUNCT-1K1 i =XBOOLE-0R4 n chooseNEWTONK3 k))"
            using A2 finseq_1_def_3 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for it2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (lenFINSEQ-1K4 it1 =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds  for k be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 it1 & k =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M implies it1 .FUNCT-1K1 i =XBOOLE-0R4 n chooseNEWTONK3 k)) & (lenFINSEQ-1K4 it2 =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds  for k be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 it2 & k =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M implies it2 .FUNCT-1K1 i =XBOOLE-0R4 n chooseNEWTONK3 k)) implies it1 =HIDDENR1 it2"
    proof-
      have " for G be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for H be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds lenFINSEQ-1K4 G =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds  for m be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 G & m =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M implies G .FUNCT-1K1 i =XBOOLE-0R4 n chooseNEWTONK3 m) implies (lenFINSEQ-1K4 H =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds  for m be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 H & m =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M implies H .FUNCT-1K1 i =XBOOLE-0R4 n chooseNEWTONK3 m) implies G =HIDDENR1 H)"
      proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impMI ,rule impI)
        fix G assume [ty]: "G be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
        fix H assume [ty]: "H be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
        assume A5: "lenFINSEQ-1K4 G =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
          and A6: " for i be NatNAT-1M1 holds  for m be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 G & m =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M implies G .FUNCT-1K1 i =XBOOLE-0R4 n chooseNEWTONK3 m"
        assume A7: "lenFINSEQ-1K4 H =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
          and A8: " for i be NatNAT-1M1 holds  for m be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 H & m =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M implies H .FUNCT-1K1 i =XBOOLE-0R4 n chooseNEWTONK3 m"
        have " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 G implies G .FUNCT-1K1 i =XBOOLE-0R4 H .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be NatNAT-1M1"
          assume A9: "i inTARSKIR2 domFINSEQ-1K5 G"
          then have A10: "i inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
            using A5 finseq_1_def_3 sorry
          then have "i >=XXREAL-0R2 \<one>\<^sub>M"
            using finseq_1_th_1 sorry
          then obtain m where 
            [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and mDef:"m = i -XCMPLX-0K6 \<one>\<^sub>M"
            using int_1_th_5 sorry
          have "i inTARSKIR2 domFINSEQ-1K5 H"
            using A7 A10 finseq_1_def_3 sorry
          then have "H .FUNCT-1K1 i =XBOOLE-0R4 n chooseNEWTONK3 m"
            using A8 sorry
          thus "G .FUNCT-1K1 i =XBOOLE-0R4 H .FUNCT-1K1 i"
            using A6 A9 sorry
        qed "sorry"
        thus "G =HIDDENR1 H"
          using A5 A7 finseq_2_th_9 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem newton_th_31:
" for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds Newton-CoeffNEWTONK6 s =FINSEQ-1R1 (\<one>\<^sub>M,\<one>\<^sub>M)In-PowerNEWTONK5 s"
proof-
  have " for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds Newton-CoeffNEWTONK6 s =FINSEQ-1R1 (\<one>\<^sub>M,\<one>\<^sub>M)In-PowerNEWTONK5 s"
  proof(rule ballI)
    fix s assume [ty]: "s be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have A1: " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 (Newton-CoeffNEWTONK6 s) implies (Newton-CoeffNEWTONK6 s).FUNCT-1K1 i =XBOOLE-0R4 ((\<one>\<^sub>M,\<one>\<^sub>M)In-PowerNEWTONK5 s).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be NatNAT-1M1"
      assume A2: "i inTARSKIR2 domFINSEQ-1K5 (Newton-CoeffNEWTONK6 s)"
      have A3: "domFINSEQ-1K5 (Newton-CoeffNEWTONK6 s) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 (Newton-CoeffNEWTONK6 s))"
        using finseq_1_def_3 sorry
      also have "... = SegFINSEQ-1K2 (s +NAT-1K1 \<one>\<^sub>M)"
        using newton_def_5 sorry
      finally have "domFINSEQ-1K5 (Newton-CoeffNEWTONK6 s) =HIDDENR1 SegFINSEQ-1K2 (s +NAT-1K1 \<one>\<^sub>M)"
         sorry
      then have "i >=XXREAL-0R2 \<one>\<^sub>M"
        using A2 finseq_1_th_1 sorry
      then obtain m1 where 
        [ty]:"m1 be ElementSUBSET-1M1-of NATNUMBERSK1" and m1Def:"m1 = i -XCMPLX-0K6 \<one>\<^sub>M"
        using int_1_th_5 sorry
      have "i <=XXREAL-0R1 s +NAT-1K1 \<one>\<^sub>M"
        using A2 A3 finseq_1_th_1 sorry
      then have "(s +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 i -XCMPLX-0K6 \<one>\<^sub>M"
        using xreal_1_th_9 sorry
      then obtain l1 where 
        [ty]:"l1 be ElementSUBSET-1M1-of NATNUMBERSK1" and l1Def:"l1 = s -XCMPLX-0K6 m1"
        using int_1_th_5 sorry
      have "domFINSEQ-1K5 (Newton-CoeffNEWTONK6 s) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 ((\<one>\<^sub>M,\<one>\<^sub>M)In-PowerNEWTONK5 s))"
        using A3 newton_def_4 sorry
      also have "... = domFINSEQ-1K5 ((\<one>\<^sub>M,\<one>\<^sub>M)In-PowerNEWTONK5 s)"
        using finseq_1_def_3 sorry
      finally have "domFINSEQ-1K5 (Newton-CoeffNEWTONK6 s) =HIDDENR1 domFINSEQ-1K5 ((\<one>\<^sub>M,\<one>\<^sub>M)In-PowerNEWTONK5 s)"
         sorry
      then have "((\<one>\<^sub>M,\<one>\<^sub>M)In-PowerNEWTONK5 s).FUNCT-1K1 i =HIDDENR1 ((s chooseNEWTONK3 m1)*XCMPLX-0K3 \<one>\<^sub>M  |^NEWTONK1 l1)*XCMPLX-0K3 \<one>\<^sub>M  |^NEWTONK1 m1"
        using A2 newton_def_4 sorry
      also have "... = (Newton-CoeffNEWTONK6 s).FUNCT-1K1 i"
        using A2 newton_def_5 sorry
      finally have "((\<one>\<^sub>M,\<one>\<^sub>M)In-PowerNEWTONK5 s).FUNCT-1K1 i =HIDDENR1 (Newton-CoeffNEWTONK6 s).FUNCT-1K1 i"
         sorry
      thus "(Newton-CoeffNEWTONK6 s).FUNCT-1K1 i =XBOOLE-0R4 ((\<one>\<^sub>M,\<one>\<^sub>M)In-PowerNEWTONK5 s).FUNCT-1K1 i"
         sorry
    qed "sorry"
    have "lenFINSEQ-1K4 (Newton-CoeffNEWTONK6 s) =HIDDENR1 s +NAT-1K1 \<one>\<^sub>M"
      using newton_def_5 sorry
    also have "... = lenFINSEQ-1K4 ((\<one>\<^sub>M,\<one>\<^sub>M)In-PowerNEWTONK5 s)"
      using newton_def_4 sorry
    finally have "lenFINSEQ-1K4 (Newton-CoeffNEWTONK6 s) =HIDDENR1 lenFINSEQ-1K4 ((\<one>\<^sub>M,\<one>\<^sub>M)In-PowerNEWTONK5 s)"
       sorry
    thus "Newton-CoeffNEWTONK6 s =FINSEQ-1R1 (\<one>\<^sub>M,\<one>\<^sub>M)In-PowerNEWTONK5 s"
      using A1 finseq_2_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_32:
" for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds \<two>\<^sub>M  |^NEWTONK1 s =HIDDENR1 SumRVSUM-1K22 (Newton-CoeffNEWTONK6 s)"
proof-
  have " for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds \<two>\<^sub>M  |^NEWTONK1 s =HIDDENR1 SumRVSUM-1K22 (Newton-CoeffNEWTONK6 s)"
  proof(rule ballI)
    fix s assume [ty]: "s be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have "\<two>\<^sub>M  |^NEWTONK1 s =HIDDENR1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) |^NEWTONK1 s"
       sorry
    also have "... = SumRVSUM-1K22 ((\<one>\<^sub>M,\<one>\<^sub>M)In-PowerNEWTONK5 s)"
      using newton_th_30 sorry
    also have "... = SumRVSUM-1K22 (Newton-CoeffNEWTONK6 s)"
      using newton_th_31 sorry
    finally have "\<two>\<^sub>M  |^NEWTONK1 s =HIDDENR1 SumRVSUM-1K22 (Newton-CoeffNEWTONK6 s)"
       sorry
    thus "\<two>\<^sub>M  |^NEWTONK1 s =HIDDENR1 SumRVSUM-1K22 (Newton-CoeffNEWTONK6 s)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem newton_th_33:
" for k be NatNAT-1M1 holds  for l be NatNAT-1M1 holds l >=XXREAL-0R2 \<one>\<^sub>M implies k *XCMPLX-0K3 l >=XXREAL-0R2 k"
proof-
  have " for k be NatNAT-1M1 holds  for l be NatNAT-1M1 holds l >=XXREAL-0R2 \<one>\<^sub>M implies k *XCMPLX-0K3 l >=XXREAL-0R2 k"
  proof(rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix l assume [ty]: "l be NatNAT-1M1"
    assume A1: "l >=XXREAL-0R2 \<one>\<^sub>M"
    have " for k be NatNAT-1M1 holds k *XCMPLX-0K3 l >=XXREAL-0R2 k"
    proof-
      let ?P = "\<lambda>Lamb1. Lamb1 *XCMPLX-0K3 l >=XXREAL-0R2 Lamb1"
      have A2: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
      proof-
        have " for k be NatNAT-1M1 holds k *XCMPLX-0K3 l >=XXREAL-0R2 k implies (k +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 l >=XXREAL-0R2 k +NAT-1K1 \<one>\<^sub>M"
        proof(rule ballI,rule impI)
          fix k assume [ty]: "k be NatNAT-1M1"
          have A3: "(k +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 l =XBOOLE-0R4 k *XCMPLX-0K3 l +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 l"
             sorry
          have A4: "k +XCMPLX-0K2 l >=XXREAL-0R2 k +NAT-1K1 \<one>\<^sub>M"
            using A1 xreal_1_th_7 sorry
          assume "k *XCMPLX-0K3 l >=XXREAL-0R2 k"
          then have "(k +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 l >=XXREAL-0R2 k +XCMPLX-0K2 l"
            using A3 xreal_1_th_7 sorry
          thus "(k +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 l >=XXREAL-0R2 k +NAT-1K1 \<one>\<^sub>M"
            using A4 xxreal_0_th_2 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have A5: "?P(0NUMBERSK6)"
         sorry
      show " for k be NatNAT-1M1 holds k *XCMPLX-0K3 l >=XXREAL-0R2 k"
        using nat_1_sch_2 A5 A2 sorry
    qed
    thus "k *XCMPLX-0K3 l >=XXREAL-0R2 k"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_34:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for l be NatNAT-1M1 holds l >=XXREAL-0R2 \<one>\<^sub>M & n >=XXREAL-0R2 k *XCMPLX-0K3 l implies n >=XXREAL-0R2 k"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for l be NatNAT-1M1 holds l >=XXREAL-0R2 \<one>\<^sub>M & n >=XXREAL-0R2 k *XCMPLX-0K3 l implies n >=XXREAL-0R2 k"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix l assume [ty]: "l be NatNAT-1M1"
    assume A1: "l >=XXREAL-0R2 \<one>\<^sub>M"
      and A2: "n >=XXREAL-0R2 k *XCMPLX-0K3 l"
    have "k *XCMPLX-0K3 l >=XXREAL-0R2 k"
      using A1 newton_th_33 sorry
    thus "n >=XXREAL-0R2 k"
      using A2 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) NEWTONK7(" _ !NEWTONK7" [164]164) where
  "n !NEWTONK7 \<equiv> n !NEWTONK2"

mtheorem newton_add_2:
  mlet "n be NatNAT-1M1"
"cluster n !NEWTONK2 as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "n !NEWTONK2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    using newton_th_16 sorry
qed "sorry"

mtheorem newton_th_35:
" for l be NatNAT-1M1 holds l <>HIDDENR2 0NUMBERSK6 implies l dividesNAT-DR1 l !NEWTONK7"
proof-
  have " for l be NatNAT-1M1 holds l <>HIDDENR2 0NUMBERSK6 implies l dividesNAT-DR1 l !NEWTONK7"
  proof(rule ballI,rule impI)
    fix l assume [ty]: "l be NatNAT-1M1"
    assume "l <>HIDDENR2 0NUMBERSK6"
    then obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A1: "l =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_6 sorry
    have 
      [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    have "(n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7 =XBOOLE-0R4 (n +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 (n !NEWTONK7)"
      using newton_th_15 sorry
    thus "l dividesNAT-DR1 l !NEWTONK7"
      using A1 nat_d_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_36:
" for n be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 implies (n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 n >XXREAL-0R4 \<one>\<^sub>M"
proof-
  have " for n be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 implies  not (n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 n >XXREAL-0R4 \<one>\<^sub>M"
  proof(rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "n <>HIDDENR2 0NUMBERSK6"
    have "(n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 n =HIDDENR1 n /XCMPLX-0K7 n +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n"
      using xcmplx_1_th_62 sorry
    also have "... = \<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n"
      using A1 xcmplx_1_th_60 sorry
    finally have "(n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 n =HIDDENR1 \<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n"
       sorry
    thus " not (n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 n >XXREAL-0R4 \<one>\<^sub>M"
      using A1 xreal_1_th_29 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_37:
" for k be NatNAT-1M1 holds k /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 \<one>\<^sub>M"
proof-
  have " for k be NatNAT-1M1 holds  not k /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 \<one>\<^sub>M"
  proof(rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    have " for m be NatNAT-1M1 holds m <XXREAL-0R3 m +NAT-1K1 \<one>\<^sub>M"
      using xreal_1_th_29 sorry
    thus " not k /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 \<one>\<^sub>M"
      using xreal_1_th_189 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_38:
" for l be NatNAT-1M1 holds l !NEWTONK7 >=XXREAL-0R2 l"
proof-
  have " for l be NatNAT-1M1 holds l !NEWTONK7 >=XXREAL-0R2 l"
  proof(rule ballI)
    fix l assume [ty]: "l be NatNAT-1M1"
    let ?P = "\<lambda>Lamb1. Lamb1 !NEWTONK7 >=XXREAL-0R2 Lamb1"
    have A1: " for l be NatNAT-1M1 holds ?P(l) implies ?P(l +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for l be NatNAT-1M1 holds l !NEWTONK7 >=XXREAL-0R2 l implies (l +NAT-1K1 \<one>\<^sub>M)!NEWTONK7 >=XXREAL-0R2 l +NAT-1K1 \<one>\<^sub>M"
      proof(rule ballI,rule impI)
        fix l assume [ty]: "l be NatNAT-1M1"
        assume A2: "l !NEWTONK7 >=XXREAL-0R2 l"
        have A3: "(l !NEWTONK7)*NAT-1K2 (l +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 (l +NAT-1K1 \<one>\<^sub>M)!NEWTONK7"
          using newton_th_15 sorry
        have "l =XBOOLE-0R4 0NUMBERSK6 & (l +NAT-1K1 \<one>\<^sub>M)!NEWTONK7 >=XXREAL-0R2 l +NAT-1K1 \<one>\<^sub>M or l >=XXREAL-0R2 \<one>\<^sub>M & (l +NAT-1K1 \<one>\<^sub>M)!NEWTONK7 >=XXREAL-0R2 l +NAT-1K1 \<one>\<^sub>M"
        proof-
          have "l =XBOOLE-0R4 0NUMBERSK6 & (l +NAT-1K1 \<one>\<^sub>M)!NEWTONK7 >=XXREAL-0R2 l +NAT-1K1 \<one>\<^sub>M or l >=XXREAL-0R2 \<one>\<^sub>M & (l >=XXREAL-0R2 \<one>\<^sub>M implies (l +NAT-1K1 \<one>\<^sub>M)!NEWTONK7 >=XXREAL-0R2 l +NAT-1K1 \<one>\<^sub>M)"
          proof-
            show "l =XBOOLE-0R4 0NUMBERSK6 & (l +NAT-1K1 \<one>\<^sub>M)!NEWTONK7 >=XXREAL-0R2 l +NAT-1K1 \<one>\<^sub>M or l >=XXREAL-0R2 \<one>\<^sub>M & (l >=XXREAL-0R2 \<one>\<^sub>M implies (l +NAT-1K1 \<one>\<^sub>M)!NEWTONK7 >=XXREAL-0R2 l +NAT-1K1 \<one>\<^sub>M)"
            proof-
              have cases: "l =XBOOLE-0R4 0NUMBERSK6 or l >=XXREAL-0R2 \<one>\<^sub>M"
                using nat_1_th_14 sorry
              have case1: "l =XBOOLE-0R4 0NUMBERSK6 implies (l +NAT-1K1 \<one>\<^sub>M)!NEWTONK7 >=XXREAL-0R2 l +NAT-1K1 \<one>\<^sub>M"
              proof(rule impI)
                assume "l =XBOOLE-0R4 0NUMBERSK6"
                thus "(l +NAT-1K1 \<one>\<^sub>M)!NEWTONK7 >=XXREAL-0R2 l +NAT-1K1 \<one>\<^sub>M"
                  using finseq_2_th_50 rvsum_1_th_95 sorry
              qed
              have case2: "l >=XXREAL-0R2 \<one>\<^sub>M implies (l +NAT-1K1 \<one>\<^sub>M)!NEWTONK7 >=XXREAL-0R2 l +NAT-1K1 \<one>\<^sub>M"
              proof(rule impI)
                assume A4: "l >=XXREAL-0R2 \<one>\<^sub>M"
                have "(l +NAT-1K1 \<one>\<^sub>M)!NEWTONK7 >=XXREAL-0R2 (l +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 l"
                  using A2 A3 xreal_1_th_64 sorry
                thus "(l +NAT-1K1 \<one>\<^sub>M)!NEWTONK7 >=XXREAL-0R2 l +NAT-1K1 \<one>\<^sub>M"
                  using A4 newton_th_34 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus " ?thesis "
             sorry
        qed
        thus "(l +NAT-1K1 \<one>\<^sub>M)!NEWTONK7 >=XXREAL-0R2 l +NAT-1K1 \<one>\<^sub>M"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A5: "?P(0NUMBERSK6)"
       sorry
    have " for l be NatNAT-1M1 holds ?P(l)"
      using nat_1_sch_2 A5 A1 sorry
    thus "l !NEWTONK7 >=XXREAL-0R2 l"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_39:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m <>HIDDENR2 \<one>\<^sub>M & m dividesNAT-DR1 n implies  not m dividesNAT-DR1 n +NAT-1K1 \<one>\<^sub>M"
proof-
  have " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m <>HIDDENR2 \<one>\<^sub>M & (m dividesNAT-DR1 n & m dividesNAT-DR1 n +NAT-1K1 \<one>\<^sub>M) implies  False "
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    assume A1: "m <>HIDDENR2 \<one>\<^sub>M"
      and A2: "m dividesNAT-DR1 n"
      and A3: "m dividesNAT-DR1 n +NAT-1K1 \<one>\<^sub>M"
    obtain t where
      [ty]:"t be NatNAT-1M1" and 
      A4: "n =XBOOLE-0R4 m *XCMPLX-0K3 t"
      using A2 nat_d_def_3 sorry
    obtain s where
      [ty]:"s be NatNAT-1M1" and 
      A5: "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 m *XCMPLX-0K3 s"
      using A3 nat_d_def_3 sorry
    have "t <=XXREAL-0R1 s"
    proof-
      have "t >XXREAL-0R4 s implies  False "
      proof(rule impI)
        have "(n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 t =HIDDENR1 (m *XCMPLX-0K3 s)*XCMPLX-0K3 t"
          using A5 sorry
        also have "... = n *XCMPLX-0K3 s"
          using A4 sorry
        finally have "(n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 t =HIDDENR1 n *XCMPLX-0K3 s"
           sorry
        then have A6: "t =HIDDENR1 (n *XCMPLX-0K3 s)/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
          using xcmplx_1_th_89 sorry
        also have "... = s *XCMPLX-0K3 (n /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))"
          using xcmplx_1_th_74 sorry
        finally have "t =HIDDENR1 s *XCMPLX-0K3 (n /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))"
           sorry
        assume A7: "t >XXREAL-0R4 s"
        have "s >XXREAL-0R4 0NUMBERSK6"
          using A5 sorry
        thus " False "
          using A7 A6 newton_th_37 xreal_1_th_157 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    then obtain r where 
      [ty]:"r be ElementSUBSET-1M1-of NATNUMBERSK1" and rDef:"r = s -XCMPLX-0K6 t"
      using int_1_th_5 sorry
    have "\<one>\<^sub>M =XBOOLE-0R4 m *XCMPLX-0K3 s -XCMPLX-0K6 m *XCMPLX-0K3 t"
      using A4 A5 sorry
    then have "\<one>\<^sub>M =XBOOLE-0R4 m *XCMPLX-0K3 r"
       sorry
    thus " False "
      using A1 nat_1_th_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_40:
" for j be NatNAT-1M1 holds  for k be NatNAT-1M1 holds j <>HIDDENR2 0NUMBERSK6 implies j dividesNAT-DR1 (j +XCMPLX-0K2 k)!NEWTONK7"
proof-
  have " for j be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  not ( not j <>HIDDENR2 0NUMBERSK6 &  not j dividesNAT-DR1 (j +XCMPLX-0K2 k)!NEWTONK7)"
  proof(rule ballI,rule ballI)
    fix j assume [ty]: "j be NatNAT-1M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    let ?P = "\<lambda>Lamb1.  for j be NatNAT-1M1 holds j <>HIDDENR2 0NUMBERSK6 implies j dividesNAT-DR1 (j +XCMPLX-0K2 Lamb1)!NEWTONK7"
    have A1: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds ( for j be NatNAT-1M1 holds j <>HIDDENR2 0NUMBERSK6 implies j dividesNAT-DR1 (j +XCMPLX-0K2 k)!NEWTONK7) implies ( for j be NatNAT-1M1 holds j <>HIDDENR2 0NUMBERSK6 implies j dividesNAT-DR1 (j +XCMPLX-0K2 (k +NAT-1K1 \<one>\<^sub>M))!NEWTONK7)"
      proof(rule ballI,rule impI,rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A2: " for j be NatNAT-1M1 holds j <>HIDDENR2 0NUMBERSK6 implies j dividesNAT-DR1 (j +XCMPLX-0K2 k)!NEWTONK7"
        fix j assume [ty]: "j be NatNAT-1M1"
        assume "j <>HIDDENR2 0NUMBERSK6"
        then have "j dividesNAT-DR1 ((j +XCMPLX-0K2 k)!NEWTONK7)*NAT-1K2 ((j +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M)"
          using A2 nat_d_th_9 sorry
        thus "j dividesNAT-DR1 (j +XCMPLX-0K2 (k +NAT-1K1 \<one>\<^sub>M))!NEWTONK7"
          using newton_th_15 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A3: "?P(0NUMBERSK6)"
      using newton_th_35 sorry
    have " for k be NatNAT-1M1 holds ?P(k)"
      using nat_1_sch_2 A3 A1 sorry
    thus " not ( not j <>HIDDENR2 0NUMBERSK6 &  not j dividesNAT-DR1 (j +XCMPLX-0K2 k)!NEWTONK7)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_41:
" for j be NatNAT-1M1 holds  for l be NatNAT-1M1 holds j <=XXREAL-0R1 l & j <>HIDDENR2 0NUMBERSK6 implies j dividesNAT-DR1 l !NEWTONK7"
proof-
  have " for j be NatNAT-1M1 holds  for l be NatNAT-1M1 holds j <=XXREAL-0R1 l & j <>HIDDENR2 0NUMBERSK6 implies j dividesNAT-DR1 l !NEWTONK7"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix j assume [ty]: "j be NatNAT-1M1"
    fix l assume [ty]: "l be NatNAT-1M1"
    assume A1: "j <=XXREAL-0R1 l"
      and A2: "j <>HIDDENR2 0NUMBERSK6"
    have " ex k be NatNAT-1M1 st l =XBOOLE-0R4 j +XCMPLX-0K2 k"
      using A1 nat_1_th_10 sorry
    thus "j dividesNAT-DR1 l !NEWTONK7"
      using A2 newton_th_40 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_42:
" for j be NatNAT-1M1 holds  for l be NatNAT-1M1 holds (j <>HIDDENR2 \<one>\<^sub>M & j <>HIDDENR2 0NUMBERSK6) & j dividesNAT-DR1 l !NEWTONK7 +NAT-1K1 \<one>\<^sub>M implies j >XXREAL-0R4 l"
  using newton_th_39 newton_th_41 sorry

mtheorem newton_th_43:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m lcmNAT-DK6 (n lcmNAT-DK6 k) =XBOOLE-0R4 (m lcmNAT-DK6 n)lcmNAT-DK6 k"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m lcmNAT-DK6 (n lcmNAT-DK6 k) =XBOOLE-0R4 (m lcmNAT-DK6 n)lcmNAT-DK6 k"
  proof(rule ballI,rule ballI,rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    let ?M = "n lcmNAT-DK6 k"
    let ?K = "m lcmNAT-DK6 ?M"
    let ?N = "m lcmNAT-DK6 n"
    let ?L = "?N lcmNAT-DK6 k"
    have A1: "m dividesNAT-DR1 ?K"
      using nat_d_def_4 sorry
    have A2: "?M dividesNAT-DR1 ?K"
      using nat_d_def_4 sorry
    have "n dividesNAT-DR1 ?M"
      using nat_d_def_4 sorry
    then have "n dividesNAT-DR1 ?K"
      using A2 nat_d_th_4 sorry
    then have A3: "?N dividesNAT-DR1 ?K"
      using A1 nat_d_def_4 sorry
    have "k dividesNAT-DR1 ?M"
      using nat_d_def_4 sorry
    then have "k dividesNAT-DR1 ?K"
      using A2 nat_d_th_4 sorry
    then have A4: "?L dividesNAT-DR1 ?K"
      using A3 nat_d_def_4 sorry
    have A5: "?N dividesNAT-DR1 ?L"
      using nat_d_def_4 sorry
    have A6: "k dividesNAT-DR1 ?L"
      using nat_d_def_4 sorry
    have "n dividesNAT-DR1 ?N"
      using nat_d_def_4 sorry
    then have "n dividesNAT-DR1 ?L"
      using A5 nat_d_th_4 sorry
    then have A7: "?M dividesNAT-DR1 ?L"
      using A6 nat_d_def_4 sorry
    have "m dividesNAT-DR1 ?N"
      using nat_d_def_4 sorry
    then have "m dividesNAT-DR1 ?L"
      using A5 nat_d_th_4 sorry
    then have "?K dividesNAT-DR1 ?L"
      using A7 nat_d_def_4 sorry
    thus "m lcmNAT-DK6 (n lcmNAT-DK6 k) =XBOOLE-0R4 (m lcmNAT-DK6 n)lcmNAT-DK6 k"
      using A4 nat_d_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_44:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m dividesNAT-DR1 n iff m lcmNAT-DK6 n =XBOOLE-0R4 n"
proof-
  have " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (m dividesNAT-DR1 n implies m lcmNAT-DK6 n =XBOOLE-0R4 n) &  not (m lcmNAT-DK6 n =XBOOLE-0R4 n &  not m dividesNAT-DR1 n)"
  proof(rule ballI,rule ballI,rule conjMI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    show "m dividesNAT-DR1 n implies m lcmNAT-DK6 n =XBOOLE-0R4 n"
    proof(rule impI)
      let ?M = "m lcmNAT-DK6 n"
      assume "m dividesNAT-DR1 n"
      then have A1: "?M dividesNAT-DR1 n"
        using nat_d_def_4 sorry
      have "n dividesNAT-DR1 ?M"
        using nat_d_def_4 sorry
      thus "m lcmNAT-DK6 n =XBOOLE-0R4 n"
        using A1 nat_d_th_5 sorry
    qed
    show " not (m lcmNAT-DK6 n =XBOOLE-0R4 n &  not m dividesNAT-DR1 n)"
      using nat_d_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_45:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n dividesNAT-DR1 m & k dividesNAT-DR1 m iff n lcmNAT-DK6 k dividesNAT-DR1 m"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  not ((n dividesNAT-DR1 m & k dividesNAT-DR1 m) &  not n lcmNAT-DK6 k dividesNAT-DR1 m) &  not (n lcmNAT-DK6 k dividesNAT-DR1 m &  not (n dividesNAT-DR1 m & k dividesNAT-DR1 m))"
  proof(rule ballI,rule ballI,rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    have "n lcmNAT-DK6 k dividesNAT-DR1 m implies n dividesNAT-DR1 m & k dividesNAT-DR1 m"
    proof(rule impI)
      let ?M = "n lcmNAT-DK6 k"
      have A1: "n dividesNAT-DR1 ?M"
        using nat_d_def_4 sorry
      have A2: "k dividesNAT-DR1 ?M"
        using nat_d_def_4 sorry
      assume "n lcmNAT-DK6 k dividesNAT-DR1 m"
      thus "n dividesNAT-DR1 m & k dividesNAT-DR1 m"
        using A1 A2 nat_d_th_4 sorry
    qed
    thus " not ((n dividesNAT-DR1 m & k dividesNAT-DR1 m) &  not n lcmNAT-DK6 k dividesNAT-DR1 m) &  not (n lcmNAT-DK6 k dividesNAT-DR1 m &  not (n dividesNAT-DR1 m & k dividesNAT-DR1 m))"
      using nat_d_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_46:
" for m be NatNAT-1M1 holds m lcmNAT-DK6 \<one>\<^sub>M =XBOOLE-0R4 m"
proof-
  have " for m be NatNAT-1M1 holds m lcmNAT-DK6 \<one>\<^sub>M =XBOOLE-0R4 m"
  proof(rule ballI)
    fix m assume [ty]: "m be NatNAT-1M1"
    let ?M = "m lcmNAT-DK6 \<one>\<^sub>M"
    have "\<one>\<^sub>M dividesNAT-DR1 m"
      using nat_d_th_6 sorry
    then have A1: "?M dividesNAT-DR1 m"
      using nat_d_def_4 sorry
    have "m dividesNAT-DR1 ?M"
      using nat_d_def_4 sorry
    thus "m lcmNAT-DK6 \<one>\<^sub>M =XBOOLE-0R4 m"
      using A1 nat_d_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_47:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m lcmNAT-DK6 n dividesNAT-DR1 m *XCMPLX-0K3 n"
proof-
  have " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m lcmNAT-DK6 n dividesNAT-DR1 m *XCMPLX-0K3 n"
  proof(rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    let ?s = "m *XCMPLX-0K3 n"
    have A1: "n dividesNAT-DR1 ?s"
      using nat_d_th_9 sorry
    have "m dividesNAT-DR1 ?s"
      using nat_d_th_9 sorry
    thus "m lcmNAT-DK6 n dividesNAT-DR1 m *XCMPLX-0K3 n"
      using A1 nat_d_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_48:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m gcdNAT-DK8 (n gcdNAT-DK8 k) =XBOOLE-0R4 (m gcdNAT-DK8 n)gcdNAT-DK8 k"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m gcdNAT-DK8 (n gcdNAT-DK8 k) =XBOOLE-0R4 (m gcdNAT-DK8 n)gcdNAT-DK8 k"
  proof(rule ballI,rule ballI,rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    let ?M = "n gcdNAT-DK8 k"
    let ?K = "m gcdNAT-DK8 ?M"
    let ?N = "m gcdNAT-DK8 n"
    let ?L = "?N gcdNAT-DK8 k"
    have A1: "?K dividesNAT-DR1 ?M"
      using nat_d_def_5 sorry
    have A2: "?K dividesNAT-DR1 m"
      using nat_d_def_5 sorry
    have "?M dividesNAT-DR1 n"
      using nat_d_def_5 sorry
    then have "?K dividesNAT-DR1 n"
      using A1 nat_d_th_4 sorry
    then have A3: "?K dividesNAT-DR1 ?N"
      using A2 nat_d_def_5 sorry
    have A4: "?L dividesNAT-DR1 ?N"
      using nat_d_def_5 sorry
    have A5: "?L dividesNAT-DR1 k"
      using nat_d_def_5 sorry
    have "?N dividesNAT-DR1 n"
      using nat_d_def_5 sorry
    then have "?L dividesNAT-DR1 n"
      using A4 nat_d_th_4 sorry
    then have A6: "?L dividesNAT-DR1 ?M"
      using A5 nat_d_def_5 sorry
    have "?N dividesNAT-DR1 m"
      using nat_d_def_5 sorry
    then have "?L dividesNAT-DR1 m"
      using A4 nat_d_th_4 sorry
    then have A7: "?L dividesNAT-DR1 ?K"
      using A6 nat_d_def_5 sorry
    have "?M dividesNAT-DR1 k"
      using nat_d_def_5 sorry
    then have "?K dividesNAT-DR1 k"
      using A1 nat_d_th_4 sorry
    then have "?K dividesNAT-DR1 ?L"
      using A3 nat_d_def_5 sorry
    thus "m gcdNAT-DK8 (n gcdNAT-DK8 k) =XBOOLE-0R4 (m gcdNAT-DK8 n)gcdNAT-DK8 k"
      using A7 nat_d_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_49:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n dividesNAT-DR1 m implies n gcdNAT-DK8 m =XBOOLE-0R4 n"
proof-
  have " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n dividesNAT-DR1 m implies n gcdNAT-DK8 m =XBOOLE-0R4 n"
  proof(rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    let ?N = "n gcdNAT-DK8 m"
    assume "n dividesNAT-DR1 m"
    then have A1: "n dividesNAT-DR1 ?N"
      using nat_d_def_5 sorry
    have "?N dividesNAT-DR1 n"
      using nat_d_def_5 sorry
    thus "n gcdNAT-DK8 m =XBOOLE-0R4 n"
      using A1 nat_d_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_50:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m dividesNAT-DR1 n & m dividesNAT-DR1 k iff m dividesNAT-DR1 n gcdNAT-DK8 k"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  not ((m dividesNAT-DR1 n & m dividesNAT-DR1 k) &  not m dividesNAT-DR1 n gcdNAT-DK8 k) &  not (m dividesNAT-DR1 n gcdNAT-DK8 k &  not (m dividesNAT-DR1 n & m dividesNAT-DR1 k))"
  proof(rule ballI,rule ballI,rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    have "m dividesNAT-DR1 n gcdNAT-DK8 k implies m dividesNAT-DR1 n & m dividesNAT-DR1 k"
    proof(rule impI)
      let ?M = "n gcdNAT-DK8 k"
      have A1: "?M dividesNAT-DR1 n"
        using nat_d_def_5 sorry
      have A2: "?M dividesNAT-DR1 k"
        using nat_d_def_5 sorry
      assume "m dividesNAT-DR1 n gcdNAT-DK8 k"
      thus "m dividesNAT-DR1 n & m dividesNAT-DR1 k"
        using A1 A2 nat_d_th_4 sorry
    qed
    thus " not ((m dividesNAT-DR1 n & m dividesNAT-DR1 k) &  not m dividesNAT-DR1 n gcdNAT-DK8 k) &  not (m dividesNAT-DR1 n gcdNAT-DK8 k &  not (m dividesNAT-DR1 n & m dividesNAT-DR1 k))"
      using nat_d_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_51:
" for m be NatNAT-1M1 holds m gcdNAT-DK8 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for m be NatNAT-1M1 holds m gcdNAT-DK8 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
  proof(rule ballI)
    fix m assume [ty]: "m be NatNAT-1M1"
    let ?M = "m gcdNAT-DK8 \<one>\<^sub>M"
    have A1: "\<one>\<^sub>M dividesNAT-DR1 ?M"
      using nat_d_th_6 sorry
    have "?M dividesNAT-DR1 \<one>\<^sub>M"
      using nat_d_def_5 sorry
    thus "m gcdNAT-DK8 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
      using A1 nat_d_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_52:
" for m be NatNAT-1M1 holds m gcdNAT-DK8 0NUMBERSK6 =XBOOLE-0R4 m"
proof-
  have " for m be NatNAT-1M1 holds m gcdNAT-DK8 0NUMBERSK6 =XBOOLE-0R4 m"
  proof(rule ballI)
    fix m assume [ty]: "m be NatNAT-1M1"
    let ?M = "m gcdNAT-DK8 0NUMBERSK6"
    have "m dividesNAT-DR1 0NUMBERSK6"
      using nat_d_th_6 sorry
    then have A1: "m dividesNAT-DR1 ?M"
      using nat_d_def_5 sorry
    have "?M dividesNAT-DR1 m"
      using nat_d_def_5 sorry
    thus "m gcdNAT-DK8 0NUMBERSK6 =XBOOLE-0R4 m"
      using A1 nat_d_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_53:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (m gcdNAT-DK8 n)lcmNAT-DK6 n =XBOOLE-0R4 n"
proof-
  have " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (m gcdNAT-DK8 n)lcmNAT-DK6 n =XBOOLE-0R4 n"
  proof(rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    let ?M = "m gcdNAT-DK8 n"
    have "?M dividesNAT-DR1 n"
      using nat_d_def_5 sorry
    thus "(m gcdNAT-DK8 n)lcmNAT-DK6 n =XBOOLE-0R4 n"
      using newton_th_44 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_54:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m gcdNAT-DK8 (m lcmNAT-DK6 n) =XBOOLE-0R4 m"
proof-
  have " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m gcdNAT-DK8 (m lcmNAT-DK6 n) =XBOOLE-0R4 m"
  proof(rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    let ?M = "m lcmNAT-DK6 n"
    have "m dividesNAT-DR1 ?M"
      using nat_d_def_4 sorry
    thus "m gcdNAT-DK8 (m lcmNAT-DK6 n) =XBOOLE-0R4 m"
      using newton_th_49 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_55:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m gcdNAT-DK8 (m lcmNAT-DK6 n) =XBOOLE-0R4 (n gcdNAT-DK8 m)lcmNAT-DK6 m"
proof-
  have " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m gcdNAT-DK8 (m lcmNAT-DK6 n) =XBOOLE-0R4 (n gcdNAT-DK8 m)lcmNAT-DK6 m"
  proof(rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    have "m gcdNAT-DK8 (m lcmNAT-DK6 n) =XBOOLE-0R4 m"
      using newton_th_54 sorry
    thus "m gcdNAT-DK8 (m lcmNAT-DK6 n) =XBOOLE-0R4 (n gcdNAT-DK8 m)lcmNAT-DK6 m"
      using newton_th_53 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_56:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m dividesNAT-DR1 n implies m gcdNAT-DK8 k dividesNAT-DR1 n gcdNAT-DK8 k"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m dividesNAT-DR1 n implies m gcdNAT-DK8 k dividesNAT-DR1 n gcdNAT-DK8 k"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    let ?M = "m gcdNAT-DK8 k"
    have A1: "?M dividesNAT-DR1 k"
      using nat_d_def_5 sorry
    assume A2: "m dividesNAT-DR1 n"
    have "?M dividesNAT-DR1 m"
      using nat_d_def_5 sorry
    then have "?M dividesNAT-DR1 n"
      using A2 nat_d_th_4 sorry
    thus "m gcdNAT-DK8 k dividesNAT-DR1 n gcdNAT-DK8 k"
      using A1 nat_d_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_57:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m dividesNAT-DR1 n implies k gcdNAT-DK8 m dividesNAT-DR1 k gcdNAT-DK8 n"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m dividesNAT-DR1 n implies k gcdNAT-DK8 m dividesNAT-DR1 k gcdNAT-DK8 n"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    let ?M = "k gcdNAT-DK8 m"
    have A1: "?M dividesNAT-DR1 k"
      using nat_d_def_5 sorry
    assume A2: "m dividesNAT-DR1 n"
    have "?M dividesNAT-DR1 m"
      using nat_d_def_5 sorry
    then have "?M dividesNAT-DR1 n"
      using A2 nat_d_th_4 sorry
    thus "k gcdNAT-DK8 m dividesNAT-DR1 k gcdNAT-DK8 n"
      using A1 nat_d_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_58:
" for m be IntegerINT-1M1 holds  for n be IntegerINT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies n gcdINT-2K3 m >XXREAL-0R4 0NUMBERSK6"
proof-
  have " for m be IntegerINT-1M1 holds  for n be IntegerINT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 & n gcdINT-2K3 m <=XXREAL-0R1 0NUMBERSK6 implies  False "
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix m assume [ty]: "m be IntegerINT-1M1"
    fix n assume [ty]: "n be IntegerINT-1M1"
    assume A1: "n >XXREAL-0R4 0NUMBERSK6"
      and A2: "n gcdINT-2K3 m <=XXREAL-0R1 0NUMBERSK6"
    have A3: "n gcdINT-2K3 m dividesINT-1R1 n"
      using int_2_def_2 sorry
    have "n gcdINT-2K3 m =XBOOLE-0R4 0NUMBERSK6 or n gcdINT-2K3 m <XXREAL-0R3 0NUMBERSK6"
      using A2 sorry
    then have " ex r be IntegerINT-1M1 st n =HIDDENR1 (0NUMBERSK6)*XCMPLX-0K3 r"
      using A3 int_1_def_3 sorry
    thus " False "
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_59:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m >XXREAL-0R4 0NUMBERSK6 & n >XXREAL-0R4 0NUMBERSK6 implies m lcmNAT-DK6 n >XXREAL-0R4 0NUMBERSK6"
proof-
  have " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m >XXREAL-0R4 0NUMBERSK6 & (n >XXREAL-0R4 0NUMBERSK6 & m lcmNAT-DK6 n <=XXREAL-0R1 0NUMBERSK6) implies  False "
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    assume A1: "m >XXREAL-0R4 0NUMBERSK6"
      and A2: "n >XXREAL-0R4 0NUMBERSK6"
      and A3: "m lcmNAT-DK6 n <=XXREAL-0R1 0NUMBERSK6"
    have A4: "m lcmNAT-DK6 n dividesNAT-DR1 m *XCMPLX-0K3 n"
      using newton_th_47 sorry
    have "m lcmNAT-DK6 n =XBOOLE-0R4 0NUMBERSK6 or m lcmNAT-DK6 n <XXREAL-0R3 0NUMBERSK6"
      using A3 sorry
    then have " ex r be NatNAT-1M1 st m *XCMPLX-0K3 n =XBOOLE-0R4 (0NUMBERSK6)*XCMPLX-0K3 r"
      using A4 nat_d_def_3 sorry
    thus " False "
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_60:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (n gcdNAT-DK8 m)lcmNAT-DK6 (n gcdNAT-DK8 k) dividesNAT-DR1 n gcdNAT-DK8 (m lcmNAT-DK6 k)"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (n gcdNAT-DK8 m)lcmNAT-DK6 (n gcdNAT-DK8 k) dividesNAT-DR1 n gcdNAT-DK8 (m lcmNAT-DK6 k)"
  proof(rule ballI,rule ballI,rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    let ?M = "m lcmNAT-DK6 k"
    let ?N = "n gcdNAT-DK8 k"
    let ?P = "n gcdNAT-DK8 m"
    let ?L = "?P lcmNAT-DK6 ?N"
    have A1: "?N dividesNAT-DR1 k"
      using nat_d_def_5 sorry
    have "k dividesNAT-DR1 ?M"
      using nat_d_def_4 sorry
    then have A2: "?N dividesNAT-DR1 ?M"
      using A1 nat_d_th_4 sorry
    have A3: "?P dividesNAT-DR1 m"
      using nat_d_def_5 sorry
    have "m dividesNAT-DR1 ?M"
      using nat_d_def_4 sorry
    then have "?P dividesNAT-DR1 ?M"
      using A3 nat_d_th_4 sorry
    then have A4: "?L dividesNAT-DR1 ?M"
      using A2 nat_d_def_4 sorry
    have A5: "?P dividesNAT-DR1 n"
      using nat_d_def_5 sorry
    have "?N dividesNAT-DR1 n"
      using nat_d_def_5 sorry
    then have "?L dividesNAT-DR1 n"
      using A5 nat_d_def_4 sorry
    thus "(n gcdNAT-DK8 m)lcmNAT-DK6 (n gcdNAT-DK8 k) dividesNAT-DR1 n gcdNAT-DK8 (m lcmNAT-DK6 k)"
      using A4 nat_d_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_61:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for l be NatNAT-1M1 holds m dividesNAT-DR1 l implies m lcmNAT-DK6 (n gcdNAT-DK8 l) dividesNAT-DR1 (m lcmNAT-DK6 n)gcdNAT-DK8 l"
proof-
  have " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for l be NatNAT-1M1 holds m dividesNAT-DR1 l implies m lcmNAT-DK6 (n gcdNAT-DK8 l) dividesNAT-DR1 (m lcmNAT-DK6 n)gcdNAT-DK8 l"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix l assume [ty]: "l be NatNAT-1M1"
    let ?M = "m lcmNAT-DK6 n"
    let ?K = "?M gcdNAT-DK8 l"
    let ?N = "n gcdNAT-DK8 l"
    have A1: "m dividesNAT-DR1 ?M"
      using nat_d_def_4 sorry
    have A2: "?N dividesNAT-DR1 n"
      using nat_d_def_5 sorry
    have A3: "?N dividesNAT-DR1 l"
      using nat_d_def_5 sorry
    have "n dividesNAT-DR1 ?M"
      using nat_d_def_4 sorry
    then have "?N dividesNAT-DR1 ?M"
      using A2 nat_d_th_4 sorry
    then have A4: "?N dividesNAT-DR1 ?K"
      using A3 nat_d_def_5 sorry
    assume "m dividesNAT-DR1 l"
    then have "m dividesNAT-DR1 ?K"
      using A1 nat_d_def_5 sorry
    thus "m lcmNAT-DK6 (n gcdNAT-DK8 l) dividesNAT-DR1 (m lcmNAT-DK6 n)gcdNAT-DK8 l"
      using A4 nat_d_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_62:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n gcdNAT-DK8 m dividesNAT-DR1 n lcmNAT-DK6 m"
proof-
  have " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n gcdNAT-DK8 m dividesNAT-DR1 n lcmNAT-DK6 m"
  proof(rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    have A1: "n dividesNAT-DR1 n lcmNAT-DK6 m"
      using nat_d_def_4 sorry
    have "n gcdNAT-DK8 m dividesNAT-DR1 n"
      using nat_d_def_5 sorry
    thus "n gcdNAT-DK8 m dividesNAT-DR1 n lcmNAT-DK6 m"
      using A1 nat_d_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve p, q for "naturalORDINAL1V7\<bar>NumberORDINAL1M1"
reserve i0, i, i1, i2, i4 for "IntegerINT-1M1"
mtheorem newton_th_63:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds 0NUMBERSK6 <XXREAL-0R3 m implies n modNAT-DK4 m =XBOOLE-0R4 n -XCMPLX-0K6 m *XCMPLX-0K3 (n divNAT-DK3 m)"
proof-
  have " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m >XXREAL-0R4 0NUMBERSK6 implies n modNAT-DK4 m =XBOOLE-0R4 n -XCMPLX-0K6 m *XCMPLX-0K3 (n divNAT-DK3 m)"
  proof(rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    obtain z1 z2 where 
      [ty]:"z1 be IntegerINT-1M1" and z1Def:"z1 = m *XCMPLX-0K3 (n divNAT-DK3 m)" and
      [ty]:"z2 be IntegerINT-1M1" and z2Def:"z2 = n modNAT-DK4 m"
       sorry
    assume "m >XXREAL-0R4 0NUMBERSK6"
    then have "n -XCMPLX-0K6 z1 =XBOOLE-0R4 (z1 +XCMPLX-0K2 z2)-XCMPLX-0K6 z1"
      using nat_d_th_2 sorry
    thus "n modNAT-DK4 m =XBOOLE-0R4 n -XCMPLX-0K6 m *XCMPLX-0K3 (n divNAT-DK3 m)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_64:
" for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds i2 >=XXREAL-0R2 0NUMBERSK6 implies i1 modINT-1K6 i2 >=XXREAL-0R2 0NUMBERSK6"
  using int_1_th_57 sorry

mtheorem newton_th_65:
" for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds i2 >XXREAL-0R4 0NUMBERSK6 implies i1 modINT-1K6 i2 <XXREAL-0R3 i2"
  using int_1_th_58 sorry

mtheorem newton_th_66:
" for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds i2 <>HIDDENR2 0NUMBERSK6 implies i1 =HIDDENR1 (i1 divINT-1K5 i2)*XCMPLX-0K3 i2 +XCMPLX-0K2 (i1 modINT-1K6 i2)"
  using int_1_th_59 sorry

(*\$N Bezout's identity*)
mtheorem newton_th_67:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  ex i be IntegerINT-1M1 st  ex i1 be IntegerINT-1M1 st i *XCMPLX-0K3 m +XCMPLX-0K2 i1 *XCMPLX-0K3 n =XBOOLE-0R4 m gcdNAT-DK8 n"
  using nat_d_th_68 sorry

mdef newton_def_6 ("SetPrimesNEWTONK8" 164 ) where
"func SetPrimesNEWTONK8 \<rightarrow> SubsetSUBSET-1M2-of NATNUMBERSK1 means
  \<lambda>it.  for n be NatNAT-1M1 holds n inTARSKIR2 it iff n be primeINT-2V1"
proof-
  (*existence*)
    show " ex it be SubsetSUBSET-1M2-of NATNUMBERSK1 st  for n be NatNAT-1M1 holds n inTARSKIR2 it iff n be primeINT-2V1"
    proof-
      have " ex tVar6 be SubsetSUBSET-1M2-of NATNUMBERSK1 st  for n be NatNAT-1M1 holds (n inTARSKIR2 tVar6 implies n be primeINT-2V1) & (n be primeINT-2V1 implies n inTARSKIR2 tVar6)"
      proof-
        let ?P = "\<lambda>Lamb1. Lamb1 be primeINT-2V1"
        obtain X where
          [ty]:"X be SubsetSUBSET-1M2-of NATNUMBERSK1" and 
          A1: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n inTARSKIR2 X iff ?P(n)"
          using subset_1_sch_3 sorry
        show " ex tVar6 be SubsetSUBSET-1M2-of NATNUMBERSK1 st  for n be NatNAT-1M1 holds (n inTARSKIR2 tVar6 implies n be primeINT-2V1) & (n be primeINT-2V1 implies n inTARSKIR2 tVar6)"
        proof(rule bexI[of _ "X"],rule ballI,rule conjMI,rule impI)
          fix n assume [ty]: "n be NatNAT-1M1"
          show "n inTARSKIR2 X implies n be primeINT-2V1"
            using A1 sorry
          assume A2: "n be primeINT-2V1"
          have "n inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          thus "n inTARSKIR2 X"
            using A1 A2 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be SubsetSUBSET-1M2-of NATNUMBERSK1 holds  for it2 be SubsetSUBSET-1M2-of NATNUMBERSK1 holds ( for n be NatNAT-1M1 holds n inTARSKIR2 it1 iff n be primeINT-2V1) & ( for n be NatNAT-1M1 holds n inTARSKIR2 it2 iff n be primeINT-2V1) implies it1 =HIDDENR1 it2"
    proof-
      have " for A be SubsetSUBSET-1M2-of NATNUMBERSK1 holds  for B be SubsetSUBSET-1M2-of NATNUMBERSK1 holds ( for n be NatNAT-1M1 holds n inTARSKIR2 A iff n be primeINT-2V1) & ( for n be NatNAT-1M1 holds n inTARSKIR2 B iff n be primeINT-2V1) implies A =HIDDENR1 B"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix A assume [ty]: "A be SubsetSUBSET-1M2-of NATNUMBERSK1"
        fix B assume [ty]: "B be SubsetSUBSET-1M2-of NATNUMBERSK1"
        assume A3: " for n be NatNAT-1M1 holds n inTARSKIR2 A iff n be primeINT-2V1"
          and A4: " for n be NatNAT-1M1 holds n inTARSKIR2 B iff n be primeINT-2V1"
        have "A c=MEMBEREDR6 B & B c=TARSKIR1 A"
        proof(rule conjMI)
          show "A c=MEMBEREDR6 B"
            using A3 A4 sorry
          have " for x be objectHIDDENM1 holds x inHIDDENR3 B implies x inHIDDENR3 A"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A5: "x inHIDDENR3 B"
            then have 
              [ty]:"x be ElementSUBSET-1M1-of NATNUMBERSK1"
               sorry
            have "x be primeINT-2V1"
              using A4 A5 sorry
            thus "x inHIDDENR3 A"
              using A3 sorry
          qed "sorry"
          thus "B c=TARSKIR1 A"
            using tarski_def_3 sorry
        qed
        thus "A =HIDDENR1 B"
          using xboole_0_def_10 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem newton_cl_11:
"cluster primeINT-2V1 for ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*existence*)
  show " ex it be ElementSUBSET-1M1-of NATNUMBERSK1 st it be primeINT-2V1"
    using int_2_th_28 sorry
qed "sorry"

mtheorem newton_cl_12:
"cluster primeINT-2V1 for NatNAT-1M1"
proof
(*existence*)
  show " ex it be NatNAT-1M1 st it be primeINT-2V1"
    using int_2_th_28 sorry
qed "sorry"

syntax NEWTONM1 :: "Ty" ("PrimeNEWTONM1" 70)
translations "PrimeNEWTONM1" \<rightharpoonup> "primeINT-2V1\<bar>NatNAT-1M1"

mdef newton_def_7 ("SetPrimenumberNEWTONK9  _ " [164]164 ) where
  mlet "p be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"func SetPrimenumberNEWTONK9 p \<rightarrow> SubsetSUBSET-1M2-of NATNUMBERSK1 means
  \<lambda>it.  for q be NatNAT-1M1 holds q inTARSKIR2 it iff q <XXREAL-0R3 p & q be primeINT-2V1"
proof-
  (*existence*)
    show " ex it be SubsetSUBSET-1M2-of NATNUMBERSK1 st  for q be NatNAT-1M1 holds q inTARSKIR2 it iff q <XXREAL-0R3 p & q be primeINT-2V1"
    proof-
      have " ex tVar7 be SubsetSUBSET-1M2-of NATNUMBERSK1 st  for q be NatNAT-1M1 holds (q inTARSKIR2 tVar7 implies q <XXREAL-0R3 p & q be primeINT-2V1) & (q <XXREAL-0R3 p & q be primeINT-2V1 implies q inTARSKIR2 tVar7)"
      proof-
        let ?P = "\<lambda>Lamb1. Lamb1 <XXREAL-0R3 p & Lamb1 be primeINT-2V1"
        obtain X where
          [ty]:"X be SubsetSUBSET-1M2-of NATNUMBERSK1" and 
          A1: " for q be ElementSUBSET-1M1-of NATNUMBERSK1 holds q inTARSKIR2 X iff ?P(q)"
          using subset_1_sch_3 sorry
        show " ex tVar7 be SubsetSUBSET-1M2-of NATNUMBERSK1 st  for q be NatNAT-1M1 holds (q inTARSKIR2 tVar7 implies q <XXREAL-0R3 p & q be primeINT-2V1) & (q <XXREAL-0R3 p & q be primeINT-2V1 implies q inTARSKIR2 tVar7)"
        proof(rule bexI[of _ "X"],rule ballI,rule conjMI,rule impMI ,rule impI)
          fix q assume [ty]: "q be NatNAT-1M1"
          show "q inTARSKIR2 X implies q <XXREAL-0R3 p & q be primeINT-2V1"
            using A1 sorry
          assume A2: "q <XXREAL-0R3 p"
            and A3: "q be primeINT-2V1"
          have "q inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          thus "q inTARSKIR2 X"
            using A1 A2 A3 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be SubsetSUBSET-1M2-of NATNUMBERSK1 holds  for it2 be SubsetSUBSET-1M2-of NATNUMBERSK1 holds ( for q be NatNAT-1M1 holds q inTARSKIR2 it1 iff q <XXREAL-0R3 p & q be primeINT-2V1) & ( for q be NatNAT-1M1 holds q inTARSKIR2 it2 iff q <XXREAL-0R3 p & q be primeINT-2V1) implies it1 =HIDDENR1 it2"
    proof-
      have " for A be SubsetSUBSET-1M2-of NATNUMBERSK1 holds  for B be SubsetSUBSET-1M2-of NATNUMBERSK1 holds ( for q be NatNAT-1M1 holds q inTARSKIR2 A iff q <XXREAL-0R3 p & q be primeINT-2V1) & ( for q be NatNAT-1M1 holds q inTARSKIR2 B iff q <XXREAL-0R3 p & q be primeINT-2V1) implies A =HIDDENR1 B"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix A assume [ty]: "A be SubsetSUBSET-1M2-of NATNUMBERSK1"
        fix B assume [ty]: "B be SubsetSUBSET-1M2-of NATNUMBERSK1"
        assume A4: " for q be NatNAT-1M1 holds q inTARSKIR2 A iff q <XXREAL-0R3 p & q be primeINT-2V1"
          and A5: " for q be NatNAT-1M1 holds q inTARSKIR2 B iff q <XXREAL-0R3 p & q be primeINT-2V1"
        have "A c=MEMBEREDR6 B & B c=TARSKIR1 A"
        proof(rule conjMI)
          show "A c=MEMBEREDR6 B"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 A implies x inHIDDENR3 B"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume A6: "x inHIDDENR3 A"
              then have 
                [ty]:"x be ElementSUBSET-1M1-of NATNUMBERSK1"
                 sorry
              have A7: "x be primeINT-2V1"
                using A4 A6 sorry
              have "x <XXREAL-0R3 p"
                using A4 A6 sorry
              thus "x inHIDDENR3 B"
                using A5 A7 sorry
            qed "sorry"
            thus "A c=MEMBEREDR6 B"
              using tarski_def_3 sorry
          qed
          have " for x be objectHIDDENM1 holds x inHIDDENR3 B implies x inHIDDENR3 A"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A8: "x inHIDDENR3 B"
            then have 
              [ty]:"x be ElementSUBSET-1M1-of NATNUMBERSK1"
               sorry
            have A9: "x be primeINT-2V1"
              using A5 A8 sorry
            have "x <XXREAL-0R3 p"
              using A5 A8 sorry
            thus "x inHIDDENR3 A"
              using A4 A9 sorry
          qed "sorry"
          thus "B c=TARSKIR1 A"
            using tarski_def_3 sorry
        qed
        thus "A =HIDDENR1 B"
          using xboole_0_def_10 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem newton_th_68:
" for p be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds SetPrimenumberNEWTONK9 p c=MEMBEREDR6 SetPrimesNEWTONK8"
proof-
  have " for p be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds SetPrimenumberNEWTONK9 p c=MEMBEREDR6 SetPrimesNEWTONK8"
  proof(rule ballI)
    fix p assume [ty]: "p be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 SetPrimenumberNEWTONK9 p implies x inHIDDENR3 SetPrimesNEWTONK8"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A1: "x inHIDDENR3 SetPrimenumberNEWTONK9 p"
      then obtain x9 where 
        [ty]:"x9 be ElementSUBSET-1M1-of NATNUMBERSK1" and x9Def:"x9 = x"
         sorry
      have "x9 be primeINT-2V1"
        using A1 newton_def_7 sorry
      thus "x inHIDDENR3 SetPrimesNEWTONK8"
        using newton_def_6 sorry
    qed "sorry"
    thus "SetPrimenumberNEWTONK9 p c=MEMBEREDR6 SetPrimesNEWTONK8"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_69:
" for p be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for q be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds p <=XXREAL-0R1 q implies SetPrimenumberNEWTONK9 p c=MEMBEREDR6 SetPrimenumberNEWTONK9 q"
proof-
  have " for p be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for q be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds p <=XXREAL-0R1 q implies SetPrimenumberNEWTONK9 p c=MEMBEREDR6 SetPrimenumberNEWTONK9 q"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix q assume [ty]: "q be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "p <=XXREAL-0R1 q"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 SetPrimenumberNEWTONK9 p implies x inHIDDENR3 SetPrimenumberNEWTONK9 q"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A2: "x inHIDDENR3 SetPrimenumberNEWTONK9 p"
      then obtain x9 where 
        [ty]:"x9 be ElementSUBSET-1M1-of NATNUMBERSK1" and x9Def:"x9 = x"
         sorry
      have "x9 <XXREAL-0R3 p"
        using A2 newton_def_7 sorry
      then have A3: "x9 <XXREAL-0R3 q"
        using A1 xxreal_0_th_2 sorry
      have "x9 be primeINT-2V1"
        using A2 newton_def_7 sorry
      thus "x inHIDDENR3 SetPrimenumberNEWTONK9 q"
        using A3 newton_def_7 sorry
    qed "sorry"
    thus "SetPrimenumberNEWTONK9 p c=MEMBEREDR6 SetPrimenumberNEWTONK9 q"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_70:
" for p be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds SetPrimenumberNEWTONK9 p c=MEMBEREDR6 SegFINSEQ-1K1 p"
proof-
  have " for p be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds SetPrimenumberNEWTONK9 p c=MEMBEREDR6 SegFINSEQ-1K1 p"
  proof(rule ballI)
    fix p assume [ty]: "p be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 SetPrimenumberNEWTONK9 p implies x inHIDDENR3 SegFINSEQ-1K1 p"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A1: "x inHIDDENR3 SetPrimenumberNEWTONK9 p"
      then obtain q where 
        [ty]:"q be ElementSUBSET-1M1-of NATNUMBERSK1" and qDef:"q = x"
         sorry
      have "q be primeINT-2V1"
        using A1 newton_def_7 sorry
      then have A2: "\<one>\<^sub>M <=XXREAL-0R1 q"
        using int_2_def_4 sorry
      have "q <XXREAL-0R3 p"
        using A1 newton_def_7 sorry
      thus "x inHIDDENR3 SegFINSEQ-1K1 p"
        using A2 sorry
    qed "sorry"
    thus "SetPrimenumberNEWTONK9 p c=MEMBEREDR6 SegFINSEQ-1K1 p"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_71:
" for p be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds SetPrimenumberNEWTONK9 p be finiteFINSET-1V1"
proof-
  have " for p be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds SetPrimenumberNEWTONK9 p be finiteFINSET-1V1"
  proof(rule ballI)
    fix p assume [ty]: "p be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have "SetPrimenumberNEWTONK9 p c=MEMBEREDR6 SegFINSEQ-1K1 p"
      using newton_th_70 sorry
    thus "SetPrimenumberNEWTONK9 p be finiteFINSET-1V1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_cl_13:
  mlet "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster SetPrimenumberNEWTONK9 n as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "SetPrimenumberNEWTONK9 n be finiteFINSET-1V1"
    using newton_th_71 sorry
qed "sorry"

reserve p for "PrimeNEWTONM1"
mtheorem newton_th_72:
" for l be NatNAT-1M1 holds  ex p be PrimeNEWTONM1 st p >XXREAL-0R4 l"
proof-
  have " for l be NatNAT-1M1 holds  not ( for p be PrimeNEWTONM1 holds p >XXREAL-0R4 l)"
  proof(rule ballI)
    fix l assume [ty]: "l be NatNAT-1M1"
    obtain two where 
      [ty]:"two be PrimeNEWTONM1" and twoDef:"two = \<two>\<^sub>M"
      using int_2_th_28 sorry
    have 
      [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    have "(l =XBOOLE-0R4 0NUMBERSK6 & ( ex p be PrimeNEWTONM1 st p be primeINT-2V1 & p >XXREAL-0R4 l) or l =XBOOLE-0R4 \<one>\<^sub>M & ( ex p be PrimeNEWTONM1 st p be primeINT-2V1 & p >XXREAL-0R4 l)) or \<two>\<^sub>M <=XXREAL-0R1 l & ( ex p be PrimeNEWTONM1 st p be primeINT-2V1 & p >XXREAL-0R4 l)"
    proof-
      have "(l =XBOOLE-0R4 0NUMBERSK6 & ( ex tVar8 be PrimeNEWTONM1 st tVar8 be primeINT-2V1 &  not tVar8 >XXREAL-0R4 l) or l =XBOOLE-0R4 \<one>\<^sub>M & (l =XBOOLE-0R4 \<one>\<^sub>M implies ( ex tVar9 be PrimeNEWTONM1 st tVar9 be primeINT-2V1 &  not tVar9 >XXREAL-0R4 l))) or \<two>\<^sub>M <=XXREAL-0R1 l & (\<two>\<^sub>M <=XXREAL-0R1 l implies ( ex tVar10 be PrimeNEWTONM1 st tVar10 be primeINT-2V1 &  not tVar10 >XXREAL-0R4 l))"
      proof-
        have Cut1682: "l <=XXREAL-0R1 \<two>\<^sub>M implies ( ex VarFor1 be setHIDDENM2 st (0NUMBERSK6 <=XXREAL-0R1 VarFor1 & VarFor1 <=XXREAL-0R1 \<two>\<^sub>M) & l =XBOOLE-0R4 VarFor1)"
           sorry
        show "(l =XBOOLE-0R4 0NUMBERSK6 & ( ex tVar8 be PrimeNEWTONM1 st tVar8 be primeINT-2V1 &  not tVar8 >XXREAL-0R4 l) or l =XBOOLE-0R4 \<one>\<^sub>M & (l =XBOOLE-0R4 \<one>\<^sub>M implies ( ex tVar9 be PrimeNEWTONM1 st tVar9 be primeINT-2V1 &  not tVar9 >XXREAL-0R4 l))) or \<two>\<^sub>M <=XXREAL-0R1 l & (\<two>\<^sub>M <=XXREAL-0R1 l implies ( ex tVar10 be PrimeNEWTONM1 st tVar10 be primeINT-2V1 &  not tVar10 >XXREAL-0R4 l))"
        proof-
          have cases: "(l =XBOOLE-0R4 0NUMBERSK6 or l =XBOOLE-0R4 \<one>\<^sub>M) or \<two>\<^sub>M <=XXREAL-0R1 l"
            using Cut1682 sorry
          have case1: "l =XBOOLE-0R4 0NUMBERSK6 implies ( ex tVar8 be PrimeNEWTONM1 st tVar8 be primeINT-2V1 &  not tVar8 >XXREAL-0R4 l)"
          proof(rule impI)
            assume A1: "l =XBOOLE-0R4 0NUMBERSK6"
            show " ex tVar8 be PrimeNEWTONM1 st tVar8 be primeINT-2V1 &  not tVar8 >XXREAL-0R4 l"
            proof(rule bexI[of _ "two"])
              show "two be primeINT-2V1 &  not two >XXREAL-0R4 l"
                using A1 sorry
            qed "sorry"
          qed
          have case2: "l =XBOOLE-0R4 \<one>\<^sub>M implies ( ex tVar9 be PrimeNEWTONM1 st tVar9 be primeINT-2V1 &  not tVar9 >XXREAL-0R4 l)"
          proof(rule impI)
            assume A2: "l =XBOOLE-0R4 \<one>\<^sub>M"
            show " ex tVar9 be PrimeNEWTONM1 st tVar9 be primeINT-2V1 &  not tVar9 >XXREAL-0R4 l"
            proof(rule bexI[of _ "two"])
              show "two be primeINT-2V1 &  not two >XXREAL-0R4 l"
                using A2 sorry
            qed "sorry"
          qed
          have case3: "\<two>\<^sub>M <=XXREAL-0R1 l implies ( ex tVar10 be PrimeNEWTONM1 st tVar10 be primeINT-2V1 &  not tVar10 >XXREAL-0R4 l)"
          proof(rule impI)
            assume A3: "\<two>\<^sub>M <=XXREAL-0R1 l"
            have "l <=XXREAL-0R1 l !NEWTONK7"
              using newton_th_38 sorry
            then have "\<two>\<^sub>M <=XXREAL-0R1 l !NEWTONK7"
              using A3 xxreal_0_th_2 sorry
            then have "\<two>\<^sub>M +NAT-1K1 0NUMBERSK6 <=XXREAL-0R1 l !NEWTONK7 +NAT-1K1 \<one>\<^sub>M"
              using xreal_1_th_7 sorry
            then obtain j where
              [ty]:"j be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A4: "j be primeINT-2V1"and A5: "j dividesNAT-DR1 l !NEWTONK7 +NAT-1K1 \<one>\<^sub>M"
              using int_2_th_31 sorry
            obtain j9 where 
              [ty]:"j9 be PrimeNEWTONM1" and j9Def:"j9 = j"
              using A4 sorry
            show " ex tVar10 be PrimeNEWTONM1 st tVar10 be primeINT-2V1 &  not tVar10 >XXREAL-0R4 l"
            proof(rule bexI[of _ "j9"])
              have A6: "j <>HIDDENR2 0NUMBERSK6"
                using A4 int_2_def_4 sorry
              have "j <>HIDDENR2 \<one>\<^sub>M"
                using A4 int_2_def_4 sorry
              thus "j9 be primeINT-2V1 &  not j9 >XXREAL-0R4 l"
                using A5 A6 newton_th_39 newton_th_41 sorry
            qed "sorry"
          qed
          show " ?thesis "
            using cases case1 case2 case3 sorry
        qed
      qed
      thus " ?thesis "
         sorry
    qed
    thus " not ( for p be PrimeNEWTONM1 holds p >XXREAL-0R4 l)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma newton_lm_1:
"SetPrimenumberNEWTONK9 \<two>\<^sub>M =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have "SetPrimenumberNEWTONK9 \<two>\<^sub>M <>HIDDENR2 {}XBOOLE-0K1 implies  False "
  proof(rule impI)
    assume "SetPrimenumberNEWTONK9 \<two>\<^sub>M <>HIDDENR2 {}XBOOLE-0K1"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A1: "x inHIDDENR3 SetPrimenumberNEWTONK9 \<two>\<^sub>M"
      using xboole_0_def_1 sorry
    have 
      [ty]:"x be NatNAT-1M1"
      using A1 sorry
    have A2: "x be primeINT-2V1"
      using A1 newton_def_7 sorry
    have "x <XXREAL-0R3 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
      using A1 newton_def_7 sorry
    then have "x <=XXREAL-0R1 \<one>\<^sub>M"
      using nat_1_th_13 sorry
    then have "0NUMBERSK6 be primeINT-2V1 or \<one>\<^sub>M be primeINT-2V1"
      using A2 nat_1_th_25 sorry
    thus " False "
      using int_2_def_4 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem newton_cl_14:
"cluster SetPrimesNEWTONK8 as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "SetPrimesNEWTONK8 be  non emptyXBOOLE-0V1"
    using newton_def_6 int_2_th_28 sorry
qed "sorry"

mtheorem newton_cl_15:
"cluster SetPrimenumberNEWTONK9 \<two>\<^sub>M as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "SetPrimenumberNEWTONK9 \<two>\<^sub>M be emptyXBOOLE-0V1"
    using newton_lm_1 sorry
qed "sorry"

mtheorem newton_th_73:
" for m be NatNAT-1M1 holds SetPrimenumberNEWTONK9 m c=MEMBEREDR6 SegFINSEQ-1K2 m"
proof-
  have " for m be NatNAT-1M1 holds SetPrimenumberNEWTONK9 m c=MEMBEREDR6 SegFINSEQ-1K2 m"
  proof(rule ballI)
    fix m assume [ty]: "m be NatNAT-1M1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 SetPrimenumberNEWTONK9 m implies x inHIDDENR3 SegFINSEQ-1K2 m"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A1: "x inHIDDENR3 SetPrimenumberNEWTONK9 m"
      then have 
        [ty]:"x be ElementSUBSET-1M1-of NATNUMBERSK1"
         sorry
      have "x be primeINT-2V1"
        using A1 newton_def_7 sorry
      then have A2: "\<one>\<^sub>M <=XXREAL-0R1 x"
        using int_2_def_4 sorry
      have "x <XXREAL-0R3 m"
        using A1 newton_def_7 sorry
      thus "x inHIDDENR3 SegFINSEQ-1K2 m"
        using A2 sorry
    qed "sorry"
    thus "SetPrimenumberNEWTONK9 m c=MEMBEREDR6 SegFINSEQ-1K2 m"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_74:
" for k be NatNAT-1M1 holds  for m be NatNAT-1M1 holds k >=XXREAL-0R2 m implies  not k inTARSKIR2 SetPrimenumberNEWTONK9 m"
  using newton_def_7 sorry

mtheorem newton_th_75:
" for n be NatNAT-1M1 holds SetPrimenumberNEWTONK9 n \\/XBOOLE-0K2 {TARSKIK1 n} be finiteFINSET-1V1"
   sorry

mtheorem newton_th_76:
" for f be PrimeNEWTONM1 holds  for g be NatNAT-1M1 holds f <XXREAL-0R3 g implies SetPrimenumberNEWTONK9 f \\/XBOOLE-0K2 {TARSKIK1 f} c=MEMBEREDR6 SetPrimenumberNEWTONK9 g"
proof(rule ballI,rule ballI,rule impI)
  fix f assume [ty]: "f be PrimeNEWTONM1"
  fix g assume [ty]: "g be NatNAT-1M1"
  assume A1: "f <XXREAL-0R3 g"
  have " for x be objectHIDDENM1 holds x inHIDDENR3 SetPrimenumberNEWTONK9 f \\/XBOOLE-0K2 {TARSKIK1 f} implies x inHIDDENR3 SetPrimenumberNEWTONK9 g"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A2: "x inHIDDENR3 SetPrimenumberNEWTONK9 f \\/XBOOLE-0K2 {TARSKIK1 f}"
    then have 
      [ty]:"x be NatNAT-1M1"
       sorry
    show "x inHIDDENR3 SetPrimenumberNEWTONK9 g"
    proof-
      have cases: "x inTARSKIR2 SetPrimenumberNEWTONK9 f or x inTARSKIR2 {TARSKIK1 f}"
        using A2 xboole_0_def_3 sorry
      have case1: "x inTARSKIR2 SetPrimenumberNEWTONK9 f implies x inHIDDENR3 SetPrimenumberNEWTONK9 g"
      proof(rule impI)
        assume A3: "x inTARSKIR2 SetPrimenumberNEWTONK9 f"
        then have "x <XXREAL-0R3 f"
          using newton_def_7 sorry
        then have A4: "x <XXREAL-0R3 g"
          using A1 xxreal_0_th_2 sorry
        have "x be primeINT-2V1"
          using A3 newton_def_7 sorry
        thus "x inHIDDENR3 SetPrimenumberNEWTONK9 g"
          using A4 newton_def_7 sorry
      qed
      have case2: "x inTARSKIR2 {TARSKIK1 f} implies x inHIDDENR3 SetPrimenumberNEWTONK9 g"
      proof(rule impI)
        assume "x inTARSKIR2 {TARSKIK1 f}"
        then have "x =XBOOLE-0R4 f"
          using tarski_def_1 sorry
        thus "x inHIDDENR3 SetPrimenumberNEWTONK9 g"
          using A1 newton_def_7 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus "SetPrimenumberNEWTONK9 f \\/XBOOLE-0K2 {TARSKIK1 f} c=MEMBEREDR6 SetPrimenumberNEWTONK9 g"
    using tarski_def_3 sorry
qed "sorry"

mtheorem newton_th_77:
" for k be NatNAT-1M1 holds  for m be NatNAT-1M1 holds k >=XXREAL-0R2 m implies  not k inTARSKIR2 SetPrimenumberNEWTONK9 m"
  using newton_def_7 sorry

mlemma newton_lm_2:
" for n be NatNAT-1M1 holds SetPrimenumberNEWTONK9 n =XBOOLE-0R4 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : k <XXREAL-0R3 n & k be primeINT-2V1 }"
proof-
  have " for n be NatNAT-1M1 holds SetPrimenumberNEWTONK9 n =XBOOLE-0R4 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 :  not k <XXREAL-0R3 n & k be primeINT-2V1 }"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have "SetPrimenumberNEWTONK9 n c=MEMBEREDR6 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : k <XXREAL-0R3 n & k be primeINT-2V1 } & {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 :  not k <XXREAL-0R3 n & k be primeINT-2V1 } c=TARSKIR1 SetPrimenumberNEWTONK9 n"
    proof(rule conjMI)
      show "SetPrimenumberNEWTONK9 n c=MEMBEREDR6 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : k <XXREAL-0R3 n & k be primeINT-2V1 }"
      proof-
        have "SetPrimenumberNEWTONK9 n c=MEMBEREDR6 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 :  not k <XXREAL-0R3 n & k be primeINT-2V1 }"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 SetPrimenumberNEWTONK9 n implies x inHIDDENR3 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 :  not k <XXREAL-0R3 n & k be primeINT-2V1 }"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A1: "x inHIDDENR3 SetPrimenumberNEWTONK9 n"
            then have 
              [ty]:"x be ElementSUBSET-1M1-of NATNUMBERSK1"
               sorry
            have A2: "x be primeINT-2V1"
              using A1 newton_def_7 sorry
            have "x <XXREAL-0R3 n"
              using A1 newton_def_7 sorry
            thus "x inHIDDENR3 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 :  not k <XXREAL-0R3 n & k be primeINT-2V1 }"
              using A2 sorry
          qed "sorry"
          thus "SetPrimenumberNEWTONK9 n c=MEMBEREDR6 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 :  not k <XXREAL-0R3 n & k be primeINT-2V1 }"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : k <XXREAL-0R3 n & k be primeINT-2V1 } implies x inHIDDENR3 SetPrimenumberNEWTONK9 n"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : k <XXREAL-0R3 n & k be primeINT-2V1 }"
        then have " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st (x =HIDDENR1 k & k <XXREAL-0R3 n) & k be primeINT-2V1"
           sorry
        thus "x inHIDDENR3 SetPrimenumberNEWTONK9 n"
          using newton_def_7 sorry
      qed "sorry"
      thus "{k where k be ElementSUBSET-1M1-of NATNUMBERSK1 :  not k <XXREAL-0R3 n & k be primeINT-2V1 } c=TARSKIR1 SetPrimenumberNEWTONK9 n"
        using tarski_def_3 sorry
    qed
    thus "SetPrimenumberNEWTONK9 n =XBOOLE-0R4 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 :  not k <XXREAL-0R3 n & k be primeINT-2V1 }"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef newton_def_8 ("primenumberNEWTONK10  _ " [164]164 ) where
  mlet "n be NatNAT-1M1"
"func primenumberNEWTONK10 n \<rightarrow> primeINT-2V1\<bar>ElementSUBSET-1M1-of NATNUMBERSK1 means
  \<lambda>it. n =XBOOLE-0R4 cardCARD-1K4 (SetPrimenumberNEWTONK9 it)"
proof-
  (*existence*)
    show " ex it be primeINT-2V1\<bar>ElementSUBSET-1M1-of NATNUMBERSK1 st n =XBOOLE-0R4 cardCARD-1K4 (SetPrimenumberNEWTONK9 it)"
    proof-
      have " not ( for VarFor1 be primeINT-2V1\<bar>ElementSUBSET-1M1-of NATNUMBERSK1 holds  not n =XBOOLE-0R4 cardCARD-1K4 (SetPrimenumberNEWTONK9 VarFor1))"
      proof-
        let ?P1 = "\<lambda>Lamb1.  ex m be NatNAT-1M1 st Lamb1 =XBOOLE-0R4 cardCARD-1K4 (SetPrimenumberNEWTONK9 m) & m be PrimeNEWTONM1"
        have A1: " for n be NatNAT-1M1 holds ?P1(n) implies ?P1(n +NAT-1K1 \<one>\<^sub>M)"
        proof-
          have " for n be NatNAT-1M1 holds ( ex m be NatNAT-1M1 st n =XBOOLE-0R4 cardCARD-1K4 (SetPrimenumberNEWTONK9 m) & m be PrimeNEWTONM1) implies ( ex tVar11 be NatNAT-1M1 st n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 cardCARD-1K4 (SetPrimenumberNEWTONK9 tVar11) & tVar11 be PrimeNEWTONM1)"
          proof(rule ballI,rule impI)
            fix n assume [ty]: "n be NatNAT-1M1"
            assume Given: " ex m be NatNAT-1M1 st n =XBOOLE-0R4 cardCARD-1K4 (SetPrimenumberNEWTONK9 m) & m be PrimeNEWTONM1"
            then obtain m where
              [ty]:"m be NatNAT-1M1" and 
              A2: "n =XBOOLE-0R4 cardCARD-1K4 (SetPrimenumberNEWTONK9 m)"and A3: "m be PrimeNEWTONM1"
               sorry
            let ?P = "\<lambda>Lamb1. Lamb1 be primeINT-2V1 & Lamb1 >XXREAL-0R4 m"
            have A4: " not m inTARSKIR2 SetPrimenumberNEWTONK9 m"
              using newton_def_7 sorry
            have A5: " ex k be NatNAT-1M1 st ?P(k)"
            proof-
              have " not ( for k be NatNAT-1M1 holds  not (k be primeINT-2V1 & k >XXREAL-0R4 m))"
              proof-
                have " ex p be PrimeNEWTONM1 st p >XXREAL-0R4 m"
                  using newton_th_72 sorry
                thus " not ( for k be NatNAT-1M1 holds  not (k be primeINT-2V1 & k >XXREAL-0R4 m))"
                   sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            obtain k where
              [ty]:"k be NatNAT-1M1" and 
              A6: "?P(k) & ( for l be NatNAT-1M1 holds ?P(l) implies k <=XXREAL-0R1 l)"
              using nat_1_sch_5 A5 sorry
            show " ex tVar11 be NatNAT-1M1 st n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 cardCARD-1K4 (SetPrimenumberNEWTONK9 tVar11) & tVar11 be PrimeNEWTONM1"
            proof(rule bexI[of _ "k"],rule conjMI)
              have A7: "SetPrimenumberNEWTONK9 k c=MEMBEREDR6 SetPrimenumberNEWTONK9 m \\/XBOOLE-0K2 {TARSKIK1 m}"
              proof-
                have " for s be objectHIDDENM1 holds s inHIDDENR3 SetPrimenumberNEWTONK9 k implies s inHIDDENR3 SetPrimenumberNEWTONK9 m \\/XBOOLE-0K2 {TARSKIK1 m}"
                proof(rule ballI,rule impI)
                  fix s assume [ty]: "s be objectHIDDENM1"
                  assume A8: "s inHIDDENR3 SetPrimenumberNEWTONK9 k"
                  then have 
                    [ty]:"s be ElementSUBSET-1M1-of NATNUMBERSK1"
                     sorry
                  have A9: "s be primeINT-2V1"
                    using A8 newton_def_7 sorry
                  have "s <XXREAL-0R3 k"
                    using A8 newton_def_7 sorry
                  then have A10: "s <=XXREAL-0R1 m"
                    using A6 A9 sorry
                  show "s inHIDDENR3 SetPrimenumberNEWTONK9 m \\/XBOOLE-0K2 {TARSKIK1 m}"
                  proof-
                    have cases: "s =XBOOLE-0R4 m or s <XXREAL-0R3 m"
                      using A10 xxreal_0_th_1 sorry
                    have case1: "s =XBOOLE-0R4 m implies s inHIDDENR3 SetPrimenumberNEWTONK9 m \\/XBOOLE-0K2 {TARSKIK1 m}"
                    proof(rule impI)
                      assume "s =XBOOLE-0R4 m"
                      then have "s inTARSKIR2 {TARSKIK1 m}"
                        using tarski_def_1 sorry
                      thus "s inHIDDENR3 SetPrimenumberNEWTONK9 m \\/XBOOLE-0K2 {TARSKIK1 m}"
                        using xboole_0_def_3 sorry
                    qed
                    have case2: "s <XXREAL-0R3 m implies s inHIDDENR3 SetPrimenumberNEWTONK9 m \\/XBOOLE-0K2 {TARSKIK1 m}"
                    proof(rule impI)
                      assume A11: "s <XXREAL-0R3 m"
                      have A12: "SetPrimenumberNEWTONK9 m c=MEMBEREDR6 SetPrimenumberNEWTONK9 m \\/XBOOLE-0K2 {TARSKIK1 m}"
                        using xboole_1_th_7 sorry
                      have "s inTARSKIR2 SetPrimenumberNEWTONK9 m"
                        using A9 A11 newton_def_7 sorry
                      thus "s inHIDDENR3 SetPrimenumberNEWTONK9 m \\/XBOOLE-0K2 {TARSKIK1 m}"
                        using A12 sorry
                    qed
                    show " ?thesis "
                      using cases case1 case2 sorry
                  qed
                qed "sorry"
                thus "SetPrimenumberNEWTONK9 k c=MEMBEREDR6 SetPrimenumberNEWTONK9 m \\/XBOOLE-0K2 {TARSKIK1 m}"
                  using tarski_def_3 sorry
              qed
              have "SetPrimenumberNEWTONK9 m \\/XBOOLE-0K2 {TARSKIK1 m} c=MEMBEREDR6 SetPrimenumberNEWTONK9 k"
                using A3 A6 newton_th_76 sorry
              then have "SetPrimenumberNEWTONK9 k =MEMBEREDR12 SetPrimenumberNEWTONK9 m \\/XBOOLE-0K2 {TARSKIK1 m}"
                using A7 sorry
              thus "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 cardCARD-1K4 (SetPrimenumberNEWTONK9 k)"
                using A2 A4 card_2_th_41 sorry
              show "k be PrimeNEWTONM1"
                using A6 sorry
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have "SetPrimenumberNEWTONK9 \<two>\<^sub>M =XBOOLE-0R4 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : k <XXREAL-0R3 \<two>\<^sub>M & k be primeINT-2V1 }"
          using newton_lm_2 sorry
        then have A13: "?P1(0NUMBERSK6)"
          using card_1_th_27 int_2_th_28 sorry
        have " for n be NatNAT-1M1 holds ?P1(n)"
          using nat_1_sch_2 A13 A1 sorry
        then obtain m where
          [ty]:"m be NatNAT-1M1" and 
          A14: "n =XBOOLE-0R4 cardCARD-1K4 (SetPrimenumberNEWTONK9 m)"and A15: "m be PrimeNEWTONM1"
           sorry
        have "m inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        thus " not ( for VarFor1 be primeINT-2V1\<bar>ElementSUBSET-1M1-of NATNUMBERSK1 holds  not n =XBOOLE-0R4 cardCARD-1K4 (SetPrimenumberNEWTONK9 VarFor1))"
          using A14 A15 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be primeINT-2V1\<bar>ElementSUBSET-1M1-of NATNUMBERSK1 holds  for it2 be primeINT-2V1\<bar>ElementSUBSET-1M1-of NATNUMBERSK1 holds n =XBOOLE-0R4 cardCARD-1K4 (SetPrimenumberNEWTONK9 it1) & n =XBOOLE-0R4 cardCARD-1K4 (SetPrimenumberNEWTONK9 it2) implies it1 =HIDDENR1 it2"
    proof-
      have " for f be primeINT-2V1\<bar>ElementSUBSET-1M1-of NATNUMBERSK1 holds  for g be primeINT-2V1\<bar>ElementSUBSET-1M1-of NATNUMBERSK1 holds n =XBOOLE-0R4 cardCARD-1K4 (SetPrimenumberNEWTONK9 f) & n =XBOOLE-0R4 cardCARD-1K4 (SetPrimenumberNEWTONK9 g) implies (f <>HIDDENR2 g implies  False )"
      proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
        fix f assume [ty]: "f be primeINT-2V1\<bar>ElementSUBSET-1M1-of NATNUMBERSK1"
        fix g assume [ty]: "g be primeINT-2V1\<bar>ElementSUBSET-1M1-of NATNUMBERSK1"
        assume A16: "n =XBOOLE-0R4 cardCARD-1K4 (SetPrimenumberNEWTONK9 f)"
          and A17: "n =XBOOLE-0R4 cardCARD-1K4 (SetPrimenumberNEWTONK9 g)"
        assume A18: "f <>HIDDENR2 g"
        have "f <XXREAL-0R3 g & n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n or g <XXREAL-0R3 f & n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
        proof-
          have "f <XXREAL-0R3 g & n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n or g <XXREAL-0R3 f & (g <XXREAL-0R3 f implies n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n)"
          proof-
            show "f <XXREAL-0R3 g & n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n or g <XXREAL-0R3 f & (g <XXREAL-0R3 f implies n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n)"
            proof-
              have cases: "f <XXREAL-0R3 g or g <XXREAL-0R3 f"
                using A18 xxreal_0_th_1 sorry
              have case1: "f <XXREAL-0R3 g implies n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
              proof(rule impI)
                assume A19: "f <XXREAL-0R3 g"
                have A20: " not f inTARSKIR2 SetPrimenumberNEWTONK9 f"
                  using newton_def_7 sorry
                have "cardCARD-1K4 (SetPrimenumberNEWTONK9 f \\/XBOOLE-0K2 {TARSKIK1 f}) <=XXREAL-0R1 cardCARD-1K4 (SetPrimenumberNEWTONK9 g)"
                  using A19 newton_th_76 nat_1_th_43 sorry
                thus "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
                  using A16 A17 A20 card_2_th_41 sorry
              qed
              have case2: "g <XXREAL-0R3 f implies n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
              proof(rule impI)
                assume A21: "g <XXREAL-0R3 f"
                have A22: " not g inTARSKIR2 SetPrimenumberNEWTONK9 g"
                  using newton_def_7 sorry
                have "cardCARD-1K4 (SetPrimenumberNEWTONK9 g \\/XBOOLE-0K2 {TARSKIK1 g}) <=XXREAL-0R1 cardCARD-1K4 (SetPrimenumberNEWTONK9 f)"
                  using A21 newton_th_76 nat_1_th_43 sorry
                thus "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
                  using A16 A17 A22 card_2_th_41 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus " ?thesis "
             sorry
        qed
        thus " False "
          using nat_1_th_13 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem newton_th_78:
" for n be NatNAT-1M1 holds SetPrimenumberNEWTONK9 n =XBOOLE-0R4 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : k <XXREAL-0R3 n & k be primeINT-2V1 }"
  using newton_lm_2 sorry

(*\$N The Infinitude of Primes*)
mtheorem newton_th_79:
"SetPrimesNEWTONK8 be infiniteFINSET-1V2"
proof-
  have "SetPrimesNEWTONK8 be finiteFINSET-1V1 implies  False "
  proof(rule impI)
    assume A1: "SetPrimesNEWTONK8 be finiteFINSET-1V1"
    then obtain SP where 
      [ty]:"SP be finiteFINSET-1V1\<bar>setHIDDENM2" and SPDef:"SP = SetPrimesNEWTONK8"
       sorry
    obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A2: "(SetPrimesNEWTONK8,SegFINSEQ-1K2 n)are-equipotentTARSKIR3"
      using A1 finseq_1_th_56 sorry
    have "cardCARD-1K1 (SetPrimesNEWTONK8) =XBOOLE-0R4 cardCARD-1K4 (SegFINSEQ-1K2 n)"
      using A2 card_1_th_5 sorry
    then have "cardCARD-1K1 (SetPrimesNEWTONK8) =XBOOLE-0R4 cardCARD-1K4 n"
      using finseq_1_th_55 sorry
    then have A3: "cardCARD-1K4 SP =XBOOLE-0R4 n"
       sorry
    let ?p = "primenumberNEWTONK10 (n +NAT-1K1 \<one>\<^sub>M)"
    let ?SPp = "SetPrimenumberNEWTONK9 ?p"
    have A4: "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 cardCARD-1K4 (SetPrimenumberNEWTONK9 ?p)"
      using newton_def_8 sorry
    have "cardCARD-1K4 ?SPp <=XXREAL-0R1 cardCARD-1K4 SP"
      using newton_th_68 nat_1_th_43 sorry
    thus " False "
      using A3 A4 nat_1_th_13 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem newton_cl_16:
"cluster SetPrimesNEWTONK8 as-term-is  non emptyXBOOLE-0V1\<bar>infiniteFINSET-1V2"
proof
(*coherence*)
  show "SetPrimesNEWTONK8 be  non emptyXBOOLE-0V1\<bar>infiniteFINSET-1V2"
    using newton_th_79 sorry
qed "sorry"

reserve i for "NatNAT-1M1"
mtheorem newton_th_80:
" for i be NatNAT-1M1 holds i be primeINT-2V1 implies ( for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds i dividesNAT-DR1 m *XCMPLX-0K3 n implies i dividesNAT-DR1 m or i dividesNAT-DR1 n)"
proof-
  have " for i be NatNAT-1M1 holds i be primeINT-2V1 implies (( ex m be NatNAT-1M1 st  ex n be NatNAT-1M1 st i dividesNAT-DR1 m *XCMPLX-0K3 n &  not (i dividesNAT-DR1 m or i dividesNAT-DR1 n)) implies  not  True )"
  proof(rule ballI,rule impI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    let ?P = "\<lambda>Lamb1. Lamb1 be primeINT-2V1 & ( ex m be NatNAT-1M1 st  ex n be NatNAT-1M1 st (Lamb1 dividesNAT-DR1 m *XCMPLX-0K3 n &  not Lamb1 dividesNAT-DR1 m) &  not Lamb1 dividesNAT-DR1 n)"
    assume A1: "i be primeINT-2V1"
    assume Given: " ex m be NatNAT-1M1 st  ex n be NatNAT-1M1 st i dividesNAT-DR1 m *XCMPLX-0K3 n &  not (i dividesNAT-DR1 m or i dividesNAT-DR1 n)"
    then obtain m n where
      [ty]:"m be NatNAT-1M1" "n be NatNAT-1M1" and 
      A2: "i dividesNAT-DR1 m *XCMPLX-0K3 n"and A3: " not (i dividesNAT-DR1 m or i dividesNAT-DR1 n)"
       sorry
    have A4: " ex i be NatNAT-1M1 st ?P(i)"
      using A1 A2 A3 sorry
    obtain p9 where
      [ty]:"p9 be NatNAT-1M1" and 
      A5: "?P(p9)"and A6: " for p1 be NatNAT-1M1 holds ?P(p1) implies p9 <=XXREAL-0R1 p1"
      using nat_1_sch_5 A4 sorry
    let ?Q = "\<lambda>Lamb1.  ex n be NatNAT-1M1 st (p9 dividesNAT-DR1 Lamb1 *XCMPLX-0K3 n &  not p9 dividesNAT-DR1 Lamb1) &  not p9 dividesNAT-DR1 n"
    have A7: " ex i be NatNAT-1M1 st ?Q(i)"
      using A5 sorry
    obtain m where
      [ty]:"m be NatNAT-1M1" and 
      A8: "?Q(m)"and A9: " for m1 be NatNAT-1M1 holds ?Q(m1) implies m <=XXREAL-0R1 m1"
      using nat_1_sch_5 A7 sorry
    have A10: "m >XXREAL-0R4 0NUMBERSK6"
      using A8 sorry
    obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A11: "p9 dividesNAT-DR1 m *XCMPLX-0K3 n"and A12: " not p9 dividesNAT-DR1 m"and A13: " not p9 dividesNAT-DR1 n"
      using A8 sorry
    have A14: "m <XXREAL-0R3 p9"
    proof-
      have "m >=XXREAL-0R2 p9 implies  False "
      proof(rule impI)
        let ?m1 = "m modNAT-DK4 p9"
        assume A15: "m >=XXREAL-0R2 p9"
        have A16: "p9 >XXREAL-0R4 0NUMBERSK6"
          using A5 int_2_def_4 sorry
        then have "m =XBOOLE-0R4 p9 *XCMPLX-0K3 (m divNAT-DK3 p9) +NAT-1K1 ?m1"
          using nat_d_th_2 sorry
        then have A17: "m *XCMPLX-0K3 n =XBOOLE-0R4 (p9 *XCMPLX-0K3 (m divNAT-DK3 p9))*XCMPLX-0K3 n +XCMPLX-0K2 ?m1 *XCMPLX-0K3 n"
           sorry
        have "?m1 <XXREAL-0R3 p9"
          using A16 nat_d_th_1 sorry
        then have A18: "?m1 <XXREAL-0R3 m"
          using A15 xxreal_0_th_2 sorry
        have A19: "p9 dividesNAT-DR1 p9 *XCMPLX-0K3 (m divNAT-DK3 p9)"
          using nat_d_def_3 sorry
        have "p9 dividesNAT-DR1 p9 *XCMPLX-0K3 ((m divNAT-DK3 p9)*XCMPLX-0K3 n)"
          using nat_d_def_3 sorry
        then have A20: "p9 dividesNAT-DR1 ?m1 *XCMPLX-0K3 n"
          using A11 A17 nat_d_th_10 sorry
        have "m =XBOOLE-0R4 p9 *XCMPLX-0K3 (m divNAT-DK3 p9) +NAT-1K1 ?m1"
          using A16 nat_d_th_2 sorry
        then have " not p9 dividesNAT-DR1 ?m1"
          using A12 A19 nat_d_th_8 sorry
        thus " False "
          using A9 A13 A18 A20 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have A21: "m <XXREAL-0R3 \<two>\<^sub>M"
    proof-
      have "m >=XXREAL-0R2 \<two>\<^sub>M implies  False "
      proof(rule impI)
        assume "m >=XXREAL-0R2 \<two>\<^sub>M"
        then obtain p1 where
          [ty]:"p1 be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A22: "p1 be primeINT-2V1"and A23: "p1 dividesNAT-DR1 m"
          using int_2_th_31 sorry
        have A24: "p1 >XXREAL-0R4 \<one>\<^sub>M"
          using A22 int_2_def_4 sorry
        have A25: " not p1 dividesNAT-DR1 p9"
        proof-
          have "p1 dividesNAT-DR1 p9 implies  False "
          proof(rule impI)
            assume "p1 dividesNAT-DR1 p9"
            then have "p1 =XBOOLE-0R4 \<one>\<^sub>M or p1 =XBOOLE-0R4 p9"
              using A5 int_2_def_4 sorry
            thus " False "
              using A8 A22 A23 int_2_def_4 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have "p1 <=XXREAL-0R1 m"
          using A10 A23 nat_d_th_7 sorry
        then have A26: " not p9 <=XXREAL-0R1 p1"
          using A14 xxreal_0_th_2 sorry
        have A27: "p1 <>HIDDENR2 0NUMBERSK6"
          using A22 int_2_def_4 sorry
        obtain k where
          [ty]:"k be NatNAT-1M1" and 
          A28: "m *XCMPLX-0K3 n =XBOOLE-0R4 p9 *XCMPLX-0K3 k"
          using A11 nat_d_def_3 sorry
        have "p1 dividesNAT-DR1 p9 *XCMPLX-0K3 k"
          using A23 A28 nat_d_th_9 sorry
        then have "p1 dividesNAT-DR1 k"
          using A6 A22 A26 A25 sorry
        then obtain k1 where
          [ty]:"k1 be NatNAT-1M1" and 
          A29: "k =XBOOLE-0R4 p1 *XCMPLX-0K3 k1"
          using nat_d_def_3 sorry
        obtain m1 where
          [ty]:"m1 be NatNAT-1M1" and 
          A30: "m =XBOOLE-0R4 p1 *XCMPLX-0K3 m1"
          using A23 nat_d_def_3 sorry
        have A31: "m1 >XXREAL-0R4 0NUMBERSK6"
          using A8 A30 sorry
        have A32: "m1 <>HIDDENR2 m"
        proof-
          have "m1 =XBOOLE-0R4 m implies  False "
          proof(rule impI)
            assume "m1 =XBOOLE-0R4 m"
            then have "m =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 m1"
               sorry
            thus " False "
              using A24 A30 A31 xreal_1_th_68 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have "m1 dividesNAT-DR1 m"
          using A30 nat_d_def_3 sorry
        then have "m1 <=XXREAL-0R1 m"
          using A10 nat_d_th_7 sorry
        then have A33: "m1 <XXREAL-0R3 m"
          using A32 xxreal_0_th_1 sorry
        have "(p9 *XCMPLX-0K3 k1)*XCMPLX-0K3 p1 =XBOOLE-0R4 p1 *XCMPLX-0K3 (m1 *XCMPLX-0K3 n)"
          using A28 A29 A30 sorry
        then have "m1 *XCMPLX-0K3 n =XBOOLE-0R4 p9 *XCMPLX-0K3 k1"
          using A27 xcmplx_1_th_5 sorry
        then have A34: "p9 dividesNAT-DR1 m1 *XCMPLX-0K3 n"
          using nat_d_def_3 sorry
        have " not p9 dividesNAT-DR1 m1"
          using A12 A30 nat_d_th_9 sorry
        thus " False "
          using A9 A13 A33 A34 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "m >=XXREAL-0R2 \<two>\<^sub>M"
    proof-
      have "m <XXREAL-0R3 \<two>\<^sub>M implies  False "
      proof(rule impI)
        have A35: "m >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
          using A10 nat_1_th_13 sorry
        assume A36: "m <XXREAL-0R3 \<two>\<^sub>M"
        then have "m <=XXREAL-0R1 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
           sorry
        then have "m =XBOOLE-0R4 \<one>\<^sub>M"
          using A36 A35 nat_1_th_9 sorry
        thus " False "
          using A11 A13 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus " not  True "
      using A21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_81:
" for x be ComplexXCMPLX-0M1 holds x  |^NEWTONK1 \<two>\<^sub>M =XBOOLE-0R4 x *XCMPLX-0K3 x & x ^2SQUARE-1K1 =XBOOLE-0R4 x  |^NEWTONK1 \<two>\<^sub>M"
proof-
  have " for x be ComplexXCMPLX-0M1 holds x *XCMPLX-0K3 x =HIDDENR1 x  |^NEWTONK1 \<two>\<^sub>M & x ^2SQUARE-1K1 =XBOOLE-0R4 x  |^NEWTONK1 \<two>\<^sub>M"
  proof(rule ballI,rule conjMI)
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    have "x *XCMPLX-0K3 x =HIDDENR1 x  |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 x"
       sorry
    also have "... = x  |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
      using newton_th_6 sorry
    also have "... = x  |^NEWTONK1 \<two>\<^sub>M"
       sorry
    finally show "x *XCMPLX-0K3 x =HIDDENR1 x  |^NEWTONK1 \<two>\<^sub>M"
       sorry
    thus "x ^2SQUARE-1K1 =XBOOLE-0R4 x  |^NEWTONK1 \<two>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_82:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m divINT-1K5 n =HIDDENR1 m divNAT-DK3 n & m modINT-1K6 n =HIDDENR1 m modNAT-DK4 n"
   sorry

reserve x for "RealXREAL-0M1"
mtheorem newton_th_83:
" for k be NatNAT-1M1 holds  for x be RealXREAL-0M1 holds x >XXREAL-0R4 0NUMBERSK6 implies x  |^NEWTONK1 k >XXREAL-0R4 0NUMBERSK6"
proof-
  have " for k be NatNAT-1M1 holds  for x be RealXREAL-0M1 holds  not ( not x >XXREAL-0R4 0NUMBERSK6 & x  |^NEWTONK1 k >XXREAL-0R4 0NUMBERSK6)"
  proof(rule ballI,rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix x assume [ty]: "x be RealXREAL-0M1"
    let ?P = "\<lambda>Lamb1.  for x be RealXREAL-0M1 holds x >XXREAL-0R4 0NUMBERSK6 implies x  |^NEWTONK1 Lamb1 >XXREAL-0R4 0NUMBERSK6"
    have A1: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds ( for x be RealXREAL-0M1 holds x >XXREAL-0R4 0NUMBERSK6 implies x  |^NEWTONK1 k >XXREAL-0R4 0NUMBERSK6) implies ( for x be RealXREAL-0M1 holds x >XXREAL-0R4 0NUMBERSK6 implies  not x  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 0NUMBERSK6)"
      proof(rule ballI,rule impI,rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A2: " for x be RealXREAL-0M1 holds x >XXREAL-0R4 0NUMBERSK6 implies x  |^NEWTONK1 k >XXREAL-0R4 0NUMBERSK6"
        fix x assume [ty]: "x be RealXREAL-0M1"
        have A3: "x  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 x *XCMPLX-0K3 x  |^NEWTONK1 k"
          using newton_th_6 sorry
        assume A4: "x >XXREAL-0R4 0NUMBERSK6"
        then have "x  |^NEWTONK1 k >XXREAL-0R4 0NUMBERSK6"
          using A2 sorry
        thus " not x  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 0NUMBERSK6"
          using A4 A3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A5: "?P(0NUMBERSK6)"
      using rvsum_1_th_94 sorry
    have " for k be NatNAT-1M1 holds ?P(k)"
      using nat_1_sch_2 A5 A1 sorry
    thus " not ( not x >XXREAL-0R4 0NUMBERSK6 & x  |^NEWTONK1 k >XXREAL-0R4 0NUMBERSK6)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_84:
" for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies (0NUMBERSK6) |^NEWTONK1 n =XBOOLE-0R4 0NUMBERSK6"
proof-
  have " for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies (0NUMBERSK6) |^NEWTONK1 n =XBOOLE-0R4 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    assume "n >XXREAL-0R4 0NUMBERSK6"
    then have "n >=XXREAL-0R2 \<one>\<^sub>M +NAT-1K1 0NUMBERSK6"
      using nat_1_th_13 sorry
    thus "(0NUMBERSK6) |^NEWTONK1 n =XBOOLE-0R4 0NUMBERSK6"
      using newton_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) NEWTONK11(" _  |^NEWTONK11  _ " [190,190]190) where
  "m  |^NEWTONK11 n \<equiv> m  |^NEWTONK1 n"

mtheorem newton_add_3:
  mlet "m be ElementSUBSET-1M1-of NATNUMBERSK1", "n be ElementSUBSET-1M1-of NATNUMBERSK1"
"cluster m  |^NEWTONK1 n as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "m  |^NEWTONK1 n be ElementSUBSET-1M1-of NATNUMBERSK1"
    using ordinal1_def_12 sorry
qed "sorry"

mlemma newton_lm_3:
" for i be NatNAT-1M1 holds \<two>\<^sub>M <=XXREAL-0R1 i implies i  |^NEWTONK1 (0NUMBERSK6) >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
  using rvsum_1_th_94 sorry

mlemma newton_lm_4:
" for n be NatNAT-1M1 holds ( for i be NatNAT-1M1 holds \<two>\<^sub>M <=XXREAL-0R1 i implies i  |^NEWTONK1 n >=XXREAL-0R2 n +NAT-1K1 \<one>\<^sub>M) implies ( for i be NatNAT-1M1 holds \<two>\<^sub>M <=XXREAL-0R1 i implies i  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
proof(rule ballI,rule impI,rule ballI,rule impI)
  fix n assume [ty]: "n be NatNAT-1M1"
  assume A0: " for i be NatNAT-1M1 holds \<two>\<^sub>M <=XXREAL-0R1 i implies i  |^NEWTONK1 n >=XXREAL-0R2 n +NAT-1K1 \<one>\<^sub>M"
  fix i assume [ty]: "i be NatNAT-1M1"
  assume A4: "\<two>\<^sub>M <=XXREAL-0R1 i"
  have "i  |^NEWTONK1 n >=XXREAL-0R2 n +NAT-1K1 \<one>\<^sub>M"
    using A0 A4 sorry
  then have A2: "i *XCMPLX-0K3 i  |^NEWTONK1 n >=XXREAL-0R2 i *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)"
    using xreal_1_th_64 sorry
  have A1: "i  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 i *XCMPLX-0K3 i  |^NEWTONK1 n"
    using newton_th_6 sorry
  have A3: "\<two>\<^sub>M +XCMPLX-0K2 n <=XXREAL-0R1 i +XCMPLX-0K2 n"
    using A4 xreal_1_th_6 sorry
  have "\<one>\<^sub>M <=XXREAL-0R1 i"
    using A4 xxreal_0_th_2 sorry
  then have "i *XCMPLX-0K3 n >=XXREAL-0R2 n"
    using xreal_1_th_151 sorry
  then have "i *XCMPLX-0K3 n +XCMPLX-0K2 i >=XXREAL-0R2 n +XCMPLX-0K2 i"
    using xreal_1_th_6 sorry
  then have "i *XCMPLX-0K3 i  |^NEWTONK1 n >=XXREAL-0R2 n +XCMPLX-0K2 i"
    using A2 xxreal_0_th_2 sorry
  thus "i  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
    using A1 A3 xxreal_0_th_2 sorry
qed "sorry"

mtheorem newton_th_85:
" for n be NatNAT-1M1 holds  for i be NatNAT-1M1 holds \<two>\<^sub>M <=XXREAL-0R1 i implies i  |^NEWTONK1 n >=XXREAL-0R2 n +NAT-1K1 \<one>\<^sub>M"
proof-
  have " for n be NatNAT-1M1 holds  for i be NatNAT-1M1 holds  not (\<two>\<^sub>M <=XXREAL-0R1 i &  not i  |^NEWTONK1 n >=XXREAL-0R2 n +NAT-1K1 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix i assume [ty]: "i be NatNAT-1M1"
    have " for n be NatNAT-1M1 holds  for i be NatNAT-1M1 holds \<two>\<^sub>M <=XXREAL-0R1 i implies i  |^NEWTONK1 n >=XXREAL-0R2 n +NAT-1K1 \<one>\<^sub>M"
      using nat_1_sch_2 newton_lm_3 newton_lm_4 sorry
    thus " not (\<two>\<^sub>M <=XXREAL-0R1 i &  not i  |^NEWTONK1 n >=XXREAL-0R2 n +NAT-1K1 \<one>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_86:
" for n be NatNAT-1M1 holds  for i be NatNAT-1M1 holds \<two>\<^sub>M <=XXREAL-0R1 i implies i  |^NEWTONK1 n >XXREAL-0R4 n"
proof-
  have " for n be NatNAT-1M1 holds  for i be NatNAT-1M1 holds \<two>\<^sub>M <=XXREAL-0R1 i implies  not i  |^NEWTONK1 n >XXREAL-0R4 n"
  proof(rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix i assume [ty]: "i be NatNAT-1M1"
    assume "\<two>\<^sub>M <=XXREAL-0R1 i"
    then have "i  |^NEWTONK1 n >=XXREAL-0R2 n +NAT-1K1 \<one>\<^sub>M"
      using newton_th_85 sorry
    thus " not i  |^NEWTONK1 n >XXREAL-0R4 n"
      using nat_1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve k for "NatNAT-1M1"
theorem newton_sch_1:
  fixes Ff1 Gf1 af0 bf0 
  assumes
[ty_func]: "\<And> x1. x1 be NatNAT-1M1 \<Longrightarrow> Ff1(x1) be ElementSUBSET-1M1-of NATNUMBERSK1" and
  [ty_func]: "\<And> x1. x1 be NatNAT-1M1 \<Longrightarrow> Gf1(x1) be ElementSUBSET-1M1-of NATNUMBERSK1" and
  [ty]: "af0 be ElementSUBSET-1M1-of NATNUMBERSK1" and
  [ty]: "bf0 be ElementSUBSET-1M1-of NATNUMBERSK1" and
   A1: "0NUMBERSK6 <XXREAL-0R3 bf0" and
   A2: "bf0 <XXREAL-0R3 af0" and
   A3: "Ff1(0NUMBERSK6) =XBOOLE-0R4 af0" and
   A4: "Gf1(0NUMBERSK6) =XBOOLE-0R4 bf0" and
   A5: " for k be NatNAT-1M1 holds Gf1(k) >XXREAL-0R4 0NUMBERSK6 implies Ff1(k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Gf1(k) & Gf1(k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Ff1(k) modNAT-DK4 Gf1(k)"
  shows " ex k be NatNAT-1M1 st Ff1(k) =XBOOLE-0R4 af0 gcdNAT-DK8 bf0 & Gf1(k) =XBOOLE-0R4 0NUMBERSK6"
  proof-
    have " ex tVar12 be NatNAT-1M1 st Ff1(tVar12) =XBOOLE-0R4 af0 gcdNAT-DK8 bf0 & Gf1(tVar12) =HIDDENR1 0NUMBERSK6"
    proof-
      let ?F = "\<lambda>Lamb1. \<lambda>Lamb2. IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Lamb2,0NUMBERSK6,0NUMBERSK6,Gf1(Lamb1))"
      obtain q where
        [ty]:"q be sequenceNAT-1M2-of NATNUMBERSK1" and 
        A6: "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 af0"and A7: " for i be NatNAT-1M1 holds q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 ?F(i,q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> i)"
        using nat_1_sch_12 sorry
      let ?Q = "\<lambda>Lamb1. q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> Lamb1"
      have "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (0NUMBERSK6),0NUMBERSK6,0NUMBERSK6,Gf1(0NUMBERSK6))"
        using A7 sorry
      also have "... = Gf1(0NUMBERSK6)"
        using A2 A6 funcop_1_def_8 sorry
      finally have "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Gf1(0NUMBERSK6)"
         sorry
      then have A8: "?Q(0NUMBERSK6) =XBOOLE-0R4 af0 & ?Q(\<one>\<^sub>M) =XBOOLE-0R4 bf0"
        using A4 A6 sorry
      have A9: " for k be NatNAT-1M1 holds q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k >XXREAL-0R4 0NUMBERSK6 implies q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k =XBOOLE-0R4 Ff1(k)"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A10: "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k >XXREAL-0R4 0NUMBERSK6"
        have "k =XBOOLE-0R4 0NUMBERSK6 & q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k =XBOOLE-0R4 Ff1(k) or k <>HIDDENR2 0NUMBERSK6 & (k <>HIDDENR2 0NUMBERSK6 implies q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k =XBOOLE-0R4 Ff1(k))"
        proof-
          show "k =XBOOLE-0R4 0NUMBERSK6 & q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k =XBOOLE-0R4 Ff1(k) or k <>HIDDENR2 0NUMBERSK6 & (k <>HIDDENR2 0NUMBERSK6 implies q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k =XBOOLE-0R4 Ff1(k))"
          proof-
            have cases: "k =XBOOLE-0R4 0NUMBERSK6 or k <>HIDDENR2 0NUMBERSK6"
               sorry
            have case1: "k =XBOOLE-0R4 0NUMBERSK6 implies q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k =XBOOLE-0R4 Ff1(k)"
            proof(rule impI)
              assume "k =XBOOLE-0R4 0NUMBERSK6"
              thus "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k =XBOOLE-0R4 Ff1(k)"
                using A3 A6 sorry
            qed
            have case2: "k <>HIDDENR2 0NUMBERSK6 implies q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k =XBOOLE-0R4 Ff1(k)"
            proof(rule impI)
              assume "k <>HIDDENR2 0NUMBERSK6"
              then obtain i where
                [ty]:"i be NatNAT-1M1" and 
                A11: "k =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M"
                using nat_1_th_6 sorry
              have 
                [ty]:"i be ElementSUBSET-1M1-of NATNUMBERSK1"
                using ordinal1_def_12 sorry
              have A12: "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> i =XBOOLE-0R4 0NUMBERSK6 implies  False "
              proof(rule impI)
                assume A13: "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> i =XBOOLE-0R4 0NUMBERSK6"
                have "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k =HIDDENR1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> i,0NUMBERSK6,0NUMBERSK6,Gf1(i))"
                  using A7 A11 sorry
                also have "... = 0NUMBERSK6"
                  using A13 funcop_1_def_8 sorry
                finally have "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k =HIDDENR1 0NUMBERSK6"
                   sorry
                thus " False "
                  using A10 sorry
              qed
              have "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k =HIDDENR1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> i,0NUMBERSK6,0NUMBERSK6,Gf1(i))"
                using A7 A11 sorry
              also have "... = Gf1(i)"
                using A12 funcop_1_def_8 sorry
              finally have "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k =HIDDENR1 Gf1(i)"
                 sorry
              thus "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k =XBOOLE-0R4 Ff1(k)"
                using A5 A10 A11 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k =XBOOLE-0R4 Ff1(k)"
           sorry
      qed "sorry"
      have A14: " for k be NatNAT-1M1 holds ?Q(k +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 ?Q(k) modNAT-DK4 ?Q(k +NAT-1K1 \<one>\<^sub>M)"
      proof-
        have " for k be NatNAT-1M1 holds q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k modNAT-DK4 q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
        proof(rule ballI)
          fix k assume [ty]: "k be NatNAT-1M1"
          have "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 0NUMBERSK6 & q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k modNAT-DK4 q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) or q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6 & (q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6 implies q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<two>\<^sub>M) =HIDDENR1 q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k modNAT-DK4 q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
          proof-
            show "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 0NUMBERSK6 & q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k modNAT-DK4 q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) or q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6 & (q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6 implies q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<two>\<^sub>M) =HIDDENR1 q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k modNAT-DK4 q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
            proof-
              have cases: "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 0NUMBERSK6 or q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6"
                 sorry
              have case1: "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 0NUMBERSK6 implies q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k modNAT-DK4 q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
              proof(rule impI)
                assume A15: "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 0NUMBERSK6"
                have A16: "Gf1(k) =XBOOLE-0R4 0NUMBERSK6 implies  False "
                proof(rule impI)
                  have A17: "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k =XBOOLE-0R4 0NUMBERSK6 or q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k <>HIDDENR2 0NUMBERSK6"
                     sorry
                  assume A18: "Gf1(k) =XBOOLE-0R4 0NUMBERSK6"
                  have "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k,0NUMBERSK6,0NUMBERSK6,Gf1(k))"
                    using A7 sorry
                  also have "... = 0NUMBERSK6"
                    using A18 A17 funcop_1_def_8 sorry
                  finally have "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 0NUMBERSK6"
                     sorry
                  thus " False "
                    using A15 sorry
                qed
                have A19: "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
                   sorry
                also have "... = IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M),0NUMBERSK6,0NUMBERSK6,Gf1(k +NAT-1K1 \<one>\<^sub>M))"
                  using A7 sorry
                also have "... = Gf1(k +NAT-1K1 \<one>\<^sub>M)"
                  using A15 funcop_1_def_8 sorry
                also have "... = Ff1(k) modNAT-DK4 Gf1(k)"
                  using A5 A16 sorry
                finally have "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 Ff1(k) modNAT-DK4 Gf1(k)"
                   sorry
                have A20: "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k =XBOOLE-0R4 0NUMBERSK6 implies  False "
                proof(rule impI)
                  assume A21: "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k =XBOOLE-0R4 0NUMBERSK6"
                  have "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k,0NUMBERSK6,0NUMBERSK6,Gf1(k))"
                    using A7 sorry
                  also have "... = 0NUMBERSK6"
                    using A21 funcop_1_def_8 sorry
                  finally have "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 0NUMBERSK6"
                     sorry
                  thus " False "
                    using A15 sorry
                qed
                have "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k,0NUMBERSK6,0NUMBERSK6,Gf1(k))"
                  using A7 sorry
                also have "... = Gf1(k)"
                  using A20 funcop_1_def_8 sorry
                finally have "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Gf1(k)"
                   sorry
                thus "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k modNAT-DK4 q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
                  using A9 A19 A20 sorry
              qed
              have case2: "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6 implies q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<two>\<^sub>M) =HIDDENR1 q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k modNAT-DK4 q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
              proof(rule impI)
                assume A22: "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6"
                have "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<two>\<^sub>M) =HIDDENR1 q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
                   sorry
                also have "... = IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M),0NUMBERSK6,0NUMBERSK6,Gf1(k +NAT-1K1 \<one>\<^sub>M))"
                  using A7 sorry
                also have "... = 0NUMBERSK6"
                  using A22 funcop_1_def_8 sorry
                also have "... = q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k modNAT-DK4 q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
                  using A22 nat_d_def_2 sorry
                finally show "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<two>\<^sub>M) =HIDDENR1 q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k modNAT-DK4 q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
                   sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k modNAT-DK4 q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have A23: "0NUMBERSK6 <XXREAL-0R3 bf0 & bf0 <XXREAL-0R3 af0"
        using A1 A2 sorry
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A24: "?Q(k) =XBOOLE-0R4 af0 gcdNAT-DK8 bf0 & ?Q(k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6"
        using nat_d_sch_1 A23 A8 A14 sorry
      show " ex tVar12 be NatNAT-1M1 st Ff1(tVar12) =XBOOLE-0R4 af0 gcdNAT-DK8 bf0 & Gf1(tVar12) =HIDDENR1 0NUMBERSK6"
      proof(rule bexI[of _ "k"],rule conjMI)
        show "Ff1(k) =XBOOLE-0R4 af0 gcdNAT-DK8 bf0"
          using A1 A9 A24 newton_th_58 sorry
        have "af0 gcdNAT-DK8 bf0 >XXREAL-0R4 0NUMBERSK6"
          using A1 newton_th_58 sorry
        then have "Gf1(k) =HIDDENR1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(q .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k,0NUMBERSK6,0NUMBERSK6,Gf1(k))"
          using A24 funcop_1_def_8 sorry
        also have "... = 0NUMBERSK6"
          using A7 A24 sorry
        finally show "Gf1(k) =HIDDENR1 0NUMBERSK6"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

reserve k, n, n1, n2, m1, m2 for "NatNAT-1M1"
mtheorem newton_th_87:
" for r be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be NatNAT-1M1 holds r <>HIDDENR2 0NUMBERSK6 or n =XBOOLE-0R4 0NUMBERSK6 iff r  |^NEWTONK1 n <>HIDDENR2 0NUMBERSK6"
proof-
  have " for r be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be NatNAT-1M1 holds  not ( not (r <>HIDDENR2 0NUMBERSK6 &  not n =XBOOLE-0R4 0NUMBERSK6) & r  |^NEWTONK1 n <>HIDDENR2 0NUMBERSK6) &  not (( not r  |^NEWTONK1 n <>HIDDENR2 0NUMBERSK6 & r <>HIDDENR2 0NUMBERSK6) &  not n =XBOOLE-0R4 0NUMBERSK6)"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?P = "\<lambda>Lamb1. r <>HIDDENR2 0NUMBERSK6 or Lamb1 =XBOOLE-0R4 0NUMBERSK6 iff r  |^NEWTONK1 Lamb1 <>HIDDENR2 0NUMBERSK6"
    have A1: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds (r <>HIDDENR2 0NUMBERSK6 or k =XBOOLE-0R4 0NUMBERSK6 iff r  |^NEWTONK1 k <>HIDDENR2 0NUMBERSK6) implies (r <>HIDDENR2 0NUMBERSK6 or k +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6 iff r  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 0NUMBERSK6)"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A2: "?P(k)"
        have "r  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 r  |^NEWTONK1 k *XCMPLX-0K3 r"
          using newton_th_6 sorry
        thus "r <>HIDDENR2 0NUMBERSK6 or k +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6 iff r  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 0NUMBERSK6"
          using A2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A3: "?P(0NUMBERSK6)"
      using rvsum_1_th_94 sorry
    have " for k be NatNAT-1M1 holds ?P(k)"
      using nat_1_sch_2 A3 A1 sorry
    thus " not ( not (r <>HIDDENR2 0NUMBERSK6 &  not n =XBOOLE-0R4 0NUMBERSK6) & r  |^NEWTONK1 n <>HIDDENR2 0NUMBERSK6) &  not (( not r  |^NEWTONK1 n <>HIDDENR2 0NUMBERSK6 & r <>HIDDENR2 0NUMBERSK6) &  not n =XBOOLE-0R4 0NUMBERSK6)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma newton_lm_5:
" for n1 be NatNAT-1M1 holds  for n2 be NatNAT-1M1 holds  for m1 be NatNAT-1M1 holds  for m2 be NatNAT-1M1 holds \<two>\<^sub>M  |^NEWTONK1 n1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m1 +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK1 n2 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m2 +NAT-1K1 \<one>\<^sub>M) implies n1 <=XXREAL-0R1 n2"
proof-
  have " for n1 be NatNAT-1M1 holds  for n2 be NatNAT-1M1 holds  for m1 be NatNAT-1M1 holds  for m2 be NatNAT-1M1 holds \<two>\<^sub>M  |^NEWTONK1 n1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m1 +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK1 n2 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m2 +NAT-1K1 \<one>\<^sub>M) implies (n1 >XXREAL-0R4 n2 implies  False )"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix n1 assume [ty]: "n1 be NatNAT-1M1"
    fix n2 assume [ty]: "n2 be NatNAT-1M1"
    fix m1 assume [ty]: "m1 be NatNAT-1M1"
    fix m2 assume [ty]: "m2 be NatNAT-1M1"
    assume A1: "\<two>\<^sub>M  |^NEWTONK1 n1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m1 +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK1 n2 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m2 +NAT-1K1 \<one>\<^sub>M)"
    assume A2: "n1 >XXREAL-0R4 n2"
    then obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A3: "n1 =XBOOLE-0R4 n2 +XCMPLX-0K2 n"
      using nat_1_th_10 sorry
    have "n <>HIDDENR2 0NUMBERSK6"
      using A2 A3 sorry
    then obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A4: "n =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_6 sorry
    have A5: "\<two>\<^sub>M  |^NEWTONK1 n2 <>HIDDENR2 0NUMBERSK6"
      using newton_th_87 sorry
    have 
      [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    have "\<two>\<^sub>M  |^NEWTONK1 n1 =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK1 n2 *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK11 (k +NAT-1K1 \<one>\<^sub>M)"
      using A3 A4 newton_th_8 sorry
    then have "\<two>\<^sub>M  |^NEWTONK1 n1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m1 +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK1 n2 *XCMPLX-0K3 (\<two>\<^sub>M  |^NEWTONK11 (k +NAT-1K1 \<one>\<^sub>M) *NAT-1K2 (\<two>\<^sub>M *XCMPLX-0K3 m1 +NAT-1K1 \<one>\<^sub>M))"
       sorry
    then have "\<two>\<^sub>M  |^NEWTONK11 (k +NAT-1K1 \<one>\<^sub>M) *NAT-1K2 (\<two>\<^sub>M *XCMPLX-0K3 m1 +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 m2 +NAT-1K1 \<one>\<^sub>M"
      using A1 A5 xcmplx_1_th_5 sorry
    then have "\<two>\<^sub>M *XCMPLX-0K3 m2 +NAT-1K1 \<one>\<^sub>M =HIDDENR1 (\<two>\<^sub>M  |^NEWTONK11 k *NAT-1K2 \<two>\<^sub>M  |^NEWTONK11 \<one>\<^sub>M)*NAT-1K2 (\<two>\<^sub>M *XCMPLX-0K3 m1 +NAT-1K1 \<one>\<^sub>M)"
      using newton_th_8 sorry
    also have "... = \<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M  |^NEWTONK11 k *NAT-1K2 (\<two>\<^sub>M *XCMPLX-0K3 m1 +NAT-1K1 \<one>\<^sub>M))"
       sorry
    finally have "\<two>\<^sub>M *XCMPLX-0K3 m2 +NAT-1K1 \<one>\<^sub>M =HIDDENR1 \<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M  |^NEWTONK11 k *NAT-1K2 (\<two>\<^sub>M *XCMPLX-0K3 m1 +NAT-1K1 \<one>\<^sub>M))"
       sorry
    then have A6: "\<two>\<^sub>M dividesNAT-DR1 \<two>\<^sub>M *XCMPLX-0K3 m2 +NAT-1K1 \<one>\<^sub>M"
      using nat_d_def_3 sorry
    have "\<two>\<^sub>M dividesNAT-DR1 \<two>\<^sub>M *XCMPLX-0K3 m2"
      using nat_d_def_3 sorry
    thus " False "
      using A6 nat_d_th_7 nat_d_th_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_88:
" for n1 be NatNAT-1M1 holds  for n2 be NatNAT-1M1 holds  for m1 be NatNAT-1M1 holds  for m2 be NatNAT-1M1 holds \<two>\<^sub>M  |^NEWTONK1 n1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m1 +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK1 n2 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m2 +NAT-1K1 \<one>\<^sub>M) implies n1 =XBOOLE-0R4 n2 & m1 =XBOOLE-0R4 m2"
proof-
  have " for n1 be NatNAT-1M1 holds  for n2 be NatNAT-1M1 holds  for m1 be NatNAT-1M1 holds  for m2 be NatNAT-1M1 holds \<two>\<^sub>M  |^NEWTONK1 n1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m1 +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK1 n2 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m2 +NAT-1K1 \<one>\<^sub>M) implies n1 =XBOOLE-0R4 n2 & m1 =XBOOLE-0R4 m2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix n1 assume [ty]: "n1 be NatNAT-1M1"
    fix n2 assume [ty]: "n2 be NatNAT-1M1"
    fix m1 assume [ty]: "m1 be NatNAT-1M1"
    fix m2 assume [ty]: "m2 be NatNAT-1M1"
    have A1: "\<two>\<^sub>M  |^NEWTONK1 n1 <>HIDDENR2 0NUMBERSK6"
      using newton_th_87 sorry
    assume A2: "\<two>\<^sub>M  |^NEWTONK1 n1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m1 +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK1 n2 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m2 +NAT-1K1 \<one>\<^sub>M)"
    then have A3: "n2 <=XXREAL-0R1 n1"
      using newton_lm_5 sorry
    have "n1 <=XXREAL-0R1 n2"
      using A2 newton_lm_5 sorry
    thus "n1 =XBOOLE-0R4 n2"
      using A3 xxreal_0_th_1 sorry
    then have "\<two>\<^sub>M *XCMPLX-0K3 m1 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 m2 +NAT-1K1 \<one>\<^sub>M"
      using A2 A1 xcmplx_1_th_5 sorry
    thus "m1 =XBOOLE-0R4 m2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem newton_th_89:
" for m be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies m  |^NEWTONK1 k dividesNAT-DR1 m  |^NEWTONK1 n"
proof-
  have " for m be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies m  |^NEWTONK1 k dividesNAT-DR1 m  |^NEWTONK1 n"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix m assume [ty]: "m be NatNAT-1M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume "k <=XXREAL-0R1 n"
    then obtain t where
      [ty]:"t be NatNAT-1M1" and 
      A1: "n =XBOOLE-0R4 k +XCMPLX-0K2 t"
      using nat_1_th_10 sorry
    have 
      [ty]:"t be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    have "m  |^NEWTONK1 n =XBOOLE-0R4 m  |^NEWTONK1 k *XCMPLX-0K3 m  |^NEWTONK1 t"
      using A1 newton_th_8 sorry
    thus "m  |^NEWTONK1 k dividesNAT-DR1 m  |^NEWTONK1 n"
      using nat_d_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
